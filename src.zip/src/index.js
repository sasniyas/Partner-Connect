import React from "react";
import ReactDOM from "react-dom/client";
import "./global.css";
import App from "./App";
import store from "./store/store";
import { Provider } from "react-redux";
import { fetchLoggedInUser } from "./store/userSlice";

import { PublicClientApplication } from "@azure/msal-browser";
import { MsalProvider } from "@azure/msal-react";
import { msalConfig } from "./authConfig";

// 1️⃣ Create MSAL instance (OUTSIDE function)
const msalInstance = new PublicClientApplication(msalConfig);

async function initApp() {
  // ✅ VERY IMPORTANT — initialize MSAL FIRST
  await msalInstance.initialize();

  // ✅ Handle redirect response globally (best practice)
  await msalInstance.handleRedirectPromise();

  // 🔹 Your existing app token logic (keep this)
 const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");

  if (token) {
    await store.dispatch(fetchLoggedInUser()); 
    // Wait for user data BEFORE rendering the UI
  }

  const root = ReactDOM.createRoot(document.getElementById("root"));
  root.render(
    <React.StrictMode>
      <Provider store={store}>
        <MsalProvider instance={msalInstance}>
          <App/>
        </MsalProvider>
      </Provider>
    </React.StrictMode>
  );
}

initApp();