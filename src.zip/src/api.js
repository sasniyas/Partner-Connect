import CreatePassword from "./pages/CreatePassword/CreatePassword";

export const API = {
  //domain: "https://partnerconnect-testenv-bsgsebgdexfmf7bz.centralindia-01.azurewebsites.net",
  domain: "http://localhost:3001",
  endpoints: {
    // Notification endpoints
    getUserNotificationsByUserId: "/getUserNotificationsByUserId",
    markNotificationAsSeen: "/toggleUserNotificationSeenStatus/toggle",
    bulkMarkNotificationsAsSeen: "/bulkToggleUserNotificationSeenStatus",
    deleteNotification: "/deleteNotification",

    // Ticket endpoints
    addTicket: "/addTicket",
    getAllTickets: "/getAllTickets",
    getTicketByUserId: "/getTicketByUserId",
    getTicketById: "/getTicketById/",
    updateTicket: "/updateTicket",
    deleteTicket: "/deleteTicket/",
    toggleTicketStatus: "/toggleTicketStatus/",

    // Ticket Comment endpoints
    addTicketComment: "/addTicketComment",
    getCommentsByTicketId: "/getCommentsByTicketId/",
    getTicketCommentById: "/getTicketCommentById/",
    updateTicketComment: "/updateTicketComment",
    deleteTicketComment: "/deleteTicketComment/",
    toggleTicketCommentStatus: "/toggleTicketCommentStatus/",

    // Ticket Attachment endpoints
    addTicketAttachment: "/addTicketAttachment",
    getAttachmentsByTicketId: "/getAttachmentsByTicketId/",
    getTicketAttachmentById: "/getTicketAttachmentById/",
    deleteTicketAttachment: "/deleteTicketAttachment/",
    toggleTicketAttachmentStatus: "/toggleTicketAttachmentStatus/",

    updateDefaultPreTemplate: "/updateDefaultPreTemplate",
    getDefaultPreTemplate: "/getDefaultPreTemplate",
    addPresentationTemplate: "/addPresentationTemplate", // POST: Add a new presentation template
    getPresentationTemplates: "/getPresentationTemplates", // GET: Retrieve all presentation templates
    updatePresentationTemplate: "/updatePresentationTemplate", // PUT: Update an existing presentation template
    togglePresentationTemplate: "/togglePresentationTemplate/toggle/", // PATCH: Toggle enable/disable for a presentation template
    deletePresentationTemplate: "/deletePresentationTemplate/", // DELETE: Remove a presentation template
    bulkAddPresentationTemplate: "/bulkAddPresentationTemplate",

    // PresentationTemplateCategory endpoints
    addPresentationTemplateCategory: "/addPresentationTemplateCategory", // POST: Add a new presentation template category
    getPresentationTemplateCategories: "/getPresentationTemplateCategories", // GET: Retrieve all presentation template categories
    getCategoriesByTemplateId: "/getCategoriesByTemplateId/", // GET: Get categories by template ID
    updatePresentationTemplateCategory: "/updatePresentationTemplateCategory", // PUT: Update an existing presentation template category
    deletePresentationTemplateCategory: "/deletePresentationTemplateCategory/", // DELETE: Remove a presentation template category (soft delete)

    // FinanceTemplate endpoints

    updateDefaultFinTemplate: "/updateDefaultFinTemplate",
    getDefaultFinTemplate: "/getDefaultFinTemplate",
    addFinanceTemplate: "/addFinanceTemplate", // POST: Add a new finance template
    getFinanceTemplates: "/getFinanceTemplates", // GET: Retrieve all finance templates
    updateFinanceTemplate: "/updateFinanceTemplate", // PUT: Update an existing finance template
    toggleFinanceTemplate: "/toggleFinanceTemplate/toggle/", // PATCH: Toggle enable/disable for a finance template
    deleteFinanceTemplate: "/deleteFinanceTemplate/", // DELETE: Remove a finance template
    bulkAddFinanceTemplate: "/bulkAddFinanceTemplate",

    // FinanceTemplateCategory endpoints
    addFinanceTemplateCategory: "/addFinanceTemplateCategory", // POST: Add a new finance template category
    getFinanceTemplateCategories: "/getFinanceTemplateCategories", // GET: Retrieve all finance template categories
    getCategoriesByFinanceTemplateId: "/getCategoriesByFinanceTemplateId/", // GET: Get categories by template ID
    updateFinanceTemplateCategory: "/updateFinanceTemplateCategory", // PUT: Update an existing finance template category
    deleteFinanceTemplateCategory: "/deleteFinanceTemplateCategory/", // DELETE: Remove a finance template category

    // Equipment endpoints
    addEquipment: "/addEquipment", // POST: Add a new equipment
    getEquipments: "/getEquipments", // GET: Retrieve all equipments
    updateEquipment: "/updateEquipment", // PUT: Update an existing equipment
    toggleEquipment: "/toggleEquipment/toggle/", // PATCH: Toggle enable/disable for an equipment
    deleteEquipment: "/deleteEquipment/", // DELETE: Remove an equipment
    bulkAddEquipment: "/bulkAddEquipment",

    // UptimePartsCategory endpoints
    addUptimePartsCategory: "/addUptimePartsCategory", // POST: Add a new uptime parts category
    getUptimePartsCategories: "/getUptimePartsCategories", // GET: Retrieve all uptime parts categories
    updateUptimePartsCategory: "/updateUptimePartsCategory", // PUT: Update an existing uptime parts category
    toggleUptimePartsCategory: "/toggleUptimePartsCategory/toggle/", // PATCH: Toggle enable/disable for an uptime parts category
    deleteUptimePartsCategory: "/deleteUptimePartsCategory/", // DELETE: Remove an uptime parts category
    bulkAddUptimePartsCategory: "/bulkAddUptimePartsCategory",

    // Infrastructure endpoints
    addInfrastructure: "/addInfrastructure", // POST: Add a new infrastructure
    getInfrastructures: "/getInfrastructures", // GET: Retrieve all infrastructures
    updateInfrastructure: "/updateInfrastructure", // PUT: Update an existing infrastructure
    toggleInfrastructure: "/toggleInfrastructure/toggle/", // PATCH: Toggle enable/disable for an infrastructure
    deleteInfrastructure: "/deleteInfrastructure/", // DELETE: Remove an infrastructure
    bulkAddInfrastructure: "/bulkAddInfrastructure",

    // Competence endpoints
    addCompetence: "/addCompetence", // POST: Add a new competence
    getCompetences: "/getCompetences", // GET: Retrieve all competences
    updateCompetence: "/updateCompetence", // PUT: Update an existing competence
    toggleCompetence: "/toggleCompetence/toggle/", // PATCH: Toggle enable/disable for a competence
    deleteCompetence: "/deleteCompetence/", // DELETE: Remove a competence
    bulkAddCompetence: "/bulkAddCompetence",

    // Marcom endpoints
    addMarcom: "/addMarcom", // POST: Add a new marcom
    getMarcoms: "/getMarcoms", // GET: Retrieve all marcoms
    updateMarcom: "/updateMarcom", // PUT: Update an existing marcom
    toggleMarcom: "/toggleMarcom/toggle/", // PATCH: Toggle enable/disable for a marcom
    deleteMarcom: "/deleteMarcom/", // DELETE: Remove a marcom
    bulkAddMarcom: "/bulkAddMarcom",


    //Marketing Marcom endpoints
    addMrkMarcom: "/addMrkMarcom", // POST: Add a new marcom
    getAllMrkMarcoms: "/getAllMrkMarcoms", // GET: Retrieve all marcoms
    updateMrkMarcom: "/updateMrkMarcom", // PUT: Update an existing marcom
    toggleMrkMarcom: "/toggleMrkMarcom/toggle/", // PATCH: Toggle enable/disable for a marcom
    deleteMrkMarcom: "/deleteMrkMarcom/", // DELETE: Remove a marcom
    bulkAddMarcomMrk: "/bulkAddMarcomMrk",

    // NationalKeyAccounts endpoints
    addNationalKeyAccount: "/addNationalKeyAccount", // POST: Add a new national key account
    getNationalKeyAccounts: "/getNationalKeyAccounts", // GET: Retrieve all national key accounts
    updateNationalKeyAccount: "/updateNationalKeyAccount", // PUT: Update an existing national key account
    toggleNationalKeyAccount: "/toggleNationalKeyAccount/toggle/", // PATCH: Toggle enable/disable for a national key account
    deleteNationalKeyAccount: "/deleteNationalKeyAccount/", // DELETE: Remove a national key account
    bulkAddNationalKeyAccount: "/bulkAddNationalKeyAccounts",

    // SegmentFocusArea endpoints
    addSegmentPriority: "/addSegmentPriority", // POST: Add a new segment focus area
    getAllSegmentPriorities: "/getSegmentPriorities", // GET: Retrieve all segment focus areas
    updateSegmentPriority: "/updateSegmentPriority", // PUT: Update an existing segment focus area
    toggleSegmentPriority: "/toggleSegmentPriority/toggle/", // PATCH: Toggle enable/disable for a segment focus area
    deleteSegmentPriority: "/deleteSegmentPriority/", // DELETE: Remove a segment focus area
    bulkAddSegmentPriority: "/bulkAddSegmentPriority",

    // BranchMaster endpoints
    addBranchMaster: "/addBranchMaster", // POST: Add a new branch master
    getBranchMasters: "/getBranchMasters", // GET: Retrieve all branch masters
    updateBranchMaster: "/updateBranchMaster", // PUT: Update an existing branch master
    toggleBranchMaster: "/toggleBranchMaster/toggle/", // PATCH: Toggle enable/disable for a branch master
    deleteBranchMaster: "/deleteBranchMaster/", // DELETE: Remove a branch master
    bulkAddBranchMaster: "/bulkAddBranchMaster",

    // OtherData endpoints
    addOtherData: "/addOtherData", // POST: Add a new other data
    getOtherData: "/getOtherData", // GET: Retrieve all other data
    updateOtherData: "/updateOtherData", // PUT: Update an existing other data
    toggleOtherData: "/toggleOtherData/toggle/", // PATCH: Toggle enable/disable for other data
    deleteOtherData: "/deleteOtherData/", // DELETE: Remove other data
    bulkAddOtherData: "/bulkAddOtherData",


    // PDP Dashboard Media endpoints
    addPdpDashboardMedia: "/addPdpDashboardMedia", // POST: Add a new PDP dashboard media
    getPdpDashboardMedia: "/getPdpDashboardMedia", // GET: Retrieve all PDP dashboard media
    getPdpDashboardMediaById: "/getPdpDashboardMedia/", // GET: Get PDP dashboard media by ID
    updatePdpDashboardMedia: "/updatePdpDashboardMedia", // PUT: Update an existing PDP dashboard media
    togglePdpDashboardMedia: "/togglePdpDashboardMedia/toggle/", // PATCH: Toggle enable/disable for PDP dashboard media
    deletePdpDashboardMedia: "/deletePdpDashboardMedia/", // DELETE: Remove PDP dashboard media

    // Scorecard Dashboard Media endpoints
    addScorecardDashboardMedia: "/addScorecardDashboardMedia", // POST: Add a new scorecard dashboard media
    getScorecardDashboardMedia: "/getScorecardDashboardMedia", // GET: Retrieve all scorecard dashboard media
    getScorecardDashboardMediaById: "/getScorecardDashboardMedia/", // GET: Get scorecard dashboard media by ID
    updateScorecardDashboardMedia: "/updateScorecardDashboardMedia", // PUT: Update an existing scorecard dashboard media
    toggleScorecardDashboardMedia: "/toggleScorecardDashboardMedia/toggle/", // PATCH: Toggle enable/disable for scorecard dashboard media
    deleteScorecardDashboardMedia: "/deleteScorecardDashboardMedia/", // DELETE: Remove scorecard dashboard media

    // Monthly Meeting Media endpoints
    addMontlyMeetingMedia: "/addMontlyMeetingMedia", // POST: Add a new monthly meeting media
    getMontlyMeetingMedia: "/getMontlyMeetingMedia", // GET: Retrieve all monthly meeting media
    getMontlyMeetingMediaById: "/getMontlyMeetingMedia/", // GET: Get monthly meeting media by ID
    updateMontlyMeetingMedia: "/updateMontlyMeetingMedia", // PUT: Update an existing monthly meeting media
    toggleMontlyMeetingMedia: "/toggleMontlyMeetingMedia/toggle/", // PATCH: Toggle enable/disable for monthly meeting media
    deleteMontlyMeetingMedia: "/deleteMontlyMeetingMedia/", // DELETE: Remove monthly meeting media

    // Dealer Investment Media endpoints
    addDealerInvestmentMedia: "/addDealerInvestmentMedia", // POST: Add a new dealer investment media
    getDealerInvestmentMedia: "/getDealerInvestmentMedia", // GET: Retrieve all dealer investment media
    getDealerInvestmentMediaById: "/getDealerInvestmentMedia/", // GET: Get dealer investment media by ID
    updateDealerInvestmentMedia: "/updateDealerInvestmentMedia", // PUT: Update an existing dealer investment media
    toggleDealerInvestmentMedia: "/toggleDealerInvestmentMedia/toggle/", // PATCH: Toggle enable/disable for dealer investment media
    deleteDealerInvestmentMedia: "/deleteDealerInvestmentMedia/", // DELETE: Remove dealer investment media
    // DFHM Media endpoints
    addDfhmMedia: "/addDfhmMedia", // POST: Add a new DFHM media
    getAllDfhmMedia: "/getAllDfhmMedia", // GET: Retrieve all DFHM media
    getDfhmMediaById: "/getDfhmMediaById/", // GET: Get DFHM media by ID
    updateDfhmMedia: "/updateDfhmMedia", // PUT: Update an existing DFHM media
    toggleDfhmMedia: "/toggleDfhmMedia/toggle/", // PATCH: Toggle enable/disable for DFHM media
    deleteDfhmMedia: "/deleteDfhmMedia/", // DELETE: Remove DFHM media

    // MarketArea endpoints
    addMarketArea: "/addMarket-area", // POST: Add a new market area
    getMarketAreas: "/getMarket-area", // GET: Retrieve all market areas
    updateMarketArea: "/updateMarket-area", // PUT: Update an existing market area
    toggleMarketArea: "/patchMarket-area/toggle/", // PATCH: Toggle enable/disable for a market area (append :id)
    deleteMarketArea: "/deleteMarket-area/", // DELETE: Remove a market area (append :id)

    // Dealer endpoints
    addDealer: "/addDealer", // POST: Add a new dealer
    getDealers: "/getDealers", // GET: Retrieve all dealers
    updateDealer: "/updateDealer", // PUT: Update an existing dealer
    toggleDealer: "/toggleDealer/toggle/", // PATCH: Toggle enable/disable for a dealer
    deleteDealer: "/deleteDealer/", // DELETE: Remove a dealer

    // City endpoints
    addCity: "/addCity", // POST: Add a new city
    getCities: "/getCities", // GET: Retrieve all cities
    updateCity: "/updateCity", // PUT: Update an existing city
    toggleCity: "/toggleCity/toggle/", // PATCH: Toggle enable/disable for a city
    deleteCity: "/deleteCity/", // DELETE: Remove a city

    // MainData endpoints
    getAllCountries: "/getAllCountries", // GET: Retrieve all countries
    getAllStates: "/getAllStates", // GET: Retrieve all states
    getAllDistricts: "/getAllDistricts", // GET: Retrieve all districts
    getAllCities: "/getCities", // GET: Retrieve all cities from city_master table

    // Equipment Multiplier endpoints
    addEquipmentMlp: "/addEquipmentMlp",
    getEquipmentsMlp: "/getEquipmentsMlp",
    updateEquipmentMlp: "/updateEquipmentMlp",
    toggleEquipmentMlp: "/toggleEquipmentMlp/toggle/",
    deleteEquipmentMlp: "/deleteEquipmentMlp/",

    // Financial  Multiplier endpoints
    addFinancial: "/addFinancial",
    getFinancials: "/getFinancials",
    updateFinancial: "/updateFinancial",
    toggleFinancial: "/toggleFinancial/toggle/",
    deleteFinancial: "/deleteFinancial/",

    // Balance Sheet endpoints
    addBalanceSheet: "/addBalanceSheet",
    getBalanceSheets: "/getBalanceSheets",
    updateBalanceSheet: "/updateBalanceSheet",
    toggleBalanceSheet: "/toggleBalanceSheet/toggle/",
    deleteBalanceSheet: "/deleteBalanceSheet/",
    bulkAddBalanceSheet: "/bulkAddBalanceSheet",

    // P&L endpoints
    addPL: "/addPL",
    getPLs: "/getPLs",
    updatePL: "/updatePL",
    togglePL: "/togglePL/toggle/",
    deletePL: "/deletePL/",
    bulkAddPL: "/bulkAddPL",


    // HeadCount endpoints
    addHeadCount: "/addHeadCount",
    getHeadCounts: "/getHeadCounts",
    updateHeadCount: "/updateHeadCount",
    toggleHeadCount: "/toggleHeadCount/toggle/",
    deleteHeadCount: "/deleteHeadCount/",
    bulkAddHeadCount: "/bulkAddHeadCount",

    // Ratio Analysis endpoints
    addRatioAnalysis: "/addRatioAnalysis",
    getRatioAnalysis: "/getRatioAnalysis",
    updateRatioAnalysis: "/updateRatioAnalysis",
    toggleRatioAnalysis: "/toggleRatioAnalysis/toggle/",
    deleteRatioAnalysis: "/deleteRatioAnalysis/",
    bulkAddRatioAnalysis: "/bulkAddRatioAnalysis",

    // User Logs endpoints
    getUserLogs: "/getUserLogs", // GET: Retrieve user logs with optional filters
    getUserLog: "/getUserLog/", // GET: Retrieve a single user log by ID (append :id)
    updateUserLog: "/updateUserLog/", // PUT: Update a user log by ID (append :id)
    deleteUserLog: "/deleteUserLog/", // DELETE: Delete a user log by ID (append :id)

    // Monthly Meeting endpoints
    addMonthlyMeeting: "/addMonthlyMeeting", // POST: Add a new monthly meeting
    getMonthlyMeetings: "/getMonthlyMeetings", // GET: Retrieve all monthly meetings
    getMonthlyMeetingById: "/getMonthlyMeeting/", // GET: Get monthly meeting by ID (append :id)
    updateMonthlyMeeting: "/updateMonthlyMeeting", // PUT: Update an existing monthly meeting
    deleteMonthlyMeeting: "/deleteMonthlyMeeting/", // DELETE: Remove a monthly meeting (append :id)

    // Action Item endpoints
    addActionItem: "/addActionItem", // POST: Add a new action item
    getActionItems: "/getActionItems", // GET: Retrieve all action items
    getActionItemById: "/getActionItem/", // GET: Get action item by ID (append :id)
    getActionItemsByMeeting: "/getActionItemsByMeeting/", // GET: Get action items by meeting ID (append :id)
    updateActionItem: "/updateActionItem", // PUT: Update an existing action item
    updateActionItemStatus: "/updateActionItemStatus/", // PATCH: Update action item status (append :id)
    deleteActionItem: "/deleteActionItem/", // DELETE: Remove an action item (append :id)
    getUsersByMonthlyMeetingDealer: "/getUsersByMonthlyMeetingDealer/",

    // Action Log endpoints
    addActionLog: "/addActionLog", // POST: Add a new action log
    getActionLogs: "/getActionLogs", // GET: Retrieve all action logs
    getActionLogById: "/getActionLog/", // GET: Get action log by ID (append :id)
    getActionLogsByActionItem: "/getActionLogsByActionItem/", // GET: Get action logs by action item ID (append :id)
    updateActionLog: "/updateActionLog/", // PUT: Update an existing action log (append :id)
    deleteActionLog: "/deleteActionLog/", // DELETE: Remove an action log (append :id)
  },

  competenceLevelEndpoints: {
    addCompetenceLevel: "/addCompetenceLevel",                    // POST
    bulkAddCompetenceLevel: "/bulkAddCompetenceLevel",            // POST
    getAllCompetenceLevels: "/getCompetenceLevels",               // GET (NOT getAllCompetenceLevels)
    getCompetenceLevelById: "/getCompetenceLevelById/",           // GET + :id
    updateCompetenceLevel: "/updateCompetenceLevel",              // PUT
    toggleCompetenceLevel: "/toggleCompetenceLevel/toggle/",      // PATCH + :id
    deleteCompetenceLevel: "/deleteCompetenceLevel/",             // DELETE + :id
  },

  specializationCompetenceEndpoints: {
    addSpecializationCompetence: "/addSpecializationCompetence",
    bulkAddSpecializationCompetence: "/bulkAddSpecializationCompetence",
    getAllSpecializationCompetences: "/getSpecializationCompetences",
    getSpecializationCompetenceById: "/getSpecializationCompetenceById/",
    updateSpecializationCompetence: "/updateSpecializationCompetence",
    toggleSpecializationCompetence: "/toggleSpecializationCompetence/toggle/",
    deleteSpecializationCompetence: "/deleteSpecializationCompetence/",
  },

  monthlyMeaatingendpoints: {
    // File Master endpoints
    getTargetDate: "/getTargetDate/",
    addFile: "/addFile", // POST: Add a new File    
    getAllFiles: "/getAllFiles", // GET: Retrieve all File
    updateFile: "/updateFile", // PUT: Update an existing File
    toggleFile: "/toggleFile/toggle/", // PATCH: Toggle enable/disable for a File
    deleteFile: "/deleteFile/", // DELETE: Remove a File

    // PresentationTemplate endpoints
    addDepartment: "/addDepartment", // POST: Add a new File
    getDepartments: "/getDepartments", // GET: Retrieve all File
    updateDepartment: "/updateDepartment", // PUT: Update an existing File
    toggleDepartment: "/toggleDepartment/toggle/", // PATCH: Toggle enable/disable for a File
    deleteDepartment: "/deleteDepartment/", // DELETE: Remove a File

    // Monthly Meeting Template endpoints
    addMonthlyMeetingTemplate: "/addMonthlyMeetingTemplate", // POST: Add a new monthly meeting template
    getMonthlyMeetingTemplates: "/getMonthlyMeetingTemplates", // GET: Retrieve all monthly meeting templates (optional query: monthly_meeting)
    getMonthlyMeetingTemplate: "/getMonthlyMeetingTemplate/", // GET: Get monthly meeting template by ID (append :id)
    getMonthlyMeetingTemplatesByMonthlyMeeting: "/getMonthlyMeetingTemplatesByMonthlyMeeting/", // GET: Get templates by monthly meeting ID (append :monthly_meeting)
    updateMonthlyMeetingTemplate: "/updateMonthlyMeetingTemplate/", // PUT: Update an existing monthly meeting template (append :id)
    bulkUploadMonthlyMeetingTemplates: "/bulkUploadMonthlyMeetingTemplates", // POST: Bulk upload files to multiple monthly meeting templates
    deleteMonthlyMeetingTemplate: "/deleteMonthlyMeetingTemplate/", // DELETE: Remove a monthly meeting template (append :id)

  },
  createPdpendpoints: {
    addPdp: "/addPdp",
    getAllPdp: "/getAllPdp",
    getAllPdpWithActionItemCounts: "/getAllPdpWithActionItemCounts",
    getPdpById: "/getPdp/",
    updatePdp: "/updatePdp",
    deletePdp: "/deletePdp/",
    pdpStatusChange: "/pdpStatusChange",                    // PUT: Change status (Started/Submit/Approved/Return)
    updatePdpMeetingDetails: "/updatePdpMeetingDetails",    // PUT: Update meeting details
    getActiveMarketarea: "/getMarket-area",
    getActiveDealers: "/getDealers",

    // PDP Action Item endpoints
    addPdpActionItem: "/addPdpActionItem",
    getAllPdpActionItem: "/getAllPdpActionItem",
    getPdpActionItemById: "/getPdpActionItem/",
    updatePdpActionItem: "/updatePdpActionItem",
    deletePdpActionItem: "/deletePdpActionItem/",

    // PDP Action Log endpoints
    addPdpActionLog: "/addPdpActionLog",
    getPdpActionLogs: "/getPdpActionLogs",
    getPdpActionLogById: "/getPdpActionLog/",
    getPdpActionLogsByActionItem: "/getPdpActionLogsByActionItem/",
    updatePdpActionLog: "/updatePdpActionLog/",
    deletePdpActionLog: "/deletePdpActionLog/",

    // PDP Others endpoints
    getPdpOthersByPdpId: "/getPdpOthersByPdpId/",
    updatePdpOthers: "/updatePdpOthers",
    deletePdpOthers: "/deletePdpOthers/",

    //  PDP Signoff endpoints - 
    addPdpSignoff: "/addPdpSignoff",                        // POST: Add signoff
    getAllPdpSignoffs: "/getAllPdpSignoffs",                // GET: Get all signoffs
    getPdpSignoffById: "/getPdpSignoff/",                   // GET: Get by ID (append :id)
    getPdpSignoffsByPdpId: "/getPdpSignoffsByPdpId/",       // GET: Get by PDP ID (append :pdpId)
    getPdpSignoffsByUserId: "/getPdpSignoffsByUserId/",     // GET: Get by User ID (append :userId)
    updatePdpSignoff: "/updatePdpSignoff",                  // PUT: Update signoff
    signPdpSignoff: "/signPdpSignoff",                      // PUT: Sign off (convenience)
    deletePdpSignoff: "/deletePdpSignoff/",


    //  NEW: PDP Upload Files endpoints
    getPdpUploadFilesByPdpId: "/getPdpUploadFilesByPdpId/",     //  Get files by PDP ID (MAIN ONE)
    addPdpUploadFile: "/addPdpUploadFile",                      //  Add new file
    updatePdpUploadFile: "/updatePdpUploadFile",                //  Update file
    deletePdpUploadFile: "/deletePdpUploadFile/",               //  Delete file

    //  TEMPLATE DOWNLOADS
    getDefaultPreTemplate: "/getDefaultPreTemplate",             //  Download Presentation template
    getDefaultFinTemplate: "/getDefaultFinTemplate",

    getPdpEquipmentsByPdpId: "/getPdpEquipmentsByPdpId/",
    updateMultiplePdpEquipments: "/updateMultiplePdpEquipments",

    //  NEW: Uptime Parts Endpoints
    getPdpUptimePartsByPdpId: "/getPdpUptimePartsByPdpId/",
    updateMultiplePdpUptimeParts: "/updateMultiplePdpUptimeParts",

    // ⭐ Competence Development Endpoints
    getPdpCompetenceDevelopmentsByPdpId: "/getPdpCompetenceDevelopmentsByPdpId/",
    updateMultiplePdpCompeDev: "/updateMultiplePdpCompeDev",
    getActiveMachines: "/getActiveMachines/",

    //  NEW: Territory Focus Endpoints
    getPdpTerritoryFocusByPdpId: "/getPdpTerritoryFocusByPdpId/",
    addPdpTerritoryFocus: "/addPdpTerritoryFocus",
    updatePdpTerritoryFocus: "/updatePdpTerritoryFocus",
    deletePdpTerritoryFocus: "/deletePdpTerritoryFocus/",

    // In api.js, add to createPdpendpoints object:
    getPdpTerritoryFocusEntriesByTerritoryFocusId: "/getPdpTerritoryFocusEntriesByTerritoryFocusId/",
    updatePdpTerritoryFocusEntry: "/updatePdpTerritoryFocusEntry",
    getPdpTerritoryFocusEntriesStatsByPdpId: "/getPdpTerritoryFocusEntriesStatsByPdpId/",
    updatePdpTerritoryFocusEntriesStats: "/updatePdpTerritoryFocusEntriesStats",

    // ⭐ Marcom Branding Endpoints
    getPdpMarcomBrandingByPdpId: "/getPdpMarcomBrandingByPdpId/",
    updateMultiplePdpMarcomBranding: "/updateMultiplePdpMarcomBranding",
    updatePdpMarcomSupdoc: "/updatePdpMarcomSupdoc",
    deletePdpMarcomSupdoc: "/deletePdpMarcomSupdoc/",

    // ⭐ Marcom Marketing Endpoints
    getPdpMarcomMarketingByPdpId: "/getPdpMarcomMarketingByPdpId/",
    updateMultiplePdpMarcomMarketing: "/updateMultiplePdpMarcomMarketing"

  },
  pdpInfrastructureEndpoints: {
    addPdpInfrastructure: "/addPdpInfrastructure", // POST: Add a new PDP infrastructure
    getAllPdpInfrastructures: "/getAllPdpInfrastructures", // GET: Retrieve all PDP infrastructures
    getPdpInfrastructureById: "/getPdpInfrastructure/", // GET: Get PDP infrastructure by ID (append :id)
    getPdpInfrastructuresByPdpId: "/getPdpInfrastructuresByPdpId/", // GET: Get PDP infrastructures by PDP ID (append :pdpId)
    updatePdpInfrastructure: "/updatePdpInfrastructure", // PUT: Update an existing PDP infrastructure
    deletePdpInfrastructure: "/deletePdpInfrastructure/" // DELETE: Delete a PDP infrastructure by ID (append :id)
  },
  pdpInfrastructureLocationCountEndpoints: {
    addPdpInfrastructureLocationCount: "/addPdpInfrastructureLocationCount", // POST: Add a new PDP infrastructure location count
    getAllPdpInfrastructureLocationCounts: "/getAllPdpInfrastructureLocationCounts", // GET: Retrieve all PDP infrastructure location counts
    getPdpInfrastructureLocationCountById: "/getPdpInfrastructureLocationCount/", // GET: Get PDP infrastructure location count by ID (append :id)
    getPdpInfrastructureLocationCountsByPdpId: "/getPdpInfrastructureLocationCountsByPdpId/", // GET: Get PDP infrastructure location counts by PDP ID (append :pdpId)
    getPdpInfrastructureLocationCountsByPdpInfrastructureId: "/getPdpInfrastructureLocationCountsByPdpInfrastructureId/", // GET: Get PDP infrastructure location counts by PDP Infrastructure ID (append :pdpInfrastructureId)
    updatePdpInfrastructureLocationCount: "/updatePdpInfrastructureLocationCount", // PUT: Update an existing PDP infrastructure location count
    deletePdpInfrastructureLocationCount: "/deletePdpInfrastructureLocationCount/" // DELETE: Delete a PDP infrastructure location count by ID (append :id)
  },
  pdpInfrastructureVehicleEndpoints: {
    addPdpInfrastructureVehicle: "/addPdpInfrastructureVehicle", // POST: Add a new PDP infrastructure vehicle
    getAllPdpInfrastructureVehicles: "/getAllPdpInfrastructureVehicles", // GET: Retrieve all PDP infrastructure vehicles
    getPdpInfrastructureVehicleById: "/getPdpInfrastructureVehicle/", // GET: Get PDP infrastructure vehicle by ID (append :id)
    getPdpInfrastructureVehiclesByPdpId: "/getPdpInfrastructureVehiclesByPdpId/", // GET: Get PDP infrastructure vehicles by PDP ID (append :pdpId)
    getPdpInfrastructureVehiclesByPdpInfrastructureId: "/getPdpInfrastructureVehiclesByPdpInfrastructureId/", // GET: Get PDP infrastructure vehicles by PDP Infrastructure ID (append :pdpInfrastructureId)
    updatePdpInfrastructureVehicle: "/updatePdpInfrastructureVehicle", // PUT: Update an existing PDP infrastructure vehicle
    deletePdpInfrastructureVehicle: "/deletePdpInfrastructureVehicle/" // DELETE: Delete a PDP infrastructure vehicle by ID (append :id)
  },
  pdpInfrastructureToolsEndpoints: {
    addPdpInfrastructureTool: "/addPdpInfrastructureTool", // POST: Add a new PDP infrastructure tool
    getAllPdpInfrastructureTools: "/getAllPdpInfrastructureTools", // GET: Retrieve all PDP infrastructure tools
    getPdpInfrastructureToolById: "/getPdpInfrastructureTool/", // GET: Get PDP infrastructure tool by ID (append :id)
    getPdpInfrastructureToolsByPdpId: "/getPdpInfrastructureToolsByPdpId/", // GET: Get PDP infrastructure tools by PDP ID (append :pdpId)
    getPdpInfrastructureToolsByPdpInfrastructureId: "/getPdpInfrastructureToolsByPdpInfrastructureId/", // GET: Get PDP infrastructure tools by PDP Infrastructure ID (append :pdpInfrastructureId)
    updatePdpInfrastructureTool: "/updatePdpInfrastructureTool", // PUT: Update an existing PDP infrastructure tool
    deletePdpInfrastructureTool: "/deletePdpInfrastructureTool/" // DELETE: Delete a PDP infrastructure tool by ID (append :id)
  },
  pdpInfrastructureAssetsEndpoints: {
    addPdpInfrastructureAsset: "/addPdpInfrastructureAsset", // POST: Add a new PDP infrastructure asset
    getAllPdpInfrastructureAssets: "/getAllPdpInfrastructureAssets", // GET: Retrieve all PDP infrastructure assets
    getPdpInfrastructureAssetById: "/getPdpInfrastructureAsset/", // GET: Get PDP infrastructure asset by ID (append :id)
    getPdpInfrastructureAssetsByPdpId: "/getPdpInfrastructureAssetsByPdpId/", // GET: Get PDP infrastructure assets by PDP ID (append :pdpId)
    getPdpInfrastructureAssetsByPdpInfrastructureId: "/getPdpInfrastructureAssetsByPdpInfrastructureId/", // GET: Get PDP infrastructure assets by PDP Infrastructure ID (append :pdpInfrastructureId)
    updatePdpInfrastructureAsset: "/updatePdpInfrastructureAsset", // PUT: Update an existing PDP infrastructure asset
    deletePdpInfrastructureAsset: "/deletePdpInfrastructureAsset/" // DELETE: Delete a PDP infrastructure asset by ID (append :id)
  },
  userManagement: {
    logedInUser: "/logedInUser",
    logout: "/logout",
    setPassword: "/setPassword",
    urlValidation: "/urlValidation",
    forgotPassword: "/forgotPassword",
    login: "/login",
    getRoles: "/getRoles",
    getMarketarea: "/getMarket-area",
    getDealers: "/getDealers",
    getAllUsers: "/getAllUsers",
    getUser: "/getUser",
    updateUser: "/updateUser",
    addUser: "/addUser",
    assignRemoveDealers: "/assignRemoveDealers",
    toggleUserStatus: "/toggleUserStatus",
    activationLink: "/activationLink",
    deleteUser: "/deleteUser",
    bulkAddUser: "/bulkAddUser",
  },
  masters: {
    //City Master End Points
    getAllCities: "/getAllCities",
    addCity: "/addCity",
    getCities: "/getCities",
    updateCity: "/updateCity",
    deleteCity: "/deleteCity",
    toggleCity: "/toggleCity/toggle",
    bulkAddCity: "/bulkAddCity",

    //Country Master End Pints
    getCountries: "/getCountries",
    getAllCuntries: "/getAllCuntries",
    addCountry: "/addCountry",
    bulkAddCountry: "/bulkAddCountry",
    updateCountry: "/updateCountry",           // - PUT endpoint
    deleteCountry: "/deleteCountry",           //- DELETE endpoint (append /:id)
    toggleCountry: "/toggleCountry/toggle",

    //Dealer Master 
    getDealers: "/getDealers",
    updateDealer: "/updateDealer",
    addDealer: "/addDealer",
    deleteDealer: "/deleteDealer",
    toggleDealer: "/toggleDealer/toggle",
    bulkAddDealer: "/bulkAddDealer",

    //KPI Master
    getKPIs: "/getKPIs",
    updateKPI: "/updateKPI",
    addKPI: "/addKPI",
    deleteKPI: "/deleteKPI",
    toggleKPI: "/toggleKPI/toggle",
    bulkAddKpi: "/bulkAddKpi",

    //Market Area Master

    getMarketarea: "/getMarket-area",
    addMarketarea: "/addMarket-area",
    updateMarketarea: "/updateMarket-area",
    deleteMarketarea: "/deleteMarket-area",
    patchMarketarea: "/patchMarket-area/toggle",
    bulkAddMarketarea: "/bulkAddMarket-area",

    //Roale Master 

    getRoles: "/getRoles",
    addRole: "/addRole",
    updateRole: "/updateRole",
    deleteRole: "/deleteRole",
    toggleRole: "/toggleRole/toggle",
    bulkAddRole: "/bulkAddRole",

    //State Master

    getStates: "/getStates",
    getAllStates: "/getAllStates",
    addState: "/addState",
    updateState: "/updateState",
    deleteState: "/deleteState",
    toggleState: "/toggleState/toggle",
    bulkAddState: "/bulkAddState",

    //Startegic Object Master 

    getStrategicObjectives: "/getStrategicObjectives",
    addStrategicObjective: "/addStrategicObjective",
    updateStrategicObjective: "/updateStrategicObjective",
    deleteStrategicObjective: "/deleteStrategicObjective",
    toggleStrategicObjective: "/toggleStrategicObjective/toggle",
    bulkAddStrategicObjective: "/bulkAddStrategicObjective",

    //Sub Kpi Master


    getAllSubKPIs: "/getAllSubKPIs",
    deleteSubKPI: "/deleteSubKPI",
    toggleSubKPI: "/toggleSubKPI/toggle",

    getAllUsers: "/getAllUsers",
    addSubKPI: "/addSubKPI",
    updateSubKPI: "/updateSubKPI",
    bulkAddSubKpi: "/bulkAddSubKpi",
    updateFormulaSubKpi: "/updateFormula",

  },


  // ⭐ Scorecard Endpoints (Complete)
  scorecardEndpoints: {
    // ════════════════════════════════════════════════════════════════
    // SCORECARD CRUD (for CreateScorecard & ViewReviews pages)
    // ════════════════════════════════════════════════════════════════
    addScorecard: "/addScorecard",                    // POST: Add a new scorecard
    getAllScorecards: "/getAllScorecards",            // GET: Retrieve all scorecards
    getScorecardById: "/getScorecard/",               // GET: Get scorecard by ID (append :id)
    updateScorecard: "/updateScorecard",              // PUT: Update an existing scorecard
    deleteScorecard: "/deleteScorecard/",             // DELETE: Delete a scorecard (append :id)
    toggleScorecard: "/toggleScorecard/toggle/",      // PATCH: Toggle scorecard status (append :id)
    getAuditors: "/getAllUsers",                      // GET: Get all users who can be auditors
    completeScorecard: "/completeScorecard/",
    bulkCompleteScorecard: "/bulkCompleteScorecard",

    // ════════════════════════════════════════════════════════════════
    // SCORE VIEW (for ScoreAudit page - single scorecard scoring)
    // ════════════════════════════════════════════════════════════════
    getScorecardScoreViewsByScorecardId: "/getScorecardScoreViewsByScorecardId/",  // GET: Get all score views by scorecard ID (append :id)
    updateScorecardScoreView: "/updateScorecardScoreView",                          // PUT: Update a score view

    // ════════════════════════════════════════════════════════════════
    // ALL SCORE VIEWS (for Scoring page - all scorecards scoring)
    // ════════════════════════════════════════════════════════════════
    getAllScorecardScoreViews: "/getAllScorecardScoreViews",                        // GET: Get ALL score views across all scorecards
    bulkToggleScorecardScoreViewExclusion: "/bulkToggleScorecardScoreViewExclusion", // PUT: Bulk toggle exclusion for multiple score views

    // ════════════════════════════════════════════════════════════════
    // SCORE VIEW DOCUMENTS (shared between ScoreAudit & Scoring pages)
    // ════════════════════════════════════════════════════════════════
    getScorecardScoreViewDocsByScorecardId: "/getScorecardScoreViewDocsByScorecardId/", // GET: Get all docs by scorecard ID (append :id)
    addScorecardScoreViewDoc: "/addScorecardScoreViewDoc",                              // POST: Add a new document (multipart/form-data)
    deleteScorecardScoreViewDoc: "/deleteScorecardScoreViewDoc/",                       // DELETE: Delete a document (append :id)

    // ════════════════════════════════════════════════════════════════
    // SCORECARD ACTION ITEMS (for UserViewDetails page)
    // ════════════════════════════════════════════════════════════════
    addScorecardActionItem: "/addScorecardActionItem",                                  // POST: Add a new action item
    getAllScorecardActionItems: "/getAllScorecardActionItems",                          // GET: Get all action items
    getScorecardActionItemById: "/getScorecardActionItemById/",                         // GET: Get action item by ID (append :id)
    getScorecardActionItemsByScoreId: "/getScorecardActionItemsByScoreId/",             // GET: Get action items by score view ID (append :scorecard_score_id)
    updateScorecardActionItem: "/updateScorecardActionItem",                            // PUT: Update an action item
    toggleScorecardActionItem: "/toggleScorecardActionItem/",                           // PATCH: Toggle action item status (append :id)
    deleteScorecardActionItem: "/deleteScorecardActionItem/",                           // DELETE: Delete an action item (append :id)

    // ════════════════════════════════════════════════════════════════
    // SCORECARD ACTION LOGS (Responses/Comments for Action Items)
    // ════════════════════════════════════════════════════════════════
    addScorecardActionLog: "/addScorecardActionLog",                                    // POST: Add a new action log (multipart/form-data for file)
    getAllScorecardActionLogs: "/getAllScorecardActionLogs",                            // GET: Get all action logs
    getScorecardActionLogById: "/getScorecardActionLogById/",                           // GET: Get action log by ID (append :id)
    getScorecardActionLogsByActionItemId: "/getScorecardActionLogsByActionItemId/",     // GET: Get action logs by action item ID (append :action_item_id)
    getFirstLogCommentsByActionItemId: "/getFirstLogCommentsByActionItemId/",           // GET: Get first log comment by action item ID (append :action_item_id)
    updateScorecardActionLog: "/updateScorecardActionLog",                              // PUT: Update an action log
    deleteScorecardActionLog: "/deleteScorecardActionLog/",                             // DELETE: Delete an action log (append :id)
  },


  dfhmEndpoints: {
    // ════════════════════════════════════════════════════════════════
    // DFHM CRUD (for CreateDfhm & ViewDfhm pages)
    // ════════════════════════════════════════════════════════════════
    addDfhm: "/addDfhm",                              // POST: Add new DFHM (creates entries for multiple dealers)
    getAllDfhm: "/getAllDfhm",                        // GET: Retrieve all DFHM records
    getDfhmById: "/getDfhmById/",                     // GET: Get DFHM by ID (append :id)
    updateDfhm: "/updateDfhm",                        // PUT: Update an existing DFHM
    deleteDfhm: "/deleteDfhm/",                       // DELETE: Soft delete a DFHM (append :id)
    toggleDfhm: "/toggleDfhm/",                       // PATCH: Toggle DFHM active status (append :id)

    // ════════════════════════════════════════════════════════════════
    // DFHM P&L (Profit & Loss) - For FillEntries P&L Tab
    // ════════════════════════════════════════════════════════════════
    getDfhmPlByDfhmId: "/getDfhmPlByDfhmId/",         // GET: Get all P&L entries by DFHM ID (append :dfhmId)
    getDfhmPlByFilters: "/getDfhmPlByFilter",         // GET: Get P&L entries by filters (?quarter=Q1&year=2025&dealerId=54)
    updateDfhmPl: "/updateDfhmPl",                    // PUT: Update a single P&L entry
    bulkUpdateDfhmPl: "/updateMultipleDfhmPl",        // PUT: Bulk update multiple P&L entries

    // ════════════════════════════════════════════════════════════════
    // DFHM Balance Sheet - For FillEntries Balance Sheet Tab
    // ════════════════════════════════════════════════════════════════
    getDfhmBsByDfhmId: "/getDfhmBsByDfhmId/",         // GET: Get all Balance Sheet entries by DFHM ID (append :dfhmId)
    getDfhmBsByFilters: "/getDfhmBsByFilters",        // GET: Get Balance Sheet entries by filters (?quarter=Q1&year=2025&dealerId=54)
    updateDfhmBs: "/updateDfhmBs",                    // PUT: Update a single Balance Sheet entry
    bulkUpdateDfhmBs: "/updateMultipleDfhmBs",        // PUT: Bulk update multiple Balance Sheet entries

    // ════════════════════════════════════════════════════════════════
    // DFHM Head Count - For FillEntries Head Count Tab
    // ════════════════════════════════════════════════════════════════
    getDfhmHcByDfhmId: "/getDfhmHcByDfhmId/",         // GET: Get all Head Count entries by DFHM ID (append :dfhmId)
    getDfhmHcByFilters: "/getDfhmHcByFilters",        // GET: Get Head Count entries by filters (?quarter=Q1&year=2025&dealerId=54)
    updateDfhmHc: "/updateDfhmHc",                    // PUT: Update a single Head Count entry
    bulkUpdateDfhmHc: "/updateMultipleDfhmHc",        // PUT: Bulk update multiple Head Count entries

    // ════════════════════════════════════════════════════════════════
    // DFHM AR Aging - For FillEntries AR Aging Tab
    // ════════════════════════════════════════════════════════════════
    getDfhmArAgingByDfhmId: "/getDfhmAgingByDfhmId/",    // GET: Get all AR Aging entries by DFHM ID (append :dfhmId)
    getDfhmArAgingByFilters: "/getDfhmAgingByFilters",   // GET: Get AR Aging entries by filters
    addDfhmArAging: "/addDfhmAging",                     // POST: Add a new AR Aging row
    updateDfhmArAging: "/updateDfhmAging",               // PUT: Update an AR Aging entry
    deleteDfhmArAging: "/deleteDfhmAging/",              // DELETE: Delete an AR Aging entry (append :id)
    bulkUpdateDfhmArAging: "/updateMultipleDfhmAging",   // PUT: Bulk update multiple AR Aging entries
  },


  dealerInvestmentEndpoints: {
    getAllDealerInvestment: "/getAllDealerInvestment",
    getDealerInvestmentById: "/getDealerInvestment/",
    getDealerInvestmentByPdpId: "/getDealerInvestmentBypdpId/",
    updateDealerInvestment: "/updateDealerInvestment",
    deleteDealerInvestment: "/deleteDealerInvestment/",
    mbpStatusEquipmentsChange: "/mbpStatusEquipmentsChange",
  },

  dealerInvestmentInfrastructureEndpoints: {
    getAllDealerInvestmentInfrastructure: "/getAllDealerInvestmentInfrastructure",
    getDealerInvestmentInfrastructureById: "/getDealerInvestmentInfrastructureById/",
    getDealerInvestmentInfrastructureByDealerInvestmentId: "/getDealerInvestmentInfrastructureByDealerInvestmentId/",
    getDealerInvestmentInfrastructureByPdpId: "/getDealerInvestmentInfrastructureByPdpId/",
    updateDealerInvestmentInfrastructure: "/updateDealerInvestmentInfrastructure",
    updateMultipleDealerInvestmentInfrastructure: "/updateMultipleDealerInvestmentInfrastructure",
    deleteDealerInvestmentInfrastructure: "/deleteDealerInvestmentInfrastructure/",
  },

  dealerInvestmentCompetenceEndpoints: {
    getAllDealerInvestmentCompetence: "/getAllDealerInvestmentCompetence",
    getDealerInvestmentCompetenceById: "/getDealerInvestmentCompetenceById/",
    getDealerInvestmentCompetenceByDealerInvestmentId: "/getDealerInvestmentCompetenceByDealerInvestmentId/",
    getDealerInvestmentCompetenceByPdpId: "/getDealerInvestmentCompetenceByPdpId/",
    updateDealerInvestmentCompetence: "/updateDealerInvestmentCompetence",
    updateMultipleDealerInvestmentCompetence: "/updateMultipleDealerInvestmentCompetence",
    deleteDealerInvestmentCompetence: "/deleteDealerInvestmentCompetence/",
  },

  dealerInvestmentMachinePopulationEndpoints: {
    getAllDealerInvestmentMachinePopulation: "/getAllDealerInvestmentMachinePopulation",
    getDealerInvestmentMachinePopulationById: "/getDealerInvestmentMachinePopulationById/",
    getDealerInvestmentMachinePopulationByDealerInvestmentId: "/getDealerInvestmentMachinePopulationByDealerInvestmentId/",
    getDealerInvestmentMachinePopulationByPdpId: "/getDealerInvestmentMachinePopulationByPdpId/",
    getActiveMachines: "/getActiveMachines/",
    updateDealerInvestmentMachinePopulation: "/updateDealerInvestmentMachinePopulation",
    updateMultipleDealerInvestmentMachinePopulation: "/updateMultipleDealerInvestmentMachinePopulation",
    deleteDealerInvestmentMachinePopulation: "/deleteDealerInvestmentMachinePopulation/",
  },

  dealerInvestmentEquipmentActualsEndpoints: {
    getAllDealerInvestmentEquipmentActuals: "/getAllDealerInvestmentEquipmentActuals",
    getDealerInvestmentEquipmentActualsById: "/getDealerInvestmentEquipmentActualsById/",
    getDealerInvestmentEquipmentActualsByDealerInvestmentId: "/getDealerInvestmentEquipmentActualsByDealerInvestmentId/",
    getDealerInvestmentEquipmentActualsByPdpId: "/getDealerInvestmentEquipmentActualsByPdpId/",
    updateDealerInvestmentEquipmentActuals: "/updateDealerInvestmentEquipmentActuals",
    updateMultipleDealerInvestmentEquipmentActuals: "/updateMultipleDealerInvestmentEquipmentActuals",
    deleteDealerInvestmentEquipmentActuals: "/deleteDealerInvestmentEquipmentActuals/",
  },

  dealerInvestmentEquipmentMbpEndpoints: {
    getAllDealerInvestmentEquipmentMbp: "/getAllDealerInvestmentEquipmentMbp",
    getDealerInvestmentEquipmentMbpById: "/getDealerInvestmentEquipmentMbpById/",
    getDealerInvestmentEquipmentMbpByDealerInvestmentId: "/getDealerInvestmentEquipmentMbpByDealerInvestmentId/",
    getDealerInvestmentEquipmentMbpByPdpId: "/getDealerInvestmentEquipmentMbpByPdpId/",
    updateDealerInvestmentEquipmentMbp: "/updateDealerInvestmentEquipmentMbp",
    updateMultipleDealerInvestmentEquipmentMbp: "/updateMultipleDealerInvestmentEquipmentMbp",
    deleteDealerInvestmentEquipmentMbp: "/deleteDealerInvestmentEquipmentMbp/",
  },

  dealerInvestmentEquipmentProjectionEndpoints: {
    getAllDealerInvestmentEquipmentProjection: "/getAllDealerInvestmentEquipmentProjection",
    getDealerInvestmentEquipmentProjectionById: "/getDealerInvestmentEquipmentProjectionById/",
    getDealerInvestmentEquipmentProjectionByDealerInvestmentId: "/getDealerInvestmentEquipmentProjectionByDealerInvestmentId/",
    getDealerInvestmentEquipmentProjectionByPdpId: "/getDealerInvestmentEquipmentProjectionByPdpId/",
    updateDealerInvestmentEquipmentProjection: "/updateDealerInvestmentEquipmentProjection",
    updateMultipleDealerInvestmentEquipmentProjection: "/updateMultipleDealerInvestmentEquipmentProjection",
    deleteDealerInvestmentEquipmentProjection: "/deleteDealerInvestmentEquipmentProjection/",
  },

  // ============================================
  // DEALER INVESTMENT ALLOCATION ENDPOINTS
  // ============================================
  dealerInvestmentAllocationEndpoints: {
    getAllDealerInvestmentAllocation: "/getAllDealerInvestmentAllocation",
    getDealerInvestmentAllocationById: "/getDealerInvestmentAllocationById/",
    getDealerInvestmentAllocationByDealerInvestmentId: "/getDealerInvestmentAllocationByDealerInvestmentId/",
    getDealerInvestmentAllocationByPdpId: "/getDealerInvestmentAllocationByPdpId/",
    updateDealerInvestmentAllocation: "/updateDealerInvestmentAllocation",
    updateMultipleDealerInvestmentAllocation: "/updateMultipleDealerInvestmentAllocation",
    deleteDealerInvestmentAllocation: "/deleteDealerInvestmentAllocation/",
  },

  dealerInvestmentUptimeMbpEndpoints: {
    getAllDealerInvestmentUptimeMbp: "/getAllDealerInvestmentUptimeMbp",
    getDealerInvestmentUptimeMbpById: "/getDealerInvestmentUptimeMbpById/",
    getDealerInvestmentUptimeMbpByDealerInvestmentId: "/getDealerInvestmentUptimeMbpByDealerInvestmentId/",
    getDealerInvestmentUptimeMbpByPdpId: "/getDealerInvestmentUptimeMbpByPdpId/",
    updateDealerInvestmentUptimeMbp: "/updateDealerInvestmentUptimeMbp",
    updateMultipleDealerInvestmentUptimeMbp: "/updateMultipleDealerInvestmentUptimeMbp",
    deleteDealerInvestmentUptimeMbp: "/deleteDealerInvestmentUptimeMbp/",
  },

  dealerInvestmentUptimeProjectionEndpoints: {
    getAllDealerInvestmentUptimeProjection: "/getAllDealerInvestmentUptimeProjection",
    getDealerInvestmentUptimeProjectionById: "/getDealerInvestmentUptimeProjectionById/",
    getDealerInvestmentUptimeProjectionByDealerInvestmentId: "/getDealerInvestmentUptimeProjectionByDealerInvestmentId/",
    getDealerInvestmentUptimeProjectionByPdpId: "/getDealerInvestmentUptimeProjectionByPdpId/",
    updateDealerInvestmentUptimeProjection: "/updateDealerInvestmentUptimeProjection",
    updateMultipleDealerInvestmentUptimeProjection: "/updateMultipleDealerInvestmentUptimeProjection",
    deleteDealerInvestmentUptimeProjection: "/deleteDealerInvestmentUptimeProjection/",
  },

  dealerInvestmentUptimeActualsEndpoints: {
    getAllDealerInvestmentUptimeActuals: "/getAllDealerInvestmentUptimeActuals",
    getDealerInvestmentUptimeActualsById: "/getDealerInvestmentUptimeActualsById/",
    getDealerInvestmentUptimeActualsByDealerInvestmentId: "/getDealerInvestmentUptimeActualsByDealerInvestmentId/",
    getDealerInvestmentUptimeActualsByPdpId: "/getDealerInvestmentUptimeActualsByPdpId/",
    updateDealerInvestmentUptimeActuals: "/updateDealerInvestmentUptimeActuals",
    updateMultipleDealerInvestmentUptimeActuals: "/updateMultipleDealerInvestmentUptimeActuals",
    deleteDealerInvestmentUptimeActuals: "/deleteDealerInvestmentUptimeActuals/",
  },

  dealerInvestmentVehiclesEndpoints: {
    addDealerInvestmentVehicle: "/addDealerInvestmentVehicle",
    getAllDealerInvestmentVehicles: "/getAllDealerInvestmentVehicles",
    getDealerInvestmentVehicleById: "/getDealerInvestmentVehicleById/",
    getDealerInvestmentVehiclesByDealerInvestmentId: "/getDealerInvestmentVehiclesByDealerInvestmentId/",
    updateDealerInvestmentVehicle: "/updateDealerInvestmentVehicle",
    deleteDealerInvestmentVehicle: "/deleteDealerInvestmentVehicle/",
  },

  dealerInvestmentFileEndpoints: {
    addDealerInvestmentFile: "/addDealerInvestmentFile",
    getAllDealerInvestmentFiles: "/getAllDealerInvestmentFiles",
    getDealerInvestmentFileById: "/getDealerInvestmentFileById/",
    getDealerInvestmentFilesByDealerInvestmentId: "/getDealerInvestmentFilesByDealerInvestmentId/",
    updateDealerInvestmentFile: "/updateDealerInvestmentFile",
    deleteDealerInvestmentFile: "/deleteDealerInvestmentFile/",
  },

  inventoryAllocationEndpoints: {
    addInventoryAllocation: "/addInventoryAllocation",
    getAllInventoryAllocations: "/getAllInventoryAllocations",
    getInventoryAllocationById: "/getInventoryAllocation/",
    updateInventoryAllocation: "/updateInventoryAllocation",
    toggleInventoryAllocationStatus: "/toggleInventoryAllocationStatus/toggle/",
    deleteInventoryAllocation: "/deleteInventoryAllocation/",
    getAllInventoryDataAllocations: "/getAllInventoryDataAllocations",
    getInventoryDataAllocationById: "/getInventoryDataAllocation/",
    getInventoryDataAllocationsByInventoryId: "/getInventoryDataAllocationsByInventoryId/",
    updateInventoryDataAllocation: "/updateInventoryDataAllocation",
    updateMultipleInventoryDataAllocations: "/updateMultipleInventoryDataAllocations",
    toggleInventoryDataAllocationStatus: "/toggleInventoryDataAllocationStatus/toggle/",
    deleteInventoryDataAllocation: "/deleteInventoryDataAllocation/",
  },
  // ============================================
  // CONTACT MANAGEMENT DEPARTMENT ENDPOINTS
  // ============================================
  contactManagementEndpoints: {
    // Department endpoints
    addCMDepartment: "/addCMDepartment",
    bulkAddCMDepartment: "/bulkAddCMDepartment",
    getAllCMDepartments: "/getAllCMDepartments",
    getCMDepartment: "/getCMDepartment/",
    updateCMDepartment: "/updateCMDepartment",
    toggleCMDepartmentStatus: "/toggleCMDepartmentStatus/toggle/",
    deleteCMDepartment: "/deleteCMDepartment/",


    // Designation endpoints
    addCMDesignation: "/addCMDesignation",
    bulkAddCMDesignation: "/bulkAddCMDesignation",
    getAllCMDesignations: "/getAllCMDesignations",
    getCMDesignation: "/getCMDesignation/",
    updateCMDesignation: "/updateCMDesignation",
    toggleCMDesignationStatus: "/toggleCMDesignationStatus/toggle/",
    deleteCMDesignation: "/deleteCMDesignation/",
  },



  // Process Management Template endpoints
  processManagementTemplateEndpoints: {
    addProcessManagementTemplate: "/addProcessManagementTemplate",
    getAllProcessManagementTemplates: "/getAllProcessManagementTemplates",
    getProcessManagementTemplateById: "/getProcessManagementTemplateById/",
    updateProcessManagementTemplate: "/updateProcessManagementTemplate",
    deleteProcessManagementTemplate: "/deleteProcessManagementTemplate/",
    toggleProcessManagementTemplateStatus: "/toggleProcessManagementTemplateStatus/toggle/",
    bulkAddProcessManagementTemplates: "/bulkAddProcessManagementTemplate"
  },


  processManagementProcessEndpoints: {
    addProcessManagementProcess: "/addProcessManagementProcess",
    getAllProcessManagementProcesses: "/getAllProcessManagementProcesses",
    getProcessManagementProcessById: "/getProcessManagementProcess/",
    updateProcessManagementProcess: "/updateProcessManagementProcess",
    deleteProcessManagementProcess: "/deleteProcessManagementProcess/",
    toggleProcessManagementProcessStatus: "/toggleProcessManagementProcessStatus/toggle/",
    bulkAddProcessManagementProcesses: "/bulkAddProcessManagementProcess"
  },


  processManagementPolicyEndpoints: {
    addProcessManagementPolicy: "/addProcessManagementPolicy",
    getAllProcessManagementPolicies: "/getAllProcessManagementPolicies",
    getProcessManagementPolicyById: "/getProcessManagementPolicy/",
    updateProcessManagementPolicy: "/updateProcessManagementPolicy",
    deleteProcessManagementPolicy: "/deleteProcessManagementPolicy/",
    toggleProcessManagementPolicyStatus: "/toggleProcessManagementPolicyStatus/toggle/",
    bulkAddProcessManagementPolicies: "/bulkAddProcessManagementPolicy"
  }

} 