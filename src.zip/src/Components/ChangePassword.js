import React, { useState } from "react";
import { Eye, EyeOff } from "lucide-react";

const PasswordField = ({ label, value, onChange, show, setShow, placeholder, info, error }) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 mb-1">
      {label}<span className="text-red1">*</span>
    </label>
    <div className="relative">
      <input
        type={show ? "text" : "password"}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className={`w-full border rounded px-3 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-darkblue1
          ${error ? "border-red1" : "border-gray-300"}`}
      />
      {info && <span className="text-xs text-gray-500">{info}</span>}
      <span
        className="absolute right-2 top-2.5 cursor-pointer"
        onClick={() => setShow(!show)}
      >
        {show ? <EyeOff className="w-5 h-5 text-gray-500" /> : <Eye className="w-5 h-5 text-gray-500" />}
      </span>
      {error && <p className="text-red1 text-xs mt-1">{error}</p>}
    </div>
  </div>
);

const ChangePassword = ({ isOpen, onClose, onSave }) => {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [errors, setErrors] = useState({});

  if (!isOpen) return null;

  const validatePassword = (password) => {
    // Password strength: min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special char
    const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
    return strongPasswordRegex.test(password);
  };

  const handleSave = () => {
    let tempErrors = {};

    if (!currentPassword) tempErrors.currentPassword = "Current password is required";
    if (!newPassword) tempErrors.newPassword = "New password is required";
    else if (newPassword.length < 8) tempErrors.newPassword = "Minimum 8 characters required";
    else if (!validatePassword(newPassword)) tempErrors.newPassword = "Password is too weak";
    if (!confirmPassword) tempErrors.confirmPassword = "Confirm password is required";
    else if (newPassword !== confirmPassword) tempErrors.confirmPassword = "Passwords do not match";

    setErrors(tempErrors);

    if (Object.keys(tempErrors).length === 0) {
      onSave({ currentPassword, newPassword });
      // Clear fields
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setShowCurrent(false);
      setShowNew(false);
      setShowConfirm(false);
      setErrors({});
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 px-4">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-red-500 hover:text-red-700"
        >
                      <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" alt="close" className="w-5 h-5"/>

        </button>

        <h2 className="text-center font-semibold text-darkblue1 mb-6">Change Password</h2>

        <div className="space-y-4">
          <PasswordField
            label="Current Password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            show={showCurrent}
            setShow={setShowCurrent}
            placeholder="Enter Current Password"
            error={errors.currentPassword}
          />

          <PasswordField
            label="New Password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            show={showNew}
            setShow={setShowNew}
            placeholder="Enter New Password"
            info="Minimum 8 characters with uppercase, lowercase, number & special char"
            error={errors.newPassword}
          />

          <PasswordField
            label="Confirm New Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            show={showConfirm}
            setShow={setShowConfirm}
            placeholder="Enter New Password"
            error={errors.confirmPassword}
          />
        </div>

        {/* Save Button */}
        <div className="mt-6 text-center">
          <button
            onClick={handleSave}
              className="bg-darkblue1 text-white text-sm font-medium px-10 py-1.5 rounded-md hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChangePassword;
