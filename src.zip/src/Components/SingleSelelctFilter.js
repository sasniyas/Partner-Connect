
"use client";
import { useState, useEffect, useRef } from "react";
import { IoSearch } from "react-icons/io5";
import { X, RotateCcw } from "lucide-react";

const DropdownArrow = ({ isOpen }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className={`w-5 h-5 transition-transform duration-300 ${
      isOpen ? "rotate-180" : "rotate-0"
    }`}
    fill="none"
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
);

const SingleSelectFilter = ({
  name,
  value = "",
  options = [],
  onChange,
  className = "",
  placeholder = "-Select-",
  placeholderColor = "text-gray-400",
  buttonBorderColor = "border-gray-300",
  dropdownBgColor = "bg-white",
  dropdownTextColor = "text-black",
  dropdownHoverColor = "hover:bg-gray-100",
  dropdownBorderColor = "border-gray-300",
  textColor = "text-gray-800",
  disableSorting = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
const buttonRef = useRef(null);
const dropdownRef = useRef(null);
  const wrapperRef = useRef(null);
  const searchInputRef = useRef(null);

  const showSearch = options.length > 4;

  const toggleDropdown = (e) => {
    e.stopPropagation();
    setIsOpen((prev) => !prev);
    setSearchTerm("");
  };

  const handleClear = (e) => {
    e.stopPropagation();
    onChange(name, "");
  };

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) {
        setIsOpen(false);
        setSearchTerm("");
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (isOpen && showSearch) {
      searchInputRef.current?.focus();
    }
  }, [isOpen, showSearch]);

  const processedOptions = disableSorting
    ? [...options]
    : [...options].sort((a, b) =>
        String(a ?? "").localeCompare(String(b ?? ""))
      );

  const filteredOptions = processedOptions.filter((option) =>
    String(option).toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOptionSelect = (option) => {
    onChange(name, option);
    setIsOpen(false);
    setSearchTerm("");
  };

  return (
    <div ref={wrapperRef} className={`relative inline-block w-44 ${className}`}>
      {/* Button */}
     <button
  ref={buttonRef}
  type="button"
  onClick={toggleDropdown}
  onKeyDown={(e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      setIsOpen(true);
    }

    if (e.key === "Escape") {
      e.preventDefault();
      setIsOpen(false);
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setIsOpen(true);

      setTimeout(() => {
        const first = dropdownRef.current?.querySelector("li");
        first?.focus();
      }, 0);
    }
  }}
  className={`flex items-center px-3 h-8 w-full text-xs border ${buttonBorderColor}
  ${isOpen ? "border-b-0" : ""}
  ${dropdownBgColor}`}
>
        <span
          className={`truncate flex-1 text-left ${
            value ? `${textColor} font-medium` : placeholderColor
          }`}
        >
          {value || placeholder}
        </span>

        <div className="flex items-center gap-1 ml-auto">
          {value && (
            <span
              onClick={handleClear}
              className="p-0.5 rounded hover:bg-gray-100 text-gray-500 hover:text-gray-700"
              title="Clear filter"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </span>
          )}
          <DropdownArrow isOpen={isOpen} />
        </div>
      </button>

      {/* Dropdown */}
      {isOpen && (
        <div
            ref={dropdownRef}   // ✅ ADD THIS
          className={`absolute z-50 ${dropdownBgColor} ${dropdownTextColor}
          border ${dropdownBorderColor} shadow-lg
          min-w-full max-h-48 overflow-auto`}
        >
          {showSearch && (
            <div className="flex items-center gap-1 px-2 py-1">
              <IoSearch className="w-3.5 h-3.5 text-gray-400" />
              <input
                ref={searchInputRef}
                value={searchTerm}
                onKeyDown={(e) => {
  if (e.key === "Escape") {
    e.preventDefault();
    setIsOpen(false);
    setSearchTerm("");
    buttonRef.current?.focus();
  }

  if (e.key === "ArrowDown") {
    e.preventDefault();
    const first = dropdownRef.current?.querySelector("li");
    first?.focus();
  }
}}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={`Search ${placeholder.toLowerCase()}...`}
                className="flex-1 bg-transparent outline-none text-xs"
              />
              {searchTerm && (
                <button onClick={() => setSearchTerm("")}>
                  <X className="w-3.5 h-3.5 text-gray-400" />
                </button>
              )}
            </div>
          )}

          <ul className="py-1 text-xs">
            {filteredOptions.length ? (
              filteredOptions.map((option, index) => (
               <li
  tabIndex={0}
  key={index}
  onClick={() => handleOptionSelect(option)}
  onKeyDown={(e) => {
    const items = Array.from(
      dropdownRef.current.querySelectorAll("li")
    );
    const currentIndex = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      const next = (currentIndex + 1) % items.length;
      items[next]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      const prev = (currentIndex - 1 + items.length) % items.length;
      items[prev]?.focus();
    }

    if (e.key === "Enter") {
      handleOptionSelect(option);
    }

    if (e.key === "Escape") {
      e.preventDefault();
      setIsOpen(false);
      buttonRef.current?.focus();
    }
  }}
  className={`px-3 py-1 cursor-pointer ${dropdownHoverColor}
  ${option === value ? "bg-lightBlue/50 font-semibold" : ""}`}
>
  {option}
</li>
              ))
            ) : (
              <li className="px-3 py-6 text-center text-gray-500 italic">
                No results found
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default SingleSelectFilter;