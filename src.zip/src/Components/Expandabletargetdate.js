import React, { useState, useCallback, useEffect } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { getTargetDateHistory } from "../services/monthlyMeeting/actionItem/actionItem.service";

// ═══════════════════════════════════════════════════════════════
// EXPANDABLE TARGET DATE COMPONENT
// Works for BOTH Monthly Meeting AND PDP:
//
//   MM usage (default — no fetchFn needed):
//   <ExpandableTargetDate currentDate={row.targetDate} actionItemId={row.id} />
//
//   PDP usage (pass fetchFn prop):
//   import { getPdpTargetDateHistory } from "...pdpActionItem.service";
//   <ExpandableTargetDate currentDate={item.targetDate} actionItemId={item.id} fetchFn={getPdpTargetDateHistory} />
//
// If fetchFn is not passed, falls back to MM's getTargetDateHistory
// ═══════════════════════════════════════════════════════════════

const formatDateForDisplay = (dateString) => {
  if (!dateString || dateString === "-" || dateString === "N/A" || dateString === "null" || dateString === null)
    return "-";
  try {
    if (typeof dateString === "string" && dateString.includes("/")) return dateString;
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "-";
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  } catch {
    return "-";
  }
};

const ExpandableTargetDate = ({
  currentDate,
  actionItemId,
  fetchFn, // optional — pass getPdpTargetDateHistory for PDP, leave empty for MM
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [previousDates, setPreviousDates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [fetched, setFetched] = useState(false);

  // Use passed fetchFn if provided, otherwise default to MM's getTargetDateHistory
  const resolveFetchFn = fetchFn || getTargetDateHistory;

  const fetchHistory = useCallback(async () => {
    if (fetched || !actionItemId) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      const response = await resolveFetchFn(actionItemId);
      if (response.status && response.data && response.data.length > 0) {
        const currentFormatted = formatDateForDisplay(currentDate);
        const filteredDates = response.data
          .map((d) => formatDateForDisplay(d))
          .filter((d) => d !== "-" && d !== currentFormatted);
        const uniqueDates = [...new Set(filteredDates)];
        setPreviousDates(uniqueDates);
      }
    } catch (err) {
      console.warn("Failed to fetch target date history:", err);
    } finally {
      setLoading(false);
      setFetched(true);
    }
  }, [actionItemId, currentDate, fetched]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const handleToggle = (e) => {
    e.stopPropagation();
    setIsExpanded(!isExpanded);
  };

  const displayDate = currentDate || "-";

  // No previous dates found — show plain date
  if (fetched && previousDates.length === 0) {
    return <span className="whitespace-nowrap">{formatDateForDisplay(displayDate)}</span>;
  }

  // Still loading — show plain date
  if (loading) {
    return <span className="whitespace-nowrap">{formatDateForDisplay(displayDate)}</span>;
  }

  return (
    <div className="overflow-hidden">
      {/* Current date + toggle arrow */}
      <div className="flex items-center gap-0.5 flex-wrap">
        <span className="whitespace-nowrap text-[10px]">{formatDateForDisplay(displayDate)}</span>
        <button
          type="button"
          onClick={handleToggle}
          className="inline-flex items-center justify-center w-3.5 h-3.5 rounded-full bg-amber-100 hover:bg-amber-200 transition-colors cursor-pointer flex-shrink-0"
          title={isExpanded ? "Hide previous dates" : "Show previous dates"}
        >
          {isExpanded ? (
            <ChevronUp className="w-2.5 h-2.5 text-amber-700" />
          ) : (
            <ChevronDown className="w-2.5 h-2.5 text-amber-700" />
          )}
        </button>
      </div>

      {/* Inline expanded previous dates */}
      {isExpanded && (
        <div className="mt-0.5 pt-0.5 border-t border-amber-200">
          <span className="text-[8px] text-gray-400 font-medium">Previous:</span>
          {previousDates.map((date, idx) => (
            <div key={idx} className="text-[10px] text-gray-400 line-through leading-tight">
              {date}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ExpandableTargetDate;