import React, { useState, useRef, useEffect } from "react";

const daysOfWeek = ["S", "M", "T", "W", "T", "F", "S"];
const months = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

const Datepicker = ({ onDateSelect, closeCalendar }) => {
  const [date, setDate] = useState(new Date());
  const [monthOpen, setMonthOpen] = useState(false);
  const [yearOpen, setYearOpen] = useState(false);
  const dropdownRef = useRef(null);

  const year = date.getFullYear();
  const month = date.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const startDay = new Date(year, month, 1).getDay();
  const today = new Date();

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setMonthOpen(false);
        setYearOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleDayClick = (day) => {
  const selected = new Date(year, month, day);
  const dd = String(selected.getDate()).padStart(2, "0");
  const mm = String(selected.getMonth() + 1).padStart(2, "0");
  const yyyy = selected.getFullYear();
  const formatted = `${dd}-${mm}-${yyyy}`;
  onDateSelect(formatted);
};

  const handleMonthChange = (offset) => {
    setDate(new Date(year, month + offset, 1));
  };

  const handleYearChange = (offset) => {
    setDate(new Date(year + offset, month, 1));
  };

  const handleClear = () => {
    onDateSelect("");
  };

  const handleToday = () => {
  const dd = String(today.getDate()).padStart(2, "0");
  const mm = String(today.getMonth() + 1).padStart(2, "0");
  const yyyy = today.getFullYear();
  const formatted = `${dd}-${mm}-${yyyy}`;
  onDateSelect(formatted);
};


  const renderDays = () => {
    const cells = [];
    for (let i = 0; i < startDay; i++) {
      cells.push(<div key={`empty-${i}`} className="w-8 h-8" />);
    }

    for (let d = 1; d <= daysInMonth; d++) {
      const isToday =
        d === today.getDate() &&
        month === today.getMonth() &&
        year === today.getFullYear();

      cells.push(
        <button
          key={d}
          onClick={() => handleDayClick(d)}
          className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center
            ${isToday ? "bg-blue-600 text-white font-bold" : "text-xs hover:bg-mildBlue hover:text-white"}
          `}
        >
          {d}
        </button>
      );
    }

    return cells;
  };

  return (
    <div
      className="absolute z-50 bg-lightBlue border border-gray-300 rounded-xl shadow-xl p-3 w-[90vw] sm:w-60 md:w-64 lg:w-72 text-sm"
      ref={dropdownRef}
    >
      {/* Month & Year Selectors */}
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center gap-1">
          <button onClick={() => handleMonthChange(-1)}>
            <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/decrementdatepicker.png" alt="prev" className="hover:scale-110" />
          </button>

          {/* Month Dropdown */}
          <div className="relative w-fit">
            <button
              onClick={() => setMonthOpen(!monthOpen)}
              className="flex items-center pr-4 gap-1"
            >
              {months[month]}
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/material-symbols-light_arrow-drop-down-rounded.png"
                alt="Dropdown"
                className={`w-5 h-5 transition-transform ${monthOpen ? "rotate-180" : ""}`}
              />
            </button>
            {monthOpen && (
              <ul className="absolute z-10 bg-white text-black shadow border rounded-md w-20 max-h-48 overflow-y-auto">
                {months.map((m, i) => (
                  <li
                    key={m}
                    onClick={() => {
                      setDate(new Date(year, i, 1));
                      setMonthOpen(false);
                    }}
                    className={`px-3 py-1 hover:bg-grey cursor-pointer ${i === month ? "font-semibold text-lg" : ""}`}
                  >
                    {m}
                  </li>
                ))}
              </ul>
            )}
          </div>

          <button onClick={() => handleMonthChange(1)}>
            <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/incremnetdatepicker.png" alt="next" className="hover:scale-110" />
          </button>
        </div>

        {/* Year Dropdown */}
        <div className="flex items-center gap-1">
          <button onClick={() => handleYearChange(-1)}>
            <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/decrementdatepicker.png" alt="prev" className="hover:scale-110" />
          </button>

          <div className="relative w-fit">
            <button
              onClick={() => setYearOpen(!yearOpen)}
              className="flex items-center pr-4 gap-1"
            >
              {year}
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/material-symbols-light_arrow-drop-down-rounded.png"
                alt="Dropdown"
                className={`w-5 h-5 transition-transform ${yearOpen ? "rotate-180" : ""}`}
              />
            </button>
            {yearOpen && (
              <ul className="absolute z-10 bg-white text-black shadow border rounded-md w-24 max-h-48 overflow-y-auto">
                {Array.from({ length: 20 }, (_, i) => year - 10 + i).map((y) => (
                  <li
                    key={y}
                    onClick={() => {
                      setDate(new Date(y, month, 1));
                      setYearOpen(false);
                    }}
                    className={`px-3 py-1 hover:bg-grey cursor-pointer ${y === year ? "font-semibold text-lg" : ""}`}
                  >
                    {y}
                  </li>
                ))}
              </ul>
            )}
          </div>

          <button onClick={() => handleYearChange(1)}>
            <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/incremnetdatepicker.png" alt="next" className="hover:scale-110" />
          </button>
        </div>
      </div>

      {/* Weekdays */}
      <div className="grid grid-cols-7 text-center text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">
        {daysOfWeek.map((d) => (
          <div key={d}>{d}</div>
        ))}
      </div>

      {/* Days Grid */}
      <div className="grid grid-cols-7 gap-1 mb-3">{renderDays()}</div>

      {/* Footer Buttons */}
      <div className="flex justify-between text-blue-600 font-medium text-xs">
        <button className="hover:scale-110" onClick={handleClear}>
          Clear
        </button>
        <button className="hover:scale-110" onClick={handleToday}>
          Today
        </button>
      </div>
    </div>
  );
};

export default Datepicker;
