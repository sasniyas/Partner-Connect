// import React from "react";  


// const IconSidebar = () => {
//     return (

// <div className="fixed top-[68px] left-0 h-[calc(100vh-68px)] w-20 bg-white shadow-lg z-40">
//     <div className="flex flex-col items-center justify-center w-full">
//          <img src="/icons/material-symbols-light_home-rounded.png" alt="Home" className="h-12 w-12 mb-6 mt-7 hover:bg-lightGrey p-2 rounded-lg transition duration-300" />
//          </div>
//       </div>
//     );
//   };
  
//   export default IconSidebar;

// import React from "react";
// import { useLocation } from "react-router-dom";
// import FullSidebar from "./Fullsidebar";
// import { useState } from "react";

// // import Login from "../pages/Login/Login";

// const IconSidebar = () => {
//     const location = useLocation();
//    const [isExpanded, setIsExpanded] = useState(false);
    
//         const isHome = location.pathname === "/homepage"; // Check if it's the Home page
//         const isManagement = location.pathname === "";
//         const isMasters = location.pathname === "";
//         const isMonthlymeeting = location.pathname === "";
//         const isPDP = location.pathname === "";
//         const isDealerinvestment = location.pathname === "";
//         const isScorecard = location.pathname === "";
//         const isDFHM = location.pathname === "";
//         const isDebugflows = location.pathname === "";
    
//   return (
  
//     <div className="fixed top-[40px] lg:top-[60px] xl:top-[68px] left-0 h-[calc(100vh-40px)] lg:h-[calc(100vh-60px)] xl:h-[calc(100vh-68px)] w-10 bg-white shadow-lg z-40
//                      md:w-20 lg:w-24 xl:w-20 
//                     flex flex-col items-center py-7"
//                     onMouseEnter={() => setIsExpanded(true)}
//       onMouseLeave={() => setIsExpanded(false)}>
      
//       {/* Icon List */}
//       <div className="flex flex-col items-center space-y-1 w-full">
//         <img 
//           src="/icons/material-symbols-light_home-rounded.png" 
//           alt="Home" 
//           className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 
//             xl:p-2  rounded-lg transition duration-300 cursor-pointer
//             ${isHome ? "bg-lightGrey text-white  " : "hover:bg-lightBlue"}`}
//         />

// <img 
//           src="/icons/clarity_users-line.png" 
//           alt="mangement" 
//           className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10
//             p-2 rounded-lg transition duration-300 cursor-pointer
//             ${isManagement ? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
//         />

// <img 
//           src="/icons/Vector (4).png" 
//           alt="masters" 
//           className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 
//             p-2 rounded-lg transition duration-300 cursor-pointer
//             ${isMasters ? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
//         />



// <img 
//           src="/icons/Vector (5).png" 
//           alt="monthlymeeting" 
//           className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 
//             p-2 rounded-lg transition duration-300 cursor-pointer
//             ${isMonthlymeeting ? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
//         />

// <img 
//           src="/icons/mdi-light_file.png" 
//           alt="pdp" 
//           className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 
//             p-2 rounded-lg transition duration-300 cursor-pointer
//             ${isPDP ? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
//         />
//         <img 
//           src="/icons/arcticons_folder-rupee.png" 
//           alt="Dealerinvestment" 
//           className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 
//             p-2 rounded-lg transition duration-300 cursor-pointer
//             ${isDealerinvestment? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
//         />

// <img 
//           src="/icons/proicons_graph.png" 
//           alt="scorecard" 
//           className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 
//             p-2 rounded-lg transition duration-300 cursor-pointer
//             ${isScorecard ? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
//         />

// <img 
//           src="/icons/streamline_medical-bag.png" 
//           alt="dfhm" 
//           className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 
//             p-2 rounded-lg transition duration-300 cursor-pointer
//             ${isDFHM? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
//         />

// <img 
//           src="/icons/solar_bug-broken.png" 
//           alt="debugflows" 
//           className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 
//             p-2 rounded-lg transition duration-300 cursor-pointer
//             ${isDebugflows ? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
//         />

// </div>
// {/* <div className="border-l border-gh-6 md:h-8 lg:h-10"></div> */}

// {/* <div className="border-t-2 border-lightBlue w-6 md:w-8 lg:w-10 my-[60px] ">
// <img 
//           src="/icons/Group 5.png" 
//           alt="Home" 
//         //   className="h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 mt- "
//         className="h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10  lg:mt-[5px] cursor-pointer hover:bg-red-200 p-2 rounded-lg transition duration-300"

//         />

// </div> */}
//  <div className={`absolute left-[150px] top-0 h-full transition-all duration-300 ${isExpanded ? "translate-x-0 opacity-100" : "-translate-x-full opacity-0"}`}>
//                 <FullSidebar />
//             </div>
//     </div>
   
   
//   );
// };

// export default IconSidebar;

// import { useState } from "react";
// import { useLocation } from "react-router-dom";
// import FullSidebar from "./Fullsidebar";

// const IconSidebar = () => {
//     const location = useLocation();
//     const [isExpanded, setIsExpanded] = useState(false);

//     const menuItems = [
//         // { path: "/homepage", icon: "/icons/material-symbols-light_home-rounded.png", alt: "Home" },
//          { 
//     path: "/homepage", 
//     icon: "/icons/Sidebar/home default.png" , 
//     activeIcon: "/icons/Sidebar/home active.png", 
//     alt: "Home" 
//   },
//         { path: ["/usermangement","/userdetails","/showhistory","/authentication","/userlogin"], icon: "/icons/clarity_users-line.png", activeIcon: "/icons/HomePage/ActiveDealer.png",  alt: "Management" },
//         { path: ["/scorecard","/masterpdphomepage","/mastermothlymeeting","/masterdealerinvestment","/masterdashboard","/masterdfhm"] ,icon: "/icons/Vector (4).png", alt: "Masters" },
//         { path: ["/monthlymeetinghomepage","/trendchart","/actionitemview","/monthlymeetingviewdetails"], icon: "/icons/Vector (5).png", alt: "Monthly Meeting" },
//         { path: ["/pdphomepage","/viewpdp","/viewdetailshomepage","/actionplannermanagement","/downloadpdpdetails","/pdpactionplannerlist","/pdptrendchart","/pdpactionitem","/branchmanager","/consolidatedpdp","/viewconsolidatedpdp"], icon: "/icons/mynaui_file.png", alt: "PDP" },
//         { path:["/viewdealerinvestmenthome"], icon: "/icons/Group (1).png", alt: "Dealer Investment" },
//         { path: "/scorecarddasbboard", icon: "/icons/proicons_graph.png", alt: "Scorecard" },
//         { path: "/dfhm", icon: "/icons/streamline_medical-bag.png", alt: "DFHM" },
//         // { path: "/debugflows", icon: "/icons/solar_bug-broken.png", alt: "Debug Flows" },
//     ];

//     return (
//         <div 
//             className="fixed top-[40px] lg:top-[60px] xl:top-[68px] left-0 h-[calc(100vh-40px)] lg:h-[calc(100vh-60px)] xl:h-[calc(100vh-68px)] w-10 bg-white shadow-lg z-40
//                      md:w-20 lg:w-24 xl:w-20 flex flex-col items-center py-7"
//             onMouseEnter={() => setIsExpanded(true)}
//             onMouseLeave={() => setIsExpanded(false)}
//         >
//             {/* <div className="flex flex-col items-center space-y-4 w-full">
//                 {menuItems.map((item) => (
//                     <img 
//                         key={item.path}
//                         src={item.icon}
//                         alt={item.alt}
//                         className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 p-2 rounded-lg transition duration-300 cursor-pointer
//                         ${location.pathname === item.path ? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
//                     />
//                 ))}
//             </div> */}

// <div className="flex flex-col items-center space-y-4 w-full">
//                 {menuItems.map((item) => {
//                     const paths = Array.isArray(item.path) ? item.path : [item.path]; // Ensure it's always an array
//                     const isActive = paths.includes(location.pathname);

//                     return (
//                         <img 
//                             key={paths.join(",")} // Now it's always an array, so `.join()` won't break
//                             src={isActive ? item.activeIcon || item.icon : item.icon}
//                             alt={item.alt}
//                             className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 p-2 rounded-lg transition duration-300 cursor-pointer
//                             ${isActive ? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
//                         />
//                     );
//                 })}
//             </div>
// {/* 
//             <div 
//                 className={`absolute left-[210px] top-[-65px] h-full transition-all duration-300 w-60 
//                 ${isExpanded ? "translate-x-0 opacity-100" : "-translate-x-full opacity-0"}`}
//             > */}
//             <div 
//     className={`absolute left-[240px] top-[-70px] h-full transition-all duration-300 w-[1200px] 
//     ${isExpanded ? "translate-x-0 opacity-100 pointer-events-auto" : "-translate-x-full opacity-0 pointer-events-none"}`}
// >
//     <FullSidebar />
// </div>

//                 {/* <FullSidebar />
//             </div> */}
//         </div>
//     );
// };  

// export default IconSidebar;


import { useState } from "react";
import { useLocation } from "react-router-dom";
import FullSidebar from "./Fullsidebar";

const IconSidebar = () => {
  const location = useLocation();
  const [isExpanded, setIsExpanded] = useState(false);

  const menuItems = [
    { 
      path: "/homepage", 
      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Sidebar/home default.png", 
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Sidebar/home active.png", 
      alt: "Home" 
    },
    { 
      path: "/outlook", 
      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Sidebar/outlookdefault.png", 
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Sidebar/outlookactive.png", 
      alt: "outlook" 
    },
    { 
      path: ["/usermangement", "/userdetails", "/showhistory", "/authentication", "/userlogin"], 
      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/clarity_users-line.png", 
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/HomePage/ActiveDealer.png",  
      alt: "Management" 
    },
    { 
      path: ["/scorecard", "/masterpdphomepage", "/mastermothlymeeting", "/masterdealerinvestment", "/masterdashboard", "/masterdfhm"], 
      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Vector (4).png", 
      alt: "Masters" 
    },
    { 
      path: ["/monthlymeetinghomepage", "/trendchart", "/actionitemview", "/monthlymeetingviewdetails"], 
      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Vector (5).png", 
      alt: "Monthly Meeting" 
    },
    { 
      path: ["/pdphomepage", "/viewpdp", "/viewdetailshomepage", "/actionplannermanagement", "/downloadpdpdetails", "/pdpactionplannerlist", "/pdptrendchart", "/pdpactionitem", "/branchmanager", "/consolidatedpdp", "/viewconsolidatedpdp"], 
      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/mynaui_file.png", 
      alt: "PDP" 
    },
    { 
      path: ["/viewdealerinvestmenthome"], 
      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Group (1).png", 
      alt: "Dealer Investment" 
    },
    { 
      path: "/scorecarddasbboard", 
      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/proicons_graph.png", 
      alt: "Scorecard" 
    },
    { 
      path: "/dfhm", 
      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/streamline_medical-bag.png", 
      alt: "DFHM" 
    },
  ];

  return (
    // Hide on small screens, visible on md and up
    <div 
      className="hidden md:flex fixed top-[40px] lg:top-[60px] xl:top-[68px] left-0 
                 h-[calc(100vh-40px)] lg:h-[calc(100vh-60px)] xl:h-[calc(100vh-68px)] 
                 w-10 md:w-20 lg:w-24 xl:w-20 
                 bg-white shadow-lg z-40 flex-col items-center py-7"
      onMouseEnter={() => setIsExpanded(true)}
      onMouseLeave={() => setIsExpanded(false)}
    >
      {/* Sidebar Menu Icons */}
      <div className="flex flex-col items-center space-y-4 w-full">
        {menuItems.map((item) => {
          const paths = Array.isArray(item.path) ? item.path : [item.path];
          const isActive = paths.includes(location.pathname);
          return (
            <img 
              key={paths.join(",")}
              src={isActive ? item.activeIcon || item.icon : item.icon}
              alt={item.alt}
              className={`h-10 w-10 md:h-12 md:w-12 lg:h-10 lg:w-10 p-2 rounded-lg transition duration-300 cursor-pointer
                ${isActive ? "bg-lightGrey text-white" : "hover:bg-lightBlue"}`}
            />
          );
        })}
      </div>
      {/* Full Sidebar appears on hover */}
      <div 
        className={`absolute left-[260px] top-[-70px] h-full transition-all duration-300 w-[1300px] 
                    ${isExpanded ? "translate-x-0 opacity-100 pointer-events-auto" : "-translate-x-full opacity-0 pointer-events-none"}`}
      >
        <FullSidebar />
      </div>
    </div>
  );
};

export default IconSidebar;
