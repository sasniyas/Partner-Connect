// // "use client";

// import {
//   Home,
//   LayoutDashboard,
//   Users,
//   Database,
// } from "lucide-react";
// import { Link, useLocation } from "react-router-dom";
// import { useRef } from "react";
// // import Scorecard from "../pages/Masters/Scorecard/Scorecard";

// const SubNavbar1 = () => {
//   const location = useLocation();
//   const menuRef = useRef(null);

//   const managementDropdown = [
//     {
//       title: "User Management",
//       path: "/usermangement",
//       links: [],
//     },
//     {
//       title: "Log",
//       links: [
//         { id: "auth-log", label: "Authentication Log", path: "/authentication" },
//         { id: "user-history", label: "User History", path: "/usermangement/user-history" },
//       ],
//     },
//   ];

//   const mastersDropdown = [
//     { title: "Scorecard", path: "/scorecard", links: [] },
//     { title: "PDP", path: "/masterpdphomepage", links: [] },
//     { title: "Monthly meeting", path: "/mastermothlymeeting", links: [] },
//     { title: "DealerInvestment", path: "/masterdealerinvestment", links: [] },
//     { title: "DashBoards", path: "/masterdashboard", links: [] },
//     { title: "Dfhm", path: "/masterdfhm", links: [] },
//   ];

//   const pdpDropdown =[
//     { title: "Create New PDP", path: "", links: [] },
//     { title: "View PDP", path: "", links: [] },
//     { title: "PDP Action Planner", path: "", links: [] },
//     { title: "DealerInvestment", path: "", links: [] },
//     { title: "Manage Branch Master", path: "", links: [] },
//     { title: "Consolidated PDP", path: "", links: [] },
//   ];

//   const dealerDropdown =[
//         { title: "View Dealer Investment", path: "", links: [] },
//         { title: "Infrastructure reports", path: "", links: [] },
//         { title: "Allocation Dashboard", path: "", links: [] },
//         { title: "MBP Dashboard V1", path: "", links: [] },


//   ];
// const scorecardDropdown = [
//         { title: "Create Review", path: "", links: [] },
//         { title: "View Reviews", path: "", links: [] },
//         { title: "ScoreCard Results", path: "", links: [] },
//         { title: "Action items", path: "", links: [] },
//   ]
//   const dfhmDropdown =[
//      { title: "View DFHM", path: "", links: [] },
//         { title: "ScoreCard Ratio", path: "", links: [] },
//         { title: "View Quarterly Meeting", path: "", links: [] },
//         { title: "Create Quarterly Meeting", path: "", links: [] },
//   ]

//   const menuItems = [
//     {
//       id: "home",
//       label: "Home",
//       icon: Home,
//       activeIcon: () => (
//         <img src="/icons/Sidebar/home active.png" alt="Home" className="w-5 h-5 object-contain" />
//       ),
//       path: "/homepage",
//     },
//     {
//       id: "outlook",
//       label: "Outlook",
//       icon: LayoutDashboard,
//       activeIcon: LayoutDashboard,
//       path: "/outlook",
//     },
//     {
//       id: "management",
//       label: "Management",
//       icon: Users,
//       activeIcon: Users,
//       path: "/usermangement",
//       submenu: managementDropdown,
//     },
//     {
//       id: "masters",
//       label: "Masters",
//       icon: Database,
//       activeIcon: () => (
//         <img src="/icons/masters-active.png" alt="Masters" className="w-4 h-4 object-contain" />
//       ),
//       submenu: mastersDropdown,
//     },
//     {
//       id: "monthly-meeting",
//       label: "Monthly Meeting",
//       icon: () => <img src="/icons\monthlymeeting.png" alt="calendar" className="w-4 h-4 object-contain" />,
//       activeIcon: () => <img src="/icons/calendar-active.png" alt="calendar" className="w-4 h-4 object-contain" />,
//     //   submenu: [
//     //     {
//     //       title: "Monthly Meeting",
//     //       links: [
//     //         { id: "trend-chart", label: "Trend Chart", path: "/trendchart" },
//     //         { id: "action-items", label: "Action Items", path: "/actionitemview" },
//     //         { id: "meeting-details", label: "Meeting Details", path: "/monthlymeetingviewdetails" },
//     //       ],
//     //     },
//     //   ],
//     },
//     {
//       id: "pdp",
//       label: "PDP",
//       icon: () => <img src="/icons/PDP.png" alt="pdp" className="w-4 h-4 object-contain" />,
//       activeIcon: () => <img src="/icons/pdp-active.png" alt="pdp" className="w-4 h-4 object-contain" />,
//     //   submenu: [
//     //     {
//     //       title: "PDP",
//     //       links: [
//     //         { id: "create-pdp", label: "Create New PDP", path: "/menu/pdp/create" },
//     //         { id: "view-pdp", label: "View PDP", path: "/menu/pdp/view" },
//     //         { id: "action-planner", label: "PDP Action Planner", path: "/menu/pdp/action-planner" },
//     //         { id: "manage-branch", label: "Manage Branch Master", path: "/menu/pdp/branch-master" },
//     //         { id: "consolidated", label: "Consolidated PDP", path: "/menu/pdp/consolidated" },
//     //       ],
//     //     },
//     //   ],
//     submenu:pdpDropdown
//     },
//     {
//       id: "dealer-investment",
//       label: "Dealer Investment",
//       icon: () => <img src="/icons/dealerinvestmnet.png" alt="investment" className="w-4 h-4 object-contain" />,
//       activeIcon: () => <img src="/icons/investment-active.png" alt="investment" className="w-4 h-4 object-contain" />,
//       submenu: dealerDropdown
//     //   [
//     //     {
//     //       title: "Dealer Investment",
//     //       links: [
//     //         { id: "view-investment", label: "View Dealer Investment", path: "/menu/dealerinvestment/view" },
//     //       ],
//     //     },
//     //   ],
//     },
//     {
//       id: "scorecard",
//       label: "Scorecard",
//       icon: () => <img src="/icons/Scorecard.png" alt="scorecard" className="w-4 h-4 object-contain" />,
//       activeIcon: () => <img src="/icons/scorecard-active.png" alt="scorecard" className="w-4 h-4 object-contain" />,
//       path: "/menu/scorecard",
//         submenu: scorecardDropdown
//     },
//     {
//       id: "dfhm",
//       label: "DFHM",
//       icon: () => <img src="/icons/DFHM.png" alt="dfhm" className="w-4 h-4 object-contain" />,
//       activeIcon: () => <img src="/icons/dfhm-active.png" alt="dfhm" className="w-4 h-4 object-contain" />,
//       path: "/menu/dfhm",
//        submenu: dfhmDropdown
//     },
//   ];

//   const isMenuItemActive = (item) => {
//     return (
//       (item.path && location.pathname.startsWith(item.path)) ||
//       (item.submenu &&
//         item.submenu.some(
//           (section) =>
//             (section.path && location.pathname.startsWith(section.path)) ||
//             section.links?.some((link) => location.pathname.startsWith(link.path))
//         ))
//     );
//   };

//   return (
//     <div className="hidden lg:block bg-grey2 border-t border-gray-300 w-full z-40 fixed top-20 shadow" style={{ height: "70px" }}>
//       <div className="max-w-screen-xl mx-auto h-full">
//         <div className="flex justify-center gap-3 sm:gap-6 md:gap-8  h-full" ref={menuRef}>
//           {menuItems.map((item) => {
//             const isActiveMain = isMenuItemActive(item);
//             const hasSubmenu = item.submenu && item.submenu.length > 0;
//             const Icon = isActiveMain ? item.activeIcon : item.icon;

//             return (
//               <div key={item.id} className="relative group h-full flex items-center transition-all duration-200 hover:bg-white">
//                 <Link
//                   to={item.path || "#"}
//                   className={`flex items-center gap-2 px-5 cursor-pointer h-full text-black ${
//                     isActiveMain ? "font-medium bg-white shadow" : ""
//                   }`}
//                 >
//                   {typeof Icon === "function" ? (
//                     <Icon />
//                   ) : (
//                     <Icon size={16} className={isActiveMain ? "fill-black stroke-black" : "fill-none stroke-current"} />
//                   )}
//                   <span className="text-base whitespace-nowrap">{item.label}</span>
//                 </Link>

//                 {hasSubmenu && (
//                 //   <div className="fixed top-[150px] left-1/2 -translate-x-1/2 mt-0 hidden group-hover:flex bg-white shadow-lg z-50 min-w-[320px] p-4">
//                 // <div className="absolute top-full left-1/2 -translate-x-1/2 mt-0 hidden group-hover:flex bg-white shadow-lg z-50 min-w-[320px] p-4">
// // ...existing code...
// <div
//   className={`absolute top-full mt-0 hidden group-hover:flex bg-white shadow-lg z-50 min-w-[220px] sm:min-w-[280px] md:min-w-[320px] lg:min-w-[340px] xl:min-w-[380px] p-2 sm:p-4 ${
//     item.id === "management" || item.id === "masters" || item.id === "pdp"
//       ? "left-1/2 -translate-x-1/2"
//       : item.id === "dealer-investment"
//       ? "left-3/2 -translate-x-1/2":
//         item.id === "scorecard"
//       ? "right-[-120px] left-auto"
//         :  item.id === "dfhm"
//       ? "right-0 left-auto"
//       : "left-0"
//   }`}>
//                     <div className="flex gap-6">
//                       {item.submenu.map((section, index) => {
//                         const isHeadingActive =
//                           (section.path && location.pathname.startsWith(section.path)) ||
//                           section.links?.some((link) => location.pathname.startsWith(link.path));

//                         return (
//                           <div key={section.title} className="flex flex-col relative pr-4">
//                             {section.path ? (
//                               <Link
//                                 to={section.path}
//                                 className={`font-semibold text-base mb-2 whitespace-nowrap hover:text-SteelBlue1 transition-colors ${
//                                   isHeadingActive ? "text-darkblue1" : "text-black"
//                                 }`}
//                               >
//                                 {section.title}
//                               </Link>
//                             ) : (
//                               <h4
//                                 className={`font-semibold text-base mb-2 whitespace-nowrap hover:text-SteelBlue1 transition-colors ${
//                                   isHeadingActive ? "text-darkblue1" : "text-black"
//                                 }`}
//                               >
//                                 {section.title}
//                               </h4>
//                             )}

//                             <ul>
//                               {section.links?.map((link) => (
//                                 <li key={link.id}>
//                                   <Link
//                                     to={link.path}
//                                     className={`block text-sm py-1 px-2 rounded whitespace-nowrap hover:bg-grey2 transition-colors ${
//                                       location.pathname === link.path
//                                         ? "font-semibold text-darkblue1"
//                                         : "text-black"
//                                     }`}
//                                   >
//                                     {link.label}
//                                   </Link>
//                                 </li>
//                               ))}
//                             </ul>

//                             {index !== item.submenu.length - 1 && (
//                               <div className="absolute top-0 right-[-12px] w-[0.2px] h-full bg-lightBlue" />
//                             )}
//                           </div>
//                         );
//                       })}
//                     </div>
//                   </div>
//                 )}
//               </div>
//             );
//           })}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SubNavbar1;


"use client"

import { Home, LayoutDashboard, Users, Database } from "lucide-react"
import { Link, useLocation } from "react-router-dom"
import { useRef } from "react"

const SubNavbar1 = () => {
  const location = useLocation()
  const menuRef = useRef(null)

  const managementDropdown = [
    {
      title: "User Management",
      path: "/usermangement",
      links: [],
    },
    {
      title: "Log",
      links: [
        { id: "auth-log", label: "Authentication Log", path: "/authentication" },
        { id: "user-history", label: "User History", path: "/usermangement/user-history" },
      ],
    },
  ]

  const mastersDropdown = [
    { title: "Scorecard", path: "/scorecard", links: [] },
    { title: "PDP", path: "/masterpdphomepage", links: [] },
    { title: "Monthly Meeting", path: "/mastermothlymeeting", links: [] },
    { title: "Dealer Investment", path: "/masterdealerinvestment", links: [] },
    { title: "Dashboards", path: "/masterdashboard", links: [] },
    { title: "DFHM", path: "/masterdfhm", links: [] },
  ]

  const pdpDropdown = [
    { title: "Create New PDP", path: "", links: [] },
    { title: "View PDP", path: "", links: [] },
    { title: "PDP Action Planner", path: "", links: [] },
    { title: "DealerInvestment", path: "", links: [] },
    { title: "Manage Branch Master", path: "", links: [] },
    { title: "Consolidated PDP", path: "", links: [] },
  ]

  const dealerDropdown = [
    { title: "View Dealer Investment", path: "", links: [] },
    { title: "Infrastructure reports", path: "", links: [] },
    { title: "Allocation Dashboard", path: "", links: [] },
    { title: "MBP Dashboard V1", path: "", links: [] },
  ]

  const scorecardDropdown = [
    { title: "Create Review", path: "", links: [] },
    { title: "View Reviews", path: "", links: [] },
    { title: "ScoreCard Results", path: "", links: [] },
    { title: "Action items", path: "", links: [] },
  ]

  const dfhmDropdown = [
    { title: "View DFHM", path: "", links: [] },
    { title: "ScoreCard Ratio", path: "", links: [] },
    { title: "View Quarterly Meeting", path: "", links: [] },
    { title: "Create Quarterly Meeting", path: "", links: [] },
  ]

  const menuItems = [
    {
      id: "home",
      label: "Home",
      icon: Home,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Sidebar/home active.png" alt="Home" className="w-5 h-5 object-contain" />,
      path: "/homepage",
    },
    {
      id: "outlook",
      label: "Outlook",
      icon: LayoutDashboard,
      activeIcon: LayoutDashboard,
      path: "/outlook",
    },
    {
      id: "management",
      label: "Management",
      icon: Users,
      activeIcon: Users,
      path: "/usermangement",
      submenu: managementDropdown,
    },
    {
      id: "masters",
      label: "Masters",
      icon: Database,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/masters-active.png" alt="Masters" className="w-4 h-4 object-contain" />,
      submenu: mastersDropdown,
    },
    {
      id: "monthly-meeting",
      label: "Monthly Meeting",
      icon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/monthlymeeting.png" alt="calendar" className="w-4 h-4 object-contain" />,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/calendar-active.png" alt="calendar" className="w-4 h-4 object-contain" />,
    },
    {
      id: "pdp",
      label: "PDP",
      icon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PDP.png" alt="pdp" className="w-4 h-4 object-contain" />,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/pdp-active.png" alt="pdp" className="w-4 h-4 object-contain" />,
      submenu: pdpDropdown,
    },
    {
      id: "dealer-investment",
      label: "Dealer Investment",
      icon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/dealerinvestmnet.png" alt="investment" className="w-4 h-4 object-contain" />,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/investment-active.png" alt="investment" className="w-4 h-4 object-contain" />,
      submenu: dealerDropdown,
    },
    {
      id: "scorecard",
      label: "Scorecard",
      icon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Scorecard.png" alt="scorecard" className="w-4 h-4 object-contain" />,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/scorecard-active.png" alt="scorecard" className="w-4 h-4 object-contain" />,
      path: "/menu/scorecard",
      submenu: scorecardDropdown,
    },
    {
      id: "dfhm",
      label: "DFHM",
      icon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/DFHM.png" alt="dfhm" className="w-4 h-4 object-contain" />,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/dfhm-active.png" alt="dfhm" className="w-4 h-4 object-contain" />,
      path: "/menu/dfhm",
      submenu: dfhmDropdown,
    },
  ]

  const isMenuItemActive = (item) => {
    return (
      (item.path && location.pathname.startsWith(item.path)) ||
      (item.submenu &&
        item.submenu.some(
          (section) =>
            (section.path && location.pathname.startsWith(section.path)) ||
            section.links?.some((link) => location.pathname.startsWith(link.path)),
        ))
    )
  }

  // Calculate dropdown position class based on item index
  const getDropdownPositionClass = (itemId) => {
    const totalItems = menuItems.length
    const itemIndex = menuItems.findIndex((item) => item.id === itemId)

    // First 3 items align left
    if (itemIndex < 3) {
      return "left-0"
    }
    // Last 2 items align right
    else if (itemIndex >= totalItems - 2) {
      return "right-0 left-auto"
    }
    // Special case for scorecard (3rd from end)
    else if (itemIndex === totalItems - 3) {
      return "right-0 translate-x-1/4 left-auto"
    }
    // Middle items center align
    else {
      return "left-1/2 -translate-x-1/2"
    }
  }

  return (
    <div
      className="hidden lg:block bg-grey2 border-t border-gray-300 w-full z-40 fixed top-20 shadow"
      style={{ height: "70px" }}
    >
      <div className="max-w-screen-2xl mx-auto h-full px-4">
        <div className="flex justify-between lg:justify-evenly xl:justify-center xl:gap-6 h-full" ref={menuRef}>
          {menuItems.map((item) => {
            const isActiveMain = isMenuItemActive(item)
            const hasSubmenu = item.submenu && item.submenu.length > 0
            const Icon = isActiveMain ? item.activeIcon : item.icon

            return (
              <div
                key={item.id}
                className="relative group h-full flex items-center transition-all duration-200 hover:bg-white"
              >
                <Link
                  to={item.path || "#"}
                  className={`flex items-center gap-1 lg:gap-2 px-2 lg:px-3 xl:px-5 cursor-pointer h-full text-black ${
                    isActiveMain ? "font-medium bg-white shadow" : ""
                  }`}
                >
                  {typeof Icon === "function" ? (
                    <Icon />
                  ) : (
                    <Icon size={16} className={isActiveMain ? "fill-black stroke-black" : "fill-none stroke-current"} />
                  )}
                  <span className="text-sm lg:text-base whitespace-nowrap">{item.label}</span>
                </Link>

                {hasSubmenu && (
                  <div
                    className={`absolute top-full mt-0 hidden group-hover:flex bg-white shadow-lg z-50 p-2 sm:p-4 ${getDropdownPositionClass(item.id)}`}
                    style={{
                      minWidth: item.submenu.length <= 3 ? "320px" : "480px",
                      maxWidth: "95vw",
                    }}
                  >
                    <div className={`flex ${item.submenu.length > 3 ? "flex-wrap lg:flex-nowrap" : ""} gap-6`}>
                      {item.submenu.map((section, index) => {
                        const isHeadingActive =
                          (section.path && location.pathname.startsWith(section.path)) ||
                          section.links?.some((link) => location.pathname.startsWith(link.path))

                        return (
                          <div key={section.title} className="flex flex-col relative pr-4">
                            {section.path ? (
                              <Link
                                to={section.path}
                                className={`font-semibold text-base mb-2 whitespace-nowrap hover:text-SteelBlue1 transition-colors ${
                                  isHeadingActive ? "text-darkblue1" : "text-black"
                                }`}
                              >
                                {section.title}
                              </Link>
                            ) : (
                              <h4
                                className={`font-semibold text-base mb-2 whitespace-nowrap hover:text-SteelBlue1 transition-colors ${
                                  isHeadingActive ? "text-darkblue1" : "text-black"
                                }`}
                              >
                                {section.title}
                              </h4>
                            )}

                            <ul>
                              {section.links?.map((link) => (
                                <li key={link.id}>
                                  <Link
                                    to={link.path}
                                    className={`block text-sm py-1 px-2 rounded whitespace-nowrap hover:bg-grey2 transition-colors ${
                                      location.pathname === link.path ? "font-semibold text-darkblue1" : "text-black"
                                    }`}
                                  >
                                    {link.label}
                                  </Link>
                                </li>
                              ))}
                            </ul>

                            {index !== item.submenu.length - 1 && (
                              <div className="absolute top-0 right-[-12px] w-[0.2px] h-full bg-lightBlue" />
                            )}
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

export default SubNavbar1
