"use client";
import { useState, useEffect, useRef } from "react";
import { IoSearch } from "react-icons/io5";
import { X, RotateCcw } from "lucide-react";
const DropdownArrow = ({ isOpen, onClick }) => (
  <svg
    onClick={onClick}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className={`w-5 h-5 cursor-pointer transition-transform duration-300 ${
      isOpen ? "rotate-180" : "rotate-0"
    }`}
    fill="none"
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
);

const Filter = ({
  name,
  value = [],
  options = [],
  onChange,
  className = "",
  placeholder = "-Select-",
  placeholderColor = "text-gray-400",
  buttonBorderColor = "border-gray-300",
  dropdownBgColor = "bg-white",
  dropdownTextColor = "text-black",
  dropdownHoverColor = "hover:bg-gray-100",
  dropdownBorderColor = "border-gray-300",
  textColor = "text-gray-800",
  disableSorting = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [showTopBorder, setShowTopBorder] = useState(false);

  const wrapperRef = useRef(null);
  const buttonRef = useRef(null);
  const dropdownRef = useRef(null);
  const searchInputRef = useRef(null);

  const showSearch = options.length > 4;

  const toggleDropdown = (e) => {
    e.stopPropagation();
    setIsOpen((prev) => !prev);
    setSearchTerm("");
  };

  const handleClearAll = () => {
    onChange(name, []);
    setSearchTerm("");
  };

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) {
        setIsOpen(false);
        setSearchTerm("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (isOpen && showSearch) {
      searchInputRef.current?.focus();
    }
  }, [isOpen, showSearch]);

  useEffect(() => {
    if (!isOpen) return;

    const measure = () => {
      if (!buttonRef.current || !dropdownRef.current) return;
      setShowTopBorder(
        dropdownRef.current.scrollWidth > buttonRef.current.offsetWidth
      );
    };

    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(dropdownRef.current);
    return () => ro.disconnect();
  }, [isOpen]);

  const processedOptions = disableSorting
    ? [...options]
    : [...options].sort((a, b) =>
        String(a ?? "").localeCompare(String(b ?? ""))
      );

  const filteredOptions = processedOptions.filter((o) =>
    String(o ?? "").toLowerCase().includes(searchTerm.toLowerCase())
  );

  const toggleOption = (option) => {
    const newValue = value.includes(option)
      ? value.filter((v) => v !== option)
      : [...value, option];

    onChange(name, newValue);
  };

  const displayText =
    value.length === 0
      ? placeholder
      : value.length === 1
      ? String(value[0])
      : `${value.length} selected`;

  return (
    <div ref={wrapperRef} className={`relative inline-block w-44 ${className}`}>
      {/* Button */}
     <button
  ref={buttonRef}
  type="button"
  onClick={toggleDropdown}

  onKeyDown={(e) => {

    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setIsOpen(true)      // open dropdown
    }

    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setIsOpen(false)     // close dropdown
    }

  }}

  className={`flex items-center px-3 h-8 w-full
    text-xs border ${buttonBorderColor}
    ${isOpen ? "border-b-0" : ""}
    ${dropdownBgColor}`}
>
        <span
          className={`truncate flex-1 text-left pr-8 ${
            value.length ? `${textColor} font-medium` : placeholderColor
          }`}
        >
          {displayText}
        </span>

        <div className="flex items-center gap-1 ml-auto">
          {value.length > 0 && (
            <span
              onClick={(e) => {
                e.stopPropagation();
                handleClearAll();
              }}
              className="p-0.5 rounded hover:bg-gray-100 text-gray-500 hover:text-gray-700"
              title="Clear filter"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </span>
          )}
          <DropdownArrow isOpen={isOpen} />
        </div>
      </button>

      {/* Dropdown */}
      {isOpen && (
        <div
          ref={dropdownRef}
          className={`
            absolute z-50
            ${dropdownBgColor} ${dropdownTextColor}
            border ${dropdownBorderColor}
            ${showTopBorder ? "border-t" : "border-t-0"}
            shadow-lg
            min-w-full w-max max-w-[90vw]
            max-h-48 overflow-auto scrollbar-thin
          `}
        >
          {showSearch && (
            <div className="flex items-center gap-1 px-2 py-1">
              <IoSearch className="w-3.5 h-3.5 text-gray-400" />
            <input
  ref={searchInputRef}
  value={searchTerm}
  onChange={(e) => setSearchTerm(e.target.value)}

 onKeyDown={(e) => {
  // ESC → close dropdown
  if (e.key === "Escape") {
    e.preventDefault();
    e.stopPropagation();

    setIsOpen(false);
    setSearchTerm("");
    buttonRef.current?.focus();
    return;
  }

  // ⬇️ ArrowDown → go to first item
  if (e.key === "ArrowDown") {
    e.preventDefault();

    const items = Array.from(
      dropdownRef.current?.querySelectorAll("li") || []
    );

    if (items.length) {
      items[0].focus();
    }
  }

  // ⬆️ ArrowUp → go to last item
  if (e.key === "ArrowUp") {
    e.preventDefault();

    const items = Array.from(
      dropdownRef.current?.querySelectorAll("li") || []
    );

    if (items.length) {
      items[items.length - 1].focus();
    }
  }
}}

  placeholder={`Search ${placeholder.toLowerCase()}...`}
  className="flex-1 bg-transparent outline-none text-xs text-left"
/>
              {searchTerm && (
                <button onClick={() => setSearchTerm("")}>
                  <X className="w-3.5 h-3.5 text-gray-400" />
                </button>
              )}
            </div>
          )}

          <ul className="py-1 text-xs">
            {filteredOptions.length ? (
              filteredOptions.map((option, index) => (
               <li
  tabIndex={0}
  key={index}
  onClick={() => toggleOption(option)}
  onKeyDown={(e) => {
    const items = Array.from(
      dropdownRef.current.querySelectorAll("li")
    );
    const currentIndex = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      const next = (currentIndex + 1) % items.length;
      items[next]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      const prev = (currentIndex - 1 + items.length) % items.length;
      items[prev]?.focus();
    }

    if (e.key === "Enter") {
      toggleOption(option);
    }
    if (e.key === "Escape") {
  e.preventDefault();
  e.stopPropagation();

  setIsOpen(false);        // ⭐ close dropdown
  buttonRef.current?.focus(); // ⭐ move focus back to button

  return;
}
  }}
  className={`flex gap-2 px-3 py-1 cursor-pointer ${dropdownHoverColor}`}
>
                  <input
                    type="checkbox"
                    checked={value.includes(option)}
                    onChange={() => toggleOption(option)}
                    onClick={(e) => e.stopPropagation()}
                  />
                  <span className="">{String(option)}</span>
                </li>
              ))
            ) : (
              <li className="px-3 py-6 text-center text-gray-500 italic">
                No results found
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Filter;
