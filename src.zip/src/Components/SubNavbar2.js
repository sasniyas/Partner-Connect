


import React, { useState, useRef, useEffect } from "react";
import { Home, LayoutDashboard, Users, Database } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const SubNavbar2 = () => {
  const location = useLocation();
  const menuRef = useRef(null);
  const [openDropdown, setOpenDropdown] = useState(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setOpenDropdown(null);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const managementDropdown = [
    {
      title: "User Management",
      path: "/usermangement",
      links: [],
    },
    {
      title: "Log",
      links: [
        { id: "auth-log", label: "Authentication Log", path: "/authentication" },
        { id: "user-history", label: "User History", path: "/usermangement/user-history" },
      ],
    },
  ];

  const mastersDropdown = [
    { title: "Scorecard", path: "/scorecard", links: [] },
    { title: "PDP", path: "/masterpdphomepage", links: [] },
    { title: "Monthly Meeting", path: "/mastermothlymeeting", links: [] },
    { title: "Dealer Investment", path: "/masterdealerinvestment", links: [] },
    { title: "Dashboards", path: "/masterdashboard", links: [] },
    { title: "DFHM", path: "/masterdfhm", links: [] },
  ];

  const pdpDropdown = [
    { title: "Create New PDP", path: "", links: [] },
    { title: "View PDP", path: "", links: [] },
    { title: "PDP Action Planner", path: "", links: [] },
    { title: "DealerInvestment", path: "", links: [] },
    { title: "Manage Branch Master", path: "", links: [] },
    { title: "Consolidated PDP", path: "", links: [] },
  ];

  const dealerDropdown = [
    { title: "View Dealer Investment", path: "", links: [] },
    { title: "Infrastructure reports", path: "", links: [] },
    { title: "Allocation Dashboard", path: "", links: [] },
    { title: "MBP Dashboard V1", path: "", links: [] },
  ];

  const scorecardDropdown = [
    { title: "Create Review", path: "", links: [] },
    { title: "View Reviews", path: "", links: [] },
    { title: "ScoreCard Results", path: "", links: [] },
    { title: "Action items", path: "", links: [] },
  ];

  const dfhmDropdown = [
    { title: "View DFHM", path: "", links: [] },
    { title: "ScoreCard Ratio", path: "", links: [] },
    { title: "View Quarterly Meeting", path: "", links: [] },
    { title: "Create Quarterly Meeting", path: "", links: [] },
  ];

  const menuItems = [
    {
      id: "home",
      label: "Home",
      icon: Home,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Sidebar/home active.png" alt="Home" className="w-5 h-5 object-contain" />,
      path: "/homepage",
    },
    {
      id: "outlook",
      label: "Outlook",
      icon: LayoutDashboard,
      activeIcon: LayoutDashboard,
      path: "/outlook",
    },
    {
      id: "management",
      label: "Management",
      icon: Users,
      activeIcon: Users,
      path: "/usermangement",
      submenu: managementDropdown,
    },
    {
      id: "masters",
      label: "Masters",
      icon: Database,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/masters-active.png" alt="Masters" className="w-5 h-5 object-contain" />,
      submenu: mastersDropdown,
    },
    {
      id: "monthly-meeting",
      label: "Monthly Meeting",
      icon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/monthlymeeting.png" alt="calendar" className="w-5 h-5 object-contain" />,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/calendar-active.png" alt="calendar" className="w-5 h-5 object-contain" />,
    },
    {
      id: "pdp",
      label: "PDP",
      icon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PDP.png" alt="pdp" className="w-5 h-5 object-contain" />,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/pdp-active.png" alt="pdp" className="w-5 h-5 object-contain" />,
      submenu: pdpDropdown,
    },
    {
      id: "dealer-investment",
      label: "Dealer Investment",
      icon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/dealerinvestmnet.png" alt="investment" className="w-5 h-5 object-contain" />,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/investment-active.png" alt="investment" className="w-5 h-5 object-contain" />,
      submenu: dealerDropdown,
    },
    {
      id: "scorecard",
      label: "Scorecard",
      icon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Scorecard.png" alt="scorecard" className="w-5 h-5 object-contain" />,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/scorecard-active.png" alt="scorecard" className="w-5 h-5 object-contain" />,
      path: "/menu/scorecard",
      submenu: scorecardDropdown,
    },
    {
      id: "dfhm",
      label: "DFHM",
      icon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/DFHM.png" alt="dfhm" className="w-5 h-5 object-contain" />,
      activeIcon: () => <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/dfhm-active.png" alt="dfhm" className="w-5 h-5 object-contain" />,
      path: "/menu/dfhm",
      submenu: dfhmDropdown,
    },
  ];

  const isMenuItemActive = (item) => {
    return (
      (item.path && location.pathname.startsWith(item.path)) ||
      (item.submenu &&
        item.submenu.some(
          (section) =>
            (section.path && location.pathname.startsWith(section.path)) ||
            section.links?.some((link) => location.pathname.startsWith(link.path))
        ))
    );
  };

  const handleMenuClick = (e, item) => {
    if (item.submenu && item.submenu.length > 0) {
      e.preventDefault();
      setOpenDropdown(openDropdown === item.id ? null : item.id);
    }
  };

  return (
    <div className="hidden lg:block bg-grey2 border-t border-gray-300 w-full z-40 fixed top-20 shadow" style={{ height: "82px" }}>
      <div className="max-w-screen-2xl mx-auto h-full px-4">
        <div className="flex justify-center gap-0 h-full" ref={menuRef}>
          {menuItems.map((item) => {
            const isActiveMain = isMenuItemActive(item);
            const hasSubmenu = item.submenu && item.submenu.length > 0;
            const Icon = isActiveMain ? item.activeIcon : item.icon;

            return (
              <div key={item.id} className="relative group flex items-center justify-center px-3">
                <Link
                  to={item.path || "#"}
                  className={`inline-flex items-center justify-center p-2 rounded-lg transition-all duration-200 ${isActiveMain ? "bg-white shadow" : ""}`}
                  onClick={(e) => handleMenuClick(e, item)}
                >
                  {typeof Icon === "function" ? (
                    <Icon className="w-5 h-5 text-black" />
                  ) : (
                    <Icon size={18} className="stroke-current" />
                  )}
                  <span className="absolute top-full mt-[-25px] left-1/2 -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-50">
                    {item.label}
                  </span>
                </Link>

                {hasSubmenu && openDropdown === item.id && (
                  <div className="absolute top-full mt-0 z-50 bg-white shadow-lg py-3 px-4 left-1/2 -translate-x-1/2">
                    <ul className="flex flex-row divide-x divide-gray-300">
                      {item.submenu.map((section, index) => {
                        const isHeadingActive =
                          (section.path && location.pathname.startsWith(section.path)) ||
                          section.links?.some((link) => location.pathname.startsWith(link.path));

                        return (
                          <li key={section.title} className="px-4 flex flex-col">
                            {section.path ? (
                              <Link
                                to={section.path}
                                className={`text-base font-medium hover:text-SteelBlue1 whitespace-nowrap ${
                                  isHeadingActive ? "text-SteelBlue1" : "text-black"
                                }`}
                              >
                                {section.title}
                              </Link>
                            ) : (
                              <span
                                className={`text-base font-medium hover:text-SteelBlue1 cursor-pointer whitespace-nowrap ${
                                  isHeadingActive ? "text-SteelBlue1" : "text-black"
                                }`}
                              >
                                {section.title}
                              </span>
                            )}

                            {section.links?.length > 0 && (
                              <ul className="mt-1">
                                {section.links.map((link) => (
                                  <li key={link.id}>
                                    <Link
                                      to={link.path}
                                      className={`block text-sm py-1 px-2 rounded hover:bg-grey2 ${
                                        location.pathname === link.path
                                          ? "font-semibold text-darkblue1"
                                          : "text-black"
                                      }`}
                                    >
                                      {link.label}
                                    </Link>
                                  </li>
                                ))}
                              </ul>
                            )}
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default SubNavbar2;
