// import React from "react";

// const DeactivateAccount= ({ isOpen, onClose, onConfirm }) => {
//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 px-4">
//       <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-sm">
//         {/* 🔴 Warning Message Box */}
//         <div className="bg-red-100 border border-red-300 text-red-700 rounded-md p-4 mb-6 text-sm">
//           Are you sure you want to <strong>deactivate</strong> this account? This action cannot be undone and the user will lose access to their account immediately.
//         </div>

//         {/* ✅ Buttons */}
//         <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
//           <button
//             onClick={onClose}
//             className="w-full sm:w-auto bg-red-100 text-red-700 font-bold px-6 py-2 rounded hover:bg-red-200 transition duration-200"
//           >
//             No
//           </button>
//           <button
//             onClick={onConfirm}
//             className="w-full sm:w-auto bg-green-100 text-green-700 font-bold px-6 py-2 rounded hover:bg-green-200 transition duration-200"
//           >
//             Yes
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default DeactivateAccount;



import React from "react";

const DeactivateAccount= ({ isOpen, onClose, onConfirm }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 px-4">
      <div className="bg-white rounded-lg shadow-lg p-4 sm:p-6 w-full max-w-sm border-l-8 border-green">
        <h3 className="flex items-center justify-center text-sm font-semibold text-center rounded-md p-3 text-red1 bg-red2 mb-4 gap-2">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/warning.png" alt="warning" className="w-4 h-4" />
          <span className="leading-snug">
          Are you sure you want to <strong>deactivate</strong> this account? This action cannot be undone and the user will lose access to their account immediately.
          </span>
        </h3>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onClose}
            className="w-full sm:w-auto border-2 border-red2 text-red px-5 py-2 text-sm font-bold rounded-md hover:bg-red2 hover:shadow-md hover:scale-105 transition duration-200"
          >
            No
          </button>
          <button
            onClick={onConfirm}
            className="w-full sm:w-auto bg-green4 text-green5 text-sm border-2 border-transparent font-bold font-VolvoNovum px-6 py-2 rounded-md hover:bg-white hover:border-green4 hover:shadow-md hover:scale-105 transition duration-200"
          >
            Yes
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeactivateAccount;
