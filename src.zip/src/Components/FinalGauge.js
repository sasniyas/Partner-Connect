// import React from "react";
// import Highcharts from "highcharts";
// import HighchartsReact from "highcharts-react-official";
// import HighchartsMore from "highcharts/highcharts-more";
// import SolidGauge from "highcharts/modules/solid-gauge";

// // Initialize modules
// HighchartsMore(Highcharts);
// SolidGauge(Highcharts);

// const FinalGauge = ({ score = 7.5 }) => {
//   const options = {
//     chart: {
//       type: "solidgauge",
//       height: 300,
//     },

//     title: {
//       text: "Final Performance Health Index",
//       style: { fontSize: "20px", fontWeight: "bold" },
//     },

//     pane: {
//       startAngle: -90,
//       endAngle: 90,
//       background: [
//         {
//           outerRadius: "100%",
//           innerRadius: "60%",
//           shape: "arc",
//           backgroundColor: "#eee",
//         },
//       ],
//     },

//     tooltip: { enabled: false },

//     yAxis: {
//       min: 0,
//       max: 10,
//       tickPositions: [],
//       lineWidth: 0,
//       stops: [
//         [0.0, "#d9534f"], // Red
//         [0.4, "#f0ad4e"], // Yellow
//         [0.7, "#5cb85c"], // Green
//       ],
//     },

//     plotOptions: {
//       solidgauge: {
//         dataLabels: {
//           enabled: false,
//         },
//       },
//     },

//     series: [
//       {
//         data: [score],
//       },
//     ],

//     credits: { enabled: false },
//   };

//   return (
//     <div className="w-full flex flex-col items-center">
//       <div style={{ width: 400 }}>
//         <HighchartsReact highcharts={Highcharts} options={options} />
//       </div>

//       {/* Score Display */}
//       <div className="text-3xl font-bold mt-[-40px]">{score}</div>
//     </div>
//   );
// };

// export default FinalGauge;
