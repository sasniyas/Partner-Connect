import React from "react";

const Signoffpopup = ({ isOpen, onClose, onConfirm, loading }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
      <div className="bg-white shadow-lg p-6 w-full max-w-sm sm:max-w-md md:max-w-lg border-l-8 border-green">
        <h3 className="flex items-center justify-center text-xs  font-semibold  p-2  text-red1 bg-red2 mb-2 gap-2 text-center">
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/warning.png"
            alt="warning"
            className="w-4 h-4"
          />
          Are you sure you want to Sign Off?
        </h3>
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <button
            onClick={onClose}
            disabled={loading}
            className={`border-2 border-red2 text-red px-4 sm:px-5 py-1.5 text-xs font-bold  transition duration-200
              ${loading ? "opacity-50 cursor-not-allowed" : "hover:bg-red2 hover:shadow-md hover:scale-105"}
            `}
          >
            No
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            className={`bg-green4 text-green5 text-xs border-2 border-transparent font-bold font-VolvoNovum px-5 sm:px-6 py-1.5  transition duration-200
              ${loading ? "opacity-50 cursor-not-allowed" : "hover:bg-green4 hover:text-green5 hover:shadow-md hover:scale-105 hover:bg-white hover:border-green4"}
            `}
          >
            {loading ? "Signing off..." : "Yes"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Signoffpopup;
