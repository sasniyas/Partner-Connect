// import React from "react";
// import { Search } from "lucide-react";

// function Searchinput({
//   value,
//   onChange,
//   placeholder = "Search...",
//   className = "",
//   icon = <Search />,
//   bgColor = "bg-white",
//   borderColor = "border-ab",
//   textColor = "text-black",
//   shadow = "shadow-[0_4px_10px_#4E78A14D]",
//   inputPadding = "pl-8 pr-3 py-2",
//   iconSize = "w-4 h-4",
//   iconLeft = "left-3",
//   inputWidth = "w-full",
//   focusRing = "focus:ring-ab",
//   hoverInputClasses = "hover:bg-white hover:border-darkblue1 hover:text-gray-800",
//   iconColor = "text-gray-500", // 👈 initial color
//   iconHoverColor = "group-hover:text-green-600", // 👈 hover color
// }) {
//   const isReactElement = React.isValidElement(icon);

//   const iconClass = `${iconSize} ${iconColor} ${iconHoverColor}`;

//   return (
//     <div className={`relative group ${className} ${bgColor} rounded-lg ${shadow}`}>
//       <div
//         className={`absolute ${iconLeft} top-1/2 transform -translate-y-1/2 ${iconSize} flex items-center justify-center`}
//       >
//         {isReactElement &&
//           React.cloneElement(icon, {
//             className: iconClass, // apply Tailwind colors directly
//             strokeWidth: 2, // optional: for better visibility
//           })}
//       </div>
//       <input
//         type="text"
//         value={value}
//         onChange={onChange}
//         placeholder={placeholder}
//         className={`${inputWidth} ${textColor} text-sm font-normal font-VolvoNovum ${inputPadding} border ${borderColor} rounded-md focus:outline-none ${focusRing} ${hoverInputClasses} h-10`}
//       />
//     </div>
//   );
// }

// export default Searchinput;


import React from "react";
import { Search } from "lucide-react";

function Searchinput({
  value,
  onChange,
  placeholder = "Search...",
  className = "",
  icon = <Search />,
  bgColor = "bg-white",
  borderColor = "",
  textColor = "text-black",
  shadow = "shadow-[0_2px_6px_#4E78A12A]", // lighter shadow
  inputPadding = "pl-7 pr-2 py-1", // reduced padding
  iconSize = "w-1 h-1", // smaller icon
  iconLeft = "left-2.5",
  inputWidth = "w-full",
  focusRing = "focus:ring-ab",
  hoverInputClasses = "hover:bg-white  hover:text-gray-800",
  iconColor = "text-gray-500",
  iconHoverColor = "group-hover:text-green-600",
}) {
  const isReactElement = React.isValidElement(icon);

  const iconClass = `${iconSize} ${iconColor} ${iconHoverColor}`;

  return (
    <div className={`relative group ${className} ${bgColor}  ${shadow}`}>
      <div
        className={`absolute ${iconLeft} top-1/2 transform -translate-y-1/2 ${iconSize} flex items-center justify-center`}
      >
        {isReactElement &&
          React.cloneElement(icon, {
            className: iconClass,
            strokeWidth: 2,
          })}
      </div>
      <input
        type="text"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className={`${inputWidth} ${textColor} text-xs  font-normal font-VolvoNovum ${inputPadding} border ${borderColor}  focus:outline-none ${focusRing} ${hoverInputClasses} h-8`}
      />
    </div>
  );
}

export default Searchinput;
