
"use client";

import { useEffect, useState } from "react";

const StyledSelectField = ({
  label,
  value,
  setValue,
  options = [],
  dropdownOpen,
  setDropdownOpen,
  dropdownRef,
  placeholder = "Select",
  required = false,
  error,
  disabled = false,
}) => {

  const [dropdownSearch, setDropdownSearch] = useState("");

  const allOptions = options.filter(Boolean);
  const showError = error && !value;

  /* ---------- Outside click ---------- */
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () =>
      document.removeEventListener("mousedown", handleClickOutside);
  }, [dropdownRef, setDropdownOpen]);

  /* ---------- Filter options ---------- */
  const filteredOptions = allOptions
    .filter((opt) => {
      const optionValue = typeof opt === "object" ? opt.label : opt;
      return !dropdownSearch
        ? true
        : optionValue.toLowerCase().includes(dropdownSearch.toLowerCase());
    })
    .sort((a, b) => {
      const aValue = typeof a === "object" ? a.label : a;
      const bValue = typeof b === "object" ? b.label : b;
      return aValue.localeCompare(bValue);
    });

  const handleSelect = (val) => {
    setValue(val);
    setDropdownOpen(false);
    setDropdownSearch("");
  };

  return (
    <div className="w-full" ref={dropdownRef}>

      {/* Label */}
      <label className="block text-xs font-medium text-black/70 mb-2">
        {label} {required && <span className="text-red1">*</span>}
      </label>

      <div className="relative">

        {/* Trigger */}
        <div
          className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none text-black placeholder:text-grey focus:ring-1 flex justify-between items-center 
          ${disabled ? "bg-gray-100 cursor-not-allowed border border-black/20" : ""}
          ${!disabled && dropdownOpen
            ? "border-l border-r border-t border-black/30 bg-white border-b-0"
            : !disabled
              ? "border border-black/30 bg-white hover:ring-1 hover:ring-black/30"
              : ""}
          ${showError ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}

          tabIndex={disabled ? -1 : 0}

          onClick={() => {
            if (!disabled) setDropdownOpen(!dropdownOpen);
          }}

          onKeyDown={(e) => {

            if (disabled) return;

            if (e.key === "Enter") {
              e.preventDefault();
              e.stopPropagation();
              setDropdownOpen(true);
            }

          if (e.key === "Escape") {
  e.preventDefault();
  e.stopPropagation();
  e.nativeEvent.stopImmediatePropagation(); // ✅ IMPORTANT
  setDropdownOpen(false);
}

          }}
        >

          <span className={`${value ? "text-black" : "text-gray-400"}`}>
            {value || `- ${placeholder} -`}
          </span>

          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"
          className={`w-3 h-3 transform transition-transform duration-200 ${
              dropdownOpen ? "rotate-180" : "rotate-0"
            }`}>
            <path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
          </svg>

        </div>

        {/* Dropdown */}
        {dropdownOpen && !disabled && (
          <div className="absolute z-[999] w-full bg-white border border-black/30 border-t-0 shadow-lg max-h-48 overflow-y-auto">

            {/* Search */}
            {allOptions.length > 5 && (
              <div className="sticky top-0 bg-white px-3 py-1.5 z-10">
                <input
                  type="text"
                  placeholder="Search..."
                  value={dropdownSearch}
                  onChange={(e) => setDropdownSearch(e.target.value)}
                  onKeyDown={(e) => {

                    if (e.key === "ArrowDown") {
                      e.preventDefault();
                      e.stopPropagation()

                      const first = document.querySelector("[data-option]");
                      first?.focus();
                    }
if (e.key === "Escape") {
  e.stopPropagation();
  e.nativeEvent.stopImmediatePropagation(); // ✅
  setDropdownOpen(false);
}

                  }}
                  className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
                  autoFocus
                />
              </div>
            )}

            {/* Options */}
            {filteredOptions.map((opt, idx) => {

              const optionValue =
                typeof opt === "object" ? opt.label : opt;

              return (
                <div
                  key={idx}
                  tabIndex={0}
                  data-option
                  className="px-3 py-2 text-xs cursor-pointer hover:bg-gray-100 transition"

                  onKeyDown={(e) => {

                    const items = Array.from(
                      e.currentTarget.parentElement.querySelectorAll("[data-option]")
                    );

                    const index = items.indexOf(e.currentTarget);

                    if (e.key === "ArrowDown") {
                      e.preventDefault();
                      e.stopPropagation()
                      items[(index + 1) % items.length]?.focus();
                    }

                    if (e.key === "ArrowUp") {
                      e.preventDefault();
                      e.stopPropagation()
                      items[(index - 1 + items.length) % items.length]?.focus();
                    }

                    if (e.key === "Escape") {
  e.preventDefault();
  e.stopPropagation();
  e.nativeEvent.stopImmediatePropagation(); // ✅
  setDropdownOpen(false);
}

                    if (e.key === "Enter") {
                      e.preventDefault();
                      e.stopPropagation();
                      handleSelect(optionValue);
                    }

                  }}

                  onMouseDown={(e) => {
                    e.preventDefault();
                    handleSelect(optionValue);
                  }}
                >
                  {optionValue}
                </div>
              );
            })}

            {filteredOptions.length === 0 && (
              <div className="px-3 py-2 text-xs text-gray-400 italic text-center">
                No options available
              </div>
            )}

          </div>
        )}

      </div>

      {showError && !dropdownOpen && (
        <p className="text-xs text-red1 mt-1">{error}</p>
      )}

    </div>
  );
};

export default StyledSelectField;