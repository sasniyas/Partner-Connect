// import { useState } from "react";
// import Header from "./Header";
// import Iconsidebar from "./Iconsidebar";

// const Headsidebar = () => {
//     const [menuCloseTrigger, setMenuCloseTrigger] = useState(false);

//     const handleMenuClick = () => {
//         setMenuCloseTrigger(prev => !prev); // Toggle trigger
//     };

//     return (
//         <div>
//             <Header onMenuClick={handleMenuClick} />
//             <Iconsidebar menuCloseTrigger={menuCloseTrigger} />
//         </div>
//     );
// };

// export default Headsidebar;

import { useState } from "react";
import Header from "./Header";
import Menubar from "./SubNavbar";
// import Iconsidebar from "./Iconsidebar";

const Headsidebar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div>
      {/* Pass menuOpen and setMenuOpen props to Header */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      
      {/* Pass menuOpen (or menuCloseTrigger) to Iconsidebar to control visibility */}
      {/* <Iconsidebar isExpanded={menuOpen} /> */}
       <Menubar />
    </div>
  );
};

export default Headsidebar;
