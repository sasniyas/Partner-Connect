import * as XLSX from "xlsx";
const BulkUploadTemplate = ({
  headers,
  sampleData = [],
  fileName = "Template.xlsx",
  sheetName = "Sheet1",
  icon,
  label,
}) => {
  const handleDownload = () => {
    const worksheet = XLSX.utils.aoa_to_sheet([headers]);

    XLSX.utils.sheet_add_json(worksheet, sampleData, {
      origin: "A2",
      skipHeader: true,
    });

    worksheet["!cols"] = headers.map(() => ({ wch: 25 }));

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
    XLSX.writeFile(workbook, fileName);
  };

  return (
    <button
      onClick={handleDownload}
      className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-2 hover:rounded-b-lg whitespace-nowrap"
    >
      {icon && <img src={icon} alt="Download" className="w-4 h-4" />}
      {label || "Download Template"}
    </button>
  );
};
export default BulkUploadTemplate