import React from "react";

const ActivateStatus = ({ isOpen, onClose, onConfirm, loading }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
      <div className="bg-white shadow-lg p-6 w-full max-w-sm sm:max-w-md md:max-w-lg border-l-8 border-green">
        <h3 className="flex items-center justify-center text-xs font-semibold  p-2 text-red1 bg-red2 mb-4 gap-2 text-center">
         <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<path fill-rule="evenodd" clip-rule="evenodd" d="M10.4573 5.06941C13.1627 3.46808 14.5147 2.66675 16 2.66675C17.4853 2.66675 18.8373 3.46675 21.5427 5.06941L22.4573 5.61075C25.1627 7.21341 26.5147 8.01475 27.2573 9.33341C28 10.6534 28 12.2534 28 15.4587V16.5414C28 19.7454 28 21.3481 27.2573 22.6667C26.5147 23.9854 25.1627 24.7867 22.4573 26.3881L21.5427 26.9307C18.8373 28.5321 17.4853 29.3334 16 29.3334C14.5147 29.3334 13.1627 28.5334 10.4573 26.9307L9.54267 26.3881C6.83733 24.7881 5.48533 23.9854 4.74267 22.6667C4 21.3467 4 19.7467 4 16.5414V15.4587C4 12.2534 4 10.6521 4.74267 9.33341C5.48533 8.01475 6.83733 7.21341 9.54267 5.61075L10.4573 5.06941ZM17.3333 21.3334C17.3333 21.687 17.1929 22.0262 16.9428 22.2762C16.6928 22.5263 16.3536 22.6667 16 22.6667C15.6464 22.6667 15.3072 22.5263 15.0572 22.2762C14.8071 22.0262 14.6667 21.687 14.6667 21.3334C14.6667 20.9798 14.8071 20.6407 15.0572 20.3906C15.3072 20.1406 15.6464 20.0001 16 20.0001C16.3536 20.0001 16.6928 20.1406 16.9428 20.3906C17.1929 20.6407 17.3333 20.9798 17.3333 21.3334ZM16 8.33341C16.2652 8.33341 16.5196 8.43877 16.7071 8.62631C16.8946 8.81384 17 9.0682 17 9.33341V17.3334C17 17.5986 16.8946 17.853 16.7071 18.0405C16.5196 18.2281 16.2652 18.3334 16 18.3334C15.7348 18.3334 15.4804 18.2281 15.2929 18.0405C15.1054 17.853 15 17.5986 15 17.3334V9.33341C15 9.0682 15.1054 8.81384 15.2929 8.62631C15.4804 8.43877 15.7348 8.33341 16 8.33341Z" fill="#BF2012"/>
</svg>
          Are you sure you want to activate this record?
        </h3>
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <button
            onClick={onClose}
            disabled={loading}
            className={`border-2 border-red2 text-red px-4 sm:px-5 py-1.5 text-xs font-bold  transition 
              ${loading ? "opacity-50 cursor-not-allowed" : "hover:bg-red2 hover:shadow-md hover:scale-105"}`}
          >
            No
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            className={`bg-green4 text-green5 text-xs border-2 border-transparent font-bold font-VolvoNovum px-5 sm:px-6 py-1.5 transition
              ${loading ? "opacity-50 cursor-not-allowed" : "hover:bg-green4 hover:text-green5 hover:shadow-md hover:scale-105 hover:bg-white hover:border-green4"}`}
          >
            {loading ? "Activating..." : "Yes"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActivateStatus;
