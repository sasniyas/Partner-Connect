import { useState, useEffect, useRef } from "react"
import { ChevronRight, LogOut } from "lucide-react"
import { useLocation, useNavigate } from "react-router-dom"
import { Users} from "lucide-react"

const FullSidebar = ({ menuOpen, setMenuOpen }) => {
  const location = useLocation()
  const navigate = useNavigate()
  const sidebarRef = useRef(null)

  const [showManagementSubmenu, setShowManagementSubmenu] = useState(false)
  const [showMastersSubmenu, setShowMastersSubmenu] = useState(false)
  const [showPDPSubmenu, setShowPDPSubmenu] = useState(false)
  const [showDealerSubmenu, setShowDealerSubmenu] = useState(false)
  const [showLogsSubmenu,setShowLogsSubmenu] =useState(false)
  // Close submenus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (sidebarRef.current && !sidebarRef.current.contains(event.target)) {
        setShowManagementSubmenu(false)
        setShowMastersSubmenu(false)
        setShowPDPSubmenu(false)
        setShowDealerSubmenu(false)
      }
    }

    if (menuOpen) {
      document.addEventListener("mousedown", handleClickOutside)
      document.addEventListener("touchstart", handleClickOutside) // Add touch support
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
      document.removeEventListener("touchstart", handleClickOutside)
    }
  }, [menuOpen])

  // Close all submenus when main sidebar closes
  useEffect(() => {
    if (!menuOpen) {
      setShowManagementSubmenu(false)
      setShowMastersSubmenu(false)
      setShowPDPSubmenu(false)
      setShowDealerSubmenu(false)
    }
  }, [menuOpen])

  // Function to close all other submenus except the one being opened
  const closeOtherSubmenus = (keepOpen) => {
    if (keepOpen !== "management") setShowManagementSubmenu(false)
    if (keepOpen !== "masters") setShowMastersSubmenu(false)
    if (keepOpen !== "pdp") setShowPDPSubmenu(false)
    if (keepOpen !== "dealer") setShowDealerSubmenu(false)
  }

  // Enhanced submenu toggle functions
  const toggleManagementSubmenu = () => {
    const newState = !showManagementSubmenu
    closeOtherSubmenus(newState ? "management" : null)
    setShowManagementSubmenu(newState)
  }

  const toggleMastersSubmenu = () => {
    const newState = !showMastersSubmenu
    closeOtherSubmenus(newState ? "masters" : null)
    setShowMastersSubmenu(newState)
  }

  const togglePDPSubmenu = () => {
    const newState = !showPDPSubmenu
    closeOtherSubmenus(newState ? "pdp" : null)
    setShowPDPSubmenu(newState)
  }

  const toggleDealerSubmenu = () => {
    const newState = !showDealerSubmenu
    closeOtherSubmenus(newState ? "dealer" : null)
    setShowDealerSubmenu(newState)
  }

  // Navigation handlers that also close submenus
  const handlehome = () => {
    closeOtherSubmenus(null)
    navigate("/homepage")
  }
  const handleoutlook = () =>{
    navigate ("/outlook")
  }

  const handlemonthlymeetinghomepage = () => {
    closeOtherSubmenus(null)
    navigate("/viewmonthlymeeting")
  }

  const handleusermanagement = () => navigate("/usermangement")
  const handleaauthentication = () => navigate("/authentication")
  const handleUserHistory = () => navigate("/userhistory");

  const handlescorecard = () => navigate("/masters/scorecard" )
  const handlePDP = () => navigate("/masterpdphomepage")
  const handlemonthlymeeting = () => navigate("/mastermothlymeeting")
  const handledealerinvestment = () => navigate("/masterdealerinvestment")
  const handledashboard = () => navigate("/masterdashboard")
  const handleDFHM = () => navigate("/masterdfhm")
  const handlecreatepdp = () => navigate("/pdphomepage")
  const handleActionplannerlist = () => navigate("/pdpactionplannerlist")
  const handleviewpdp = () => navigate("/viewpdp")
  const handleMangerBranch = () => navigate("/branchmanager")
  const handleconsolidatedpdp = () => navigate("/consolidatedpdp")
  const handleviewdealerinvestment = () => navigate("/viewdealerinvestmenthome")

  // Logout handler
  const handleLogout = () => {
    console.log("Logging out...")
  }

  // Route checking logic
  const isHome = location.pathname === "/homepage"
   const isOutlook = location.pathname === "/outlook"
  const isManagement =
    location.pathname === "/usermangement" ||
    location.pathname === "/userdetails" ||
    location.pathname === "/showhistory" ||
    location.pathname === "/authentication" ||
    location.pathname === "/userlogin"||
    location.pathname === "/userhistory"
  const isUserManagementPath =
    location.pathname === "/usermangement" ||
    location.pathname === "/userdetails" ||
    location.pathname === "/showhistory" ||
    location.pathname === "/userlogin"
    
  const isAuthenticationPath = location.pathname === "/authentication"
  const isUserHistoryPath = location.pathname === "/userhistory";
const isLogsActive = isAuthenticationPath || isUserHistoryPath;

  const isMasters =
    location.pathname === "/masters/scorecard"  ||
    location.pathname === "/masterpdphomepage" ||
    location.pathname === "/mastermothlymeeting" ||
    location.pathname === "/masterdealerinvestment" ||
    location.pathname === "/masterdashboard" ||
    location.pathname === "/masterdfhm"
     const isScorecardPath = location.pathname === "/masters/scorecard";
  const isPDPPath = location.pathname === "/masterpdphomepage";
  const isMonthlyMeetingPath = location.pathname === "/mastermothlymeeting";
  const isDealerInvestmentPath = location.pathname === "/masterdealerinvestment" ;
  const isDashboardPath= location.pathname ==="/masterdashboard";
   const isDFHMPath= location.pathname === "/masterdfhm";


  const isMonthlymeeting =
    location.pathname === "/monthlymeetinghomepage" ||
    location.pathname === "/trendchart" ||
    location.pathname ==="/viewmonthlymeeting"||
    location.pathname === "/actionitemview" ||
    location.pathname === "/monthlymeetingviewdetails"
  const isPDP =
    location.pathname === "/pdphomepage" ||
    location.pathname === "/viewpdp" ||
    location.pathname === "/viewdetailshomepage" ||
    location.pathname === "/actionplannermanagement" ||
    location.pathname === "/downloadpdpdetails" ||
    location.pathname === "/pdpactionplannerlist" ||
    location.pathname === "/pdptrendchart" ||
    location.pathname === "/pdpactionitem" ||
    location.pathname === "/branchmanager" ||
    location.pathname === "/consolidatedpdp" ||
    location.pathname === "/viewconsolidatedpdp"
  const isCreatePDPPath =
    location.pathname === "/pdphomepage" ||
    location.pathname === "/viewpdp" ||
    location.pathname === "/viewdetailshomepage" ||
    location.pathname === "/actionplannermanagement" ||
    location.pathname === "/downloadpdpdetails"
  const isPDPActionlist =
    location.pathname === "/pdpactionplannerlist" ||
    location.pathname === "/pdptrendchart" ||
    location.pathname === "/pdpactionitem"
  const isPDPMangerlist = location.pathname === "/branchmanager"
  const isConsolidatedPDP = location.pathname === "/consolidatedpdp" || location.pathname === "/viewconsolidatedpdp"
  const isDealerinvestment = location.pathname === "/viewdealerinvestmenthome"
  const isviewdealerinvestmnetpath = location.pathname === "/viewdealerinvestmenthome"
  const isScorecard = location.pathname === ""
  const isDFHM = location.pathname === ""

  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black bg-opacity-40 transition-opacity duration-300 z-30 ${
          menuOpen ? "opacity-100 visible" : "opacity-0 invisible"
        }`}
        onClick={() => setMenuOpen(false)}
      />

      {/* Full Sidebar with Responsive Width */}
      <aside
        ref={sidebarRef}
        className={`fixed top-16 sm:top-17 md:top-18 lg:top-20 left-0 
          h-[calc(100vh-4rem)] sm:h-[calc(100vh-4.25rem)] md:h-[calc(100vh-4.5rem)] lg:h-[calc(100vh-5rem)]
          w-full sm:w-full md:w-1/2 lg:w-[19.95%] xl:w-[20%]
          bg-white shadow-xl transform transition-transform duration-300 z-40 
          overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100
          ${menuOpen ? "translate-x-0" : "-translate-x-full"}`}
      >
        <nav className="p-2 sm:p-3 md:p-4 h-full flex flex-col">
          {/* Main Navigation */}
          <ul className="mt-1 space-y-1 flex-1">
            {/* Home */}
           <li
  className={`flex items-center space-x-2 sm:space-x-3 p-2 sm:p-3 rounded-lg transition duration-300 cursor-pointer ${
    isHome ? "bg-lightGrey text-black" : "hover:bg-lightBlue"
  }`}
  onClick={handlehome}
>
  {/* Left active rectangle indicator */}
  {isHome && (
    <img
      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Rectangle 16.png"
      alt="rectangle"
      className="h-6 w-2 sm:h-7 sm:w-2"
    />
  )}

  {/* Home icon */}
  <img
    src={
      isHome
        ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Sidebar/home active.png"
        : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Sidebar/home default.png"
    }
    alt="Home"
    className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 lg:h-5 lg:w-5 transition duration-300 flex-shrink-0"
  />

  {/* Label */}
  <span className="text-xs sm:text-sm md:text-base font-normal truncate">Home</span>
</li>

            {/* Outlokk */}
           <li
  className={`flex items-center space-x-2 sm:space-x-3 p-2 sm:p-3 rounded-lg transition duration-300 cursor-pointer ${
    isOutlook ? "bg-lightGrey text-black" : "hover:bg-lightBlue"
  }`}
  onClick={handleoutlook}
>
  {/* Left active rectangle indicator */}
  {isOutlook && (
    <img
      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Rectangle 16.png"
      alt="rectangle"
      className="h-6 w-2 sm:h-7 sm:w-2"
    />
  )}

  {/* Outlook icon */}
  <img
    src={
      isOutlook
        ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Sidebar/outlookactive.png"
        : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Sidebar/outlookdefault.png"
    }
    alt="Outlook"
    className="h-3 w-3 sm:h-4 sm:w-4 md:h-4 md:w-4 lg:h-4 lg:w-4 transition duration-300 flex-shrink-0"
  />

  {/* Label */}
  <span className="text-xs sm:text-sm md:text-base font-normal truncate">Outlook</span>
</li>

            {/* Management */}
           
  {/* Main Management Item */}
  <li>
  <div
    className={`flex items-center justify-between p-2 sm:p-3 rounded-lg cursor-pointer transition duration-300
      ${isManagement ? "bg-lightGrey text-black" : "hover:bg-lightBlue"}`}
    onClick={toggleManagementSubmenu}
  >
    <div className="flex items-center space-x-2 sm:space-x-3">
      {isManagement && (
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Rectangle 16.png"
          alt="indicator"
          className="h-6 w-2 sm:h-7 sm:w-2"
        />
      )}

      {isManagement ? (
    <Users fill="black" stroke="black" className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 flex-shrink-0 transition duration-300" />
  ) : (
    <Users className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 flex-shrink-0 transition duration-300" />
  )}

      <span className="text-xs sm:text-sm md:text-base font-normal truncate">Management</span>
    </div>

    <ChevronRight
      className={`h-4 w-4 sm:h-5 sm:w-5 transition-transform duration-300 flex-shrink-0 ${
        showManagementSubmenu ? "rotate-90" : ""
      }`}
    />
  </div>

  {showManagementSubmenu && (
    <ul className="ml-4 lg:ml-2 xl:ml-4 space-y-1">
      <li
        className={`flex items-center space-x-2 sm:space-x-3 text-xs sm:text-sm cursor-pointer py-1 ${
          isUserManagementPath ? "text-black font-medium" : "text-mildbrown hover:text-grey"
        }`}
        onClick={handleusermanagement}
      >
        <span
          className={`font-bold leading-none ${
            isUserManagementPath ? "text-blue2 text-lg sm:text-xl" : "text-3xl sm:text-4xl"
          }`}
        >
          {isUserManagementPath ? "●" : "◦"}
        </span>
        <span className="truncate">User Management</span>
      </li>

      <li>
        <div
  className={`flex items-center justify-between space-x-2 sm:space-x-3 cursor-pointer py-1 ${
    isLogsActive ? "text-black font-medium" : "text-mildbrown hover:text-grey"
  }`}
  onClick={() => setShowLogsSubmenu(!showLogsSubmenu)}
>
  <div className="flex items-center space-x-2 sm:space-x-3">
    <span
      className={`font-bold leading-none ${
        isLogsActive ? "text-blue2 text-lg sm:text-xl" : "text-xl sm:text-4xl"
      }`}
    >
      {isLogsActive ? "●" : "◦"}
    </span>
    <span className="truncate text-xs sm:text-sm">Logs</span>
  </div>
  <ChevronRight
    className={`h-3 w-3 sm:h-4 sm:w-4 transition-transform duration-300 ${
      showLogsSubmenu ? "rotate-90" : ""
    }`}
  />
</div>


        {showLogsSubmenu && (
          <ul className="ml-4 space-y-1">
            <li
              className={`flex items-center space-x-2 sm:space-x-3 text-xs sm:text-sm cursor-pointer py-1 ${
                isAuthenticationPath ? "text-black font-medium" : "text-mildbrown hover:text-gray-500"
              }`}
              onClick={handleaauthentication}
            >
              <span
                className={`font-bold leading-none ${
                  isAuthenticationPath ? "text-blue2 text-lg sm:text-xl" : "text-3xl sm:text-4xl"
                }`}
              >
                {isAuthenticationPath ? "●" : "◦"}
              </span>
              <span className="truncate">Authentication Log</span>
            </li>

            <li
              className={`flex items-center space-x-2 sm:space-x-3 text-xs sm:text-sm cursor-pointer py-1 ${
                isUserHistoryPath ? "text-black font-medium" : "text-mildbrown hover:text-gray-500"
              }`}
              onClick={handleUserHistory}
            >
              <span
                className={`font-bold leading-none ${
                  isUserHistoryPath ? "text-blue2 text-lg sm:text-xl" : "text-3xl sm:text-4xl"
                }`}
              >
                {isUserHistoryPath ? "●" : "◦"}
              </span>
              <span className="truncate">User History</span>
            </li>
          </ul>
        )}
      </li>
    </ul>
  )}
</li>

            {/* Masters */}
          <li>
  <div
    className={`flex items-center space-x-2 sm:space-x-3 p-2 sm:p-3 rounded-lg transition duration-300 cursor-pointer 
      ${isMasters ? "bg-lightGrey text-black" : "hover:bg-lightBlue"}`}
    onClick={toggleMastersSubmenu}
  >
    {/* Left rectangle when active */}
    {isMasters && (
      <img
        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Rectangle 16.png"
        alt="rectangle"
        className="h-6 w-2 sm:h-7 sm:w-2"
      />
    )}

    {/* Dynamic icon component */}
    <span className="flex-shrink-0">
      {isMasters ? (
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/HomePage/fluent_coin-stack-24-filled.png"
          alt="Masters Active"
          className="w-5 h-5 object-contain"
        />
      ) : (
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Vector (4).png"
          alt="Masters"
          className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 lg:h-5 lg:w-5 transition duration-300 flex-shrink-0"
        />
      )}
    </span>

    {/* Text and Chevron */}
    <div className="flex justify-between w-full items-center min-w-0">
      <span className="text-xs sm:text-sm md:text-base font-normal truncate">Masters</span>
      <ChevronRight
        className={`h-4 w-4 sm:h-5 sm:w-5 transition-transform duration-300 flex-shrink-0 ${
          showMastersSubmenu ? "rotate-90" : ""
        }`}
      />
    </div>
  </div>


              {/* Masters Submenu */}
             {/* Masters Submenu */}
{showMastersSubmenu && (
  <ul className="ml-4 lg:ml-2 xl:ml-4 space-y-0">
    {[
      { label: "Scorecard", handler: handlescorecard, isActive: isScorecardPath },
      { label: "PDP", handler: handlePDP, isActive: isPDPPath },
      { label: "Monthly Meeting", handler: handlemonthlymeeting, isActive: isMonthlyMeetingPath },
      { label: "Dealer Investment", handler: handledealerinvestment, isActive: isDealerInvestmentPath },
      { label: "Dashboard", handler: handledashboard, isActive: isDashboardPath },
      { label: "DFHM", handler: handleDFHM, isActive: isDFHMPath },
    ].map((item, index) => (
      <li
        key={index}
        className={`flex items-center space-x-2 sm:space-x-3 text-xs sm:text-sm cursor-pointer py-0.5 ${
          item.isActive ? "text-black font-medium" : "text-mildbrown hover:text-grey"
        }`}
        onClick={item.handler}
      >
        <span className={`font-bold leading-none ${item.isActive ? "text-blue2 text-lg sm:text-xl" : "text-3xl sm:text-4xl"}`}>
          {item.isActive ? "●" : "◦"}
        </span>
        <span className="truncate leading-tight">{item.label}</span>
      </li>
    ))}
  </ul>
)}

            </li>

            {/* Monthly Meeting */}
           <li
  className={`flex items-center space-x-2 sm:space-x-3 p-2 sm:p-3 rounded-lg transition duration-300 cursor-pointer 
    ${isMonthlymeeting ? "bg-lightGrey text-black" : "hover:bg-lightBlue"}`}
  onClick={handlemonthlymeetinghomepage}
>
  {/* Left rectangle when active */}
  {isMonthlymeeting && (
    <img
      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Rectangle 16.png"
      alt="rectangle"
      className="h-6 w-2 sm:h-7 sm:w-2"
    />
  )}

  {/* Dynamic icon */}
  <span className="flex-shrink-0">
    {isMonthlymeeting ? (
      <img
        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/monthlymeeting.png"
        alt="Monthly Meeting Active"
        className="w-4 h-4 object-contain"
      />
    ) : (
      <img
        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/monthlymeeting.png"
        alt="Monthly Meeting"
        className="w-5 h-5 object-contain"
      />
    )}
  </span>

  {/* Text */}
  <span className="text-xs sm:text-sm md:text-base font-normal truncate">Monthly Meeting</span>
</li>

            {/* PDP */}
            <li>
              <div
                className={`flex items-center space-x-2 sm:space-x-3 p-2 sm:p-3 rounded-lg transition duration-300 cursor-pointer 
                  ${isPDP ? "bg-lightGrey text-black" : "hover:bg-lightBlue"}`}
                onClick={togglePDPSubmenu}
              >
                {isPDP && <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Rectangle 16.png" alt="rectangle" className="h-6 w-2 sm:h-7 sm:w-2" />}

                <img
       src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PDP.png" 
                  alt="pdp"
                  className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 lg:h-5 lg:w-5 transition duration-300 flex-shrink-0"
                />

                <div className="flex justify-between w-full items-center min-w-0">
                  <span className="text-xs sm:text-sm md:text-base font-normal truncate">PDP</span>
                  <ChevronRight
                    className={`h-4 w-4 sm:h-5 sm:w-5 transition-transform duration-300 flex-shrink-0 ${showPDPSubmenu ? "rotate-90" : ""}`}
                  />
                </div>
              </div>

              {/* PDP Submenu */}
              {showPDPSubmenu && (
                 <ul className="ml-4  lg:ml-2 xl:ml-4 space-y-0">
                  <li
                    className="flex items-center space-x-2 sm:space-x-3 text-mildbrown text-xs sm:text-sm hover:text-gray-500 cursor-pointer py-0.5"
                    onClick={handlecreatepdp}
                  >
                    <span
                      className={`font-bold leading-none ${isCreatePDPPath ? "text-lg sm:text-xl text-black" : "text-3xl sm:text-4xl"}`}
                    >
                      {isCreatePDPPath ? "●" : "◦"}
                    </span>
                    <span className={`truncate leading-tight ${isCreatePDPPath ? "font-medium text-black" : ""}`}>
                      Create New PDP
                    </span>
                  </li>

                  <li
                    className="flex items-center space-x-2 sm:space-x-3 text-mildbrown text-xs sm:text-sm hover:text-gray-500 cursor-pointer py-0.5"
                    onClick={handleviewpdp}
                  >
                    <span
                      className={`font-bold leading-none ${isCreatePDPPath ? "text-lg sm:text-xl text-black" : "text-3xl sm:text-4xl"}`}
                    >
                      {isCreatePDPPath ? "●" : "◦"}
                    </span>
                    <span className={`truncate leading-tight ${isCreatePDPPath ? "font-medium text-black" : ""}`}>
                      View PDP
                    </span>
                  </li>

                  <li
                    className="flex items-center space-x-2 sm:space-x-3 text-mildbrown text-xs sm:text-sm hover:text-gray-500 cursor-pointer py-0.5"
                    onClick={handleActionplannerlist}
                  >
                    <span
                      className={`font-bold leading-none ${isPDPActionlist ? "text-lg sm:text-xl text-black" : "text-3xl sm:text-4xl"}`}
                    >
                      {isPDPActionlist ? "●" : "◦"}
                    </span>
                    <span className={`truncate leading-tight ${isPDPActionlist ? "font-medium text-black" : ""}`}>
                      PDP Action Planner
                    </span>
                  </li>

                  <li
                    className="flex items-center space-x-2 sm:space-x-3 text-mildbrown text-xs sm:text-sm hover:text-gray-500 cursor-pointer py-0.5"
                    onClick={handleMangerBranch}
                  >
                    <span
                      className={`font-bold leading-none ${isPDPMangerlist ? "text-lg sm:text-xl text-black" : "text-3xl sm:text-4xl"}`}
                    >
                      {isPDPMangerlist ? "●" : "◦"}
                    </span>
                    <span className={`truncate leading-tight ${isPDPMangerlist ? "font-medium text-black" : ""}`}>
                      Manage Branch Master
                    </span>
                  </li>

                  <li
                    className="flex items-center space-x-2 sm:space-x-3 text-mildbrown text-xs sm:text-sm hover:text-gray-500 cursor-pointer py-0.5"
                    onClick={handleconsolidatedpdp}
                  >
                    <span
                      className={`font-bold leading-none ${isConsolidatedPDP ? "text-lg sm:text-xl text-black" : "text-3xl sm:text-4xl"}`}
                    >
                      {isConsolidatedPDP ? "●" : "◦"}
                    </span>
                    <span className={`truncate leading-tight ${isConsolidatedPDP ? "font-medium text-black" : ""}`}>
                      Consolidated PDP
                    </span>
                  </li>
                </ul>
              )}
            </li>

            {/* Dealer Investment */}
            <li>
              <div
                className={`flex items-center space-x-2 sm:space-x-3 p-2 sm:p-3 rounded-lg transition duration-300 cursor-pointer 
                  ${isDealerinvestment ? "bg-lightGrey text-black" : "hover:bg-lightBlue"}`}
                onClick={toggleDealerSubmenu}
              >
                {isDealerinvestment && (
                  <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Rectangle 16.png" alt="rectangle" className="h-6 w-2 sm:h-7 sm:w-2" />
                )}

                <img
       src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/dealerinvestmnet.png" 
                  alt="dealerinvestment"
                  className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 lg:h-5 lg:w-5 transition duration-300 flex-shrink-0"
                />

                <div className="flex justify-between w-full items-center min-w-0">
                  <span className="text-xs sm:text-sm md:text-base font-normal truncate">Dealer Investment</span>
                  <ChevronRight
                    className={`h-4 w-4 sm:h-5 sm:w-5 transition-transform duration-300 flex-shrink-0 ${showDealerSubmenu ? "rotate-90" : ""}`}
                  />
                </div>
              </div>

              {/* Dealer Investment Submenu */}
              {showDealerSubmenu && (
                  <ul className="ml-4  lg:ml-2 xl:ml-4 space-y-0">
                  <li className="flex items-center space-x-2 sm:space-x-3 text-mildbrown text-xs sm:text-sm hover:text-gray-500 cursor-pointer py-0.5">
                    <span
                      className={`font-bold leading-none ${isviewdealerinvestmnetpath ? "text-lg sm:text-xl text-blue2" : "text-3xl sm:text-4xl"}`}
                    >
                      {isviewdealerinvestmnetpath ? "●" : "◦"}
                    </span>
                    <span
                      onClick={handleviewdealerinvestment}
                      className={`cursor-pointer truncate leading-tight ${isviewdealerinvestmnetpath ? "text-black font-medium" : ""}`}
                    >
                      View Dealer Investment
                    </span>
                  </li>

                  {["Infrastructure Reports", "Allocation Dashboard", "MBP Dashboard V1"].map((item, index) => (
                    <li
                      key={index}
                      className="flex items-center space-x-2 sm:space-x-3 text-mildbrown text-xs sm:text-sm hover:text-gray-500 cursor-pointer py-0.5"
                    >
                      <span className="font-bold text-3xl sm:text-4xl leading-none">◦</span>
                      <span className="truncate leading-tight">{item}</span>
                    </li>
                  ))}
                </ul>
              )}
            </li>

            {/* Score Card */}
            <li
              className={`flex items-center space-x-2 sm:space-x-3 p-2 sm:p-3 rounded-lg transition duration-300 cursor-pointer 
                ${isScorecard ? "bg-lightGrey text-black" : "hover:bg-lightBlue"}`}
              onClick={() => closeOtherSubmenus(null)}
            >
              {isScorecard && <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Rectangle 16.png" alt="rectangle" className="h-6 w-2 sm:h-7 sm:w-2" />}

              <img
     src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Scorecard.png" 
                alt="scorecard"
                className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 lg:h-5 lg:w-5 transition duration-300 flex-shrink-0"
              />

              <span className="text-xs sm:text-sm md:text-base font-normal truncate">Score Card</span>
            </li>

            {/* DFHM */}
            <li
              className={`flex items-center space-x-2 sm:space-x-3 p-2 sm:p-3 rounded-lg transition duration-300 cursor-pointer 
                ${isDFHM ? "bg-lightGrey text-black" : "hover:bg-lightBlue"}`}
              onClick={() => closeOtherSubmenus(null)}
            >
              {isDFHM && <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Rectangle 16.png" alt="rectangle" className="h-6 w-2 sm:h-7 sm:w-2" />}

              <img
       src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/DFHM.png" 
                alt="dfhm"
                className="h-4 w-4 sm:h-5 sm:w-5 md:h-6 md:w-6 lg:h-5 lg:w-5 transition duration-300 flex-shrink-0"
              />

              <span className="text-xs sm:text-sm md:text-base font-normal truncate">DFHM</span>
            </li>
          </ul>

          {/* Logout Section - Only visible on small and medium screens */}
          <div className="mt-auto pt-4 border-t border-gray-200 block md:block lg:hidden">
            <button
              onClick={handleLogout}
              className="w-full flex items-center space-x-2 sm:space-x-3 p-2 sm:p-3 rounded-lg transition duration-300 cursor-pointer hover:bg-red-50 text-red-600 hover:text-red-700"
            >
              <LogOut className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
              <span className="text-xs sm:text-sm font-medium">Logout</span>
            </button>
          </div>
        </nav>
      </aside>
    </>
  )
}

export default FullSidebar
