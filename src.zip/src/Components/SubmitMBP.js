import React from "react";

/**
 * SubmitMBP Component
 * 
 * A reusable confirmation modal component for MBP submission and other confirmations
 * 
 * Used in:
 *   - EquipmentsAttachments.jsx (Admin submitting MBP)
 *   - FillEntriesEqup.jsx (Dealer submitting or requesting edit)
 * 
 * Props:
 *   - isOpen (boolean): Controls modal visibility (required)
 *   - onClose (function): Called when user clicks Cancel/No (required)
 *   - onConfirm (function): Called when user clicks Confirm/Yes (required)
 *   - title (string): Modal header title (default: "Confirm Action")
 *   - message (string): Modal description/message (default: "Are you sure...")
 *   - loading (boolean): Show loading state on confirm button (default: false)
 *   - confirmText (string): Text for confirm button (default: "Yes")
 *   - cancelText (string): Text for cancel button (default: "No")
 * 
 * Example Usage:
 *   <SubmitMBP
 *     isOpen={showPopup}
 *     onClose={() => setShowPopup(false)}
 *     onConfirm={handleSubmit}
 *     title="Submit MBP"
 *     message="Are you sure you want to submit?"
 *     loading={isSubmitting}
 *     confirmText="Submit"
 *     cancelText="Cancel"
 *   />
 */
const SubmitMBP = ({
  isOpen,
  onClose,
  onConfirm,
  title = "Confirm Action",
  message = "Are you sure you want to proceed?",
  loading = false,
  confirmText = "Yes",
  cancelText = "No",
}) => {
  // Don't render if modal is not open
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
      {/* Modal Container */}
      <div className="bg-white shadow-lg rounded-lg border-l-8 border-green-600 w-full max-w-sm sm:max-w-md md:max-w-lg">
        {/* ============================================
            HEADER WITH WARNING ICON
            ============================================ */}
        <div className="flex items-start gap-3 p-3 bg-red-100 rounded-t-lg">
          {/* Warning Icon */}
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/warning.png"
            alt="warning icon"
            className="w-5 h-5 flex-shrink-0 mt-0.5"
          />

          {/* Title and Message */}
          <div className="flex flex-col flex-1">
            <span className="text-xs font-semibold text-red-700">{title}</span>
            {message && (
              <span className="text-xs text-gray-700 mt-1 leading-relaxed">
                {message}
              </span>
            )}
          </div>
        </div>

        {/* ============================================
            ACTION BUTTONS
            ============================================ */}
        <div className="flex items-center justify-center gap-3 p-6 flex-wrap">
          {/* Cancel Button */}
          <button
            onClick={onClose}
            disabled={loading}
            className="border-2 border-red-300 text-red-600 px-4 py-1.5 text-xs font-bold rounded hover:bg-red-100 hover:shadow-md hover:scale-105 transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:none"
          >
            {cancelText}
          </button>

          {/* Confirm Button */}
          <button
            onClick={onConfirm}
            disabled={loading}
            className={`bg-green-600 text-white text-xs font-bold px-6 py-1.5 rounded transition duration-200 flex items-center gap-2 ${
              loading
                ? "opacity-50 cursor-not-allowed"
                : "hover:bg-white hover:border-2 hover:border-green-600 hover:text-green-600 hover:shadow-md hover:scale-105"
            }`}
          >
            {loading && (
              <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
            )}
            <span>{loading ? "Processing..." : confirmText}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SubmitMBP;