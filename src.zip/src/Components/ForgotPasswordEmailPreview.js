

import React from "react";

const ForgotPasswordEmailPreview = ({
  isOpen,
  onClose,
  onSend,
  email,
  isLoading = false,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 px-3 sm:px-4 md:px-6">
      <div className="bg-white  shadow-lg p-4  border-l-8 border-green overflow-y-auto max-h-[90vh]">
        
        {/* Header */}
        <h3 className="flex items-center justify-center text-base  font-semibold text-center p-2 sm:p-3 text-blue-800 bg-blue-100 mb-0 gap-2">
          <span className="leading-snug text-center">
            Password Reset Email Preview
          </span>
        </h3>

        {/* Email Preview Box */}
        <div className="border border-Dustyblue  bg-Frostwhite p-4 sm:p-6 text-xs  text-black font-VolvoNovum mb-4">
          <div className="mb-0 p-3 bg-gray-50  border-l-4 border-grey2">
            <p className="font-semibold text-gray-700 break-words">
              <strong>To:</strong> {email || "user@example.com"}
            </p>
            <p className="font-semibold text-gray-700">
              <strong>Subject:</strong> Reset Your Password
            </p>
          </div>

          <div className="space-y-1 leading-relaxed">
            <p>Hello,</p>

            <p>
              We received a request to reset the password for your account
              associated with <strong>{email}</strong>.
            </p>

            <p>
              If you made this request, please click the button below to set a
              new password:
            </p>

            <div className="flex justify-start my-4">
              <button
                disabled
                className="bg-darkblue1 text-white text-xs font-semibold px-4 sm:px-5 py-1.5  cursor-not-allowed hover:bg-white hover:text-darkblue1 hover:border-2 border-darkblue1 shadow-md transition duration-200 flex items-center gap-2 mb-1 "
              >
                🔗 Reset Password
              </button>
            </div>

            <div className="bg-mustardyellow/20 border-l-4 border-yellow1/40 p-1.5 ">
              <p className="text-xs">
                <strong>Important:</strong> This reset link will expire in{" "}
                <strong>24 hours</strong> for security reasons.
              </p>
            </div>

            <p>
              If you did not request a password reset, you can safely ignore
              this email — your password will remain unchanged.
            </p>
            <p className="mt-6 text-xs ">

              Thank you, <br />
              <strong>The Volvo Team</strong>
            </p>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
          <button
            onClick={onClose}
            disabled={isLoading}
            className="w-full sm:w-auto border-2 border-red2 text-red text-xs px-4 sm:px-5 py-1.5 font-bold hover:bg-red2 hover:shadow-md hover:scale-105 transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
          >
            Cancel
          </button>

          <button
            onClick={onSend}
            disabled={isLoading}
            className="w-full sm:w-auto bg-green4 text-green5 text-xs border-2 border-transparent font-bold font-VolvoNovum px-5 sm:px-6 py-1.5  hover:bg-white hover:border-green4 hover:shadow-md hover:scale-105 transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center"
          >
            {isLoading ? (
              <>
                <svg
                  className="animate-spin -ml-1 mr-3 h-4 w-4 text-current"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  ></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                Sending...
              </>
            ) : (
              "Send Email"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordEmailPreview;
