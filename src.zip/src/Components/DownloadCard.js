import React from "react";

const DownloadCard = ({ description, fileName, fileData }) => {

  const handleDownload = () => {
    const blob = new Blob([fileData], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    URL.revokeObjectURL(url);
  };

  return (
    <div className="border border-dashed border-black rounded-md bg-gery1 p-4 shadow-md w-full max-w-md">
      <div className="flex items-center gap-4">
        {/* Icon on the left */}
        <div className="flex-shrink-0">
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PDP/warning.png" // or use a built-in icon
            alt="info"
            className="w-4 h-4" // Fixed width and height
          />
        </div>

        {/* Text in center, vertically stacked */}
        <div className="flex flex-col">
          <p className="text-sm text-black text-left">
            {/* If the description has multiple lines, this will center align the second line */}
            <span className="block">{description.split("\n")[0]}</span>
            <span className="block text-center">{description.split("\n")[1]}</span>
          </p>
          <button
            onClick={handleDownload}
            className="text-sm text-SteelBlue underline font-medium hover:font-bold text-left "
          >
            {fileName}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DownloadCard;
