import { useState, useEffect, useRef } from "react"
import { useNavigate } from "react-router-dom"
import { getUserNotificationsByUserId, bulkToggleNotificationsAsSeen } from "../services/notificationService"

const NotificationPanel = ({ isOpen, onClose, onViewAll = null }) => {
  const navigate = useNavigate()
  const [notifications, setNotifications] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const listRef = useRef(null)

  useEffect(() => {
    if (isOpen) {
      fetchNotifications()
    }
  }, [isOpen])

  const fetchNotifications = async () => {
    try {
      setLoading(true)
      setError(null)
      
      const data = await getUserNotificationsByUserId()
      const sortedData = (data || []).sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      setNotifications(sortedData)

      // Mark unseen as seen (optimal bulk approach - single API call)
      const unseenIds = (sortedData || []).filter(n => n.isSeen === 0).map(n => n.id)
      if (unseenIds.length > 0) {
        try {
          await bulkToggleNotificationsAsSeen(unseenIds)
        } catch (err) {
          console.error("Error marking notifications as seen:", err)
        }
      }
    } catch (error) {
      console.error("❌ Error fetching notifications:", error.message)
      setError(error.message)
      setNotifications([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (listRef.current && notifications.length > 0) {
      listRef.current.scrollTop = 0
    }
  }, [notifications])

  const getIconColor = (type) => {
    const colors = {
      alert: "#DC2626",
      assignment: "#2563EB",
      reminder: "#7C3AED",
      update: "#059669",
      compliance: "#EA580C",
      user: "#06B6D4",
      system: "#8B5CF6"
    }
    return colors[type] || "#1e3a5f"
  }

  const getIconSVG = (type) => {
    const icons = {
      alert: (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z" />
        </svg>
      ),
      assignment: (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54-2.12-2.59c-.39-.48-1.08-.59-1.63-.27-.55.33-.68 1.04-.29 1.58l3 3.72c.3.38.77.59 1.25.59.48 0 .95-.21 1.25-.59l4-5.13c.39-.54.25-1.25-.29-1.58-.55-.32-1.24-.21-1.63.27z" />
        </svg>
      ),
      reminder: (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
        </svg>
      ),
      update: (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-8 3.58-8 8 0 .5.05 1 .15 1.5H4.5c-.1-.5-.1-1.5-.1-1.5 0-5.52 4.48-10 10-10 2.58 0 4.92.99 6.73 2.61l2.18-2.18c.46-.46 1.21-.46 1.67 0 .46.46.46 1.21 0 1.67L17.65 6.35zM13 17.9v2.2c0 .83-.67 1.5-1.5 1.5S10 20.93 10 20.1v-2.2c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5zm4-4c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-10 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm6-6c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2z" />
        </svg>
      ),
      compliance: (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
        </svg>
      ),
      user: (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
        </svg>
      ),
      system: (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
        </svg>
      )
    }
    return icons[type] || icons.alert
  }

  const formatDate = (dateString) => {
    if (!dateString) return ""
    try {
      const date = new Date(dateString)
      const now = new Date()
      const diffMs = now - date
      const diffMins = Math.floor(diffMs / 60000)
      const diffHours = Math.floor(diffMs / 3600000)
      const diffDays = Math.floor(diffMs / 86400000)

      if (diffMins < 1) return "just now"
      if (diffMins < 60) return `${diffMins}m ago`
      if (diffHours < 24) return `${diffHours}h ago`
      if (diffDays < 7) return `${diffDays}d ago`
      
      return date.toLocaleDateString()
    } catch (e) {
      return dateString
    }
  }

  const handleViewAll = () => {
    if (onViewAll) {
      onViewAll()
    } else {
      onClose?.()
      navigate('/notifications')
    }
  }

  if (!isOpen) return null

  return (
    <>
      <style>{`
        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .notification-list::-webkit-scrollbar { width: 8px; }
        .notification-list::-webkit-scrollbar-track { background: transparent; }
        .notification-list::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
        .notification-list::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
        .notification-list { scrollbar-color: #cbd5e1 transparent; scrollbar-width: thin; }
      `}</style>

      <div className="fixed inset-0 z-40 bg-black bg-opacity-20" onClick={onClose} />

      <div className="absolute right-0 top-full mt-2 w-96 max-h-[calc(100vh-140px)] bg-gray-50  shadow-lg z-50 flex flex-col border border-gray-200">

        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 bg-white">
          <h3 className="text-sm font-bold text-darkblue1">Your Notifications</h3>

          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
             <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>

          </button>
        </div>

        <div className="notification-list overflow-y-auto flex-1 px-3 py-3 space-y-2" ref={listRef}>
          {loading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center h-32 text-red-600 space-y-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4m0 4v.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p className="text-xs text-center">
                <strong>Failed to load notifications</strong><br />{error}
              </p>
              <button onClick={fetchNotifications} className="text-xs underline hover:text-red-700 transition">Try Again</button>
            </div>
          ) : notifications.length > 0 ? (
            <>
              {notifications.slice(0, 15).map((notification, index) => (
                <div
                  key={notification.id}
                  style={{ animation: index === 0 ? 'slideDown 0.3s ease-out' : 'none' }}
                  className="bg-white rounded-md p-3 shadow-sm hover:shadow-md transition-shadow duration-200 cursor-pointer border border-gray-100"
                >
                  <div className="flex gap-3 items-start">
                    <div className="flex-shrink-0 mt-0.5">
                      <div
                        className="w-10 h-10 rounded-full flex items-center justify-center text-white flex-shrink-0"
                        style={{ backgroundColor: getIconColor(notification.type || "update") }}
                      >
                        {getIconSVG(notification.type || "update")}
                      </div>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline justify-between gap-2 mb-0.5">
                        <h4 className="text-sm font-semibold text-black leading-tight">
                          {notification.title}
                        </h4>
                        <span className="text-xs text-black/70 flex-shrink-0 whitespace-nowrap">
                          {formatDate(notification.created_at)}
                        </span>
                      </div>
                      <p className="text-xs text-black/70 line-clamp-2 leading-tight">
                        {notification.message}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-32 text-gray-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10 mb-2 opacity-25" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
              </svg>
              <p className="text-xs">No notifications yet</p>
            </div>
          )}
        </div>

        <div className="px-4 py-2.5 border-t border-gray-200 bg-white">
          <button
            onClick={handleViewAll}
            className="w-full text-xs font-medium text-SteelBlue1 underline hover:font-bold transition-colors"
          >
            View All {notifications.length > 15 ? `(${notifications.length})` : ""}
          </button>
        </div>
      </div>
    </>
  )
}

export default NotificationPanel