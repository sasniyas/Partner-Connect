import React from "react";

const DeleteAllRecords = ({ isOpen, onClose, onConfirm }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 px-4">
      <div className="bg-white  shadow-lg p-4 sm:p-6 w-full max-w-sm border-l-8 border-green">
        <h3 className="flex items-center justify-center text-xs font-semibold text-center  p-2 text-red1 bg-red2 mb-4 gap-2">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/warning.png" alt="warning" className="w-4 h-4" />
          <span className="leading-snug">
            Are you sure you want to delete <span className="font-bold">all records</span>?
          </span>
        </h3>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onClose}
            className="w-full sm:w-auto border-2 border-red2 text-red px-5 py-1.5 text-xs font-bold  hover:bg-red2 hover:shadow-md hover:scale-105 transition duration-200"
          >
            No
          </button>
          <button
            onClick={onConfirm}
            className="w-full sm:w-auto bg-green4 text-green5 text-xs border-2 border-transparent font-bold font-VolvoNovum px-6 py-1.5  hover:bg-white hover:border-green4 hover:shadow-md hover:scale-105 transition duration-200"
          >
            Yes
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteAllRecords;
