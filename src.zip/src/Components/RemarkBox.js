import React from "react";
import { Edit, Trash } from "lucide-react"; // optional icons (use any icons you want)

const RemarkBox = ({
  title,
  value,
  onChange,
  footerName,
  footerTime,
  onEdit,
  onDelete,
  onSave,
}) => {
  return (
    <div className="bg-white border border-black/60 shadow-sm p-3 w-full">
      {/* Title */}
      <p className="text-xs font-semibold mb-1">{title}</p>

      {/* Textarea */}
      <textarea
        className="w-full bg-gery1 p-2 text-xs resize-none"
        placeholder="Enter your text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      ></textarea>

      {/* Footer */}
      <div className="flex items-center justify-between mt-2">
        {/* Name + Time */}
        <p className="text-[10px] text-gray-500">
          {footerName}, {footerTime}
        </p>

        {/* Icons + Save */}
        <div className="flex items-center gap-2">
            <div className="relative group">
          <button
            onClick={onEdit}
            className="text-green-600 hover:text-green-800"
          >
                              <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png" className="w-4 h-4" alt="Edit" />
          </button>
           <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                              Edit
                            </span>
          </div>
<div className="relative group">
          <button
            onClick={onDelete}
            className="text-red-600 hover:text-red-800"
          >
                              <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png" className="w-4 h-4" alt="Delete" />
          </button>
           <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                             Delete
                            </span>
</div>
          <button
            onClick={onSave}
            className="bg-darkblue1 text-white px-4 py-[1px] text-[10px] font-medium hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default RemarkBox;
