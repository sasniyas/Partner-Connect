"use client"

import FullSidebar from "./Fullsidebar"
import { useState, useRef, useEffect, useCallback } from "react"
import UserProfilePopup from "../pages/Outlook/UserProfilePopup"
import { useNavigate } from "react-router-dom"
import axios from "axios"
import LogoutModal from "./LogoutModal"
import NotificationPanel from "./NotificationPanel"
import { API } from '../api';
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import { getUserNotificationsByUserId, bulkToggleNotificationsAsSeen } from "../services/notificationService"


const Header = ({ menuOpen, setMenuOpen }) => {
  const [isOpen, setIsOpen] = useState(false)
  const [showProfile, setShowProfile] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [profileImage, setProfileImage] = useState(null)
  const [notificationCount, setNotificationCount] = useState(0)
  const [hasNewNotification, setHasNewNotification] = useState(false)
  const navigate = useNavigate()
  const [isLogoutOpen, setIsLogoutOpen] = useState(false)
  const [user, setUser] = useState({})
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const { data: userData } = useSelector((state) => state.user);
  const location = useLocation();
  const [isImpersonating, setIsImpersonating] = useState(false);

  const notificationRef = useRef(null)
  const dropdownRef = useRef(null)
  const pollingIntervalRef = useRef(null)
  const prevCountRef = useRef(0)
  const isMarkingRef = useRef(false)

  const handlesupport = () => { navigate("/support") }
  const isActive = location.pathname === "/support";

  // ─── Fetch unseen count ───
  const fetchUnseenCount = useCallback(async () => {
    if (isMarkingRef.current) return;

    try {
      const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
      if (!token) return;

      const data = await getUserNotificationsByUserId();
      const unseenCount = (data || []).filter(n => n.isSeen === 0).length;

      if (unseenCount > prevCountRef.current) {
        setHasNewNotification(true);
        setTimeout(() => setHasNewNotification(false), 3000);
      }

      prevCountRef.current = unseenCount;
      setNotificationCount(unseenCount);
    } catch (error) {
      console.error("Error fetching notification count:", error);
    }
  }, []);

  // ─── Poll every 30 seconds ───
  useEffect(() => {
    fetchUnseenCount();
    pollingIntervalRef.current = setInterval(fetchUnseenCount, 30000);
    return () => {
      if (pollingIntervalRef.current) clearInterval(pollingIntervalRef.current);
    };
  }, [fetchUnseenCount]);

  // ─── Mark all unseen as seen ───
  const markAllSeenAndClearBadge = useCallback(async () => {
    if (isMarkingRef.current) return;

    isMarkingRef.current = true;

    // Stop polling
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
      pollingIntervalRef.current = null;
    }

    // Clear badge immediately
    setNotificationCount(0);
    prevCountRef.current = 0;
    setHasNewNotification(false);

    try {
      // This fetches fresh data, checks isSeen===0, only calls API for those
      const data = await getUserNotificationsByUserId();
      const unseenIds = (data || []).filter(n => n.isSeen === 0).map(n => n.id);
      if (unseenIds.length > 0) {
        await bulkToggleNotificationsAsSeen(unseenIds);
      }
    } catch (err) {
      console.error("Error marking as seen:", err);
    } finally {
      isMarkingRef.current = false;
      // Resume polling after delay
      setTimeout(() => {
        fetchUnseenCount();
        pollingIntervalRef.current = setInterval(fetchUnseenCount, 30000);
      }, 2000);
    }
  }, [fetchUnseenCount]);

  // ─── Bell click ───
  const handleNotificationToggle = async () => {
    const opening = !showNotifications;
    setShowNotifications(opening);
    if (opening) {
      await markAllSeenAndClearBadge();
    }
  };

  // ─── "View All" from panel ───
  const handleViewAllNotifications = async () => {
    setShowNotifications(false);
    await markAllSeenAndClearBadge();
    navigate('/notifications');
  };

  useEffect(() => {
    const fetchActiveUser = async () => {
      try {
        let userToken = localStorage.getItem("userToken")
        if (userToken) setIsImpersonating(true);

        const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) {
          navigate("/")
          return
        }

        const fetchedUser = userData
        if (fetchedUser) {
          const formattedRole = fetchedUser.role
            ? fetchedUser.role
              .toLowerCase()
              .replace(/_/g, " ")
              .replace(/\b\w/g, (c) => c.toUpperCase())
            : ""

          setUser({
            ...fetchedUser,
            role: formattedRole,
          })
        } else {
          navigate("/")
          console.warn("User is inactive or not found")
        }
      } catch (error) {
        console.error("Failed to fetch logged-in user:", error)
        if (
          error.response?.data?.message === "token is invalid" ||
          error.response?.data?.message === "jwt expired"
        ) {
          navigate("/")
        }
      }
    }

    fetchActiveUser()
  }, [navigate, userData])

  const handleProfile = () => setShowProfile(true)
  const handleLogoutClick = () => { setIsLogoutOpen(true) }
  const handleClose = () => { setIsLogoutOpen(false) }

  const handleBackToAdmin = () => {
    try {
      const impersonationData = localStorage.getItem("userToken");
      if (impersonationData) {
        localStorage.removeItem("userToken");
        setIsImpersonating(false);
        navigate("/usermangement");
        window.location.reload();
      }
    } catch (error) {
      console.error("Error returning to admin:", error);
      localStorage.removeItem("adminImpersonation");
      setIsImpersonating(false);
      navigate("/usermangement");
    }
  };

  const handleLogout = async () => {
    try {
      setIsLoggingOut(true);
      const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");

      if (!token) {
        localStorage.removeItem("superUserToken");
        localStorage.removeItem("user");
        localStorage.removeItem("userToken");
        setIsLogoutOpen(false);
        navigate("/");
        return;
      }

      const response = await axios.post(
        `${API.domain}${API.userManagement.logout}`,
        {},
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.data.status) {
        localStorage.removeItem("superUserToken");
        localStorage.removeItem("user");
        localStorage.removeItem("userToken");
        setIsLogoutOpen(false);
        navigate("/");
      } else {
        console.error("Logout API error:", response.data.message);
        localStorage.removeItem("superUserToken");
        localStorage.removeItem("user");
        localStorage.removeItem("userToken");
        setIsLogoutOpen(false);
        navigate("/");
      }
    } catch (error) {
      console.error("Logout error:", error);
      localStorage.removeItem("superUserToken");
      localStorage.removeItem("user");
      localStorage.removeItem("userToken");
      setIsLogoutOpen(false);
      navigate("/");
    } finally {
      setIsLoggingOut(false);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target)) {
        setShowNotifications(false)
      }
    }
    if (showNotifications) {
      document.addEventListener("mousedown", handleClickOutside)
    }
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [showNotifications])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  return (
    <>
      <style>{`
        @keyframes bellRing {
          0% { transform: rotate(0deg); }
          10% { transform: rotate(14deg); }
          20% { transform: rotate(-14deg); }
          30% { transform: rotate(10deg); }
          40% { transform: rotate(-10deg); }
          50% { transform: rotate(6deg); }
          60% { transform: rotate(-4deg); }
          70% { transform: rotate(2deg); }
          80% { transform: rotate(-1deg); }
          100% { transform: rotate(0deg); }
        }
        @keyframes badgePop {
          0% { transform: scale(0); }
          50% { transform: scale(1.3); }
          100% { transform: scale(1); }
        }
        .bell-ring-animation {
          animation: bellRing 0.8s ease-in-out;
          animation-iteration-count: 3;
        }
        .badge-pop {
          animation: badgePop 0.3s ease-out;
        }
      `}</style>

      <header className="bg-white shadow-md fixed w-full top-0 z-50 h-16 lg:h-12 flex items-center">
        <div className="relative flex items-center justify-between w-full px-4">
          <div className="flex items-center gap-2">
            <div className="lg:hidden">
              <button onClick={() => setMenuOpen(!menuOpen)} className="focus:outline-none flex items-center justify-center hover:bg-lightBlue h-8 w-8 sm:h-10 sm:w-10 transition-all duration-200">
                {menuOpen ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                ) : (
                  <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/material-symbols_menu-rounded.png" alt="Menu" className="h-5 w-5 sm:h-6 sm:w-6" />
                )}
              </button>
            </div>

            <div className="hidden lg:flex items-center justify-start ml-[-60px]">
              <div className="pointer-events-none">
                <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Volvo Logo" className="h-10 w-24 sm:h-12 sm:w-36 md:h-14 md:w-44 lg:h-16 lg:w-56 xl:h-18 xl:w-64 object-contain" />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 sm:gap-2 lg:gap-3">

            {isImpersonating && (
              <button onClick={handleBackToAdmin} className="flex items-center gap-1.5 bg-darkblue1 hover:bg-darkblue2 text-white px-2 sm:px-3 py-1.5 text-xs font-medium transition-all duration-200 shadow-sm hover:shadow-md">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M11 17l-5-5m0 0l5-5m-5 5h12" />
                </svg>
                <span className="hidden sm:inline">Back to Admin</span>
                <span className="sm:hidden">Admin</span>
              </button>
            )}

            <button onClick={handlesupport} className={`relative focus:outline-none flex items-center justify-center h-8 w-8 sm:h-10 sm:w-10 lg:h-8 lg:w-8 transition group ${isActive ? "bg-lightBlue rounded-full" : "hover:bg-lightBlue"}`}>
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none" className="h-3 w-3">
                <path d="M19.4666 10.7667C19.4666 9.81111 19.1502 9.04444 18.5173 8.46667C17.8844 7.88889 17.0453 7.6 15.9999 7.6C15.3555 7.6 14.7724 7.73911 14.2506 8.01733C13.7288 8.29556 13.2786 8.70089 12.8999 9.23333C12.5444 9.74444 12.0608 10.0391 11.4493 10.1173C10.8377 10.1956 10.3102 10.0342 9.8666 9.63333C9.55548 9.34444 9.38348 8.98889 9.3506 8.56667C9.31771 8.14444 9.42304 7.74444 9.6666 7.36667C10.3777 6.3 11.2835 5.47244 12.3839 4.884C13.4844 4.29556 14.6897 4.00089 15.9999 4C18.1555 4 19.9057 4.61111 21.2506 5.83333C22.5955 7.05556 23.2675 8.65556 23.2666 10.6333C23.2666 11.6333 23.0555 12.5333 22.6333 13.3333C22.211 14.1333 21.4333 15.0778 20.2999 16.1667C19.4777 16.9444 18.9222 17.5502 18.6333 17.984C18.3444 18.4178 18.1555 18.912 18.0666 19.4667C17.9777 20 17.7497 20.4444 17.3826 20.8C17.0155 21.1556 16.5768 21.3333 16.0666 21.3333C15.5564 21.3333 15.1177 21.1613 14.7506 20.8173C14.3835 20.4733 14.1999 20.0453 14.1999 19.5333C14.1999 18.6667 14.3888 17.8724 14.7666 17.1507C15.1444 16.4289 15.7777 15.6676 16.6666 14.8667C17.7999 13.8667 18.5502 13.0947 18.9173 12.5507C19.2844 12.0067 19.4675 11.412 19.4666 10.7667ZM15.9999 29.3333C15.2666 29.3333 14.639 29.0724 14.1173 28.5507C13.5955 28.0289 13.3342 27.4009 13.3333 26.6667C13.3324 25.9324 13.5937 25.3049 14.1173 24.784C14.6408 24.2631 15.2684 24.0018 15.9999 24C16.7315 23.9982 17.3595 24.2596 17.8839 24.784C18.4084 25.3084 18.6693 25.936 18.6666 26.6667C18.6639 27.3973 18.403 28.0253 17.8839 28.5507C17.3648 29.076 16.7368 29.3369 15.9999 29.3333Z" fill="#212121" />
              </svg>
              <span className="absolute left-1/2 top-full mt-2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">Support</span>
            </button>

            {/* NOTIFICATION BELL */}
            <div ref={notificationRef} className="relative">
              <button
                onClick={handleNotificationToggle}
                className="relative focus:outline-none flex items-center justify-center h-8 w-8 sm:h-10 sm:w-10 lg:h-8 lg:w-8 transition group hover:bg-lightBlue"
              >
                <div className={hasNewNotification ? 'bell-ring-animation' : ''}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none" className="h-4 w-4">
                    <path d="M20.3431 23.6667V24.6667C20.3431 25.7275 19.9217 26.7449 19.1715 27.4951C18.4214 28.2452 17.4039 28.6667 16.3431 28.6667C15.2822 28.6667 14.2648 28.2452 13.5147 27.4951C12.7645 26.7449 12.3431 25.7275 12.3431 24.6667V23.6667M27.0731 21.631C25.4681 19.6667 24.335 18.6667 24.335 13.251C24.335 8.29167 21.8025 6.52479 19.7181 5.66667C19.4412 5.55292 19.1806 5.29167 19.0962 5.00729C18.7306 3.76292 17.7056 2.66667 16.3431 2.66667C14.9806 2.66667 13.955 3.76354 13.5931 5.00854C13.5087 5.29604 13.2481 5.55292 12.9712 5.66667C10.8843 6.52604 8.35433 8.28667 8.35433 13.251C8.35121 18.6667 7.21808 19.6667 5.61308 21.631C4.94808 22.4448 5.53058 23.6667 6.69371 23.6667H25.9987C27.1556 23.6667 27.7343 22.441 27.0731 21.631Z" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>

                {notificationCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-[18px] h-[18px] px-1 text-[10px] font-bold leading-none text-white bg-red rounded-full badge-pop">
                    {notificationCount > 99 ? '99+' : notificationCount}
                  </span>
                )}

                <span className="absolute left-1/2 top-full mt-2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                  Notifications
                </span>
              </button>

              {showNotifications && (
                <NotificationPanel
                  isOpen={showNotifications}
                  onClose={() => setShowNotifications(false)}
                  onViewAll={handleViewAllNotifications}
                />
              )}
            </div>

            <div className="relative inline-block">
              <div className="flex items-center gap-2 lg:gap-3">
                <div className="relative group">
                  <div onClick={handleProfile} className="w-8 h-8 sm:w-9 sm:h-9 lg:w-8 lg:h-8 flex items-center justify-center rounded-full cursor-pointer hover:scale-105 overflow-hidden transition-transform">
                    {profileImage ? (
                      <img src={profileImage} alt="Profile" className="w-full h-full object-cover rounded-full" />
                    ) : (
                      <span className="bg-[#B6D7D2] w-full h-full flex items-center justify-center text-xs font-semibold text-gray-700">
                        {user.firstName?.[0]?.toUpperCase()}{user.lastName?.[0]?.toUpperCase()}
                      </span>
                    )}
                  </div>
                  <span className="absolute left-1/2 top-full mt-2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">Profile</span>
                </div>

                <div onClick={handleProfile} className="hidden lg:flex flex-col cursor-pointer">
                  <span className="text-xs font-semibold text-gray-900">
                    {user?.firstName ? `${user.firstName} ${user.middleName || ""} ${user.lastName}` : "Loading..."}
                  </span>
                  <span className="text-xs text-black">{user.persona}</span>
                </div>

                <div className="relative group" ref={dropdownRef}>
                  <button onClick={handleLogoutClick} className="relative focus:outline-none flex items-center justify-center h-8 w-8 sm:h-10 sm:w-10 lg:h-8 lg:w-8 transition hover:bg-lightBlue group">
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none" className="h-4 w-4">
                      <path d="M17.222 3.78512L17.2532 5.43249C17.2553 5.54497 17.3065 5.64948 17.3946 5.71814C17.5969 5.87841 17.7923 6.05052 17.9786 6.23218C18.7509 6.97496 19.3719 7.86038 19.8072 8.83945C20.2584 9.85377 20.5008 10.9486 20.5198 12.0586C20.5411 13.181 20.3414 14.2725 19.9295 15.3023C19.5316 16.2972 18.9445 17.2055 18.2009 17.977C17.46 18.7497 16.5761 19.3715 15.5984 19.8078C14.5849 20.2606 13.5041 20.4991 12.3816 20.5204C11.2592 20.5416 10.1701 20.3419 9.1402 19.93C8.14576 19.5316 7.24628 18.9485 6.47024 18.199C5.69419 17.4495 5.07749 16.5727 4.64166 15.5917C4.19114 14.5782 3.95029 13.4951 3.92904 12.3726C3.90779 11.2502 4.10514 10.1587 4.51931 9.12885C4.91771 8.13206 5.50079 7.23259 6.24791 6.45424C6.42953 6.26562 6.6184 6.08857 6.81209 5.91847C6.89746 5.84653 6.94463 5.7378 6.94254 5.62767L6.91136 3.98031C6.90857 3.83268 6.7428 3.74439 6.62016 3.82876C3.86093 5.67897 2.07158 8.85872 2.1486 12.4321C2.26894 18.0465 6.91193 22.4617 12.5185 22.2993C18.0359 22.1386 22.4055 17.5598 22.3007 12.0249C22.2333 8.46065 20.3275 5.36491 17.5073 3.62266C17.3816 3.54534 17.2192 3.6375 17.222 3.78512ZM11.8796 1.80229L9.31804 5.17716C9.22197 5.30322 9.31443 5.48197 9.47143 5.479L11.2524 5.44528L11.3917 12.8033C11.3936 12.9064 11.4796 12.9892 11.5827 12.9873L12.8949 12.9624C12.998 12.9605 13.0808 12.8745 13.0789 12.7714L12.9396 5.41334L14.7205 5.37963C14.8775 5.37666 14.9631 5.19219 14.8624 5.0722L12.1749 1.7967C12.1569 1.77463 12.1342 1.75693 12.1084 1.74495C12.0825 1.73297 12.0543 1.72703 12.0259 1.72757C11.9974 1.72811 11.9695 1.73511 11.9441 1.74806C11.9188 1.76101 11.8967 1.77955 11.8796 1.80229Z" fill="#212121" />
                    </svg>
                  </button>
                  <span className="absolute left-1/2 top-full mt-2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">Logout</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <FullSidebar menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      {showProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black bg-opacity-50" onClick={() => setShowProfile(false)} />
          <div className="relative w-full max-w-md sm:max-w-lg md:max-w-xl lg:max-w-2xl max-h-[90vh] overflow-auto">
            <UserProfilePopup user={user} setUser={setUser} onClose={() => setShowProfile(false)} profileImage={profileImage} setProfileImage={setProfileImage} />
          </div>
        </div>
      )}

      <LogoutModal isOpen={isLogoutOpen} onClose={handleClose} onConfirm={handleLogout} loading={isLoggingOut} />
    </>
  )
}

export default Header