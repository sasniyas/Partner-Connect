import React from "react";

const CompleteReview = ({
  isOpen,
  onClose,
  onConfirm,
  loading = false,
  extraMessage // optional: additional text
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
      <div className="bg-white shadow-lg p-6 w-full max-w-sm sm:max-w-md md:max-w-lg border-l-8 border-green">
       <h3 className="flex items-center justify-center text-xs font-semibold  p-2 text-red1 bg-red2 mb-4 gap-3 text-left">
  <img
    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/warning.png"
    alt="warning"
    className="w-5 h-5 flex-shrink-0"
  />
  <div className="flex flex-col">
    <span>Are you sure you want to complete all the reviews?</span>
    {extraMessage && (
      <span className="mt-1 text-xs">
        <span className="text-red1 font-bold mr-1">*Note:</span>
        <span className="text-black/70">{extraMessage}</span>
      </span>
    )}
  </div>
</h3>


        <div className="flex items-center justify-center gap-4 flex-wrap">
          <button
            onClick={onClose}
            disabled={loading}
            className="border-2 border-red2 text-red px-4  py-1.5 text-xs font-bold  hover:bg-red2 hover:shadow-md hover:scale-105 transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            No
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            className={`bg-green4 text-green5 text-xs border-2 border-transparent font-bold font-VolvoNovum px-5  py-1.5  transition duration-200 ${
              loading
                ? "opacity-50 cursor-not-allowed"
                : "hover:bg-white hover:border-green4 hover:shadow-md hover:scale-105"
            }`}
          >
              {loading ? "Processing..." : "Yes"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CompleteReview;
