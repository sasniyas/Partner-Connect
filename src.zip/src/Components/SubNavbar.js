// import {
//   Home,
//   LayoutDashboard,
//   Users,
//   Database,
//   MoreVertical,
//   Home as HomeActive,
//   LayoutDashboard as LayoutDashboardActive,
//   Users as UsersActive,
//   Database as DatabaseActive,
//   MoreVertical as MoreVerticalActive,
// } from "lucide-react";
// import { Link, useLocation } from "react-router-dom";
// import { useRef } from "react";

// const SubNavbar = () => {
//   const location = useLocation();
//   const menuRef = useRef(null);

//   const managementDropdown = [
//     {
//       title: "User Management",
//       path: "/usermangement",
//       links: [],
//     },
//     {
//       title: "Log",
//       links: [
//         { id: "auth-log", label: "Authentication Log", path: "/authentication" },
//         { id: "user-history", label: "User History", path: "/usermangement/user-history" },
//       ],
//     },
//   ];

//   const mastersDropdown = [
//     {
//       title: "Scorecard",
//       path: "/scorecard",
//       links: [],
//     },
//     {
//       title: "PDP",
//       path: "/masterpdphomepage",
//       links: [],
//     },
//     {
//       title: "Monthly meeting",
//       path: "/mastermothlymeeting",
//       links: [],
//     },
//     {
//       title: "DealerInvestment",
//       path: "/masterdealerinvestment",
//       links: [],
//     },
//     {
//       title: "DashBoards",
//       path: "/masterdashboard",
//       links: [],
//     },
//     {
//       title: "Dfhm",
//       path: "/masterdfhm",
//       links: [],
//     },
//   ];

//   const menuDropdown = [
//     {
//       title: "Monthly Meeting",
//       path: "/monthlymeetinghomepage",
//       links: [],
//     },
//     {
//       title: "PDP",
//       path: "/menu/pdp",
//       links: [
//         { id: "create-pdp", label: "Create New PDP", path: "/menu/pdp/create" },
//         { id: "view-pdp", label: "View PDP", path: "/menu/pdp/view" },
//         { id: "action-planner", label: "PDP Action Planner", path: "/menu/pdp/action-planner" },
//         { id: "manage-branch", label: "Manage Branch Master", path: "/menu/pdp/branch-master" },
//         { id: "consolidated", label: "Consolidated PDP", path: "/menu/pdp/consolidated" },
//       ],
//     },
//     {
//       title: "DealerInvestment",
//       path: "/menu/dealerinvestment",
//       links: [
//         { id: "view-investment", label: "View Dealer Investment", path: "/menu/dealerinvestment/view" },
//       ],
//     },
//     {
//       title: "Scorecard",
//       path: "/menu/scorecard",
//       links: [],
//     },
//     {
//       title: "DFHM",
//       path: "/menu/dfhm",
//       links: [],
//     },
//   ];

//   const menuItems = [
//     {
//       id: "home",
//       label: "Home",
//       icon: Home,
//       activeIcon: HomeActive,
//       path: "/homepage",
//     },
//     {
//       id: "outlook",
//       label: "Outlook",
//       icon: LayoutDashboard,
//       activeIcon: LayoutDashboardActive,
//       path: "/outlook",
//     },
//     {
//       id: "management",
//       label: "Management",
//       icon: Users,
//       activeIcon: UsersActive,
//       path: "/usermangement",
//       submenu: managementDropdown,
//     },
//     {
//       id: "masters",
//       label: "Masters",
//       icon: Database,
//       activeIcon: DatabaseActive,
//       submenu: mastersDropdown,
//     },
//     {
//       id: "menu",
//       label: "Menu",
//       icon: MoreVertical,
//       activeIcon: MoreVerticalActive,
//       submenu: menuDropdown,
//     },
//   ];

//   // Extra paths for highlighting main modules
//   const extraHighlightPaths = {
//     management: ["/userlogin", "/userdetails"],
//     menu: ["/trendchart", "/actionitemview", "/monthlymeetingviewdetails"],
//   };

//   // Extra paths to highlight submenu headings by title
//   const extraSubmenuHighlightPaths = {
//     "Monthly Meeting": [
//       "/trendchart",
//       "/actionitemview",
//       "/monthlymeetingviewdetails",
//       // add more paths here to highlight the heading
//     ],
//   };

//   // Check if the main menu item is active (for highlight)
//   const isMenuItemActive = (item) => {
//     return (
//       (item.path && location.pathname.startsWith(item.path)) ||
//       (item.submenu &&
//         item.submenu.some(
//           (section) =>
//             (section.path && location.pathname.startsWith(section.path)) ||
//             section.links?.some((link) => location.pathname.startsWith(link.path)) ||
//             (extraSubmenuHighlightPaths[section.title] &&
//               extraSubmenuHighlightPaths[section.title].some((p) =>
//                 location.pathname.startsWith(p)
//               ))
//         )) ||
//       (extraHighlightPaths[item.id]?.some((p) => location.pathname.startsWith(p)))
//     );
//   };

//   return (
//     <div
//       className="hidden lg:block bg-grey2 border-t border-gray-300 w-full z-40 fixed top-20 shadow"
//       style={{ height: "70px" }}
//     >
//       <div className="max-w-screen-xl mx-auto h-full">
//         <div className="flex justify-center gap-3 sm:gap-6 md:gap-8 h-full" ref={menuRef}>
//           {menuItems.map((item) => {
//             const isActiveMain = isMenuItemActive(item);
//             const hasSubmenu = item.submenu && item.submenu.length > 0;
//             const Icon = isActiveMain ? item.activeIcon : item.icon;

//             return (
//               <div
//                 key={item.id}
//                 className="relative group h-full flex items-center transition-all duration-200 hover:bg-white"
//               >
//                 <Link
//                   to={item.path || "#"}
//                   className={`flex items-center gap-2 px-3 cursor-pointer h-full text-black ${
//                     isActiveMain ? "font-medium bg-white shadow" : ""
//                   }`}
//                 >
//                   <Icon
//                     size={16}
//                     className={isActiveMain ? "fill-black stroke-black" : "fill-none stroke-current"}
//                   />
//                   <span className="text-base">{item.label}</span>
//                 </Link>

//                 {/* Submenu on Hover */}
//                 {hasSubmenu && (
//                   <div className="absolute top-full left-1/2 -translate-x-1/2 mt-0 hidden group-hover:flex bg-white shadow-lg z-50 min-w-[320px] p-4">
//                     <div className="flex gap-6">
//                       {item.submenu.map((section, index) => {
//                         const isHeadingActive =
//                           (section.path && location.pathname.startsWith(section.path)) ||
//                           (extraSubmenuHighlightPaths[section.title] &&
//                             extraSubmenuHighlightPaths[section.title].some((p) =>
//                               location.pathname.startsWith(p)
//                             ));

//                         return (
//                           <div key={section.title} className="flex flex-col relative pr-4">
//                             {section.path ? (
//                               <Link
//                                 to={section.path}
//                                 className={`font-semibold text-base mb-2 whitespace-nowrap hover:text-blue-600 transition-colors ${
//                                   isHeadingActive ? "text-darkblue1" : "text-black"
//                                 }`}
//                               >
//                                 {section.title}
//                               </Link>
//                             ) : (
//                               <h4
//                                 className={`font-semibold text-base mb-2 whitespace-nowrap transition-colors ${
//                                   isHeadingActive ? "text-darkblue1" : "text-black"
//                                 }`}
//                               >
//                                 {section.title}
//                               </h4>
//                             )}

//                             <ul>
//                               {section.links.map((link) => (
//                                 <li key={link.id}>
//                                   <Link
//                                     to={link.path}
//                                     className={`block text-sm py-1 px-2 rounded whitespace-nowrap hover:bg-grey2 transition-colors ${
//                                       location.pathname === link.path
//                                         ? "font-semibold text-darkblue1"
//                                         : "text-black"
//                                     }`}
//                                   >
//                                     {link.label}
//                                   </Link>
//                                 </li>
//                               ))}
//                             </ul>

//                             {/* Divider */}
//                             {index !== item.submenu.length - 1 && (
//                               <div className="absolute top-0 right-[-12px] w-px h-full bg-lightBlue" />
//                             )}
//                           </div>
//                         );
//                       })}
//                     </div>
//                   </div>
//                 )}
//               </div>
//             );
//           })}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SubNavbar;


import {
  Home,
  LayoutDashboard,
  Users,
  Database,
  MoreVertical,
} from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { useRef } from "react";

const SubNavbar = () => {
  const location = useLocation();
  const menuRef = useRef(null);

  const managementDropdown = [
    {
      title: "User Management",
      path: "/usermangement",
      links: [],
    },
    {
      title: "Log",
      links: [
        { id: "auth-log", label: "Authentication Log", path: "/authentication" },
        { id: "user-history", label: "User History", path: "/usermangement/user-history" },
      ],
    },
  ];

  const mastersDropdown = [
    { title: "Scorecard", path: "/scorecard", links: [] },
    { title: "PDP", path: "/masterpdphomepage", links: [] },
    { title: "Monthly Meeting", path: "/mastermothlymeeting", links: [] },
    { title: "Dealer Investment", path: "/masterdealerinvestment", links: [] },
    { title: "Dashboards", path: "/masterdashboard", links: [] },
    { title: "DFHM", path: "/masterdfhm", links: [] },
  ];

  const menuDropdown = [
    { title: "Monthly Meeting", path: "/monthlymeetinghomepage", links: [] },
    {
      title: "PDP",
      path: "/menu/pdp",
      links: [
        { id: "create-pdp", label: "Create New PDP", path: "/menu/pdp/create" },
        { id: "view-pdp", label: "View PDP", path: "/menu/pdp/view" },
        { id: "action-planner", label: "PDP Action Planner", path: "/menu/pdp/action-planner" },
        { id: "manage-branch", label: "Manage Branch Master", path: "/menu/pdp/branch-master" },
        { id: "consolidated", label: "Consolidated PDP", path: "/menu/pdp/consolidated" },
      ],
    },
    {
      title: "Dealer Investment",
      path: "/menu/dealerinvestment",
              links: [
                { id: "view-investment", label: "View Dealer Investment", path: "/menu/dealerinvestment/view" },
                { id: "infrastructure-reports", label: "Infrastructure Reports", path: "/menu/dealerinvestment/view" },
                { id: "allocation-dashboard", label: "Allocation-DashBoard", path: "/menu/dealerinvestment/view" },
                { id: "mbpdashboard", label: "MBP Dashboard V1", path: "/menu/dealerinvestment/view" }

      ],
    },
    { title: "Scorecard", path: "/menu/scorecard", links: [
                { id: "createreview", label: "Create Review", path: "/menu/dealerinvestment/view" },
                { id: "viewreviews", label: "View Reviews", path: "/menu/dealerinvestment/view" },
                { id: "scorecardresults", label: "ScoreCard Results", path: "/menu/dealerinvestment/view" },
                { id: "actionitems", label: "Action Items", path: "/menu/dealerinvestment/view" },

    ] },
    { title: "DFHM", path: "/menu/dfhm", links: [
                      { id: "viewdfhm", label: "View DFHM", path: "/menu/dealerinvestment/view" },
                      { id: "scorecardratio", label: "ScoreCard Ratio ", path: "/menu/dealerinvestment/view" },
                      { id: "viewquaterlymeeting", label: "View Quaterly Meeting", path: "/menu/dealerinvestment/view" },
                      { id: "createquaterlymeeting", label: "Create Quaterly Meeting", path: "/menu/dealerinvestment/view" },
                      { id: "dfhmdashboard", label: "DFHM Dashboard", path: "/menu/dealerinvestment/view" },

    ] },
  ];

  const menuItems = [
    {
      id: "home",
      label: "Home",
      icon: Home,
      activeIcon: () => (
        <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons\Sidebar\home active.png" alt="Home" className="w-5 h-5 object-contain" />
      ),
      path: "/homepage",
    },
   {
  id: "outlook",
  label: "Outlook",
  icon: LayoutDashboard,
  activeIcon: LayoutDashboard, // Use same icon
  path: "/outlook",
},

{
  id: "management",
  label: "Management",
  icon: Users,
  activeIcon: Users, // Use the same icon and apply filled styles dynamically
  path: "/usermangement",
  submenu: managementDropdown,
},

    {
      id: "masters",
      label: "Masters",
      icon: Database,
      activeIcon: () => (
        <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/masters-active.png" alt="Masters" className="w-4 h-4 object-contain" />
      ),
      submenu: mastersDropdown,
    },
    {
      id: "menu",
      label: "Menu",
      icon: MoreVertical,
      activeIcon: () => (
        <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/menu-active.png" alt="Menu" className="w-4 h-4 object-contain" />
      ),
      submenu: menuDropdown,
    },
  ];

  const extraHighlightPaths = {
    management: ["/userlogin", "/userdetails"],
    menu: ["/trendchart", "/actionitemview", "/monthlymeetingviewdetails"],
  };

  const extraSubmenuHighlightPaths = {
    "Monthly Meeting": [
      "/trendchart",
      "/actionitemview",
      "/monthlymeetingviewdetails",
    ],
  };

  const isMenuItemActive = (item) => {
    return (
      (item.path && location.pathname.startsWith(item.path)) ||
      (item.submenu &&
        item.submenu.some(
          (section) =>
            (section.path && location.pathname.startsWith(section.path)) ||
            section.links?.some((link) => location.pathname.startsWith(link.path)) ||
            (extraSubmenuHighlightPaths[section.title] &&
              extraSubmenuHighlightPaths[section.title].some((p) =>
                location.pathname.startsWith(p)
              ))
        )) ||
      (extraHighlightPaths[item.id]?.some((p) => location.pathname.startsWith(p)))
    );
  };

  return (
    <div
      className="hidden lg:block bg-grey2 border-t border-gray-300 w-full z-40 fixed top-20 "
      style={{ height: "70px" }}
    >
      <div className="max-w-screen-xl mx-auto h-full">
        <div className="flex justify-center gap-3 sm:gap-6 md:gap-8 h-full" ref={menuRef}>
          {menuItems.map((item) => {
            const isActiveMain = isMenuItemActive(item);
            const hasSubmenu = item.submenu && item.submenu.length > 0;
            const Icon = isActiveMain ? item.activeIcon : item.icon;

            return (
              <div
                key={item.id}
                className="relative group h-full flex items-center transition-all duration-200 hover:bg-white"
              >
                <Link
                  to={item.path || "#"}
                  className={`flex items-center gap-2 px-3 cursor-pointer h-full text-black ${
                    isActiveMain ? "font-medium bg-white shadow" : ""
                  }`}
                >
                  {typeof Icon === "function" ? (
                    <Icon />
                  ) : (
                    <Icon
                      size={16}
                      className={
                        isActiveMain ? "fill-black stroke-black" : "fill-none stroke-current"
                      }
                    />
                  )}
                  <span className="text-base">{item.label}</span>
                </Link>

                {hasSubmenu && (
                  // <div className="absolute top-full left-1/2 -translate-x-1/2 mt-0 hidden group-hover:flex bg-white shadow-lg z-50 min-w-[320px] p-4">
                    <div className="fixed top-[150px] left-1/2 -translate-x-1/2 mt-0 hidden group-hover:flex bg-white shadow-lg z-50 min-w-[320px] p-4">

                    <div className="flex gap-6 ">
                      {item.submenu.map((section, index) => {
                        const isHeadingActive =
                          (section.path && location.pathname.startsWith(section.path)) ||
                          (extraSubmenuHighlightPaths[section.title] &&
                            extraSubmenuHighlightPaths[section.title].some((p) =>
                              location.pathname.startsWith(p)
                            ));

                        return (
                          <div key={section.title} className="flex flex-col relative pr-4">
                            {section.path ? (
                              <Link
                                to={section.path}
                                className={`font-semibold text-base mb-2 whitespace-nowrap hover:text-SteelBlue1 transition-colors ${
                                  isHeadingActive ? "text-darkblue1" : "text-black"
                                }`}
                              >
                                {section.title}
                              </Link>
                            ) : (
                              <h4
                                className={`font-semibold text-base mb-2 whitespace-nowrap hover:text-SteelBlue1 transition-colors ${
                                  isHeadingActive ? "text-darkblue1" : "text-black"
                                }`}
                              >
                                {section.title}
                              </h4>
                            )}

                            <ul>
                              {section.links.map((link) => (
                                <li key={link.id}>
                                  <Link
                                    to={link.path}
                                    className={`block text-sm py-1 px-2 rounded whitespace-nowrap hover:bg-grey2 transition-colors ${
                                      location.pathname === link.path
                                        ? "font-semibold text-darkblue1"
                                        : "text-black"
                                    }`}
                                  >
                                    {link.label}
                                  </Link>
                                </li>
                              ))}
                            </ul>

                            {index !== item.submenu.length - 1 && (
                              <div className="absolute top-0 right-[-12px] w-[0.2px] h-full bg-lightBlue" />
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default SubNavbar;

