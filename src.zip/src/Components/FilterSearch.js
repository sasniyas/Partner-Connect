import React, { useState, useEffect, useRef } from 'react';

const FilterSearch = ({
  name,
  value,
  options = [],
  onChange,
  className = '',
  placeholder = '-Select-',
  placeholderColor = 'text-gray-400',
  buttonBorderColor = 'border-gray-300',
  dropdownBgColor = 'bg-white',
  dropdownTextColor = 'text-black',
  dropdownHoverColor = 'hover:bg-gray-100',
  dropdownBorderColor = 'border-gray-300',
  closedBgColor = 'bg-white',
  focusRingColor = 'ring-blue-500',
  hoverRingColor = 'ring-blue-300',
  openBgColor = '',
  textColor = 'text-gray-800',
  disableSorting = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const dropdownRef = useRef(null);

  const handleDropdownToggle = () => setIsOpen((prev) => !prev);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
        setSearchTerm('');
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

const processedOptions = disableSorting
  ? [...options]
  : [...options].sort((a, b) => String(a ?? "").localeCompare(String(b ?? "")));

  const filteredOptions = processedOptions.filter((option) =>
    option.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const shouldShowTooltip = value && value.length > 20;

  return (
    <div
      ref={dropdownRef}
      className={`relative w-full sm:w-48 md:w-56 lg:w-64 xl:w-72 ${className}`}
    >
      <button
        type="button"
        onClick={handleDropdownToggle}
        className={`h-10 flex items-center justify-between px-4 text-sm w-full gap-4
          ${isOpen ? `${openBgColor} rounded-t-md border-b-white` : `${closedBgColor} rounded-md`}
          border ${buttonBorderColor}
          ${!isOpen ? `focus:outline-none focus:ring-1 ${focusRingColor} hover:ring-1 ${hoverRingColor}` : ''}`}
        title={shouldShowTooltip ? value : ''}
      >
        <span className={`ml-[-10px] truncate ${value ? textColor : placeholderColor}`}>
          {value || placeholder}
        </span>
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/material-symbols-light_arrow-drop-down-rounded.png"
          alt="dropdown"
          className={`w-6 h-6 transform transition-transform duration-300 ${isOpen ? 'rotate-180' : 'rotate-0'}`}
        />
      </button>

      {isOpen && (
        <div
          className={`absolute w-full mt-0 ${dropdownBgColor} ${dropdownTextColor} border ${dropdownBorderColor}
            rounded-md rounded-t-none border-t-white shadow-lg z-20 max-h-60 overflow-y-auto`}
        >
          <div className="px-4 py-2">
            <input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-gray-300"
            />
          </div>
          <ul>
            {filteredOptions.length > 0 ? (
              filteredOptions.map((option, index) => (
                <li
                  key={index}
                  title={option.length > 20 ? option : ''}
                  className={`ml-[-6px] truncate px-4 py-2 text-sm cursor-pointer ${dropdownHoverColor} ${
                    index !== options.length - 1 ? 'mb-1' : ''
                  }`}
                  onClick={() => {
                    onChange(name, option);
                    setIsOpen(false);
                    setSearchTerm('');
                  }}
                >
                  {option}
                </li>
              ))
            ) : (
              <li className="px-4 py-2 text-sm text-gray-400">No options found</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default FilterSearch;
