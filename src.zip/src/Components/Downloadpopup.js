import React from "react";
import * as XLSX from "xlsx"; // Import xlsx library

// File Display Component with dynamically calculated initials from file name
const FileDisplay = ({ fileName, onDownload, showInitials = true, description }) => {
  // Function to get the first letter of the first two words in the file name
  const getFileInitials = (name) => {
    if (!name) return "NA"; // Return "NA" if name is empty
    const base = name.split(" "); // Split the file name by space
    if (base.length > 1) {
      // If there are more than one word, get the first letter of the first two words
      return base[0][0].toUpperCase() + base[1][0].toUpperCase();
    }
    // If there's only one word, just return the first letter of the word
    return base[0][0].toUpperCase();
  };

  // Get the initiator from fileName
  const initiator = getFileInitials(fileName);

  return (
    <div className="border border-dotted border-black p-4 rounded-md flex items-center gap-4">
      {/* Initiator */}
      <div className="flex items-center justify-center text-mildBlue text-base font-bold bg-ab rounded-md p-2">
        {initiator || "!"} {/* Default initiator */}
      </div>

      {/* Content */}
      <div className="flex-1">
        {/* Description */}
        {description && <p className="text-black text-xs mb-1 whitespace-normal">{description}</p>}

        {/* File Name */}
        <p
          className="text-mildBlue underline text-xs text-left cursor-pointer"
          onClick={() => onDownload(fileName)} // Trigger download on file name click
        >
          {fileName}
        </p>
      </div>
    </div>
  );
};

// Main Popup Component
const DownloadPopup = ({
  title,
  fileName,
  fileContent,
  description,
  onClose,
  lineColor,
  showInitials = true,
}) => {
  const handleDownload = (fileName) => {
    if (!fileContent || !Array.isArray(fileContent)) {
      alert("Invalid or empty data for download");
      return;
    }

    // Create a new workbook and add content
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(fileContent); // Converting JSON content into a sheet
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");

    // Download the Excel file
    XLSX.writeFile(wb, fileName || "file.xlsx");
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
      <div
        className={`bg-lightGrey rounded-2xl p-6 shadow-xl w-auto min-w-[300px] max-w-[90%] relative`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-500 hover:scale-110"
        >
                              <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" alt="close" className="w-4 h-4" />
        </button>

        {/* Reusable Heading */}
        <h2 className="text-lg font-medium mb-1 text-black">{title}</h2>

        {/* Reusable Line with dynamic color */}
        <hr className={`w-14 border-t-2 rounded ${lineColor} mb-6`} />

        {/* Reusable File Display */}
        <FileDisplay
          fileName={fileName}
          onDownload={handleDownload} // Pass the handleDownload function
          showInitials={showInitials}
          description={description} // Pass the dynamic description here
        />
      </div>
    </div>
  );
};

export default DownloadPopup;