import React from "react";

const DateChangeRequest = ({ isOpen, onCancel, onConfirm, message = "" }) => {
  if (!isOpen) return null;

  return (
   <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-sm sm:max-w-md md:max-w-lg border-l-8 border-green">
        <h3 className="flex items-center justify-center text-sm sm:text-base font-semibold rounded-md p-3 text-red1 bg-red2 mb-4 gap-2 text-center">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/warning.png" alt="warning" className="w-4 h-4" />
           {message}
        </h3>
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <button
            onClick={onCancel}
            className="border-2 border-red2 text-red px-4 sm:px-5 py-1.5 text-sm font-bold rounded-md hover:bg-red2 hover:shadow-md hover:scale-105 transition duration-200"
          >
            No
          </button>
          <button
            onClick={onConfirm}
            className="bg-green4 text-green5 text-sm border-2 border-transparent font-bold px-5 sm:px-6 py-1.5 rounded-md hover:bg-green4 hover:text-green5 hover:shadow-md hover:scale-105 hover:bg-white hover:border-green4 transition duration-200"
          >
            Yes
          </button>
        </div>
      </div>
    </div>
  );
};

export default DateChangeRequest;
