import React from 'react';

const SearchExtend = ({
  searchText,
  setSearchText,
  placeholder = 'Search...',
  iconSrc = 'https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/search.png',
  containerWidth = 'w-96',
  collapsedWidth = 'w-8',
}) => {
  const [showSearch, setShowSearch] = React.useState(false);

  const handleIconClick = (e) => {
    e.stopPropagation();
    if (showSearch) {
      setSearchText('');
    }
    setShowSearch(!showSearch);
  };

  return (
    <div
    className={`flex items-center border border-mildbrown rounded-md bg-white shadow-[0_4px_10px_rgba(86,_63,_110,_0.25)] transition-all duration-300 cursor-pointer ${
      showSearch
        ? `${containerWidth} px-2 py-2 hover:ring-1 hover:ring-mildbrown`
        : `${collapsedWidth} px-2 py-2 hover:scale-110`
    }`}
      onClick={() => setShowSearch(true)}
    >
      <img
        src={iconSrc}
        alt="Search"
        className="w-5 h-4 cursor-pointer"
        onClick={handleIconClick}
      />
      {showSearch && (
        <input
          type="text"
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          placeholder={placeholder}
          className="ml-2 font-normal w-full bg-transparent focus:outline-none text-sm"
        />
      )}
    </div>
  );
};

export default SearchExtend;
