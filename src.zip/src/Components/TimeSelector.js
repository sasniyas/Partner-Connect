"use client";
import { useState, useRef, useEffect, useCallback } from "react";

const TimeSelector = ({
  label,
  value,
  setValue,
  dropdownOpen,
  setDropdownOpen,
  dropdownRef,
  required = false,
  error,
}) => {
  const hours = Array.from({ length: 12 }, (_, i) =>
    String(i + 1).padStart(2, "0")
  );
  const dropdownMinutes = ["00", "15", "30", "45"];
  const periods = ["AM", "PM"];
  const itemHeight = 32;

  const hourRef = useRef(null);
  const minuteRef = useRef(null);
  const periodRef = useRef(null);
  const inputRef = useRef(null);

  const [selectedHourIndex, setSelectedHourIndex] = useState(0);
  const [selectedMinuteIndex, setSelectedMinuteIndex] = useState(0);
  const [selectedPeriodIndex, setSelectedPeriodIndex] = useState(0);
  const [inputValue, setInputValue] = useState("");
  const [isFocused, setIsFocused] = useState(false);
  const [inputError, setInputError] = useState("");

  const parseTime = useCallback((timeStr) => {
    if (!timeStr) return { h: "12", m: "00", p: "AM" };
    const match = timeStr.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
    if (match) {
      return {
        h: match[1].padStart(2, "0"),
        m: match[2],
        p: match[3].toUpperCase(),
      };
    }
    return { h: "12", m: "00", p: "AM" };
  }, []);

  useEffect(() => {
    if (!isFocused) {
      setInputValue(value || "");
    }
  }, [value, isFocused]);

  const scrollToIndex = (ref, index) => {
    if (!ref.current) return;
    ref.current.scrollTo({ top: index * itemHeight, behavior: "smooth" });
  };

  useEffect(() => {
    if (!dropdownOpen) return;

    if (!value) {
      setValue("12:00 AM");
      setInputValue("12:00 AM");
    }

    const { h, m, p } = parseTime(value || "12:00 AM");
    const hIndex = hours.indexOf(h);
    const mIndex = dropdownMinutes.indexOf(m);
    const pIndex = periods.indexOf(p);

    if (hIndex >= 0) {
      setSelectedHourIndex(hIndex);
      setTimeout(() => scrollToIndex(hourRef, hIndex), 50);
    }
    if (mIndex >= 0) {
      setSelectedMinuteIndex(mIndex);
      setTimeout(() => scrollToIndex(minuteRef, mIndex), 50);
    } else {
      // If current minute not in dropdown list, find closest
      const mNum = parseInt(m, 10);
      const closestIdx = dropdownMinutes.reduce((best, curr, idx) =>
        Math.abs(parseInt(curr, 10) - mNum) <
        Math.abs(parseInt(dropdownMinutes[best], 10) - mNum)
          ? idx
          : best, 0);
      setSelectedMinuteIndex(closestIdx);
      setTimeout(() => scrollToIndex(minuteRef, closestIdx), 50);
    }
    if (pIndex >= 0) {
      setSelectedPeriodIndex(pIndex);
      setTimeout(() => scrollToIndex(periodRef, pIndex), 50);
    }
  }, [dropdownOpen]);

  useEffect(() => {
    if (dropdownOpen && value) {
      setInputValue(value);
    }
  }, [value, dropdownOpen]);

  const handleScroll = (ref, list, type) => {
    if (!ref.current) return;
    const index = Math.round(ref.current.scrollTop / itemHeight);
    const selected = list[index];
    if (!selected) return;

    if (type === "hour") setSelectedHourIndex(index);
    if (type === "minute") setSelectedMinuteIndex(index);
    if (type === "period") setSelectedPeriodIndex(index);

    const { h, m, p } = parseTime(value || "12:00 AM");
    let newH = h, newM = m, newP = p;
    if (type === "hour") newH = selected;
    if (type === "minute") newM = selected;
    if (type === "period") newP = selected;

    setValue(`${newH}:${newM} ${newP}`);
  };

  // ═══════════════════════════════════════════════════════════════
  // MANUAL INPUT — any minute 00-59 allowed
  // ═══════════════════════════════════════════════════════════════

  const handleInputChange = (e) => {
    let raw = e.target.value;
    raw = raw.replace(/[^0-9:aAmMpP\s]/g, "");
    if (raw.length > 8) raw = raw.slice(0, 8);
    setInputValue(raw);
    setInputError("");
  };

 const handleInputKeyDown = (e) => {
  // ⏎ ENTER
  if (e.key === "Enter") {
    e.preventDefault();
    e.stopPropagation();

    if (!dropdownOpen) {
      // 🔥 OPEN CLOCK
      setDropdownOpen(true);
    } else {
      // if already open → confirm input
      commitInput();
      inputRef.current?.blur();
    }
  }

  // ❌ ESC
  if (e.key === "Escape") {
    e.preventDefault();
    e.stopPropagation();

    if (dropdownOpen) {
      // 🔥 CLOSE CLOCK
      setDropdownOpen(false);
    } else {
      setInputValue(value || "");
      setInputError("");
      inputRef.current?.blur();
    }
  }

  // ⬇️ DOWN → open
  if (e.key === "ArrowDown" && !dropdownOpen) {
    e.preventDefault();
    e.stopPropagation();
    setDropdownOpen(true);
  }
};
  const commitInput = () => {
    const trimmed = inputValue.trim();
    if (!trimmed) {
      setInputValue(value || "");
      setInputError("");
      return;
    }

    // Try with colon: "10:56 AM", "10:56AM", "1:30 PM"
    let match = trimmed.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);

    // Try without colon: "1056AM", "1056 AM", "130PM"
    if (!match) {
      const noColon = trimmed.match(/^(\d{1,4})\s*(AM|PM)$/i);
      if (noColon) {
        const digits = noColon[1];
        const period = noColon[2];
        if (digits.length === 3) {
          match = `${digits[0]}:${digits.slice(1)} ${period}`.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
        } else if (digits.length === 4) {
          match = `${digits.slice(0, 2)}:${digits.slice(2)} ${period}`.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
        }
      }
    }

    if (!match) {
      setInputError("Format: HH:MM AM/PM");
      setInputValue(value || "");
      setTimeout(() => setInputError(""), 2500);
      return;
    }

    const h = parseInt(match[1], 10);
    const m = parseInt(match[2], 10);
    const p = match[3].toUpperCase();

    if (h < 1 || h > 12) {
      setInputError("Hour must be 1–12");
      setInputValue(value || "");
      setTimeout(() => setInputError(""), 2500);
      return;
    }

    if (m < 0 || m > 59) {
      setInputError("Minutes must be 00–59");
      setInputValue(value || "");
      setTimeout(() => setInputError(""), 2500);
      return;
    }

    const final = `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")} ${p}`;
    setValue(final);
    setInputValue(final);
    setInputError("");
  };

  const handleInputFocus = () => {
    setIsFocused(true);
    setInputError("");
    if (dropdownOpen) {
      setDropdownOpen(false);
    }
    setTimeout(() => {
      inputRef.current?.select();
    }, 0);
  };

  const handleInputBlur = () => {
    setIsFocused(false);
    commitInput();
  };

  const handleClockClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setInputError("");
    if (isFocused) {
      inputRef.current?.blur();
    }
    setTimeout(() => {
      setDropdownOpen(!dropdownOpen);
    }, 10);
  };

  const showError = (error && !value) || inputError;
  const displayError = inputError || error;

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <label className="block text-xs font-medium text-black/70 mb-1">
        {label} {required && <span className="text-red1">*</span>}
      </label>

      <div className="relative w-full">
        <input
          ref={inputRef}
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          onKeyDown={handleInputKeyDown}
          onFocus={handleInputFocus}
          onBlur={handleInputBlur}
          placeholder="HH:MM AM"
          maxLength={8}
          autoComplete="off"
          className={`border w-full  text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all cursor-text bg-transparent
            ${showError ? "border-red1 focus:ring-red1" : isFocused ? "border-black/30 ring-1 ring-black/30" : dropdownOpen ? "border-black border-b-white" : "border-black/30 focus:ring-black/30"}
            ${!inputValue && !isFocused ? "text-gray-400" : "text-black"}`}
        />

        <button
          type="button"
          onMouseDown={handleClockClick}
          className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 hover:bg-gray-50 rounded transition-colors"
          tabIndex={-1}
          title="Open time picker"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            className={`w-4 h-4 transition-colors ${dropdownOpen ? "text-black" : "text-gray-500 hover:text-black"}`}
          >
            <circle cx="12" cy="12" r="9" />
            <path d="M12 7v5l3 2" />
          </svg>
        </button>
      </div>

      {/* Wheel Picker Dropdown */}
      {dropdownOpen && (
        <div className="absolute left-0 top-full w-full mt-0 bg-white border border-black border-t-white shadow-lg z-50">
          <div className="flex h-24 relative overflow-hidden text-center text-sm">
            <div className="absolute top-1/2 left-0 w-full h-8 -translate-y-1/2 bg-MediumGrey/10 pointer-events-none z-10" />

            {/* HOURS */}
            <div
              ref={hourRef}
              onScroll={() => handleScroll(hourRef, hours, "hour")}
              className="w-1/3 overflow-y-scroll snap-y snap-mandatory scrollbar-hide"
            >
              <div style={{ height: itemHeight }} />
              {hours.map((h, i) => (
                <div
                  key={h}
                  onClick={() => {
                    setSelectedHourIndex(i);
                    scrollToIndex(hourRef, i);
                    const { m, p } = parseTime(value || "12:00 AM");
                    setValue(`${h}:${m} ${p}`);
                  }}
                  className={`h-8 flex items-center justify-center snap-center cursor-pointer transition-colors
                    ${i === selectedHourIndex ? "text-black font-semibold text-xs" : "text-gray-400 hover:text-gray-600"}`}
                >
                  {h}
                </div>
              ))}
              <div style={{ height: itemHeight }} />
            </div>

            {/* MINUTES — dropdown only shows 00, 15, 30, 45 */}
            <div
              ref={minuteRef}
              onScroll={() => handleScroll(minuteRef, dropdownMinutes, "minute")}
              className="w-1/3 overflow-y-scroll snap-y snap-mandatory scrollbar-hide border-x border-gray-100"
            >
              <div style={{ height: itemHeight }} />
              {dropdownMinutes.map((m, i) => (
                <div
                  key={m}
                  onClick={() => {
                    setSelectedMinuteIndex(i);
                    scrollToIndex(minuteRef, i);
                    const { h, p } = parseTime(value || "12:00 AM");
                    setValue(`${h}:${m} ${p}`);
                  }}
                  className={`h-8 flex items-center justify-center snap-center cursor-pointer transition-colors
                    ${i === selectedMinuteIndex ? "text-black font-semibold text-xs" : "text-gray-400 hover:text-gray-600"}`}
                >
                  {m}
                </div>
              ))}
              <div style={{ height: itemHeight }} />
            </div>

            {/* PERIOD */}
            <div
              ref={periodRef}
              onScroll={() => handleScroll(periodRef, periods, "period")}
              className="w-1/3 overflow-y-scroll snap-y snap-mandatory scrollbar-hide"
            >
              <div style={{ height: itemHeight }} />
              {periods.map((p, i) => (
                <div
                  key={p}
                  onClick={() => {
                    setSelectedPeriodIndex(i);
                    scrollToIndex(periodRef, i);
                    const { h, m } = parseTime(value || "12:00 AM");
                    setValue(`${h}:${m} ${p}`);
                  }}
                  className={`h-8 flex items-center justify-center snap-center cursor-pointer transition-colors
                    ${i === selectedPeriodIndex ? "text-black font-semibold text-xs" : "text-gray-400 hover:text-gray-600"}`}
                >
                  {p}
                </div>
              ))}
              <div style={{ height: itemHeight }} />
            </div>
          </div>
        </div>
      )}

      {displayError && !dropdownOpen && !isFocused && (
        <p className="text-xs text-red1 mt-1">{displayError}</p>
      )}
    </div>
  );
};

export default TimeSelector;