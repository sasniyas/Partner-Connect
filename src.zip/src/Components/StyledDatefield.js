import { useRef } from "react";
import { FaRegCalendarAlt } from "react-icons/fa";

export default function StyledDateField({
  label,
  value,
  setValue,
  error,
   required = false,   // 👈 add this
}) {
  const inputRef = useRef(null);

  const today = new Date().toISOString().split("T")[0];

  const openDatePicker = () => {
    if (inputRef.current?.showPicker) {
      inputRef.current.showPicker();
    } else {
      inputRef.current?.focus();
    }
  };

  return (
    <div className="mb-2 relative">
      <label className="block text-xs font-medium text-black/70 mb-1">
         {label}
        {required && <span className="text-red1 ml-1">*</span>}
      </label>

      <div
        className={`relative w-full border  px-3 py-1 flex items-center cursor-pointer ${
          error ? "border-red1" : "border-black/30"
        }`}
        tabIndex={0}
        onClick={openDatePicker} // click anywhere opens calendar
      >
        <input
          ref={inputRef}
          type="date"
          value={value || ""}
          min={today}
          onChange={(e) => setValue(e.target.value)}
          className="w-full text-xs bg-transparent outline-none cursor-pointer"
        />

        <FaRegCalendarAlt
          className="absolute right-3 top-1/2 -translate-y-1/2 cursor-pointer text-black text-xs"
          onClick={(e) => {
            e.stopPropagation();
            openDatePicker();
          }}
        />
      </div>

      {error && <p className="text-xs text-red1 mt-1">{error}</p>}
    </div>
  );
}
