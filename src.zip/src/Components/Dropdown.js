// import React, { useState } from "react";

// const Dropdown = ({
//   label = "Select Option",
//   options = [],
//   selectedOption = "",
//   onSelect,
//   placeholder = "Select an option",
// }) => {
//   const [isOpen, setIsOpen] = useState(false);

//   const handleSelect = (option) => {
//     onSelect(option);
//     setIsOpen(false);
//   };

//   return (
//     <div className="mb-4 relative">
//       {label && <label className="block text-sm font-medium text-black mb-1">{label}</label>}
      
//       {/* Dropdown Button */}
//       <div
//         className={`w-full border ${
//           isOpen ? "border-black/50 border-b-white rounded-b-none" : "border-black/50"
//         } rounded-md px-3 py-2 text-sm focus:outline focus:ring-1 ${
//           isOpen ? "focus:ring-black/50" : "focus:ring-black/50"
//         }`}
//         onClick={() => setIsOpen(!isOpen)}
//       >
//         <div className="flex items-center justify-between cursor-pointer">
//         <span
//             className={`${
//               selectedOption ? "text-black" : "text-grey"
//             }`} // Apply gray color for placeholder and black for selected text
//           >
//             {selectedOption || placeholder}
//           </span>          
//           <img
//             src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/dropdown.png"
//             alt="Dropdown Arrow"
//             className={`w-4 h-4 transform ${isOpen ? "rotate-180" : "rotate-0"} transition-transform`}
//           />
//         </div>
//       </div>

//       {/* Dropdown List */}
//       {isOpen && (
//         <ul className="absolute z-10 mt-0 w-full bg-white border border-black/50 rounded-t-none border-t-white rounded-md shadow-lg max-h-40 overflow-auto">
//           {options.map((option, index) => (
//             <li
//               key={index}
//               className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-lightBlue cursor-pointer"
//               onClick={() => handleSelect(option)}
//             >
//               {option}
//             </li>
//           ))}
//         </ul>
//       )}
//     </div>
//   );
// };

// export default Dropdown;


import React, { useState } from "react";

const Dropdown = ({
  label = "Select Option",
  options = [],
  selectedOption = "",
  onSelect,
  placeholder = "Select an option",
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (option) => {
    onSelect(option);
    setIsOpen(false);
  };

  return (
    <div className="mb-4 relative">
      {/* Label */}
      {label && <label className="block text-sm font-medium text-black mb-1">{label}</label>}

      {/* Dropdown Button */}
      <div
        tabIndex={0} // Make the div focusable
        className={`w-full border ${
          isOpen ? "border-black/50 border-b-white rounded-b-none" : "border-black/50"
        } rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 ${
          isOpen ? "focus:ring-black/50" : "focus:ring-black/50"
        }`}
        onClick={() => setIsOpen(!isOpen)}
        onBlur={() => setIsOpen(false)} // Close dropdown when focus is lost
      >
        <div className="flex items-center justify-between cursor-pointer">
          <span
            className={`${
              selectedOption ? "text-black" : "text-gray-400"
            }`} // Apply gray color for placeholder and black for selected text
          >
            {selectedOption || placeholder}
          </span>
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/dropdown.png"
            alt="Dropdown Arrow"
            className={`w-4 h-4 transform ${isOpen ? "rotate-180" : "rotate-0"} transition-transform`}
          />
        </div>
      </div>

      {/* Dropdown List */}
      {isOpen && (
        <ul className="absolute z-10 mt-0 w-full bg-white border border-black/50 rounded-t-none border-t-white rounded-md shadow-lg max-h-40 overflow-auto">
          {options.map((option, index) => (
            <li
              key={index}
              className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-lightBlue cursor-pointer"
              onClick={() => handleSelect(option)}
            >
              {option}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Dropdown;