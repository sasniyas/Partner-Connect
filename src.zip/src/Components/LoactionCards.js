import React from "react";

const dummyBranches = [
  {
    city: "Mumbai",
    location: "Andheri West",
    address: "123, Main Street, Andheri West, Mumbai",
    mapLink: "https://www.google.com/maps?q=Andheri+West+Mumbai",
  },
  {
    city: "Delhi",
    location: "Connaught Place",
    address: "456, Connaught Place, New Delhi",
    mapLink: "https://www.google.com/maps?q=Connaught+Place+Delhi",
  },
  {
    city: "Bangalore",
    location: "Whitefield",
    address: "789, Whitefield Road, Bangalore",
    mapLink: "https://www.google.com/maps?q=Whitefield+Bangalore",
  },
  {
    city: "Chennai",
    location: "T. Nagar",
    address: "101, T. Nagar, Chennai",
    mapLink: "https://www.google.com/maps?q=T+Nagar+Chennai",
  },
];

const LocationCards = () => {
  return (
    <div className="p-2">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
        {dummyBranches.map((branch, index) => (
          <div
            key={index}
            className="border border-grey1 p-4 bg-grey3 flex flex-col items-center text-center shadow-sm bg-white"
          >
            {/* Placeholder image for branch */}
            
            <h3 className="font-semibold text-black  text-sm mb-1">{branch.city}</h3>
            <p className="text-xs text-gray-400 mb-1">{branch.location}</p>
            {branch.mapLink ? (
              <a
                href={branch.mapLink}
                target="_blank"
                rel="noreferrer"
                className="text-darkblue1  text-xs"
              >
                View Location
              </a>
            ) : (
              <p className="text-gray-400 text-xs">No map link</p>
            )}
                        <p className="text-xs text-gray-400 mb-2">{branch.address}</p>

          </div>
        ))}
      </div>
    </div>
  );
};

export default LocationCards;
