/**
 * Process Management Template Service
 * Handles API calls for Process Management Templates module
 */

import axios from "axios";
import { API } from "../../api";

const { domain } = API;
const endpoints = API.processManagementTemplateEndpoints;

// ============================================
// UTILITY FUNCTIONS
// ============================================

const getAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

const getMultipartAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    ...(token && { Authorization: `Bearer ${token}` }),
    // NOTE: Do NOT set Content-Type for FormData - axios sets it automatically
  };
};

// ============================================
// API FUNCTIONS
// ============================================

/**
 * Add a new Process Management Template
 * @param {Object} templateData - { template_name, department_id, description, valid_till }
 * @param {File} file - Template file to upload
 */
export const addProcessManagementTemplate = async (templateData, file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const formData = new FormData();
    formData.append("template_name", templateData.template_name);
    formData.append("department_id", templateData.department_id);
    formData.append("description", templateData.description);
    formData.append("valid_till", templateData.valid_till);
    
    if (file) {
      formData.append("file", file);
    }

    const response = await axios.post(
      `${domain}${endpoints.addProcessManagementTemplate}`,
      formData,
      { headers: getMultipartAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding process management template:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add template"
    );
  }
};

/**
 * Get all Process Management Templates
 */
export const getAllProcessManagementTemplates = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${domain}${endpoints.getAllProcessManagementTemplates}`,
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    throw new Error(response.data?.message || "Failed to fetch templates");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching process management templates:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch templates"
    );
  }
};

/**
 * Get Process Management Template by ID
 * @param {number} id - Template ID
 */
export const getProcessManagementTemplateById = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${domain}${endpoints.getProcessManagementTemplateById}${id}`,
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to fetch template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching process management template:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch template"
    );
  }
};

/**
 * Update Process Management Template
 * @param {Object} templateData - { id, template_name, department_id, description, valid_till, isActive }
 * @param {File} file - Optional new file to upload
 */
export const updateProcessManagementTemplate = async (templateData, file = null) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const formData = new FormData();
    formData.append("id", templateData.id);
    
    if (templateData.template_name !== undefined) {
      formData.append("template_name", templateData.template_name);
    }
    if (templateData.department_id !== undefined) {
      formData.append("department_id", templateData.department_id);
    }
    if (templateData.description !== undefined) {
      formData.append("description", templateData.description);
    }
    if (templateData.valid_till !== undefined) {
      formData.append("valid_till", templateData.valid_till);
    }
    if (templateData.isActive !== undefined) {
      formData.append("isActive", templateData.isActive);
    }
    if (file) {
      formData.append("file", file);
    }

    const response = await axios.put(
      `${domain}${endpoints.updateProcessManagementTemplate}`,
      formData,
      { headers: getMultipartAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to update template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating process management template:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update template"
    );
  }
};

/**
 * Delete Process Management Template (soft delete)
 * @param {number} id - Template ID
 */
export const deleteProcessManagementTemplate = async (id) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.delete(
      `${domain}${endpoints.deleteProcessManagementTemplate}${id}`,
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to delete template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting process management template:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete template"
    );
  }
};

/**
 * Toggle Process Management Template Status (Active/Inactive)
 * @param {number} id - Template ID
 */
export const toggleProcessManagementTemplateStatus = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.patch(
      `${domain}${endpoints.toggleProcessManagementTemplateStatus}${id}`,
      {},
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to toggle template status");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling process management template status:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle status"
    );
  }
};

/**
 * Bulk Add Process Management Templates
 * @param {Array} rows - Array of template objects
 */
export const bulkAddProcessManagementTemplates = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.post(
      `${domain}${endpoints.bulkAddProcessManagementTemplates}`,
      { rows },
      { headers: getAuthHeaders() }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add templates");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding process management templates:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add templates"
    );
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Transform API data to table format
 * @param {Array} apiData - Data from API
 * @returns {Array} - Transformed data for table
 */
export const transformTemplateData = (apiData) => {
  if (!apiData || !Array.isArray(apiData)) return [];

  return apiData.map((item) => ({
    id: item.id,
    templateName: item.template_name,
    departmentId: item.department_id,
    department: item.department_name || "",
    description: item.description,
    templateFile: item.template_file,
    validTill: item.valid_till ? item.valid_till.split("T")[0] : "",
    uploadedBy: `${item.uploader_first_name || ""} ${item.uploader_last_name || ""}`.trim() || "Unknown",
    uploadedById: item.uploaded_by,
    uploadedDate: item.created_at ? item.created_at.split(" ")[0] : "",
    status: item.isActive === 1 ? "Active" : "Inactive",
    isActive: item.isActive,
  }));
};

/**
 * Extract file name from URL
 * @param {string} fileUrl - Full file URL
 * @returns {string} - File name
 */
export const extractFileName = (fileUrl) => {
  if (!fileUrl) return "";
  
  const parts = fileUrl.split("/");
  let fileName = parts[parts.length - 1];
  
  // Remove query parameters if present
  if (fileName.includes("?")) {
    fileName = fileName.split("?")[0];
  }
  
  // Decode URL encoding
  try {
    fileName = decodeURIComponent(fileName);
  } catch (e) {
    // If decoding fails, use as is
  }
  
  return fileName;
};

/**
 * Format date for API (YYYY-MM-DD)
 * @param {string} dateString - Date string
 * @returns {string} - Formatted date
 */
export const formatDateForAPI = (dateString) => {
  if (!dateString) return "";
  
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;
  
  return date.toISOString().split("T")[0];
};