/**
 * Process Management Policy Service
 * Handles API calls for Process Management Policies module
 */

import axios from "axios";
import { API } from "../../api";

const { domain } = API;
const endpoints = API.processManagementPolicyEndpoints;

// ============================================
// UTILITY FUNCTIONS
// ============================================

const getAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

const getMultipartAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// ============================================
// API FUNCTIONS
// ============================================

/**
 * Add a new Process Management Policy
 * @param {Object} policyData - { process_no, policy, department_id, effective_date, description, valid_till }
 * @param {File} file - Template file to upload
 */
export const addProcessManagementPolicy = async (policyData, file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const formData = new FormData();
    formData.append("process_no", policyData.process_no);
    formData.append("policy", policyData.policy);
    formData.append("department_id", policyData.department_id);
    formData.append("effective_date", policyData.effective_date);
    formData.append("description", policyData.description);
    formData.append("valid_till", policyData.valid_till);

    if (file) {
      formData.append("file", file);
    }

    const response = await axios.post(
      `${domain}${endpoints.addProcessManagementPolicy}`,
      formData,
      { headers: getMultipartAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add policy");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding process management policy:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add policy"
    );
  }
};

/**
 * Get all Process Management Policies
 */
export const getAllProcessManagementPolicies = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${domain}${endpoints.getAllProcessManagementPolicies}`,
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    throw new Error(response.data?.message || "Failed to fetch policies");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching process management policies:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch policies"
    );
  }
};

/**
 * Get Process Management Policy by ID
 * @param {number} id - Policy ID
 */
export const getProcessManagementPolicyById = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${domain}${endpoints.getProcessManagementPolicyById}${id}`,
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to fetch policy");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching process management policy:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch policy"
    );
  }
};

/**
 * Update Process Management Policy
 * @param {Object} policyData - { id, process_no, policy, department_id, effective_date, description, valid_till, isActive }
 * @param {File} file - Optional new file to upload
 */
export const updateProcessManagementPolicy = async (policyData, file = null) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const formData = new FormData();
    formData.append("id", policyData.id);

    if (policyData.process_no !== undefined) {
      formData.append("process_no", policyData.process_no);
    }
    if (policyData.policy !== undefined) {
      formData.append("policy", policyData.policy);
    }
    if (policyData.department_id !== undefined) {
      formData.append("department_id", policyData.department_id);
    }
    if (policyData.effective_date !== undefined) {
      formData.append("effective_date", policyData.effective_date);
    }
    if (policyData.description !== undefined) {
      formData.append("description", policyData.description);
    }
    if (policyData.valid_till !== undefined) {
      formData.append("valid_till", policyData.valid_till);
    }
    if (policyData.isActive !== undefined) {
      formData.append("isActive", policyData.isActive);
    }
    if (file) {
      formData.append("file", file);
    }

    const response = await axios.put(
      `${domain}${endpoints.updateProcessManagementPolicy}`,
      formData,
      { headers: getMultipartAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to update policy");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating process management policy:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update policy"
    );
  }
};

/**
 * Delete Process Management Policy (soft delete)
 * @param {number} id - Policy ID
 */
export const deleteProcessManagementPolicy = async (id) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.delete(
      `${domain}${endpoints.deleteProcessManagementPolicy}${id}`,
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to delete policy");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting process management policy:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete policy"
    );
  }
};

/**
 * Toggle Process Management Policy Status (Active/Inactive)
 * @param {number} id - Policy ID
 */
export const toggleProcessManagementPolicyStatus = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.patch(
      `${domain}${endpoints.toggleProcessManagementPolicyStatus}${id}`,
      {},
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to toggle policy status");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling process management policy status:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle status"
    );
  }
};

/**
 * Bulk Add Process Management Policies
 * @param {Array} rows - Array of policy objects
 */
export const bulkAddProcessManagementPolicies = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.post(
      `${domain}${endpoints.bulkAddProcessManagementPolicies}`,
      { rows },
      { headers: getAuthHeaders() }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add policies");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding process management policies:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add policies"
    );
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Transform API data to table format
 * @param {Array} apiData - Data from API
 * @returns {Array} - Transformed data for table
 */
export const transformPolicyData = (apiData) => {
  if (!apiData || !Array.isArray(apiData)) return [];

  return apiData.map((item) => ({
    id: item.id,
    policyNo: item.process_no,
    schemeName: item.policy,
    departmentId: item.department_id,
    department: item.department_name || "",
    effectiveDate: item.effective_date ? item.effective_date.split("T")[0] : "",
    description: item.description,
    validTill: item.valid_till ? item.valid_till.split("T")[0] : "",
    templateFile: item.template_file,
    uploadedBy: `${item.uploader_first_name || ""} ${item.uploader_last_name || ""}`.trim() || "Unknown",
    uploadedById: item.uploaded_by,
    uploadedDate: item.created_at ? item.created_at.split(" ")[0] : "",
    status: item.isActive === 1 ? "Active" : "Inactive",
    isActive: item.isActive,
    active: item.isActive === 1 ? "Yes" : "No",
  }));
};

/**
 * Extract file name from URL
 * @param {string} fileUrl - Full file URL
 * @returns {string} - File name
 */
export const extractFileName = (fileUrl) => {
  if (!fileUrl) return "";

  const parts = fileUrl.split("/");
  let fileName = parts[parts.length - 1];

  if (fileName.includes("?")) {
    fileName = fileName.split("?")[0];
  }

  try {
    fileName = decodeURIComponent(fileName);
  } catch (e) {
    // If decoding fails, use as is
  }

  return fileName;
};