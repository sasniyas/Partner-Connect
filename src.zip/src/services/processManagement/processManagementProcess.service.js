import axios from "axios";
import { API } from "../../api";

const { domain, processManagementProcessEndpoints } = API;

// ===================== HELPER FUNCTIONS =====================

const getAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

const getMultipartAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// Transform API data to table format
export const transformProcessData = (apiData) => {
  if (!Array.isArray(apiData)) return [];

  return apiData.map((item) => ({
    id: item.id,
    processNo: item.process_id,
    processName: item.process_name,
    departmentId: item.department_id,
    department: item.department_name || "",
    processOwner: item.process_owner,
    description: item.description,
    processFile: item.process_file,
    uploadedBy: `${item.uploader_first_name || ""} ${item.uploader_last_name || ""}`.trim() || "Unknown",
    uploadedById: item.uploaded_by,
    uploadedDate: item.created_at ? item.created_at.split(" ")[0] : "",
    lastModifiedBy: `${item.modifier_first_name || ""} ${item.modifier_last_name || ""}`.trim() || "Unknown",
    lastModifiedById: item.last_modified_by,
    lastModifiedDate: item.updated_at ? item.updated_at.split(" ")[0] : "",
    status: item.isActive === 1 ? "Active" : "Inactive",
    isActive: item.isActive,
    active: item.isActive === 1 ? "Yes" : "No",
  }));
};

// Extract filename from URL
export const extractFileName = (fileUrl) => {
  if (!fileUrl) return "";
  try {
    const url = new URL(fileUrl);
    const pathname = url.pathname;
    const fileName = pathname.split("/").pop();
    return decodeURIComponent(fileName);
  } catch {
    return fileUrl.split("/").pop() || "";
  }
};

// ===================== API FUNCTIONS =====================

// Add Process
export const addProcessManagementProcess = async (processData, file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const formData = new FormData();
    formData.append("process_id", processData.process_id);
    formData.append("process_name", processData.process_name);
    formData.append("department_id", processData.department_id);
    formData.append("process_owner", processData.process_owner);
    formData.append("description", processData.description);

    if (file) {
      formData.append("file", file);
    }

    const response = await axios.post(
      `${domain}${processManagementProcessEndpoints.addProcessManagementProcess}`,
      formData,
      { headers: getMultipartAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add process");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding process:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add process"
    );
  }
};

// Get All Processes
export const getAllProcessManagementProcesses = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${domain}${processManagementProcessEndpoints.getAllProcessManagementProcesses}`,
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    throw new Error(response.data?.message || "Failed to fetch processes");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching processes:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch processes"
    );
  }
};

// Get Process By ID
export const getProcessManagementProcessById = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${domain}${processManagementProcessEndpoints.getProcessManagementProcessById}${id}`,
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to fetch process");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching process:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch process"
    );
  }
};

// Update Process
export const updateProcessManagementProcess = async (processData, file) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const formData = new FormData();
    formData.append("id", processData.id);

    if (processData.process_id !== undefined) {
      formData.append("process_id", processData.process_id);
    }
    if (processData.process_name !== undefined) {
      formData.append("process_name", processData.process_name);
    }
    if (processData.department_id !== undefined) {
      formData.append("department_id", processData.department_id);
    }
    if (processData.process_owner !== undefined) {
      formData.append("process_owner", processData.process_owner);
    }
    if (processData.description !== undefined) {
      formData.append("description", processData.description);
    }

    if (file) {
      formData.append("file", file);
    }

    const response = await axios.put(
      `${domain}${processManagementProcessEndpoints.updateProcessManagementProcess}`,
      formData,
      { headers: getMultipartAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to update process");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating process:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update process"
    );
  }
};

// Delete Process
export const deleteProcessManagementProcess = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.delete(
      `${domain}${processManagementProcessEndpoints.deleteProcessManagementProcess}${id}`,
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to delete process");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting process:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete process"
    );
  }
};

// Toggle Process Status
export const toggleProcessManagementProcessStatus = async (id) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.patch(
      `${domain}${processManagementProcessEndpoints.toggleProcessManagementProcessStatus}${id}`,
      {},
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to toggle process status");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling process status:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle process status"
    );
  }
};

// Bulk Add Processes - CORRECT ENDPOINT
export const bulkAddProcessManagementProcesses = async (rows) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    // Call the BULK endpoint - NOT the single add endpoint
    const response = await axios.post(
      `${domain}${processManagementProcessEndpoints.bulkAddProcessManagementProcesses}`,
      { rows }, // Backend expects { rows: [...] }
      { headers: getAuthHeaders() }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add processes");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
            
    console.error("Error bulk adding processes:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add processes"
    );
  }
};