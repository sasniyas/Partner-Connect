import axios from 'axios';
import { API } from '../../api';

// Add Equipment Multiplier
export const addEquipmentMlp = async (equipmentMlp) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.addEquipmentMlp}`,
      equipmentMlp,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add equipment multiplier");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding equipment multiplier:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add equipment multiplier");
  }
};

// Get All Equipment Multipliers
export const getEquipmentsMlp = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getEquipmentsMlp}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to get equipment multipliers");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting equipment multipliers:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to get equipment multipliers");
  }
};

// Update Equipment Multiplier
export const updateEquipmentMlp = async (equipmentMlpId, equipmentMlp) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    
    const payload = {
      id: parseInt(equipmentMlpId),
      type: String(equipmentMlp.type),
      multiplier: parseInt(equipmentMlp.multiplier)
    };

    console.log("Update payload being sent:", payload); // Debug log

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateEquipmentMlp}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to update equipment multiplier");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating equipment multiplier:", error);
    console.error("Error response:", error.response?.data); // Debug log
    throw new Error(error.response?.data?.message || error.message || "Failed to update equipment multiplier");
  }
};

// Toggle Equipment Multiplier (Active/Inactive)
export const toggleEquipmentMlp = async (equipmentMlpId) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleEquipmentMlp}${equipmentMlpId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to toggle equipment multiplier");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling equipment multiplier:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle equipment multiplier");
  }
};

// Delete Equipment Multiplier
export const deleteEquipmentMlp = async (equipmentMlpId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteEquipmentMlp}${equipmentMlpId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to delete equipment multiplier");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting equipment multiplier:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete equipment multiplier");
  }
};