import axios from "axios";
import { API } from "../../../api";

/**
 * Fetch all PDP Others records for a specific PDP ID
 * @param {number} pdpId - The PDP ID
 * @returns {Promise<Array>} Array of PDP Others records
 */
export const getPdpOthersByPdpId = async (pdpId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getPdpOthersByPdpId}${pdpId}`;
    console.log("📡 Fetching PDP Others - URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("📦 API Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    throw new Error(response.data.message || "Failed to fetch PDP Others data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getPdpOthersByPdpId Error:", error);
    
  

    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Others data"
    );
  }
};

/**
 * Update PDP Others record with optional document upload
 * @param {number} id - The pdp_others record ID
 * @param {File|null} file - The file to upload (null to clear)
 * @returns {Promise<Object>} Response data
 */
export const updatePdpOthers = async (id, file = null) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const formData = new FormData();
    formData.append("id", id);
    
    if (file) {
      formData.append("files", file);
    }

    const url = `${API.domain}${API.createPdpendpoints.updatePdpOthers}`;
    console.log("📡 Updating PDP Others - URL:", url);

    const response = await axios.put(url, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update PDP Others");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updatePdpOthers Error:", error);
    
   

    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to update PDP Others"
    );
  }
};

/**
 * Delete a PDP Others record
 * @param {number} id - The pdp_others record ID
 * @returns {Promise<Object>} Response data
 */
export const deletePdpOthers = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.deletePdpOthers}${id}`;
    console.log("📡 Deleting PDP Others - URL:", url);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete PDP Others");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ deletePdpOthers Error:", error);
    
  
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to delete PDP Others"
    );
  }
};