import axios from "axios";
import { API } from "../../../../../api";

// ====================== PDP Infrastructure Assets CRUD ======================= //

/**
 * Add a new PDP Infrastructure Asset
 * @param {Object} payload - PDP Infrastructure Asset data
 * @param {number} payload.pdpId - PDP ID (required)
 * @param {number} payload.pdpInfrastructureId - PDP Infrastructure ID (required)
 * @param {string} payload.asset_type - Asset type (required)
 * @param {number} payload.quantity - Quantity (required)
 * @param {number} [payload.yop] - Year of production/purchase (optional)
 * @param {string} payload.available - Available status (required)
 * @param {string} [payload.assigned_to] - Person assigned to asset (optional)
 * @returns {Promise<Object>} Response object with status and message
 */
export const addPdpInfrastructureAsset = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    // Validate required fields
    if (!payload.pdpId || !payload.pdpInfrastructureId || !payload.asset_type || 
        !payload.quantity || !payload.available) {
      throw new Error("Required fields: pdpId, pdpInfrastructureId, asset_type, quantity, available");
    }

    const response = await axios.post(
      `${API.domain}${API.pdpInfrastructureAssetsEndpoints.addPdpInfrastructureAsset}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message || "Failed to add PDP Infrastructure Asset"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to add PDP Infrastructure Asset"
    );
  }
};

/**
 * Get all PDP Infrastructure Assets
 * @returns {Promise<Array>} Array of PDP Infrastructure Asset records with joined data
 */
export const getAllPdpInfrastructureAssets = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureAssetsEndpoints.getAllPdpInfrastructureAssets}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Asset list"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Asset list"
    );
  }
};

/**
 * Get PDP Infrastructure Asset by ID
 * @param {number|string} id - PDP Infrastructure Asset ID
 * @returns {Promise<Object>} PDP Infrastructure Asset record with joined data
 */
export const getPdpInfrastructureAssetById = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP Infrastructure Asset id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureAssetsEndpoints.getPdpInfrastructureAssetById}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Asset"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Asset"
    );
  }
};

/**
 * Get PDP Infrastructure Assets by PDP ID
 * @param {number|string} pdpId - PDP ID
 * @returns {Promise<Array>} Array of PDP Infrastructure Asset records for the specified PDP
 */
export const getPdpInfrastructureAssetsByPdpId = async (pdpId) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!pdpId) throw new Error("PDP id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureAssetsEndpoints.getPdpInfrastructureAssetsByPdpId}${pdpId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Assets"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Assets"
    );
  }
};

/**
 * Get PDP Infrastructure Assets by PDP Infrastructure ID
 * @param {number|string} pdpInfrastructureId - PDP Infrastructure ID
 * @returns {Promise<Array>} Array of PDP Infrastructure Asset records for the specified PDP Infrastructure
 */
export const getPdpInfrastructureAssetsByPdpInfrastructureId = async (
  pdpInfrastructureId
) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!pdpInfrastructureId)
      throw new Error("PDP Infrastructure id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureAssetsEndpoints.getPdpInfrastructureAssetsByPdpInfrastructureId}${pdpInfrastructureId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Assets"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Assets"
    );
  }
};

/**
 * Update a PDP Infrastructure Asset
 * @param {Object} payload - PDP Infrastructure Asset data
 * @param {number} payload.id - PDP Infrastructure Asset ID (required)
 * @param {number} [payload.pdpId] - PDP ID (optional)
 * @param {number} [payload.pdpInfrastructureId] - PDP Infrastructure ID (optional)
 * @param {string} [payload.asset_type] - Asset type (optional)
 * @param {number} [payload.quantity] - Quantity (optional)
 * @param {number} [payload.yop] - Year of production/purchase (optional)
 * @param {string} [payload.available] - Available status (optional)
 * @param {string} [payload.assigned_to] - Person assigned to asset (optional)
 * @param {boolean} [payload.isActive] - Active status (optional)
 * @returns {Promise<Object>} Response object with status and message
 */
export const updatePdpInfrastructureAsset = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!payload.id) throw new Error("ID is required");

    const response = await axios.put(
      `${API.domain}${API.pdpInfrastructureAssetsEndpoints.updatePdpInfrastructureAsset}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to update PDP Infrastructure Asset"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to update PDP Infrastructure Asset"
    );
  }
};

/**
 * Delete a PDP Infrastructure Asset
 * @param {number|string} id - PDP Infrastructure Asset ID
 * @returns {Promise<Object>} Response object with status and message
 */
export const deletePdpInfrastructureAsset = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP Infrastructure Asset id is required");

    const response = await axios.delete(
      `${API.domain}${API.pdpInfrastructureAssetsEndpoints.deletePdpInfrastructureAsset}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to delete PDP Infrastructure Asset"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to delete PDP Infrastructure Asset"
    );
  }
};

