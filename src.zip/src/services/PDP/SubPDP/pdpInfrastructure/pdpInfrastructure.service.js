import axios from "axios";
import { API } from "../../../../api";

// ====================== PDP Infrastructure CRUD ======================= //

/**
 * Add a new PDP Infrastructure
 * @param {Object} payload - PDP Infrastructure data
 * @param {number} payload.pdpId - PDP ID (required)
 * @param {number} payload.infrastructureId - Infrastructure ID (required)
 * @param {string} payload.category - Category: "Retails" or "Key Account" (required)
 * @param {number} [payload.py_infrastructure_id] - Previous year infrastructure ID (optional)
 * @param {number} [payload.py_achievement_eoy] - Previous year achievement EOY (optional, defaults to 0)
 * @param {number} [payload.py_achievement] - Previous year achievement (optional, defaults to 0.00)
 * @param {number} [payload.target] - Target (optional, defaults to 0)
 * @returns {Promise<Object>} Response object with status and message
 */
export const addPdpInfrastructure = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    // Validate required fields
    if (!payload.pdpId || !payload.infrastructureId || !payload.category) {
      throw new Error("Required fields: pdpId, infrastructureId, category");
    }

    // Validate category
    const validCategories = ["Retails", "Key Account"];
    if (!validCategories.includes(payload.category)) {
      throw new Error("Category must be either 'Retails' or 'Key Account'");
    }

    const response = await axios.post(
      `${API.domain}${API.pdpInfrastructureEndpoints.addPdpInfrastructure}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data.message || "Failed to add PDP Infrastructure");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to add PDP Infrastructure"
    );
  }
};

/**
 * Get all PDP Infrastructures
 * @returns {Promise<Array>} Array of PDP Infrastructure records with joined data
 */
export const getAllPdpInfrastructures = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureEndpoints.getAllPdpInfrastructures}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message || "Failed to fetch PDP Infrastructure list"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure list"
    );
  }
};

/**
 * Get PDP Infrastructure by ID
 * @param {number|string} id - PDP Infrastructure ID
 * @returns {Promise<Object>} PDP Infrastructure record with joined data
 */
export const getPdpInfrastructureById = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP Infrastructure id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureEndpoints.getPdpInfrastructureById}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }
    throw new Error(
      response.data.message || "Failed to fetch PDP Infrastructure"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure"
    );
  }
};

/**
 * Get PDP Infrastructures by PDP ID
 * @param {number|string} pdpId - PDP ID
 * @returns {Promise<Array>} Array of PDP Infrastructure records for the specified PDP
 */
export const getPdpInfrastructuresByPdpId = async (pdpId) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!pdpId) throw new Error("PDP id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureEndpoints.getPdpInfrastructuresByPdpId}${pdpId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message || "Failed to fetch PDP Infrastructures"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructures"
    );
  }
};

/**
 * Update a PDP Infrastructure
 * @param {Object} payload - PDP Infrastructure data
 * @param {number} payload.id - PDP Infrastructure ID (required)
 * @param {number} [payload.pdpId] - PDP ID (optional)
 * @param {number} [payload.infrastructureId] - Infrastructure ID (optional)
 * @param {string} [payload.category] - Category: "Retails" or "Key Account" (optional)
 * @param {number} [payload.py_infrastructure_id] - Previous year infrastructure ID (optional)
 * @param {number} [payload.py_achievement_eoy] - Previous year achievement EOY (optional)
 * @param {number} [payload.py_achievement] - Previous year achievement (optional)
 * @param {number} [payload.target] - Target (optional)
 * @returns {Promise<Object>} Response object with status and message
 */
export const updatePdpInfrastructure = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!payload?.id) throw new Error("PDP Infrastructure id is required");

    // Validate category if provided
    if (payload.category) {
      const validCategories = ["Retails", "Key Account"];
      if (!validCategories.includes(payload.category)) {
        throw new Error("Category must be either 'Retails' or 'Key Account'");
      }
    }

    const response = await axios.put(
      `${API.domain}${API.pdpInfrastructureEndpoints.updatePdpInfrastructure}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message || "Failed to update PDP Infrastructure"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to update PDP Infrastructure"
    );
  }
};

/**
 * Delete a PDP Infrastructure
 * @param {number|string} id - PDP Infrastructure ID
 * @returns {Promise<Object>} Response object with status and message
 */
export const deletePdpInfrastructure = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP Infrastructure id is required");

    const response = await axios.delete(
      `${API.domain}${API.pdpInfrastructureEndpoints.deletePdpInfrastructure}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message || "Failed to delete PDP Infrastructure"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to delete PDP Infrastructure"
    );
  }
};

