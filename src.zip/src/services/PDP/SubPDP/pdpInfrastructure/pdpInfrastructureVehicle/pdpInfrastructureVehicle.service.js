import axios from "axios";
import { API } from "../../../../../api";

// ====================== PDP Infrastructure Vehicle CRUD ======================= //

/**
 * Add a new PDP Infrastructure Vehicle
 * @param {Object} payload - PDP Infrastructure Vehicle data
 * @param {number} payload.pdpId - PDP ID (required)
 * @param {number} payload.pdpInfrastructureId - PDP Infrastructure ID (required)
 * @param {string} payload.vehicle_type - Vehicle type: "Commercial" or "Personal" (required)
 * @param {string} payload.make - Vehicle make (required)
 * @param {string} payload.model - Vehicle model (required)
 * @param {string} payload.registration_number - Vehicle registration number (required)
 * @param {number} payload.yop - Year of production/purchase (required)
 * @param {number} payload.vehicle_age - Vehicle age (required)
 * @param {string} [payload.operating_area] - Operating area (optional)
 * @param {string} [payload.utilisation_rate] - Utilisation rate: "Daily", "Monthly", or "Weekly" (optional)
 * @param {string} [payload.assigned_to] - Person assigned to vehicle (optional)
 * @returns {Promise<Object>} Response object with status and message
 */
export const addPdpInfrastructureVehicle = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    // Validate required fields
    if (!payload.pdpId || !payload.pdpInfrastructureId || !payload.vehicle_type || 
        !payload.make || !payload.model || !payload.registration_number || 
        !payload.yop || !payload.vehicle_age) {
      throw new Error("Required fields: pdpId, pdpInfrastructureId, vehicle_type, make, model, registration_number, yop, vehicle_age");
    }

    // Validate vehicle_type enum
    const validVehicleTypes = ["Commercial", "Personal"];
    if (!validVehicleTypes.includes(payload.vehicle_type)) {
      throw new Error("Vehicle type must be either 'Commercial' or 'Personal'");
    }

    // Validate utilisation_rate enum if provided
    if (payload.utilisation_rate) {
      const validUtilisationRates = ["Daily", "Monthly", "Weekly"];
      if (!validUtilisationRates.includes(payload.utilisation_rate)) {
        throw new Error("Utilisation rate must be either 'Daily', 'Monthly', or 'Weekly'");
      }
    }

    const response = await axios.post(
      `${API.domain}${API.pdpInfrastructureVehicleEndpoints.addPdpInfrastructureVehicle}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message || "Failed to add PDP Infrastructure Vehicle"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to add PDP Infrastructure Vehicle"
    );
  }
};

/**
 * Get all PDP Infrastructure Vehicles
 * @returns {Promise<Array>} Array of PDP Infrastructure Vehicle records with joined data
 */
export const getAllPdpInfrastructureVehicles = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureVehicleEndpoints.getAllPdpInfrastructureVehicles}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Vehicle list"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Vehicle list"
    );
  }
};

/**
 * Get PDP Infrastructure Vehicle by ID
 * @param {number|string} id - PDP Infrastructure Vehicle ID
 * @returns {Promise<Object>} PDP Infrastructure Vehicle record with joined data
 */
export const getPdpInfrastructureVehicleById = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP Infrastructure Vehicle id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureVehicleEndpoints.getPdpInfrastructureVehicleById}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Vehicle"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Vehicle"
    );
  }
};

/**
 * Get PDP Infrastructure Vehicles by PDP ID
 * @param {number|string} pdpId - PDP ID
 * @returns {Promise<Array>} Array of PDP Infrastructure Vehicle records for the specified PDP
 */
export const getPdpInfrastructureVehiclesByPdpId = async (pdpId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!pdpId) throw new Error("PDP id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureVehicleEndpoints.getPdpInfrastructureVehiclesByPdpId}${pdpId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Vehicles"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Vehicles"
    );
  }
};

/**
 * Get PDP Infrastructure Vehicles by PDP Infrastructure ID
 * @param {number|string} pdpInfrastructureId - PDP Infrastructure ID
 * @returns {Promise<Array>} Array of PDP Infrastructure Vehicle records for the specified PDP Infrastructure
 */
export const getPdpInfrastructureVehiclesByPdpInfrastructureId = async (
  pdpInfrastructureId
) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!pdpInfrastructureId)
      throw new Error("PDP Infrastructure id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureVehicleEndpoints.getPdpInfrastructureVehiclesByPdpInfrastructureId}${pdpInfrastructureId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Vehicles"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Vehicles"
    );
  }
};

/**
 * Update a PDP Infrastructure Vehicle
 * @param {Object} payload - PDP Infrastructure Vehicle data
 * @param {number} payload.id - PDP Infrastructure Vehicle ID (required)
 * @param {number} [payload.pdpId] - PDP ID (optional)
 * @param {number} [payload.pdpInfrastructureId] - PDP Infrastructure ID (optional)
 * @param {string} [payload.vehicle_type] - Vehicle type: "Commercial" or "Personal" (optional)
 * @param {string} [payload.make] - Vehicle make (optional)
 * @param {string} [payload.model] - Vehicle model (optional)
 * @param {string} [payload.registration_number] - Vehicle registration number (optional)
 * @param {number} [payload.yop] - Year of production/purchase (optional)
 * @param {number} [payload.vehicle_age] - Vehicle age (optional)
 * @param {string} [payload.operating_area] - Operating area (optional)
 * @param {string} [payload.utilisation_rate] - Utilisation rate: "Daily", "Monthly", or "Weekly" (optional)
 * @param {string} [payload.assigned_to] - Person assigned to vehicle (optional)
 * @param {boolean} [payload.isActive] - Active status (optional)
 * @returns {Promise<Object>} Response object with status and message
 */
export const updatePdpInfrastructureVehicle = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!payload.id) throw new Error("ID is required");

    // Validate vehicle_type enum if provided
    if (payload.vehicle_type) {
      const validVehicleTypes = ["Commercial", "Personal"];
      if (!validVehicleTypes.includes(payload.vehicle_type)) {
        throw new Error("Vehicle type must be either 'Commercial' or 'Personal'");
      }
    }

    // Validate utilisation_rate enum if provided
    if (payload.utilisation_rate) {
      const validUtilisationRates = ["Daily", "Monthly", "Weekly"];
      if (!validUtilisationRates.includes(payload.utilisation_rate)) {
        throw new Error("Utilisation rate must be either 'Daily', 'Monthly', or 'Weekly'");
      }
    }

    const response = await axios.put(
      `${API.domain}${API.pdpInfrastructureVehicleEndpoints.updatePdpInfrastructureVehicle}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to update PDP Infrastructure Vehicle"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to update PDP Infrastructure Vehicle"
    );
  }
};

/**
 * Delete a PDP Infrastructure Vehicle
 * @param {number|string} id - PDP Infrastructure Vehicle ID
 * @returns {Promise<Object>} Response object with status and message
 */
export const deletePdpInfrastructureVehicle = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP Infrastructure Vehicle id is required");

    const response = await axios.delete(
      `${API.domain}${API.pdpInfrastructureVehicleEndpoints.deletePdpInfrastructureVehicle}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to delete PDP Infrastructure Vehicle"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to delete PDP Infrastructure Vehicle"
    );
  }
};

