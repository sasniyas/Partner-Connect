import axios from "axios";
import { API } from "../../../../../api";

// ====================== PDP Infrastructure Location Count CRUD ======================= //

/**
 * Add a new PDP Infrastructure Location Count
 * @param {Object} payload - PDP Infrastructure Location Count data
 * @param {number} payload.pdpId - PDP ID (required)
 * @param {number} payload.pdpInfrastructureId - PDP Infrastructure ID (required)
 * @param {string} [payload.location] - Location name (optional)
 * @param {number} [payload.count] - Count (optional, defaults to 0)
 * @returns {Promise<Object>} Response object with status and message
 */
export const addPdpInfrastructureLocationCount = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    // Validate required fields
    if (!payload.pdpId || !payload.pdpInfrastructureId) {
      throw new Error("Required fields: pdpId, pdpInfrastructureId");
    }

    const response = await axios.post(
      `${API.domain}${API.pdpInfrastructureLocationCountEndpoints.addPdpInfrastructureLocationCount}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message || "Failed to add PDP Infrastructure Location Count"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to add PDP Infrastructure Location Count"
    );
  }
};

/**
 * Get all PDP Infrastructure Location Counts
 * @returns {Promise<Array>} Array of PDP Infrastructure Location Count records with joined data
 */
export const getAllPdpInfrastructureLocationCounts = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureLocationCountEndpoints.getAllPdpInfrastructureLocationCounts}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Location Count list"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Location Count list"
    );
  }
};

/**
 * Get PDP Infrastructure Location Count by ID
 * @param {number|string} id - PDP Infrastructure Location Count ID
 * @returns {Promise<Object>} PDP Infrastructure Location Count record with joined data
 */
export const getPdpInfrastructureLocationCountById = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP Infrastructure Location Count id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureLocationCountEndpoints.getPdpInfrastructureLocationCountById}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Location Count"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Location Count"
    );
  }
};

/**
 * Get PDP Infrastructure Location Counts by PDP ID
 * @param {number|string} pdpId - PDP ID
 * @returns {Promise<Array>} Array of PDP Infrastructure Location Count records for the specified PDP
 */
export const getPdpInfrastructureLocationCountsByPdpId = async (pdpId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!pdpId) throw new Error("PDP id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureLocationCountEndpoints.getPdpInfrastructureLocationCountsByPdpId}${pdpId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Location Counts"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Location Counts"
    );
  }
};

/**
 * Get PDP Infrastructure Location Counts by PDP Infrastructure ID
 * @param {number|string} pdpInfrastructureId - PDP Infrastructure ID
 * @returns {Promise<Array>} Array of PDP Infrastructure Location Count records for the specified PDP Infrastructure
 */
export const getPdpInfrastructureLocationCountsByPdpInfrastructureId = async (
  pdpInfrastructureId
) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!pdpInfrastructureId)
      throw new Error("PDP Infrastructure id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureLocationCountEndpoints.getPdpInfrastructureLocationCountsByPdpInfrastructureId}${pdpInfrastructureId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Location Counts"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Location Counts"
    );
  }
};

/**
 * Update a PDP Infrastructure Location Count
 * @param {Object} payload - PDP Infrastructure Location Count data
 * @param {number} payload.id - PDP Infrastructure Location Count ID (required)
 * @param {number} [payload.pdpId] - PDP ID (optional)
 * @param {number} [payload.pdpInfrastructureId] - PDP Infrastructure ID (optional)
 * @param {string} [payload.location] - Location name (optional)
 * @param {number} [payload.count] - Count (optional)
 * @param {boolean} [payload.isActive] - Active status (optional)
 * @returns {Promise<Object>} Response object with status and message
 */
export const updatePdpInfrastructureLocationCount = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!payload.id) throw new Error("ID is required");

    const response = await axios.put(
      `${API.domain}${API.pdpInfrastructureLocationCountEndpoints.updatePdpInfrastructureLocationCount}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to update PDP Infrastructure Location Count"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
  
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to update PDP Infrastructure Location Count"
    );
  }
};

/**
 * Delete a PDP Infrastructure Location Count
 * @param {number|string} id - PDP Infrastructure Location Count ID
 * @returns {Promise<Object>} Response object with status and message
 */
export const deletePdpInfrastructureLocationCount = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP Infrastructure Location Count id is required");

    const response = await axios.delete(
      `${API.domain}${API.pdpInfrastructureLocationCountEndpoints.deletePdpInfrastructureLocationCount}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to delete PDP Infrastructure Location Count"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to delete PDP Infrastructure Location Count"
    );
  }
};

