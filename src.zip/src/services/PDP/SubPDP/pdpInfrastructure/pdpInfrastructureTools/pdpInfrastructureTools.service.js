import axios from "axios";
import { API } from "../../../../../api";

// ====================== PDP Infrastructure Tools CRUD ======================= //

/**
 * Add a new PDP Infrastructure Tool
 * @param {Object} payload - PDP Infrastructure Tool data
 * @param {number} payload.pdpId - PDP ID (required)
 * @param {number} payload.pdpInfrastructureId - PDP Infrastructure ID (required)
 * @param {string} payload.tool_type - Tool type (required)
 * @param {string} payload.tool_name - Tool name (required)
 * @param {number} payload.quantity - Quantity (required)
 * @param {number} [payload.yop] - Year of production/purchase (optional)
 * @param {string} payload.available - Available status (required)
 * @returns {Promise<Object>} Response object with status and message
 */
export const addPdpInfrastructureTool = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    // Validate required fields
    if (!payload.pdpId || !payload.pdpInfrastructureId || !payload.tool_type || 
        !payload.tool_name || !payload.quantity || !payload.available) {
      throw new Error("Required fields: pdpId, pdpInfrastructureId, tool_type, tool_name, quantity, available");
    }

    const response = await axios.post(
      `${API.domain}${API.pdpInfrastructureToolsEndpoints.addPdpInfrastructureTool}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message || "Failed to add PDP Infrastructure Tool"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to add PDP Infrastructure Tool"
    );
  }
};

/**
 * Get all PDP Infrastructure Tools
 * @returns {Promise<Array>} Array of PDP Infrastructure Tool records with joined data
 */
export const getAllPdpInfrastructureTools = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureToolsEndpoints.getAllPdpInfrastructureTools}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Tool list"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
  
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Tool list"
    );
  }
};

/**
 * Get PDP Infrastructure Tool by ID
 * @param {number|string} id - PDP Infrastructure Tool ID
 * @returns {Promise<Object>} PDP Infrastructure Tool record with joined data
 */
export const getPdpInfrastructureToolById = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP Infrastructure Tool id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureToolsEndpoints.getPdpInfrastructureToolById}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Tool"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Tool"
    );
  }
};

/**
 * Get PDP Infrastructure Tools by PDP ID
 * @param {number|string} pdpId - PDP ID
 * @returns {Promise<Array>} Array of PDP Infrastructure Tool records for the specified PDP
 */
export const getPdpInfrastructureToolsByPdpId = async (pdpId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!pdpId) throw new Error("PDP id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureToolsEndpoints.getPdpInfrastructureToolsByPdpId}${pdpId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Tools"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
 
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Tools"
    );
  }
};

/**
 * Get PDP Infrastructure Tools by PDP Infrastructure ID
 * @param {number|string} pdpInfrastructureId - PDP Infrastructure ID
 * @returns {Promise<Array>} Array of PDP Infrastructure Tool records for the specified PDP Infrastructure
 */
export const getPdpInfrastructureToolsByPdpInfrastructureId = async (
  pdpInfrastructureId
) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!pdpInfrastructureId)
      throw new Error("PDP Infrastructure id is required");

    const response = await axios.get(
      `${API.domain}${API.pdpInfrastructureToolsEndpoints.getPdpInfrastructureToolsByPdpInfrastructureId}${pdpInfrastructureId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(
      response.data.message ||
        "Failed to fetch PDP Infrastructure Tools"
    );
  } catch (error) {

    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch PDP Infrastructure Tools"
    );
  }
};

/**
 * Update a PDP Infrastructure Tool
 * @param {Object} payload - PDP Infrastructure Tool data
 * @param {number} payload.id - PDP Infrastructure Tool ID (required)
 * @param {number} [payload.pdpId] - PDP ID (optional)
 * @param {number} [payload.pdpInfrastructureId] - PDP Infrastructure ID (optional)
 * @param {string} [payload.tool_type] - Tool type (optional)
 * @param {string} [payload.tool_name] - Tool name (optional)
 * @param {number} [payload.quantity] - Quantity (optional)
 * @param {number} [payload.yop] - Year of production/purchase (optional)
 * @param {string} [payload.available] - Available status (optional)
 * @param {boolean} [payload.isActive] - Active status (optional)
 * @returns {Promise<Object>} Response object with status and message
 */
export const updatePdpInfrastructureTool = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!payload.id) throw new Error("ID is required");

    const response = await axios.put(
      `${API.domain}${API.pdpInfrastructureToolsEndpoints.updatePdpInfrastructureTool}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to update PDP Infrastructure Tool"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to update PDP Infrastructure Tool"
    );
  }
};

/**
 * Delete a PDP Infrastructure Tool
 * @param {number|string} id - PDP Infrastructure Tool ID
 * @returns {Promise<Object>} Response object with status and message
 */
export const deletePdpInfrastructureTool = async (id) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP Infrastructure Tool id is required");

    const response = await axios.delete(
      `${API.domain}${API.pdpInfrastructureToolsEndpoints.deletePdpInfrastructureTool}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(
      response.data.message ||
        "Failed to delete PDP Infrastructure Tool"
    );
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to delete PDP Infrastructure Tool"
    );
  }
};

