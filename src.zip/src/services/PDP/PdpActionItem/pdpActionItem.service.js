import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 PDP ACTION ITEM SERVICE
// Complete CRUD operations for PDP Action Items
// Pattern: Mirrored from Monthly Meeting Action Item Service
// ═══════════════════════════════════════════════════════════════

const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

const handleTokenExpiry = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

const getAxiosConfig = () => {
  const token = getAuthToken();
  if (!token) {
    throw new Error("Authentication token not found. Please login again.");
  }
  return {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET ALL PDP ACTION ITEMS
// Route: GET /getAllPdpActionItem?pdp_id=&isActive=
// Returns: id, pdp, focus_area, objective, actions_to_achieve,
//   actions_progress_update, closure_action, comments,
//   responsibility, priority, target_date, completed_date,
//   status, isActive, target_data_change, created_by, created_on
// ═══════════════════════════════════════════════════════════════

export const getAllPdpActionItem = async (filters = {}) => {
  try {
    const config = getAxiosConfig();

    const params = new URLSearchParams();
    if (filters.pdp_id) params.append("pdp_id", filters.pdp_id);
    if (filters.isActive !== undefined) params.append("isActive", filters.isActive);

    const queryString = params.toString();
    const url = `${API.domain}/getAllPdpActionItem${queryString ? `?${queryString}` : ""}`;

    const response = await axios.get(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    throw new Error(response.data.message || "Failed to fetch action items");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action items"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET PDP ACTION ITEM BY ID
// Route: GET /getPdpActionItem/:id
// Returns same fields as getAllPdpActionItem including
//   closure_action and comments
// ═══════════════════════════════════════════════════════════════

export const getPdpActionItemById = async (id) => {
  try {
    if (!id) {
      throw new Error("Action item ID is required");
    }

    const config = getAxiosConfig();
    const url = `${API.domain}/getPdpActionItem/${id}`;

    const response = await axios.get(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to fetch action item");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action item"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// ➕ ADD PDP ACTION ITEM
// Route: POST /addPdpActionItem
// Backend required: pdp, focus_area, objective, priority
// Backend rule: created_by !== responsibility
// NOTE: closure_action and comments are NOT in the INSERT —
//   they can only be set via updatePdpActionItem after creation
// ═══════════════════════════════════════════════════════════════

export const addPdpActionItem = async (payload) => {
  try {
    if (!payload.pdp) throw new Error("PDP ID is required");
    if (!payload.focus_area) throw new Error("Focus area is required");
    if (!payload.objective) throw new Error("Objective is required");
    if (!payload.priority) throw new Error("Priority is required");

    const validFocusAreas = [
      "Uptime & Parts", "DD- CD and Infra", "Finance", "Key Accounts",
      "Machine Attach- sales", "Marcom", "People and Culture", "Territory Focus",
    ];
    if (!validFocusAreas.includes(payload.focus_area)) {
      throw new Error(`Invalid focus_area. Must be one of: ${validFocusAreas.join(", ")}`);
    }

    const validPriorities = ["High", "Medium", "Low"];
    if (!validPriorities.includes(payload.priority)) {
      throw new Error(`Invalid priority. Must be one of: ${validPriorities.join(", ")}`);
    }

    if (payload.status) {
      const validStatuses = ["Open", "In Progress", "Closed"];
      if (!validStatuses.includes(payload.status)) {
        throw new Error(`Invalid status. Must be one of: ${validStatuses.join(", ")}`);
      }
    }

    const config = getAxiosConfig();
    const url = `${API.domain}/addPdpActionItem`;

    // Only send fields the INSERT supports — closure_action + comments NOT included
    const cleanPayload = {
      pdp: parseInt(payload.pdp, 10),
      focus_area: payload.focus_area,
      objective: payload.objective,
      priority: payload.priority,
      actions_to_achieve: payload.actions_to_achieve || null,
      actions_progress_update: payload.actions_progress_update || null,
      responsibility: payload.responsibility ? parseInt(payload.responsibility, 10) : null,
      target_date: payload.target_date || null,
      completed_date: payload.completed_date || null,
      status: payload.status || "Open",
      isActive: payload.isActive !== undefined ? payload.isActive : true,
      target_data_change: payload.target_data_change || false,
    };

    const response = await axios.post(url, cleanPayload, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to create action item");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to create action item"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// ✏️ UPDATE PDP ACTION ITEM
// Route: PUT /updatePdpActionItem
// Backend accepts: id, pdp, focus_area, objective, actions_to_achieve,
//   actions_progress_update, responsibility, priority, target_date,
//   completed_date, status, isActive, target_data_change,
//   closure_action, comments   ← added in updated backend
// ═══════════════════════════════════════════════════════════════

export const updatePdpActionItem = async (payload) => {
  try {
    if (!payload.id) {
      throw new Error("Action item ID is required for update");
    }

    if (payload.focus_area) {
      const validFocusAreas = [
        "Uptime & Parts", "DD- CD and Infra", "Finance", "Key Accounts",
        "Machine Attach- sales", "Marcom", "People and Culture", "Territory Focus",
      ];
      if (!validFocusAreas.includes(payload.focus_area)) {
        throw new Error(`Invalid focus_area. Must be one of: ${validFocusAreas.join(", ")}`);
      }
    }

    if (payload.priority) {
      const validPriorities = ["High", "Medium", "Low"];
      if (!validPriorities.includes(payload.priority)) {
        throw new Error(`Invalid priority. Must be one of: ${validPriorities.join(", ")}`);
      }
    }

    if (payload.status) {
      const validStatuses = ["Open", "In Progress", "Closed"];
      if (!validStatuses.includes(payload.status)) {
        throw new Error(`Invalid status. Must be one of: ${validStatuses.join(", ")}`);
      }
    }

    const config = getAxiosConfig();
    const url = `${API.domain}/updatePdpActionItem`;

    // Clean payload — only include fields defined in update
    const cleanPayload = { id: parseInt(payload.id, 10) };

    if (payload.pdp !== undefined) cleanPayload.pdp = parseInt(payload.pdp, 10);
    if (payload.focus_area !== undefined) cleanPayload.focus_area = payload.focus_area;
    if (payload.objective !== undefined) cleanPayload.objective = payload.objective;
    if (payload.priority !== undefined) cleanPayload.priority = payload.priority;
    if (payload.actions_to_achieve !== undefined) cleanPayload.actions_to_achieve = payload.actions_to_achieve;
    if (payload.actions_progress_update !== undefined) cleanPayload.actions_progress_update = payload.actions_progress_update;
    if (payload.responsibility !== undefined) {
      cleanPayload.responsibility = payload.responsibility
        ? parseInt(payload.responsibility, 10)
        : null;
    }
    if (payload.target_date !== undefined) cleanPayload.target_date = payload.target_date;
    if (payload.completed_date !== undefined) cleanPayload.completed_date = payload.completed_date;
    if (payload.status !== undefined) cleanPayload.status = payload.status;
    if (payload.isActive !== undefined) cleanPayload.isActive = payload.isActive;
    if (payload.target_data_change !== undefined) cleanPayload.target_data_change = payload.target_data_change;
    // closure_action + comments — supported in updated backend
    if (payload.closure_action !== undefined) cleanPayload.closure_action = payload.closure_action;
    if (payload.comments !== undefined) cleanPayload.comments = payload.comments;

    const response = await axios.put(url, cleanPayload, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update action item");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update action item"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 🔄 UPDATE PDP ACTION ITEM STATUS
// Route: PUT /updatePdpActionItemStatus/:id
// Same pattern as MM's updateActionItemStatus
// ═══════════════════════════════════════════════════════════════

export const updatePdpActionItemStatus = async (id, status, completed_date) => {
  try {
    if (!id || !status) throw new Error("ID and status are required");

    const validStatuses = ["Open", "Closed", "In Progress"];
    if (!validStatuses.includes(status)) {
      throw new Error(`Invalid status. Must be one of: ${validStatuses.join(", ")}`);
    }

    const config = getAxiosConfig();
    const url = `${API.domain}/updatePdpActionItemStatus/${id}`;

    const body = { status };
    if (completed_date) body.completed_date = completed_date;

    const response = await axios.put(url, body, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update action item status");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update action item status"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📅 GET PDP TARGET DATE HISTORY
// Route: GET /getPdpTargetDate/:pdp_action_item
// Returns array of previous target dates from pdp_action_log
// Returns [] gracefully on failure — supplementary data
// ═══════════════════════════════════════════════════════════════

export const getPdpTargetDateHistory = async (actionItemId) => {
  try {
    if (!actionItemId) throw new Error("Action item ID is required");

    const config = getAxiosConfig();
    const url = `${API.domain}/getPdpTargetDate/${actionItemId}`;

    const response = await axios.get(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to fetch target date history");
  } catch (error) {
    handleTokenExpiry(error);
    // Don't throw — supplementary data, return empty gracefully
    return { status: true, data: [] };
  }
};

// ═══════════════════════════════════════════════════════════════
// 👥 GET USERS BY PDP DEALER
// Route: GET /getUsersByPdpDealer/:pdpId
// Same pattern as MM's getUsersByMonthlyMeetingDealer
// Returns only users mapped to the dealer of this PDP
// Used in Add/Edit form responsibility dropdown
// ═══════════════════════════════════════════════════════════════

export const getUsersByPdpDealer = async (pdpId) => {
  try {
    const token =
      localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await fetch(
      `${API.domain}/getUsersByPdpDealer/${pdpId}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return await response.json();
  } catch (error) {
    console.error("Error fetching users by PDP dealer:", error);
    return { status: false, message: error.message, data: [] };
  }
};

// ═══════════════════════════════════════════════════════════════
// 🗑️ DELETE PDP ACTION ITEM (Soft Delete)
// Route: DELETE /deletePdpActionItem/:id
// ═══════════════════════════════════════════════════════════════

export const deletePdpActionItem = async (id) => {
  try {
    if (!id) throw new Error("Action item ID is required for deletion");

    const config = getAxiosConfig();
    const url = `${API.domain}/deletePdpActionItem/${id}`;

    const response = await axios.delete(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete action item");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete action item"
    );
  }
};