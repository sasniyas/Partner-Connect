import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 PDP ACTION ITEM LOG SERVICE
// Complete CRUD operations for PDP Action Item Logs
// ═══════════════════════════════════════════════════════════════

/**
 * Helper function to get authentication token
 * @returns {string|null} Authentication token
 */
const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

/**
 * Helper function to handle token expiry
 * @param {Object} error - Axios error object
 */
const handleTokenExpiry = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

/**
 * Helper function to create axios config with auth headers
 * @returns {Object} Axios config object
 */
const getAxiosConfig = () => {
  const token = getAuthToken();
  if (!token) {
    throw new Error("Authentication token not found. Please login again.");
  }
  return {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET ACTION LOGS BY ACTION ITEM ID
// ═══════════════════════════════════════════════════════════════

/**
 * Fetch all action logs for a specific action item
 * @param {number} actionItemId - PDP Action Item ID
 * @returns {Promise<Object>} Response with logs array
 * 
 * @example
 * const response = await getPdpActionLogsByActionItem(33);
 * console.log(response.data); // Array of logs
 */
export const getPdpActionLogsByActionItem = async (actionItemId) => {
  try {
    if (!actionItemId) {
      throw new Error("Action item ID is required");
    }
    
    const config = getAxiosConfig();
    const url = `${API.domain}/getPdpActionLogsByActionItem/${actionItemId}`;
    
    console.log("📡 Fetching Action Logs for Action Item:", actionItemId);
    
    const response = await axios.get(url, config);
    
    if (response.status === 200 && response.data.status) {
      console.log("✅ Action logs fetched:", response.data.data?.length || 0);
      return response.data;
    }
    
    throw new Error(response.data.message || "Failed to fetch action logs");
  } catch (error) {
    handleTokenExpiry(error);
    console.error("❌ getPdpActionLogsByActionItem Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action logs"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET ALL ACTION LOGS
// ═══════════════════════════════════════════════════════════════

/**
 * Fetch all action logs with optional filters
 * @param {Object} filters - Optional filters
 * @param {number} [filters.pdp_action_item] - Filter by action item ID
 * @param {number} [filters.updated_by] - Filter by user who updated
 * @returns {Promise<Object>} Response with logs array
 * 
 * @example
 * const response = await getAllPdpActionLogs({ pdp_action_item: 33 });
 */
export const getAllPdpActionLogs = async (filters = {}) => {
  try {
    const config = getAxiosConfig();
    
    // Build query params
    const params = new URLSearchParams();
    if (filters.pdp_action_item) params.append("pdp_action_item", filters.pdp_action_item);
    if (filters.updated_by) params.append("updated_by", filters.updated_by);
    
    const queryString = params.toString();
    const url = `${API.domain}/getAllPdpActionLogs${queryString ? `?${queryString}` : ""}`;
    
    console.log("📡 Fetching All Action Logs:", url);
    
    const response = await axios.get(url, config);
    
    if (response.status === 200 && response.data.status) {
      console.log("✅ Action logs fetched:", response.data.data?.length || 0);
      return response.data;
    }
    
    throw new Error(response.data.message || "Failed to fetch action logs");
  } catch (error) {
    handleTokenExpiry(error);
    console.error("❌ getAllPdpActionLogs Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action logs"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET ACTION LOG BY ID
// ═══════════════════════════════════════════════════════════════

/**
 * Fetch a single action log by ID
 * @param {number} id - Action log ID
 * @returns {Promise<Object>} Response with log details
 * 
 * @example
 * const response = await getPdpActionLogById(1);
 */
export const getPdpActionLogById = async (id) => {
  try {
    if (!id) {
      throw new Error("Action log ID is required");
    }
    
    const config = getAxiosConfig();
    const url = `${API.domain}/getPdpActionLog/${id}`;
    
    console.log("📡 Fetching Action Log by ID:", id);
    
    const response = await axios.get(url, config);
    
    if (response.status === 200 && response.data.status) {
      console.log("✅ Action log fetched:", response.data.data);
      return response.data;
    }
    
    throw new Error(response.data.message || "Failed to fetch action log");
  } catch (error) {
    handleTokenExpiry(error);
    console.error("❌ getPdpActionLogById Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action log"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// ➕ ADD ACTION LOG
// ═══════════════════════════════════════════════════════════════

/**
 * Create a new action log entry
 * @param {Object} payload - Log data
 * @param {number} payload.pdp_action_item - Action item ID (required)
 * @param {string} [payload.comment] - Log comment
 * @returns {Promise<Object>} Response with created log ID
 * 
 * @example
 * const result = await addPdpActionLog({
 *   pdp_action_item: 33,
 *   comment: "Updated progress to 50%"
 * });
 */
export const addPdpActionLog = async (payload) => {
  try {
    if (!payload.pdp_action_item) {
      throw new Error("Action item ID is required");
    }
    
    const config = getAxiosConfig();
    const url = `${API.domain}/addPdpActionLog`;
    
    const cleanPayload = {
      pdp_action_item: parseInt(payload.pdp_action_item, 10),
      comment: payload.comment || null,
    };
    
    console.log("📡 Adding Action Log:", cleanPayload);
    
    const response = await axios.post(url, cleanPayload, config);
    
    if (response.status === 200 && response.data.status) {
      console.log("✅ Action log created:", response.data.data?.id);
      return response.data;
    }
    
    throw new Error(response.data.message || "Failed to create action log");
  } catch (error) {
    handleTokenExpiry(error);
    console.error("❌ addPdpActionLog Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to create action log"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// ✏️ UPDATE ACTION LOG
// ═══════════════════════════════════════════════════════════════

/**
 * Update an existing action log
 * @param {number} id - Action log ID
 * @param {Object} payload - Log data to update
 * @param {string} [payload.comment] - Updated comment
 * @returns {Promise<Object>} Response object
 * 
 * @example
 * await updatePdpActionLog(1, { comment: "Updated comment" });
 */
export const updatePdpActionLog = async (id, payload) => {
  try {
    if (!id) {
      throw new Error("Action log ID is required");
    }
    
    const config = getAxiosConfig();
    const url = `${API.domain}/updatePdpActionLog/${id}`;
    
    console.log("📡 Updating Action Log:", id, payload);
    
    const response = await axios.put(url, payload, config);
    
    if (response.status === 200 && response.data.status) {
      console.log("✅ Action log updated successfully");
      return response.data;
    }
    
    throw new Error(response.data.message || "Failed to update action log");
  } catch (error) {
    handleTokenExpiry(error);
    console.error("❌ updatePdpActionLog Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update action log"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 🗑️ DELETE ACTION LOG
// ═══════════════════════════════════════════════════════════════

/**
 * Soft delete an action log
 * @param {number} id - Action log ID
 * @returns {Promise<Object>} Response object
 * 
 * @example
 * await deletePdpActionLog(1);
 */
export const deletePdpActionLog = async (id) => {
  try {
    if (!id) {
      throw new Error("Action log ID is required");
    }
    
    const config = getAxiosConfig();
    const url = `${API.domain}/deletePdpActionLog/${id}`;
    
    console.log("📡 Deleting Action Log:", id);
    
    const response = await axios.delete(url, config);
    
    if (response.status === 200 && response.data.status) {
      console.log("✅ Action log deleted successfully");
      return response.data;
    }
    
    throw new Error(response.data.message || "Failed to delete action log");
  } catch (error) {
    handleTokenExpiry(error);
    console.error("❌ deletePdpActionLog Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete action log"
    );
  }
};