import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 CORE API FUNCTIONS - PDP Equipment Details
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ FUNCTION 1: Get PDP Equipments by PDP ID
 * Fetch all equipment records for a specific PDP with optional filters
 * Used by both Equipment.jsx (summary) and Equipments.jsx (details)
 * 
 * @param {number} pdpId - The PDP ID (required)
 * @param {Object} filters - Optional filters
 * @param {string} filters.category - Category filter ("Retails" or "Key Account")
 * @param {string} filters.equipment_type - Equipment type filter
 * @returns {Promise<Array>} Array of equipment records with normalized field names
 * 
 * @example
 * // Fetch all equipments for Equipment.jsx summary
 * const data = await getPdpEquipmentsByPdpId(52, { category: "Retails" });
 * 
 * @example
 * // Fetch specific equipment type for Equipments.jsx details
 * const data = await getPdpEquipmentsByPdpId(52, { 
 *   category: "Retails", 
 *   equipment_type: "GPE (General Production Equipment)" 
 * });
 */
export const getPdpEquipmentsByPdpId = async (pdpId, filters = {}) => {
  try {
    // Validate PDP ID
    if (!pdpId) {
      throw new Error("PDP ID is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    // ⭐ Clean equipment type - Remove ALL whitespace issues (tabs, newlines, extra spaces)
    let cleanEquipmentType = filters.equipment_type;
    if (cleanEquipmentType) {
      cleanEquipmentType = cleanEquipmentType
        .replace(/\t/g, '')  // Remove tabs
        .replace(/\r/g, '')  // Remove carriage returns
        .replace(/\n/g, '')  // Remove newlines
        .replace(/\s+/g, ' ') // Replace multiple spaces with single space
        .trim();              // Remove leading/trailing spaces
      
      console.log("🔧 Cleaned equipment_type:", {
        original: filters.equipment_type,
        cleaned: cleanEquipmentType
      });
    }

    const url = `${API.domain}${API.createPdpendpoints.getPdpEquipmentsByPdpId}${pdpId}`;
    
    console.log("📡 Fetching PDP Equipments");
    console.log("  URL:", url);
    console.log("  PDP ID:", pdpId);
    console.log("  Filters:", {
      category: filters.category || "none",
      equipment_type: cleanEquipmentType || "none"
    });

    const response = await axios.get(url, {
      params: {
        category: filters.category || undefined,
        equipment_type: cleanEquipmentType || undefined
      },
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Raw API Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];
      
      // ⭐ Helper function to clean string fields (removes tabs, newlines, extra spaces)
      const cleanString = (str) => {
        if (!str) return str;
        return str
          .replace(/\t/g, '')    // Remove tabs
          .replace(/\r/g, '')    // Remove carriage returns
          .replace(/\n/g, '')    // Remove newlines
          .replace(/\s+/g, ' ')  // Replace multiple spaces with single space
          .trim();               // Remove leading/trailing spaces
      };

      // ⭐ Transform API response to match component expectations
      const transformedData = rawData.map(item => ({
        // Keep original ID fields
        id: item.id,
        pdpId: item.pdpId,
        equipmentMasterId: item.equipmentMasterId,
        category: item.category,
        
        // ⭐ Map for Equipment.jsx (summary page) - backward compatibility
        target: item.pdp_target || 0,
        total: item.total_market_volume || 0,
        
        // ⭐ Clean all string fields to remove tabs/newlines/extra spaces
        equipment_type: cleanString(item.equipment_type),
        equipment_make: cleanString(item.equipment_make),
        equipment_line: cleanString(item.equipment_line),
        equipment_model: cleanString(item.equipment_model),
        remarks: item.remarks ? cleanString(item.remarks) : null,
        
        // Previous Year data
        py_pdpEquipment_id: item.py_pdpEquipment_id,
        py_market_share: item.py_market_share,
        py_pdp_target: item.py_pdp_target,
        py_total_market_volume: item.py_total_market_volume,
        
        // Current Year YTD data
        actual_sales_ytd: item.actual_sales_ytd,
        market_volume_ytd: item.market_volume_ytd,
        market_share_ytd: item.market_share_ytd,
        
        // Current Year Forecast data
        forecast_sales_eoy: item.forecast_sales_eoy,
        forecast_market_volume_eoy: item.forecast_market_volume_eoy,
        forecast_market_share_eoy: item.forecast_market_share_eoy,
        
        // Current Year PDP data
        pdp_target: item.pdp_target,
        total_market_volume: item.total_market_volume,
        market_share: item.market_share,
        
        // Additional fields
        equipment_year: item.equipment_year
      }));

      console.log("✅ Equipment data transformed:", transformedData.length, "records");
      if (transformedData.length > 0) {
        console.log("📦 Sample transformed data:", {
          id: transformedData[0].id,
          equipment_type: transformedData[0].equipment_type,
          equipment_make: transformedData[0].equipment_make,
          equipment_line: transformedData[0].equipment_line,
          equipment_model: transformedData[0].equipment_model,
          target: transformedData[0].target,
          total: transformedData[0].total
        });
      }
      
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch equipments");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getPdpEquipmentsByPdpId Error:", error.message);
    
    if (error.response) {
      console.error("❌ Response Error:", {
        status: error.response.status,
        data: error.response.data
      });
    }
    
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch equipments"
    );
  }
};

/**
 * ✅ FUNCTION 2: Update Multiple PDP Equipments
 * Bulk update multiple equipment records in a single API call
 * Used by Equipments.jsx when saving edited data
 * 
 * @param {Array<Object>} rows - Array of equipment objects to update
 * @returns {Promise<Object>} Response data with update results
 * 
 * @example
 * const rows = [
 *   { 
 *     id: 1177, 
 *     pdpId: 52,
 *     py_pdp_target: 100,
 *     py_total_market_volume: 200,
 *     pdp_target: 120,
 *     total_market_volume: 220,
 *     remarks: "Updated remark"
 *   },
 *   // ... more rows
 * ];
 * await updateMultiplePdpEquipments(rows);
 */
export const updateMultiplePdpEquipments = async (rows) => {
  try {
    // Validate input
    if (!Array.isArray(rows) || rows.length === 0) {
      throw new Error("Rows array is required and cannot be empty");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.updateMultiplePdpEquipments}`;
    console.log("📡 Updating Multiple PDP Equipments");
    console.log("  URL:", url);
    console.log("  Rows to update:", rows.length);
    console.log("  Sample row:", rows[0]);

    const response = await axios.put(
      url, 
      { rows }, 
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Update Response:", {
      status: response.status,
      message: response.data.message,
      updatedCount: response.data.data?.updatedCount || rows.length
    });

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update equipments");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updateMultiplePdpEquipments Error:", error.message);
    
    if (error.response) {
      console.error("❌ Response Error:", {
        status: error.response.status,
        data: error.response.data
      });
    }
    
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to update equipments"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📤 DEFAULT EXPORT
// ═══════════════════════════════════════════════════════════════
