import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 COMPETENCE DEVELOPMENT APIs
// ═══════════════════════════════════════════════════════════════

/**
 * Get PDP Competence Developments by PDP ID
 */
export const getPdpCompetenceDevelopmentsByPdpId = async (pdpId) => {
  try {
    if (!pdpId) {
      throw new Error("PDP ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getPdpCompetenceDevelopmentsByPdpId}${pdpId}`;
    
    console.log("📡 Fetching Competence Developments");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Competence Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];
      
      // ⭐ Transform API response - removed fields that don't exist in API
      const transformedData = rawData.map(item => ({
        id: item.id,
        pdpId: item.pdpId,
        competenceId: item.competenceId,
        competence_name: item.competence_name,           // ⭐ Display in table column
        competence_type: item.competence_type,           // ⭐ Use for category filtering
        py_target: item.py_target,
        py_target_value: item.py_target_value,
        py_eoy: item.py_eoy,
        target: item.target,
        remarks: item.remarks,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        createdAt: item.created_at,
        updatedAt: item.updated_at
      }));

      console.log("✅ Competence data transformed:", transformedData.length, "records");
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch competence data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getPdpCompetenceDevelopmentsByPdpId Error:", error.message);


    throw new Error(error.response?.data?.message || error.message || "Failed to fetch competence data");
  }
};

/**
 * Update Multiple PDP Competence Developments
 */
export const updateMultiplePdpCompeDev = async (records) => {
  try {
    if (!records || records.length === 0) {
      throw new Error("No records to update");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.updateMultiplePdpCompeDev}`;
    
    console.log("📡 Updating Multiple Competence Developments");
    console.log("  URL:", url);
    console.log("  Records count:", records.length);

    const payload = { rows: records };

    console.log("📤 API Payload:", payload);

    const response = await axios.put(url, payload, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update competence records");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updateMultiplePdpCompeDev Error:", error.message);
    console.error("❌ Error details:", error.response?.data);
    
   

    throw new Error(error.response?.data?.message || error.message || "Failed to update competence records");
  }
};

/**
 * Get Active Machines - Calculate totals from array
 */
export const getActiveMachines = async (pdpId) => {
  try {
    if (!pdpId) {
      throw new Error("PDP ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getActiveMachines}${pdpId}`;
    
    console.log("📡 Fetching Active Machines");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Active Machines Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const dataArray = response.data.data || [];
      
      // ⭐ Calculate totals by summing all records
      const totals = dataArray.reduce((acc, item) => {
        return {
          py_target: acc.py_target + (parseFloat(item.py_target) || 0),
          py_eoy: acc.py_eoy + (parseFloat(item.py_eoy) || 0),
          target: acc.target + (parseFloat(item.target) || 0)
        };
      }, { py_target: 0, py_eoy: 0, target: 0 });
      
      console.log("✅ Calculated totals:", totals);
      
      return {
        status: true,
        data: totals,
        rawData: dataArray // Keep raw data if needed
      };
    }

    throw new Error(response.data?.message || "Failed to fetch active machines data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getActiveMachines Error:", error.message);
    


    throw new Error(error.response?.data?.message || error.message || "Failed to fetch active machines data");
  }
};

