import axios from "axios";
import { API } from "../../../api"; // adjust path as needed

// ═══════════════════════════════════════════════════════════════
// 🔧 DATE HELPER FUNCTIONS (Same as Scorecard)
// ═══════════════════════════════════════════════════════════════

/**
 * Format date for DISPLAY (DD/MM/YYYY) in Kolkata timezone
 * Use this for tables, labels, and read-only displays
 * 
 * Example:
 *   Input:  "2024-12-15T00:00:00.000Z"
 *   Output: "15/12/2024"
 * 
 * @param {string} dateString - Date string from API
 * @returns {string} Formatted date in DD/MM/YYYY format (Kolkata timezone)
 */
export const formatDateDisplay = (dateString) => {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);

    // Check if date is valid
    if (isNaN(date.getTime())) {
      return dateString;
    }

    // Format in Kolkata timezone (Asia/Kolkata) as DD/MM/YYYY
    return date.toLocaleDateString('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  } catch {
    return dateString;
  }
};

/**
 * Format date for INPUT fields (YYYY-MM-DD) in Kolkata timezone
 * Use this for <input type="date"> fields which require YYYY-MM-DD format
 * 
 * Example:
 *   Input:  "2024-12-15T00:00:00.000Z"
 *   Output: "2024-12-15"
 * 
 * @param {string} dateString - Date string from API
 * @returns {string} Formatted date in YYYY-MM-DD format (Kolkata timezone)
 */
export const formatDateInput = (dateString) => {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);

    // Check if date is valid
    if (isNaN(date.getTime())) {
      return dateString;
    }

    // Convert to Kolkata timezone and format as YYYY-MM-DD
    // Using 'en-CA' locale which naturally outputs YYYY-MM-DD format
    return date.toLocaleDateString('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
  } catch {
    return dateString;
  }
};

/**
 * Get today's date in YYYY-MM-DD format (Kolkata timezone)
 * Use this for setting min attribute on date inputs
 * 
 * @returns {string} Today's date in YYYY-MM-DD format
 */
export const getTodayDateInput = () => {
  const now = new Date();
  return now.toLocaleDateString('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
};

/**
 * Get next date from a given date in YYYY-MM-DD format
 * 
 * @param {string} dateString - Date string in YYYY-MM-DD format
 * @returns {string} Next day's date in YYYY-MM-DD format
 */
export const getNextDateInput = (dateString) => {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);
    date.setDate(date.getDate() + 1);
    return date.toLocaleDateString('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
  } catch {
    return dateString;
  }
};

// ═══════════════════════════════════════════════════════════════
// 📡 PDP API SERVICES
// ═══════════════════════════════════════════════════════════════

// ✅ Fetch only active Market Areas
export const getMarketAreas = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.createPdpendpoints.getActiveMarketarea}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // ✅ API returns { status: true, data: [...] }
    if (response.status === 200 && response.data.status) {
      // return active areas with id + name (marketarea)
      const activeAreas = response.data.data
        .filter((item) => item.isActive === 1)
        .map((item) => ({ id: item.id, marketarea: item.marketarea }));
      return activeAreas;
    }

    throw new Error(response.data.message || "Failed to fetch market areas");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";   // redirect to login
    }
    console.error("Error fetching market areas:", error);

    throw new Error(
      error.response?.data?.message ||
      error.message ||
      "Failed to fetch market areas"
    );
  }
};


export const getActiveDealers = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No auth token");

    const response = await axios.get(
      `${API.domain}${API.createPdpendpoints.getActiveDealers}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    if (response.status === 200 && response.data.status) {
      // return only active dealers as objects
      return response.data.data.filter(d => d.isActive === 1);
    }

    return [];
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";   // redirect to login
    }
    console.error(error);
    return [];
  }
};

// ====================== PDP CRUD ======================= //

/**
 * Create PDP records for multiple dealers
 * @param {Object} payload - PDP data
 * @param {number} payload.year - Year
 * @param {number} payload.market_area - Market area ID
 * @param {string} payload.choose_dealer - Choose dealer value
 * @param {string} payload.pdp_start_date - PDP start date
 * @param {string} payload.pdp_end_date - PDP end date
 * @param {string} [payload.physical_pdp_start_date] - Physical PDP start date (optional)
 * @param {string} [payload.physical_pdp_end_date] - Physical PDP end date (optional)
 * @param {string} [payload.sign_of_status] - Sign off status: "Not Started", "Closed", or "Ongoing" (optional, defaults to "Not Started")
 * @param {Array<number>} payload.dealers - Array of dealer IDs
 * @returns {Promise<Object>} Response with ids (array) and count
 */
export const createPdp = async (payload) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    // Validate dealers array
    if (!payload.dealers || !Array.isArray(payload.dealers) || payload.dealers.length === 0) {
      throw new Error("At least one dealer is required");
    }

    // Validate sign_of_status if provided
    const validSignOffStatuses = ["Not Started", "Closed", "Ongoing"];
    if (payload.sign_of_status && !validSignOffStatuses.includes(payload.sign_of_status)) {
      throw new Error(`sign_of_status must be one of: ${validSignOffStatuses.join(", ")}`);
    }

    const response = await axios.post(
      `${API.domain}${API.createPdpendpoints.addPdp}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      // Returns: { status: true, message: "...", ids: [1, 2, 3], count: 3 }
      return response.data;
    }
    throw new Error(response.data.message || "Failed to create PDP");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";   // redirect to login
    }

    throw new Error(error.response?.data?.message || error.message || "Failed to create PDP");
  }
};

/**
 * Get all PDP records
 * @returns {Promise<Array>} Array of PDP records, each with dealer_info: { dealer_id, dealer_name }, sign_of_status, and formatted dates
 */
export const getAllPdp = async (page = 1, filters = {}) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    // Construct query parameters
    const queryParams = new URLSearchParams({ page });

    if (filters.year) queryParams.append('year', filters.year);
    if (filters.market_area) queryParams.append('market_area', filters.market_area);
    if (filters.dealer) queryParams.append('dealer', filters.dealer);
    if (filters.sign_of_status) queryParams.append('sign_of_status', filters.sign_of_status);
    if (filters.action_item_status) queryParams.append('action_item_status', filters.action_item_status);
    if (filters.search) queryParams.append('search', filters.search);

    const response = await axios.get(
      `${API.domain}${API.createPdpendpoints.getAllPdp}?${queryParams.toString()}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      // ⭐ Transform API response with proper date formatting (Kolkata timezone)
      const transformedData = rawData.map((item) => ({
        ...item,
        // ⭐ Display format (DD/MM/YYYY) for tables and labels
        pdpStartDate: item.pdp_start_date ? formatDateDisplay(item.pdp_start_date) : "",
        pdpEndDate: item.pdp_end_date ? formatDateDisplay(item.pdp_end_date) : "",
        physicalPdpStartDate: item.physical_pdp_start_date ? formatDateDisplay(item.physical_pdp_start_date) : "",
        physicalPdpEndDate: item.physical_pdp_end_date ? formatDateDisplay(item.physical_pdp_end_date) : "",
        // ⭐ Raw format (YYYY-MM-DD) for form inputs
        pdpStartDateRaw: item.pdp_start_date ? formatDateInput(item.pdp_start_date) : "",
        pdpEndDateRaw: item.pdp_end_date ? formatDateInput(item.pdp_end_date) : "",
        physicalPdpStartDateRaw: item.physical_pdp_start_date ? formatDateInput(item.physical_pdp_start_date) : "",
        physicalPdpEndDateRaw: item.physical_pdp_end_date ? formatDateInput(item.physical_pdp_end_date) : "",
      }));

      return transformedData;
    }
    throw new Error(response.data.message || "Failed to fetch PDP list");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";   // redirect to login
    }

    throw new Error(error.response?.data?.message || error.message || "Failed to fetch PDP list");
  }
};

/**
 * Get all PDP records with action item counts
 * @returns {Promise<Array>} Array of PDP records, each with dealer_info: { dealer_id, dealer_name }, sign_of_status, action_item_counts: { open, ongoing, closed }, and formatted dates
 */
export const getAllPdpWithActionItemCounts = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}${API.createPdpendpoints.getAllPdpWithActionItemCounts}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      // ⭐ Transform API response with proper date formatting (Kolkata timezone)
      const transformedData = rawData.map((item) => ({
        ...item,
        // ⭐ Display format (DD/MM/YYYY) for tables and labels
        pdpStartDate: item.pdp_start_date ? formatDateDisplay(item.pdp_start_date) : "",
        pdpEndDate: item.pdp_end_date ? formatDateDisplay(item.pdp_end_date) : "",
        physicalPdpStartDate: item.physical_pdp_start_date ? formatDateDisplay(item.physical_pdp_start_date) : "",
        physicalPdpEndDate: item.physical_pdp_end_date ? formatDateDisplay(item.physical_pdp_end_date) : "",
        // ⭐ Raw format (YYYY-MM-DD) for form inputs
        pdpStartDateRaw: item.pdp_start_date ? formatDateInput(item.pdp_start_date) : "",
        pdpEndDateRaw: item.pdp_end_date ? formatDateInput(item.pdp_end_date) : "",
        physicalPdpStartDateRaw: item.physical_pdp_start_date ? formatDateInput(item.physical_pdp_start_date) : "",
        physicalPdpEndDateRaw: item.physical_pdp_end_date ? formatDateInput(item.physical_pdp_end_date) : "",
      }));

      return transformedData;
    }
    throw new Error(response.data.message || "Failed to fetch PDP list with action item counts");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";   // redirect to login
    }

    throw new Error(error.response?.data?.message || error.message || "Failed to fetch PDP list with action item counts");
  }
};

/**
 * Get PDP record by ID
 * @param {number|string} id - PDP ID
 * @returns {Promise<Object>} PDP record with dealer_info: { dealer_id, dealer_name }, sign_of_status, and formatted dates
 */
export const getPdpById = async (id) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP id is required");

    const response = await axios.get(
      `${API.domain}${API.createPdpendpoints.getPdpById}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      const item = response.data.data;

      // ⭐ Transform with proper date formatting (Kolkata timezone)
      return {
        ...item,
        // ⭐ Display format (DD/MM/YYYY) for tables and labels
        pdpStartDate: item.pdp_start_date ? formatDateDisplay(item.pdp_start_date) : "",
        pdpEndDate: item.pdp_end_date ? formatDateDisplay(item.pdp_end_date) : "",
        physicalPdpStartDate: item.physical_pdp_start_date ? formatDateDisplay(item.physical_pdp_start_date) : "",
        physicalPdpEndDate: item.physical_pdp_end_date ? formatDateDisplay(item.physical_pdp_end_date) : "",
        // ⭐ Raw format (YYYY-MM-DD) for form inputs
        pdpStartDateRaw: item.pdp_start_date ? formatDateInput(item.pdp_start_date) : "",
        pdpEndDateRaw: item.pdp_end_date ? formatDateInput(item.pdp_end_date) : "",
        physicalPdpStartDateRaw: item.physical_pdp_start_date ? formatDateInput(item.physical_pdp_start_date) : "",
        physicalPdpEndDateRaw: item.physical_pdp_end_date ? formatDateInput(item.physical_pdp_end_date) : "",
      };
    }
    throw new Error(response.data.message || "Failed to fetch PDP");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";   // redirect to login
    }

    throw new Error(error.response?.data?.message || error.message || "Failed to fetch PDP");
  }
};

/**
 * Update a PDP record
 * @param {Object} payload - PDP data
 * @param {number} payload.id - PDP ID
 * @param {number} payload.year - Year
 * @param {number} payload.market_area - Market area ID
 * @param {number} payload.dealer - Dealer ID (single dealer, not array)
 * @param {string} payload.choose_dealer - Choose dealer value
 * @param {string} payload.pdp_start_date - PDP start date
 * @param {string} payload.pdp_end_date - PDP end date
 * @param {string} [payload.physical_pdp_start_date] - Physical PDP start date (optional)
 * @param {string} [payload.physical_pdp_end_date] - Physical PDP end date (optional)
 * @param {string} [payload.sign_of_status] - Sign off status: "Not Started", "Closed", or "Ongoing" (optional)
 * @returns {Promise<Object>} Response object
 */
export const updatePdpService = async (payload) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!payload?.id) throw new Error("PDP id is required");
    if (!payload?.dealer) throw new Error("Dealer is required");

    // Ensure dealer is a single value, not an array
    if (Array.isArray(payload.dealer)) {
      throw new Error("Dealer must be a single ID, not an array");
    }

    // Validate sign_of_status if provided
    const validSignOffStatuses = ["Not Started", "Closed", "Ongoing"];
    if (payload.sign_of_status && !validSignOffStatuses.includes(payload.sign_of_status)) {
      throw new Error(`sign_of_status must be one of: ${validSignOffStatuses.join(", ")}`);
    }

    const response = await axios.put(
      `${API.domain}${API.createPdpendpoints.updatePdp}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data.message || "Failed to update PDP");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";   // redirect to login
    }

    throw new Error(error.response?.data?.message || error.message || "Failed to update PDP");
  }
};

/**
 * Delete a PDP record (only allowed if status is "Created")
 * @param {number|string} id - PDP ID
 * @returns {Promise<Object>} Response object
 */
export const deletePdpService = async (id) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP id is required");

    const response = await axios.delete(
      `${API.domain}${API.createPdpendpoints.deletePdp}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data.message || "Failed to delete PDP");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";   // redirect to login
    }

    throw new Error(error.response?.data?.message || error.message || "Failed to delete PDP");
  }
};

// ====================== EXPORT ALIASES ======================= //
// Export alias for backward compatibility with ViewPdp.jsx
export const deletePdp = deletePdpService;
export const updatePdp = updatePdpService;