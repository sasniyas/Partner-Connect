import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 CORE API FUNCTIONS - PDP Uptime Parts
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ FUNCTION 1: Get PDP Uptime Parts by PDP ID
 * Fetch all uptime parts records for a specific PDP with optional filters
 * 
 * @param {number} pdpId - The PDP ID (required)
 * @param {Object} filters - Optional filters
 * @param {string} filters.category - Category filter ("Retails" or "Key Account")
 * @returns {Promise<Array>} Array of uptime parts records
 */
export const getPdpUptimePartsByPdpId = async (pdpId, filters = {}) => {
  try {
    // Validate PDP ID
    if (!pdpId) {
      throw new Error("PDP ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getPdpUptimePartsByPdpId}${pdpId}`;
    
    console.log("📡 Fetching PDP Uptime Parts");
    console.log("  URL:", url);
    console.log("  PDP ID:", pdpId);
    console.log("  Filters:", {
      category: filters.category || "none"
    });

    const response = await axios.get(url, {
      params: {
        category: filters.category || undefined
      },
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Raw API Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];
      
      // ⭐ Helper function to clean string fields (removes tabs, newlines, extra spaces)
      const cleanString = (str) => {
        if (!str) return str;
        return str
          .replace(/\t/g, '')    // Remove tabs
          .replace(/\r/g, '')    // Remove carriage returns
          .replace(/\n/g, '')    // Remove newlines
          .replace(/\s+/g, ' ')  // Replace multiple spaces with single space
          .trim();               // Remove leading/trailing spaces
      };

      // ⭐ Transform API response to match component expectations
      const transformedData = rawData.map(item => ({
        // Keep original ID fields
        id: item.id,
        pdpId: item.pdpId,
        uptimePartsId: item.uptimePartsId,
        category: item.category,
        
        // ⭐ Map for Uptimeparts.jsx (summary page) - backward compatibility
        target: item.target || 0,
        total: item.py_target || 0, // Use previous year target as total for summary
        
        // ⭐ Clean all string fields to remove tabs/newlines/extra spaces
        uptime_parts_category: cleanString(item.uptime_parts_category),
        equipment_make: cleanString(item.equipment_make),
        details: cleanString(item.details),
        measurement_units: cleanString(item.measurement_units),
        remarks: item.remarks ? cleanString(item.remarks) : null,
        
        // Year information
        year: item.uptime_parts_year,
        uptime_parts_year: item.uptime_parts_year,
        
        // Previous Year data
        py_pdpUptime_id: item.py_pdpUptime_id,
        py_ytd: item.py_ytd,
        py_eoy: item.py_eoy,
        py_achievement: item.py_achievement,
        py_target: item.py_target,
        
        // Current Year data
        measurements: item.measurements,
        
        // Additional fields for details page
        targetLS: item.py_target || 0,
        ytd: item.py_ytd || 0,
        eoy: item.py_eoy || 0,
        achievement: item.py_achievement || "0.00",
        targetCY: item.target || 0
      }));

      console.log("✅ Uptime Parts data transformed:", transformedData.length, "records");
      if (transformedData.length > 0) {
        console.log("📦 Sample transformed data:", {
          id: transformedData[0].id,
          category: transformedData[0].category,
          equipment_make: transformedData[0].equipment_make,
          details: transformedData[0].details,
          year: transformedData[0].year,
          target: transformedData[0].target,
          total: transformedData[0].total
        });
      }
      
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch uptime parts");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getPdpUptimePartsByPdpId Error:", error.message);
    
    if (error.response) {
      console.error("❌ Response Error:", {
        status: error.response.status,
        data: error.response.data
      });
    }
    
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch uptime parts"
    );
  }
};

/**
 * ✅ FUNCTION 2: Update Multiple PDP Uptime Parts
 * Bulk update multiple uptime parts records in a single API call
 * 
 * @param {Array<Object>} rows - Array of uptime parts objects to update
 * @returns {Promise<Object>} Response data with update results
 */
export const updateMultiplePdpUptimeParts = async (rows) => {
  try {
    // Validate input
    if (!Array.isArray(rows) || rows.length === 0) {
      throw new Error("Rows array is required and cannot be empty");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.updateMultiplePdpUptimeParts}`;
    console.log("📡 Updating Multiple PDP Uptime Parts");
    console.log("  URL:", url);
    console.log("  Rows to update:", rows.length);
    console.log("  Sample row:", rows[0]);

    const response = await axios.put(
      url, 
      { rows }, 
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Update Response:", {
      status: response.status,
      message: response.data.message,
      updatedCount: response.data.data?.updatedCount || rows.length
    });

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update uptime parts");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updateMultiplePdpUptimeParts Error:", error.message);
    
    if (error.response) {
      console.error("❌ Response Error:", {
        status: error.response.status,
        data: error.response.data
      });
    }
    
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to update uptime parts"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📤 DEFAULT EXPORT
// ═══════════════════════════════════════════════════════════════

