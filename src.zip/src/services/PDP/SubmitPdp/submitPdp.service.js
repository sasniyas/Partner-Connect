// services/PDP/SubmitPdp/submitPdp.service.js

import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════
const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  if (!token) {
    throw new Error("Authentication token not found");
  }
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };
};

const handleAuthError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ═══════════════════════════════════════════════════════════════
// START PDP - Changes status from "Created" to "Started"
// ═══════════════════════════════════════════════════════════════
export const startPDP = async ({ pdpId }) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.pdpStatusChange}`;
    console.log("📡 Starting PDP - URL:", url);

    const response = await axios.put(
      url,
      {
        id: pdpId,
        status: "Started"
      },
      { headers: getAuthHeaders() }
    );

    console.log("✅ Start Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to start PDP");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ startPDP Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to start PDP"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// SUBMIT PDP - Changes status to "Pending Review"
// ═══════════════════════════════════════════════════════════════
export const submitPDP = async ({ pdpId }) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.pdpStatusChange}`;
    console.log("📡 Submitting PDP - URL:", url);

    const response = await axios.put(
      url,
      {
        id: pdpId,
        status: "Submit"  // Backend maps this to "Pending Review"
      },
      { headers: getAuthHeaders() }
    );

    console.log("✅ Submit Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to submit PDP");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ submitPDP Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to submit PDP"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// APPROVE PDP - Changes status to "Approved"
// ═══════════════════════════════════════════════════════════════
export const approvePDP = async ({ pdpId }) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.pdpStatusChange}`;
    console.log("📡 Approving PDP - URL:", url);

    const response = await axios.put(
      url,
      {
        id: pdpId,
        status: "Approved"
      },
      { headers: getAuthHeaders() }
    );

    console.log("✅ Approve Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to approve PDP");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ approvePDP Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to approve PDP"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// RETURN PDP - Changes status back to "Started" with comments
// ═══════════════════════════════════════════════════════════════
export const returnPDP = async ({ pdpId, comments }) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.pdpStatusChange}`;
    console.log("📡 Returning PDP - URL:", url);

    const response = await axios.put(
      url,
      {
        id: pdpId,
        status: "Return",
        return_back_comment: comments || null
      },
      { headers: getAuthHeaders() }
    );

    console.log("✅ Return Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to return PDP");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ returnPDP Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to return PDP"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// GET RETURN COMMENTS - Fetches return comment from PDP
// ═══════════════════════════════════════════════════════════════
export const getReturnComments = async (pdpId) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.getPdpById}${pdpId}`;
    console.log("📡 Fetching PDP for return comments - URL:", url);

    const response = await axios.get(url, { headers: getAuthHeaders() });

    console.log("✅ PDP Response:", response.data);

    if (response.status === 200 && response.data.status) {
      const pdpData = response.data.data;
      // Return comments in expected format for frontend
      if (pdpData.return_back_comment) {
        return {
          data: [{
            return_comments: pdpData.return_back_comment,
            returned_at: pdpData.updated_at
          }]
        };
      }
      return { data: [] };
    }

    throw new Error(response.data.message || "Failed to fetch return comments");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ getReturnComments Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch return comments"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// SCHEDULE SIGNOFF MEETING - Updates meeting details for PDP
// ═══════════════════════════════════════════════════════════════
export const scheduleSignoffMeeting = async ({
  pdpId,
  signoffMeetingDate,
  venueDetails,
  specialNote
}) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.updatePdpMeetingDetails}`;
    console.log("📡 Scheduling Signoff Meeting - URL:", url);

    const response = await axios.put(
      url,
      {
        id: pdpId,
        sign_off_meeting_date: signoffMeetingDate,
        venue_details: venueDetails,
        special_note: specialNote || null
      },
      { headers: getAuthHeaders() }
    );

    console.log("✅ Meeting Schedule Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to schedule meeting");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ scheduleSignoffMeeting Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to schedule meeting"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// GET PDP BY ID - Fetches complete PDP details
// ═══════════════════════════════════════════════════════════════
export const getPdpById = async (pdpId) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.getPdpById}${pdpId}`;
    console.log("📡 Fetching PDP by ID - URL:", url);

    const response = await axios.get(url, { headers: getAuthHeaders() });

    console.log("✅ PDP Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to fetch PDP");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ getPdpById Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch PDP"
    );
  }
};