import axios from "axios";
import { API } from "../../../api"; // adjust path as needed

// ✅ Fetch only active Market Areas
export const getMarketAreas = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.createPdpendpoints.getActiveMarketarea}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // ✅ API returns { status: true, data: [...] }
    if (response.status === 200 && response.data.status) {
      // return active areas with id + name (marketarea)
      const activeAreas = response.data.data
        .filter((item) => item.isActive === 1)
        .map((item) => ({ id: item.id, marketarea: item.marketarea }));
      return activeAreas;
    }

    throw new Error(response.data.message || "Failed to fetch market areas");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching market areas:", error);

    // ✅ Handle token errors gracefully
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch market areas"
    );
  }
};


export const getActiveDealers = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No auth token");

    const response = await axios.get(
      `${API.domain}${API.createPdpendpoints.getActiveDealers}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    if (response.status === 200 && response.data.status) {
      // return only active dealers as objects
      return response.data.data.filter(d => d.isActive === 1);
    }

    return [];
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error(error);
    return [];
  }
};

// ====================== PDP CRUD ======================= //

export const createPdp = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.post(
      `${API.domain}${API.endpoints.addPdp}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data.message || "Failed to create PDP");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(error.response?.data?.message || error.message || "Failed to create PDP");
  }
};

export const getAllPdp = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}${API.endpoints.getAllPdp}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(response.data.message || "Failed to fetch PDP list");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch PDP list");
  }
};

export const getPdpById = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP id is required");

    const response = await axios.get(
      `${API.domain}${API.endpoints.getPdpById}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }
    throw new Error(response.data.message || "Failed to fetch PDP");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
  
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch PDP");
  }
};

export const updatePdpService = async (payload) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!payload?.id) throw new Error("PDP id is required");

    const response = await axios.put(
      `${API.domain}${API.endpoints.updatePdp}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data.message || "Failed to update PDP");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
   
    throw new Error(error.response?.data?.message || error.message || "Failed to update PDP");
  }
};

export const deletePdpService = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");
    if (!id) throw new Error("PDP id is required");

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deletePdp}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data.message || "Failed to delete PDP");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
  
    throw new Error(error.response?.data?.message || error.message || "Failed to delete PDP");
  }
};