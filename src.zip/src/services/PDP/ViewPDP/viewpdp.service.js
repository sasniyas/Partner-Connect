import axios from "axios";
import { API } from "../../../api"; // adjust path as needed

// ✅ Fetch all Market Areas
export const getAllMarketAreas = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.createPdpendpoints.getActiveMarketarea}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    // ✅ Return all market areas, regardless of isActive
    if (response.status === 200 && response.data.status) {
      const allAreas = response.data.data.map((item) => item.marketarea);
      return allAreas;
    }

    throw new Error(response.data.message || "Failed to fetch market areas");
  } catch (error) {
    const message = error.response?.data?.message;

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/"; // redirect to login
    }
    console.error("Error fetching market areas:", error);

    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch market areas"
    );
  }
};

export const getAllDealers = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No auth token");

    const response = await axios.get(
      `${API.domain}${API.createPdpendpoints.getActiveDealers}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    if (response.status === 200 && response.data.status) {
      // ✅ Return all dealers regardless of active/inactive
      return response.data.data || [];
    }

    return [];
  } catch (error) {
    const message = error.response?.data?.message;

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/"; // redirect to login
    }
    console.error("Error fetching dealers:", error);
    return [];
  }
};