import axios from "axios";
import { API } from "../../../api";

/**
 * Get PDP Upload Files by PDP ID
 * @param {number} pdpId - The PDP ID
 * @returns {Promise<Array>} Array of upload file records
 */
export const getPdpUploadFilesByPdpId = async (pdpId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getPdpUploadFilesByPdpId}${pdpId}`;
    console.log("📡 Fetching PDP Upload Files by PDP ID - URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("📦 API Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    throw new Error(response.data.message || "Failed to fetch upload files");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getPdpUploadFilesByPdpId Error:", error);
    
   

    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to fetch upload files"
    );
  }
};

/**
 * Add PDP Upload File
 * @param {FormData} formData - Form data with file and details
 * @returns {Promise<Object>} Response data
 */
export const addPdpUploadFile = async (formData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.addPdpUploadFile}`;
    console.log("📡 Adding PDP Upload File - URL:", url);

    const response = await axios.post(url, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("📦 Add Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to add upload file");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ addPdpUploadFile Error:", error);
    
   

    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to add upload file"
    );
  }
};

/**
 * Update PDP Upload File
 * @param {FormData} formData - Form data with updated file and details
 * @returns {Promise<Object>} Response data
 */
export const updatePdpUploadFile = async (formData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.updatePdpUploadFile}`;
    console.log("📡 Updating PDP Upload File - URL:", url);

    const response = await axios.put(url, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update upload file");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updatePdpUploadFile Error:", error);
    
   

    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to update upload file"
    );
  }
};

/**
 * Delete PDP Upload File (Soft Delete)
 * @param {number} id - The upload file ID
 * @returns {Promise<Object>} Response data
 */
export const deletePdpUploadFile = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.deletePdpUploadFile}${id}`;
    console.log("📡 Deleting PDP Upload File - URL:", url);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete upload file");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ deletePdpUploadFile Error:", error);
    
   
    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to delete upload file"
    );
  }
};

/**
 * Download Default Presentation Template
 * @returns {Promise<Blob>} File blob for download
 */
export const getDefaultPreTemplate = async () => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getDefaultPreTemplate}`;
    console.log("📡 Downloading Presentation Template - URL:", url);

    const response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      }
    });

    console.log("✅ Template Download Response:", response);

    if (response.status === 200) {
      const link = document.createElement('a');
      link.href = response.data.data.url
      
      const contentDisposition = response.headers['content-disposition'];
      let fileName = 'PDP_Presentation_Template.pptx';
      
      if (contentDisposition) {
        const fileNameMatch = contentDisposition.match(/filename="(.+)"/);
        if (fileNameMatch && fileNameMatch.length === 2) {
          fileName = fileNameMatch[1];
        }
      }
      
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(link);
      
      return { status: true, message: "Template downloaded successfully" };
    }

    throw new Error("Failed to download presentation template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getDefaultPreTemplate Error:", error);
    
   

    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to download presentation template"
    );
  }
};

/**
 * Download Default Finance Template
 * @returns {Promise<Blob>} File blob for download
 */
export const getDefaultFinTemplate = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getDefaultFinTemplate}`;
    console.log("📡 Downloading Finance Template - URL:", url);

    const response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      }
    });

    console.log("✅ Template Download Response:", response);

    if (response.status === 200) {
      const link = document.createElement('a');
      link.href = response.data.data.url
      
      const contentDisposition = response.headers['content-disposition'];
      let fileName = 'PDP_Finance_Template.xlsx';
      
      if (contentDisposition) {
        const fileNameMatch = contentDisposition.match(/filename="(.+)"/);
        if (fileNameMatch && fileNameMatch.length === 2) {
          fileName = fileNameMatch[1];
        }
      }
      
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(link);
      
      return { status: true, message: "Template downloaded successfully" };
    }

    throw new Error("Failed to download finance template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getDefaultFinTemplate Error:", error);
    
   

    throw new Error(
      error.response?.data?.message ||
        error.message ||
        "Failed to download finance template"
    );
  }
};