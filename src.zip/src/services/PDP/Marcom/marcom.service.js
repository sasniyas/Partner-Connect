import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 MARCOM BRANDING APIs
// ═══════════════════════════════════════════════════════════════

/**
 * Get PDP Marcom Branding by PDP ID
 */
export const getPdpMarcomBrandingByPdpId = async (pdpId) => {
  try {
    if (!pdpId) {
      throw new Error("PDP ID is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getPdpMarcomBrandingByPdpId}${pdpId}`;
    
    console.log("📡 Fetching Marcom Branding");
    console.log("  URL:", url);
    console.log("  PDP ID:", pdpId);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Branding Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];
      
      const transformedData = rawData.map(item => ({
        id: item.id,
        pdpId: item.pdpId,
        marcomBrandingId: item.marcom_branding_id,
        marcomId: item.marcom_id,
        marcomType: item.marcom_type,
        marcomName: item.marcom_name,
        budget: item.budget || "",
        remarks: item.remarks || "",
        supportiveDocUrl: item.supportive_doc_url || null,
        documentName: item.supportive_doc_url ? item.supportive_doc_url.split('/').pop() : "",
        year: item.pdp_year,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        createdAt: item.created_at,
        updatedAt: item.updated_at
      }));

      console.log("✅ Branding data transformed:", transformedData.length, "records");
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch branding data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getPdpMarcomBrandingByPdpId Error:", error.message);
    
    

    throw new Error(error.response?.data?.message || error.message || "Failed to fetch branding data");
  }
};

/**
 * Update Multiple PDP Marcom Branding records (Budget & Remarks)
 */
export const updateMultiplePdpMarcomBranding = async (records) => {
  try {
    if (!records || records.length === 0) {
      throw new Error("No records to update");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.updateMultiplePdpMarcomBranding}`;
    
    console.log("📡 Updating Multiple Marcom Branding");
    console.log("  URL:", url);
    console.log("  Records count:", records.length);

    const apiData = records.map(record => ({
      id: parseInt(record.id),
      budget: record.budget || null,
      remarks: record.remarks || null
    }));

    const payload = { rows: apiData };

    console.log("📤 API Data being sent:", payload);

    const response = await axios.put(url, payload, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update branding records");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updateMultiplePdpMarcomBranding Error:", error.message);
    console.error("❌ Error details:", error.response?.data);
    
    

    throw new Error(error.response?.data?.message || error.message || "Failed to update branding records");
  }
};

/**
 * Update PDP Marcom Supportive Document
 * ⭐ FIXED: Removed const reassignment error
 */
export const updatePdpMarcomSupdoc = async (recordId, fileToUpload) => {
  try {
    if (!recordId) {
      throw new Error("Record ID is required");
    }
    if (!fileToUpload) {
      throw new Error("File is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.updatePdpMarcomSupdoc}`;
    
    console.log("📡 Uploading Marcom Document");
    console.log("  URL:", url);
    console.log("  Record ID:", recordId);
    console.log("  File name:", fileToUpload.name);
    console.log("  File size:", (fileToUpload.size / 1024 / 1024).toFixed(2), "MB");
    console.log("  File type:", fileToUpload.type);

    const formData = new FormData();
    formData.append("id", recordId.toString());
    formData.append("file", fileToUpload);

    console.log("📤 Sending FormData...");

    const response = await axios.put(url, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Upload Response:", response);
    console.log("  Status:", response.status);
    console.log("  Data:", response.data);

    if (response.status === 200 && response.data) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to upload document");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updatePdpMarcomSupdoc Error:");
    console.error("  Message:", error.message);
    console.error("  Response Status:", error.response?.status);
    console.error("  Response Data:", error.response?.data);
    
  
    const errorMessage = error.response?.data?.message || error.message || "Failed to upload document";
    throw new Error(errorMessage);
  }
};

/**
 * Delete PDP Marcom Supportive Document
 */
export const deletePdpMarcomSupdoc = async (recordId) => {
  try {
    if (!recordId) {
      throw new Error("Record ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.deletePdpMarcomSupdoc}${recordId}`;
    
    console.log("📡 Deleting Marcom Document");
    console.log("  URL:", url);
    console.log("  Record ID:", recordId);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete document");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ deletePdpMarcomSupdoc Error:", error.message);
    
   

    throw new Error(error.response?.data?.message || error.message || "Failed to delete document");
  }
};

// ═══════════════════════════════════════════════════════════════
// 📡 MARCOM MARKETING APIs
// ═══════════════════════════════════════════════════════════════

/**
 * Get PDP Marcom Marketing by PDP ID
 */
export const getPdpMarcomMarketingByPdpId = async (pdpId) => {
  try {
    if (!pdpId) {
      throw new Error("PDP ID is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getPdpMarcomMarketingByPdpId}${pdpId}`;
    
    console.log("📡 Fetching Marcom Marketing");
    console.log("  URL:", url);
    console.log("  PDP ID:", pdpId);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Marketing Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];
      
      const transformedData = rawData.map(item => ({
        id: item.id,
        pdpId: item.pdpId,
        marcomMarketingId: item.marcom_marketing_id,
        marcommrkId: item.marcommrk_id,
        activityType: item.activity_Type,
        target: item.target,
        marketingArea: item.marketing_area || "",
        countOfActivities: item.count_of_activities || "",
        activityDescription: item.activity_description || "",
        amountSpent: item.amount_spent || "",
        impacts: item.impacts || "",
        year: item.pdp_year,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        createdAt: item.created_at,
        updatedAt: item.updated_at
      }));

      console.log("✅ Marketing data transformed:", transformedData.length, "records");
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch marketing data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getPdpMarcomMarketingByPdpId Error:", error.message);
   

    throw new Error(error.response?.data?.message || error.message || "Failed to fetch marketing data");
  }
};

/**
 * Update Multiple PDP Marcom Marketing records
 */
export const updateMultiplePdpMarcomMarketing = async (records) => {
  try {
    if (!records || records.length === 0) {
      throw new Error("No records to update");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.updateMultiplePdpMarcomMarketing}`;
    
    console.log("📡 Updating Multiple Marcom Marketing");
    console.log("  URL:", url);
    console.log("  Records count:", records.length);

    const apiData = records.map(record => ({
      id: parseInt(record.id),
      marketing_area: record.marketing_area || null,
      count_of_activities: record.count_of_activities || null,
      activity_description: record.activity_description || null,
      amount_spent: record.amount_spent || null,
      impacts: record.impacts || null
    }));

    const payload = { rows: apiData };

    console.log("📤 API Data being sent:", payload);

    const response = await axios.put(url, payload, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update marketing records");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updateMultiplePdpMarcomMarketing Error:", error.message);
    console.error("❌ Error details:", error.response?.data);
    
  
    throw new Error(error.response?.data?.message || error.message || "Failed to update marketing records");
  }
};

// ═══════════════════════════════════════════════════════════════
// 📤 DEFAULT EXPORT
// ═══════════════════════════════════════════════════════════════

