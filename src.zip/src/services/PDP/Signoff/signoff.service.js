// services/PDP/Signoff/signoff.service.js

import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════
const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  if (!token) {
    throw new Error("Authentication token not found");
  }
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };
};

const handleAuthError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ═══════════════════════════════════════════════════════════════
// API FUNCTIONS
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ FUNCTION 1: Add PDP Signoff
 * @param {Object} payload - { pdpId, userId, category }
 * @returns {Promise<Object>} Response data
 */
export const addPdpSignoff = async (payload) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.addPdpSignoff}`;
    console.log("📡 Adding PDP Signoff - URL:", url);

    const response = await axios.post(url, payload, { headers: getAuthHeaders() });

    console.log("✅ Add Signoff Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to add PDP Signoff");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ addPdpSignoff Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add PDP Signoff"
    );
  }
};

/**
 * ✅ FUNCTION 2: Get All PDP Signoffs
 * @returns {Promise<Array>} Array of all signoff records
 */
export const getAllPdpSignoffs = async () => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.getAllPdpSignoffs}`;
    console.log("📡 Fetching All PDP Signoffs - URL:", url);

    const response = await axios.get(url, { headers: getAuthHeaders() });

    console.log("📦 API Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    throw new Error(response.data.message || "Failed to fetch all PDP Signoffs");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ getAllPdpSignoffs Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch all PDP Signoffs"
    );
  }
};

/**
 * ✅ FUNCTION 3: Get PDP Signoff by ID
 * @param {number} id - Signoff ID
 * @returns {Promise<Object>} Signoff record
 */
export const getPdpSignoffById = async (id) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.getPdpSignoffById}${id}`;
    console.log("📡 Fetching PDP Signoff by ID - URL:", url);

    const response = await axios.get(url, { headers: getAuthHeaders() });

    console.log("📦 API Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to fetch PDP Signoff");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ getPdpSignoffById Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch PDP Signoff"
    );
  }
};

/**
 * ✅ FUNCTION 4: Fetch PDP Signoffs by PDP ID
 * This is the MAIN function used by SignoffStatus component
 * @param {number} pdpId - The PDP ID
 * @returns {Promise<Array>} Array of signoff records for the PDP
 */
export const getPdpSignoffsByPdpId = async (pdpId) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.getPdpSignoffsByPdpId}${pdpId}`;
    console.log("📡 Fetching PDP Signoffs by PDP ID - URL:", url);

    const response = await axios.get(url, { headers: getAuthHeaders() });

    console.log("📦 API Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    throw new Error(response.data.message || "Failed to fetch PDP Signoffs");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ getPdpSignoffsByPdpId Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch PDP Signoffs"
    );
  }
};

/**
 * ✅ FUNCTION 5: Get PDP Signoffs by User ID
 * @param {number} userId - User ID
 * @returns {Promise<Array>} Array of signoff records for the user
 */
export const getPdpSignoffsByUserId = async (userId) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.getPdpSignoffsByUserId}${userId}`;
    console.log("📡 Fetching PDP Signoffs by User ID - URL:", url);

    const response = await axios.get(url, { headers: getAuthHeaders() });

    console.log("📦 API Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    throw new Error(response.data.message || "Failed to fetch PDP Signoffs by User");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ getPdpSignoffsByUserId Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch PDP Signoffs by User"
    );
  }
};

/**
 * ✅ FUNCTION 6: Update PDP Signoff (Sign Off)
 * Used when user clicks "Sign Off Now"
 * Backend will auto-complete PDP when all signoffs are done
 * @param {number} id - The signoff record ID
 * @param {boolean|Object} payload - Either boolean isSigned or object with full payload
 * @returns {Promise<Object>} Response data
 */
export const updatePdpSignoff = async (id, payload) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.updatePdpSignoff}`;
    console.log("📡 Updating PDP Signoff - URL:", url);

    // Handle both boolean and object payloads
    let requestBody;
    if (typeof payload === 'boolean') {
      requestBody = { id, isSigned: payload };
    } else if (typeof payload === 'object') {
      requestBody = { id, ...payload };
    } else {
      requestBody = { id, isSigned: true };
    }

    console.log("📝 Payload:", requestBody);

    const response = await axios.put(url, requestBody, { headers: getAuthHeaders() });

    console.log("✅ Update Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update PDP Signoff");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ updatePdpSignoff Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update PDP Signoff"
    );
  }
};

/**
 * ✅ FUNCTION 7: Sign PDP Signoff (Convenience method)
 * Quick sign off method - sets isSigned to true
 * @param {number} id - The signoff record ID
 * @returns {Promise<Object>} Response data
 */
export const signPdpSignoff = async (id) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.signPdpSignoff}`;
    console.log("📡 Signing PDP Signoff - URL:", url);

    const response = await axios.put(url, { id }, { headers: getAuthHeaders() });

    console.log("✅ Sign Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to sign PDP Signoff");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ signPdpSignoff Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to sign PDP Signoff"
    );
  }
};

/**
 * ✅ FUNCTION 8: Delete PDP Signoff (Soft Delete)
 * @param {number} id - The signoff record ID
 * @returns {Promise<Object>} Response data
 */
export const deletePdpSignoff = async (id) => {
  try {
    const url = `${API.domain}${API.createPdpendpoints.deletePdpSignoff}${id}`;
    console.log("📡 Deleting PDP Signoff - URL:", url);

    const response = await axios.delete(url, { headers: getAuthHeaders() });

    console.log("✅ Delete Response:", response.data);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete PDP Signoff");
  } catch (error) {
    handleAuthError(error);
    console.error("❌ deletePdpSignoff Error:", error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete PDP Signoff"
    );
  }
};

/**
 * ✅ FUNCTION 9: Bulk Update Multiple Signoffs
 * Used when signing off multiple items at once
 * @param {Array<{id: number, isSigned: boolean}>} signoffs - Array of signoff updates
 * @returns {Promise<Object>} Response data
 */
export const bulkUpdatePdpSignoffs = async (signoffs) => {
  try {
    console.log("📡 Bulk Updating PDP Signoffs");
    console.log("📝 Payload:", signoffs);

    const promises = signoffs.map(signoff =>
      updatePdpSignoff(signoff.id, signoff.isSigned)
    );

    const results = await Promise.all(promises);
    console.log("✅ Bulk Update Results:", results);

    return { status: true, message: "All signoffs updated successfully" };
  } catch (error) {
    handleAuthError(error);
    console.error("❌ bulkUpdatePdpSignoffs Error:", error);
    throw new Error(
      error.message || "Failed to bulk update PDP Signoffs"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// HELPER FUNCTIONS (Non-API)
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ FUNCTION 10: Get Signoff Statistics (Helper function)
 * Calculate signoff completion statistics
 * @param {Array} signoffs - Array of signoff records
 * @returns {Object} Statistics object
 */
export const getSignoffStats = (signoffs) => {
  if (!Array.isArray(signoffs) || signoffs.length === 0) {
    return {
      total: 0,
      signed: 0,
      pending: 0,
      percentage: 0
    };
  }

  const total = signoffs.length;
  const signed = signoffs.filter(s => s.isSigned === 1 || s.isSigned === true).length;
  const pending = total - signed;
  const percentage = total > 0 ? Math.round((signed / total) * 100) : 0;

  return {
    total,
    signed,
    pending,
    percentage
  };
};

/**
 * ✅ FUNCTION 11: Check if all signoffs are complete
 * @param {Array} signoffs - Array of signoff records
 * @returns {boolean} True if all are signed
 */
export const areAllSignoffsComplete = (signoffs) => {
  if (!Array.isArray(signoffs) || signoffs.length === 0) {
    return false;
  }

  return signoffs.every(s => s.isSigned === 1 || s.isSigned === true);
};

/**
 * ✅ FUNCTION 12: Get pending signoffs
 * @param {Array} signoffs - Array of signoff records
 * @returns {Array} Array of pending signoffs
 */
export const getPendingSignoffs = (signoffs) => {
  if (!Array.isArray(signoffs)) {
    return [];
  }

  return signoffs.filter(s => s.isSigned !== 1 && s.isSigned !== true);
};

/**
 * ✅ FUNCTION 13: Get completed signoffs
 * @param {Array} signoffs - Array of signoff records
 * @returns {Array} Array of completed signoffs
 */
export const getCompletedSignoffs = (signoffs) => {
  if (!Array.isArray(signoffs)) {
    return [];
  }

  return signoffs.filter(s => s.isSigned === 1 || s.isSigned === true);
};

/**
 * ✅ FUNCTION 14: Sort signoffs by category order
 * Maintains consistent display order regardless of signed status
 * @param {Array} signoffs - Array of signoff records
 * @param {Object} categoryOrder - Custom order mapping (optional)
 * @returns {Array} Sorted signoffs array
 */
export const sortSignoffsByCategory = (signoffs, categoryOrder = null) => {
  if (!Array.isArray(signoffs)) {
    return [];
  }

  const defaultCategoryOrder = {
    'Sales_Head': 1,
    'CEO': 2,
    'Business_Head': 3,
    'Regional_Head': 4,
    'Equipments_Volvo': 1,
    'Equipments_Dealer': 2,
    'Uptime_Volvo': 1,
    'Uptime_Dealer': 2,
  };

  const orderMap = categoryOrder || defaultCategoryOrder;

  return [...signoffs].sort((a, b) => {
    const orderA = orderMap[a.category] || 999;
    const orderB = orderMap[b.category] || 999;
    return orderA - orderB;
  });
};

/**
 * ✅ FUNCTION 15: Get category display name
 * Convert backend category codes to user-friendly names
 * CORRECTED: Aligned with backend categories
 * @param {string} category - Category code
 * @returns {string} Display name
 */
export const getCategoryDisplayName = (category) => {
  const categoryNames = {
    // ═══════════════════════════════════════════════════════════════
    // PDP FINAL SIGN OFF CATEGORIES
    // ═══════════════════════════════════════════════════════════════
    'Sales_Head': 'Dealer Sales Head',
    'CEO': 'Dealer Principal / CEO',
    'Business_Head': 'Volvo CE Retail Sales Manager',
    'Regional_Head': 'Head Of Channel Development Region India',

    // ═══════════════════════════════════════════════════════════════
    // EQUIPMENT CATEGORIES
    // ═══════════════════════════════════════════════════════════════
    'Equipments_Volvo': 'Volvo CE Retail Sales Manager',
    'Equipments_Dealer': 'Dealer Sales Head',
    'Equipment_Volvo': 'Volvo CE Retail Sales Manager',
    'Equipment_Dealer': 'Dealer Sales Head',

    // ═══════════════════════════════════════════════════════════════
    // UPTIME & PARTS CATEGORIES
    // ═══════════════════════════════════════════════════════════════
    'Uptime_Volvo': 'Volvo CE MA Uptime & Parts Head',
    'Uptime_Dealer': 'Dealer Uptime & Parts Head',
  };

  return categoryNames[category] || category;
};

/**
 * ✅ FUNCTION 16: Validate signoff data
 * Check if signoff data is valid before processing
 * @param {Object} signoff - Signoff record
 * @returns {Object} Validation result
 */
export const validateSignoffData = (signoff) => {
  const errors = [];

  if (!signoff) {
    errors.push("Signoff data is missing");
  }

  if (!signoff?.id) {
    errors.push("Signoff ID is required");
  }

  if (!signoff?.category) {
    errors.push("Category is required");
  }

  return {
    isValid: errors.length === 0,
    errors
  };
};

// ═══════════════════════════════════════════════════════════════
// ROLE-BASED VISIBILITY HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ FUNCTION 17: Get visible categories based on user role
 * @param {string} userRole - User's role
 * @param {Array} allCategories - All available categories
 * @returns {Array} Visible categories for the user
 */
export const getVisibleCategoriesForRole = (userRole, allCategories = []) => {
  const roleLower = userRole?.toLowerCase() || '';

  // Role mappings
  const DEALER_SALES_HEAD_ROLES = [
    "dealer sales head",
    "dealer ceo",
    "dealer principal"
  ];

  const VOLVO_RETAIL_SALES_MANAGER_ROLES = [
    "market area head",
    "retail sales manager",
    "administrator",
    "head of channel developement (region india)"
  ];

  const DEALER_CEO_ROLES = [
    "dealer principal",
    "dealer ceo"
  ];

  const REGIONAL_HEAD_ROLES = [
    "administrator",
    "head of channel developement (region india)"
  ];

  const DEALER_UPTIME_ROLES = [
    "dealer cst head",
    "dealer ceo",
    "dealer principal"
  ];

  const VOLVO_UPTIME_ROLES = [
    "uptime & parts manager",
    "administrator",
    "head of channel developement (region india)"
  ];

  const visible = [];

  allCategories.forEach(category => {
    switch (category) {
      case 'Sales_Head':
        if (DEALER_SALES_HEAD_ROLES.includes(roleLower)) visible.push(category);
        break;
      case 'Business_Head':
        if (VOLVO_RETAIL_SALES_MANAGER_ROLES.includes(roleLower)) visible.push(category);
        break;
      case 'CEO':
        if (DEALER_CEO_ROLES.includes(roleLower)) visible.push(category);
        break;
      case 'Regional_Head':
        if (REGIONAL_HEAD_ROLES.includes(roleLower)) visible.push(category);
        break;
      case 'Equipments_Volvo':
      case 'Equipment_Volvo':
        if (VOLVO_RETAIL_SALES_MANAGER_ROLES.includes(roleLower)) visible.push(category);
        break;
      case 'Equipments_Dealer':
      case 'Equipment_Dealer':
        if (DEALER_SALES_HEAD_ROLES.includes(roleLower)) visible.push(category);
        break;
      case 'Uptime_Volvo':
        if (VOLVO_UPTIME_ROLES.includes(roleLower)) visible.push(category);
        break;
      case 'Uptime_Dealer':
        if (DEALER_UPTIME_ROLES.includes(roleLower)) visible.push(category);
        break;
      default:
        break;
    }
  });

  return visible;
};

/**
 * ✅ FUNCTION 18: Check if user can sign a specific category
 * @param {string} userRole - User's role
 * @param {string} category - Category to check
 * @returns {boolean} True if user can sign
 */
export const canUserSignCategory = (userRole, category) => {
  const roleLower = userRole?.toLowerCase() || '';

  const rolePermissions = {
    'Sales_Head': ["dealer sales head", "dealer ceo", "dealer principal"],
    'Business_Head': ["market area head", "retail sales manager", "administrator", "head of channel developement (region india)"],
    'CEO': ["dealer principal", "dealer ceo"],
    'Regional_Head': ["administrator", "head of channel developement (region india)"],
    'Equipments_Volvo': ["market area head", "retail sales manager", "administrator", "head of channel developement (region india)"],
    'Equipments_Dealer': ["dealer sales head", "dealer ceo", "dealer principal"],
    'Equipment_Volvo': ["market area head", "retail sales manager", "administrator", "head of channel developement (region india)"],
    'Equipment_Dealer': ["dealer sales head", "dealer ceo", "dealer principal"],
    'Uptime_Volvo': ["uptime & parts manager", "administrator", "head of channel developement (region india)"],
    'Uptime_Dealer': ["dealer cst head", "dealer ceo", "dealer principal"],
  };

  const allowedRoles = rolePermissions[category] || [];
  return allowedRoles.includes(roleLower);
};

/**
 * ✅ FUNCTION 19: Get user's signable categories
 * Returns all categories that a user can sign based on their role
 * @param {string} userRole - User's role
 * @returns {Array<string>} Array of category codes user can sign
 */
export const getUserSignableCategories = (userRole) => {
  const roleLower = userRole?.toLowerCase() || '';

  const allCategories = [
    'Sales_Head',
    'Business_Head',
    'CEO',
    'Regional_Head',
    'Equipments_Volvo',
    'Equipments_Dealer',
    'Uptime_Volvo',
    'Uptime_Dealer'
  ];

  return allCategories.filter(category => canUserSignCategory(roleLower, category));
};

/**
 * ✅ FUNCTION 20: Format signoff for display
 * Converts raw signoff data to display-friendly format
 * @param {Object} signoff - Raw signoff record
 * @returns {Object} Formatted signoff data
 */
export const formatSignoffForDisplay = (signoff) => {
  if (!signoff) return null;

  return {
    id: signoff.id,
    pdpId: signoff.pdpId,
    category: signoff.category,
    categoryDisplay: getCategoryDisplayName(signoff.category),
    isSigned: signoff.isSigned === 1 || signoff.isSigned === true,
    signedTimestamp: signoff.signed_timestamp,
    signedBy: signoff.user_first_name && signoff.user_last_name
      ? `${signoff.user_first_name} ${signoff.user_last_name}`.trim()
      : null,
    userEmail: signoff.user_email,
    userPersona: signoff.user_persona,
    formattedDate: signoff.signed_timestamp
      ? new Date(signoff.signed_timestamp).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: 'numeric',
          minute: '2-digit',
          hour12: true
        })
      : null
  };
};