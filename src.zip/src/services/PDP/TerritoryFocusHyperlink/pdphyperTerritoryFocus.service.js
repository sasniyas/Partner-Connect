import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 CORE API FUNCTIONS - PDP Territory Focus
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ FUNCTION 1: Get PDP Territory Focus by PDP ID
 * Fetch all territory focus records for a specific PDP
 * 
 * @param {number} pdpId - The PDP ID (required)
 * @returns {Promise<Array>} Array of territory focus records
 */
export const getPdpTerritoryFocusByPdpId = async (pdpId) => {
  try {
    if (!pdpId) {
      throw new Error("PDP ID is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getPdpTerritoryFocusByPdpId}${pdpId}`;
    
    console.log("📡 Fetching PDP Territory Focus");
    console.log("  URL:", url);
    console.log("  PDP ID:", pdpId);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Raw API Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];
      
      // ⭐ Helper function to clean string fields
      const cleanString = (str) => {
        if (!str) return str;
        return str
          .replace(/\t/g, '')
          .replace(/\r/g, '')
          .replace(/\n/g, '')
          .replace(/\s+/g, ' ')
          .trim();
      };

      // ⭐ Transform API response to frontend format (matching actual API response)
      const transformedData = rawData.map(item => {
        return {
          id: item.id,
          pdpId: item.pdpId,
          branchId: item.branchId,
          
          // Location data (from joined tables)
          city: cleanString(item.cityName),
          branch: cleanString(item.branch_name),
          districts: Array.isArray(item.districts) 
            ? item.districts.map(d => d.district_name).join(", ")
            : "",
          
          // Segment priorities - store both ID and name
          firstSegment: cleanString(item.segment_priority_1_name),
          segmentPriorityId_1: item.segmentPriorityId_1,
          secondSegment: cleanString(item.segment_priority_2_name),
          segmentPriorityId_2: item.segmentPriorityId_2,
          thirdSegment: cleanString(item.segment_priority_3_name),
          segmentPriorityId_3: item.segmentPriorityId_3,
          fourthSegment: cleanString(item.segment_priority_4_name),
          segmentPriorityId_4: item.segmentPriorityId_4,
          
          // Other fields
          overallFocus: cleanString(item.overall_focus),
          responsiblePerson: cleanString(item.responsible_person),
          totalPlan: item.total_plan || 0,
          
          // Status flags
          isActive: item.isActive,
          isDeleted: item.isDeleted,
          
          // Timestamps
          created_at: item.created_at,
          updated_at: item.updated_at
        };
      });

      console.log("✅ Territory Focus data transformed:", transformedData.length, "records");
      if (transformedData.length > 0) {
        console.log("📦 Sample transformed data:", transformedData[0]);
      }
      
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch territory focus");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getPdpTerritoryFocusByPdpId Error:", error.message);
    
 

    throw new Error(error.response?.data?.message || error.message || "Failed to fetch territory focus");
  }
};

/**
 * ✅ FUNCTION 2: Add PDP Territory Focus
 * Create a new territory focus record
 * 
 * @param {Object} data - Territory focus data to create
 * @returns {Promise<Object>} Created territory focus record
 */
export const addPdpTerritoryFocus = async (data) => {
  try {
    if (!data.pdpId) {
      throw new Error("PDP ID is required");
    }
    
    if (!data.branchId) {
      throw new Error("Branch ID is required");
    }
    
    if (!data.overall_focus) {
      throw new Error("Overall Focus is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.addPdpTerritoryFocus}`;
    
    console.log("📡 Adding PDP Territory Focus");
    console.log("  URL:", url);
    console.log("  Input Data:", data);

    // ⭐ Transform data to API format
    const apiData = {
      pdpId: parseInt(data.pdpId),
      branchId: parseInt(data.branchId),
      responsible_person: data.responsible_person || data.responsiblePerson || null,
      overall_focus: data.overall_focus || data.overallFocus,
      segmentPriorityId_1: data.segmentPriorityId_1 ? parseInt(data.segmentPriorityId_1) : null,
      segmentPriorityId_2: data.segmentPriorityId_2 ? parseInt(data.segmentPriorityId_2) : null,
      segmentPriorityId_3: data.segmentPriorityId_3 ? parseInt(data.segmentPriorityId_3) : null,
      segmentPriorityId_4: data.segmentPriorityId_4 ? parseInt(data.segmentPriorityId_4) : null,
      total_plan: parseInt(data.total_plan || data.totalPlan) || null
    };

    console.log("📤 API Data being sent:", apiData);

    const response = await axios.post(url, apiData, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Add Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200 || response.status === 201) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to add territory focus");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ addPdpTerritoryFocus Error:", error.message);
    console.error("❌ Error details:", error.response?.data);
    
   

    throw new Error(error.response?.data?.message || error.message || "Failed to add territory focus");
  }
};

/**
 * ✅ FUNCTION 3: Update PDP Territory Focus
 * Update an existing territory focus record
 * 
 * @param {number} id - Territory focus record ID
 * @param {Object} data - Updated territory focus data
 * @returns {Promise<Object>} Updated territory focus record
 */
export const updatePdpTerritoryFocus = async (id, data) => {
  try {
    if (!id) {
      throw new Error("Territory Focus ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.updatePdpTerritoryFocus}`;
    
    console.log("📡 Updating PDP Territory Focus");
    console.log("  URL:", url);
    console.log("  ID:", id);
    console.log("  Input Data:", data);

    // ⭐ Transform data to API format
    const apiData = {
      id: parseInt(id),
      branchId: data.branchId ? parseInt(data.branchId) : undefined,
      responsible_person: data.responsible_person || data.responsiblePerson,
      overall_focus: data.overall_focus || data.overallFocus,
      segmentPriorityId_1: data.segmentPriorityId_1 !== undefined ? (data.segmentPriorityId_1 ? parseInt(data.segmentPriorityId_1) : null) : undefined,
      segmentPriorityId_2: data.segmentPriorityId_2 !== undefined ? (data.segmentPriorityId_2 ? parseInt(data.segmentPriorityId_2) : null) : undefined,
      segmentPriorityId_3: data.segmentPriorityId_3 !== undefined ? (data.segmentPriorityId_3 ? parseInt(data.segmentPriorityId_3) : null) : undefined,
      segmentPriorityId_4: data.segmentPriorityId_4 !== undefined ? (data.segmentPriorityId_4 ? parseInt(data.segmentPriorityId_4) : null) : undefined,
      total_plan: data.total_plan !== undefined ? parseInt(data.total_plan || data.totalPlan) : undefined
    };

    // Remove undefined values
    Object.keys(apiData).forEach(key => {
      if (apiData[key] === undefined) {
        delete apiData[key];
      }
    });

    console.log("📤 API Data being sent:", apiData);

    const response = await axios.put(url, apiData, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update territory focus");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updatePdpTerritoryFocus Error:", error.message);
    console.error("❌ Error details:", error.response?.data);
    
   

    throw new Error(error.response?.data?.message || error.message || "Failed to update territory focus");
  }
};

/**
 * ✅ FUNCTION 4: Delete PDP Territory Focus
 * Delete a territory focus record
 * 
 * @param {number} id - Territory focus record ID to delete
 * @returns {Promise<Object>} Delete response
 */
export const deletePdpTerritoryFocus = async (id) => {
  try {
    if (!id) {
      throw new Error("Territory Focus ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.deletePdpTerritoryFocus}${id}`;
    
    console.log("📡 Deleting PDP Territory Focus");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete territory focus");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ deletePdpTerritoryFocus Error:", error.message);
    
   

    throw new Error(error.response?.data?.message || error.message || "Failed to delete territory focus");
  }
};

/**
 * ✅ FUNCTION 5: Get PDP Territory Focus Entries by Territory Focus ID
 * Fetch entries for a specific territory focus record (for Fill Target popup)
 * 
 * @param {number} territoryFocusId - The Territory Focus ID (required)
 * @returns {Promise<Array>} Array of territory focus entries
 */
export const getPdpTerritoryFocusEntriesByTerritoryFocusId = async (territoryFocusId) => {
  try {
    if (!territoryFocusId) {
      throw new Error("Territory Focus ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getPdpTerritoryFocusEntriesByTerritoryFocusId}${territoryFocusId}`;
    
    console.log("📡 Fetching PDP Territory Focus Entries");
    console.log("  URL:", url);
    console.log("  Territory Focus ID:", territoryFocusId);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Raw API Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];
      
      // Transform to match component expectations
      const transformedData = Array.isArray(rawData) ? rawData.map(item => ({
        id: item.id,
        pdpId: item.pdpId,
        pdp_territory_focus: item.pdp_territory_focus,
        
        // Previous Year Forecasted Volvo Sales Volume (EOY)
        py_fvsv_gpe: item.py_fvsv_gpe || 0,
        py_fvsv_rm: item.py_fvsv_rm || 0,
        py_fvsv_sdlg: item.py_fvsv_sdlg || 0,
        py_fvsv_breaker: item.py_fvsv_breaker || 0,
        py_fvsv_expectedClosure: item.py_fvsv_expectedClosure || 0,
        
        // Current Year Volvo Target Volume
        vtv_gpe: item.vtv_gpe || 0,
        vtv_rm: item.vtv_rm || 0,
        vtv_sdlg: item.vtv_sdlg || 0,
        vtv_breaker: item.vtv_breaker || 0,
        vtv_total_plan: item.vtv_total_plan || 0,
        
        // Metadata
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        created_at: item.created_at,
        updated_at: item.updated_at
      })) : [];

      console.log("✅ Territory Focus Entries transformed:", transformedData.length, "records");
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch territory focus entries");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getPdpTerritoryFocusEntriesByTerritoryFocusId Error:", error.message);
    
    
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch territory focus entries");
  }
};

/**
 * ✅ FUNCTION 6: Update PDP Territory Focus Entry
 * Update an existing territory focus entry record (for Fill Target popup)
 * 
 * Backend expects:
 * {
 *   "id": 17,
 *   "py_fvsv_gpe": 1,
 *   "py_fvsv_rm": 3,
 *   "py_fvsv_sdlg": 4,
 *   "py_fvsv_breaker": 5,
 *   "py_fvsv_expectedClosure": 13,
 *   "vtv_gpe": 8,
 *   "vtv_rm": 4,
 *   "vtv_sdlg": 5,
 *   "vtv_breaker": 10,
 *   "vtv_total_plan": 27
 * }
 * 
 * @param {number} id - Entry record ID
 * @param {Object} data - Updated entry data
 * @returns {Promise<Object>} Updated entry record
 */
export const updatePdpTerritoryFocusEntry = async (id, data) => {
  try {
    if (!id) {
      throw new Error("Entry ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.updatePdpTerritoryFocusEntry}`;
    
    console.log("📡 Updating PDP Territory Focus Entry");
    console.log("  URL:", url);
    console.log("  ID:", id);
    console.log("  Input Data:", data);

    // Transform data to API format
    const apiData = {
      id: parseInt(id),
      py_fvsv_gpe: parseFloat(data.py_fvsv_gpe) || 0,
      py_fvsv_rm: parseFloat(data.py_fvsv_rm) || 0,
      py_fvsv_sdlg: parseFloat(data.py_fvsv_sdlg) || 0,
      py_fvsv_breaker: parseFloat(data.py_fvsv_breaker) || 0,
      py_fvsv_expectedClosure: parseFloat(data.py_fvsv_expectedClosure) || 0,
      vtv_gpe: parseFloat(data.vtv_gpe) || 0,
      vtv_rm: parseFloat(data.vtv_rm) || 0,
      vtv_sdlg: parseFloat(data.vtv_sdlg) || 0,
      vtv_breaker: parseFloat(data.vtv_breaker) || 0,
      vtv_total_plan: parseFloat(data.vtv_total_plan) || 0
    };

    console.log("📤 API Data being sent:", apiData);

    const response = await axios.put(url, apiData, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update territory focus entry");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updatePdpTerritoryFocusEntry Error:", error.message);
    console.error("❌ Error details:", error.response?.data);
    
    

    throw new Error(error.response?.data?.message || error.message || "Failed to update territory focus entry");
  }
};

/**
 * ✅ FUNCTION 7: Get PDP Territory Focus Entries Stats by PDP ID
 * Fetch stats for PDP Target Volume and Estimated Market Volume rows
 * 
 * @param {number} pdpId - The PDP ID (required)
 * @returns {Promise<Object>} Stats object
 */
export const getPdpTerritoryFocusEntriesStatsByPdpId = async (pdpId) => {
  try {
    if (!pdpId) {
      throw new Error("PDP ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");;
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.getPdpTerritoryFocusEntriesStatsByPdpId}${pdpId}`;
    
    console.log("📡 Fetching PDP Territory Focus Entries Stats");
    console.log("  URL:", url);
    console.log("  PDP ID:", pdpId);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Raw API Response:", {
      status: response.status,
      hasData: !!response.data.data
    });

    if (response.status === 200 && response.data.status) {
      const item = response.data.data || {};
      
      // Transform to match component expectations
      // NOTE: PDP Target Volume 2025 (gpe_pvtv, etc.) is NOT used - it's calculated from vtv_* sum
      const transformedData = {
        id: item.id,
        pdpId: item.pdpId,
        
        // Previous Year - PDP Target Volume (2024) - from stats API
        py_gpe_pvtv: item.py_gpe_pvtv || 0,
        py_rm_pvtv: item.py_rm_pvtv || 0,
        py_sdlg_pvtv: item.py_sdlg_pvtv || 0,
        py_breaker_pvtv: item.py_breaker_pvtv || 0,
        
        // Current Year - PDP Target Volume (2025) - NOT FROM API (calculated from vtv_* sum)
        // These fields are not used by the component
        
        // Previous Year - Estimated Market Volume (2024)
        py_gpe_etmv: item.py_gpe_etmv || 0,
        py_rm_etmv: item.py_rm_etmv || 0,
        py_sdlg_etmv: item.py_sdlg_etmv || 0,
        py_breaker_etmv: item.py_breaker_etmv || 0,
        
        // Current Year - Estimated Market Volume (2025)
        gpe_etmv: item.gpe_etmv || 0,
        rm_etmv: item.rm_etmv || 0,
        sdlg_etmv: item.sdlg_etmv || 0,
        breaker_etmv: item.breaker_etmv || 0,
        
        // Metadata
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        created_at: item.created_at,
        updated_at: item.updated_at
      };

      console.log("✅ Territory Focus Stats transformed:", transformedData);
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch territory focus stats");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getPdpTerritoryFocusEntriesStatsByPdpId Error:", error.message);
    
   

    throw new Error(error.response?.data?.message || error.message || "Failed to fetch territory focus stats");
  }
};

/**
 * ✅ FUNCTION 8: Update PDP Territory Focus Entries Stats
 * Update stats for PDP Target Volume and Estimated Market Volume rows
 * 
 * API Fields:
 * - py_gpe_pvtv, py_rm_pvtv, py_sdlg_pvtv, py_breaker_pvtv (PDP Target Volume 2024 - manual entry)
 * - NOTE: PDP Target Volume 2025 is AUTO-CALCULATED from sum of vtv_* values, NOT saved here
 * - py_gpe_etmv, py_rm_etmv, py_sdlg_etmv, py_breaker_etmv (Estimated Market Volume 2024)
 * - gpe_etmv, rm_etmv, sdlg_etmv, breaker_etmv (Estimated Market Volume 2025)
 * 
 * @param {number} id - Stats record ID
 * @param {Object} data - Updated stats data
 * @returns {Promise<Object>} Updated stats record
 */
export const updatePdpTerritoryFocusEntriesStats = async (id, data) => {
  try {
    if (!id) {
      throw new Error("Stats ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.createPdpendpoints.updatePdpTerritoryFocusEntriesStats}`;
    
    console.log("📡 Updating PDP Territory Focus Entries Stats");
    console.log("  URL:", url);
    console.log("  ID:", id);
    console.log("  Input Data:", data);

    // Transform data to API format
    // NOTE: PDP Target Volume 2025 (gpe_pvtv, rm_pvtv, etc.) is NOT sent - it's auto-calculated
    const apiData = {
      id: parseInt(id),
      // Previous Year - PDP Target Volume (2024) - manually editable
      py_gpe_pvtv: parseFloat(data.py_gpe_pvtv) || 0,
      py_rm_pvtv: parseFloat(data.py_rm_pvtv) || 0,
      py_sdlg_pvtv: parseFloat(data.py_sdlg_pvtv) || 0,
      py_breaker_pvtv: parseFloat(data.py_breaker_pvtv) || 0,
      // Current Year - PDP Target Volume (2025) - NOT SENT (auto-calculated from vtv_*)
      // Previous Year - Estimated Market Volume (2024)
      py_gpe_etmv: parseFloat(data.py_gpe_etmv) || 0,
      py_rm_etmv: parseFloat(data.py_rm_etmv) || 0,
      py_sdlg_etmv: parseFloat(data.py_sdlg_etmv) || 0,
      py_breaker_etmv: parseFloat(data.py_breaker_etmv) || 0,
      // Current Year - Estimated Market Volume (2025)
      gpe_etmv: parseFloat(data.gpe_etmv) || 0,
      rm_etmv: parseFloat(data.rm_etmv) || 0,
      sdlg_etmv: parseFloat(data.sdlg_etmv) || 0,
      breaker_etmv: parseFloat(data.breaker_etmv) || 0
    };

    console.log("📤 API Data being sent:", apiData);

    const response = await axios.put(url, apiData, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update territory focus stats");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updatePdpTerritoryFocusEntriesStats Error:", error.message);
    console.error("❌ Error details:", error.response?.data);
    
   

    throw new Error(error.response?.data?.message || error.message || "Failed to update territory focus stats");
  }
};

// ═══════════════════════════════════════════════════════════════
// 📤 DEFAULT EXPORT
// ═══════════════════════════════════════════════════════════════
