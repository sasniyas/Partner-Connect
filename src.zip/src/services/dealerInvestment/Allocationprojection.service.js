import axios from "axios";
import { API } from "../../api";

// API Base URL from configuration
const API_BASE_URL = API.domain;

// Get endpoints from API configuration
const projectionEndpoints = API.dealerInvestmentEquipmentProjectionEndpoints;
const actualsEndpoints = API.dealerInvestmentEquipmentActualsEndpoints;
const allocationEndpoints = API.dealerInvestmentAllocationEndpoints;

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Get auth headers with token
 */
const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

/**
 * Handle auth errors - redirect to login if token invalid/expired
 */
const handleAuthError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/"; // redirect to login
  }
};

// Month mapping for display and filtering
const MONTH_MAP = {
  jan: "Jan",
  feb: "Feb",
  mar: "Mar",
  apr: "Apr",
  may: "May",
  jun: "Jun",
  jul: "Jul",
  aug: "Aug",
  sep: "Sep",
  oct: "Oct",
  nov: "Nov",
  decem: "Dec",
};

// Category to type mapping
const CATEGORY_TYPE_MAP = {
  Retails: "Retail",
  "Key Account": "KAM",
  Retail: "Retail",
  KAM: "KAM",
};

// Helper function to clean string values (remove tabs and extra whitespace)
const cleanString = (str) => {
  if (!str) return "";
  return str.replace(/\t/g, "").replace(/\s+/g, " ").trim();
};

const allocationProjectionService = {
  /**
   * Get all dealer investment equipment projections (Monthly Projection)
   * Endpoint: GET /getAllDealerInvestmentEquipmentProjection
   */
  getAllProjections: async (params = {}) => {
    try {
      const queryParams = new URLSearchParams();
      if (params.pdpId) queryParams.append("pdpId", params.pdpId);
      if (params.pdpEquipmentId) queryParams.append("pdpEquipmentId", params.pdpEquipmentId);
      if (params.dealerInvestmentId) queryParams.append("dealerInvestmentId", params.dealerInvestmentId);
      if (params.year) queryParams.append("year", params.year);
      if (params.marketArea) queryParams.append("marketArea", params.marketArea);

      const queryString = queryParams.toString();
      const url = `${API_BASE_URL}${projectionEndpoints.getAllDealerInvestmentEquipmentProjection}${queryString ? `?${queryString}` : ""}`;

      console.log("Fetching projections from:", url);
      const response = await axios.get(url, { headers: getAuthHeaders() });
      console.log("Projection API Response:", response.data);
      return response.data;
    } catch (error) {
      handleAuthError(error);
      console.error("Error fetching projections:", error);
      if (error.response?.status === 404 || error.code === "ERR_NETWORK") {
        console.warn("API endpoint not available, returning empty data");
        return { status: true, data: [], message: "No data available" };
      }
      throw error.response?.data || { status: false, message: error.message };
    }
  },

  /**
   * Get all dealer investment allocations (Allocation Tab)
   * Endpoint: GET /getAllDealerInvestmentAllocation
   */
  getAllAllocations: async (params = {}) => {
    try {
      const queryParams = new URLSearchParams();
      if (params.pdpId) queryParams.append("pdpId", params.pdpId);
      if (params.pdpEquipmentId) queryParams.append("pdpEquipmentId", params.pdpEquipmentId);
      if (params.dealerInvestmentId) queryParams.append("dealerInvestmentId", params.dealerInvestmentId);
      if (params.year) queryParams.append("year", params.year);
      if (params.marketArea) queryParams.append("marketArea", params.marketArea);

      const queryString = queryParams.toString();
      const url = `${API_BASE_URL}${allocationEndpoints.getAllDealerInvestmentAllocation}${queryString ? `?${queryString}` : ""}`;

      console.log("Fetching allocations from:", url);
      const response = await axios.get(url, { headers: getAuthHeaders() });
      console.log("Allocation API Response:", response.data);
      return response.data;
    } catch (error) {
      handleAuthError(error);
      console.error("Error fetching allocations:", error);
      if (error.response?.status === 404 || error.code === "ERR_NETWORK") {
        console.warn("API endpoint not available, returning empty data");
        return { status: true, data: [], message: "No data available" };
      }
      throw error.response?.data || { status: false, message: error.message };
    }
  },

  /**
   * Get all dealer investment equipment actuals (Final Projection)
   * Endpoint: GET /getAllDealerInvestmentEquipmentActuals
   */
  getAllActuals: async (params = {}) => {
    try {
      const queryParams = new URLSearchParams();
      if (params.pdpId) queryParams.append("pdpId", params.pdpId);
      if (params.pdpEquipmentId) queryParams.append("pdpEquipmentId", params.pdpEquipmentId);
      if (params.dealerInvestmentId) queryParams.append("dealerInvestmentId", params.dealerInvestmentId);
      if (params.year) queryParams.append("year", params.year);
      if (params.marketArea) queryParams.append("marketArea", params.marketArea);

      const queryString = queryParams.toString();
      const url = `${API_BASE_URL}${actualsEndpoints.getAllDealerInvestmentEquipmentActuals}${queryString ? `?${queryString}` : ""}`;

      console.log("Fetching actuals from:", url);
      const response = await axios.get(url, { headers: getAuthHeaders() });
      console.log("Actuals API Response:", response.data);
      return response.data;
    } catch (error) {
      handleAuthError(error);
      console.error("Error fetching actuals:", error);
      if (error.response?.status === 404 || error.code === "ERR_NETWORK") {
        console.warn("API endpoint not available, returning empty data");
        return { status: true, data: [], message: "No data available" };
      }
      throw error.response?.data || { status: false, message: error.message };
    }
  },

  /**
   * Transform API response data to table format
   * @param {Array} rawData - Raw API response data
   * @param {Object} filters - Active filters
   * @param {boolean} isAllocationData - Whether this is allocation data (no category field)
   */
  transformDataForTable: (rawData, filters = {}, isAllocationData = false) => {
    if (!rawData || rawData.length === 0) {
      console.log("No raw data to transform");
      return [];
    }

    console.log("Transforming data, raw items count:", rawData.length);
    console.log("Active filters:", filters);
    console.log("Is Allocation Data:", isAllocationData);

    let filteredRawData = [...rawData];

    // Filter by type (category mapping) - SKIP for allocation data as it has no category
    if (!isAllocationData && filters.type && filters.type !== "Retail+KAM") {
      filteredRawData = filteredRawData.filter((item) => {
        const category = item.category || item.pdp_equipment_info?.category || "";
        const itemType = CATEGORY_TYPE_MAP[category] || category;
        return itemType === filters.type;
      });
    }

    // Filter by year
    if (filters.year?.length > 0) {
      filteredRawData = filteredRawData.filter((item) => {
        const itemYear = String(item.pdp_info?.year || "");
        return filters.year.includes(itemYear);
      });
    }

    // Filter by market area
    if (filters.marketArea?.length > 0) {
      filteredRawData = filteredRawData.filter((item) => {
        const itemMarketArea = cleanString(item.dealer_info?.market_area_name || "");
        return filters.marketArea.includes(itemMarketArea);
      });
    }

    // Filter by dealer
    if (filters.dealer?.length > 0) {
      filteredRawData = filteredRawData.filter((item) => {
        const dealerShortName = cleanString(item.dealer_info?.dealer_short_name || "");
        return filters.dealer.includes(dealerShortName);
      });
    }

    // Filter by equipment type
    if (filters.equipmentType?.length > 0 && !filters.equipmentType.includes("Equipment All Types")) {
      filteredRawData = filteredRawData.filter((item) => {
        const equipType = cleanString(item.equipment_info?.equipment_type || "");
        return filters.equipmentType.includes(equipType);
      });
    }

    // Filter by model
    if (filters.model?.length > 0 && !filters.model.includes("All Models")) {
      filteredRawData = filteredRawData.filter((item) => {
        const model = cleanString(item.equipment_info?.equipment_model || "");
        return filters.model.includes(model);
      });
    }

    // Filter by month
    const selectedMonths = filters.month?.length > 0 ? filters.month.map((m) => m.toLowerCase()) : null;

    // Get unique dealers and market areas
    const dealersSet = new Set();
    const marketAreasSet = new Set();

    filteredRawData.forEach((item) => {
      const dealerShortName = cleanString(item.dealer_info?.dealer_short_name);
      if (dealerShortName) dealersSet.add(dealerShortName);
      const marketArea = cleanString(item.dealer_info?.market_area_name);
      if (marketArea) marketAreasSet.add(marketArea);
    });

    const dealers = Array.from(dealersSet).sort();
    const marketAreas = Array.from(marketAreasSet).sort();

    console.log("Unique dealers found:", dealers);
    console.log("Unique market areas found:", marketAreas);

    // Group data by equipment type + model + year
    const groupedData = {};

    filteredRawData.forEach((item) => {
      const equipmentType = cleanString(item.equipment_info?.equipment_type) || "Unknown";
      const model = cleanString(item.equipment_info?.equipment_model) || "Unknown";
      const year = item.pdp_info?.year || "";
      const dealerShortName = cleanString(item.dealer_info?.dealer_short_name) || "";
      const marketArea = cleanString(item.dealer_info?.market_area_name) || "";
      
      // For allocation data, category doesn't exist - treat as "All"
      const category = isAllocationData ? "All" : (item.category || item.pdp_equipment_info?.category || "");
      const type = isAllocationData ? "All" : (CATEGORY_TYPE_MAP[category] || category);

      // For allocation data, don't include type in the key since there's no category
      let key;
      if (isAllocationData) {
        key = `${equipmentType}|${model}|${year}`;
      } else if (filters.type === "Retail+KAM") {
        key = `${equipmentType}|${model}|${year}`;
      } else {
        key = `${equipmentType}|${model}|${year}|${type}`;
      }

      if (!groupedData[key]) {
        groupedData[key] = {
          id: item.id,
          equipmentId: item.equipmentId,
          dealerInvestmentId: item.dealerInvestmentId,
          equipmentType,
          model,
          year: String(year),
          type: isAllocationData ? "All" : (filters.type === "Retail+KAM" ? "Retail+KAM" : type),
          category,
          equipmentMake: cleanString(item.equipment_info?.equipment_make) || "",
          equipmentLine: cleanString(item.equipment_info?.equipment_line) || "",
          dealerAllocation: {},
          marketAreaValues: {},
          monthlyData: {
            jan: 0, feb: 0, mar: 0, apr: 0, may: 0, jun: 0,
            jul: 0, aug: 0, sep: 0, oct: 0, nov: 0, decem: 0,
          },
          inExp: 0,
          rawItems: [],
        };

        dealers.forEach((d) => {
          groupedData[key].dealerAllocation[d] = 0;
        });

        marketAreas.forEach((ma) => {
          groupedData[key].marketAreaValues[ma.toLowerCase()] = 0;
        });
      }

      groupedData[key].rawItems.push(item);

      let monthlyTotal = 0;
      const monthKeys = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "decem"];

      monthKeys.forEach((monthKey) => {
        const value = item[monthKey] || 0;
        if (selectedMonths) {
          const displayMonth = MONTH_MAP[monthKey].toLowerCase();
          if (selectedMonths.includes(displayMonth)) {
            monthlyTotal += value;
          }
        } else {
          monthlyTotal += value;
        }
        groupedData[key].monthlyData[monthKey] += value;
      });

      if (dealerShortName) {
        groupedData[key].dealerAllocation[dealerShortName] =
          (groupedData[key].dealerAllocation[dealerShortName] || 0) + monthlyTotal;
      }

      if (marketArea) {
        const maKey = marketArea.toLowerCase();
        groupedData[key].marketAreaValues[maKey] =
          (groupedData[key].marketAreaValues[maKey] || 0) + monthlyTotal;
      }
    });

    const result = Object.values(groupedData).map((item) => {
      const flattened = {
        id: item.id,
        equipmentId: item.equipmentId,
        dealerInvestmentId: item.dealerInvestmentId,
        equipmentType: item.equipmentType,
        model: item.model,
        year: item.year,
        type: item.type,
        category: item.category,
        equipmentMake: item.equipmentMake,
        equipmentLine: item.equipmentLine,
        dealerAllocation: item.dealerAllocation,
        monthlyData: item.monthlyData,
        inExp: item.inExp,
        rawItems: item.rawItems,
      };

      Object.keys(item.marketAreaValues).forEach((maKey) => {
        flattened[maKey] = item.marketAreaValues[maKey];
      });

      return flattened;
    });

    console.log("Transformed data count:", result.length);
    return result;
  },

  /**
   * Extract unique filter options from raw API data
   */
  extractFilterOptions: (rawData) => {
    if (!rawData || rawData.length === 0) {
      return {
        years: [],
        dealers: [],
        marketAreas: [],
        equipmentTypes: ["Equipment All Types"],
        models: ["All Models"],
      };
    }

    const yearsSet = new Set();
    const dealersSet = new Set();
    const marketAreasSet = new Set();
    const equipmentTypesSet = new Set();
    const modelsSet = new Set();

    rawData.forEach((item) => {
      if (item.pdp_info?.year) yearsSet.add(String(item.pdp_info.year));

      const dealerShortName = cleanString(item.dealer_info?.dealer_short_name);
      if (dealerShortName) dealersSet.add(dealerShortName);

      const marketArea = cleanString(item.dealer_info?.market_area_name);
      if (marketArea) marketAreasSet.add(marketArea);

      const equipType = cleanString(item.equipment_info?.equipment_type);
      if (equipType) equipmentTypesSet.add(equipType);

      const model = cleanString(item.equipment_info?.equipment_model);
      if (model) modelsSet.add(model);
    });

    return {
      years: Array.from(yearsSet).sort((a, b) => Number(b) - Number(a)),
      dealers: Array.from(dealersSet).sort(),
      marketAreas: Array.from(marketAreasSet).sort(),
      equipmentTypes: ["Equipment All Types", ...Array.from(equipmentTypesSet).sort()],
      models: ["All Models", ...Array.from(modelsSet).sort()],
    };
  },

  getMonthlyBreakdown: (row) => {
    if (!row || !row.monthlyData) return [];
    return Object.keys(MONTH_MAP).map((key) => ({
      month: MONTH_MAP[key],
      value: row.monthlyData[key] || 0,
    }));
  },

  getDealerBreakdown: (row) => {
    if (!row || !row.dealerAllocation) return [];
    return Object.entries(row.dealerAllocation)
      .filter(([_, value]) => value > 0)
      .map(([dealer, value]) => ({ dealer, value }))
      .sort((a, b) => b.value - a.value);
  },

  calculateRowTotal: (row, marketAreas = []) => {
    if (!row) return 0;
    let total = 0;
    marketAreas.forEach((area) => {
      total += row[area.toLowerCase()] || 0;
    });
    total += row.inExp || 0;
    return total;
  },

  exportToCSV: (data, dealers = [], marketAreas = []) => {
    if (!data || data.length === 0) return "";

    const headers = ["Equipment Type", "Model", "Year", "Type"];
    dealers.forEach((dealer) => headers.push(dealer));
    marketAreas.forEach((area) => headers.push(area));
    headers.push("In-Exp", "Total");

    const rows = data.map((row) => {
      const rowData = [row.equipmentType, row.model, row.year, row.type];
      dealers.forEach((dealer) => rowData.push(row.dealerAllocation?.[dealer] || 0));
      marketAreas.forEach((area) => rowData.push(row[area.toLowerCase()] || 0));

      let total = 0;
      marketAreas.forEach((area) => {
        total += row[area.toLowerCase()] || 0;
      });
      total += row.inExp || 0;
      rowData.push(row.inExp || 0, total);

      return rowData.join(",");
    });

    return [headers.join(","), ...rows].join("\n");
  },
};

export default allocationProjectionService;