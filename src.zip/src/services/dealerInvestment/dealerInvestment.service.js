/**
 * Dealer Investment Service
 * Handles API calls for Dealer Investment module
 */

import axios from "axios";
import { API } from "../../api";

// Base URL from API config
const BASE_URL = API.domain;
const ENDPOINTS = API.dealerInvestmentEndpoints;

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Get auth headers with token
 */
const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// ============================================
// API FUNCTIONS
// ============================================

/**
 * Get all dealer investments
 */
export const getAllDealerInvestment = async (page = 1, filters = {}) => {
  try {
    const queryParams = new URLSearchParams({ page });

    if (filters.year) queryParams.append('year', filters.year);
    if (filters.marketArea) queryParams.append('market_area', filters.marketArea); // Start calling it market_area for backend
    if (filters.dealer) queryParams.append('dealer', filters.dealer);
    if (filters.search) queryParams.append('search', filters.search);
    if (filters.mbpStatusEquipments) queryParams.append('mbpStatusEquipments', filters.mbpStatusEquipments);
    if (filters.mbpStatusUap) queryParams.append('mbpStatusUap', filters.mbpStatusUap);

    // Legacy support for array filters if passed as joined strings or handle arrays here
    // But ViewDealerInvestment passes arrays, we should join them?
    // Let's assume the caller handles joining or we check type. 
    // Ideally the Component should pass strings or we join here. 
    // ViewPdp joined them in component: `year: selectedYear.join(',')`
    // So we assume filters values are already strings or primitives.

    const response = await axios.get(
      `${BASE_URL}${ENDPOINTS.getAllDealerInvestment}?${queryParams.toString()}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error fetching dealer investments:", error);
    throw error;
  }
};

/**
 * Get dealer investment by ID
 */
export const getDealerInvestmentById = async (id) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${ENDPOINTS.getDealerInvestmentById}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error fetching dealer investment by ID:", error);
    throw error;
  }
};

/**
 * Get dealer investment by PDP ID
 */
export const getDealerInvestmentByPdpId = async (pdpId) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${ENDPOINTS.getDealerInvestmentByPdpId}${pdpId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error fetching dealer investment by PDP ID:", error);
    throw error;
  }
};

/**
 * Update dealer investment
 */
export const updateDealerInvestment = async (data) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${ENDPOINTS.updateDealerInvestment}`,
      data,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error updating dealer investment:", error);
    throw error;
  }
};

/**
 * Delete dealer investment (soft delete)
 */
export const deleteDealerInvestment = async (id) => {
  try {
    const response = await axios.delete(
      `${BASE_URL}${ENDPOINTS.deleteDealerInvestment}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error deleting dealer investment:", error);
    throw error;
  }
};

// ============================================
// DATA TRANSFORMATION FUNCTIONS
// ============================================

/**
 * Transform API data to table format
 * Maps API response structure to component-friendly format
 */
export const transformDealerInvestmentForTable = (apiData) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return [];
  }

  return apiData.map((item) => ({
    id: item.id,
    pdpId: item.pdpId,
    dealerId: item.dealerId,
    // Flatten pdp_info
    year: item.pdp_info?.year || "",
    marketArea: item.dealer_info?.market_area_name?.trim() || item.pdp_info?.market_area || "",
    // Flatten dealer_info (trim to remove leading tabs/spaces)
    dealer: (item.dealer_info?.dealer_short_name || item.dealer_info?.dealer_name || "").trim(),
    dealerName: (item.dealer_info?.dealer_name || "").trim(),
    dealerShortName: (item.dealer_info?.dealer_short_name || "").trim(),
    // Additional info
    pdp_start_date: item.pdp_info?.pdp_start_date || "",
    pdp_end_date: item.pdp_info?.pdp_end_date || "",
    physical_pdp_start_date: item.pdp_info?.physical_pdp_start_date || "",
    physical_pdp_end_date: item.pdp_info?.physical_pdp_end_date || "",
    sign_of_status: item.pdp_info?.sign_of_status || "",
    isActive: item.isActive,
    created_at: item.created_at,
    updated_at: item.updated_at,
    // Keep original nested objects for reference
    pdp_info: item.pdp_info,
    dealer_info: item.dealer_info,
  }));
};

/**
 * Get unique years from investments
 */
export const getUniqueYears = (investments) => {
  const years = [...new Set(investments.map((inv) => inv.year).filter(Boolean))];
  return years.sort((a, b) => b - a); // Sort descending (newest first)
};

/**
 * Get unique market areas from investments
 */
export const getUniqueMarketAreas = (investments) => {
  const areas = [...new Set(investments.map((inv) => inv.marketArea?.trim()).filter(Boolean))];
  return areas.sort();
};

/**
 * Get unique dealers from investments (uses short name)
 */
export const getUniqueDealers = (investments) => {
  const dealers = [...new Set(investments.map((inv) => inv.dealer?.trim()).filter(Boolean))];
  return dealers.sort();
};

