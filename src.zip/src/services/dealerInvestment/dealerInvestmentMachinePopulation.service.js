/**
 * Dealer Investment Machine Population Service
 * Handles API calls and data transformation for Machine & Population tab
 */

import axios from "axios";
import { API } from "../../api";

const { domain, dealerInvestmentMachinePopulationEndpoints } = API;

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Get auth headers with token
 */
const getAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// ============================================
// API FUNCTIONS
// ============================================

/**
 * Get all dealer investment machine population records
 */
export const getAllDealerInvestmentMachinePopulation = async (filters = {}) => {
  try {
    const params = new URLSearchParams();
    if (filters.pdpId) params.append("pdpId", filters.pdpId);
    if (filters.dealerInvestmentId) params.append("dealerInvestmentId", filters.dealerInvestmentId);
    if (filters.make) params.append("make", filters.make);

    const queryString = params.toString() ? `?${params.toString()}` : "";
    const response = await axios.get(
      `${domain}${dealerInvestmentMachinePopulationEndpoints.getAllDealerInvestmentMachinePopulation}${queryString}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching dealer investment machine population:", error);
    throw error;
  }
};

/**
 * Get dealer investment machine population by ID
 */
export const getDealerInvestmentMachinePopulationById = async (id) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentMachinePopulationEndpoints.getDealerInvestmentMachinePopulationById}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching dealer investment machine population by ID:", error);
    throw error;
  }
};

/**
 * Get dealer investment machine population by Dealer Investment ID
 * This is the main function used in Fill Entries Machine & Population tab
 */
export const getDealerInvestmentMachinePopulationByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentMachinePopulationEndpoints.getDealerInvestmentMachinePopulationByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching machine population by dealer investment ID:", error);
    throw error;
  }
};

/**
 * Get dealer investment machine population by PDP ID
 */
export const getDealerInvestmentMachinePopulationByPdpId = async (pdpId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentMachinePopulationEndpoints.getDealerInvestmentMachinePopulationByPdpId}${pdpId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching machine population by PDP ID:", error);
    throw error;
  }
};

/**
 * Get Active Machines (PDP Targets) by PDP ID
 * Returns targets grouped by equipment_make (Volvo, SDLG)
 */
export const getActiveMachines = async (pdpId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentMachinePopulationEndpoints.getActiveMachines}${pdpId}`,
      { headers: getAuthHeaders() }
    );
    
    if (response.data?.status && response.data?.data) {
      const dataArray = response.data.data;
      
      // Group targets by equipment_make and sum them
      const targetsByMake = {};
      
      dataArray.forEach((item) => {
        const make = item.equipment_make?.trim();
        if (make) {
          if (!targetsByMake[make]) {
            targetsByMake[make] = 0;
          }
          // Sum target values for each make
          targetsByMake[make] += parseFloat(item.target) || 0;
        }
      });
      
      console.log("Active Machines targets by make:", targetsByMake);
      
      return {
        status: true,
        data: targetsByMake,
        rawData: dataArray,
      };
    }
    
    return { status: false, data: {}, rawData: [] };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching active machines:", error);
    throw error;
  }
};

/**
 * Update single dealer investment machine population record
 */
export const updateDealerInvestmentMachinePopulation = async (data) => {
  try {
    const response = await axios.put(
      `${domain}${dealerInvestmentMachinePopulationEndpoints.updateDealerInvestmentMachinePopulation}`,
      data,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating dealer investment machine population:", error);
    throw error;
  }
};

/**
 * Update multiple dealer investment machine population records
 */
export const updateMultipleDealerInvestmentMachinePopulation = async (rows) => {
  try {
    console.log("Sending machine population rows to API:", rows);
    
    const response = await axios.put(
      `${domain}${dealerInvestmentMachinePopulationEndpoints.updateMultipleDealerInvestmentMachinePopulation}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating multiple dealer investment machine population:", error);
    console.error("Error response:", error.response?.data);
    throw error;
  }
};

/**
 * Delete dealer investment machine population record (soft delete)
 */
export const deleteDealerInvestmentMachinePopulation = async (id) => {
  try {
    const response = await axios.delete(
      `${domain}${dealerInvestmentMachinePopulationEndpoints.deleteDealerInvestmentMachinePopulation}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting dealer investment machine population:", error);
    throw error;
  }
};

// ============================================
// DATA TRANSFORMATION FUNCTIONS
// ============================================

/**
 * Transform API data for Machine & Population tab
 * Groups by make (Volvo, SDLG)
 * @param {Array} apiData - Machine population data from API
 * @param {Object} pdpTargets - PDP targets grouped by make (from getActiveMachines)
 */
export const transformMachinePopulationData = (apiData, pdpTargets = {}) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return { tableData: {}, pdpTargets: {} };
  }

  const tableData = {};
  const formattedPdpTargets = {};

  apiData.forEach((item) => {
    const make = item.make?.trim() || "Unknown";
    const target = pdpTargets[make] || 0;

    tableData[make] = {
      id: item.id,
      Q1: item.q1 !== null ? String(item.q1) : "",
      Q2: item.q2 !== null ? String(item.q2) : "",
      Q3: item.q3 !== null ? String(item.q3) : "",
      Q4: item.q4 !== null ? String(item.q4) : "",
      actual: item.actual !== null ? String(item.actual) : "",
      pdpTarget: String(target),
      dealerInvestmentId: item.dealerInvestmentId,
      pdpId: item.pdpId,
    };

    // Format PDP targets for display
    formattedPdpTargets[`Active Machine Population - ${make}`] = String(target);
  });

  return { tableData, pdpTargets: formattedPdpTargets };
};

/**
 * Prepare machine population data for API update
 */
export const prepareMachinePopulationDataForUpdate = (tableData) => {
  if (!tableData || typeof tableData !== "object") return [];

  return Object.entries(tableData).map(([make, data]) => {
    const q1Val = data.Q1 !== "" && data.Q1 !== null && data.Q1 !== undefined ? Number(data.Q1) : null;
    const q2Val = data.Q2 !== "" && data.Q2 !== null && data.Q2 !== undefined ? Number(data.Q2) : null;
    const q3Val = data.Q3 !== "" && data.Q3 !== null && data.Q3 !== undefined ? Number(data.Q3) : null;
    const q4Val = data.Q4 !== "" && data.Q4 !== null && data.Q4 !== undefined ? Number(data.Q4) : null;
    
    // Calculate actual as sum of quarters
    const actual = (q1Val || 0) + (q2Val || 0) + (q3Val || 0) + (q4Val || 0);
    
    return {
      id: data.id,
      q1: q1Val,
      q2: q2Val,
      q3: q3Val,
      q4: q4Val,
      actual: actual > 0 ? actual : null,
    };
  });
};

/**
 * Calculate Actual from quarterly values
 */
export const calculateActual = (data) => {
  const q1 = parseInt(data.Q1) || 0;
  const q2 = parseInt(data.Q2) || 0;
  const q3 = parseInt(data.Q3) || 0;
  const q4 = parseInt(data.Q4) || 0;
  return q1 + q2 + q3 + q4;
};

/**
 * Calculate Achievement percentage
 */
export const calculateAchievement = (actual, pdpTarget) => {
  const actualVal = parseInt(actual) || 0;
  const target = parseInt(pdpTarget) || 0;
  // Return 0 if target is 0 or not set
  return target > 0 ? ((actualVal / target) * 100).toFixed(2) : "0.00";
};

// ============================================
// EXPORT DEFAULT
// ============================================
