/**
 * Dealer Investment Competence Service
 * Handles all API calls and data transformation for Competence Development module
 */

import axios from "axios";
import { API } from "../../api";

const { domain } = API;

// ============================================
// API FUNCTIONS
// ============================================

/**
 * Get all Competence records by Dealer Investment ID
 */
export const getDealerInvestmentCompetenceByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.get(
      `${domain}${API.dealerInvestmentCompetenceEndpoints.getDealerInvestmentCompetenceByDealerInvestmentId}${dealerInvestmentId}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    // API returns { status, message, data: [...] }
    return { status: true, data: response.data?.data || response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching Competence data:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

/**
 * Get all Competence records by PDP ID
 */
export const getDealerInvestmentCompetenceByPdpId = async (pdpId) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.get(
      `${domain}${API.dealerInvestmentCompetenceEndpoints.getDealerInvestmentCompetenceByPdpId}${pdpId}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    return { status: true, data: response.data?.data || response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching Competence data by PDP ID:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

/**
 * Update single Competence record
 */
export const updateDealerInvestmentCompetence = async (data) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.put(
      `${domain}${API.dealerInvestmentCompetenceEndpoints.updateDealerInvestmentCompetence}`,
      data,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    return { status: true, data: response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating Competence data:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

/**
 * Update multiple Competence records
 */
export const updateMultipleDealerInvestmentCompetence = async (rows) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.put(
      `${domain}${API.dealerInvestmentCompetenceEndpoints.updateMultipleDealerInvestmentCompetence}`,
      { rows },
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    return { status: true, data: response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating multiple Competence records:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

/**
 * Delete Competence record
 */
export const deleteDealerInvestmentCompetence = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.delete(
      `${domain}${API.dealerInvestmentCompetenceEndpoints.deleteDealerInvestmentCompetence}${id}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    return { status: true, data: response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting Competence record:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

// ============================================
// DATA TRANSFORMATION FUNCTIONS
// ============================================

/**
 * Categorize competence name into a group (SCL, TCL, CCL, LCL, Other)
 */
const categorizeCompetence = (name) => {
  const lowerName = (name || "").trim().toLowerCase();
  
  // SCL (Sales Competence Level)
  if (lowerName.includes("scl") || 
      lowerName.includes("sales coordinator") || 
      lowerName.includes("sales training") ||
      (lowerName.includes("sales") && lowerName.includes("head"))) {
    return "SCL";
  }
  
  // TCL (Technical Competence Level)
  if (lowerName.includes("tcl") || 
      lowerName.includes("eps") || 
      lowerName.includes("dot") ||
      lowerName.includes("paver") ||
      lowerName.includes("technical") ||
      lowerName.includes("sdlg service manager") ||
      lowerName.includes("operator trainer")) {
    return "TCL";
  }
  
  // CCL (Commercial Competence Level)
  if (lowerName.includes("ccl") || 
      lowerName.includes("csr") ||
      lowerName.includes("commercial")) {
    return "CCL";
  }
  
  // LCL (Logistic Competence Level)
  if (lowerName.includes("lcl") || 
      lowerName.includes("logistic")) {
    return "LCL";
  }
  
  // Default - Other
  return "Other";
};

/**
 * Transform API data to component format
 * Groups competences by category (SCL, TCL, CCL, LCL, Other)
 */
export const transformCompetenceData = (apiData) => {
  if (!apiData || !Array.isArray(apiData)) {
    return {
      tableData: {},
      pdpTargets: { SCL: "0", TCL: "0", CCL: "0", LCL: "0", Other: "0" },
      groupedData: {
        SCL: {},
        TCL: {},
        CCL: {},
        LCL: {},
        Other: {},
      },
    };
  }

  const tableData = {};
  const groupedData = {
    SCL: {},
    TCL: {},
    CCL: {},
    LCL: {},
    Other: {},
  };
  const categoryTotals = {
    SCL: 0,
    TCL: 0,
    CCL: 0,
    LCL: 0,
    Other: 0,
  };

  // Process each API record
  apiData.forEach((item) => {
    const competenceName = (item.competence_info?.competence_name || "Unknown").trim();
    const target = item.competence_info?.target;
    const pyTarget = item.competence_info?.py_target;
    const category = categorizeCompetence(competenceName);

    const competenceItem = {
      id: item.id,
      pdpId: item.pdpId,
      pdpCompetenceId: item.pdpCompetenceId,
      dealerInvestmentId: item.dealerInvestmentId,
      competenceId: item.competence_info?.competence_id,
      Q1: item.q1 !== null ? String(item.q1) : "",
      Q2: item.q2 !== null ? String(item.q2) : "",
      Q3: item.q3 !== null ? String(item.q3) : "",
      Q4: item.q4 !== null ? String(item.q4) : "",
      ytdActual: item.ytd_actual !== null ? String(item.ytd_actual) : "",
      pdpTarget: target !== null ? String(target) : (pyTarget !== null ? String(pyTarget) : ""),
      pyTarget: pyTarget !== null ? String(pyTarget) : "",
      category: category,
    };

    // Add to flat tableData
    tableData[competenceName] = competenceItem;

    // Add to grouped data
    groupedData[category][competenceName] = competenceItem;

    // Sum up targets for category totals (use pyTarget if target is null)
    const targetValue = parseInt(target) || parseInt(pyTarget) || 0;
    categoryTotals[category] += targetValue;
  });

  // Convert category totals to strings for pdpTargets
  const pdpTargets = {
    SCL: String(categoryTotals.SCL),
    TCL: String(categoryTotals.TCL),
    CCL: String(categoryTotals.CCL),
    LCL: String(categoryTotals.LCL),
    Other: String(categoryTotals.Other),
  };

  return {
    tableData,
    pdpTargets,
    groupedData,
  };
};

/**
 * Prepare competence data for API update
 * Transforms component state (groupedData) to API format
 */
export const prepareCompetenceDataForUpdate = (groupedData) => {
  if (!groupedData || typeof groupedData !== 'object') {
    return [];
  }

  const rows = [];
  
  // Iterate through each category
  Object.keys(groupedData).forEach((category) => {
    const categoryData = groupedData[category];
    if (categoryData && typeof categoryData === 'object') {
      Object.keys(categoryData).forEach((competenceName) => {
        const item = categoryData[competenceName];
        if (item && item.id) {
          rows.push({
            id: item.id,
            q1: item.Q1 !== "" ? parseInt(item.Q1) || null : null,
            q2: item.Q2 !== "" ? parseInt(item.Q2) || null : null,
            q3: item.Q3 !== "" ? parseInt(item.Q3) || null : null,
            q4: item.Q4 !== "" ? parseInt(item.Q4) || null : null,
            ytd_actual: calculateYtdActual(item),
          });
        }
      });
    }
  });

  return rows;
};

/**
 * Calculate YTD Actual from quarterly values
 */
export const calculateYtdActual = (item) => {
  const q1 = parseInt(item.Q1) || 0;
  const q2 = parseInt(item.Q2) || 0;
  const q3 = parseInt(item.Q3) || 0;
  const q4 = parseInt(item.Q4) || 0;
  
  // If all quarters are empty/0, return null
  if (item.Q1 === "" && item.Q2 === "" && item.Q3 === "" && item.Q4 === "") {
    return null;
  }
  
  return q1 + q2 + q3 + q4;
};

/**
 * Calculate achievement percentage
 */
export const calculateAchievement = (actual, target) => {
  const actualNum = parseInt(actual) || 0;
  const targetNum = parseInt(target) || 0;
  
  if (targetNum === 0) return "0.00";
  return ((actualNum / targetNum) * 100).toFixed(2);
};

// ============================================
// EXPORTS
// ============================================
