/**
 * Dealer Investment Equipment Service
 * Handles API calls and data transformation for Equipment & Attachments tab
 * Supports MBP, Projection, and Actuals data types
 */

import axios from "axios";
import { API } from "../../api";

const { 
  domain, 
  dealerInvestmentEquipmentActualsEndpoints,
  dealerInvestmentEquipmentMbpEndpoints,
  dealerInvestmentEquipmentProjectionEndpoints
} = API;

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Get auth headers with token
 */
const getAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// ============================================
// ACTUALS API FUNCTIONS
// ============================================

export const getDealerInvestmentEquipmentActualsByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentEquipmentActualsEndpoints.getDealerInvestmentEquipmentActualsByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching equipment actuals:", error);
    throw error;
  }
};

export const updateMultipleDealerInvestmentEquipmentActuals = async (rows) => {
  try {
    const response = await axios.put(
      `${domain}${dealerInvestmentEquipmentActualsEndpoints.updateMultipleDealerInvestmentEquipmentActuals}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating equipment actuals:", error);
    throw error;
  }
};

// ============================================
// MBP API FUNCTIONS
// ============================================

export const getDealerInvestmentEquipmentMbpByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentEquipmentMbpEndpoints.getDealerInvestmentEquipmentMbpByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching equipment MBP:", error);
    throw error;
  }
};

export const updateMultipleDealerInvestmentEquipmentMbp = async (rows) => {
  try {
    const response = await axios.put(
      `${domain}${dealerInvestmentEquipmentMbpEndpoints.updateMultipleDealerInvestmentEquipmentMbp}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating equipment MBP:", error);
    throw error;
  }
};

// ============================================
// PROJECTION API FUNCTIONS
// ============================================

export const getDealerInvestmentEquipmentProjectionByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentEquipmentProjectionEndpoints.getDealerInvestmentEquipmentProjectionByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching equipment projection:", error);
    throw error;
  }
};

export const updateMultipleDealerInvestmentEquipmentProjection = async (rows) => {
  try {
    const response = await axios.put(
      `${domain}${dealerInvestmentEquipmentProjectionEndpoints.updateMultipleDealerInvestmentEquipmentProjection}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating equipment projection:", error);
    throw error;
  }
};

// ============================================
// DATA TRANSFORMATION FUNCTIONS
// ============================================

/**
 * Month field mapping (API field -> Display name)
 */
const MONTH_FIELDS = {
  jan: "Jan",
  feb: "Feb",
  mar: "Mar",
  apr: "Apr",
  may: "May",
  jun: "Jun",
  jul: "Jul",
  aug: "Aug",
  sep: "Sep",
  oct: "Oct",
  nov: "Nov",
  decem: "Dec",
};

/**
 * Category mapping (API -> UI)
 */
const CATEGORY_MAP = {
  "Key Account": "KAM",
  "Retails": "Retail",
};

/**
 * Equipment types classified as "Attachments"
 * Everything else is classified as "Equipments"
 */
const ATTACHMENT_TYPES = [
  "breaker sales",
  "quick coupler",
  "quick coupler sales",
  "other attachments sales",
  "other attachments",
  "attachments",
];

/**
 * Check if equipment type is classified as Attachment
 */
const isAttachmentType = (equipmentType) => {
  if (!equipmentType) return false;
  const normalizedType = equipmentType.trim().toLowerCase();
  return ATTACHMENT_TYPES.some(type => normalizedType.includes(type));
};

/**
 * Filter API data by Make and Type (Equipments/Attachments)
 * @param {Array} data - Raw API data
 * @param {string} make - "Volvo" or "SDLG"
 * @param {string} type - "Equipments" or "Attachments"
 */
export const filterEquipmentDataByMakeAndType = (data, make, type) => {
  if (!data || !Array.isArray(data)) return [];
  
  return data.filter(item => {
    const itemMake = (item.equipment_info?.equipment_make || "").trim();
    const itemEquipType = (item.equipment_info?.equipment_type || "").trim();
    
    // Check if make matches (case-insensitive)
    const matchesMake = !make || itemMake.toLowerCase() === make.toLowerCase();
    
    // Check if type matches (Equipments vs Attachments)
    const isAttachment = isAttachmentType(itemEquipType);
    const matchesType = !type || 
      (type === "Attachments" && isAttachment) || 
      (type === "Equipments" && !isAttachment);
    
    return matchesMake && matchesType;
  });
};

/**
 * Calculate quarterly totals from monthly data
 */
const calculateQuarterlyTotals = (data) => {
  const jan = parseInt(data.jan) || 0;
  const feb = parseInt(data.feb) || 0;
  const mar = parseInt(data.mar) || 0;
  const apr = parseInt(data.apr) || 0;
  const may = parseInt(data.may) || 0;
  const jun = parseInt(data.jun) || 0;
  const jul = parseInt(data.jul) || 0;
  const aug = parseInt(data.aug) || 0;
  const sep = parseInt(data.sep) || 0;
  const oct = parseInt(data.oct) || 0;
  const nov = parseInt(data.nov) || 0;
  const decem = parseInt(data.decem) || 0;

  return {
    Q1: jan + feb + mar,
    Q2: apr + may + jun,
    Q3: jul + aug + sep,
    Q4: oct + nov + decem,
  };
};

/**
 * Calculate total from monthly data
 */
const calculateMonthlyTotal = (data) => {
  return Object.keys(MONTH_FIELDS).reduce((sum, field) => {
    return sum + (parseInt(data[field]) || 0);
  }, 0);
};

/**
 * Transform API data to component structure
 * Groups by equipment_type, then by category (KAM/Retail)
 * 
 * @param {Array} apiData - Raw API response data
 * @param {string} dataType - "MBP", "Projection", or "Actuals"
 * @returns {Object} Transformed data structure
 */
export const transformEquipmentData = (apiData, dataType) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return {
      equipmentModels: {},
      quarterlySummary: {},
      equipmentTypes: [],
    };
  }

  const equipmentModels = {};
  const quarterlySummary = {};
  const equipmentTypesSet = new Set();

  // Group data by equipment_type and category
  apiData.forEach((item) => {
    // Trim whitespace/tabs from equipment fields
    const equipmentType = (item.equipment_info?.equipment_type || "Unknown").trim();
    const equipmentModel = (item.equipment_info?.equipment_model || "Unknown").trim();
    const equipmentMake = (item.equipment_info?.equipment_make || "").trim();
    const equipmentLine = (item.equipment_info?.equipment_line || "").trim();
    const apiCategory = item.category || "Retails";
    const uiCategory = CATEGORY_MAP[apiCategory] || "Retail";

    equipmentTypesSet.add(equipmentType);

    // Initialize equipment type structure
    if (!equipmentModels[equipmentType]) {
      equipmentModels[equipmentType] = {
        MBP: { KAM: [], Retail: [] },
        Projection: { KAM: [], Retail: [] },
        Actuals: { KAM: [], Retail: [] },
      };
    }

    // Initialize quarterly summary for equipment type
    if (!quarterlySummary[equipmentType]) {
      quarterlySummary[equipmentType] = {
        Q1: { MBP: 0, Projection: 0, Actuals: 0 },
        Q2: { MBP: 0, Projection: 0, Actuals: 0 },
        Q3: { MBP: 0, Projection: 0, Actuals: 0 },
        Q4: { MBP: 0, Projection: 0, Actuals: 0 },
      };
    }

    // Create monthly data object
    const monthlyData = {};
    Object.keys(MONTH_FIELDS).forEach((apiField) => {
      const displayMonth = MONTH_FIELDS[apiField];
      monthlyData[displayMonth] = item[apiField] !== null ? String(item[apiField]) : "";
    });

    // Calculate totals
    const total = calculateMonthlyTotal(item);
    const quarters = calculateQuarterlyTotals(item);

    // Create model entry
    const modelEntry = {
      id: item.id,
      pdpEquipmentId: item.pdpEquipmentId,
      dealerInvestmentId: item.dealerInvestmentId,
      name: equipmentModel,
      equipmentType: equipmentType,
      equipmentMake: equipmentMake,
      equipmentLine: equipmentLine,
      category: apiCategory,
      monthlyData: monthlyData,
      pdpTarget: item.pdp_equipment_info?.pdp_target !== null 
        ? String(item.pdp_equipment_info?.pdp_target) 
        : "0",
      kamTotal: uiCategory === "KAM" ? String(total) : "0",
      retailTotal: uiCategory === "Retail" ? String(total) : "0",
    };

    // Add to appropriate category
    equipmentModels[equipmentType][dataType][uiCategory].push(modelEntry);

    // Update quarterly summary
    quarterlySummary[equipmentType].Q1[dataType] += quarters.Q1;
    quarterlySummary[equipmentType].Q2[dataType] += quarters.Q2;
    quarterlySummary[equipmentType].Q3[dataType] += quarters.Q3;
    quarterlySummary[equipmentType].Q4[dataType] += quarters.Q4;
  });

  // Convert quarterly summary numbers to strings
  Object.keys(quarterlySummary).forEach((type) => {
    ["Q1", "Q2", "Q3", "Q4"].forEach((q) => {
      quarterlySummary[type][q].MBP = String(quarterlySummary[type][q].MBP);
      quarterlySummary[type][q].Projection = String(quarterlySummary[type][q].Projection);
      quarterlySummary[type][q].Actuals = String(quarterlySummary[type][q].Actuals);
    });
  });

  return {
    equipmentModels,
    quarterlySummary,
    equipmentTypes: Array.from(equipmentTypesSet).sort(),
  };
};

/**
 * Merge multiple data types into single structure
 * @param {Object} mbpData - Transformed MBP data
 * @param {Object} projectionData - Transformed Projection data
 * @param {Object} actualsData - Transformed Actuals data
 */
export const mergeEquipmentData = (mbpData, projectionData, actualsData) => {
  const allTypes = new Set([
    ...mbpData.equipmentTypes,
    ...projectionData.equipmentTypes,
    ...actualsData.equipmentTypes,
  ]);

  const equipmentModels = {};
  const quarterlySummary = {};

  allTypes.forEach((type) => {
    equipmentModels[type] = {
      MBP: {
        KAM: mbpData.equipmentModels[type]?.MBP?.KAM || [],
        Retail: mbpData.equipmentModels[type]?.MBP?.Retail || [],
      },
      Projection: {
        KAM: projectionData.equipmentModels[type]?.Projection?.KAM || [],
        Retail: projectionData.equipmentModels[type]?.Projection?.Retail || [],
      },
      Actuals: {
        KAM: actualsData.equipmentModels[type]?.Actuals?.KAM || [],
        Retail: actualsData.equipmentModels[type]?.Actuals?.Retail || [],
      },
    };

    // Merge quarterly summaries
    quarterlySummary[type] = {
      Q1: {
        MBP: mbpData.quarterlySummary[type]?.Q1?.MBP || "0",
        Projection: projectionData.quarterlySummary[type]?.Q1?.Projection || "0",
        Actuals: actualsData.quarterlySummary[type]?.Q1?.Actuals || "0",
      },
      Q2: {
        MBP: mbpData.quarterlySummary[type]?.Q2?.MBP || "0",
        Projection: projectionData.quarterlySummary[type]?.Q2?.Projection || "0",
        Actuals: actualsData.quarterlySummary[type]?.Q2?.Actuals || "0",
      },
      Q3: {
        MBP: mbpData.quarterlySummary[type]?.Q3?.MBP || "0",
        Projection: projectionData.quarterlySummary[type]?.Q3?.Projection || "0",
        Actuals: actualsData.quarterlySummary[type]?.Q3?.Actuals || "0",
      },
      Q4: {
        MBP: mbpData.quarterlySummary[type]?.Q4?.MBP || "0",
        Projection: projectionData.quarterlySummary[type]?.Q4?.Projection || "0",
        Actuals: actualsData.quarterlySummary[type]?.Q4?.Actuals || "0",
      },
    };
  });

  return {
    equipmentModels,
    quarterlySummary,
    equipmentTypes: Array.from(allTypes).sort(),
  };
};

/**
 * Prepare data for API update
 * Converts component state back to API format
 * 
 * @param {Array} models - Array of model entries with updated monthly data
 * @returns {Array} Formatted rows for API update
 */
export const prepareEquipmentDataForUpdate = (models) => {
  if (!models || !Array.isArray(models)) return [];

  // Reverse month mapping
  const REVERSE_MONTH_MAP = {
    Jan: "jan",
    Feb: "feb",
    Mar: "mar",
    Apr: "apr",
    May: "may",
    Jun: "jun",
    Jul: "jul",
    Aug: "aug",
    Sep: "sep",
    Oct: "oct",
    Nov: "nov",
    Dec: "decem",
  };

  return models.map((model) => {
    const row = { id: model.id };

    // Convert monthly data back to API fields
    if (model.monthlyData) {
      Object.keys(model.monthlyData).forEach((displayMonth) => {
        const apiField = REVERSE_MONTH_MAP[displayMonth];
        if (apiField) {
          const value = model.monthlyData[displayMonth];
          row[apiField] = value !== "" && value !== null && value !== undefined 
            ? parseInt(value) 
            : null;
        }
      });
    }

    return row;
  });
};

/**
 * Get unique equipment models for dropdown
 */
export const getUniqueModels = (models) => {
  if (!models || !Array.isArray(models)) return [];
  return [...new Set(models.map((m) => m.name))].sort();
};

/**
 * Filter models by equipment model name
 */
export const filterModelsByName = (models, selectedModel) => {
  if (!models || !Array.isArray(models)) return [];
  if (selectedModel === "All Models") return models;
  return models.filter((m) => m.name === selectedModel);
};

// ============================================
// FETCH ALL DATA FUNCTION
// ============================================

/**
 * Fetch all equipment data (MBP, Projection, Actuals) for a dealer investment
 * @param {number} dealerInvestmentId 
 * @param {Object} filters - Optional filters { make: "Volvo", type: "Equipments" }
 * @returns {Object} Merged and transformed data
 */
export const fetchAllEquipmentData = async (dealerInvestmentId, filters = {}) => {
  try {
    const { make, type } = filters;
    
    // Fetch all three data types in parallel
    const [mbpResponse, projectionResponse, actualsResponse] = await Promise.all([
      getDealerInvestmentEquipmentMbpByDealerInvestmentId(dealerInvestmentId),
      getDealerInvestmentEquipmentProjectionByDealerInvestmentId(dealerInvestmentId),
      getDealerInvestmentEquipmentActualsByDealerInvestmentId(dealerInvestmentId),
    ]);

    // Get raw data
    let mbpRaw = mbpResponse?.status ? mbpResponse.data : [];
    let projectionRaw = projectionResponse?.status ? projectionResponse.data : [];
    let actualsRaw = actualsResponse?.status ? actualsResponse.data : [];

    // Apply filters if provided
    if (make || type) {
      console.log(`Filtering equipment data by Make: ${make}, Type: ${type}`);
      mbpRaw = filterEquipmentDataByMakeAndType(mbpRaw, make, type);
      projectionRaw = filterEquipmentDataByMakeAndType(projectionRaw, make, type);
      actualsRaw = filterEquipmentDataByMakeAndType(actualsRaw, make, type);
    }

    // Transform each response
    const mbpData = transformEquipmentData(mbpRaw, "MBP");
    const projectionData = transformEquipmentData(projectionRaw, "Projection");
    const actualsData = transformEquipmentData(actualsRaw, "Actuals");

    // Merge all data
    const mergedData = mergeEquipmentData(mbpData, projectionData, actualsData);

    console.log("Equipment data loaded:", {
      filters: { make, type },
      mbpCount: mbpRaw.length,
      projectionCount: projectionRaw.length,
      actualsCount: actualsRaw.length,
      equipmentTypes: mergedData.equipmentTypes,
    });

    return {
      status: true,
      data: mergedData,
      rawData: {
        mbp: mbpRaw,
        projection: projectionRaw,
        actuals: actualsRaw,
      },
    };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching all equipment data:", error);
    return {
      status: false,
      data: {
        equipmentModels: {},
        quarterlySummary: {},
        equipmentTypes: [],
      },
      rawData: { mbp: [], projection: [], actuals: [] },
    };
  }
};

// ============================================
// SAVE DATA FUNCTION
// ============================================

/**
 * Save equipment data based on data type
 * @param {string} dataType - "MBP", "Projection", or "Actuals"
 * @param {Array} models - Array of model entries to save
 */
export const saveEquipmentData = async (dataType, models) => {
  const rows = prepareEquipmentDataForUpdate(models);
  
  if (rows.length === 0) {
    return { status: false, message: "No data to save" };
  }

  console.log(`Saving ${dataType} data:`, rows);

  switch (dataType) {
    case "MBP":
      return await updateMultipleDealerInvestmentEquipmentMbp(rows);
    case "Projection":
      return await updateMultipleDealerInvestmentEquipmentProjection(rows);
    case "Actuals":
      return await updateMultipleDealerInvestmentEquipmentActuals(rows);
    default:
      throw new Error(`Unknown data type: ${dataType}`);
  }
};

// ============================================
// EXPORT DEFAULT
// ============================================
