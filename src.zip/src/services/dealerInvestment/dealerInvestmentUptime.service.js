/**
 * Dealer Investment Uptime & Parts Service
 * Handles all API calls and data transformation for Uptime & Parts module
 */

import axios from "axios";
import { API } from "../../api";

const { domain } = API;

// ============================================
// MONTH FIELD MAPPINGS
// ============================================
export const MONTH_FIELDS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "decem"];
export const MONTH_DISPLAY = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// ============================================
// API FUNCTIONS - MBP
// ============================================

/**
 * Get all Uptime MBP records by Dealer Investment ID
 */
export const getDealerInvestmentUptimeMbpByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.get(
      `${domain}${API.dealerInvestmentUptimeMbpEndpoints.getDealerInvestmentUptimeMbpByDealerInvestmentId}${dealerInvestmentId}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    return { status: true, data: response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching Uptime MBP:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

/**
 * Update multiple Uptime MBP records
 */
export const updateMultipleDealerInvestmentUptimeMbp = async (rows) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.put(
      `${domain}${API.dealerInvestmentUptimeMbpEndpoints.updateMultipleDealerInvestmentUptimeMbp}`,
      { rows },
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    return { status: true, data: response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating Uptime MBP:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

// ============================================
// API FUNCTIONS - PROJECTION
// ============================================

/**
 * Get all Uptime Projection records by Dealer Investment ID
 */
export const getDealerInvestmentUptimeProjectionByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.get(
      `${domain}${API.dealerInvestmentUptimeProjectionEndpoints.getDealerInvestmentUptimeProjectionByDealerInvestmentId}${dealerInvestmentId}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    return { status: true, data: response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching Uptime Projection:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

/**
 * Update multiple Uptime Projection records
 */
export const updateMultipleDealerInvestmentUptimeProjection = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.put(
      `${domain}${API.dealerInvestmentUptimeProjectionEndpoints.updateMultipleDealerInvestmentUptimeProjection}`,
      { rows },
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    return { status: true, data: response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating Uptime Projection:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

// ============================================
// API FUNCTIONS - ACTUALS
// ============================================

/**
 * Get all Uptime Actuals records by Dealer Investment ID
 */
export const getDealerInvestmentUptimeActualsByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.get(
      `${domain}${API.dealerInvestmentUptimeActualsEndpoints.getDealerInvestmentUptimeActualsByDealerInvestmentId}${dealerInvestmentId}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    return { status: true, data: response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching Uptime Actuals:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

/**
 * Update multiple Uptime Actuals records
 */
export const updateMultipleDealerInvestmentUptimeActuals = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await axios.put(
      `${domain}${API.dealerInvestmentUptimeActualsEndpoints.updateMultipleDealerInvestmentUptimeActuals}`,
      { rows },
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    return { status: true, data: response.data };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating Uptime Actuals:", error);
    return { status: false, message: error.response?.data?.message || error.message };
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Extract array from API response
 * Handles various response formats: array, { data: [] }, { rows: [] }, etc.
 */
const extractArrayFromResponse = (response) => {
  if (!response) return [];
  if (Array.isArray(response)) return response;
  if (response.data) {
    if (Array.isArray(response.data)) return response.data;
    if (Array.isArray(response.data.rows)) return response.data.rows;
    if (Array.isArray(response.data.result)) return response.data.result;
  }
  if (Array.isArray(response.rows)) return response.rows;
  if (Array.isArray(response.result)) return response.result;
  return [];
};

/**
 * Convert API month fields to display format
 */
const convertToMonthlyData = (item) => {
  const monthlyData = {};
  MONTH_DISPLAY.forEach((month, index) => {
    const apiField = MONTH_FIELDS[index];
    monthlyData[month] = item[apiField] !== null && item[apiField] !== undefined 
      ? String(item[apiField]) 
      : "";
  });
  return monthlyData;
};

/**
 * Create empty monthly data object
 */
const createEmptyMonthlyData = () => {
  const data = {};
  MONTH_DISPLAY.forEach(month => {
    data[month] = "";
  });
  return data;
};

/**
 * Calculate quarterly totals from monthly data
 */
const calculateQuarterly = (monthlyData) => {
  const parseVal = (val) => parseFloat(val) || 0;
  
  const q1 = parseVal(monthlyData["Jan"]) + parseVal(monthlyData["Feb"]) + parseVal(monthlyData["Mar"]);
  const q2 = parseVal(monthlyData["Apr"]) + parseVal(monthlyData["May"]) + parseVal(monthlyData["Jun"]);
  const q3 = parseVal(monthlyData["Jul"]) + parseVal(monthlyData["Aug"]) + parseVal(monthlyData["Sep"]);
  const q4 = parseVal(monthlyData["Oct"]) + parseVal(monthlyData["Nov"]) + parseVal(monthlyData["Dec"]);
  
  return {
    Q1: q1 > 0 ? String(q1) : "",
    Q2: q2 > 0 ? String(q2) : "",
    Q3: q3 > 0 ? String(q3) : "",
    Q4: q4 > 0 ? String(q4) : "",
  };
};

/**
 * Calculate total from monthly data
 */
const calculateTotal = (monthlyData) => {
  let total = 0;
  MONTH_DISPLAY.forEach(month => {
    total += parseFloat(monthlyData[month]) || 0;
  });
  return total;
};

/**
 * Calculate percentage with handling for division by zero
 */
const calculatePercentage = (numerator, denominator) => {
  if (!denominator || denominator === 0) return "";
  const percentage = (numerator / denominator) * 100;
  return `${percentage.toFixed(1)}%`;
};

// ============================================
// MAIN DATA TRANSFORMATION FUNCTION
// ============================================

/**
 * Transform raw API data into structured format for UI
 * Uses consistent naming: "Lube" (not "Lubes"), "Off take" (not "Off Take")
 */
const transformUptimeData = (mbpData = [], projectionData = [], actualsData = []) => {
  // Ensure we're working with arrays
  const safeMbpData = Array.isArray(mbpData) ? mbpData : [];
  const safeProjData = Array.isArray(projectionData) ? projectionData : [];
  const safeActualsData = Array.isArray(actualsData) ? actualsData : [];

  console.log("transformUptimeData input:", {
    mbpCount: safeMbpData.length,
    projCount: safeProjData.length,
    actualsCount: safeActualsData.length,
  });

  // Initialize target data structure
  const targetData = [
    { make: "Volvo", parts: { retail: "0", offtake: "0" }, lube: { retail: "0", offtake: "0" }, csa: "0" },
    { make: "SDLG", parts: { retail: "0", offtake: "0" }, lube: { retail: "0", offtake: "0" }, csa: "0" },
  ];

  // Initialize all data structure - CONSISTENT NAMING for UI
  const allData = {
    Volvo: {
      Parts: { Retail: null, "Off take": null },
      Lube: { Retail: null, "Off take": null },
    },
    SDLG: {
      Parts: { Retail: null, "Off take": null },
      Lube: { Retail: null, "Off take": null },
    },
    CSA: null,
  };

  // Helper to create data entry structure
  const createDataEntry = (mbpItem, projItem, actualsItem) => {
    const mbpMonthly = mbpItem ? convertToMonthlyData(mbpItem) : createEmptyMonthlyData();
    const projMonthly = projItem ? convertToMonthlyData(projItem) : createEmptyMonthlyData();
    const actualsMonthly = actualsItem ? convertToMonthlyData(actualsItem) : createEmptyMonthlyData();

    // Calculate Achievement % (Actuals / MBP * 100)
    const achievementMonthly = {};
    MONTH_DISPLAY.forEach(month => {
      achievementMonthly[month] = calculatePercentage(
        parseFloat(actualsMonthly[month]) || 0,
        parseFloat(mbpMonthly[month]) || 0
      );
    });

    // Calculate Accuracy % (Actuals / Projection * 100)
    const accuracyMonthly = {};
    MONTH_DISPLAY.forEach(month => {
      accuracyMonthly[month] = calculatePercentage(
        parseFloat(actualsMonthly[month]) || 0,
        parseFloat(projMonthly[month]) || 0
      );
    });

    // Calculate quarterly data
    const mbpQuarterly = calculateQuarterly(mbpMonthly);
    const projQuarterly = calculateQuarterly(projMonthly);
    const actualsQuarterly = calculateQuarterly(actualsMonthly);

    // Calculate quarterly percentages
    const achievementQuarterly = {
      Q1: calculatePercentage(parseFloat(actualsQuarterly.Q1), parseFloat(mbpQuarterly.Q1)),
      Q2: calculatePercentage(parseFloat(actualsQuarterly.Q2), parseFloat(mbpQuarterly.Q2)),
      Q3: calculatePercentage(parseFloat(actualsQuarterly.Q3), parseFloat(mbpQuarterly.Q3)),
      Q4: calculatePercentage(parseFloat(actualsQuarterly.Q4), parseFloat(mbpQuarterly.Q4)),
    };

    const accuracyQuarterly = {
      Q1: calculatePercentage(parseFloat(actualsQuarterly.Q1), parseFloat(projQuarterly.Q1)),
      Q2: calculatePercentage(parseFloat(actualsQuarterly.Q2), parseFloat(projQuarterly.Q2)),
      Q3: calculatePercentage(parseFloat(actualsQuarterly.Q3), parseFloat(projQuarterly.Q3)),
      Q4: calculatePercentage(parseFloat(actualsQuarterly.Q4), parseFloat(projQuarterly.Q4)),
    };

    // Calculate stats
    const pdpTarget = mbpItem?.pdp_uptime_info?.target || "0";
    const totalMBP = calculateTotal(mbpMonthly);
    const ytdActuals = calculateTotal(actualsMonthly);
    const ytdAchievement = calculatePercentage(ytdActuals, totalMBP);

    return {
      ids: {
        mbpId: mbpItem?.id || null,
        projectionId: projItem?.id || null,
        actualsId: actualsItem?.id || null,
      },
      monthly: {
        "Monthly Business Plan": mbpMonthly,
        "Monthly Projection": projMonthly,
        "Actuals": actualsMonthly,
        "Achievement %": achievementMonthly,
        "Accuracy %": accuracyMonthly,
      },
      quarterly: {
        "Quarterly Business Plan": mbpQuarterly,
        "Quarterly Projections": projQuarterly,
        "Actuals": actualsQuarterly,
        "Achievement %": achievementQuarterly,
        "Accuracy %": accuracyQuarterly,
      },
      stats: {
        pdpTarget: String(pdpTarget),
        totalMBP: String(totalMBP),
        ytdActuals: String(ytdActuals),
        ytdAchievement: ytdAchievement,
      },
    };
  };

  // Map API values to UI values - CONSISTENT NAMING
  const mapToUI = (item) => {
    const make = item?.uptime_info?.equipment_make; // "Volvo" or "SDLG"
    const details = item?.uptime_info?.details; // "Parts", "Lubes", "Service Revenue"
    const category = item?.category; // "Retails" or "Off Take"

    // Map make
    const uiMake = make === "Volvo" ? "Volvo" : make === "SDLG" ? "SDLG" : null;
    
    // Map category (API "Lubes" → UI "Lube", API "Service Revenue" → CSA)
    let uiCategory = null;
    if (details === "Parts") uiCategory = "Parts";
    else if (details === "Lubes" || details === "Lube") uiCategory = "Lube";
    else if (details === "Service Revenue") uiCategory = "CSA";
    
    // Map business type (API "Retails" → UI "Retail", API "Off Take" → UI "Off take")
    let uiBusinessType = null;
    if (category === "Retails" || category === "Retail") uiBusinessType = "Retail";
    else if (category === "Off Take" || category === "Off take") uiBusinessType = "Off take";

    return { uiMake, uiCategory, uiBusinessType };
  };

  // Group data by identifiers (pdpUptimeId links MBP, Projection, Actuals)
  const groupedData = {};

  // Group MBP data
  safeMbpData.forEach(item => {
    const key = item.pdpUptimeId || `mbp_${item.id}`;
    if (!groupedData[key]) {
      groupedData[key] = { mbp: null, projection: null, actuals: null };
    }
    groupedData[key].mbp = item;
  });

  // Group Projection data
  safeProjData.forEach(item => {
    const key = item.pdpUptimeId || `proj_${item.id}`;
    if (!groupedData[key]) {
      groupedData[key] = { mbp: null, projection: null, actuals: null };
    }
    groupedData[key].projection = item;
  });

  // Group Actuals data
  safeActualsData.forEach(item => {
    const key = item.pdpUptimeId || `actuals_${item.id}`;
    if (!groupedData[key]) {
      groupedData[key] = { mbp: null, projection: null, actuals: null };
    }
    groupedData[key].actuals = item;
  });

  // CSA aggregation containers
  const csaData = {
    mbpIds: [],
    projectionIds: [],
    actualsIds: [],
    mbpMonthlySum: createEmptyMonthlyData(),
    projMonthlySum: createEmptyMonthlyData(),
    actualsMonthlySum: createEmptyMonthlyData(),
    pdpTargetSum: 0,
  };

  // Process grouped data
  Object.values(groupedData).forEach(group => {
    const refItem = group.mbp || group.projection || group.actuals;
    if (!refItem) return;

    const { uiMake, uiCategory, uiBusinessType } = mapToUI(refItem);

    console.log("Processing item:", {
      make: refItem?.uptime_info?.equipment_make,
      details: refItem?.uptime_info?.details,
      category: refItem?.category,
      mapped: { uiMake, uiCategory, uiBusinessType },
    });

    if (uiCategory === "CSA") {
      // Aggregate Service Revenue into CSA
      if (group.mbp) {
        csaData.mbpIds.push(group.mbp.id);
        MONTH_DISPLAY.forEach((month, index) => {
          csaData.mbpMonthlySum[month] = String(
            (parseFloat(csaData.mbpMonthlySum[month]) || 0) + (parseFloat(group.mbp[MONTH_FIELDS[index]]) || 0)
          );
        });
        csaData.pdpTargetSum += parseFloat(group.mbp.pdp_uptime_info?.target) || 0;
      }
      if (group.projection) {
        csaData.projectionIds.push(group.projection.id);
        MONTH_DISPLAY.forEach((month, index) => {
          csaData.projMonthlySum[month] = String(
            (parseFloat(csaData.projMonthlySum[month]) || 0) + (parseFloat(group.projection[MONTH_FIELDS[index]]) || 0)
          );
        });
      }
      if (group.actuals) {
        csaData.actualsIds.push(group.actuals.id);
        MONTH_DISPLAY.forEach((month, index) => {
          csaData.actualsMonthlySum[month] = String(
            (parseFloat(csaData.actualsMonthlySum[month]) || 0) + (parseFloat(group.actuals[MONTH_FIELDS[index]]) || 0)
          );
        });
      }
    } else if (uiMake && uiCategory && uiBusinessType) {
      // Regular Parts/Lube data
      const dataEntry = createDataEntry(group.mbp, group.projection, group.actuals);
      
      if (allData[uiMake] && allData[uiMake][uiCategory]) {
        allData[uiMake][uiCategory][uiBusinessType] = dataEntry;
        console.log(`Set data for ${uiMake} > ${uiCategory} > ${uiBusinessType}`);
      }

      // Update target data with PDP Target
      const targetIndex = uiMake === "Volvo" ? 0 : 1;
      const categoryKey = uiCategory === "Parts" ? "parts" : "lube";
      const businessKey = uiBusinessType === "Retail" ? "retail" : "offtake";
      
      if (targetData[targetIndex] && targetData[targetIndex][categoryKey]) {
        targetData[targetIndex][categoryKey][businessKey] = dataEntry.stats.pdpTarget || "0";
      }
    }
  });

  // Build CSA data entry
  const csaAchievementMonthly = {};
  const csaAccuracyMonthly = {};
  MONTH_DISPLAY.forEach(month => {
    csaAchievementMonthly[month] = calculatePercentage(
      parseFloat(csaData.actualsMonthlySum[month]) || 0,
      parseFloat(csaData.mbpMonthlySum[month]) || 0
    );
    csaAccuracyMonthly[month] = calculatePercentage(
      parseFloat(csaData.actualsMonthlySum[month]) || 0,
      parseFloat(csaData.projMonthlySum[month]) || 0
    );
  });

  const csaMbpQuarterly = calculateQuarterly(csaData.mbpMonthlySum);
  const csaProjQuarterly = calculateQuarterly(csaData.projMonthlySum);
  const csaActualsQuarterly = calculateQuarterly(csaData.actualsMonthlySum);

  const csaTotalMBP = calculateTotal(csaData.mbpMonthlySum);
  const csaYtdActuals = calculateTotal(csaData.actualsMonthlySum);

  allData.CSA = {
    ids: {
      mbpIds: csaData.mbpIds,
      projectionIds: csaData.projectionIds,
      actualsIds: csaData.actualsIds,
    },
    monthly: {
      "Monthly Business Plan": csaData.mbpMonthlySum,
      "Monthly Projection": csaData.projMonthlySum,
      "Actuals": csaData.actualsMonthlySum,
      "Achievement %": csaAchievementMonthly,
      "Accuracy %": csaAccuracyMonthly,
    },
    quarterly: {
      "Quarterly Business Plan": csaMbpQuarterly,
      "Quarterly Projections": csaProjQuarterly,
      "Actuals": csaActualsQuarterly,
      "Achievement %": {
        Q1: calculatePercentage(parseFloat(csaActualsQuarterly.Q1), parseFloat(csaMbpQuarterly.Q1)),
        Q2: calculatePercentage(parseFloat(csaActualsQuarterly.Q2), parseFloat(csaMbpQuarterly.Q2)),
        Q3: calculatePercentage(parseFloat(csaActualsQuarterly.Q3), parseFloat(csaMbpQuarterly.Q3)),
        Q4: calculatePercentage(parseFloat(csaActualsQuarterly.Q4), parseFloat(csaMbpQuarterly.Q4)),
      },
      "Accuracy %": {
        Q1: calculatePercentage(parseFloat(csaActualsQuarterly.Q1), parseFloat(csaProjQuarterly.Q1)),
        Q2: calculatePercentage(parseFloat(csaActualsQuarterly.Q2), parseFloat(csaProjQuarterly.Q2)),
        Q3: calculatePercentage(parseFloat(csaActualsQuarterly.Q3), parseFloat(csaProjQuarterly.Q3)),
        Q4: calculatePercentage(parseFloat(csaActualsQuarterly.Q4), parseFloat(csaProjQuarterly.Q4)),
      },
    },
    stats: {
      pdpTarget: String(csaData.pdpTargetSum),
      totalMBP: String(csaTotalMBP),
      ytdActuals: String(csaYtdActuals),
      ytdAchievement: calculatePercentage(csaYtdActuals, csaTotalMBP),
    },
  };

  // Update CSA in target data with PDP Target
  targetData[0].csa = String(csaData.pdpTargetSum);
  targetData[1].csa = "0";

  console.log("transformUptimeData output:", {
    targetData,
    allDataKeys: Object.keys(allData),
    volvoPartsRetail: allData.Volvo?.Parts?.Retail,
    volvoLubeOfftake: allData.Volvo?.Lube?.["Off take"],
  });

  return { targetData, allData };
};

// ============================================
// MAIN FETCH FUNCTION
// ============================================

/**
 * Fetch all uptime data and transform for UI
 */
export const fetchAllUptimeData = async (dealerInvestmentId) => {
  try {
    // Fetch all three data types in parallel
    const [mbpResponse, projResponse, actualsResponse] = await Promise.all([
      getDealerInvestmentUptimeMbpByDealerInvestmentId(dealerInvestmentId),
      getDealerInvestmentUptimeProjectionByDealerInvestmentId(dealerInvestmentId),
      getDealerInvestmentUptimeActualsByDealerInvestmentId(dealerInvestmentId),
    ]);

    // Extract arrays from responses (handles various API response formats)
    const mbpData = mbpResponse.status ? extractArrayFromResponse(mbpResponse.data) : [];
    const projectionData = projResponse.status ? extractArrayFromResponse(projResponse.data) : [];
    const actualsData = actualsResponse.status ? extractArrayFromResponse(actualsResponse.data) : [];

    console.log("Uptime API Data:", {
      mbpCount: mbpData.length,
      projectionCount: projectionData.length,
      actualsCount: actualsData.length,
      mbpSample: mbpData[0],
    });

    // Transform data for UI
    const { targetData, allData } = transformUptimeData(mbpData, projectionData, actualsData);

    return {
      status: true,
      data: {
        targetData,
        allData,
        rawData: {
          mbp: mbpData,
          projection: projectionData,
          actuals: actualsData,
        },
      },
    };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching all uptime data:", error);
    return { status: false, message: error.message };
  }
};

// ============================================
// SAVE FUNCTION
// ============================================

/**
 * Prepare update payload from UI data
 */
export const prepareUpdatePayload = (currentData, rowType) => {
  const monthlyData = currentData.monthly[rowType];
  if (!monthlyData) return null;

  let id = null;
  if (rowType === "Monthly Business Plan") {
    id = currentData.ids.mbpId;
  } else if (rowType === "Monthly Projection") {
    id = currentData.ids.projectionId;
  } else if (rowType === "Actuals") {
    id = currentData.ids.actualsId;
  }

  if (!id) return null;

  const payload = { id };
  MONTH_DISPLAY.forEach((month, index) => {
    const value = monthlyData[month];
    payload[MONTH_FIELDS[index]] = value !== "" ? parseFloat(value) : null;
  });

  return payload;
};