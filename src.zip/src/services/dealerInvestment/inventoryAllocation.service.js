
import axios from "axios";
import { API } from "../../api";

const BASE_URL = API.domain;

// ============================================
// AUTHENTICATION HELPER
// ============================================

/**
 * Get auth headers with token
 * @returns {Object} Headers object with Content-Type and Authorization
 */
const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

/**
 * Handle token expiry and redirect to login
 * @param {Object} error - Axios error object
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ============================================
// INVENTORY ALLOCATION MANAGEMENT APIs
// ============================================

/**
 * Get all inventory allocations
 * @returns {Promise} API response with all inventory allocations
 */
export const getAllInventoryAllocations = async () => {
  try {
    const response = await axios.get(
      `${BASE_URL}${API.inventoryAllocationEndpoints.getAllInventoryAllocations}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching inventory allocations:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Get inventory allocation by ID
 * @param {number} id - Inventory allocation ID
 * @returns {Promise} API response with inventory allocation details
 */
export const getInventoryAllocationById = async (id) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${API.inventoryAllocationEndpoints.getInventoryAllocationById}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching inventory allocation:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Add new inventory allocation
 * Creates inventory and auto-generates equipment entries for all months
 * @param {Object} data - { inventory_year: number }
 * @returns {Promise} API response
 */
export const addInventoryAllocation = async (data) => {
  try {
    const response = await axios.post(
      `${BASE_URL}${API.inventoryAllocationEndpoints.addInventoryAllocation}`,
      data,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error adding inventory allocation:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Update inventory allocation
 * @param {Object} data - { id: number, inventory_year: number }
 * @returns {Promise} API response
 */
export const updateInventoryAllocation = async (data) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${API.inventoryAllocationEndpoints.updateInventoryAllocation}`,
      data,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error updating inventory allocation:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Toggle inventory allocation active status
 * @param {number} id - Inventory allocation ID
 * @returns {Promise} API response
 */
export const toggleInventoryAllocationStatus = async (id) => {
  try {
    const response = await axios.patch(
      `${BASE_URL}${API.inventoryAllocationEndpoints.toggleInventoryAllocationStatus}${id}`,
      {},
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error toggling inventory allocation status:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Delete inventory allocation (soft delete)
 * @param {number} id - Inventory allocation ID
 * @returns {Promise} API response
 */
export const deleteInventoryAllocation = async (id) => {
  try {
    const response = await axios.delete(
      `${BASE_URL}${API.inventoryAllocationEndpoints.deleteInventoryAllocation}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error deleting inventory allocation:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

// ============================================
// INVENTORY DATA ALLOCATION MANAGEMENT APIs
// ============================================

/**
 * Get all inventory data allocations
 * @returns {Promise} API response with all inventory data allocations
 */
export const getAllInventoryDataAllocations = async () => {
  try {
    const response = await axios.get(
      `${BASE_URL}${API.inventoryAllocationEndpoints.getAllInventoryDataAllocations}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching inventory data allocations:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Get inventory data allocation by ID
 * @param {number} id - Inventory data allocation ID
 * @returns {Promise} API response with inventory data allocation details
 */
export const getInventoryDataAllocationById = async (id) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${API.inventoryAllocationEndpoints.getInventoryDataAllocationById}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching inventory data allocation:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Get inventory data allocations by inventory ID
 * This is the main API for ViewInventory page
 * @param {number} inventoryId - Inventory allocation ID
 * @returns {Promise} API response with all equipment data for the inventory
 */
export const getInventoryDataAllocationsByInventoryId = async (inventoryId) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${API.inventoryAllocationEndpoints.getInventoryDataAllocationsByInventoryId}${inventoryId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching inventory data allocations by inventory ID:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Update single inventory data allocation
 * @param {Object} data - Inventory data allocation update object
 * @returns {Promise} API response
 */
export const updateInventoryDataAllocation = async (data) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${API.inventoryAllocationEndpoints.updateInventoryDataAllocation}`,
      data,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error updating inventory data allocation:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Update multiple inventory data allocations (bulk update)
 * @param {Array} rows - Array of objects with id and month fields to update
 * @returns {Promise} API response
 *
 * @example
 * updateMultipleInventoryDataAllocations([
 *   { id: 1, january_open_stock: 100, january_arrivals: 50 },
 *   { id: 2, january_open_stock: 200, january_arrivals: 75 }
 * ])
 */
export const updateMultipleInventoryDataAllocations = async (rows) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${API.inventoryAllocationEndpoints.updateMultipleInventoryDataAllocations}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error updating multiple inventory data allocations:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Toggle inventory data allocation active status
 * @param {number} id - Inventory data allocation ID
 * @returns {Promise} API response
 */
export const toggleInventoryDataAllocationStatus = async (id) => {
  try {
    const response = await axios.patch(
      `${BASE_URL}${API.inventoryAllocationEndpoints.toggleInventoryDataAllocationStatus}${id}`,
      {},
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error toggling inventory data allocation status:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

/**
 * Delete inventory data allocation (soft delete)
 * @param {number} id - Inventory data allocation ID
 * @returns {Promise} API response
 */
export const deleteInventoryDataAllocation = async (id) => {
  try {
    const response = await axios.delete(
      `${BASE_URL}${API.inventoryAllocationEndpoints.deleteInventoryDataAllocation}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error deleting inventory data allocation:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Get month field names for API
 * @param {string} month - Month name (e.g., "January", "February")
 * @returns {Object} - { openStock: string, arrivals: string }
 *
 * @example
 * getMonthFieldNames("January")
 * // Returns: { openStock: "january_open_stock", arrivals: "january_arrivals" }
 */
export const getMonthFieldNames = (month) => {
  const monthLower = month.toLowerCase();
  return {
    openStock: `${monthLower}_open_stock`,
    arrivals: `${monthLower}_arrivals`,
  };
};

/**
 * Calculate close stock
 * @param {number|string} openStock - Open stock value
 * @param {number|string} arrivals - Arrivals value
 * @returns {number} - Close stock (openStock + arrivals)
 */
export const calculateCloseStock = (openStock, arrivals) => {
  return (parseInt(openStock, 10) || 0) + (parseInt(arrivals, 10) || 0);
};

/**
 * Format date for display
 * @param {string} dateString - Date string from API
 * @returns {string} - Formatted date string (e.g., "07 Jan 2026")
 */
export const formatDate = (dateString) => {
  if (!dateString) return "-";
  const date = new Date(dateString);
  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

/**
 * Get all month names
 * @returns {Array} Array of month names
 */
export const getMonthNames = () => [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

/**
 * Get current month name
 * @returns {string} Current month name
 */
export const getCurrentMonth = () => {
  const monthNames = getMonthNames();
  const today = new Date();
  return monthNames[today.getMonth()];
};