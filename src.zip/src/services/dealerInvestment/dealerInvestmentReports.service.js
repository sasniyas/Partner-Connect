

import axios from "axios";
import { API } from "../../api";

const { domain } = API;

// ============================================
// UTILITY FUNCTIONS
// ============================================

const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

/**
 * Handle token expiration
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

/**
 * Extract array from API response
 */
const extractArrayFromResponse = (response) => {
  if (!response) return [];
  if (Array.isArray(response)) return response;
  if (response.data) {
    if (Array.isArray(response.data)) return response.data;
    if (Array.isArray(response.data.rows)) return response.data.rows;
  }
  if (Array.isArray(response.rows)) return response.rows;
  return [];
};

/**
 * Get dealer short name from dealer info
 */
const getDealerShortName = (investment) => {
  return (
    investment.dealer_info?.dealer_short_name?.trim() ||
    investment.dealer_info?.dealer_name?.trim() ||
    "Unknown"
  );
};

// ============================================
// BASE API FUNCTIONS
// ============================================

/**
 * Get all dealer investments
 */
export const getAllDealerInvestments = async () => {
  try {
    const response = await axios.get(
      `${domain}${API.dealerInvestmentEndpoints.getAllDealerInvestment}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching dealer investments:", error);
    throw error;
  }
};

/**
 * Get infrastructure data by dealer investment ID
 */
export const getInfrastructureByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${API.dealerInvestmentInfrastructureEndpoints.getDealerInvestmentInfrastructureByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching infrastructure:", error);
    return { status: false, data: [] };
  }
};

/**
 * Get competence data by dealer investment ID
 */
export const getCompetenceByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${API.dealerInvestmentCompetenceEndpoints.getDealerInvestmentCompetenceByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching competence:", error);
    return { status: false, data: [] };
  }
};

/**
 * Get vehicles data by dealer investment ID
 */
export const getVehiclesByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${API.dealerInvestmentVehiclesEndpoints.getDealerInvestmentVehiclesByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching vehicles:", error);
    return { status: false, data: [] };
  }
};

/**
 * Get machine population by dealer investment ID
 */
export const getMachinePopulationByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${API.dealerInvestmentMachinePopulationEndpoints.getDealerInvestmentMachinePopulationByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching machine population:", error);
    return { status: false, data: [] };
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Categorize competence into SCL, TCL, CCL, LCL
 */
const categorizeCompetence = (name) => {
  const lowerName = (name || "").trim().toLowerCase();
  
  // SCL (Sales Competence Level)
  if (lowerName.includes("scl") || (lowerName.includes("sales") && !lowerName.includes("vehicle"))) {
    if (lowerName.includes("scl-0") || lowerName.includes("scl0") || lowerName.includes("scl 0")) return "scl0";
    if (lowerName.includes("scl-1 pro") || lowerName.includes("scl1 pro") || lowerName.includes("scl 1 pro")) return "scl1Pro";
    if (lowerName.includes("scl-1") || lowerName.includes("scl1") || lowerName.includes("scl 1")) return "scl1";
    if (lowerName.includes("scl-2") || lowerName.includes("scl2") || lowerName.includes("scl 2")) return "scl2";
    if (lowerName.includes("scl-3") || lowerName.includes("scl3") || lowerName.includes("scl 3")) return "scl3";
    return "scl0";
  }
  
  // TCL (Technical Competence Level)
  if (lowerName.includes("tcl") || lowerName.includes("technical")) {
    if (lowerName.includes("tcl-0") || lowerName.includes("tcl0") || lowerName.includes("tcl 0")) return "tcl0";
    if (lowerName.includes("tcl-1") || lowerName.includes("tcl1") || lowerName.includes("tcl 1")) return "tcl1";
    if (lowerName.includes("tcl-2") || lowerName.includes("tcl2") || lowerName.includes("tcl 2")) return "tcl2";
    if (lowerName.includes("tcl-3 pro") || lowerName.includes("tcl3 pro") || lowerName.includes("tcl 3 pro")) return "tcl3Pro";
    if (lowerName.includes("tcl-3") || lowerName.includes("tcl3") || lowerName.includes("tcl 3")) return "tcl3";
    return "tcl0";
  }
  
  // CCL (Commercial Competence Level / CSR)
  if (lowerName.includes("ccl") || lowerName.includes("csr") || lowerName.includes("commercial")) {
    if (lowerName.includes("ccl-0") || lowerName.includes("ccl0") || lowerName.includes("ccl 0") || lowerName.includes("csr-0") || lowerName.includes("csr0")) return "ccl0";
    if (lowerName.includes("ccl-1") || lowerName.includes("ccl1") || lowerName.includes("ccl 1") || lowerName.includes("csr-1") || lowerName.includes("csr1")) return "ccl1";
    if (lowerName.includes("ccl-2") || lowerName.includes("ccl2") || lowerName.includes("ccl 2") || lowerName.includes("csr-2") || lowerName.includes("csr2")) return "ccl2";
    if (lowerName.includes("ccl-3") || lowerName.includes("ccl3") || lowerName.includes("ccl 3") || lowerName.includes("csr-3") || lowerName.includes("csr3")) return "ccl3";
    return "ccl0";
  }
  
  return null;
};

/**
 * Classify facility type
 */
const classifyFacilityType = (facilityType) => {
  const type = (facilityType || "").trim().toLowerCase();
  
  if (type.includes("1s") || type === "1s") return "1S";
  if (type.includes("2s") || type === "2s") return "2S";
  if (type.includes("3s") || type === "3s") return "3S";
  if (type.includes("touch point") || type.includes("tp") || type === "tp") return "TP";
  
  return null;
};

/**
 * Classify vehicle type
 */
const classifyVehicleType = (vehicleCategory, vehicleType) => {
  const category = (vehicleCategory || "").toLowerCase();
  const type = (vehicleType || "").toLowerCase();
  
  const isSales = category.includes("sales");
  const isService = category.includes("service");
  const isFourWheeler = type.includes("4") || type.includes("four") || type.includes("4-wheeler") || type.includes("4 wheeler");
  const isTwoWheeler = type.includes("2") || type.includes("two") || type.includes("2-wheeler") || type.includes("2 wheeler");
  
  return { isSales, isService, isFourWheeler, isTwoWheeler };
};

/**
 * Calculate YTD Actual from quarterly data
 */
const calculateYtdActual = (item) => {
  if (item.ytd_actual !== undefined && item.ytd_actual !== null) {
    return parseInt(item.ytd_actual) || 0;
  }
  return (parseInt(item.q1) || 0) + (parseInt(item.q2) || 0) + 
         (parseInt(item.q3) || 0) + (parseInt(item.q4) || 0);
};

/**
 * Helper function to fetch facilities count for a single investment
 */
const fetchFacilitiesForInvestment = async (investmentId) => {
  let totalFacilities = 0;
  try {
    const infraResponse = await getInfrastructureByDealerInvestmentId(investmentId);
    const infraData = extractArrayFromResponse(infraResponse);
    
    infraData.forEach(item => {
      const facilityType = item.infrastructure_info?.facility_type || item.facility_type;
      if (classifyFacilityType(facilityType)) {
        const ytdActual = calculateYtdActual(item);
        totalFacilities += ytdActual;
      }
    });
  } catch (err) {
    console.error(`Error fetching infrastructure for investment ${investmentId}:`, err);
  }
  return totalFacilities;
};

// ============================================
// REPORT DATA FUNCTIONS
// ============================================

/**
 * Fetch available years from dealer investments
 */
export const fetchAvailableYears = async () => {
  try {
    const investmentsResponse = await getAllDealerInvestments();
    const investments = extractArrayFromResponse(investmentsResponse);
    
    const years = [...new Set(
      investments
        .map(inv => inv.pdp_info?.year)
        .filter(Boolean)
    )].sort((a, b) => b - a);

    return { status: true, data: years.map(String) };
  } catch (error) {
    console.error("Error fetching available years:", error);
    return { status: false, data: [] };
  }
};

/**
 * Fetch Facility Growth YOY data
 * Returns year-wise facility count
 */
export const fetchFacilityGrowthYOYData = async (selectedYear) => {
  try {
    const investmentsResponse = await getAllDealerInvestments();
    const investments = extractArrayFromResponse(investmentsResponse);
    
    if (!investments || investments.length === 0) {
      return { status: false, data: [] };
    }

    // Group investments by year
    const yearlyData = {};
    
    for (const investment of investments) {
      const year = investment.pdp_info?.year;
      if (!year) continue;
      
      if (!yearlyData[year]) {
        yearlyData[year] = {
          year: String(year),
          facilities: 0,
          dealerInvestmentIds: []
        };
      }
      yearlyData[year].dealerInvestmentIds.push(investment.id);
    }

    // Fetch infrastructure data for each year's investments
    for (const year of Object.keys(yearlyData)) {
      const investmentIds = yearlyData[year].dealerInvestmentIds;
      
      // Fetch all facilities in parallel for this year
      const facilitiesPromises = investmentIds.map(id => fetchFacilitiesForInvestment(id));
      const facilitiesResults = await Promise.all(facilitiesPromises);
      
      // Sum all facilities for this year
      yearlyData[year].facilities = facilitiesResults.reduce((sum, count) => sum + count, 0);
    }

    // Convert to array and sort by year
    const chartData = Object.values(yearlyData)
      .filter(item => parseInt(item.year) <= parseInt(selectedYear))
      .map(item => ({
        year: item.year,
        facilities: item.facilities
      }))
      .sort((a, b) => parseInt(a.year) - parseInt(b.year));

    return { status: true, data: chartData };
  } catch (error) {
    console.error("Error fetching facility growth YOY data:", error);
    return { status: false, data: [] };
  }
};

/**
 * Fetch Dealerwise Facilities data
 * Returns facility breakdown by dealer
 */
export const fetchDealerwiseFacilitiesData = async (selectedYear) => {
  try {
    const investmentsResponse = await getAllDealerInvestments();
    const investments = extractArrayFromResponse(investmentsResponse);
    
    // Filter by selected year
    const yearInvestments = investments.filter(
      inv => String(inv.pdp_info?.year) === String(selectedYear)
    );

    if (yearInvestments.length === 0) {
      return { status: false, data: [] };
    }

    const chartData = [];

    for (const investment of yearInvestments) {
      const dealerName = getDealerShortName(investment);
      
      // Initialize dealer data
      const dealerData = {
        dealer: dealerName,
        "1S": 0,
        "2S": 0,
        "3S": 0,
        "TP": 0,
        totalActual: 0,
        target: 0,
        population: 0
      };

      try {
        // Fetch infrastructure data
        const infraResponse = await getInfrastructureByDealerInvestmentId(investment.id);
        const infraData = extractArrayFromResponse(infraResponse);
        
        infraData.forEach(item => {
          const facilityType = classifyFacilityType(item.infrastructure_info?.facility_type || item.facility_type);
          if (facilityType) {
            const ytdActual = calculateYtdActual(item);
            dealerData[facilityType] += ytdActual;
            dealerData.totalActual += ytdActual;
            dealerData.target += parseInt(item.infrastructure_info?.target || item.pdp_target) || 0;
          }
        });

        // Fetch machine population
        const popResponse = await getMachinePopulationByDealerInvestmentId(investment.id);
        const popData = extractArrayFromResponse(popResponse);
        
        popData.forEach(item => {
          const actual = calculateYtdActual(item);
          dealerData.population += actual;
        });
      } catch (err) {
        console.error(`Error fetching data for dealer ${dealerName}:`, err);
      }

      chartData.push(dealerData);
    }

    // Sort by dealer name
    chartData.sort((a, b) => a.dealer.localeCompare(b.dealer));

    return { status: true, data: chartData };
  } catch (error) {
    console.error("Error fetching dealerwise facilities data:", error);
    return { status: false, data: [] };
  }
};

/**
 * Fetch Sales Vehicles data
 */
export const fetchSalesVehiclesData = async (selectedYear) => {
  try {
    const investmentsResponse = await getAllDealerInvestments();
    const investments = extractArrayFromResponse(investmentsResponse);
    
    const yearInvestments = investments.filter(
      inv => String(inv.pdp_info?.year) === String(selectedYear)
    );

    if (yearInvestments.length === 0) {
      return { status: false, data: [] };
    }

    const chartData = [];

    for (const investment of yearInvestments) {
      const dealerName = getDealerShortName(investment);
      
      const dealerData = {
        dealer: dealerName,
        fourWheeler: 0,
        twoWheeler: 0,
        target: 0,
        population: 0
      };

      try {
        // Fetch vehicles data
        const vehiclesResponse = await getVehiclesByDealerInvestmentId(investment.id);
        const vehiclesData = extractArrayFromResponse(vehiclesResponse);
        
        vehiclesData.forEach(vehicle => {
          const { isSales, isFourWheeler, isTwoWheeler } = classifyVehicleType(
            vehicle.vehicle_category || vehicle.category,
            vehicle.vehicle_type || vehicle.vehicleType
          );
          
          if (isSales) {
            if (isFourWheeler) dealerData.fourWheeler += 1;
            else if (isTwoWheeler) dealerData.twoWheeler += 1;
            else dealerData.fourWheeler += 1; // Default to 4-wheeler
          }
        });

        // Fetch infrastructure for target (vehicles type)
        const infraResponse = await getInfrastructureByDealerInvestmentId(investment.id);
        const infraData = extractArrayFromResponse(infraResponse);
        
        infraData.forEach(item => {
          const facilityType = (item.infrastructure_info?.facility_type || item.facility_type || "").toLowerCase();
          if (facilityType.includes("vehicle") && facilityType.includes("sales")) {
            dealerData.target += parseInt(item.infrastructure_info?.target || item.pdp_target) || 0;
          }
        });

        // Fetch machine population
        const popResponse = await getMachinePopulationByDealerInvestmentId(investment.id);
        const popData = extractArrayFromResponse(popResponse);
        
        popData.forEach(item => {
          const actual = calculateYtdActual(item);
          dealerData.population += actual;
        });
      } catch (err) {
        console.error(`Error fetching data for dealer ${dealerName}:`, err);
      }

      chartData.push(dealerData);
    }

    chartData.sort((a, b) => a.dealer.localeCompare(b.dealer));

    return { status: true, data: chartData };
  } catch (error) {
    console.error("Error fetching sales vehicles data:", error);
    return { status: false, data: [] };
  }
};

/**
 * Fetch Service Vehicles data
 */
export const fetchServiceVehiclesData = async (selectedYear) => {
  try {
    const investmentsResponse = await getAllDealerInvestments();
    const investments = extractArrayFromResponse(investmentsResponse);
    
    const yearInvestments = investments.filter(
      inv => String(inv.pdp_info?.year) === String(selectedYear)
    );

    if (yearInvestments.length === 0) {
      return { status: false, data: [] };
    }

    const chartData = [];

    for (const investment of yearInvestments) {
      const dealerName = getDealerShortName(investment);
      
      const dealerData = {
        dealer: dealerName,
        fourWheeler: 0,
        twoWheeler: 0,
        target: 0,
        population: 0
      };

      try {
        // Fetch vehicles data
        const vehiclesResponse = await getVehiclesByDealerInvestmentId(investment.id);
        const vehiclesData = extractArrayFromResponse(vehiclesResponse);
        
        vehiclesData.forEach(vehicle => {
          const { isService, isFourWheeler, isTwoWheeler } = classifyVehicleType(
            vehicle.vehicle_category || vehicle.category,
            vehicle.vehicle_type || vehicle.vehicleType
          );
          
          if (isService) {
            if (isFourWheeler) dealerData.fourWheeler += 1;
            else if (isTwoWheeler) dealerData.twoWheeler += 1;
            else dealerData.fourWheeler += 1; // Default to 4-wheeler
          }
        });

        // Fetch infrastructure for target
        const infraResponse = await getInfrastructureByDealerInvestmentId(investment.id);
        const infraData = extractArrayFromResponse(infraResponse);
        
        infraData.forEach(item => {
          const facilityType = (item.infrastructure_info?.facility_type || item.facility_type || "").toLowerCase();
          if (facilityType.includes("vehicle") && facilityType.includes("service")) {
            dealerData.target += parseInt(item.infrastructure_info?.target || item.pdp_target) || 0;
          }
        });

        // Fetch machine population
        const popResponse = await getMachinePopulationByDealerInvestmentId(investment.id);
        const popData = extractArrayFromResponse(popResponse);
        
        popData.forEach(item => {
          const actual = calculateYtdActual(item);
          dealerData.population += actual;
        });
      } catch (err) {
        console.error(`Error fetching data for dealer ${dealerName}:`, err);
      }

      chartData.push(dealerData);
    }

    chartData.sort((a, b) => a.dealer.localeCompare(b.dealer));

    return { status: true, data: chartData };
  } catch (error) {
    console.error("Error fetching service vehicles data:", error);
    return { status: false, data: [] };
  }
};

/**
 * Fetch Tools data
 */
export const fetchToolsData = async (selectedYear) => {
  try {
    const investmentsResponse = await getAllDealerInvestments();
    const investments = extractArrayFromResponse(investmentsResponse);
    
    const yearInvestments = investments.filter(
      inv => String(inv.pdp_info?.year) === String(selectedYear)
    );

    if (yearInvestments.length === 0) {
      return { status: false, data: [] };
    }

    const chartData = [];

    for (const investment of yearInvestments) {
      const dealerName = getDealerShortName(investment);
      
      const dealerData = {
        dealer: dealerName,
        specialTools: 0,
        target: 0,
        population: 0
      };

      try {
        // Fetch infrastructure data for tools
        const infraResponse = await getInfrastructureByDealerInvestmentId(investment.id);
        const infraData = extractArrayFromResponse(infraResponse);
        
        infraData.forEach(item => {
          const facilityType = (item.infrastructure_info?.facility_type || item.facility_type || "").toLowerCase();
          if (facilityType.includes("tool")) {
            const ytdActual = calculateYtdActual(item);
            dealerData.specialTools += ytdActual;
            dealerData.target += parseInt(item.infrastructure_info?.target || item.pdp_target) || 0;
          }
        });

        // Fetch machine population
        const popResponse = await getMachinePopulationByDealerInvestmentId(investment.id);
        const popData = extractArrayFromResponse(popResponse);
        
        popData.forEach(item => {
          const actual = calculateYtdActual(item);
          dealerData.population += actual;
        });
      } catch (err) {
        console.error(`Error fetching data for dealer ${dealerName}:`, err);
      }

      chartData.push(dealerData);
    }

    chartData.sort((a, b) => a.dealer.localeCompare(b.dealer));

    return { status: true, data: chartData };
  } catch (error) {
    console.error("Error fetching tools data:", error);
    return { status: false, data: [] };
  }
};

/**
 * Fetch CSR (CCL) data
 */
export const fetchCSRData = async (selectedYear) => {
  try {
    const investmentsResponse = await getAllDealerInvestments();
    const investments = extractArrayFromResponse(investmentsResponse);
    
    const yearInvestments = investments.filter(
      inv => String(inv.pdp_info?.year) === String(selectedYear)
    );

    if (yearInvestments.length === 0) {
      return { status: false, data: [] };
    }

    const chartData = [];

    for (const investment of yearInvestments) {
      const dealerName = getDealerShortName(investment);
      
      const dealerData = {
        dealer: dealerName,
        ccl0: 0,
        ccl1: 0,
        ccl2: 0,
        ccl3: 0,
        target: 0,
        population: 0
      };

      try {
        // Fetch competence data
        const compResponse = await getCompetenceByDealerInvestmentId(investment.id);
        const compData = extractArrayFromResponse(compResponse);
        
        compData.forEach(item => {
          const competenceName = item.competence_info?.competence_name || item.competence_name || "";
          const category = categorizeCompetence(competenceName);
          
          if (category && category.startsWith("ccl")) {
            const ytdActual = calculateYtdActual(item);
            
            if (Object.prototype.hasOwnProperty.call(dealerData, category)) {
              dealerData[category] += ytdActual;
            }
            dealerData.target += parseInt(item.competence_info?.target || item.pdp_target) || 0;
          }
        });

        // Fetch machine population
        const popResponse = await getMachinePopulationByDealerInvestmentId(investment.id);
        const popData = extractArrayFromResponse(popResponse);
        
        popData.forEach(item => {
          const actual = calculateYtdActual(item);
          dealerData.population += actual;
        });
      } catch (err) {
        console.error(`Error fetching data for dealer ${dealerName}:`, err);
      }

      chartData.push(dealerData);
    }

    chartData.sort((a, b) => a.dealer.localeCompare(b.dealer));

    return { status: true, data: chartData };
  } catch (error) {
    console.error("Error fetching CSR data:", error);
    return { status: false, data: [] };
  }
};

/**
 * Fetch SCL data
 */
export const fetchSCLData = async (selectedYear) => {
  try {
    const investmentsResponse = await getAllDealerInvestments();
    const investments = extractArrayFromResponse(investmentsResponse);
    
    const yearInvestments = investments.filter(
      inv => String(inv.pdp_info?.year) === String(selectedYear)
    );

    if (yearInvestments.length === 0) {
      return { status: false, data: [] };
    }

    const chartData = [];

    for (const investment of yearInvestments) {
      const dealerName = getDealerShortName(investment);
      
      const dealerData = {
        dealer: dealerName,
        scl0: 0,
        scl1: 0,
        scl1Pro: 0,
        scl2: 0,
        scl3: 0,
        target: 0,
        population: 0
      };

      try {
        // Fetch competence data
        const compResponse = await getCompetenceByDealerInvestmentId(investment.id);
        const compData = extractArrayFromResponse(compResponse);
        
        compData.forEach(item => {
          const competenceName = item.competence_info?.competence_name || item.competence_name || "";
          const category = categorizeCompetence(competenceName);
          
          if (category && category.startsWith("scl")) {
            const ytdActual = calculateYtdActual(item);
            
            if (Object.prototype.hasOwnProperty.call(dealerData, category)) {
              dealerData[category] += ytdActual;
            }
            dealerData.target += parseInt(item.competence_info?.target || item.pdp_target) || 0;
          }
        });

        // Fetch machine population
        const popResponse = await getMachinePopulationByDealerInvestmentId(investment.id);
        const popData = extractArrayFromResponse(popResponse);
        
        popData.forEach(item => {
          const actual = calculateYtdActual(item);
          dealerData.population += actual;
        });
      } catch (err) {
        console.error(`Error fetching data for dealer ${dealerName}:`, err);
      }

      chartData.push(dealerData);
    }

    chartData.sort((a, b) => a.dealer.localeCompare(b.dealer));

    return { status: true, data: chartData };
  } catch (error) {
    console.error("Error fetching SCL data:", error);
    return { status: false, data: [] };
  }
};

/**
 * Fetch TCL data
 */
export const fetchTCLData = async (selectedYear) => {
  try {
    const investmentsResponse = await getAllDealerInvestments();
    const investments = extractArrayFromResponse(investmentsResponse);
    
    const yearInvestments = investments.filter(
      inv => String(inv.pdp_info?.year) === String(selectedYear)
    );

    if (yearInvestments.length === 0) {
      return { status: false, data: [] };
    }

    const chartData = [];

    for (const investment of yearInvestments) {
      const dealerName = getDealerShortName(investment);
      
      const dealerData = {
        dealer: dealerName,
        tcl0: 0,
        tcl1: 0,
        tcl2: 0,
        tcl3: 0,
        tcl3Pro: 0,
        target: 0,
        population: 0
      };

      try {
        // Fetch competence data
        const compResponse = await getCompetenceByDealerInvestmentId(investment.id);
        const compData = extractArrayFromResponse(compResponse);
        
        compData.forEach(item => {
          const competenceName = item.competence_info?.competence_name || item.competence_name || "";
          const category = categorizeCompetence(competenceName);
          
          if (category && category.startsWith("tcl")) {
            const ytdActual = calculateYtdActual(item);
            
            if (Object.prototype.hasOwnProperty.call(dealerData, category)) {
              dealerData[category] += ytdActual;
            }
            dealerData.target += parseInt(item.competence_info?.target || item.pdp_target) || 0;
          }
        });

        // Fetch machine population
        const popResponse = await getMachinePopulationByDealerInvestmentId(investment.id);
        const popData = extractArrayFromResponse(popResponse);
        
        popData.forEach(item => {
          const actual = calculateYtdActual(item);
          dealerData.population += actual;
        });
      } catch (err) {
        console.error(`Error fetching data for dealer ${dealerName}:`, err);
      }

      chartData.push(dealerData);
    }

    chartData.sort((a, b) => a.dealer.localeCompare(b.dealer));

    return { status: true, data: chartData };
  } catch (error) {
    console.error("Error fetching TCL data:", error);
    return { status: false, data: [] };
  }
};