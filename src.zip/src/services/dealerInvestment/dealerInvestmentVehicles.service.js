/**
 * Dealer Investment Vehicles Service
 * Handles API calls for Vehicles tab in Infrastructure
 */

import axios from "axios";
import { API } from "../../api";

const { domain, dealerInvestmentVehiclesEndpoints } = API;

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Get auth headers with token
 */
const getAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// ============================================
// API FUNCTIONS
// ============================================

/**
 * Add a new dealer investment vehicle
 * @param {Object} vehicleData - Vehicle data to add
 */
export const addDealerInvestmentVehicle = async (vehicleData) => {
  try {
    const response = await axios.post(
      `${domain}${dealerInvestmentVehiclesEndpoints.addDealerInvestmentVehicle}`,
      vehicleData,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding dealer investment vehicle:", error);
    throw error;
  }
};

/**
 * Get all dealer investment vehicles
 */
export const getAllDealerInvestmentVehicles = async () => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentVehiclesEndpoints.getAllDealerInvestmentVehicles}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching all dealer investment vehicles:", error);
    throw error;
  }
};

/**
 * Get dealer investment vehicle by ID
 * @param {number} id - Vehicle ID
 */
export const getDealerInvestmentVehicleById = async (id) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentVehiclesEndpoints.getDealerInvestmentVehicleById}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching dealer investment vehicle by ID:", error);
    throw error;
  }
};

/**
 * Get dealer investment vehicles by Dealer Investment ID
 * This is the main function used in VehiclesList
 * @param {number} dealerInvestmentId - Dealer Investment ID
 */
export const getDealerInvestmentVehiclesByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentVehiclesEndpoints.getDealerInvestmentVehiclesByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching vehicles by dealer investment ID:", error);
    throw error;
  }
};

/**
 * Update dealer investment vehicle
 * @param {Object} vehicleData - Vehicle data with ID
 */
export const updateDealerInvestmentVehicle = async (vehicleData) => {
  try {
    const response = await axios.put(
      `${domain}${dealerInvestmentVehiclesEndpoints.updateDealerInvestmentVehicle}`,
      vehicleData,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating dealer investment vehicle:", error);
    throw error;
  }
};

/**
 * Delete dealer investment vehicle (soft delete)
 * @param {number} id - Vehicle ID
 */
export const deleteDealerInvestmentVehicle = async (id) => {
  try {
    const response = await axios.delete(
      `${domain}${dealerInvestmentVehiclesEndpoints.deleteDealerInvestmentVehicle}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting dealer investment vehicle:", error);
    throw error;
  }
};

// ============================================
// DATA TRANSFORMATION FUNCTIONS
// ============================================

/**
 * Transform API data to frontend format
 * @param {Array} apiData - Raw API data
 * @returns {Array} Transformed data for frontend
 */
export const transformVehiclesListData = (apiData) => {
  if (!apiData || !Array.isArray(apiData)) return [];

  return apiData.map((item) => ({
    id: item.id,
    dealerInvestmentId: item.dealer_investment_id,
    quarter: item.quarter || "Q1",
    category: item.vehicle_category || "",
    vehicleType: item.vehicle_type || "",
    brand: item.brand || "",
    registrationNumber: item.registration_number || "",
    yearOfPurchase: item.yop ? String(item.yop) : "",
    ageOfVehicle: item.yop ? String(new Date().getFullYear() - item.yop) : "",
    assigned: item.assigned_user_name || "",
    assignedUserId: item.assigned_user,
    location: item.location || "",
    remarks: item.remarks || "",
    isActive: item.isActive,
    createdAt: item.created_at,
    updatedAt: item.updated_at,
  }));
};

/**
 * Transform frontend data to API format for adding/updating
 * @param {Object} formData - Frontend form data
 * @param {number} dealerInvestmentId - Dealer Investment ID
 * @returns {Object} API formatted data
 */
export const transformToApiFormat = (formData, dealerInvestmentId) => {
  return {
    dealer_investment_id: dealerInvestmentId,
    assigned_user: formData.assignedUserId || formData.assigned_user || null,
    quarter: formData.quarter || "Q1",
    vehicle_category: formData.category || formData.vehicle_category,
    vehicle_type: formData.vehicleType || formData.vehicle_type,
    brand: formData.brand,
    registration_number: formData.registrationNumber || formData.registration_number,
    yop: formData.yearOfPurchase ? parseInt(formData.yearOfPurchase) : (formData.yop || null),
    location: formData.location || null,
    remarks: formData.remarks || null,
  };
};

/**
 * Get vehicle counts by quarter
 * @param {Array} vehicles - Array of vehicles
 * @returns {Object} Counts by quarter { Q1: 5, Q2: 3, Q3: 0, Q4: 2 }
 */
export const getVehicleCountsByQuarter = (vehicles) => {
  if (!vehicles || !Array.isArray(vehicles)) {
    return { Q1: 0, Q2: 0, Q3: 0, Q4: 0 };
  }

  const counts = { Q1: 0, Q2: 0, Q3: 0, Q4: 0 };

  vehicles.forEach((vehicle) => {
    const quarter = vehicle.quarter || "Q1";
    if (counts.hasOwnProperty(quarter)) {
      counts[quarter]++;
    }
  });

  return counts;
};

/**
 * Filter vehicles by quarter
 * @param {Array} vehicles - Array of vehicles
 * @param {string} quarter - Quarter to filter (Q1, Q2, Q3, Q4)
 * @returns {Array} Filtered vehicles
 */
export const filterVehiclesByQuarter = (vehicles, quarter) => {
  if (!vehicles || !Array.isArray(vehicles)) return [];
  return vehicles.filter((vehicle) => vehicle.quarter === quarter);
};