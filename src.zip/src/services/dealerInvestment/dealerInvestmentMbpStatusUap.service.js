/**
 * Dealer Investment MBP Status Service - Uptime & Parts (UAP)
 * Handles MBP submission, request edit, enable/disable operations for Uptime & Parts
 */

import axios from "axios";
import { API } from "../../api";

const { domain, dealerInvestmentEndpoints } = API;

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Get auth headers with token
 */
const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

/**
 * Handle token expiration
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ============================================
// MBP STATUS API FUNCTIONS - UPTIME & PARTS
// ============================================

/**
 * Update MBP Status for Uptime & Parts (UAP)
 * @param {number} dealerInvestmentId - The dealer investment ID
 * @param {string} status - Status value: "Submitted" | "Requested" | "Disabled" | "Enable"
 * @returns {Promise<Object>} API response
 */
export const updateMbpStatusUap = async (dealerInvestmentId, status) => {
  try {
    const response = await axios.put(
      `${domain}${dealerInvestmentEndpoints.mbpStatusUapChange}`,
      {
        id: dealerInvestmentId,
        status: status,
      },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error updating MBP status for UAP:", error);
    throw error;
  }
};

// ============================================
// CONVENIENCE FUNCTIONS
// ============================================

/**
 * Submit MBP for Uptime & Parts (Dealer action)
 * Sets status to "Submitted" - dealer can no longer edit
 * @param {number} dealerInvestmentId 
 */
export const submitMbpUap = async (dealerInvestmentId) => {
  return await updateMbpStatusUap(dealerInvestmentId, "Submitted");
};

/**
 * Request MBP Edit for Uptime & Parts (Dealer action after submission)
 * Sets status to "Requested" - notifies admin that dealer wants to edit
 * @param {number} dealerInvestmentId 
 */
export const requestMbpEditUap = async (dealerInvestmentId) => {
  return await updateMbpStatusUap(dealerInvestmentId, "Requested");
};

/**
 * Enable MBP for Uptime & Parts (Admin action)
 * Sets status to "Enable" - allows dealer to edit MBP values
 * @param {number} dealerInvestmentId 
 */
export const enableMbpUap = async (dealerInvestmentId) => {
  return await updateMbpStatusUap(dealerInvestmentId, "Enable");
};

/**
 * Disable MBP for Uptime & Parts (Admin action)
 * Sets status to "Disabled" (actually "Submitted") - prevents dealer from editing
 * @param {number} dealerInvestmentId 
 */
export const disableMbpUap = async (dealerInvestmentId) => {
  return await updateMbpStatusUap(dealerInvestmentId, "Disabled");
};

/**
 * Get MBP status info from dealer investment data
 * @param {string} mbpStatusUap - Status from API
 * @returns {Object} { mbpSubmitted, mbpEnabled, mbpRequested }
 */
export const parseMbpStatusUap = (mbpStatusUap) => {
  return {
    mbpSubmitted: mbpStatusUap === "Submitted" || mbpStatusUap === "Requested",
    mbpEnabled: mbpStatusUap === "Enable",
    mbpRequested: mbpStatusUap === "Requested",
  };
};

