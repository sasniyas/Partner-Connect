import axios from "axios";
import { API } from "../../api";

const BASE_URL = API.domain;

// ============================================
// AUTHENTICATION HELPER
// ============================================

const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================

const cleanString = (str) => {
  if (!str) return "";
  return str.replace(/\t/g, "").replace(/\s+/g, " ").trim();
};

/**
 * Month name to field mapping for Allocation API (short form)
 */
const MONTH_FIELD_MAP = {
  January: "jan",
  February: "feb",
  March: "mar",
  April: "apr",
  May: "may",
  June: "jun",
  July: "jul",
  August: "aug",
  September: "sep",
  October: "oct",
  November: "nov",
  December: "decem",
};

/**
 * Month name to inventory field prefix (full month name lowercase)
 */
const MONTH_INVENTORY_MAP = {
  January: "january",
  February: "february",
  March: "march",
  April: "april",
  May: "may",
  June: "june",
  July: "july",
  August: "august",
  September: "september",
  October: "october",
  November: "november",
  December: "december",
};

export const getMonthField = (monthName) => {
  return MONTH_FIELD_MAP[monthName] || "jan";
};

export const getInventoryMonthPrefix = (monthName) => {
  return MONTH_INVENTORY_MAP[monthName] || "january";
};

export const getMonthNames = () => [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

export const getCurrentMonthName = () => {
  return new Date().toLocaleString("default", { month: "long" });
};

// ============================================
// ALLOCATION API FUNCTIONS
// ============================================

export const getDealerInvestmentAllocationByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${API.dealerInvestmentAllocationEndpoints.getDealerInvestmentAllocationByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching dealer investment allocations:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

export const updateMultipleDealerInvestmentAllocation = async (rows) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${API.dealerInvestmentAllocationEndpoints.updateMultipleDealerInvestmentAllocation}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error updating dealer investment allocations:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

// ============================================
// PROJECTION API FUNCTIONS
// ============================================

export const getDealerInvestmentEquipmentProjectionByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${API.dealerInvestmentEquipmentProjectionEndpoints.getDealerInvestmentEquipmentProjectionByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching projections:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

// ============================================
// INVENTORY API FUNCTIONS
// ============================================

export const getAllInventoryDataAllocations = async (year) => {
  try {
    const url = year 
      ? `${BASE_URL}${API.inventoryAllocationEndpoints.getAllInventoryDataAllocations}?year=${year}`
      : `${BASE_URL}${API.inventoryAllocationEndpoints.getAllInventoryDataAllocations}`;
    
    const response = await axios.get(url, { headers: getAuthHeaders() });
    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("Error fetching inventory data:", error);
    throw error.response?.data || { status: false, message: error.message };
  }
};

// ============================================
// DATA TRANSFORMATION
// ============================================

/**
 * Transform Allocation API data for table display
 * Includes all monthly data
 */
export const transformAllocationDataForTable = (rawData) => {
  if (!rawData || !Array.isArray(rawData)) return [];

  return rawData.map((item) => ({
    id: item.id,
    equipmentId: item.equipmentId, // This is the key for matching
    dealerInvestmentId: item.dealerInvestmentId,
    // Equipment info - cleaned
    equipmentMake: cleanString(item.equipment_info?.equipment_make) || "-",
    equipmentType: cleanString(item.equipment_info?.equipment_type) || "-",
    equipmentModel: cleanString(item.equipment_info?.equipment_model) || "-",
    equipmentLine: cleanString(item.equipment_info?.equipment_line) || "-",
    equipmentYear: item.equipment_info?.year || "-",
    // Master equipment ID for matching with projection/inventory
    equipmentMasterId: item.equipment_info?.equipment_id || item.equipmentId,
    // All monthly allocation values
    allocation_jan: item.jan,
    allocation_feb: item.feb,
    allocation_mar: item.mar,
    allocation_apr: item.apr,
    allocation_may: item.may,
    allocation_jun: item.jun,
    allocation_jul: item.jul,
    allocation_aug: item.aug,
    allocation_sep: item.sep,
    allocation_oct: item.oct,
    allocation_nov: item.nov,
    allocation_decem: item.decem,
    // Dealer info
    dealerName: cleanString(item.dealer_info?.dealer_name) || "-",
    dealerShortName: cleanString(item.dealer_info?.dealer_short_name) || "-",
    marketAreaName: cleanString(item.dealer_info?.market_area_name) || "-",
    // PDP info
    pdpYear: item.pdp_info?.year || "-",
  }));
};

/**
 * Transform Projection data - SUM Retail + Key Account for same equipment
 * Groups by equipment_info.equipment_id and sums values
 */
export const transformProjectionData = (rawData) => {
  if (!rawData || !Array.isArray(rawData)) return {};

  const projectionMap = {};
  const months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'decem'];
  
  rawData.forEach((item) => {
    // Get equipment ID from equipment_info.equipment_id OR pdp_equipment_info.equipmentMasterId
    const equipmentId = item.equipment_info?.equipment_id || 
                        item.pdp_equipment_info?.equipmentMasterId ||
                        item.equipmentId;
    
    if (!equipmentId) {
      console.warn("No equipment ID found in projection item:", item);
      return;
    }

    // Initialize if not exists
    if (!projectionMap[equipmentId]) {
      projectionMap[equipmentId] = {};
      months.forEach((month) => {
        projectionMap[equipmentId][month] = 0;
      });
    }

    // Add values for each month (Retail + Key Account will be summed)
    months.forEach((month) => {
      const value = parseInt(item[month]) || 0;
      projectionMap[equipmentId][month] += value;
    });

    console.log(`📊 Projection for Equipment ${equipmentId} (${item.category}):`, 
      months.reduce((acc, m) => ({ ...acc, [m]: item[m] }), {}));
  });

  console.log("✅ Final Projection Map:", projectionMap);
  return projectionMap;
};

/**
 * Transform Inventory data - stores all months
 * Uses equipment_id for matching
 * Field format: january_open_stock, january_arrivals, january_closing_stock
 */
export const transformInventoryData = (rawData) => {
  if (!rawData || !Array.isArray(rawData)) return {};

  const inventoryMap = {};
  const monthPrefixes = [
    'january', 'february', 'march', 'april', 'may', 'june',
    'july', 'august', 'september', 'october', 'november', 'december'
  ];

  rawData.forEach((item) => {
    const equipmentId = item.equipment_id;
    if (!equipmentId) {
      console.warn("No equipment_id found in inventory item:", item);
      return;
    }

    const inventory = {};
    
    monthPrefixes.forEach((monthPrefix) => {
      // Field names: january_open_stock, january_arrivals, january_closing_stock
      inventory[`openStock_${monthPrefix}`] = item[`${monthPrefix}_open_stock`] ?? null;
      inventory[`arrivals_${monthPrefix}`] = item[`${monthPrefix}_arrivals`] ?? null;
      inventory[`closeStock_${monthPrefix}`] = item[`${monthPrefix}_closing_stock`] ?? null;
    });

    inventoryMap[equipmentId] = inventory;
    
    console.log(`📦 Inventory for Equipment ${equipmentId}:`, {
      january_open_stock: item.january_open_stock,
      january_arrivals: item.january_arrivals,
      january_closing_stock: item.january_closing_stock,
    });
  });

  console.log("✅ Final Inventory Map:", inventoryMap);
  return inventoryMap;
};

/**
 * Merge all data and get values for specific month
 * Matches by equipmentMasterId (equipment_info.equipment_id)
 */
export const mergeAllocationData = (allocationData, projectionMap, inventoryMap, monthField, monthName) => {
  // Get inventory month prefix (full name: january, february, etc.)
  const inventoryMonthPrefix = getInventoryMonthPrefix(monthName);
  
  console.log("🔄 Merging data for month:", monthName, "Field:", monthField, "Inventory prefix:", inventoryMonthPrefix);

  return allocationData.map((item) => {
    // Use equipmentMasterId for matching (this is equipment_info.equipment_id)
    const matchId = item.equipmentMasterId || item.equipmentId;
    
    const projection = projectionMap[matchId] || {};
    const inventory = inventoryMap[matchId] || {};

    // Debug logging
    if (Object.keys(projectionMap).length > 0 || Object.keys(inventoryMap).length > 0) {
      console.log(`🔍 Matching Equipment ID ${matchId}:`, {
        projectionFound: !!projectionMap[matchId],
        inventoryFound: !!inventoryMap[matchId],
        projectionValue: projection[monthField],
        openStock: inventory[`openStock_${inventoryMonthPrefix}`],
        arrivals: inventory[`arrivals_${inventoryMonthPrefix}`],
        closeStock: inventory[`closeStock_${inventoryMonthPrefix}`],
      });
    }

    return {
      ...item,
      // Current month allocation value
      allocation: item[`allocation_${monthField}`] ?? null,
      // Projection value for current month (Retail + KAM summed)
      projection: projection[monthField] ?? null,
      // Inventory values using full month name prefix
      openStock: inventory[`openStock_${inventoryMonthPrefix}`] ?? null,
      arrivals: inventory[`arrivals_${inventoryMonthPrefix}`] ?? null,
      closeStock: inventory[`closeStock_${inventoryMonthPrefix}`] ?? null,
    };
  });
};

/**
 * Get unique equipment makes from data
 */
export const getUniqueEquipmentMakes = (data) => {
  const makes = [...new Set(data.map((item) => item.equipmentMake).filter(Boolean))];
  return makes.filter((m) => m !== "-").sort();
};

/**
 * Get unique equipment types from data
 */
export const getUniqueEquipmentTypes = (data, selectedMake = null) => {
  let filtered = data;
  if (selectedMake && selectedMake.length > 0) {
    filtered = data.filter((item) => selectedMake.includes(item.equipmentMake));
  }
  const types = [...new Set(filtered.map((item) => item.equipmentType).filter(Boolean))];
  return types.filter((t) => t !== "-").sort();
};

/**
 * Get unique equipment models from data
 */
export const getUniqueEquipmentModels = (data, selectedMake = null, selectedType = null) => {
  let filtered = data;
  if (selectedMake && selectedMake.length > 0) {
    filtered = filtered.filter((item) => selectedMake.includes(item.equipmentMake));
  }
  if (selectedType && selectedType.length > 0) {
    filtered = filtered.filter((item) => selectedType.includes(item.equipmentType));
  }
  const models = [...new Set(filtered.map((item) => item.equipmentModel).filter(Boolean))];
  return models.filter((m) => m !== "-").sort();
};