/**
 * Dealer Investment Infrastructure Service
 * Handles API calls and data transformation for Infrastructure tabs
 * (Facility, Competence, Vehicles, Machine & Population, Tools)
 */

import axios from "axios";
import { API } from "../../api";

const { domain, dealerInvestmentInfrastructureEndpoints } = API;

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Get auth headers with token
 */
const getAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// ============================================
// FACILITY TYPES MAPPING (from API)
// ============================================

// Types that go to Vehicles Tab
export const VEHICLES_TAB_TYPES = ["Vehicles"];

// Types that go to Tools Tab
export const TOOLS_TAB_TYPES = ["Tools", "Accessories"];

// Facility Tab gets EVERYTHING ELSE (not Vehicles, Tools, or Accessories)

// Legacy constant for backwards compatibility
export const FACILITY_TYPES = {
  VEHICLES: "Vehicles",
  TOOLS: "Tools",
  ACCESSORIES: "Accessories",
};

// ============================================
// API FUNCTIONS
// ============================================

/**
 * Get all dealer investment infrastructure records
 */
export const getAllDealerInvestmentInfrastructure = async (filters = {}) => {
  try {
    const params = new URLSearchParams();
    if (filters.pdpId) params.append("pdpId", filters.pdpId);
    if (filters.dealerInvestmentId) params.append("dealerInvestmentId", filters.dealerInvestmentId);
    if (filters.pdpInfrastructureId) params.append("pdpInfrastructureId", filters.pdpInfrastructureId);

    const queryString = params.toString() ? `?${params.toString()}` : "";
    const response = await axios.get(
      `${domain}${dealerInvestmentInfrastructureEndpoints.getAllDealerInvestmentInfrastructure}${queryString}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching dealer investment infrastructure:", error);
    throw error;
  }
};

/**
 * Get dealer investment infrastructure by ID
 */
export const getDealerInvestmentInfrastructureById = async (id) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentInfrastructureEndpoints.getDealerInvestmentInfrastructureById}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching dealer investment infrastructure by ID:", error);
    throw error;
  }
};

/**
 * Get dealer investment infrastructure by Dealer Investment ID
 * This is the main function used in Fill Entries
 */
export const getDealerInvestmentInfrastructureByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentInfrastructureEndpoints.getDealerInvestmentInfrastructureByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching infrastructure by dealer investment ID:", error);
    throw error;
  }
};

/**
 * Get dealer investment infrastructure by PDP ID
 */
export const getDealerInvestmentInfrastructureByPdpId = async (pdpId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentInfrastructureEndpoints.getDealerInvestmentInfrastructureByPdpId}${pdpId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching infrastructure by PDP ID:", error);
    throw error;
  }
};

/**
 * Update single dealer investment infrastructure record
 */
export const updateDealerInvestmentInfrastructure = async (data) => {
  try {
    const response = await axios.put(
      `${domain}${dealerInvestmentInfrastructureEndpoints.updateDealerInvestmentInfrastructure}`,
      data,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating dealer investment infrastructure:", error);
    throw error;
  }
};

/**
 * Update multiple dealer investment infrastructure records
 */
export const updateMultipleDealerInvestmentInfrastructure = async (rows) => {
  try {
    console.log("Sending rows to API:", rows);
    
    const response = await axios.put(
      `${domain}${dealerInvestmentInfrastructureEndpoints.updateMultipleDealerInvestmentInfrastructure}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating multiple dealer investment infrastructure:", error);
    console.error("Error response:", error.response?.data);
    throw error;
  }
};

/**
 * Delete dealer investment infrastructure record (soft delete)
 */
export const deleteDealerInvestmentInfrastructure = async (id) => {
  try {
    const response = await axios.delete(
      `${domain}${dealerInvestmentInfrastructureEndpoints.deleteDealerInvestmentInfrastructure}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting dealer investment infrastructure:", error);
    throw error;
  }
};

// ============================================
// DATA TRANSFORMATION FUNCTIONS
// ============================================

/**
 * Filter infrastructure data by facility type
 * @param {Array} data - Raw API data
 * @param {String|Array} facilityTypes - Type(s) to filter
 * @returns {Array} Filtered data
 */
export const filterByFacilityType = (data, facilityTypes) => {
  if (!data || !Array.isArray(data)) return [];
  
  // Convert to array if single string
  const typesArray = Array.isArray(facilityTypes) ? facilityTypes : [facilityTypes];
  
  return data.filter((item) => {
    const itemType = item.infrastructure_info?.facility_type?.trim()?.toUpperCase();
    return typesArray.some(type => itemType === type.trim().toUpperCase());
  });
};

/**
 * Filter data for Facility tab (EVERYTHING except Vehicles, Tools, Accessories)
 */
export const filterFacilityData = (data) => {
  if (!data || !Array.isArray(data)) return [];
  
  // Exclude types that belong to other tabs
  const excludeTypes = [...VEHICLES_TAB_TYPES, ...TOOLS_TAB_TYPES].map(t => t.toUpperCase());
  
  return data.filter((item) => {
    const itemType = item.infrastructure_info?.facility_type?.trim()?.toUpperCase();
    return itemType && !excludeTypes.includes(itemType);
  });
};

/**
 * Filter data for Vehicles tab (only "Vehicles" type)
 */
export const filterVehiclesData = (data) => {
  return filterByFacilityType(data, VEHICLES_TAB_TYPES);
};

/**
 * Filter data for Tools tab (only "Tools" and "Accessories" types)
 */
export const filterToolsAndAccessoriesData = (data) => {
  return filterByFacilityType(data, TOOLS_TAB_TYPES);
};

/**
 * Transform API data for Facility tab
 * Groups by facility_type and extracts Q1-Q4 values
 * Includes: 1S Facility, 2S Facility, 3S Facility, Touch Point (Sales), Touch Point (Service)
 */
export const transformFacilityData = (apiData) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return { tableData: {}, pdpTargets: {} };
  }

  // Filter facility types for Facility tab
  const facilityData = filterFacilityData(apiData);

  const tableData = {};
  const pdpTargets = {};

  facilityData.forEach((item) => {
    // Use facility_type as the row name (e.g., "1S Facility", "2S Facility")
    const facilityType = item.infrastructure_info?.facility_type?.trim() || "Unknown";
    const target = item.infrastructure_info?.target || 0;

    tableData[facilityType] = {
      id: item.id,
      Q1: item.q1 !== null ? String(item.q1) : "",
      Q2: item.q2 !== null ? String(item.q2) : "",
      Q3: item.q3 !== null ? String(item.q3) : "",
      Q4: item.q4 !== null ? String(item.q4) : "",
      ytdActual: item.ytd_actual !== null ? String(item.ytd_actual) : "",
      pdpTarget: String(target),
      pdpInfrastructureId: item.pdpInfrastructureId,
      dealerInvestmentId: item.dealerInvestmentId,
      facilityDefinition: item.infrastructure_info?.facility_definition?.trim() || "",
    };

    pdpTargets[facilityType] = String(target);
  });

  return { tableData, pdpTargets };
};

/**
 * Transform API data for Vehicles tab
 * Uses facility_definition as row name
 */
export const transformVehiclesData = (apiData) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return { tableData: {}, pdpTargets: {} };
  }

  // Filter Vehicles type
  const vehicleData = filterVehiclesData(apiData);

  const tableData = {};
  const pdpTargets = {};

  vehicleData.forEach((item) => {
    // Use facility_definition as row name (e.g., "Service Vehicles - 4-Wheeler")
    const vehicleName = item.infrastructure_info?.facility_definition?.trim() || "Unknown";
    const target = item.infrastructure_info?.target || 0;

    tableData[vehicleName] = {
      id: item.id,
      Q1: item.q1 !== null ? String(item.q1) : "",
      Q2: item.q2 !== null ? String(item.q2) : "",
      Q3: item.q3 !== null ? String(item.q3) : "",
      Q4: item.q4 !== null ? String(item.q4) : "",
      ytdActual: item.ytd_actual !== null ? String(item.ytd_actual) : "",
      pdpTarget: String(target),
      pdpInfrastructureId: item.pdpInfrastructureId,
      dealerInvestmentId: item.dealerInvestmentId,
    };

    pdpTargets[vehicleName] = String(target);
  });

  return { tableData, pdpTargets };
};

/**
 * Transform API data for Tools tab
 * Separates into Tools and Accessories based on facility_type
 */
export const transformToolsData = (apiData) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return { toolsData: {}, accessoriesData: {}, pdpTargets: {} };
  }

  // Filter Tools type specifically
  const toolsRaw = filterByFacilityType(apiData, ["Tools"]);
  // Filter Accessories type
  const accessoriesRaw = filterByFacilityType(apiData, ["Accessories"]);

  const toolsData = {};
  const accessoriesData = {};
  const pdpTargets = {};

  // Transform Tools
  toolsRaw.forEach((item) => {
    const toolName = item.infrastructure_info?.facility_definition?.trim() || "Unknown";
    const target = item.infrastructure_info?.target || 0;

    toolsData[toolName] = {
      id: item.id,
      Q1: item.q1 !== null ? String(item.q1) : "",
      Q2: item.q2 !== null ? String(item.q2) : "",
      Q3: item.q3 !== null ? String(item.q3) : "",
      Q4: item.q4 !== null ? String(item.q4) : "",
      actual: item.ytd_actual !== null ? String(item.ytd_actual) : "",
      pdpTarget: String(target),
      pdpInfrastructureId: item.pdpInfrastructureId,
      dealerInvestmentId: item.dealerInvestmentId,
    };

    pdpTargets[toolName] = String(target);
  });

  // Transform Accessories
  accessoriesRaw.forEach((item) => {
    const accessoryName = item.infrastructure_info?.facility_definition?.trim() || "Unknown";
    const target = item.infrastructure_info?.target || 0;

    accessoriesData[accessoryName] = {
      id: item.id,
      Q1: item.q1 !== null ? String(item.q1) : "",
      Q2: item.q2 !== null ? String(item.q2) : "",
      Q3: item.q3 !== null ? String(item.q3) : "",
      Q4: item.q4 !== null ? String(item.q4) : "",
      actual: item.ytd_actual !== null ? String(item.ytd_actual) : "",
      pdpTarget: String(target),
      pdpInfrastructureId: item.pdpInfrastructureId,
      dealerInvestmentId: item.dealerInvestmentId,
    };

    pdpTargets[accessoryName] = String(target);
  });

  return { toolsData, accessoriesData, pdpTargets };
};

/**
 * Transform API data for Competence tab
 * Note: Currently no specific facility_type for Competence in API
 * This will return empty unless data structure changes
 */
export const transformCompetenceData = (apiData) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return { tableData: {}, pdpTargets: {} };
  }

  // Filter for Competence type (if exists)
  const competenceData = filterByFacilityType(apiData, ["Competence"]);

  const tableData = {};
  const pdpTargets = {};

  competenceData.forEach((item) => {
    const competenceName = item.infrastructure_info?.facility_definition?.trim() || "Unknown";
    const target = item.infrastructure_info?.target || 0;

    tableData[competenceName] = {
      id: item.id,
      Q1: item.q1 !== null ? String(item.q1) : "",
      Q2: item.q2 !== null ? String(item.q2) : "",
      Q3: item.q3 !== null ? String(item.q3) : "",
      Q4: item.q4 !== null ? String(item.q4) : "",
      ytdActual: item.ytd_actual !== null ? String(item.ytd_actual) : "",
      pdpTarget: String(target),
      pdpInfrastructureId: item.pdpInfrastructureId,
      dealerInvestmentId: item.dealerInvestmentId,
    };

    pdpTargets[competenceName] = String(target);
  });

  return { tableData, pdpTargets };
};

/**
 * Transform API data for Machine & Population tab
 * Note: Currently no specific facility_type for Machine Population in API
 * This will return empty unless data structure changes
 */
export const transformMachinePopulationData = (apiData) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return { tableData: {}, pdpTargets: {} };
  }

  // Filter for Machine Population type (if exists)
  const machineData = filterByFacilityType(apiData, ["Machine Population", "Machine & Population"]);

  const tableData = {};
  const pdpTargets = {};

  machineData.forEach((item) => {
    const machineName = item.infrastructure_info?.facility_definition?.trim() || "Unknown";
    const target = item.infrastructure_info?.target || 0;

    tableData[machineName] = {
      id: item.id,
      Q1: item.q1 !== null ? String(item.q1) : "",
      Q2: item.q2 !== null ? String(item.q2) : "",
      Q3: item.q3 !== null ? String(item.q3) : "",
      Q4: item.q4 !== null ? String(item.q4) : "",
      ytdActual: item.ytd_actual !== null ? String(item.ytd_actual) : "",
      pdpTarget: String(target),
      pdpInfrastructureId: item.pdpInfrastructureId,
      dealerInvestmentId: item.dealerInvestmentId,
    };

    pdpTargets[machineName] = String(target);
  });

  return { tableData, pdpTargets };
};

// ============================================
// PREPARE DATA FOR API UPDATE
// ============================================

/**
 * Transform table data back to API format for update
 * @param {Object} tableData - Table data object keyed by row name
 * @returns {Array} Array of row objects for API
 */
export const prepareDataForUpdate = (tableData) => {
  if (!tableData || typeof tableData !== "object") return [];

  const rows = Object.entries(tableData).map(([name, data]) => {
    // Calculate YTD from Q values
    const q1Val = data.Q1 !== "" && data.Q1 !== null && data.Q1 !== undefined ? Number(data.Q1) : null;
    const q2Val = data.Q2 !== "" && data.Q2 !== null && data.Q2 !== undefined ? Number(data.Q2) : null;
    const q3Val = data.Q3 !== "" && data.Q3 !== null && data.Q3 !== undefined ? Number(data.Q3) : null;
    const q4Val = data.Q4 !== "" && data.Q4 !== null && data.Q4 !== undefined ? Number(data.Q4) : null;
    
    // Calculate YTD actual as sum of quarters
    const ytdActual = (q1Val || 0) + (q2Val || 0) + (q3Val || 0) + (q4Val || 0);
    
    return {
      id: data.id,
      q1: q1Val,
      q2: q2Val,
      q3: q3Val,
      q4: q4Val,
      ytd_actual: ytdActual > 0 ? ytdActual : null,
    };
  });

  console.log("Prepared rows for update:", rows);
  return rows;
};

/**
 * Calculate YTD Actual from quarterly values
 */
export const calculateYTDActual = (data) => {
  const q1 = parseInt(data.Q1) || 0;
  const q2 = parseInt(data.Q2) || 0;
  const q3 = parseInt(data.Q3) || 0;
  const q4 = parseInt(data.Q4) || 0;
  return q1 + q2 + q3 + q4;
};

/**
 * Calculate Achievement percentage
 */
export const calculateAchievement = (ytdActual, pdpTarget) => {
  const actual = parseInt(ytdActual) || 0;
  const target = parseInt(pdpTarget) || 1;
  return target > 0 ? ((actual / target) * 100).toFixed(2) : 0;
};

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Get unique facility types from data
 */
export const getUniqueFacilityTypes = (data) => {
  if (!data || !Array.isArray(data)) return [];
  const types = new Set(
    data.map((item) => item.infrastructure_info?.facility_type).filter(Boolean)
  );
  return Array.from(types);
};

/**
 * Check if data exists for a specific facility type
 */
export const hasDataForFacilityType = (data, facilityType) => {
  if (!data || !Array.isArray(data)) return false;
  return data.some(
    (item) => item.infrastructure_info?.facility_type?.toLowerCase() === facilityType.toLowerCase()
  );
};

