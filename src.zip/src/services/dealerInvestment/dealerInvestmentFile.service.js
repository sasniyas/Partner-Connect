/**
 * Dealer Investment File Service
 * Handles API calls for file upload/download in Dealer Investment module
 */

import axios from "axios";
import { API } from "../../api";

const { domain } = API;

// Use endpoints from API if available, otherwise use defaults
const dealerInvestmentFileEndpoints = API.dealerInvestmentFileEndpoints || {
  addDealerInvestmentFile: "/addDealerInvestmentFile",
  getAllDealerInvestmentFiles: "/getAllDealerInvestmentFiles",
  getDealerInvestmentFileById: "/getDealerInvestmentFileById/",
  getDealerInvestmentFilesByDealerInvestmentId: "/getDealerInvestmentFilesByDealerInvestmentId/",
  updateDealerInvestmentFile: "/updateDealerInvestmentFile",
  deleteDealerInvestmentFile: "/deleteDealerInvestmentFile/",
};

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Get auth headers with token
 */
const getAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

/**
 * Get auth headers for multipart form data
 * NOTE: Do NOT set Content-Type for FormData - axios sets it automatically with boundary
 */
const getMultipartAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// ============================================
// API FUNCTIONS
// ============================================

/**
 * Add a new dealer investment file
 * @param {number} dealerInvestmentId - Dealer Investment ID
 * @param {File} file - File object to upload
 * @param {string} type - File type (e.g., "Facility", "Competence", etc.)
 * @param {string} category - Category ("Infrastructure" or "Monthly Business Plan")
 */
export const addDealerInvestmentFile = async (dealerInvestmentId, file, type, category) => {
  try {
    const formData = new FormData();
    formData.append("dealer_investment_id", dealerInvestmentId);
    formData.append("file", file);
    formData.append("type", type || "");
    formData.append("category", category || "");

    // Debug: Log what we're sending
    console.log("Uploading file with data:", {
      dealer_investment_id: dealerInvestmentId,
      fileName: file?.name,
      fileSize: file?.size,
      fileType: file?.type,
      type: type,
      category: category
    });

    const response = await axios.post(
      `${domain}${dealerInvestmentFileEndpoints.addDealerInvestmentFile}`,
      formData,
      { headers: getMultipartAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding dealer investment file:", error);
    console.error("Error response data:", error.response?.data);
    throw error;
  }
};

/**
 * Get all dealer investment files
 */
export const getAllDealerInvestmentFiles = async () => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentFileEndpoints.getAllDealerInvestmentFiles}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching all dealer investment files:", error);
    throw error;
  }
};

/**
 * Get dealer investment file by ID
 * @param {number} id - File ID
 */
export const getDealerInvestmentFileById = async (id) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentFileEndpoints.getDealerInvestmentFileById}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching dealer investment file by ID:", error);
    throw error;
  }
};

/**
 * Get dealer investment files by Dealer Investment ID
 * @param {number} dealerInvestmentId - Dealer Investment ID
 */
export const getDealerInvestmentFilesByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentFileEndpoints.getDealerInvestmentFilesByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching files by dealer investment ID:", error);
    throw error;
  }
};

/**
 * Update dealer investment file
 * @param {number} id - File ID
 * @param {Object} updateData - Data to update (type, category, isActive)
 * @param {File} file - Optional new file to upload
 */
export const updateDealerInvestmentFile = async (id, updateData, file = null) => {
  try {
    const formData = new FormData();
    formData.append("id", id);
    
    if (updateData.type !== undefined) {
      formData.append("type", updateData.type);
    }
    if (updateData.category !== undefined) {
      formData.append("category", updateData.category);
    }
    if (updateData.isActive !== undefined) {
      formData.append("isActive", updateData.isActive);
    }
    if (file) {
      formData.append("file", file);
    }

    const response = await axios.put(
      `${domain}${dealerInvestmentFileEndpoints.updateDealerInvestmentFile}`,
      formData,
      { headers: getMultipartAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating dealer investment file:", error);
    throw error;
  }
};

/**
 * Delete dealer investment file (soft delete)
 * @param {number} id - File ID
 */
export const deleteDealerInvestmentFile = async (id) => {
  try {
    const response = await axios.delete(
      `${domain}${dealerInvestmentFileEndpoints.deleteDealerInvestmentFile}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting dealer investment file:", error);
    throw error;
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Determine category based on active sub tab
 * @param {string} activeSubTab - Current active sub tab
 * @returns {string} - "Infrastructure" or "Monthly Business Plan"
 */
export const getCategoryFromSubTab = (activeSubTab) => {
  const infrastructureTabs = ["Facility", "Competence", "Vehicles", "Machine & Population", "Tools"];
  const monthlyBusinessPlanTabs = ["Equipments & Attachments", "Uptime & Parts", "Allocation"];
  
  if (infrastructureTabs.includes(activeSubTab)) {
    return "Infrastructure";
  } else if (monthlyBusinessPlanTabs.includes(activeSubTab)) {
    return "Monthly Business Plan";
  }
  return "Infrastructure"; // Default
};

/**
 * Transform API data to table format
 * @param {Array} apiData - Data from API
 * @returns {Array} - Transformed data for table
 */
export const transformFilesToTableData = (apiData) => {
  if (!apiData || !Array.isArray(apiData)) return [];
  
  return apiData.map((item) => ({
    id: item.id,
    fileName: extractFileName(item.file),
    fileUrl: item.file,
    type: item.type,
    category: item.category,
    createdAt: item.created_at,
    updatedAt: item.updated_at,
  }));
};

/**
 * Extract file name from URL
 * @param {string} fileUrl - Full file URL
 * @returns {string} - File name
 */
export const extractFileName = (fileUrl) => {
  if (!fileUrl) return "Unknown";
  
  // Handle Azure blob storage URLs or regular URLs
  const parts = fileUrl.split("/");
  let fileName = parts[parts.length - 1];
  
  // Remove query parameters if present
  if (fileName.includes("?")) {
    fileName = fileName.split("?")[0];
  }
  
  // Decode URL encoding
  try {
    fileName = decodeURIComponent(fileName);
  } catch (e) {
    // If decoding fails, use as is
  }
  
  return fileName;
};

/**
 * Filter files by type (sub tab)
 * @param {Array} files - All files
 * @param {string} type - Type to filter by
 * @returns {Array} - Filtered files
 */
export const filterFilesByType = (files, type) => {
  if (!files || !Array.isArray(files)) return [];
  if (!type) return files;
  
  return files.filter((file) => file.type === type);
};

/**
 * Filter files by category
 * @param {Array} files - All files
 * @param {string} category - Category to filter by
 * @returns {Array} - Filtered files
 */
export const filterFilesByCategory = (files, category) => {
  if (!files || !Array.isArray(files)) return [];
  if (!category) return files;
  
  return files.filter((file) => file.category === category);
};