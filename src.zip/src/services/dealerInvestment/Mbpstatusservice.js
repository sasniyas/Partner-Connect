/**
 * MBP Status Service - FIXED VERSION WITH API URL DEBUGGING
 * Properly handles API domain configuration
 * 
 * Location: src/services/dealerInvestment/mbpStatusservice.js
 */

import axios from "axios";
import { API } from "../../api";

const { domain, dealerInvestmentEndpoints } = API;

console.log("🔧 API Configuration:", { domain, dealerInvestmentEndpoints });

// ============================================
// MBP STATUS CONSTANTS
// ============================================
export const MBP_STATUS = {
  ENABLED: "Enable",
  SUBMITTED: "Submitted",
  REQUESTED: "Requested",
};

// ============================================
// STATUS DISPLAY TEXT
// ============================================
export const MBP_STATUS_DISPLAY = {
  [MBP_STATUS.ENABLED]: "Enabled - Ready to Edit",
  [MBP_STATUS.SUBMITTED]: "Submitted - Locked",
  [MBP_STATUS.REQUESTED]: "Edit Requested - Pending",
};

// ============================================
// STATUS COLORS
// ============================================
export const MBP_STATUS_COLORS = {
  [MBP_STATUS.ENABLED]: {
    bg: "bg-green-100",
    text: "text-green-800",
    badge: "bg-green-500",
    icon: "✅",
  },
  [MBP_STATUS.SUBMITTED]: {
    bg: "bg-blue-100",
    text: "text-blue-800",
    badge: "bg-blue-500",
    icon: "📤",
  },
  [MBP_STATUS.REQUESTED]: {
    bg: "bg-yellow-100",
    text: "text-yellow-800",
    badge: "bg-yellow-500",
    icon: "📝",
  },
};

// ============================================
// AUTH HEADERS
// ============================================
const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// ============================================
// HANDLE AUTH ERRORS
// ============================================
const handleAuthError = (error) => {
  const message = error.response?.data?.message;

  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
    return true;
  }
  return false;
};

// ============================================
// UPDATE MBP STATUS
// ============================================
/**
 * Update MBP status via backend
 * 
 * @param {number} dealerInvestmentId 
 * @param {string} status - Use MBP_STATUS.ENABLED, MBP_STATUS.SUBMITTED, or MBP_STATUS.REQUESTED
 * @returns {Promise<Object>}
 */
export const updateMBPStatus = async (dealerInvestmentId, status) => {
  try {
    if (!dealerInvestmentId) {
      throw new Error("Invalid dealer investment ID");
    }

    const validStatuses = Object.values(MBP_STATUS);
    if (!validStatuses.includes(status)) {
      throw new Error(`Invalid status: ${status}. Allowed values: ${validStatuses.join(", ")}`);
    }

    const endpoint = dealerInvestmentEndpoints?.mbpStatusEquipmentsChange;
    if (!endpoint) {
      throw new Error("MBP endpoint not configured");
    }

    const url = `${domain}${endpoint}`;

    console.log("📡 Updating MBP Status:", { 
      url,
      dealerInvestmentId, 
      status 
    });

    const response = await axios.put(
      url,
      {
        id: dealerInvestmentId,
        status: status,
      },
      { headers: getAuthHeaders() }
    );

    if (!response.data) {
      throw new Error("Invalid server response");
    }

    console.log("✅ MBP Status updated:", response.data);

    return response.data;

  } catch (error) {
    if (handleAuthError(error)) {
      return { status: false, message: "Session expired" };
    }

    const errorMessage = error.response?.data?.message || 
                        error.message || 
                        "Failed to update MBP status";

    console.error("❌ Error updating MBP status:", errorMessage);

    return {
      status: false,
      message: errorMessage,
      error: error
    };
  }
};

// ============================================
// FETCH LATEST MBP STATUS - FIXED VERSION
// ============================================
/**
 * Fetch current MBP status from database
 * FIXED: Handles API domain properly
 * 
 * @param {number} dealerInvestmentId
 * @returns {Promise<string>} - Returns MBP_STATUS value
 */
export const fetchLatestMBPStatus = async (dealerInvestmentId) => {
  try {
    if (!dealerInvestmentId) {
      throw new Error("Invalid dealer investment ID");
    }

    // ⭐ FIXED: Proper URL construction
    const endpoint = dealerInvestmentEndpoints?.getDealerInvestmentById;
    
    if (!endpoint) {
      console.warn("⚠️ Endpoint not configured, using default");
      return MBP_STATUS.SUBMITTED;
    }

    // ⭐ Construct URL properly - NO double domain
    const url = `${domain}${endpoint}${dealerInvestmentId}`;

    console.log("📡 Fetching MBP status from URL:", url);

    const response = await axios.get(url, { headers: getAuthHeaders() });

    console.log("✅ API Response:", response.data);

    if (response.data?.status && response.data?.data?.mbpStatusEquipments) {
      const status = response.data.data.mbpStatusEquipments;
      console.log("✅ Fetched MBP Status from DB:", status);
      return status;
    }

    console.warn("⚠️ No MBP status found in response, defaulting to SUBMITTED");
    return MBP_STATUS.SUBMITTED;

  } catch (error) {
    if (handleAuthError(error)) {
      return MBP_STATUS.SUBMITTED;
    }

    const statusCode = error.response?.status;
    const errorMessage = error.response?.data?.message || error.message;

    // ⭐ Better error handling
    if (statusCode === 404) {
      console.error("❌ API Endpoint not found (404). Check your API configuration:");
      console.error("   - API Domain:", domain);
      console.error("   - Endpoint:", dealerInvestmentEndpoints?.getDealerInvestmentById);
      console.error("   - ID:", dealerInvestmentId);
    } else {
      console.warn("⚠️ Error fetching MBP status:", errorMessage);
    }

    return MBP_STATUS.SUBMITTED;
  }
};

// ============================================
// CHECK IF EDITABLE
// ============================================
/**
 * Determine if MBP is editable based on status and user role
 * 
 * @param {string} status - MBP_STATUS value
 * @param {string} userRole 
 * @param {array} dealerRoles 
 * @param {array} adminRoles 
 * @returns {boolean}
 */
export const isMBPEditable = (status, userRole, dealerRoles = [], adminRoles = []) => {
  if (status !== MBP_STATUS.ENABLED) {
    console.log("🔒 MBP not editable - Status is", status);
    return false;
  }

  const isAdmin = adminRoles.some(role => role?.toLowerCase() === userRole?.toLowerCase());
  const isDealer = dealerRoles.some(role => role?.toLowerCase() === userRole?.toLowerCase());

  if (isAdmin || isDealer) {
    console.log("🔓 MBP is editable for", isAdmin ? "Admin" : "Dealer");
    return true;
  }

  return false;
};

// ============================================
// GET AVAILABLE ACTIONS
// ============================================
export const getMBPActions = (status, userRole, dealerRoles = [], adminRoles = []) => {
  const isAdmin = adminRoles.some(role => role?.toLowerCase() === userRole?.toLowerCase());
  const isDealer = dealerRoles.some(role => role?.toLowerCase() === userRole?.toLowerCase());

  const actions = {
    canEnable: false,
    canDisable: false,
    canSubmit: false,
    canRequestEdit: false,
    canSave: false,
  };

  if (isAdmin) {
    actions.canEnable = status !== MBP_STATUS.ENABLED;
    actions.canDisable = status === MBP_STATUS.ENABLED;
    actions.canSubmit = status === MBP_STATUS.ENABLED;
    actions.canSave = status === MBP_STATUS.ENABLED;
  }

  if (isDealer) {
    actions.canSubmit = status === MBP_STATUS.ENABLED || status === MBP_STATUS.REQUESTED;
    actions.canRequestEdit = status === MBP_STATUS.SUBMITTED;
    actions.canSave = status === MBP_STATUS.ENABLED || status === MBP_STATUS.REQUESTED;
  }

  console.log("🎯 Available actions:", actions);
  return actions;
};

// ============================================
// GET STATUS DISPLAY INFO
// ============================================
export const getStatusInfo = (status) => {
  return {
    status: status,
    display: MBP_STATUS_DISPLAY[status] || status,
    colors: MBP_STATUS_COLORS[status] || MBP_STATUS_COLORS[MBP_STATUS.SUBMITTED],
  };
};

// ============================================
// SUBMIT MBP
// ============================================
export const submitMBP = async (dealerInvestmentId) => {
  try {
    console.log("📤 Submitting MBP...");
    return await updateMBPStatus(dealerInvestmentId, MBP_STATUS.SUBMITTED);
  } catch (error) {
    console.error("❌ Error submitting MBP:", error);
    throw error;
  }
};

// ============================================
// REQUEST EDIT
// ============================================
export const requestMBPEdit = async (dealerInvestmentId) => {
  try {
    console.log("📝 Requesting MBP Edit...");
    return await updateMBPStatus(dealerInvestmentId, MBP_STATUS.REQUESTED);
  } catch (error) {
    console.error("❌ Error requesting edit:", error);
    throw error;
  }
};

// ============================================
// ENABLE MBP
// ============================================
export const enableMBP = async (dealerInvestmentId) => {
  try {
    console.log("✅ Enabling MBP...");
    return await updateMBPStatus(dealerInvestmentId, MBP_STATUS.ENABLED);
  } catch (error) {
    console.error("❌ Error enabling MBP:", error);
    throw error;
  }
};

// ============================================
// DISABLE MBP
// ============================================
export const disableMBP = async (dealerInvestmentId) => {
  try {
    console.log("🔒 Disabling MBP...");
    return await updateMBPStatus(dealerInvestmentId, MBP_STATUS.SUBMITTED);
  } catch (error) {
    console.error("❌ Error disabling MBP:", error);
    throw error;
  }
};

// ============================================
// TOGGLE MBP STATUS
// ============================================
export const toggleMBPStatus = async (dealerInvestmentId, shouldEnable) => {
  try {
    const newStatus = shouldEnable ? MBP_STATUS.ENABLED : MBP_STATUS.SUBMITTED;
    console.log("🔄 Toggling MBP to:", newStatus);
    return await updateMBPStatus(dealerInvestmentId, newStatus);
  } catch (error) {
    console.error("❌ Error toggling MBP status:", error);
    throw error;
  }
};

// ============================================
// GET STATUS DISPLAY TEXT
// ============================================
export const getStatusDisplayText = (status) => {
  return MBP_STATUS_DISPLAY[status] || status;
};