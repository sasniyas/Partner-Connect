/**
 * Dealer Investment Equipment Summary Service
 * Aggregates equipment data for EquipmentsAttachments tab
 * Groups by Make (Volvo/SDLG) and Type (Equipments/Attachments)
 */

import axios from "axios";
import { API } from "../../api";

const { 
  domain, 
  dealerInvestmentEquipmentActualsEndpoints,
  dealerInvestmentEquipmentMbpEndpoints,
  dealerInvestmentEquipmentProjectionEndpoints
} = API;

// ============================================
// UTILITY FUNCTIONS
// ============================================

const getAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

// ============================================
// CONSTANTS
// ============================================

/**
 * Equipment types that are classified as "Attachments"
 * Everything else is classified as "Equipments"
 */
const ATTACHMENT_TYPES = [
  "breaker sales",
  "quick coupler",
  "quick coupler sales",
  "other attachments sales",
  "other attachments",
  "attachments",
];

/**
 * Month field mapping
 */
const MONTH_FIELDS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "decem"];
const MONTH_DISPLAY = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// ============================================
// API FUNCTIONS
// ============================================

export const getDealerInvestmentEquipmentMbpByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentEquipmentMbpEndpoints.getDealerInvestmentEquipmentMbpByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching equipment MBP:", error);
    throw error;
  }
};

export const getDealerInvestmentEquipmentProjectionByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentEquipmentProjectionEndpoints.getDealerInvestmentEquipmentProjectionByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching equipment projection:", error);
    throw error;
  }
};

export const getDealerInvestmentEquipmentActualsByDealerInvestmentId = async (dealerInvestmentId) => {
  try {
    const response = await axios.get(
      `${domain}${dealerInvestmentEquipmentActualsEndpoints.getDealerInvestmentEquipmentActualsByDealerInvestmentId}${dealerInvestmentId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching equipment actuals:", error);
    throw error;
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Determine if equipment type is Attachment or Equipment
 */
const isAttachment = (equipmentType) => {
  if (!equipmentType) return false;
  const normalizedType = equipmentType.trim().toLowerCase();
  return ATTACHMENT_TYPES.some(type => normalizedType.includes(type));
};

/**
 * Sum monthly values from data array
 */
const sumMonthlyData = (dataArray) => {
  const result = {};
  MONTH_DISPLAY.forEach((month, index) => {
    result[month] = dataArray.reduce((sum, item) => {
      return sum + (parseInt(item[MONTH_FIELDS[index]]) || 0);
    }, 0);
  });
  return result;
};

/**
 * Calculate quarterly totals from monthly data
 */
const calculateQuarterly = (monthlyData) => {
  return {
    Q1: (monthlyData.Jan || 0) + (monthlyData.Feb || 0) + (monthlyData.Mar || 0),
    Q2: (monthlyData.Apr || 0) + (monthlyData.May || 0) + (monthlyData.Jun || 0),
    Q3: (monthlyData.Jul || 0) + (monthlyData.Aug || 0) + (monthlyData.Sep || 0),
    Q4: (monthlyData.Oct || 0) + (monthlyData.Nov || 0) + (monthlyData.Dec || 0),
  };
};

/**
 * Calculate total from monthly data
 */
const calculateTotal = (monthlyData) => {
  return Object.values(monthlyData).reduce((sum, val) => sum + (parseInt(val) || 0), 0);
};

/**
 * Sum PDP targets from data array
 * Uses pdp_target field, falls back to summing monthly MBP values
 */
const sumPdpTargets = (dataArray) => {
  // First try to sum pdp_target values
  const pdpTargetSum = dataArray.reduce((sum, item) => {
    return sum + (parseInt(item.pdp_equipment_info?.pdp_target) || 0);
  }, 0);
  
  // If pdp_target is 0, calculate from monthly MBP values
  if (pdpTargetSum === 0) {
    return dataArray.reduce((sum, item) => {
      const monthlySum = MONTH_FIELDS.reduce((mSum, field) => {
        return mSum + (parseInt(item[field]) || 0);
      }, 0);
      return sum + monthlySum;
    }, 0);
  }
  
  return pdpTargetSum;
};

/**
 * Convert monthly data object to string values for display
 */
const toStringValues = (monthlyData) => {
  const result = {};
  Object.keys(monthlyData).forEach(key => {
    result[key] = monthlyData[key] > 0 ? String(monthlyData[key]) : "";
  });
  return result;
};

// ============================================
// DATA TRANSFORMATION
// ============================================

/**
 * Transform and aggregate equipment data for summary view
 * Groups by Make (Volvo/SDLG) and Type (Equipments/Attachments)
 */
export const transformEquipmentSummaryData = (mbpData, projectionData, actualsData) => {
  // Initialize structure for both makes
  const makes = ["Volvo", "SDLG"];
  const types = ["Equipments", "Attachments"];
  
  const result = {
    targetData: [],
    allData: {},
  };

  // Initialize structure for each make
  makes.forEach(make => {
    result.allData[make] = {};
    types.forEach(type => {
      result.allData[make][type] = {
        monthly: {
          "Monthly Business Plan": {},
          "Monthly Projection": {},
          "Actuals": {},
          "Achievement %": {},
          "Accuracy %": {},
        },
        quarterly: {
          "Quarterly Business Plan": {},
          "Quarterly Projections": {},
          "Actuals": {},
          "Achievement %": {},
          "Accuracy %": {},
        },
        stats: {
          ytdActuals: "0",
          pdpTarget: "0",
          achievement: "0.00",
        },
      };
    });
  });

  // Filter data by make and type
  const filterData = (dataArray, make, isAttachmentType) => {
    return dataArray.filter(item => {
      const itemMake = (item.equipment_info?.equipment_make || "").trim();
      const itemType = (item.equipment_info?.equipment_type || "").trim();
      const matchesMake = itemMake.toLowerCase() === make.toLowerCase();
      const matchesType = isAttachmentType ? isAttachment(itemType) : !isAttachment(itemType);
      return matchesMake && matchesType;
    });
  };

  // Process each make and type
  makes.forEach(make => {
    types.forEach(type => {
      const isAttachmentType = type === "Attachments";
      
      // Filter data for this make/type combination
      const filteredMbp = filterData(mbpData, make, isAttachmentType);
      const filteredProjection = filterData(projectionData, make, isAttachmentType);
      const filteredActuals = filterData(actualsData, make, isAttachmentType);

      // Calculate monthly totals
      const mbpMonthly = sumMonthlyData(filteredMbp);
      const projectionMonthly = sumMonthlyData(filteredProjection);
      const actualsMonthly = sumMonthlyData(filteredActuals);

      // Calculate quarterly totals
      const mbpQuarterly = calculateQuarterly(mbpMonthly);
      const projectionQuarterly = calculateQuarterly(projectionMonthly);
      const actualsQuarterly = calculateQuarterly(actualsMonthly);

      // Calculate achievement and accuracy percentages
      const achievementMonthly = {};
      const accuracyMonthly = {};
      MONTH_DISPLAY.forEach(month => {
        const mbpVal = mbpMonthly[month] || 0;
        const projVal = projectionMonthly[month] || 0;
        const actualVal = actualsMonthly[month] || 0;
        
        achievementMonthly[month] = mbpVal > 0 ? `${Math.round((actualVal / mbpVal) * 100)}%` : "";
        accuracyMonthly[month] = projVal > 0 ? `${Math.round((actualVal / projVal) * 100)}%` : "";
      });

      const achievementQuarterly = {};
      const accuracyQuarterly = {};
      ["Q1", "Q2", "Q3", "Q4"].forEach(q => {
        const mbpVal = mbpQuarterly[q] || 0;
        const projVal = projectionQuarterly[q] || 0;
        const actualVal = actualsQuarterly[q] || 0;
        
        achievementQuarterly[q] = mbpVal > 0 ? String(Math.round((actualVal / mbpVal) * 100)) : "";
        accuracyQuarterly[q] = projVal > 0 ? String(Math.round((actualVal / projVal) * 100)) : "";
      });

      // Calculate stats
      const ytdActuals = calculateTotal(actualsMonthly);
      const pdpTarget = sumPdpTargets(filteredMbp);
      const achievement = pdpTarget > 0 ? ((ytdActuals / pdpTarget) * 100).toFixed(2) : "0.00";

      // Assign to result
      result.allData[make][type] = {
        monthly: {
          "Monthly Business Plan": toStringValues(mbpMonthly),
          "Monthly Projection": toStringValues(projectionMonthly),
          "Actuals": toStringValues(actualsMonthly),
          "Achievement %": achievementMonthly,
          "Accuracy %": accuracyMonthly,
        },
        quarterly: {
          "Quarterly Business Plan": { 
            Q1: mbpQuarterly.Q1 > 0 ? String(mbpQuarterly.Q1) : "", 
            Q2: mbpQuarterly.Q2 > 0 ? String(mbpQuarterly.Q2) : "", 
            Q3: mbpQuarterly.Q3 > 0 ? String(mbpQuarterly.Q3) : "", 
            Q4: mbpQuarterly.Q4 > 0 ? String(mbpQuarterly.Q4) : "" 
          },
          "Quarterly Projections": { 
            Q1: projectionQuarterly.Q1 > 0 ? String(projectionQuarterly.Q1) : "", 
            Q2: projectionQuarterly.Q2 > 0 ? String(projectionQuarterly.Q2) : "", 
            Q3: projectionQuarterly.Q3 > 0 ? String(projectionQuarterly.Q3) : "", 
            Q4: projectionQuarterly.Q4 > 0 ? String(projectionQuarterly.Q4) : "" 
          },
          "Actuals": { 
            Q1: actualsQuarterly.Q1 > 0 ? String(actualsQuarterly.Q1) : "", 
            Q2: actualsQuarterly.Q2 > 0 ? String(actualsQuarterly.Q2) : "", 
            Q3: actualsQuarterly.Q3 > 0 ? String(actualsQuarterly.Q3) : "", 
            Q4: actualsQuarterly.Q4 > 0 ? String(actualsQuarterly.Q4) : "" 
          },
          "Achievement %": achievementQuarterly,
          "Accuracy %": accuracyQuarterly,
        },
        stats: {
          ytdActuals: String(ytdActuals),
          pdpTarget: String(pdpTarget),
          achievement: achievement,
        },
      };
    });
  });

  // Build target data for summary table
  makes.forEach(make => {
    const filteredEquipment = filterData(mbpData, make, false);
    const filteredAttachment = filterData(mbpData, make, true);
    
    const equipmentTarget = sumPdpTargets(filteredEquipment);
    const attachmentTarget = sumPdpTargets(filteredAttachment);
    
    console.log(`Target calculation for ${make}:`, {
      equipmentCount: filteredEquipment.length,
      attachmentCount: filteredAttachment.length,
      equipmentTarget,
      attachmentTarget,
    });
    
    result.targetData.push({
      make: make,
      equipments: String(equipmentTarget),
      attachments: String(attachmentTarget),
    });
  });

  return result;
};

// ============================================
// MAIN FETCH FUNCTION
// ============================================

/**
 * Fetch and transform all equipment data for summary view
 */
export const fetchEquipmentSummaryData = async (dealerInvestmentId) => {
  try {
    // Fetch all three data types in parallel
    const [mbpResponse, projectionResponse, actualsResponse] = await Promise.all([
      getDealerInvestmentEquipmentMbpByDealerInvestmentId(dealerInvestmentId),
      getDealerInvestmentEquipmentProjectionByDealerInvestmentId(dealerInvestmentId),
      getDealerInvestmentEquipmentActualsByDealerInvestmentId(dealerInvestmentId),
    ]);

    const mbpData = mbpResponse?.status ? mbpResponse.data : [];
    const projectionData = projectionResponse?.status ? projectionResponse.data : [];
    const actualsData = actualsResponse?.status ? actualsResponse.data : [];

    console.log("Equipment Summary data loaded:", {
      mbpCount: mbpData.length,
      projectionCount: projectionData.length,
      actualsCount: actualsData.length,
    });
    
    // Log sample data structure for debugging
    if (mbpData.length > 0) {
      console.log("Sample MBP item:", {
        equipment_make: mbpData[0].equipment_info?.equipment_make,
        equipment_type: mbpData[0].equipment_info?.equipment_type,
        pdp_target: mbpData[0].pdp_equipment_info?.pdp_target,
        jan: mbpData[0].jan,
        feb: mbpData[0].feb,
      });
    }

    // Transform and aggregate data
    const transformedData = transformEquipmentSummaryData(mbpData, projectionData, actualsData);

    return {
      status: true,
      data: transformedData,
    };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching equipment summary data:", error);
    return {
      status: false,
      data: {
        targetData: [
          { make: "Volvo", equipments: "0", attachments: "0" },
          { make: "SDLG", equipments: "0", attachments: "0" },
        ],
        allData: {},
      },
    };
  }
};

// ============================================
// EXPORT DEFAULT
// ============================================
