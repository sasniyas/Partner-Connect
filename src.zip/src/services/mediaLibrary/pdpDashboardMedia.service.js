import axios from 'axios';
import { API } from '../../api.js';

// Add a new PDP Dashboard Media
export const addPdpDashboardMedia = async (pdpDashboardMediaData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    console.log("domain", API.domain);
    const response = await axios.post(
      `${API.domain}${API.endpoints.addPdpDashboardMedia}`,
      pdpDashboardMediaData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return true;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to add PDP Dashboard Media");
    }

    throw new Error("Failed to add PDP Dashboard Media");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding PDP Dashboard Media:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to add PDP Dashboard Media");
    }
  }
};

// Get all PDP Dashboard Media
export const getPdpDashboardMedia = async () => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getPdpDashboardMedia}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to get PDP Dashboard Media");
    }

    throw new Error("Failed to get PDP Dashboard Media");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting PDP Dashboard Media:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to get PDP Dashboard Media");
    }
  }
};

// Get PDP Dashboard Media by ID
export const getPdpDashboardMediaById = async (pdpDashboardMediaId) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getPdpDashboardMediaById}${pdpDashboardMediaId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to get PDP Dashboard Media by ID");
    }

    throw new Error("Failed to get PDP Dashboard Media by ID");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting PDP Dashboard Media by ID:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to get PDP Dashboard Media by ID");
    }
  }
};

// Update an existing PDP Dashboard Media
export const updatePdpDashboardMedia = async (pdpDashboardMediaId, pdpDashboardMediaData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updatePdpDashboardMedia}`,
      pdpDashboardMediaData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to update PDP Dashboard Media");
    }

    throw new Error("Failed to update PDP Dashboard Media");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating PDP Dashboard Media:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to update PDP Dashboard Media");
    }
  }
};

// Toggle enable/disable for PDP Dashboard Media
export const togglePdpDashboardMedia = async (pdpDashboardMediaId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.togglePdpDashboardMedia}${pdpDashboardMediaId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to toggle PDP Dashboard Media");
    }

    throw new Error("Failed to toggle PDP Dashboard Media");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling PDP Dashboard Media:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to toggle PDP Dashboard Media");
    }
  }
};

// Delete PDP Dashboard Media
export const deletePdpDashboardMedia = async (pdpDashboardMediaId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deletePdpDashboardMedia}${pdpDashboardMediaId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to delete PDP Dashboard Media");
    }

    throw new Error("Failed to delete PDP Dashboard Media");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting PDP Dashboard Media:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to delete PDP Dashboard Media");
    }
  }
};
