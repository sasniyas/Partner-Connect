import axios from 'axios';
import { API } from '../../api.js';

// Add a new DFHM Media
export const addDfhmMedia = async (dfhmMediaData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    console.log("domain", API.domain);
    const response = await axios.post(
      `${API.domain}${API.endpoints.addDfhmMedia}`,
      dfhmMediaData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return true;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to add DFHM Media");
    }

    throw new Error("Failed to add DFHM Media");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding DFHM Media:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to add DFHM Media");
    }
  }
};

// Get all DFHM Media
export const getAllDfhmMedia = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getAllDfhmMedia}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to get DFHM Media");
    }

    throw new Error("Failed to get DFHM Media");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting DFHM Media:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to get DFHM Media");
    }
  }
};

// Get DFHM Media by ID
export const getDfhmMediaById = async (dfhmMediaId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getDfhmMediaById}${dfhmMediaId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to get DFHM Media by ID");
    }

    throw new Error("Failed to get DFHM Media by ID");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting DFHM Media by ID:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to get DFHM Media by ID");
    }
  }
};

// Update an existing DFHM Media
export const updateDfhmMedia = async (dfhmMediaId, dfhmMediaData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateDfhmMedia}`,
      dfhmMediaData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to update DFHM Media");
    }

    throw new Error("Failed to update DFHM Media");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating DFHM Media:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to update DFHM Media");
    }
  }
};

// Toggle enable/disable for DFHM Media
export const toggleDfhmMedia = async (dfhmMediaId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleDfhmMedia}${dfhmMediaId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to toggle DFHM Media");
    }

    throw new Error("Failed to toggle DFHM Media");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling DFHM Media:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to toggle DFHM Media");
    }
  }
};

// Delete DFHM Media
export const deleteDfhmMedia = async (dfhmMediaId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteDfhmMedia}${dfhmMediaId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to delete DFHM Media");
    }

    throw new Error("Failed to delete DFHM Media");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting DFHM Media:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to delete DFHM Media");
    }
  }
};
