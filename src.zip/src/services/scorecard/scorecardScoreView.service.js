import axios from "axios";
import { API } from "../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 SCORECARD SCORE VIEW API SERVICES
// For ScoreAudit page (single scorecard scoring)
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ FUNCTION 1: Get Scorecard Score Views by Scorecard ID
 * Fetch all score views for a specific scorecard
 * 
 * @param {number} scorecardId - Scorecard ID
 * @returns {Promise<Array>} Array of score view records
 */
export const getScorecardScoreViewsByScorecardId = async (scorecardId) => {
  try {
    if (!scorecardId) {
      throw new Error("Scorecard ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.getScorecardScoreViewsByScorecardId}${scorecardId}`;

    console.log("📡 Fetching Scorecard Score Views");
    console.log("  URL:", url);
    console.log("  Scorecard ID:", scorecardId);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Score Views Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      // Debug: Log first record to see formula field
      if (rawData.length > 0) {
        console.log("📋 Sample raw data (first record):", {
          formula: rawData[0].formula,
          minScore: rawData[0].minScore,
          maxScore: rawData[0].maxScore,
          sub_kpi_measurement: rawData[0].sub_kpi_measurement,
        });
      }

      // Transform API response to frontend format
      const transformedData = rawData.map(item => ({
        // Score View Fields
        id: item.id,
        subKpiId: item.sub_kpi_id,
        scorecardId: item.scorecard_id,
        reviewerScore: item.reviewer_score,
        reviewerId: item.reviewer,
        reviewerName: item.reviewer_name || "",
        reviewerEmail: item.reviewer_email || "",
        isScored: item.isScored === 1,
        scored: item.isScored === 1 ? "Yes" : "No",
        isExcluded: item.isExcluded === 1,
        exclude: item.isExcluded === 1 ? "Yes" : "No",
        remarks: item.remarks || "",
        supportingDoc: item.supporting_doc || item.supportingDoc || "",
        uploadedBy: item.uploaded_by || item.uploadedBy || "",
        uploadedByName: item.uploaded_by_name || item.uploadedByName || "",
        uploadedByEmail: item.uploaded_by_email || item.uploadedByEmail || "",
        uploadedOn: item.uploaded_on || item.uploadedOn || "",
        finalScore: item.final_score,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        createdAt: item.created_at,
        updatedAt: item.updated_at,

        // Sub KPI Fields
        kpiNo: item.sub_kpi_kpiNumber || "",
        strategicObjective: item.sub_kpi_objectiveName || "",
        kpi: item.sub_kpi_kpiName || "",
        subKpi: item.sub_kpi_subKpiName || "",
        subKpiName: item.sub_kpi_subKpiName || "",
        assessmentPeriod: item.sub_kpi_assessmentPeriod || "",
        minScore: parseFloat(item.minScore) || parseFloat(item.sub_kpi_minScore) || 0,
        maxScore: parseFloat(item.maxScore) || parseFloat(item.sub_kpi_maxScore) || 0,
        formula: item.formula || null,  // ⭐ NEW: Formula from database
        scoringCriteria: item.sub_kpi_scoringCriteria || "",
        measurement: item.sub_kpi_measurement || "",
        annualScore: item.sub_kpi_annualScore || "",
        annualScoringCriteria: item.sub_kpi_annualScoringCriteria || "",
        criteriaDefinition: item.sub_kpi_criteriaDefinition || "",
        dataSource: item.sub_kpi_dataSource || "",
        subKpiCreatedYear: item.sub_kpi_createdYear,
        subKpiObjectiveId: item.sub_kpi_objectiveId,
        subKpiKpiId: item.sub_kpi_kpiId,
        subKpiDocStatus: item.sub_kpi_docStaus,
        subKpiDoc: item.sub_kpi_doc || item.subKpiDoc || "",

        // Scorecard Fields
        scorecardYear: item.scorecard_year,
        scorecardFrequency: item.scorecard_frequency,
        scorecardQuarter: item.scorecard_quarter_frequency,
        scorecardAuditLocation: item.scorecard_audit_location,
        scorecardBranch: item.scorecard_branch,

        // Scoring object for UI
        scoring: {
          maxScore: item.maxScore || item.sub_kpi_maxScore || "0",
          minScore: item.minScore || item.sub_kpi_minScore || "0",
          threshold: item.minScore || item.sub_kpi_minScore || "0",
          reviewerScore: item.reviewer_score || "",
          finalScore: item.final_score || "",
        },

        // Quarter scores placeholder
        quarterScores: [
          { quarter: "Q1", score: "" },
          { quarter: "Q2", score: "" },
          { quarter: "Q3", score: "" },
          { quarter: "Q4", score: "" },
        ],

        // Documents placeholder
        documents: [],
      }));

      console.log("✅ Score Views transformed:", transformedData.length, "records");
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch score views");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getScorecardScoreViewsByScorecardId Error:", error.message);

   
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch score views");
  }
};

/**
 * ✅ FUNCTION 2: Update Scorecard Score View
 * Update a score view record
 * 
 * @param {Object} data - Score view data to update
 * @returns {Promise<Object>} Updated score view response
 */
export const updateScorecardScoreView = async (data) => {
  try {
    if (!data.id) {
      throw new Error("Score View ID is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.updateScorecardScoreView}`;

    console.log("📡 Updating Scorecard Score View");
    console.log("  URL:", url);
    console.log("  Input Data:", data);

    // Prepare data for API
    const apiData = {
      id: parseInt(data.id),
    };

    // Only include fields that are provided
    if (data.reviewer_score !== undefined) apiData.reviewer_score = data.reviewer_score;
    if (data.reviewerScore !== undefined) apiData.reviewer_score = data.reviewerScore;
    if (data.reviewer !== undefined) apiData.reviewer = parseInt(data.reviewer);
    if (data.reviewerId !== undefined) apiData.reviewer = parseInt(data.reviewerId);
    if (data.isScored !== undefined) apiData.isScored = data.isScored ? 1 : 0;
    if (data.isExcluded !== undefined) apiData.isExcluded = data.isExcluded ? 1 : 0;
    if (data.remarks !== undefined) apiData.remarks = data.remarks;
    if (data.final_score !== undefined) apiData.final_score = data.final_score;
    if (data.finalScore !== undefined) apiData.final_score = data.finalScore;

    console.log("📤 API Data being sent:", apiData);

    const response = await axios.put(url, apiData, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Score View Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update score view");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updateScorecardScoreView Error:", error.message);

   

    throw new Error(error.response?.data?.message || error.message || "Failed to update score view");
  }
};

/**
 * ✅ FUNCTION 2B: Upload Supporting Document for Score View
 * Uploads a supporting document file for a score view
 * 
 * @param {number} scoreViewId - Score View ID
 * @param {File} file - File to upload
 * @returns {Promise<Object>} Updated score view data
 */
export const uploadScorecardScoreViewDoc = async (scoreViewId, file) => {
  try {
    if (!scoreViewId) {
      throw new Error("Score View ID is required");
    }
    if (!file) {
      throw new Error("File is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.updateScorecardScoreView}`;

    console.log("📡 Uploading Supporting Document");
    console.log("  URL:", url);
    console.log("  Score View ID:", scoreViewId);
    console.log("  File:", file.name, "Size:", file.size, "Type:", file.type);

    // Use FormData for file upload
    const formData = new FormData();
    formData.append("id", scoreViewId);
    formData.append("files", file);

    const response = await axios.put(url, formData, {
      headers: {
        Authorization: `Bearer ${token}`,
        // Don't set Content-Type for FormData - let browser set it with boundary
      },
    });

    console.log("✅ Upload Document Response:", {
      status: response.status,
      data: response.data
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to upload document");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ uploadScorecardScoreViewDoc Error:", error.message);


    throw new Error(error.response?.data?.message || error.message || "Failed to upload document");
  }
};

/**
 * ✅ FUNCTION 3: Get Scorecard Score View Docs by Scorecard ID
 * Fetch all documents for a specific scorecard
 * 
 * @param {number} scorecardId - Scorecard ID
 * @returns {Promise<Array>} Array of document records
 */
export const getScorecardScoreViewDocsByScorecardId = async (scorecardId) => {
  try {
    if (!scorecardId) {
      throw new Error("Scorecard ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.getScorecardScoreViewDocsByScorecardId}${scorecardId}`;

    console.log("📡 Fetching Scorecard Score View Docs");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Score View Docs Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      const transformedData = rawData.map(item => ({
        id: item.id,
        scorecardId: item.scorecard_id,
        uploadedBy: item.uploaded_by,
        uploadedByName: item.uploaded_by_name || "Unknown",
        uploadedByEmail: item.uploaded_by_email || "",
        docUrl: item.doc_url,
        name: extractFileName(item.doc_url),
        date: formatDateDisplay(item.created_at),
        createdAt: item.created_at,
        updatedAt: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        scorecardYear: item.scorecard_year,
        scorecardFrequency: item.scorecard_frequency,
        scorecardQuarter: item.scorecard_quarter_frequency,
        scorecardAuditLocation: item.scorecard_audit_location,
        scorecardBranch: item.scorecard_branch,
      }));

      console.log("✅ Score View Docs transformed:", transformedData.length, "records");
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch score view docs");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getScorecardScoreViewDocsByScorecardId Error:", error.message);

    

    throw new Error(error.response?.data?.message || error.message || "Failed to fetch score view docs");
  }
};

/**
 * ✅ FUNCTION 4: Add Scorecard Score View Doc
 * Upload a new document for a scorecard
 * 
 * @param {Object} data - Document data including file
 * @returns {Promise<Object>} Created document response
 */
export const addScorecardScoreViewDoc = async (data) => {
  try {
    if (!data.scorecard_id && !data.scorecardId) {
      throw new Error("Scorecard ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.addScorecardScoreViewDoc}`;

    console.log("📡 Adding Scorecard Score View Doc");
    console.log("  URL:", url);

    const formData = new FormData();
    formData.append("scorecard_id", data.scorecard_id || data.scorecardId);
    
    if (data.uploaded_by || data.uploadedBy) {
      formData.append("uploaded_by", data.uploaded_by || data.uploadedBy);
    }
    
    if (data.file) {
      formData.append("doc", data.file);
    } else if (data.doc_url || data.docUrl) {
      formData.append("doc_url", data.doc_url || data.docUrl);
    }

    const response = await axios.post(url, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Add Score View Doc Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200 || response.status === 201) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to add document");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ addScorecardScoreViewDoc Error:", error.message);

   

    throw new Error(error.response?.data?.message || error.message || "Failed to add document");
  }
};

/**
 * ✅ FUNCTION 5: Delete Scorecard Score View Doc
 * Soft delete a document
 * 
 * @param {number} docId - Document ID to delete
 * @returns {Promise<Object>} Delete response
 */
export const deleteScorecardScoreViewDoc = async (docId) => {
  try {
    if (!docId) {
      throw new Error("Document ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.deleteScorecardScoreViewDoc}${docId}`;

    console.log("📡 Deleting Scorecard Score View Doc");
    console.log("  URL:", url);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Score View Doc Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete document");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ deleteScorecardScoreViewDoc Error:", error.message);

   

    throw new Error(error.response?.data?.message || error.message || "Failed to delete document");
  }
};

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

const extractFileName = (url) => {
  if (!url) return "Unknown File";
  try {
    const parts = url.split("/");
    return decodeURIComponent(parts[parts.length - 1]) || "Unknown File";
  } catch {
    return "Unknown File";
  }
};

const formatDateDisplay = (dateString) => {
  if (!dateString) return "";
  try {
    let date;
    
    if (typeof dateString === 'string') {
      // Remove any existing 'Z' and add it back to ensure UTC parsing
      let cleanDateString = dateString.replace('Z', '').trim();
      
      // If it has 'T', it's ISO format - append Z for UTC
      if (cleanDateString.includes('T')) {
        date = new Date(cleanDateString + 'Z');
      } else {
        // For other formats, try parsing directly
        date = new Date(dateString);
      }
    } else {
      date = new Date(dateString);
    }
    
    if (isNaN(date.getTime())) return dateString;

    // Get local time components (JavaScript automatically converts UTC to local)
    const day = date.getDate();
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const month = monthNames[date.getMonth()];
    const year = date.getFullYear();
    let hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;

    return `${day} ${month},${year} ${hours}:${minutes} ${ampm}`;
  } catch {
    return dateString;
  }
};

/**
 * Group score views by strategic objective
 */
export const groupScoreViewsByObjective = (scoreViews) => {
  const grouped = {};
  
  scoreViews.forEach(item => {
    const objective = item.strategicObjective || "Other";
    if (!grouped[objective]) {
      grouped[objective] = [];
    }
    grouped[objective].push(item);
  });

  return grouped;
};

/**
 * Calculate objective statistics
 */
export const calculateObjectiveStats = (scoreViews) => {
  const total = scoreViews.length;
  const scored = scoreViews.filter(sv => sv.isScored).length;
  const totalMaxScore = scoreViews.reduce((sum, sv) => sum + (parseFloat(sv.maxScore) || 0), 0);
  const totalFinalScore = scoreViews.reduce((sum, sv) => sum + (parseFloat(sv.finalScore) || 0), 0);
  const percentage = totalMaxScore > 0 ? ((totalFinalScore / totalMaxScore) * 100).toFixed(2) : 0;

  return {
    total,
    scored,
    totalMaxScore,
    totalFinalScore,
    percentage,
    scoreText: `Scored:${scored}/${total}`,
    percentageText: `${totalFinalScore}/${totalMaxScore} (${percentage}%)`,
  };
};

// ═══════════════════════════════════════════════════════════════
// 📋 SCORECARD ACTION ITEMS API FUNCTIONS
// For UserViewDetails page
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ Get Action Items by Score View ID
 * Fetch all action items for a specific score view
 * 
 * @param {number} scoreViewId - Score View ID (scorecard_score_id)
 * @returns {Promise<Array>} Array of action items
 */
export const getScorecardActionItemsByScoreId = async (scoreViewId) => {
  try {
    if (!scoreViewId) {
      throw new Error("Score View ID is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.getScorecardActionItemsByScoreId}${scoreViewId}`;

    console.log("📡 Fetching Action Items by Score View ID");
    console.log("  URL:", url);
    console.log("  Score View ID:", scoreViewId);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Action Items Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      // Transform API response to frontend format
      return rawData.map(item => ({
        id: item.id,
        scoreViewId: item.scorecard_score_id,
        scorecardId: item.scorecard_id,
        // Sub KPI details from joined data
        subKpiId: item.sub_kpi_id,
        subKpi: item.sub_kpi_subKpiName || "",
        kpiNo: item.sub_kpi_kpiNumber || "",
        strategicObjective: item.strategic_objective_name || "",
        // Score details
        maxScore: parseFloat(item.sub_kpi_maxScore) || 0,
        finalScore: parseFloat(item.final_score) || 0,
        reviewerScore: item.reviewer_score,
        remarks: item.remarks || "",
        // Action item details
        status: item.action_item_status || "Created",
        assignedTo: item.assigned_to_name || "",
        assignedToId: item.assigned_to,
        assignedToEmail: item.assigned_to_email || "",
        endDate: item.end_date,
        // Created by
        createdBy: item.created_by_name || "User",
        createdById: item.created_by,
        createdByEmail: item.created_by_email || "",
        createdDate: formatDateDisplay(item.created_at),
        createdAt: item.created_at,
        updatedAt: item.updated_at,
        isActive: item.isActive ?? 1,
        isDeleted: item.isDeleted ?? 0,
        // Scorecard details
        year: item.scorecard_year,
        quarter: item.scorecard_quarter,
        dealerName: item.dealer_name,
      }));
    }

    return [];
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error fetching action items:", error);
    throw error;
  }
};

// Alias for backward compatibility
export const getScorecardActionItemsByScoreViewId = getScorecardActionItemsByScoreId;

/**
 * ✅ Get All Action Items
 * Fetch all action items (optionally filter by scorecard ID on frontend)
 * 
 * @param {number} scorecardId - Optional Scorecard ID to filter
 * @returns {Promise<Array>} Array of action items
 */
export const getAllScorecardActionItems = async (scorecardId = null) => {
  try {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.getAllScorecardActionItems}`;

    console.log("📡 Fetching All Action Items");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Action Items Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    // Debug: Log first item's threshold/minScore from raw API response
    if (response.data.data?.length > 0) {
      const firstItem = response.data.data[0];
      console.log("🔍 Raw API first item scores:", {
        sub_kpi_minScore: firstItem.sub_kpi_minScore,
        sub_kpi_maxScore: firstItem.sub_kpi_maxScore,
        final_score: firstItem.final_score,
        reviewer_score: firstItem.reviewer_score,
      });
    }

    if (response.status === 200 && response.data.status) {
      let rawData = response.data.data || [];

      // Filter by scorecard ID if provided
      if (scorecardId) {
        rawData = rawData.filter(item => item.scorecard_id === scorecardId);
      }

      // Transform API response to frontend format
      return rawData.map(item => ({
        id: item.id,
        scoreViewId: item.scorecard_score_id,
        scorecardId: item.scorecard_id,
        subKpiId: item.sub_kpi_id,
        subKpi: item.sub_kpi_subKpiName || "",
        kpiNo: item.sub_kpi_kpiNumber || "",
        strategicObjective: item.strategic_objective_name || "",
        maxScore: parseFloat(item.sub_kpi_maxScore) || 0,
        minScore: parseFloat(item.sub_kpi_minScore) || 0,
        threshold: parseFloat(item.sub_kpi_minScore) || 0,
        finalScore: parseFloat(item.final_score) || 0,
        reviewerScore: item.reviewer_score,
        remarks: item.remarks || "",
        status: item.action_item_status || "Created",
        assignedTo: item.assigned_to_name || "",
        assignedToId: item.assigned_to,
        assignedToEmail: item.assigned_to_email || "",
        endDate: item.end_date,
        createdBy: item.created_by_name || "User",
        createdById: item.created_by,
        createdByEmail: item.created_by_email || "",
        createdDate: formatDateDisplay(item.created_at),
        createdAt: item.created_at,
        updatedAt: item.updated_at,
        isActive: item.isActive ?? 1,
        isDeleted: item.isDeleted ?? 0,
        year: item.scorecard_year,
        quarter: item.scorecard_quarter,
        dealerName: item.dealer_name,
      }));
    }

    return [];
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error fetching action items:", error);
    throw error;
  }
};

// Alias for backward compatibility
export const getScorecardActionItemsByScorecardId = getAllScorecardActionItems;

/**
 * ✅ Add Scorecard Action Item
 * Create a new action item for a score view
 * 
 * Backend expects:
 * - scorecard_score_id (required) - Score View ID
 * - assigned_to (optional) - User ID
 * - action_item_status (optional) - "Created", "In Progress", "Closed", "Completed"
 * - end_date (optional)
 * - final_score (optional)
 * 
 * @param {Object} actionItemData - Action item data
 * @returns {Promise<Object>} Created action item
 */
export const addScorecardActionItem = async (actionItemData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.addScorecardActionItem}`;

    // Prepare request body - match backend expected fields
    const requestBody = {
      scorecard_score_id: actionItemData.scoreViewId || actionItemData.scorecard_score_id,
      assigned_to: actionItemData.assignedToId || actionItemData.assigned_to || null,
      action_item_status: actionItemData.status || actionItemData.action_item_status || "Created",
      end_date: actionItemData.endDate || actionItemData.end_date || null,
      final_score: actionItemData.finalScore || actionItemData.final_score || null,
    };

    console.log("📤 Adding Action Item:", requestBody);

    const response = await axios.post(url, requestBody, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Action Item Added:", response.data);

    if (response.status === 200 || response.status === 201) {
      // Return formatted response for UI
      return {
        id: response.data.data?.id || Date.now(), // Use returned ID or temp ID
        scoreViewId: requestBody.scorecard_score_id,
        status: requestBody.action_item_status,
        assignedTo: actionItemData.assignedTo || "",
        assignedToId: requestBody.assigned_to,
        endDate: requestBody.end_date,
        finalScore: requestBody.final_score || 0,
        maxScore: actionItemData.maxScore || 0,
        subKpi: actionItemData.subKpi || "",
        strategicObjective: actionItemData.strategicObjective || "",
        createdBy: "You",
        createdDate: formatDateDisplay(new Date().toISOString()),
        createdAt: new Date().toISOString(),
        remarks: actionItemData.comments || "",
      };
    }

    throw new Error("Failed to add action item");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error adding action item:", error);
    throw error;
  }
};

/**
 * ✅ Update Scorecard Action Item
 * Update an existing action item
 * 
 * Backend accepts:
 * - id (required)
 * - scorecard_score_id (optional)
 * - assigned_to (optional) - User ID or null
 * - action_item_status (optional) - "Created", "In Progress", "Closed", "Completed"
 * - end_date (optional)
 * - final_score (optional)
 * - isActive (optional)
 * 
 * @param {Object} actionItemData - Action item data with id
 * @returns {Promise<Object>} Updated action item
 */
export const updateScorecardActionItem = async (actionItemData) => {
  try {
    if (!actionItemData.id) {
      throw new Error("Action Item ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.updateScorecardActionItem}`;

    // Prepare request body - match backend expected fields
    const requestBody = {
      id: actionItemData.id,
    };

    // Only include fields that are being updated
    if (actionItemData.scoreViewId !== undefined) {
      requestBody.scorecard_score_id = actionItemData.scoreViewId;
    }
    if (actionItemData.assignedToId !== undefined || actionItemData.assigned_to !== undefined) {
      requestBody.assigned_to = actionItemData.assignedToId || actionItemData.assigned_to;
    }
    if (actionItemData.status !== undefined || actionItemData.action_item_status !== undefined) {
      requestBody.action_item_status = actionItemData.status || actionItemData.action_item_status;
    }
    if (actionItemData.endDate !== undefined || actionItemData.end_date !== undefined) {
      requestBody.end_date = actionItemData.endDate || actionItemData.end_date;
    }
    if (actionItemData.finalScore !== undefined || actionItemData.final_score !== undefined) {
      requestBody.final_score = actionItemData.finalScore || actionItemData.final_score;
    }
    if (actionItemData.isActive !== undefined) {
      requestBody.isActive = actionItemData.isActive;
    }

    console.log("📤 Updating Action Item:", requestBody);

    const response = await axios.put(url, requestBody, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Action Item Updated:", response.data);

    if (response.status === 200) {
      return response.data.data || response.data;
    }

    throw new Error("Failed to update action item");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error updating action item:", error);
    throw error;
  }
};

/**
 * ✅ Delete Scorecard Action Item
 * Delete an action item by ID
 * 
 * @param {number} actionItemId - Action Item ID
 * @returns {Promise<boolean>} Success status
 */
export const deleteScorecardActionItem = async (actionItemId) => {
  try {
    if (!actionItemId) {
      throw new Error("Action Item ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.deleteScorecardActionItem}${actionItemId}`;

    console.log("📤 Deleting Action Item:", actionItemId);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Action Item Deleted:", response.data);

    return response.status === 200;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error deleting action item:", error);
    throw error;
  }
};

// ═══════════════════════════════════════════════════════════════
// 💬 SCORECARD ACTION LOG API FUNCTIONS (Responses/Comments)
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ Get Action Logs by Action Item ID
 * Fetch all logs/responses for a specific action item
 * 
 * @param {number} actionItemId - Action Item ID
 * @returns {Promise<Array>} Array of action logs
 */
export const getScorecardActionLogsByActionItemId = async (actionItemId) => {
  try {
    if (!actionItemId) {
      throw new Error("Action Item ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.getScorecardActionLogsByActionItemId}${actionItemId}`;

    console.log("📡 Fetching Action Logs by Action Item ID");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Action Logs fetched:", response.data);

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      // Debug: Log first record to see supporting_doc_url
      if (rawData.length > 0) {
        console.log("📋 Sample action log raw data:", {
          id: rawData[0].id,
          comments: rawData[0].comments,
          supporting_doc_url: rawData[0].supporting_doc_url,
          commented_by_name: rawData[0].commented_by_name,
        });
      }

      return rawData.map(item => ({
        id: item.id,
        actionItemId: item.action_item_id,
        commentedBy: item.commented_by,
        commentedByName: item.commented_by_name || "",
        commentedByEmail: item.commented_by_email || "",
        comments: item.comments || "",
        supportingDocUrl: item.supporting_doc_url || "",
        createdAt: item.created_at,
        createdDate: formatDateDisplay(item.created_at),
        updatedAt: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        // From joined action item
        scorecardScoreId: item.scorecard_score_id,
        actionItemStatus: item.action_item_status,
        endDate: item.end_date,
        finalScore: item.final_score,
        // For display
        systemUser: item.commented_by ? "User" : "System",
        details: `${formatDateDisplay(item.created_at)} By ${item.commented_by_name || "System"}`,
      }));
    }

    return [];
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error fetching action logs:", error);
    throw error;
  }
};

/**
 * ✅ Get First Log Comments by Action Item ID
 * Fetch the first log comment for a specific action item
 * 
 * @param {number} actionItemId - Action Item ID
 * @returns {Promise<Object>} First action log
 */
export const getFirstLogCommentsByActionItemId = async (actionItemId) => {
  try {
    if (!actionItemId) {
      throw new Error("Action Item ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.getFirstLogCommentsByActionItemId}${actionItemId}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.status === 200 && response.data.status) {
      const item = response.data.data;
      return {
        id: item.id,
        actionItemId: item.action_item_id,
        comments: item.comments || "",
        commentedByName: item.commented_by_name || "",
        commentedByEmail: item.commented_by_email || "",
        createdAt: item.created_at,
        createdDate: formatDateDisplay(item.created_at),
      };
    }

    return null;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error fetching first log:", error);
    throw error;
  }
};

/**
 * ✅ Add Scorecard Action Log
 * Add a new log/response to an action item (supports file upload)
 * 
 * @param {Object} logData - Log data with optional file
 * @returns {Promise<Object>} Created action log
 */
export const addScorecardActionLog = async (logData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.addScorecardActionLog}`;

    console.log("📤 Adding Action Log:", logData.actionItemId, logData.file ? `(with file: ${logData.file.name})` : "(no file)");

    let response;

    if (logData.file) {
      // Use FormData for file upload
      const formData = new FormData();
      formData.append("action_item_id", logData.actionItemId);
      formData.append("comments", logData.comments || "");
      formData.append("files", logData.file); // Backend expects 'files' field name

      console.log("📤 FormData contents:", {
        action_item_id: logData.actionItemId,
        comments: logData.comments,
        fileName: logData.file.name,
        fileSize: logData.file.size,
        fileType: logData.file.type,
      });

      // Don't set Content-Type for FormData - browser will set it with boundary
      response = await axios.post(url, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    } else {
      // Use JSON for no file
      response = await axios.post(url, {
        action_item_id: logData.actionItemId,
        comments: logData.comments || "",
      }, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
    }

    console.log("✅ Action Log Added:", response.data);

    if (response.status === 200 || response.status === 201) {
      return {
        success: true,
        message: response.data.message,
      };
    }

    throw new Error("Failed to add action log");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error adding action log:", error);
    throw error;
  }
};

/**
 * ✅ Update Scorecard Action Log
 * Update an existing action log
 * 
 * @param {Object} logData - Log data with id
 * @returns {Promise<Object>} Updated action log
 */
export const updateScorecardActionLog = async (logData) => {
  try {
    if (!logData.id) {
      throw new Error("Action Log ID is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.updateScorecardActionLog}`;

    // Use FormData if there's a file to upload
    let requestBody;
    let headers = {
      Authorization: `Bearer ${token}`,
    };

    if (logData.file) {
      requestBody = new FormData();
      requestBody.append("id", logData.id);
      if (logData.actionItemId) requestBody.append("action_item_id", logData.actionItemId);
      if (logData.comments) requestBody.append("comments", logData.comments);
      requestBody.append("file", logData.file);
    } else {
      requestBody = {
        id: logData.id,
        action_item_id: logData.actionItemId,
        comments: logData.comments,
      };
      headers["Content-Type"] = "application/json";
    }

    console.log("📤 Updating Action Log:", logData.id);

    const response = await axios.put(url, requestBody, { headers });

    console.log("✅ Action Log Updated:", response.data);

    if (response.status === 200) {
      return response.data.data || response.data;
    }

    throw new Error("Failed to update action log");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error updating action log:", error);
    throw error;
  }
};

/**
 * ✅ Delete Scorecard Action Log
 * Delete an action log by ID
 * 
 * @param {number} logId - Action Log ID
 * @returns {Promise<boolean>} Success status
 */
export const deleteScorecardActionLog = async (logId) => {
  try {
    if (!logId) {
      throw new Error("Action Log ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.deleteScorecardActionLog}${logId}`;

    console.log("📤 Deleting Action Log:", logId);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Action Log Deleted:", response.data);

    return response.status === 200;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error deleting action log:", error);
    throw error;
  }
};