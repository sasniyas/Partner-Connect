import axios from "axios";
import { API } from "../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 SCORECARD API SERVICES
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ FUNCTION 1: Add Scorecard
 * Create a new scorecard record
 * 
 * @param {Object} data - Scorecard data to create
 * @returns {Promise<Object>} Created scorecard response
 */
export const addScorecard = async (data) => {
  try {
    // Validate required fields
    if (!data.year) {
      throw new Error("Year is required");
    }
    if (!data.market_area_id) {
      throw new Error("Market Area is required");
    }
    if (!data.dealer_id) {
      throw new Error("Dealer is required");
    }
    if (!data.frequency) {
      throw new Error("Frequency is required");
    }
    if (!data.lead_auditor) {
      throw new Error("Lead Auditor is required");
    }
    if (!data.co_auditor) {
      throw new Error("Co Auditor is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.addScorecard}`;

    console.log("📡 Adding Scorecard");
    console.log("  URL:", url);
    console.log("  Input Data:", data);

    // Prepare data for API - match backend field names exactly
    const apiData = {
      year: data.year,
      market_area_id: parseInt(data.market_area_id),
      dealer_id: parseInt(data.dealer_id),
      frequency: data.frequency,
      quarter_frequency: data.frequency === "Annual" ? "Q4" : (data.quarter_frequency || data.quarter || null),
      audit_start_date: data.audit_start_date || null,
      audit_end_date: data.audit_end_date || null,
      physical_audit_start_date: data.physical_audit_start_date || null,
      physical_audit_end_date: data.physical_audit_end_date || null,
      lead_auditor: parseInt(data.lead_auditor),
      co_auditor: parseInt(data.co_auditor),
      audit_location: data.audit_location || null,
      branch: data.branch || null, // ⭐ Add branch field
      remarks: data.remarks || null,
      review_status: data.review_status || "Created"
    };

    console.log("📤 API Data being sent:", apiData);

    const response = await axios.post(url, apiData, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Add Scorecard Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200 || response.status === 201) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to add scorecard");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ addScorecard Error:", error.message);
    console.error("❌ Error details:", error.response?.data);

    

    throw new Error(error.response?.data?.message || error.message || "Failed to add scorecard");
  }
};

/**
 * ✅ FUNCTION 2: Update Scorecard
 * Update an existing scorecard record
 * 
 * @param {number} id - Scorecard ID to update
 * @param {Object} data - Updated scorecard data
 * @returns {Promise<Object>} Updated scorecard response
 */
export const updateScorecard = async (id, data) => {
  try {
    if (!id) {
      throw new Error("Scorecard ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.updateScorecard}`;

    console.log("📡 Updating Scorecard");
    console.log("  URL:", url);
    console.log("  ID:", id);
    console.log("  Input Data:", data);

    // Prepare data for API - include id in body as backend expects
    const apiData = {
      id: parseInt(id)
    };

    // Only include fields that are provided (backend handles partial updates)
    if (data.year !== undefined) apiData.year = data.year;
    if (data.market_area_id !== undefined) apiData.market_area_id = parseInt(data.market_area_id);
    if (data.dealer_id !== undefined) apiData.dealer_id = parseInt(data.dealer_id);
    if (data.frequency !== undefined) apiData.frequency = data.frequency;
    if (data.quarter_frequency !== undefined || data.quarter !== undefined) {
      apiData.quarter_frequency = data.quarter_frequency || data.quarter;
    }
    if (data.audit_start_date !== undefined) apiData.audit_start_date = data.audit_start_date;
    if (data.audit_end_date !== undefined) apiData.audit_end_date = data.audit_end_date;
    if (data.physical_audit_start_date !== undefined) apiData.physical_audit_start_date = data.physical_audit_start_date;
    if (data.physical_audit_end_date !== undefined) apiData.physical_audit_end_date = data.physical_audit_end_date;
    if (data.lead_auditor !== undefined) apiData.lead_auditor = parseInt(data.lead_auditor);
    if (data.co_auditor !== undefined) apiData.co_auditor = parseInt(data.co_auditor);
    if (data.audit_location !== undefined) apiData.audit_location = data.audit_location;
    if (data.branch !== undefined) apiData.branch = data.branch; // ⭐ Add branch field
    if (data.remarks !== undefined) apiData.remarks = data.remarks;
    if (data.review_status !== undefined) apiData.review_status = data.review_status;

    console.log("📤 API Data being sent:", apiData);

    const response = await axios.put(url, apiData, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Scorecard Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update scorecard");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ updateScorecard Error:", error.message);
    console.error("❌ Error details:", error.response?.data);

  
    throw new Error(error.response?.data?.message || error.message || "Failed to update scorecard");
  }
};

/**
 * ✅ FUNCTION 3: Get All Scorecards
 * Fetch all scorecard records with joined data
 * 
 * @returns {Promise<Array>} Array of scorecard records
 */
export const getAllScorecards = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.getAllScorecards}`;

    console.log("📡 Fetching All Scorecards");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Raw API Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      // Transform API response to frontend format
      const transformedData = rawData.map(item => ({
        id: item.id,
        year: item.year,
        marketAreaId: item.market_area_id,
        marketArea: item.market_area_name || "",
        dealerId: item.dealer_id,
        dealer: item.dealer_name || "",
        frequency: item.frequency,
        quarter: item.quarter_frequency,
        quarterFrequency: item.quarter_frequency,
        // Use formatDateDisplay for table display (DD/MM/YYYY in Kolkata timezone)
        auditStartDate: item.audit_start_date ? formatDateDisplay(item.audit_start_date) : "",
        auditEndDate: item.audit_end_date ? formatDateDisplay(item.audit_end_date) : "",
        physicalAuditStartDate: item.physical_audit_start_date ? formatDateDisplay(item.physical_audit_start_date) : "",
        physicalAuditEndDate: item.physical_audit_end_date ? formatDateDisplay(item.physical_audit_end_date) : "",
        // Keep raw dates for form inputs (YYYY-MM-DD format required by input type="date")
        auditStartDateRaw: item.audit_start_date ? formatDateInput(item.audit_start_date) : "",
        auditEndDateRaw: item.audit_end_date ? formatDateInput(item.audit_end_date) : "",
        physicalAuditStartDateRaw: item.physical_audit_start_date ? formatDateInput(item.physical_audit_start_date) : "",
        physicalAuditEndDateRaw: item.physical_audit_end_date ? formatDateInput(item.physical_audit_end_date) : "",
        leadAuditorId: item.lead_auditor,
        leadAuditor: item.lead_auditor_name || "",
        leadAuditorEmail: item.lead_auditor_email || "",
        coAuditorId: item.co_auditor,
        coAuditor: item.co_auditor_name || "",
        coAuditorEmail: item.co_auditor_email || "",
        auditLocation: item.audit_location || "",
        branch: item.branch || "", // ⭐ Add branch field
        remarks: item.remarks || "",
        reviewStatus: item.review_status || "Created",
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        createdAt: item.created_at,
        updatedAt: item.updated_at
      }));

      console.log("✅ Scorecards transformed:", transformedData.length, "records");
      if (transformedData.length > 0) {
        console.log("📦 Sample transformed data:", transformedData[0]);
      }

      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch scorecards");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getAllScorecards Error:", error.message);

   

    throw new Error(error.response?.data?.message || error.message || "Failed to fetch scorecards");
  }
};

/**
 * ✅ FUNCTION 4: Get Scorecard by ID
 * Fetch a single scorecard by ID
 * 
 * @param {number} id - Scorecard ID
 * @returns {Promise<Object>} Scorecard record
 */
export const getScorecardById = async (id) => {
  try {
    if (!id) {
      throw new Error("Scorecard ID is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.getScorecardById}${id}`;

    console.log("📡 Fetching Scorecard by ID");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Get Scorecard Response:", {
      status: response.status,
      hasData: !!response.data.data
    });

    if (response.status === 200 && response.data.status) {
      const item = response.data.data;

      // Transform to frontend format
      return {
        id: item.id,
        year: item.year,
        marketAreaId: item.market_area_id,
        marketArea: item.market_area_name || "",
        dealerId: item.dealer_id,
        dealer: item.dealer_name || "",
        frequency: item.frequency,
        quarter: item.quarter_frequency,
        quarterFrequency: item.quarter_frequency,
        // Use formatDateDisplay for display (DD/MM/YYYY in Kolkata timezone)
        auditStartDate: item.audit_start_date ? formatDateDisplay(item.audit_start_date) : "",
        auditEndDate: item.audit_end_date ? formatDateDisplay(item.audit_end_date) : "",
        physicalAuditStartDate: item.physical_audit_start_date ? formatDateDisplay(item.physical_audit_start_date) : "",
        physicalAuditEndDate: item.physical_audit_end_date ? formatDateDisplay(item.physical_audit_end_date) : "",
        // Keep raw dates for form inputs (YYYY-MM-DD format required by input type="date")
        auditStartDateRaw: item.audit_start_date ? formatDateInput(item.audit_start_date) : "",
        auditEndDateRaw: item.audit_end_date ? formatDateInput(item.audit_end_date) : "",
        physicalAuditStartDateRaw: item.physical_audit_start_date ? formatDateInput(item.physical_audit_start_date) : "",
        physicalAuditEndDateRaw: item.physical_audit_end_date ? formatDateInput(item.physical_audit_end_date) : "",
        leadAuditorId: item.lead_auditor,
        leadAuditor: item.lead_auditor_name || "",
        coAuditorId: item.co_auditor,
        coAuditor: item.co_auditor_name || "",
        auditLocation: item.audit_location || "",
        branch: item.branch || "", // ⭐ Add branch field
        remarks: item.remarks || "",
        reviewStatus: item.review_status || "Created",
        isActive: item.isActive,
        isDeleted: item.isDeleted
      };
    }

    throw new Error(response.data.message || "Failed to fetch scorecard");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getScorecardById Error:", error.message);

   
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch scorecard");
  }
};

/**
 * ✅ FUNCTION 5: Delete Scorecard (Soft Delete)
 * Soft delete a scorecard record
 * 
 * @param {number} id - Scorecard ID to delete
 * @returns {Promise<Object>} Delete response
 */
export const deleteScorecard = async (id) => {
  try {
    if (!id) {
      throw new Error("Scorecard ID is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.deleteScorecard}${id}`;

    console.log("📡 Deleting Scorecard");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Scorecard Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete scorecard");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ deleteScorecard Error:", error.message);

   
    throw new Error(error.response?.data?.message || error.message || "Failed to delete scorecard");
  }
};

/**
 * ✅ FUNCTION 6: Toggle Scorecard Status
 * Toggle active/inactive status
 * 
 * @param {number} id - Scorecard ID
 * @returns {Promise<Object>} Toggle response
 */
export const toggleScorecardStatus = async (id) => {
  try {
    if (!id) {
      throw new Error("Scorecard ID is required");
    }

   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.toggleScorecard}${id}`;

    console.log("📡 Toggling Scorecard Status");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.patch(url, {}, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Toggle Scorecard Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to toggle scorecard status");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ toggleScorecardStatus Error:", error.message);

   

    throw new Error(error.response?.data?.message || error.message || "Failed to toggle scorecard status");
  }
};

/**
 * ✅ FUNCTION 7: Get All Auditors (Users who can audit)
 * Fetch all users who can be auditors
 * 
 * @returns {Promise<Array>} Array of auditor records
 */
export const getAuditors = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.getAuditors || API.userManagement.getAllUsers}`;

    console.log("📡 Fetching Auditors");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Auditors Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200) {
      const rawData = response.data.data || response.data || [];

      // Transform to dropdown format - only active users
      const transformedData = rawData
        .filter(user => user.status === "ACTIVE")
        .map(user => ({
          id: user.id,
          label: `${user.firstName || ""} ${user.lastName || ""}`.trim(),
          value: `${user.firstName || ""} ${user.lastName || ""}`.trim(),
          email: user.email
        }));

      console.log("✅ Auditors transformed:", transformedData.length, "records");
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch auditors");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ getAuditors Error:", error.message);


    throw new Error(error.response?.data?.message || error.message || "Failed to fetch auditors");
  }
};

/**
 * ✅ FUNCTION 8: Complete Scorecard
 * Mark a scorecard as completed and automatically create Annual scorecard if Q4
 * 
 * Backend Logic:
 * - Updates current scorecard status to "Completed"
 * - If quarter_frequency is "Q4", automatically creates an "Annual" scorecard
 * - The Annual scorecard inherits all data from Q4 and is marked as "Completed"
 * 
 * @param {number} id - Scorecard ID to complete
 * @returns {Promise<Object>} Complete response
 */
export const completeScorecard = async (id) => {
  try {
    if (!id) {
      throw new Error("Scorecard ID is required");
    }

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.completeScorecard}${id}`;

    console.log("📡 Completing Scorecard");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.put(url, {}, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Complete Scorecard Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to complete scorecard");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ completeScorecard Error:", error.message);

    

    throw new Error(error.response?.data?.message || error.message || "Failed to complete scorecard");
  }
};

/**
 * ✅ FUNCTION 9: Bulk Complete Scorecards
 * Complete all Q4 scorecards and automatically create Annual scorecards for all dealers
 * 
 * Backend Logic:
 * - Fetches all Q4 scorecards that are not completed
 * - Creates Annual scorecards for each Q4 (if not already exists)
 * - Updates all Q4 scorecards to "Completed" status
 * 
 * @returns {Promise<Object>} Bulk complete response with counts
 */
export const bulkCompleteScorecard = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.scorecardEndpoints.bulkCompleteScorecard}`;

    console.log("📡 Bulk Completing Scorecards");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Bulk Complete Scorecards Response:", {
      status: response.status,
      message: response.data.message,
      data: response.data.data
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to bulk complete scorecards");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ bulkCompleteScorecard Error:", error.message);

    

    throw new Error(error.response?.data?.message || error.message || "Failed to bulk complete scorecards");
  }
};

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Format date for DISPLAY (DD/MM/YYYY) in Kolkata timezone
 * Use this for tables, labels, and read-only displays
 * 
 * Example:
 *   Input:  "2024-12-15T00:00:00.000Z"
 *   Output: "15/12/2024"
 * 
 * @param {string} dateString - Date string from API
 * @returns {string} Formatted date in DD/MM/YYYY format (Kolkata timezone)
 */
const formatDateDisplay = (dateString) => {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);
    
    // Check if date is valid
    if (isNaN(date.getTime())) {
      return dateString;
    }
    
    // Format in Kolkata timezone (Asia/Kolkata) as DD/MM/YYYY
    return date.toLocaleDateString('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  } catch {
    return dateString;
  }
};

/**
 * Format date for INPUT fields (YYYY-MM-DD) in Kolkata timezone
 * Use this for <input type="date"> fields which require YYYY-MM-DD format
 * 
 * Example:
 *   Input:  "2024-12-15T00:00:00.000Z"
 *   Output: "2024-12-15"
 * 
 * @param {string} dateString - Date string from API
 * @returns {string} Formatted date in YYYY-MM-DD format (Kolkata timezone)
 */
const formatDateInput = (dateString) => {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);
    
    // Check if date is valid
    if (isNaN(date.getTime())) {
      return dateString;
    }
    
    // Convert to Kolkata timezone and format as YYYY-MM-DD
    // Using 'en-CA' locale which naturally outputs YYYY-MM-DD format
    return date.toLocaleDateString('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
  } catch {
    return dateString;
  }
};