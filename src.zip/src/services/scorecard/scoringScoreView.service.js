import axios from "axios";
import { API } from "../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 SCORING PAGE API SERVICES
// ═══════════════════════════════════════════════════════════════

/**
 * ✅ FUNCTION 1: Get All Scorecard Score Views
 * Fetch all score views across all scorecards (for Scoring page)
 * 
 * @returns {Promise<Array>} Array of all score view records
 */
export const getAllScorecardScoreViews = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}/getAllScorecardScoreViews`;

    console.log("📡 Fetching All Scorecard Score Views");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ All Score Views Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      // Transform API response to frontend format
      const transformedData = rawData.map((item, index) => ({
        // Primary identifiers
        id: item.id,
        rowId: `${item.id}-${index}`, // Unique identifier for React keys
        subKpiId: item.sub_kpi_id,
        scorecardId: item.scorecard_id,

        // Score view fields
        reviewerScore: item.reviewer_score,
        reviewerId: item.reviewer,
        reviewerName: item.reviewer_name || "",
        reviewerEmail: item.reviewer_email || "",
        isScored: item.isScored === 1,
        scored: item.isScored === 1 ? "Yes" : "No",
        isExcluded: item.isExcluded === 1,
        excluded: item.isExcluded === 1,
        remarks: item.remarks || "",
        supportingDoc: item.supporting_doc,
        uploadedBy: item.uploaded_by,
        uploadedByName: item.uploaded_by_name || "",
        uploadedByEmail: item.uploaded_by_email || "",
        uploadedOn: item.uploaded_on,
        finalScore: item.final_score,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        createdAt: item.created_at,
        updatedAt: item.updated_at,

        // Sub KPI fields
        kpiNo: item.sub_kpi_kpiNumber || "",
        strategicObjective: item.sub_kpi_objectiveName || "",
        kpi: item.sub_kpi_kpiName || "",
        subKpi: item.sub_kpi_subKpiName || "",
        subKpiName: item.sub_kpi_subKpiName || "",
        assessmentPeriod: item.sub_kpi_assessmentPeriod || "",
        minScore: parseFloat(item.minScore) || parseFloat(item.sub_kpi_minScore) || 0,
        maxScore: parseFloat(item.maxScore) || parseFloat(item.sub_kpi_maxScore) || 0,
        threshold: parseFloat(item.minScore) || parseFloat(item.sub_kpi_minScore) || 0,
        formula: item.formula || null,  // ⭐ NEW: Formula from database
        scoringCriteria: item.sub_kpi_scoringCriteria || "",
        measurement: item.sub_kpi_measurement || "",
        annualScore: item.sub_kpi_annualScore || "",
        annualScoringCriteria: item.sub_kpi_annualScoringCriteria || "",
        criteriaDefinition: item.sub_kpi_criteriaDefinition || "",
        dataSource: item.sub_kpi_dataSource || "",
        subKpiCreatedYear: item.sub_kpi_createdYear,
        subKpiObjectiveId: item.sub_kpi_objectiveId,
        subKpiKpiId: item.sub_kpi_kpiId,
        subKpiDocStatus: item.sub_kpi_docStaus,
        subKpiDoc: item.sub_kpi_doc,

        // Scorecard fields
        year: String(item.scorecard_year || ""),
        quarter: item.scorecard_quarter_frequency || "",
        frequency: item.scorecard_frequency || "",
        auditLocation: item.scorecard_audit_location || "",
        branch: item.scorecard_branch || "",

        // Dealer fields
        dealerId: item.dealer_id,
        dealer: item.dealer_name?.trim() || "",

        // For table display
        scorecardYear: item.scorecard_year,
        scorecardFrequency: item.scorecard_frequency,
        scorecardQuarter: item.scorecard_quarter_frequency,
        scorecardAuditLocation: item.scorecard_audit_location,
        scorecardBranch: item.scorecard_branch,

        // Reviewer display
        reviewer: item.reviewer_name || "—",

        // Documents placeholder
        documents: [],
      }));

      console.log("✅ All Score Views transformed:", transformedData.length, "records");
      if (transformedData.length > 0) {
        console.log("📦 Sample transformed data:", transformedData[0]);
      }

      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch score views");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("❌ getAllScorecardScoreViews Error:", error.message);



    throw new Error(error.response?.data?.message || error.message || "Failed to fetch score views");
  }
};

/**
 * ✅ FUNCTION 2: Update Scorecard Score View
 * Update a score view record (reviewer score, remarks, excluded, final score)
 * 
 * Backend expects: id (scorecard_scoreview primary key)
 * 
 * @param {Object} data - Score view data to update
 * @returns {Promise<Object>} Updated score view response
 */
export const updateScorecardScoreView = async (data) => {
  try {
    // Need id (scorecard_scoreview primary key)
    if (!data.id) {
      throw new Error("Score View ID is required");
    }

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}/updateScorecardScoreView`;

    console.log("📡 Updating Scorecard Score View");
    console.log("  URL:", url);
    console.log("  Input Data:", data);

    // Prepare data for API - backend expects 'id' as scorecard_scoreview primary key
    const apiData = {
      id: parseInt(data.id),
    };

    // Only include fields that are provided
    if (data.sub_kpi_id !== undefined) apiData.sub_kpi_id = parseInt(data.sub_kpi_id);
    if (data.subKpiId !== undefined) apiData.sub_kpi_id = parseInt(data.subKpiId);
    if (data.scorecard_id !== undefined) apiData.scorecard_id = parseInt(data.scorecard_id);
    if (data.scorecardId !== undefined) apiData.scorecard_id = parseInt(data.scorecardId);
    if (data.reviewer_score !== undefined) apiData.reviewer_score = data.reviewer_score;
    if (data.reviewerScore !== undefined) apiData.reviewer_score = data.reviewerScore;
    if (data.reviewer !== undefined) apiData.reviewer = parseInt(data.reviewer);
    if (data.reviewerId !== undefined) apiData.reviewer = parseInt(data.reviewerId);
    if (data.isScored !== undefined) apiData.isScored = data.isScored ? 1 : 0;
    if (data.isExcluded !== undefined) apiData.isExcluded = data.isExcluded ? 1 : 0;
    if (data.excluded !== undefined) apiData.isExcluded = data.excluded ? 1 : 0;
    if (data.remarks !== undefined) apiData.remarks = data.remarks;
    if (data.final_score !== undefined) apiData.final_score = data.final_score;
    if (data.finalScore !== undefined) apiData.final_score = data.finalScore;

    console.log("📤 API Data being sent:", apiData);

    const response = await axios.put(url, apiData, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Score View Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update score view");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("❌ updateScorecardScoreView Error:", error.message);
    console.error("❌ Error details:", error.response?.data);



    throw new Error(error.response?.data?.message || error.message || "Failed to update score view");
  }
};

/**
 * ✅ FUNCTION 3: Bulk Toggle Scorecard Score View Exclusion
 * Toggle exclusion status for multiple score views at once
 * 
 * @param {number} scorecardId - Scorecard ID
 * @param {Array} ids - Array of score_view ids to toggle
 * @param {boolean} isExcluded - New exclusion status
 * @returns {Promise<Object>} Bulk update response
 */
export const bulkToggleScorecardScoreViewExclusion = async (scorecardId, ids, isExcluded) => {
  try {
    if (!scorecardId) {
      throw new Error("Scorecard ID is required");
    }

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}/bulkToggleScorecardScoreViewExclusion`;

    // Clean and validate IDs
    const cleanedIds = (ids || [])
      .filter(id => id !== null && id !== undefined && id !== '' && id !== 0)
      .map(id => parseInt(id))
      .filter(id => !isNaN(id) && id > 0);

    console.log("📡 Bulk Toggling Score View Exclusion");
    console.log("  URL:", url);
    console.log("  Scorecard ID:", scorecardId);
    console.log("  Score View IDs to exclude:", cleanedIds);
    console.log("  isExcluded:", isExcluded);

    const apiData = {
      scorecard_id: parseInt(scorecardId),
      ids: isExcluded ? cleanedIds : [],
    };

    console.log("  API Data:", JSON.stringify(apiData));

    const response = await axios.put(url, apiData, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Bulk Toggle Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to bulk toggle exclusion");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("❌ bulkToggleScorecardScoreViewExclusion Error:", error.message);



    throw new Error(error.response?.data?.message || error.message || "Failed to bulk toggle exclusion");
  }
};

/**
 * ✅ FUNCTION 4: Get Scorecard Score View Docs by Scorecard ID
 */
export const getScorecardScoreViewDocsByScorecardId = async (scorecardId) => {
  try {
    if (!scorecardId) {
      throw new Error("Scorecard ID is required");
    }

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}/getScorecardScoreViewDocsByScorecardId/${scorecardId}`;

    console.log("📡 Fetching Scorecard Score View Docs");
    console.log("  URL:", url);
    console.log("  Scorecard ID:", scorecardId);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Score View Docs Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      const transformedData = rawData.map(item => ({
        id: item.id,
        scorecardId: item.scorecard_id,
        uploadedBy: item.uploaded_by,
        uploadedByName: item.uploaded_by_name || "Unknown",
        uploadedByEmail: item.uploaded_by_email || "",
        docUrl: item.doc_url,
        name: extractFileName(item.doc_url),
        date: formatDateDisplay(item.created_at),
        createdAt: item.created_at,
        updatedAt: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        scorecardYear: item.scorecard_year,
        scorecardFrequency: item.scorecard_frequency,
        scorecardQuarter: item.scorecard_quarter_frequency,
        scorecardAuditLocation: item.scorecard_audit_location,
        scorecardBranch: item.scorecard_branch,
      }));

      console.log("✅ Score View Docs transformed:", transformedData.length, "records");
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch score view docs");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("❌ getScorecardScoreViewDocsByScorecardId Error:", error.message);



    throw new Error(error.response?.data?.message || error.message || "Failed to fetch score view docs");
  }
};

/**
 * ✅ FUNCTION 5: Add Scorecard Score View Doc
 */
export const addScorecardScoreViewDoc = async (data) => {
  try {
    if (!data.scorecard_id && !data.scorecardId) {
      throw new Error("Scorecard ID is required");
    }

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}/addScorecardScoreViewDoc`;

    console.log("📡 Adding Scorecard Score View Doc");
    console.log("  URL:", url);

    const formData = new FormData();
    formData.append("scorecard_id", data.scorecard_id || data.scorecardId);

    if (data.uploaded_by || data.uploadedBy) {
      formData.append("uploaded_by", data.uploaded_by || data.uploadedBy);
    }

    if (data.file) {
      formData.append("doc", data.file);
    } else if (data.doc_url || data.docUrl) {
      formData.append("doc_url", data.doc_url || data.docUrl);
    }

    console.log("📤 Uploading document for scorecard:", data.scorecard_id || data.scorecardId);

    const response = await axios.post(url, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Add Score View Doc Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200 || response.status === 201) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to add document");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("❌ addScorecardScoreViewDoc Error:", error.message);
    console.error("❌ Error details:", error.response?.data);


    throw new Error(error.response?.data?.message || error.message || "Failed to add document");
  }
};

/**
 * ✅ FUNCTION 6: Delete Scorecard Score View Doc
 */
export const deleteScorecardScoreViewDoc = async (docId) => {
  try {
    if (!docId) {
      throw new Error("Document ID is required");
    }

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}/deleteScorecardScoreViewDoc/${docId}`;

    console.log("📡 Deleting Scorecard Score View Doc");
    console.log("  URL:", url);
    console.log("  Document ID:", docId);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Score View Doc Response:", {
      status: response.status,
      message: response.data.message
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete document");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {

      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("❌ deleteScorecardScoreViewDoc Error:", error.message);



    throw new Error(error.response?.data?.message || error.message || "Failed to delete document");
  }
};

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

const extractFileName = (url) => {
  if (!url) return "Unknown File";
  try {
    const parts = url.split("/");
    const fileName = parts[parts.length - 1];
    return decodeURIComponent(fileName) || "Unknown File";
  } catch {
    return "Unknown File";
  }
};

const formatDateDisplay = (dateString) => {
  if (!dateString) return "";
  try {
    let date;

    if (typeof dateString === 'string') {
      let cleanDateString = dateString.replace('Z', '').trim();
      if (cleanDateString.includes('T')) {
        date = new Date(cleanDateString + 'Z');
      } else {
        date = new Date(dateString);
      }
    } else {
      date = new Date(dateString);
    }

    if (isNaN(date.getTime())) return dateString;

    const day = date.getDate();
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const month = monthNames[date.getMonth()];
    const year = date.getFullYear();
    let hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;

    return `${day} ${month},${year} ${hours}:${minutes} ${ampm}`;
  } catch {
    return dateString;
  }
};

export const getUniqueFilterOptions = (data, field) => {
  const values = data.map(item => item[field]).filter(Boolean);
  return [...new Set(values)].sort();
};

/**
 * ⭐ Calculate final score based on measurement type and formula
 * - If formula is provided from API/Database, use it
 * - If formula is null, use hardcoded default formula
 * - Absolute: Final Score = Reviewer Score
 * - Percentage: Final Score calculated using formula steps
 */
export const calculateFinalScore = (reviewerScore, maxScore, measurement, formula = null) => {
  if (reviewerScore === null || reviewerScore === undefined || reviewerScore === '' || isNaN(reviewerScore)) {
    return "";
  }

  // Default hardcoded formula (used when API formula is null)
  const defaultFormula = {
    "steps": [
      { "expression": "percentage <20", "then": 3 },
      { "expression": "percentage <30", "then": 5 },
      { "expression": "percentage >50", "then": 8 },
      { "expression": "percentage >80", "then": 10 }
    ]
  };

  function evaluateExpression(expression, context) {
    const operators = {
      "<": (a, b) => a < b,
      "<=": (a, b) => a <= b,
      ">": (a, b) => a > b,
      ">=": (a, b) => a >= b,
      "==": (a, b) => a === b
    };

    // Split compound expressions by &&
    const conditions = expression.split("&&").map(c => c.trim());

    return conditions.every(condition => {
      const match = condition.match(/(\w+)\s*(<=|>=|<|>|==)\s*(\d+(\.\d+)?)/);
      if (!match) return false;

      const [, variable, operator, value] = match;
      return operators[operator](context[variable], Number(value));
    });
  }


  function executeSteps(percentage, formulaToUse) {
    let parsedFormula;

    // Parse formula if it's a string from database/API, or use as-is if object
    if (typeof formulaToUse === 'string') {
      try {
        parsedFormula = JSON.parse(formulaToUse);
      } catch (e) {
        console.warn("Failed to parse formula, using default:", e);
        parsedFormula = defaultFormula;
      }
    } else if (formulaToUse && typeof formulaToUse === 'object') {
      parsedFormula = formulaToUse;
    } else {
      parsedFormula = defaultFormula;
    }

    // Ensure steps array exists
    const steps = parsedFormula?.steps || defaultFormula.steps;

    for (const step of steps) {
      if (evaluateExpression(step.expression, { percentage })) {
        return step.then; // Stop at first match
      }
    }

    return 0; // No match found
  }

  const rv = parseFloat(reviewerScore);

  if (isNaN(rv)) return "";

  const measurementType = (measurement || "").toLowerCase();

  if (measurementType === "percentage" || measurementType === "%") {
    // Percentage: Use formula (from API/Database or default)
    const formulaToUse = formula || defaultFormula;
    const finalScore = executeSteps(rv, formulaToUse);
    return finalScore.toFixed(2);
  } else {
    // Absolute: Final Score = Reviewer Score (directly)
    return rv.toFixed(2);
  }
};
