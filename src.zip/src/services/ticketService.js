import axios from "axios"
import { API } from "../api"

export const addTicket = async (ticketData, files = []) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    let response;

    if (files && files.length > 0) {
      // Use multipart/form-data when files are present
      const formData = new FormData()
      formData.append("ticket_subject", ticketData.ticket_subject)
      formData.append("issue", ticketData.issue)
      formData.append("priority", ticketData.priority)
      if (ticketData.description) formData.append("description", ticketData.description)
      if (ticketData.expected_resolution_date) formData.append("expected_resolution_date", ticketData.expected_resolution_date)

      for (const file of files) {
        formData.append("files", file)
      }

      response = await axios.post(
        `${API.domain}/addTicket`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
        }
      )
    } else {
      // Use JSON when no files
      response = await axios.post(
        `${API.domain}/addTicket`,
        ticketData,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      )
    }

    if (response.status === 200 && response.data.status) {
      return response.data.data
    }

    throw new Error(response.data?.message || "Failed to add ticket")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error adding ticket:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to add ticket")
  }
}

export const getAllTickets = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    const response = await axios.get(
      `${API.domain}/getAllTickets`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data.data || []
    }

    throw new Error(response.data?.message || "Failed to fetch tickets")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error fetching all tickets:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch tickets")
  }
}

export const getTicketByUserId = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    const response = await axios.get(
      `${API.domain}/getTicketByUserId`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data.data || []
    }

    throw new Error(response.data?.message || "Failed to fetch user tickets")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error fetching user tickets:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch user tickets")
  }
}

export const getTicketById = async (id) => {
  try {
    if (!id) {
      throw new Error("Ticket ID is required")
    }

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    const response = await axios.get(
      `${API.domain}/getTicketById/${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data.data
    }

    throw new Error(response.data?.message || "Failed to fetch ticket")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error fetching ticket:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch ticket")
  }
}

export const updateTicket = async (ticketData) => {
  try {
    if (!ticketData.id) {
      throw new Error("Ticket ID is required")
    }

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    const response = await axios.put(
      `${API.domain}/updateTicket`,
      ticketData,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data
    }

    throw new Error(response.data?.message || "Failed to update ticket")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error updating ticket:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to update ticket")
  }
}

export const deleteTicket = async (id) => {
  try {
    if (!id) {
      throw new Error("Ticket ID is required")
    }

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    const response = await axios.delete(
      `${API.domain}/deleteTicket/${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data
    }

    throw new Error(response.data?.message || "Failed to delete ticket")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error deleting ticket:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to delete ticket")
  }
}

export const toggleTicketStatus = async (id) => {
  try {
    if (!id) {
      throw new Error("Ticket ID is required")
    }

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    const response = await axios.patch(
      `${API.domain}/toggleTicketStatus/${id}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data
    }

    throw new Error(response.data?.message || "Failed to toggle ticket status")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error toggling ticket status:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle ticket status")
  }
}

// ==================== COMMENT SERVICES ====================

export const addTicketComment = async (ticketId, commentData, files = []) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    let response;

    if (files && files.length > 0) {
      // Use multipart/form-data when files are present
      const formData = new FormData()
      formData.append("ticket_id", ticketId)
      formData.append("comment", commentData.comment)

      for (const file of files) {
        formData.append("files", file)
      }

      response = await axios.post(
        `${API.domain}/addTicketComment`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
        }
      )
    } else {
      // Use JSON when no files
      const payload = {
        ticket_id: ticketId,
        comment: commentData.comment,
      }

      response = await axios.post(
        `${API.domain}/addTicketComment`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      )
    }

    if (response.status === 200 && response.data.status) {
      return response.data.data
    }

    throw new Error(response.data?.message || "Failed to add comment")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error adding comment:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to add comment")
  }
}

export const getCommentsByTicketId = async (ticketId) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    const response = await axios.get(
      `${API.domain}/getCommentsByTicketId/${ticketId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data.data || []
    }

    throw new Error(response.data?.message || "Failed to fetch comments")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error fetching comments:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch comments")
  }
}

export const updateTicketComment = async (commentId, commentData) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    const payload = {
      id: commentId,
      comment: commentData.comment,
    }

    const response = await axios.put(
      `${API.domain}/updateTicketComment`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data
    }

    throw new Error(response.data?.message || "Failed to update comment")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error updating comment:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to update comment")
  }
}

export const deleteTicketComment = async (commentId) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) {
      throw new Error("No authentication token found")
    }

    const response = await axios.delete(
      `${API.domain}/deleteTicketComment/${commentId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data
    }

    throw new Error(response.data?.message || "Failed to delete comment")
  } catch (error) {
    const message = error.response?.data?.message

    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }

    console.error("Error deleting comment:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to delete comment")
  }
}

// ==================== ATTACHMENT SERVICES ====================

export const addTicketAttachment = async (ticketId, file) => {
  try {
    if (!ticketId) throw new Error("Ticket ID is required")
    if (!file) throw new Error("File is required")

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) throw new Error("No authentication token found")

    const formData = new FormData()
    formData.append("ticket_id", ticketId)
    formData.append("files", file)

    const response = await axios.post(
      `${API.domain}/addTicketAttachment`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data.data
    }

    throw new Error(response.data?.message || "Failed to upload attachment")
  } catch (error) {
    const message = error.response?.data?.message
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }
    console.error("Error uploading attachment:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to upload attachment")
  }
}

export const getAttachmentsByTicketId = async (ticketId) => {
  try {
    if (!ticketId) throw new Error("Ticket ID is required")

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) throw new Error("No authentication token found")

    const response = await axios.get(
      `${API.domain}/getAttachmentsByTicketId/${ticketId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data.data || []
    }

    throw new Error(response.data?.message || "Failed to fetch attachments")
  } catch (error) {
    const message = error.response?.data?.message
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }
    console.error("Error fetching attachments:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch attachments")
  }
}

export const deleteTicketAttachment = async (attachmentId) => {
  try {
    if (!attachmentId) throw new Error("Attachment ID is required")

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) throw new Error("No authentication token found")

    const response = await axios.delete(
      `${API.domain}/deleteTicketAttachment/${attachmentId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data
    }

    throw new Error(response.data?.message || "Failed to delete attachment")
  } catch (error) {
    const message = error.response?.data?.message
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }
    console.error("Error deleting attachment:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to delete attachment")
  }
}