// services/Masters/State/state.service.js

import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Helper function to get auth token
 */
const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

/**
 * Helper function to handle token errors
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ═══════════════════════════════════════════════════════════════
// 📊 STATE CRUD OPERATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Get All States (raw data from getStates endpoint)
 */
export const getAllStates = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getStates}`;

    console.log("📡 Fetching States");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ States Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0,
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllStates Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch States"
    );
  }
};

/**
 * Get All States Formatted for Table
 */
export const getAllStatesFormatted = async () => {
  try {
    const data = await getAllStates();
    return data.map((item) => ({
      id: item.id,
      marketarea_id: item.marketarea_id,
      area: item.marketAreaName,
      state: item.stateName,
      status: item.isActive === 1 ? "Active" : "Inactive",
      isActive: item.isActive,
      createdOn: item.createdOn,
    }));
  } catch (error) {
    console.error("❌ getAllStatesFormatted Error:", error.message);
    throw error;
  }
};

/**
 * Get Active States (for dropdowns)
 */
export const getActiveStates = async () => {
  try {
    const data = await getAllStates();
    return data.filter((state) => state.isActive === 1);
  } catch (error) {
    console.error("❌ getActiveStates Error:", error.message);
    throw error;
  }
};

/**
 * Get All States List (from getAllStates endpoint - for dropdown selection)
 */
export const getAllStatesList = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getAllStates}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllStatesList Error:", error.message);
    throw error;
  }
};

/**
 * Add New State
 * @param {Object} payload - { marketarea_id, stateName }
 */
export const addState = async (payload) => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.addState}`;

    console.log("📡 Adding State");

    const response = await axios.post(url, payload, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Add State Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ addState Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add State"
    );
  }
};

/**
 * Update State
 * @param {Object} payload - { id, marketarea_id, stateName }
 */
export const updateState = async (payload) => {
  try {
    const { id, ...updateData } = payload;

    if (!id) {
      throw new Error("State ID is required for update");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.updateState}`;

    console.log("📡 Updating State ID:", id);

    const response = await axios.put(
      url,
      { id, ...updateData },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Update State Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ updateState Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update State"
    );
  }
};

/**
 * Delete State by ID
 */
export const deleteState = async (id) => {
  try {
    if (!id) {
      throw new Error("State ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.deleteState}/${id}`;

    console.log("📡 Deleting State ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete State Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ deleteState Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete State"
    );
  }
};

/**
 * Toggle State Status by ID (Activate/Deactivate)
 */
export const toggleStateStatus = async (id) => {
  try {
    if (!id) {
      throw new Error("State ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.toggleState}/${id}`;

    console.log("📡 Toggling State Status ID:", id);

    const response = await axios.patch(
      url,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Toggle State Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ toggleStateStatus Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle State status"
    );
  }
};

/**
 * Bulk Add States
 * @param {Array} states - Array of { marketarea_id, stateName }
 */
export const bulkAddStates = async (states) => {
  try {
    if (!states || !Array.isArray(states) || states.length === 0) {
      throw new Error("States array is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.bulkAddState}`;

    console.log("📡 Bulk Adding States:", states.length);

    const response = await axios.post(
      url,
      { rows: states },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Bulk Add States Response:", {
      status: response.status,
      inserted: response.data.data?.inserted,
      invalid: response.data.data?.invalid,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ bulkAddStates Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add States"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📊 MARKET AREA OPERATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Get All Market Areas
 */
export const getAllMarketAreas = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getMarketarea}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllMarketAreas Error:", error.message);
    throw error;
  }
};

/**
 * Get Active Market Areas (for dropdowns)
 */
export const getActiveMarketAreas = async () => {
  try {
    const data = await getAllMarketAreas();
    return data.filter((area) => area.isActive === 1);
  } catch (error) {
    console.error("❌ getActiveMarketAreas Error:", error.message);
    throw error;
  }
};

// ═══════════════════════════════════════════════════════════════
// 🔧 VALIDATION HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Check if State exists (for duplicate validation) - Using ID
 * @param {Array} states - Current states data
 * @param {string} area - Market area name
 * @param {string} stateName - State name
 * @param {number|null} excludeId - ID to exclude (for edit mode)
 */
export const checkStateExists = (states, area, stateName, excludeId = null) => {
  return states.some((item) => {
    // Skip the current item being edited (by ID)
    if (excludeId !== null && item.id === excludeId) {
      return false;
    }
    return (
      item.area?.toLowerCase() === area?.toLowerCase() &&
      item.state?.toLowerCase() === stateName?.trim().toLowerCase()
    );
  });
};

/**
 * Check if State Name exists (stateName only, for stricter duplicate check)
 * @param {Array} states - Current states data
 * @param {string} stateName - State name
 * @param {number|null} excludeId - ID to exclude (for edit mode)
 */
export const checkStateNameExists = (states, stateName, excludeId = null) => {
  return states.some((item) => {
    if (excludeId !== null && item.id === excludeId) {
      return false;
    }
    return item.state?.toLowerCase() === stateName?.trim().toLowerCase();
  });
};

/**
 * Check duplicates in uploaded data against existing database
 * @param {Array} uploadedRows - Rows from uploaded file
 * @param {Array} existingStates - Existing states from database
 * @returns {Object} - { updatedRows, duplicateCount }
 */
export const checkDuplicatesInUpload = (uploadedRows, existingStates) => {
  // Create a Set of existing state names (stateName only)
  const existingStateNames = new Set();
  existingStates.forEach((item) => {
    existingStateNames.add((item.stateName || item.state || "").toLowerCase());
  });

  const seenInFile = new Set();

  const updatedRows = uploadedRows.map((row) => {
    if (row.hasError) return row;

    const stateKey = row.stateName.toLowerCase();

    let isDuplicate = false;
    let duplicateReason = "";

    if (!row.marketarea_id || !row.stateName) {
      return {
        ...row,
        hasError: true,
        isDuplicate: false,
        duplicateReason: "",
      };
    }

    // Check if state name exists in database
    if (existingStateNames.has(stateKey)) {
      isDuplicate = true;
      duplicateReason = "State already exists in database";
    }

    // Check if duplicate state name within file
    if (seenInFile.has(stateKey) && !isDuplicate) {
      isDuplicate = true;
      duplicateReason = "Duplicate state within file";
    }

    seenInFile.add(stateKey);

    return { ...row, isDuplicate, duplicateReason };
  });

  const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

  return { updatedRows, duplicateCount };
};

/**
 * Find State by ID
 */
export const findStateById = (states, id) => {
  return states.find((state) => state.id === id) || null;
};

/**
 * Get Market Area ID by Name
 */
export const getMarketAreaIdByName = (marketAreas, name) => {
  const area = marketAreas.find(
    (a) => a.marketarea.toLowerCase() === name.toLowerCase()
  );
  return area?.id || null;
};

/**
 * Get Market Area Name by ID
 */
export const getMarketAreaNameById = (marketAreas, id) => {
  const area = marketAreas.find((a) => a.id === id);
  return area?.marketarea || null;
};