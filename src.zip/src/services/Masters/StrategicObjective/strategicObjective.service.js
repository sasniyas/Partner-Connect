// services/Masters/StrategicObjective/strategicObjective.service.js

import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Helper function to get auth token
 */
const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

/**
 * Helper function to handle token errors
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ═══════════════════════════════════════════════════════════════
// 📊 STRATEGIC OBJECTIVE CRUD OPERATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Get All Strategic Objectives (raw data)
 */
export const getAllStrategicObjectives = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getStrategicObjectives}`;

    console.log("📡 Fetching Strategic Objectives");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Strategic Objectives Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0,
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllStrategicObjectives Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch Strategic Objectives"
    );
  }
};

/**
 * Get All Strategic Objectives Formatted for Table
 */
export const getAllStrategicObjectivesFormatted = async () => {
  try {
    const data = await getAllStrategicObjectives();
    return data.map((obj) => ({
      id: obj.id,
      name: obj.objectiveName,
      status: obj.isActive === 1 ? "Active" : "Inactive",
      isActive: obj.isActive,
      createdOn: obj.createdOn,
    }));
  } catch (error) {
    console.error("❌ getAllStrategicObjectivesFormatted Error:", error.message);
    throw error;
  }
};

/**
 * Get Active Strategic Objectives (for dropdowns)
 */
export const getActiveStrategicObjectives = async () => {
  try {
    const data = await getAllStrategicObjectives();
    return data
      .filter((obj) => obj.isActive === 1)
      .map((obj) => ({ id: obj.id, name: obj.objectiveName }));
  } catch (error) {
    console.error("❌ getActiveStrategicObjectives Error:", error.message);
    throw error;
  }
};

/**
 * Add New Strategic Objective
 * @param {Object} payload - { objectiveName }
 */
export const addStrategicObjective = async (payload) => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.addStrategicObjective}`;

    console.log("📡 Adding Strategic Objective");

    const response = await axios.post(url, payload, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Add Strategic Objective Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ addStrategicObjective Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add Strategic Objective"
    );
  }
};

/**
 * Update Strategic Objective
 * @param {Object} payload - { id, objectiveName }
 */
export const updateStrategicObjective = async (payload) => {
  try {
    const { id, ...updateData } = payload;

    if (!id) {
      throw new Error("Strategic Objective ID is required for update");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.updateStrategicObjective}`;

    console.log("📡 Updating Strategic Objective ID:", id);

    const response = await axios.put(
      url,
      { id, ...updateData },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Update Strategic Objective Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ updateStrategicObjective Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update Strategic Objective"
    );
  }
};

/**
 * Delete Strategic Objective by ID
 */
export const deleteStrategicObjective = async (id) => {
  try {
    if (!id) {
      throw new Error("Strategic Objective ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.deleteStrategicObjective}/${id}`;

    console.log("📡 Deleting Strategic Objective ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Strategic Objective Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ deleteStrategicObjective Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete Strategic Objective"
    );
  }
};

/**
 * Toggle Strategic Objective Status by ID (Activate/Deactivate)
 */
export const toggleStrategicObjectiveStatus = async (id) => {
  try {
    if (!id) {
      throw new Error("Strategic Objective ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.toggleStrategicObjective}/${id}`;

    console.log("📡 Toggling Strategic Objective Status ID:", id);

    const response = await axios.patch(
      url,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Toggle Strategic Objective Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ toggleStrategicObjectiveStatus Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle Strategic Objective status"
    );
  }
};

/**
 * Bulk Add Strategic Objectives
 * @param {Array} objectives - Array of { objectiveName }
 */
export const bulkAddStrategicObjectives = async (objectives) => {
  try {
    if (!objectives || !Array.isArray(objectives) || objectives.length === 0) {
      throw new Error("Strategic Objectives array is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.bulkAddStrategicObjective}`;

    console.log("📡 Bulk Adding Strategic Objectives:", objectives.length);

    const response = await axios.post(
      url,
      { rows: objectives },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Bulk Add Strategic Objectives Response:", {
      status: response.status,
      inserted: response.data.data?.inserted,
      invalid: response.data.data?.invalid,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ bulkAddStrategicObjectives Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add Strategic Objectives"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 🔧 VALIDATION HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Check if Strategic Objective exists (for duplicate validation) - Using ID
 * @param {Array} objectives - Current objectives data
 * @param {string} objectiveName - Objective name to check
 * @param {number|null} excludeId - ID to exclude (for edit mode)
 */
export const checkObjectiveExists = (objectives, objectiveName, excludeId = null) => {
  return objectives.some((item) => {
    // Skip the current item being edited (by ID)
    if (excludeId !== null && item.id === excludeId) {
      return false;
    }
    return item.name?.toLowerCase() === objectiveName?.trim().toLowerCase();
  });
};

/**
 * Check duplicates in uploaded data against existing database
 * @param {Array} uploadedRows - Rows from uploaded file
 * @param {Array} existingObjectives - Existing objectives from database
 * @returns {Object} - { updatedRows, duplicateCount }
 */
export const checkDuplicatesInUpload = (uploadedRows, existingObjectives) => {
  const existingSet = new Set();
  existingObjectives.forEach((item) => {
    const key = (item.objectiveName || item.name || "").toLowerCase();
    existingSet.add(key);
  });

  const seenInFile = new Set();

  const updatedRows = uploadedRows.map((row) => {
    if (row.hasError) return row;

    const key = row.objectiveName.toLowerCase();

    let isDuplicate = false;
    let duplicateReason = "";

    if (existingSet.has(key)) {
      isDuplicate = true;
      duplicateReason = "Strategic Objective already exists in database";
    }

    if (seenInFile.has(key) && !isDuplicate) {
      isDuplicate = true;
      duplicateReason = "Duplicate within file";
    }

    seenInFile.add(key);

    return { ...row, isDuplicate, duplicateReason };
  });

  const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

  return { updatedRows, duplicateCount };
};

/**
 * Find Strategic Objective by ID
 */
export const findObjectiveById = (objectives, id) => {
  return objectives.find((obj) => obj.id === id) || null;
};