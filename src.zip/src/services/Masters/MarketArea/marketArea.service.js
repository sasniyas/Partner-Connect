import axios from "axios";
import { API } from "../../../api"; // adjust path as needed

// ═══════════════════════════════════════════════════════════════
// 📡 MARKET AREA MASTER APIs
// ═══════════════════════════════════════════════════════════════

/**
 * Helper function to get auth token
 */
const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

/**
 * Helper function to handle token errors
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

/**
 * Get All Market Areas (Transformed)
 */
export const getAllMarketAreas = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getMarketarea}`;

    console.log("📡 Fetching Market Areas");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Market Areas Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0,
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      // Transform API response
      const transformedData = rawData.map((item) => ({
        id: item.id,
        name: item.marketarea,
        status: item.isActive === 1 ? "Active" : "Inactive",
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        createdAt: item.created_at,
        updatedAt: item.updated_at,
      }));

      console.log("✅ Market Areas transformed:", transformedData.length, "records");
      return transformedData;
    }

    throw new Error(response.data.message || "Failed to fetch market areas");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllMarketAreas Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch market areas"
    );
  }
};

/**
 * Get All Market Areas (Raw) - For duplicate checking
 */
export const getAllMarketAreasRaw = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getMarketarea}`;

    console.log("📡 Fetching Market Areas (Raw)");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    throw new Error(response.data.message || "Failed to fetch market areas");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllMarketAreasRaw Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch market areas"
    );
  }
};

/**
 * Add New Market Area
 */
export const addMarketArea = async (marketAreaName) => {
  try {
    if (!marketAreaName || !marketAreaName.trim()) {
      throw new Error("Market Area name is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.addMarketarea}`;

    console.log("📡 Adding Market Area");
    console.log("  URL:", url);
    console.log("  Name:", marketAreaName.trim());

    const response = await axios.post(
      url,
      { marketarea: marketAreaName.trim() },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Add Market Area Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200 || response.status === 201) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to add market area");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ addMarketArea Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add market area"
    );
  }
};

/**
 * Update Market Area by ID
 */
export const updateMarketArea = async (id, marketAreaName) => {
  try {
    if (!id) {
      throw new Error("Market Area ID is required");
    }
    if (!marketAreaName || !marketAreaName.trim()) {
      throw new Error("Market Area name is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.updateMarketarea}`;

    console.log("📡 Updating Market Area");
    console.log("  URL:", url);
    console.log("  ID:", id);
    console.log("  Name:", marketAreaName.trim());

    const response = await axios.put(
      url,
      {
        id: id,
        marketarea: marketAreaName.trim(),
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Update Market Area Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update market area");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ updateMarketArea Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update market area"
    );
  }
};

/**
 * Delete Market Area by ID
 */
export const deleteMarketArea = async (id) => {
  try {
    if (!id) {
      throw new Error("Market Area ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.deleteMarketarea}/${id}`;

    console.log("📡 Deleting Market Area");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Market Area Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200 && response.data?.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete market area");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ deleteMarketArea Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete market area"
    );
  }
};

/**
 * Toggle Market Area Status by ID (Activate/Deactivate)
 */
export const toggleMarketAreaStatus = async (id) => {
  try {
    if (!id) {
      throw new Error("Market Area ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.patchMarketarea}/${id}`;

    console.log("📡 Toggling Market Area Status");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.patch(
      url,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Toggle Market Area Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to toggle market area status");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ toggleMarketAreaStatus Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle market area status"
    );
  }
};

/**
 * Bulk Add Market Areas
 */
export const bulkAddMarketAreas = async (marketAreas) => {
  try {
    if (!marketAreas || !Array.isArray(marketAreas) || marketAreas.length === 0) {
      throw new Error("Market Areas array is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.bulkAddMarketarea}`;

    console.log("📡 Bulk Adding Market Areas");
    console.log("  URL:", url);
    console.log("  Count:", marketAreas.length);

    const response = await axios.post(
      url,
      { rows: marketAreas },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Bulk Add Market Areas Response:", {
      status: response.status,
      message: response.data.message,
      inserted: response.data.data?.inserted,
      invalid: response.data.data?.invalid,
    });

    if (response.status === 200 || response.status === 201) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to bulk add market areas");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ bulkAddMarketAreas Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add market areas"
    );
  }
};

/**
 * Check if Market Area exists by name (helper for validation)
 * @param {Array} tableData - Current table data
 * @param {string} marketAreaName - Name to check
 * @param {number|null} excludeId - ID to exclude (for edit mode)
 */
export const checkMarketAreaExists = (tableData, marketAreaName, excludeId = null) => {
  return tableData.some(
    (item) =>
      item.name.toLowerCase() === marketAreaName.trim().toLowerCase() &&
      item.id !== excludeId
  );
};

/**
 * Check duplicates in uploaded data against existing database
 * @param {Array} uploadedRows - Rows from uploaded file
 * @returns {Object} - { updatedRows, duplicateCount }
 */
export const checkDuplicatesInUpload = async (uploadedRows) => {
  try {
    if (!uploadedRows || uploadedRows.length === 0) {
      throw new Error("No data to check");
    }

    // Fetch existing data from database
    const existingData = await getAllMarketAreasRaw();

    // Create a Set of existing market areas for fast lookup
    const existingSet = new Set();
    if (Array.isArray(existingData)) {
      existingData.forEach((item) => {
        const key = (item.marketarea || item.name || "").toLowerCase().trim();
        if (key) existingSet.add(key);
      });
    }

    // Also check for duplicates within the uploaded file itself
    const seenInFile = new Set();

    // Check each row against existing data and within file
    const updatedRows = uploadedRows.map((row) => {
      const key = (row.marketArea || "").toLowerCase().trim();

      let isDuplicate = false;
      let duplicateReason = "";

      // Skip empty rows
      if (!key) {
        return {
          ...row,
          isDuplicate: false,
          duplicateReason: "",
        };
      }

      // Check if exists in database
      if (existingSet.has(key)) {
        isDuplicate = true;
        duplicateReason = "Already exists in database";
      }

      // Check if duplicate within file
      if (seenInFile.has(key) && !isDuplicate) {
        isDuplicate = true;
        duplicateReason = "Duplicate within file";
      }

      seenInFile.add(key);

      return {
        ...row,
        isDuplicate,
        duplicateReason,
      };
    });

    const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

    console.log("✅ Duplicate check completed:", {
      total: uploadedRows.length,
      duplicates: duplicateCount,
      valid: uploadedRows.length - duplicateCount,
    });

    return {
      updatedRows,
      duplicateCount,
    };
  } catch (error) {
    handleTokenError(error);
    console.error("❌ checkDuplicatesInUpload Error:", error.message);
    throw new Error(error.message || "Failed to check duplicates");
  }
};

/**
 * Parse Excel file for Market Area bulk upload
 * @param {File} file - Excel file
 * @returns {Promise<Array>} - Parsed rows
 */
export const parseMarketAreaExcel = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const XLSX = require("xlsx");
        const data = new Uint8Array(event.target.result);
        const workbook = XLSX.read(data, { type: "array" });
        const sheetName = workbook.SheetNames[0];

        let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
          defval: "",
        });

        // Remove empty rows
        json = json.filter((row) =>
          Object.values(row).some((cell) => String(cell).trim() !== "")
        );

        const finalRows = json.map((row) => {
          const marketArea = String(
            row["Market Area"] ||
              row["MarketArea"] ||
              row["MARKET AREA"] ||
              row["marketarea"] ||
              row["market area"] ||
              ""
          ).trim();

          return {
            marketArea,
            hasError: !marketArea,
            isDuplicate: false,
            duplicateReason: "",
          };
        });

        console.log("✅ Excel parsed:", finalRows.length, "rows");
        resolve(finalRows);
      } catch (error) {
        console.error("❌ Excel parse error:", error);
        reject(new Error("Failed to parse Excel file"));
      }
    };

    reader.onerror = () => {
      reject(new Error("Failed to read file"));
    };

    reader.readAsArrayBuffer(file);
  });
};