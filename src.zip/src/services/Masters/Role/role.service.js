// services/Masters/Role/role.service.js

import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Helper function to get auth token
 */
const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

/**
 * Helper function to handle token errors
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ═══════════════════════════════════════════════════════════════
// 📊 ROLE CRUD OPERATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Get All Roles (raw data)
 */
export const getAllRoles = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getRoles}`;

    console.log("📡 Fetching Roles");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Roles Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0,
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllRoles Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch Roles"
    );
  }
};

/**
 * Get All Roles Formatted for Table
 */
export const getAllRolesFormatted = async () => {
  try {
    const data = await getAllRoles();
    return data.map((role) => ({
      id: role.id,
      userType: role.userType,
      location: role.location || "",
      userRole: role.userRole,
      status: role.isActive === 1 ? "Active" : "Inactive",
      isActive: role.isActive,
      createdOn: role.createdOn,
    }));
  } catch (error) {
    console.error("❌ getAllRolesFormatted Error:", error.message);
    throw error;
  }
};

/**
 * Get Active Roles (for dropdowns)
 */
export const getActiveRoles = async () => {
  try {
    const data = await getAllRoles();
    return data
      .filter((role) => role.isActive === 1)
      .map((role) => ({
        id: role.id,
        userType: role.userType,
        location: role.location,
        userRole: role.userRole,
      }));
  } catch (error) {
    console.error("❌ getActiveRoles Error:", error.message);
    throw error;
  }
};

/**
 * Add New Role
 * @param {Object} payload - { userType, location, userRole }
 */
export const addRole = async (payload) => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.addRole}`;

    console.log("📡 Adding Role");

    const response = await axios.post(url, payload, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Add Role Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ addRole Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add Role"
    );
  }
};

/**
 * Update Role
 * @param {Object} payload - { id, userType, location, userRole }
 */
export const updateRole = async (payload) => {
  try {
    const { id, ...updateData } = payload;

    if (!id) {
      throw new Error("Role ID is required for update");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.updateRole}`;

    console.log("📡 Updating Role ID:", id);

    const response = await axios.put(
      url,
      { id, ...updateData },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Update Role Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ updateRole Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update Role"
    );
  }
};

/**
 * Delete Role by ID
 */
export const deleteRole = async (id) => {
  try {
    if (!id) {
      throw new Error("Role ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.deleteRole}/${id}`;

    console.log("📡 Deleting Role ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Role Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ deleteRole Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete Role"
    );
  }
};

/**
 * Toggle Role Status by ID (Activate/Deactivate)
 */
export const toggleRoleStatus = async (id) => {
  try {
    if (!id) {
      throw new Error("Role ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.toggleRole}/${id}`;

    console.log("📡 Toggling Role Status ID:", id);

    const response = await axios.patch(
      url,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Toggle Role Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ toggleRoleStatus Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle Role status"
    );
  }
};

/**
 * Bulk Add Roles
 * @param {Array} roles - Array of { userType, location, userRole }
 */
export const bulkAddRoles = async (roles) => {
  try {
    if (!roles || !Array.isArray(roles) || roles.length === 0) {
      throw new Error("Roles array is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.bulkAddRole}`;

    console.log("📡 Bulk Adding Roles:", roles.length);

    const response = await axios.post(
      url,
      { rows: roles },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Bulk Add Roles Response:", {
      status: response.status,
      inserted: response.data.data?.inserted,
      invalid: response.data.data?.invalid,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ bulkAddRoles Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add Roles"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 🔧 VALIDATION HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Check if Role exists (for duplicate validation) - Using ID
 * @param {Array} roles - Current roles data
 * @param {string} userType - User type
 * @param {string} userRole - User role name
 * @param {string} location - Location
 * @param {number|null} excludeId - ID to exclude (for edit mode)
 */
export const checkRoleExists = (roles, userType, userRole, location, excludeId = null) => {
  return roles.some((item) => {
    // Skip the current item being edited (by ID)
    if (excludeId !== null && item.id === excludeId) {
      return false;
    }
    
    const matchesUserType = item.userType === userType;
    const matchesUserRole = item.userRole?.toLowerCase() === userRole?.trim().toLowerCase();
    
    // For Volvo User, also check location
    if (userType === "Volvo User") {
      return matchesUserType && matchesUserRole && item.location === location;
    }
    
    // For Dealer User, location doesn't matter for uniqueness
    return matchesUserType && matchesUserRole;
  });
};

/**
 * Check duplicates in uploaded data against existing database
 * @param {Array} uploadedRows - Rows from uploaded file
 * @param {Array} existingRoles - Existing roles from database
 * @returns {Object} - { updatedRows, duplicateCount }
 */
export const checkDuplicatesInUpload = (uploadedRows, existingRoles) => {
  const existingSet = new Set();
  existingRoles.forEach((item) => {
    const locationKey = item.location || "NULL";
    const key = `${(item.userType || "").toLowerCase()}|${(item.userRole || "").toLowerCase()}|${locationKey.toLowerCase()}`;
    existingSet.add(key);
  });

  const seenInFile = new Set();

  const updatedRows = uploadedRows.map((row) => {
    if (row.hasError) return row;

    const locationKey = row.userType === "Dealer User" ? "NULL" : (row.location || "NULL");
    const key = `${row.userType.toLowerCase()}|${row.userRole.toLowerCase()}|${locationKey.toLowerCase()}`;

    let isDuplicate = false;
    let duplicateReason = "";

    if (existingSet.has(key)) {
      isDuplicate = true;
      duplicateReason = "Role already exists in database";
    }

    if (seenInFile.has(key) && !isDuplicate) {
      isDuplicate = true;
      duplicateReason = "Duplicate role within file";
    }

    seenInFile.add(key);

    return { ...row, isDuplicate, duplicateReason };
  });

  const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

  return { updatedRows, duplicateCount };
};

/**
 * Find Role by ID
 */
export const findRoleById = (roles, id) => {
  return roles.find((role) => role.id === id) || null;
};

/**
 * Get location options based on user type
 */
export const getLocationOptions = (userType) => {
  if (userType === "Volvo User") {
    return ["Headquarters", "Region"];
  }
  if (userType === "Dealer User") {
    return ["Headquarters", "Branch"];
  }
  return [];
};

/**
 * User type options
 */
export const userTypeOptions = ["Dealer User", "Volvo User"];