import axios from "axios";
import { API } from "../../../api"; // adjust path as needed

// ═══════════════════════════════════════════════════════════════
// 📡 COUNTRY MASTER APIs
// ═══════════════════════════════════════════════════════════════

/**
 * Helper function to get auth token
 */
const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

/**
 * Helper function to handle token errors
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

/**
 * Get All Countries (Transformed for Table)
 */
export const getAllCountries = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getCountries}`;

    console.log("📡 Fetching Countries");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Countries Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0,
    });

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || [];

      // Transform API response
      const transformedData = rawData.map((item) => ({
        id: item.id,
        name: item.countryName,
        countryCode: item.countryCode,
        status: item.isActive === 1 ? "Active" : "Inactive",
        isActive: item.isActive,
      }));

      console.log("✅ Countries transformed:", transformedData.length, "records");
      return transformedData;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllCountries Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch countries"
    );
  }
};

/**
 * Get All Countries (Raw) - For duplicate checking
 */
export const getAllCountriesRaw = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getCountries}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllCountriesRaw Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch countries"
    );
  }
};

/**
 * Get All Countries for Dropdown (from master list)
 */
export const getCountriesForDropdown = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getAllCuntries}`;

    console.log("📡 Fetching Countries for Dropdown");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.data.status) {
      const mappedCountries = response.data.data.map((c) => ({
        name: c.country_name,
        code: c.phone_code,
      }));
      console.log("✅ Countries for dropdown:", mappedCountries.length, "records");
      return mappedCountries;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getCountriesForDropdown Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch countries"
    );
  }
};

/**
 * Add New Country
 */
export const addCountry = async (countryName, countryCode) => {
  try {
    if (!countryName || !countryName.trim()) {
      throw new Error("Country name is required");
    }
    if (!countryCode || !countryCode.trim()) {
      throw new Error("Country code is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.addCountry}`;

    console.log("📡 Adding Country");
    console.log("  URL:", url);
    console.log("  Name:", countryName.trim());
    console.log("  Code:", countryCode.trim());

    const response = await axios.post(
      url,
      {
        countryName: countryName.trim(),
        countryCode: countryCode.trim(),
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Add Country Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200 || response.status === 201) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to add country");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ addCountry Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add country"
    );
  }
};

/**
 * Update Country by ID
 */
export const updateCountry = async (id, countryName, countryCode) => {
  try {
    if (!id) {
      throw new Error("Country ID is required");
    }
    if (!countryName || !countryName.trim()) {
      throw new Error("Country name is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.updateCountry}`;

    console.log("📡 Updating Country");
    console.log("  URL:", url);
    console.log("  ID:", id);
    console.log("  Name:", countryName.trim());

    const response = await axios.put(
      url,
      {
        id: id,
        countryName: countryName.trim(),
        countryCode: countryCode.trim(),
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Update Country Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update country");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ updateCountry Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update country"
    );
  }
};

/**
 * Delete Country by ID
 */
export const deleteCountry = async (id) => {
  try {
    if (!id) {
      throw new Error("Country ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.deleteCountry}/${id}`;

    console.log("📡 Deleting Country");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Country Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200 && response.data?.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete country");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ deleteCountry Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete country"
    );
  }
};

/**
 * Toggle Country Status by ID (Activate/Deactivate)
 */
export const toggleCountryStatus = async (id) => {
  try {
    if (!id) {
      throw new Error("Country ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.toggleCountry}/${id}`;

    console.log("📡 Toggling Country Status");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.patch(
      url,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Toggle Country Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to toggle country status");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ toggleCountryStatus Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle country status"
    );
  }
};

/**
 * Bulk Add Countries
 */
export const bulkAddCountries = async (countries) => {
  try {
    if (!countries || !Array.isArray(countries) || countries.length === 0) {
      throw new Error("Countries array is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.bulkAddCountry}`;

    console.log("📡 Bulk Adding Countries");
    console.log("  URL:", url);
    console.log("  Count:", countries.length);

    const response = await axios.post(
      url,
      { rows: countries },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Bulk Add Countries Response:", {
      status: response.status,
      message: response.data.message,
      inserted: response.data.data?.inserted,
      invalid: response.data.data?.invalid,
    });

    if (response.status === 200 || response.status === 201) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to bulk add countries");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ bulkAddCountries Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add countries"
    );
  }
};

/**
 * Check if Country exists by name (helper for validation)
 * @param {Array} tableData - Current table data
 * @param {string} countryName - Name to check
 * @param {number|null} excludeId - ID to exclude (for edit mode)
 */
export const checkCountryExists = (tableData, countryName, excludeId = null) => {
  return tableData.some(
    (item) =>
      item.name.toLowerCase() === countryName.trim().toLowerCase() &&
      item.id !== excludeId
  );
};

/**
 * Check duplicates in uploaded data against existing database
 * @param {Array} uploadedRows - Rows from uploaded file
 * @returns {Object} - { updatedRows, duplicateCount }
 */
export const checkDuplicatesInUpload = async (uploadedRows) => {
  try {
    if (!uploadedRows || uploadedRows.length === 0) {
      throw new Error("No data to check");
    }

    // Fetch existing data from database
    const existingData = await getAllCountriesRaw();

    // Create Sets for fast lookup
    const existingNames = new Set();
    const existingCodes = new Set();

    if (Array.isArray(existingData)) {
      existingData.forEach((item) => {
        existingNames.add((item.countryName || "").toLowerCase().trim());
        existingCodes.add((item.countryCode || "").toUpperCase().trim());
      });
    }

    // Check for duplicates within the uploaded file
    const seenNames = new Set();
    const seenCodes = new Set();

    // Check each row against existing data and within file
    const updatedRows = uploadedRows.map((row) => {
      const nameKey = (row.countryName || "").toLowerCase().trim();
      const codeKey = (row.countryCode || "").toUpperCase().trim();

      let isDuplicate = false;
      let duplicateReason = "";

      // Skip empty rows
      if (!nameKey || !codeKey) {
        return {
          ...row,
          isDuplicate: false,
          duplicateReason: "",
        };
      }

      // Check if exists in database
      if (existingNames.has(nameKey)) {
        isDuplicate = true;
        duplicateReason = "Country Name already exists in database";
      } else if (existingCodes.has(codeKey)) {
        isDuplicate = true;
        duplicateReason = "Country Code already exists in database";
      }

      // Check if duplicate within file
      if (!isDuplicate && seenNames.has(nameKey)) {
        isDuplicate = true;
        duplicateReason = "Duplicate Country Name in file";
      } else if (!isDuplicate && seenCodes.has(codeKey)) {
        isDuplicate = true;
        duplicateReason = "Duplicate Country Code in file";
      }

      seenNames.add(nameKey);
      seenCodes.add(codeKey);

      return {
        ...row,
        isDuplicate,
        duplicateReason,
      };
    });

    const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

    console.log("✅ Duplicate check completed:", {
      total: uploadedRows.length,
      duplicates: duplicateCount,
      valid: uploadedRows.length - duplicateCount,
    });

    return {
      updatedRows,
      duplicateCount,
    };
  } catch (error) {
    handleTokenError(error);
    console.error("❌ checkDuplicatesInUpload Error:", error.message);
    throw new Error(error.message || "Failed to check duplicates");
  }
};

/**
 * Parse Excel file for Country bulk upload
 * @param {File} file - Excel file
 * @returns {Promise<Array>} - Parsed rows
 */
export const parseCountryExcel = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const XLSX = require("xlsx");
        const data = new Uint8Array(event.target.result);
        const workbook = XLSX.read(data, { type: "array" });
        const sheetName = workbook.SheetNames[0];

        let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
          defval: "",
        });

        // Remove empty rows
        json = json.filter((row) =>
          Object.values(row).some((cell) => String(cell).trim() !== "")
        );

        const finalRows = json.map((row) => {
          const countryName = String(
            row["Country Name"] ||
              row["CountryName"] ||
              row["COUNTRY NAME"] ||
              row["country name"] ||
              ""
          ).trim();

          const countryCode = String(
            row["Country Code"] ||
              row["CountryCode"] ||
              row["COUNTRY CODE"] ||
              row["country code"] ||
              ""
          ).trim();

          return {
            countryName,
            countryCode,
            hasError: !countryName || !countryCode,
            isDuplicate: false,
            duplicateReason: "",
          };
        });

        console.log("✅ Excel parsed:", finalRows.length, "rows");
        resolve(finalRows);
      } catch (error) {
        console.error("❌ Excel parse error:", error);
        reject(new Error("Failed to parse Excel file"));
      }
    };

    reader.onerror = () => {
      reject(new Error("Failed to read file"));
    };

    reader.readAsArrayBuffer(file);
  });
};