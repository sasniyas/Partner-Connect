// services/Masters/City/city.service.js

import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Helper function to get auth token
 */
const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

/**
 * Helper function to handle token errors
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ═══════════════════════════════════════════════════════════════
// 📊 CITY CRUD OPERATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Get All Cities (raw data)
 */
export const getAllCities = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getCities}`;

    console.log("📡 Fetching Cities");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Cities Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0,
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllCities Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch Cities"
    );
  }
};

/**
 * Get All Cities Formatted for Table
 */
export const getAllCitiesFormatted = async () => {
  try {
    const data = await getAllCities();
    return data.map((city) => ({
      id: city.cityId,
      state: city.stateName,
      stateId: city.stateId || city.state_id,
      city: city.cityName,
      marketArea: city.marketArea,
      status: city.cityActive === 1 ? "Active" : "Inactive",
      isActive: city.cityActive,
      createdOn: city.createdOn,
    }));
  } catch (error) {
    console.error("❌ getAllCitiesFormatted Error:", error.message);
    throw error;
  }
};

/**
 * Get Active Cities (for dropdowns)
 */
export const getActiveCities = async () => {
  try {
    const data = await getAllCities();
    return data
      .filter((city) => city.cityActive === 1)
      .map((city) => ({
        id: city.cityId,
        city: city.cityName,
        state: city.stateName,
        marketArea: city.marketArea,
      }));
  } catch (error) {
    console.error("❌ getActiveCities Error:", error.message);
    throw error;
  }
};

/**
 * Get All Cities for Dropdown (used in popup)
 */
export const getAllCitiesForDropdown = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getAllCities}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllCitiesForDropdown Error:", error.message);
    throw error;
  }
};

/**
 * Add New City
 * @param {Object} payload - { state_id, cityName }
 */
export const addCity = async (payload) => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.addCity}`;

    console.log("📡 Adding City");

    const response = await axios.post(url, payload, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Add City Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ addCity Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add City"
    );
  }
};

/**
 * Update City
 * @param {Object} payload - { id, state_id, cityName }
 */
export const updateCity = async (payload) => {
  try {
    const { id, ...updateData } = payload;

    if (!id) {
      throw new Error("City ID is required for update");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.updateCity}`;

    console.log("📡 Updating City ID:", id);

    const response = await axios.put(
      url,
      { id, ...updateData },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Update City Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ updateCity Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update City"
    );
  }
};

/**
 * Delete City by ID
 */
export const deleteCity = async (id) => {
  try {
    if (!id) {
      throw new Error("City ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.deleteCity}/${id}`;

    console.log("📡 Deleting City ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete City Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ deleteCity Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete City"
    );
  }
};

/**
 * Toggle City Status by ID (Activate/Deactivate)
 */
export const toggleCityStatus = async (id) => {
  try {
    if (!id) {
      throw new Error("City ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.toggleCity}/${id}`;

    console.log("📡 Toggling City Status ID:", id);

    const response = await axios.patch(
      url,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Toggle City Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ toggleCityStatus Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle City status"
    );
  }
};

/**
 * Bulk Add Cities
 * @param {Array} cities - Array of { state_id, cityName }
 */
export const bulkAddCities = async (cities) => {
  try {
    if (!cities || !Array.isArray(cities) || cities.length === 0) {
      throw new Error("Cities array is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.bulkAddCity}`;

    console.log("📡 Bulk Adding Cities:", cities.length);

    const response = await axios.post(
      url,
      { rows: cities },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Bulk Add Cities Response:", {
      status: response.status,
      inserted: response.data.data?.inserted,
      invalid: response.data.data?.invalid,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ bulkAddCities Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add Cities"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📊 STATE & MARKET AREA OPERATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Get All States
 */
export const getAllStates = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getStates}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllStates Error:", error.message);
    throw error;
  }
};

/**
 * Get Active States (for dropdowns)
 */
export const getActiveStates = async () => {
  try {
    const data = await getAllStates();
    return data.filter((state) => state.isActive === 1);
  } catch (error) {
    console.error("❌ getActiveStates Error:", error.message);
    throw error;
  }
};

/**
 * Get All Market Areas
 */
export const getAllMarketAreas = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getMarketarea}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllMarketAreas Error:", error.message);
    throw error;
  }
};

/**
 * Get Cities for State (by state name)
 */
export const getCitiesForState = (allCities, stateName) => {
  if (!stateName) return [];
  
  return allCities
    .filter(
      (city) =>
        city.state_name?.toLowerCase() === stateName.toLowerCase() ||
        city.stateName?.toLowerCase() === stateName.toLowerCase()
    )
    .map((city) => city.city_name || city.cityName)
    .sort();
};

// ═══════════════════════════════════════════════════════════════
// 🔧 VALIDATION HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Check if City exists (for duplicate validation) - Using ID
 * @param {Array} cities - Current cities data
 * @param {string} state - State name
 * @param {string} cityName - City name
 * @param {number|null} excludeId - ID to exclude (for edit mode)
 */
export const checkCityExists = (cities, state, cityName, excludeId = null) => {
  return cities.some((item) => {
    // Skip the current item being edited (by ID)
    if (excludeId !== null && item.id === excludeId) {
      return false;
    }
    return (
      item.state?.toLowerCase() === state?.toLowerCase() &&
      item.city?.toLowerCase() === cityName?.trim().toLowerCase()
    );
  });
};

/**
 * Check duplicates in uploaded data against existing database
 * @param {Array} uploadedRows - Rows from uploaded file
 * @param {Array} existingCities - Existing cities from database
 * @returns {Object} - { updatedRows, duplicateCount }
 */
export const checkDuplicatesInUpload = (uploadedRows, existingCities) => {
  const existingSet = new Set();
  existingCities.forEach((item) => {
    const key = `${(item.cityName || item.city || "").toLowerCase()}|${item.stateId || item.state_id}`;
    existingSet.add(key);
  });

  const seenInFile = new Set();

  const updatedRows = uploadedRows.map((row) => {
    if (row.hasError) return row;

    const key = `${row.cityName.toLowerCase()}|${row.state_id}`;

    let isDuplicate = false;
    let duplicateReason = "";

    if (!row.state_id || !row.cityName) {
      return {
        ...row,
        hasError: true,
        isDuplicate: false,
        duplicateReason: "",
      };
    }

    if (existingSet.has(key)) {
      isDuplicate = true;
      duplicateReason = "Already exists in database";
    }

    if (seenInFile.has(key) && !isDuplicate) {
      isDuplicate = true;
      duplicateReason = "Duplicate within file";
    }

    seenInFile.add(key);

    return { ...row, isDuplicate, duplicateReason };
  });

  const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

  return { updatedRows, duplicateCount };
};

/**
 * Find City by ID
 */
export const findCityById = (cities, id) => {
  return cities.find((city) => city.id === id) || null;
};

/**
 * Get State ID by Name
 */
export const getStateIdByName = (states, name) => {
  const state = states.find(
    (s) => s.stateName.toLowerCase() === name.toLowerCase()
  );
  return state?.id || null;
};