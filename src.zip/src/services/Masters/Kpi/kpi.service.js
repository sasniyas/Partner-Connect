// services/Masters/Kpi/kpi.service.js

import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ═══════════════════════════════════════════════════════════════
// 📊 KPI CRUD OPERATIONS
// ═══════════════════════════════════════════════════════════════

export const getAllKPIs = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getKPIs}`;

    console.log("📡 Fetching KPIs");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ KPIs Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0,
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllKPIs Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch KPIs"
    );
  }
};

export const getAllKPIsFormatted = async () => {
  try {
    const data = await getAllKPIs();
    return data.map((kpi) => ({
      id: kpi.id,
      objectiveId: kpi.objectiveId,
      objectives: kpi.strategicObjective,
      kpis: kpi.kpiName,
      maxScore: kpi.maxScore,
      status: kpi.isActive === 1 ? "Active" : "Inactive",
      isActive: kpi.isActive,
    }));
  } catch (error) {
    console.error("❌ getAllKPIsFormatted Error:", error.message);
    throw error;
  }
};

export const addKPI = async (payload) => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.addKPI}`;

    console.log("📡 Adding KPI");

    const response = await axios.post(url, payload, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Add KPI Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ addKPI Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add KPI"
    );
  }
};

/**
 * ✅ FIXED: Update KPI - Now accepts single payload object
 * @param {Object} payload - { id, objectiveId, kpiName, maxScore }
 */
export const updateKPI = async (payload) => {
  try {
    const { id, ...updateData } = payload;
    
    if (!id) {
      throw new Error("KPI ID is required for update");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.updateKPI}`;

    console.log("📡 Updating KPI ID:", id);

    const response = await axios.put(
      url,
      { id, ...updateData },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Update KPI Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ updateKPI Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update KPI"
    );
  }
};

export const deleteKPI = async (id) => {
  try {
    if (!id) {
      throw new Error("KPI ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.deleteKPI}/${id}`;

    console.log("📡 Deleting KPI ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete KPI Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ deleteKPI Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete KPI"
    );
  }
};

export const toggleKPIStatus = async (id) => {
  try {
    if (!id) {
      throw new Error("KPI ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.toggleKPI}/${id}`;

    console.log("📡 Toggling KPI Status ID:", id);

    const response = await axios.patch(
      url,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Toggle KPI Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ toggleKPIStatus Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle KPI status"
    );
  }
};

export const bulkAddKPIs = async (kpis) => {
  try {
    if (!kpis || !Array.isArray(kpis) || kpis.length === 0) {
      throw new Error("KPIs array is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.bulkAddKpi}`;

    console.log("📡 Bulk Adding KPIs:", kpis.length);

    const response = await axios.post(
      url,
      { rows: kpis },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Bulk Add KPIs Response:", {
      status: response.status,
      inserted: response.data.data?.inserted,
      invalid: response.data.data?.invalid,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ bulkAddKPIs Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add KPIs"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📋 STRATEGIC OBJECTIVES APIs
// ═══════════════════════════════════════════════════════════════

export const getAllStrategicObjectives = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getStrategicObjectives}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.data?.status && Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllStrategicObjectives Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch strategic objectives"
    );
  }
};

export const getActiveStrategicObjectives = async () => {
  try {
    const data = await getAllStrategicObjectives();
    return data
      .filter((obj) => obj.isActive === 1)
      .map((obj) => ({ id: obj.id, name: obj.objectiveName }));
  } catch (error) {
    console.error("❌ getActiveStrategicObjectives Error:", error.message);
    throw error;
  }
};

// ═══════════════════════════════════════════════════════════════
// 🔧 VALIDATION HELPERS
// ═══════════════════════════════════════════════════════════════

export const checkKPIExists = (kpis, objectiveName, kpiName, excludeId = null) => {
  return kpis.some((item) => {
    if (excludeId !== null && item.id === excludeId) {
      return false;
    }
    return (
      item.objectives === objectiveName &&
      item.kpis?.toLowerCase() === kpiName?.trim().toLowerCase()
    );
  });
};

export const checkDuplicatesInUpload = (uploadedRows, existingKpis) => {
  const existingSet = new Set();
  existingKpis.forEach((item) => {
    const key = `${(item.strategicObjective || "").toLowerCase()}|${(
      item.kpiName || ""
    ).toLowerCase()}`;
    existingSet.add(key);
  });

  const seenInFile = new Set();

  const updatedRows = uploadedRows.map((row) => {
    if (row.hasError) return row;

    const key = `${row.objectiveName.toLowerCase()}|${row.kpiName.toLowerCase()}`;

    let isDuplicate = false;
    let duplicateReason = "";

    if (existingSet.has(key)) {
      isDuplicate = true;
      duplicateReason = "KPI already exists in database";
    }

    if (seenInFile.has(key) && !isDuplicate) {
      isDuplicate = true;
      duplicateReason = "Duplicate KPI within file";
    }

    seenInFile.add(key);

    return { ...row, isDuplicate, duplicateReason };
  });

  const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

  return { updatedRows, duplicateCount };
};

export const getObjectiveIdByName = (objectives, name) => {
  if (!name) return null;
  const obj = objectives.find(
    (o) => o.name.toLowerCase().trim() === name.toLowerCase().trim()
  );
  return obj?.id || null;
};

/**
 * Find KPI by ID
 */
export const findKPIById = (kpis, id) => {
  return kpis.find((kpi) => kpi.id === id) || null;
};