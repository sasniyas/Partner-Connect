import axios from "axios";
import { API } from "../../../api"; // adjust path as needed

// ═══════════════════════════════════════════════════════════════
// 📡 SUB KPI MASTER APIs
// ═══════════════════════════════════════════════════════════════

/**
 * Helper function to get auth token
 */
const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

/**
 * Helper function to handle token errors
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ═══════════════════════════════════════════════════════════════
// 📊 SUB KPI CRUD OPERATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Get All Sub KPIs
 */
export const getAllSubKPIs = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getAllSubKPIs}`;

    console.log("📡 Fetching Sub KPIs");
    console.log("  URL:", url);

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Sub KPIs Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0,
    });

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllSubKPIs Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch sub KPIs"
    );
  }
};

/**
 * Add New Sub KPI
 * @param {FormData} formData - Form data with all sub KPI fields
 */
export const addSubKPI = async (formData) => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.addSubKPI}`;

    console.log("📡 Adding Sub KPI");
    console.log("  URL:", url);

    const response = await axios.post(url, formData, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "multipart/form-data",
      },
    });

    console.log("✅ Add Sub KPI Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200 || response.status === 201) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to add sub KPI");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ addSubKPI Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add sub KPI"
    );
  }
};

/**
 * Update Sub KPI by ID
 * @param {FormData} formData - Form data with all sub KPI fields including ID
 */
export const updateSubKPI = async (formData) => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.updateSubKPI}`;

    console.log("📡 Updating Sub KPI");
    console.log("  URL:", url);

    const response = await axios.put(url, formData, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "multipart/form-data",
      },
    });

    console.log("✅ Update Sub KPI Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update sub KPI");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ updateSubKPI Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update sub KPI"
    );
  }
};

/**
 * Update Formula for Sub KPI
 * @param {Object} data - { id, formula }
 */
export const updateFormulaSubKpi = async (data) => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.updateFormulaSubKpi}`;

    console.log("📡 Updating Formula for Sub KPI");
    console.log("  URL:", url);
    console.log("  Data:", data);

    const response = await axios.put(url, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Update Formula Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update formula");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ updateFormulaSubKpi Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update formula"
    );
  }
};

/**
 * Delete Sub KPI by ID
 */
export const deleteSubKPI = async (id) => {
  try {
    if (!id) {
      throw new Error("Sub KPI ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.deleteSubKPI}/${id}`;

    console.log("📡 Deleting Sub KPI");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Sub KPI Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200 && response.data?.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete sub KPI");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ deleteSubKPI Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete sub KPI"
    );
  }
};

/**
 * Toggle Sub KPI Status by ID (Activate/Deactivate)
 */
export const toggleSubKPIStatus = async (id) => {
  try {
    if (!id) {
      throw new Error("Sub KPI ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.toggleSubKPI}/${id}`;

    console.log("📡 Toggling Sub KPI Status");
    console.log("  URL:", url);
    console.log("  ID:", id);

    const response = await axios.patch(
      url,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Toggle Sub KPI Response:", {
      status: response.status,
      message: response.data.message,
    });

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to toggle sub KPI status");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ toggleSubKPIStatus Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle sub KPI status"
    );
  }
};

/**
 * Bulk Add Sub KPIs
 */
export const bulkAddSubKPIs = async (subKpis) => {
  try {
    if (!subKpis || !Array.isArray(subKpis) || subKpis.length === 0) {
      throw new Error("Sub KPIs array is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.bulkAddSubKpi}`;

    console.log("📡 Bulk Adding Sub KPIs");
    console.log("  URL:", url);
    console.log("  Count:", subKpis.length);

    const response = await axios.post(
      url,
      { rows: subKpis },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Bulk Add Sub KPIs Response:", {
      status: response.status,
      message: response.data.message,
      inserted: response.data.data?.inserted,
      invalid: response.data.data?.invalid,
    });

    if (response.status === 200 || response.status === 201) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to bulk add sub KPIs");
  } catch (error) {
    handleTokenError(error);
    console.error("❌ bulkAddSubKPIs Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add sub KPIs"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📋 DROPDOWN DATA FETCHERS
// ═══════════════════════════════════════════════════════════════

/**
 * ⭐ FIXED: Get All KPIs (for dropdown)
 * Now includes objectiveId so dependent dropdown filtering works correctly
 */
export const getAllKPIs = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getKPIs}`;

    console.log("📡 Fetching KPIs");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.data?.status && Array.isArray(response.data?.data)) {
      const activeKPIs = response.data.data
        .filter((kpi) => kpi.isActive === 1)
        .map((kpi) => ({
          value: kpi.id,
          label: kpi.kpiName,
          objectiveName: kpi.strategicObjective, // ⭐ API returns name string, not objectiveId
        }));

      console.log("✅ KPIs fetched:", activeKPIs.length, "records");
      return activeKPIs;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllKPIs Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch KPIs"
    );
  }
};

/**
 * Get All KPIs (Raw) - For table display
 */
export const getAllKPIsRaw = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getKPIs}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllKPIsRaw Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch KPIs"
    );
  }
};

/**
 * Get All Strategic Objectives (for dropdown)
 */
export const getAllStrategicObjectives = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getStrategicObjectives}`;

    console.log("📡 Fetching Strategic Objectives");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.data?.status && Array.isArray(response.data?.data)) {
      const activeObjectives = response.data.data
        .filter((obj) => obj.isActive === 1 || obj.isActive === true)
        .map((obj) => ({ id: obj.id, name: obj.objectiveName }));

      console.log("✅ Strategic Objectives fetched:", activeObjectives.length, "records");
      return activeObjectives;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllStrategicObjectives Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch strategic objectives"
    );
  }
};

/**
 * Get All Strategic Objectives (Raw)
 */
export const getAllStrategicObjectivesRaw = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getStrategicObjectives}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.data?.status && Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllStrategicObjectivesRaw Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch strategic objectives"
    );
  }
};

/**
 * Get All Roles (for dropdown)
 */
export const getAllRoles = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getRoles}`;

    console.log("📡 Fetching Roles");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.data.status) {
      console.log("✅ Roles fetched:", response.data.data?.length || 0, "records");
      return response.data.data || [];
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllRoles Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch roles"
    );
  }
};

/**
 * Get All Users (for dropdown)
 */
export const getAllUsers = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getAllUsers}`;

    console.log("📡 Fetching Users");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Users fetched:", response.data.data?.length || 0, "records");
    return response.data.data || [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllUsers Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch users"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Check if Sub KPI exists (for duplicate validation)
 */
export const checkSubKPIExists = (subKPIs, subKpiName, kpiId, objectiveId, year, excludeId = null) => {
  return subKPIs.find((row) => {
    return (
      row.subKpiName?.toLowerCase() === subKpiName?.trim().toLowerCase() &&
      row.kpiId === Number(kpiId) &&
      row.objectiveId === Number(objectiveId) &&
      String(row.createdYear) === String(year) &&
      row.id !== excludeId
    );
  });
};

/**
 * Build FormData for Sub KPI submission
 */
export const buildSubKPIFormData = (form, isEdit = false) => {
  const formData = new FormData();

  if (isEdit && form.id) {
    formData.append("id", form.id);
  }

  formData.append("createdYear", form.year ? Number(form.year) : 0);
  formData.append("strategicObjective", form.strategicObjective ? Number(form.strategicObjective) : 0);
  formData.append("kpiNumber", form.kpiNumber || "");
  formData.append("kpiId", form.kpi ? Number(form.kpi) : 0);
  formData.append("subKpiName", form.subKpi || "");
  formData.append("assessmentPeriod", form.assessmentPeriod || "");
  formData.append("minScore", form.minScore ? Number(form.minScore) : 0);
  formData.append("maxScore", form.maxScore ? Number(form.maxScore) : 0);
  formData.append("scoringCriteria", form.scoringCriteria || "");
  formData.append("measurement", form.measurement || "");
  formData.append("annualScore", form.annualScore || "");
  formData.append("annualScoringCriteria", form.annualScoringCriteria || "");
  formData.append("criteriaDefinition", form.criteriaDefinition || "");
  formData.append("dataSource", form.dataSource || "");
  formData.append("userType", form.userType || "");
  formData.append("docStaus", form.dealerContent === "Yes" ? 1 : 0);

  // User roles array
  if (Array.isArray(form.userRole)) {
    form.userRole.forEach((r) => formData.append("userRoles[]", Number(r)));
  } else if (form.userRole) {
    formData.append("userRoles[]", Number(form.userRole));
  }

  // User IDs array
  if (Array.isArray(form.userName)) {
    form.userName.forEach((u) => formData.append("userIds[]", Number(u)));
  } else if (form.userName) {
    formData.append("userIds[]", Number(form.userName));
  }

  // Supporting document
  if (form.supportingDocument) {
    formData.append("document", form.supportingDocument);
  }

  return formData;
};

/**
 * Check duplicates in uploaded data against existing database
 */
export const checkDuplicatesInUpload = (uploadedRows, existingSubKpis) => {
  const existingSet = new Set();
  existingSubKpis.forEach((item) => {
    if (item.kpiId && item.subKpiName) {
      const key = `${item.kpiId}|${item.subKpiName.toLowerCase()}|${item.createdYear}`;
      existingSet.add(key);
    }
  });

  const seenInFile = new Set();

  const updatedRows = uploadedRows.map((row) => {
    if (row.hasError || !row.kpiId) return row;

    const key = `${row.kpiId}|${row.subKpiName.toLowerCase()}|${row.createdYear}`;

    let isDuplicate = false;
    let duplicateReason = "";

    if (existingSet.has(key)) {
      isDuplicate = true;
      duplicateReason = "Sub KPI already exists in database for this KPI and Year";
    }

    if (seenInFile.has(key) && !isDuplicate) {
      isDuplicate = true;
      duplicateReason = "Duplicate entry within uploaded file (same KPI, Sub KPI, and Year)";
    }

    seenInFile.add(key);

    return { ...row, isDuplicate, duplicateReason };
  });

  const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

  console.log("✅ Duplicate check completed:", {
    total: uploadedRows.length,
    duplicates: duplicateCount,
    valid: uploadedRows.length - duplicateCount,
  });

  return { updatedRows, duplicateCount };
};

/**
 * Parse Excel file for Sub KPI bulk upload
 */
export const parseSubKPIExcel = (file, lookups) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const XLSX = require("xlsx");
        const data = new Uint8Array(event.target.result);
        const workbook = XLSX.read(data, { type: "array" });

        const sheetName =
          workbook.SheetNames.find((name) => name === "Sub KPI Template") ||
          workbook.SheetNames.find((name) => !name.toLowerCase().includes("dropdown")) ||
          workbook.SheetNames[0];

        let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });

        json = json.filter((row) =>
          Object.values(row).some((cell) => String(cell).trim() !== "")
        );

        const { objectives, kpis, roles, users, years } = lookups;

        const finalRows = json.map((row) => {
          const createdYear = String(row["Created Year"] || "").trim();
          const objectiveName = String(row["Strategic Objective"] || "").trim();
          const kpiNumber = String(row["KPI Number"] || "").trim();
          const kpiName = String(row["KPI"] || "").trim();
          const subKpiName = String(row["Sub KPI"] || "").trim();
          const assessmentPeriod = String(row["Assessment Period"] || "").trim();
          const minScore = String(row["Min Score"] || "0").trim();
          const maxScore = String(row["Max Score"] || "0").trim();
          const scoringCriteria = String(row["Scoring Criteria"] || "").trim();
          const measurement = String(row["Measurement"] || "").trim();
          const annualScore = String(row["Annual Score"] || "").trim();
          const annualScoringCriteria = String(row["Annual Scoring Criteria"] || "").trim();
          const userType = String(row["User Type"] || "").trim();
          const userRoleName = String(row["User Roles"] || "").trim();
          const userName = String(row["User Names"] || "").trim();
          const criteriaDefinition = String(row["Criteria Definition"] || "").trim();
          const dataSource = String(row["Data Source"] || "").trim();
          const dealerContent = String(row["Dealer Needs to Provide Content"] || "").trim();

          const objectiveId = objectives.find(
            (o) => o.name.toLowerCase().trim() === objectiveName.toLowerCase().trim()
          )?.id || null;

          const kpiId = kpis.find(
            (k) => k.name.toLowerCase().trim() === kpiName.toLowerCase().trim()
          )?.id || null;

          const roleId = roles.find(
            (r) =>
              r.userRole?.toLowerCase().trim() === userRoleName.toLowerCase().trim() &&
              r.userType?.toLowerCase().trim() === userType.toLowerCase().trim() &&
              r.isActive === 1
          )?.id || null;

          const normalizedUserName = userName.replace(/\s+/g, " ").trim().toLowerCase();
          const userId = users.find((u) => {
            const fullName = `${u.firstName || ""} ${u.middleName || ""} ${u.lastName || ""}`
              .replace(/\s+/g, " ")
              .trim()
              .toLowerCase();
            return fullName === normalizedUserName && u.status === "ACTIVE";
          })?.id || null;

          const isValidYear = years.includes(createdYear);
          const isValidObjective = !!objectiveId;
          const isValidKpi = !!kpiId;
          const isValidSubKpi = !!subKpiName;

          const hasError = !isValidYear || !isValidObjective || !isValidKpi || !isValidSubKpi;

          return {
            createdYear,
            objectiveName,
            objectiveId,
            kpiNumber,
            kpiName,
            kpiId,
            subKpiName,
            assessmentPeriod,
            minScore,
            maxScore,
            scoringCriteria,
            measurement,
            annualScore,
            annualScoringCriteria,
            userType,
            userRoleName,
            roleId,
            userName,
            userId,
            criteriaDefinition,
            dataSource,
            dealerContent,
            hasError,
            isDuplicate: false,
            duplicateReason: "",
          };
        });

        console.log("✅ Excel parsed:", finalRows.length, "rows");
        resolve(finalRows);
      } catch (error) {
        console.error("❌ Excel parse error:", error);
        reject(new Error("Failed to parse Excel file"));
      }
    };

    reader.onerror = () => {
      reject(new Error("Failed to read file"));
    };

    reader.readAsArrayBuffer(file);
  });
};

/**
 * Get filtered roles based on user type
 */
export const getFilteredRoles = (allRoles, userType) => {
  if (!userType) return [];
  return allRoles
    .filter((role) => role.userType === userType && role.isActive === 1)
    .map((role) => ({ value: role.id, label: role.userRole }));
};

/**
 * Get filtered users based on selected roles
 */
export const getFilteredUsers = (allUsers, allRoles, selectedRoleIds) => {
  if (!selectedRoleIds || selectedRoleIds.length === 0) return [];

  return allUsers.filter((user) => {
    if (user.status !== "ACTIVE") return false;
    const role = allRoles.find((r) => r.userRole === user.persona && r.isActive === 1);
    return role && selectedRoleIds.includes(role.id);
  });
};

/**
 * Get years array for dropdown
 */
export const getYearsArray = () => {
  const currentYear = new Date().getFullYear();
  return Array.from({ length: currentYear - 2016 + 1 }, (_, i) => (2016 + i).toString());
};

/**
 * Static dropdown options
 */
export const ASSESSMENT_PERIODS = ["Quarterly", "Half yearly", "Annually"];
export const MEASUREMENTS = ["Percentage", "Absolute Value"];
export const ANNUAL_SCORE_OPTIONS = ["Sum", "Average", "Annual", "Conditional Avg"];
export const DEALER_CONTENT_OPTIONS = ["Yes", "No"];
export const USER_TYPES = [
  { value: "dealer-user", label: "Dealer User" },
  { value: "volvo-user", label: "Volvo User" },
];