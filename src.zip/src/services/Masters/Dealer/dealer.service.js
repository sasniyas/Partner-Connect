// services/Masters/Dealer/dealer.service.js

import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Helper function to get auth token
 */
const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

/**
 * Helper function to handle token errors
 */
const handleTokenError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// ═══════════════════════════════════════════════════════════════
// 📊 DEALER CRUD OPERATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Get All Dealers (raw data)
 */
export const getAllDealers = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getDealers}`;

    console.log("📡 Fetching Dealers");

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Dealers Response:", {
      status: response.status,
      recordCount: response.data.data?.length || 0,
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllDealers Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch Dealers"
    );
  }
};

/**
 * Get All Dealers Formatted for Table
 */
export const getAllDealersFormatted = async () => {
  try {
    const data = await getAllDealers();
    return data.map((dealer) => ({
      id: dealer.id,
      dealerName: dealer.dealerName,
      dealerShortName: dealer.dealerShortName,
      marketArea: dealer.marketName,
      marketAreaId: dealer.market_id,
      states: dealer.stateName,
      stateId: dealer.state_id,
      status: dealer.isActive === 1 ? "Active" : "Inactive",
      isActive: dealer.isActive,
      createdOn: dealer.createdOn,
    }));
  } catch (error) {
    console.error("❌ getAllDealersFormatted Error:", error.message);
    throw error;
  }
};

/**
 * Get Active Dealers (for dropdowns)
 */
export const getActiveDealers = async () => {
  try {
    const data = await getAllDealers();
    return data
      .filter((dealer) => dealer.isActive === 1)
      .map((dealer) => ({
        id: dealer.id,
        dealerName: dealer.dealerName,
        dealerShortName: dealer.dealerShortName,
        marketArea: dealer.marketName,
        states: dealer.stateName,
      }));
  } catch (error) {
    console.error("❌ getActiveDealers Error:", error.message);
    throw error;
  }
};

/**
 * Add New Dealer
 * @param {Object} payload - { market_id, state_id, dealerName, dealerShortName }
 */
export const addDealer = async (payload) => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.addDealer}`;

    console.log("📡 Adding Dealer");

    const response = await axios.post(url, payload, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Add Dealer Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ addDealer Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to add Dealer"
    );
  }
};

/**
 * Update Dealer
 * @param {Object} payload - { id, market_id, state_id, dealerName, dealerShortName }
 */
export const updateDealer = async (payload) => {
  try {
    const { id, ...updateData } = payload;

    if (!id) {
      throw new Error("Dealer ID is required for update");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.updateDealer}`;

    console.log("📡 Updating Dealer ID:", id);
console.log("📡 Updating Dealer ID:", updateData);
    const response = await axios.put(
      url,
      { id, ...updateData },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Update Dealer Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ updateDealer Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update Dealer"
    );
  }
};

/**
 * Delete Dealer by ID
 */
export const deleteDealer = async (id) => {
  try {
    if (!id) {
      throw new Error("Dealer ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.deleteDealer}/${id}`;

    console.log("📡 Deleting Dealer ID:", id);

    const response = await axios.delete(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Delete Dealer Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ deleteDealer Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete Dealer"
    );
  }
};

/**
 * Toggle Dealer Status by ID (Activate/Deactivate)
 */
export const toggleDealerStatus = async (id, isActive) => {
  try {
    if (!id) {
      throw new Error("Dealer ID is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.toggleDealer}/${id}`;

    console.log("📡 Toggling Dealer Status ID:", id, "to:", isActive);

    const response = await axios.patch(
      url,
      { isActive },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Toggle Dealer Response:", {
      status: response.status,
      message: response.data.message,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ toggleDealerStatus Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to toggle Dealer status"
    );
  }
};

/**
 * Bulk Add Dealers
 * @param {Array} dealers - Array of { market_id, state_id, dealerName, dealerShortName }
 */
export const bulkAddDealers = async (dealers) => {
  try {
    if (!dealers || !Array.isArray(dealers) || dealers.length === 0) {
      throw new Error("Dealers array is required");
    }

    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.bulkAddDealer}`;

    console.log("📡 Bulk Adding Dealers:", dealers.length);

    const response = await axios.post(
      url,
      { rows: dealers },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("✅ Bulk Add Dealers Response:", {
      status: response.status,
      inserted: response.data.data?.inserted,
      invalid: response.data.data?.invalid,
    });

    return response.data;
  } catch (error) {
    handleTokenError(error);
    console.error("❌ bulkAddDealers Error:", error.message);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to bulk add Dealers"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📊 MARKET AREA & STATE OPERATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Get All Market Areas
 */
export const getAllMarketAreas = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getMarketarea}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllMarketAreas Error:", error.message);
    throw error;
  }
};

/**
 * Get Active Market Areas (for dropdowns)
 */
export const getActiveMarketAreas = async () => {
  try {
    const data = await getAllMarketAreas();
    return data.filter((area) => area.isActive === 1);
  } catch (error) {
    console.error("❌ getActiveMarketAreas Error:", error.message);
    throw error;
  }
};

/**
 * Get All States
 */
export const getAllStates = async () => {
  try {
    const token = getAuthToken();
    if (!token) {
      throw new Error("Authentication token not found");
    }

    const url = `${API.domain}${API.masters.getStates}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (Array.isArray(response.data?.data)) {
      return response.data.data;
    }

    return [];
  } catch (error) {
    handleTokenError(error);
    console.error("❌ getAllStates Error:", error.message);
    throw error;
  }
};

/**
 * Get States by Market Area ID
 */
export const getStatesByMarketArea = async (marketAreaId) => {
  try {
    const allStates = await getAllStates();
    return allStates.filter(
      (state) => state.marketarea_id === marketAreaId && state.isActive === 1
    );
  } catch (error) {
    console.error("❌ getStatesByMarketArea Error:", error.message);
    throw error;
  }
};

/**
 * Get States by Market Area Name
 */
export const getStatesByMarketAreaName = (allStates, marketAreas, marketAreaName) => {
  const marketArea = marketAreas.find(
    (ma) => ma.marketarea.toLowerCase() === marketAreaName.toLowerCase()
  );
  
  if (!marketArea) return allStates.filter((s) => s.isActive === 1);
  
  const filteredStates = allStates.filter(
    (s) => s.marketarea_id === marketArea.id && s.isActive === 1
  );
  
  return filteredStates.length > 0 ? filteredStates : [];
};

// ═══════════════════════════════════════════════════════════════
// 🔧 VALIDATION HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Check if Dealer exists (for duplicate validation) - Using ID
 * @param {Array} dealers - Current dealers data
 * @param {string} marketArea - Market area name
 * @param {string} dealerName - Dealer name
 * @param {number|null} excludeId - ID to exclude (for edit mode)
 */
export const checkDealerExists = (dealers, marketArea, dealerName, excludeId = null) => {
  return dealers.some((item) => {
    // Skip the current item being edited (by ID)
    if (excludeId !== null && item.id === excludeId) {
      return false;
    }
    return (
      item.marketArea === marketArea &&
      item.dealerName?.toLowerCase() === dealerName?.trim().toLowerCase()
    );
  });
};

/**
 * Check duplicates in uploaded data against existing database
 * @param {Array} uploadedRows - Rows from uploaded file
 * @param {Array} existingDealers - Existing dealers from database
 * @returns {Object} - { updatedRows, duplicateCount }
 */
export const checkDuplicatesInUpload = (uploadedRows, existingDealers) => {
  const existingSet = new Set();
  existingDealers.forEach((item) => {
    const key = `${(item.dealerName || "").toLowerCase()}|${item.market_id}|${item.state_id}`;
    existingSet.add(key);
  });

  const seenInFile = new Set();

  const updatedRows = uploadedRows.map((row) => {
    if (row.hasError) return row;

    const key = `${row.dealerName.toLowerCase()}|${row.market_id}|${row.state_id}`;

    let isDuplicate = false;
    let duplicateReason = "";

    if (!row.market_id || !row.state_id || !row.dealerName) {
      return {
        ...row,
        hasError: true,
        isDuplicate: false,
        duplicateReason: "",
      };
    }

    if (existingSet.has(key)) {
      isDuplicate = true;
      duplicateReason = "Dealer already exists in database";
    }

    if (seenInFile.has(key) && !isDuplicate) {
      isDuplicate = true;
      duplicateReason = "Duplicate dealer within file";
    }

    seenInFile.add(key);

    return { ...row, isDuplicate, duplicateReason };
  });

  const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

  return { updatedRows, duplicateCount };
};

/**
 * Find Dealer by ID
 */
export const findDealerById = (dealers, id) => {
  return dealers.find((dealer) => dealer.id === id) || null;
};

/**
 * Get Market Area ID by Name
 */
export const getMarketAreaIdByName = (marketAreas, name) => {
  const marketArea = marketAreas.find(
    (ma) => ma.marketarea.toLowerCase() === name.toLowerCase()
  );
  return marketArea?.id || null;
};

/**
 * Get State ID by Name
 */
export const getStateIdByName = (states, name) => {
  const state = states.find(
    (s) => s.stateName.toLowerCase() === name.toLowerCase()
  );
  return state?.id || null;
};