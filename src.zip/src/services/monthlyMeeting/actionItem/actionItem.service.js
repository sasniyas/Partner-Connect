import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 MONTHLY MEETING ACTION ITEM SERVICE
// Complete CRUD operations for Monthly Meeting Action Items
// Pattern: Same as PDP Action Item Service
// ═══════════════════════════════════════════════════════════════

const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

const handleTokenExpiry = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

const getAxiosConfig = () => {
  const token = getAuthToken();
  if (!token) {
    throw new Error("Authentication token not found. Please login again.");
  }
  return {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
};

// ═══════════════════════════════════════════════════════════════
// ➕ CREATE ACTION ITEM
// Route: POST /addActionItem
// ═══════════════════════════════════════════════════════════════

export const createActionItem = async (payload) => {
  try {
    if (!payload.monthly_meeting_id) {
      throw new Error("Monthly meeting ID is required");
    }
    if (!payload.department) {
      throw new Error("Department is required");
    }
    if (!payload.topic_of_discussion) {
      throw new Error("Topic of discussion is required");
    }
    if (!payload.responsibility) {
      throw new Error("Responsibility is required");
    }

    if (payload.status) {
      const validStatuses = ["Open", "Closed", "In Progress"];
      if (!validStatuses.includes(payload.status)) {
        throw new Error(`Invalid status. Must be one of: ${validStatuses.join(", ")}`);
      }
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.addActionItem}`;

    const cleanPayload = {
      monthly_meeting_id: parseInt(payload.monthly_meeting_id, 10),
      department: parseInt(payload.department, 10),
      topic_of_discussion: payload.topic_of_discussion,
      closure_action: payload.closure_action || null,
      responsibility: parseInt(payload.responsibility, 10),
      target_date: payload.target_date || null,
      completed_date: payload.completed_date || null,
      status: payload.status || "Open",
      comments: payload.comments || null,
      action_progress_update: payload.action_progress_update || null,
      target_date_change: payload.target_date_change || false,
    };

    const response = await axios.post(url, cleanPayload, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to create action item");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to create action item"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET ALL ACTION ITEMS
// Route: GET /getActionItems?monthly_meeting_id=&status=&department=&responsibility=
// ═══════════════════════════════════════════════════════════════

export const getAllActionItems = async (filters = {}) => {
  try {
    const config = getAxiosConfig();

    const params = new URLSearchParams();
    if (filters.monthly_meeting_id) params.append("monthly_meeting_id", filters.monthly_meeting_id);
    if (filters.status) params.append("status", filters.status);
    if (filters.department) params.append("department", filters.department);
    if (filters.responsibility) params.append("responsibility", filters.responsibility);

    const queryString = params.toString();
    const url = `${API.domain}${API.endpoints.getActionItems}${queryString ? `?${queryString}` : ""}`;

    const response = await axios.get(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to fetch action items");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action items"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET ACTION ITEM BY ID
// Route: GET /getActionItem/:id
// ═══════════════════════════════════════════════════════════════

export const getActionItemById = async (id) => {
  try {
    if (!id) {
      throw new Error("Action item ID is required");
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.getActionItemById}${id}`;

    const response = await axios.get(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to fetch action item");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action item"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET ACTION ITEMS BY MEETING
// Route: GET /getActionItemsByMeeting/:meeting_id
// ═══════════════════════════════════════════════════════════════

export const getActionItemsByMeeting = async (meetingId) => {
  try {
    if (!meetingId) {
      throw new Error("Meeting ID is required");
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.getActionItemsByMeeting}${meetingId}`;

    const response = await axios.get(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to fetch action items by meeting");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action items by meeting"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// ✏️ UPDATE ACTION ITEM
// Route: PUT /updateActionItem
// Supports full update (admin/creator) and partial update (assigned person)
// ═══════════════════════════════════════════════════════════════

export const updateActionItem = async (payload) => {
  try {
    if (!payload.id) {
      throw new Error("Action item ID is required for update");
    }

    if (payload.status) {
      const validStatuses = ["Open", "Closed", "In Progress"];
      if (!validStatuses.includes(payload.status)) {
        throw new Error(`Invalid status. Must be one of: ${validStatuses.join(", ")}`);
      }
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.updateActionItem}`;

    // Clean payload - only include defined values
    const cleanPayload = { id: parseInt(payload.id, 10) };

    if (payload.monthly_meeting_id !== undefined) cleanPayload.monthly_meeting_id = payload.monthly_meeting_id ? parseInt(payload.monthly_meeting_id, 10) : null;
    if (payload.department !== undefined) cleanPayload.department = payload.department ? parseInt(payload.department, 10) : null;
    if (payload.topic_of_discussion !== undefined) cleanPayload.topic_of_discussion = payload.topic_of_discussion;
    if (payload.closure_action !== undefined) cleanPayload.closure_action = payload.closure_action;
    if (payload.responsibility !== undefined) cleanPayload.responsibility = payload.responsibility ? parseInt(payload.responsibility, 10) : null;
    if (payload.target_date !== undefined) cleanPayload.target_date = payload.target_date;
    if (payload.completed_date !== undefined) cleanPayload.completed_date = payload.completed_date;
    if (payload.status !== undefined) cleanPayload.status = payload.status;
    if (payload.comments !== undefined) cleanPayload.comments = payload.comments;
    if (payload.action_progress_update !== undefined) cleanPayload.action_progress_update = payload.action_progress_update;
    if (payload.target_date_change !== undefined) cleanPayload.target_date_change = payload.target_date_change;

    const response = await axios.put(url, cleanPayload, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update action item");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update action item"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 🔄 UPDATE ACTION ITEM STATUS
// Route: PUT /updateActionItemStatus/:id
// ═══════════════════════════════════════════════════════════════

export const updateActionItemStatus = async (id, status, completed_date) => {
  try {
    if (!id || !status) {
      throw new Error("ID and status are required");
    }

    const validStatuses = ["Open", "Closed", "In Progress"];
    if (!validStatuses.includes(status)) {
      throw new Error(`Invalid status. Must be one of: ${validStatuses.join(", ")}`);
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.updateActionItemStatus}${id}`;

    const body = { status };
    if (completed_date) body.completed_date = completed_date;

    const response = await axios.put(url, body, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update action item status");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update action item status"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 🗑️ DELETE ACTION ITEM (Soft Delete)
// Route: DELETE /deleteActionItem/:id
// ═══════════════════════════════════════════════════════════════

export const deleteActionItem = async (id) => {
  try {
    if (!id) {
      throw new Error("Action item ID is required for deletion");
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.deleteActionItem}${id}`;

    const response = await axios.delete(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete action item");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete action item"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📅 GET TARGET DATE HISTORY (NEW)
// Route: GET /getTargetDate/:action_item_id
// Uses existing backend endpoint (line ~376 in actionLog controller)
// Returns array of previous target dates from action_log table
// ═══════════════════════════════════════════════════════════════

export const getTargetDateHistory = async (actionItemId) => {
  try {
    if (!actionItemId) {
      throw new Error("Action item ID is required");
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.monthlyMeaatingendpoints.getTargetDate}${actionItemId}`;

    const response = await axios.get(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to fetch target date history");
  } catch (error) {
    handleTokenExpiry(error);
    // Don't throw for this - it's supplementary data, return empty
    return { status: true, data: [] };
  }
};

export const getUsersByMonthlyMeetingDealer = async (monthlyMeetingId) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    const response = await fetch(
      `${API.domain}${API.endpoints.getUsersByMonthlyMeetingDealer}${monthlyMeetingId}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return await response.json();
  } catch (error) {
    console.error("Error fetching users by dealer:", error);
    return { status: false, message: error.message, data: [] };
  }
};