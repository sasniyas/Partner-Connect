import axios from "axios";
import { API } from "../../../api";

// ═══════════════════════════════════════════════════════════════
// 📡 MONTHLY MEETING ACTION LOG SERVICE
// Complete CRUD operations for Monthly Meeting Action Logs
// Pattern: Same as PDP Action Log Service
// ═══════════════════════════════════════════════════════════════

const getAuthToken = () => {
  return localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
};

const handleTokenExpiry = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

const getAxiosConfig = () => {
  const token = getAuthToken();
  if (!token) {
    throw new Error("Authentication token not found. Please login again.");
  }
  return {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET ACTION LOGS BY ACTION ITEM ID
// Route: GET /getActionLogsByActionItem/:action_item_id
// ═══════════════════════════════════════════════════════════════

export const getActionLogs = async (actionItemId) => {
  try {
    if (!actionItemId) {
      throw new Error("Action item ID is required");
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.getActionLogsByActionItem}${actionItemId}`;

    const response = await axios.get(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to fetch action logs");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action logs"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET ALL ACTION LOGS
// Route: GET /getActionLogs?action_item_id=&updated_by=
// ═══════════════════════════════════════════════════════════════

export const getAllActionLogs = async (filters = {}) => {
  try {
    const config = getAxiosConfig();

    const params = new URLSearchParams();
    if (filters.action_item_id) params.append("action_item_id", filters.action_item_id);
    if (filters.updated_by) params.append("updated_by", filters.updated_by);

    const queryString = params.toString();
    const url = `${API.domain}${API.endpoints.getActionLogs}${queryString ? `?${queryString}` : ""}`;

    const response = await axios.get(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to fetch action logs");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action logs"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 📋 GET ACTION LOG BY ID
// Route: GET /getActionLog/:id
// ═══════════════════════════════════════════════════════════════

export const getActionLogById = async (id) => {
  try {
    if (!id) {
      throw new Error("Action log ID is required");
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.getActionLogById}${id}`;

    const response = await axios.get(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to fetch action log");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to fetch action log"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// ➕ ADD ACTION LOG
// Route: POST /addActionLog
// Note: Logs are auto-created by backend on action item create/update
// ═══════════════════════════════════════════════════════════════

export const createActionLog = async (payload) => {
  try {
    if (!payload.action_item_id) {
      throw new Error("Action item ID is required");
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.addActionLog}`;

    const cleanPayload = {
      action_item_id: parseInt(payload.action_item_id, 10),
      present_status: payload.present_status || null,
      comments: payload.comments || null,
    };

    const response = await axios.post(url, cleanPayload, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to create action log");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to create action log"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// ✏️ UPDATE ACTION LOG
// Route: PUT /updateActionLog/:id
// ═══════════════════════════════════════════════════════════════

export const updateActionLog = async (id, payload) => {
  try {
    if (!id) {
      throw new Error("Action log ID is required");
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.updateActionLog}${id}`;

    const response = await axios.put(url, payload, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to update action log");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to update action log"
    );
  }
};

// ═══════════════════════════════════════════════════════════════
// 🗑️ DELETE ACTION LOG
// Route: DELETE /deleteActionLog/:id
// ═══════════════════════════════════════════════════════════════

export const deleteActionLog = async (id) => {
  try {
    if (!id) {
      throw new Error("Action log ID is required");
    }

    const config = getAxiosConfig();
    const url = `${API.domain}${API.endpoints.deleteActionLog}${id}`;

    const response = await axios.delete(url, config);

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete action log");
  } catch (error) {
    handleTokenExpiry(error);
    throw new Error(
      error.response?.data?.message || error.message || "Failed to delete action log"
    );
  }
};