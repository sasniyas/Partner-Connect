import axios from 'axios';
import { API } from '../../../api';

// Add Monthly Meeting Template
// templateData: { monthly_meeting: number, file?: File }
export const addMonthlyMeetingTemplate = async (templateData) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const formData = new FormData();
    formData.append('monthly_meeting', templateData.monthly_meeting);

    // Append file if provided — backend reads req.files[0]
    if (templateData.file && templateData.file instanceof File) {
      formData.append('upload_file', templateData.file);
    }

    const response = await axios.post(
      `${API.domain}${API.monthlyMeaatingendpoints.addMonthlyMeetingTemplate}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add monthly meeting template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding monthly meeting template:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add monthly meeting template");
  }
};

// Get All Monthly Meeting Templates
export const getAllMonthlyMeetingTemplates = async (monthly_meeting = null) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    let url = `${API.domain}${API.monthlyMeaatingendpoints.getMonthlyMeetingTemplates}`;
    
    // Add optional query parameter if provided
    if (monthly_meeting) {
      url += `?monthly_meeting=${monthly_meeting}`;
    }

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to fetch monthly meeting templates");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching monthly meeting templates:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch monthly meeting templates");
  }
};

// Get Monthly Meeting Template by ID
export const getMonthlyMeetingTemplateById = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.monthlyMeaatingendpoints.getMonthlyMeetingTemplate}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to fetch monthly meeting template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching monthly meeting template:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch monthly meeting template");
  }
};

// Get Monthly Meeting Templates by Monthly Meeting ID
export const getMonthlyMeetingTemplatesByMonthlyMeeting = async (monthly_meeting) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.monthlyMeaatingendpoints.getMonthlyMeetingTemplatesByMonthlyMeeting}${monthly_meeting}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to fetch monthly meeting templates");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching monthly meeting templates:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch monthly meeting templates");
  }
};

// Update Monthly Meeting Template
// templateData can contain: master_fileName, master_fileLink, upload_fileLink, or upload_file (File object)
// If upload_file is provided, it will be uploaded to Azure storage and the link will be stored in upload_fileLink
export const updateMonthlyMeetingTemplate = async (id, templateData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const formData = new FormData();

    // Add optional fields if provided
    if (templateData.master_fileName !== undefined) {
      formData.append('master_fileName', templateData.master_fileName);
    }

    if (templateData.master_fileLink !== undefined) {
      formData.append('master_fileLink', templateData.master_fileLink);
    }

    if (templateData.upload_fileLink !== undefined && !templateData.upload_file) {
      // If upload_fileLink is provided directly (without file), add it
      formData.append('upload_fileLink', templateData.upload_fileLink);
    }

    // Add file if present (this will be uploaded to Azure storage and stored in upload_fileLink)
    if (templateData.upload_file) {
      formData.append('upload_file', templateData.upload_file);
    }

    const response = await axios.put(
      `${API.domain}${API.monthlyMeaatingendpoints.updateMonthlyMeetingTemplate}${id}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to update monthly meeting template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating monthly meeting template:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to update monthly meeting template");
  }
};

// Upload file to Monthly Meeting Template
// Convenience function specifically for uploading a file to update the upload_fileLink field
export const uploadFileToMonthlyMeetingTemplate = async (id, file) => {
  try {
    return await updateMonthlyMeetingTemplate(id, { upload_file: file });
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error uploading file to monthly meeting template:", error);
    throw error;
  }
};

// Bulk upload files to Monthly Meeting Templates
// Accepts an array of {id, file} objects where id is the template ID and file is the File object
export const bulkUploadMonthlyMeetingTemplates = async (uploads) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    if (!Array.isArray(uploads) || uploads.length === 0) {
      throw new Error("Uploads array is required and must not be empty");
    }

    // Validate uploads structure
    const templateIds = [];
    for (const upload of uploads) {
      if (!upload.id) {
        throw new Error("Each upload must have an id property");
      }
      if (!upload.file || !(upload.file instanceof File)) {
        throw new Error("Each upload must have a file property that is a File object");
      }
      templateIds.push(upload.id);
    }

    // Create FormData for multiple file uploads
    const formData = new FormData();

    // Add template IDs as JSON array
    formData.append('templateIds', JSON.stringify(templateIds));

    // Add each file in order (they will be matched by index with templateIds)
    uploads.forEach((upload) => {
      formData.append('files', upload.file);
    });

    const response = await axios.post(
      `${API.domain}${API.monthlyMeaatingendpoints.bulkUploadMonthlyMeetingTemplates}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk upload monthly meeting templates");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk uploading monthly meeting templates:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk upload monthly meeting templates");
  }
};

// Delete Monthly Meeting Template
export const deleteMonthlyMeetingTemplate = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.monthlyMeaatingendpoints.deleteMonthlyMeetingTemplate}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to delete monthly meeting template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting monthly meeting template:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete monthly meeting template");
  }
};