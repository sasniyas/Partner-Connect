import axios from 'axios';
import { API } from '../../../api';

// Helper: get auth token
const getToken = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  if (!token) throw new Error("No authentication token found");
  return token;
};

// Helper: handle token expiry
const handleAuthError = (error) => {
  const message = error.response?.data?.message;
  if (message === "token is invalid" || message === "jwt expired") {
    localStorage.removeItem("userToken");
    localStorage.removeItem("superUserToken");
    window.location.href = "/";
  }
};

// Add Monthly Meeting
export const addMonthlyMeeting = async (monthlyMeetingData) => {
  try {
    const token = getToken();
    const formData = new FormData();

    // Required fields
    formData.append('market_area_id', monthlyMeetingData.market_area_id);
    formData.append('dealer_id', monthlyMeetingData.dealer_id);
    formData.append('meeting_date', monthlyMeetingData.meeting_date);
    formData.append('start_time', monthlyMeetingData.start_time);
    formData.append('end_time', monthlyMeetingData.end_time);
    formData.append('recurring_meeting', monthlyMeetingData.recurring_meeting || 'One-time Meeting');
    formData.append('meeting_mode', monthlyMeetingData.meeting_mode);
    formData.append('meeting_venue', monthlyMeetingData.meeting_venue || '');
    formData.append('meet_link', monthlyMeetingData.meet_link || '');
    formData.append('agenda_text', monthlyMeetingData.agenda_text || '');

    // Recurring meeting fields — backend expects these for non-one-time meetings
    if (monthlyMeetingData.limit_date) {
      formData.append('limit_date', monthlyMeetingData.limit_date);
    }
    if (monthlyMeetingData.next_meeting_date) {
      formData.append('next_meeting_date', monthlyMeetingData.next_meeting_date);
    }

    // Status (optional for create, backend defaults to 'Created')
    if (monthlyMeetingData.status) {
      formData.append('status', monthlyMeetingData.status);
    }

    // User IDs — backend expects JSON stringified arrays
    if (monthlyMeetingData.dealerUserIds) {
      formData.append('dealerUserIds', JSON.stringify(
        Array.isArray(monthlyMeetingData.dealerUserIds) 
          ? monthlyMeetingData.dealerUserIds 
          : []
      ));
    }
    if (monthlyMeetingData.volvoUserIds) {
      formData.append('volvoUserIds', JSON.stringify(
        Array.isArray(monthlyMeetingData.volvoUserIds) 
          ? monthlyMeetingData.volvoUserIds 
          : []
      ));
    }

    // Email arrays — backend expects JSON stringified arrays
    if (monthlyMeetingData.externalEmails) {
      formData.append('externalEmails', JSON.stringify(
        Array.isArray(monthlyMeetingData.externalEmails) 
          ? monthlyMeetingData.externalEmails 
          : []
      ));
    }
    if (monthlyMeetingData.optionalEmails) {
      formData.append('optionalEmails', JSON.stringify(
        Array.isArray(monthlyMeetingData.optionalEmails) 
          ? monthlyMeetingData.optionalEmails 
          : []
      ));
    }

    // File upload — backend reads req.files[0]
    if (monthlyMeetingData.agenda_file && monthlyMeetingData.agenda_file instanceof File) {
      formData.append('agenda_file', monthlyMeetingData.agenda_file);
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.addMonthlyMeeting}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add monthly meeting");
  } catch (error) {
    handleAuthError(error);
    console.error("Error adding monthly meeting:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add monthly meeting");
  }
};

// Get All Monthly Meetings
export const getAllMonthlyMeetings = async () => {
  try {
    const token = getToken();

    const response = await axios.get(
      `${API.domain}${API.endpoints.getMonthlyMeetings}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to fetch monthly meetings");
  } catch (error) {
    handleAuthError(error);
    console.error("Error fetching monthly meetings:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch monthly meetings");
  }
};

// Get Monthly Meeting by ID
export const getMonthlyMeetingById = async (id) => {
  try {
    const token = getToken();

    const response = await axios.get(
      `${API.domain}${API.endpoints.getMonthlyMeetingById}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to fetch monthly meeting");
  } catch (error) {
    handleAuthError(error);
    console.error("Error fetching monthly meeting:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch monthly meeting");
  }
};

// Update Monthly Meeting
export const updateMonthlyMeeting = async (monthlyMeetingData) => {
  try {
    const token = getToken();
    const formData = new FormData();

    // ID is always required
    formData.append('id', monthlyMeetingData.id);

    // Check if this is a status-only update (Cancel or Complete)
    // Backend controller checks: status === 'Cancelled' || status === 'Completed'
    const isStatusOnlyUpdate = 
      monthlyMeetingData.status === 'Cancelled' || 
      monthlyMeetingData.status === 'Completed';

    if (isStatusOnlyUpdate) {
      // Status-only update — only send status and cancellation fields
      formData.append('status', monthlyMeetingData.status);

      if (monthlyMeetingData.cancellation_reason) {
        formData.append('cancellation_reason', monthlyMeetingData.cancellation_reason);
      }
    } else {
      // Full update — send all meeting fields

      // Required fields
      formData.append('market_area_id', monthlyMeetingData.market_area_id);
      formData.append('dealer_id', monthlyMeetingData.dealer_id);
      formData.append('meeting_date', monthlyMeetingData.meeting_date);
      formData.append('start_time', monthlyMeetingData.start_time);
      formData.append('end_time', monthlyMeetingData.end_time);
      formData.append('recurring_meeting', monthlyMeetingData.recurring_meeting || 'One-time Meeting');
      formData.append('meeting_mode', monthlyMeetingData.meeting_mode);
      formData.append('meeting_venue', monthlyMeetingData.meeting_venue || '');
      formData.append('meet_link', monthlyMeetingData.meet_link || '');
      formData.append('agenda_text', monthlyMeetingData.agenda_text || '');

      // Recurring meeting fields
      // Send limit_date and next_meeting_date — backend stores these directly
      if (monthlyMeetingData.limit_date) {
        formData.append('limit_date', monthlyMeetingData.limit_date);
      }
      if (monthlyMeetingData.next_meeting_date) {
        formData.append('next_meeting_date', monthlyMeetingData.next_meeting_date);
      }

      // Optional status field for regular updates
      if (monthlyMeetingData.status) {
        formData.append('status', monthlyMeetingData.status);
      }

      // User IDs — backend expects JSON stringified arrays
      if (monthlyMeetingData.dealerUserIds) {
        formData.append('dealerUserIds', JSON.stringify(
          Array.isArray(monthlyMeetingData.dealerUserIds) 
            ? monthlyMeetingData.dealerUserIds 
            : []
        ));
      }
      if (monthlyMeetingData.volvoUserIds) {
        formData.append('volvoUserIds', JSON.stringify(
          Array.isArray(monthlyMeetingData.volvoUserIds) 
            ? monthlyMeetingData.volvoUserIds 
            : []
        ));
      }

      // Email arrays — backend expects JSON stringified arrays
      if (monthlyMeetingData.externalEmails) {
        formData.append('externalEmails', JSON.stringify(
          Array.isArray(monthlyMeetingData.externalEmails) 
            ? monthlyMeetingData.externalEmails 
            : []
        ));
      }
      if (monthlyMeetingData.optionalEmails) {
        formData.append('optionalEmails', JSON.stringify(
          Array.isArray(monthlyMeetingData.optionalEmails) 
            ? monthlyMeetingData.optionalEmails 
            : []
        ));
      }

      // File upload — only append if it's an actual File object
      // Backend reads req.files[0] and uploads to Azure
      // If no new file, backend keeps the old agenda_file_url
      if (monthlyMeetingData.agenda_file && monthlyMeetingData.agenda_file instanceof File) {
        formData.append('agenda_file', monthlyMeetingData.agenda_file);
      }
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateMonthlyMeeting}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to update monthly meeting");
  } catch (error) {
    handleAuthError(error);
    console.error("Error updating monthly meeting:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to update monthly meeting");
  }
};

// Delete Monthly Meeting
export const deleteMonthlyMeeting = async (id) => {
  try {
    const token = getToken();

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteMonthlyMeeting}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to delete monthly meeting");
  } catch (error) {
    handleAuthError(error);
    console.error("Error deleting monthly meeting:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete monthly meeting");
  }
};