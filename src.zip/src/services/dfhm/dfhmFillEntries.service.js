/**
 * DFHM Fill Entries Service
 * Handles API calls and data transformations for P&L, Balance Sheet, Head Count, AR Aging
 */

import axios from "axios";
import { API } from "../../api";

// Base URL from API config
const BASE_URL = API.domain;
const DFHM_ENDPOINTS = API.dfhmEndpoints;

// ============================================
// QUARTER MONTH MAPPING (EXPORTED)
// ============================================
export const quarterMonthsMap = {
  Q1: ["Jan", "Feb", "Mar"],
  Q2: ["Apr", "May", "Jun"],
  Q3: ["Jul", "Aug", "Sep"],
  Q4: ["Oct", "Nov", "Dec"],
};

// ============================================
// UTILITY FUNCTIONS (EXPORTED)
// ============================================

/**
 * Get auth headers with token
 */
const getAuthHeaders = () => {
 const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

/**
 * Parse numeric value (handles null, undefined, strings with commas)
 */
export const parseNumericValue = (val) => {
  if (val === null || val === undefined || val === "") return 0;
  if (typeof val === "number") return val;
  // Remove commas and parse
  return parseFloat(String(val).replace(/,/g, "")) || 0;
};

/**
 * Format number with Indian comma notation
 */
export const formatIndianNumber = (num) => {
  if (num === null || num === undefined || num === 0) return "0";
  const absNum = Math.abs(num);
  const sign = num < 0 ? "-" : "";
  
  // Convert to string and split decimal
  const [intPart, decPart] = absNum.toString().split(".");
  
  // Indian number formatting
  let formatted = intPart;
  if (intPart.length > 3) {
    const lastThree = intPart.slice(-3);
    const remaining = intPart.slice(0, -3);
    formatted = remaining.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + "," + lastThree;
  }
  
  return sign + formatted + (decPart ? "." + decPart : "");
};

/**
 * Calculate derived values
 */
export const calculateDerivedValues = (month1, month2, month3, ytd, bp) => {
  const m1 = parseNumericValue(month1);
  const m2 = parseNumericValue(month2);
  const m3 = parseNumericValue(month3);
  const ytdVal = parseNumericValue(ytd);
  const bpVal = parseNumericValue(bp);

  const quarterTotal = m1 + m2 + m3;
  const vsBP = ytdVal - bpVal;
  const vbpm = bpVal !== 0 ? ((ytdVal - bpVal) / bpVal) * 100 : 0;
  const runRate = bpVal !== 0 ? (ytdVal / bpVal) * 100 : 0;

  return {
    quarterTotal,
    vsBP,
    vbpm: vbpm.toFixed(2),
    runRate: runRate.toFixed(2),
  };
};

// ============================================
// P&L (PROFIT & LOSS) APIs
// ============================================

/**
 * Fetch P&L data by DFHM ID
 */
export const getDfhmPlByDfhmId = async (dfhmId) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${DFHM_ENDPOINTS.getDfhmPlByDfhmId}${dfhmId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching P&L data:", error);
    throw error;
  }
};

/**
 * Fetch P&L data by Filters (quarter, year, dealerId)
 */
export const getDfhmPlByFilters = async (filters) => {
  try {
    const { quarter, year, dealerId } = filters;
    const params = new URLSearchParams();
    
    if (quarter) params.append("quarter", quarter);
    if (year) params.append("year", year);
    if (dealerId) params.append("dealerId", dealerId);
    
    const response = await axios.get(
      `${BASE_URL}${DFHM_ENDPOINTS.getDfhmPlByFilters}?${params.toString()}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching P&L data by filters:", error);
    throw error;
  }
};

/**
 * Update multiple P&L records
 */
export const updateMultipleDfhmPl = async (rows) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${DFHM_ENDPOINTS.bulkUpdateDfhmPl}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating P&L data:", error);
    throw error;
  }
};

/**
 * Transform API P&L data to table format
 * Groups by category and creates the nested structure expected by the table
 * Auto-generates a Total row at the end of each category
 */
export const transformPlDataForTable = (apiData, quarter) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return [];
  }

  const months = quarterMonthsMap[quarter] || ["Jan", "Feb", "Mar"];
  
  // Group data by category
  const groupedData = {};
  
  apiData.forEach((item) => {
    const category = item.pl_master_info?.category || "Others";
    const subCategory = item.pl_master_info?.subCategory || "";
    const categoryType = item.pl_master_info?.categoryType || ""; // Revenue, Profit, Expense
    
    if (!groupedData[category]) {
      groupedData[category] = {
        category,
        categoryType, // Store categoryType for filtering
        rows: [],
        isTotalRow: false, // This is for GRAND total sections only
      };
    }

    // Calculate derived values
    const derived = calculateDerivedValues(
      item.month1,
      item.month2,
      item.month3,
      item.ytd,
      item.bp
    );

    groupedData[category].rows.push({
      id: item.id, // Keep ID for updates
      master_pl_id: item.master_pl_id,
      dfhm_id: item.dfhm_id,
      subCategory,
      isTotal: false, // Regular data rows are not totals
      isCalculatedTotal: false, // Not a calculated total
      values: {
        [months[0]]: item.month1 || 0,
        [months[1]]: item.month2 || 0,
        [months[2]]: item.month3 || 0,
        Q1: derived.quarterTotal,
        YTD: item.ytd || 0,
        BP: item.bp || 0,
        VSBP: derived.vsBP,
        VBPM: derived.vbpm,
        runRate: derived.runRate,
      },
      rawValues: {
        month1: item.month1,
        month2: item.month2,
        month3: item.month3,
        ytd: item.ytd,
        bp: item.bp,
      },
    });
  });

  // Convert to array and add calculated total row for each category
  const result = Object.values(groupedData).map((section) => {
    // Calculate totals for this category
    const totalValues = {
      [months[0]]: 0,
      [months[1]]: 0,
      [months[2]]: 0,
      Q1: 0,
      YTD: 0,
      BP: 0,
      VSBP: 0,
      VBPM: 0,
      runRate: 0,
    };

    // Sum up all rows
    section.rows.forEach((row) => {
      totalValues[months[0]] += parseNumericValue(row.values[months[0]]);
      totalValues[months[1]] += parseNumericValue(row.values[months[1]]);
      totalValues[months[2]] += parseNumericValue(row.values[months[2]]);
      totalValues.Q1 += parseNumericValue(row.values.Q1);
      totalValues.YTD += parseNumericValue(row.values.YTD);
      totalValues.BP += parseNumericValue(row.values.BP);
    });

    // Calculate derived values for total
    totalValues.VSBP = totalValues.YTD - totalValues.BP;
    totalValues.VBPM = totalValues.BP !== 0 
      ? (((totalValues.YTD - totalValues.BP) / totalValues.BP) * 100).toFixed(2) 
      : "0.00";
    totalValues.runRate = totalValues.BP !== 0 
      ? ((totalValues.YTD / totalValues.BP) * 100).toFixed(2) 
      : "0.00";

    // Add calculated total row at the end
    const totalRow = {
      id: null, // No ID for calculated row
      master_pl_id: null,
      dfhm_id: section.rows[0]?.dfhm_id || null,
      subCategory: "Total", // Just "Total" in SubCategory column
      isTotal: true, // This is a total row
      isCalculatedTotal: true, // This is auto-calculated, not from API
      values: totalValues,
      rawValues: null,
    };

    // Check if this entire section is a grand total (like "Grand Total" standalone)
    const categoryLower = section.category.toLowerCase().trim();
    const isGrandTotalSection = 
      categoryLower === "grand total" ||
      categoryLower === "total";

    return {
      ...section,
      rows: [...section.rows, totalRow], // Add total row at the end
      isTotalRow: isGrandTotalSection,
    };
  });

  // Sort sections by categoryType to group similar categories together
  result.sort((a, b) => {
    // Grand totals always at end
    if (a.isTotalRow && !b.isTotalRow) return 1;
    if (!a.isTotalRow && b.isTotalRow) return -1;
    // Then sort by categoryType
    if (a.categoryType < b.categoryType) return -1;
    if (a.categoryType > b.categoryType) return 1;
    return 0;
  });

  return result;
};

/**
 * Filter P&L data by metric type (Revenue, Profit, Expense)
 * Uses categoryType from pl_master or falls back to category name matching
 */
export const filterPlDataByMetric = (data, metric) => {
  if (!data || data.length === 0 || metric === "viewall") {
    return data;
  }

  // Map metric buttons to categoryType values from API
  const categoryTypeMap = {
    revenue: ["revenue", "volume"],                    // "Revenue", "Volume(units)"
    profit: ["gross profit", "profit", "margin"],      // "Gross Profit"
    expense: ["expense", "cost", "salary", "opex"],    // "Expense", "Operating Cost"
  };

  // Fallback keywords for category name matching
  const keywordMap = {
    revenue: ["revenue", "sales", "income", "volume"],
    profit: ["profit", "gross", "margin"],
    expense: ["expense", "cost", "salary", "sga", "finance", "operating", "opex"],
  };

  const categoryTypes = categoryTypeMap[metric] || [];
  const keywords = keywordMap[metric] || [];

  return data.filter((section) => {
    // First try to match by categoryType if available
    if (section.categoryType) {
      const catTypeLower = section.categoryType.toLowerCase();
      if (categoryTypes.some((ct) => catTypeLower.includes(ct))) {
        return true;
      }
    }

    // Fallback to category name matching
    const categoryLower = section.category.toLowerCase();
    return keywords.some((kw) => categoryLower.includes(kw));
  });
};

/**
 * Transform table data back to API format for saving
 * Excludes calculated total rows (only saves actual data rows)
 */
export const transformPlDataForApi = (tableData, quarter) => {
  const months = quarterMonthsMap[quarter] || ["Jan", "Feb", "Mar"];
  const rows = [];

  tableData.forEach((section) => {
    section.rows.forEach((row) => {
      // Only include rows that have an ID and are NOT calculated totals
      if (row.id && !row.isCalculatedTotal) {
        rows.push({
          id: row.id,
          month1: parseNumericValue(row.values[months[0]]),
          month2: parseNumericValue(row.values[months[1]]),
          month3: parseNumericValue(row.values[months[2]]),
          ytd: parseNumericValue(row.values.YTD),
          bp: parseNumericValue(row.values.BP),
        });
      }
    });
  });

  return rows;
};

// ============================================
// BALANCE SHEET APIs
// ============================================

/**
 * Fetch Balance Sheet data by DFHM ID
 */
export const getDfhmBsByDfhmId = async (dfhmId) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${DFHM_ENDPOINTS.getDfhmBsByDfhmId}${dfhmId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching Balance Sheet data:", error);
    throw error;
  }
};

/**
 * Fetch Balance Sheet data by filters (quarter, year, dealerId)
 */
export const getDfhmBsByFilters = async (filters) => {
  try {
    const params = new URLSearchParams();
    if (filters.quarter) params.append("quarter", filters.quarter);
    if (filters.year) params.append("year", filters.year);
    if (filters.dealerId) params.append("dealerId", filters.dealerId);

    const url = `${BASE_URL}${DFHM_ENDPOINTS.getDfhmBsByFilters}?${params.toString()}`;
    const response = await axios.get(url, { headers: getAuthHeaders() });
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching Balance Sheet data by filters:", error);
    throw error;
  }
};

/**
 * Update multiple Balance Sheet records
 */
export const updateMultipleDfhmBs = async (rows) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${DFHM_ENDPOINTS.bulkUpdateDfhmBs}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating Balance Sheet data:", error);
    throw error;
  }
};

/**
 * Transform API Balance Sheet data to table format
 * Groups by category, stores categoryType, auto-generates Total row
 */
export const transformBsDataForTable = (apiData, quarter) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return [];
  }

  const months = quarterMonthsMap[quarter] || ["Jan", "Feb", "Mar"];
  
  // Group data by category
  const groupedData = {};
  
  apiData.forEach((item) => {
    const category = item.balance_sheet_master_info?.category || "Others";
    const subCategory = item.balance_sheet_master_info?.subCategory || "";
    const categoryType = item.balance_sheet_master_info?.categoryType || ""; // Assets, Liabilities, etc.
    
    if (!groupedData[category]) {
      groupedData[category] = {
        category,
        categoryType, // Store categoryType for filtering
        rows: [],
        isTotalRow: false,
      };
    }

    const derived = calculateDerivedValues(
      item.month1,
      item.month2,
      item.month3,
      item.ytd,
      item.bp
    );

    groupedData[category].rows.push({
      id: item.id,
      balance_sheet_master_id: item.balance_sheet_master_id,
      dfhm_id: item.dfhm_id,
      subCategory,
      isTotal: false, // Regular data rows
      isCalculatedTotal: false,
      values: {
        [months[0]]: item.month1 || 0,
        [months[1]]: item.month2 || 0,
        [months[2]]: item.month3 || 0,
        Q1: derived.quarterTotal,
        YTD: item.ytd || 0,
        BP: item.bp || 0,
        VSBP: derived.vsBP,
        VBPM: derived.vbpm,
        runRate: derived.runRate,
      },
      rawValues: {
        month1: item.month1,
        month2: item.month2,
        month3: item.month3,
        ytd: item.ytd,
        bp: item.bp,
      },
    });
  });

  // Convert to array and add calculated total row for each category
  const result = Object.values(groupedData).map((section) => {
    // Calculate totals for this category
    const totalValues = {
      [months[0]]: 0,
      [months[1]]: 0,
      [months[2]]: 0,
      Q1: 0,
      YTD: 0,
      BP: 0,
      VSBP: 0,
      VBPM: 0,
      runRate: 0,
    };

    // Sum up all rows
    section.rows.forEach((row) => {
      totalValues[months[0]] += parseNumericValue(row.values[months[0]]);
      totalValues[months[1]] += parseNumericValue(row.values[months[1]]);
      totalValues[months[2]] += parseNumericValue(row.values[months[2]]);
      totalValues.Q1 += parseNumericValue(row.values.Q1);
      totalValues.YTD += parseNumericValue(row.values.YTD);
      totalValues.BP += parseNumericValue(row.values.BP);
    });

    // Calculate derived values for total
    totalValues.VSBP = totalValues.YTD - totalValues.BP;
    totalValues.VBPM = totalValues.BP !== 0 
      ? (((totalValues.YTD - totalValues.BP) / totalValues.BP) * 100).toFixed(2) 
      : "0.00";
    totalValues.runRate = totalValues.BP !== 0 
      ? ((totalValues.YTD / totalValues.BP) * 100).toFixed(2) 
      : "0.00";

    // Add calculated total row at the end
    const totalRow = {
      id: null,
      balance_sheet_master_id: null,
      dfhm_id: section.rows[0]?.dfhm_id || null,
      subCategory: "Total",
      isTotal: true,
      isCalculatedTotal: true,
      values: totalValues,
      rawValues: null,
    };

    // Check if this entire section is a grand total
    const categoryLower = section.category.toLowerCase().trim();
    const isGrandTotalSection = 
      categoryLower === "grand total" ||
      categoryLower === "total" ||
      categoryLower === "check";

    return {
      ...section,
      rows: isGrandTotalSection ? section.rows : [...section.rows, totalRow],
      isTotalRow: isGrandTotalSection,
    };
  });

  // Sort sections by categoryType
  result.sort((a, b) => {
    if (a.isTotalRow && !b.isTotalRow) return 1;
    if (!a.isTotalRow && b.isTotalRow) return -1;
    if (a.categoryType < b.categoryType) return -1;
    if (a.categoryType > b.categoryType) return 1;
    return 0;
  });

  return result;
};

/**
 * Filter Balance Sheet data by metric (assets, liability, inventories, trade, equity)
 */
export const filterBsDataByMetric = (data, metric) => {
  if (!metric || metric === "viewall") {
    return data;
  }

  // Map metric buttons to categoryType values from API
  // API returns: "Assets", "Trade Receivables", "Inventories", "Liabilities", "Equity"
  const categoryTypeMap = {
    assets: ["assets"],
    liability: ["liabilities", "liability"],
    inventories: ["inventories", "inventory"],
    trade: ["trade receivables", "trade", "receivables"],
    equity: ["equity"],
  };

  // Fallback keywords for category name matching
  const categoryKeywordMap = {
    assets: ["assets", "current assets", "non-current assets", "total assets"],
    liability: ["liabilities", "liability", "payables", "borrowings"],
    inventories: ["inventories", "inventory", "machines inventories", "parts inventories"],
    trade: ["trade receivables", "receivables", "net trade"],
    equity: ["equity", "share capital", "reserves", "retained earnings"],
  };

  const categoryTypes = categoryTypeMap[metric] || [];
  const keywords = categoryKeywordMap[metric] || [];

  return data.filter((section) => {
    // First try to match by categoryType if available
    if (section.categoryType) {
      const catTypeLower = section.categoryType.toLowerCase();
      if (categoryTypes.some((ct) => catTypeLower.includes(ct))) {
        return true;
      }
    }

    // Fallback to category name matching
    const categoryLower = section.category.toLowerCase();
    return keywords.some((kw) => categoryLower.includes(kw));
  });
};

/**
 * Transform Balance Sheet table data for API
 * Excludes calculated total rows
 */
export const transformBsDataForApi = (tableData, quarter) => {
  const months = quarterMonthsMap[quarter] || ["Jan", "Feb", "Mar"];
  const rows = [];

  tableData.forEach((section) => {
    section.rows.forEach((row) => {
      // Only include rows that have an ID and are NOT calculated totals
      if (row.id && !row.isCalculatedTotal) {
        rows.push({
          id: row.id,
          month1: parseNumericValue(row.values[months[0]]),
          month2: parseNumericValue(row.values[months[1]]),
          month3: parseNumericValue(row.values[months[2]]),
          ytd: parseNumericValue(row.values.YTD),
          bp: parseNumericValue(row.values.BP),
        });
      }
    });
  });

  return rows;
};

// ============================================
// HEAD COUNT APIs
// ============================================

/**
 * Fetch Head Count data by DFHM ID
 */
export const getDfhmHcByDfhmId = async (dfhmId) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${DFHM_ENDPOINTS.getDfhmHcByDfhmId}${dfhmId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching Head Count data:", error);
    throw error;
  }
};

/**
 * Fetch Head Count data by filters (quarter, year, dealerId)
 */
export const getDfhmHcByFilters = async (filters) => {
  try {
    const params = new URLSearchParams();
    if (filters.quarter) params.append("quarter", filters.quarter);
    if (filters.year) params.append("year", filters.year);
    if (filters.dealerId) params.append("dealerId", filters.dealerId);

    const url = `${BASE_URL}${DFHM_ENDPOINTS.getDfhmHcByFilters}?${params.toString()}`;
    const response = await axios.get(url, { headers: getAuthHeaders() });
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching Head Count data by filters:", error);
    throw error;
  }
};

/**
 * Update multiple Head Count records
 */
export const updateMultipleDfhmHc = async (rows) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${DFHM_ENDPOINTS.bulkUpdateDfhmHc}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating Head Count data:", error);
    throw error;
  }
};

/**
 * Transform API Head Count data to table format
 * Groups by category, auto-generates Total row
 */
export const transformHcDataForTable = (apiData, quarter) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return [];
  }

  const months = quarterMonthsMap[quarter] || ["Jan", "Feb", "Mar"];
  
  // Group data by category
  const groupedData = {};
  
  apiData.forEach((item) => {
    const category = item.head_count_master_info?.category || "Others";
    const subCategory = item.head_count_master_info?.subCategory || "";
    
    if (!groupedData[category]) {
      groupedData[category] = {
        category,
        rows: [],
        isTotalRow: false,
      };
    }

    const derived = calculateDerivedValues(
      item.month1,
      item.month2,
      item.month3,
      item.ytd,
      item.bp
    );

    groupedData[category].rows.push({
      id: item.id,
      head_count_master_id: item.head_count_master_id,
      dfhm_id: item.dfhm_id,
      subCategory,
      isTotal: false, // Regular data rows
      isCalculatedTotal: false,
      values: {
        [months[0]]: item.month1 || 0,
        [months[1]]: item.month2 || 0,
        [months[2]]: item.month3 || 0,
        Q1: derived.quarterTotal,
        YTD: item.ytd || 0,
        BP: item.bp || 0,
        VSBP: derived.vsBP,
        VBPM: derived.vbpm,
        runRate: derived.runRate,
      },
      rawValues: {
        month1: item.month1,
        month2: item.month2,
        month3: item.month3,
        ytd: item.ytd,
        bp: item.bp,
      },
    });
  });

  // Convert to array and add calculated total row for each category
  const result = Object.values(groupedData).map((section) => {
    // Calculate totals for this category
    const totalValues = {
      [months[0]]: 0,
      [months[1]]: 0,
      [months[2]]: 0,
      Q1: 0,
      YTD: 0,
      BP: 0,
      VSBP: 0,
      VBPM: 0,
      runRate: 0,
    };

    // Sum up all rows
    section.rows.forEach((row) => {
      totalValues[months[0]] += parseNumericValue(row.values[months[0]]);
      totalValues[months[1]] += parseNumericValue(row.values[months[1]]);
      totalValues[months[2]] += parseNumericValue(row.values[months[2]]);
      totalValues.Q1 += parseNumericValue(row.values.Q1);
      totalValues.YTD += parseNumericValue(row.values.YTD);
      totalValues.BP += parseNumericValue(row.values.BP);
    });

    // Calculate derived values for total
    totalValues.VSBP = totalValues.YTD - totalValues.BP;
    totalValues.VBPM = totalValues.BP !== 0 
      ? (((totalValues.YTD - totalValues.BP) / totalValues.BP) * 100).toFixed(2) 
      : "0.00";
    totalValues.runRate = totalValues.BP !== 0 
      ? ((totalValues.YTD / totalValues.BP) * 100).toFixed(2) 
      : "0.00";

    // Add calculated total row at the end
    const totalRow = {
      id: null,
      head_count_master_id: null,
      dfhm_id: section.rows[0]?.dfhm_id || null,
      subCategory: "Total",
      isTotal: true,
      isCalculatedTotal: true,
      values: totalValues,
      rawValues: null,
    };

    // Check if this entire section is a grand total
    const categoryLower = section.category.toLowerCase().trim();
    const isGrandTotalSection = 
      categoryLower === "grand total" ||
      categoryLower === "total" ||
      categoryLower === "total head count";

    return {
      ...section,
      rows: isGrandTotalSection ? section.rows : [...section.rows, totalRow],
      isTotalRow: isGrandTotalSection,
    };
  });

  // Sort sections
  result.sort((a, b) => {
    if (a.isTotalRow && !b.isTotalRow) return 1;
    if (!a.isTotalRow && b.isTotalRow) return -1;
    return 0;
  });

  return result;
};

/**
 * Transform Head Count table data for API
 * Excludes calculated total rows
 */
export const transformHcDataForApi = (tableData, quarter) => {
  const months = quarterMonthsMap[quarter] || ["Jan", "Feb", "Mar"];
  const rows = [];

  tableData.forEach((section) => {
    section.rows.forEach((row) => {
      // Only include rows that have an ID and are NOT calculated totals
      if (row.id && !row.isCalculatedTotal) {
        rows.push({
          id: row.id,
          month1: parseNumericValue(row.values[months[0]]),
          month2: parseNumericValue(row.values[months[1]]),
          month3: parseNumericValue(row.values[months[2]]),
          ytd: parseNumericValue(row.values.YTD),
          bp: parseNumericValue(row.values.BP),
        });
      }
    });
  });

  return rows;
};

// ============================================
// AR AGING APIs
// ============================================

/**
 * Fetch AR Aging data by DFHM ID
 */
export const getDfhmAgingByDfhmId = async (dfhmId) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${DFHM_ENDPOINTS.getDfhmArAgingByDfhmId}${dfhmId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching AR Aging data:", error);
    throw error;
  }
};

/**
 * Add new AR Aging record
 */
export const addDfhmAging = async (data) => {
  try {
    const response = await axios.post(
      `${BASE_URL}${DFHM_ENDPOINTS.addDfhmArAging}`,
      data,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding AR Aging record:", error);
    throw error;
  }
};

/**
 * Update multiple AR Aging records
 */
export const updateMultipleDfhmAging = async (rows) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${DFHM_ENDPOINTS.bulkUpdateDfhmArAging}`,
      { rows },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating AR Aging data:", error);
    throw error;
  }
};

/**
 * Delete AR Aging record
 */
export const deleteDfhmAging = async (id) => {
  try {
    const response = await axios.delete(
      `${BASE_URL}${DFHM_ENDPOINTS.deleteDfhmArAging}${id}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting AR Aging record:", error);
    throw error;
  }
};

/**
 * Transform API AR Aging data to table format
 * Groups by category (Equipment/Parts)
 */
export const transformAgingDataForTable = (apiData) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return { equipment: [], parts: [] };
  }

  const equipment = [];
  const parts = [];

  apiData.forEach((item) => {
    const row = {
      id: item.id,
      dfhm_id: item.dfhm_id,
      quarter: item.quarter,
      category: item.category,
      customer_name: item.customer_name,
      current_ar: item.current_ar || 0,
      L30: item.L30 || 0,
      L60: item.L60 || 0,
      L90: item.L90 || 0,
      M90: item.M90 || 0,
      // Calculated fields
      totalOverdue: (item.L30 || 0) + (item.L60 || 0) + (item.L90 || 0) + (item.M90 || 0),
      total: (item.current_ar || 0) + (item.L30 || 0) + (item.L60 || 0) + (item.L90 || 0) + (item.M90 || 0),
    };

    if (item.category === "Equipment") {
      equipment.push(row);
    } else if (item.category === "Parts") {
      parts.push(row);
    }
  });

  return { equipment, parts };
};

/**
 * Fetch AR Aging data by filters (quarter, year, dealerId)
 */
export const getDfhmAgingByFilters = async (filters) => {
  try {
    const params = new URLSearchParams();
    if (filters.quarter) params.append("quarter", filters.quarter);
    if (filters.year) params.append("year", filters.year);
    if (filters.dealerId) params.append("dealerId", filters.dealerId);

    const response = await axios.get(
      `${BASE_URL}${DFHM_ENDPOINTS.getDfhmArAgingByFilters}?${params.toString()}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching AR Aging by filters:", error);
    throw error;
  }
};

/**
 * Transform AR Aging API data to table format
 * Groups by category (Equipment Customer/Parts Customer) with auto-generated Total rows
 */
export const transformAgingDataForTableGrouped = (apiData) => {
  if (!apiData || !Array.isArray(apiData) || apiData.length === 0) {
    return [];
  }

  // Group by category
  const grouped = {};

  apiData.forEach((item) => {
    const categoryKey = item.category === "Equipment" ? "Equipment Customer" : "Parts Customer";
    
    if (!grouped[categoryKey]) {
      grouped[categoryKey] = {
        category: categoryKey,
        categoryType: item.category, // Original category for API
        rows: [],
      };
    }

    const currentAr = parseNumericValue(item.current_ar);
    const l30 = parseNumericValue(item.L30);
    const l60 = parseNumericValue(item.L60);
    const l90 = parseNumericValue(item.L90);
    const m90 = parseNumericValue(item.M90);
    const totalOverdue = l30 + l60 + l90 + m90;
    const total = currentAr + totalOverdue;

    grouped[categoryKey].rows.push({
      id: item.id,
      dfhm_id: item.dfhm_id,
      quarter: item.quarter,
      category: item.category,
      subCategory: item.customer_name,
      customer_name: item.customer_name,
      isTotal: false,
      isCalculatedTotal: false,
      values: {
        "Current": currentAr,
        "<30 Days": l30,
        "30-60 Days": l60,
        "60-90 Days": l90,
        ">90 Days": m90,
        "Total Overdue": totalOverdue,
        "Total": total,
      },
      rawValues: {
        current_ar: item.current_ar,
        L30: item.L30,
        L60: item.L60,
        L90: item.L90,
        M90: item.M90,
      },
    });
  });

  // Convert to array and add Total row for each category
  const result = [];
  
  // Ensure Equipment Customer comes first
  const categoryOrder = ["Equipment Customer", "Parts Customer"];
  
  categoryOrder.forEach((categoryKey) => {
    if (grouped[categoryKey]) {
      const section = grouped[categoryKey];
      
      // Calculate totals for the category
      const totalValues = {
        "Current": 0,
        "<30 Days": 0,
        "30-60 Days": 0,
        "60-90 Days": 0,
        ">90 Days": 0,
        "Total Overdue": 0,
        "Total": 0,
      };

      section.rows.forEach((row) => {
        Object.keys(totalValues).forEach((key) => {
          totalValues[key] += parseNumericValue(row.values[key]);
        });
      });

      // Add Total row
      section.rows.push({
        id: null,
        dfhm_id: section.rows[0]?.dfhm_id || null,
        quarter: section.rows[0]?.quarter || null,
        category: section.categoryType,
        subCategory: "Total",
        customer_name: "Total",
        isTotal: true,
        isCalculatedTotal: true,
        values: totalValues,
        rawValues: null,
      });

      result.push(section);
    }
  });

  return result;
};

/**
 * Transform AR Aging table data for API update (excludes calculated total rows)
 */
export const transformAgingDataForApi = (equipmentData, partsData) => {
  const rows = [];

  [...equipmentData, ...partsData].forEach((row) => {
    if (row.id) {
      rows.push({
        id: row.id,
        current_ar: parseNumericValue(row.current_ar),
        L30: parseNumericValue(row.L30),
        L60: parseNumericValue(row.L60),
        L90: parseNumericValue(row.L90),
        M90: parseNumericValue(row.M90),
      });
    }
  });

  return rows;
};

/**
 * Transform grouped AR Aging table data for API update
 * Works with the new grouped format from transformAgingDataForTableGrouped
 */
export const transformAgingGroupedDataForApi = (tableData) => {
  const rows = [];

  tableData.forEach((section) => {
    section.rows.forEach((row) => {
      // Skip calculated total rows
      if (row.isCalculatedTotal || !row.id) return;

      rows.push({
        id: row.id,
        current_ar: parseNumericValue(row.values["Current"]),
        L30: parseNumericValue(row.values["<30 Days"]),
        L60: parseNumericValue(row.values["30-60 Days"]),
        L90: parseNumericValue(row.values["60-90 Days"]),
        M90: parseNumericValue(row.values[">90 Days"]),
      });
    });
  });

  return rows;
};

// ============================================
// DFHM PARENT APIs
// ============================================

/**
 * Get DFHM by ID
 */
export const getDfhmById = async (dfhmId) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${DFHM_ENDPOINTS.getDfhmById}${dfhmId}`,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching DFHM:", error);
    throw error;
  }
};

/**
 * Update DFHM status
 */
export const updateDfhmStatus = async (id, status) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${DFHM_ENDPOINTS.updateDfhm}`,
      { id, status },
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating DFHM status:", error);
    throw error;
  }
};

// ============================================
// EXPORT ALL
// ============================================
