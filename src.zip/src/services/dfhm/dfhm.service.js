import axios from "axios";
import { API } from "../../api";

// ================== DFHM API ENDPOINTS ==================
// Base URL from API config
const BASE_URL = API.domain;

// DFHM Endpoints from API config
const DFHM_ENDPOINTS = API.dfhmEndpoints;

/**
 * Get auth headers with token
 */
const getAuthHeaders = () => {
  const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

/**
 * Add new DFHM entries
 * @param {Object} data - DFHM data
 * @param {number} data.year - Year (required)
 * @param {string} data.quarter - Quarter: Q1, Q2, Q3, Q4 (required)
 * @param {number} data.market_area_id - Market Area ID (required)
 * @param {string} data.start_date - Start date YYYY-MM-DD (required)
 * @param {string} data.end_date - End date YYYY-MM-DD (required)
 * @param {number[]} data.dealerIds - Array of dealer IDs (required)
 * @param {string} data.status - Status: Created, All Data Review, Review by Volvo (optional, defaults to "Created")
 * @param {string} data.dealer_principal_validate - Dealer principal validation status (optional)
 * @param {string} data.volvo_user_validate - Volvo user validation status (optional)
 */
export const addDfhm = async (data) => {
  try {
    const response = await axios.post(
      `${BASE_URL}${DFHM_ENDPOINTS.addDfhm}`,
      data,
      { headers: getAuthHeaders() }
    );
    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error adding DFHM:", error);
    throw new Error(error.response?.data?.message || "Failed to add DFHM");
  }
};

/**
 * Get all DFHM records
 * @returns {Array} List of DFHM records with market area and dealer info
 */
export const getAllDfhm = async () => {
  try {
    const response = await axios.get(
      `${BASE_URL}${DFHM_ENDPOINTS.getAllDfhm}`,
      { headers: getAuthHeaders() }
    );

    if (!response.data.status) {
      throw new Error(response.data.message || "Failed to fetch DFHM list");
    }

    // Transform data for frontend use
    const transformedData = (response.data.data || []).map((item, index) => ({
      id: item.id,
      rowId: `dfhm-${item.id}-${index}`, // Unique row ID for selection
      year: item.year,
      quarter: item.quarter,
      marketAreaId: item.market_area_id,
      marketArea: item.market_area_info?.market_area_name || "—",
      startDate: item.start_date,
      endDate: item.end_date,
      dealerId: item.dealerId,
      dealer: item.dealer_info?.dealer_short_name || item.dealer_info?.dealer_name || "—",
      dealerName: item.dealer_info?.dealer_name || "—",
      status: item.status || "Created",
      dealerPrincipalValidate: item.dealer_principal_validate || "—",
      volvoUserValidate: item.volvo_user_validate || "—",
      createdAt: item.created_at,
      updatedAt: item.updated_at,
      isActive: item.isActive,
      isDeleted: item.isDeleted,
    }));

    return transformedData;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error fetching DFHM list:", error);
    throw new Error(error.response?.data?.message || "Failed to fetch DFHM list");
  }
};

/**
 * Get DFHM by ID
 * @param {number} id - DFHM ID
 * @returns {Object} DFHM record with details
 */
export const getDfhmById = async (id) => {
  try {
    const response = await axios.get(
      `${BASE_URL}${DFHM_ENDPOINTS.getDfhmById}${id}`,
      { headers: getAuthHeaders() }
    );

    if (!response.data.status) {
      throw new Error(response.data.message || "Failed to fetch DFHM");
    }

    const item = response.data.data;
    return {
      id: item.id,
      year: item.year,
      quarter: item.quarter,
      marketAreaId: item.market_area_id,
      marketArea: item.market_area_info?.market_area_name || "—",
      startDate: item.start_date,
      endDate: item.end_date,
      dealerId: item.dealerId,
      dealer: item.dealer_info?.dealer_short_name || item.dealer_info?.dealer_name || "—",
      dealerName: item.dealer_info?.dealer_name || "—",
      status: item.status || "Created",
      dealerPrincipalValidate: item.dealer_principal_validate || "—",
      volvoUserValidate: item.volvo_user_validate || "—",
      createdAt: item.created_at,
      updatedAt: item.updated_at,
      isActive: item.isActive,
      isDeleted: item.isDeleted,
    };
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error fetching DFHM by ID:", error);
    throw new Error(error.response?.data?.message || "Failed to fetch DFHM");
  }
};

/**
 * Update DFHM
 * @param {Object} data - Update data
 * @param {number} data.id - DFHM ID (required)
 * @param {number} data.year - Year (optional)
 * @param {string} data.quarter - Quarter (optional)
 * @param {number} data.market_area_id - Market Area ID (optional)
 * @param {string} data.start_date - Start date (optional)
 * @param {string} data.end_date - End date (optional)
 * @param {number} data.dealerId - Dealer ID (optional)
 * @param {string} data.status - Status (optional)
 * @param {string} data.dealer_principal_validate - Dealer principal validation (optional)
 * @param {string} data.volvo_user_validate - Volvo user validation (optional)
 * @param {boolean} data.isActive - Active status (optional)
 */
export const updateDfhm = async (data) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${DFHM_ENDPOINTS.updateDfhm}`,
      data,
      { headers: getAuthHeaders() }
    );

    if (!response.data.status) {
      throw new Error(response.data.message || "Failed to update DFHM");
    }

    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error updating DFHM:", error);
    throw new Error(error.response?.data?.message || "Failed to update DFHM");
  }
};

/**
 * Toggle DFHM active status
 * @param {number} id - DFHM ID
 */
export const toggleDfhm = async (id) => {
  try {
    const response = await axios.put(
      `${BASE_URL}${DFHM_ENDPOINTS.toggleDfhm}${id}`,
      {},
      { headers: getAuthHeaders() }
    );

    if (!response.data.status) {
      throw new Error(response.data.message || "Failed to toggle DFHM");
    }

    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error toggling DFHM:", error);
    throw new Error(error.response?.data?.message || "Failed to toggle DFHM");
  }
};

/**
 * Delete DFHM (soft delete)
 * @param {number} id - DFHM ID
 */
export const deleteDfhm = async (id) => {
  try {
    const response = await axios.delete(
      `${BASE_URL}${DFHM_ENDPOINTS.deleteDfhm}${id}`,
      { headers: getAuthHeaders() }
    );

    if (!response.data.status) {
      throw new Error(response.data.message || "Failed to delete DFHM");
    }

    return response.data;
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("❌ Error deleting DFHM:", error);
    throw new Error(error.response?.data?.message || "Failed to delete DFHM");
  }
};

// ================== HELPER FUNCTIONS ==================

/**
 * Get unique filter options from DFHM data
 * @param {Array} data - DFHM data array
 * @param {string} field - Field name to extract unique values from
 * @returns {Array} Sorted unique values
 */
export const getUniqueFilterOptions = (data, field) => {
  if (!Array.isArray(data)) return [];
  const values = data.map(item => item[field]).filter(Boolean);
  return [...new Set(values)].sort();
};

/**
 * Format date for display
 * @param {string} dateString - Date string from API
 * @returns {string} Formatted date string
 */
export const formatDate = (dateString) => {
  if (!dateString) return "—";
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  } catch {
    return dateString;
  }
};

/**
 * Format date for API (YYYY-MM-DD)
 * @param {Date|string} date - Date object or string
 * @returns {string} Formatted date string
 */
export const formatDateForApi = (date) => {
  if (!date) return null;
  try {
    const d = new Date(date);
    return d.toISOString().split('T')[0];
  } catch {
    return null;
  }
};