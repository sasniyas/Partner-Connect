import axios from 'axios';
import { API } from '../../api';

// Add HeadCount
export const addHeadCountMlp = async (headCountData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.addHeadCount}`,
      headCountData,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add HeadCount");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding HeadCount:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add HeadCount");
  }
};

// ✅ Bulk Add HeadCount
export const bulkAddHeadCountMlp = async (rows) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddHeadCount}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add HeadCount");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding HeadCount:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add HeadCount");
  }
};

// Get All HeadCounts
export const getHeadCountsMlp = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getHeadCounts}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("Full API response:", response.data);

    if (response.status === 200 && (response.data.status || response.data.success)) {
      const responseData = response.data.data;
      
      // If it's not an array, wrap it in an array
      if (responseData && !Array.isArray(responseData)) {
        return [responseData];
      }
      
      // If it's already an array, return it
      if (Array.isArray(responseData)) {
        return responseData;
      }
    }

    throw new Error(response.data?.message || "Failed to get HeadCounts");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting HeadCounts:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to get HeadCounts");
  }
};

// Update HeadCount
export const updateHeadCountMlp = async (headCountId, headCountData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const payload = {
      id: parseInt(headCountId),
      category: String(headCountData.category),
      subCategory: String(headCountData.subCategory)
    };

    console.log("Update payload being sent:", payload);

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateHeadCount}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to update HeadCount");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating HeadCount:", error);
    console.error("Error response:", error.response?.data);
    throw new Error(error.response?.data?.message || error.message || "Failed to update HeadCount");
  }
};

// Toggle HeadCount (Active/Inactive)
export const toggleHeadCountMlp = async (headCountId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleHeadCount}${headCountId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to toggle HeadCount");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling HeadCount:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle HeadCount");
  }
};

// Delete HeadCount
export const deleteHeadCountMlp = async (headCountId) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteHeadCount}${headCountId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to delete HeadCount");
  } catch (error) {const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting HeadCount:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete HeadCount");
  }
};