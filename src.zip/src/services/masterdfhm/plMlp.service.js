import axios from 'axios';
import { API } from '../../api';

// Add P&L
export const addPLMlp = async (plData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.addPL}`,
      plData,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add P&L");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding P&L:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add P&L");
  }
};

// ✅ Bulk Add P&L
export const bulkAddPLMlp = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddPL}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add P&L");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding P&L:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add P&L");
  }
};

// Get All P&Ls
export const getPLsMlp = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getPLs}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("Full API response:", response.data);

    if (response.status === 200 && (response.data.status || response.data.success)) {
      const responseData = response.data.data;
      
      // If it's not an array, wrap it in an array
      if (responseData && !Array.isArray(responseData)) {
        return [responseData];
      }
      
      // If it's already an array, return it
      if (Array.isArray(responseData)) {
        return responseData;
      }
    }

    throw new Error(response.data?.message || "Failed to get P&Ls");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting P&Ls:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to get P&Ls");
  }
};

// Update P&L
export const updatePLMlp = async (plId, plData) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const payload = {
      id: parseInt(plId),
      categoryType: String(plData.categoryType),
      category: String(plData.category),
      subCategory: String(plData.subCategory)
    };

    console.log("Update payload being sent:", payload);

    const response = await axios.put(
      `${API.domain}${API.endpoints.updatePL}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to update P&L");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating P&L:", error);
    console.error("Error response:", error.response?.data);
    throw new Error(error.response?.data?.message || error.message || "Failed to update P&L");
  }
};

// Toggle P&L (Active/Inactive)
export const togglePLMlp = async (plId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.togglePL}${plId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to toggle P&L");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling P&L:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle P&L");
  }
};

// Delete P&L
export const deletePLMlp = async (plId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deletePL}${plId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to delete P&L");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting P&L:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete P&L");
  }
};