import axios from "axios";
import { API } from "../../api";

// Add a new file to File Master
export const uploadTempFile = async (file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }
    

    // Create FormData for file upload
    const formData = new FormData();
    if (file) {
      formData.append("file", file);
    }

    const response = await axios.post(
      `${API.domain}/xlxFiles`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to add file");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding file:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add file");
  }
};

