  const fetchActiveUser = async () => {
    try {
      const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
      if (!token) {
        navigate("/") // redirect if no token
        return
      }

      const res = await axios.get(
        "https://partnerconnect-testenv-bsgsebgdexfmf7bz.centralindia-01.azurewebsites.net/logedInUser",
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`, 
          },
        }
      )

      const fetchedUser = res.data.data
     if (fetchedUser && fetchedUser.status === "ACTIVE") {
  // ✅ Convert role names to readable format
  const formattedRole = fetchedUser.role
    ? fetchedUser.role
        .toLowerCase()
        .replace(/_/g, " ")          // change underscores to spaces
        .replace(/\b\w/g, (c) => c.toUpperCase()) // capitalize each word
    : "";

  setUser({
    ...fetchedUser,
    role: formattedRole, // use formatted version
  });
}

      else {
        console.warn("User is inactive or not found")
        // navigate("/") // redirect if inactive
      }

    } catch (error) {
      const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
      console.error("Failed to fetch logged-in user:", error)
      if(error.response.data.message === "token is invalid" ||error.response.data.message === "jwt expired") {
      navigate ("/")
    }
    }
  }