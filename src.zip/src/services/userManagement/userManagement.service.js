import axios from 'axios';
import { API } from '../../api';

// Get all users
export const getAllUsers = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}/getAllUsers`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to fetch users");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching users:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch users");
  }
};

// Get users by type (Dealer User or Volvo User)
export const getUsersByType = async (userType) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}/getAllUsers`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      // Filter users by type
      const filteredUsers = response.data.data.filter(user => {
        if (userType === 'Dealer User') {
          return user.role === 'DEALER_USER';
        } else if (userType === 'Volvo User') {
          return user.role === 'VOLVO_USER';
        }
        return false;
      });

      return filteredUsers;
    }

    throw new Error(response.data?.message || "Failed to fetch users");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching users by type:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch users by type");
  }
};

// Get dealer users
export const getDealerUsers = async () => {
  return getUsersByType('Dealer User');
};

// Get volvo users
export const getVolvoUsers = async () => {
  return getUsersByType('Volvo User');
};
