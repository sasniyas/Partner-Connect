import { API } from '../../api';

  
  // ✅ API Login Function
  export const userLogin = async (email) => {
    try {
        
     const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
            if (!token) {
                window.location.href = "/";   // redirect to login
                return "No token "
            }
      const response = await fetch( `${API.domain}/adminLogin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
           Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          "email": email
        })
      });

      const data = await response.json();

      if (response.ok) {
        // Success - store token if provided
        if (data.token) {
          localStorage.setItem('userToken', data.token);
        }

        return { success: true, data };
      } else {
        // API returned error
        return { 
          success: false, 
          error: data.message || 'Login failed. Please try again.' 
        };
      }
    } catch (error) {
      const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
      console.error('Login error:', error);
      return { 
        success: false, 
        error: 'Network error. Please check your connection and try again.' 
      };
    }
  };
