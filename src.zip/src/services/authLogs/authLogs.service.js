import axios from 'axios';
import { API } from '../../api';

// // Add User Log
// export const addUserLog = async (userLog) => {
//   try {
//     const token = localStorage.getItem("authToken");
//     if (!token) {
//       throw new Error("No authentication token found");
//     }

//     const response = await axios.post(
//       `${API.domain}${API.endpoints.addUserLog}`,
//       userLog,
//       {
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//       }
//     );

//     if (response.status === 200 && response.data.status) {
//       return response.data;
//     }

//     throw new Error(response.data?.message || "Failed to add user log");
//   } catch (error) {
//     console.error("Error adding user log:", error);
//     throw new Error(error.response?.data?.message || error.message || "Failed to add user log");
//   }
// };

// Get All User Logs
export const getUserLogs = async (filters = {}) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    // Build query string from filters
    const queryParams = new URLSearchParams();
    Object.keys(filters).forEach(key => {
      if (filters[key] !== undefined && filters[key] !== null && filters[key] !== '') {
        queryParams.append(key, filters[key]);
      }
    });

    const queryString = queryParams.toString();
    const url = `${API.domain}${API.endpoints.getUserLogs}${queryString ? `?${queryString}` : ''}`;

    const response = await axios.get(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to get user logs");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting user logs:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to get user logs");
  }
};

// Get Single User Log by ID
export const getUserLog = async (logId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getUserLog}${logId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to get user log");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting user log:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to get user log");
  }
};

// Update User Log by ID
export const updateUserLog = async (logId, userLogData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateUserLog}${logId}`,
      userLogData,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to update user log");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating user log:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to update user log");
  }
};

// Delete User Log by ID
export const deleteUserLog = async (logId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteUserLog}${logId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to delete user log");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting user log:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete user log");
  }
};