import axios from 'axios';
import { API } from '../../api.js';

// Add Finance Template
export const addDeafultFinanceTemplate = async (financeTemplateData, file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const formData = new FormData();
    formData.append("sampleFileUrl", financeTemplateData.financeTemplate);

    if (file) {
      formData.append("file", file);
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateDefaultFinTemplate}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to add finance template");

  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding finance template:", error);
    throw new Error(error.response?.data?.message || error.message);
  }
};

// get Finance Template
export const getDeafultFinanceTemplate = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");


    const response = await axios.get(
      `${API.domain}${API.endpoints.getDefaultFinTemplate}`,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      console.log(response.data.data)
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to add finance template");

  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding finance template:", error);
    throw new Error(error.response?.data?.message || error.message);
  }
};


// Add a new finance template with file upload
export const addFinanceTemplate = async (financeTemplateData, file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    console.log("domain",API.domain);
    
    // Create FormData for file upload
    const formData = new FormData();
    formData.append('year', financeTemplateData.year);
    formData.append('financeTemplate', financeTemplateData.financeTemplate);
    if (file) {
      formData.append('file', file);
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.addFinanceTemplate}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to add finance template");
    }

    throw new Error("Failed to add finance template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding finance template:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to add finance template");
    }
  }
};

// Get all finance templates
export const getFinanceTemplates = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getFinanceTemplates}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to get finance templates");
    }

    throw new Error("Failed to get finance templates");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting finance templates:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to get finance templates");
    }
  }
};

// Update an existing finance template with optional file upload
export const updateFinanceTemplate = async (financeTemplateData, file) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    // Create FormData for file upload
    const formData = new FormData();
    formData.append('id', financeTemplateData.id);
    formData.append('year', financeTemplateData.year);
    formData.append('financeTemplate', financeTemplateData.financeTemplate);
    formData.append('sampleFileUrl', financeTemplateData.sampleFileUrl || '');
    if (file) {
      formData.append('file', file);
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateFinanceTemplate}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to update finance template");
    }

    throw new Error("Failed to update finance template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating finance template:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to update finance template");
    }
  }
};

// Toggle enable/disable for a finance template
export const toggleFinanceTemplate = async (financeTemplateId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleFinanceTemplate}${financeTemplateId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to toggle finance template");
    }

    throw new Error("Failed to toggle finance template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling finance template:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to toggle finance template");
    }
  }
};
// Bulk Add Finance Template
export const bulkAddFinanceTemplate = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddFinanceTemplate}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add finance template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding finance template:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add finance template");
  }
};
// Delete a finance template
export const deleteFinanceTemplate = async (financeTemplateId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteFinanceTemplate}${financeTemplateId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to delete finance template");
    }

    throw new Error("Failed to delete finance template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting finance template:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to delete finance template");
    }
  }
};
