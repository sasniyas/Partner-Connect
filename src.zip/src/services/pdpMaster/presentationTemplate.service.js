import axios from 'axios';
import { API } from '../../api.js';

// Add Finance Template
export const addDeafultPreTemplate = async (preTemplateData, file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const formData = new FormData();
    formData.append("sampleFileUrl", preTemplateData.financeTemplate);

    if (file) {
      formData.append("file", file);
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateDefaultPreTemplate}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to add finance template");

  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding finance template:", error);
    throw new Error(error.response?.data?.message || error.message);
  }
};

// get Finance Template
export const getDeafultPreTemplate = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");


    const response = await axios.get(
      `${API.domain}${API.endpoints.getDefaultPreTemplate}`,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      console.log(response.data.data)
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to add finance template");

  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding finance template:", error);
    throw new Error(error.response?.data?.message || error.message);
  }
};


// Add a new presentation template with file upload
export const addPresentationTemplate = async (presentationTemplateData, file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    console.log("domain",API.domain);
    
    // Create FormData for file upload
    const formData = new FormData();
    formData.append('year', presentationTemplateData.year);
    formData.append('presentationTemplate', presentationTemplateData.presentationTemplate);
    if (file) {
      formData.append('file', file);
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.addPresentationTemplate}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to add presentation template");
    }

    throw new Error("Failed to add presentation template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding presentation template:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to add presentation template");
    }
  }
};

// Get all presentation templates
export const getPresentationTemplates = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getPresentationTemplates}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to get presentation templates");
    }

    throw new Error("Failed to get presentation templates");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting presentation templates:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to get presentation templates");
    }
  }
};

// Update an existing presentation template with optional file upload
export const updatePresentationTemplate = async (presentationTemplateData, file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    // Create FormData for file upload
    const formData = new FormData();
    formData.append('id', presentationTemplateData.id);
    formData.append('year', presentationTemplateData.year);
    formData.append('presentationTemplate', presentationTemplateData.presentationTemplate);
    formData.append('sampleFileUrl', presentationTemplateData.sampleFileUrl || '');
    if (file) {
      formData.append('file', file);
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updatePresentationTemplate}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to update presentation template");
    }

    throw new Error("Failed to update presentation template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating presentation template:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to update presentation template");
    }
  }
};

// Toggle enable/disable for a presentation template
export const togglePresentationTemplate = async (presentationTemplateId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.togglePresentationTemplate}${presentationTemplateId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to toggle presentation template");
    }

    throw new Error("Failed to toggle presentation template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling presentation template:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to toggle presentation template");
    }
  }
};

// Bulk Add Presentation Template
export const bulkAddPresentationTemplate = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddPresentationTemplate}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add presentation template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding presentation template:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add presentation template");
  }
};
// Delete a presentation template
export const deletePresentationTemplate = async (presentationTemplateId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deletePresentationTemplate}${presentationTemplateId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to delete presentation template");
    }

    throw new Error("Failed to delete presentation template");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting presentation template:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to delete presentation template");
    }
  }
};
