import axios from 'axios';
import { API } from '../../api';

// Add a new uptime parts category
export const addUptimePartsCategory = async (uptimePartsCategory) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    console.log("domain", API.domain);
    const response = await axios.post(
      `${API.domain}${API.endpoints.addUptimePartsCategory}`,
      uptimePartsCategory,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return true;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to add uptime parts category");
    }

    throw new Error("Failed to add uptime parts category");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error adding uptime parts category:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to add uptime parts category");
    }
  }
};

// Get all uptime parts categories
export const getUptimePartsCategories = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getUptimePartsCategories}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to get uptime parts categories");
    }

    throw new Error("Failed to get uptime parts categories");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error getting uptime parts categories:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to get uptime parts categories");
    }
  }
};

// Update an existing uptime parts category
export const updateUptimePartsCategory = async (uptimePartsCategoryId, uptimePartsCategory) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateUptimePartsCategory}`,
      { id: uptimePartsCategoryId, ...uptimePartsCategory },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to update uptime parts category");
    }

    throw new Error("Failed to update uptime parts category");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error updating uptime parts category:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to update uptime parts category");
    }
  }
};

// Toggle enable/disable for an uptime parts category
export const toggleUptimePartsCategory = async (uptimePartsCategoryId) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleUptimePartsCategory}${uptimePartsCategoryId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to toggle uptime parts category");
    }

    throw new Error("Failed to toggle uptime parts category");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error toggling uptime parts category:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to toggle uptime parts category");
    }
  }
};

// Bulk Add Uptime Parts Category
export const bulkAddUptimePartsCategory = async (rows) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddUptimePartsCategory}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add uptime parts category");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error bulk adding uptime parts category:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add uptime parts category");
  }
};

// Delete an uptime parts category
export const deleteUptimePartsCategory = async (uptimePartsCategoryId) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteUptimePartsCategory}${uptimePartsCategoryId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to delete uptime parts category");
    }

    throw new Error("Failed to delete uptime parts category");
  } catch (error) {
    const message = error.response?.data?.message;

    if (
      message === "token is invalid" ||
      message === "jwt expired"
    ) {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/";   // redirect to login
    }
    console.error("Error deleting uptime parts category:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to delete uptime parts category");
    }
  }
};