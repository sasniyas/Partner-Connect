import axios from 'axios';
import { API } from '../../api';

// Add Other Data
export const addOthersData = async (otherData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }
    
    console.log(otherData);
    
    const response = await axios.post(
      `${API.domain}${API.endpoints.addOtherData}`,
      otherData,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add other data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding other data:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add other data");
  }
};

// Get All Other Data
export const getAllOthersData = async () => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getOtherData}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("Full API response:", response.data);

    if (response.status === 200 && (response.data.status || response.data.success)) {
      const responseData = response.data.data;
      
      // If response is an object (not array), wrap it in array
      if (responseData && !Array.isArray(responseData)) {
        return [responseData];
      }
      
      // If it's already an array, return it
      if (Array.isArray(responseData)) {
        return responseData;
      }
    }

    throw new Error(response.data?.message || "Failed to get other data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting other data:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to get other data");
  }
};

// Update Other Data
export const updateOthersData = async (otherDataId, otherData) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const payload = {
      id: parseInt(otherDataId),
      file_name: String(otherData.file_name)
    };

    console.log("Update payload being sent:", payload);

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateOtherData}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to update other data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating other data:", error);
    console.error("Error response:", error.response?.data);
    throw new Error(error.response?.data?.message || error.message || "Failed to update other data");
  }
};

// Toggle Other Data (Active/Inactive)
export const toggleOthersData = async (otherDataId) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleOtherData}${otherDataId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to toggle other data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling other data:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle other data");
  }
};

export const bulkAddOthersData = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddOtherData}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add other data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding other data:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add other data");
  }
};

// Delete Other Data
export const deleteOthersData = async (otherDataId) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteOtherData}${otherDataId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to delete other data");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting other data:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete other data");
  }
};