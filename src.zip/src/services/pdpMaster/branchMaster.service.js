import axios from 'axios';
import { API } from '../../api';

/**
 * Add a new branch master
 * @param {Object} branchMaster - Branch master data
 * @param {number} branchMaster.market_area_id - Market area ID
 * @param {number} branchMaster.dealership_id - Dealership ID
 * @param {number} branchMaster.city_id - City ID
 * @param {Array<number>} branchMaster.district_ids - Array of district IDs
 * @param {string} branchMaster.branch_name - Branch name
 * @param {string} branchMaster.facility_type - Facility type
 * @param {string} [branchMaster.target_date] - Target date (optional, format: YYYY-MM-DD)
 * @param {string} [branchMaster.development_status] - Development status (optional: 'Completed', 'Not Started', 'In Progress')
 * @returns {Promise<any>} Response data
 */
export const addBranchMaster = async (branchMaster) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    // Validate development_status if provided
    const allowedStatuses = ['Completed', 'New', 'In Progress'];
    if (branchMaster.development_status && !allowedStatuses.includes(branchMaster.development_status)) {
      throw new Error(`development_status must be one of: ${allowedStatuses.join(', ')}`);
    }

    console.log("domain",API.domain);
    const response = await axios.post(
      `${API.domain}${API.endpoints.addBranchMaster}`,
      branchMaster,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || true;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to add branch master");
    }

    throw new Error("Failed to add branch master");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding branch master:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to add branch master");
    }
  }
};

/**
 * Bulk Add Branch Masters
 * @param {Array<Object>} rows - Array of branch master data
 * @returns {Promise<any>} Response data with inserted count
 */
export const bulkAddBranchMaster = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddBranchMaster}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add branch masters");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding branch masters:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add branch masters");
  }
};

/**
 * Get all branch masters
 * @returns {Promise<Array>} Array of branch masters with target_date and development_status
 */
export const getBranchMasters = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getBranchMasters}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      // Map the response data to match the expected frontend structure
      const mappedData = response.data.data.map(branch => ({
        ...branch,
        city_name: branch.cityName, // Map cityName to city_name for consistency
        branch_name: branch.branch_name,
        facility_type: branch.facility_type,
        marketarea: branch.marketarea,
        dealer_name: branch.dealer_name,
        isActive: branch.isActive,
        target_date: branch.target_date || null,
        development_status: branch.development_status || null,
        districts: branch.districts || []
      }));
      return mappedData;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to get branch masters");
    }

    throw new Error("Failed to get branch masters");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting branch masters:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to get branch masters");
    }
  }
};

/**
 * Update an existing branch master
 * @param {number|string} branchMasterId - Branch master ID
 * @param {Object} branchMaster - Branch master data
 * @param {number} branchMaster.market_area_id - Market area ID
 * @param {number} branchMaster.dealership_id - Dealership ID
 * @param {number} branchMaster.city_id - City ID
 * @param {Array<number>} branchMaster.district_ids - Array of district IDs
 * @param {string} branchMaster.branch_name - Branch name
 * @param {string} branchMaster.facility_type - Facility type
 * @param {number} [branchMaster.isActive] - Active status (0 or 1)
 * @param {string} [branchMaster.target_date] - Target date (optional, format: YYYY-MM-DD)
 * @param {string} [branchMaster.development_status] - Development status (optional: 'Completed', 'Not Started', 'In Progress')
 * @returns {Promise<any>} Response data
 */
export const updateBranchMaster = async (branchMasterId, branchMaster) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    // Validate development_status if provided
    const allowedStatuses = ['Completed', 'New', 'In Progress'];
    if (branchMaster.development_status && !allowedStatuses.includes(branchMaster.development_status)) {
      throw new Error(`development_status must be one of: ${allowedStatuses.join(', ')}`);
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateBranchMaster}`,
      { id: branchMasterId, ...branchMaster },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to update branch master");
    }

    throw new Error("Failed to update branch master");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating branch master:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to update branch master");
    }
  }
};

// Toggle enable/disable for a branch master
export const toggleBranchMaster = async (branchMasterId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleBranchMaster}${branchMasterId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to toggle branch master");
    }

    throw new Error("Failed to toggle branch master");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling branch master:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to toggle branch master");
    }
  }
};

// Delete a branch master
export const deleteBranchMaster = async (branchMasterId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteBranchMaster}${branchMasterId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to delete branch master");
    }

    throw new Error("Failed to delete branch master");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting branch master:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to delete branch master");
    }
  }
};
