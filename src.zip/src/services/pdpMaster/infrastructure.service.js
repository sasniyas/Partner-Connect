import axios from 'axios';
import { API } from '../../api';

// Add a new infrastructure
export const addInfrastructure = async (infrastructure) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    console.log("domain",API.domain);
    const response = await axios.post(
      `${API.domain}${API.endpoints.addInfrastructure}`,
      infrastructure,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return true;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to add infrastructure");
    }

    throw new Error("Failed to add infrastructure");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding infrastructure:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to add infrastructure");
    }
  }
};

// Get all infrastructures
export const getInfrastructures = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getInfrastructures}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to get infrastructures");
    }

    throw new Error("Failed to get infrastructures");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting infrastructures:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to get infrastructures");
    }
  }
};

// Update an existing infrastructure
export const updateInfrastructure = async (infrastructureId, infrastructure) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateInfrastructure}`,
      { id: infrastructureId, ...infrastructure },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to update infrastructure");
    }

    throw new Error("Failed to update infrastructure");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating infrastructure:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to update infrastructure");
    }
  }
};

// Toggle enable/disable for an infrastructure
export const toggleInfrastructure = async (infrastructureId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleInfrastructure}${infrastructureId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to toggle infrastructure");
    }

    throw new Error("Failed to toggle infrastructure");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling infrastructure:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to toggle infrastructure");
    }
  }
};

// Bulk Add Infrastructure
export const bulkAddInfrastructure = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddInfrastructure}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add infrastructure");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding infrastructure:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add infrastructure");
  }
};

// Delete an infrastructure
export const deleteInfrastructure = async (infrastructureId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteInfrastructure}${infrastructureId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to delete infrastructure");
    }

    throw new Error("Failed to delete infrastructure");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting infrastructure:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to delete infrastructure");
    }
  }
};
