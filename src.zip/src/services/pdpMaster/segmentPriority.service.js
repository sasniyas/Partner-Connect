import axios from 'axios';
import { API } from '../../api';

// Add Segment Priority
export const addSegmentPriority = async (segmentPriority) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }
    const response = await axios.post(
      `${API.domain}${API.endpoints.addSegmentPriority}`,
      segmentPriority,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add segment priority");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding segment priority:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add segment priority");
  }
};

// Bulk Add Segment Priorities
export const bulkAddSegmentPriority = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddSegmentPriority}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add segment priorities");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding segment priorities:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add segment priorities");
  }
};

// Get All Segment Priorities
export const getAllSegmentPriorities = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getAllSegmentPriorities}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );


    if (response.status === 200 && (response.data.status || response.data.success)) {
      const responseData = response.data.data;
      
      // If response is an object (not array), wrap it in array
      if (responseData && !Array.isArray(responseData)) {
        return [responseData];
      }
      
      // If it's already an array, return it
      if (Array.isArray(responseData)) {
        return responseData;
      }
    }

    throw new Error(response.data?.message || "Failed to get segment priorities");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting segment priorities:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to get segment priorities");
  }
};

// Update Segment Priority
export const updateSegmentPriority = async (segmentPriorityId, segmentPriority) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    // ✅ FIX: Include year in the payload
    const payload = {
      id: parseInt(segmentPriorityId),
      year: String(segmentPriority.year),  // ✅ ADDED: Include year
      segment_focus_area: String(segmentPriority.segment_focus_area)
    };


    const response = await axios.put(
      `${API.domain}${API.endpoints.updateSegmentPriority}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to update segment priority");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating segment priority:", error);
    console.error("Error response:", error.response?.data);
    throw new Error(error.response?.data?.message || error.message || "Failed to update segment priority");
  }
};

// Toggle Segment Priority (Active/Inactive)
export const toggleSegmentPriority = async (segmentPriorityId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleSegmentPriority}${segmentPriorityId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to toggle segment priority");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling segment priority:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle segment priority");
  }
};

// Delete Segment Priority
export const deleteSegmentPriority = async (segmentPriorityId) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteSegmentPriority}${segmentPriorityId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to delete segment priority");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting segment priority:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete segment priority");
  }
};