import axios from 'axios';
import { API } from '../../api';

// Add a new equipment
export const addEquipment = async (equipment) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    console.log("domain",API.domain);
    const response = await axios.post(
      `${API.domain}${API.endpoints.addEquipment}`,
      equipment,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return true;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to add equipment");
    }

    throw new Error("Failed to add equipment");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding equipment:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to add equipment");
    }
  }
};

// Get all equipments
export const getEquipments = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getEquipments}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to get equipments");
    }

    throw new Error("Failed to get equipments");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting equipments:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to get equipments");
    }
  }
};

// Bulk Add Equipment
export const bulkAddEquipment = async (rows) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddEquipment}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add equipment");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding equipment:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add equipment");
  }
};
// Update an existing equipment
export const updateEquipment = async (equipmentId, equipment) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateEquipment}`,
      { id: equipmentId, ...equipment },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to update equipment");
    }

    throw new Error("Failed to update equipment");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating equipment:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to update equipment");
    }
  }
};

// Toggle enable/disable for an equipment
export const toggleEquipment = async (equipmentId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleEquipment}${equipmentId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to toggle equipment");
    }

    throw new Error("Failed to toggle equipment");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling equipment:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to toggle equipment");
    }
  }
};

// Delete an equipment
export const deleteEquipment = async (equipmentId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteEquipment}${equipmentId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    if (response.data && !response.data.status) {
      throw new Error(response.data.message || "Failed to delete equipment");
    }

    throw new Error("Failed to delete equipment");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting equipment:", error);
    if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (error.message) {
      throw new Error(error.message);
    } else {
      throw new Error("Failed to delete equipment");
    }
  }
};
