import axios from 'axios';
import { API } from '../../api';

// Add Marcom
export const addMarcom = async (marcom) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    console.log("Adding marcom:", marcom);

    const response = await axios.post(
      `${API.domain}${API.endpoints.addMarcom}`,
      marcom,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to add marcom");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding marcom:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add marcom");
  }
};

// Bulk Add Marcom
export const bulkAddMarcom = async (rows) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.post(
      `${API.domain}${API.endpoints.bulkAddMarcom}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }

    throw new Error(response.data?.message || "Failed to bulk add marcom");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding marcom:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add marcom");
  }
};

// Get All Marcoms
export const getAllMarcoms = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.endpoints.getMarcoms}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("Full API response:", response.data);

    if (response.status === 200 && (response.data.status || response.data.success)) {
      const responseData = response.data.data;
      
      // If response is an object (not array), wrap it in array
      if (responseData && !Array.isArray(responseData)) {
        return [responseData];
      }
      
      // If it's already an array, return it
      if (Array.isArray(responseData)) {
        return responseData;
      }
    }

    throw new Error(response.data?.message || "Failed to get marcoms");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting marcoms:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to get marcoms");
  }
};

// Update Marcom - ✅ FIXED: Now includes year in payload
export const updateMarcom = async (marcomId, marcom) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    // ✅ FIXED: Include year in the payload
    const payload = {
      id: parseInt(marcomId),
      year: marcom.year ? String(marcom.year) : null,
      marcom_type: String(marcom.marcom_type),
      marcom_name: String(marcom.marcom_name)
    };

    console.log("Update payload being sent:", payload);

    const response = await axios.put(
      `${API.domain}${API.endpoints.updateMarcom}`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to update marcom");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating marcom:", error);
    console.error("Error response:", error.response?.data);
    throw new Error(error.response?.data?.message || error.message || "Failed to update marcom");
  }
};

// Toggle Marcom (Active/Inactive)
export const toggleMarcom = async (marcomId) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.endpoints.toggleMarcom}${marcomId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to toggle marcom");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling marcom:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle marcom");
  }
};

// Delete Marcom
export const deleteMarcom = async (marcomId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteMarcom}${marcomId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && (response.data.status || response.data.success)) {
      return response.data.data;
    }

    throw new Error(response.data?.message || "Failed to delete marcom");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting marcom:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete marcom");
  }
};