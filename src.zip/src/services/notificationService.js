import axios from "axios"
import { API } from "../api"

export const getUserNotificationsByUserId = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) throw new Error("No authentication token found")

    const response = await axios.get(
      `${API.domain}${API.endpoints.getUserNotificationsByUserId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      const rawData = response.data.data || []
      return rawData.map(item => ({
        id: item.id,
        notificationId: item.notification_id,
        userId: item.user_id,
        isSeen: Number(item.isSeen),
        title: item.notification_title,
        message: item.notification_message,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        type: item.notification_type || "update"
      }))
    }

    throw new Error(response.data?.message || "Failed to fetch notifications")
  } catch (error) {
    const message = error.response?.data?.message
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }
    console.error("Error fetching notifications:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch notifications")
  }
}

/**
 * Call toggleSeenStatus API for ONE notification.
 * Just calls the API — no filtering logic here.
 */
const callMarkSeenAPI = async (mappingId) => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
  if (!token) throw new Error("No authentication token found")

  const response = await axios.put(
    `${API.domain}${API.endpoints.markNotificationAsSeen}/${mappingId}`,
    {},
    {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    }
  )

  if (response.status === 200 && response.data.status) {
    return response.data
  }

  throw new Error(response.data?.message || "Failed to mark notification as seen")
}

/**
 * Fetch all notifications, find ones where isSeen === 0,
 * call API ONLY for those. Skip if isSeen is already 1.
 * Returns count of notifications that were actually marked.
 */
export const markUnseenNotificationsAsSeen = async () => {
  try {
    const notifications = await getUserNotificationsByUserId()

    // ONLY get notifications where isSeen is exactly 0
    const unseenOnly = (notifications || []).filter(n => n.isSeen === 0)

    console.log(`🔔 Total: ${notifications.length}, Unseen (isSeen===0): ${unseenOnly.length}`)

    if (unseenOnly.length === 0) {
      console.log("✅ No unseen notifications, skipping API calls")
      return 0
    }

    // Call API one by one (sequential to avoid race condition)
    let markedCount = 0
    for (const n of unseenOnly) {
      try {
        console.log(`📡 Marking ID ${n.id} as seen (isSeen was ${n.isSeen})`)
        await callMarkSeenAPI(n.id)
        markedCount++
        console.log(`✅ ID ${n.id} marked as seen`)
      } catch (err) {
        console.error(`❌ Failed to mark ID ${n.id}:`, err.message)
      }
    }

    console.log(`✅ Done: marked ${markedCount}/${unseenOnly.length}`)
    return markedCount
  } catch (error) {
    console.error("Error in markUnseenNotificationsAsSeen:", error)
    throw error
  }
}

export const deleteNotification = async (notificationId) => {
  try {
    if (!notificationId) throw new Error("Notification ID is required")

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) throw new Error("No authentication token found")

    const response = await axios.delete(
      `${API.domain}${API.endpoints.deleteNotification}/${notificationId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) return response.data
    throw new Error(response.data?.message || "Failed to delete notification")
  } catch (error) {
    const message = error.response?.data?.message
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }
    console.error("Error deleting notification:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to delete notification")
  }
}

export const bulkToggleNotificationsAsSeen = async (ids) => {
  try {
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      throw new Error("An array of IDs is required")
    }

    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken")
    if (!token) throw new Error("No authentication token found")

    const response = await axios.put(
      `${API.domain}${API.endpoints.bulkMarkNotificationsAsSeen}`,
      { ids },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response.status === 200 && response.data.status) {
      return response.data
    }

    throw new Error(response.data?.message || "Failed to mark notifications as seen")
  } catch (error) {
    const message = error.response?.data?.message
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken")
      localStorage.removeItem("superUserToken")
      window.location.href = "/"
    }
    console.error("Error marking bulk notifications as seen:", error)
    throw new Error(error.response?.data?.message || error.message || "Failed to mark notifications as seen")
  }
}