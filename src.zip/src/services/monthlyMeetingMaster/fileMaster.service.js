import axios from "axios";
import { API } from "../../api";

// Add a new file to File Master
export const addFile = async (fileData, file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }
    

    // Create FormData for file upload
    const formData = new FormData();
    formData.append("fileName", fileData.fileName);
    if (file) {
      formData.append("file", file);
    }

    const response = await axios.post(
      `${API.domain}${API.monthlyMeaatingendpoints.addFile}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to add file");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding file:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add file");
  }
};

// Get all files from File Master
export const getAllFiles = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.get(
      `${API.domain}${API.monthlyMeaatingendpoints.getAllFiles}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to fetch files");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error fetching files:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch files");
  }
};

// Update a file in File Master
export const updateFile = async (fileData, file) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    // Create FormData for update
    const formData = new FormData();
    formData.append("id", fileData.id);
    formData.append("fileName", fileData.fileName);
    formData.append("fileUrl", fileData.fileUrl || "");
    if (file) {
      formData.append("file", file);
    }

    const response = await axios.put(
      `${API.domain}${API.monthlyMeaatingendpoints.updateFile}`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data;
    }

    throw new Error(response.data.message || "Failed to update file");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating file:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to update file");
  }
};

// Toggle enable/disable for a file
export const toggleFile = async (fileId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.patch(
      `${API.domain}${API.monthlyMeaatingendpoints.toggleFile}${fileId}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to toggle file");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling file:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle file");
  }
};

// Delete a file from File Master
export const deleteFile = async (fileId) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      throw new Error("No authentication token found");
    }

    const response = await axios.delete(
      `${API.domain}${API.monthlyMeaatingendpoints.deleteFile}${fileId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }

    throw new Error(response.data.message || "Failed to delete file");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting file:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete file");
  }
};
