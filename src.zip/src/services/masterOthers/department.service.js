import axios from 'axios';
import { API } from '../../api';

// Add Department
export const addDepartment = async (department) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.post(
      `${API.domain}${API.contactManagementEndpoints.addCMDepartment}`,
      department,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to add department");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding department:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add department");
  }
};

// Bulk Add Departments
export const bulkAddDepartments = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.post(
      `${API.domain}${API.contactManagementEndpoints.bulkAddCMDepartment}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to bulk add departments");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error bulk adding departments:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add departments");
  }
};

// Get All Departments
export const getAllDepartments = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}${API.contactManagementEndpoints.getAllCMDepartments}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(response.data?.message || "Failed to get departments");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting departments:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to get departments");
  }
};

// Update Department
export const updateDepartment = async (department) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.put(
      `${API.domain}${API.contactManagementEndpoints.updateCMDepartment}`,
      department,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to update department");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating department:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to update department");
  }
};

// Toggle Department Status
export const toggleDepartmentStatus = async (id) => {
  try {
   const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.patch(
      `${API.domain}${API.contactManagementEndpoints.toggleCMDepartmentStatus}${id}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to toggle department status");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling department status:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle department status");
  }
};

// Delete Department
export const deleteDepartment = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.delete(
      `${API.domain}${API.contactManagementEndpoints.deleteCMDepartment}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to delete department");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting department:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete department");
  }
};
