import axios from 'axios';
import { API } from '../../api';

// Add Designation
export const addDesignation = async (designation) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.post(
      `${API.domain}${API.contactManagementEndpoints.addCMDesignation}`,
      designation,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to add designation");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error adding designation:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add designation");
  }
};

// Bulk Add Designations
export const bulkAddDesignations = async (rows) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.post(
      `${API.domain}${API.contactManagementEndpoints.bulkAddCMDesignation}`,
      { rows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to bulk add designations");
  } catch (error) {
    console.error("Error bulk adding designations:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add designations");
  }
};

// Get All Designations
export const getAllDesignations = async () => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}${API.contactManagementEndpoints.getAllCMDesignations}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data.data || [];
    }
    throw new Error(response.data?.message || "Failed to get designations");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error getting designations:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to get designations");
  }
};

// Update Designation
export const updateDesignation = async (designation) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.put(
      `${API.domain}${API.contactManagementEndpoints.updateCMDesignation}`,
      designation,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to update designation");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error updating designation:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to update designation");
  }
};

// Toggle Designation Status
export const toggleDesignationStatus = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.patch(
      `${API.domain}${API.contactManagementEndpoints.toggleCMDesignationStatus}${id}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to toggle designation status");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error toggling designation status:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle designation status");
  }
};

// Delete Designation
export const deleteDesignation = async (id) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.delete(
      `${API.domain}${API.contactManagementEndpoints.deleteCMDesignation}${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to delete designation");
  } catch (error) {
    const message = error.response?.data?.message;

            if (
                message === "token is invalid" ||
                message === "jwt expired"
            ) {

                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    console.error("Error deleting designation:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete designation");
  }
};