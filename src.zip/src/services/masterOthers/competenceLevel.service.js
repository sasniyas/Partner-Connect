import axios from 'axios';
import { API } from '../../api';

// ========== ADD COMPETENCE LEVEL ==========
export const addCompetenceLevel = async (competenceData) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.post(
      `${API.domain}/addCompetenceLevel`,
      {
        competence_type: competenceData.competenceType,
        competence: competenceData.competenceLevel,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to add competence level");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error adding competence level:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add competence level");
  }
};

// ========== BULK ADD COMPETENCE LEVELS ==========
export const bulkAddCompetenceLevels = async (rows) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const transformedRows = rows.map((row) => ({
      competence_type: row.competenceType,
      competence: row.competenceLevel,
    }));

    const response = await axios.post(
      `${API.domain}/bulkAddCompetenceLevel`,
      { rows: transformedRows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to bulk add competence levels");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error bulk adding competence levels:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add competence levels");
  }
};

// ========== GET ALL COMPETENCE LEVELS ==========
export const getAllCompetenceLevels = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}/getCompetenceLevels`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return (response.data.data || []).map((item) => ({
        id: item.id,
        competenceType: item.competence_type,
        competenceLevel: item.competence,
        status: item.isActive === 1 ? "Active" : "Inactive",
      }));
    }
    throw new Error(response.data?.message || "Failed to fetch competence levels");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error fetching competence levels:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch competence levels");
  }
};

// ========== GET COMPETENCE LEVEL BY ID ==========
export const getCompetenceLevelById = async (id) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}/getCompetenceLevelById/${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      const item = response.data.data;
      return {
        id: item.id,
        competenceType: item.competence_type,
        competenceLevel: item.competence,
        status: item.isActive === 1 ? "Active" : "Inactive",
      };
    }
    throw new Error(response.data?.message || "Failed to fetch competence level");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error fetching competence level:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch competence level");
  }
};

// ========== UPDATE COMPETENCE LEVEL ==========
export const updateCompetenceLevel = async (competenceData) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.put(
      `${API.domain}/updateCompetenceLevel`,
      {
        id: competenceData.id,
        competence_type: competenceData.competenceType,
        competence: competenceData.competenceLevel,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to update competence level");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error updating competence level:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to update competence level");
  }
};

// ========== TOGGLE COMPETENCE LEVEL STATUS ==========
export const toggleCompetenceLevelStatus = async (id) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.patch(
      `${API.domain}/toggleCompetenceLevel/toggle/${id}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to toggle competence level status");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error toggling competence level status:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle competence level status");
  }
};

// ========== DELETE COMPETENCE LEVEL ==========
export const deleteCompetenceLevel = async (id) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.delete(
      `${API.domain}/deleteCompetenceLevel/${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to delete competence level");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error deleting competence level:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete competence level");
  }
};