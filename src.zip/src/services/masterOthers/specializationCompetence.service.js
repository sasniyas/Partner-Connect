import axios from 'axios';
import { API } from '../../api';

// ========== ADD SPECIALIZATION COMPETENCE ==========
export const addSpecializationCompetence = async (specializationData) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.post(
      `${API.domain}/addSpecializationCompetence`,
      {
        specialization: specializationData.specialization,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to add specialization competence");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error adding specialization competence:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to add specialization competence");
  }
};

// ========== BULK ADD SPECIALIZATION COMPETENCE ==========
export const bulkAddSpecializationCompetence = async (rows) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const transformedRows = rows.map((row) => ({
      specialization: row.specialization,
    }));

    const response = await axios.post(
      `${API.domain}/bulkAddSpecializationCompetence`,
      { rows: transformedRows },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to bulk add specialization competences");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error bulk adding specialization competences:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to bulk add specialization competences");
  }
};

// ========== GET ALL SPECIALIZATION COMPETENCES ==========
export const getAllSpecializationCompetences = async () => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}/getSpecializationCompetences`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return (response.data.data || []).map((item) => ({
        id: item.id,
        specialization: item.specialization,
        status: item.isActive === 1 ? "Active" : "Inactive",
        created_at: item.created_at,
        updated_at: item.updated_at,
      }));
    }
    throw new Error(response.data?.message || "Failed to fetch specialization competences");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error fetching specialization competences:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch specialization competences");
  }
};

// ========== GET SPECIALIZATION COMPETENCE BY ID ==========
export const getSpecializationCompetenceById = async (id) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.get(
      `${API.domain}/getSpecializationCompetenceById/${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      const item = response.data.data;
      return {
        id: item.id,
        specialization: item.specialization,
        status: item.isActive === 1 ? "Active" : "Inactive",
        created_at: item.created_at,
        updated_at: item.updated_at,
      };
    }
    throw new Error(response.data?.message || "Failed to fetch specialization competence");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error fetching specialization competence:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to fetch specialization competence");
  }
};

// ========== UPDATE SPECIALIZATION COMPETENCE ==========
export const updateSpecializationCompetence = async (specializationData) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.put(
      `${API.domain}/updateSpecializationCompetence`,
      {
        id: specializationData.id,
        specialization: specializationData.specialization,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to update specialization competence");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error updating specialization competence:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to update specialization competence");
  }
};

// ========== TOGGLE SPECIALIZATION COMPETENCE STATUS ==========
export const toggleSpecializationCompetenceStatus = async (id) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.patch(
      `${API.domain}/toggleSpecializationCompetence/toggle/${id}`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to toggle specialization competence status");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error toggling specialization competence status:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to toggle specialization competence status");
  }
};

// ========== DELETE SPECIALIZATION COMPETENCE ==========
export const deleteSpecializationCompetence = async (id) => {
  try {
    const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) throw new Error("No authentication token found");

    const response = await axios.delete(
      `${API.domain}/deleteSpecializationCompetence/${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.status === 200 && response.data.status) {
      return response.data;
    }
    throw new Error(response.data?.message || "Failed to delete specialization competence");
  } catch (error) {
    const message = error.response?.data?.message;
    if (message === "token is invalid" || message === "jwt expired") {
      localStorage.removeItem("userToken");
      localStorage.removeItem("superUserToken");
      window.location.href = "/";
    }
    console.error("Error deleting specialization competence:", error);
    throw new Error(error.response?.data?.message || error.message || "Failed to delete specialization competence");
  }
};