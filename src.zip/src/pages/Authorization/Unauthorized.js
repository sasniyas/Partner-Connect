import React from "react";
import { useNavigate } from "react-router-dom";
import Header from "../../Components/Header";   // adjust path if needed
import SubNavbar3 from "../../Components/SubNavbar3"; // adjust path if needed

const Unauthorized = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Header */}
      {/* <Header /> */}

      {/* Sub Navigation
      <SubNavbar3 /> */}

      {/* 401 Content */}
      <div className="flex-1 flex flex-col items-center justify-center text-center px-6">
        <h1 className="text-6xl font-bold text-darkblue1 font-VolvoNovum">401</h1>
        <p className="mt-2 text-lg text-gray-600 font-VolvoNovum">
          Unauthorized! You do not have permission to view this page.
        </p>

        <button
          onClick={() => navigate("/homepage")} // navigate back to login or dashboard
          className="mt-6 bg-darkblue1 text-white px-6 py-2 rounded-lg font-medium hover:bg-opacity-90 transition"
        >
          Back to Home Page
        </button>
      </div>
    </div>
  );
};

export default Unauthorized;
