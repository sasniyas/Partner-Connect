import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { API } from '../../api';
import { useDispatch } from "react-redux";
import { fetchLoggedInUser } from "../../store/userSlice";
import { useMsal } from "@azure/msal-react";
import { InteractionRequiredAuthError } from "@azure/msal-browser";
import { LOGO_BASE_URL } from '../../util/filePath';

const Login = () => {
  const { instance, accounts } = useMsal();

  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  useEffect(() => {
    const handleRedirectLogin = async () => {
      try {
        // 1️⃣ Handle Microsoft redirect response
        const response = await instance.handleRedirectPromise();

        // 2️⃣ Get logged-in account
        const account = response?.account || instance.getAllAccounts()[0];

        if (!account) return; // ❌ Not logged in yet

        // 3️⃣ Get access token
        const tokenResponse = await instance.acquireTokenSilent({
          scopes: ["User.Read"],
          account,
        });
        const idToken = tokenResponse.idToken;


        // 4️⃣ Send token to backend
        const res = await fetch(`${API.domain}/ssoLogin`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            idToken,
          }),
        });

        const data = await res.json();

        if (res.ok) {
          // Success - store token if provided
          if (data.token) {
            localStorage.setItem('superUserToken', data.token);
          }
          await dispatch(fetchLoggedInUser());
               // 6️⃣ Redirect to app
          navigate("/homepage");
        } else {
          // API returned error
          return {
            success: false,
            error: data.message || 'Login failed. Please try again.'
          };
        }
      } catch (err) {
        // 1️⃣ Azure / MSAL session expired
        if (err instanceof InteractionRequiredAuthError) {
          setErrors({
            submit: "Your session has expired. Please sign in again.",
          });
          return;
        }

        // 2️⃣ Backend API error (Axios)
        if (err?.response) {
          if (err.response.status === 400) {
            setErrors({
              submit: "You are not authorized to access this application.",
            });
          } else if (err.response.status === 404) {
            setErrors({
              submit: err.response.data?.message || "User not found.",
            });
          } else {
            setErrors({
              submit: "Something went wrong. Please try again.",
            });
          }
          return;
        }

        // 3️⃣ Network / unknown error
        setErrors({
          submit: "Network error. Please check your connection.",
        });
      }

    };

    handleRedirectLogin();
  }, []);


  const togglePassword = () => setShowPassword((prev) => !prev);

  const handleForgotPassword = () => {
    navigate("/forgot-password");
  };

  // ✅ Validation Function
  const validateForm = () => {
    let newErrors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email) {
      newErrors.email = "Please enter your email";
    } else if (!emailRegex.test(email)) {
      newErrors.email = "Please enter a valid email address";
    }

    if (!password) {
      newErrors.password = "Please enter your password";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // ✅ API Login Function
  const loginUser = async (email, password) => {
    try {
      const response = await fetch(`${API.domain}${API.userManagement.login}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          "email": email,
          "password": password
        })
      });

      const data = await response.json();

      if (response.ok) {
        // Success - store token if provided
        if (data.token) {
          localStorage.setItem('superUserToken', data.token);
        }
        if (data.user) {
          localStorage.setItem('user', JSON.stringify(data.user));
        }
        await dispatch(fetchLoggedInUser());
        return { success: true, data };
      } else {
        // API returned error
        return {
          success: false,
          error: data.message || 'Login failed. Please try again.'
        };
      }
    } catch (error) {
      console.error('Login error:', error);
      return {
        success: false,
        error: 'Network error. Please check your connection and try again.'
      };
    }
  };

  // ✅ Handle Submit with API Integration
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    setErrors({}); // Clear any previous errors

    try {
      const result = await loginUser(email, password);

      if (result.success) {
        // Login successful - redirect to homepage
        navigate("/homepage");
      } else {
        // Login failed - show error
        setErrors({
          submit: result.error
        });
      }
    } catch (error) {
      setErrors({
        submit: 'An unexpected error occurred. Please try again.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSSOLogin = async () => {
    setErrors({});
    await instance.loginRedirect({
      scopes: ["User.Read"],
    });
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row overflow-hidden">
      {/* Left Side Image */}
      <div className="hidden lg:block lg:w-1/2">
        <img
          src={`${LOGO_BASE_URL}/public/icons/Login/volvologin 2.png`}
          alt="Truck"
          className="w-full h-screen object-cover"
        />
      </div>

      {/* Right Side Login Form */}
      <div className="w-full lg:w-1/2 h-screen flex flex-col justify-center px-6 bg-white">
        {/* Volvo Logo */}
        <div className="flex justify-center  mt-[-50px]">
          <img
            src={`${LOGO_BASE_URL}/public/volvo-spread-word-mark1214[1].jpg`}
            alt="Volvo"
            className="w-40 h-auto"
          />
        </div>

        <div className="max-w-sm w-full px-6 mx-auto">
          <h2 className="text-4xl font-bold mb-2 text-center font-VolvoNovum">Welcome back!</h2>
          <p className="text-sm text-grey font-medium mb-6 text-center font-VolvoNovum">
            Login to continue
          </p>

          <form className="space-y-5" onSubmit={handleSubmit}>
            {/* General Error Message */}
            {errors.submit && (
              <div className="relative bg-transparent border border-red1 text-red1 px-4 py-3  text-sm flex items-center">
                {/* Close Button */}
                <button
                  onClick={() => setErrors({ ...errors, submit: "" })}
                  type="button"
                  className=" flex items-center justify-center gpa-2  mr-3"
                >
                  <img src={`${LOGO_BASE_URL}/public/icons/MarketAreaatble/cancel.png`} alt="close" className="w-4 h-4" />

                </button>

                {/* Error Message */}
                <span className="flex-1">{errors.submit}</span>
              </div>
            )}


            {/* Email */}
           

           

            <button
              type="button"
              onClick={handleSSOLogin}
              disabled={isLoading}
              className="w-full bg-darkblue1 text-white   py-1.5 text-sm font-medium mt-3
             hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition
             disabled:opacity-50 disabled:cursor-not-allowed"
            >
Login with partner connect            </button>

          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;