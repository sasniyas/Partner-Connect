import React, { useState, useRef, useEffect, useCallback,useMemo } from "react";
import Inventory from "./Inventory/Inventory";
import allocationProjectionService from "../../../services/dealerInvestment/Allocationprojection.service";
import { ChevronDown,ChevronUp,ChevronsUpDown ,RotateCcw} from "lucide-react";
import Searchinput from "../../../Components/Searchinput";
const AllocationManagementSystem = ({ initialActiveTab }) => {
  const [activeTab, setActiveTab] = useState(initialActiveTab || "allocation");
  const [expandDealers, setExpandDealers] = useState(false);
  const [expandMarketAreas, setExpandMarketAreas] = useState(false);
const [highlightIndex, setHighlightIndex] = useState(-1);
const handleKeyDown = (e, filterName) => {
  const options = filteredOptions(filterName);

  if (!options.length) return;

  // ESC → close
  if (e.key === "Escape") {
    setOpenDropdown(null);
    setHighlightIndex(-1);
  }

  // DOWN ↓
  else if (e.key === "ArrowDown") {
    e.preventDefault();
    setHighlightIndex((prev) =>
      prev < options.length - 1 ? prev + 1 : 0
    );
  }

  // UP ↑
  else if (e.key === "ArrowUp") {
    e.preventDefault();
    setHighlightIndex((prev) =>
      prev > 0 ? prev - 1 : options.length - 1
    );
  }

  // ENTER → select
  else if (e.key === "Enter") {
    e.preventDefault();
    if (highlightIndex >= 0) {
      handleSelect(filterName, options[highlightIndex]);
    }
  }
};
  // API Data States
  const [projectionData, setProjectionData] = useState([]);
  const [actualsData, setActualsData] = useState([]);
  const [allocationData, setAllocationData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showScrollButtons, setShowScrollButtons] = useState(false);
const [scrollDirection, setScrollDirection] = useState(null);
const [lastScrollTop, setLastScrollTop] = useState(0);
const [searchTerm, setSearchTerm] = useState("");
  const [dataLoaded, setDataLoaded] = useState({
    projection: false,
    actuals: false,
    allocation: false,
  });
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);

  // Dynamic filter options from API
  const [dynamicFilterOptions, setDynamicFilterOptions] = useState({
    years: [],
    dealers: [],
    marketAreas: [],
    equipmentTypes: ["Equipment All Types"],
    models: ["All Models"],
  });

  const [selectedValues, setSelectedValues] = useState({
    year: [],
    marketArea: [],
    dealer: [],
    month: [],
equipmentType: [],
    model: [],
    type: "Retail",
  });

  const [openDropdown, setOpenDropdown] = useState(null);
  const [searchTerms, setSearchTerms] = useState({
    year: "",
    marketArea: "",
    dealer: "",
    month: "",
    equipmentType: "",
    model: "",
  });
  const [displayedRows, setDisplayedRows] = useState(20);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const tableContainerRef = useRef(null);
  const searchInputRefs = useRef({});
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // Static data for fallback
  const staticYears = ["2027", "2026", "2025", "2024", "2023"];
  const staticMarketAreas = ["North", "South", "East", "West", "Central", "Northeast"];
  const staticDealers = [
    "ACT", "ALPHA-DL", "ALPHA-UP", "BSES", "DRS", "ENCORE", "ESDEE", "INFRA",
    "NAVIN", "PACT", "PAL", "PT ENGG", "RPSL-TS", "RPSL-AP", "SEMAC", "SELECT",
    "OMAX", "UNITED ENG", "VEE KAY", "TRIDENT", "SMPL-BH",
  ];
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const staticEquipmentTypes = ["Equipment All Types", "Excavators", "Loader", "Road Machinery", "Volvo", "SDLG", "Attachments", "GPE", "20 T", "Quick Coupler"];
  const staticModels = ["All Models", "JEC55D", "EC210EB", "EC220 Q&A", "EC220 M", "EC210DLR8", "EC250DL", "EC300DL", "EC380DL", "EC480DL", "EC550EL", "EC750DL", "EC950EL", "L90H", "L120H", "L150H", "L180H", "L220H", "L260H", "L350F", "EC200D", "HYST34", "8 ton coupler"];
  const types = ["Retail", "KAM", "Retail+KAM"];
const handleSort = (key) => {
  if (sortKey === key) {
    // cycle through asc → desc → none
    if (sortOrder === "asc") setSortOrder("desc");
    else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else setSortOrder("asc");
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  useEffect(() => {
    const style = document.createElement("style");
    style.innerHTML = `.hide-scrollbar::-webkit-scrollbar{display:none}.hide-scrollbar{-ms-overflow-style:none;scrollbar-width:none}`;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  useEffect(() => {
    if (initialActiveTab) {
      setActiveTab(initialActiveTab);
    }
  }, [initialActiveTab]);

  // Fetch projection data (Monthly Projection)
  const fetchProjectionData = useCallback(async () => {
    if (dataLoaded.projection) return;
    
    setLoading(true);
    setError(null);
    try {
      const response = await allocationProjectionService.getAllProjections();
      
      if (response.status && response.data) {
        setProjectionData(response.data);
        setDataLoaded((prev) => ({ ...prev, projection: true }));
        
        const filterOptions = allocationProjectionService.extractFilterOptions(response.data);
        setDynamicFilterOptions((prev) => ({
          ...prev,
          years: filterOptions.years.length > 0 ? filterOptions.years : staticYears,
          dealers: filterOptions.dealers.length > 0 ? filterOptions.dealers : staticDealers,
          marketAreas: filterOptions.marketAreas.length > 0 ? filterOptions.marketAreas : staticMarketAreas,
          equipmentTypes: filterOptions.equipmentTypes.length > 1 ? filterOptions.equipmentTypes : staticEquipmentTypes,
          models: filterOptions.models.length > 1 ? filterOptions.models : staticModels,
        }));
      }
    } catch (err) {
      console.error("Error fetching projection data:", err);
      setError("Failed to load projection data. Please try again.");
    } finally {
      setLoading(false);
    }
  }, [dataLoaded.projection]);

  // Fetch actuals data (Final Projection)
  const fetchActualsData = useCallback(async () => {
    if (dataLoaded.actuals) return;
    
    setLoading(true);
    setError(null);
    try {
      const response = await allocationProjectionService.getAllActuals();
      
      if (response.status && response.data) {
        setActualsData(response.data);
        setDataLoaded((prev) => ({ ...prev, actuals: true }));
        
        if (dynamicFilterOptions.years.length === 0) {
          const filterOptions = allocationProjectionService.extractFilterOptions(response.data);
          setDynamicFilterOptions((prev) => ({
            ...prev,
            years: filterOptions.years.length > 0 ? filterOptions.years : staticYears,
            dealers: filterOptions.dealers.length > 0 ? filterOptions.dealers : staticDealers,
            marketAreas: filterOptions.marketAreas.length > 0 ? filterOptions.marketAreas : staticMarketAreas,
            equipmentTypes: filterOptions.equipmentTypes.length > 1 ? filterOptions.equipmentTypes : staticEquipmentTypes,
            models: filterOptions.models.length > 1 ? filterOptions.models : staticModels,
          }));
        }
      }
    } catch (err) {
      console.error("Error fetching actuals data:", err);
      setError("Failed to load actuals data. Please try again.");
    } finally {
      setLoading(false);
    }
  }, [dataLoaded.actuals, dynamicFilterOptions.years.length]);

  // Fetch allocation data (Allocation Tab)
  const fetchAllocationData = useCallback(async () => {
    if (dataLoaded.allocation) return;
    
    setLoading(true);
    setError(null);
    try {
      const response = await allocationProjectionService.getAllAllocations();
      
      if (response.status && response.data) {
        setAllocationData(response.data);
        setDataLoaded((prev) => ({ ...prev, allocation: true }));
        
        // Extract filter options from allocation data
        const filterOptions = allocationProjectionService.extractFilterOptions(response.data);
        setDynamicFilterOptions((prev) => ({
          ...prev,
          years: filterOptions.years.length > 0 ? filterOptions.years : prev.years.length > 0 ? prev.years : staticYears,
          dealers: filterOptions.dealers.length > 0 ? filterOptions.dealers : prev.dealers.length > 0 ? prev.dealers : staticDealers,
          marketAreas: filterOptions.marketAreas.length > 0 ? filterOptions.marketAreas : prev.marketAreas.length > 0 ? prev.marketAreas : staticMarketAreas,
          equipmentTypes: filterOptions.equipmentTypes.length > 1 ? filterOptions.equipmentTypes : prev.equipmentTypes.length > 1 ? prev.equipmentTypes : staticEquipmentTypes,
          models: filterOptions.models.length > 1 ? filterOptions.models : prev.models.length > 1 ? prev.models : staticModels,
        }));
      }
    } catch (err) {
      console.error("Error fetching allocation data:", err);
      setError("Failed to load allocation data. Please try again.");
    } finally {
      setLoading(false);
    }
  }, [dataLoaded.allocation]);

  // Fetch data when tab changes
  useEffect(() => {
    if (activeTab === "monthlyProjection") {
      fetchProjectionData();
    } else if (activeTab === "finalProjection") {
      fetchActualsData();
    } else if (activeTab === "allocation") {
      fetchAllocationData();
    }
  }, [activeTab, fetchProjectionData, fetchActualsData, fetchAllocationData]);

  const isApiTab = activeTab === "monthlyProjection" || activeTab === "finalProjection" || activeTab === "allocation";
  
  // Check if current tab is allocation (no category/type filter available)
  const isAllocationTab = activeTab === "allocation";

  const getFilterOptions = () => {
    if (isApiTab && dynamicFilterOptions.years.length > 0) {
      return {
        years: dynamicFilterOptions.years,
        dealers: dynamicFilterOptions.dealers.length > 0 ? dynamicFilterOptions.dealers : staticDealers,
        marketAreas: dynamicFilterOptions.marketAreas.length > 0 ? dynamicFilterOptions.marketAreas : staticMarketAreas,
        equipmentTypes: dynamicFilterOptions.equipmentTypes,
        models: dynamicFilterOptions.models,
      };
    }
    return {
      years: staticYears,
      dealers: staticDealers,
      marketAreas: staticMarketAreas,
      equipmentTypes: staticEquipmentTypes,
      models: staticModels,
    };
  };

  const filterOptions = getFilterOptions();

  const getOptionsMap = (name) => {
    const optionsMap = {
      year: filterOptions.years,
      marketArea: filterOptions.marketAreas,
      dealer: filterOptions.dealers,
      month: months,
      equipmentType: filterOptions.equipmentTypes,
      model: filterOptions.models,
      type: types,
    };
    return optionsMap[name] || [];
  };

  const calculateTotal = (row) => {
    let total = 0;
    const currentMarketAreas = filterOptions.marketAreas;
    currentMarketAreas.forEach((area) => {
      const key = area.toLowerCase();
      total += row[key] || 0;
    });
    total += row.inExp || 0;
    return total;
  };

  const getFilteredData = (projectionType = "Monthly") => {
    // Monthly Projection Tab - API data only
    if (activeTab === "monthlyProjection") {
      if (projectionData.length > 0) {
        return allocationProjectionService.transformDataForTable(projectionData, selectedValues, false);
      }
      return [];
    }

    // Final Projection Tab - API data only
    if (activeTab === "finalProjection") {
      if (actualsData.length > 0) {
        return allocationProjectionService.transformDataForTable(actualsData, selectedValues, false);
      }
      return [];
    }

    // Allocation Tab - API data only (pass isAllocationData = true)
    if (activeTab === "allocation") {
      if (allocationData.length > 0) {
        // Pass true for isAllocationData to skip category/type filtering
        return allocationProjectionService.transformDataForTable(allocationData, selectedValues, true);
      }
      return [];
    }

    return [];
  };

 const handleClear = () => {
  setSelectedValues({
    year: [],
    marketArea: [],
    dealer: [],
    month: [],
    equipmentType: [],
    model: [],
    type: "Retail",
  });

  setSearchTerm("");        // 🔥 CLEAR SEARCH
  setDisplayedRows(20);     // reset lazy load
};

  const handleRefresh = async () => {
    setDataLoaded({ projection: false, actuals: false, allocation: false });
    setProjectionData([]);
    setActualsData([]);
    setAllocationData([]);
    
    if (activeTab === "monthlyProjection") {
      await fetchProjectionData();
    } else if (activeTab === "finalProjection") {
      await fetchActualsData();
    } else if (activeTab === "allocation") {
      await fetchAllocationData();
    }
  };

  const filteredOptions = (name) => {
    const opts = getOptionsMap(name);
    const search = searchTerms[name]?.toLowerCase() || "";
    return opts.filter((opt) => opt.toLowerCase().includes(search));
  };

  const handleSelect = (name, value) => {
    setSelectedValues((prev) => {
      const newValues = { ...prev };
      if (name === "type") {
        newValues.type = value;
      } else if (Array.isArray(newValues[name])) {
        if (name === "equipmentType" && value === "Equipment All Types") {
          newValues[name] = ["Equipment All Types"];
        } else if (name === "model" && value === "All Models") {
          newValues[name] = ["All Models"];
        } else {
          if (newValues[name].includes(value)) {
            newValues[name] = newValues[name].filter((v) => v !== value);
          } else {
            if (name === "equipmentType") {
              newValues[name] = [...newValues[name].filter((v) => v !== "Equipment All Types"), value];
            } else if (name === "model") {
              newValues[name] = [...newValues[name].filter((v) => v !== "All Models"), value];
            } else {
              newValues[name] = [...newValues[name], value];
            }
          }
        }
      }
      return newValues;
    });
    setDisplayedRows(20);
  };

  const handleSelectAll = (name) => {
    const options = filteredOptions(name);
    setSelectedValues((prev) => ({ ...prev, [name]: options }));
    setDisplayedRows(20);
  };

  const handleDeselectAll = (name) => {
    const defaultValues = {
      year: [], marketArea: [], dealer: [], month: [],
      equipmentType: ["Equipment All Types"], model: [],
    };
    setSelectedValues((prev) => ({ ...prev, [name]: defaultValues[name] || [] }));
    setDisplayedRows(20);
  };

  const handleDropdownClick = (name) => {
    setOpenDropdown(openDropdown === name ? null : name);
  };

  useEffect(() => {
    const handleClick = (e) => {
      if (!e.target.closest(".dropdown-container")) setOpenDropdown(null);
    };
    document.addEventListener("click", handleClick);
    return () => document.removeEventListener("click", handleClick);
  }, []);

  useEffect(() => {
    if (openDropdown && searchInputRefs.current[openDropdown]) {
      searchInputRefs.current[openDropdown].focus();
    }
  }, [openDropdown]);

  const handleScroll = useCallback(() => {
    if (!tableContainerRef.current || isLoadingMore) return;
    const { scrollTop, scrollHeight, clientHeight } = tableContainerRef.current;
    
    // Load more when near bottom (within 100px)
    if (scrollTop + clientHeight >= scrollHeight - 100) {
      // Get current data length based on active tab
      let totalDataLength = 0;
      if (activeTab === "monthlyProjection") {
        totalDataLength = projectionData.length;
      } else if (activeTab === "finalProjection") {
        totalDataLength = actualsData.length;
      } else if (activeTab === "allocation") {
        totalDataLength = allocationData.length;
      }
      
      if (displayedRows < totalDataLength) {
        setIsLoadingMore(true);
        setTimeout(() => {
          setDisplayedRows((prev) => Math.min(prev + 20, totalDataLength));
          setIsLoadingMore(false);
        }, 300);
      }
    }
  }, [isLoadingMore, displayedRows, activeTab, projectionData.length, actualsData.length, allocationData.length]);

  useEffect(() => {
    const container = tableContainerRef.current;
    if (container) {
      container.addEventListener("scroll", handleScroll);
      return () => container.removeEventListener("scroll", handleScroll);
    }
  }, [handleScroll]);
const [showTopBorder, setShowTopBorder] = useState({});

useEffect(() => {
  if (!openDropdown) return;

  const dropdown = dropdownRef.current[openDropdown];
  const button = dropdown?.parentElement?.querySelector("button");

  if (!dropdown || !button) return;

  const isSameWidth =
    Math.abs(dropdown.offsetWidth - button.offsetWidth) < 2;

  setShowTopBorder((prev) => ({
    ...prev,
    [openDropdown]: !isSameWidth, // show border only if different
  }));
}, [openDropdown]);
  const getSelectedDisplay = (name) => {
    if (name === "type") return selectedValues.type;
    const selected = selectedValues[name];
    if (!selected || selected.length === 0) {
      const placeholders = {
  year: "Year",
  marketArea: "Market Area",
  dealer: "Dealer",
  month: "Month",
  equipmentType: "Equipment Type", // ✅ FIXED
  model: "Models",
};
      return placeholders[name];
    }
    if (selected.length === 1) return selected[0];
    return `${selected.length} selected`;
  };

  const getTableColspan = () => {
    let cols = 4;
    if (expandDealers) cols += filterOptions.dealers.length;
    if (expandMarketAreas) cols += filterOptions.marketAreas.length;
    return cols;
  };
  const filterWidths = {
  year: "w-[160px]",
  marketArea: "w-[160px]",
  dealer: "w-[160px]",
  month: "w-[160px]",
  equipmentType: "w-[160px]",
  model: "w-[160px]",
};
const dropdownRef = useRef({});

  const TableView = ({ projectionType, title }) => {
    const filteredData = getFilteredData(projectionType);
    const displayData = filteredData.slice(0, displayedRows);
    const visibleDealers = selectedValues.dealer.length > 0 ? selectedValues.dealer : filterOptions.dealers;
    const visibleMarketAreas = selectedValues.marketArea.length > 0 ? selectedValues.marketArea : filterOptions.marketAreas;
const sortedData = useMemo(() => {
  // 🔥 APPLY SEARCH FIRST
  let searchedData = displayData;

  if (searchTerm.trim()) {
    const search = searchTerm.toLowerCase();

    searchedData = displayData.filter((row) => {
      return (
        row.equipmentType?.toLowerCase().includes(search) ||
        row.model?.toLowerCase().includes(search) ||
        String(row.inExp || "").toLowerCase().includes(search) ||
        String(calculateTotal(row)).toLowerCase().includes(search) ||
        Object.values(row.dealerAllocation || {}).some((val) =>
          String(val).toLowerCase().includes(search)
        )
      );
    });
  }

  // 🔥 APPLY SORT
  if (!sortKey || !sortOrder) return searchedData;

  return [...searchedData].sort((a, b) => {
    let valA;
    let valB;

    if (sortKey === "total") {
      valA = calculateTotal(a);
      valB = calculateTotal(b);
    } else {
      valA = a[sortKey];
      valB = b[sortKey];
    }

    // numeric
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // string
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });

}, [displayData, sortKey, sortOrder, searchTerm]);
    return (
      <div className=" w-full">
<div className="flex items-center w-full">
  <h2 className="text-sm font-bold text-[#2c3e50] mr-2">
    {title}
  </h2>
   {/* API Status - Right side */}
            <div className="ml-auto flex items-center gap-1.5">
               {!isAllocationTab && (
              <div className="flex items-center gap-0.5 bg-gray-200 rounded p-0.5">
                {types.map((type) => (
                  <button key={type} onClick={() => handleSelect("type", type)}
                    className={`px-1 py-0.5 text-xs rounded transition-colors ${selectedValues.type === type ? "bg-[#2c3e50] text-white" : "text-gray-600 hover:bg-gray-300"}`}>
                    {type}
                  </button>
                ))}
              </div>
            )}
              {isApiTab && (
                <>
                  {loading ? (
                    <div className="flex items-center gap-1 text-blue-600">
                      <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-blue-600"></div>
                      <span className="text-xs">Loading...</span>
                    </div>
                  ) : error ? (
                    <div className="flex items-center gap-1 text-red-600">
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span className="text-xs">Error</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 text">
                      <div className="w-2 h-2 rounded-full bg"></div>
                      <span className="text-xs">Connected</span>
                    </div>
                  )}
                  <button onClick={handleRefresh} disabled={loading}
                    className="p-1 text-gray-500 hover:text-[#2c3e50] hover:bg-gray-100 rounded transition-colors disabled:opacity-50" title="Refresh">
                    <svg className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                  </button>
                </>
              )}
            </div>
</div>
        {/* COMPACT FILTER SECTION - Single row layout */}
        <div className=" py-2 border-b border-gray-200">
          {/* Row 1: Title + Filters + API Status - ALL IN ONE LINE */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Title */}
            <Searchinput
  value={searchTerm}
  onChange={(e) => {
    setSearchTerm(e.target.value);
    setDisplayedRows(20); // reset lazy load
  }}
  placeholder="Search"
  className="w-[150px]"
  iconColor="text-black"
  bgColor="bg-FrostWhite"
  borderColor="border-black/60"
  textColor="text-black"
  shadow="shadow-none"
  inputPadding="pl-6 pr-3 py-1.5"
  iconSize="w-3 h-3"
  iconLeft="left-3"
  inputWidth="w-full"
  focusRing="focus:ring-1 focus:ring-black/60"
  hoverInputClasses="hover:bg-white hover:border-black/60"
/>
            {/* Filter Dropdowns */}
         {["year", "marketArea", "dealer", "month", "equipmentType", "model"].map((filterName) => (
<div
  key={filterName}
  className={`dropdown-container relative ${filterWidths[filterName]}`}
>
    {/* BUTTON */}
  <button
  onClick={(e) => {
    e.stopPropagation();
    handleDropdownClick(filterName);
  }}
  className={`flex items-center w-full px-3 py-1.5 text-xs bg-white border border-black/60 ${
    openDropdown === filterName ? "border-b-0" : ""
  }`}
>
  {/* TEXT */}
  <span
    className={`truncate flex-1 text-left ${
      selectedValues[filterName]?.length
        ? "text-black font-medium"
        : "text-gray-400"
    }`}
  >
    {getSelectedDisplay(filterName)}
  </span>

  {/* RIGHT SIDE ICONS */}
  <div className="flex items-center gap-1 ml-auto">

    {/* 🔄 CLEAR ICON */}
    {selectedValues[filterName]?.length > 0 && (
      <span
        onClick={(e) => {
          e.stopPropagation(); // prevent dropdown open
          handleDeselectAll(filterName);
        }}
        className="p-0.5 rounded hover:bg-gray-100 text-gray-500 hover:text-black cursor-pointer"
        title="Clear"
      >
                     <RotateCcw className="w-3.5 h-3.5" />

      </span>
    )}

    {/* DROPDOWN ICON */}
    <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className={`w-5 h-5 transition-transform ${
        openDropdown === filterName ? "rotate-180" : ""
      }`}
    fill="none"
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
  </div>
</button>

    {/* DROPDOWN */}
   {openDropdown === filterName && (
  <div
    ref={(el) => (dropdownRef.current[filterName] = el)}
    className={`absolute top-full left-0 bg-white border border-black/60 shadow-lg z-50 
    min-w-full w-max max-w-[90vw]
   ${showTopBorder[filterName] ? "border-t" : "border-t-0"}`}
  >

    {/* SEARCH */}
    <div className="flex items-center gap-1 px-2 py-1 border-b border-gray-200">
      <input
        ref={(el) => (searchInputRefs.current[filterName] = el)}
        type="text"
        placeholder="Search..."
        value={searchTerms[filterName] || ""}
        onKeyDown={(e) => handleKeyDown(e, filterName)}
        onChange={(e) =>
          setSearchTerms((prev) => ({
            ...prev,
            [filterName]: e.target.value,
          }))
        }
        className="flex-1 bg-transparent outline-none text-xs"
        onClick={(e) => e.stopPropagation()}
      />
    </div>

    {/* ACTIONS */}
    <div className="flex gap-1 p-1.5 border-b border-gray-200">

      {/* ALL */}
      <button
        data-nav
        tabIndex={0}
        onClick={(e) => {
          e.stopPropagation();
          handleSelectAll(filterName);
        }}
        onKeyDown={(e) => {
          const items = Array.from(
            dropdownRef.current[filterName].querySelectorAll("[data-nav]")
          );
          const i = items.indexOf(e.currentTarget);

          if (e.key === "ArrowDown") {
            e.preventDefault();
            items[i + 1]?.focus();
          }
          if (e.key === "ArrowUp") {
            e.preventDefault();
            items[i - 1]?.focus();
          }
          if (e.key === "Enter") {
            handleSelectAll(filterName);
          }
        }}
        className="px-2 py-0.5 text-xs bg-gray-100 hover:bg-blue-100 rounded"
      >
        All
      </button>

    </div>

    {/* OPTIONS */}
    <div className="max-h-[180px] overflow-y-auto">
      {filteredOptions(filterName).map((option) => (
        <div
          key={option}
          data-nav
          tabIndex={0}
          onClick={(e) => {
            e.stopPropagation();
            handleSelect(filterName, option);
          }}
          onKeyDown={(e) => {
            const items = Array.from(
              dropdownRef.current[filterName].querySelectorAll("[data-nav]")
            );
            const i = items.indexOf(e.currentTarget);

            if (e.key === "ArrowDown") {
              e.preventDefault();
              items[(i + 1) % items.length]?.focus();
            }
            if (e.key === "ArrowUp") {
              e.preventDefault();
              items[(i - 1 + items.length) % items.length]?.focus();
            }
            if (e.key === "Enter") {
              handleSelect(filterName, option);
            }
            if (e.key === "Escape") {
              setOpenDropdown(null);
            }
          }}
          className={`px-2.5 py-1 text-xs cursor-pointer flex items-center gap-1.5
            hover:bg-blue-50
            ${selectedValues[filterName]?.includes(option) ? "bg-blue-100" : ""}
          `}
        >
          <input
            type="checkbox"
            checked={selectedValues[filterName]?.includes(option) || false}
            readOnly
            className="w-3.5 h-3.5"
          />
          <span className="truncate">{option}</span>
        </div>
      ))}
    </div>
  </div>
)}
  </div>
))}

            {/* Type Toggle - HIDE for Allocation tab since it has no category data */}
           

            <button onClick={handleClear} className="px-2 py-1 text-xs text-gray-500 hover:text-red-600 hover:bg-red-50 rounded transition-colors">
              Clear All
            </button>

           
          </div>

          {/* Error message if any */}
          {error && (
            <div className="mt-2 p-1.5 bg-red-50 border border-red-200 rounded text-red-700 text-xs flex items-center gap-2">
              <span>{error}</span>
              <button onClick={handleRefresh} className="ml-auto text-red-600 hover:text-red-800 underline text-xs">Retry</button>
            </div>
          )}
        </div>

        {/* Row 2: Checkboxes - Compact */}
        <div className="py-1.5 flex gap-4">
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input type="checkbox" checked={expandDealers} onChange={() => setExpandDealers(!expandDealers)}
              className="w-3.5 h-3.5 rounded border-gray-300 text-[#2c3e50] focus:ring-[#2c3e50]" />
            <span className="text-xs text-gray-700">Show Dealers ({visibleDealers.length})</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input type="checkbox" checked={expandMarketAreas} onChange={() => setExpandMarketAreas(!expandMarketAreas)}
              className="w-3.5 h-3.5 rounded border-gray-300 text-[#2c3e50] focus:ring-[#2c3e50]" />
            <span className="text-xs text-gray-700">Show Market Areas ({visibleMarketAreas.length})</span>
          </label>
        </div>

        {/* TABLE - FIXED HEIGHT WITH SCROLL */}
        <div className="w-full border border-Dustyblue overflow-x-auto">
  <div
    ref={tableContainerRef}
    className="overflow-y-auto scrollbar-hide"
    style={{ maxHeight: "calc(100vh - 320px)", minHeight: "200px" }}
    onScroll={handleScroll}
  >
<table className="min-w-[1200px] w-full text-[10px] border-collapse table-auto">
                <thead className="sticky top-0 bg-Dustyblue text-white z-10">
                <tr>
<th
  className="border border-grey2  border-r-0 border-t-0 border-l-0 border-b-0 px-2 py-1.5 text-left font-semibold cursor-pointer"
  onClick={() => handleSort("equipmentType")}
>
  <div className="flex items-center gap-1">
    Equipment Type
    {sortKey === "equipmentType" ? (
      sortOrder === "asc" ? <ChevronUp className="w-3 h-3 text-white"/> : <ChevronDown className="w-3 h-3 text-white"/>
    ) : (
      <ChevronsUpDown className="w-3 h-3 text-white"/>
    )}
  </div>
  </th>
<th
  className="border border-grey2 border-t-0 border-b-0  px-2 py-1.5 text-left font-semibold cursor-pointer"
  onClick={() => handleSort("model")}
>
  <div className="flex items-center gap-1">
    Model
    {sortKey === "model" && (
      sortOrder === "asc" ? <ChevronUp className="w-3 h-3 text-white"/> : <ChevronDown className="w-3 h-3 text-white"/>
    )  }
  </div>
</th>                {expandDealers && visibleDealers.map((dealer) => (
  <th
    key={dealer}
    className="px-2 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 text-center font-semibold text-[10px] bg-blue-700 whitespace-nowrap cursor-pointer select-none"
    onClick={() => handleSort(`dealer-${dealer}`)}
  >
    <div className="flex items-center justify-center gap-1">
      {dealer}
      {sortKey === `dealer-${dealer}` && (
        sortOrder === "asc" ? (
          <ChevronUp className="w-3 h-3 text-white" />
        ) : (
          <ChevronDown className="w-3 h-3 text-white" />
        )
      ) }
    </div>
  </th>
))}

             {expandMarketAreas && visibleMarketAreas.map((area) => (
  <th
    key={area}
    className="px-2 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 text-center font-semibold text-[10px] whitespace-nowrap cursor-pointer select-none"
    onClick={() => handleSort(`area-${area}`)}
  >
    <div className="flex items-center justify-center gap-1">
    {area}
    {sortKey === `area-${area}` && (
      sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3 text-white" />
      ) : (
        <ChevronDown className="w-3 h-3 text-white" />
      )
    )}
  </div>
  </th>
))}

<th
  className="border border-grey2 border-t-0 border-l-0 border-b-0 px-2 py-1.5 text-center font-semibold text-[10px] whitespace-nowrap cursor-pointer select-none"
  onClick={() => handleSort("inExp")}
>
  <div className="flex items-center justify-center gap-1">
    <span>In-Exp</span>
    <span className="flex-shrink-0 w-3 h-3">
      {sortKey === "inExp" ? (
        sortOrder === "asc" ? (
          <ChevronUp className="w-3 h-3 text-white" />
        ) : (
          <ChevronDown className="w-3 h-3 text-white" />
        )
      ) : null}
    </span>
  </div>
</th>

<th
  className="px-2 py-1.5 text-center font-semibold text-[10px] whitespace-nowrap cursor-pointer select-none"
  onClick={() => handleSort("total")}
>
  <div className="flex items-center justify-center gap-1">
    <span>Total</span>
    <span className="flex-shrink-0 w-3 h-3">
      {sortKey === "total" ? (
        sortOrder === "asc" ? (
          <ChevronUp className="w-3 h-3 text-white" />
        ) : (
          <ChevronDown className="w-3 h-3 text-white" />
        )
      ) : null}
    </span>
  </div>
</th>
           </tr>
              </thead>
              <tbody>
                {loading && sortedData.length === 0 ? (
                  <tr>
                    <td colSpan={getTableColspan()} className="border-t border-gray-300 px-2 py-8 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#2c3e50]"></div>
                        <p className="text-gray-500 text-xs">Loading data from API...</p>
                      </div>
                    </td>
                  </tr>
                ) : sortedData.length > 0 ? (
                  <>
                    {sortedData.map((row, index) => (
                      <tr key={index} className="hover:bg-blue-50 transition-colors">
                        <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-left whitespace-nowrap font-medium text-gray-700">{row.equipmentType}</td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-left whitespace-nowrap text-black">{row.model}</td>
                        {expandDealers && visibleDealers.map((dealer) => (
                          <td key={`dealer-${dealer}`} className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-center bg-blue-50 font-medium whitespace-nowrap">
                            {row.dealerAllocation?.[dealer] || 0}
                          </td>
                        ))}
                        {expandMarketAreas && visibleMarketAreas.map((area) => (
                          <td key={`area-${area}`} className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-center text-black whitespace-nowrap">
                            {row[area.toLowerCase()] || 0}
                          </td>
                        ))}
                        <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-center text-black whitespace-nowrap">{row.inExp || 0}</td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-center font-bold text-blue-900 bg-blue-50 whitespace-nowrap">{calculateTotal(row)}</td>
                      </tr>
                    ))}
                    {isLoadingMore && (
                      <tr>
                        <td colSpan={getTableColspan()} className="border-t border-gray-300 px-2 py-3 text-center">
                          <div className="flex items-center justify-center gap-2 text-gray-500">
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-[#2c3e50]"></div>
                            <span className="text-xs">Loading more...</span>
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                ) : (
                  <tr>
                    <td colSpan={getTableColspan()} className="border-t border-gray-300 px-2 py-6 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <svg className="w-10 h-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                        </svg>
                        <p className="text-gray-500 text-xs">No data found</p>
                        {isApiTab && !loading && (
                          <button onClick={handleRefresh} className="text-xs text-blue-600 hover:text-blue-800 underline">Try refreshing</button>
                        )}
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            
          </div>
        </div>

        {displayData.length > 0 && (
          <div className="flex justify-between items-center text-xs text-gray-500 px-2 py-1.5 border-t border-gray-200">
            <span>Showing {displayData.length} of {filteredData.length} records</span>
            {isApiTab && (
              <span className="text-green flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-green"></div>
                {activeTab === "monthlyProjection" ? "Projections API" : activeTab === "finalProjection" ? "Actuals API" : "Allocations API"}
              </span>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="w-full space-y-2">
      <div className="">
        <div className="px-3 py-2">
          <h1 className="text-lg font-semibold text-darkblue1 text-center">Allocation Management System</h1>
        </div>
      </div>

      <div className="bg-white border border-black/30 overflow-hidden">
  <div className="grid grid-cols-4 sm:flex [&>button:not(:last-child)]:border-r [&>button:not(:last-child)]:border-black/30">          <button onClick={() => setActiveTab("monthlyProjection")}
            className={`px-2 py-2 text-[10px] sm:text-xs font-semibold transition-all  ${activeTab === "monthlyProjection" ? "bg-DustyBlue1 text-white border-[#1a252f]" : "bg-gray-50 text-gray-600 border-transparent hover:bg-gray-100"} flex-1`}>
            <div className="flex flex-row items-center justify-center gap-1.5">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
              <span>Monthly Projection</span>
            </div>
          </button>
          <button onClick={() => setActiveTab("allocation")}
            className={`px-2 py-2 text-[10px] sm:text-xs font-semibold transition-all  ${activeTab === "allocation" ? "bg-DustyBlue1 text-white border-[#1a252f]" : "bg-gray-50 text-gray-600 border-transparent hover:bg-gray-100"} flex-1`}>
            <div className="flex flex-row items-center justify-center gap-1.5">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
              </svg>
              <span>Allocation</span>
            </div>
          </button>
          <button onClick={() => setActiveTab("finalProjection")}
            className={`px-2 py-2 text-[10px] sm:text-xs font-semibold transition-all  ${activeTab === "finalProjection" ? "bg-DustyBlue1 text-white border-[#1a252f]" : "bg-gray-50 text-gray-600 border-transparent hover:bg-gray-100"} flex-1`}>
            <div className="flex flex-row items-center justify-center gap-1.5">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>Final Projection</span>
            </div>
          </button>
          <button onClick={() => setActiveTab("inventory")}
            className={`px-2 py-2 text-[10px] sm:text-xs font-semibold transition-all ${activeTab === "inventory" ? "bg-DustyBlue1 text-white border-[#1a252f]" : "bg-gray-50 text-gray-600 border-transparent hover:bg-gray-100"} flex-1`}>
            <div className="flex flex-row items-center justify-center gap-1.5">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
              </svg>
              <span>Inventory</span>
            </div>
          </button>
        </div>
      </div>

      <div>
        {activeTab === "monthlyProjection" && <TableView projectionType="Monthly" title="Monthly Projection" />}
        {activeTab === "allocation" && <TableView projectionType="Monthly" title="Allocation" />}
        {activeTab === "finalProjection" && <TableView projectionType="Final" title="Final Projection" />}
        {activeTab === "inventory" && <Inventory />}
      </div>
    </div>
  );
};

export default AllocationManagementSystem;