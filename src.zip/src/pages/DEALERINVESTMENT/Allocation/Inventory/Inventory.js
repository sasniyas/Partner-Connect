import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import DeleteModal from "../../../../Components/DeleteModal";
import Filter from "../../../../Components/Filter";
import Searchinput from "../../../../Components/Searchinput";
import { useMemo } from "react";
import { ChevronUp,ChevronDown,ChevronsUpDown,ArrowUp,ArrowDown} from "lucide-react";
import { Eye } from "lucide-react";
import {
  getAllInventoryAllocations,
  addInventoryAllocation,
  deleteInventoryAllocation,
} from "../../../../services/dealerInvestment/inventoryAllocation.service";
import { useKeyboardNavigation } from "../../../../util/useKeyboardNavigation";

const Inventory = () => {
  // ============================================
  // STATE MANAGEMENT
  // ============================================
  const [showPopup, setShowPopup] = useState(false);
  const [year, setYear] = useState("");
  const [error, setError] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [rowToDelete, setRowToDelete] = useState(null);
  const [inventoryList, setInventoryList] = useState([]);
  const [filterYear, setFilterYear] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const navigate = useNavigate();
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};


  const tableContainerRef = useRef()
  // ============================================
  // FETCH INVENTORY LIST ON MOUNT
  // ============================================
  useEffect(() => {
    fetchInventoryList();
  }, []);

  /**
   * Fetch all inventory allocations from API
   */
  const fetchInventoryList = async () => {
    setIsLoading(true);
    try {
      const response = await getAllInventoryAllocations();
      if (response.status && response.data) {
        // Sort by year descending (newest first)
        const sortedData = response.data.sort(
          (a, b) => Number(b.inventory_year) - Number(a.inventory_year)
        );
        setInventoryList(sortedData);
      } else {
        setInventoryList([]);
      }
    } catch (error) {
      console.error("Error fetching inventory list:", error);
      toast.error(error.message || "Failed to fetch inventory list");
      setInventoryList([]);
    } finally {
      setIsLoading(false);
    }
  };
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


  // ============================================
  // FILTER INVENTORY LIST
  // ============================================

  /**
   * Filter inventory list based on search term and year filter
   */
  const filteredInventory = inventoryList.filter((item) => {
    const matchesSearch = item.inventory_year
      .toString()
      .includes(searchTerm.trim());
    const matchesDropdown =
      filterYear.length > 0
        ? filterYear.includes(item.inventory_year.toString())
        : true;
    return matchesSearch && matchesDropdown;
  });
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredInventory;

  return [...filteredInventory].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [filteredInventory, sortKey, sortOrder]);
  /**
   * Get unique years for filter dropdown
   */
  const getYearOptions = () => {
    const years = [
      ...new Set(inventoryList.map((item) => item.inventory_year.toString())),
    ];
    return years.sort((a, b) => Number(b) - Number(a));
  };

  // ============================================
  // CREATE INVENTORY
  // ============================================

  /**
   * Handle save button click - Create new inventory
   */
  const handleSave = async () => {
    // Validation - Check if year is provided
    if (!year) {
      setError("Please fill this field");
      return;
    }

    // Validation - Check if year is 4 digits
    if (!/^\d{4}$/.test(year)) {
      setError("Year must be a 4-digit number");
      return;
    }

    // Validation - Check year range (reasonable range)
    const yearNum = parseInt(year, 10);
    if (yearNum < 2000 || yearNum > 2100) {
      setError("Please enter a valid year (2000-2100)");
      return;
    }

    // Validation - Check for duplicate year
    const isDuplicate = inventoryList.some(
      (item) => item.inventory_year.toString() === year
    );
    if (isDuplicate) {
      setError("Inventory for this year already exists");
      return;
    }

    setIsSaving(true);
    try {
      const response = await addInventoryAllocation({
        inventory_year: parseInt(year, 10),
      });

      if (response.status) {
        toast.success("Inventory created successfully");
        resetForm();
        setShowPopup(false);
        // Refresh the list
        await fetchInventoryList();
      } else {
        toast.error(response.message || "Failed to create inventory");
      }
    } catch (error) {
      console.error("Error creating inventory:", error);
      toast.error(error.message || "Failed to create inventory");
    } finally {
      setIsSaving(false);
    }
  };

  // ============================================
  // DELETE INVENTORY
  // ============================================

  /**
   * Handle delete confirmation - Delete inventory
   */
  const handleDelete = async () => {
    if (!rowToDelete) return;

    setIsDeleting(true);
    try {
      const response = await deleteInventoryAllocation(rowToDelete.id);

      if (response.status) {
        toast.success("Inventory deleted successfully");
        setShowDeleteModal(false);
        setRowToDelete(null);
        // Refresh the list
        await fetchInventoryList();
      } else {
        toast.error(response.message || "Failed to delete inventory");
      }
    } catch (error) {
      console.error("Error deleting inventory:", error);
      toast.error(error.message || "Failed to delete inventory");
    } finally {
      setIsDeleting(false);
    }
  };

  // ============================================
  // UTILITY FUNCTIONS
  // ============================================

  /**
   * Reset form fields
   */
  const resetForm = () => {
    setYear("");
    setError("");
  };
  const containerRef = useRef(null);
useKeyboardNavigation({
  containerRef,
  onSubmit: handleSave,
  onCancel: () => {
    resetForm();
    setShowPopup(false);
  },
});
  /**
   * Format date for display
   * @param {string} dateString - Date string from API
   * @returns {string} - Formatted date string (e.g., "07 Jan 2026")
   */
  const formatDate = (dateString) => {
    if (!dateString) return "-";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  // ============================================
  // RENDER
  // ============================================
  return (
    <div className="w-full">
      {/* Header Section */}
      <div className="flex justify-between items-center mb-3">
        {/* Left Side: Search + Filter */}
        <div className="flex items-center gap-4">
          {/* Search Input */}
          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search Year"
            className="w-1/2"
            iconColor="text-black"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            inputWidth="w-full"
            focusRing="focus:ring-1 focus:ring-black/60"
            hoverInputClasses="hover:bg-white hover:border-black/60"
          />

          {/* Year Dropdown Filter */}
          <Filter
            name="Year Filter"
            value={filterYear}
            options={getYearOptions()}
            onChange={(name, newValue) => setFilterYear(newValue)}
            placeholder="Year"
            customWidth="w-[120px]"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
          />
        </div>

        {/* Right Side: Create Button */}
        <button
          onClick={() => setShowPopup(true)}
          className="bg-darkblue1 text-white px-4 py-1.5 text-xs font-medium 
                     hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 
                     transition rounded"
        >
          + Create Inventory
        </button>
      </div>

      {/* Inventory Table */}
      <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
          <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
              maxHeight:  filteredInventory.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >
            <table className="w-full text-xs whitespace-nowrap table-fixed min-w-[500px] lg:min-w-full">
            <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
<tr>

<th
  className="border border-grey2 border-t-0 border-l-0 border-b-0 font-normal px-2 py-1.5 text-left w-[25%] cursor-pointer select-none"
  onClick={() => handleSort("inventory_year")}
>
  <div className="flex items-center gap-1">
    Inventory Year
    {sortKey !== "inventory_year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}


    {sortKey === "inventory_year" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3 text-white" />
    )}
    {sortKey === "inventory_year" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3 text-white" />
    )}
  </div>
</th>

<th
  className="border border-grey2 border-t-0 border-l-0 border-b-0 px-2 py-1.5 font-normal text-left w-[30%] cursor-pointer select-none"
  onClick={() => handleSort("created_by_name")}
>
  <div className="flex items-center gap-1">
    Created By
    {sortKey === "created_by_name" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3 text-white" />
    )}
    {sortKey === "created_by_name" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3 text-white" />
    )}
  </div>
</th>

<th
  className="border border-grey2 border-t-0 border-l-0 border-b-0 px-2 py-1.5 font-normal text-left w-[25%] cursor-pointer select-none"
  onClick={() => handleSort("created_at")}
>
  <div className="flex items-center gap-1">
    Created At
    {sortKey === "created_at" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3 text-white" />
    )}
    {sortKey === "created_at" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3 text-white" />
    )}
  </div>
</th>

<th className="border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 px-2 py-1.5 font-normal text-center w-[20%]">
  Action
</th>

</tr>
</thead>

            {/* Table Body */}
            <tbody>
              {isLoading ? (
                // Loading State
                <tr>
                  <td
                    colSpan={4}
                    className="border border-grey2 border-t-0 border-l-0 px-2 py-8 text-center"
                  >
                    <div className="flex items-center justify-center gap-2">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-darkblue1"></div>
                      <span className="text-black/60">Loading...</span>
                    </div>
                  </td>
                </tr>
              ) : sortedData.length > 0 ? (
                // Data Rows
                sortedData.map((item) => (
                  <tr key={item.id} className="hover:bg-lightBlue/20 transition">
                    {/* Inventory Year */}
                    <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 font-medium">
                      {item.inventory_year}
                    </td>

                    {/* Created By */}
                    <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1">
                      {item.created_by_name || "-"}
                    </td>

                    {/* Created At */}
                    <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1">
                      {formatDate(item.created_at)}
                    </td>

                    {/* Actions */}
                    <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-2 py-1 text-center">
                      <div className="flex items-center justify-center gap-2">
                        {/* View Button */}
                        <div className="relative group">
                          <button
                            onClick={() =>
                              navigate("/viewinventory", {
                                state: {
                                  inventoryId: item.id,
                                  year: item.inventory_year,
                                  fromTab: "inventory",
                                },
                              })
                            }
                            className="w-6 h-6 border border-black/60 hover:bg-lightBlue/50 flex items-center justify-center transition"
                          >
                            <Eye className="w-4 h-4 text-black/70" />
                          </button>
                          <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50">
                            View
                          </span>
                        </div>

                        {/* Delete Button */}
                        <div className="relative group">
                          <button
                            onClick={() => {
                              setRowToDelete(item);
                              setShowDeleteModal(true);
                            }}
                            className="w-6 h-6 border border-black/60 hover:bg-red-100 flex items-center justify-center transition"
                          >
                           <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>

                          </button>
                          <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50">
                            Delete
                          </span>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                // Empty State
                <tr>
                  <td
                    colSpan={4}
                    className="border border-grey2 border-t-0 border-l-0 px-2 py-4 text-center text-black/60 italic"
                  >
                    No Data Found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
         {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}



      </div>

      {/* Record Count */}
      {!isLoading && inventoryList.length > 0 && (
        <div className="mt-2 text-xs text-gray-500">
          Showing {filteredInventory.length} of {inventoryList.length} record(s)
        </div>
      )}

      {/* Create Inventory Popup Modal */}
      {showPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div 
           ref={containerRef}
          className="bg-white p-6 shadow-lg w-[90%] max-w-md relative">
            {/* Close Button */}
            <button
              onClick={() => {
                resetForm();
                setShowPopup(false);
              }}
              className="absolute right-3 top-3 text-gray-600 hover:text-gray-800"
              disabled={isSaving}
            >
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
                alt="close"
                className="w-4 h-4"
              />
            </button>

            {/* Modal Title */}
            <h2 className="text-sm font-semibold text-MediumGrey mb-4 text-center">
              Create Inventory
            </h2>

            {/* Year Input Field */}
            <div className="mb-4">
              <label className="text-xs font-medium text-black/60 block mb-1">
                Inventory Year <span className="text-red1">*</span>
              </label>

              <input
                type="text"
                maxLength={4}
                value={year}
                onChange={(e) => {
                  const val = e.target.value;
                  // Only allow numeric input
                  if (/^\d*$/.test(val)) {
                    setYear(val);
                  }
                  setError("");
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleSave();
                  }
                }}
                className={`w-full border px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-darkblue1 transition
                  ${error ? "border-red1" : "border-black/30"}`}
                placeholder="Enter year (e.g., 2025)"
                disabled={isSaving}
                autoFocus
              />

              {/* Error Message */}
              {error && (
                <p className="text-red1 text-xs mt-1 flex items-center gap-1">
                  
                  {error}
                </p>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex justify-center gap-3">
              {/* Cancel Button */}
              {/* <button
                onClick={() => {
                  resetForm();
                  setShowPopup(false);
                }}
                className="px-6 py-1.5 text-xs font-medium border border-gray-300 text-gray-700 
                           hover:bg-gray-100 transition"
                disabled={isSaving}
              >
                Cancel
              </button> */}

              {/* Create Button */}
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="px-8 py-1.5 text-xs font-medium bg-darkblue1 text-white 
                           hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1
                           disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition"
              >
                {isSaving ? (
                  <>
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  Saving...
                  </>
                ) : (
                  "Save"
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <DeleteModal
        isOpen={showDeleteModal}
        onClose={() => {
          setShowDeleteModal(false);
          setRowToDelete(null);
        }}
        onConfirm={handleDelete}
      />
    </div>
  );
};

export default Inventory;