import React, { useState, useEffect, useCallback, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { ArrowLeft } from "lucide-react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import SingleSelectFilter from "../../../../Components/SingleSelelctFilter";
import { ArrowUp,ArrowDown } from "lucide-react";
import { useMemo } from "react";
import {
  getInventoryDataAllocationsByInventoryId,
  updateMultipleInventoryDataAllocations,
} from "../../../../services/dealerInvestment/inventoryAllocation.service";
import { ChevronDown,ChevronUp,ChevronsUpDown } from "lucide-react";
const ViewInventory = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const tableContainerRef= useRef()
  // Get data from navigation state
  const { inventoryId, year } = location.state || {};
  const fromTab = location.state?.fromTab || "inventory";

  // Month names array
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  // ============================================
  // STATE MANAGEMENT
  // ============================================
  const [inventoryData, setInventoryData] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [modifiedRows, setModifiedRows] = useState(new Set());
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  // Filter States
  const [selectedMonthDropdown, setSelectedMonthDropdown] = useState("");
  const [currentMonth, setCurrentMonth] = useState(() => {
    const today = new Date();
    return monthNames[today.getMonth()];
  });
  const [filterType, setFilterType] = useState("");
  const [filterMake, setFilterMake] = useState("");
  const [filterModel, setFilterModel] = useState("");
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return tableData;

  return [...tableData].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [tableData, sortKey, sortOrder]);
 // ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  // ============================================
  // HELPER FUNCTIONS
  // ============================================

  /**
   * Get month field names for a specific month
   * @param {string} month - Month name (e.g., "January")
   * @returns {Object} - { openStock: string, arrivals: string, closingStock: string }
   */
  const getMonthFieldNames = (month) => {
    const monthLower = month.toLowerCase();
    return {
      openStock: `${monthLower}_open_stock`,
      arrivals: `${monthLower}_arrivals`,
      closingStock: `${monthLower}_closing_stock`,
    };
  };

  // ============================================
  // FETCH INVENTORY DATA ON MOUNT
  // ============================================
  useEffect(() => {
    if (inventoryId) {
      fetchInventoryData();
    } else {
      toast.error("Invalid inventory ID");
      navigate(-1);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inventoryId]);

  /**
   * Fetch inventory data from API
   */
  const fetchInventoryData = async () => {
    setIsLoading(true);
    try {
      const response = await getInventoryDataAllocationsByInventoryId(inventoryId);
      if (response.status && response.data) {
        setInventoryData(response.data);
      } else {
        setInventoryData([]);
        toast.warning("No inventory data found");
      }
    } catch (error) {
      console.error("Error fetching inventory data:", error);
      toast.error(error.message || "Failed to fetch inventory data");
      setInventoryData([]);
    } finally {
      setIsLoading(false);
    }
  };

  // ============================================
  // FILTER AND PREPARE TABLE DATA
  // ============================================
  useEffect(() => {
    filterAndPrepareData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inventoryData, filterType, filterMake, filterModel, currentMonth]);

  /**
   * Filter inventory data and prepare table data with current month values
   */
  const filterAndPrepareData = useCallback(() => {
    // Apply filters
    let filtered = inventoryData.filter((item) => {
      const typeMatch = !filterType || item.equipment_type?.trim() === filterType;
      const makeMatch = !filterMake || item.equipment_make?.trim() === filterMake;
      const modelMatch = !filterModel || item.equipment_model?.trim() === filterModel;
      return typeMatch && makeMatch && modelMatch;
    });

    // Get month field names for current month
    const { openStock: openStockField, arrivals: arrivalsField, closingStock: closingStockField } = getMonthFieldNames(currentMonth);

    // Prepare table data with current month values
    const prepared = filtered.map((item) => {
      const openStockValue = parseInt(item[openStockField], 10) || 0;
      const arrivalsValue = parseInt(item[arrivalsField], 10) || 0;
      // Get closing stock from API (already calculated with allocation deduction on backend)
      const closingStockValue = parseInt(item[closingStockField], 10) || 0;

      return {
        id: item.id,
        inventory_id: item.inventory_id,
        equipment_id: item.equipment_id,
        equipment_type: item.equipment_type?.trim() || "-",
        equipment_make: item.equipment_make?.trim() || "-",
        equipment_model: item.equipment_model?.trim() || "-",
        equipment_line: item.equipment_line?.trim() || "-",
        openStock: openStockValue,
        arrivals: arrivalsValue,
        // Use API closing stock (calculated with allocation deduction on backend)
        closeStock: closingStockValue,
        // Store original values for tracking changes
        originalOpenStock: openStockValue,
        originalArrivals: arrivalsValue,
        originalCloseStock: closingStockValue,
        // Store field names for API update
        openStockField,
        arrivalsField,
        closingStockField,
      };
    });

    setTableData(prepared);
    setModifiedRows(new Set()); // Reset modified rows when data changes
  }, [inventoryData, filterType, filterMake, filterModel, currentMonth]);

  // ============================================
  // GET UNIQUE FILTER OPTIONS
  // ============================================

  /**
   * Get unique equipment types for filter dropdown
   */
  const getUniqueTypes = () => {
    const types = [
      ...new Set(
        inventoryData.map((item) => item.equipment_type?.trim()).filter(Boolean)
      ),
    ];
    return types.sort();
  };

  /**
   * Get unique equipment makes based on selected type
   */
  const getUniqueMakes = () => {
    let filtered = inventoryData;
    if (filterType) {
      filtered = filtered.filter((item) => item.equipment_type?.trim() === filterType);
    }
    const makes = [
      ...new Set(filtered.map((item) => item.equipment_make?.trim()).filter(Boolean)),
    ];
    return makes.sort();
  };

  /**
   * Get unique equipment models based on selected type and make
   */
  const getUniqueModels = () => {
    let filtered = inventoryData;
    if (filterType) {
      filtered = filtered.filter((item) => item.equipment_type?.trim() === filterType);
    }
    if (filterMake) {
      filtered = filtered.filter((item) => item.equipment_make?.trim() === filterMake);
    }
    const models = [
      ...new Set(filtered.map((item) => item.equipment_model?.trim()).filter(Boolean)),
    ];
    return models.sort();
  };

  // ============================================
  // HANDLE INPUT CHANGES
  // ============================================

  /**
   * Handle input change for open stock and arrivals
   * @param {number} index - Row index in tableData
   * @param {string} field - Field name ("openStock" or "arrivals")
   * @param {string} value - Input value
   */
  const handleInputChange = (index, field, value) => {
    const newData = [...tableData];

    // Clean the value - remove non-numeric characters and leading zeros
    let cleanValue = value.replace(/[^0-9]/g, "");
    cleanValue = cleanValue.replace(/^0+/, "") || "0";
    const numValue = parseInt(cleanValue, 10) || 0;

    // Update the appropriate field
    if (field === "openStock") {
      newData[index].openStock = numValue;
    } else if (field === "arrivals") {
      newData[index].arrivals = numValue;
    }

    // Track modified rows by comparing with original values
    const isModified =
      newData[index].openStock !== newData[index].originalOpenStock ||
      newData[index].arrivals !== newData[index].originalArrivals;

    const newModifiedRows = new Set(modifiedRows);
    if (isModified) {
      newModifiedRows.add(newData[index].id);
      // Show preview: openStock + arrivals (backend will subtract allocation on save)
      const previewCloseStock = newData[index].openStock + newData[index].arrivals;
      newData[index].closeStock = previewCloseStock;
    } else {
      newModifiedRows.delete(newData[index].id);
      // Reset to original close stock if no changes
      newData[index].closeStock = newData[index].originalCloseStock;
    }

    setModifiedRows(newModifiedRows);
    setTableData(newData);
  };

  // ============================================
  // HANDLE MONTH CHANGE
  // ============================================

  /**
   * Handle month dropdown change
   * @param {string} name - Dropdown name
   * @param {string} value - Selected month value
   */
  const handleMonthChange = (name, value) => {
    // Warn user about unsaved changes before switching month
    if (modifiedRows.size > 0) {
      const confirmSwitch = window.confirm(
        "You have unsaved changes. Do you want to discard them and switch month?"
      );
      if (!confirmSwitch) return;
    }

    setSelectedMonthDropdown(value);
    setCurrentMonth(value);
  };

  // ============================================
  // SAVE CHANGES
  // ============================================

  /**
   * Save modified rows to API
   * Backend will automatically calculate closing_stock = open_stock + arrivals - allocation
   */
  const handleSave = async () => {
    if (modifiedRows.size === 0) {
      toast.info("No changes to save");
      return;
    }

    setIsSaving(true);
    try {
      // Prepare only modified rows for update
      // Backend will automatically calculate closing_stock with allocation deduction
      const rowsToUpdate = tableData
        .filter((row) => modifiedRows.has(row.id))
        .map((row) => ({
          id: row.id,
          [row.openStockField]: row.openStock,
          [row.arrivalsField]: row.arrivals,
          // Don't send closing stock - backend calculates it automatically
        }));

      const response = await updateMultipleInventoryDataAllocations(rowsToUpdate);

      if (response.status) {
        toast.success(`${rowsToUpdate.length} row(s) updated successfully`);
        setModifiedRows(new Set());

        // Refresh data from server to get correct closing stock values
        // (calculated with allocation deduction)
        await fetchInventoryData();
      } else {
        toast.error(response.message || "Failed to save changes");
      }
    } catch (error) {
      console.error("Error saving inventory data:", error);
      toast.error(error.message || "Failed to save changes");
    } finally {
      setIsSaving(false);
    }
  };

  // ============================================
  // HANDLE BACK NAVIGATION
  // ============================================

  /**
   * Handle back button click with unsaved changes warning
   */
  const handleBack = () => {
    if (modifiedRows.size > 0) {
      const confirmLeave = window.confirm(
        "You have unsaved changes. Do you want to discard them and leave?"
      );
      if (!confirmLeave) return;
    }
    navigate("/DEALERINVESTMENT/Allocation/Allocationhome", {
      state: { activeTab: fromTab },
    });
  };

  // ============================================
  // CALCULATE TOTALS
  // ============================================
  const totalOpenStock = tableData.reduce((sum, item) => sum + item.openStock, 0);
  const totalArrivals = tableData.reduce((sum, item) => sum + item.arrivals, 0);
  const totalCloseStock = tableData.reduce((sum, item) => sum + item.closeStock, 0);

  // ============================================
  // RENDER
  // ============================================
  return (
    <div className="bg-Frostwhite h-screen overflow-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 flex-1 ${
          menuOpen ? "lg:ml-60" : ""
        } flex justify-center`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-2 flex-wrap gap-4">
            <h2 className="text-base font-medium font-VolvoNovum text-center text-darkblue1 flex items-center justify-center gap-2">
              <ArrowLeft
                onClick={handleBack}
                size={24}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              />
              Dealer Inventory - {year}
            </h2>

            {/* Unsaved Changes Indicator */}
            {modifiedRows.size > 0 && (
              <span className="text-xs text-White font-medium bg-orange px-2 py-1 rounded ">
                ⚠ {modifiedRows.size} unsaved change(s)
              </span>
            )}
          </div>

          {/* Filters Section */}
          <div className="flex justify-between items-center mb-3 flex-wrap gap-2">
            {/* Left Side: Filter Dropdowns */}
            <div className="flex gap-2 flex-wrap">
              {/* Month Filter */}
              <SingleSelectFilter
                name="month"
                value={selectedMonthDropdown}
                options={monthNames}
                placeholder="Month"
                placeholderColor="text-black"
                onChange={handleMonthChange}
                disableSorting={true}
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-gray-100"
                customWidth="w-[120px]"
                dropdownBorderColor="border-black/60"
              />

              {/* Equipment Type Filter */}
              <SingleSelectFilter
                name="type"
                value={filterType}
                options={getUniqueTypes()}
                placeholder="All Types"
                onChange={(name, value) => {
                  setFilterType(value);
                  setFilterMake("");
                  setFilterModel("");
                }}
                placeholderColor="text-black"
                customWidth="w-[180px]"
                buttonBorderColor="border-black/60"
                dropdownBorderColor="border-black/60"
              />

              {/* Equipment Make Filter */}
              <SingleSelectFilter
                name="make"
                value={filterMake}
                options={getUniqueMakes()}
                placeholder="All Makes"
                onChange={(name, value) => {
                  setFilterMake(value);
                  setFilterModel("");
                }}
                placeholderColor="text-black"
                customWidth="w-[120px]"
                buttonBorderColor="border-black/60"
                dropdownBorderColor="border-black/60"
              />

              {/* Equipment Model Filter */}
              <SingleSelectFilter
                name="model"
                value={filterModel}
                options={getUniqueModels()}
                placeholder="All Models"
                onChange={(name, value) => setFilterModel(value)}
                placeholderColor="text-black"
                customWidth="w-[180px]"
                buttonBorderColor="border-black/60"
                dropdownBorderColor="border-black/60"
              />

              {/* Clear Filters Button */}
              {(filterType || filterMake || filterModel) && (
                <button
                  onClick={() => {
                    setFilterType("");
                    setFilterMake("");
                    setFilterModel("");
                  }}
                  className="px-3 py-1 text-xs text-White border border-red hover:bg-red transition"
                >
                  Clear Filters
                </button>
              )}
            </div>

            {/* Right Side: Save Button */}
            <button
              onClick={handleSave}
              disabled={isSaving || modifiedRows.size === 0}
              className={`px-4 py-1 text-xs transition flex items-center gap-2
                ${
                  modifiedRows.size > 0
                    ? "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                    : "bg-gray-300 text-gray-500 cursor-not-allowed"
                }`}
            >
              {isSaving ? (
                <>
                  <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  Saving...
                </>
              ) : (
                `Save ${modifiedRows.size > 0 ? `(${modifiedRows.size})` : ""}`
              )}
            </button>
          </div>

          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
          <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
              maxHeight: sortedData.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
             onScroll={handleTableScroll}
          >
            <table className="w-full text-xs table-fixed min-w-[500px] lg:min-w-full">
           <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
  <tr>
    <th
      rowSpan={2}
      className="border border-grey2 border-t-0 border-b-0 border-l-0 px-2 py-1.5 cursor-pointer select-none font-normal"
      onClick={() => handleSort("equipment_type")}
    >
      <div className="flex items-center gap-1">
        Equipment Type
        {sortKey !== "equipment_type" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}


        {sortKey === "equipment_type" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "equipmentType" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    <th
      rowSpan={2}
      className="border border-grey2 border-t-0 border-b-0 px-2 py-1.5 cursor-pointer select-none font-normal"
      onClick={() => handleSort("equipmentMake")}
    >
      <div className="flex items-center gap-1">
        Equipment Make
        {sortKey === "equipmentMake" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "equipmentMake" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    <th
      rowSpan={2}
      className="border border-grey2 border-t-0 border-b-0 px-2 py-1.5 cursor-pointer select-none font-normal"
      onClick={() => handleSort("equipmentModel")}
    >
      <div className="flex items-center gap-1">
        Equipment Model
        {sortKey === "equipmentModel" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "equipmentModel" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    <th
      colSpan={3}
      className="border border-grey2 border-t-0 border-r-0 px-2 py-1.5 text-center font-normal"
    >
      {currentMonth}
    </th>
  </tr>

  <tr>
    <th
      className="border border-grey2 border-t-0 border-b-0 px-2 py-1.5 text-center w-[12%] cursor-pointer select-none font-normal"
      onClick={() => handleSort("openStock")}
    >
      <div className="flex items-center justify-center gap-1">
        Open Stock
        {sortKey === "openStock" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "openStock" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    <th
      className="border border-grey2 border-t-0 border-b-0 px-2 py-1.5 text-center w-[12%] cursor-pointer select-none font-normal"
      onClick={() => handleSort("arrivals")}
    >
      <div className="flex items-center justify-center gap-1">
        Arrivals
        {sortKey === "arrivals" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "arrivals" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    <th
      className="border border-grey2 border-t-0 border-b-0 border-r-0 px-2 py-1.5 text-center w-[12%] cursor-pointer select-none font-normal"
      onClick={() => handleSort("closeStock")}
    >
      <div className="flex items-center justify-center gap-1">
        Close Stock
        {sortKey === "closeStock" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "closeStock" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>
  </tr>
</thead>

                {/* Table Body */}
                <tbody>
                  {isLoading ? (
                    // Loading State
                    <tr>
                      <td colSpan={6} className="text-center py-8">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-darkblue1"></div>
                          <span className="text-black/60">Loading inventory data...</span>
                        </div>
                      </td>
                    </tr>
                  ) : sortedData.length > 0 ? (
                    // Data Rows
                    sortedData.map((item, index) => {
                      const isModified = modifiedRows.has(item.id);
                      return (
                        <tr
                          key={item.id}
                          className={`hover:bg-lightBlue/20 transition ${
                            isModified ? "bg-yellow" : ""
                          }`}
                        >
                          {/* Equipment Type */}
                          <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1">
                            {item.equipment_type}
                          </td>

                          {/* Equipment Make */}
                          <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1">
                            {item.equipment_make}
                          </td>

                          {/* Equipment Model */}
                          <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1">
                            {item.equipment_model}
                          </td>

                          {/* Open Stock Input */}
                          <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1">
                            <input
                              type="text"
                              inputMode="numeric"
                              pattern="[0-9]*"
                              className={`w-full border px-2 py-0.5 text-xs text-center outline-none focus:ring-1 focus:ring-darkblue1
                                ${isModified ? "border-orange bg-orange" : "border-gray-300"}`}
                              value={item.openStock === 0 ? "" : item.openStock}
                              placeholder="0"
                              onChange={(e) =>
                                handleInputChange(index, "openStock", e.target.value)
                              }
                              onBlur={(e) => {
                                if (e.target.value === "") {
                                  handleInputChange(index, "openStock", "0");
                                }
                              }}
                            />
                          </td>

                          {/* Arrivals Input */}
                          <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1">
                            <input
                              type="text"
                              inputMode="numeric"
                              pattern="[0-9]*"
                              className={`w-full border px-2 py-0.5 text-xs text-center outline-none focus:ring-1 focus:ring-darkblue1
                                ${isModified ? "border-orange bg-orange" : "border-gray-300"}`}
                              value={item.arrivals === 0 ? "" : item.arrivals}
                              placeholder="0"
                              onChange={(e) =>
                                handleInputChange(index, "arrivals", e.target.value)
                              }
                              onBlur={(e) => {
                                if (e.target.value === "") {
                                  handleInputChange(index, "arrivals", "0");
                                }
                              }}
                            />
                          </td>

                          {/* Close Stock (Calculated by Backend - Read Only) */}
                          <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-2 py-1 font-semibold text-center bg-gray-50">
                            <span className={
                              item.closeStock > 0 
                                ? "text-green" 
                                : item.closeStock === 0 
                                  ? "text-orange" 
                                  : "text-red"
                            }>
                              {item.closeStock}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    // Empty State
                    <tr>
                      <td colSpan={6} className="text-center py-4 text-black/60 italic">
                        No equipment found
                      </td>
                    </tr>
                  )}
                </tbody>

                {/* Table Footer with Totals */}
                {!isLoading && tableData.length > 0 && (
                  <tfoot className="bg-gray-100 font-semibold sticky bottom-0">
                    <tr>
                      <td
                        colSpan={3}
                        className="border border-grey2 border-b-0 border-l-0 px-2 py-1.5 text-right"
                      >
                        Total:
                      </td>
                      <td className="border border-grey2 border-b-0 px-2 py-1.5 text-center">
                        {totalOpenStock}
                      </td>
                      <td className="border border-grey2 border-b-0 px-2 py-1.5 text-center">
                        {totalArrivals}
                      </td>
                      <td className="border border-grey2 border-b-0 border-r-0 px-2 py-1.5 text-center bg-blue-50">
                        <span className={
                          totalCloseStock > 0 
                            ? "text-green" 
                            : totalCloseStock === 0 
                              ? "text-orange" 
                              : "text-red"
                        }>
                          {totalCloseStock}
                        </span>
                      </td>
                    </tr>
                  </tfoot>
                )}
                 {showScrollButtons && (
            <div className="fixed bottom-14 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}



              </table>
            </div>
          </div>

          {/* Summary Information */}
          {!isLoading && tableData.length > 0 && (
            <div className="mt-2 flex justify-between items-center text-xs text-gray-600 flex-wrap gap-2">
              <span>
                Showing {tableData.length} of {inventoryData.length} equipment(s)
              </span>
              <span>
                Inventory Year: <strong>{year}</strong> | Month:{" "}
                <strong>{currentMonth}</strong>
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ViewInventory;