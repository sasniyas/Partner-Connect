import React from "react";
import { useState } from "react";
import { useLocation } from "react-router-dom";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import AllocationManagementSystem from "./Viewallocationpage";

const Allocationhome = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  // Get activeTab from navigation state (passed from ViewInventory)
  const initialTab = location.state?.activeTab || "allocation";

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      {/* Fixed Navigation */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      {/* Main Content Area */}
      <div
        className={`
          transition-all duration-300 ease-in-out
          ${menuOpen ? "lg:ml-60" : "lg:ml-0"}
          flex-1
          overflow-y-auto
        `}
      >
        {/* Compact spacing - reduced padding */}
        <div className="w-full pt-16 lg:pt-24 px-2 sm:px-3 lg:px-4 pb-3">
          <AllocationManagementSystem initialActiveTab={initialTab} />
        </div>
      </div>
    </div>
  );
};

export default Allocationhome;