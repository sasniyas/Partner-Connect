import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import StyledSelectField from "../../../Components/StyledSelectField";
import { toast } from "react-toastify";
import { API } from "../../../api";
import {
  addDealerInvestmentVehicle,
  updateDealerInvestmentVehicle,
} from "../../../services/dealerInvestment/dealerInvestmentVehicles.service";
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation";
const AddVehicle = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const location = useLocation();
  const isEditMode = Boolean(id);
  const [menuOpen, setMenuOpen] = useState(false);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  // Get the quarter, investment, and mode from navigation state
  const currentQuarter = location.state?.quarter || "Q1";
  const investment = location.state?.investment || null;
  const currentMode = location.state?.mode || "view";

  // Edit mode data
  const editVehicleData = location.state?.vehicleData || null;

  const [formData, setFormData] = useState({
    category: "",
    vehicleType: "",
    brand: "",
    registrationNumber: "",
    yearOfPurchase: "",
    ageOfVehicle: "",
    assignedToUser: "",
    assignedUserId: "",
    location: "",
    remarks: "",
  });

  // Dropdown states
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const [isVehicleTypeOpen, setIsVehicleTypeOpen] = useState(false);
  const [isUserOpen, setIsUserOpen] = useState(false);
  const formRef = useRef(null)
  // Refs for dropdowns
  const categoryRef = useRef(null);
  const vehicleTypeRef = useRef(null);
  const userRef = useRef(null);

  // Static dropdown options
  const categories = ["Commercial", "Personal"];
  const vehicleTypes = ["2 Wheeler", "4 Wheeler", "N/A"];

  // Users list - fetched from API
  const [users, setUsers] = useState([]);
  const [usersMap, setUsersMap] = useState({}); // Map of name -> id
  const [loadingUsers, setLoadingUsers] = useState(false);

  // Fetch users from API
  useEffect(() => {
    const fetchUsers = async () => {
      setLoadingUsers(true);
      try {
        const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        const response = await fetch(`${API.domain}${API.userManagement.getAllUsers}`, {
          headers: {
            "Content-Type": "application/json",
            ...(token && { Authorization: `Bearer ${token}` }),
          },
        });
        const data = await response.json();
        
        if (data?.status && data?.data) {
          // Transform users data
          const userNames = [];
          const nameToIdMap = {};
          
          data.data.forEach(user => {
            const fullName = `${user.firstName || ''} ${user.middleName || ''} ${user.lastName || ''}`.trim().replace(/\s+/g, ' ');
            userNames.push(fullName);
            nameToIdMap[fullName] = user.id;
          });
          
          setUsers(userNames);
          setUsersMap(nameToIdMap);
        }
      } catch (error) {
        console.error("Error fetching users:", error);
      } finally {
        setLoadingUsers(false);
      }
    };

    fetchUsers();
  }, []);

  // Calculate age automatically when year of purchase changes
  useEffect(() => {
    if (formData.yearOfPurchase) {
      const currentYear = new Date().getFullYear();
      const purchaseYear = parseInt(formData.yearOfPurchase);
      
      if (purchaseYear > 0 && purchaseYear <= currentYear) {
        const age = currentYear - purchaseYear;
        setFormData((prev) => ({ ...prev, ageOfVehicle: age.toString() }));
      } else {
        setFormData((prev) => ({ ...prev, ageOfVehicle: "" }));
      }
    } else {
      setFormData((prev) => ({ ...prev, ageOfVehicle: "" }));
    }
  }, [formData.yearOfPurchase]);

  // Load data if editing
  useEffect(() => {
    if (isEditMode && editVehicleData) {
      setFormData({
        category: editVehicleData.category || "",
        vehicleType: editVehicleData.vehicleType || "",
        brand: editVehicleData.brand || "",
        registrationNumber: editVehicleData.registrationNumber || "",
        yearOfPurchase: editVehicleData.yearOfPurchase || "",
        ageOfVehicle: editVehicleData.ageOfVehicle || "",
        assignedToUser: editVehicleData.assigned || "",
        assignedUserId: editVehicleData.assignedUserId || "",
        location: editVehicleData.location || "",
        remarks: editVehicleData.remarks || "",
      });
    }
  }, [isEditMode, editVehicleData]);

  // Back to VehiclesList with state preserved
  const handleBack = () => {
    navigate("/DEALERINVESTMENT/ViewDealerInvestment/VehiclesList", {
      state: { 
        quarter: currentQuarter,
        investment: investment,
        mode: currentMode
      }
    });
  };

  const handleChange = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
    
    // If user is selected, also store the user ID
    if (name === "assignedToUser" && usersMap[value]) {
      setFormData((prev) => ({ ...prev, assignedToUser: value, assignedUserId: usersMap[value] }));
    }
    
    // Clear error for this field when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    handleChange(name, value);
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.category) {
      newErrors.category = "Vehicle category is required";
    }

    if (!formData.vehicleType) {
      newErrors.vehicleType = "Vehicle type is required";
    }

    if (!formData.brand) {
      newErrors.brand = "Brand is required";
    }

    if (!formData.registrationNumber) {
      newErrors.registrationNumber = "Registration number is required";
    } else if (!/^[A-Z]{2}\d{2}[A-Z]{1,2}\d{4}$/.test(formData.registrationNumber.toUpperCase().replace(/[-\s]/g, ''))) {
      newErrors.registrationNumber = "Invalid format (e.g., KA01AB1234)";
    }

    if (!formData.yearOfPurchase) {
      newErrors.yearOfPurchase = "Year of purchase is required";
    } else {
      const year = parseInt(formData.yearOfPurchase);
      const currentYear = new Date().getFullYear();
      if (year < 1900 || year > currentYear) {
        newErrors.yearOfPurchase = `Year must be between 1900 and ${currentYear}`;
      }
    }

    if (!formData.assignedToUser) {
      newErrors.assignedToUser = "Assigned user is required";
    }

    if (!formData.location) {
      newErrors.location = "Location is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error("Please fill in all required fields correctly");
      return;
    }

    if (!investment?.id) {
      toast.error("Investment ID not found");
      return;
    }

    setSaving(true);

    try {
      // Prepare API data
      const apiData = {
        dealer_investment_id: investment.id,
        assigned_user: formData.assignedUserId || usersMap[formData.assignedToUser] || null,
        quarter: currentQuarter,
        vehicle_category: formData.category,
        vehicle_type: formData.vehicleType,
        brand: formData.brand,
        registration_number: formData.registrationNumber,
        yop: formData.yearOfPurchase ? parseInt(formData.yearOfPurchase) : null,
        location: formData.location || null,
        remarks: formData.remarks || null,
      };

      let response;

      if (isEditMode) {
        // Update existing vehicle
        response = await updateDealerInvestmentVehicle({
          id: parseInt(id),
          ...apiData
        });

        if (response?.status) {
          toast.success("Vehicle updated successfully!");
          navigate("/DEALERINVESTMENT/ViewDealerInvestment/VehiclesList", {
            state: { 
              quarter: currentQuarter,
              investment: investment,
              mode: currentMode,
              refresh: true
            }
          });
        } else {
          toast.error(response?.message || "Failed to update vehicle");
        }
      } else {
        // Add new vehicle
        response = await addDealerInvestmentVehicle(apiData);

        if (response?.status) {
          toast.success("Vehicle added successfully!");
          navigate("/DEALERINVESTMENT/ViewDealerInvestment/VehiclesList", {
            state: { 
              quarter: currentQuarter,
              investment: investment,
              mode: currentMode,
              refresh: true
            }
          });
        } else {
          toast.error(response?.message || "Failed to add vehicle");
        }
      }
    } catch (error) {
      console.error("Error saving vehicle:", error);
      toast.error(error?.response?.data?.message || "Failed to save vehicle");
    } finally {
      setSaving(false);
    }
  };
useKeyboardNavigation({
  containerRef: formRef, // your popup div ref

    onSubmit: () => handleSubmit({ preventDefault: () => {} }), // fake event


  onCancel: () => {
    handleBack(); // closes popup and resets state
  },
});


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      {/* Header */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      {/* SubNavbar */}
      <SubNavbar3 />

      {/* Main Content */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2">
            <div className="flex items-center gap-3">
              <ArrowLeft
                onClick={handleBack}
                size={24}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
              />
              <h1 className="text-base font-semibold text-darkblue1">
                {isEditMode ? "Edit Vehicle" : "Add New Vehicle"} - {currentQuarter}
              </h1>
              {/* <span className="bg-darkblue1 text-white px-2 py-0.5 text-xs rounded-full">
                {currentQuarter}
              </span> */}
            </div>
          </div>

          {/* Form Container */}
          <div className="bg-white shadow-md border border-gray-300 p-4">
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-4">
                {/* Vehicle Category */}
                <div>
                  <StyledSelectField
                    label="Vehicle Category"
                    placeholder="Select Category"
                    value={formData.category}
                    setValue={(val) => handleChange("category", val)}
                    options={categories}
                    dropdownOpen={isCategoryOpen}
                    setDropdownOpen={setIsCategoryOpen}
                    dropdownRef={categoryRef}
                    required
                    error={errors.category}
                  />
                </div>

                {/* Vehicle Type */}
                <div>
                  <StyledSelectField
                    label="Vehicle Type"
                    placeholder="Select Type"
                    value={formData.vehicleType}
                    setValue={(val) => handleChange("vehicleType", val)}
                    options={vehicleTypes}
                    dropdownOpen={isVehicleTypeOpen}
                    setDropdownOpen={setIsVehicleTypeOpen}
                    dropdownRef={vehicleTypeRef}
                    required
                    error={errors.vehicleType}
                  />
                </div>

                {/* Brand */}
                <div className="mt-1">
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Brand <span className="text-red1">*</span>
                  </label>
                  <input
                    type="text"
                    name="brand"
                    value={formData.brand}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-1.5 border focus:outline-none focus:ring-1 text-xs ${
                      errors.brand
                        ? "border-red1 focus:ring-red1"
                        : "border-black/30 focus:ring-black/30"
                    }`}
                    placeholder="Enter brand"
                  />
                  {errors.brand && (
                    <p className="text-red1 text-xs mt-1">{errors.brand}</p>
                  )}
                </div>

                {/* Registration Number */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Registration Number <span className="text-red1">*</span>
                  </label>
                  <input
                    type="text"
                    name="registrationNumber"
                    value={formData.registrationNumber}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-1.5 border focus:outline-none focus:ring-1 text-xs uppercase ${
                      errors.registrationNumber
                        ? "border-red1 focus:ring-red1"
                        : "border-black/30 focus:ring-black/30"
                    }`}
                    placeholder="e.g., KA01AB1234"
                    maxLength="13"
                  />
                  {errors.registrationNumber && (
                    <p className="text-red1 text-xs mt-1">{errors.registrationNumber}</p>
                  )}
                </div>

                {/* Year of Purchase */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Year of Purchase <span className="text-red1">*</span>
                  </label>
                  <input
                    type="number"
                    name="yearOfPurchase"
                    value={formData.yearOfPurchase}
                    onChange={handleInputChange}
                    min="1900"
                    max={new Date().getFullYear()}
                    className={`w-full px-4 py-1.5 border focus:outline-none focus:ring-1 text-xs ${
                      errors.yearOfPurchase
                        ? "border-red1 focus:ring-red1"
                        : "border-black/30 focus:ring-black/30"
                    }`}
                    placeholder="Enter year"
                  />
                  {errors.yearOfPurchase && (
                    <p className="text-red1 text-xs mt-1">{errors.yearOfPurchase}</p>
                  )}
                </div>

                {/* Vehicle Age */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Vehicle Age (Years)
                  </label>
                  <input
                    type="text"
                    name="ageOfVehicle"
                    value={formData.ageOfVehicle}
                    readOnly
                    className="w-full px-4 py-1.5 border border-black/30 bg-gray-100 cursor-not-allowed text-xs"
                    placeholder="Auto calculated"
                  />
                </div>

                {/* Assigned to User */}
                <div className="">
                  <StyledSelectField
                    label="Assigned to User"
                    placeholder={loadingUsers ? "Loading users..." : "Select User"}
                    value={formData.assignedToUser}
                    setValue={(val) => handleChange("assignedToUser", val)}
                    options={users}
                    dropdownOpen={isUserOpen}
                    setDropdownOpen={setIsUserOpen}
                    dropdownRef={userRef}
                    required
                    error={errors.assignedToUser}
                  />
                </div>

                {/* Location */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-2">
                    Location <span className="text-red1">*</span>
                  </label>
                  <input
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-1.5 border focus:outline-none focus:ring-1 text-xs ${
                      errors.location
                        ? "border-red1 focus:ring-red1"
                        : "border-black/30 focus:ring-black/30"
                    }`}
                    placeholder="Enter location"
                  />
                  {errors.location && (
                    <p className="text-red1 text-xs mt-1">{errors.location}</p>
                  )}
                </div>

                {/* Remarks - Full Width */}
                <div className="md:col-span-2 lg:col-span-3">
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Remarks
                  </label>
                  <textarea
                    name="remarks"
                    value={formData.remarks}
                    onChange={handleInputChange}
                    rows="4"
                    className="w-full px-4 py-1.5 border border-black/30 focus:outline-none focus:ring-1 focus:ring-black/30 text-xs resize-none"
                    placeholder="Enter remarks"
                  />
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex flex-wrap gap-4 justify-center lg:justify-end mt-10">
                <button
                  type="button"
                  className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium hover:bg-mildBlue1 hover:scale-105 transition"
                  onClick={handleBack}
                  disabled={saving}
                >
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 18 20" fill="none">
<path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  {saving && (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  )}
                  {saving ? "Saving..." : "Save"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddVehicle;