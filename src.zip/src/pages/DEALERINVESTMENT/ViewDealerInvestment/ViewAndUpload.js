import React, { useState, useRef, useEffect } from "react";
import { toast } from "react-toastify";
import DeleteModal from "../../../Components/DeleteModal";

// Import service functions
import {
  addDealerInvestmentFile,
  getDealerInvestmentFilesByDealerInvestmentId,
  deleteDealerInvestmentFile,
  getCategoryFromSubTab,
  transformFilesToTableData,
  filterFilesByType,
} from "../../../services/dealerInvestment/dealerInvestmentFile.service";

const ViewAndUpload = ({
  isOpen,
  onClose,
  activeType,
  dealerInvestmentId,
  headerTitle,
}) => {
  const [formData, setFormData] = useState({
    file: "",
    fileObject: null,
  });
  const [tableData, setTableData] = useState([]);
  const [allFiles, setAllFiles] = useState([]);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteRowId, setDeleteRowId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  // Fetch files on mount
  useEffect(() => {
    if (isOpen && dealerInvestmentId) {
      fetchFiles();
    }
  }, [isOpen, dealerInvestmentId]);

  // Filter files when activeType changes
  useEffect(() => {
    if (allFiles.length > 0) {
      const filtered = filterFilesByType(allFiles, activeType);
      setTableData(filtered);
    }
  }, [activeType, allFiles]);

  // Fetch files from API
  const fetchFiles = async () => {
    if (!dealerInvestmentId) return;

    setLoading(true);
    try {
      const response = await getDealerInvestmentFilesByDealerInvestmentId(dealerInvestmentId);

      if (response?.status && response?.data) {
        const transformedData = transformFilesToTableData(response.data);
        setAllFiles(transformedData);
        const filtered = filterFilesByType(transformedData, activeType);
        setTableData(filtered);
      } else {
        setAllFiles([]);
        setTableData([]);
      }
    } catch (error) {
      console.error("Error fetching files:", error);
      toast.error("Failed to load files");
      setAllFiles([]);
      setTableData([]);
    } finally {
      setLoading(false);
    }
  };

  // Handle file upload
  const handleSave = async () => {
    if (!formData.fileObject) {
      toast.warning("Please select a file to upload");
      return;
    }

    if (!dealerInvestmentId) {
      toast.error("Dealer Investment ID is required");
      return;
    }

    setUploading(true);
    try {
      const category = getCategoryFromSubTab(activeType);

      const response = await addDealerInvestmentFile(
        dealerInvestmentId,
        formData.fileObject,
        activeType,
        category
      );

      if (response?.status) {
        toast.success("File uploaded successfully!");
        setFormData({ file: "", fileObject: null });

        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }

        await fetchFiles();
      } else {
        toast.error(response?.message || "Failed to upload file");
      }
    } catch (error) {
      console.error("Error uploading file:", error);
      toast.error(error.response?.data?.message || "Failed to upload file");
    } finally {
      setUploading(false);
    }
  };

  // Handle file delete
  const handleConfirmDelete = async () => {
    if (!deleteRowId) return;

    try {
      const response = await deleteDealerInvestmentFile(deleteRowId);

      if (response?.status) {
        toast.success("File deleted successfully!");
        setAllFiles((prev) => prev.filter((item) => item.id !== deleteRowId));
        setTableData((prev) => prev.filter((item) => item.id !== deleteRowId));
      } else {
        toast.error(response?.message || "Failed to delete file");
      }
    } catch (error) {
      console.error("Error deleting file:", error);
      toast.error(error.response?.data?.message || "Failed to delete file");
    } finally {
      setShowDeleteModal(false);
      setDeleteRowId(null);
    }
  };

  // Handle file download
  const handleDownload = (fileUrl) => {
    if (!fileUrl) {
      toast.error("File URL not available");
      return;
    }
    window.open(fileUrl, "_blank");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white shadow-lg rounded-lg w-[50%] max-h-[60%] p-5 relative overflow-hidden flex flex-col">
        {/* Close */}
        <button className="absolute top-3 right-3" onClick={onClose}>
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
            alt="close"
            className="w-4 h-4"
          />
        </button>

        {/* Header with title and category */}
        <div className="flex items-center justify-between mb-4 pr-6">
          <h2 className="text-sm font-semibold text-MediumGrey">
            {headerTitle}
          </h2>
          <span className={`text-xs font-medium px-2 py-0.5 rounded ${
            getCategoryFromSubTab(activeType) === "Infrastructure" 
              ? "bg-blue-100 text-blue-700" 
              : "bg-green-100 text-green-700"
          }`}>
            {getCategoryFromSubTab(activeType)}
          </span>
        </div>

        {/* File Input Row - Click input to open file picker, Save button on right */}
        <div className="flex items-center gap-2 mb-4">
          <div
            onClick={() => fileInputRef.current.click()}
            className="flex-1 flex items-center gap-2 px-2 py-1.5 border border-black/30 bg-white cursor-pointer hover:border-darkblue1 hover:bg-gray-50 transition group"
          >
            {/* Upload Icon */}
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-4 h-4 text-gray-400 group-hover:text-darkblue1 transition"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
              />
            </svg>
            
            <span className={`text-xs ${formData.file ? "text-black" : "text-gray-400"}`}>
              {formData.file || "Click here to select a file"}
            </span>
          </div>

          <button
            onClick={handleSave}
            disabled={!formData.fileObject || uploading}
            className={`px-3 py-1.5 text-xs font-medium transition ${
              formData.fileObject && !uploading
                ? "bg-darkblue1 text-white hover:bg-darkblue1/80"
                : "bg-gray-300 text-gray-500 cursor-not-allowed"
            }`}
          >
            {uploading ? "Saving..." : "Save"}
          </button>
        </div>

        {/* Hidden file input */}
        <input
          type="file"
          ref={fileInputRef}
          accept=".ppt,.pptx,.xls,.xlsx,.pdf,.jpg,.jpeg,.png,.gif,.webp"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files[0];
            if (file) {
              setFormData({ file: file.name, fileObject: file });
            }
          }}
        />

        {/* Table */}
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden flex-1 flex flex-col">
          {loading ? (
            <div className="flex items-center justify-center py-10">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-darkblue1"></div>
              <span className="ml-2 text-xs text-gray-500">Loading files...</span>
            </div>
          ) : (
            <div className="overflow-y-auto flex-1">
              <table className="w-full text-sm whitespace-nowrap cursor-pointer text-xs">
                <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                  <tr>
                    <th className="px-3 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 text-left">
                      File
                    </th>
                    <th className="px-3 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 text-left">
                      Type
                    </th>
                    <th className="px-3 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 text-center">
                      Action
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {tableData.length > 0 ? (
                    tableData.map((row) => (
                      <tr key={row.id}>
                        <td
                          className="border border-grey2 border-t-0 border-l-0 px-3 py-1 truncate max-w-[200px]"
                          title={row.fileName}
                        >
                          {row.fileName}
                        </td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">
                          {row.type}
                        </td>
                        <td className="border border-grey2 border-t-0 border-l-0 border-r-0 py-1 text-center">
                          <div className="flex items-center justify-center gap-2">
                            {/* Download Button */}
                            <button
                              onClick={() => handleDownload(row.fileUrl)}
                              className="text-blue-600 hover:text-blue-800"
                              title="Download"
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="w-4 h-4"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={2}
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                                />
                              </svg>
                            </button>

                            {/* Delete Button */}
                            <button
                              onClick={() => {
                                setDeleteRowId(row.id);
                                setShowDeleteModal(true);
                              }}
                              className="text-red-600 hover:text-red-800"
                              title="Delete"
                            >
                              <img
                                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpmasterHomepage/delete.png"
                                alt="delete"
                                className="w-4 h-4"
                              />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        colSpan="3"
                        className="text-center text-gray-500 py-3 text-xs italic"
                      >
                        No files uploaded
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* File Count */}
        {tableData.length > 0 && (
          <div className="mt-2 text-xs text-gray-500">
            {tableData.length} file{tableData.length !== 1 ? "s" : ""} uploaded for {activeType}
          </div>
        )}
      </div>

      {/* Delete Modal */}
      {showDeleteModal && (
        <DeleteModal
          isOpen={showDeleteModal}
          onClose={() => {
            setShowDeleteModal(false);
            setDeleteRowId(null);
          }}
          onConfirm={handleConfirmDelete}
        />
      )}
    </div>
  );
};

export default ViewAndUpload;