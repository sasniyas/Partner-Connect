import React, { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { ArrowLeft, Plus } from "lucide-react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import DeleteModal from "../../../Components/DeleteModal";
import Filter from "../../../Components/Filter";
import Searchinput from "../../../Components/Searchinput";
import { toast } from "react-toastify";
import { ChevronUp,ChevronDown,ChevronsUpDown ,ArrowUp,ArrowDown} from "lucide-react";
import {
  getDealerInvestmentVehiclesByDealerInvestmentId,
  deleteDealerInvestmentVehicle,
  transformVehiclesListData,
  filterVehiclesByQuarter,
} from "../../../services/dealerInvestment/dealerInvestmentVehicles.service";

const VehiclesList = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [hoveredCell,setHoveredCell] = useState("")
  // Get the quarter, investment, and mode from navigation state
  const currentQuarter = location.state?.quarter || "Q1";
  const investment = location.state?.investment || null;
  const currentMode = location.state?.mode || "view";
  const tableContainerRef= useRef(null)
  // Search and Filter states
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedVehicleTypes, setSelectedVehicleTypes] = useState([]);
  const [selectedBrands, setSelectedBrands] = useState([]);

  // API Data states
  const [allVehiclesData, setAllVehiclesData] = useState([]); // All vehicles from API
  const [vehiclesData, setVehiclesData] = useState([]); // Filtered by quarter
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [error, setError] = useState(null);

  // Lazy loading states
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const observerRef = useRef();

  const itemsPerLoad = 10;
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


  // Fetch vehicles data from API
  const fetchVehiclesData = async () => {
    if (!investment?.id) {
      setError("No dealer investment ID provided");
      setIsLoadingData(false);
      return;
    }

    setIsLoadingData(true);
    setError(null);

    try {
      const response = await getDealerInvestmentVehiclesByDealerInvestmentId(investment.id);

      if (response?.status && response?.data) {
        console.log(response.data)
        const transformedData = transformVehiclesListData(response.data);
        setAllVehiclesData(transformedData);
        
        // Filter by current quarter
        const filteredByQuarter = filterVehiclesByQuarter(transformedData, currentQuarter);
        setVehiclesData(filteredByQuarter);
        
        console.log("Vehicles loaded:", {
          total: transformedData.length,
          forQuarter: filteredByQuarter.length,
          quarter: currentQuarter
        });
      } else {
        setAllVehiclesData([]);
        setVehiclesData([]);
      }
    } catch (err) {
      console.error("Error fetching vehicles:", err);
      setError("Failed to load vehicles data. Please try again.");
    } finally {
      setIsLoadingData(false);
    }
  };

  // Fetch on mount
  useEffect(() => {
    fetchVehiclesData();
  }, [investment?.id, currentQuarter]);

  // Extract unique values for filters
  const categories = useMemo(() => {
    const uniqueCategories = [...new Set(vehiclesData.map(v => v.category))].filter(Boolean);
    return uniqueCategories.sort();
  }, [vehiclesData]);

  const vehicleTypes = useMemo(() => {
    const uniqueTypes = [...new Set(vehiclesData.map(v => v.vehicleType))].filter(Boolean);
    return uniqueTypes.sort();
  }, [vehiclesData]);

  const brands = useMemo(() => {
    const uniqueBrands = [...new Set(vehiclesData.map(v => v.brand))].filter(Boolean);
    return uniqueBrands.sort();
  }, [vehiclesData]);

  // Filter data based on search and filters
  const filteredData = useMemo(() => {
    return vehiclesData.filter(vehicle => {
      const matchesSearch = 
        vehicle.registrationNumber?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        vehicle.assigned?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        vehicle.location?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        vehicle.brand?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(vehicle.category);
      const matchesVehicleType = selectedVehicleTypes.length === 0 || selectedVehicleTypes.includes(vehicle.vehicleType);
      const matchesBrand = selectedBrands.length === 0 || selectedBrands.includes(vehicle.brand);

      return matchesSearch && matchesCategory && matchesVehicleType && matchesBrand;
    });
  }, [vehiclesData, searchQuery, selectedCategories, selectedVehicleTypes, selectedBrands]);

  // Load more items function
  const loadMoreItems = useCallback(() => {
    if (isLoading || !hasMore) return;

    setIsLoading(true);
    
    setTimeout(() => {
      const currentLength = displayedItems.length;
      const nextItems = filteredData.slice(currentLength, currentLength + itemsPerLoad);
      
      if (nextItems.length === 0) {
        setHasMore(false);
      } else {
        setDisplayedItems(prev => [...prev, ...nextItems]);
      }
      
      setIsLoading(false);
    }, 300);
  }, [displayedItems.length, filteredData, isLoading, hasMore, itemsPerLoad]);

  // Intersection Observer callback
  const lastItemRef = useCallback(node => {
    if (isLoading) return;
    if (observerRef.current) observerRef.current.disconnect();
    
    observerRef.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        loadMoreItems();
      }
    });
    
    if (node) observerRef.current.observe(node);
  }, [isLoading, hasMore, loadMoreItems]);

  // Reset displayed items when filters change
  useEffect(() => {
    setDisplayedItems(filteredData.slice(0, itemsPerLoad));
    setHasMore(filteredData.length > itemsPerLoad);
    setIsLoading(false);
  }, [filteredData, itemsPerLoad]);

  // Back to FillEntries page with Vehicles tab active
  const handleBack = () => {
    navigate("/DEALERINVESTMENT/ViewDealerInvestment/FillEntries", {
      state: { 
        activeSubTab: "Vehicles",
        investment: investment,
        mode: currentMode
      }
    });
  };

  const handleAddNew = () => {
    navigate("/DEALERINVESTMENT/ViewDealerInvestment/AddVehicle", {
      state: { 
        quarter: currentQuarter,
        investment: investment,
        mode: currentMode
      }
    });
  };

  const handleEdit = (vehicleId) => {
    const vehicleToEdit = vehiclesData.find(v => v.id === vehicleId);
    navigate(`/DEALERINVESTMENT/ViewDealerInvestment/EditVehicle/${vehicleId}`, {
      state: { 
        vehicleData: vehicleToEdit, 
        quarter: currentQuarter,
        investment: investment,
        mode: currentMode
      }
    });
  };

  const handleDelete = async (vehicleId) => {
    if (!vehicleId) return;

    setDeleteLoading(true);

    try {
      const response = await deleteDealerInvestmentVehicle(vehicleId);

      if (response?.status) {
        toast.success("Vehicle deleted successfully!");
        
        // Remove from local state
        setVehiclesData(prev => prev.filter(v => v.id !== vehicleId));
        setAllVehiclesData(prev => prev.filter(v => v.id !== vehicleId));
        
        setIsDeleteModalOpen(false);
        setSelectedRow(null);
      } else {
        toast.error(response?.message || "Failed to delete vehicle");
      }
    } catch (error) {
      console.error("Error deleting vehicle:", error);
      toast.error("Failed to delete vehicle");
    } finally {
      setDeleteLoading(false);
    }
  };

  // Refresh data when returning from add/edit
  useEffect(() => {
    if (location.state?.refresh) {
      fetchVehiclesData();
      // Clear the refresh flag
      navigate(location.pathname, { 
        replace: true, 
        state: { 
          quarter: currentQuarter,
          investment: investment,
          mode: currentMode
        } 
      });
    }
  }, [location.state?.refresh]);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") setSortOrder("desc");
    else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else setSortOrder("asc");
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return vehiclesData;

  return [...vehiclesData].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    if (!isNaN(valA) && !isNaN(valB)) return sortOrder === "asc" ? valA - valB : valB - valA;

    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [vehiclesData, sortKey, sortOrder]);

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
            <div className="flex items-center gap-3">
              <ArrowLeft
                onClick={handleBack}
                size={24}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
              />
              <h1 className="text-base font-semibold text-darkblue1">
                Newly Added Vehicles List - {currentQuarter}
              </h1>
              <span className="bg-darkblue1 text-white px-2 py-0.5 text-xs rounded-full">
{vehiclesData.length} {vehiclesData.length <= 1 ? "vehicle" : "vehicles"}       
       </span>
            </div>
            <button
              onClick={handleAddNew}
              className="bg-darkblue1 text-white px-4 py-1 font-medium text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition flex items-center justify-center gap-0 w-full sm:w-auto"
            >
              <Plus size={14} />
              Add New
            </button>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col lg:flex-row gap-4 mb-2">
            <div className="">
              <Searchinput
                onChange={(e) => setSearchQuery(e.target.value)}
                value={searchQuery}
                placeholder="Search"
                className="w-[1/2]"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-2"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />
            </div>

            <div className="flex flex-wrap gap-3">
              <Filter
                name="category"
                placeholder="Category"
                options={categories}
                value={selectedCategories}
                onChange={(name, value) => setSelectedCategories(value)}
                customWidth="w-[120px]"
                textColor="text-black"
                placeholderColor="text-black"
                buttonBorderColor="border-black"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black"
              />

              <Filter
                name="vehicleType"
                placeholder="Vehicle Type"
                options={vehicleTypes}
                value={selectedVehicleTypes}
                onChange={(name, value) => setSelectedVehicleTypes(value)}
                customWidth="w-[120px]"
                textColor="text-black"
                placeholderColor="text-black"
                buttonBorderColor="border-black"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black"
              />

              <Filter
                name="brand"
                placeholder="Brand"
                options={brands}
                value={selectedBrands}
                onChange={(name, value) => setSelectedBrands(value)}
                customWidth="w-[120px]"
                textColor="text-black"
                placeholderColor="text-black"
                buttonBorderColor="border-black"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black"
              />
            </div>
          </div>

          {/* Error State */}
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 p-4 rounded mb-4">
              <p>{error}</p>
              <button 
                onClick={fetchVehiclesData}
                className="mt-2 text-sm underline hover:no-underline"
              >
                Try again
              </button>
            </div>
          )}

          {/* Desktop Table */}
           <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
          <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
              maxHeight: filteredData.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
             onScroll={handleTableScroll}
          >
            <table className="w-full text-xs whitespace-nowrap table-fixed ">
             <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
  <tr>
    {/* Category */}
    <th
      className="px-3 py-1.5 font-medium text-left border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%] cursor-pointer select-none"
      onClick={() => handleSort("category")}
    >
      <div className="flex items-center gap-1">
        Category
        {sortKey !== "category" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

        {sortKey === "category" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "category" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* Vehicle Type */}
    <th
      className="px-3 py-1.5 font-medium text-left border border-grey2 border-t-0 border-l-0 border-b-0  w-[10%]  cursor-pointer select-none"
      onClick={() => handleSort("vehicleType")}
    >
      <div className="flex items-center gap-1">
        Vehicle Type
        {sortKey === "vehicleType" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "vehicleType" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* Brand */}
    <th
      className="px-3 py-1.5 font-medium text-left border border-grey2 border-t-0 border-l-0 border-b-0 cursor-pointer  w-[10%]  select-none"
      onClick={() => handleSort("brand")}
    >
      <div className="flex items-center gap-1">
        Brand
        {sortKey === "brand" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "brand" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* Registration Number */}
    <th
      className="px-3 py-1.5 font-medium text-left border border-grey2 border-t-0 border-l-0 border-b-0 cursor-pointer  w-[12%]  select-none"
      onClick={() => handleSort("registrationNumber")}
    >
      <div className="flex items-center gap-1">
        Registration Number
        {sortKey === "registrationNumber" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "registrationNumber" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* Year of Purchase */}
    <th
      className="px-3 py-1.5 font-medium text-left border border-grey2 border-t-0 border-l-0 border-b-0 cursor-pointer  w-[10%]  select-none"
      onClick={() => handleSort("yearOfPurchase")}
    >
      <div className="flex items-center gap-1">
        Year of Purchase
        {sortKey === "yearOfPurchase" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "yearOfPurchase" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* Age of Vehicle */}
    <th
      className="px-3 py-1.5 font-medium  border border-grey2 border-t-0 border-l-0 border-b-0 cursor-pointer  w-[10%]  select-none"
      onClick={() => handleSort("ageOfVehicle")}
    >
      <div className="flex items-center gap-1">
        Age of Vehicle
        {sortKey === "ageOfVehicle" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "ageOfVehicle" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* Assigned */}
    <th
      className="px-3 py-1.5 font-medium text-left border border-grey2 border-t-0 border-l-0 border-b-0 cursor-pointer  w-[10%]  select-none"
      onClick={() => handleSort("assignedToUser")}
    >
      <div className="flex items-center gap-1">
        Assigned
        {sortKey === "assignedToUser" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "assignedToUser" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* Operation Area */}
    <th
      className="px-3 py-1.5 font-medium text-left border border-grey2 border-t-0 border-l-0 border-b-0 cursor-pointer  w-[10%]  select-none"
      onClick={() => handleSort("location")}
    >
      <div className="flex items-center gap-1">
        Operation Area
        {sortKey === "location" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "location" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* Remarks */}
    <th
      className="px-3 py-1.5 font-medium text-left border border-grey2 border-t-0 border-l-0 border-b-0 cursor-pointer  w-[14%]  select-none"
      onClick={() => handleSort("remarks")}
    >
      <div className="flex items-center gap-1">
        Remarks
        {sortKey === "remarks" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "remarks" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* Actions - NO SORT */}
    <th
      className="px-3 py-1.5 font-medium text-center border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0  w-[5%]  select-none"
    >
      Actions
    </th>
  </tr>
</thead>


                <tbody>
                  {isLoadingData && sortedData.length === 0 && (
                    <tr>
                      <td colSpan={10} className="px-6 py-8 text-center text-gray-500">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                          Loading vehicles...
                        </div>
                      </td>
                    </tr>
                  )}
                  
                  {!isLoadingData && sortedData.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="text-center py-8 text-gray-500 italic">
                        No vehicles found for {currentQuarter}. Click "Add New" to add vehicles.
                      </td>
                    </tr>
                  ) : (
                   sortedData.map((vehicle, index) => (
                      <tr 
                        key={vehicle.id}
                        ref={index === displayedItems.length - 1 ? lastItemRef : null}
                        className={`${index % 2 === 0 ? "" : ""} hover:bg-lightBlue/50 text-xs`}
                      >
                         <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">
        <div className="relative">
          <p
            className="truncate max-w-[12rem] cursor-pointer"
            onMouseEnter={() => {
              if (vehicle.category && vehicle.category.length > 18)
                setHoveredCell(vehicle.id + "-category");
            }}
            onMouseLeave={() => setHoveredCell(null)}
          >
            {vehicle.category || "-"}
          </p>
          {hoveredCell === vehicle.id + "-category" && (
            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
              {vehicle.category}
            </span>
          )}
        </div>
      </td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">
        <div className="relative">
          <p
            className="truncate max-w-[12rem] cursor-pointer"
            onMouseEnter={() => {
              if (vehicle.vehicleType && vehicle.vehicleType.length > 18)
                setHoveredCell(vehicle.id + "-vehicleType");
            }}
            onMouseLeave={() => setHoveredCell(null)}
          >
            {vehicle.vehicleType || "-"}
          </p>
          {hoveredCell === vehicle.id + "-vehicleType" && (
            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
              {vehicle.vehicleType}
            </span>
          )}
        </div>
      </td>
                         <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">
        <div className="relative">
          <p
            className="truncate max-w-[12rem] cursor-pointer"
            onMouseEnter={() => {
              if (vehicle.brand && vehicle.brand.length > 18)
                setHoveredCell(vehicle.id + "-brand");
            }}
            onMouseLeave={() => setHoveredCell(null)}
          >
            {vehicle.brand || "-"}
          </p>
          {hoveredCell === vehicle.id + "-brand" && (
            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
              {vehicle.brand}
            </span>
          )}
        </div>
      </td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">
                          {vehicle.registrationNumber || "-"}
                        </td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-3 text-left py-1">
                          {vehicle.yearOfPurchase || "-"}
                        </td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-left">
                          {vehicle.ageOfVehicle || "-"}
                        </td>
                       <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">
        <div className="relative">
          <p
            className="truncate max-w-[12rem] cursor-pointer"
            onMouseEnter={() => {
              if (vehicle.assigned && vehicle.assigned.length > 18)
                setHoveredCell(vehicle.id + "-assigned");
            }}
            onMouseLeave={() => setHoveredCell(null)}
          >
            {vehicle.assigned || "-"}
          </p>
          {hoveredCell === vehicle.id + "-assigned" && (
            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
              {vehicle.assigned}
            </span>
          )}
        </div>
      </td>
 <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">
        <div className="relative">
          <p
            className="truncate max-w-[12rem] cursor-pointer"
            onMouseEnter={() => {
              if (vehicle.location && vehicle.location.length > 18)
                setHoveredCell(vehicle.id + "-location");
            }}
            onMouseLeave={() => setHoveredCell(null)}
          >
            {vehicle.location || "-"}
          </p>
          {hoveredCell === vehicle.id + "-location" && (
            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
              {vehicle.location}
            </span>
          )}
        </div>
      </td>

                     <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">
        <div className="relative">
          <p
            className="truncate max-w-[12rem] cursor-pointer"
            onMouseEnter={() => {
              if (vehicle.remarks && vehicle.remarks.length > 18)
                setHoveredCell(vehicle.id + "-remarks");
            }}
            onMouseLeave={() => setHoveredCell(null)}
          >
            {vehicle.remarks || "-"}
          </p>
          {hoveredCell === vehicle.id + "-remarks" && (
            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
              {vehicle.remarks}
            </span>
          )}
        </div>
      </td>
                        <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <div className="relative group">
                              <button onClick={() => handleEdit(vehicle.id)}>
                               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

                              </button>
                              <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                Edit
                              </span>
                            </div>

                            <div className="relative group">
                              <button
                                onClick={() => {
                                  setSelectedRow(vehicle.id);
                                  setIsDeleteModalOpen(true);
                                }}
                              >
                             <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>
                              </button>
                              <span className="absolute left-1 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                Delete
                              </span>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                  
                  {isLoading && (
                    <tr>
                      <td colSpan={10} className="px-6 py-4 text-center text-gray-500">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                          Loading more...
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

          </div>

          {/* Mobile/Tablet Cards */}
          <div className="lg:hidden space-y-4">
            {isLoadingData && (
              <div className="text-center py-8 text-gray-500">
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                  Loading vehicles...
                </div>
              </div>
            )}

            {!isLoadingData && displayedItems.length === 0 && (
              <div className="text-center py-8 text-gray-500 italic bg-white shadow-md border border-Dustyblue p-4">
                No vehicles found for {currentQuarter}. Click "Add New" to add vehicles.
              </div>
            )}

            {displayedItems.map((vehicle, index) => (
              <div 
                key={vehicle.id} 
                ref={index === displayedItems.length - 1 ? lastItemRef : null}
                className="bg-white shadow-md border-2 border-Dustyblue p-4"
              >
                <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                  <div className="flex flex-col">
                    <span className="font-medium text-gray-600">Category:</span>
                    <span className="text-gray-800">{vehicle.category}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-medium text-gray-600">Vehicle Type:</span>
                    <span className="text-gray-800">{vehicle.vehicleType}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-medium text-gray-600">Brand:</span>
                    <span className="text-gray-800">{vehicle.brand || "-"}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-medium text-gray-600">Registration:</span>
                    <span className="text-gray-800">{vehicle.registrationNumber || "-"}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-medium text-gray-600">Year of Purchase:</span>
                    <span className="text-gray-800">{vehicle.yearOfPurchase || "-"}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-medium text-gray-600">Age:</span>
                    <span className="text-gray-800">{vehicle.ageOfVehicle || "-"}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-medium text-gray-600">Assigned:</span>
                    <span className="text-gray-800">{vehicle.assigned || "-"}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-medium text-gray-600">Location:</span>
                    <span className="text-gray-800">{vehicle.location || "-"}</span>
                  </div>
                  <div className="flex flex-col col-span-2">
                    <span className="font-medium text-gray-600">Remarks:</span>
                    <span className="text-gray-800">{vehicle.remarks || "-"}</span>
                  </div>
                </div>
                <div className="flex gap-2 pt-3 border-t border-gray-200">
                  <button
                    onClick={() => handleEdit(vehicle.id)}
                    className="flex-1 bg-darkblue1 text-white px-4 py-2 rounded-md font-medium text-sm hover:bg-darkblue1/90 transition flex items-center justify-center gap-2"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

                    Edit
                  </button>
                  <button
                    onClick={() => {
                      setSelectedRow(vehicle.id);
                      setIsDeleteModalOpen(true);
                    }}
                    className="hover:scale-110 transition-all flex items-center gap-1"
                  >
                   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>
                    Delete
                  </button>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="px-6 py-4 text-center text-gray-500">
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                  Loading more...
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {isDeleteModalOpen && selectedRow !== null && (
        <DeleteModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            if (!deleteLoading) {
              setIsDeleteModalOpen(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={() => handleDelete(selectedRow)}
          loading={deleteLoading}
          extraMessage="This will delete all the records related to this vehicle."
        />
      )}
    </div>
  );
};

export default VehiclesList;