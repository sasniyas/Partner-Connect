import React, { useState, useEffect, useMemo, useRef } from "react";
import { useSelector } from "react-redux";
import Filter from "../../../Components/Filter";
import Searchinput from "../../../Components/Searchinput";
import SingleSelectFilter from "../../../Components/SingleSelelctFilter";
import { toast } from "react-toastify";
import { ChevronDown,ChevronUp,ChevronsUpDown,ArrowUp,ArrowDown } from "lucide-react";
// Import service functions
import {
  getDealerInvestmentAllocationByDealerInvestmentId,
  getDealerInvestmentEquipmentProjectionByDealerInvestmentId,
  getAllInventoryDataAllocations,
  updateMultipleDealerInvestmentAllocation,
  transformAllocationDataForTable,
  transformProjectionData,
  transformInventoryData,
  mergeAllocationData,
  getUniqueEquipmentMakes,
  getUniqueEquipmentTypes,
  getUniqueEquipmentModels,
  getMonthField,
  getMonthNames,
  getCurrentMonthName,
} from "../../../services/dealerInvestment/dealerInvestmentAllocation.service";

// ═══════════════════════════════════════════════════════════════
// ADMIN ROLES - Only these roles can access Allocation page
// ═══════════════════════════════════════════════════════════════
const ADMIN_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Uptime & Parts Manager",
  "Market Area Head"
];

const Allocation = ({ mode, investment }) => {
  // ⭐ Get current user from Redux
  const user = useSelector((state) => state.user);
  const userRole = user?.data?.persona || user?.persona || user?.role || "";
const tableContainerRef=useState(null)
  // ⭐ Check if current user is admin
  const isAdmin = ADMIN_ROLES.some(
    role => role.toLowerCase() === userRole.toLowerCase()
  );

  // ============================================
  // STATE MANAGEMENT
  // ============================================
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  // Raw API data (stores all months)
  const [allocationData, setAllocationData] = useState([]);
  const [projectionMap, setProjectionMap] = useState({});
  const [inventoryMap, setInventoryMap] = useState({});
  
  // Merged table data for current month
  const [tableData, setTableData] = useState([]);
  
  // Track modified rows with their month field
  const [modifiedRows, setModifiedRows] = useState(new Map());

  // PDP Year for inventory filtering
  const [pdpYear, setPdpYear] = useState(null);

  // Month options
  const monthOptions = getMonthNames();

  // Get current month on initial load
  const initialMonth = useRef(getCurrentMonthName());

  // Filter states - DEFAULT TO CURRENT MONTH
  const [selectedMonth, setSelectedMonth] = useState(initialMonth.current);
  const [selectedValues, setSelectedValues] = useState({
    equipmentMake: [],
    equipmentType: [],
    equipmentModel: [],
  });

  // Current selected month and its field name
  const currentMonthField = getMonthField(selectedMonth);

  // Debug logging
  useEffect(() => {
    console.log("Allocation - User Role:", userRole, "isAdmin:", isAdmin);
  }, [userRole, isAdmin]);

  // ============================================
  // FETCH ALL DATA FROM APIs
  // ============================================
  const fetchAllData = async () => {
    // ⭐ Don't fetch data if user is not admin
    if (!isAdmin) {
      setLoading(false);
      return;
    }

    if (!investment?.id) {
      setError("No dealer investment ID provided");
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // 1. Fetch Allocation Data (Main data source)
      const allocationResponse = await getDealerInvestmentAllocationByDealerInvestmentId(investment.id);
      let transformedAllocation = [];
      let year = investment.year;
      
      if (allocationResponse?.status && allocationResponse?.data) {
        transformedAllocation = transformAllocationDataForTable(allocationResponse.data);
        setAllocationData(transformedAllocation);
        year = allocationResponse.data[0]?.pdp_info?.year || investment.year;
        setPdpYear(year);
        console.log("✅ Allocation data loaded:", transformedAllocation.length, "records, Year:", year);
      }

      // 2. Fetch Projection Data (Retail + KAM for all months)
      let projMap = {};
      try {
        const projectionResponse = await getDealerInvestmentEquipmentProjectionByDealerInvestmentId(investment.id);
        if (projectionResponse?.status && projectionResponse?.data) {
          projMap = transformProjectionData(projectionResponse.data);
          setProjectionMap(projMap);
          console.log("✅ Projection data loaded (Retail + KAM):", Object.keys(projMap).length, "equipment mappings");
        }
      } catch (projErr) {
        console.warn("⚠️ Could not load projection data:", projErr.message);
      }

      // 3. Fetch Inventory Data WITH YEAR FILTER
      let invMap = {};
      try {
        const inventoryResponse = await getAllInventoryDataAllocations(year);
        if (inventoryResponse?.status && inventoryResponse?.data) {
          invMap = transformInventoryData(inventoryResponse.data);
          setInventoryMap(invMap);
          console.log("✅ Inventory data loaded for year", year, ":", Object.keys(invMap).length, "equipment mappings");
        }
      } catch (invErr) {
        console.warn("⚠️ Could not load inventory data:", invErr.message);
      }

      // Initial merge for current month
      if (transformedAllocation.length > 0) {
        const monthField = getMonthField(selectedMonth);
        const merged = mergeAllocationData(
          transformedAllocation,
          projMap,
          invMap,
          monthField,
          selectedMonth
        );
        setTableData(merged);
      }

    } catch (err) {
      console.error("❌ Error fetching allocation data:", err);
      setError("Failed to load allocation data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Fetch on mount (only if admin)
  useEffect(() => {
    if (isAdmin) {
      fetchAllData();
    } else {
      setLoading(false);
    }
  }, [investment?.id, isAdmin]);

  // ============================================
  // MERGE DATA WHEN MONTH CHANGES
  // ============================================
  useEffect(() => {
    if (allocationData.length > 0 && !loading && isAdmin) {
      const monthField = getMonthField(selectedMonth);
      console.log("📅 Month changed to:", selectedMonth, "Field:", monthField);
      
      const merged = mergeAllocationData(
        allocationData,
        projectionMap,
        inventoryMap,
        monthField,
        selectedMonth
      );
      setTableData(merged);
      // Clear modified rows when month changes
      setModifiedRows(new Map());
    }
  }, [selectedMonth]);

  // ============================================
  // FILTER OPTIONS (derived from data)
  // ============================================
  const equipmentMakeOptions = useMemo(() => {
    return getUniqueEquipmentMakes(tableData);
  }, [tableData]);

  const equipmentTypeOptions = useMemo(() => {
    return getUniqueEquipmentTypes(tableData, selectedValues.equipmentMake);
  }, [tableData, selectedValues.equipmentMake]);

  const equipmentModelOptions = useMemo(() => {
    return getUniqueEquipmentModels(
      tableData,
      selectedValues.equipmentMake,
      selectedValues.equipmentType
    );
  }, [tableData, selectedValues.equipmentMake, selectedValues.equipmentType]);

  // ============================================
  // FILTERED DATA
  // ============================================
  const filteredData = useMemo(() => {
    return tableData.filter((row) => {
      const { equipmentMake, equipmentType, equipmentModel } = selectedValues;

      const matchMake =
        equipmentMake.length === 0 || equipmentMake.includes(row.equipmentMake);
      const matchType =
        equipmentType.length === 0 || equipmentType.includes(row.equipmentType);
      const matchModel =
        equipmentModel.length === 0 || equipmentModel.includes(row.equipmentModel);

      const matchSearch =
        searchQuery === "" ||
        row.equipmentMake.toLowerCase().includes(searchQuery.toLowerCase()) ||
        row.equipmentType.toLowerCase().includes(searchQuery.toLowerCase()) ||
        row.equipmentModel.toLowerCase().includes(searchQuery.toLowerCase());

      return matchMake && matchType && matchModel && matchSearch;
    });
  }, [tableData, selectedValues, searchQuery]);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [filteredData, sortKey, sortOrder]);

  // ============================================
  // HANDLE FILTER CHANGE
  // ============================================
  const handleFilterChange = (name, newValue) => {
    if (name === "month") {
      setSelectedMonth(newValue);
    } else {
      setSelectedValues((prev) => {
        const updated = { ...prev, [name]: newValue };
        
        if (name === "equipmentMake") {
          updated.equipmentType = [];
          updated.equipmentModel = [];
        } else if (name === "equipmentType") {
          updated.equipmentModel = [];
        }
        
        return updated;
      });
    }
  };

  // ============================================
  // HANDLE INPUT CHANGE (Allocation only)
  // ============================================
  const handleAllocationChange = (rowId, value) => {
    const cleanValue = value.replace(/[^0-9]/g, "");
    const numValue = cleanValue === "" ? null : parseInt(cleanValue, 10);

    const monthField = getMonthField(selectedMonth);
    
    console.log("📝 Allocation change - Row:", rowId, "Value:", numValue, "Month:", selectedMonth, "Field:", monthField);

    setTableData((prev) =>
      prev.map((row) => {
        if (row.id === rowId) {
          return {
            ...row,
            allocation: numValue,
            isModified: true,
          };
        }
        return row;
      })
    );

    setModifiedRows((prev) => {
      const newMap = new Map(prev);
      newMap.set(rowId, { value: numValue, monthField: monthField });
      return newMap;
    });
  };

  // ============================================
  // HANDLE SAVE
  // ============================================
  const handleSave = async () => {
    if (modifiedRows.size === 0) {
      toast.info("No changes to save");
      return;
    }

    setSaving(true);

    try {
      const monthField = getMonthField(selectedMonth);
      
      const rowsToUpdate = [];
      modifiedRows.forEach((data, rowId) => {
        rowsToUpdate.push({
          id: rowId,
          [data.monthField]: data.value,
        });
      });

      console.log("💾 Saving allocations for", selectedMonth, "(" + monthField + "):", rowsToUpdate);

      const response = await updateMultipleDealerInvestmentAllocation(rowsToUpdate);

      if (response?.status) {
        toast.success(`${rowsToUpdate.length} allocation(s) saved for ${selectedMonth}!`);
        
        setModifiedRows(new Map());
        setTableData((prev) =>
          prev.map((row) => ({ ...row, isModified: false }))
        );
        
        await fetchAllData();
      } else {
        toast.error(response?.message || "Failed to save allocations");
      }
    } catch (err) {
      console.error("Error saving allocations:", err);
      toast.error("Failed to save allocations");
    } finally {
      setSaving(false);
    }
  };

  // ============================================
  // CLEAR FILTERS
  // ============================================
  const handleClearFilters = () => {
    setSelectedValues({
      equipmentMake: [],
      equipmentType: [],
      equipmentModel: [],
    });
    setSearchQuery("");
  };

  // ============================================
  // GET CLOSE STOCK COLOR
  // ============================================
  const getCloseStockColor = (value) => {
    if (value === null || value === undefined) return "text-gray";
    if (value > 0) return "text-green";
    if (value === 0) return "text-orange";
    return "text-red";
  };

  // ============================================
  // FORMAT VALUE FOR DISPLAY
  // ============================================
  const formatValue = (value) => {
    if (value === null || value === undefined) return "-";
    return value;
  };

  // ============================================
  // RENDER - ACCESS DENIED (Non-Admin Users)
  // ============================================
  if (!isAdmin) {
    return (
      <div className="mb-2">
        <div className="flex flex-col items-center justify-center py-12 bg-gray-50 border border-gray-200 rounded">
          <svg 
            className="w-12 h-12 text-gray-400 mb-4" 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={1.5} 
              d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" 
            />
          </svg>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Access Restricted</h3>
          <p className="text-sm text-gray-500 text-center max-w-md">
            The Allocation page is only accessible to Administrators. 
            Please contact your administrator if you need access to this feature.
          </p>
        </div>
      </div>
    );
  }

  // ============================================
  // RENDER - LOADING STATE
  // ============================================
  if (loading) {
    return (
      <div className="mb-2">
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-darkblue1"></div>
          <span className="ml-3 text-sm text-gray-600">Loading allocation data...</span>
        </div>
      </div>
    );
  }

  // ============================================
  // RENDER - ERROR STATE
  // ============================================
  if (error) {
    return (
      <div className="mb-2">
        <div className="flex flex-col items-center justify-center py-12">
          <p className="text-red text-sm mb-4">{error}</p>
          <button
            onClick={fetchAllData}
            className="px-4 py-2 bg-darkblue1 text-white text-xs hover:bg-blue-700 transition"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  // ============================================
  // RENDER - MAIN (Admin Only)
  // ============================================
  return (
    <div className="mb-2">
      {/* Filters */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex flex-wrap items-center gap-2">
          <Searchinput
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search"
            className="w-44 h-8"
            bgColor="bg-white"
            borderColor="border-black/60"
            textColor="text-black"
            focusRing="focus:ring-black/60"
            shadow="shadow-none"
            inputPadding="pl-7 pr-3 py-1.5"
            iconSize="w-3.5 h-3.5"
            iconLeft="left-3"
            iconColor="text-black"
          />

          <Filter
            name="equipmentMake"
            value={selectedValues.equipmentMake}
            options={equipmentMakeOptions}
            onChange={handleFilterChange}
            placeholder="Equipment Make"
            textColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBorderColor="border-black/60"
            dropdownHoverColor="hover:bg-lightBlue/50"
            customWidth="w-40"
            placeholderColor="text-black"
          />

          <Filter
            name="equipmentType"
            value={selectedValues.equipmentType}
            options={equipmentTypeOptions}
            onChange={handleFilterChange}
            placeholder="Equipment Type"
            textColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBorderColor="border-black/60"
            dropdownHoverColor="hover:bg-lightBlue/50"
            customWidth="w-40"
            placeholderColor="text-black"
          />

          <Filter
            name="equipmentModel"
            value={selectedValues.equipmentModel}
            options={equipmentModelOptions}
            onChange={handleFilterChange}
            placeholder="Equipment Model"
            textColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBorderColor="border-black/60"
            dropdownHoverColor="hover:bg-lightBlue/50"
            customWidth="w-40"
            placeholderColor="text-black"
          />

          <SingleSelectFilter
            name="month"
            value={selectedMonth}
            options={monthOptions}
            onChange={handleFilterChange}
            placeholder="Month"
            textColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBorderColor="border-black/60"
            dropdownHoverColor="hover:bg-lightBlue/50"
            customWidth="w-32"
            disableSorting={true}
            placeholderColor="text-black"
          />

          {(selectedValues.equipmentMake.length > 0 ||
            selectedValues.equipmentType.length > 0 ||
            selectedValues.equipmentModel.length > 0 ||
            searchQuery) && (
            <button
              onClick={handleClearFilters}
              className="px-3 py-1.5 text-xs text-red border border-red-300 hover:bg-red-50 transition"
            >
              Clear
            </button>
          )}
        </div>

        {mode === "fill" && (
          <button
            onClick={handleSave}
            disabled={saving || modifiedRows.size === 0}
            className={`px-6 py-1.5 text-xs font-medium transition whitespace-nowrap flex items-center gap-2
              ${modifiedRows.size > 0
                ? "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                : "bg-gray-300 text-gray-500 cursor-not-allowed"
              }`}
          >
            {saving ? (
              <>
                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                Saving...
              </>
            ) : (
              `Save Allocation ${modifiedRows.size > 0 ? `(${modifiedRows.size})` : ""}`
            )}
          </button>
        )}
      </div>

      {/* Unsaved Changes Indicator */}
      {modifiedRows.size > 0 && (
        <div className="mb-2 text-xs text-orange-600 bg-orange-50 px-3 py-1.5 rounded border border-orange-200">
          ⚠ {modifiedRows.size} unsaved change(s) for {selectedMonth}
        </div>
      )}

      {/* Table */}
      <div className="bg-white shadow-md border border-Dustyblue overflow-hidden  relative z-0">
              <div
              ref={tableContainerRef}
                className="overflow-y-auto relative z-0"
                style={{
                  scrollbarWidth: "none",
                  msOverflowStyle: "none",
                  maxHeight: sortedData.length > 7 ? "calc(100vh - 320px)" : "auto",
                }}
                onScroll={handleTableScroll}
              >
                <style jsx>{`
                  div::-webkit-scrollbar {
                    display: none;
                  }
                `}</style>

                <table className="w-full text-xs whitespace-nowrap">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">

  {/* First row */}
  <tr>
    {["equipmentMake", "equipmentType", "equipmentModel"].map((key) => {
      const labelMap = {
        equipmentMake: "Equipment Make",
        equipmentType: "Equipment Type",
        equipmentModel: "Equipment Model",
      };

      return (
     <th
  key={key}
  rowSpan={2}
  className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort(key)}
>
  <div className="flex items-center gap-1">
    {labelMap[key]}

    {/* Show neutral only for first column */}
    {key === "equipmentMake" && sortKey !== key && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

    {/* Sorted ascending */}
    {sortKey === key && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3 text-white" />
    )}

    {/* Sorted descending */}
    {sortKey === key && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3 text-white" />
    )}
  </div>
</th>

      );
    })}

    <th
      colSpan={5}
      className="py-1.5 px-2 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium bg-darkblue1"
    >
      {selectedMonth} {pdpYear && `(${pdpYear})`}
    </th>
  </tr>

  {/* Second row */}
  <tr>
    {["allocation", "projection", "openStock", "arrivals", "closeStock"].map((key, index, arr) => {
      const labelMap = {
        allocation: "Allocation",
        projection: "Projection",
        openStock: "Open Stock",
        arrivals: "Arrival",
        closeStock: "Close Stock",
      };

      const noteMap = {
        projection: "(Retail + KAM)",
      };

      return (
        <th
          key={key}
          className={`py-1.5 px-2 text-xs border border-grey2 border-l-0 border-b-0 font-medium text-center w-[10%] cursor-pointer select-none ${
            index === arr.length - 1 ? "border-r-0" : ""
          }`}
          onClick={() => handleSort(key)}
        >
          <div className="flex flex-col items-center gap-0.5">
            <span>{labelMap[key]}</span>
            {noteMap[key] && <span className="text-[9px] font-normal opacity-80">{noteMap[key]}</span>}
            {sortKey === key && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
            {sortKey === key && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
          </div>
        </th>
      );
    })}
  </tr>

</thead>

            <tbody>
              {sortedData.length > 0 ? (
                sortedData.map((row) => {
                  const isModified = modifiedRows.has(row.id);

                  return (
                    <tr
                      key={row.id}
                      className={`hover:bg-lightBlue/30 transition ${
                        isModified ? "bg-yellow-50" : ""
                      }`}
                    ><td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.equipmentMake && row.equipmentMake.length > 18)
          setHoveredCell(row.id + "-equipmentMake");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.equipmentMake}
    </p>

    {hoveredCell === row.id + "-equipmentMake" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {row.equipmentMake}
      </span>
    )}
  </div>
</td>

<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.equipmentType && row.equipmentType.length > 18)
          setHoveredCell(row.id + "-equipmentType");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.equipmentType}
    </p>

    {hoveredCell === row.id + "-equipmentType" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {row.equipmentType}
      </span>
    )}
  </div>
</td>

<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.equipmentModel && row.equipmentModel.length > 18)
          setHoveredCell(row.id + "-equipmentModel");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.equipmentModel}
    </p>

    {hoveredCell === row.id + "-equipmentModel" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {row.equipmentModel}
      </span>
    )}
  </div>
</td>

                      <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0 text-center">
                        {mode === "fill" ? (
                         <input
  type="text"
  inputMode="decimal"
  value={row.allocation === null || row.allocation === undefined ? "" : row.allocation}
  placeholder="0"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleAllocationChange(row.id, value);
    }
  }}
  className={`w-full text-center border px-2 py-0.5 text-xs focus:outline-none focus:ring-1 focus:ring-darkblue1
    ${isModified ? "border-orange-400 bg-orange-50" : "border-gray-300 bg-white"}`}
/>
                        ) : (
                          <span className="text-gray-800">{formatValue(row.allocation)}</span>
                        )}
                      </td>

                      <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0 text-center bg-blue-50">
                        <span className="text-blue-700 font-medium">
                          {formatValue(row.projection)}
                        </span>
                      </td>

                      <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0 text-center">
                        <span className="text-gray-600">{formatValue(row.openStock)}</span>
                      </td>

                      <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0 text-center">
                        <span className="text-gray-600">{formatValue(row.arrivals)}</span>
                      </td>

                      <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 text-center bg-gray-50">
                        <span className={`font-semibold ${getCloseStockColor(row.closeStock)}`}>
                          {formatValue(row.closeStock)}
                        </span>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={8} className="text-center py-8 text-gray-500 italic">
                    No allocation data available for {selectedMonth}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
  {showScrollButtons && (
            <div className="fixed bottom-10 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

      </div>

      {/* Record Count & Legend */}
      {tableData.length > 0 && (
        <div className="mt-2 flex flex-wrap justify-between items-center text-xs text-gray-500 gap-2">
          <span>
            Showing {sortedData.length} of {tableData.length} record(s) for <strong>{selectedMonth}</strong>
          </span>
          <div className="flex items-center gap-4">
            <span className="text-blue-600 font-medium">Projection = Retail + KAM</span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 bg-green rounded-full"></span>
              Positive
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 bg-orange rounded-full"></span>
              Zero
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 bg-red rounded-full"></span>
              Negative
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default Allocation;