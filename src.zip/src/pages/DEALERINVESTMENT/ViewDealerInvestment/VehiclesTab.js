import React, { useState, useEffect, useRef,useMemo} from "react";
import { useNavigate } from "react-router-dom";
import { ChevronUp,ChevronDown,ChevronsUpDown } from "lucide-react";
import {
  getDealerInvestmentVehiclesByDealerInvestmentId,
  getVehicleCountsByQuarter,
} from "../../../services/dealerInvestment/dealerInvestmentVehicles.service";
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation";
const VehiclesTab = ({ mode, apiData, onSave, saving, investment }) => {
  const navigate = useNavigate();
  const formRef= useRef(null)
  // Initialize state from API data or empty
  const [vehiclesData, setVehiclesData] = useState({});
  const [pdpTargets, setPdpTargets] = useState({});
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell,setHoveredCell] = useState("")
  // Quarter-wise vehicle counts (from API)
  const [quarterCounts, setQuarterCounts] = useState({
    Q1: 0,
    Q2: 0,
    Q3: 0,
    Q4: 0
  });
  
  const [loadingCounts, setLoadingCounts] = useState(false);

  // Sync with API data when it changes (for vehicle types from infrastructure)
  useEffect(() => {
    // Always show "Service Vehicles" as the main label
    // Combine all vehicle types (2-Wheeler + 4-Wheeler) under one "Service Vehicles" row
    let totalPdpTarget = 0;
    
    if (apiData?.tableData && Object.keys(apiData.tableData).length > 0) {
      totalPdpTarget = Object.values(apiData.tableData).reduce(
        (sum, v) => sum + (parseInt(v.pdpTarget) || 0), 
        0
      );
    }
    
    const transformedData = {
      "Service Vehicles": {
        pdpTarget: String(totalPdpTarget),
      }
    };
    
    setVehiclesData(transformedData);
    setPdpTargets({ "Service Vehicles": String(totalPdpTarget) });
    
    console.log("Transformed vehicles data:", transformedData);
  }, [apiData]);

  // Fetch vehicle counts from API
  const fetchVehicleCounts = async () => {
    if (!investment?.id) return;

    setLoadingCounts(true);
    try {
      const response = await getDealerInvestmentVehiclesByDealerInvestmentId(investment.id);
      
      if (response?.status && response?.data) {
        const counts = getVehicleCountsByQuarter(response.data);
        setQuarterCounts(counts);
        console.log("Vehicle counts loaded from API:", counts);
      }
    } catch (error) {
      console.error("Error fetching vehicle counts:", error);
    } finally {
      setLoadingCounts(false);
    }
  };

  // Load counts on mount and when investment changes
  useEffect(() => {
    fetchVehicleCounts();
  }, [investment?.id]);

  // Refresh counts when window gains focus (returning from VehiclesList)
  useEffect(() => {
    const handleFocus = () => {
      fetchVehicleCounts();
    };
    window.addEventListener('focus', handleFocus);
    
    return () => {
      window.removeEventListener('focus', handleFocus);
    };
  }, [investment?.id]);

  // Get count for a specific quarter
  const getQuarterCount = (vehicleType, quarter) => {
    return quarterCounts[quarter] || 0;
  };

  // Calculate total vehicles across all quarters
  const calculateYTDActual = (vehicle) => {
    return quarterCounts.Q1 + quarterCounts.Q2 + quarterCounts.Q3 + quarterCounts.Q4;
  };

  const calculateAchievement = (vehicle) => {
    const ytdActual = calculateYTDActual(vehicle);
    const target = parseInt(vehiclesData[vehicle]?.pdpTarget || pdpTargets[vehicle]) || 1;
    return target > 0 ? ((ytdActual / target) * 100).toFixed(2) : 0;
  };
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

const sortedVehiclesData = useMemo(() => {
  const entries = Object.entries(vehiclesData); // [[vehicleName, { pdpTarget }], ...]
  if (!sortKey || !sortOrder) return entries;

  return entries.sort(([nameA, dataA], [nameB, dataB]) => {
    let valA, valB;

    switch (sortKey) {
      case "vehicle":
        valA = nameA.toLowerCase();
        valB = nameB.toLowerCase();
        break;
      case "q1":
      case "q2":
      case "q3":
      case "q4":
        valA = quarterCounts[sortKey.toUpperCase()] || 0;
        valB = quarterCounts[sortKey.toUpperCase()] || 0;
        break;
      case "actual":
        valA = calculateYTDActual(nameA);
        valB = calculateYTDActual(nameB);
        break;
      case "pdpTarget":
        valA = parseInt(dataA.pdpTarget || pdpTargets[nameA] || 0);
        valB = parseInt(dataB.pdpTarget || pdpTargets[nameB] || 0);
        break;
      case "achievement":
        valA = calculateAchievement(nameA);
        valB = calculateAchievement(nameB);
        break;
      default:
        valA = 0;
        valB = 0;
    }

    if (typeof valA === "number" && typeof valB === "number") {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    valA = String(valA).toLowerCase();
    valB = String(valB).toLowerCase();
    if (valA < valB) return sortOrder === "asc" ? -1 : 1;
    if (valA > valB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [vehiclesData, quarterCounts, pdpTargets, sortKey, sortOrder]);

  const handleSave = () => {
    if (onSave) {
      onSave(vehiclesData);
    }
  };
// useKeyboardNavigation({
//         containerRef: formRef,
//         onSubmit: () => handleSave(),
//         onCancel: () => {},
//     });
  const handleViewDetails = (quarter) => {
    console.log(`View details for ${quarter}`);
    navigate("/DEALERINVESTMENT/ViewDealerInvestment/VehiclesList", {
      state: { 
        quarter: quarter,
        investment: investment,
        mode: mode
      }
    });
  };

  return (
    <div>
      {/* Desktop View */}
      <div className="hidden lg:block">
        {/* Service Vehicles Total Card - Shows PDP Target */}
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
          <div className="bg-Dustyblue text-white">
            <div className="grid grid-cols-2 text-center font-medium text-xs">
              <div className="py-1.5 px-4 border border-grey2 border-t-0 border-l-0 border-b-0 text-xs">PDP Target</div>
              <div className="py-1.5 px-4 border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 text-xs">
                Service Vehicles
              </div>
            </div>
          </div>
          <div className="bg-white">
            <div className="grid grid-cols-2 text-center border-t border-Dustyblue text-xs font-normal">
              <div className="py-1 px-4 border border-grey2 border-t-0 border-l-0 text-xs"></div>
              <div className="py-1 px-4 border border-grey2 border-t-0 border-l-0 border-r-0 text-xs">
                {Object.values(vehiclesData)[0]?.pdpTarget || Object.values(pdpTargets)[0] || 0}
              </div>
            </div>
          </div>
        </div>

        {/* Main Vehicles Table */}
        <div 
        ref={formRef}
        className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-4">
          <div className="overflow-x-auto">
            <table className="w-full table-fixed" style={{ borderCollapse: 'collapse' }}>
              <colgroup>
                <col className="w-[12.5%]" />
                <col className="w-[12.5%]" />
                <col className="w-[12.5%]" />
                <col className="w-[12.5%]" />
                <col className="w-[12.5%]" />
                <col className="w-[12.5%]" />
                <col className="w-[12.5%]" />
                <col className="w-[12.5%]" />
              </colgroup>
             <thead>
  <tr className="bg-Dustyblue text-white">
    {/* Vehicles */}
    <th
      className="border-r border-white px-3 py-1.5 text-center font-medium border-b border-Dustyblue text-xs cursor-pointer select-none"
      onClick={() => handleSort("vehicle")}
    >
      <div className="flex  gap-1">
        Vehicles
        {sortKey !== "vehicle" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

        {sortKey === "vehicle" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "vehicle" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* Q1–Q4 */}
    {[
      { label: "Q1", key: "q1" },
      { label: "Q2", key: "q2" },
      { label: "Q3", key: "q3" },
      { label: "Q4", key: "q4" },
    ].map(({ label, key }) => (
      <th
        key={key}
        className="border-r border-white px-3 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 text-xs cursor-pointer select-none"
        onClick={() => handleSort(key)}
      >
        <div className="flex items-center justify-center gap-1">
          {label}
          {sortKey === key && sortOrder === "asc" && (
            <ChevronUp className="w-3 h-3 text-white" />
          )}
          {sortKey === key && sortOrder === "desc" && (
            <ChevronDown className="w-3 h-3 text-white" />
          )}
        </div>
      </th>
    ))}

    {/* Actual */}
    <th
      className="border-r border-white px-3 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 text-xs cursor-pointer select-none"
      onClick={() => handleSort("actual")}
    >
      <div className="flex items-center justify-center gap-1">
        Actual
        {sortKey === "actual" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "actual" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* PDP Target */}
    <th
      className="border-r border-white px-3 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 text-xs cursor-pointer select-none"
      onClick={() => handleSort("pdpTarget")}
    >
      <div className="flex items-center justify-center gap-1">
        PDP Target
        {sortKey === "pdpTarget" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "pdpTarget" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* Achievement % */}
    <th
      className="px-3 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 text-xs cursor-pointer select-none"
      onClick={() => handleSort("achievement")}
    >
      <div className="flex items-center justify-center gap-1">
        Achievement %
        {sortKey === "achievement" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "achievement" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>
  </tr>
</thead>
<tbody>
  {sortedVehiclesData.map(([vehicleName, vehicleObj]) => (
    <tr key={vehicleName}>
      {/* Vehicle Name */}
     <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-black text-left text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (vehicleName && vehicleName.length > 12) // show tooltip only if name is long
          setHoveredCell(vehicleName + "-name");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {vehicleName}
    </p>

    {hoveredCell === vehicleName + "-name" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {vehicleName}
      </span>
    )}
  </div>
</td>

      {/* Q1–Q4 */}
      {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
        <td
          key={quarter}
          className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs"
        >
          {loadingCounts ? "..." : quarterCounts[quarter] || "-"}
        </td>
      ))}

      {/* Actual */}
      <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-center text-xs">
        {loadingCounts ? "..." : calculateYTDActual(vehicleName)}
      </td>

      {/* PDP Target */}
      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs">
        {vehicleObj.pdpTarget || pdpTargets[vehicleName] || 0}
      </td>

      {/* Achievement % */}
      <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1 text-center text-xs">
        {calculateAchievement(vehicleName)}%
      </td>
    </tr>
  ))}

  {/* Optional View Details Row */}
  <tr>
    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1"></td>
    {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
      <td
        key={quarter}
        className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-center"
      >
        <button
          onClick={() => handleViewDetails(quarter)}
          className="bg-darkblue1 text-white px-2 py-1 font-medium text-xs hover:bg-darkblue1/90 transition flex items-center justify-center gap-1 mx-auto whitespace-nowrap"
        >
          <span>➕</span>
          View Details
        </button>
      </td>
    ))}
    <td colSpan="3"></td>
  </tr>
</tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Mobile/Tablet View */}
      <div className="lg:hidden">
        {/* PDP Target Card - Shows PDP Target Value */}
        <div className="bg-white shadow-md border-2 border-Dustyblue overflow-hidden mb-6">
          <div className="bg-Dustyblue text-white">
            <div className="grid grid-cols-2 text-center font-medium text-xs sm:text-sm">
              <div className="py-2 px-2 sm:px-4 border-r border-white">PDP Target</div>
              <div className="py-2 px-2 sm:px-4">
                Service Vehicles
              </div>
            </div>
          </div>
          <div className="bg-white">
            <div className="grid grid-cols-2 text-center text-gray-700 border-t border-Dustyblue text-xs sm:text-sm">
              <div className="py-2 px-2 sm:px-4 border-r border-Dustyblue"></div>
              <div className="py-2 px-2 sm:px-4 font-medium">
                {Object.values(vehiclesData)[0]?.pdpTarget || Object.values(pdpTargets)[0] || 0}
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Cards */}
        <div className="space-y-4 mb-6">
          <div className="bg-white shadow-md border-2 border-Dustyblue p-4">
            <h3 className="font-semibold text-darkblue1 mb-3 pb-2 border-b-2 border-Dustyblue text-sm">
              Service Vehicles
            </h3>
            <div className="grid grid-cols-2 gap-3 text-sm">
              {/* Q1, Q2, Q3, Q4 - View Only */}
              {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
                <div key={quarter} className="flex justify-between">
                  <span className="font-medium text-gray-600">{quarter}:</span>
                  <span className="text-gray-800">
                    {loadingCounts ? "..." : quarterCounts[quarter] || "-"}
                  </span>
                </div>
              ))}

              {/* Actual / YTD */}
              <div className="flex justify-between col-span-2">
                <span className="font-medium text-gray-600">Actual:</span>
                <span className="text-gray-800">
                  {loadingCounts ? "..." : (quarterCounts.Q1 + quarterCounts.Q2 + quarterCounts.Q3 + quarterCounts.Q4)}
                </span>
              </div>

              {/* PDP Target */}
              <div className="flex justify-between">
                <span className="font-medium text-gray-600">PDP Target:</span>
                <span className="text-gray-800">
                  {Object.values(vehiclesData)[0]?.pdpTarget || Object.values(pdpTargets)[0] || 0}
                </span>
              </div>

              {/* Achievement */}
              <div className="flex justify-between">
                <span className="font-medium text-gray-600">Achievement:</span>
                <span className="font-semibold text-darkblue1">
                  {(() => {
                    const ytdActual = quarterCounts.Q1 + quarterCounts.Q2 + quarterCounts.Q3 + quarterCounts.Q4;
                    const target = Object.values(vehiclesData)[0]?.pdpTarget || Object.values(pdpTargets)[0] || 1;
                    return target > 0 ? ((ytdActual / target) * 100).toFixed(2) : "0.00";
                  })()}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* View Details Buttons for Mobile */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
            <button
              key={quarter}
              onClick={() => handleViewDetails(quarter)}
              className="bg-darkblue1 text-white px-3 py-2 font-medium text-xs sm:text-sm hover:bg-darkblue1/90 transition flex items-center justify-center gap-2"
            >
              <span>➕</span>
              View Details - {quarter}
            </button>
          ))}
        </div>
      </div>

      {/* Save Button */}
      {/* {mode === "fill" && (
        <div className="flex justify-end mb-6">
          <button
            onClick={handleSave}
            disabled={saving}
            className="bg-darkblue1 text-white px-8 py-1.5 font-medium text-xs 
                       hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 
                       transition w-full sm:w-auto
                       disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? "Saving..." : "Save"}
          </button>
        </div>
      )} */}
    </div>
  );
};

export default VehiclesTab;