import React, { useState, useEffect, useRef,useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { ArrowLeft, Loader2,ChevronDown,ChevronUp,ChevronsUpDown } from "lucide-react";
import { toast } from "react-toastify";
import axios from "axios";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import SubmitMBP from "../../../Components/SubmitMBP";
import { API } from "../../../api";
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation";

// Import service functions
import {
  fetchAllEquipmentData,
  saveEquipmentData,
  getUniqueModels,
  filterModelsByName,
} from "../../../services/dealerInvestment/dealerInvestmentEquipment.service";

// ⭐ IMPORT MBP SERVICE with constants
import {
  MBP_STATUS,
  fetchLatestMBPStatus,
  isMBPEditable,
  getMBPActions,
  submitMBP,
  requestMBPEdit,
  enableMBP,
  disableMBP,
} from "../../../services/dealerInvestment/Mbpstatusservice";

// ═══════════════════════════════════════════════════════════════
// DEALER ROLES
// ═══════════════════════════════════════════════════════════════
const DEALER_ROLES = [
  "Dealer Parts Manager",
  "Dealer Finance Head",
  "Dealer Coordinator",
  "Dealer Sales Head",
  "Dealer CST Head",
  "Dealer CEO",
  "Dealer HR Head",
  "Dealer Principal"
];

// ═══════════════════════════════════════════════════════════════
// ADMIN ROLES
// ═══════════════════════════════════════════════════════════════
const ADMIN_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Uptime & Parts Manager",
  "Market Area Head"
];
// ============================================
// AUTH HEADERS HELPER
// ============================================
const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

const FillEntriesEqup = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // ⭐ Get current user from Redux
  const user = useSelector((state) => state.user);
  const userRole = user?.data?.persona || user?.persona || user?.role || "";

  // ⭐ Check if current user is a dealer
  const isDealer = DEALER_ROLES.some(
    role => role.toLowerCase() === userRole.toLowerCase()
  );

  // ⭐ Check if current user is admin
  const isAdmin = ADMIN_ROLES.some(
    role => role.toLowerCase() === userRole.toLowerCase()
  );

  // Get data from navigation state
  const {
    investment,
    mode,
    dealerInvestmentId: directId,
    selectedMake: passedMake,
    selectedType: passedType,
    mbpStatus: passedMbpStatus,
  } = location.state || {};

  const dealerInvestmentId = investment?.id || directId;
  const pdpYear = investment?.pdp_info?.year || new Date().getFullYear();

  // Store the filter from parent page
  const [filterMake, setFilterMake] = useState(passedMake || "Volvo");
  const [filterType, setFilterType] = useState(passedType || "Equipments");

  // ⭐ MBP STATUS STATE - Uses MBP_STATUS constants
  const [mbpStatus, setMbpStatus] = useState(passedMbpStatus || MBP_STATUS.SUBMITTED);
  const [mbpLoading, setMbpLoading] = useState(false);
  const [mbpActions, setMbpActions] = useState({});
const formRef= useRef(null)

  // Popup states
  const [showSubmitPopup, setShowSubmitPopup] = useState(false);
  const [showRequestPopup, setShowRequestPopup] = useState(false);
  const [requestLoading, setRequestLoading] = useState(false);
 const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null);

  const handleSort = (key) => {
    if (sortKey === key) {
      // toggle sort order
      if (sortOrder === "asc") setSortOrder("desc");
      else if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
      } else setSortOrder("asc");
    } else {
      setSortKey(key);
      setSortOrder("asc");
    }
  };
  
  // Debug logging
  useEffect(() => {
    console.log("🎯 FillEntriesEqup location.state:", location.state);
    console.log("📊 Resolved dealerInvestmentId:", dealerInvestmentId);
    console.log("🎨 Filter - Make:", filterMake, "Type:", filterType);
    console.log("👤 User Role:", userRole, "isDealer:", isDealer, "isAdmin:", isAdmin);
    console.log("📋 MBP Status:", mbpStatus);
  }, [location.state, dealerInvestmentId, filterMake, filterType, userRole, isDealer, isAdmin, mbpStatus]);

  // Refs for click-outside detection
  const equipmentTypeRef = useRef(null);
  const equipmentModelRef = useRef(null);
  const kamTypeRef = useRef(null);

  // Loading and error states
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  // Dropdown states
  const [menuOpen, setMenuOpen] = useState(false);
  const [equipmentTypeDropdownOpen, setEquipmentTypeDropdownOpen] = useState(false);
  const [equipmentModelDropdownOpen, setEquipmentModelDropdownOpen] = useState(false);
  const [kamDropdownOpen, setKamDropdownOpen] = useState(false);

  // Selection states
  const [selectedEquipmentType, setSelectedEquipmentType] = useState("");
  const [selectedDataType, setSelectedDataType] = useState("Projection");
  const [selectedKAMType, setSelectedKAMType] = useState("KAM");
  const [selectedEquipmentModel, setSelectedEquipmentModel] = useState("All Models");

  // Data states (from API)
  const [equipmentTypes, setEquipmentTypes] = useState([]);
  const [equipmentModels, setEquipmentModels] = useState({});
  const [quarterlySummary, setQuarterlySummary] = useState({});
  const [rawData, setRawData] = useState({ mbp: [], projection: [], actuals: [] });

  // Local edits state
  const [localEdits, setLocalEdits] = useState({});

  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  // ⭐ UPDATE MBP ACTIONS WHEN STATUS CHANGES
  useEffect(() => {
    const actions = getMBPActions(mbpStatus, userRole, DEALER_ROLES, ADMIN_ROLES);
    setMbpActions(actions);
    console.log("🎯 MBP Actions updated:", actions);
  }, [mbpStatus, userRole]);
const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return [...equipmentTypes];

    return [...equipmentTypes].sort((a, b) => {
      let valA, valB;

      if (sortKey === "Equipment") {
        valA = a.toLowerCase();
        valB = b.toLowerCase();
      } else {
        // keys like "Q1-MBP", "Q2-Actuals"
        const [q, field] = sortKey.split("-");
        valA = quarterlySummary[a]?.[q]?.[field] ?? 0;
        valB = quarterlySummary[b]?.[q]?.[field] ?? 0;
      }

      // numeric comparison if both are numbers
      if (!isNaN(valA) && !isNaN(valB)) return sortOrder === "asc" ? valA - valB : valB - valA;

      // fallback to string comparison
      const strA = valA.toString().toLowerCase();
      const strB = valB.toString().toLowerCase();

      if (strA < strB) return sortOrder === "asc" ? -1 : 1;
      if (strA > strB) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [equipmentTypes, quarterlySummary, sortKey, sortOrder]);
  // ⭐ FETCH LATEST MBP STATUS FROM DATABASE
  const fetchLatestMBPStatusFromDB = async () => {
    if (!dealerInvestmentId) {
      console.warn("⚠️ No dealerInvestmentId available");
      return;
    }

    try {
      setMbpLoading(true);
      console.log("📡 Fetching latest MBP status for ID:", dealerInvestmentId);

      const actualStatus = await fetchLatestMBPStatus(dealerInvestmentId);
      console.log("✅ Fetched MBP Status:", actualStatus);
      setMbpStatus(actualStatus);
    } catch (error) {
      console.warn("⚠️ Could not fetch MBP status:", error.message);
    } finally {
      setMbpLoading(false);
    }
  };
useKeyboardNavigation({
  containerRef: formRef, // your popup div ref

  onSubmit: () => { 
    handleSave()
  },

  onCancel: () => {
  },
});

  // ============================================
  // FETCH DATA
  // ============================================
  useEffect(() => {
    const fetchData = async () => {
      if (!dealerInvestmentId) {
        console.error("No dealer investment ID found. location.state:", location.state);
        setError("No dealer investment ID provided. Please navigate from the Equipment & Attachments page.");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);

        // ⭐ FETCH LATEST MBP STATUS FROM DATABASE
        await fetchLatestMBPStatusFromDB();

        const filters = {
          make: filterMake,
          type: filterType,
        };

        console.log("📡 Fetching equipment data with filters:", filters);
        const response = await fetchAllEquipmentData(dealerInvestmentId, filters);

        if (response.status && response.data) {
          const { equipmentModels: models, quarterlySummary: summary, equipmentTypes: types } = response.data;

          setEquipmentModels(models);
          setQuarterlySummary(summary);
          setEquipmentTypes(types);
          setRawData(response.rawData);

          if (types.length > 0 && !selectedEquipmentType) {
            setSelectedEquipmentType(types[0]);
          }

          console.log("✅ Equipment data loaded successfully");
        }
      } catch (err) {
        console.error("Error fetching equipment data:", err);
        setError("Failed to load equipment data. Please try again.");
        toast.error("Failed to load equipment data");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [dealerInvestmentId]);

  // ============================================
  // CLICK OUTSIDE HANDLER
  // ============================================
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (equipmentTypeRef.current && !equipmentTypeRef.current.contains(event.target)) {
        setEquipmentTypeDropdownOpen(false);
      }
      if (equipmentModelRef.current && !equipmentModelRef.current.contains(event.target)) {
        setEquipmentModelDropdownOpen(false);
      }
      if (kamTypeRef.current && !kamTypeRef.current.contains(event.target)) {
        setKamDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ============================================
  // HANDLERS
  // ============================================
  const handleBack = () => {
    navigate("/DEALERINVESTMENT/ViewDealerInvestment/FillEntries", {
      state: {
        investment: investment,
        mode: mode,
        activeSubTab: "Equipments & Attachments",
        selectedMake: filterMake,
        selectedType: filterType,
      },
    });
  };

  // ⭐ ADMIN: ENABLE MBP
  const handleEnableMBP = async () => {
    try {
      setMbpLoading(true);
      console.log("🔄 Enabling MBP...");

      const response = await enableMBP(dealerInvestmentId);

      if (response.status) {
        toast.success("✅ MBP Enabled! Dealer can now edit.");

        // ⭐ Fetch actual status from DB
        const actualStatus = await fetchLatestMBPStatus(dealerInvestmentId);
        setMbpStatus(actualStatus);
      } else {
        toast.error(response.message || "Failed to enable MBP");
      }
    } catch (err) {
      console.error("❌ Error enabling MBP:", err);
      toast.error("Failed to enable MBP");
    } finally {
      setMbpLoading(false);
    }
  };

  // ⭐ ADMIN: DISABLE MBP
  const handleDisableMBP = async () => {
    try {
      setMbpLoading(true);
      console.log("🔄 Disabling MBP...");

      const response = await disableMBP(dealerInvestmentId);

      if (response.status) {
        toast.info("🔒 MBP Disabled");

        // ⭐ Fetch actual status from DB
        const actualStatus = await fetchLatestMBPStatus(dealerInvestmentId);
        setMbpStatus(actualStatus);
      } else {
        toast.error(response.message || "Failed to disable MBP");
      }
    } catch (err) {
      console.error("❌ Error disabling MBP:", err);
      toast.error("Failed to disable MBP");
    } finally {
      setMbpLoading(false);
    }
  };

  // ⭐ SUBMIT MBP
  const handleSubmitMBPConfirm = async () => {
    try {
      setMbpLoading(true);
      console.log("📤 Submitting MBP...");

      const response = await submitMBP(dealerInvestmentId);

      if (response.status) {
        setShowSubmitPopup(false);
        toast.success("✅ MBP submitted!");

        // ⭐ Fetch actual status from DB
        const actualStatus = await fetchLatestMBPStatus(dealerInvestmentId);
        setMbpStatus(actualStatus);
      } else {
        toast.error(response.message || "Failed to submit MBP");
      }
    } catch (err) {
      console.error("❌ Error submitting MBP:", err);
      toast.error("Failed to submit MBP");
    } finally {
      setMbpLoading(false);
    }
  };

  // ⭐ REQUEST MBP EDIT
  const handleRequestMBPEditConfirm = async () => {
    try {
      setRequestLoading(true);
      console.log("📝 Requesting MBP Edit...");

      const response = await requestMBPEdit(dealerInvestmentId);

      if (response.status) {
        setShowRequestPopup(false);
        toast.success("✅ Request sent!");

        // ⭐ Fetch actual status from DB
        const actualStatus = await fetchLatestMBPStatus(dealerInvestmentId);
        setMbpStatus(actualStatus);
      } else {
        toast.error(response.message || "Failed to send request");
      }
    } catch (err) {
      console.error("❌ Error requesting edit:", err);
      toast.error("Failed to send request");
    } finally {
      setRequestLoading(false);
    }
  };

  // Handle month input change
  const handleMonthInputChange = (modelId, month, value) => {
    setLocalEdits((prev) => ({
      ...prev,
      [modelId]: {
        ...(prev[modelId] || {}),
        [month]: value,
      },
    }));
  };

  // Get current value for a month
  const getMonthValue = (model, month) => {
    if (localEdits[model.id]?.[month] !== undefined) {
      return localEdits[model.id][month];
    }
    return model.monthlyData?.[month] || "";
  };

  // Calculate total from current values
  const calculateModelTotal = (model) => {
    return months.reduce((sum, month) => {
      const value = parseInt(getMonthValue(model, month)) || 0;
      return sum + value;
    }, 0);
  };

  // Handle save
  const handleSave = async () => {
    try {
      setSaving(true);

      const currentModels = equipmentModels[selectedEquipmentType]?.[selectedDataType]?.[selectedKAMType] || [];

      const modelsToSave = currentModels.map((model) => {
        const editedMonthlyData = { ...model.monthlyData };

        if (localEdits[model.id]) {
          Object.keys(localEdits[model.id]).forEach((month) => {
            editedMonthlyData[month] = localEdits[model.id][month];
          });
        }

        return {
          ...model,
          monthlyData: editedMonthlyData,
        };
      }).filter((model) => localEdits[model.id]);

      if (modelsToSave.length === 0) {
        toast.info("No changes to save");
        setSaving(false);
        return;
      }

      const response = await saveEquipmentData(selectedDataType, modelsToSave);

      if (response?.status) {
        toast.success(`✅ ${selectedDataType} data saved!`);

        setLocalEdits((prev) => {
          const newEdits = { ...prev };
          modelsToSave.forEach((model) => {
            delete newEdits[model.id];
          });
          return newEdits;
        });

        const refreshResponse = await fetchAllEquipmentData(dealerInvestmentId);
        if (refreshResponse.status && refreshResponse.data) {
          setEquipmentModels(refreshResponse.data.equipmentModels);
          setQuarterlySummary(refreshResponse.data.quarterlySummary);
        }
      } else {
        toast.error("Failed to save data");
      }
    } catch (err) {
      console.error("Error saving data:", err);
      toast.error("Error saving data");
    } finally {
      setSaving(false);
    }
  };

  // ============================================
  // COMPUTED VALUES
  // ============================================
  const currentModels = equipmentModels[selectedEquipmentType]?.[selectedDataType]?.[selectedKAMType] || [];
  const availableModels = getUniqueModels(currentModels);
  const filteredModels = filterModelsByName(currentModels, selectedEquipmentModel);

  const showPDPTotal = selectedDataType === "MBP";
  const showKAMTotal = selectedKAMType === "KAM";
  const showRetailTotal = selectedKAMType === "Retail";
  const showEnableMBP = selectedDataType === "MBP";
const sortedModels = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredModels;

  return [...filteredModels].sort((a, b) => {
    let valA = a[sortKey];
    let valB = b[sortKey];

    // calculate totals if key is dynamic
    if (sortKey === "kamTotal") {
      valA = calculateModelTotal(a);
      valB = calculateModelTotal(b);
    } else if (sortKey === "retailTotal") {
      valA = calculateModelTotal(a);
      valB = calculateModelTotal(b);
    } else if (months.includes(sortKey)) {
      valA = getMonthValue(a, sortKey);
      valB = getMonthValue(b, sortKey);
    }

    // numeric comparison
    if (!isNaN(valA) && !isNaN(valB)) return sortOrder === "asc" ? valA - valB : valB - valA;

    // string fallback
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";
    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [filteredModels, sortKey, sortOrder]);

  // ⭐ CALCULATE EDITABILITY - Using actual DB status
  const isEditable = mode === "fill" && isMBPEditable(mbpStatus, userRole, DEALER_ROLES, ADMIN_ROLES);

  // ⭐ RENDER MBP ACTION BUTTONS
  const renderMBPButtons = () => {
    // For Projection or Actuals - Show Save button
    if (selectedDataType !== "MBP") {
      return mode === "fill" && (
        <button
          onClick={handleSave}
          disabled={saving}
          className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2 disabled:opacity-50"
        >
          {saving ? (
            <>
              <Loader2 className="w-3 h-3 animate-spin" />
              Saving...
            </>
          ) : (
            "Save"
          )}
        </button>
      );
    }

    // MBP Data Type - ADMIN
    if (isAdmin) {
      return (
        <>
          <button
            onClick={mbpStatus === MBP_STATUS.ENABLED ? handleDisableMBP : handleEnableMBP}
            disabled={mbpLoading}
            className={`px-6 py-1 font-medium text-xs transition flex items-center gap-2 border ${
              mbpStatus === MBP_STATUS.ENABLED
                ? "bg-green-500 text-white border-green-600 hover:bg-white hover:text-green-600"
                : "bg-darkblue1 text-white border-darkblue1 hover:bg-white hover:text-darkblue1"
            } disabled:opacity-50`}
          >
            {mbpLoading ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : null}
            {mbpStatus === MBP_STATUS.ENABLED ? "Disable MBP" : "Enable MBP"}
          </button>

          {mbpStatus === MBP_STATUS.ENABLED && (
            <>
              <button
                onClick={() => setShowSubmitPopup(true)}
                disabled={mbpLoading}
                className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2 disabled:opacity-50"
              >
                Submit MBP
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2 disabled:opacity-50"
              >
                {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : "Save"}
              </button>
            </>
          )}

          <div className={`px-3 py-1 text-xs font-semibold rounded text-white ${
            mbpStatus === MBP_STATUS.ENABLED ? "bg-green-500" :
            mbpStatus === MBP_STATUS.SUBMITTED ? "bg-blue-500" :
            mbpStatus === MBP_STATUS.REQUESTED ? "bg-yellow-500" :
            "bg-gray-500"
          }`}>
            {mbpStatus}
          </div>
        </>
      );
    }

    // MBP Data Type - DEALER
    if (isDealer) {
      if (mbpStatus === MBP_STATUS.SUBMITTED) {
        return (
          <>
            <button
              onClick={() => setShowRequestPopup(true)}
              disabled={mbpLoading}
              className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2 disabled:opacity-50"
            >
              Request Edit
            </button>
            <div className="px-3 py-1 text-xs font-semibold rounded text-white bg-blue-500">
              Submitted
            </div>
          </>
        );
      }

      if (mbpStatus === MBP_STATUS.ENABLED || mbpStatus === MBP_STATUS.REQUESTED) {
        return (
          <>
            <button
              onClick={() => setShowSubmitPopup(true)}
              disabled={mbpLoading}
              className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2 disabled:opacity-50"
            >
              Submit MBP
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2 disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : "Save"}
            </button>
            <div className={`px-3 py-1 text-xs font-semibold rounded text-white ${
              mbpStatus === MBP_STATUS.REQUESTED ? "bg-yellow-500" : "bg-green-500"
            }`}>
              {mbpStatus}
            </div>
          </>
        );
      }

      return (
        <div className="px-3 py-1 text-xs font-semibold rounded text-white bg-gray-500">
          Disabled (Cannot Edit)
        </div>
      );
    }

    return null;
  };

  // ============================================
  // RENDER - LOADING
  // ============================================
  if (loading) {
    return (
      <div className="bg-Frostwhite min-h-screen flex flex-col">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        <SubNavbar3 />
        <div className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-darkblue1" />
            <p className="text-sm text-gray-600">Loading equipment data...</p>
          </div>
        </div>
      </div>
    );
  }

  // ============================================
  // RENDER - ERROR
  // ============================================
  if (error) {
    return (
      <div className="bg-Frostwhite min-h-screen flex flex-col">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        <SubNavbar3 />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <p className="text-red-600 mb-4">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-darkblue1 text-white text-sm hover:bg-opacity-90"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ============================================
  // RENDER - MAIN
  // ============================================
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Page Header */}
          <div className="flex items-center gap-3 mb-2">
            <ArrowLeft
              onClick={handleBack}
              size={24}
              className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
            />
            <h1 className="text-base font-semibold font-VolvoNovum text-darkblue1">
              {filterType} - {filterMake}
            </h1>
            <span className="ml-auto text-sm text-darkblue1 font-medium">
              {pdpYear}-{mode === "fill" ? "FILL" : "VIEW"}
            </span>
          </div>

          {/* Main Card - Quarterly Summary */}
          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm">
                <thead>
                  <tr className="bg-Dustyblue text-xs">
                    <th
            className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-left font-normal text-white cursor-pointer select-none"
          
          >
            <div className="flex items-center gap-1">
              {filterType} {filterMake}
             
            </div>
          </th>
                     {["Q1", "Q2", "Q3", "Q4"].map((q) => (
            <th key={q} colSpan={3} className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-normal text-white">
              {q}
            </th>
          ))}
        </tr>
                  <tr>
                <th
  className="border border-grey2 border-l-0 border-b-0 px-3 py-2 text-left font-normal   text-white bg-Dustyblue text-xs cursor-pointer select-none"
  onClick={() => handleSort("Equipment")}
>
  <div className="flex items-center gap-1" style={{ lineHeight: 1 }}>
    <span className="truncate">Equipment Type</span>

    <span className="flex-shrink-0">
      {sortKey === "Equipment" ? (
        sortOrder === "asc" ? (
          <ChevronUp className="w-3 h-3 text-white" />
        ) : (
          <ChevronDown className="w-3 h-3 text-white" />
        )
      ) : (
        <ChevronsUpDown className="w-3 h-3 text-white" />
      )}
    </span>
  </div>
</th>


                  {["Q1", "Q2", "Q3", "Q4"].map((q) =>
  ["MBP", "Projection", "Actuals"].map((field) => {
    const isLastCol = q === "Q4" && field === "Actuals";

    return (
      <th
        key={`${q}-${field}`}
        className={`border border-grey2 border-l-0 border-b-0 px-3 py-2 text-center text-xs font-semibold text-white bg-Dustyblue cursor-pointer select-none ${
          isLastCol ? "border-r-0" : ""
        }`}
        onClick={() => handleSort(`${q}-${field}`)}
      >
        <div className="flex items-center justify-center gap-1">
          {field}
          {sortKey === `${q}-${field}` &&
            (sortOrder === "asc" ? (
              <ChevronUp className="w-3 h-3 text-white" />
            ) : (
              <ChevronDown className="w-3 h-3 text-white" />
            ))}
        </div>
      </th>
    );
  })
)}
                  </tr>
                </thead>
                <tbody>
        {sortedData.length > 0 ? (
          sortedData.map((type) => (
            <tr key={type}>
              <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 font-medium text-black text-xs">{type}</td>

              {["Q1", "Q2", "Q3", "Q4"].map((q) =>
                ["MBP", "Projection", "Actuals"].map((field) => (
                  <td key={`${type}-${q}-${field}`} className="border border-grey2 border-t-0 border-l-0 px-3 py-1 last:border-r-0 text-xs text-center text-black">
                    {quarterlySummary[type]?.[q]?.[field] || "0"}
                  </td>
                ))
              )}
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan={13} className="border border-grey2 px-3 py-4 text-center text-xs text-gray-500">
              No equipment data available
            </td>
          </tr>
        )}
      </tbody>
              </table>
            </div>
          </div>

          {/* Controls Section */}
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 mb-2">
            {/* Left side - Dropdowns and Radio Buttons */}
            <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
              {/* Equipment Type Dropdown */}
              <div className="relative" ref={equipmentTypeRef}>
                <button
                  onClick={() => {
                    setEquipmentTypeDropdownOpen(!equipmentTypeDropdownOpen);
                    setEquipmentModelDropdownOpen(false);
                    setKamDropdownOpen(false);
                  }}
                  className="flex items-center justify-between min-w-[180px] px-4 py-1 text-xs text-black bg-white border border-black/60 hover:bg-gray-50"
                >
                  {selectedEquipmentType || "Select Type"}
                  <svg
                    className={`w-3 h-3 ml-2 transition-transform ${equipmentTypeDropdownOpen ? "rotate-180" : ""}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {equipmentTypeDropdownOpen && (
                  <div className="absolute z-10 min-w-[180px] mt-1 bg-white border border-black/60 shadow-lg max-h-60 overflow-y-auto">
                    {equipmentTypes.map((type) => (
                      <button
                        key={type}
                        onClick={() => {
                          setSelectedEquipmentType(type);
                          setSelectedEquipmentModel("All Models");
                          setEquipmentTypeDropdownOpen(false);
                        }}
                        className="block w-full px-4 py-1 text-xs text-left text-gray-700 hover:bg-lightBlue/50"
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Equipment Model Dropdown */}
              <div className="relative" ref={equipmentModelRef}>
                <button
                  onClick={() => {
                    setEquipmentModelDropdownOpen(!equipmentModelDropdownOpen);
                    setEquipmentTypeDropdownOpen(false);
                    setKamDropdownOpen(false);
                  }}
                  className="flex items-center justify-between min-w-[150px] px-4 py-1 text-xs text-black bg-white border border-black/60"
                >
                  {selectedEquipmentModel}
                  <svg
                    className={`w-3 h-3 ml-2 transition-transform ${equipmentModelDropdownOpen ? "rotate-180" : ""}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {equipmentModelDropdownOpen && (
                  <div className="absolute z-10 min-w-[150px] mt-1 bg-white border border-black/60 shadow-lg max-h-60 overflow-y-auto">
                    <button
                      onClick={() => {
                        setSelectedEquipmentModel("All Models");
                        setEquipmentModelDropdownOpen(false);
                      }}
                      className="block w-full px-4 py-1 text-xs text-left text-black hover:bg-lightBlue/50"
                    >
                      All Models
                    </button>
                    {availableModels.map((model) => (
                      <button
                        key={model}
                        onClick={() => {
                          setSelectedEquipmentModel(model);
                          setEquipmentModelDropdownOpen(false);
                        }}
                        className="block w-full px-4 py-1 text-xs text-left text-black hover:bg-lightBlue/50"
                      >
                        {model}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* KAM Dropdown */}
              <div className="relative" ref={kamTypeRef}>
                <button
                  onClick={() => {
                    setKamDropdownOpen(!kamDropdownOpen);
                    setEquipmentTypeDropdownOpen(false);
                    setEquipmentModelDropdownOpen(false);
                  }}
                  className="flex items-center justify-between min-w-[100px] px-4 py-1 text-xs text-black bg-white border border-black/60"
                >
                  {selectedKAMType}
                  <svg
                    className={`w-3 h-3 ml-2 transition-transform ${kamDropdownOpen ? "rotate-180" : ""}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {kamDropdownOpen && (
                  <div className="absolute z-10 min-w-[100px] mt-1 bg-white border border-black/60 shadow-lg">
                    <button
                      onClick={() => {
                        setSelectedKAMType("KAM");
                        setSelectedEquipmentModel("All Models");
                        setKamDropdownOpen(false);
                      }}
                      className="block w-full px-4 py-1 text-xs text-left text-black hover:bg-lightBlue/50"
                    >
                      KAM
                    </button>
                    <button
                      onClick={() => {
                        setSelectedKAMType("Retail");
                        setSelectedEquipmentModel("All Models");
                        setKamDropdownOpen(false);
                      }}
                      className="block w-full px-4 py-1 text-xs text-left text-gray-700 hover:bg-lightBlue/50"
                    >
                      Retail
                    </button>
                  </div>
                )}
              </div>

              {/* Radio Buttons */}
              <div className="flex items-center gap-4 flex-wrap">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="dataType"
                    checked={selectedDataType === "MBP"}
                    onChange={() => {
                      setSelectedDataType("MBP");
                      setSelectedEquipmentModel("All Models");
                    }}
                    className="w-4 h-4 text-black focus:ring-darkblue1"
                  />
                  <span className="text-xs font-medium text-black">MBP</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="dataType"
                    checked={selectedDataType === "Projection"}
                    onChange={() => {
                      setSelectedDataType("Projection");
                      setSelectedEquipmentModel("All Models");
                    }}
                    className="w-4 h-4 text-darkblue1 focus:ring-darkblue1"
                  />
                  <span className="text-xs font-medium text-black">Projection</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="dataType"
                    checked={selectedDataType === "Actuals"}
                    onChange={() => {
                      setSelectedDataType("Actuals");
                      setSelectedEquipmentModel("All Models");
                    }}
                    className="w-4 h-4 text-darkblue1 focus:ring-darkblue1"
                  />
                  <span className="text-xs font-medium text-black">Actuals</span>
                </label>
              </div>
            </div>

            {/* Right side - Buttons */}
            <div className="flex items-center gap-3 flex-wrap">
              {renderMBPButtons()}
            </div>
          </div>

          {/* Validation Warning (only for MBP) */}
          {showEnableMBP && !isEditable && (
            <div className="bg-red-50 border-l-4 border-red-400 p-2 mb-2">
              <div className="flex items-start gap-3">
                <svg className="w-4 h-4 text-red-600 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                    clipRule="evenodd"
                  />
                </svg>
                <p className="text-xs text-red-800 font-medium">
                  MBP is locked. {isDealer ? "Request edit from admin" : "Enable MBP to allow editing"}
                </p>
              </div>
            </div>
          )}

          {/* Detailed Table Section */}
          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
            <div className="text-darkblue1 px-4 py-1.5">
              <h3 className="text-xs font-semibold">
                {selectedDataType} {selectedKAMType}
                {selectedEquipmentModel !== "All Models" && ` - ${selectedEquipmentModel}`}
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-xs">
                <thead className="bg-Dustyblue text-white">
  <tr>
    <th
      className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-left font-semibold min-w-[130px] cursor-pointer select-none"
      onClick={() => handleSort("equipmentType")}
    >
      <div className="flex items-center gap-1">
        Equipment Type
        {sortKey !== "equipmentType" && <ChevronsUpDown className="w-3 h-3 text-white" />}
        {sortKey === "equipmentType" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "equipmentType" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-left font-semibold min-w-[130px] cursor-pointer select-none"
      onClick={() => handleSort("name")}
    >
      <div className="flex items-center gap-1">
        Equipment Model
        {sortKey === "name" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "name" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {showPDPTotal && (
      <th
        className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-semibold min-w-[100px] cursor-pointer select-none"
        onClick={() => handleSort("pdpTarget")}
      >
        <div className="flex items-center justify-center gap-1">
          PDP Target
          {sortKey === "pdpTarget" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
          {sortKey === "pdpTarget" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
        </div>
      </th>
    )}

    {showKAMTotal && (
      <th
        className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-semibold min-w-[100px] cursor-pointer select-none"
        onClick={() => handleSort("kamTotal")}
      >
        <div className="flex items-center justify-center gap-1">
          KAM Total
          {sortKey === "kamTotal" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
          {sortKey === "kamTotal" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
        </div>
      </th>
    )}

    {showRetailTotal && (
      <th
        className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-semibold min-w-[100px] cursor-pointer select-none"
        onClick={() => handleSort("retailTotal")}
      >
        <div className="flex items-center justify-center gap-1">
          Retail Total
          {sortKey === "retailTotal" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
          {sortKey === "retailTotal" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
        </div>
      </th>
    )}

    {months.map((month) => (
      <th
        key={month}
        className="border border-grey2 border-t-0 border-l-0 border-b-0 last:border-r-0 px-3 py-1.5 text-center font-semibold min-w-[60px] cursor-pointer select-none"
        onClick={() => handleSort(month)}
      >
        <div className="flex items-center justify-center gap-1">
          {month}
          {sortKey === month && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
          {sortKey === month && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
        </div>
      </th>
    ))}
  </tr>
</thead>

                <tbody>
                {sortedModels.length > 0 ? (
  sortedModels.map((model, index) => (
                      <tr key={model.id || index}>
                        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-xs text-black">
                          {model.equipmentType || selectedEquipmentType}
                        </td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-xs text-black">
                          {model.name}
                        </td>
                        {showPDPTotal && (
                          <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs text-black">
                            {model.pdpTarget || "0"}
                          </td>
                        )}
                        {showKAMTotal && (
                          <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs text-black">
                            {calculateModelTotal(model)}
                          </td>
                        )}
                        {showRetailTotal && (
                          <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs text-black">
                            {calculateModelTotal(model)}
                          </td>
                        )}
                        {months.map((month) => (
                          <td
                            key={month}
                            className="border border-grey2 border-t-0 border-l-0 last:border-r-0 px-2 py-1 text-center text-xs text-black"
                          >
                            {isEditable ? (
                              <input
  type="text"
  className="w-full text-center border bg-transparent focus:outline-none focus:ring-1 focus:ring-darkblue1 px-1 py-1 text-xs text-black"
  value={getMonthValue(model, month) || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleMonthInputChange(model.id, month, value);
    }
  }}
/>
                            ) : (
                              <span className="text-sm text-black">
                                {getMonthValue(model, month) || ""}
                              </span>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        colSpan={17}
                        className="border border-gray-400 px-3 py-4 text-center text-xs text-black"
                      >
                        No data available
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Submit MBP Popup */}
      <SubmitMBP
        isOpen={showSubmitPopup}
        onClose={() => setShowSubmitPopup(false)}
        onConfirm={handleSubmitMBPConfirm}
        title="Submit Monthly Business Plan"
        message={`Are you sure you want to submit MBP for ${filterType} - ${filterMake}? You cannot edit after submitting.`}
      />

      {/* Request MBP Edit Popup */}
      {showRequestPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-96 max-w-md mx-4">
            <h3 className="text-lg font-semibold text-darkblue1 mb-4">Request MBP Edit</h3>
            <p className="text-sm text-gray-600 mb-6">
              Send edit request to Administrator for <strong>{filterType} - {filterMake}</strong>?
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setShowRequestPopup(false)}
                disabled={requestLoading}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded transition disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleRequestMBPEditConfirm}
                disabled={requestLoading}
                className="px-4 py-2 text-sm font-medium text-white bg-darkblue1 hover:bg-white hover:text-darkblue1 border border-darkblue1 rounded transition disabled:opacity-50 flex items-center gap-2"
              >
                {requestLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Sending...
                  </>
                ) : (
                  "Send Request"
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FillEntriesEqup;