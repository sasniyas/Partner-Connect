import React, { useState, useEffect ,useMemo} from "react";
import { ChevronUp,ChevronDown,ChevronsUpDown } from "lucide-react";
const Tools = ({ mode, apiData, onSave, saving }) => {
  // Initialize state from API data or empty
  const [toolsData, setToolsData] = useState({});
  const [accessoriesData, setAccessoriesData] = useState({});
  const [pdpTargets, setPdpTargets] = useState({});
const [toolsSortKey, setToolsSortKey] = useState(null);
const [toolsSortOrder, setToolsSortOrder] = useState(null);

const [accessoriesSortKey, setAccessoriesSortKey] = useState(null);
const [accessoriesSortOrder, setAccessoriesSortOrder] = useState(null);

  // Sync with API data when it changes
  useEffect(() => {
    if (apiData) {
      if (apiData.toolsData && Object.keys(apiData.toolsData).length > 0) {
        setToolsData(apiData.toolsData);
      }
      if (apiData.accessoriesData && Object.keys(apiData.accessoriesData).length > 0) {
        setAccessoriesData(apiData.accessoriesData);
      }
      if (apiData.pdpTargets) {
        setPdpTargets(apiData.pdpTargets);
      }
    }
  }, [apiData]);

  const handleInputChange = (dataType, item, quarter, value) => {
    const setters = {
      tools: setToolsData,
      accessories: setAccessoriesData,
    };

    setters[dataType]((prev) => ({
      ...prev,
      [item]: {
        ...prev[item],
        [quarter]: value,
      },
    }));
  };

  const calculateActual = (data, item) => {
    const itemData = data[item];
    if (!itemData) return 0;
    return (
      (parseInt(itemData.Q1) || 0) +
      (parseInt(itemData.Q2) || 0) +
      (parseInt(itemData.Q3) || 0) +
      (parseInt(itemData.Q4) || 0)
    );
  };

  const calculateAchievement = (data, item) => {
    const itemData = data[item];
    if (!itemData) return 0;
    const actual = calculateActual(data, item);
    const target = parseInt(itemData.pdpTarget || pdpTargets[item]) || 1;
    return target > 0 ? ((actual / target) * 100).toFixed(2) : 0;
  };

  const handleSave = () => {
    if (onSave) {
      onSave({
        tools: toolsData,
        accessories: accessoriesData,
      });
    }
  };
const handleTableSort = (table, key) => {
  const setKey = table === "tools" ? setToolsSortKey : setAccessoriesSortKey;
  const setOrder = table === "tools" ? setToolsSortOrder : setAccessoriesSortOrder;
  const currentKey = table === "tools" ? toolsSortKey : accessoriesSortKey;
  const currentOrder = table === "tools" ? toolsSortOrder : accessoriesSortOrder;

  if (currentKey === key) {
    if (currentOrder === "asc") setOrder("desc");
    else if (currentOrder === "desc") {
      setKey(null);
      setOrder(null);
    } else setOrder("asc");
  } else {
    setKey(key);
    setOrder("asc");
  }
};

  // Check if data exists
  const hasTools = Object.keys(toolsData).length > 0;
  const hasAccessories = Object.keys(accessoriesData).length > 0;
const sortedTools = useMemo(() => {
  if (!toolsSortKey || !toolsSortOrder) return Object.keys(toolsData);

  return [...Object.keys(toolsData)].sort((a, b) => {
    let valA, valB;

    switch (toolsSortKey) {
      case "name":
        valA = a;
        valB = b;
        break;
      case "actual":
        valA = calculateActual(toolsData, a);
        valB = calculateActual(toolsData, b);
        break;
      case "achievement":
        valA = calculateAchievement(toolsData, a);
        valB = calculateAchievement(toolsData, b);
        break;
      default:
        valA = toolsData[a][toolsSortKey];
        valB = toolsData[b][toolsSortKey];
    }

    if (!isNaN(valA) && !isNaN(valB)) {
      return toolsSortOrder === "asc" ? valA - valB : valB - valA;
    }

    return toolsSortOrder === "asc"
      ? valA.toString().localeCompare(valB.toString())
      : valB.toString().localeCompare(valA.toString());
  });
}, [toolsData, toolsSortKey, toolsSortOrder]);

const sortedAccessories = useMemo(() => {
  if (!accessoriesSortKey || !accessoriesSortOrder)
    return Object.keys(accessoriesData);

  return [...Object.keys(accessoriesData)].sort((a, b) => {
    let valA, valB;

    switch (accessoriesSortKey) {
      case "name":
        valA = a;
        valB = b;
        break;
      case "actual":
        valA = calculateActual(accessoriesData, a);
        valB = calculateActual(accessoriesData, b);
        break;
      case "achievement":
        valA = calculateAchievement(accessoriesData, a);
        valB = calculateAchievement(accessoriesData, b);
        break;
      default:
        valA = accessoriesData[a][accessoriesSortKey];
        valB = accessoriesData[b][accessoriesSortKey];
    }

    if (!isNaN(valA) && !isNaN(valB)) {
      return accessoriesSortOrder === "asc" ? valA - valB : valB - valA;
    }

    return accessoriesSortOrder === "asc"
      ? valA.toString().localeCompare(valB.toString())
      : valB.toString().localeCompare(valA.toString());
  });
}, [accessoriesData, accessoriesSortKey, accessoriesSortOrder]);


  if (!hasTools && !hasAccessories) {
    return (
      <div className="bg-white shadow-md border border-Dustyblue p-8 text-center">
        <p className="text-gray-500 italic">No tools & accessories data available</p>
      </div>
    );
  }

  // Desktop Table Render
  const renderTable = (title, data, dataType) => {
    if (Object.keys(data).length === 0) return null;

    return (
      <>
        {/* Desktop Table */}
        <div className="hidden lg:block bg-white shadow-md border border-Dustyblue overflow-hidden mb-6">
          <div className="overflow-x-auto">
            <table className="w-full table-fixed" style={{ borderCollapse: 'collapse' }}>
              <colgroup>
                <col className="w-[20%]" />
                <col className="w-[10%]" />
                <col className="w-[10%]" />
                <col className="w-[10%]" />
                <col className="w-[10%]" />
                <col className="w-[15%]" />
                <col className="w-[15%]" />
                <col className="w-[10%]" />
              </colgroup>
       <thead>
  <tr className="bg-Dustyblue text-white">

    {/* Name */}
    <th
      onClick={() => handleTableSort(dataType, "name")}
      className="px-3 py-1.5 text-left text-xs font-medium cursor-pointer select-none border border-grey2 border-t-0 border-l-0 border-b-0"
    >
      <div className="flex gap-1">
        {title}
         {/* Default (not sorted) */}
    {((dataType === "tools" ? toolsSortKey : accessoriesSortKey) !== "name") && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
        {((dataType === "tools" && toolsSortKey === "name") ||
          (dataType === "accessories" && accessoriesSortKey === "name")) &&
          (dataType === "tools" ? toolsSortOrder : accessoriesSortOrder) === "asc" && (
            <ChevronUp className="w-3 h-3" />
        )}
        {((dataType === "tools" && toolsSortKey === "name") ||
          (dataType === "accessories" && accessoriesSortKey === "name")) &&
          (dataType === "tools" ? toolsSortOrder : accessoriesSortOrder) === "desc" && (
            <ChevronDown className="w-3 h-3" />
        )}
      </div>
    </th>

    {/* Q1–Q4 */}
    {["Q1", "Q2", "Q3", "Q4"].map((q) => (
      <th
        key={q}
        onClick={() => handleTableSort(dataType, q)}
        className="px-3 py-1.5 text-center text-xs font-medium cursor-pointer select-none border border-grey2 border-t-0 border-l-0 border-b-0"
      >
        <div className="flex items-center justify-center gap-1">
          {q}
          {((dataType === "tools" ? toolsSortKey : accessoriesSortKey) === q) &&
           (dataType === "tools" ? toolsSortOrder : accessoriesSortOrder) === "asc" && (
             <ChevronUp className="w-3 h-3" />
          )}
          {((dataType === "tools" ? toolsSortKey : accessoriesSortKey) === q) &&
           (dataType === "tools" ? toolsSortOrder : accessoriesSortOrder) === "desc" && (
             <ChevronDown className="w-3 h-3" />
          )}
        </div>
      </th>
    ))}

    {/* Actual */}
    <th
      onClick={() => handleTableSort(dataType, "actual")}
      className="px-3 py-1.5 text-center text-xs font-medium cursor-pointer select-none border border-grey2 border-t-0 border-l-0 border-b-0"
    >
      <div className="flex items-center justify-center gap-1">
        Actual
        {((dataType === "tools" && toolsSortKey === "actual") ||
         (dataType === "accessories" && accessoriesSortKey === "actual")) &&
         (dataType === "tools" ? toolsSortOrder : accessoriesSortOrder) === "asc" && (
           <ChevronUp className="w-3 h-3" />
        )}
        {((dataType === "tools" && toolsSortKey === "actual") ||
         (dataType === "accessories" && accessoriesSortKey === "actual")) &&
         (dataType === "tools" ? toolsSortOrder : accessoriesSortOrder) === "desc" && (
           <ChevronDown className="w-3 h-3" />
        )}
      </div>
    </th>

    {/* PDP Target */}
    <th
      onClick={() => handleTableSort(dataType, "pdpTarget")}
      className="px-3 py-1.5 text-center text-xs font-medium cursor-pointer select-none border border-grey2 border-t-0 border-l-0 border-b-0"
    >
      <div className="flex items-center justify-center gap-1">
        PDP Target
        {((dataType === "tools" && toolsSortKey === "pdpTarget") ||
         (dataType === "accessories" && accessoriesSortKey === "pdpTarget")) &&
         (dataType === "tools" ? toolsSortOrder : accessoriesSortOrder) === "asc" && (
           <ChevronUp className="w-3 h-3" />
        )}
        {((dataType === "tools" && toolsSortKey === "pdpTarget") ||
         (dataType === "accessories" && accessoriesSortKey === "pdpTarget")) &&
         (dataType === "tools" ? toolsSortOrder : accessoriesSortOrder) === "desc" && (
           <ChevronDown className="w-3 h-3" />
        )}
      </div>
    </th>

    {/* Achievement % */}
    <th
      onClick={() => handleTableSort(dataType, "achievement")}
      className="px-3 py-1.5 text-center text-xs font-medium cursor-pointer select-none border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0"
    >
      <div className="flex items-center justify-center gap-1">
        Achievement %
        {((dataType === "tools" && toolsSortKey === "achievement") ||
         (dataType === "accessories" && accessoriesSortKey === "achievement")) &&
         (dataType === "tools" ? toolsSortOrder : accessoriesSortOrder) === "asc" && (
           <ChevronUp className="w-3 h-3" />
        )}
        {((dataType === "tools" && toolsSortKey === "achievement") ||
         (dataType === "accessories" && accessoriesSortKey === "achievement")) &&
         (dataType === "tools" ? toolsSortOrder : accessoriesSortOrder) === "desc" && (
           <ChevronDown className="w-3 h-3" />
        )}
      </div>
    </th>

  </tr>
</thead>


              <tbody>
  {(dataType === "tools" ? sortedTools : sortedAccessories).map((item) => {
                  const qSum = calculateActual(data, item);

                  return (
                    <tr key={item}>
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-black text-left text-xs">
                        {item}
                      </td>

                      {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
                        <td
                          key={quarter}
                          className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs"
                        >
                          {mode === "fill" ? (
                           <input
  type="text"
  value={data[item][quarter] || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleInputChange(dataType, item, quarter, value);
    }
  }}
  className="w-full text-center border border-gray-300 px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-darkblue1"
  required
/>
                          ) : (
                            data[item][quarter] || "-"
                          )}
                        </td>
                      ))}

                      {/* Actual column */}
                      <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-center text-xs">
                        {mode === "fill" ? (
                          <input
                            type="number"
                            value={qSum}
                            readOnly
                            className="w-full text-center border border-gray-300 px-2 py-1 text-xs bg-gray-100 cursor-not-allowed"
                          />
                        ) : (
                          qSum
                        )}
                      </td>

                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs">
                        {data[item]?.pdpTarget || pdpTargets[item] || "-"}
                      </td>

                      <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1 text-center text-xs">
                        {calculateAchievement(data, item)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Mobile/Tablet Cards */}
        <div className="lg:hidden mb-6">
          <h3 className="text-base sm:text-lg font-semibold text-darkblue1 mb-3 px-2">
            {title}
          </h3>
          <div className="space-y-3">
            {Object.keys(data).map((item) => {
              const qSum = calculateActual(data, item);

              return (
                <div
                  key={item}
                  className="bg-white shadow-md border-2 border-Dustyblue p-4"
                >
                  <h4 className="font-semibold text-darkblue1 mb-3 pb-2 border-b-2 border-Dustyblue text-sm">
                    {item}
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
                      <div key={quarter} className="flex justify-between">
                        <span className="font-medium text-gray-600">{quarter}:</span>
                        {mode === "fill" ? (
                          <input
                            type="number"
                            value={data[item][quarter] || ""}
                            onChange={(e) => handleInputChange(dataType, item, quarter, e.target.value)}
                            className="w-20 text-center border border-gray-300 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-darkblue1"
                          />
                        ) : (
                          <span className="text-gray-800">{data[item][quarter] || "-"}</span>
                        )}
                      </div>
                    ))}
                    <div className="flex justify-between col-span-2">
                      <span className="font-medium text-gray-600">Actual:</span>
                      <span className="text-gray-800">{qSum}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium text-gray-600">PDP Target:</span>
                      <span className="text-gray-800">{data[item]?.pdpTarget || pdpTargets[item] || "-"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium text-gray-600">Achievement:</span>
                      <span className="font-semibold text-darkblue1">
                        {calculateAchievement(data, item)}%
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </>
    );
  };

  // Get all items for PDP Target card header
  const allToolItems = Object.keys(toolsData);
  const allAccessoryItems = Object.keys(accessoriesData);
  const allItems = [...allToolItems, ...allAccessoryItems];

  return (
    <div>
      {/* Single Combined PDP Target Card for ALL Tools and Accessories */}
      {allItems.length > 0 && (
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
          <div className="bg-Dustyblue text-white">
            <div className="grid text-center font-medium text-xs"
                 style={{ gridTemplateColumns: `repeat(${allItems.length + 1}, minmax(0, 1fr))` }}>
              <div className="py-1.5 px-2 border border-grey2 border-t-0 border-l-0 border-b-0">PDP Target</div>
              {allItems.map((item, idx) => (
                <div key={item} 
                     className={`py-1.5 px-2 border border-grey2 border-t-0 border-l-0 border-b-0 ${idx === allItems.length - 1 ? 'border-r-0' : ''}`}>
                  {item}
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white">
            <div className="grid text-center text-normal text-xs"
                 style={{ gridTemplateColumns: `repeat(${allItems.length + 1}, minmax(0, 1fr))` }}>
              <div className="py-1 border border-grey2 border-t-0 border-l-0"></div>
              {allToolItems.map((tool) => (
                <div key={`${tool}-tools`} className="py-1 px-2 border border-grey2 border-t-0 border-l-0">
                  {toolsData[tool]?.pdpTarget || pdpTargets[tool] || "-"}
                </div>
              ))}
              {allAccessoryItems.map((accessory, idx) => (
                <div key={`${accessory}-acc`} 
                     className={`py-1 px-2 border border-grey2 border-t-0 border-l-0 ${idx === allAccessoryItems.length - 1 ? 'border-r-0' : ''}`}>
                  {accessoriesData[accessory]?.pdpTarget || pdpTargets[accessory] || "-"}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tools Table */}
      {hasTools && renderTable("Tools", toolsData, "tools")}

      {/* Accessories Table */}
      {hasAccessories && renderTable("Accessories", accessoriesData, "accessories")}

      {/* Save Button */}
      {mode === "fill" && (
        <div className="flex justify-end mb-6">
          <button
            onClick={handleSave}
            disabled={saving}
            className="bg-darkblue1 text-white px-8 py-1.5 font-medium text-xs hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition w-full sm:w-auto disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? "Saving..." : "Save"}
          </button>
        </div>
      )}
    </div>
  );
};

export default Tools;