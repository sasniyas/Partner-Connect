import React, { useState } from "react";

const ViewAllocation = () => {
  // Sample allocation data (read-only)
  const allocationData = {
    // Add your allocation data structure here
    // Example structure:
    categories: [
      { name: "Category 1", value: "100" },
      { name: "Category 2", value: "200" },
      { name: "Category 3", value: "150" },
    ]
  };

  return (
    <div>
      <div className="bg-white  shadow-md border border-Dustyblue p-6 mb-2">
        <h3 className="text-sm font-semibold text-darkblue1 mb-2">
          Allocation - View Only
        </h3>
        <p className="text-gray-600 mb-2">
          Allocation data is displayed here in view-only mode.
        </p>
        
        {/* Example table for viewing allocation data */}
        <div className="overflow-x-auto border border-Dustyblue">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-Dustyblue text-white">
                <th className="border border-grey2 border-t-0 border-l-0 border-b-0  px-4 py-1.5 text-left text-xs">Category</th>
                <th className="border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0  px-4 py-1.5 text-left text-xs">Value</th>
              </tr>
            </thead>
            <tbody>
              {allocationData.categories.map((item, index) => (
                <tr key={index} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                  <td className="border border-grey2 border-t-0 border-l-0 px-4 py-1 text-xs">{item.name}</td>
                  <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-4 py-1 text-xs">{item.value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ViewAllocation;