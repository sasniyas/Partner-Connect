import React, { useState, useEffect,useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ArrowLeft,ChevronDown,ChevronUp,ChevronsUpDown,ArrowUp,ArrowDown } from "lucide-react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { toast } from "react-toastify";
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation";
// Import child tab components
import Competence from "./Competence";
import VehiclesTab from "./VehiclesTab";
import MachinePopulation from "./MachinePopulation";
import Tools from "./Tools";
import EquipmentsAttachments from "./EquipmentsAttachments";
import UptimeParts from "./UptimeParts";
import Allocation from "./Allocation";
import ViewAndUpload from "./ViewAndUpload";
import { useMemo } from "react";
// Import service functions - Infrastructure
import {
  getDealerInvestmentInfrastructureByDealerInvestmentId,
  updateMultipleDealerInvestmentInfrastructure,
  transformFacilityData,
  transformVehiclesData,
  transformToolsData,
  prepareDataForUpdate,
  FACILITY_TYPES,
} from "../../../services/dealerInvestment/dealerInvestmentInfrastructure.service";

// Import service functions - Competence
import {
  getDealerInvestmentCompetenceByDealerInvestmentId,
  updateMultipleDealerInvestmentCompetence,
  transformCompetenceData,
  prepareCompetenceDataForUpdate,
} from "../../../services/dealerInvestment/dealerInvestmentCompetences.service";

// Import service functions - Machine Population
import {
  getDealerInvestmentMachinePopulationByDealerInvestmentId,
  updateMultipleDealerInvestmentMachinePopulation,
  transformMachinePopulationData,
  prepareMachinePopulationDataForUpdate,
  getActiveMachines,
} from "../../../services/dealerInvestment/dealerInvestmentMachinePopulation.service";

const FillEntries = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  // Get investment data and mode from navigation state
  // Also get filter values passed back from FillEntriesEqup
  const { 
    investment, 
    mode, 
    selectedMake: passedMake, 
    selectedType: passedType 
  } = location.state || {};
  
  // Debug logging
  useEffect(() => {
    console.log("FillEntries location.state:", location.state);
    console.log("FillEntries passedMake:", passedMake, "passedType:", passedType);
  }, [location.state, passedMake, passedType]);
  
  const isFill = mode === "fill";
  const isView = mode === "view";
  const tableContainerRef = useRef(null)
  // Role detection
  const detectedRole = location.pathname.includes('/user/') ? 'user' : 'admin';
  const effectiveRole = detectedRole;
  const isAdmin = false; // effectiveRole === "admin";
const formRef=useRef (null)

  // ============================================
  // STATE MANAGEMENT
  // ============================================
  
  // Tab states (persisted in sessionStorage)
  const [activeTab, setActiveTab] = useState(() => {
    const savedTab = sessionStorage.getItem('fillEntries_activeTab');
    return savedTab || "Infrastructure";
  });
  
  const [activeSubTab, setActiveSubTab] = useState(() => {
    const savedSubTab = sessionStorage.getItem('fillEntries_activeSubTab');
    return location.state?.activeSubTab || savedSubTab || "Facility";
  });
  
  const [menuOpen, setMenuOpen] = useState(false);
  const [showUploadPopup, setShowUploadPopup] = useState(false);

  // API Data states
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [rawApiData, setRawApiData] = useState([]);

  // Transformed data for each tab
  const [facilityData, setFacilityData] = useState({ tableData: {}, pdpTargets: {} });
  const [vehiclesData, setVehiclesData] = useState({ tableData: {}, pdpTargets: {} });
  const [toolsData, setToolsData] = useState({ toolsData: {}, accessoriesData: {}, pdpTargets: {} });
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};



  // Competence data includes groupedData for category tables
  const [competenceData, setCompetenceData] = useState({ 
    tableData: {}, 
    pdpTargets: { SCL: "0", TCL: "0", CCL: "0", LCL: "0", Other: "0" }, 
    groupedData: { SCL: {}, TCL: {}, CCL: {}, LCL: {}, Other: {} } 
  });
  const [machinePopulationData, setMachinePopulationData] = useState({ tableData: {}, pdpTargets: {} });

  // ============================================
  // FETCH DATA FROM API
  // ============================================
  const fetchInfrastructureData = async () => {
    if (!investment?.id) {
      setError("No dealer investment ID provided");
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Fetch Infrastructure data
      const infraResponse = await getDealerInvestmentInfrastructureByDealerInvestmentId(investment.id);

      if (infraResponse?.status && infraResponse?.data) {
        const data = infraResponse.data;
        setRawApiData(data);

        // Transform data for each tab
        setFacilityData(transformFacilityData(data));
        setVehiclesData(transformVehiclesData(data));
        setToolsData(transformToolsData(data));

        console.log("Infrastructure data loaded:", {
          total: data.length,
          facilityCount: Object.keys(transformFacilityData(data).tableData).length,
          vehiclesCount: Object.keys(transformVehiclesData(data).tableData).length,
        });
      } else {
        setRawApiData([]);
      }

      // Fetch Competence data (separate API)
      const competenceResponse = await getDealerInvestmentCompetenceByDealerInvestmentId(investment.id);

      if (competenceResponse?.status && competenceResponse?.data) {
        const compData = competenceResponse.data;
        const transformedCompetence = transformCompetenceData(compData);
        setCompetenceData(transformedCompetence);

        console.log("Competence data loaded:", {
          total: compData.length,
          groupedData: transformedCompetence.groupedData,
          pdpTargets: transformedCompetence.pdpTargets,
        });
      }

      // Fetch Machine Population data (separate API)
      const machinePopResponse = await getDealerInvestmentMachinePopulationByDealerInvestmentId(investment.id);

      if (machinePopResponse?.status && machinePopResponse?.data) {
        const machineData = machinePopResponse.data;
        
        // Get pdpId from first record or from investment
        const pdpId = machineData[0]?.pdpId || investment.pdpId;
        
        // Fetch PDP Targets from getActiveMachines API
        let pdpTargetsByMake = {};
        if (pdpId) {
          try {
            const activeMachinesResponse = await getActiveMachines(pdpId);
            if (activeMachinesResponse?.status && activeMachinesResponse?.data) {
              pdpTargetsByMake = activeMachinesResponse.data;
              console.log("PDP Targets loaded:", pdpTargetsByMake);
            }
          } catch (targetErr) {
            console.warn("Could not fetch PDP targets:", targetErr);
          }
        }
        
        // Transform with PDP targets
        setMachinePopulationData(transformMachinePopulationData(machineData, pdpTargetsByMake));

        console.log("Machine Population data loaded:", {
          total: machineData.length,
          machineCount: Object.keys(transformMachinePopulationData(machineData, pdpTargetsByMake).tableData).length,
        });
      }
    } catch (err) {
      console.error("Error fetching data:", err);
      setError("Failed to load data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Fetch on mount
  useEffect(() => {
    fetchInfrastructureData();
  }, [investment?.id]);

  // ============================================
  // SESSION STORAGE FOR TABS
  // ============================================
  useEffect(() => {
    sessionStorage.setItem('fillEntries_activeTab', activeTab);
  }, [activeTab]);

  useEffect(() => {
    sessionStorage.setItem('fillEntries_activeSubTab', activeSubTab);
  }, [activeSubTab]);

  // Update activeSubTab when location.state changes
  useEffect(() => {
    if (location.state?.activeSubTab) {
      setActiveSubTab(location.state.activeSubTab);
      
      const infrastructureTabs = ["Facility", "Competence", "Vehicles", "Machine & Population", "Tools"];
      const monthlyBusinessPlanTabs = ["Equipments & Attachments", "Uptime & Parts", "Allocation"];
      
      if (infrastructureTabs.includes(location.state.activeSubTab)) {
        setActiveTab("Infrastructure");
      } else if (monthlyBusinessPlanTabs.includes(location.state.activeSubTab)) {
        setActiveTab("Monthly business Plan");
      }
      
      console.log("Tab updated from navigation:", {
        activeSubTab: location.state.activeSubTab,
        selectedMake: location.state.selectedMake,
        selectedType: location.state.selectedType,
      });
    }
  }, [location.state, location.key]); // location.key ensures this runs on each navigation

  // ============================================
  // TAB HANDLERS
  // ============================================
  const handleMainTabClick = (tab) => {
    setActiveTab(tab);
    
    if (tab === "Infrastructure") {
      setActiveSubTab("Facility");
    } else if (tab === "Monthly business Plan") {
      setActiveSubTab("Equipments & Attachments");
    }
  };

  const getSubTabs = () => {
    if (activeTab === "Infrastructure") {
      return ["Facility", "Competence", "Vehicles", "Machine & Population", "Tools"];
    } else if (activeTab === "Monthly business Plan") {
      return ["Equipments & Attachments", "Uptime & Parts", "Allocation"];
    }
    return [];
  };

  // ============================================
  // NAVIGATION HANDLERS
  // ============================================
  const handleBack = () => {
    navigate("/DEALERINVESTMENT/ViewDealerInvestment/ViewDealerhome");
  };

  // ============================================
  // SAVE HANDLERS
  // ============================================
  const handleSaveFacility = async (tableData) => {
    setSaving(true);
    try {
      const rows = prepareDataForUpdate(tableData);
      const response = await updateMultipleDealerInvestmentInfrastructure(rows);
      
      if (response?.status) {
        toast.success("Facility data saved successfully!");
        // Update local state
        setFacilityData(prev => ({ ...prev, tableData }));
      } else {
        toast.error(response?.message || "Failed to save facility data");
      }
    } catch (error) {
      console.error("Error saving facility data:", error);
      toast.error("Failed to save facility data");
    } finally {
      setSaving(false);
    }
  };

  const handleSaveVehicles = async (tableData) => {
    setSaving(true);
    try {
      const rows = prepareDataForUpdate(tableData);
      const response = await updateMultipleDealerInvestmentInfrastructure(rows);
      
      if (response?.status) {
        toast.success("Vehicles data saved successfully!");
        setVehiclesData(prev => ({ ...prev, tableData }));
      } else {
        toast.error(response?.message || "Failed to save vehicles data");
      }
    } catch (error) {
      console.error("Error saving vehicles data:", error);
      toast.error("Failed to save vehicles data");
    } finally {
      setSaving(false);
    }
  };

  const handleSaveTools = async (data) => {
    setSaving(true);
    try {
      const toolsRows = prepareDataForUpdate(data.tools);
      const accessoriesRows = prepareDataForUpdate(data.accessories);
      const allRows = [...toolsRows, ...accessoriesRows];
      
      const response = await updateMultipleDealerInvestmentInfrastructure(allRows);
      
      if (response?.status) {
        toast.success("Tools & Accessories data saved successfully!");
        setToolsData(prev => ({
          ...prev,
          toolsData: data.tools,
          accessoriesData: data.accessories,
        }));
      } else {
        toast.error(response?.message || "Failed to save tools data");
      }
    } catch (error) {
      console.error("Error saving tools data:", error);
      toast.error("Failed to save tools data");
    } finally {
      setSaving(false);
    }
  };

  // Competence save handler - receives groupedData from Competence component
  const handleSaveCompetence = async (groupedData) => {
    setSaving(true);
    try {
      const rows = prepareCompetenceDataForUpdate(groupedData);
      const response = await updateMultipleDealerInvestmentCompetence(rows);
      
      if (response?.status) {
        toast.success("Competence data saved successfully!");
        setCompetenceData(prev => ({ ...prev, groupedData }));
      } else {
        toast.error(response?.message || "Failed to save competence data");
      }
    } catch (error) {
      console.error("Error saving competence data:", error);
      toast.error("Failed to save competence data");
    } finally {
      setSaving(false);
    }
  };

  const handleSaveMachinePopulation = async (tableData) => {
    setSaving(true);
    try {
      const rows = prepareMachinePopulationDataForUpdate(tableData);
      const response = await updateMultipleDealerInvestmentMachinePopulation(rows);
      
      if (response?.status) {
        toast.success("Machine & Population data saved successfully!");
        setMachinePopulationData(prev => ({ ...prev, tableData }));
      } else {
        toast.error(response?.message || "Failed to save machine data");
      }
    } catch (error) {
      console.error("Error saving machine data:", error);
      toast.error("Failed to save machine data");
    } finally {
      setSaving(false);
    }
  };
const sortedData = useMemo(() => {
  const tableArray = Object.entries(facilityData.tableData).map(
    ([facility, value]) => {
      const ytdActual =
        (parseInt(value.Q1) || 0) +
        (parseInt(value.Q2) || 0) +
        (parseInt(value.Q3) || 0) +
        (parseInt(value.Q4) || 0);

      const achievement =
        value.pdpTarget && Number(value.pdpTarget) > 0
          ? (ytdActual / Number(value.pdpTarget)) * 100
          : 0;

      return {
        facility,
        ...value,
        ytdActual,
        achievement,
      };
    }
  );

  if (!sortKey || !sortOrder) return tableArray;

  return [...tableArray].sort((a, b) => {
    let valA = a[sortKey];
    let valB = b[sortKey];

    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    valA = valA?.toString().toLowerCase() || "";
    valB = valB?.toString().toLowerCase() || "";

    return sortOrder === "asc"
      ? valA.localeCompare(valB)
      : valB.localeCompare(valA);
  });
}, [facilityData.tableData, sortKey, sortOrder]);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
useKeyboardNavigation({
        containerRef: formRef,
        onSubmit: () => handleSaveFacility(facilityData.tableData),
        onCancel: () => {},
    });
  // ============================================
  // RENDER FACILITY TAB (Inline)
  // ============================================
  const renderFacilityTab = () => {
    
    const { tableData, pdpTargets } = facilityData;
    const handleInputChange = (facility, quarter, value) => {
      setFacilityData((prev) => ({
        ...prev,
        tableData: {
          ...prev.tableData,
          [facility]: {
            ...prev.tableData[facility],
            [quarter]: value,
          },
        },
      }));
    };

    const calculateYTDActual = (facility) => {
      const data = tableData[facility];
      if (!data) return 0;
      return (
        (parseInt(data.Q1) || 0) +
        (parseInt(data.Q2) || 0) +
        (parseInt(data.Q3) || 0) +
        (parseInt(data.Q4) || 0)
      );
    };

    const calculateAchievement = (facility) => {
      const data = tableData[facility];
      if (!data) return 0;
      const ytdActual = calculateYTDActual(facility);
      const target = parseInt(data.pdpTarget) || 1;
      return target > 0 ? ((ytdActual / target) * 100).toFixed(2) : 0;
    };

    const handleSave = () => {
      handleSaveFacility(tableData);
    };
   

        // Check if data exists
    if (Object.keys(tableData).length === 0) {
      
      return (
        <div className="bg-white shadow-md border border-Dustyblue p-8 text-center">
          <p className="text-gray-500 italic">No facility data available</p>
        </div>
      );
    }

    return (
      <>
        {/* PDP Target Card */}
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
          <div className="bg-Dustyblue text-white">
            <div className={`grid text-center font-medium  text-xs`} 
                 style={{ gridTemplateColumns: `repeat(${Object.keys(tableData).length + 1}, minmax(0, 1fr))` }}>
              <div className="py-1.5 px-2 border border-grey2 border-t-0 border-l-0 border-b-0 ">PDP Target</div>
              {Object.keys(tableData).map((facility, idx) => (
                <div key={facility} 
                     className={`py-1.5 px-2 border border-grey2 border-t-0 border-l-0 border-b-0 ${idx === Object.keys(tableData).length - 1 ? 'border-r-0' : ''}`}>
                  {facility}
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white">
            <div className={`grid text-center text-xs font-normal`}
                 style={{ gridTemplateColumns: `repeat(${Object.keys(tableData).length + 1}, minmax(0, 1fr))` }}>
              <div className="py-1 border border-grey2 border-t-0 border-l-0"></div>
              {Object.keys(tableData).map((facility, idx) => (
                <div key={facility} 
                     className={`py-1 px-2 border border-grey2 border-t-0 border-l-0 ${idx === Object.keys(tableData).length - 1 ? 'border-r-0' : ''}`}>
                  {tableData[facility]?.pdpTarget || "-"}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Desktop Table */}
        <div 
        ref={formRef}
        className="hidden lg:block bg-white shadow-md border border-Dustyblue overflow-hidden mb-4">
 <div
            ref={tableContainerRef}
            className="w-full overflow-x-auto overflow-y-auto max-h-[calc(100vh-200px)] scrollbar-hide"
            style={{ 
              scrollbarWidth: 'none',
              msOverflowStyle: 'none',
              WebkitOverflowScrolling: 'touch'
            }}
              onScroll={handleTableScroll}

          >            <table className="w-full border-collapse table-fixed">
              <thead className="bg-Dustyblue text-white sticky top-0 z-10 text-xs">
  <tr className="bg-Dustyblue text-white text-xs font-medium">
    <th
      className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-normal w-[12.5%] cursor-pointer select-none"
      onClick={() => handleSort("facility")}
    >
      <div className="flex items-center gap-1">
        Facility
        {sortKey !== "facility" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
        {sortKey === "facility" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "facility" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {["Q1", "Q2", "Q3", "Q4"].map((q) => (
      <th
        key={q}
        className="border border-grey2 border-t-0 border-b-0 px-3 py-1.5 text-center font-normal cursor-pointer select-none"
        onClick={() => handleSort(q)}
      >
        {q}
        {sortKey === q && sortOrder === "asc" && <ChevronUp className="w-3 h-3 inline ml-1" />}
        {sortKey === q && sortOrder === "desc" && <ChevronDown className="w-3 h-3 inline ml-1" />}
      </th>
    ))}

  {["YTD Actual", "PDP Target", "Achievement %"].map((key) => (
  <th
    key={key}
    className="border border-grey2 border-t-0 border-b-0 last:border-r-0 px-3 py-1.5 text-center cursor-pointer font-normal select-none"
    onClick={() => handleSort(key)}
  >
    {key}
    {sortKey === key && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3 inline ml-1" />
    )}
    {sortKey === key && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3 inline ml-1" />
    )}
  </th>
))}
  </tr>
</thead>

              <tbody>
               {sortedData.map((row, index) => {
  const { facility } = row;

                  const qSum = calculateYTDActual(facility);

                  return (
                    <tr key={facility} className={index % 2 === 0 ? "" : ""}>
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 font-normal text-black text-xs">
                        {facility}
                      </td>

                      {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
                        <td key={quarter} className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center   text-xs">
                          {isFill ? (
                           <input
  type="text"
  value={tableData[facility][quarter] || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleInputChange(facility, quarter, value);
    }
  }}
  className="w-24 text-center border border-gray-300 px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-darkblue1"
/>
                          ) : (
                            <span className="text-xs">{tableData[facility][quarter] || "-"}</span>
                          )}
                        </td>
                      ))}

                      <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-center text-xs">
                        {isFill ? (
                          <input
                            type="number"
                            value={qSum}
                            readOnly
                            className="w-full text-center border border-gray-300 px-2 py-1 text-xs bg-gray-100 cursor-not-allowed"
                          />
                        ) : (
                          <span className="text-xs">{qSum}</span>
                        )}
                      </td>

                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs">
                        {tableData[facility]?.pdpTarget || "-"}
                      </td>

                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center font-normal text-xs">
                        {calculateAchievement(facility)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {showScrollButtons && (
<div
  className={`fixed right-6 z-40 pointer-events-auto animate-fade-in
    ${mode === "fill" ? "bottom-20" : "bottom-10"}
  `}
>              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}


        </div>

        {/* Mobile/Tablet Cards */}
        <div className="lg:hidden space-y-4 mb-6">
          {Object.keys(tableData).map((facility) => {
            const qSum = calculateYTDActual(facility);

            return (
              <div key={facility} className="bg-white shadow-md border-2 border-Dustyblue p-4">
                <h3 className="font-semibold text-darkblue1 mb-3 pb-2 border-b-2 border-Dustyblue">
                  {facility}
                </h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
                    <div key={quarter} className="flex justify-between">
                      <span className="font-medium text-gray-600">{quarter}:</span>
                      {isFill ? (
                      <input
  type="text"
  value={tableData[facility][quarter] || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleInputChange(facility, quarter, value);
    }
  }}
  className="w-20 text-center border border-gray-300 px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-darkblue1"
/>
                      ) : (
                        <span className="text-gray-800">{tableData[facility][quarter] || "-"}</span>
                      )}
                    </div>
                  ))}

                  <div className="flex justify-between col-span-2">
                    <span className="font-medium text-gray-600">YTD Actual:</span>
                    <span className="text-gray-800">{qSum}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">PDP Target:</span>
                    <span className="text-gray-800">{tableData[facility]?.pdpTarget || "-"}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">Achievement:</span>
                    <span className="font-semibold text-darkblue1">{calculateAchievement(facility)}%</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Save Button */}
        {mode === "fill" && (
          <div className="flex justify-end mb-6">
            <button
              onClick={handleSave}
              disabled={saving}
              className="bg-darkblue1 text-white px-6 py-1.5 font-medium text-xs 
                         hover:bg-white hover:border hover:border-darkblue1 
                         hover:text-darkblue1 transition w-full sm:w-auto
                         disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? "Saving..." : "Save"}
            </button>
          </div>
        )}
      </>
    );
  };

  // ============================================
  // RENDER SUB TAB CONTENT
  // ============================================
  const renderSubTabContent = () => {
    switch (activeSubTab) {
      case "Facility":
        return renderFacilityTab();

      case "Competence":
        return (
          <Competence 
            mode={mode}
            apiData={competenceData}
            onSave={handleSaveCompetence}
            saving={saving}
          />
        );

      case "Vehicles":
        return (
          <VehiclesTab 
            mode={mode}
            apiData={vehiclesData}
            onSave={handleSaveVehicles}
            saving={saving}
            investment={investment}
          />
        );

      case "Machine & Population":
        return (
          <MachinePopulation 
            mode={mode}
            apiData={machinePopulationData}
            onSave={handleSaveMachinePopulation}
            saving={saving}
          />
        );

      case "Tools":
        return (
          <Tools 
            mode={mode}
            apiData={toolsData}
            onSave={handleSaveTools}
            saving={saving}
          />
        );

      case "Equipments & Attachments":
        return (
          <EquipmentsAttachments 
            mode={mode} 
            investment={investment}
            passedMake={passedMake}
            passedType={passedType}
          />
        );

      case "Uptime & Parts":
        return (
          <UptimeParts 
            mode={mode} 
            investment={investment}
          />
        );

      case "Allocation":
         return <Allocation mode={mode} investment={investment} />;

      default:
        return renderFacilityTab();
    }
  };

  // ============================================
  // RENDER - LOADING STATE
  // ============================================
  if (loading) {
    return (
      <div className="bg-Frostwhite min-h-screen flex flex-col">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        <SubNavbar3 />
        <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
          <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
              <span className="ml-3 text-sm text-gray-600">Loading infrastructure data...</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ============================================
  // RENDER - ERROR STATE
  // ============================================
  if (error) {
    return (
      <div className="bg-Frostwhite min-h-screen flex flex-col">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        <SubNavbar3 />
        <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
          <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
            <div className="flex flex-col items-center justify-center py-20">
              <p className="text-red-500 text-sm mb-4">{error}</p>
              <button
                onClick={fetchInfrastructureData}
                className="px-4 py-2 bg-darkblue1 text-white text-xs hover:bg-blue-700 transition"
              >
                Retry
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ============================================
  // RENDER - MAIN
  // ============================================
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      {/* Header */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      {/* SubNavbar */}
      <SubNavbar3 />

      {/* Main Content */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header with Back Button */}
          <div className="mb-2">
            <div className="flex flex-col gap-3 sm:gap-0 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2">
                <ArrowLeft
                  onClick={handleBack}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
                />
                <span className="text-base font-semibold font-VolvoNovum text-darkblue1">
                  {investment?.year} - Infrastructure & Financial Health - {investment?.dealer}
                </span>
              </div>
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 text-xs">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-darkblue1 rounded-full"></span>
                  {mode === "fill" ? "Fill Mode" : "View Mode"}
                </span>
                <button
                  onClick={() => setShowUploadPopup(true)}
                  className="bg-darkblue1 text-white px-3 py-1 text-xs font-medium hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition w-full sm:w-auto"
                >
                  View / Upload Files
                </button>
              </div>
            </div>
          </div>

          {/* Main Tabs and Sub Tabs - Combined Card */}
          <div className="bg-white shadow-md border border-gray-300 mb-2 px-3 py-2">
            {/* Main Tabs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-0">
              <div
                className={`text-center py-1.5 font-medium cursor-pointer transition text-sm ${
                  activeTab === "Infrastructure"
                    ? "bg-Dustyblue text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
                onClick={() => handleMainTabClick("Infrastructure")}
              >
                Infrastructure
              </div>

              <div
                className={`text-center py-1.5 font-medium cursor-pointer transition text-sm ${
                  activeTab === "Monthly business Plan"
                    ? "bg-Dustyblue text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
                onClick={() => handleMainTabClick("Monthly business Plan")}
              >
                Monthly Business Plan
              </div>
            </div>

            {/* Sub Tabs */}
            <div className={`sm:mt-4 grid gap-2 sm:gap-3 ${
              activeTab === "Infrastructure" 
                ? "grid-cols-2 sm:grid-cols-3 lg:grid-cols-5" 
                : "grid-cols-1 sm:grid-cols-3"
            }`}>
              {getSubTabs().map((tab) => (
                <button
                  key={tab}
                  className={`py-1 px-2 sm:px-3 text-xs font-medium transition ${
                    activeSubTab === tab
                      ? "bg-lightBlue/50 text-darkblue1 border-[1px] border-darkblue1"
                      : "bg-white text-gray-700 border border-gray-400 hover:bg-gray-100"
                  }`}
                  onClick={() => setActiveSubTab(tab)}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Dynamic Content Based on Active Sub-Tab */}
          {renderSubTabContent()}
        </div>
      </div>

      {/* View and Upload Popup - Now with API Integration */}
      {showUploadPopup && (
        <ViewAndUpload
          isOpen={showUploadPopup}
          onClose={() => setShowUploadPopup(false)}
          activeType={activeSubTab}
          dealerInvestmentId={investment?.id}
          headerTitle={`${investment?.year} - Infrastructure & Financial Health - ${investment?.dealer}`}
        />
      )}
    </div>
  );
};

export default FillEntries;