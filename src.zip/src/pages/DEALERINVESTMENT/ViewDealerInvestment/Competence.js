import React, { useState, useEffect,useMemo, useRef } from "react";
import { ChevronUp,ChevronDown,ChevronsUpDown } from "lucide-react";
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation";
/**
 * Competence Component
 * Displays competence data grouped by category (SCL, TCL, CCL, LCL, Other)
 * 
 * Props:
 * - mode: "fill" or "view"
 * - apiData: { tableData, pdpTargets, groupedData } from FillEntries
 * - onSave: callback function to save data
 * - saving: boolean for save loading state
 */
const Competence = ({ mode, apiData, onSave, saving }) => {
  // Category definitions
  const categories = [
    { key: "SCL", title: "Sales Competence Level" },
    { key: "TCL", title: "Technical Competence Level" },
    { key: "CCL", title: "Commercial Competence Level" },
    { key: "LCL", title: "Logistic Competence Level" },
    { key: "Other", title: "Other Competence" },
  ];
const formRef=useRef(null)
  // Local state for editable grouped data
  const [groupedData, setGroupedData] = useState({
    SCL: {},
    TCL: {},
    CCL: {},
    LCL: {},
    Other: {},
  });
  const [pdpTargets, setPdpTargets] = useState({
    SCL: "0",
    TCL: "0",
    CCL: "0",
    LCL: "0",
    Other: "0",
  });

  // Sync with apiData from parent
  useEffect(() => {
    if (apiData?.groupedData) {
      setGroupedData(apiData.groupedData);
    }
    if (apiData?.pdpTargets) {
      setPdpTargets(apiData.pdpTargets);
    }
  }, [apiData]);

  // ============================================
  // HANDLERS
  // ============================================
  const handleInputChange = (category, competenceName, field, value) => {
    setGroupedData((prev) => ({
      ...prev,
      [category]: {
        ...prev[category],
        [competenceName]: {
          ...prev[category][competenceName],
          [field]: value,
        },
      },
    }));
  };

  const calculateYTDActual = (data) => {
    return (
      (parseInt(data.Q1) || 0) +
      (parseInt(data.Q2) || 0) +
      (parseInt(data.Q3) || 0) +
      (parseInt(data.Q4) || 0)
    );
  };

  const calculateAchievement = (data, categoryTarget) => {
    const ytdActual = calculateYTDActual(data);
    const target = parseInt(data.pdpTarget) || parseInt(categoryTarget) || 0;
    return target > 0 ? ((ytdActual / target) * 100).toFixed(2) : "0.00";
  };

  const handleSave = () => {
    if (onSave) {
      onSave(groupedData);
    }
  };
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [sortSettings, setSortSettings] = useState({});

const handleSort = (categoryKey, key) => {
  setSortSettings((prev) => {
    const current = prev[categoryKey] || {};
    let newOrder;

    if (current.key === key) {
      if (current.order === "asc") newOrder = "desc";
      else if (current.order === "desc") newOrder = null;
      else newOrder = "asc";
    } else {
      newOrder = "asc";
    }

    return {
      ...prev,
      [categoryKey]: newOrder
        ? { key, order: newOrder }
        : undefined, // reset if no sort
    };
  });
};
useKeyboardNavigation({
        containerRef: formRef,
        onSubmit: () => handleSave(),
        onCancel: () => {},
    });

  // Check if any data exists
  const hasData = Object.values(groupedData).some(
    (category) => Object.keys(category).length > 0
  );

  // ============================================
  // RENDER COMPETENCE TABLE
  // ============================================
  const renderCompetenceTable = (categoryKey, title) => {
    const categoryData = groupedData[categoryKey] || {};
    
    const categoryTarget = pdpTargets[categoryKey] || "0";
const { key: sortKey, order: sortOrder } = sortSettings[categoryKey] || {};

    // Skip rendering if no data in this category
    if (Object.keys(categoryData).length === 0) {
      return null;
    }
const sortedCompetenceData = (() => {
  const rows = Object.entries(categoryData).map(([name, values]) => ({
    name,
    ...values,
    ytd: calculateYTDActual(values),
    achievement: calculateAchievement(values, categoryTarget),
  }));

  if (!sortKey || !sortOrder) return rows;

  return [...rows].sort((a, b) => {
    const valA = a[sortKey] ?? 0;
    const valB = b[sortKey] ?? 0;

    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    return sortOrder === "asc"
      ? valA.toString().localeCompare(valB.toString())
      : valB.toString().localeCompare(valA.toString());
  });
})();


    return (
      <div key={categoryKey}>
        {/* Desktop Table */}
        <div 
        ref={formRef}
        className="hidden lg:block bg-white shadow-md border border-Dustyblue overflow-hidden mb-4">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead className="text-xs">
                <tr className="bg-Dustyblue text-white">
 <th
        onClick={() => handleSort(categoryKey, "name")}
        className="cursor-pointer px-3 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%] text-left font-medium text-xs"
      >
        <div className="flex items-center gap-1">
          {title}
          {sortSettings[categoryKey]?.key !== "name" && (
            <ChevronsUpDown className="w-3 h-3 text-white" />
          )}
          {sortSettings[categoryKey]?.key === "name" &&
            sortSettings[categoryKey].order === "asc" && <ChevronUp size={12} />}
          {sortSettings[categoryKey]?.key === "name" &&
            sortSettings[categoryKey].order === "desc" && <ChevronDown size={12} />}
        </div>
      </th>
               {/* Q1-Q4 */}
      {["Q1", "Q2", "Q3", "Q4"].map((q) => (
        <th
          key={q}
          onClick={() => handleSort(categoryKey, q)}
          className="cursor-pointer px-3 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%] text-center font-medium text-xs"
        >
          {q}
          {sortSettings[categoryKey]?.key === q &&
            sortSettings[categoryKey].order === "asc" && <ChevronUp size={12} className="inline ml-1" />}
          {sortSettings[categoryKey]?.key === q &&
            sortSettings[categoryKey].order === "desc" && <ChevronDown size={12} className="inline ml-1" />}
        </th>
      ))}
   <th
        onClick={() => handleSort(categoryKey, "ytd")}
        className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-medium w-[15%] cursor-pointer select-none"
      >
        <div className="flex items-center justify-center gap-1">
          Actual
          {sortSettings[categoryKey]?.key === "ytd" &&
            sortSettings[categoryKey].order === "asc" && <ChevronUp size={12} />}
          {sortSettings[categoryKey]?.key === "ytd" &&
            sortSettings[categoryKey].order === "desc" && <ChevronDown size={12} />}
        </div>
      </th>

                 <th
        onClick={() => handleSort(categoryKey, "pdpTarget")}
        className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-medium w-[15%] cursor-pointer select-none"
      >
        <div className="flex items-center justify-center gap-1">
          PDP Target
          {sortSettings[categoryKey]?.key === "pdpTarget" &&
            sortSettings[categoryKey].order === "asc" && <ChevronUp size={12} />}
          {sortSettings[categoryKey]?.key === "pdpTarget" &&
            sortSettings[categoryKey].order === "desc" && <ChevronDown size={12} />}
        </div>
      </th>

 <th
        onClick={() => handleSort(categoryKey, "achievement")}
        className="border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 px-3 py-1.5 text-center font-medium w-[10%] cursor-pointer select-none"
      >
        <div className="flex items-center justify-center gap-1">
          Achievement %
          {sortSettings[categoryKey]?.key === "achievement" &&
            sortSettings[categoryKey].order === "asc" && <ChevronUp size={12} />}
          {sortSettings[categoryKey]?.key === "achievement" &&
            sortSettings[categoryKey].order === "desc" && <ChevronDown size={12} />}
        </div>
      </th>

                </tr>
              </thead>
            <tbody>
  {sortedCompetenceData.map((row) => {
    const qSum = calculateYTDActual(row);

    return (
      <tr key={row.name}>
        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 font-normal text-black text-xs">
          {row.name}
        </td>

        {/* Q1-Q4 inputs or values */}
        {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
          <td
            key={quarter}
            className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs"
          >
            {mode === "fill" ? (
            <input
  type="text"
  value={row[quarter] || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleInputChange(
        categoryKey,
        row.name,
        quarter,
        value
      );
    }
  }}
  className="w-full text-center border border-gray-300 px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-darkblue1"
/>
            ) : (
              <span>{row[quarter] || "-"}</span>
            )}
          </td>
        ))}

        {/* YTD Actual */}
        <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-center text-xs">
          {mode === "fill" ? (
            <input
              type="number"
              value={qSum}
              readOnly
              className="w-full text-center border border-gray-300 px-2 py-1 text-xs bg-gray-100 cursor-not-allowed"
            />
          ) : (
            <span>{qSum}</span>
          )}
        </td>

        {/* PDP Target */}
        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs">
          {row.pdpTarget || "-"}
        </td>

        {/* Achievement */}
        <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1 text-center text-xs">
          {row.achievement}%
        </td>
      </tr>
    );
  })}
</tbody>

            </table>
          </div>
        </div>

        {/* Mobile/Tablet Cards */}
        <div className="lg:hidden mb-6">
          <h3 className="text-base sm:text-lg font-semibold text-darkblue1 mb-3 px-2">
            {title}
          </h3>
          <div className="space-y-3">
            {Object.keys(categoryData).map((competenceName) => {
              const data = categoryData[competenceName];
              const qSum = calculateYTDActual(data);

              return (
                <div
                  key={competenceName}
                  className="bg-white shadow-md border-2 border-Dustyblue p-4"
                >
                  <h4 className="font-semibold text-darkblue1 mb-3 pb-2 border-b-2 border-Dustyblue text-sm">
                    {competenceName}
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
                      <div key={quarter} className="flex justify-between">
                        <span className="font-medium text-gray-600">{quarter}:</span>
                        {mode === "fill" ? (
                          <input
                            type="number"
                            min="0"
                            value={data[quarter] || ""}
                            onChange={(e) =>
                              handleInputChange(categoryKey, competenceName, quarter, e.target.value)
                            }
                            className="w-20 text-center border border-gray-300 px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-darkblue1"
                          />
                        ) : (
                          <span className="text-gray-800">{data[quarter] || "-"}</span>
                        )}
                      </div>
                    ))}

                    {/* YTD Actual */}
                    <div className="flex justify-between col-span-2">
                      <span className="font-medium text-gray-600">Actual:</span>
                      {mode === "fill" ? (
                        <input
                          type="number"
                          value={qSum}
                          readOnly
                          className="w-20 text-center border border-gray-300 px-2 py-1 text-sm bg-gray-100 cursor-not-allowed"
                        />
                      ) : (
                        <span className="text-gray-800">{qSum}</span>
                      )}
                    </div>

                    {/* PDP Target */}
                    <div className="flex justify-between">
                      <span className="font-medium text-gray-600">PDP Target:</span>
                      <span className="text-gray-800">{data.pdpTarget || "-"}</span>
                    </div>

                    {/* Achievement */}
                    <div className="flex justify-between">
                      <span className="font-medium text-gray-600">Achievement:</span>
                      <span className="font-semibold text-darkblue1">
                        {calculateAchievement(data, categoryTarget)}%
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  // ============================================
  // RENDER - NO DATA
  // ============================================
  if (!hasData) {
    return (
      <div className="bg-white shadow-md border border-Dustyblue p-8 text-center">
        <p className="text-gray-500 italic">No competence data available</p>
      </div>
    );
  }

  // Get categories that have data (for PDP Target card)
  const categoriesWithData = categories.filter(
    (cat) => Object.keys(groupedData[cat.key] || {}).length > 0
  );

  // ============================================
  // RENDER - MAIN
  // ============================================
  return (
    <div>
      {/* PDP Target Card */}
      <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-6">
        <div className="bg-Dustyblue text-white">
          <div
            className={`grid text-center font-medium text-xs`}
            style={{
              gridTemplateColumns: `repeat(${categoriesWithData.length + 1}, minmax(0, 1fr))`,
            }}
          >
            <div className="py-1.5 px-2 border border-grey2 border-t-0 border-l-0 border-b-0">
              PDP Target
            </div>
            {categoriesWithData.map((cat, idx) => (
              <div
                key={cat.key}
                className={`py-1.5 px-2 border border-grey2 border-t-0 border-l-0 border-b-0 ${
                  idx === categoriesWithData.length - 1 ? "border-r-0" : ""
                }`}
              >
                {cat.key}
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white">
          <div
            className={`grid text-center text-xs`}
            style={{
              gridTemplateColumns: `repeat(${categoriesWithData.length + 1}, minmax(0, 1fr))`,
            }}
          >
            <div className="py-1 border border-grey2 border-t-0 border-l-0"></div>
            {categoriesWithData.map((cat, idx) => (
              <div
                key={cat.key}
                className={`py-1 border border-grey2 border-t-0 border-l-0 ${
                  idx === categoriesWithData.length - 1 ? "border-r-0" : ""
                }`}
              >
                {pdpTargets[cat.key] || "0"}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Category Tables */}
      {categories.map((cat) => renderCompetenceTable(cat.key, cat.title))}

      {/* Save Button */}
      {mode === "fill" && (
        <div className="flex justify-end mb-6">
          <button
            onClick={handleSave}
            disabled={saving}
            className="bg-darkblue1 text-white px-6 py-1.5 font-medium text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? "Saving..." : "Save"}
          </button>
        </div>
      )}
    </div>
  );
};

export default Competence;