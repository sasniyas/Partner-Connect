
import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import Filter from "../../../Components/Filter";
import DeleteModal from "../../../Components/DeleteModal";
import { useNavigate, useLocation } from "react-router-dom";
import Searchinput from "../../../Components/Searchinput";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import { ChevronDown,ChevronUp,ChevronsUpDown,ArrowUp,ArrowDown } from "lucide-react";
// Import service functions
import {
  getAllDealerInvestment,
  deleteDealerInvestment,
} from "../../../services/dealerInvestment/dealerInvestment.service";
import { getAllDealers, getAllMarketAreas } from "../../../services/PDP/ViewPDP/viewpdp.service";

const ViewDealerInvestment = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Role detection from Redux or fallback (aligning with ViewPdp pattern)
  const user = useSelector((state) => state.user);
  const userRole = user?.data?.persona || user?.persona || user?.role || "";

  // Basic Admin check based on role - keeping existing logic roughly but enhancing if needed
  // existing logic:
  const detectedRole = location.pathname.includes('/user/') ? 'user' : 'admin';
  const effectiveRole = detectedRole;
  const isAdmin = effectiveRole === "admin";
  // Should we verify against ADMIN_ROLES like ViewPdp? The user seemingly relies on URL path here.
  // I will keep the URL path logic as it was in the original file to avoid breaking existing permission logic.

  // State
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  // Data & Pagination State
  const [tableData, setTableData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const tableContainerRef = useRef(null);

  // Filters State
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState("");
  const [selectedYear, setSelectedYear] = useState([]);
  const [selectedMarketArea, setSelectedMarketArea] = useState([]);
  const [selectedDealer, setSelectedDealer] = useState([]);

  // Filter Options State
  const [allDealers, setAllDealers] = useState([]);
  const [filteredDealerOptions, setFilteredDealerOptions] = useState([]);
  const [marketAreaOptions, setMarketAreaOptions] = useState([]);

  // Year Options (Current year + 10 future years, same as ViewPdp)
  const currentYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 11 }, (_, i) =>
    (currentYear + i).toString()
  );
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};


  // ============================================
  // DEBOUNCE SEARCH
  // ============================================
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchQuery(searchQuery);
    }, 500);
    return () => clearTimeout(handler);
  }, [searchQuery]);

  // ============================================
  // FETCH MARKET AREAS & DEALERS (Initial Load)
  // ============================================
  useEffect(() => {
    const fetchMarketAreas = async () => {
      try {
        const areas = await getAllMarketAreas();
        setMarketAreaOptions(areas.sort((a, b) => a.localeCompare(b)));
      } catch (err) {
        console.error("Error fetching market areas:", err.message);
      }
    };
    fetchMarketAreas();
  }, []);

  useEffect(() => {
    const fetchDealers = async () => {
      try {
        const dealers = await getAllDealers();
        setAllDealers(dealers);
        const allOptions = dealers
          .filter((d) => d.dealerShortName)
          .map((d) => d.dealerShortName)
          .sort((a, b) => a.localeCompare(b));
        setFilteredDealerOptions(allOptions);
      } catch (err) {
        console.error("Error fetching dealers:", err);
      }
    };
    fetchDealers();
  }, []);

  // ============================================
  // FILTER DEALERS BASED ON MARKET AREA
  // ============================================
  useEffect(() => {
    if (!allDealers.length) return;
    let options = [];
    if (!selectedMarketArea.length) {
      options = allDealers
        .map((d) => d.dealerShortName)
        .sort((a, b) => a.localeCompare(b));
    } else {
      options = allDealers
        .filter((d) =>
          selectedMarketArea.some(
            (ma) => ma.toLowerCase() === String(d.marketName).toLowerCase()
          )
        )
        .map((d) => d.dealerShortName)
        .sort((a, b) => a.localeCompare(b));
    }
    setFilteredDealerOptions(options);

    // Only reset selectedDealer if it has values to avoid loop
    if (selectedDealer.length > 0) {
      setSelectedDealer([]);
    }
  }, [selectedMarketArea, allDealers]);

  // ============================================
  // FETCH DATA FUNCTION
  // ============================================
  const fetchDealerInvestments = useCallback(
    async (currentPage) => {
      try {
        if (currentPage === 1) setIsLoading(true);
        else setIsLoadingMore(true);

        const filters = {
          year: selectedYear.join(','),
          marketArea: selectedMarketArea.join(','), // Changed to match service expectation (marketArea)
          dealer: selectedDealer.join(','),
          search: debouncedSearchQuery
        };

        const response = await getAllDealerInvestment(currentPage, filters);
        const list = response?.data || [];

        console.log(`📍 Dealer Investment List (Page ${currentPage}):`, list?.length);

        if (!list || list.length < 300) { // Matching limit from controller
          setHasMore(false);
        } else {
          setHasMore(true);
        }

        if (currentPage === 1) {
          setTableData(list);
        } else {
          setTableData((prev) => [...prev, ...list]);
        }
      } catch (err) {
        console.error("Error fetching dealer investments:", err);
        // Only show toast on first load failure to avoid spamming on scroll
        if (currentPage === 1) {
          toast.error("Failed to load dealer investments");
        }
      } finally {
        setIsLoading(false);
        setIsLoadingMore(false);
      }
    },
    [selectedYear, selectedMarketArea, selectedDealer, debouncedSearchQuery]
  );

  // ============================================
  // EFFECTS FOR FETCHING
  // ============================================
  // Reset page and fetch when filters change
  useEffect(() => {
    setPage(1);
    fetchDealerInvestments(1);
  }, [selectedYear, selectedMarketArea, selectedDealer, debouncedSearchQuery, fetchDealerInvestments]);

  // Fetch next page
  useEffect(() => {
    if (page > 1) {
      fetchDealerInvestments(page);
    }
  }, [page, fetchDealerInvestments]);

  // ============================================
  // SCROLL HANDLER
  // ============================================
 
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return tableData;

  return [...tableData].sort((a, b) => {
    let valA, valB;

    switch (sortKey) {
      case "year":
        valA = a.pdp_info?.year;
        valB = b.pdp_info?.year;
        break;

      case "marketArea":
        valA = a.dealer_info?.market_area_name || a.pdp_info?.market_area;
        valB = b.dealer_info?.market_area_name || b.pdp_info?.market_area;
        break;

      case "dealer":
        valA =
          a.dealer_info?.dealer_short_name ||
          a.dealer_info?.dealer_name ||
          a.pdp_info?.dealer;

        valB =
          b.dealer_info?.dealer_short_name ||
          b.dealer_info?.dealer_name ||
          b.pdp_info?.dealer;
        break;

      default:
        return 0;
    }

    // number sort
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // string sort
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [tableData, sortKey, sortOrder]);
 // ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  // ============================================
  // ACTION HANDLERS
  // ============================================
  const handleDelete = async () => {
    if (!itemToDelete) return;

    setDeleting(true);

    try {
      const response = await deleteDealerInvestment(itemToDelete.id);

      if (response?.status) {
        toast.success("Dealer investment deleted successfully!");
        // Remove from local state
        setTableData((prev) => prev.filter((d) => d.id !== itemToDelete.id));
      } else {
        toast.error(response?.message || "Failed to delete");
      }
    } catch (err) {
      console.error("Error deleting dealer investment:", err);
      toast.error("Failed to delete dealer investment");
    } finally {
      setDeleting(false);
      setItemToDelete(null);
      setDeleteModalVisible(false);
    }
  };

  const handleFillEntries = (investment) => {
    navigate("/DEALERINVESTMENT/ViewDealerInvestment/FillEntries", {
      state: { investment, mode: "fill" }
    });
  };

  const handleViewEntries = (investment) => {
    navigate("/DEALERINVESTMENT/ViewDealerInvestment/FillEntries", {
      state: { investment, mode: "view" }
    });
  };

  // ============================================
  // DATA FLATTENING FOR TABLE
  // ============================================
  // Transform data for display (mimicking old transform logic but inline or via accessor)
  // The service implementation returned response.data direct? 
  // Wait, my service update returns response.data which is the object { status, data: [] }?
  // No, getAllDealerInvestment returns response.data.
  // In `fetchDealerInvestments`: const list = response?.data || [];
  // Backend returns { status: true, data: [...] }
  // So response.data is the array.
  // The array items have nested pdp_info and dealer_info.
  // We need to access these correctly in the table.

  // ============================================
  // RENDER
  // ============================================
  if (isLoading && page === 1) {
    return (
      <div className="w-full">
        <div className="w-full flex justify-center mb-2">
          <h2 className="text-xl font-semibold text-darkblue1 font-VolvoNovum">
            Dealer Investment
          </h2>
        </div>
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
          <span className="ml-3 text-sm text-gray-600">Loading dealer investments...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full">
      {/* Hide scrollbar for webkit browsers */}
      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>

      {/* Title - Centered */}
      <div className="w-full flex justify-center mb-2">
        <h2 className="text-xl font-semibold text-darkblue1 font-VolvoNovum">
          Dealer Investment
        </h2>
      </div>

      <div>
        {/* Filters */}
        <div className="w-full mb-2">
          <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:flex-wrap">

            {/* Search Input */}
            <div className="">
              <Searchinput
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search"
                className="w-[1/2]"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />
            </div>

            {/* Year Filter */}
            <div className="">
              <Filter
                name="year"
                value={selectedYear}
                options={yearOptions}
                onChange={(name, val) => setSelectedYear(val)}
                placeholder="Year"
                customWidth="w-[120px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                textColor="text-black"
              />
            </div>

            {/* Market Area Filter */}
            <div className="">
              <Filter
                name="marketArea"
                value={selectedMarketArea}
                options={marketAreaOptions}
                onChange={(name, val) => setSelectedMarketArea(val)}
                placeholder="Market Area"
                customWidth="w-[120px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                textColor="text-black"
              />
            </div>

            {/* Dealer Filter */}
            <div className="">
              <Filter
                name="dealer"
                value={selectedDealer}
                options={filteredDealerOptions}
                onChange={(name, val) => setSelectedDealer(val)}
                placeholder="Dealer"
                customWidth="w-[150px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                textColor="text-black"
              />
            </div>
          </div>
        </div>

        {/* Table - Desktop */}
        <div className="hidden lg:block bg-white shadow-md border border-Dustyblue">
          <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
              maxHeight: sortedData.length > 8 ? "calc(100vh - 200px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >
            <table className="w-full text-sm table-fixed min-w-[700px]">
            <thead className="bg-Dustyblue text-white sticky top-0 z-10 text-xs">
  <tr>
    {/* YEAR */}
    <th
      className="w-[10%] px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium text-left cursor-pointer select-none"
      onClick={() => handleSort("year")}
    >
      <div className="flex items-center gap-1">
        Year
        {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

        {sortKey === "year" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "year" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* MARKET AREA */}
    <th
      className="w-[18%] px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium text-left cursor-pointer select-none"
      onClick={() => handleSort("marketArea")}
    >
      <div className="flex items-center gap-1">
        Market Area
        {sortKey === "marketArea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "marketArea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* DEALER */}
    <th
      className="w-[27%] px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium text-left cursor-pointer select-none"
      onClick={() => handleSort("dealer")}
    >
      <div className="flex items-center gap-1">
        Dealer
        {sortKey === "dealer" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "dealer" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {/* FILL ENTRIES */}
    <th
      className="w-[15%] px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium text-center cursor-pointer select-none"
    >
        Fill Entries
       
    </th>

    {/* VIEW ENTRIES */}
    <th
      className={`w-[15%] px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium text-center cursor-pointer select-none ${
        !isAdmin ? "border-r-0" : ""
      }`}
    >
        View Entries 
    </th>

    {/* DELETE (NO SORT) */}
    {isAdmin && (
      <th className="w-[15%] px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-r-0 font-medium text-center">
        Delete
      </th>
    )}
  </tr>
</thead>
              <tbody>
                {sortedData.length === 0 ? (
                  <tr>
                    <td colSpan={isAdmin ? 6 : 5} className="text-center py-6 text-gray-500 italic">
                      No data found
                    </td>
                  </tr>
                ) : (
                 sortedData.map((investment, index) => {
                    const year = investment.pdp_info?.year || "";
                    const marketArea = investment.dealer_info?.market_area_name || investment.pdp_info?.market_area || "";
                    const dealerName = investment.dealer_info?.dealer_short_name || investment.dealer_info?.dealer_name || investment.pdp_info?.dealer || "";

                    return (
                      <tr
                        key={`${investment.id}-${index}`}
                        className="hover:bg-lightBlue/50 transition text-xs text-black"
                      >
                        <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-left">{year}</td>
                        <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-left truncate" >{marketArea}</td>
                        <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-left truncate">{dealerName}</td>

                        {/* Fill Entries Button */}
                        <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-center">
                          <div className="relative group inline-block">
                            <button
                              onClick={() => handleFillEntries(investment)}
                              className="hover:scale-110 transition-all"
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"  className="w-3.5 h-3.5">
<path d="M16.5 4.5H20.25V21.75H3.75V4.5H7.5V6H16.5V4.5ZM6.75 12H17.25V10.5H6.75V12ZM6.75 18H17.25V16.5H6.75V18ZM9 4.5V2.25H15V4.5H9Z" fill="#E06900"/>
</svg>
                            </button>
                            <span className="absolute top-full mt-0 left-1/2 transform -translate-x-1/2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-0">
                              Fill Entries
                            </span>
                          </div>
                        </td>

                        {/* View Entries Button */}
                        <td className={`px-4 py-1 border border-grey2 border-t-0 border-l-0 text-center ${!isAdmin ? "border-r-0" : ""}`}>
                          <div className="relative group inline-block">
                            <button
                              onClick={() => handleViewEntries(investment)}
                              className="hover:scale-110 transition-all"
                            >
                             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" className="w-3.5 h-3.5 mx-auto">
<path d="M9.6002 7.19998H20.4002V9.59998H9.6002V7.19998ZM9.6002 3.59998H22.8002V5.99998H9.6002V3.59998ZM1.2002 3.59998H8.4002V10.8H1.2002V3.59998ZM9.6002 16.8H20.4002V19.2H9.6002V16.8ZM9.6002 13.2H22.8002V15.6H9.6002V13.2ZM1.2002 13.2H8.4002V20.4H1.2002V13.2Z" fill="#2C4730"/>
</svg>
                            </button>
                            <span className="absolute top-full mt-0 left-1/2 transform -translate-x-1/2 text-[10px] bg-SteelBlue1 text-white px-2 py-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-0">
                              View Entries
                            </span>
                          </div>
                        </td>

                        {/* Delete Button */}
                        {isAdmin && (
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-center">
                            <div className="relative group inline-block">
                              <button
                                onClick={() => {
                                  setItemToDelete(investment);
                                  setDeleteModalVisible(true);
                                }}
                                className="hover:scale-110 transition-all"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none" >
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>

                              </button>
                              <span className="absolute top-full mt-0 left-1/2 transform -translate-x-1/2 text-[10px] bg-SteelBlue1 text-white px-2 py-0 opacity-0 group-hover:opacity-100 z-0">
                                Delete
                              </span>
                            </div>
                          </td>
                        )}
                      </tr>
                    )
                  })
                )}
                {isLoadingMore && (
                  <tr>
                    <td colSpan={isAdmin ? 6 : 5} className="text-center py-2">
                      <div className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-darkblue1"></div>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
           {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {scrollDirection === 'down' && (
                <button onClick={scrollToTop} className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm" aria-label="Scroll to top">
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}
              {scrollDirection === 'up' && (
                <button onClick={scrollToBottom} className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm" aria-label="Scroll to bottom">
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Mobile / Tablet Cards */}
        <div className="lg:hidden flex flex-col gap-4">
          {tableData.length === 0 ? (
            <div className="text-center py-8 text-gray-500 italic">No data found</div>
          ) : (
            tableData.map((investment, index) => {
              const year = investment.pdp_info?.year || "";
              const marketArea = investment.dealer_info?.market_area_name || investment.pdp_info?.market_area || "";
              const dealerName = investment.dealer_info?.dealer_short_name || investment.dealer_info?.dealer_name || investment.pdp_info?.dealer || "";

              return (
                <div
                  key={`${investment.id}-${index}`}
                  className="bg-white shadow-md p-4 border border-Dustyblue"
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium text-gray-500">Year:</span>
                    <span className="text-gray-700">{year}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium text-gray-500">Market Area:</span>
                    <span className="text-gray-700">{marketArea}</span>
                  </div>
                  <div className="flex justify-between mb-4">
                    <span className="font-medium text-gray-500">Dealer:</span>
                    <span className="text-gray-700">{dealerName}</span>
                  </div>

                  <div className="flex flex-col sm:flex-row justify-between gap-2 mt-4">
                    <button
                      onClick={() => handleFillEntries(investment)}
                      className="w-full sm:flex-1 px-3 py-2 bg-darkblue1 text-white text-sm hover:bg-darkblue1/90 transition"
                    >
                      Fill Entries
                    </button>
                    <button
                      onClick={() => handleViewEntries(investment)}
                      className="w-full sm:flex-1 px-3 py-2 bg-green1 text-white text-sm hover:bg-green1/90 transition"
                    >
                      View Entries
                    </button>
                    {isAdmin && (
                      <button
                        onClick={() => {
                          setItemToDelete(investment);
                          setDeleteModalVisible(true);
                        }}
                        className="w-full sm:w-auto px-3 py-2 bg-red1 text-white text-sm hover:bg-red1/90 transition"
                      >
                        Delete
                      </button>
                    )}
                  </div>
                </div>
              )
            })
          )}
          {isLoadingMore && (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-darkblue1 mx-auto"></div>
            </div>
          )}
        </div>
      </div>

      <DeleteModal
        isOpen={deleteModalVisible}
        onClose={() => {
          setDeleteModalVisible(false);
          setItemToDelete(null);
        }}
        onConfirm={handleDelete}
        loading={deleting}
      />
    </div>
  );
};

export default ViewDealerInvestment;