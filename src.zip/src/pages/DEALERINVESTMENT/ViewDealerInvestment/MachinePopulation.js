import React, { useState, useEffect,useRef } from "react";
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation";
import {ChevronUp,ChevronDown,ChevronsUpDown} from "lucide-react"
const MachinePopulation = ({ mode, apiData, onSave, saving }) => {
  // Initialize state from API data
  const [machineData, setMachineData] = useState({});
  const formRef= useRef(null)
  // PDP Target values (from API)
  const [pdpTargets, setPdpTargets] = useState({});
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") setSortOrder("desc");
    else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else setSortOrder("asc");
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  // Sync with API data when it changes
  useEffect(() => {
    if (apiData?.tableData && Object.keys(apiData.tableData).length > 0) {
      setMachineData(apiData.tableData);
    }
    // Set PDP targets from API
    if (apiData?.pdpTargets && Object.keys(apiData.pdpTargets).length > 0) {
      setPdpTargets(apiData.pdpTargets);
    }
  }, [apiData]);

  const handleInputChange = (machine, quarter, value) => {
    setMachineData((prev) => ({
      ...prev,
      [machine]: {
        ...prev[machine],
        [quarter]: value,
      },
    }));
  };

  const calculateActual = (machine) => {
    const data = machineData[machine];
    if (!data) return 0;
    return (
      (parseInt(data.Q1) || 0) +
      (parseInt(data.Q2) || 0) +
      (parseInt(data.Q3) || 0) +
      (parseInt(data.Q4) || 0)
    );
  };

  const calculateAchievement = (machine) => {
    const actual = calculateActual(machine);
    const target = parseInt(pdpTargets[`Active Machine Population - ${machine}`]) || 0;
    // Return 0 if target is 0 or not set
    return target > 0 ? ((actual / target) * 100).toFixed(2) : "0.00";
  };

  const handleSave = () => {
    if (onSave) {
      onSave(machineData);
    }
  };
useKeyboardNavigation({
  containerRef: formRef, // your popup div ref

  onSubmit: () => { 
   handleSave()
  },

  onCancel: () => {
  
  },
});

  // Check if data exists
  if (Object.keys(machineData).length === 0) {
    return (
      <div className="bg-white shadow-md border border-Dustyblue p-8 text-center">
        <p className="text-gray-500 italic">No machine population data available</p>
      </div>
    );
  }

  // Get machine names (makes) from data
  const machineNames = Object.keys(machineData);
const sortedMachineNames = [...machineNames].sort((a, b) => {
  if (!sortKey || !sortOrder) return 0; // no sorting

  let valA, valB;

  switch (sortKey) {
    case "vehicle":
      valA = a.toLowerCase();
      valB = b.toLowerCase();
      break;
    case "q1":
    case "q2":
    case "q3":
    case "q4":
      valA = parseInt(machineData[a][sortKey.toUpperCase()]) || 0;
      valB = parseInt(machineData[b][sortKey.toUpperCase()]) || 0;
      break;
    case "actual":
      valA = calculateActual(a);
      valB = calculateActual(b);
      break;
    case "pdpTarget":
      valA = parseInt(pdpTargets[`Active Machine Population - ${a}`]) || 0;
      valB = parseInt(pdpTargets[`Active Machine Population - ${b}`]) || 0;
      break;
    case "achievement":
      valA = parseFloat(calculateAchievement(a));
      valB = parseFloat(calculateAchievement(b));
      break;
    default:
      valA = 0;
      valB = 0;
  }

  if (valA < valB) return sortOrder === "asc" ? -1 : 1;
  if (valA > valB) return sortOrder === "asc" ? 1 : -1;
  return 0;
});

  return (
    <div>
      {/* Desktop View */}
      <div className="hidden lg:block">
        {/* PDP Target Card */}
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
          <div className="bg-Dustyblue text-white">
            <div 
              className="grid text-center font-medium text-xs"
              style={{ gridTemplateColumns: `1fr repeat(${machineNames.length}, 1fr)` }}
            >
              <div className="py-1.5 px-4 border border-grey2 border-t-0 border-l-0 border-b-0">PDP Target</div>
              {machineNames.map((machine, idx) => (
                <div 
                  key={machine} 
                  className={`py-1.5 px-4 border border-grey2 border-t-0 border-l-0 border-b-0 ${idx === machineNames.length - 1 ? 'border-r-0' : ''}`}
                >
                  Active Machine Population - {machine}
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white">
            <div 
              className="grid text-center text-gray-700 text-xs"
              style={{ gridTemplateColumns: `1fr repeat(${machineNames.length}, 1fr)` }}
            >
              <div className="py-1 px-4 border border-grey2 border-t-0 border-l-0 font-normal"></div>
              {machineNames.map((machine, idx) => (
                <div 
                  key={machine} 
                  className={`py-1 px-4 border border-grey2 border-t-0 border-l-0 font-normal ${idx === machineNames.length - 1 ? 'border-r-0' : ''}`}
                >
                  {pdpTargets[`Active Machine Population - ${machine}`] || "-"}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Main Machine Population Table */}
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-4">
          <div className="overflow-x-auto">
            <table 
            ref={formRef}
            className="w-full table-fixed" style={{ borderCollapse: 'collapse' }}>
              <colgroup>
                <col className="w-[20%]" />
                <col className="w-[10%]" />
                <col className="w-[10%]" />
                <col className="w-[10%]" />
                <col className="w-[10%]" />
                <col className="w-[15%]" />
                <col className="w-[15%]" />
                <col className="w-[10%]" />
              </colgroup>
           <thead>
  <tr className="bg-Dustyblue text-white">
    {/* Vehicles */}
    <th
      className="border-r border-white px-3 py-1.5 font-medium border-b border-Dustyblue text-xs text-center cursor-pointer select-none"
      onClick={() => handleSort("vehicle")}
    >
      <div className="flex items-center gap-1">
        Vehicles
        {sortKey !== "vehicle" && (
          <ChevronsUpDown className="w-3 h-3 text-white" />
        )}
        {sortKey === "vehicle" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "vehicle" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* Q1–Q4 */}
    {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
      <th
        key={quarter}
        className="border-r border-white px-3 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 text-xs cursor-pointer select-none"
        onClick={() => handleSort(quarter.toLowerCase())}
      >
        <div className="flex items-center justify-center gap-1">
          {quarter}
          {sortKey === quarter.toLowerCase() && sortOrder === "asc" && (
            <ChevronUp className="w-3 h-3 text-white" />
          )}
          {sortKey === quarter.toLowerCase() && sortOrder === "desc" && (
            <ChevronDown className="w-3 h-3 text-white" />
          )}
        </div>
      </th>
    ))}

    {/* Actual */}
    <th
      className="border-r border-white px-3 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 text-xs cursor-pointer select-none"
      onClick={() => handleSort("actual")}
    >
      <div className="flex items-center justify-center gap-1">
        Actual
        {sortKey === "actual" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "actual" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* PDP Target */}
    <th
      className="border-r border-white px-3 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 text-xs cursor-pointer select-none"
      onClick={() => handleSort("pdpTarget")}
    >
      <div className="flex items-center justify-center gap-1">
        PDP Target
        {sortKey === "pdpTarget" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "pdpTarget" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* Achievement % */}
    <th
      className="px-3 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 text-xs cursor-pointer select-none"
      onClick={() => handleSort("achievement")}
    >
      <div className="flex items-center justify-center gap-1">
        Achievement %
        {sortKey === "achievement" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "achievement" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>
  </tr>
</thead>

              <tbody>
                {sortedMachineNames.map((machine) => {
                  const actualSum = calculateActual(machine);

                  return (
                    <tr key={machine}>
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-left text-xs">
                        {machine}
                      </td>

                      {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
                        <td
                          key={quarter}
                          className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs"
                        >
                          {mode === "fill" ? (
                           <input
  type="text"
  value={machineData[machine][quarter] || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleInputChange(machine, quarter, value);
    }
  }}
  className="w-full text-center border border-gray-300 px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-darkblue1"
/>
                          ) : (
                            machineData[machine][quarter] || "-"
                          )}
                        </td>
                      ))}

                      {/* Actual: sum of Q1-Q4, read-only */}
                      <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-center text-xs">
                        {mode === "fill" ? (
                          <input
                            type="number"
                            value={actualSum}
                            readOnly
                            className="w-full text-center border border-gray-300 px-2 py-1 text-xs bg-gray-100 cursor-not-allowed"
                          />
                        ) : (
                          actualSum
                        )}
                      </td>

                      {/* PDP Target */}
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs">
                        {pdpTargets[`Active Machine Population - ${machine}`] || "-"}
                      </td>

                      {/* Achievement */}
                      <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1 text-center text-xs">
                        {calculateAchievement(machine)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Mobile/Tablet View */}
      <div className="lg:hidden">
        {/* PDP Target Card */}
        <div className="bg-white shadow-md border-2 border-Dustyblue overflow-hidden mb-6">
          <div className="bg-Dustyblue text-white">
            <div className="grid grid-cols-1 text-center font-medium text-xs sm:text-sm">
              <div className="py-2 px-2 sm:px-4 border-b border-white">PDP Target</div>
            </div>
            <div 
              className="grid text-center font-medium text-xs sm:text-sm"
              style={{ gridTemplateColumns: `repeat(${machineNames.length}, 1fr)` }}
            >
              {machineNames.map((machine, idx) => (
                <div 
                  key={machine} 
                  className={`py-2 px-2 sm:px-4 ${idx < machineNames.length - 1 ? 'border-r border-white' : ''}`}
                >
                  Active Machine Population - {machine}
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white">
            <div 
              className="grid text-center text-gray-700 border-t border-Dustyblue text-xs sm:text-sm"
              style={{ gridTemplateColumns: `repeat(${machineNames.length}, 1fr)` }}
            >
              {machineNames.map((machine, idx) => (
                <div 
                  key={machine} 
                  className={`py-2 px-2 sm:px-4 font-medium ${idx < machineNames.length - 1 ? 'border-r border-Dustyblue' : ''}`}
                >
                  {pdpTargets[`Active Machine Population - ${machine}`] || "-"}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile Cards */}
        <div className="space-y-4 mb-6">
          {machineNames.map((machine) => {
            const actualSum = calculateActual(machine);

            return (
              <div key={machine} className="bg-white shadow-md border-2 border-Dustyblue p-4">
                <h3 className="font-semibold text-darkblue1 mb-3 pb-2 border-b-2 border-Dustyblue text-sm">
                  {machine}
                </h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  {["Q1", "Q2", "Q3", "Q4"].map((quarter) => (
                    <div key={quarter} className="flex justify-between">
                      <span className="font-medium text-gray-600">{quarter}:</span>
                      {mode === "fill" ? (
                       <input
  type="text"
  value={machineData[machine][quarter] || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleInputChange(machine, quarter, value);
    }
  }}
  className="w-full text-center border border-gray-300 px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-darkblue1"
/>
                      ) : (
                        <span className="text-gray-800">{machineData[machine][quarter] || "-"}</span>
                      )}
                    </div>
                  ))}

                  {/* Actual: sum of Q1-Q4, read-only */}
                  <div className="flex justify-between col-span-2">
                    <span className="font-medium text-gray-600">Actual:</span>
                    {mode === "fill" ? (
                      <input
                        type="number"
                        value={actualSum}
                        readOnly
                        className="w-20 text-center border border-gray-300 px-2 py-1 text-sm bg-gray-100 cursor-not-allowed"
                      />
                    ) : (
                      <span className="text-gray-800">{actualSum}</span>
                    )}
                  </div>

                  {/* PDP Target */}
                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">PDP Target:</span>
                    <span className="text-gray-800">
                      {pdpTargets[`Active Machine Population - ${machine}`] || "-"}
                    </span>
                  </div>

                  {/* Achievement */}
                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">Achievement:</span>
                    <span className="font-semibold text-darkblue1">
                      {calculateAchievement(machine)}%
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Save Button */}
      {mode === "fill" && (
        <div className="flex justify-end mb-6">
          <button
            onClick={handleSave}
            disabled={saving}
            className="bg-darkblue1 text-white px-8 py-1.5 font-medium text-xs 
                       hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 
                       transition w-full sm:w-auto
                       disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? "Saving..." : "Save"}
          </button>
        </div>
      )}
    </div>
  );
};

export default MachinePopulation;