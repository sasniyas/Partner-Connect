import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import axios from "axios";
import { fetchEquipmentSummaryData } from "../../../services/dealerInvestment/dealerInvestmentEquipmentSummary.service";
import { API } from "../../../api";
import { useMemo } from "react";
import {ChevronDown,ChevronUp,ChevronsUpDown} from "lucide-react";
import { RotateCcw } from "lucide-react";

// ⭐ IMPORT MBP SERVICE with constants
import {
  MBP_STATUS,
  fetchLatestMBPStatus,
  isMBPEditable,
  getMBPActions,
  submitMBP,
  requestMBPEdit,
  enableMBP,
  disableMBP,
} from "../../../services/dealerInvestment/Mbpstatusservice";
import Searchinput from "../../../Components/Searchinput";

// ═══════════════════════════════════════════════════════════════
// DEALER ROLES
// ═══════════════════════════════════════════════════════════════
const DEALER_ROLES = [
  "Dealer Parts Manager",
  "Dealer Finance Head",
  "Dealer Coordinator",
  "Dealer Sales Head",
  "Dealer CST Head",
  "Dealer CEO",
  "Dealer HR Head",
  "Dealer Principal"
];

// ═══════════════════════════════════════════════════════════════
// ADMIN ROLES
// ═══════════════════════════════════════════════════════════════
const ADMIN_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Uptime & Parts Manager",
  "Market Area Head"
];

// ============================================
// AUTH HEADERS HELPER
// ============================================
const getAuthHeaders = () => {
  const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
  return {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  };
};

const EquipmentsAttachments = ({ mode: propMode, dealerInvestmentId, investment: propInvestment, passedMake: propMake, passedType: propType }) => {
  const navigate = useNavigate();
  const location = useLocation();

  // ⭐ Get current user from Redux
  const user = useSelector((state) => state.user);
  const userRole = user?.data?.persona || user?.persona || user?.role || "";
const [searchQuery, setSearchQuery] = useState("");
  // ⭐ Check if current user is a dealer
  const isDealer = DEALER_ROLES.some(
    role => role.toLowerCase() === userRole.toLowerCase()
  );

  // ⭐ Check if current user is admin
  const isAdmin = ADMIN_ROLES.some(
    role => role.toLowerCase() === userRole.toLowerCase()
  );

  // Get investment from props or location.state
  const investment = propInvestment || location.state?.investment;
  const mode = propMode || location.state?.mode || "fill";

  // Get dealerInvestmentId from props, investment object, or location state
  const investmentId = dealerInvestmentId || investment?.id || location.state?.dealerInvestmentId || location.state?.investment?.id;

  // Get passed filters
  const passedMake = propMake || location.state?.selectedMake;
  const passedType = propType || location.state?.selectedType;

  // Loading and error states
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // ⭐ MBP Status States - Using MBP_STATUS constants
  const [mbpStatus, setMbpStatus] = useState(MBP_STATUS.SUBMITTED);
  const [mbpLoading, setMbpLoading] = useState(false);
  const [mbpActions, setMbpActions] = useState({});
const [quarterlySortKey, setQuarterlySortKey] = useState(null);
const [quarterlySortOrder, setQuarterlySortOrder] = useState(null);

  // Popup states
  const [showSubmitPopup, setShowSubmitPopup] = useState(false);
  const [showRequestPopup, setShowRequestPopup] = useState(false);
  const [requestLoading, setRequestLoading] = useState(false);

  // Dropdown states
  // const [selectedMake, setSelectedMake] = useState(passedMake || "Volvo");
  // const [selectedType, setSelectedType] = useState(passedType || "Equipments");
  const [selectedMake, setSelectedMake] = useState("");
const [selectedType, setSelectedType] = useState("");
  const [makeDropdownOpen, setMakeDropdownOpen] = useState(false);
  const [typeDropdownOpen, setTypeDropdownOpen] = useState(false);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);
const [targetSortKey, setTargetSortKey] = useState(null);
const [targetSortOrder, setTargetSortOrder] = useState(null);

const handleTargetSort = (key) => {
  if (targetSortKey === key) {
    // Toggle sorting
    setTargetSortOrder((prev) =>
      prev === "asc" ? "desc" : prev === "desc" ? null : "asc"
    );
    if (targetSortOrder === "desc") setTargetSortKey(null);
  } else {
    setTargetSortKey(key);
    setTargetSortOrder("asc");
  }
};


const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};
const handleQuarterlySort = (key) => {
  if (quarterlySortKey === key) {
    if (quarterlySortOrder === "asc") {
      setQuarterlySortOrder("desc");
    } else if (quarterlySortOrder === "desc") {
      setQuarterlySortKey(null);
      setQuarterlySortOrder(null);
    } else {
      setQuarterlySortOrder("asc");
    }
  } else {
    setQuarterlySortKey(key);
    setQuarterlySortOrder("asc");
  }
};


  // Update filters when navigating back
  useEffect(() => {
    if (passedMake) {
      setSelectedMake(passedMake);
      console.log("Updated selectedMake from props/navigation:", passedMake);
    }
    if (passedType) {
      setSelectedType(passedType);
      console.log("Updated selectedType from props/navigation:", passedType);
    }
  }, [passedMake, passedType]);

  // Refs for click outside detection
  const makeDropdownRef = useRef(null);
  const typeDropdownRef = useRef(null);

  // Data states
  const [targetData, setTargetData] = useState([
    { make: "Volvo", equipments: "0", attachments: "0" },
    { make: "SDLG", equipments: "0", attachments: "0" },
  ]);

  const [allData, setAllData] = useState({
    Volvo: {
      Equipments: {
        monthly: {
          "Monthly Business Plan": {},
          "Monthly Projection": {},
          Actuals: {},
          "Achievement %": {},
          "Accuracy %": {},
        },
        quarterly: {
          "Quarterly Business Plan": {},
          "Quarterly Projections": {},
          Actuals: {},
          "Achievement %": {},
          "Accuracy %": {},
        },
        stats: { ytdActuals: "0", pdpTarget: "0", achievement: "0.00" },
      },
      Attachments: {
        monthly: {
          "Monthly Business Plan": {},
          "Monthly Projection": {},
          Actuals: {},
          "Achievement %": {},
          "Accuracy %": {},
        },
        quarterly: {
          "Quarterly Business Plan": {},
          "Quarterly Projections": {},
          Actuals: {},
          "Achievement %": {},
          "Accuracy %": {},
        },
        stats: { ytdActuals: "0", pdpTarget: "0", achievement: "0.00" },
      },
    },
    SDLG: {
      Equipments: {
        monthly: {
          "Monthly Business Plan": {},
          "Monthly Projection": {},
          Actuals: {},
          "Achievement %": {},
          "Accuracy %": {},
        },
        quarterly: {
          "Quarterly Business Plan": {},
          "Quarterly Projections": {},
          Actuals: {},
          "Achievement %": {},
          "Accuracy %": {},
        },
        stats: { ytdActuals: "0", pdpTarget: "0", achievement: "0.00" },
      },
      Attachments: {
        monthly: {
          "Monthly Business Plan": {},
          "Monthly Projection": {},
          Actuals: {},
          "Achievement %": {},
          "Accuracy %": {},
        },
        quarterly: {
          "Quarterly Business Plan": {},
          "Quarterly Projections": {},
          Actuals: {},
          "Achievement %": {},
          "Accuracy %": {},
        },
        stats: { ytdActuals: "0", pdpTarget: "0", achievement: "0.00" },
      },
    },
  });

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        makeDropdownRef.current &&
        !makeDropdownRef.current.contains(event.target)
      ) {
        setMakeDropdownOpen(false);
      }
      if (
        typeDropdownRef.current &&
        !typeDropdownRef.current.contains(event.target)
      ) {
        setTypeDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // ⭐ FETCH LATEST MBP STATUS FROM DATABASE
  const fetchLatestMBPStatusFromDB = async () => {
    if (!investmentId) {
      console.warn("⚠️ No investmentId available to fetch MBP status");
      return;
    }

    try {
      setMbpLoading(true);
      console.log("📡 Fetching latest MBP status for investment ID:", investmentId);

      const actualStatus = await fetchLatestMBPStatus(investmentId);
      console.log("✅ Fetched MBP Status:", actualStatus);
      setMbpStatus(actualStatus);
    } catch (error) {
      console.warn("⚠️ Could not fetch MBP status:", error.message);
      setMbpStatus(MBP_STATUS.SUBMITTED);
    } finally {
      setMbpLoading(false);
    }
  };

  // ⭐ UPDATE MBP ACTIONS WHEN STATUS CHANGES
  useEffect(() => {
    const actions = getMBPActions(mbpStatus, userRole, DEALER_ROLES, ADMIN_ROLES);
    setMbpActions(actions);
    console.log("🎯 MBP Actions updated:", actions);
  }, [mbpStatus, userRole]);

  // Debug logging
  useEffect(() => {
    console.log("EquipmentsAttachments props:", { dealerInvestmentId, investment, mode, propMake, propType });
    console.log("Resolved investmentId:", investmentId);
    console.log("Filter state - Make:", selectedMake, "Type:", selectedType);
    console.log("User Role:", userRole, "isDealer:", isDealer, "isAdmin:", isAdmin);
    console.log("MBP Status:", mbpStatus, "Actions:", mbpActions);
  }, [dealerInvestmentId, investment, mode, investmentId, selectedMake, selectedType, userRole, isDealer, isAdmin, mbpStatus, mbpActions]);

  // Fetch data on mount and when navigating back
  useEffect(() => {
    const loadData = async () => {
      if (!investmentId) {
        console.error("No dealer investment ID found. Props:", { dealerInvestmentId, investment });
        setError("No dealer investment ID provided. Please navigate from the main list.");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);

        // Get pdpId from investment object
        const pdpId = investment?.pdp_id || investment?.pdp_info?.id || null;

        console.log("Fetching equipment summary data for investment:", investmentId, "pdpId:", pdpId);

        // ⭐ FETCH MBP STATUS FROM DATABASE
        await fetchLatestMBPStatusFromDB();

        // Fetch equipment data
        const response = await fetchEquipmentSummaryData(investmentId, pdpId);

        if (response.status && response.data) {
          setTargetData(response.data.targetData);
          setAllData(response.data.allData);

          console.log("Equipment summary data loaded:", response.data);
        } else {
          setError("Failed to load equipment data");
        }
      } catch (err) {
        console.error("Error loading equipment summary:", err);
        setError("Error loading equipment data");
        toast.error("Failed to load equipment data");
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [investmentId, investment, location.key]);

  const months = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
  ];
  const quarters = ["Q1", "Q2", "Q3", "Q4"];

  // Get current data based on selected make and type
const effectiveMake = selectedMake || "Volvo";
const effectiveType = selectedType || "Equipments";

const currentData = allData[effectiveMake]?.[effectiveType] || {    monthly: {},
    quarterly: {},
    stats: { ytdActuals: "0", pdpTarget: "0", achievement: "0" },
  };

  // Calculate totals for monthly rows
  const calculateMonthlyTotal = (rowData) => {
    if (!rowData) return "";
    const total = months.reduce((sum, month) => {
      const value = parseInt(rowData[month]) || 0;
      return sum + value;
    }, 0);
    return total > 0 ? total.toString() : "";
  };

  // Calculate totals for quarterly rows
  const calculateQuarterlyTotal = (rowData) => {
    if (!rowData) return "";
    const total = quarters.reduce((sum, quarter) => {
      const value = parseInt(rowData[quarter]) || 0;
      return sum + value;
    }, 0);
    return total > 0 ? total.toString() : "";
  };
const sortedMonthlyRows = useMemo(() => {
  const rows = Object.keys(currentData.monthly || {});

  if (!sortKey || !sortOrder) return rows;

  return [...rows].sort((a, b) => {
    let valA;
    let valB;

    // Sort by row name
    if (sortKey === "row") {
      valA = a;
      valB = b;
    }
    // Sort by total column
    else if (sortKey === "total") {
      valA = calculateMonthlyTotal(currentData.monthly[a]);
      valB = calculateMonthlyTotal(currentData.monthly[b]);
    }
    // Sort by specific month
    else {
      valA = currentData.monthly[a]?.[sortKey] || 0;
      valB = currentData.monthly[b]?.[sortKey] || 0;
    }

    // numeric sort
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // string sort
    const strA = valA?.toString().toLowerCase() || "";
    const strB = valB?.toString().toLowerCase() || "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [currentData.monthly, sortKey, sortOrder]);
const filteredMonthlyRows = useMemo(() => {
  if (!searchQuery) return sortedMonthlyRows;

  return sortedMonthlyRows.filter((row) => {
    const rowData = currentData.monthly[row];

    return (
      row.toLowerCase().includes(searchQuery.toLowerCase()) ||
      months.some((m) =>
        rowData?.[m]?.toString().toLowerCase().includes(searchQuery.toLowerCase())
      ) ||
      calculateMonthlyTotal(rowData)
        ?.toString()
        .includes(searchQuery)
    );
  });
}, [sortedMonthlyRows, searchQuery, currentData]);
const sortedQuarterlyRows = useMemo(() => {
  const rows = Object.keys(currentData.quarterly || {});
  if (!quarterlySortKey || !quarterlySortOrder) return rows;

  return [...rows].sort((a, b) => {
    let valA, valB;

    if (quarterlySortKey === "quarterlyRow") {
      valA = a.toLowerCase();
      valB = b.toLowerCase();
      return quarterlySortOrder === "asc" ? valA.localeCompare(valB) : valB.localeCompare(valA);
    }

    if (quarterlySortKey === "quarterlyTotal") {
      valA = parseInt(calculateQuarterlyTotal(currentData.quarterly[a])) || 0;
      valB = parseInt(calculateQuarterlyTotal(currentData.quarterly[b])) || 0;
    } else {
      valA = parseInt(currentData.quarterly[a]?.[quarterlySortKey]) || 0;
      valB = parseInt(currentData.quarterly[b]?.[quarterlySortKey]) || 0;
    }

    return quarterlySortOrder === "asc" ? valA - valB : valB - valA;
  });
}, [currentData.quarterly, quarterlySortKey, quarterlySortOrder]);
const filteredQuarterlyRows = useMemo(() => {
  if (!searchQuery) return sortedQuarterlyRows;

  return sortedQuarterlyRows.filter((row) => {
    const rowData = currentData.quarterly[row];

    return (
      row.toLowerCase().includes(searchQuery.toLowerCase()) ||
      quarters.some((q) =>
        rowData?.[q]?.toString().toLowerCase().includes(searchQuery.toLowerCase())
      ) ||
      calculateQuarterlyTotal(rowData)
        ?.toString()
        .includes(searchQuery)
    );
  });
}, [sortedQuarterlyRows, searchQuery, currentData]);

const sortedTargetData = useMemo(() => {
  if (!targetSortKey || !targetSortOrder) return targetData;

  return [...targetData].sort((a, b) => {
    let valA = a[targetSortKey];
    let valB = b[targetSortKey];

    // Convert numeric strings to numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      valA = Number(valA);
      valB = Number(valB);
      return targetSortOrder === "asc" ? valA - valB : valB - valA;
    }

    // Compare strings
    const strA = valA?.toString().toLowerCase() || "";
    const strB = valB?.toString().toLowerCase() || "";

    if (strA < strB) return targetSortOrder === "asc" ? -1 : 1;
    if (strA > strB) return targetSortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [targetData, targetSortKey, targetSortOrder]);

  // ⭐ ADMIN: ENABLE MBP
  const handleEnableMBP = async () => {
    try {
      setMbpLoading(true);
      console.log("🔄 Enabling MBP...");

      const response = await enableMBP(investmentId);

      if (response.status) {
        toast.success("✅ MBP Enabled! Dealer can now edit MBP values.");

        // ⭐ Fetch actual status from DB
        const actualStatus = await fetchLatestMBPStatus(investmentId);
        setMbpStatus(actualStatus);
      } else {
        toast.error(response.message || "Failed to enable MBP");
      }
    } catch (err) {
      console.error("❌ Error enabling MBP:", err);
      toast.error("Failed to enable MBP. Please try again.");
    } finally {
      setMbpLoading(false);
    }
  };

  // ⭐ ADMIN: DISABLE MBP
  const handleDisableMBP = async () => {
    try {
      setMbpLoading(true);
      console.log("🔄 Disabling MBP...");

      const response = await disableMBP(investmentId);

      if (response.status) {
        toast.info("🔒 MBP Disabled. Dealers cannot edit.");

        // ⭐ Fetch actual status from DB
        const actualStatus = await fetchLatestMBPStatus(investmentId);
        setMbpStatus(actualStatus);
      } else {
        toast.error(response.message || "Failed to disable MBP");
      }
    } catch (err) {
      console.error("❌ Error disabling MBP:", err);
      toast.error("Failed to disable MBP. Please try again.");
    } finally {
      setMbpLoading(false);
    }
  };

  // ⭐ DEALER/ADMIN: SUBMIT MBP
  const handleSubmitMBPConfirm = async () => {
    try {
      setMbpLoading(true);
      console.log("📤 Submitting MBP...");

      const response = await submitMBP(investmentId);

      if (response.status) {
        setShowSubmitPopup(false);
        toast.success("✅ MBP submitted successfully!");

        // ⭐ Fetch actual status from DB
        const actualStatus = await fetchLatestMBPStatus(investmentId);
        setMbpStatus(actualStatus);
      } else {
        toast.error(response.message || "Failed to submit MBP");
      }
    } catch (err) {
      console.error("❌ Error submitting MBP:", err);
      toast.error("Failed to submit MBP. Please try again.");
    } finally {
      setMbpLoading(false);
    }
  };

  // ⭐ DEALER: REQUEST MBP EDIT
  const handleRequestMBPEditConfirm = async () => {
    try {
      setRequestLoading(true);
      console.log("📝 Requesting MBP Edit...");

      const response = await requestMBPEdit(investmentId);

      if (response.status) {
        setShowRequestPopup(false);
        toast.success("✅ MBP edit request sent to Administrator!");

        // ⭐ Fetch actual status from DB
        const actualStatus = await fetchLatestMBPStatus(investmentId);
        setMbpStatus(actualStatus);
      } else {
        toast.error(response.message || "Failed to send request");
      }
    } catch (err) {
      console.error("❌ Error requesting edit:", err);
      toast.error("Failed to send request. Please try again.");
    } finally {
      setRequestLoading(false);
    }
  };

  const handleFillEntries = () => {
    navigate("/DEALERINVESTMENT/ViewDealerInvestment/FillEntriesEquipment", {
      state: {
        investment: investment || { id: investmentId },
        selectedMake,
        selectedType,
        year: investment?.pdp_info?.year || new Date().getFullYear(),
        mode,
        dealerInvestmentId: investmentId,
        mbpStatus,
      },
    });
  };

  // Loading state
  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-darkblue1 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-sm text-gray-600">Loading equipment data...</span>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="text-center">
          <p className="text-red-500 mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="bg-darkblue1 text-white px-4 py-2 text-xs hover:bg-opacity-90"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  // ⭐ RENDER MBP ACTION BUTTONS BASED ON ROLE AND STATUS
  const renderMBPButtons = () => {
    // ═══════════════════════════════════════════════════════════════
    // ADMIN: Can Enable/Disable MBP and Submit MBP
    // ═══════════════════════════════════════════════════════════════
    if (isAdmin) {
      return (
        <>
          {/* Enable/Disable MBP Button */}
          <button
            onClick={mbpStatus === MBP_STATUS.ENABLED ? handleDisableMBP : handleEnableMBP}
            disabled={mbpLoading}
            className={`px-6 py-1 font-medium text-xs transition flex items-center gap-2 border ${
              mbpStatus === MBP_STATUS.ENABLED
                ? "bg-green text-white border-green hover:bg-white hover:text-green"
                : "bg-darkblue1 text-white border-darkblue1 hover:bg-white hover:text-darkblue1"
            } disabled:opacity-50 disabled:cursor-not-allowed`}
            title={mbpStatus === MBP_STATUS.ENABLED ? "Click to disable MBP" : "Click to enable MBP"}
          >
            {mbpLoading ? (
              <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                  clipRule="evenodd"
                />
              </svg>
            )}
            {mbpStatus === MBP_STATUS.ENABLED ? "Disable MBP" : "Enable MBP"}
          </button>

          {/* Submit MBP Button - Only show when MBP is enabled */}
          {mbpStatus === MBP_STATUS.ENABLED && (
            <button
              onClick={() => setShowSubmitPopup(true)}
              disabled={mbpLoading}
              className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                  clipRule="evenodd"
                />
              </svg>
              Submit MBP
            </button>
          )}

          {/* Show status badge */}
          <div className={`px-3 py-1 text-xs font-semibold rounded text-white ${
            mbpStatus === MBP_STATUS.ENABLED ? "bg-green" :
            mbpStatus === MBP_STATUS.SUBMITTED ? "bg-blue" :
            mbpStatus === MBP_STATUS.REQUESTED ? "bg-yellow" :
            "bg-gray-500"
          }`}>
            Status: {mbpStatus}
          </div>
        </>
      );
    }

    // ═══════════════════════════════════════════════════════════════
    // DEALER: Can Save/Submit MBP, Request Edit after submission
    // ═══════════════════════════════════════════════════════════════
    if (isDealer) {
      // If MBP is submitted, show "Request MBP Edit" button
      if (mbpStatus === MBP_STATUS.SUBMITTED) {
        return (
          <>
            <button
              onClick={() => setShowRequestPopup(true)}
              disabled={mbpLoading}
              className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z"
                  clipRule="evenodd"
                />
              </svg>
              Request MBP Edit
            </button>

            {/* Show status badge */}
            <div className="px-3 py-1 text-xs font-semibold rounded text-white bg-blue-500">
              Status: Submitted
            </div>
          </>
        );
      }

      // MBP enabled - dealer can submit
      if (mbpStatus === MBP_STATUS.ENABLED || mbpStatus === MBP_STATUS.REQUESTED) {
        return (
          <>
            <button
              onClick={() => setShowSubmitPopup(true)}
              disabled={mbpLoading}
              className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                  clipRule="evenodd"
                />
              </svg>
              Submit MBP
            </button>

            {/* Show status badge */}
            <div className={`px-3 py-1 text-xs font-semibold rounded text-white ${
              mbpStatus === MBP_STATUS.REQUESTED ? "bg-yellow-500" : "bg-green-500"
            }`}>
              Status: {mbpStatus}
            </div>
          </>
        );
      }

      // MBP disabled - cannot edit
      return (
        <div className="px-3 py-1 text-xs font-semibold rounded text-white bg-gray-500">
          Status: Disabled (Cannot Edit)
        </div>
      );
    }

    // Other roles - no MBP actions
    return null;
  };

  return (
    <div>
      {/* Combined Target Table */}
      <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
        <table className="w-full border-collapse">
  <thead className="bg-Dustyblue text-white">
    <tr>
      {/* Make */}
     <th
  onClick={() => handleTargetSort("make")}
  className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 px-4 py-1.5 text-left font-medium text-xs select-none w-40"
>
  <div className="flex items-center gap-1">
    <span className="truncate">Make</span>
    <span className="flex-shrink-0">
      {targetSortKey === "make" ? (
        targetSortOrder === "asc" ? (
          <ChevronUp className="w-3 h-3 text-white" />
        ) : (
          <ChevronDown className="w-3 h-3 text-white" />
        )
      ) : (
        <ChevronsUpDown className="w-3 h-3 text-white" />
      )}
    </span>
  </div>
</th>

      {/* Equipments */}
      <th
        onClick={() => handleTargetSort("equipments")}
        className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 px-4 py-1.5 text-center font-medium text-xs select-none w-40"
      >
        <div className="flex items-center justify-center gap-1">
          Annual Target - Equipments
          {targetSortKey === "equipments" && targetSortOrder === "asc" && (
            <ChevronUp className="w-3 h-3 text-white" />
          )}
          {targetSortKey === "equipments" && targetSortOrder === "desc" && (
            <ChevronDown className="w-3 h-3 text-white" />
          )}
        </div>
      </th>

      {/* Attachments */}
      <th
        onClick={() => handleTargetSort("attachments")}
        className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 px-4 py-1.5 text-center font-medium text-xs select-none w-40"
      >
        <div className="flex items-center justify-center gap-1">
          Annual Target - Attachments
          {targetSortKey === "attachments" && targetSortOrder === "asc" && (
            <ChevronUp className="w-3 h-3 text-white" />
          )}
          {targetSortKey === "attachments" && targetSortOrder === "desc" && (
            <ChevronDown className="w-3 h-3 text-white" />
          )}
        </div>
      </th>
    </tr>
  </thead>

          <tbody>
            {sortedTargetData.map((row, index) => (
              <tr
                key={row.make}
                className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}
              >
                <td className="border border-grey2 border-t-0 border-l-0 px-4 py-1 font-medium text-xs">
                  {row.make}
                </td>
                <td className="border border-grey2 border-t-0 border-l-0 px-4 py-1 text-center text-xs">
                  {row.equipments}
                </td>
                <td className="border border-grey2 border-t-0 border-l-0 px-4 py-1 text-center text-xs">
                  {row.attachments}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Dropdowns and Action Buttons */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-2">
        
        {/* Dropdowns */}
<div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto items-center">

  {/* 🔍 SEARCH INPUT */}
  <div className="w-full sm:w-64">
    <Searchinput
      value={searchQuery}
      onChange={(e) => setSearchQuery(e.target.value)}
      placeholder="Search"
      iconColor="text-black"
      bgColor="bg-FrostWhite"
      borderColor="border-black/60"
      textColor="text-black"
      shadow="shadow-none"
      inputPadding="pl-6 pr-3 py-1"
      iconSize="w-3 h-3"
      iconLeft="left-3"
      inputWidth="w-full"
      focusRing="focus:ring-1 focus:ring-black/60"
      hoverInputClasses="hover:bg-white hover:border-black/60"
    />
  </div>          
          {/* Make Dropdown */}
        <div ref={makeDropdownRef} className="relative w-full sm:w-48">
  <button
  onClick={() => {
    setMakeDropdownOpen(!makeDropdownOpen);
    setTypeDropdownOpen(false);
  }}
  onKeyDown={(e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      setMakeDropdownOpen(true);
    }
    if (e.key === "Escape") {
      setMakeDropdownOpen(false);
    }
  }}

  className={`flex items-center w-full px-3 h-8 text-xs border border-black/60 bg-white ${
    selectedMake ? "text-black font-medium" : "text-gray-400"
  } ${makeDropdownOpen ? "border-b-0 rounded-b-none" : ""}`}
>
  <span className="truncate">
    {selectedMake || "Equipment Make"}
  </span>

  {/* RIGHT SIDE ICONS */}
  <div className="flex items-center gap-1 ml-auto">

    {/* 🔥 CLEAR BUTTON */}
    {selectedMake && (
      <span
        onClick={(e) => {
          e.stopPropagation(); // prevent dropdown open
          setSelectedMake("");
        }}
        className="p-0.5 rounded hover:bg-gray-100 text-gray-500 hover:text-black cursor-pointer"
        title="Clear filter"
      >
        {/* Rotate Icon */}
                    <RotateCcw className="w-3.5 h-3.5" />

      </span>
    )}

    {/* DROPDOWN ARROW */}
    <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
   className={`w-5 h-5 text-black transition-transform duration-300 ${
        makeDropdownOpen ? "rotate-180" : ""
      }`}
    fill="none"
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
  </div>
</button>

  {makeDropdownOpen && (
    <div className="absolute z-50 w-full bg-white border border-black/60 border-t-0 shadow-lg max-h-40 overflow-auto">
      
      {/* Volvo */}
      <div
        tabIndex={0}
        onClick={() => {
          setSelectedMake("Volvo");
          setMakeDropdownOpen(false);
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            setSelectedMake("Volvo");
            setMakeDropdownOpen(false);
          }
        }}
        className="px-3 py-1 text-xs cursor-pointer hover:bg-gray-100 focus:bg-gray-100 outline-none"
      >
        Volvo
      </div>

      {/* SDLG */}
      <div
        tabIndex={0}
        onClick={() => {
          setSelectedMake("SDLG");
          setMakeDropdownOpen(false);
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            setSelectedMake("SDLG");
            setMakeDropdownOpen(false);
          }
        }}
        className="px-3 py-1 text-xs cursor-pointer hover:bg-gray-100 focus:bg-gray-100 outline-none"
      >
        SDLG
      </div>

    </div>
  )}
</div>

     <div ref={typeDropdownRef} className="relative w-full sm:w-48">
  <button
    onClick={() => {
      setTypeDropdownOpen(!typeDropdownOpen);
      setMakeDropdownOpen(false);
    }}
    onKeyDown={(e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        setTypeDropdownOpen(true);
      }
      if (e.key === "Escape") {
        setTypeDropdownOpen(false);
      }
    }}
    className={`flex items-center w-full px-3 h-8 text-xs border border-black/60 bg-white ${
      selectedType ? "text-black font-medium" : "text-gray-400"
    } ${typeDropdownOpen ? "border-b-0 rounded-b-none" : ""}`}
  >
    {/* LEFT TEXT */}
    <span className="truncate">
      {selectedType || "Equipment Type"}
    </span>

    {/* RIGHT ICONS */}
    <div className="flex items-center gap-1 ml-auto">

      {/* 🔄 CLEAR BUTTON */}
      {selectedType && (
        <span
          onClick={(e) => {
            e.stopPropagation();
            setSelectedType("");
          }}
          className="p-0.5 rounded hover:bg-gray-100 text-gray-500 hover:text-black cursor-pointer"
          title="Clear filter"
        >
                             <RotateCcw className="w-3.5 h-3.5" />

        </span>
      )}

      {/* DROPDOWN ICON */}
      <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
   className={`w-5 h-5 text-black transition-transform duration-300 ${
          typeDropdownOpen ? "rotate-180" : ""
        }`}
    fill="none"
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
    </div>
  </button>

  {typeDropdownOpen && (
    <div className="absolute z-50 w-full bg-white border border-black/60 border-t-0 shadow-lg max-h-40 overflow-auto">
      
      {/* Equipments */}
      <div
        tabIndex={0}
        onClick={() => {
          setSelectedType("Equipments");
          setTypeDropdownOpen(false);
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            setSelectedType("Equipments");
            setTypeDropdownOpen(false);
          }
        }}
        className="px-3 py-1 text-xs cursor-pointer hover:bg-gray-100 focus:bg-gray-100 outline-none"
      >
        Equipments
      </div>

      {/* Attachments */}
      <div
        tabIndex={0}
        onClick={() => {
          setSelectedType("Attachments");
          setTypeDropdownOpen(false);
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            setSelectedType("Attachments");
            setTypeDropdownOpen(false);
          }
        }}
        className="px-3 py-1 text-xs cursor-pointer hover:bg-gray-100 focus:bg-gray-100 outline-none"
      >
        Attachments
      </div>

    </div>
  )}
</div>
</div>

        {/* Action Buttons */}
        <div className="flex gap-3 w-full lg:w-auto flex-wrap">
          {/* ⭐ Render MBP buttons based on role and status */}
          {renderMBPButtons()}

          {/* Fill Entries Button - Always visible */}
          <button
            onClick={handleFillEntries}
            className="flex-1 lg:flex-none bg-darkblue1 text-white border border-darkblue1 px-4 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center justify-center gap-2"
          >
            <span className="text-xs">→</span>
            Fill Entries
          </button>
        </div>
      </div>

      {/* Submit MBP Confirmation Popup */}
      {showSubmitPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-96 max-w-md mx-4">
            <h3 className="text-lg font-semibold text-darkblue1 mb-4">Confirm MBP Submission</h3>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to submit the Monthly Business Plan for <strong>{selectedType} - {selectedMake}</strong>?
              This action cannot be undone. You will need to request Administrator approval to edit after submission.
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setShowSubmitPopup(false)}
                disabled={mbpLoading}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded transition disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitMBPConfirm}
                disabled={mbpLoading}
                className="px-4 py-2 text-sm font-medium text-white bg-darkblue1 hover:bg-white hover:text-darkblue1 border border-darkblue1 rounded transition disabled:opacity-50 flex items-center gap-2"
              >
                {mbpLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Submitting...
                  </>
                ) : (
                  "Confirm Submit"
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ⭐ Request MBP Edit Popup */}
      {showRequestPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-96 max-w-md mx-4">
            <h3 className="text-lg font-semibold text-darkblue1 mb-4">Request MBP Edit</h3>
            <p className="text-sm text-gray-600 mb-6">
              Your MBP for <strong>{selectedType} - {selectedMake}</strong> has already been submitted.
              Do you want to send a request to the Administrator to re-enable editing?
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setShowRequestPopup(false)}
                disabled={requestLoading}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded transition disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleRequestMBPEditConfirm}
                disabled={requestLoading}
                className="px-4 py-2 text-sm font-medium text-white bg-darkblue1 hover:bg-white hover:text-darkblue1 border border-darkblue1 rounded transition disabled:opacity-50 flex items-center gap-2"
              >
                {requestLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Sending...
                  </>
                ) : (
                  "Send Request"
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Dynamic Data Section */}
      <div className="border-Dustyblue overflow-hidden mb-6">
        {/* Header with Stats */}
        <div className="bg-white px-4 py-3 border border-Dustyblue">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <h3 className="text-base font-semibold text-darkblue1">
{effectiveType} - {effectiveMake}           
 </h3>
            <div className="flex flex-wrap gap-4 text-xs text-black">
              <span>
                <strong>YTD Actuals:</strong> {currentData.stats.ytdActuals}
              </span>
              <span>
                <strong>PDP Targets:</strong> {currentData.stats.pdpTarget}
              </span>
              <span>
                <strong>Achievement:</strong> {currentData.stats.achievement}%
              </span>
            </div>
          </div>
        </div>

        {/* Combined Monthly & Quarterly Table */}
        <div className="overflow-x-auto bg-white border border-Dustyblue">
          <table className="w-full border-collapse border text-xs" style={{ tableLayout: 'fixed' }}>
            {/* Column widths definition */}
            <colgroup>
              <col style={{ width: '15%' }} />
              {months.map((_, i) => (
                <col key={i} style={{ width: '6.15%' }} />
              ))}
              <col style={{ width: '6.5%' }} />
            </colgroup>

            {/* Monthly Headers */}
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th
  onClick={() => handleSort("row")}
  className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 font-normal text-left"
>
  <div className="flex items-center gap-1">
    Monthly
    {sortKey !== "row" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

    {sortKey === "row" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "row" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

                {months.map((month) => (
                 <th
    key={month}
    onClick={() => handleSort(month)}
    className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-normal select-none"
  >
    <div className="flex items-center justify-center gap-1">
      {month}
      {sortKey === month && sortOrder === "asc" && (
        <ChevronUp className="w-3 h-3 text-white" />
      )}
      {sortKey === month && sortOrder === "desc" && (
        <ChevronDown className="w-3 h-3 text-white" />
      )}
    </div>
  </th>
                ))}
               <th
  onClick={() => handleSort("total")}
  className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 px-3 py-1.5 text-center font-normal select-none"
>
  <div className="flex items-center justify-center gap-1">
    Total
    {sortKey === "total" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3 text-white" />
    )}
    {sortKey === "total" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3 text-white" />
    )}
  </div>
</th>

              </tr>
            </thead>

            {/* Monthly Data */}
            <tbody>
{filteredMonthlyRows.map((row) => (
                <tr key={row} className="bg-white">
                  <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 font-medium">
                    {row}
                  </td>
                  {months.map((month) => (
                    <td
                      key={month}
                      className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-black"
                    >
                      {currentData.monthly[row]?.[month] || ""}
                    </td>
                  ))}
                  <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1 text-center text-black font-medium">
                    {calculateMonthlyTotal(currentData.monthly[row])}
                  </td>
                </tr>
              ))}
              {filteredMonthlyRows.length === 0 && (
  <tr>
    <td colSpan={14} className="text-center py-3 text-gray-400">
      No data found
    </td>
  </tr>
)}
            </tbody>

            {/* Quarterly Headers */}
         <thead className="bg-Dustyblue text-white">
  <tr>
    {/* Row Name */}
    <th
      onClick={() => handleQuarterlySort("quarterlyRow")}
      className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-left font-normal select-none"
    >
      <div className="flex items-center gap-1">
        Quarterly
          {quarterlySortKey !== "quarterlyRow" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

        {quarterlySortKey === "quarterlyRow" && quarterlySortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {quarterlySortKey === "quarterlyRow" && quarterlySortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* Q1 */}
    <th
      colSpan={3}
      onClick={() => handleQuarterlySort("Q1")}
      className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-normal select-none"
    >
      <div className="flex items-center justify-center gap-1">
        Q1
        {quarterlySortKey === "Q1" && quarterlySortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {quarterlySortKey === "Q1" && quarterlySortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* Q2 */}
    <th
      colSpan={3}
      onClick={() => handleQuarterlySort("Q2")}
      className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-normal select-none"
    >
      <div className="flex items-center justify-center gap-1">
        Q2
        {quarterlySortKey === "Q2" && quarterlySortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {quarterlySortKey === "Q2" && quarterlySortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* Q3 */}
    <th
      colSpan={3}
      onClick={() => handleQuarterlySort("Q3")}
      className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-normal select-none"
    >
      <div className="flex items-center justify-center gap-1">
        Q3
        {quarterlySortKey === "Q3" && quarterlySortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {quarterlySortKey === "Q3" && quarterlySortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* Q4 */}
    <th
      colSpan={3}
      onClick={() => handleQuarterlySort("Q4")}
      className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-normal select-none"
    >
      <div className="flex items-center justify-center gap-1">
        Q4
        {quarterlySortKey === "Q4" && quarterlySortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {quarterlySortKey === "Q4" && quarterlySortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* Total */}
    <th
      onClick={() => handleQuarterlySort("quarterlyTotal")}
      className="cursor-pointer border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 px-3 py-1.5 text-normal font-semibold select-none"
    >
      <div className="flex items-center justify-center gap-1">
        Total
        {quarterlySortKey === "quarterlyTotal" && quarterlySortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {quarterlySortKey === "quarterlyTotal" && quarterlySortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>
  </tr>
</thead>

            {/* Quarterly Data */}
         <tbody>
  {filteredQuarterlyRows.map((row) => (
    <tr key={row} className="bg-white">
      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 font-medium text-black">
        {row}
      </td>
      {quarters.map((quarter) => (
        <td
          key={quarter}
          colSpan={3}
          className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-black"
        >
          {currentData.quarterly[row]?.[quarter] || ""}
        </td>
      ))}
      <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1 text-center text-black font-medium">
        {calculateQuarterlyTotal(currentData.quarterly[row])}
      </td>
    </tr>
  ))}
  {filteredMonthlyRows.length === 0 && (
  <tr>
    <td colSpan={14} className="text-center py-3 text-gray-400">
      No data found
    </td>
  </tr>
)}
</tbody>

          </table>
        </div>
      </div>
    </div>
  );
};

export default EquipmentsAttachments;