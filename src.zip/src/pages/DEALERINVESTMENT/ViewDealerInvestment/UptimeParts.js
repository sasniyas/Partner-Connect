import React, { useState, useRef, useEffect, } from "react";
import { useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import { useMemo } from "react";
import { ChevronUp,ChevronDown,ChevronsUpDown } from "lucide-react";
import {useKeyboardNavigation} from "../../../util/useKeyboardNavigation"
import {
  fetchAllUptimeData,
  updateMultipleDealerInvestmentUptimeMbp,
  updateMultipleDealerInvestmentUptimeProjection,
  updateMultipleDealerInvestmentUptimeActuals,
  MONTH_DISPLAY,
  MONTH_FIELDS,
} from "../../../services/dealerInvestment/dealerInvestmentUptime.service";

// ═══════════════════════════════════════════════════════════════
// DEALER ROLES - Can Fill/Save/Submit MBP, after submit need to request edit
// ═══════════════════════════════════════════════════════════════
const DEALER_ROLES = [
  "Dealer Parts Manager",
  "Dealer Finance Head",
  "Dealer Coordinator",
  "Dealer Sales Head",
  "Dealer CST Head",
  "Dealer CEO",
  "Dealer HR Head",
  "Dealer Principal"
];

// ═══════════════════════════════════════════════════════════════
// ADMIN ROLES - Can approve MBP edit requests (Enable/Disable MBP)
// ═══════════════════════════════════════════════════════════════
const ADMIN_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Uptime & Parts Manager",
  "Market Area Head"
];
const UptimeParts = ({ mode, investment }) => {
  const location = useLocation();
const formRef=useRef(null)
  // ⭐ Get current user from Redux
  const user = useSelector((state) => state.user);
  const userRole = user?.data?.persona || user?.persona || user?.role || "";

  // ⭐ Check if current user is a dealer
  const isDealer = DEALER_ROLES.some(
    role => role.toLowerCase() === userRole.toLowerCase()
  );

  // ⭐ Check if current user is admin
  const isAdmin = ADMIN_ROLES.some(
    role => role.toLowerCase() === userRole.toLowerCase()
  );

  // MBP States
  const [enableMBP, setEnableMBP] = useState(false); // Admin controls this
  const [mbpSubmitted, setMbpSubmitted] = useState(false); // Tracks if MBP is submitted
  const [showMBPSubmitModal, setShowMBPSubmitModal] = useState(false);
  const [showRequestPopup, setShowRequestPopup] = useState(false);
  const [requestLoading, setRequestLoading] = useState(false);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

  // Loading states
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  // Raw data for save operations (stores IDs)
  const [rawData, setRawData] = useState({ mbp: [], projection: [], actuals: [] });

  // Refs for click outside detection
  const makeDropdownRef = useRef(null);
  const categoryDropdownRef = useRef(null);
  const businessTypeDropdownRef = useRef(null);

  // Dropdown states
  const [selectedMake, setSelectedMake] = useState("Volvo");
  const [selectedCategory, setSelectedCategory] = useState("Parts");
  const [selectedBusinessType, setSelectedBusinessType] = useState("Retail");
  const [selectedCSA, setSelectedCSA] = useState(false);
  const [makeDropdownOpen, setMakeDropdownOpen] = useState(false);
  const [categoryDropdownOpen, setCategoryDropdownOpen] = useState(false);
  const [businessTypeDropdownOpen, setBusinessTypeDropdownOpen] = useState(false);

  // State for showing data table
  const [showDataTable, setShowDataTable] = useState(true);
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  // Click outside to close dropdowns
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (makeDropdownRef.current && !makeDropdownRef.current.contains(event.target)) {
        setMakeDropdownOpen(false);
      }
      if (categoryDropdownRef.current && !categoryDropdownRef.current.contains(event.target)) {
        setCategoryDropdownOpen(false);
      }
      if (businessTypeDropdownRef.current && !businessTypeDropdownRef.current.contains(event.target)) {
        setBusinessTypeDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Debug logging
  useEffect(() => {
    console.log("UptimeParts - User Role:", userRole, "isDealer:", isDealer, "isAdmin:", isAdmin);
  }, [userRole, isDealer, isAdmin]);

  // Target data for Parts, Lube, CSA (shows PDP Target values from API)
  const [targetData, setTargetData] = useState([
    {
      make: "Volvo",
      parts: { retail: "0", offtake: "0" },
      lube: { retail: "0", offtake: "0" },
      csa: "0"
    },
    {
      make: "SDLG",
      parts: { retail: "0", offtake: "0" },
      lube: { retail: "0", offtake: "0" },
      csa: "0"
    },
  ]);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return targetData;

  return [...targetData].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [targetData, sortKey, sortOrder]);




  // Create empty entry structure
  const createEmptyEntry = () => ({
    ids: { mbpId: null, projectionId: null, actualsId: null },
    monthly: {
      "Monthly Business Plan": { Jan: "", Feb: "", Mar: "", Apr: "", May: "", Jun: "", Jul: "", Aug: "", Sep: "", Oct: "", Nov: "", Dec: "" },
      "Monthly Projection": { Jan: "", Feb: "", Mar: "", Apr: "", May: "", Jun: "", Jul: "", Aug: "", Sep: "", Oct: "", Nov: "", Dec: "" },
      "Actuals": { Jan: "", Feb: "", Mar: "", Apr: "", May: "", Jun: "", Jul: "", Aug: "", Sep: "", Oct: "", Nov: "", Dec: "" },
      "Achievement %": { Jan: "", Feb: "", Mar: "", Apr: "", May: "", Jun: "", Jul: "", Aug: "", Sep: "", Oct: "", Nov: "", Dec: "" },
      "Accuracy %": { Jan: "", Feb: "", Mar: "", Apr: "", May: "", Jun: "", Jul: "", Aug: "", Sep: "", Oct: "", Nov: "", Dec: "" },
    },
    quarterly: {
      "Quarterly Business Plan": { Q1: "", Q2: "", Q3: "", Q4: "" },
      "Quarterly Projections": { Q1: "", Q2: "", Q3: "", Q4: "" },
      "Actuals": { Q1: "", Q2: "", Q3: "", Q4: "" },
      "Achievement %": { Q1: "", Q2: "", Q3: "", Q4: "" },
      "Accuracy %": { Q1: "", Q2: "", Q3: "", Q4: "" },
    },
    stats: { pdpTarget: "0", totalMBP: "0", ytdActuals: "0", ytdAchievement: "" }
  });

  // Initialize with empty structure - CONSISTENT NAMING with service
  const createEmptyDataStructure = () => ({
    Volvo: {
      Parts: {
        Retail: createEmptyEntry(),
        "Off take": createEmptyEntry(),
      },
      Lube: {
        Retail: createEmptyEntry(),
        "Off take": createEmptyEntry(),
      }
    },
    SDLG: {
      Parts: {
        Retail: createEmptyEntry(),
        "Off take": createEmptyEntry(),
      },
      Lube: {
        Retail: createEmptyEntry(),
        "Off take": createEmptyEntry(),
      }
    },
    CSA: createEmptyEntry()
  });

  const [allData, setAllData] = useState(createEmptyDataStructure());

  // ============================================
  // FETCH DATA FROM API
  // ============================================
  const loadData = async () => {
    if (!investment?.id) {
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetchAllUptimeData(investment.id);

      if (response.status && response.data) {
        const { targetData: apiTargetData, allData: apiAllData, rawData: apiRawData } = response.data;

        // Update target data if available
        if (apiTargetData && apiTargetData.length > 0) {
          setTargetData(apiTargetData);
        }

        // Update all data - service now uses consistent naming
        if (apiAllData) {
          setAllData(prev => {
            const merged = createEmptyDataStructure();

            // Merge Volvo data
            if (apiAllData.Volvo) {
              Object.keys(apiAllData.Volvo).forEach(category => {
                Object.keys(apiAllData.Volvo[category]).forEach(businessType => {
                  if (apiAllData.Volvo[category][businessType]) {
                    merged.Volvo[category][businessType] = apiAllData.Volvo[category][businessType];
                  }
                });
              });
            }

            // Merge SDLG data
            if (apiAllData.SDLG) {
              Object.keys(apiAllData.SDLG).forEach(category => {
                Object.keys(apiAllData.SDLG[category]).forEach(businessType => {
                  if (apiAllData.SDLG[category][businessType]) {
                    merged.SDLG[category][businessType] = apiAllData.SDLG[category][businessType];
                  }
                });
              });
            }

            // Merge CSA data
            if (apiAllData.CSA) {
              merged.CSA = apiAllData.CSA;
            }

            return merged;
          });
        }

        // Store raw data for save operations
        if (apiRawData) {
          setRawData(apiRawData);
        }

        // ⭐ Check MBP status from API response
        if (response.data.mbpSubmitted !== undefined) {
          setMbpSubmitted(response.data.mbpSubmitted);
        }
        if (response.data.mbpEnabled !== undefined) {
          setEnableMBP(response.data.mbpEnabled);
        }

        console.log("Uptime data loaded successfully");
      }
    } catch (err) {
      console.error("Error loading uptime data:", err);
      setError("Failed to load data");
      toast.error("Failed to load uptime data");
    } finally {
      setLoading(false);
    }
  };

  // Fetch data on mount
  useEffect(() => {
    loadData();
  }, [investment?.id]);

  // Get current data based on selections
  const getCurrentData = () => {
    if (selectedCSA) {
      return allData["CSA"] || createEmptyEntry();
    }
    if (selectedMake && selectedCategory && selectedBusinessType) {
      return allData[selectedMake]?.[selectedCategory]?.[selectedBusinessType] || createEmptyEntry();
    }
    return createEmptyEntry();
  };

  const currentData = getCurrentData();
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const quarters = ["Q1", "Q2", "Q3", "Q4"];
 const sortedMonthlyData = useMemo(() => {
  const monthlyRows = currentData ? Object.entries(currentData.monthly) : [];

  if (!sortKey || !sortOrder) return monthlyRows;

  return [...monthlyRows].sort(([rowA, dataA], [rowB, dataB]) => {
    let valA, valB;

    if (sortKey === "monthly") {
      // sort by row name (e.g., MBP, Projection, Actuals)
      valA = rowA.toLowerCase();
      valB = rowB.toLowerCase();
      if (valA < valB) return sortOrder === "asc" ? -1 : 1;
      if (valA > valB) return sortOrder === "asc" ? 1 : -1;
      return 0;
    } else if (sortKey === "total") {
      valA = calculateMonthlyTotal(dataA);
      valB = calculateMonthlyTotal(dataB);
    } else {
      // sort by month key
      valA = dataA[sortKey] ?? 0;
      valB = dataB[sortKey] ?? 0;
    }

    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    const strA = valA?.toString().toLowerCase() || "";
    const strB = valB?.toString().toLowerCase() || "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [currentData, sortKey, sortOrder]);
const sortedQuarterlyData = useMemo(() => {
  if (!currentData) return [];

  const quarterlyRows = Object.entries(currentData.quarterly); // [rowName, {Q1, Q2, Q3, Q4}]

  if (!sortKey || !sortOrder) return quarterlyRows;

  return [...quarterlyRows].sort(([rowA, dataA], [rowB, dataB]) => {
    let valA, valB;

    if (sortKey === "quarterly") {
      valA = rowA.toLowerCase();
      valB = rowB.toLowerCase();
      if (valA < valB) return sortOrder === "asc" ? -1 : 1;
      if (valA > valB) return sortOrder === "asc" ? 1 : -1;
      return 0;
    } else if (sortKey === "total") {
      valA = calculateQuarterlyTotal(dataA);
      valB = calculateQuarterlyTotal(dataB);
    } else if (quarters.includes(sortKey)) {
      valA = dataA[sortKey] ?? 0;
      valB = dataB[sortKey] ?? 0;
    }

    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    const strA = valA?.toString().toLowerCase() || "";
    const strB = valB?.toString().toLowerCase() || "";
    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [currentData, sortKey, sortOrder]);

  
useKeyboardNavigation({
   containerRef: formRef, // your popup div ref

  onSubmit: () => { 
    handleSave()
     handleSubmitMBP()
   
  },

  onCancel: () => {
    // resetForm(); // closes popup and resets state
  },
});
  // Handle input change for monthly data
  const handleMonthlyInputChange = (row, month, value) => {
    if (selectedCSA) {
      // Update CSA data
      setAllData((prev) => ({
        ...prev,
        CSA: {
          ...prev.CSA,
          monthly: {
            ...prev.CSA.monthly,
            [row]: {
              ...prev.CSA.monthly[row],
              [month]: value,
            }
          }
        }
      }));
    } else {
      // Update regular data
      setAllData((prev) => ({
        ...prev,
        [selectedMake]: {
          ...prev[selectedMake],
          [selectedCategory]: {
            ...prev[selectedMake][selectedCategory],
            [selectedBusinessType]: {
              ...prev[selectedMake][selectedCategory][selectedBusinessType],
              monthly: {
                ...prev[selectedMake][selectedCategory][selectedBusinessType].monthly,
                [row]: {
                  ...prev[selectedMake][selectedCategory][selectedBusinessType].monthly[row],
                  [month]: value,
                }
              }
            }
          }
        }
      }));
    }
  };

  // ============================================
  // SAVE HANDLER
  // ============================================
  const handleSave = async () => {
    setSaving(true);

    try {
      const dataToSave = getCurrentData();

      if (!dataToSave) {
        toast.warning("No data to save");
        setSaving(false);
        return;
      }

      const mbpUpdates = [];
      const projUpdates = [];
      const actualsUpdates = [];

      // Get IDs from data
      const ids = dataToSave.ids || {};

      // Prepare MBP update
      if (ids.mbpId && dataToSave.monthly["Monthly Business Plan"]) {
        const payload = { id: ids.mbpId };
        MONTH_DISPLAY.forEach((month, index) => {
          const value = dataToSave.monthly["Monthly Business Plan"][month];
          payload[MONTH_FIELDS[index]] = value !== "" && value !== null ? parseFloat(value) : null;
        });
        mbpUpdates.push(payload);
      } else if (ids.mbpIds && ids.mbpIds.length > 0) {
        // CSA case - multiple IDs
        const payload = { id: ids.mbpIds[0] };
        MONTH_DISPLAY.forEach((month, index) => {
          const value = dataToSave.monthly["Monthly Business Plan"][month];
          payload[MONTH_FIELDS[index]] = value !== "" && value !== null ? parseFloat(value) : null;
        });
        mbpUpdates.push(payload);
      }

      // Prepare Projection update
      if (ids.projectionId && dataToSave.monthly["Monthly Projection"]) {
        const payload = { id: ids.projectionId };
        MONTH_DISPLAY.forEach((month, index) => {
          const value = dataToSave.monthly["Monthly Projection"][month];
          payload[MONTH_FIELDS[index]] = value !== "" && value !== null ? parseFloat(value) : null;
        });
        projUpdates.push(payload);
      } else if (ids.projectionIds && ids.projectionIds.length > 0) {
        const payload = { id: ids.projectionIds[0] };
        MONTH_DISPLAY.forEach((month, index) => {
          const value = dataToSave.monthly["Monthly Projection"][month];
          payload[MONTH_FIELDS[index]] = value !== "" && value !== null ? parseFloat(value) : null;
        });
        projUpdates.push(payload);
      }

      // Prepare Actuals update
      if (ids.actualsId && dataToSave.monthly["Actuals"]) {
        const payload = { id: ids.actualsId };
        MONTH_DISPLAY.forEach((month, index) => {
          const value = dataToSave.monthly["Actuals"][month];
          payload[MONTH_FIELDS[index]] = value !== "" && value !== null ? parseFloat(value) : null;
        });
        actualsUpdates.push(payload);
      } else if (ids.actualsIds && ids.actualsIds.length > 0) {
        const payload = { id: ids.actualsIds[0] };
        MONTH_DISPLAY.forEach((month, index) => {
          const value = dataToSave.monthly["Actuals"][month];
          payload[MONTH_FIELDS[index]] = value !== "" && value !== null ? parseFloat(value) : null;
        });
        actualsUpdates.push(payload);
      }

      // Execute updates
      const updatePromises = [];

      if (mbpUpdates.length > 0) {
        updatePromises.push(updateMultipleDealerInvestmentUptimeMbp(mbpUpdates));
      }
      if (projUpdates.length > 0) {
        updatePromises.push(updateMultipleDealerInvestmentUptimeProjection(projUpdates));
      }
      if (actualsUpdates.length > 0) {
        updatePromises.push(updateMultipleDealerInvestmentUptimeActuals(actualsUpdates));
      }

      if (updatePromises.length > 0) {
        await Promise.all(updatePromises);
        toast.success("Data saved successfully!");
        // Reload data to get fresh calculations
        await loadData();
      } else {
        toast.info("No changes to save");
      }
    } catch (err) {
      console.error("Save error:", err);
      toast.error("Failed to save data");
    } finally {
      setSaving(false);
    }
  };

  // Check which rows should be editable (Monthly only - Quarterly is calculated)
  const isEditableRow = (row) => {
    return row === "Monthly Business Plan" ||
      row === "Monthly Projection" ||
      row === "Actuals";
  };

  // ============================================
  // MBP HANDLERS
  // ============================================
  
  // ⭐ Admin: Enable/Disable MBP (to approve dealer's edit request)
  const handleEnableMBP = () => {
    const newState = !enableMBP;
    setEnableMBP(newState);
    
    if (newState) {
      // When admin enables MBP, reset submitted state so dealer can edit again
      setMbpSubmitted(false);
      toast.success("MBP Enabled! Dealer can now edit MBP values.");
    } else {
      toast.info("MBP Disabled.");
    }
    
    // TODO: Call API to update MBP enabled status
    // await updateMBPStatus({ dealerInvestmentId: investment.id, mbpEnabled: newState });
  };

  // ⭐ Submit MBP Handler
  const handleSubmitMBP = () => {
    setShowMBPSubmitModal(true);
  };

  const confirmSubmitMBP = () => {
    // TODO: Call API to submit MBP
    setMbpSubmitted(true);
    setEnableMBP(false); // Disable editing after submit
    setShowMBPSubmitModal(false);
    toast.success("MBP submitted successfully!");
  };

  const cancelSubmitMBP = () => {
    setShowMBPSubmitModal(false);
  };

  // ⭐ Dealer: Request MBP Edit (after MBP is submitted)
  const handleRequestMBPEdit = () => {
    setShowRequestPopup(true);
  };

  const confirmRequestMBPEdit = async () => {
    try {
      setRequestLoading(true);
      // TODO: Call API to request MBP edit
      // await requestMBPEdit({ dealerInvestmentId: investment.id, category: selectedCategory, businessType: selectedBusinessType });
      
      setShowRequestPopup(false);
      toast.success("MBP edit request sent to Administrator successfully!");
    } catch (err) {
      console.error("Error requesting MBP edit:", err);
      toast.error("Failed to send request. Please try again.");
    } finally {
      setRequestLoading(false);
    }
  };

  const cancelRequestMBPEdit = () => {
    setShowRequestPopup(false);
  };

  // Calculate monthly total
  const calculateMonthlyTotal = (rowData) => {
    if (!rowData) return "";
    const total = months.reduce((sum, month) => {
      const val = parseFloat(rowData[month]) || 0;
      return sum + val;
    }, 0);
    return total > 0 ? String(total) : "";
  };

  // Calculate quarterly total
  const calculateQuarterlyTotal = (rowData) => {
    if (!rowData) return "";
    const total = quarters.reduce((sum, q) => {
      const val = parseFloat(rowData[q]) || 0;
      return sum + val;
    }, 0);
    return total > 0 ? String(total) : "";
  };

  // Get current selection label for popups
  const getCurrentSelectionLabel = () => {
    if (selectedCSA) {
      return "CSA (Service Revenue)";
    }
    return `${selectedCategory} ${selectedBusinessType} - ${selectedMake}`;
  };

  // ⭐ Render MBP Action Buttons based on role and submission status
  const renderMBPButtons = () => {
    // ═══════════════════════════════════════════════════════════════
    // ADMIN: Can Enable/Disable MBP and Submit MBP
    // ═══════════════════════════════════════════════════════════════
    if (isAdmin) {
      return (
        <>
          {/* Enable/Disable MBP Button - Admin can toggle this to approve dealer edit requests */}
          <button
            onClick={handleEnableMBP}
            className={`px-6 py-1 font-medium text-xs transition flex items-center gap-2 border ${
              enableMBP
                ? "bg-green text-white border-green-600 hover:bg-white hover:text-green-600"
                : "bg-darkblue1 text-white border-darkblue1 hover:bg-white hover:text-darkblue1"
            }`}
          >
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                clipRule="evenodd"
              />
            </svg>
            {enableMBP ? "MBP Enabled" : "Enable MBP"}
          </button>

          {/* Submit MBP Button - Only show when MBP is enabled */}
          {enableMBP && !mbpSubmitted && (
            <button
              onClick={handleSubmitMBP}
              className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2"
            >
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                  clipRule="evenodd"
                />
              </svg>
              Submit MBP
            </button>
          )}
        </>
      );
    }

    // ═══════════════════════════════════════════════════════════════
    // DEALER: Can Save/Submit MBP, Request Edit after submission
    // ═══════════════════════════════════════════════════════════════
    if (isDealer) {
      // If MBP is already submitted, show "Request MBP Edit" button
      if (mbpSubmitted) {
        return (
          <button
            onClick={handleRequestMBPEdit}
            className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2"
          >
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z"
                clipRule="evenodd"
              />
            </svg>
            Request MBP Edit
          </button>
        );
      }

      // MBP not submitted yet - dealer can submit
      return (
        <button
          onClick={handleSubmitMBP}
          className="bg-darkblue1 text-white border border-darkblue1 px-6 py-1 font-medium text-xs hover:bg-white hover:text-darkblue1 transition flex items-center gap-2"
        >
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path
              fillRule="evenodd"
              d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
              clipRule="evenodd"
            />
          </svg>
          Submit MBP
        </button>
      );
    }

    // Other roles - no MBP actions
    return null;
  };

  // ============================================
  // LOADING STATE
  // ============================================
  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
        <span className="ml-3 text-sm text-gray-600">Loading uptime & parts data...</span>
      </div>
    );
  }

  // ============================================
  // ERROR STATE
  // ============================================
  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 p-4 text-center">
        <p className="text-red-600 text-sm">{error}</p>
        <button
          onClick={loadData}
          className="mt-2 px-4 py-1 bg-darkblue1 text-white text-xs"
        >
          Retry
        </button>
      </div>
    );
  }

  // ⭐ Determine if cells should be editable based on role and MBP status
  // For Dealer: Can edit if MBP not submitted yet
  // For Admin: Can edit if MBP is enabled
  const canEditMBP = isDealer ? !mbpSubmitted : (isAdmin && enableMBP);


  return (
    <div>
      {/* PDP Target Table - Parts, Lube, CSA */}
      <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-4">
        <div 
        
        className="bg-white px-4 py-2 border-b border-Dustyblue">
          <h3 className="text-sm font-semibold text-darkblue1">PDP Targets</h3>
        </div>
        <table className="w-full border-collapse text-xs">
        <thead className="bg-Dustyblue text-white">
  <tr>
    {/* Make column with rowSpan=2 and sorting */}
    <th
      rowSpan={2}
      className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-medium w-[100px] cursor-pointer select-none"
      onClick={() => handleSort("make")}
    >
      <div className="flex items-center justify-center gap-1">
        Make
        {sortKey !== "make" && <ChevronsUpDown className="w-3 h-3 text-white" />}
        {sortKey === "make" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "make" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Parts group */}
    <th colSpan={2} className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-medium">
      Parts
    </th>

    {/* Lube group */}
    <th colSpan={2} className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-medium">
      Lube
    </th>

    {/* CSA column with rowSpan=2 and sorting */}
    <th
      rowSpan={2}
      className="border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 px-3 py-1.5 text-center font-medium w-[100px] cursor-pointer select-none"
      onClick={() => handleSort("csa")}
    >
      <div className="flex items-center justify-center gap-1">
        CSA
        {sortKey === "csa" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "csa" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>
  </tr>

  <tr>
    {/* Parts - Retail */}
   <th
  className="border border-grey2 border-l-0 border-b-0 px-3 py-1.5 text-center font-medium text-xs cursor-pointer select-none"
  onClick={() => handleSort("partsRetail")}
>
  <div className="flex items-center justify-center gap-1">
    <span className="truncate">Retail</span>
    <span className="flex-none w-3 h-3 relative">
      {/* Always render icon wrapper to prevent shifting */}
            {sortKey === "partsRetail" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white absolute" />}

      {sortKey === "partsRetail" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white absolute" />}
    </span>
  </div>
</th>


    {/* Parts - Off take */}
   <th
  className="border border-grey2 border-l-0 border-b-0 px-3 py-1.5 text-center font-medium text-xs cursor-pointer select-none"
  onClick={() => handleSort("partsOfftake")}
>
  <div className="flex items-center justify-center gap-1 relative">
    <span className="truncate">Off take</span>
    <span className="flex-none w-3 h-3 relative">
      {/* Neutral — show when this column is not the active sort key */}
      {/* Sorted ascending */}
      {sortKey === "partsOfftake" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white absolute" />}
      {/* Sorted descending */}
      {sortKey === "partsOfftake" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white absolute" />}
    </span>
  </div>
</th>


    {/* Lube - Retail */}
   {/* Lube - Retail */}
<th
  className="border border-grey2 border-l-0 border-b-0 px-3 py-1.5 text-center font-medium text-xs cursor-pointer select-none"
  onClick={() => handleSort("lubeRetail")}
>
  <div className="flex items-center justify-center gap-1 relative">
    <span className="truncate">Retail</span>
    <span className="flex-none w-3 h-3 relative">
      {/* Neutral — show when this column is not the active sort key */}
      {/* Sorted ascending */}
      {sortKey === "lubeRetail" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white absolute" />}
      {/* Sorted descending */}
      {sortKey === "lubeRetail" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white absolute" />}
    </span>
  </div>
</th>

{/* Lube - Off take */}
<th
  className="border border-grey2 border-l-0 border-b-0 px-3 py-1.5 text-center font-medium text-xs cursor-pointer select-none"
  onClick={() => handleSort("lubeOfftake")}
>
  <div className="flex items-center justify-center gap-1 relative">
    <span className="truncate">Off take</span>
    <span className="flex-none w-3 h-3 relative">
      {/* Neutral — show when this column is not the active sort key */}
      {/* Sorted ascending */}
      {sortKey === "lubeOfftake" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white absolute" />}
      {/* Sorted descending */}
      {sortKey === "lubeOfftake" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white absolute" />}
    </span>
  </div>
</th>

  </tr>
</thead>

          <tbody className="bg-white">
            {sortedData.map((row, index) => (
              <tr key={row.make}>
                <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs font-medium">
                  {row.make}
                </td>
                <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs">
                  {row.parts?.retail || "0"}
                </td>
                <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs">
                  {row.parts?.offtake || "0"}
                </td>
                <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs">
                  {row.lube?.retail || "0"}
                </td>
                <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-xs">
                  {row.lube?.offtake || "0"}
                </td>
                <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1 text-center text-xs">
                  {row.csa || "0"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Filter Dropdowns */}
      <div className="flex justify-between items-center w-full gap-4 mb-4">
        {/* Left Section: Dropdowns */}
        <div className="flex items-center gap-2">
          {/* Make Dropdown */}
          <div ref={makeDropdownRef} className="relative w-full sm:w-36">
            <button
              onClick={() => {
                setMakeDropdownOpen(!makeDropdownOpen);
                setCategoryDropdownOpen(false);
                setBusinessTypeDropdownOpen(false);
              }}
              className="flex items-center justify-between w-full px-3 py-1 text-xs border text-black bg-white border-black/60"
            >
              <span>{selectedMake || 'Make'}</span>
              <svg className={`w-3 h-3 ml-2 transition-transform ${makeDropdownOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            {makeDropdownOpen && (
              <div className="absolute z-10 w-full mt-1 bg-white border border-Dustyblue shadow-lg">
                <button
                  onClick={() => {
                    setSelectedMake("Volvo");
                    setMakeDropdownOpen(false);
                    setSelectedCSA(false);
                    setShowDataTable(true);
                  }}
                  className="block w-full px-3 py-1 text-xs text-left text-black hover:bg-lightBlue/50"
                >
                  Volvo
                </button>
                <button
                  onClick={() => {
                    setSelectedMake("SDLG");
                    setMakeDropdownOpen(false);
                    setSelectedCSA(false);
                    setShowDataTable(true);
                  }}
                  className="block w-full px-3 py-1 text-xs text-left text-black hover:bg-lightBlue/50"
                >
                  SDLG
                </button>
              </div>
            )}
          </div>

          {/* Category Dropdown */}
          <div ref={categoryDropdownRef} className="relative w-full sm:w-36">
            <button
              onClick={() => {
                setCategoryDropdownOpen(!categoryDropdownOpen);
                setMakeDropdownOpen(false);
                setBusinessTypeDropdownOpen(false);
              }}
              className="flex items-center justify-between w-full px-3 py-1 text-xs border text-black bg-white border-black/60"
            >
              <span>{selectedCategory || 'Category'}</span>
              <svg className={`w-3 h-3 ml-2 transition-transform ${categoryDropdownOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            {categoryDropdownOpen && (
              <div className="absolute z-10 w-full mt-1 bg-white border border-black/60 shadow-lg">
                <button
                  onClick={() => {
                    setSelectedCategory("Parts");
                    setCategoryDropdownOpen(false);
                    setSelectedCSA(false);
                    setShowDataTable(true);
                  }}
                  className="block w-full px-3 py-1 text-xs text-left text-black hover:bg-lightBlue/50"
                >
                  Parts
                </button>
                <button
                  onClick={() => {
                    setSelectedCategory("Lube");
                    setCategoryDropdownOpen(false);
                    setSelectedCSA(false);
                    setShowDataTable(true);
                  }}
                  className="block w-full px-3 py-1 text-xs text-left text-black hover:bg-lightBlue/50"
                >
                  Lube
                </button>
              </div>
            )}
          </div>

          {/* Business Type Dropdown */}
          <div ref={businessTypeDropdownRef} className="relative w-full sm:w-40">
            <button
              onClick={() => {
                setBusinessTypeDropdownOpen(!businessTypeDropdownOpen);
                setMakeDropdownOpen(false);
                setCategoryDropdownOpen(false);
              }}
              className="flex items-center justify-between w-full px-3 py-1 text-xs border text-black bg-white border-black/60"
            >
              <span>{selectedBusinessType || 'Business Type'}</span>
              <svg className={`w-3 h-3 ml-2 transition-transform ${businessTypeDropdownOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            {businessTypeDropdownOpen && (
              <div className="absolute z-10 w-full mt-1 bg-white border border-black/60 shadow-lg">
                <button
                  onClick={() => {
                    setSelectedBusinessType("Retail");
                    setBusinessTypeDropdownOpen(false);
                    setSelectedCSA(false);
                    setShowDataTable(true);
                  }}
                  className="block w-full px-3 py-1 text-xs text-left text-black hover:bg-lightBlue/50"
                >
                  Retail
                </button>
                <button
                  onClick={() => {
                    setSelectedBusinessType("Off take");
                    setBusinessTypeDropdownOpen(false);
                    setSelectedCSA(false);
                    setShowDataTable(true);
                  }}
                  className="block w-full px-3 py-1 text-xs text-left text-black hover:bg-lightBlue/50"
                >
                  Off take
                </button>
              </div>
            )}
          </div>

          {/* CSA Button */}
          <button
            onClick={() => {
              setSelectedCSA(true);
              setShowDataTable(true);
            }}
            className={`px-4 py-1 text-xs font-medium border ${selectedCSA
              ? 'bg-darkblue1 text-white border-darkblue1'
              : 'text-black bg-white border-black/60'
              }`}
          >
            CSA
          </button>
        </div>

        {/* Right Section: MBP Buttons */}
        <div className="flex items-center gap-3">
          {renderMBPButtons()}
        </div>
      </div>

      {/* Dynamic Data Section */}
      {showDataTable && currentData && (
        <div className="border-Dustyblue overflow-hidden mb-6">
          {/* Header with Stats - White background */}
          <div className="bg-white px-4 py-3 border border-Dustyblue">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <h3 className="text-base font-semibold text-darkblue1">
                {getCurrentSelectionLabel()}
              </h3>
              <div className="flex flex-wrap gap-4 text-xs text-black">
                <span>
                  <strong>YTD Actuals:</strong> {currentData.stats?.ytdActuals || "0"}
                </span>
                <span>
                  <strong>PDP Targets:</strong> {currentData.stats?.pdpTarget || "0"}
                </span>
                <span>
                  <strong>Achievement:</strong> {currentData.stats?.ytdAchievement || "0.00%"}
                </span>
              </div>
            </div>
          </div>

          {/* Combined Monthly & Quarterly Table */}
          <div className="overflow-x-auto bg-white border border-Dustyblue">
            <table 
            ref={formRef}
            className="w-full border-collapse border text-xs" style={{ tableLayout: 'fixed' }}>
              {/* Column widths definition */}
              <colgroup>
                <col style={{ width: '15%' }} />
                {months.map((_, i) => (
                  <col key={i} style={{ width: '6.15%' }} />
                ))}
                <col style={{ width: '6.5%' }} />
              </colgroup>

              {/* Monthly Headers */}
           <thead className="bg-Dustyblue text-white">
  <tr>
    {/* Monthly label */}
    <th
      className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-left cursor-pointer font-normal select-none"
      onClick={() => handleSort("monthly")} // sort key for this column
    >
      <div className="flex items-center gap-1">
        Monthly
        
{sortKey !== "monthly" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

        {sortKey === "monthly" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "monthly" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {/* Month columns */}
    {months.map((month) => (
      <th
        key={month}
        className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-normal cursor-pointer select-none"
        onClick={() => handleSort(month)} // sort by month dynamically
      >
        <div className="flex items-center justify-center gap-1">
          {month}
          {sortKey === month && sortOrder === "asc" && (
            <ChevronUp className="w-3 h-3 text-white" />
          )}
          {sortKey === month && sortOrder === "desc" && (
            <ChevronDown className="w-3 h-3 text-white" />
          )}
        </div>
      </th>
    ))}

    {/* Total column */}
    <th
      className="border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 px-3 py-1.5 text-center font-normal cursor-pointer select-none"
      onClick={() => handleSort("total")}
    >
      <div className="flex items-center justify-center gap-1">
        Total
        {sortKey === "total" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "total" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>
  </tr>
</thead>


              {/* Monthly Data */}
              <tbody>
{sortedMonthlyData.map(([row, rowData]) => {
                  // ⭐ Editable logic:
                  // - Row must be editable type (MBP, Projection, Actuals)
                  // - For Dealer: Can edit if MBP not submitted
                  // - For Admin: Can edit if MBP is enabled
                  const isEditable = isEditableRow(row) && mode === "fill" && canEditMBP;

                  return (
                    <tr key={row} className="bg-white">
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 font-medium">
                        {row}
                      </td>
                      {months.map((month) => (
                        <td
                          key={month}
                          className="border border-grey2 border-t-0 border-l-0 px-1 py-1 text-center text-black"
                        >
                          {isEditable ? (
                           <input
  type="text"
  value={rowData[month] ?? ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleMonthlyInputChange(row, month, value);
    }
  }}
  className="w-full text-center border border-gray-300 bg-white focus:outline-none focus:border-darkblue1 px-1 py-0.5 text-xs text-black"
/>
                          ) : (
              rowData[month] ?? "" // ✅ use rowData here too
                          )}
                        </td>
                      ))}
                      <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1 text-center text-black font-medium">
          {calculateMonthlyTotal(rowData)} 
                      </td>
                    </tr>
                  );
                })}
              </tbody>

              {/* Quarterly Headers */}
           <thead className="bg-Dustyblue text-white">
  <tr>
    {/* Row name header */}
    <th
      className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-left font-normal cursor-pointer select-none"
      onClick={() => handleSort("quarterly")}
    >
      <div className="flex items-center gap-1">
        Quarterly
        
{sortKey !== "quarterly" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
        {sortKey === "quarterly" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "quarterly" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Quarter headers */}
    {quarters.map((q) => (
      <th
        key={q}
        colSpan={3}
        className="border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 text-center font-normal cursor-pointer select-none"
        onClick={() => handleSort(q)}
      >
        <div className="flex items-center justify-center gap-1">
          {q}
          {sortKey === q && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
          {sortKey === q && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
        </div>
      </th>
    ))}

    {/* Total header */}
    <th
      className="border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 px-3 py-1.5 text-center font-normal cursor-pointer select-none"
      onClick={() => handleSort("total")}
    >
      <div className="flex items-center justify-center gap-1">
        Total
        {sortKey === "total" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "total" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>
  </tr>
</thead>


              {/* Quarterly Data - Display only (calculated from monthly) */}
              <tbody>
  {sortedQuarterlyData.map(([row, rowData]) => (
                  <tr key={row} className="bg-white">
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 font-medium text-black">
                      {row}
                    </td>
                   {quarters.map((q) => (
                      <td
                        key={q}
                        colSpan={3}
                        className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center text-black"
                      >
                         {rowData[q] ?? ""}
                      </td>
                    ))}
                    <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1 text-center text-black font-medium">
                      {calculateQuarterlyTotal(rowData)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Save Button - Show when editing is enabled */}
          {mode === "fill" && canEditMBP && (
            <div className="flex justify-end px-4 py-3 bg-white border-t border-grey2">
              <button
                onClick={handleSave}
                disabled={saving}
                className="bg-darkblue1 text-white px-8 py-1.5 font-medium text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {saving ? "Saving..." : "Save"}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Submit MBP Confirmation Popup */}
      {showMBPSubmitModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-96 max-w-md mx-4">
            <h3 className="text-lg font-semibold text-darkblue1 mb-4">Confirm MBP Submission</h3>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to submit the Monthly Business Plan for{" "}
              <strong>{getCurrentSelectionLabel()}</strong>?
              This action cannot be undone. You will need to request Administrator approval to edit after submission.
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={cancelSubmitMBP}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded transition"
              >
                Cancel
              </button>
              <button
                onClick={confirmSubmitMBP}
                className="px-4 py-2 text-sm font-medium text-white bg-darkblue1 hover:bg-white hover:text-darkblue1 border border-darkblue1 rounded transition"
              >
                Confirm Submit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ⭐ Request MBP Edit Popup */}
      {showRequestPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-96 max-w-md mx-4">
            <h3 className="text-lg font-semibold text-darkblue1 mb-4">Request MBP Edit</h3>
            <p className="text-sm text-gray-600 mb-6">
              Your MBP for <strong>{getCurrentSelectionLabel()}</strong> has already been submitted.
              Do you want to send a request to the Administrator to re-enable editing?
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={cancelRequestMBPEdit}
                disabled={requestLoading}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded transition disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={confirmRequestMBPEdit}
                disabled={requestLoading}
                className="px-4 py-2 text-sm font-medium text-white bg-darkblue1 hover:bg-white hover:text-darkblue1 border border-darkblue1 rounded transition disabled:opacity-50 flex items-center gap-2"
              >
                {requestLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Sending...
                  </>
                ) : (
                  "Send Request"
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UptimeParts;