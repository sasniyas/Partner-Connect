// src/pages/DEALERINVESTMENT/InfrastructureReports/FacilityGrowthYOY.jsx
import React, { useState, useRef, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Menu } from "lucide-react";
import DataTableModal from "./DataTableModal";
import { fetchFacilityGrowthYOYData } from "../../../services/dealerInvestment/dealerInvestmentReports.service";
import { printChart } from "../../../util/printChart";
import { LabelList } from "recharts";
import html2canvas from "html2canvas";
import ExcelJS from "exceljs";

const FacilityGrowthYOY = ({ selectedYear, onDataReady }) => {
  const [showChartMenu, setShowChartMenu] = useState(false);
  const [showDataTable, setShowDataTable] = useState(false);
  const [chartData, setChartData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const chartRef = useRef(null);
  const chartContainerRef = useRef(null);
  const menuRef = useRef(null);

  // Fetch data from API
  useEffect(() => {
  const loadData = async () => {
    setLoading(true);
    setError(null);

    try {
      let response;

      if (!selectedYear) {
        // 🔥 INITIAL LOAD → FETCH ALL DATA
  response = await fetchFacilityGrowthYOYData("ALL"); // or null or 0 based on API
      } else {
        // 🔥 FILTERED DATA
        response = await fetchFacilityGrowthYOYData(selectedYear);
      }

      if (response.status && response.data.length > 0) {
        setChartData(response.data);
      } else {
        const fallbackData = generateFallbackData(selectedYear || "2025");
        setChartData(fallbackData);
      }
    } catch (err) {
      console.error("Error loading facility growth data:", err);
      const fallbackData = generateFallbackData(selectedYear || "2025");
      setChartData(fallbackData);
    } finally {
      setLoading(false);
    }
  };

  loadData();
}, [selectedYear]);
  // Send chart element and data to parent for PDF export
  useEffect(() => {
    if (onDataReady && chartContainerRef.current && chartData.length > 0) {
      onDataReady(chartContainerRef.current, chartData);
    }
  }, [chartData, onDataReady]);

  const generateFallbackData = (year) => {
    const baseData = [
      { year: "2018", facilities: 190 },
      { year: "2019", facilities: 196 },
      { year: "2020", facilities: 199 },
      { year: "2021", facilities: 223 },
      { year: "2022", facilities: 245 },
      { year: "2023", facilities: 268 },
      { year: "2024", facilities: 290 },
      { year: "2025", facilities: 312 },
    ];
    return baseData.filter(item => parseInt(item.year) <= parseInt(year));
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowChartMenu(false);
      }
    };
    if (showChartMenu) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showChartMenu]);

  const [isFullScreen, setIsFullScreen] = useState(false);
const handleFullScreen = () => {
  const element = chartRef.current;
  if (!element) return;

  if (!document.fullscreenElement) {
    // 🔥 ENTER FULLSCREEN
    const request =
      element.requestFullscreen ||
      element.webkitRequestFullscreen ||
      element.msRequestFullscreen;

    if (request) {
      request.call(element).catch((err) => {
        console.error("Fullscreen error:", err);
      });
    }
  } else {
    // 🔥 EXIT FULLSCREEN
    const exit =
      document.exitFullscreen ||
      document.webkitExitFullscreen ||
      document.msExitFullscreen;

    if (exit) exit.call(document);
  }

  setShowChartMenu(false);
};
useEffect(() => {
  const handleFullScreenChange = () => {
    setIsFullScreen(!!document.fullscreenElement);
  };

  document.addEventListener("fullscreenchange", handleFullScreenChange);
  document.addEventListener("webkitfullscreenchange", handleFullScreenChange);

  return () => {
    document.removeEventListener("fullscreenchange", handleFullScreenChange);
    document.removeEventListener("webkitfullscreenchange", handleFullScreenChange);
  };
}, []);
  const handlePrint = () => {
    printChart(
      chartContainerRef.current,
      "Facility Growth YOY",
      `Year: ${selectedYear} | ${chartData.length} Years of Data`
    );
    setShowChartMenu(false);
  };

  const handleExportPNG = async () => {
  if (!chartRef.current) return;

  setShowChartMenu(false);

  // 🔥 Hide tooltips
  const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
  tooltips.forEach((t) => (t.style.display = "none"));

  setTimeout(async () => {
    // 🔥 Optional: Add header (if you want filters/title)
    const header = document.createElement("div");
    header.id = "export-header";
    header.style.cssText =
      "padding:10px 16px; background:#ffffff; font-size:12px; color:#333; border-bottom:1px solid #e5e7eb;";
    header.innerHTML = `
      <strong>Facility Growth YOY</strong><br/>
      Year: ${selectedYear || "All Years"}
    `;

    chartRef.current.insertBefore(header, chartRef.current.firstChild);

    try {
      const canvas = await html2canvas(chartRef.current, {
        backgroundColor: "#ffffff", // 🔥 FIX BLACK BG
        scale: 2,                   // 🔥 HIGH QUALITY
        useCORS: true,
      });

      const link = document.createElement("a");
      link.download = `facility-growth-yoy${
        selectedYear ? "-" + selectedYear : ""
      }.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch (error) {
      console.error("Error exporting PNG:", error);
    } finally {
      // 🔥 Remove header
      const addedHeader = document.getElementById("export-header");
      if (addedHeader) addedHeader.remove();

      // 🔥 Restore tooltips
      tooltips.forEach((t) => (t.style.display = ""));
    }
  }, 200);
};

  const handleExportJPEG = async () => {
  if (!chartRef.current) return;

  setShowChartMenu(false);

  // 🔥 Hide tooltips
  const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
  tooltips.forEach((t) => (t.style.display = "none"));

  setTimeout(async () => {
    // 🔥 Add header (same as ref)
    const header = document.createElement("div");
    header.id = "export-header";
    header.style.cssText =
      "padding:10px 16px; background:#ffffff; font-size:12px; color:#333; border-bottom:1px solid #e5e7eb;";
    
    header.innerHTML = `
      <strong>Facility Growth YOY</strong><br/>
      Year: ${selectedYear || "All Years"}
    `;

    chartRef.current.insertBefore(header, chartRef.current.firstChild);

    try {
      const canvas = await html2canvas(chartRef.current, {
        backgroundColor: "#ffffff", // 🔥 fix black bg
        scale: 2,                   // 🔥 high quality
        useCORS: true,
        scrollY: -window.scrollY,
      });

      const link = document.createElement("a");
      link.download = `facility-growth-yoy${
        selectedYear ? "-" + selectedYear : ""
      }.jpeg`;

      link.href = canvas.toDataURL("image/jpeg", 0.95);
      link.click();
    } catch (error) {
      console.error("Error exporting JPEG:", error);
    } finally {
      // 🔥 remove header
      const addedHeader = document.getElementById("export-header");
      if (addedHeader) addedHeader.remove();

      // 🔥 restore tooltips
      tooltips.forEach((t) => (t.style.display = ""));
    }
  }, 200);
};
 const handleExportSVG = async () => {
  if (!chartRef.current) return;

  setShowChartMenu(false);

  // 🔥 Hide tooltips
  const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
  tooltips.forEach((t) => (t.style.display = "none"));

  setTimeout(async () => {
    // 🔥 Add header
    const header = document.createElement("div");
    header.id = "export-header";
    header.style.cssText =
      "padding:10px 16px; background:#ffffff; font-size:12px; color:#333; border-bottom:1px solid #e5e7eb;";
    
    header.innerHTML = `
      <strong>Facility Growth YOY</strong><br/>
      Year: ${selectedYear || "All Years"}
    `;

    chartRef.current.insertBefore(header, chartRef.current.firstChild);

    try {
      const canvas = await html2canvas(chartRef.current, {
        backgroundColor: "#ffffff",
        scale: 2,
        useCORS: true,
        scrollY: -window.scrollY,
      });

      const imgData = canvas.toDataURL("image/png");

      // 🔥 Wrap image inside SVG
      const svgContent = `
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          width="100%" 
          height="100%" 
          viewBox="0 0 ${canvas.width} ${canvas.height}"
          preserveAspectRatio="xMidYMid meet"
        >
          <image 
            href="${imgData}" 
            width="${canvas.width}" 
            height="${canvas.height}" 
          />
        </svg>
      `;

      const blob = new Blob([svgContent], {
        type: "image/svg+xml;charset=utf-8",
      });

      const url = URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.download = `facility-growth-yoy${
        selectedYear ? "-" + selectedYear : ""
      }.svg`;
      link.href = url;
      link.click();

      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error exporting SVG:", error);
    } finally {
      // 🔥 Remove header
      const addedHeader = document.getElementById("export-header");
      if (addedHeader) addedHeader.remove();

      // 🔥 Restore tooltips
      tooltips.forEach((t) => (t.style.display = ""));
    }
  }, 200);
};

 const handleDownloadXLS = async () => {
  try {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Facility Growth YOY");

    // 🔥 Filter info
    const filterStyle = {
      font: { bold: true, color: { argb: "FF1B365D" } },
    };

    const yearRow = sheet.addRow([
      "Year:",
      selectedYear || "All Years",
    ]);
    yearRow.getCell(1).font = filterStyle.font;

    sheet.addRow([]);

    // 🔥 Headers
    const headerRow = sheet.addRow(["Year", "Facilities"]);
    headerRow.eachCell((cell) => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: "left" };
    });

    // 🔥 Column widths
    sheet.getColumn(1).width = 15;
    sheet.getColumn(2).width = 15;

    // 🔥 Data
    chartData.forEach((row) => {
      const dataRow = sheet.addRow([
        row.year,
        Number(row.facilities),
      ]);

      dataRow.eachCell((cell) => {
        cell.alignment = { horizontal: "left" };
      });
    });

    // 🔥 Generate file
    const buffer = await workbook.xlsx.writeBuffer();

    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = `facility-growth-yoy${
      selectedYear ? "-" + selectedYear : ""
    }.xlsx`;

    link.click();
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error("Error downloading Excel:", error);
  }

  setShowChartMenu(false);
};
const handleDownloadCSV = () => {
  try {
    // 🔥 Filter info
    const filterRows = [
      `Year:,"${selectedYear || "All Years"}"`,
      ""
    ];

    // 🔥 Headers
    const headers = ["Year", "Facilities"];

    // 🔥 Data rows
    const rows = chartData.map((row) => [
      row.year,
      Number(row.facilities),
    ]);

    // 🔥 Final CSV
    const csvContent = [
      ...filterRows,
      headers.join(","),
      ...rows.map((r) => r.join(",")),
    ].join("\n");

    const blob = new Blob(["\uFEFF" + csvContent], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.download = `facility-growth-yoy${
      selectedYear ? "-" + selectedYear : ""
    }.csv`;

    link.href = url;
    link.click();

    URL.revokeObjectURL(url);
  } catch (error) {
    console.error("Error downloading CSV:", error);
  }

  setShowChartMenu(false);
};
 const handleViewDataTable = () => {
  const tableWindow = window.open("", "", "width=700,height=600");

  tableWindow.document.write(`
    <html>
      <head>
        <title>Facility Growth YOY - Data Table</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
          }
          .container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          }
          h2 {
            color: #1e3a5f;
            margin-bottom: 5px;
          }
          .filters {
            font-size: 12px;
            color: #666;
            margin-bottom: 15px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
          }
          th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
          }
          th {
            background-color: #1e3a5f;
            color: white;
          }
          tr:nth-child(even) {
            background-color: #f9f9f9;
          }
          .total-row {
            background-color: #e8f4fc !important;
            font-weight: bold;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h2>Facility Growth YOY</h2>

          <div class="filters">
            <p><strong>Year:</strong> ${selectedYear || "All Years"}</p>
          </div>

          <table>
            <thead>
              <tr>
                <th>Year</th>
                <th>Facilities</th>
              </tr>
            </thead>

            <tbody>
              ${chartData
                .map(
                  (row) =>
                    `<tr>
                      <td>${row.year}</td>
                      <td>${row.facilities}</td>
                    </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </body>
    </html>
  `);

  tableWindow.document.close();
  setShowChartMenu(false);
};

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-300 rounded shadow-lg">
          <p className="font-normal text-xs text-gray-800 mb-1">{label}</p>
          <p style={{ color: payload[0].fill }} className="text-xs">
            Facilities: {payload[0].value}
          </p>
        </div>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-darkblue1 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-sm text-gray-600">Loading facility growth data...</span>
        </div>
      </div>
    );
  }

  return (
    <>
<div
  className={isFullScreen ? "bg-white h-screen w-full" : "relative"}
  ref={chartRef}
>        {error && (
          <div className="mb-4 px-4 py-2 bg-yellow-50 border border-yellow-200 text-yellow-800 text-sm rounded">
            {error}
          </div>
        )}

        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 text-center">
            <div className="text-xl font-bold text-gray-800 tracking-wider mb-1">V O L V O</div>
            <h2 className="text-lg font-semibold text-gray-800">Facility Growth YOY</h2>
            <p className="text-sm text-gray-600 mt-1">Year: {selectedYear || "All Years"} | {chartData.length} Years of Data</p>
          </div>

          <div className="relative" ref={menuRef}>
            <button onClick={() => setShowChartMenu(!showChartMenu)} className="p-2 hover:bg-gray-100 rounded-md transition">
              <Menu size={20} className="text-gray-600" />
            </button>

            {showChartMenu && (
              <div className="absolute right-0 top-full mt-2 w-56 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                <button onClick={handleFullScreen} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" /></svg>
                  View in full screen
                </button>
                <button onClick={handlePrint} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                  Print chart
                </button>
                <div className="border-t border-gray-200 my-1"></div>
                <button onClick={handleExportPNG} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download PNG image</button>
                <button onClick={handleExportJPEG} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download JPEG image</button>
                <button onClick={handleExportSVG} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download SVG vector image</button>
                <div className="border-t border-gray-200 my-1"></div>
                <button onClick={handleDownloadCSV} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download CSV</button>
                <button onClick={handleDownloadXLS} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download XLS</button>
                <button onClick={handleViewDataTable} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">View data table</button>
              </div>
            )}
          </div>
        </div>

<div
  ref={chartContainerRef}
  className={isFullScreen ? "h-screen w-full flex flex-col" : ""}
>          {chartData.length > 0 ? (
<ResponsiveContainer
  width="100%"
  height={isFullScreen ? "75%" : 400}
>    <BarChart
      data={chartData}
      margin={{ top: 10, right: 30, left: 10, bottom: 10 }}
    >
      {/* Grid */}
      <CartesianGrid
        strokeDasharray="3 3"
        stroke="#e5e7eb"
        vertical={false}
      />

      {/* X Axis */}
      <XAxis
        dataKey="year"
        tick={{ fontSize: 11, fill: "#4b5563" }}
        axisLine={{ stroke: "#d1d5db" }}
        tickLine={false}
      />

      {/* Y Axis */}
      <YAxis
        tick={{ fontSize: 11, fill: "#4b5563" }}
        axisLine={{ stroke: "#d1d5db" }}
        tickLine={false}
        allowDecimals={false}
        label={{
          value: "No. of Facility",
          angle: -90,
          position: "insideLeft",
          style: {
            fontSize: 12,
            fill: "#4b5563",
            fontWeight: 500,
          },
        }}
        width={60}
      />

      {/* Tooltip */}
      <Tooltip
        content={<CustomTooltip />}
        cursor={{ fill: "rgba(0,0,0,0.03)" }}
      />

      {/* Legend */}
      <Legend
        verticalAlign="top"
        align="center"
        iconType="square"
        iconSize={10}
        wrapperStyle={{ paddingBottom: 10 }}
        formatter={(value) => (
          <span style={{ fontSize: "12px", color: "#374151" }}>
            {value}
          </span>
        )}
      />

      {/* Bar */}
      <Bar
        dataKey="facilities"
        name="Facilities"
        fill="#5B9A8B"
        radius={[4, 4, 0, 0]}
        maxBarSize={40}
      >
        {/* Labels on top */}
        <LabelList
          dataKey="facilities"
          position="top"
          formatter={(value) => (value > 0 ? value : "")}
          style={{
            fontSize: 11,
            fill: "#374151",
            fontWeight: 500,
          }}
        />
      </Bar>
    </BarChart>
  </ResponsiveContainer>
          ) : (
            <div className="flex justify-center items-center h-96 text-gray-500">No data available</div>
          )}
        </div>

        <div className="mt-4 text-left text-xs text-gray-500">Volvo Construction Equipment</div>
      </div>

      <DataTableModal isOpen={showDataTable} onClose={() => setShowDataTable(false)} title="Facility Growth YOY - Data Table" subtitle={`Year: {selectedYear || "All Years"}`} data={chartData} />
    </>
  );
};

export default FacilityGrowthYOY;