// src/pages/DEALERINVESTMENT/InfrastructureReports/InfrastructureReportsHome.jsx
import React, { useState, useRef, useEffect, useCallback } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, ChevronDown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { fetchAvailableYears } from "../../../services/dealerInvestment/dealerInvestmentReports.service";
import { exportReportToPDF, getReportColumns } from "../../../util/pdfExport";
import FacilityGrowthYOY from "./FacilityGrowthYOY";
import DealerwiseFacilities from "./DealerwiseFacilities";
import SalesVehicles from "./SalesVehicles";
import ServiceVehicles from "./ServiceVehicles";
import Tools from "./Tools";
import CSR from "./CSR";
import SCL from "./SCL";
import TCL from "./TCL";

const InfrastructureReportsHome = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedYear, setSelectedYear] = useState("");
  const [activeReport, setActiveReport] = useState("Facility Growth YOY");
  const [isYearDropdownOpen, setIsYearDropdownOpen] = useState(false);
  const [yearOptions, setYearOptions] = useState([]);
  const [loadingYears, setLoadingYears] = useState(true);
  const [exporting, setExporting] = useState(false);
  const yearDropdownRef = useRef(null);
  const yearDropdownRefMobile = useRef(null);
  
  // Ref to store chart data and element from child components
  const reportDataRef = useRef({ chartElement: null, data: [] });

  // Report options - matching the tabs in images
  const reportOptions = [
    { id: "facilityGrowth", label: "Facility Growth YOY", component: FacilityGrowthYOY },
    { id: "dealerwiseFacilities", label: "Dealerwise Facilities", component: DealerwiseFacilities },
    { id: "salesVehicles", label: "Sales Vehicles", component: SalesVehicles },
    { id: "serviceVehicles", label: "Service Vehicles", component: ServiceVehicles },
    { id: "tools", label: "Tools", component: Tools },
    { id: "csr", label: "CSR", component: CSR },
    { id: "scl", label: "SCL", component: SCL },
    { id: "tcl", label: "TCL", component: TCL },
  ];

  const ActiveComponent = reportOptions.find(r => r.label === activeReport)?.component || FacilityGrowthYOY;

  // Callback to receive chart data and element from child components
  const handleReportDataReady = useCallback((chartElement, data) => {
    reportDataRef.current = { chartElement, data };
  }, []);

  // Fetch available years from API
 useEffect(() => {
  const loadYears = async () => {
    setLoadingYears(true);

    try {
      const response = await fetchAvailableYears();

      if (response.status && response.data.length > 0) {
        // ✅ API success
        setYearOptions(response.data);

        // 🔥 DO NOT SELECT ANY YEAR BY DEFAULT
        setSelectedYear("");
      } else {
        // ⚠️ API returned empty → fallback years
        const currentYear = new Date().getFullYear();

        const defaultYears = Array.from({ length: 8 }, (_, i) =>
          String(currentYear - i)
        );

        setYearOptions(defaultYears);

        // 🔥 STILL NO DEFAULT SELECTION
        setSelectedYear("");
      }
    } catch (error) {
      console.error("Error loading years:", error);

      // ⚠️ API failed → fallback years
      const currentYear = new Date().getFullYear();

      const defaultYears = Array.from({ length: 8 }, (_, i) =>
        String(currentYear - i)
      );

      setYearOptions(defaultYears);

      // 🔥 STILL NO DEFAULT SELECTION
      setSelectedYear("");
    } finally {
      setLoadingYears(false);
    }
  };

  loadYears();
}, []);
  // Close year dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        (yearDropdownRef.current && !yearDropdownRef.current.contains(event.target)) &&
        (yearDropdownRefMobile.current && !yearDropdownRefMobile.current.contains(event.target))
      ) {
        setIsYearDropdownOpen(false);
      }
    };

    if (isYearDropdownOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isYearDropdownOpen]);

  const handleBack = () => {
    navigate("/DEALERINVESTMENT/ViewDealerInvestment/ViewDealerhome");
  };

  const handleExportReports = async () => {
    if (!selectedYear) {
      alert("Please select a year first");
      return;
    }

    const { chartElement, data } = reportDataRef.current;

    if (!chartElement || !data || data.length === 0) {
      alert("No data available to export. Please wait for the chart to load.");
      return;
    }

    setExporting(true);

    try {
      const columns = getReportColumns(activeReport);
      const filename = `${activeReport.replace(/\s+/g, "-").toLowerCase()}-${selectedYear}.pdf`;

      const result = await exportReportToPDF({
        chartElement,
        data,
        title: activeReport,
        subtitle: `Year: ${selectedYear} | ${data.length} ${activeReport === "Facility Growth YOY" ? "Years" : "Dealers"}`,
        columns,
        filename,
      });

      if (!result.success) {
        alert("Failed to generate PDF. Please try again.");
      }
    } catch (error) {
      console.error("Export error:", error);
      alert("Failed to export report. Please try again.");
    } finally {
      setExporting(false);
    }
  };

  const handleYearSelect = (year) => {
    setSelectedYear(year);
    setIsYearDropdownOpen(false);
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Page Header */}
          <div className="flex flex-col lg:flex-row items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-2 text-lg font-semibold font-VolvoNovum text-darkblue1">
              <ArrowLeft
                onClick={handleBack}
                size={24}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              />
              Infrastructure Reports
            </div>

            <button
              onClick={handleExportReports}
              disabled={!selectedYear || exporting}
              className={`flex items-center gap-2 px-6 py-1.5 text-xs font-medium transition-all ${
                selectedYear && !exporting
                  ? "bg-darkblue1 text-white hover:bg-darkblue1/90 hover:shadow-lg"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"
              }`}
            >
              {exporting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Exporting...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Export PDF
                </>
              )}
            </button>
          </div>

          <hr className="hidden lg:block w-16 border-t-4 border-darkblue1 mb-6 -mt-5 ml-9" />

          {/* Year Filter and Report Tabs - Combined in One Line */}
          <div className="mb-6">
            {/* Desktop View - Year and Tabs on Same Line */}
            <div className="hidden lg:flex items-center gap-3 flex-shrink-0">
              <div className="relative w-30" ref={yearDropdownRef}>
                {/* Closed Button */}
                <button
                  type="button"
                  onClick={() => setIsYearDropdownOpen(!isYearDropdownOpen)}
                  disabled={loadingYears}
                  className={`
                    flex items-center justify-between px-3 py-1 text-xs gap-2 
                    border border-black/60 bg-white hover:bg-gray-50 transition w-full
                    ${isYearDropdownOpen ? "border-b-white border-black/60 border" : ""}
                    ${loadingYears ? "opacity-50 cursor-not-allowed" : ""}
                  `}
                >
                  <span className={`flex-1 truncate text-left ${selectedYear ? "text-black" : "text-black"}`}>
                    {loadingYears ? "Loading..." : (selectedYear || "Year")}
                  </span>

                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/material-symbols-light_arrow-drop-down-rounded.png"
                    alt="dropdown"
                    className={`w-5 h-5 transition-transform duration-300 ${isYearDropdownOpen ? "rotate-180" : ""}`}
                  />
                </button>

                {/* Dropdown Menu */}
                {isYearDropdownOpen && !loadingYears && (
                  <div className="absolute w-full mt-0 bg-white text-black border border-black/60 border-t-white shadow-lg z-30 flex flex-col max-h-48 overflow-y-auto">
                    <ul className="py-1 text-[12px]">
                      {yearOptions.map((year) => (
                        <li
                          key={year}
                          onClick={() => handleYearSelect(year)}
                          className={`
                            px-3 py-1 cursor-pointer flex items-center justify-between 
                            hover:bg-gray-100 transition duration-150 text-xs
                            ${selectedYear === year ? "bg-darkblue1 text-white" : "text-black"}
                          `}
                        >
                          {year}
                          {selectedYear === year && (
                            <svg className="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Report Type Tabs */}
              <div className="flex items-center gap-3 flex-1 overflow-x-auto">
                {reportOptions.map((report) => (
                  <button
                    key={report.id}
                    onClick={() => setActiveReport(report.label)}
                    className={`
                      px-2 py-1 text-sm font-medium whitespace-nowrap flex-shrink-0
                      transition-all duration-200
                      ${activeReport === report.label
                        ? "bg-lightBlue/50 text-darkblue1 shadow-md scale-105"
                        : "bg-white text-gray-700 hover:bg-gray-50 hover:shadow-sm shadow-sm"
                      }
                    `}
                  >
                    {report.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Mobile/Tablet View - Stacked Layout */}
            <div className="lg:hidden space-y-4">
              {/* Year Dropdown */}
              <div className="flex items-center gap-3">
                <label className="text-sm font-medium text-gray-700 whitespace-nowrap">
                  Year <span className="text-red-500">*</span>
                </label>
                
                <div className="relative flex-1" ref={yearDropdownRefMobile}>
                  <button
                    type="button"
                    onClick={() => setIsYearDropdownOpen(!isYearDropdownOpen)}
                    disabled={loadingYears}
                    className={`
                      w-full px-4 py-2.5 text-left border-2 
                      bg-white text-sm font-medium
                      transition-all duration-200
                      flex items-center justify-between
                      ${isYearDropdownOpen 
                        ? 'border-darkblue1 ring-2 ring-darkblue1/20 shadow-md' 
                        : 'border-gray-300 hover:border-darkblue1/50'
                      }
                      ${!selectedYear ? 'text-gray-400' : 'text-gray-900'}
                      ${loadingYears ? 'opacity-50 cursor-not-allowed' : ''}
                    `}
                  >
                    <span className="truncate">
                      {loadingYears ? "Loading..." : (selectedYear || "Select Year")}
                    </span>
                    <ChevronDown 
                      size={18} 
                      className={`
                        transition-transform duration-200 flex-shrink-0 ml-2
                        ${isYearDropdownOpen ? 'rotate-180 text-darkblue1' : 'text-gray-400'}
                      `}
                    />
                  </button>

                  {isYearDropdownOpen && !loadingYears && (
                    <div className="absolute z-50 w-full mt-2 bg-white border-2 border-darkblue1 shadow-xl max-h-64 overflow-y-auto">
                      <div className="py-1">
                        {yearOptions.map((year) => (
                          <button
                            key={year}
                            type="button"
                            onClick={() => handleYearSelect(year)}
                            className={`
                              w-full px-4 py-2.5 text-left text-sm
                              transition-colors duration-150
                              ${selectedYear === year 
                                ? 'bg-darkblue1 text-white font-medium' 
                                : 'text-gray-700 hover:bg-lightBlue/30'
                              }
                            `}
                          >
                            <div className="flex items-center justify-between">
                              <span>{year}</span>
                              {selectedYear === year && (
                                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                </svg>
                              )}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Report Type Tabs - Radio buttons */}
              <div className="flex flex-wrap gap-3">
                {reportOptions.map((report) => (
                  <label key={report.id} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="report"
                      checked={activeReport === report.label}
                      onChange={() => setActiveReport(report.label)}
                      className="w-4 h-4 text-darkblue1 focus:ring-darkblue1"
                    />
                    <span className="text-sm font-medium text-gray-700">{report.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Dynamic Chart Component or Empty State */}
        <div className="bg-white shadow-lg border border-gray-200 p-4 lg:p-6">
  <ActiveComponent 
    selectedYear={selectedYear}   // can be ""
    onDataReady={handleReportDataReady}
  />
</div>
        </div>
      </div>
    </div>
  );
};

export default InfrastructureReportsHome;