// src/pages/DEALERINVESTMENT/InfrastructureReports/DealerwiseFacilities.jsx
import React, { useState, useRef, useEffect } from "react";
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,BarChart } from "recharts";
import { Menu } from "lucide-react";
import DataTableModal from "./DataTableModal";
import { fetchDealerwiseFacilitiesData } from "../../../services/dealerInvestment/dealerInvestmentReports.service";
import { printChart } from "../../../util/printChart";

const DealerwiseFacilities = ({ selectedYear, onDataReady }) => {
  const [showChartMenu, setShowChartMenu] = useState(false);
  const [showDataTable, setShowDataTable] = useState(false);
  const [chartData, setChartData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const chartRef = useRef(null);
  const chartContainerRef = useRef(null);
  const menuRef = useRef(null);

 useEffect(() => {
  const loadData = async () => {
    setLoading(true);
    setError(null);

    try {
      let response;

      if (!selectedYear) {
        // 🔥 INITIAL LOAD → FETCH ALL DATA
        response = await fetchDealerwiseFacilitiesData("ALL");
      } else {
        // 🔥 FILTERED DATA
        response = await fetchDealerwiseFacilitiesData(selectedYear);
      }

      if (response.status && response.data.length > 0) {
        setChartData(response.data);
      } else {
        setChartData(generateFallbackData());
        if (!response.status) {
          setError("No data available from API. Showing sample data.");
        }
      }
    } catch (err) {
      console.error("Error loading dealerwise facilities data:", err);
      setError("Failed to load data. Showing sample data.");
      setChartData(generateFallbackData());
    } finally {
      setLoading(false);
    }
  };

  loadData();
}, [selectedYear]);
  useEffect(() => {
    if (onDataReady && chartContainerRef.current && chartData.length > 0) {
      onDataReady(chartContainerRef.current, chartData);
    }
  }, [chartData, onDataReady]);

  const generateFallbackData = () => {
    const dealers = ["ACT", "ALPHA-DL", "ALPHA-UP", "BSES", "DBS", "ENCORE", "ESDEE", "INFRA", "NAVIN", "PACT", "PAL", "PT ENGG", "RPSL-AP", "RPSL-TS", "SEMS", "SMPL-BH", "SMPL-WB", "SVP", "TEAM", "WIE"];
    return dealers.map(dealer => ({
      dealer, "1S": Math.floor(Math.random() * 5), "2S": Math.floor(Math.random() * 4), "3S": Math.floor(Math.random() * 3), "TP": Math.floor(Math.random() * 6),
      totalActual: Math.floor(Math.random() * 15) + 5, target: Math.floor(Math.random() * 20) + 10, population: Math.floor(Math.random() * 200) + 50
    }));
  };
  const [isFullScreen, setIsFullScreen] = useState(false);

  useEffect(() => {
    const handleClickOutside = (event) => { if (menuRef.current && !menuRef.current.contains(event.target)) setShowChartMenu(false); };
    if (showChartMenu) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showChartMenu]);

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-300 rounded shadow-lg">
          <p className="font-normal text-xs text-gray-800 mb-1">{label}</p>
          {payload.map((entry, index) => (<p key={index} style={{ color: entry.color }} className="text-xs">{entry.name}: {entry.value}</p>))}
        </div>
      );
    }
    return null;
  };
const handleFullScreen = () => {
  const element = chartRef.current;
  if (!element) return;

  if (!document.fullscreenElement) {
    // ENTER
    const request =
      element.requestFullscreen ||
      element.webkitRequestFullscreen ||
      element.msRequestFullscreen;

    if (request) {
      request.call(element).catch((err) => {
        console.error("Fullscreen error:", err);
      });
    }
  } else {
    // EXIT
    const exit =
      document.exitFullscreen ||
      document.webkitExitFullscreen ||
      document.msExitFullscreen;

    if (exit) exit.call(document);
  }

  setShowChartMenu(false);
};
useEffect(() => {
  const handleFullScreenChange = () => {
    setIsFullScreen(!!document.fullscreenElement);
  };

  document.addEventListener("fullscreenchange", handleFullScreenChange);
  document.addEventListener("webkitfullscreenchange", handleFullScreenChange);

  return () => {
    document.removeEventListener("fullscreenchange", handleFullScreenChange);
    document.removeEventListener("webkitfullscreenchange", handleFullScreenChange);
  };
}, []);  
  const handlePrint = () => {
    printChart(chartContainerRef.current, "Dealerwise Facilities", `Year: ${selectedYear} | ${chartData.length} Dealers`);
    setShowChartMenu(false);
  };

  const handleExportPNG = () => {
    const svg = chartContainerRef.current?.querySelector("svg");
    if (svg) {
      const svgRect = svg.getBoundingClientRect();
      const canvas = document.createElement("canvas");
      canvas.width = svgRect.width * 2; canvas.height = svgRect.height * 2;
      const ctx = canvas.getContext("2d");
      ctx.scale(2, 2); ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, svgRect.width, svgRect.height);
      const svgString = new XMLSerializer().serializeToString(svg.cloneNode(true));
      const img = new Image();
      img.onload = () => { ctx.drawImage(img, 0, 0, svgRect.width, svgRect.height); canvas.toBlob((blob) => { const link = document.createElement("a"); link.download = `dealerwise-facilities-${selectedYear}.png`; link.href = URL.createObjectURL(blob); link.click(); }, "image/png"); };
      img.src = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svgString)));
    }
    setShowChartMenu(false);
  };

  const handleExportJPEG = () => {
    const svg = chartContainerRef.current?.querySelector("svg");
    if (svg) {
      const svgRect = svg.getBoundingClientRect();
      const canvas = document.createElement("canvas");
      canvas.width = svgRect.width * 2; canvas.height = svgRect.height * 2;
      const ctx = canvas.getContext("2d");
      ctx.scale(2, 2); ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, svgRect.width, svgRect.height);
      const svgString = new XMLSerializer().serializeToString(svg.cloneNode(true));
      const img = new Image();
      img.onload = () => { ctx.drawImage(img, 0, 0, svgRect.width, svgRect.height); canvas.toBlob((blob) => { const link = document.createElement("a"); link.download = `dealerwise-facilities-${selectedYear}.jpeg`; link.href = URL.createObjectURL(blob); link.click(); }, "image/jpeg", 0.95); };
      img.src = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svgString)));
    }
    setShowChartMenu(false);
  };

  const handleExportSVG = () => {
    const svg = chartContainerRef.current?.querySelector("svg");
    if (svg) {
      const svgData = new XMLSerializer().serializeToString(svg);
      const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
      const link = document.createElement("a"); link.download = `dealerwise-facilities-${selectedYear}.svg`; link.href = URL.createObjectURL(blob); link.click();
    }
    setShowChartMenu(false);
  };

  const handleDownloadCSV = () => {
    const headers = ["Dealer", "1S", "2S", "3S", "TP", "Total Actual", "Target", "Population"];
    const csvContent = [headers.join(","), ...chartData.map((row) => `${row.dealer},${row["1S"]},${row["2S"]},${row["3S"]},${row.TP},${row.totalActual},${row.target},${row.population}`)].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a"); link.download = `dealerwise-facilities-${selectedYear}.csv`; link.href = URL.createObjectURL(blob); link.click();
    setShowChartMenu(false);
  };

  const handleDownloadXLS = () => {
    const headers = ["Dealer", "1S", "2S", "3S", "TP", "Total Actual", "Target", "Population"];
    const content = [headers.join("\t"), ...chartData.map((row) => `${row.dealer}\t${row["1S"]}\t${row["2S"]}\t${row["3S"]}\t${row.TP}\t${row.totalActual}\t${row.target}\t${row.population}`)].join("\n");
    const blob = new Blob([content], { type: "application/vnd.ms-excel" });
    const link = document.createElement("a"); link.download = `dealerwise-facilities-${selectedYear}.xls`; link.href = URL.createObjectURL(blob); link.click();
    setShowChartMenu(false);
  };

  const handleViewDataTable = () => { setShowDataTable(true); setShowChartMenu(false); };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-darkblue1 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-sm text-gray-600">Loading dealerwise facilities data...</span>
        </div>
      </div>
    );
  }

  return (
    <>
<div
  className={isFullScreen ? "bg-white h-screen w-full" : "relative"}
  ref={chartRef}
>        {error && <div className="mb-4 px-4 py-2 bg-yellow-50 border border-yellow-200 text-yellow-800 text-sm rounded">{error}</div>}

        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 text-center">
            <div className="text-xl font-bold text-gray-800 tracking-wider mb-1">V O L V O</div>
            <h2 className="text-lg font-semibold text-gray-800">Facility Types for all Dealers</h2>
            <p className="text-sm text-gray-600 mt-1">Year: {selectedYear} | {chartData.length} Dealers</p>
          </div>

          <div className="relative" ref={menuRef}>
            <button onClick={() => setShowChartMenu(!showChartMenu)} className="p-2 hover:bg-gray-100 rounded-md transition"><Menu size={20} className="text-gray-600" /></button>
            {showChartMenu && (
              <div className="absolute right-0 top-full mt-2 w-56 bg-white border border-gray-200 rounded-md shadow-lg z-50">
                <button onClick={handleFullScreen} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" /></svg>
                  View in full screen
                </button>
                <button onClick={handlePrint} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                  Print chart
                </button>
                <div className="border-t border-gray-200 my-1"></div>
                <button onClick={handleExportPNG} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download PNG image</button>
                <button onClick={handleExportJPEG} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download JPEG image</button>
                <button onClick={handleExportSVG} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download SVG vector image</button>
                <div className="border-t border-gray-200 my-1"></div>
                <button onClick={handleDownloadCSV} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download CSV</button>
                <button onClick={handleDownloadXLS} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download XLS</button>
                <button onClick={handleViewDataTable} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">View data table</button>
              </div>
            )}
          </div>
        </div>

       <div
  ref={chartContainerRef}
  className={
    isFullScreen
      ? "h-screen w-full flex flex-col bg-white p-4"
      : ""
  }
>
  {chartData.length > 0 ? (
    <div className={isFullScreen ? "flex-1 min-h-0" : ""}>
      <ResponsiveContainer
        width="100%"
        height={isFullScreen ? "75%" : 400}
      >
        <BarChart
          data={chartData}
          margin={{ top: 20, right: 20, left: 10, bottom: 60 }}
        >
          {/* Grid */}
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="#e5e7eb"
            vertical={false}
          />

          {/* X Axis */}
         <XAxis
  dataKey="dealer"
  tick={{ fontSize: 9 }}
  angle={0}
  textAnchor="middle"
  interval={0}
  height={60} // 🔥 gives space for label
  label={{
    value: "Dealers",          // 🔥 THIS IS WHAT YOU WANT
    position: "insideBottom",
    offset: -5,
    style: {
      fontSize: 12,
      fill: "#4b5563",
      fontWeight: 500,
    },
  }}
/>

          {/* Y Axis */}
          <YAxis
            tick={{ fontSize: 11, fill: "#4b5563" }}
            tickLine={false}
            axisLine={{ stroke: "#d1d5db" }}
            label={{
              value: "No. of Facility",
              angle: -90,
              position: "insideLeft",
              style: {
                fontSize: 12,
                fill: "#4b5563",
                fontWeight: 500,
              },
            }}
          />

          {/* Tooltip */}
          <Tooltip
            content={<CustomTooltip />}
            cursor={{ fill: "rgba(0,0,0,0.03)" }}
          />

          {/* Legend */}
          <Legend
            verticalAlign="top"
            align="center"
            iconType="square"
            iconSize={10}
            wrapperStyle={{ paddingBottom: 10 }}
          />

          {/* Bars */}
          <Bar dataKey="1S" fill="#7CB342" name="1S" radius={[4, 4, 0, 0]} />
          <Bar dataKey="2S" fill="#66BB6A" name="2S" radius={[4, 4, 0, 0]} />
          <Bar dataKey="3S" fill="#4CAF50" name="3S" radius={[4, 4, 0, 0]} />
          <Bar dataKey="TP" fill="#388E3C" name="TP" radius={[4, 4, 0, 0]} />
          <Bar
            dataKey="totalActual"
            fill="#81C784"
            name="Total Facility Actual"
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  ) : (
    <div className="flex justify-center items-center h-96 text-gray-500">
      No data available
    </div>
  )}
</div>
        <div className="mt-4 text-left text-xs text-gray-500">Volvo Construction Equipment</div>
      </div>

      <DataTableModal isOpen={showDataTable} onClose={() => setShowDataTable(false)} title="Dealerwise Facilities - Data Table" subtitle={`Year: ${selectedYear}`} data={chartData} />
    </>
  );
};

export default DealerwiseFacilities;