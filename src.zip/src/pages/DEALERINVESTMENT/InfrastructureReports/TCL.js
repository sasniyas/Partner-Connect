// src/pages/DEALERINVESTMENT/InfrastructureReports/TCL.jsx
import React, { useState, useRef, useEffect } from "react";
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Menu } from "lucide-react";
import DataTableModal from "./DataTableModal";
import { fetchTCLData } from "../../../services/dealerInvestment/dealerInvestmentReports.service";
import { printChart } from "../../../util/printChart";

const TCL = ({ selectedYear, onDataReady }) => {
  const [showChartMenu, setShowChartMenu] = useState(false);
  const [showDataTable, setShowDataTable] = useState(false);
  const [chartData, setChartData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const chartRef = useRef(null);
  const chartContainerRef = useRef(null);
  const menuRef = useRef(null);

 useEffect(() => {
  const loadData = async () => {
    setLoading(true);
    setError(null);

    try {
      let response;

      if (!selectedYear) {
        // 🔥 INITIAL LOAD → FETCH ALL DATA
        response = await fetchTCLData("ALL");
      } else {
        // 🔥 FILTERED DATA
        response = await fetchTCLData(selectedYear);
      }

      if (response.status && response.data.length > 0) {
        setChartData(response.data);
      } else {
        setChartData(generateFallbackData());
        if (!response.status) {
          setError("No data available from API. Showing sample data.");
        }
      }
    } catch (err) {
      console.error("Error loading TCL data:", err);
      setError("Failed to load data. Showing sample data.");
      setChartData(generateFallbackData());
    } finally {
      setLoading(false);
    }
  };

  loadData();
}, [selectedYear]);

  useEffect(() => {
    if (onDataReady && chartContainerRef.current && chartData.length > 0) {
      onDataReady(chartContainerRef.current, chartData);
    }
  }, [chartData, onDataReady]);

  const generateFallbackData = () => {
    const dealers = ["ACT", "ALPHA-DL", "ALPHA-UP", "BSES", "DBS", "ENCORE", "ESDEE", "INFRA", "NAVIN", "PACT", "PAL", "PT ENGG", "RPSL-AP", "RPSL-TS", "SEMS", "SMPL-BH", "SMPL-WB", "SVP", "TEAM", "WIE"];
    return dealers.map(dealer => ({ dealer, tcl0: Math.floor(Math.random() * 5), tcl1: Math.floor(Math.random() * 6), tcl2: Math.floor(Math.random() * 4), tcl3: Math.floor(Math.random() * 3), tcl3Pro: Math.floor(Math.random() * 2), target: Math.floor(Math.random() * 20) + 5, population: Math.floor(Math.random() * 200) + 50 }));
  };

  useEffect(() => {
    const handleClickOutside = (event) => { if (menuRef.current && !menuRef.current.contains(event.target)) setShowChartMenu(false); };
    if (showChartMenu) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showChartMenu]);

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-300 rounded shadow-lg">
          <p className="font-semibold text-gray-800 mb-1">{label}</p>
          {payload.map((entry, index) => (<p key={index} style={{ color: entry.color }} className="text-sm">{entry.name}: {entry.value}</p>))}
        </div>
      );
    }
    return null;
  };

  const handleFullScreen = () => { if (chartRef.current?.requestFullscreen) chartRef.current.requestFullscreen(); setShowChartMenu(false); };
  
  const handlePrint = () => {
    printChart(chartContainerRef.current, "Technical Team - TCL for all Dealers", `Year: ${selectedYear} | ${chartData.length} Dealers`);
    setShowChartMenu(false);
  };

  const handleExportPNG = () => {
    const svg = chartContainerRef.current?.querySelector("svg");
    if (svg) {
      const svgRect = svg.getBoundingClientRect();
      const canvas = document.createElement("canvas");
      canvas.width = svgRect.width * 2; canvas.height = svgRect.height * 2;
      const ctx = canvas.getContext("2d");
      ctx.scale(2, 2); ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, svgRect.width, svgRect.height);
      const svgString = new XMLSerializer().serializeToString(svg.cloneNode(true));
      const img = new Image();
      img.onload = () => { ctx.drawImage(img, 0, 0, svgRect.width, svgRect.height); canvas.toBlob((blob) => { const link = document.createElement("a"); link.download = `tcl-${selectedYear}.png`; link.href = URL.createObjectURL(blob); link.click(); }, "image/png"); };
      img.src = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svgString)));
    }
    setShowChartMenu(false);
  };

  const handleExportJPEG = () => {
    const svg = chartContainerRef.current?.querySelector("svg");
    if (svg) {
      const svgRect = svg.getBoundingClientRect();
      const canvas = document.createElement("canvas");
      canvas.width = svgRect.width * 2; canvas.height = svgRect.height * 2;
      const ctx = canvas.getContext("2d");
      ctx.scale(2, 2); ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, svgRect.width, svgRect.height);
      const svgString = new XMLSerializer().serializeToString(svg.cloneNode(true));
      const img = new Image();
      img.onload = () => { ctx.drawImage(img, 0, 0, svgRect.width, svgRect.height); canvas.toBlob((blob) => { const link = document.createElement("a"); link.download = `tcl-${selectedYear}.jpeg`; link.href = URL.createObjectURL(blob); link.click(); }, "image/jpeg", 0.95); };
      img.src = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svgString)));
    }
    setShowChartMenu(false);
  };

  const handleExportSVG = () => {
    const svg = chartContainerRef.current?.querySelector("svg");
    if (svg) {
      const svgData = new XMLSerializer().serializeToString(svg);
      const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
      const link = document.createElement("a"); link.download = `tcl-${selectedYear}.svg`; link.href = URL.createObjectURL(blob); link.click();
    }
    setShowChartMenu(false);
  };

  const handleDownloadCSV = () => {
    const headers = ["Dealer", "TCL0", "TCL1", "TCL2", "TCL3", "TCL3 PRO", "Target", "Population"];
    const csvContent = [headers.join(","), ...chartData.map((row) => `${row.dealer},${row.tcl0},${row.tcl1},${row.tcl2},${row.tcl3},${row.tcl3Pro},${row.target},${row.population}`)].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a"); link.download = `tcl-${selectedYear}.csv`; link.href = URL.createObjectURL(blob); link.click();
    setShowChartMenu(false);
  };

  const handleDownloadXLS = () => {
    const headers = ["Dealer", "TCL0", "TCL1", "TCL2", "TCL3", "TCL3 PRO", "Target", "Population"];
    const content = [headers.join("\t"), ...chartData.map((row) => `${row.dealer}\t${row.tcl0}\t${row.tcl1}\t${row.tcl2}\t${row.tcl3}\t${row.tcl3Pro}\t${row.target}\t${row.population}`)].join("\n");
    const blob = new Blob([content], { type: "application/vnd.ms-excel" });
    const link = document.createElement("a"); link.download = `tcl-${selectedYear}.xls`; link.href = URL.createObjectURL(blob); link.click();
    setShowChartMenu(false);
  };

  const handleViewDataTable = () => { setShowDataTable(true); setShowChartMenu(false); };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-darkblue1 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-sm text-gray-600">Loading TCL data...</span>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="relative" ref={chartRef}>
        {error && <div className="mb-4 px-4 py-2 bg-yellow-50 border border-yellow-200 text-yellow-800 text-sm rounded">{error}</div>}
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 text-center">
            <div className="text-xl font-bold text-gray-800 tracking-wider mb-1">V O L V O</div>
            <h2 className="text-lg font-semibold text-gray-800">Technical Team - TCL for all Dealers</h2>
            <p className="text-sm text-gray-600 mt-1">Year: {selectedYear} | {chartData.length} Dealers</p>
          </div>
          <div className="relative" ref={menuRef}>
            <button onClick={() => setShowChartMenu(!showChartMenu)} className="p-2 hover:bg-gray-100 rounded-md transition"><Menu size={20} className="text-gray-600" /></button>
            {showChartMenu && (
              <div className="absolute right-0 top-full mt-2 w-56 bg-white border border-gray-200 rounded-md shadow-lg z-50">
                <button onClick={handleFullScreen} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" /></svg>
                  View in full screen
                </button>
                <button onClick={handlePrint} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                  Print chart
                </button>
                <div className="border-t border-gray-200 my-1"></div>
                <button onClick={handleExportPNG} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download PNG image</button>
                <button onClick={handleExportJPEG} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download JPEG image</button>
                <button onClick={handleExportSVG} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download SVG vector image</button>
                <div className="border-t border-gray-200 my-1"></div>
                <button onClick={handleDownloadCSV} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download CSV</button>
                <button onClick={handleDownloadXLS} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">Download XLS</button>
                <button onClick={handleViewDataTable} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50">View data table</button>
              </div>
            )}
          </div>
        </div>
        <div ref={chartContainerRef}>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={450}>
              <ComposedChart data={chartData} margin={{ top: 20, right: 20, left: 10, bottom: 50 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                <XAxis dataKey="dealer" tick={{ fontSize: 9, fill: "#6b7280" }} angle={-45} textAnchor="end" height={80} />
                <YAxis yAxisId="left" tick={{ fontSize: 11, fill: "#6b7280" }} label={{ value: "No. of TCL", angle: -90, position: "insideLeft", style: { fontSize: 12, fill: "#6b7280" } }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: "#6b7280" }} label={{ value: "Machine Population", angle: 90, position: "insideRight", style: { fontSize: 12, fill: "#6b7280" } }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ paddingTop: "20px" }} iconType="circle" />
                <Bar yAxisId="left" dataKey="tcl0" fill="#7CB342" name="TCL0" radius={[4, 4, 0, 0]} maxBarSize={12} />
                <Bar yAxisId="left" dataKey="tcl1" fill="#66BB6A" name="TCL1" radius={[4, 4, 0, 0]} maxBarSize={12} />
                <Bar yAxisId="left" dataKey="tcl2" fill="#4CAF50" name="TCL2" radius={[4, 4, 0, 0]} maxBarSize={12} />
                <Bar yAxisId="left" dataKey="tcl3" fill="#388E3C" name="TCL3" radius={[4, 4, 0, 0]} maxBarSize={12} />
                <Bar yAxisId="left" dataKey="tcl3Pro" fill="#2E7D32" name="TCL3 PRO" radius={[4, 4, 0, 0]} maxBarSize={12} />
                <Line yAxisId="right" type="monotone" dataKey="target" stroke="#2196F3" strokeWidth={2} dot={{ r: 3 }} name="Target" />
                <Line yAxisId="right" type="monotone" dataKey="population" stroke="#1976D2" strokeWidth={2} dot={{ r: 3 }} name="Machine Population" />
              </ComposedChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex justify-center items-center h-96 text-gray-500">No data available</div>
          )}
        </div>
        <div className="mt-4 text-left text-xs text-gray-500">Volvo Construction Equipment</div>
      </div>
      <DataTableModal isOpen={showDataTable} onClose={() => setShowDataTable(false)} title="Technical Team - TCL - Data Table" subtitle={`Year: ${selectedYear}`} data={chartData} />
    </>
  );
};

export default TCL;