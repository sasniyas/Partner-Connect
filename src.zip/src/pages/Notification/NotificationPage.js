import { useState, useEffect, useRef } from "react"
import { useNavigate } from "react-router-dom"
import Header from "../../Components/Header"
import SubNavbar3 from "../../Components/SubNavbar3"
import { ArrowLeft, ArrowUp, ArrowDown, ChevronUp, ChevronDown, ChevronsUpDown } from "lucide-react"
import { getUserNotificationsByUserId, bulkToggleNotificationsAsSeen } from "../../services/notificationService"
import { useMemo } from "react"
import Searchinput from "../../Components/Searchinput"
import { formatedTime } from "../../util/timeFormat"

const NotificationPage = () => {
  const navigate = useNavigate()
  const tableContainerRef = useRef(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [notifications, setNotifications] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [hoveredCell, setHoveredCell] = useState(null)

  const [showScrollButtons, setShowScrollButtons] = useState(false)
  const [scrollDirection, setScrollDirection] = useState(null)
  const [lastScrollTop, setLastScrollTop] = useState(0)
  const [sortKey, setSortKey] = useState(null)
  const [sortOrder, setSortOrder] = useState(null)

  const formatDate = (dateString) => {
    if (!dateString) return ""
    try {
      const date = new Date(dateString)
      return date.toLocaleString()
    } catch (e) {
      return dateString
    }
  }

  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc")
        return
      } else if (sortOrder === "desc") {
        setSortKey(null)
        setSortOrder(null)
        return
      }
    }
    setSortKey(key)
    setSortOrder("asc")
  }

  const filteredNotifications = useMemo(() => {
    if (!searchTerm) return notifications
    const lowerSearch = searchTerm.toLowerCase()
    return notifications.filter(n =>
      (n.title?.toLowerCase().includes(lowerSearch)) ||
      (formatedTime(n.created_at).toLowerCase().includes(lowerSearch))
    )
  }, [notifications, searchTerm])

  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredNotifications

    return [...filteredNotifications].sort((a, b) => {
      const valA = (a[sortKey] || "").toString().toLowerCase()
      const valB = (b[sortKey] || "").toString().toLowerCase()

      return sortOrder === "asc"
        ? valA.localeCompare(valB)
        : valB.localeCompare(valA)
    })
  }, [filteredNotifications, sortKey, sortOrder])

  useEffect(() => {
    fetchNotifications()
  }, [])

  const fetchNotifications = async () => {
    try {
      setLoading(true)
      setError(null)

      const data = await getUserNotificationsByUserId()
      setNotifications(data || [])

      // Mark unseen as seen (optimal bulk approach - single API call)
      const unseenIds = (data || []).filter(n => n.isSeen === 0).map(n => n.id)
      if (unseenIds.length > 0) {
        try {
          await bulkToggleNotificationsAsSeen(unseenIds)
        } catch (err) {
          console.error("Error marking notifications as seen:", err)
        }
      }
    } catch (error) {
      console.error("❌ Error fetching notifications:", error.message)
      setError(error.message)
      setNotifications([])
    } finally {
      setLoading(false)
    }
  }

  const handleTableScroll = (e) => {
    const container = e.target
    const scrollTop = container.scrollTop
    const scrollHeight = container.scrollHeight
    const clientHeight = container.clientHeight

    if (scrollTop > lastScrollTop) {
      setScrollDirection("down")
    } else if (scrollTop < lastScrollTop) {
      setScrollDirection("up")
    }
    setLastScrollTop(scrollTop)

    const isScrollable = scrollHeight > clientHeight
    const hasScrolledDown = scrollTop > 100
    setShowScrollButtons(isScrollable && hasScrolledDown)
  }

  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: tableContainerRef.current.scrollHeight, behavior: "smooth" })
    }
  }

  const handleBack = () => navigate(-1)

  return (
    <div className="bg-Frostwhite h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="flex items-center gap-2 mb-4">
            <ArrowLeft onClick={handleBack} size={24} className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1" />
            <h1 className="text-lg font-semibold text-darkblue1">Notifications</h1>
          </div>
          <hr className="hidden lg:block w-[7%] border-t-4 ml-8 border-darkblue1 -mt-5 mb-4" />

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg shadow-sm p-4 mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-red-600 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4v.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div>
                  <p className="text-sm font-medium text-red-800">Failed to load notifications</p>
                  <p className="text-xs text-red-700">{error}</p>
                </div>
              </div>
              <button onClick={fetchNotifications} className="text-xs px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 transition flex-shrink-0">Retry</button>
            </div>
          )}

          <div className="flex items-center justify-between mb-2">
            {/* Left: Search Input */}
            <div className="w-[200px]">
              <Searchinput
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search..."
                className="w-full"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                focusRing="focus:ring-black/60"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-2 sm:py-3"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                iconColor="text-black"
              />
            </div>

            {/* Right: Notification count */}
            <div className="flex items-center gap-2">
              <span className="inline-block w-3 h-3 rounded-full bg-SteelBlue1"></span>
              <p className="text-xs text-black">
                <span className="font-bold">Total:</span> {notifications.length} notification{notifications.length !== 1 ? "s" : ""}
              </p>
            </div>
          </div>

          {loading ? (
            <div className="bg-white shadow-md border border-Dustyblue rounded-lg overflow-hidden p-8 flex justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
            </div>
          ) : notifications.length === 0 ? (
            <div className="bg-white shadow-md border border-Dustyblue rounded-lg overflow-hidden p-12 text-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
              </svg>
              <p className="text-gray-500 text-sm">No notifications yet</p>
            </div>
          ) : (
            <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
              <div ref={tableContainerRef} className="overflow-y-auto overflow-x-auto scrollbar-hide" style={{ maxHeight: notifications.length > 8 ? "calc(100vh - 220px)" : "auto" }} onScroll={handleTableScroll}>
                <table className="w-full text-xs table-fixed">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                    <tr>
                      <th
                        className="text-left px-6 py-1.5 w-[65%] border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer select-none"
                        onClick={() => handleSort("title")}
                      >
                        <div className="flex items-center gap-1">
                          Title
                          {sortKey !== "title" && (
                            <ChevronsUpDown className="w-3 h-3 text-white" />
                          )}
                          {sortKey === "title" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "title" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                      <th
                        className="text-left px-6 py-1.5 w-[35%] border border-grey2 border-t-0 border-l-0 border-r-0 font-medium cursor-pointer select-none"
                        onClick={() => handleSort("created_at")}
                      >
                        <div className="flex items-center gap-1">
                          Created Date
                          {sortKey === "created_at" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "created_at" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortedData.length > 0 ? (
                      sortedData.map((notification, idx) => (
                        <tr key={notification.id} className="border-t hover:bg-lightBlue/50 transition">
                          {/* Title cell */}
                          <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 text-xs relative">
                            <p
                              className="truncate max-w-[40rem] cursor-pointer font-medium"
                              onMouseEnter={() => {
                                if ((notification.title || "").length > 40) setHoveredCell(notification.id + "-title")
                              }}
                              onMouseLeave={() => setHoveredCell(null)}
                            >
                              {notification.title || "Untitled"}
                            </p>
                            {hoveredCell === notification.id + "-title" && (
                              <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-10">
                                {notification.title}
                              </span>
                            )}
                            {/* Message below title */}
                            <p className="text-black/60 text-xs mt-0.5 truncate max-w-[40rem]">
                              {notification.message || "No message"}
                            </p>
                          </td>

                          {/* Created Date cell */}
                          <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-xs relative">
                            <p
                              className="truncate max-w-[15rem] cursor-pointer"
                              onMouseEnter={() => {
                                if ((notification.created_at || "").length > 15) setHoveredCell(notification.id + "-created_at")
                              }}
                              onMouseLeave={() => setHoveredCell(null)}
                            >
                              {formatedTime(notification.created_at) || "No date"}
                            </p>
                            {hoveredCell === notification.id + "-created_at" && (
                              <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-10">
                                {formatedTime(notification.created_at)}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={2} className="text-center py-4 text-gray-500 text-xs italic">
                          No data found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {showScrollButtons && (
            <div className="fixed bottom-8 right-6 z-40 pointer-events-auto animate-fade-in">
              {scrollDirection === "down" && (
                <button onClick={scrollToTop} className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm" aria-label="Scroll to top">
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}
              {scrollDirection === "up" && (
                <button onClick={scrollToBottom} className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm" aria-label="Scroll to bottom">
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default NotificationPage