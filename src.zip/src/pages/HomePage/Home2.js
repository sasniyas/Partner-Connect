// import { useEffect, useState } from "react";
// import Header from "../../Components/Header";
// import SubNavbar2 from "../../Components/SubNavbar2";


// function Home2() {
//   const [menuOpen, setMenuOpen] = useState(false);
//   const [currentSlide, setCurrentSlide] = useState(0);

//   const images = [
//     "/icons/Login/volvologin 11.png",
//     "/icons/Homepage1/HAOMEPAGEAIMGAE2.png",
//     "/icons/Homepage1/Homepage iamge3.png",
//   ];

//   useEffect(() => {
//     const interval = setInterval(() => {
//       setCurrentSlide((prev) => (prev + 1) % images.length);
//     }, 3000);
//     return () => clearInterval(interval);
//   }, [images.length]);

//   return (
//     <div className="bg-black/15 min-h-screen flex flex-col">
//       <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
//       {/* <SubNavbar /> */}
// <SubNavbar2/>
//       <div
//         className={`transition-all duration-300 mt-16 ${
//           menuOpen ? "lg:ml-60" : "ml-0"
//         }`}
//       >
//         {/* Hero Slider */}
//         <div className="relative w-full h-screen overflow-hidden mt-[-65px]">
//           {images.map((img, index) => (
//             <img
//               key={index}
//               src={img}
//               alt={`Slide ${index + 1}`}
//               className={`absolute top-0 left-0 w-full h-full object-cover transition-opacity duration-1000 ${
//                 index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
//               }`}
//             />
//           ))}

//           {/* Text Overlay */}
//           <div className="absolute inset-0 bg-black bg-opacity-10 flex flex-col items-center justify-start pt-32 md:pt-48 lg:pt-56 xl:pt-60 text-center z-20 px-4">
//             <h1 className="text-white text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-9xl font-semibold mb-3 font-VolvoNovum leading-tight">
//               Construction Operation Center
//             </h1>
//             <p className="text-white text-sm sm:text-lg md:text-xl font-medium">
//               Real-time monitoring and project management dashboard
//             </p>
//           </div>

//           {/* Dot Indicators */}
//           <div className="absolute bottom-6 w-full flex justify-center gap-2 z-30">
//             {images.map((_, index) => (
//               <div
//                 key={index}
//                 className={`rounded-full transition-all duration-300 ${
//                   currentSlide === index
//                     ? "bg-white scale-110 w-2.5 h-2.5"
//                     : "bg-white/50 w-2 h-2"
//                 }`}
//               />
//             ))}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Home2;
