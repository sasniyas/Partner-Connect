// // // import React, { useState } from "react";
// // // import Header from "../../Components/Header";
// // // // import Dashboard from "./Dashboard";
// // // function Home() {
// // //   const [menuOpen, setMenuOpen] = useState(false);

// // //   return (
// // //     <div className="bg-black/15  min-h-screen flex flex-col">
// // //       {/* Navigation Bar */}
// // //       <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

// // //       {/* Main Content */}
// // //       <div
// // //         className={`
// // //           transition-all duration-300 mt-16 p-4 sm:p-6 md:p-10 lg:p-14
// // //           ${menuOpen ? "lg:ml-60" : "ml-0 lg:ml-[65px]"}
// // //         `}
// // //       >
// // //         {/* Replace or uncomment below as needed */}
// // //         {/* <img src="/homepageimage.png" alt="home page" /> */}
// // //         {/* <Dashboard /> */}
// // //       </div>
// // //     </div>
// // //   );
// // // }

// // // export default Home ;


// // import React, { useState } from "react";
// // import Header from "../../Components/Header";
// // import SubNavbar from "../../Components/SubNavbar";
// // // import Menubar from "../../Components/SubNavbar";

// // function Home() {
// //   const [menuOpen, setMenuOpen] = useState(false);

// //   return (
// //     <div className="bg-black/15 min-h-screen flex flex-col">
// //       {/* Header */}
// //       <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
// // <SubNavbar/>
// //       {/* Main Content */}
// //       <div
// //         className={`transition-all duration-300 mt-16 
// //           ${menuOpen ? "lg:ml-60" : "ml-0 "}`}
// //       >
// //         {/* Hero Banner */}
// //         <div className="relative w-full h-screen overflow-hidden mt-[-65px]">
// //           <img
// //             src="/icons/Login/volvologin 11.png"
// //             alt="Construction Site"
// //             className="w-full h-full object-cover"
// //           />
// // <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col justify-start pt-[130px] items-start text-left pl-4 sm:pl-10 md:pl-16">
// //   <h1 className="text-white text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-7xl font-medium mb-3 font-VolvoNovum">
// //     Construction Operation Center
// //   </h1>
// //   <p className="text-white text-sm sm:text-base md:text-sm font-medium mt-[-10px]">
// //     Real-time monitoring and project management dashboard
// //   </p>
// // </div>

// //         </div>
// //       </div>
// //     </div>
// //   );
// // }

// // export default Home;

// // import { useEffect, useState } from "react";
// // import Header from "../../Components/Header";
// // import SubNavbar from "../../Components/SubNavbar";

// // function Home() {
// //   const [menuOpen, setMenuOpen] = useState(false);
// //   const [currentSlide, setCurrentSlide] = useState(0);

// //   const images = [
// //     "/icons/Login/volvologin 11.png",
// //     "/icons/Homepage1/HAOMEPAGEAIMGAE2.png", // replace with actual path
// //     "/icons/Homepage1/Homepage iamge3.png", // replace with actual path
// //   ];

// //   useEffect(() => {
// //     const interval = setInterval(() => {
// //       setCurrentSlide((prev) => (prev + 1) % images.length);
// //     }, 5000); // Change every 5 seconds

// //     return () => clearInterval(interval);
// //   }, [images.length]); // ✅ Correct dependency

// //   return (
// //     <div className="bg-black/15 min-h-screen flex flex-col">
// //       <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
// //       <SubNavbar />

// //       <div className={`transition-all duration-300 mt-16 ${menuOpen ? "lg:ml-60" : "ml-0"}`}>
// //         {/* Hero Banner with Slider */}
// //         <div className="relative w-full h-screen overflow-hidden mt-[-65px]">
// //           {images.map((img, index) => (
// //             <img
// //               key={index}
// //               src={img}
// //               alt={`Slide ${index + 1}`}
// //               className={`absolute top-0 left-0 w-full h-full object-cover transition-opacity duration-1000 ${
// //                 index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
// //               }`}
// //             />
// //           ))}

// //           {/* Overlay with heading and subtext */}
// //           {/* <div className="absolute inset-0 bg-black bg-opacity-10 flex flex-col justify-start pt-[130px] items-start text-left pl-4 sm:pl-10 md:pl-16 z-20"> */}
// //           <div className="absolute inset-0 bg-black bg-opacity-10 flex flex-col justify-center items-center text-center z-20 mt-[-120px]">

// //             <h1 className="text-white text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-7xl font-medium mb-3 font-VolvoNovum">
// //               Construction Operation Center
// //             </h1>
// //             <p className="text-white text-sm sm:text-base md:text-sm font-medium mt-[-10px]">
// //               Real-time monitoring and project management dashboard
// //             </p>
// //           </div>

// //           {/* Dot Indicators */}
// //           <div className="absolute bottom-6 w-full flex justify-center gap-2 z-30">
// //            <div className="absolute bottom-6 w-full flex justify-center gap-2 z-30">
// //   {images.map((_, index) => (
// //     <div
// //       key={index}
// //       className={` rounded-full transition-all duration-300 ${
// //         currentSlide === index
// //           ? "bg-white scale-110 w-2.5 h-2.5"
// //           : "bg-white/50 w-2 h-2 "
// //       }`}
// //     />
// //   ))}
// // </div>

// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // }

// // export default Home;


// import { useEffect, useState } from "react";
// import Header from "../../Components/Header";
// import SubNavbar from "../../Components/SubNavbar";
// // import SubNavbar2 from "../../Components/SubNavbar2";

// function Home() {
//   const [menuOpen, setMenuOpen] = useState(false);
//   const [currentSlide, setCurrentSlide] = useState(0);

//   const images = [
//     "/icons/Login/volvologin 11.png",
//     "/icons/Homepage1/HAOMEPAGEAIMGAE2.png",
//     "/icons/Homepage1/Homepage iamge3.png",
//   ];

//   useEffect(() => {
//     const interval = setInterval(() => {
//       setCurrentSlide((prev) => (prev + 1) % images.length);
//     }, 3000);
//     return () => clearInterval(interval);
//   }, [images.length]);

//   return (
//     <div className="bg-black/15 min-h-screen flex flex-col">
//       <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
//       {/* <SubNavbar /> */}
// <SubNavbar/>
//       <div
//         className={`transition-all duration-300 mt-16 ${
//           menuOpen ? "lg:ml-60" : "ml-0"
//         }`}
//       >
//         {/* Hero Slider */}
//         <div className="relative w-full h-screen overflow-hidden mt-[-65px]">
//           {images.map((img, index) => (
//             <img
//               key={index}
//               src={img}
//               alt={`Slide ${index + 1}`}
//               className={`absolute top-0 left-0 w-full h-full object-cover transition-opacity duration-1000 ${
//                 index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
//               }`}
//             />
//           ))}

//           {/* Text Overlay */}
//           <div className="absolute inset-0 bg-black bg-opacity-10 flex flex-col items-center justify-start pt-32 md:pt-48 lg:pt-56 xl:pt-60 text-center z-20 px-4">
//             <h1 className="text-white text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-9xl font-semibold mb-3 font-VolvoNovum leading-tight">
//               Construction Operation Center
//             </h1>
//             <p className="text-white text-sm sm:text-lg md:text-xl font-medium">
//               Real-time monitoring and project management dashboard
//             </p>
//           </div>

//           {/* Dot Indicators */}
//           <div className="absolute bottom-6 w-full flex justify-center gap-2 z-30">
//             {images.map((_, index) => (
//               <div
//                 key={index}
//                 className={`rounded-full transition-all duration-300 ${
//                   currentSlide === index
//                     ? "bg-white scale-110 w-2.5 h-2.5"
//                     : "bg-white/50 w-2 h-2"
//                 }`}
//               />
//             ))}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Home;
