import React from "react";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  Legend,
} from "recharts";
import Header from "../../Components/Header";
import SubNavbar3 from "../../Components/SubNavbar3";
import { useState } from "react";
import { useEffect } from "react";
// Dummy Data
const departmentData = [
  { name: "Finance", value: 90 },
  { name: "HR", value: 75 },
  { name: "Marketing", value: 65 },
  { name: "Operations", value: 60 },
  { name: "IT", value: 45 },
  { name: "Sales", value: 55 },
];

const creationTrendData = [
  { month: "Jan", count: 5 },
  { month: "Feb", count: 15 },
  { month: "Mar", count: 25 },
  { month: "Apr", count: 30 },
  { month: "May", count: 35 },
  { month: "Jun", count: 38 },
];

const resourceData = [    
  { name: "Sales", value: 25 },
  { name: "Spares", value: 30 },
  { name: "Service", value: 10 },
  { name: "Marketing", value: 40 },
  { name: "HR-Admin", value: 7 },
  { name: "Finance", value: 5 },
 { name: "Competence", value: 10 },
 { name: "Total Manpower", value: 10 },



];

const COLORS = ["#396976", "#476896", "#50A294", "#C0A790", "#52796F","#89B0AE","#89C2D9","#003049"];

const currentpdpaction = [
  ["Financial Report Q2", "Finance", "Open", 85],
  ["Sales Presentation", "Presentation", "Ongoing", 65],
  ["Project Timeline", "Operations", "Closed", 100],
  ["Equipment Tracking", "Equipment", "Open", 45],
  ["Marketing Campaign", "Marketing", "Ongoing", 70],
];



const PdpOutlook = () => {
     const [menuOpen, setMenuOpen] = useState(false)
   
  
    const [isSmallScreen, setIsSmallScreen] = useState(false);
  
    useEffect(() => {
      const checkScreen = () => setIsSmallScreen(window.innerWidth < 640);
      checkScreen();
      window.addEventListener("resize", checkScreen);
      return () => window.removeEventListener("resize", checkScreen);
    }, []);
  return (
     
      
 <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
    
    <div className={`transition-all duration-300  ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full transition-all duration-300 ease-in-out px-4 lg:px-4">
         
<h2 className="text-center text-xl font-semibold text-darkblue1 font-VolvoNovum mb-2">
        Partnership Development Program(PDP)
      </h2>
{/* Stats Cards */}
    <div className="grid grid-cols-1 md:grid-cols-5 gap-6  place-items-center mb-4">
  {[
    {
      title: "Business Performance",
      value: "126",
      note: "+12% from last month",
    },
    {
      title: "Financials",
      value: "38",
      note: "+5% from last month",
    },
    {
      title: "Infrastructure",
      value: "84%",
      note: "-2% from last month",
    },
    {
      title: "Manpower",
      value: "92%",
      note: "+3% from last month",
    },
    {
      title: "Organization",
      value: "92",
      note: "+12% from last month",
    },
  ].map((item, idx) => {
    
    const isPositive = item.note.trim().startsWith("+");
     const noteColor = isPositive ? "text-lightgreen" : "text-red1";
    const barColor = isPositive ? "bg-mildBlue" :  "bg-red";
    const percent = parseInt(item.value);
   

    return (
      <div
        key={idx}         
       className={`bg-white  shadow-[0_4px_10px_#4E78A140] p-4 border w-full h-30 md:h-40 lg:h-40 flex flex-col justify-between 
  transform transition duration-300 ease-in-out hover:-translate-y-2 hover:shadow-[0_6px_16px_#4E78A140]`}>
        <div>
          <p className="text-sm font-medium text-VolvoNovum text-black mb-2">
            {item.title}
          </p>
          <h2 className="text-base font-bold text-darkblue1">{item.value}</h2>
          <p className={`text-xs  ${noteColor}`}>{item.note}</p>
        </div>

        {/* Progress bar for last two cards */}
        {idx >= 2 && (
          <div className="w-full h-2 bg-gray-200 rounded-full mb-4">
            <div
              className={`h-full rounded-full ${barColor}`}
              style={{ width: `${percent}%` }}
            ></div>
          </div>
        )}
      </div>
    );
  })}
</div>


<div className="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
  <div className="bg-white  shadow-[0_4px_10px_#4E78A140] p-6 md:p-4  flex flex-col h-full">
    {/* Heading */}
    <h3 className="text-sm font-semibold text-mildBlue mb-4 text-left">
      Usage By Department
    </h3>

    {/* Chart Container */}
    <div className="flex-1 w-full ml-[-15%] md:ml-0 lg:ml-0 ">
      <ResponsiveContainer width="100%" height={isSmallScreen ? 180 : 270}>
        <BarChart data={departmentData}>
          <XAxis
            dataKey="name"
            tickLine={false}
            axisLine={{ stroke: "rgba(0, 0, 0, 0.7)", strokeWidth: 1.5 }}
            tick={{
        fill: "black",
        fontSize: isSmallScreen ? 8 : window.innerWidth < 1024 ? 10 : 14, // medium screens font
        angle: window.innerWidth < 1024 ? -30 : 0, // small & medium screens tilted
        dx: window.innerWidth < 1024 ? -5 : 0,
        dy: window.innerWidth < 1024 ? 10 : 0,
        // textAnchor: window.innerWidth < 1024 ? "end" : "middle",
      }}
            interval={0} // show all labels
          />
          <YAxis
            tickLine={false}
            axisLine={{ stroke: "rgba(0, 0, 0, 0.7)", strokeWidth: 1.5 }}
            tick={{ fill: "black", fontSize: isSmallScreen ? 8 : 14 }}
          />
          <Bar
            dataKey="value"
            fill="#476896"
            radius={[10, 10, 0, 0]}
            barSize={isSmallScreen ? 20 : 30} // responsive bar width
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  </div>



<div className="bg-white shadow-[0_4px_10px_#4E78A140] p-4 md:p-6 flex flex-col h-full">
  {/* Heading */}
  <h3 className="text-sm   font-semibold text-mildBlue mb-4 text-left">
    Creation Trend
  </h3>

  {/* Chart Container */}
    <div className="flex-1 w-full ml-[-15%] md:ml-[-4%] lg:ml-[] ">
    <ResponsiveContainer width="100%" height={isSmallScreen ? 180 : 280}>
      <LineChart data={creationTrendData} margin={{ top: 10, right: 20, left: 20, bottom: 10 }}>
        {/* Horizontal grid lines */}
        <CartesianGrid
          strokeDasharray="3 3"
          vertical={false}
          stroke="rgba(0, 0, 0, 0.3)"
        />

        <XAxis
          dataKey="month"
          tickLine={false}
          axisLine={{ stroke: "rgba(0, 0, 0, 0.7)", strokeWidth: 1.5 }}
          tick={{
            fill: "black",
            fontSize: isSmallScreen ? 10 : 14,
          }}
        />

        <YAxis
          tickLine={false}
          axisLine={{ stroke: "rgba(0, 0, 0, 0.7)", strokeWidth: 1.5 }}
          tick={{ fill: "black", fontSize: isSmallScreen ? 10 : 14 }}
          ticks={[10, 20, 30, 40]}
        />

        <Line
          type="monotone"
          dataKey="count"
          stroke="#50A294"
          strokeWidth={2}
          dot={{ r: isSmallScreen ? 2 : 4, fill: "#50A294" }}
        />
      </LineChart>
    </ResponsiveContainer>
  </div>
</div>
</div>

      {/* Pie Chart and Table */}
      <div className="grid grid-cols-1  md:grid-cols-1 lg:grid-cols-2 gap-4 lg:mb-2">
 <div className="bg-white shadow-[0_4px_10px_#4E78A140] p-4  mb-[7%] lg:h-full">
  {/* Heading */}
  <h3 className="text-sm  font-semibold text-mildBlue mb-4 text-left">
    Resource Allocation Simulation
  </h3>

  {/* Chart + Labels Container */}
  <div className="flex flex-col mt-[-20%] md:mt-[2%] md:flex-row items-center">
    {/* Pie Chart */}
    <div className="w-full md:w-2/3 h-64  mb-[-20%] md:mb-[2%]">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={resourceData}
            cx="50%"
            cy="50%"
            innerRadius={window.innerWidth < 640 ? 30 : window.innerWidth < 1024 ? 50 : 70}
            outerRadius={window.innerWidth < 640 ? 50 : window.innerWidth < 1024 ? 80 : 100}
            paddingAngle={1}
            dataKey="value"
          >
            {resourceData.map((_, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
    </div>

    {/* Labels */}
    <div className="w-full md:w-1/3 mt-4 md:mt-0 md:ml-4">
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-1 gap-2">
        {resourceData.map((entry, index) => (
          <div key={index} className="flex items-center space-x-2">
            <div
              className="w-4 h-4 "
              style={{ backgroundColor: COLORS[index % COLORS.length] }}
            ></div>
            <span className="text-xs">{entry.name}</span>
          </div>
        ))}
      </div>
    </div>
  </div>
</div>

<div className="bg-white shadow-[0_4px_10px_#4E78A140] p-4 mt-[-8%] md:mt-[-6%] lg:mt-0 lg:h-full">
  <h3 className="text-sm font-semibold mb-2 text-mildBlue">Current PDP Actions</h3>

  {/* For medium & large screens: table */}
  <div className="hidden md:block overflow-x-auto">
    <div className="w-full max-w-3xl">
      <table className="w-full table-auto text-sm text-left border-separate border-spacing-y-1">
        <thead className="bg-mildblue2">
          <tr>
            <th className="px-6 py-2 text-mildBlue ">Name</th>
            <th className="px-6 py-2 text-mildBlue">Type</th>
            <th className="px-6 py-2 text-mildBlue">Status</th>
            <th className="px-6 py-2 text-mildBlue ">Progress</th>
          </tr>
        </thead>
        <tbody>
        {currentpdpaction.map(([name, type, status,percent], i) => (
          <tr key={name + i} className="border border-gray-200 ">
             <td
  className={`px-6 py-3  ${
    i % 2 === 0
      ? 'bg-white border-t-2 border-b-2 border-l-2 border-lightBlue'
      : 'bg-lightGrey/60 '
  }`}
>
              {name}</td>
              <td
  className={`px-6 py-3  ${
   i % 2 === 0
      ? 'bg-white border-t-2 border-b-2  border-lightBlue'
      : 'bg-lightGrey/60 '
  }`}
>
          {type}
          </td>
         <td
  className={`px-6 py-3  ${
    i % 2 === 0
      ? "bg-white border-t-2 border-b-2  border-lightBlue"
      : "bg-lightGrey/60 "
  } ${
    status === "Open"
      ? "text-green"
      : status === "Ongoing"
      ? "text-SteelBlue1" // SteelBlue1
      : status === "Closed"
      ? "text-darkblue1" // DarkBlue1
      : ""
  } font-medium`}
>
  {status}
</td>

               <td
      className={`px-6 py-3 ${
        i % 2 === 0
          ? "bg-white border-t-2 border-b-2 border-r-2 border-lightBlue "
          : "bg-lightGrey/60"
      }`}
    >
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className={`h-full rounded-full ${
            status === "Open"
              ? "bg-green"
              : status === "Ongoing"
              ? "bg-blue"
              : "bg-blue"
          }`}
          style={{ width: `${Math.min(percent, 100)}%` }}
        ></div>
      </div>
    </td>     </tr>
        ))}
        </tbody>
      </table>
    </div>
  </div>

  {/* Small screens: cards */}
  <div className="md:hidden space-y-4">
    {currentpdpaction.map(([name, type, status, percent], i) => (
      <div key={name + i} className="bg-white shadow-md  p-4 border border-gray-200">
        <div className="flex justify-between mb-2">
          <span className="font-semibold text-sm text-mildBlue">Name:</span>
          <span className="text-xs">{name}</span>
        </div>
        <div className="flex justify-between mb-2">
          <span className="font-semibold text-sm text-mildBlue">Type:</span>
          <span className="text-xs">{type}</span>
        </div>
        <div className="flex justify-between mb-2">
          <span className="font-semibold text-sm text-mildBlue">Status:</span>
          <span className={`text-sm font-medium ${
            status === "Open" ? "text-green" : status === "Ongoing" ? "text-SteelBlue1" : "text-darkblue1"
          }`}>{status}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="font-semibold text-sm text-mildBlue">Progress:</span>
          <div className="w-2/3 bg-gray-200 rounded-full h-2">
            <div
              className={`h-full rounded-full ${status === "Open" ? "bg-green" : status === "Ongoing" ? "bg-blue" : "bg-blue"}`}
              style={{ width: `${Math.min(percent, 100)}%` }}
            ></div>
          </div>

        </div>
      </div>
    ))}
  </div>
</div>

</div>
  {/* <div className="mt-6 sm:mt-8 md:mt-10 flex justify-end">
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="bg-grey text-white px-3 py-2 sm:px-4 sm:py-2 rounded-lg shadow-lg hover:bg-blue-700 transition duration-200"
        >
          ^
        </button>
      </div> */}
      </div>
    </div>
    </div>
    </div>
  );
};

export default PdpOutlook
;
