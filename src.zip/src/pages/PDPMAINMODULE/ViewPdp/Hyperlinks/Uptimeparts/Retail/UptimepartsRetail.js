import React, { useState, useMemo, useEffect,useRef } from "react";
import Header from "../../../../../../Components/Header";
import SubNavbar3 from "../../../../../../Components/SubNavbar3";
import { ArrowLeft, Lock,ChevronDown,ChevronsUpDown,ChevronUp,ArrowUp,ArrowDown } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import Searchinput from "../../../../../../Components/Searchinput";
import { canEditData, isEditableStatus, isDealerRole } from "../../../../../../pages/constants/roles";
import { 
  getPdpUptimePartsByPdpId,
  updateMultiplePdpUptimeParts 
} from "../../../../../../services/PDP/UptimepartsHyperlink/pdphyperUptimeparts.service";

const UptimepartsRetail = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [editableData, setEditableData] = useState([]);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedRow, setExpandedRow] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();
  const tableContainerRef = useRef(null);
  // ⭐ Parameter extraction (includes pdpStatus)
  const navigationState = React.useMemo(() => {
    const state = location.state || {};
    
    const pdpIdValue = state.pdpId || state.rowData?.id || null;
    const year = state.selectedYear || 
                 state.year ||
                 state.rowData?.year || 
                 new Date().getFullYear();
    const category = state.category || "Uptime and Parts";
    const view = state.viewType || "retail";
    const role = state.userRole;
    // ⭐ NEW: Extract PDP status from rowData
    const pdpStatus = state.rowData?.signOffStatus || state.rowData?.sign_of_status || state.pdpStatus || "Created";
    
    console.log("📍 UptimepartsRetail Component - Extracted Parameters:");
    console.log("  PDP ID:", pdpIdValue);
    console.log("  Year:", year);
    console.log("  Category:", category);
    console.log("  View Type:", view);
    console.log("  Role:", role);
    console.log("  PDP Status:", pdpStatus);
    
    return {
      pdpId: pdpIdValue,
      year: parseInt(year),
      category: category,
      viewType: view,
      userRole: role,
      pdpStatus: pdpStatus,
      rowData: state.rowData || { id: pdpIdValue, year: parseInt(year), signOffStatus: pdpStatus }
    };
  }, [location.state, location.pathname]);
  
  const pdpId = navigationState.pdpId;
  const selectedYear = navigationState.year;
  const category = navigationState.category;
  const viewType = navigationState.viewType;
  const userRole = navigationState.userRole;
  const pdpStatus = navigationState.pdpStatus;
  const rowData = navigationState.rowData;
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

 // ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};
  // ⭐ FIXED: Check if user can edit (considers both role AND status)
  const canEdit = canEditData(userRole, pdpStatus);
  
  // ⭐ NEW: Check if user is a dealer but editing is locked due to status
  const isStatusLocked = isDealerRole(userRole) && !isEditableStatus(pdpStatus);

  // Validate required parameters
  useEffect(() => {
    if (!pdpId) {
      console.error("❌ Missing PDP ID!");
      alert("PDP ID is required. Redirecting back...");
      handleBack();
    }
  }, [pdpId]);

  // ⭐ Calculate Achievement percentage
  const calculateAchievement = (eoy, targetLS) => {
    const eoyNum = parseFloat(eoy) || 0;
    const targetNum = parseFloat(targetLS) || 0;
    
    if (targetNum === 0) return "0%";
    
    const achievement = (eoyNum / targetNum) * 100;
    return `${achievement.toFixed(2)}%`;
  };

  // ⭐ Transform API data into table structure - NO YEAR FILTERING
  const transformDataToTableFormat = (apiData) => {
    if (!apiData || apiData.length === 0) {
      console.log("⚠️ No API data to transform");
      return [];
    }

    console.log("🔄 Transforming API data to table format:", apiData.length, "items");
    console.log("⭐ SHOWING ALL DATA - NO YEAR FILTERING");

    // Group by year first, then by category
    const groupedByYear = apiData.reduce((acc, item) => {
      const itemYear = parseInt(item.year) || selectedYear;
      if (!acc[itemYear]) {
        acc[itemYear] = {};
      }
      
      const cat = item.uptime_parts_category || "Others";
      if (!acc[itemYear][cat]) {
        acc[itemYear][cat] = [];
      }
      acc[itemYear][cat].push(item);
      return acc;
    }, {});

    // Create table sections for each year and category
    const tableData = [];
    
    Object.keys(groupedByYear).sort((a, b) => b - a).forEach(year => {
      const categoriesForYear = groupedByYear[year];
      
      Object.keys(categoriesForYear).forEach(categoryName => {
        const items = categoriesForYear[categoryName];
        
        const rows = items.map(item => {
          const targetLS = item.py_target || 0;
          const eoy = item.py_eoy || 0;
          
          // ⭐ Calculate achievement based on EOY and Target LS
          const calculatedAchievement = calculateAchievement(eoy, targetLS);
          
          return {
            id: item.id,
            make: item.equipment_make || "Unknown",
            details: item.details || "",
            measure: item.measurement_units || "Units",
            targetLS: targetLS,
            ytd: item.py_ytd || 0,
            eoy: eoy,
            ach: calculatedAchievement,
            targetCY: item.target || 0,
            remarks: item.remarks || "",
            isEditable: true // ⭐ FIXED: Remove isAdmin check here, use canEdit instead
          };
        });

        tableData.push({
          year: parseInt(year),
          category: categoryName,
          rows: rows
        });
      });
    });

    console.log("✅ Transformed table data:", tableData.length, "sections");
    console.log("📊 Years included:", [...new Set(tableData.map(t => t.year))]);
    return tableData;
  };

  // ⭐ Fetch ALL data on mount - NO YEAR FILTERING
  useEffect(() => {
    const loadData = async () => {
      if (!pdpId) {
        console.error("❌ PDP ID is missing, cannot fetch data");
        setError("PDP ID is required");
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);

        console.log("🔄 Fetching ALL uptime parts data (no year filter)...");
        console.log("  PDP ID:", pdpId);
        console.log("  View Type:", viewType);
        
        // Fetch ALL data from API with only category filter
        const filters = {
          category: viewType === "retail" ? "Retails" : "Key Account"
        };
        
        const allData = await getPdpUptimePartsByPdpId(pdpId, filters);
        console.log("📦 ALL Uptime data fetched:", allData.length, "records");
        
        if (allData.length > 0) {
          console.log("📅 Years in data:", [...new Set(allData.map(item => item.year))]);
        }
        
        // ⭐ Transform ALL data without year filtering
        const transformedData = transformDataToTableFormat(allData);
        
        if (transformedData && transformedData.length > 0) {
          setEditableData(transformedData);
          console.log("✅ Displaying ALL data:", transformedData.length, "sections");
        } else {
          setEditableData([]);
          console.log("⚠️ No data available");
        }

      } catch (error) {
        console.error("❌ Error loading data:", error);
        setError("Failed to load data: " + error.message);
        setEditableData([]);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [pdpId, viewType]);

  // Data to display
  const tableData = editableData;

  // ✅ Search filter
  const filteredData = useMemo(() => {
    if (!searchTerm.trim()) return tableData;
    
    return tableData
      .map((section) => {
        const filteredRows = section.rows.filter((row) =>
          Object.values({ ...row, year: section.year, category: section.category })
            .join(" ")
            .toLowerCase()
            .includes(searchTerm.toLowerCase())
        );
        return filteredRows.length > 0 ? { ...section, rows: filteredRows } : null;
      })
      .filter(Boolean);
  }, [searchTerm, tableData]);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [filteredData, sortKey, sortOrder]);




  // ⭐ Handle field changes for user edits with achievement recalculation
  const handleFieldChange = (sectionIdx, rowIdx, field, value) => {
    // ⭐ FIXED: Use canEdit instead of isAdmin check
    if (!canEdit) {
      console.warn("⚠️ Editing is disabled for this PDP status:", pdpStatus);
      return;
    }
    
    console.log("📝 Field change:", { sectionIdx, rowIdx, field, value });
    
    setEditableData(prevData => {
      const newData = JSON.parse(JSON.stringify(prevData));
      newData[sectionIdx].rows[rowIdx][field] = value;
      
      // ⭐ Recalculate achievement when EOY or Target LS changes
      const row = newData[sectionIdx].rows[rowIdx];
      if (field === 'eoy' || field === 'targetLS') {
        row.ach = calculateAchievement(row.eoy, row.targetLS);
        console.log("🔄 Recalculated achievement:", row.ach);
      }
      
      return newData;
    });
  };

  // ⭐ Save functionality
  const handleSave = async () => {
    if (!pdpId) {
      alert("❌ PDP ID is missing. Cannot save data.");
      return;
    }

    // ⭐ NEW: Double-check edit permission before saving
    if (!canEdit) {
      alert(`❌ Cannot save. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      return;
    }

    try {
      setIsSaving(true);
      
      const rows = [];
      
      editableData.forEach(section => {
        section.rows.forEach(row => {
          if (row.id) {
            // ⭐ Remove percentage sign from achievement before saving
            const achievementValue = row.ach.replace('%', '').trim();
            
            rows.push({
              id: row.id,
              py_ytd: parseFloat(row.ytd) || 0,
              py_eoy: parseFloat(row.eoy) || 0,
              py_achievement: achievementValue,
              target: parseFloat(row.targetCY) || 0,
              remarks: row.remarks || null
            });
          }
        });
      });

      console.log("💾 Saving uptime parts data:");
      console.log("  PDP ID:", pdpId);
      console.log("  Rows count:", rows.length);
      console.log("  Sample row:", rows[0]);

      await updateMultiplePdpUptimeParts(rows);
      
      alert("✅ Data saved successfully!");
      
      // Refetch all data
      try {
        const filters = {
          category: viewType === "retail" ? "Retails" : "Key Account"
        };
        const updatedData = await getPdpUptimePartsByPdpId(pdpId, filters);
        const newData = transformDataToTableFormat(updatedData);
        if (newData) {
          setEditableData(newData);
        }
      } catch (refreshError) {
        console.warn("⚠️ Could not refresh data after save:", refreshError);
      }
      
    } catch (error) {
      console.error("❌ Error saving data:", error);
      alert(`❌ Failed to save data: ${error.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Back navigation
  const handleBack = () => {
    const backPath = "/pdp/viewdetails";
    
    navigate(backPath, { 
      state: { 
        activeTab: "Uptime & Parts",
        rowData: rowData,
        selectedYear: selectedYear
      }
    });
  };

  // ⭐ NEW: Get status badge color
  const getStatusBadgeColor = (status) => {
    switch (status) {
      case "Completed": return "bg-green-100 text-green-800 border-green-300";
      case "Approved": return "bg-blue-100 text-blue-800 border-blue-300";
      case "Pending Review": return "bg-orange-100 text-orange-800 border-orange-300";
      case "Started": return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "Created": return "bg-gray-100 text-gray-800 border-gray-300";
      default: return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="bg-Frostwhite min-h-screen flex flex-col">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        <SubNavbar3 />
        <div className="flex items-center justify-center py-20 mt-[19%] md:mt-[7%] lg:mt-[11%]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-darkblue1 mx-auto mb-4"></div>
            <p className="text-gray-600 font-medium text-lg">Loading all uptime parts data...</p>
            <p className="text-gray-500 text-sm mt-2">PDP ID: {pdpId}</p>
            <p className="text-gray-500 text-sm">Category: {viewType === "retail" ? "Retail" : "Key Account"}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 flex items-center justify-between">
            <span>{error}</span>
            <button
              onClick={() => setError(null)}
              className="ml-2 text-red-500 hover:text-red-700 text-xl font-bold"
            >
              ×
            </button>
          </div>
        )}

        {/* Top bar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={24}
              className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
            />
            <h1 className="text-base font-medium text-darkblue1">
              PDP ({selectedYear}) - ACT - {category} - {viewType === "retail" ? "Retail" : "Key Account"}
            </h1>
          </div>

          {/* ⭐ UPDATED: Status Badge with dynamic color */}
          <div className={`shadow-[0_4px_10px_#0000001A] px-3 py-1 flex items-center justify-center gap-2 w-full sm:w-auto border ${getStatusBadgeColor(pdpStatus)}`}>
            {isStatusLocked && <Lock size={14} />}
            <span className="w-2 h-2 bg-current rounded-full inline-block opacity-60"></span>
            <span className="text-xs font-medium">{pdpStatus}</span>
          </div>
        </div>
        
        <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-[2.7%] mb-2"></div>

        {/* ⭐ NEW: Status Lock Banner - Shows when dealer cannot edit due to status */}
        {/* {isStatusLocked && (
          <div className="bg-amber-50 border border-amber-300 rounded-lg p-3 mb-4 flex items-start gap-3">
            <div className="flex-shrink-0 mt-0.5">
              <Lock size={20} className="text-amber-600" />
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-amber-800 mb-1">
                Editing Disabled
              </h4>
              <p className="text-xs text-amber-700">
                This PDP is in <span className="font-bold">{pdpStatus}</span> status. 
                Data can only be edited when status is <span className="font-semibold">"Created"</span> or <span className="font-semibold">"Started"</span>.
              </p>
              <p className="text-xs text-amber-600 mt-1">
                {pdpStatus === "Pending Review" && "The PDP is awaiting admin approval."}
                {pdpStatus === "Approved" && "The PDP has been approved and is now read-only."}
                {pdpStatus === "Completed" && "The PDP has been completed and finalized."}
              </p>
            </div>
          </div>
        )} */}

        {/* Search Section with Save Button */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-2">
          <div className="">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="w-[1/2]"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              focusRing="focus:ring-black/60"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-1.5"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              iconColor="text-black"
            />
          </div>

          {/* ⭐ FIXED: Only show Save button when canEdit is true */}
          {canEdit && filteredData.length > 0 && (
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="flex items-center justify-center gap-2 bg-darkblue1 text-white px-4 py-1.5 hover:bg-darkblue1/90 transition disabled:opacity-50 disabled:cursor-not-allowed text-xs font-medium shadow-md whitespace-nowrap"
            >
              {isSaving ? "Saving..." : "Save"}
            </button>
          )}
        </div>

        {/* Desktop Table */}
          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer ">
          <div
            ref={tableContainerRef}
className="overflow-y-auto overflow-x-hidden scrollbar-hide"            style={{
               maxHeight: filteredData.length > 8 ? "calc(100vh - 200px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >
            <table className="w-full text-xs table-fixed border-collapse">
              <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
              <tr>
               <th
  rowSpan="2"
  className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[5%] text-left cursor-pointer select-none"
  onClick={() => handleSort("year")}
>
  <div className="flex items-center gap-1">
    Year
    {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

    {sortKey === "year" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3 text-white" />
    )}
    {sortKey === "year" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3 text-white" />
    )}
  </div>
</th>

<th
  rowSpan="2"
  className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[10%] text-left cursor-pointer select-none"
  onClick={() => handleSort("category")}
>
  <div className="flex items-center gap-1">
    Category
    {sortKey === "category" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3 text-white" />
    )}
    {sortKey === "category" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3 text-white" />
    )}
  </div>
</th>
                <th rowSpan="2" className="bg-Dustyblue font-normal text-white px-3 py-1.5 w-[7%] text-xs border border-grey2 border-t-0 border-l-0 text-left">
                  Equipment Make
                </th>
                <th rowSpan="2" className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs w-[10%] border border-grey2 border-t-0 border-l-0 text-left">
                  Details
                </th>
                <th rowSpan="2" className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs border w-[8%] border-grey2 border-t-0 border-l-0 text-center">
                  Measurements
                </th>
                <th colSpan="4" className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs border border-grey2 w-[30%] border-t-0 border-l-0 text-center">
                {selectedYear ? selectedYear - 1 : "Year"} 
                </th>
                <th colSpan="1" className="bg-Dustyblue font-normal   text-white px-3 py-1.5 text-xs border border-grey2 w-[8%] border-t-0 border-l-0 text-center">
                  {selectedYear ? selectedYear : "Current Year"}
                </th>
                <th rowSpan="2" className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[12%] border-r-0 text-left">
                  Remarks
                </th>
              </tr>
              <tr>
                <th className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-center">
                  Target
                </th>
                <th className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-center">
                  YTD
                </th>
                <th className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-center">
                  EOY
                </th>
                <th className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-center">
                  Achievement
                </th>
                <th className="bg-Dustyblue font-normal text-white px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-center">
                  Target
                </th>
              </tr>
            </thead>

            <tbody>
              {sortedData.length === 0 ? (
                <tr>
                  <td colSpan="11" className="text-center py-4 text-gray-500 italic">
                    {searchTerm ? "No matching data found." : "No data available."}
                  </td>
                </tr>
              ) : (
                sortedData.map((section, sectionIdx) =>
                  section.rows.map((row, rowIdx) => (
                    <tr 
                      key={`${sectionIdx}-${rowIdx}`} 
                      className="border border-grey2 border-t-0 border-l-0 text-xs font-normal hover:bg-lightBlue/30"
                    >
                      {rowIdx === 0 && (
                        <>
                          <td 
                            rowSpan={section.rows.length} 
                            className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-left"
                          >
                            {section.year}
                          </td>
                      <td
  rowSpan={section.rows.length}
  className="border border-grey2 border-t-0 border-l-0 px-3 py-1 max-w-[150px]"
>
  <div className="relative w-full">
    <span
      className="block truncate w-full cursor-pointer"
      onMouseEnter={() => {
        if (section.category && section.category.length > 15) {
          setHoveredCell(`section-${sectionIdx}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {section.category}
    </span>

    {hoveredCell === `section-${sectionIdx}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
        {section.category}
      </span>
    )}
  </div>
</td>                 </>
                      )}
                      
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{row.make}</td>
                      
                  <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 max-w-[200px]">
  <div className="relative w-full">
    <span
      className="block truncate w-full cursor-pointer"
      onMouseEnter={() => {
        if (row.details && row.details.length > 20) {
          setHoveredCell(`detail-${row.id}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.details || "-"}
    </span>

    {hoveredCell === `detail-${row.id}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
        {row.details}
      </span>
    )}
  </div>
</td>
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center">{row.measure}</td>
                      
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center">
                        {row.targetLS}
                      </td>
                      
                      {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center">
                        {canEdit && row.isEditable ? (
                        <input
  type="text"
  value={row.ytd || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleFieldChange(sectionIdx, rowIdx, "ytd", value);
    }
  }}
  className="w-full px-2 py-1 border border-gray-300 text-center focus:ring-1 focus:ring-darkblue1 focus:border-transparent outline-none bg-white"
/>
                        ) : (
                          row.ytd
                        )}
                      </td>
                      
                      {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center">
                        {canEdit && row.isEditable ? (
                         <input
  type="text"
  value={row.eoy || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleFieldChange(sectionIdx, rowIdx, "eoy", value);
    }
  }}
  className="w-full px-2 py-1 border border-gray-300 text-center focus:ring-1 focus:ring-darkblue1 focus:border-transparent outline-none bg-white"
/>
                        ) : (
                          row.eoy
                        )}
                      </td>
                      
                      {/* ⭐ Achievement - Auto-calculated, READ ONLY */}
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center font-semibold text-blue-600">
                        {row.ach}
                      </td>
                      
                      {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                      <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center">
  {canEdit && row.isEditable ? (
    <input
      type="text"
      value={row.targetCY || ""}
      placeholder="0"
      inputMode="decimal"
      onChange={(e) => {
        const value = e.target.value;
        if (/^\d*\.?\d*$/.test(value)) {
          handleFieldChange(sectionIdx, rowIdx, "targetCY", value);
        }
      }}
  className="w-full px-2 py-1 border border-gray-300 text-center focus:ring-1 focus:ring-darkblue1 focus:border-transparent outline-none bg-white"
    />
  ) : (
    row.targetCY || "-"
  )}
</td>
                      
                      {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                      <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1">
                        {canEdit ? (
                          <textarea
                            value={row.remarks}
                            onChange={(e) => handleFieldChange(sectionIdx, rowIdx, 'remarks', e.target.value)}
                            className="w-full px-2 py-1 border border-gray-300 focus:ring-1 focus:ring-darkblue1 focus:border-transparent outline-none bg-white resize-y"
                            placeholder="Enter remarks..."
                            rows={1}
                          />
                        ) : (
                          <div className="text-sm min-w-[200px]">
                            {row.remarks || "-"}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))
                )
              )}
            </tbody>
          </table>
        </div>
         {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

</div>
        {/* Mobile Card Layout */}
        <div className="lg:hidden space-y-4">
          {sortedData.length === 0 ? (
            <div className="text-center py-8 text-gray-500 italic bg-gray-50">
              {searchTerm ? "No matching data found." : "No data available."}
            </div>
          ) : (
            sortedData.map((section, sectionIdx) =>
              section.rows.map((row, rowIdx) => (
                <div
                  key={`${sectionIdx}-${rowIdx}`}
                  className="bg-white shadow-md p-4 border border-gray-200"
                >
                  <div className="space-y-3">
                    <div className="flex justify-between pb-2 border-b border-gray-200">
                      <span className="font-semibold text-sm text-darkblue1">Year:</span>
                      <span className="text-sm font-medium">{section.year}</span>
                    </div>
                    
                    <div className="flex justify-between pb-2 border-b border-gray-200">
                      <span className="font-semibold text-sm text-darkblue1">Category:</span>
                      <span className="text-sm font-medium">{section.category}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="font-semibold text-sm text-mildBlue">Equipment Make:</span>
                      <span className="text-sm">{row.make}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="font-semibold text-sm text-mildBlue">Details:</span>
                      <span className="text-sm text-gray-700">{row.details || "-"}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="font-semibold text-sm text-mildBlue">Measurements:</span>
                      <span className="text-sm">{row.measure}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="font-semibold text-sm text-mildBlue">Target (Previous Year):</span>
                      <span className="text-sm font-medium">{row.targetLS}</span>
                    </div>
                    
                    {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                    <div className="flex justify-between">
                      <span className="font-semibold text-sm text-mildBlue">YTD:</span>
                      {canEdit && row.isEditable ? (
                       <input
  type="text"
  value={row.ytd || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleFieldChange(sectionIdx, rowIdx, "ytd", value);
    }
  }}
  className="text-sm px-2 py-1 border border-gray-300 text-center focus:ring-2 focus:ring-darkblue1 w-24"
/>
                      ) : (
                        <span className="text-sm font-medium">{row.ytd}</span>
                      )}
                    </div>
                    
                    {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                    <div className="flex justify-between">
                      <span className="font-semibold text-sm text-mildBlue">EOY:</span>
                      {canEdit && row.isEditable ? (
                        <input
  type="text"
  value={row.eoy || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      handleFieldChange(sectionIdx, rowIdx, "eoy", value);
    }
  }}
  className="w-full px-2 py-1 border border-gray-300 text-center bg-white"
/>
                      ) : (
                        <span className="text-sm font-medium">{row.eoy}</span>
                      )}
                    </div>
                    
                    {/* ⭐ Achievement - Auto-calculated */}
                    <div className="flex justify-between">
                      <span className="font-semibold text-sm text-mildBlue">Achievement:</span>
                      <span className="text-sm font-semibold text-blue-600">{row.ach}</span>
                    </div>
                    
                    {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                    <div className="flex justify-between">
                      <span className="font-semibold text-sm text-mildBlue">Target (Current Year):</span>
                      {canEdit && row.isEditable ? (
                        <input
                          type="text"
                          value={row.targetCY}
                          onChange={(e) => handleFieldChange(sectionIdx, rowIdx, 'targetCY', e.target.value)}
                          className="text-sm px-2 py-1 border border-gray-300 focus:ring-2 focus:ring-darkblue1 w-24"
                        />
                      ) : (
                        <span className="text-sm font-medium">{row.targetCY}</span>
                      )}
                    </div>
                    
                    {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                    <div className="pt-2 border-t border-gray-200">
                      <span className="font-semibold text-sm text-mildBlue block mb-2">Remarks:</span>
                      {canEdit ? (
                        <textarea
                          value={row.remarks}
                          onChange={(e) => handleFieldChange(sectionIdx, rowIdx, 'remarks', e.target.value)}
                          className="w-full px-2 py-1 border border-gray-300 focus:ring-2 focus:ring-darkblue1 text-sm resize-y"
                          placeholder="Enter remarks..."
                          rows={2}
                        />
                      ) : (
                        <div className="text-sm text-gray-700">
                          {row.remarks || "-"}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default UptimepartsRetail;