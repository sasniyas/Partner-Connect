import { ArrowDown,ArrowLeft,ArrowUp,ChevronDown,ChevronUp,ChevronsUpDown,Lock,Save } from "lucide-react";
import React, { useState, useEffect, useMemo,useRef } from "react";
import Header from "../../../../../Components/Header";
import SubNavbar3 from "../../../../../Components/SubNavbar3";
import { useLocation, useNavigate } from "react-router-dom";
import SingleSelectFilter from "../../../../../Components/SingleSelelctFilter";
import Filter from "../../../../../Components/Filter";
import Searchinput from "../../../../../Components/Searchinput";
import { canEditData, isEditableStatus, isDealerRole } from "../../../../../pages/constants/roles";
import { 
  getPdpEquipmentsByPdpId, 
  updateMultiplePdpEquipments 
} from "../../../../../services/PDP/Equipmentshyperlink/pdphyperEquipments.service";

const Equipments = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"
 const [sortKey1, setSortKey1] = useState(null);
const [sortOrder1, setSortOrder1] = useState(null); // "asc" | "desc"
const [hoveredCell, setHoveredCell] = useState(null);
const tableContainerRef =useRef(null);
const [expandedCell, setExpandedCell] = useState(null);
const normalizeKey = (label) =>
  label
    .replace(/\s+/g, " ")
    .trim()
    .split(" ")
    .map((word, i) =>
      i === 0
        ? word.toLowerCase()
        : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    )
    .join("");
const toTitleCase = (text) => {
  return text
    ?.toLowerCase()
    .split(" ")
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") setSortOrder("desc");
    else {
      setSortKey(null);
      setSortOrder(null);
    }
    return;
  }
  setSortKey(key);
  setSortOrder("asc");
};

const handleSort1 = (key) => {
  if (sortKey1 === key) {
    if (sortOrder1 === "asc") setSortOrder1("desc");
    else {
      setSortKey1(null);
      setSortOrder1(null);
    }
    return;
  }
  setSortKey1(key);
  setSortOrder1("asc");
};
  // ⭐ FIXED: Robust parameter extraction with validation (includes pdpStatus)
  const navigationState = React.useMemo(() => {
    const state = location.state || {};
    
    const pdpIdValue = state.pdpId || state.rowData?.id || null;
    const year = state.selectedYear || state.rowData?.year || new Date().getFullYear();
    const equipType = state.equipmentType || "Equipment's";
    const view = state.viewType || "retail";
    const role = state.userRole;
    // ⭐ NEW: Extract PDP status from rowData
    const pdpStatus = state.rowData?.signOffStatus || state.rowData?.sign_of_status || state.pdpStatus || "Created";
    
    return {
      pdpId: pdpIdValue,
      year: parseInt(year),
      equipmentType: equipType,
      viewType: view,
      userRole: role,
      pdpStatus: pdpStatus,
      rowData: state.rowData || { id: pdpIdValue, year: parseInt(year), signOffStatus: pdpStatus }
    };
  }, [location.state, location.pathname]);
  
  const pdpId = navigationState.pdpId;
  const selectedYear = navigationState.year;
  const equipmentType = navigationState.equipmentType;
  const viewType = navigationState.viewType;
  const userRole = navigationState.userRole;
  const pdpStatus = navigationState.pdpStatus;
  const rowData = navigationState.rowData;
  
  // ⭐ FIXED: Check if user can edit (considers both role AND status)
  const canEdit = canEditData(userRole, pdpStatus);
  
  // ⭐ NEW: Check if user is a dealer but editing is locked due to status
  const isStatusLocked = isDealerRole(userRole) && !isEditableStatus(pdpStatus);
  
  const [showTable, setShowTable] = useState(true);
  const [masterEquipmentData, setMasterEquipmentData] = useState([]);
  const [isLoadingMaster, setIsLoadingMaster] = useState(true);
  const [error, setError] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [editableData, setEditableData] = useState([]);

  const subColumnsLS = [
    "PDP Target",
    "Total Market Vol.",
    "Market Share",
    "Actual Sales YTD",
    "Market Vol. YTD",
    "Market Share YTD",
    "Forecast Sales EOY",
    "Forecast Market Vol. EOY",
    "Forecast Market Share EOY",
  ];
  const subColumnsCY = ["PDP Target", "Total Market Vol.", "Market Share"];

  const editableFieldsLS = [3, 4, 6, 7];
  const editableFieldsCY = [0, 1];

  const percentageColumnsLS = [2, 5, 8];
  const percentageColumnsCY = [2];
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


  // ⭐ Validate required parameters
  useEffect(() => {
    if (!pdpId) {
      console.error("❌ Missing PDP ID!");
      setError("PDP ID is required. Please navigate from the Equipment tab.");
      setIsLoadingMaster(false);
      return;
    }
    
    if (!selectedYear || !equipmentType) {
      console.error("❌ Missing required parameters!");
      setError("Missing required parameters. Please navigate from the Equipment tab.");
      setIsLoadingMaster(false);
      return;
    }
  }, [pdpId, selectedYear, equipmentType]);

  const calculateMarketShare = (target, volume) => {
    const targetNum = parseFloat(target) || 0;
    const volumeNum = parseFloat(volume) || 0;
    if (volumeNum === 0) return "0.00";
    return ((targetNum / volumeNum) * 100).toFixed(2);
  };

  const calculateRowMarketShares = (row) => {
    const updatedRow = { ...row };
    updatedRow.dataLS[2] = calculateMarketShare(row.dataLS[0], row.dataLS[1]);
    updatedRow.dataLS[5] = calculateMarketShare(row.dataLS[3], row.dataLS[4]);
    updatedRow.dataLS[8] = calculateMarketShare(row.dataLS[6], row.dataLS[7]);
    updatedRow.dataCY[2] = calculateMarketShare(row.dataCY[0], row.dataCY[1]);
    return updatedRow;
  };

  const formatCellValue = (value, columnIndex, isLastYear = true) => {
    const percentageIndices = isLastYear ? percentageColumnsLS : percentageColumnsCY;
    if (percentageIndices.includes(columnIndex)) {
      const numValue = parseFloat(value) || 0;
      return `${numValue.toFixed(2)}%`;
    }
    return value;
  };

  const getEquipmentMakesForHeading = () => {
    if (masterEquipmentData.length === 0) return "";
    const uniqueMakes = [...new Set(masterEquipmentData.map(item => item.equipment_make))].filter(Boolean);
    if (uniqueMakes.length === 0) return "";
    if (uniqueMakes.length === 1) return uniqueMakes[0];
    return uniqueMakes.join(", ");
  };

  const equipmentMakesText = getEquipmentMakesForHeading();

  // ⭐ Fetch equipment data using getPdpEquipmentsByPdpId
  useEffect(() => {
    const fetchEquipmentData = async () => {
      if (!pdpId) {
        console.error("❌ PDP ID is missing");
        setError("PDP ID is required to load equipment data");
        setIsLoadingMaster(false);
        return;
      }

      if (!selectedYear || !equipmentType) {
        setError("Missing required parameters: year or equipment type");
        setIsLoadingMaster(false);
        return;
      }

      try {
        setIsLoadingMaster(true);
        setError(null);

        // ⭐ CRITICAL FIX: Use "Retails" (with 's')
        const filters = {
          category: viewType === "retail" ? "Retails" : "Key Account",
          equipment_type: equipmentType
        };

        const data = await getPdpEquipmentsByPdpId(pdpId, filters);
        
        if (data.length > 0) {
          // console.log("📦 Sample data:", data[0]);
        } else {
          // console.warn("⚠️ No data returned from API. Check filters!");
        }
        
        setMasterEquipmentData(data);
      } catch (error) {
        console.error("❌ Error fetching equipment data:", error);
        setError(error.message || "Failed to load equipment data. Please try again.");
      } finally {
        setIsLoadingMaster(false);
      }
    };

    fetchEquipmentData();
  }, [pdpId, selectedYear, equipmentType, viewType]);

  const equipmentOptions = useMemo(() => {
    const uniqueLines = [...new Set(masterEquipmentData.map(item => item.equipment_line))].filter(Boolean).sort();
    return uniqueLines;
  }, [masterEquipmentData]);

  const equipmentModelOptions = useMemo(() => {
    const uniqueModels = [...new Set(masterEquipmentData.map(item => item.equipment_model))].filter(Boolean).sort();
    return uniqueModels;
  }, [masterEquipmentData]);

  const equipmentMakeOptions = useMemo(() => {
    const uniqueMakes = [...new Set(masterEquipmentData.map(item => item.equipment_make))].filter(Boolean).sort();
    return uniqueMakes;
  }, [masterEquipmentData]);

  const generateAggregatedDataFromEditable = (sourceData) => {
    if (sourceData.length === 0) return [];

    const groupedData = sourceData.reduce((acc, item) => {
      const key = `${item.equipmentMake}_${item.category}`;
      
      if (!acc[key]) {
        acc[key] = {
          year: selectedYear,
          equipmentMake: item.equipmentMake,
          category: item.category,
          models: [],
          dataLS: [0, 0, 0, 0, 0, 0, 0, 0, 0],
          dataCY: [0, 0, 0],
        };
      }
      
      acc[key].dataLS = acc[key].dataLS.map((val, idx) => val + (parseFloat(item.dataLS[idx]) || 0));
      acc[key].dataCY = acc[key].dataCY.map((val, idx) => val + (parseFloat(item.dataCY[idx]) || 0));
      acc[key].models.push(item.equipmentModel);
      
      return acc;
    }, {});

    return Object.values(groupedData).map(row => {
      const newRow = { ...row };
      newRow.dataLS[2] = calculateMarketShare(row.dataLS[0], row.dataLS[1]);
      newRow.dataLS[5] = calculateMarketShare(row.dataLS[3], row.dataLS[4]);
      newRow.dataLS[8] = calculateMarketShare(row.dataLS[6], row.dataLS[7]);
      newRow.dataCY[2] = calculateMarketShare(row.dataCY[0], row.dataCY[1]);
      return newRow;
    });
  };

  // ⭐ Transform API data to component format
  const generateDetailedData = () => {
    if (masterEquipmentData.length === 0) return [];

    return masterEquipmentData.map(item => ({
      id: item.id,
      year: selectedYear,
      equipmentMake: item.equipment_make,
      category: item.equipment_line,
      equipmentModel: item.equipment_model,
      // ⭐ Map Last Year data (PY = Previous Year)
      dataLS: [
        item.py_pdp_target || 0,
        item.py_total_market_volume || 0,
        item.py_market_share || "0.00",
        item.actual_sales_ytd || 0,
        item.market_volume_ytd || 0,
        item.market_share_ytd || "0.00",
        item.forecast_sales_eoy || 0,
        item.forecast_market_volume_eoy || 0,
        item.forecast_market_share_eoy || "0.00"
      ],
      // ⭐ Map Current Year data
      dataCY: [
        item.pdp_target || item.target || 0,
        item.total_market_volume || item.total || 0,
        item.market_share || "0.00"
      ],
      remark: item.remarks || "",
      // Keep original data for update
      originalData: item
    }));
  };

  const detailedData = useMemo(() => generateDetailedData(), [masterEquipmentData, selectedYear]);

  // ⭐ FIXED: Changed isAdmin to canEdit
  const aggregatedData = useMemo(() => {
    if (canEdit && editableData.length > 0) {
      return generateAggregatedDataFromEditable(editableData);
    } else if (detailedData.length > 0) {
      return generateAggregatedDataFromEditable(detailedData);
    }
    return [];
  }, [canEdit, editableData, detailedData, selectedYear]);

  // ⭐ FIXED: Changed isAdmin to canEdit
  useEffect(() => {
    if (canEdit && detailedData.length > 0 && editableData.length === 0) {
      const initialData = detailedData.map(row => {
        const newRow = {
          ...row,
          dataLS: [...row.dataLS],
          dataCY: [...row.dataCY],
          remark: row.remark || ""
        };
        return calculateRowMarketShares(newRow);
      });
      setEditableData(initialData);
    }
  }, [detailedData, canEdit, editableData.length]);

  const [filters, setFilters] = useState({
    equipment: "",
    equipmentModel: [],
    equipmentMake: "",
  });

  const [searchTerm, setSearchTerm] = useState("");

  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({
      ...prev,
      // ✅ Convert null/undefined to appropriate empty value
      [name]: value === null || value === undefined 
        ? (Array.isArray(prev[name]) ? [] : "") 
        : value,
    }));
  };

  const handleBack = () => {
    const backPath = "/pdp/viewdetails";
    navigate(backPath, { 
      state: { 
        activeTab: "Equipment's",
        rowData: rowData
      }
    });
  };

  const handleFieldChange = (rowId, fieldType, index, newValue) => {
    // ⭐ NEW: Prevent editing if status is locked
    if (!canEdit) {
      console.warn("⚠️ Editing is disabled for this PDP status:", pdpStatus);
      return;
    }
    
    setEditableData(prevData => {
      return prevData.map(row => {
        if (row.id !== rowId) return row;
        
        let updatedRow = { ...row };
        
        if (fieldType === 'remark') {
          updatedRow.remark = newValue;
        } else if (fieldType === 'dataLS') {
          updatedRow.dataLS = [...row.dataLS];
          updatedRow.dataLS[index] = newValue;
        } else if (fieldType === 'dataCY') {
          updatedRow.dataCY = [...row.dataCY];
          updatedRow.dataCY[index] = newValue;
        }
        
        updatedRow = calculateRowMarketShares(updatedRow);
        return updatedRow;
      });
    });
  };

  // ⭐ CORRECTED: Save function with proper market share conversion
  const handleSave = async () => {
    if (!pdpId) {
      alert("❌ PDP ID is missing. Cannot save data.");
      return;
    }

    // ⭐ NEW: Double-check edit permission before saving
    if (!canEdit) {
      alert(`❌ Cannot save. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      return;
    }

    try {
      setIsSaving(true);
      
      // ⭐ Helper function to convert percentage string to decimal
      const percentageToDecimal = (value) => {
        if (value === null || value === undefined) return "0.00";
        const strValue = value.toString().replace('%', '').trim();
        const numValue = parseFloat(strValue);
        return isNaN(numValue) ? "0.00" : numValue.toFixed(2);
      };
      
      // ⭐ Transform editableData to API format
      const rows = filteredData.map(row => ({
        id: row.id,
        // ⭐ Current Year YTD data (editable fields from Last Year columns)
        actual_sales_ytd: parseFloat(row.dataLS[3]) || 0,
        market_volume_ytd: parseFloat(row.dataLS[4]) || 0,
    
        // ⭐ Current Year Forecast data (editable fields from Last Year columns)
        forecast_sales_eoy: parseFloat(row.dataLS[6]) || 0,
        forecast_market_volume_eoy: parseFloat(row.dataLS[7]) || 0,
        
        // ⭐ Current Year PDP data (editable fields from Current Year columns)
        pdp_target: parseFloat(row.dataCY[0]) || 0,
        total_market_volume: parseFloat(row.dataCY[1]) || 0,
        
        // ⭐ Remarks
        remarks: row.remark || null
      }));

      await updateMultiplePdpEquipments(rows);
      
      alert("✅ Data saved successfully! The changes have been saved.");
      
      // ⭐ Refetch data to show updated values
      try {
        const filters = {
          category: viewType === "retail" ? "Retails" : "Key Account",
          equipment_type: equipmentType
        };
        const updatedData = await getPdpEquipmentsByPdpId(pdpId, filters);
        setMasterEquipmentData(updatedData);
        setEditableData([]); // Reset to force re-initialization with fresh data
      } catch (refreshError) {
        console.warn("⚠️ Could not refresh data after save:", refreshError);
      }
      
    } catch (error) {
      console.error("❌ Error saving data:", error);
      alert(`❌ Failed to save data: ${error.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const matchesSearchAggregated = (row) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      row.equipmentMake?.toLowerCase().includes(term) ||
      row.category?.toLowerCase().includes(term) ||
      row.dataLS.some((val) => val.toString().includes(term)) ||
      row.dataCY.some((val) => val.toString().includes(term))
    );
  };

  const matchesSearchDetailed = (row) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      row.equipmentMake?.toLowerCase().includes(term) ||
      row.category?.toLowerCase().includes(term) ||
      row.equipmentModel?.toLowerCase().includes(term) ||
      row.dataLS.some((val) => val.toString().includes(term)) ||
      row.dataCY.some((val) => val.toString().includes(term)) ||
      (row.remark && row.remark.toLowerCase().includes(term))
    );
  };

  const searchedData = aggregatedData.filter(matchesSearchAggregated);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return searchedData;

  return [...searchedData].sort((a, b) => {
    const A = a[sortKey];
    const B = b[sortKey];

    if (typeof A === "number" && typeof B === "number") {
      return sortOrder === "asc" ? A - B : B - A;
    }

    return sortOrder === "asc"
      ? String(A ?? "").localeCompare(String(B ?? ""))
      : String(B ?? "").localeCompare(String(A ?? ""));
  });
}, [searchedData, sortKey, sortOrder]);


  // ⭐ FIXED: Changed isAdmin to !canEdit
  const dataToDisplay = !canEdit ? detailedData : editableData;
  
  const filteredData = dataToDisplay
  .filter((row) => {

    // Helper to check if filter has value
    const hasValue = (val) => {
      if (val === null || val === undefined) return false;
      if (Array.isArray(val)) return val.length > 0;
      if (typeof val === "string") return val.trim() !== "";
      return false;
    };

    const hasEquipmentFilter = hasValue(filters.equipment);
    const hasModelFilter = hasValue(filters.equipmentModel);
    const hasMakeFilter = hasValue(filters.equipmentMake);

    // If no filters → show all
    if (!hasEquipmentFilter && !hasModelFilter && !hasMakeFilter) {
      return true;
    }

    const normalizeValue = (val) =>
      (val || "").toString().trim().toLowerCase();

    /* ---------------- Equipment Filter ---------------- */
    let matchesEquipment = true;

    if (hasEquipmentFilter) {
      if (Array.isArray(filters.equipment)) {
        matchesEquipment = filters.equipment.some(
          (eq) => normalizeValue(eq) === normalizeValue(row.category)
        );
      } else {
        matchesEquipment =
          normalizeValue(row.category) === normalizeValue(filters.equipment);
      }
    }

    /* ---------------- Model Filter ---------------- */
    let matchesModel = true;

    if (hasModelFilter) {
      if (Array.isArray(filters.equipmentModel)) {
        matchesModel = filters.equipmentModel.some(
          (model) =>
            normalizeValue(model) === normalizeValue(row.equipmentModel)
        );
      } else {
        matchesModel =
          normalizeValue(row.equipmentModel) ===
          normalizeValue(filters.equipmentModel);
      }
    }

    /* ---------------- Make Filter ---------------- */
    let matchesMake = true;

    if (hasMakeFilter) {
      if (Array.isArray(filters.equipmentMake)) {
        matchesMake = filters.equipmentMake.some(
          (make) =>
            normalizeValue(make) === normalizeValue(row.equipmentMake)
        );
      } else {
        matchesMake =
          normalizeValue(row.equipmentMake) ===
          normalizeValue(filters.equipmentMake);
      }
    }

    return matchesEquipment && matchesModel && matchesMake;
  })
  .filter(matchesSearchDetailed);


/* ---------------- Totals ---------------- */

const totalLS = subColumnsLS.map((_, idx) =>
  filteredData.reduce(
    (sum, row) => sum + (parseFloat(row.dataLS[idx]) || 0),
    0
  )
);

const totalCY = subColumnsCY.map((_, idx) =>
  filteredData.reduce(
    (sum, row) => sum + (parseFloat(row.dataCY[idx]) || 0),
    0
  )
);


/* ---------------- Page Title ---------------- */

const getPageTitle = () => {
  const viewTypeText = viewType === "retail" ? "Retail" : "Key Account";
  return `${equipmentType} - ${viewTypeText}`;
};
const sortedFilteredData = useMemo(() => {
  // start from filteredData
  const base = Array.isArray(filteredData) ? filteredData : [];

  if (!sortKey1 || !sortOrder1) return base;

  return [...base].sort((a, b) => {
    let A, B;

    // If sortKey is for LS array
    if (sortKey1.startsWith("ls_")) {
      const field = sortKey1.replace("ls_", "");
      const idx = subColumnsLS.findIndex(c => normalizeKey(c) === field);
      A = a.dataLS[idx];
      B = b.dataLS[idx];
    }
    // If sortKey is for CY array
    else if (sortKey1.startsWith("cy_")) {
      const field = sortKey1.replace("cy_", "");
      const idx = subColumnsCY.findIndex(c => normalizeKey(c) === field);
      A = a.dataCY[idx];
      B = b.dataCY[idx];
    }
    // Otherwise static field
    else {
      A = a[sortKey1];
      B = b[sortKey1 ];
    }

    // Numeric sort
    if (!isNaN(parseFloat(A)) && !isNaN(parseFloat(B))) {
      return sortOrder1 === "asc"
        ? parseFloat(A) - parseFloat(B)
        : parseFloat(B) - parseFloat(A);
    }

    // String sort
    return sortOrder1 === "asc"
      ? String(A ?? "").localeCompare(String(B ?? ""))
      : String(B ?? "").localeCompare(String(A ?? ""));
  });
}, [filteredData, sortKey1, sortOrder1, subColumnsLS, subColumnsCY]);

  // ⭐ NEW: Get status badge color
  const getStatusBadgeColor = (status) => {
    switch (status) {
      case "Completed": return "bg-green-100 text-green-800 border-green-300";
      case "Approved": return "bg-blue-100 text-blue-800 border-blue-300";
      case "Pending Review": return "bg-orange-100 text-orange-800 border-orange-300";
      case "Started": return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "Created": return "bg-gray-100 text-gray-800 border-gray-300";
      default: return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  if (isLoadingMaster) {
    return (
      <div className="bg-Frostwhite min-h-screen flex flex-col">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        <SubNavbar3 />
        <div className="flex items-center justify-center py-20 mt-[19%] md:mt-[7%] lg:mt-[11%]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-darkblue1 mx-auto mb-4"></div>
            <p className="text-gray-600 font-medium text-lg">Loading equipment data...</p>
            <p className="text-gray-500 text-sm mt-2">PDP ID: {pdpId}</p>
            <p className="text-gray-500 text-sm">{equipmentType} ({selectedYear})</p>
            <p className="text-gray-500 text-sm">Category: {viewType === "retail" ? "Retails" : "Key Account"}</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-Frostwhite min-h-screen flex flex-col">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        <SubNavbar3 />
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="text-center">
            <div className="text-red-600 mb-4">
              <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-lg font-semibold mb-2">Error Loading Data</h3>
              <p className="text-sm text-gray-600 mb-4">{error}</p>
              <div className="text-xs text-gray-500 space-y-1">
                <p>PDP ID: {pdpId || "Not found"}</p>
                <p>Year: {selectedYear}</p>
                <p>Equipment Type: {equipmentType}</p>
                <p>Category: {viewType === "retail" ? "Retails" : "Key Account"}</p>
              </div>
            </div>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => window.location.reload()}
                className="bg-darkblue1 text-white px-6 py-2 hover:bg-darkblue1/90 transition"
              >
                Retry
              </button>
              <button
                onClick={handleBack}
                className="bg-gray-200 text-gray-700 px-6 py-2 hover:bg-gray-300 transition"
              >
                Go Back
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <ArrowLeft
              onClick={handleBack}
              size={24}
              className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
            />
            <h1 className="text-base font-medium text-darkblue1 break-words">
              PDP ({selectedYear}) - ACT - {getPageTitle()}
            </h1>
          </div>

          {/* ⭐ UPDATED: Status Badge with dynamic color */}
          <div className={`shadow-[0_4px_10px_#0000001A] px-3 py-1 flex items-center justify-center gap-2 w-full sm:w-auto border ${getStatusBadgeColor(pdpStatus)}`}>
            {isStatusLocked && <Lock size={14} />}
            <span className="w-2 h-2 bg-current rounded-full inline-block opacity-60"></span>
            <span className="text-xs font-medium">{pdpStatus}</span>
          </div>
        </div>

        <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-[2.7%] mb-2"></div>

        {/* ⭐ NEW: Status Lock Banner - Shows when dealer cannot edit due to status */}
        {/* {isStatusLocked && (
          <div className="bg-amber-50 border border-amber-300 rounded-lg p-3 mb-4 flex items-start gap-3">
            <div className="flex-shrink-0 mt-0.5">
              <Lock size={20} className="text-amber-600" />
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-amber-800 mb-1">
                Editing Disabled
              </h4>
              <p className="text-xs text-amber-700">
                This PDP is in <span className="font-bold">{pdpStatus}</span> status. 
                Data can only be edited when status is <span className="font-semibold">"Created"</span> or <span className="font-semibold">"Started"</span>.
              </p>
              <p className="text-xs text-amber-600 mt-1">
                {pdpStatus === "Pending Review" && "The PDP is awaiting admin approval."}
                {pdpStatus === "Approved" && "The PDP has been approved and is now read-only."}
                {pdpStatus === "Completed" && "The PDP has been completed and finalized."}
              </p>
            </div>
          </div>
        )} */}

        <div className="flex flex-col sm:flex-row flex-wrap justify-between items-start sm:items-center gap-2 sm:gap-3 mb-2">
          <div className="min-h-[24px] w-full sm:w-auto">
            {showTable && (
            <h2 className="text-base font-semibold text-darkblue1 break-words">
  {toTitleCase(equipmentType)} - {equipmentMakesText ? `(${equipmentMakesText})` : ""}
</h2>
            )}
          </div>

          <div className="flex items-center gap-2">
            <div className="">
              <Searchinput
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
                className="w-[1/2]"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                focusRing="focus:ring-black/60"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1"
                iconSize="w-3 h-3"
                iconLeft="left-2 sm:left-3"
                iconColor="text-black"
              />
            </div>

            <div className="relative group flex-shrink-0">
              <button
                onClick={() => setShowTable(!showTable)}
                className="flex items-center gap-1 text-sm font-medium bg-Dustyblue text-white p-1.5 rounded-full hover:bg-darkblue1 transition"
                aria-label={showTable ? "Collapse table" : "Expand table"}
              >
                {showTable ? <ChevronUp size={14} className="w-3 h-3" /> : <ChevronDown size={14} className="w-3 h-3" />}
              </button>

              <span className="absolute left-1/2 top-full -translate-x-1/2 mt-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap pointer-events-none z-50">
                {showTable ? "Collapse" : "Expand"}
              </span>
            </div>
          </div>
        </div>

        {/* ⭐ FIRST TABLE: Aggregated WITHOUT Remarks Column */}
        {showTable && (
          <div className="border border-Dustyblue mb-2 shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-xs text-center min-w-[800px] lg:min-w-0 lg:table-fixed">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
  <tr className="bg-Dustyblue text-white">
    <th
      rowSpan="2"
      className="border border-grey2 border-t-0 border-l-0 px-2 py-1.5 font-semibold text-left w-auto lg:w-[5%] cursor-pointer select-none"
      onClick={() => handleSort("year")}
    >
      <div className="flex items-center gap-1">
        Year
        {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
        {sortKey === "year" && (sortOrder === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
      </div>
    </th>

    <th
      rowSpan="2"
      className="border border-grey2 border-t-0 border-l-0 px-2 py-1.5 font-semibold text-left w-auto lg:w-[10%] cursor-pointer select-none"
      onClick={() => handleSort("equipmentMake")}
    >
      <div className="flex items-center gap-1">
        Equipment Make
        {sortKey === "equipmentMake" && (sortOrder === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
      </div>
    </th>

    <th
      rowSpan="2"
      className="border border-grey2 border-t-0 border-l-0 px-2 py-1.5 font-semibold text-left w-auto lg:w-[12%] cursor-pointer select-none"
      onClick={() => handleSort("category")}
    >
      <div className="flex items-center gap-1">
        Category
        {sortKey === "category" && (sortOrder === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
      </div>
    </th>

    <th colSpan={subColumnsLS.length} className="border border-grey2 border-t-0 border-l-0 px-2 text-center py-1.5 font-semibold">
      {selectedYear - 1}
    </th>
    <th colSpan={subColumnsCY.length} className="border border-grey2 border-t-0 border-l-0 border-r-0 text-center px-2 py-1.5 font-semibold">
      {selectedYear}
    </th>
  </tr>

  <tr className="bg-Dustyblue text-white">
    {subColumnsLS.map((col) => {
      const key = normalizeKey(col) + String(selectedYear - 1);
      return (
        <th
          key={`ls-${col}`}
          className="border border-grey2 border-t-0 border-l-0 px-1 py-2 font-medium cursor-pointer select-none"
          onClick={() => handleSort(key)}
        >
          <div className="flex items-center justify-center gap-1">
            {col}
            {sortKey === key && (sortOrder === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
          </div>
        </th>
      );
    })}

    {subColumnsCY.map((col, idx) => {
  const key = normalizeKey(col) + String(selectedYear);

  return (
    <th
      key={`cy-${col}`}
      className={`border border-grey2 border-t-0 border-l-0 px-1 py-2 font-medium cursor-pointer select-none ${
        idx === subColumnsCY.length - 1 ? "border-r-0" : ""
      }`}
      onClick={() => handleSort(key)}
    >
      <div className="flex items-center justify-center gap-1">
        {col}
        {sortKey === key &&
          (sortOrder === "asc" ? (
            <ChevronUp className="w-3 h-3" />
          ) : (
            <ChevronDown className="w-3 h-3" />
          ))}
      </div>
    </th>
  );
})}

  </tr>
</thead>



              <tbody>
  {sortedData.length > 0 ? (
    <>
      {sortedData.map((row, i) => (
        <tr key={i} className="hover:bg-lightBlue/30 text-xs">

          {/* Year cell with tooltip only if long */}
          <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-left">
            <div className="relative">
              <p
                className="truncate max-w-[10rem] cursor-pointer"
                onMouseEnter={() => {
                  if ((row.year ?? "").toString().length > 10)
                    setHoveredCell(`${i}-year`);
                }}
                onMouseLeave={() => setHoveredCell(null)}
              >
                {row.year}
              </p>
              {hoveredCell === `${i}-year` && (
                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                  {row.year}
                </span>
              )}
            </div>
          </td>

          {/* Equipment Make with tooltip */}
          <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-left">
            <div className="relative">
              <p
                className="truncate max-w-[12rem] cursor-pointer"
                onMouseEnter={() => {
                  if ((row.equipmentMake ?? "").length > 15)
                    setHoveredCell(`${i}-make`);
                }}
                onMouseLeave={() => setHoveredCell(null)}
              >
                {row.equipmentMake}
              </p>
              {hoveredCell === `${i}-make` && (
                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                  {row.equipmentMake}
                </span>
              )}
            </div>
          </td>

          {/* Category with tooltip */}
      <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-left">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if ((row.category ?? "").length > 15)
          setHoveredCell(`${i}-category`);
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.category}
    </p>

    {hoveredCell === `${i}-category` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {row.category}
      </span>
    )}
  </div>
</td>
         {/* Last-Year Data with tooltips */}
{row.dataLS.map((val, j) => {
  const text = formatCellValue(val, j, true);
  const display = text === 0 || text === null || text === undefined ? "" : text;

  return (
    <td
      key={`ls-${i}-${j}`}
      className="border border-grey2 border-t-0 border-l-0 px-1 py-1 text-xs"
    >
      <div className="relative">
        <p
          className="truncate max-w-[8rem] cursor-pointer"
          onMouseEnter={() => {
            if ((display ?? "").toString().length > 8)
              setHoveredCell(`${i}-ls-${j}`);
          }}
          onMouseLeave={() => setHoveredCell(null)}
        >
          {display}
        </p>

        {hoveredCell === `${i}-ls-${j}` && display && (
          <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
            {display}
          </span>
        )}
      </div>
    </td>
  );
})}

{/* Current-Year Data with tooltips */}
{row.dataCY.map((val, j) => {
  const text = formatCellValue(val, j, false);
  const display = text === 0 || text === null || text === undefined ? "" : text;

  return (
    <td
      key={`cy-${i}-${j}`}
      className="border border-grey2 border-t-0 border-l-0 px-1 py-1 text-xs"
    >
      <div className="relative">
        <p
          className="truncate max-w-[8rem] cursor-pointer"
          onMouseEnter={() => {
            if ((display ?? "").toString().length > 8)
              setHoveredCell(`${i}-cy-${j}`);
          }}
          onMouseLeave={() => setHoveredCell(null)}
        >
          {display}
        </p>

        {hoveredCell === `${i}-cy-${j}` && display && (
          <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
            {display}
          </span>
        )}
      </div>
    </td>
  );
})}
        </tr>
      ))}

      {/* Total Row */}
      <tr className="font-semibold hover:bg-lightBlue/30">
        <td colSpan={3} className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-left text-xs">
          Total
        </td>
        {totalLS.map((val, idx) => (
          <td
            key={`totalLS-${idx}`}
            className="border border-grey2 border-t-0 border-l-0 px-1 py-2 text-xs"
          >
            {formatCellValue(val, idx, true)}
          </td>
        ))}
        {totalCY.map((val, idx) => (
          <td
            key={`totalCY-${idx}`}
            className="border border-grey2 border-t-0 border-l-0 border-r-0 px-1 py-1 text-xs"
          >
            {formatCellValue(val, idx, false)}
          </td>
        ))}
      </tr>
    </>
  ) : (
    <tr>
      <td
        colSpan={3 + subColumnsLS.length + subColumnsCY.length}
        className="border border-grey2 border-t-0 border-l-0 px-4 py-8 text-center text-gray-500 italic text-xs sm:text-sm"
      >
        {searchTerm ? "No matching data found" : "No equipment data available"}
      </td>
    </tr>
  )}
</tbody>

              </table>
            </div>
          </div>
        )}

        <div className="flex flex-col sm:flex-row flex-wrap justify-between items-start sm:items-center mb-2">
          <h2 className="text-base font-semibold text-darkblue1 w-full sm:w-auto break-words">
            {toTitleCase(equipmentType)} - {equipmentMakesText ? `(${equipmentMakesText})` : ""} 
          </h2>

          <div className="flex flex-row flex-wrap items-center gap-2 sm:gap-3 w-full sm:w-auto">
            {equipmentMakeOptions.length > 0 && (
              <div className="">
                <Filter
                  name="equipmentMake"
                  value={filters.equipmentMake}
                  options={equipmentMakeOptions}
                  onChange={handleFilterChange}
                  className=""
                  placeholder="Equipment Make"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black/60"
                  openBgColor="bg-white"
                  textColor="text-black"
                  customWidth="w-[150px]"
                />
              </div>
            )}
            {equipmentOptions.length > 0 && (
              <div className="">
                <Filter
                  name="equipment"
                  value={filters.equipment}
                  options={equipmentOptions}
                  onChange={handleFilterChange}
                  className=""
                  placeholder="Equipment"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black/60"
                  openBgColor="bg-white"
                  textColor="text-black"
                  customWidth="w-[150px]"
                />
              </div>
            )}
            {equipmentModelOptions.length > 0 && (
              <div className="flex-1 sm:flex-initial sm:w-[180px] md:w-[200px]">
                <Filter
                  name="equipmentModel"
                  value={filters.equipmentModel}
                  options={equipmentModelOptions}
                  onChange={handleFilterChange}
                  placeholder="Select Model"
                  customWidth="w-full"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  textColor="text-black"
                />
              </div>
            )}
            {/* ⭐ FIXED: Only show Save button when canEdit is true */}
            {canEdit && filteredData.length > 0 && (
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="flex items-center justify-center gap-2 bg-darkblue1 text-white px-4 py-1.5 transition disabled:opacity-50 disabled:cursor-not-allowed text-xs font-medium shadow-md flex-shrink-0"
              >
                {isSaving ? "Saving..." : "Save"}
              </button>
            )}
          </div>
        </div>

        {/* ⭐ SECOND TABLE: WITH Remarks Column */}
        <div className="border border-Dustyblue mb-6 shadow-sm">
          <div className="overflow-x-auto">
             <div
               ref={tableContainerRef}
                className="overflow-y-auto overflow-x-auto scrollbar-hide"
                style={{
                  maxHeight: sortedFilteredData.length > 8 ? "calc(100vh - 240px)" : "auto",
                }}
                 onScroll={handleTableScroll}
              >
            <table className="w-full border-collapse text-xs min-w-[1000px] lg:min-w-0 lg:table-fixed">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
  {/* First header row */}
  <tr className="bg-Dustyblue text-white">
    {/* Year */}
    <th
      rowSpan="2"
      className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 px-2 font-semibold text-left w-[4%] cursor-pointer select-none"
      onClick={() => handleSort1("year")}
    >
      <div className="flex items-center gap-1">
        Year
        {sortKey1 !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
        {sortKey1 === "year" && (
          sortOrder1=== "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />
        )}
      </div>
    </th>

    {/* Equipment Make */}
    <th
      rowSpan="2"
      className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 px-2 font-semibold text-left w-[8%] cursor-pointer select-none"
      onClick={() => handleSort1("equipmentMake")}
    >
      <div className="flex items-center gap-1">
        Equipment Make
        {sortKey1 === "equipmentMake" && (
          sortOrder1 === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />
        )}
      </div>
    </th>

    {/* Category */}
    <th
      rowSpan="2"
      className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 px-2 font-semibold text-left w-[6%] cursor-pointer select-none"
      onClick={() => handleSort1("category")}
    >
      <div className="flex items-center gap-1">
        Category
        {sortKey1 === "category" && (
          sortOrder1 === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />
        )}
      </div>
    </th>

    {/* Equipment Model */}
    <th
      rowSpan="2"
      className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 px-2 font-semibold text-left w-[8%] cursor-pointer select-none"
      onClick={() => handleSort1("equipmentModel")}
    >
      <div className="flex items-center gap-1">
        Equipment Model
        {sortKey1 === "equipmentModel" && (
          sortOrder1 === "asc" ? <ChevronUp class="w-3 h-3" /> : <ChevronDown class="w-3 h-3" />
        )}
      </div>
    </th>

    {/* Last Year (LS) group */}
    <th
      colSpan={subColumnsLS.length}
      className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 px-2 font-semibold text-center"
    >
      {selectedYear - 1}
    </th>

    {/* Current Year (CY) group */}
    <th
      colSpan={subColumnsCY.length}
      className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 px-2 font-semibold text-center"
    >
      {selectedYear}
    </th>

    {/* Remarks */}
    <th
      rowSpan="2"
      className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 px-2 font-semibold text-left w-[12%] cursor-pointer select-none"
      onClick={() => handleSort1("remark")}
    >
      <div className="flex items-center gap-1">
        Remarks
        {setSortKey1 === "remark" && (
          sortOrder1 === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />
        )}
      </div>
    </th>
  </tr>

  {/* Second header row (dynamic subcolumns) */}
  <tr className="bg-Dustyblue text-white">
    {subColumnsLS.map((col, i) => {
      const key = `ls_${normalizeKey(col)}`; // unique sort key per subcol
      return (
        <th
          key={`ls-${i}`}
          className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 px-1 font-medium text-center cursor-pointer select-none"
          onClick={() => handleSort(key)}
        >
          <div className="flex items-center justify-center gap-1">
            {col}
            {sortKey === key && (
              sortOrder === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />
            )}
          </div>
        </th>
      );
    })}

    {subColumnsCY.map((col, i) => {
      const key = `cy_${normalizeKey(col)}`;
      return (
        <th
          key={`cy-${i}`}
          className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 px-1 font-medium text-center cursor-pointer select-none"
          onClick={() => handleSort(key)}
        >
          <div className="flex items-center justify-center gap-1">
            {col}
            {sortKey === key && (
              sortOrder === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />
            )}
          </div>
        </th>
      );
    })}
  </tr>
</thead>



              <tbody>
                {sortedFilteredData.length > 0 ? (
                  sortedFilteredData.map((row, i) => (
                    <tr key={row.id || i} className="hover:bg-lightBlue/30 text-xs">
        <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-left">
          <div className="relative">
            <p
              className="truncate max-w-[8rem] cursor-pointer"
              onMouseEnter={() => {
                if ((row.year?.toString() ?? "").length > 8)
                  setHoveredCell(`${row.id}-year-${i}`);
              }}
              onMouseLeave={() => setHoveredCell(null)}
            >
              {row.year}
            </p>
            {hoveredCell === `${row.id}-year-${i}` && (
              <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                {row.year}
              </span>
            )}
          </div>
        </td>

 <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-left">
          <div className="relative">
            <p
              className="truncate max-w-[12rem] cursor-pointer"
              title={row.equipmentMake}
              onMouseEnter={() => {
                if ((row.equipmentMake ?? "").length > 12)
                  setHoveredCell(`${row.id}-make-${i}`);
              }}
              onMouseLeave={() => setHoveredCell(null)}
            >
              {row.equipmentMake}
            </p>
            {hoveredCell === `${row.id}-make-${i}` && (
              <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                {row.equipmentMake}
              </span>
            )}
          </div>
        </td>

<td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-left">
          <div className="relative">
            <p
              className="truncate max-w-[10rem] cursor-pointer"
              onMouseEnter={() => {
                if ((row.category ?? "").length > 10)
                  setHoveredCell(`${row.id}-category-${i}`);
              }}
              onMouseLeave={() => setHoveredCell(null)}
            >
              {row.category}
            </p>
            {hoveredCell === `${row.id}-category-${i}` && (
              <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                {row.category}
              </span>
            )}
          </div>
        </td>    
  {/* Equipment Model */}
       <td className="border border-grey2 border-t-0 border-l-0 px-2 py-1 text-left">
          <div className="relative">
            <p
              className="truncate max-w-[12rem] cursor-pointer"
              
              onMouseEnter={() => {
                if ((row.equipmentModel ?? "").length > 12)
                  setHoveredCell(`${row.id}-model-${i}`);
              }}
              onMouseLeave={() => setHoveredCell(null)}
            >
              {row.equipmentModel}
            </p>
            {hoveredCell === `${row.id}-model-${i}` && (
              <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                {row.equipmentModel}
              </span>
            )}
          </div>
        </td>



                  {row.dataLS.map((val, j) => {
  const text = formatCellValue(val, j, true);
  const display = text === 0 || text === null || text === undefined ? "" : text;
  const isEditableLS = canEdit && editableFieldsLS.includes(j);

  return (
    <td
      key={`fls-${i}-${j}`}
      className="border border-grey2 border-t-0 border-l-0 px-1 py-1 text-center"
    >
      {isEditableLS ? (
        <input
          type="text"
          value={row.dataLS[j] || ""}
          placeholder="0"
          inputMode="decimal"
          onChange={(e) => {
            const value = e.target.value;
            if (/^\d*\.?\d*$/.test(value)) {
              handleFieldChange(row.id, "dataLS", j, value);
            }
          }}
          className="w-full px-1 py-0.5 border border-gray-300 text-center focus:ring-1 focus:ring-darkblue1 outline-none bg-white text-xs"
        />
      ) : (
        <div className="relative">
          <p
            className="truncate max-w-[6rem] cursor-pointer"
            onMouseEnter={() => {
              if ((display ?? "").toString().length > 6)
                setHoveredCell(`${row.id}-ls-${j}-${i}`);
            }}
            onMouseLeave={() => setHoveredCell(null)}
          >
            {display}
          </p>
          {hoveredCell === `${row.id}-ls-${j}-${i}` && display && (
            <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
              {display}
            </span>
          )}
        </div>
      )}
    </td>
  );
})}

{row.dataCY.map((val, j) => {
  const text = formatCellValue(val, j, false);
  const display = text === 0 || text === null || text === undefined ? "" : text;
  const isEditableCY = canEdit && editableFieldsCY.includes(j);

  return (
    <td
      key={`fcy-${i}-${j}`}
      className="border border-grey2 border-t-0 border-l-0 px-1 py-1 text-center"
    >
      {isEditableCY ? (
        <input
          type="text"
          value={row.dataCY[j] || ""}
          placeholder="0"
          inputMode="decimal"
          onChange={(e) => {
            const value = e.target.value;
            if (/^\d*\.?\d*$/.test(value)) {
              handleFieldChange(row.id, "dataCY", j, value);
            }
          }}
          className="w-full px-1 py-0.5 border border-gray-300 text-center focus:ring-1 focus:ring-darkblue1 outline-none bg-white text-xs"
        />
      ) : (
        <div className="relative">
          <p
            className="truncate max-w-[6rem] cursor-pointer"
            onMouseEnter={() => {
              if ((display ?? "").toString().length > 6)
                setHoveredCell(`${row.id}-cy-${j}-${i}`);
            }}
            onMouseLeave={() => setHoveredCell(null)}
          >
            {display}
          </p>
          {hoveredCell === `${row.id}-cy-${j}-${i}` && display && (
            <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
              {display}
            </span>
          )}
        </div>
      )}
    </td>
  );
})}

                      <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-2 py-1 text-left">
          {canEdit ? (
            <input
              type="text"
              value={row.remark || ""}
              placeholder="-"
              onChange={(e) => handleFieldChange(row.id, "remark", null, e.target.value)}
              className="w-full px-1 py-0.5 border border-gray-300 text-center focus:ring-1 focus:ring-darkblue1 outline-none bg-white text-xs"
            />
          ) : (
            <div className="relative">
              <p
                className="truncate max-w-[15rem] cursor-pointer"
                title={row.remark}
                onMouseEnter={() => {
                  if ((row.remark ?? "").length > 15)
                    setHoveredCell(`${row.id}-remark-${i}`);
                }}
                onMouseLeave={() => setHoveredCell(null)}
              >
                {row.remark || "-"}
              </p>
              {hoveredCell === `${row.id}-remark-${i}` && (
                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                  {row.remark}
                </span>
              )}
            </div>
          )}
        </td>


                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={4 + subColumnsLS.length + subColumnsCY.length + 1}
                      className="border border-black/30 px-4 py-8 text-center text-gray-500 font-normal italic text-xs sm:text-sm"
                    >
                      {searchTerm || filters.equipment || filters.equipmentModel || filters.equipmentMake
                        ? "No matching data found" 
                        : "No equipment data available"}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
           {showScrollButtons && (
            <div className="fixed bottom-10 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

          </div>
        </div>
      </div>
    </div>
  );
};

export default Equipments;