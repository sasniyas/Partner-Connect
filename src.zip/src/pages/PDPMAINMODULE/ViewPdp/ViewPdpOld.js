"use client";
import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import Searchinput from "../../../Components/Searchinput";
import Filter from "../../../Components/Filter";
import { ChevronUp, ChevronDown, ChevronsUpDown, ArrowUp, ArrowDown } from "lucide-react";
import {
  ArrowLeft,
  ArrowRight,
  Download,
  CheckCircle,
  Clock,
  AlertCircle,
  FileText,
  Play,
  RotateCcw,
  Calendar,
  X,
  MapPin,
  StickyNote,
  Trash2,
  Eye,
  PlayCircle,
} from "lucide-react";
import * as XLSX from "xlsx";
import { getAllDealers, getAllMarketAreas } from "../../../services/PDP/ViewPDP/viewpdp.service";
import {
  getAllPdp,
  deletePdp,
  formatDateDisplay,
  formatDateInput
} from "../../../services/PDP/CrudPdp/crudPdp.service";
import { getAllPdpActionItem } from "../../../services/PDP/PdpActionItem/pdpActionItem.service";
import {
  getPdpSignoffsByPdpId,
  getSignoffStats,
  areAllSignoffsComplete,
} from "../../../services/PDP/Signoff/signoff.service";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../services/download/bluckDownload.service";
import {
  startPDP,
  scheduleSignoffMeeting,
} from "../../../services/PDP/SubmitPdp/submitPdp.service";

// ═══════════════════════════════════════════════════════════════
// ROLES ALLOWED TO SCHEDULE SIGNOFF MEETING
// ═══════════════════════════════════════════════════════════════
const MEETING_INVITE_ALLOWED_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
];

// ═══════════════════════════════════════════════════════════════
// ADMIN ROLES - Can delete PDPs & approve/return
// ═══════════════════════════════════════════════════════════════
const ADMIN_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Uptime & Parts Manager",
  "Market Area Head",
];

// ═══════════════════════════════════════════════════════════════
// DEALER ROLES - Can start/continue PDPs
// ═══════════════════════════════════════════════════════════════
const DEALER_ROLES = [
  "Dealer Parts Manager",
  "Dealer Finance Head",
  "Dealer Coordinator",
  "Dealer Sales Head",
  "Dealer CST Head",
  "Dealer CEO",
  "Dealer HR Head",
  "Dealer Principal",
];

function ViewPdp() {
  const navigate = useNavigate();
  const location = useLocation();
  const rowData = location.state || null;

  // Get current user from Redux
  const user = useSelector((state) => state.user);
  const userRole = user?.data?.persona || user?.persona || user?.role || "";
  const userName =
    user?.data?.firstName && user?.data?.lastName
      ? `${user.data.firstName} ${user.data.lastName}`
      : user?.data?.name || user?.name || "User";

  // Check if current user can schedule meetings
  const canScheduleMeeting = MEETING_INVITE_ALLOWED_ROLES.some(
    (role) => role.toLowerCase() === userRole.toLowerCase()
  );

  // Check if current user is admin
  const isAdmin = ADMIN_ROLES.some(
    (role) => role.toLowerCase() === userRole.toLowerCase()
  );

  // Check if current user is dealer
  const isDealer = DEALER_ROLES.some(
    (role) => role.toLowerCase() === userRole.toLowerCase()
  );

  const [tableData, setTableData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const tableContainerRef = useRef(null);

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedYear, setSelectedYear] = useState([]);
  const [selectedMarketArea, setSelectedMarketArea] = useState([]);
  const [selectedDealer, setSelectedDealer] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState([]);
  const [selectedSignOffStatus, setSelectedSignOffStatus] = useState([]);
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"
  const [hoveredCell, setHoveredCell] = useState(null);

  const marketAreaRef = useRef(null);
  const dealerRef = useRef(null);

  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteIndex, setDeleteIndex] = useState(null);
  const [deletePdpItem, setDeletePdpItem] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const [allDealers, setAllDealers] = useState([]);
  const [filteredDealerOptions, setFilteredDealerOptions] = useState([]);
  const [marketAreaOptions, setMarketAreaOptions] = useState([]);

  const [menuOpen, setMenuOpen] = useState(false);
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // ═══════════════════════════════════════════════════════════════
  // MEETING INVITE POPUP STATE
  // ═══════════════════════════════════════════════════════════════
  const [showMeetingPopup, setShowMeetingPopup] = useState(false);
  const [selectedPdpForMeeting, setSelectedPdpForMeeting] = useState(null);
  const [meetingDetails, setMeetingDetails] = useState({
    signoffMeetingDate: "",
    venueDetails: "",
    specialNote: "",
  });
  const [meetingErrors, setMeetingErrors] = useState({});
  const [isSavingMeeting, setIsSavingMeeting] = useState(false);

  // ═══════════════════════════════════════════════════════════════
  // START/CONTINUE LOADING STATE
  // ═══════════════════════════════════════════════════════════════
  const [startingPdpId, setStartingPdpId] = useState(null);

  const currentYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 11 }, (_, i) =>
    (currentYear + i).toString()
  );

  // ═══════════════════════════════════════════════════════════════
  // STATUS COLOR HELPERS
  // ═══════════════════════════════════════════════════════════════
  const getStatusColor = (status) => {
    switch (status) {
      case "Completed":
        return "text-green-600";
      case "Approved":
        return "text-blue-600";
      case "Pending Review":
        return "text-orange-600";
      case "Started":
        return "text-blue-500";
      case "Created":
        return "text-gray-500";
      case "In Progress":
        return "text-yellow-600";
      case "Open":
        return "text-blue-600";
      case "Ongoing":
        return "text-blue-600";
      case "Closed":
        return "text-gray-700";
      case "No Action Items":
        return "text-gray-400";
      case "Not Started":
        return "text-gray-500";
      default:
        return "text-gray-600";
    }
  };

  const getSignOffStatusIcon = (status) => {
    switch (status) {
      case "Completed":
        return <CheckCircle size={14} className="inline mr-1 text-green" />;
      case "Approved":
        return <CheckCircle size={14} className="inline mr-1 text-blue" />;
      case "Pending Review":
        return <Clock size={14} className="inline mr-1 text-orange" />;
      case "Started":
        return <Play size={14} className="inline mr-1 text-blue" />;
      case "Created":
        return <FileText size={14} className="inline mr-1 text-gray" />;
      case "In Progress":
        return <Clock size={14} className="inline mr-1" />;
      case "Not Started":
        return <AlertCircle size={14} className="inline mr-1" />;
      default:
        return null;
    }
  };

  const getActionItemStatusIcon = (status) => {
    switch (status) {
      case "Completed":
        return <CheckCircle size={14} className="inline mr-1" />;
      case "In Progress":
        return <Clock size={14} className="inline mr-1" />;
      case "Open":
        return <AlertCircle size={14} className="inline mr-1" />;
      case "No Action Items":
        return null;
      default:
        return null;
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // GET SIGN OFF STATUS FROM BACKEND
  // ═══════════════════════════════════════════════════════════════
  const getSignOffStatus = (item, signoffs = []) => {
    const backendStatus = item.sign_of_status || item.signOffStatus || item.status;
    if (backendStatus) {
      const normalizedStatus = backendStatus.trim();
      const validStatuses = [
        "Created",
        "Started",
        "Pending Review",
        "Approved",
        "Completed",
      ];
      if (validStatuses.includes(normalizedStatus)) {
        return normalizedStatus;
      }
    }
    if (!signoffs || signoffs.length === 0) return "Created";
    const stats = getSignoffStats(signoffs);
    if (stats.percentage === 100) return "Completed";
    else if (stats.percentage >= 75) return "Approved";
    else if (stats.percentage >= 50) return "Pending Review";
    else if (stats.percentage > 0) return "Started";
    else return "Created";
  };

  const calculateActionItemStatus = (actionItems) => {
    if (!actionItems || actionItems.length === 0) return "No Action Items";
    const totalItems = actionItems.length;
    const closedItems = actionItems.filter((item) => item.status === "Closed").length;
    const openItems = actionItems.filter((item) => item.status === "Open").length;
    const inProgressItems = actionItems.filter(
      (item) => item.status === "In Progress"
    ).length;
    if (closedItems === totalItems) return "Completed";
    if (openItems === totalItems) return "Open";
    if (closedItems > 0 || inProgressItems > 0) return "In Progress";
    return "Open";
  };

  const formatSignoffDetails = (signoffs) => {
    if (!signoffs || signoffs.length === 0) return [];
    return signoffs
      .filter((s) => s.isSigned === 1 || s.isSigned === true)
      .map((s) => ({
        approvedBy:
          `${s.user_first_name || ""} ${s.user_last_name || ""}`.trim() ||
          "Unknown",
        signOffDate: s.signed_timestamp
          ? new Date(s.signed_timestamp).toLocaleDateString("en-US", {
            year: "numeric",
            month: "long",
            day: "numeric",
          })
          : "N/A",
        category: s.category,
        designation: s.user_persona || s.category,
      }));
  };

  // ═══════════════════════════════════════════════════════════════
  // FORMAT MEETING DATE FOR DISPLAY
  // ═══════════════════════════════════════════════════════════════
  const formatMeetingDate = (dateString) => {
    if (!dateString) return "";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return "";
      return date.toLocaleDateString("en-US", {
        timeZone: "Asia/Kolkata",
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      });
    } catch {
      return "";
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // FETCH PDP DATA WITH SIGNOFFS AND ACTIONS
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const fetchPdpWithSignoffsAndActions = async () => {
      try {
        setIsLoading(true);
        const list = await getAllPdp();
        console.log("📍 PDP List from API:", list);

        const pdpWithData = await Promise.all(
          (list || []).map(async (item) => {
            let signoffs = [];
            let signOffStatus = "Created";
            let pdpSignOff = [];
            let actionItems = [];
            let actionItemStatus = "No Action Items";
            let actionItemStats = null;

            // -------------------------------------------------------------
            // REMOVED TO PREVENT NETWORK LOOP
            // -------------------------------------------------------------
            // try {
            //   if (item.id) {
            //     signoffs = await getPdpSignoffsByPdpId(item.id);
            //     pdpSignOff = formatSignoffDetails(signoffs);
            //   }
            // } catch (err) {
            //   console.warn(
            //     `Failed to fetch signoffs for PDP ${item.id}:`,
            //     err.message
            //   );
            // }
            signoffs = [];
            pdpSignOff = [];

            signOffStatus =
              item.sign_of_status || getSignOffStatus(item, signoffs);
            console.log(
              `📍 PDP ${item.id} - Backend status: ${item.sign_of_status}, Final status: ${signOffStatus}`
            );

            // -------------------------------------------------------------
            // Use Backend Properties for Action Item Stats
            // -------------------------------------------------------------
            if (item.action_item_count !== undefined) {
              actionItemStatus =
                item.action_item_count === 0
                  ? "No Action Items"
                  : item.consolidated_actionItem_status || "Open";

              if (item.action_item_count > 0) {
                const total = item.action_item_count;
                const closed = item.action_item_count_completed;
                const open = item.action_item_count_open;
                // Assuming any item not Open or Closed is "In Progress"
                const inProgress = Math.max(0, total - closed - open);

                actionItemStats = {
                  total,
                  closed,
                  open,
                  inProgress,
                  percentage: Math.round((closed / total) * 100),
                };
              }
            } else {
              // Fallback if backend fields are missing (though they should be there)
              try {
                if (item.id) {
                  actionItems = await getAllPdpActionItem({ pdp_id: item.id });
                  actionItemStatus = calculateActionItemStatus(actionItems);
                  if (actionItems && actionItems.length > 0) {
                    const total = actionItems.length;
                    const closed = actionItems.filter(
                      (a) => a.status === "Closed"
                    ).length;
                    const open = actionItems.filter(
                      (a) => a.status === "Open"
                    ).length;
                    const inProgress = actionItems.filter(
                      (a) => a.status === "In Progress"
                    ).length;
                    actionItemStats = {
                      total,
                      closed,
                      open,
                      inProgress,
                      percentage: Math.round((closed / total) * 100),
                    };
                  }
                }
              } catch (err) {
                console.warn(
                  `Failed to fetch action items for PDP ${item.id}:`,
                  err.message
                );
              }
            }

            return {
              id: item.id,
              year: String(item.year),
              marketArea: item.market_area_name,
              dealer: item.dealer_name ? [item.dealer_name] : [],
              dealerName: item.dealer_name,
              // ⭐ Use pre-formatted dates from service (Display format DD/MM/YYYY)
              pdpstartdate: item.pdpStartDate || "",
              pdpenddate: item.pdpEndDate || "",
              physicalpdpstartdate: item.physicalPdpStartDate || "",
              physicalpdpenddate: item.physicalPdpEndDate || "",
              // ⭐ Keep raw dates for form inputs (YYYY-MM-DD)
              pdpstartdateRaw: item.pdpStartDateRaw || "",
              pdpenddateRaw: item.pdpEndDateRaw || "",
              physicalpdpstartdateRaw: item.physicalPdpStartDateRaw || "",
              physicalpdpenddateRaw: item.physicalPdpEndDateRaw || "",
              actionItemStatus,
              actionItemStats,
              signOffStatus,
              pdpSignOff,
              signoffStats:
                signoffs.length > 0 ? getSignoffStats(signoffs) : null,
              returnComments: item.return_back_comment,
              signoffMeetingDate: item.sign_off_meeting_date,
              venueDetails: item.venue_details,
              specialNote: item.special_note,
              completedDate: item.completed_date,
              // ✅ APPROVED BY INFO (from backend)
              approvedByName: item.approved_by_name || null,
              approvedByDesignation: item.approved_by_designation || null,
              approvedAt: item.approved_at || null,
              created_at: item.created_at,
            };
          })
        );

        if (rowData) {
          let injectedSignoffs = [];
          let injectedSignOffStatus = "Created";
          let injectedPdpSignOff = [];
          let injectedActionItems = [];
          let injectedActionItemStatus = "No Action Items";
          let injectedActionItemStats = null;

          if (rowData.id) {
            // -------------------------------------------------------------
            // REMOVED TO PREVENT NETWORK LOOP
            // -------------------------------------------------------------
            // try {
            //   injectedSignoffs = await getPdpSignoffsByPdpId(rowData.id);
            //   injectedPdpSignOff = formatSignoffDetails(injectedSignoffs);
            // } catch (err) {
            //   console.warn(
            //     "Failed to fetch signoffs for injected rowData:",
            //     err.message
            //   );
            // }
            injectedSignoffs = [];
            injectedPdpSignOff = [];
            injectedSignOffStatus =
              rowData.sign_of_status ||
              getSignOffStatus(rowData, injectedSignoffs);
            // ---------------------------------------------------------
            // Optimize Injected Action Items (if available in rowData)
            // ---------------------------------------------------------
            if (rowData.action_item_count !== undefined) {
              injectedActionItemStatus =
                rowData.action_item_count === 0
                  ? "No Action Items"
                  : rowData.consolidated_actionItem_status || "Open";

              if (rowData.action_item_count > 0) {
                const total = rowData.action_item_count;
                const closed = rowData.action_item_count_completed;
                const open = rowData.action_item_count_open;
                const inProgress = Math.max(0, total - closed - open);

                injectedActionItemStats = {
                  total,
                  closed,
                  open,
                  inProgress,
                  percentage: Math.round((closed / total) * 100),
                };
              }
            } else {
              try {
                injectedActionItems = await getAllPdpActionItem({
                  pdp_id: rowData.id,
                });
                injectedActionItemStatus =
                  calculateActionItemStatus(injectedActionItems);
                if (injectedActionItems && injectedActionItems.length > 0) {
                  const total = injectedActionItems.length;
                  const closed = injectedActionItems.filter(
                    (a) => a.status === "Closed"
                  ).length;
                  const open = injectedActionItems.filter(
                    (a) => a.status === "Open"
                  ).length;
                  const inProgress = injectedActionItems.filter(
                    (a) => a.status === "In Progress"
                  ).length;
                  injectedActionItemStats = {
                    total,
                    closed,
                    open,
                    inProgress,
                    percentage: Math.round((closed / total) * 100),
                  };
                }
              } catch (err) {
                console.warn(
                  "Failed to fetch action items for injected rowData:",
                  err.message
                );
              }
            }
          }

          const injected = {
            id: rowData.id,
            year: String(rowData.year),
            marketArea:
              rowData.marketarea || rowData.marketArea || rowData.market_area_name,
            dealer: Array.isArray(rowData.dealer)
              ? rowData.dealer
              : [rowData.dealer],
            dealerName: Array.isArray(rowData.dealer)
              ? rowData.dealer[0]
              : rowData.dealer,
            // ⭐ Use formatDateDisplay for display
            pdpstartdate: formatDateDisplay(
              rowData.pdpstartdate || rowData.pdp_start_date
            ),
            pdpenddate: formatDateDisplay(
              rowData.pdpenddate || rowData.pdp_end_date
            ),
            physicalpdpstartdate: formatDateDisplay(
              rowData.physicalpdpstartdate || rowData.physical_pdp_start_date
            ),
            physicalpdpenddate: formatDateDisplay(
              rowData.physicalpdpenddate || rowData.physical_pdp_end_date
            ),
            // ⭐ Keep raw dates for form inputs
            pdpstartdateRaw: formatDateInput(
              rowData.pdpstartdate || rowData.pdp_start_date
            ),
            pdpenddateRaw: formatDateInput(
              rowData.pdpenddate || rowData.pdp_end_date
            ),
            physicalpdpstartdateRaw: formatDateInput(
              rowData.physicalpdpstartdate || rowData.physical_pdp_start_date
            ),
            physicalpdpenddateRaw: formatDateInput(
              rowData.physicalpdpenddate || rowData.physical_pdp_end_date
            ),
            actionItemStatus: injectedActionItemStatus,
            actionItemStats: injectedActionItemStats,
            signOffStatus: injectedSignOffStatus,
            pdpSignOff: injectedPdpSignOff,
            signoffStats:
              injectedSignoffs.length > 0
                ? getSignoffStats(injectedSignoffs)
                : null,
            returnComments: rowData.returnComments || rowData.return_back_comment,
            signoffMeetingDate:
              rowData.signoffMeetingDate || rowData.sign_off_meeting_date,
            venueDetails: rowData.venueDetails || rowData.venue_details,
            specialNote: rowData.specialNote || rowData.special_note,
            completedDate: rowData.completedDate || rowData.completed_date,
            approvedByName:
              rowData.approvedByName || rowData.approved_by_name || null,
            approvedByDesignation:
              rowData.approvedByDesignation ||
              rowData.approved_by_designation ||
              null,
            approvedAt: rowData.approvedAt || rowData.approved_at || null,
          };
          setTableData([injected, ...pdpWithData]);
        } else {
          setTableData(pdpWithData);
        }
      } catch (e) {
        console.error("Failed to fetch PDP list:", e.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchPdpWithSignoffsAndActions();
  }, [rowData]);

  useEffect(() => {
    const fetchMarketAreas = async () => {
      try {
        const areas = await getAllMarketAreas();
        setMarketAreaOptions(areas.sort((a, b) => a.localeCompare(b)));
      } catch (err) {
        console.error(err.message);
      }
    };
    fetchMarketAreas();
  }, []);

  useEffect(() => {
    const fetchDealers = async () => {
      try {
        const dealers = await getAllDealers();
        setAllDealers(dealers);
        const allOptions = dealers
          .filter((d) => d.dealerShortName)
          .map((d) => d.dealerShortName)
          .sort((a, b) => a.localeCompare(b));
        setFilteredDealerOptions(allOptions);
      } catch (err) {
        console.error(err);
      }
    };
    fetchDealers();
  }, []);

  useEffect(() => {
    if (!allDealers.length) return;
    let options = [];
    if (!selectedMarketArea.length) {
      options = allDealers
        .map((d) => d.dealerShortName)
        .sort((a, b) => a.localeCompare(b));
    } else {
      options = allDealers
        .filter((d) =>
          selectedMarketArea.some(
            (ma) => ma.toLowerCase() === String(d.marketName).toLowerCase()
          )
        )
        .map((d) => d.dealerShortName)
        .sort((a, b) => a.localeCompare(b));
    }
    setFilteredDealerOptions(options);
    setSelectedDealer([]);
  }, [selectedMarketArea, allDealers]);

  const flattenedData = useMemo(() => {
    const rows = [];
    tableData.forEach((item) => {
      if (Array.isArray(item.dealer) && item.dealer.length > 0) {
        item.dealer.forEach((dealerName) => {
          rows.push({
            ...item,
            dealer: dealerName,
            dealerName: dealerName,
          });
        });
      } else {
        rows.push({ ...item, dealer: item.dealer || "-" });
      }
    });
    return rows;
  }, [tableData]);

  const filteredData = useMemo(() => {
    return flattenedData.filter((item) => {
      const matchesSearch = Object.values(item).some((val) =>
        val?.toString().toLowerCase().includes(searchQuery.toLowerCase())
      );
      const matchesYear = selectedYear.length
        ? selectedYear.includes(item.year)
        : true;
      const matchesMarketArea = selectedMarketArea.length
        ? selectedMarketArea.includes(item.marketArea)
        : true;
      const matchesDealer = selectedDealer.length
        ? selectedDealer.includes(item.dealer)
        : true;
      const matchesStatus = selectedStatus.length
        ? selectedStatus.includes(item.actionItemStatus)
        : true;
      const matchesSignOff = selectedSignOffStatus.length
        ? selectedSignOffStatus.includes(item.signOffStatus)
        : true;
      return (
        matchesSearch &&
        matchesYear &&
        matchesMarketArea &&
        matchesDealer &&
        matchesStatus &&
        matchesSignOff
      );
    });
  }, [
    flattenedData,
    searchQuery,
    selectedYear,
    selectedMarketArea,
    selectedDealer,
    selectedStatus,
    selectedSignOffStatus,
  ]);

  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc");
        return;
      } else if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
        return;
      }
    }
    setSortKey(key);
    setSortOrder("asc");
  };
  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredData;

    return [...filteredData].sort((a, b) => {
      const valA = (a[sortKey] || "").toString().trim().toLowerCase();
      const valB = (b[sortKey] || "").toString().trim().toLowerCase();

      return sortOrder === "asc"
        ? valA.localeCompare(valB, undefined, { sensitivity: "base", numeric: true })
        : valB.localeCompare(valA, undefined, { sensitivity: "base", numeric: true });
    });
  }, [filteredData, sortKey, sortOrder]);
  // ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;

    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 100);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (marketAreaRef.current && !marketAreaRef.current.contains(e.target)) {
      }
      if (dealerRef.current && !dealerRef.current.contains(e.target)) {
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handlePreviewAndDownload = async () => {
    if (!filteredData || filteredData.length === 0) {
      alert("No data available to export");
      return;
    }
    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("PDP Data");
      sheet.columns = [
        { header: "Sl. No", key: "slNo", width: 8 },
        { header: "Year", key: "year", width: 10 },
        { header: "Market Area", key: "marketArea", width: 20 },
        { header: "Dealer", key: "dealer", width: 25 },
        { header: "PDP Start Date", key: "pdpStart", width: 15 },
        { header: "PDP End Date", key: "pdpEnd", width: 15 },
        { header: "Physical PDP Start", key: "physicalStart", width: 18 },
        { header: "Physical PDP End", key: "physicalEnd", width: 18 },
        { header: "Action Item Status", key: "actionItemStatus", width: 20 },
        { header: "Sign-Off Status", key: "signOffStatus", width: 20 },
        { header: "Approved By", key: "approvedBy", width: 25 },
      ];
      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
      filteredData.forEach((item, index) => {
        const row = sheet.addRow({
          slNo: index + 1,
          year: item.year,
          marketArea: item.marketArea,
          dealer: item.dealer,
          pdpStart: item.pdpstartdate,
          pdpEnd: item.pdpenddate,
          physicalStart: item.physicalpdpstartdate,
          physicalEnd: item.physicalpdpenddate,
          actionItemStatus: item.actionItemStatus,
          signOffStatus: item.signOffStatus,
          approvedBy: item.approvedByName
            ? `${item.approvedByName}${item.approvedByDesignation
              ? `, ${item.approvedByDesignation}`
              : ""
            }`
            : "-",
        });
        row.eachCell((cell) => {
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });
      });
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const file = new File([blob], "PDP_Data.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const fileUrl = await uploadTempFile(file);
      if (fileUrl) {
        const previewUrl = `https://view.officeapps.live.com/op/view.aspx?src=${encodeURIComponent(
          fileUrl
        )}`;
        window.open(previewUrl, "_blank", "noopener,noreferrer");
      } else {
        alert("Unable to generate preview");
      }
    } catch (error) {
      console.error("PDP export failed:", error);
      alert("Failed to export PDP data");
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // MEETING INVITE HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleOpenMeetingPopup = (item) => {
    setSelectedPdpForMeeting(item);
    setMeetingDetails({
      signoffMeetingDate: item.signoffMeetingDate || "",
      venueDetails: item.venueDetails || "",
      specialNote: item.specialNote || "",
    });
    setMeetingErrors({});
    setShowMeetingPopup(true);
  };

  const handleCloseMeetingPopup = () => {
    setShowMeetingPopup(false);
    setSelectedPdpForMeeting(null);
    setMeetingDetails({
      signoffMeetingDate: "",
      venueDetails: "",
      specialNote: "",
    });
    setMeetingErrors({});
  };

  const validateMeetingForm = () => {
    const errors = {};
    if (!meetingDetails.signoffMeetingDate) {
      errors.signoffMeetingDate = "SignOff Meeting Date is required";
    }
    if (
      !meetingDetails.venueDetails ||
      meetingDetails.venueDetails.trim() === ""
    ) {
      errors.venueDetails = "Venue Details is required";
    }
    setMeetingErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSaveMeeting = async () => {
    if (!validateMeetingForm()) return;

    setIsSavingMeeting(true);
    try {
      await scheduleSignoffMeeting({
        pdpId: selectedPdpForMeeting.id,
        signoffMeetingDate: meetingDetails.signoffMeetingDate,
        venueDetails: meetingDetails.venueDetails,
        specialNote: meetingDetails.specialNote || null,
      });

      setTableData((prev) =>
        prev.map((item) => {
          if (item.id === selectedPdpForMeeting.id) {
            return {
              ...item,
              signoffMeetingDate: meetingDetails.signoffMeetingDate,
              venueDetails: meetingDetails.venueDetails,
              specialNote: meetingDetails.specialNote,
            };
          }
          return item;
        })
      );

      handleCloseMeetingPopup();
      alert("Meeting scheduled successfully!");
    } catch (error) {
      console.error("Failed to save meeting:", error);
      alert(error.message || "Failed to schedule meeting. Please try again.");
    } finally {
      setIsSavingMeeting(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // DELETE PDP HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleDeleteClick = (e, item, idx) => {
    e.stopPropagation();
    setDeletePdpItem(item);
    setDeleteIndex(idx);
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!deletePdpItem) return;

    setIsDeleting(true);
    try {
      await deletePdp(deletePdpItem.id);
      setTableData((prev) =>
        prev.filter((item) => item.id !== deletePdpItem.id)
      );
      setIsDeleteModalOpen(false);
      setDeletePdpItem(null);
      setDeleteIndex(null);
      alert("PDP deleted successfully!");
    } catch (error) {
      console.error("Failed to delete PDP:", error);
      alert(error.message || "Failed to delete PDP. Please try again.");
    } finally {
      setIsDeleting(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // START/CONTINUE PDP HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleStartPdp = async (e, item) => {
    e.stopPropagation();
    setStartingPdpId(item.id);

    try {
      await startPDP({ pdpId: item.id });
      setTableData((prev) =>
        prev.map((pdp) => {
          if (pdp.id === item.id) {
            return { ...pdp, signOffStatus: "Started" };
          }
          return pdp;
        })
      );
      navigate("/pdp/viewdetails", {
        state: { rowData: { ...item, signOffStatus: "Started" } },
      });
    } catch (error) {
      console.error("Failed to start PDP:", error);
      alert(error.message || "Failed to start PDP. Please try again.");
    } finally {
      setStartingPdpId(null);
    }
  };

  const handleContinuePdp = (e, item) => {
    e.stopPropagation();
    navigate("/pdp/viewdetails", { state: { rowData: item } });
  };

  const handleViewPdp = (e, item) => {
    e.stopPropagation();
    navigate("/pdp/viewdetails", { state: { rowData: item } });
  };

  // ═══════════════════════════════════════════════════════════════
  // RENDER PDP DETAILS COLUMN (Actions)
  // ═══════════════════════════════════════════════════════════════
  const renderPdpDetailsColumn = (item, idx) => {
    const status = item.signOffStatus;

    return (
      <div className="flex items-center justify-center gap-1">
        {isAdmin && (
          <>
            {status === "Created" && (
              <div className="relative group inline-block">
                <button
                  onClick={(e) => handleDeleteClick(e, item, idx)}

                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                    <g clip-path="url(#clip0_6398_313)">
                      <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012" />
                    </g>
                    <defs>
                      <clipPath id="clip0_6398_313">
                        <rect width="24" height="24" fill="white" transform="translate(4 4)" />
                      </clipPath>
                    </defs>
                  </svg>


                </button>
                <span className="
    absolute left-1/2 top-full mt-1
    bg-SteelBlue1 text-white text-[10px]
    px-2 py-0 whitespace-nowrap
    transform -translate-x-1/2
    opacity-0 group-hover:opacity-100
    pointer-events-none
    z-50
  ">
                  Delete
                </span>
              </div>
            )}
            <div className="relative group inline-block">
              <button
                onClick={(e) => handleViewPdp(e, item)}
                className="w-6 h-6 border border-grey hover:bg-lightBlue/50 flex items-center justify-center transition"

              >
                <Eye size={14} />
              </button>
              <span className="
    absolute left-1/2 top-full mt-1
    bg-SteelBlue1 text-white text-[10px]
    px-2 py-0 whitespace-nowrap
    transform -translate-x-1/2
    opacity-0 group-hover:opacity-100
    pointer-events-none
    z-50
  ">
                View PDP
              </span>
            </div>
          </>
        )}

        {isDealer && (
          <>
            {status === "Created" && (
              <div className="relative group inline-block">
                <button
                  onClick={(e) => handleStartPdp(e, item)}
                  disabled={startingPdpId === item.id}
                  className="flex items-center gap-1 px-2 py-1 bg-green hover:bg-green-600 text-white text-xs font-medium rounded transition disabled:opacity-50"

                >
                  {startingPdpId === item.id ? (
                    <svg
                      className="animate-spin h-3 w-3"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                  ) : (
                    <PlayCircle size={14} />
                  )}
                  Start
                </button>
                <span className="
    absolute left-1/2 top-full mt-1
    bg-SteelBlue1 text-white text-[10px]
    px-2 py-0 whitespace-nowrap
    transform -translate-x-1/2
    opacity-0 group-hover:opacity-100
    pointer-events-none
    z-50
  ">
                  Start PDP
                </span>
              </div>
            )}

            {status === "Started" && (
              <div className="relative group inline-block">
                <button
                  onClick={(e) => handleContinuePdp(e, item)}
                  className="flex items-center gap-1 px-2 py-1 bg-blue hover:bg-blue-600 text-white text-xs font-medium rounded transition"

                >
                  <Play size={14} />
                  Continue
                </button>
                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                  Continue PDP
                </span>
              </div>
            )}

            {["Pending Review", "Approved", "Completed"].includes(status) && (
              <div className="relative group inline-block">
                <button
                  onClick={(e) => handleViewPdp(e, item)}
                  className="flex items-center gap-1 px-2 py-1 bg-gray-500 hover:bg-gray-600 text-white text-xs font-medium rounded transition"

                >
                  <Eye size={14} />
                  View
                </button>
                <span className="
    absolute left-1/2 top-full mt-1
    bg-SteelBlue1 text-white text-[10px]
    px-2 py-0 whitespace-nowrap
    transform -translate-x-1/2
    opacity-0 group-hover:opacity-100
    pointer-events-none
    z-50
  ">
                  View PDP
                </span>
              </div>
            )}
          </>
        )}

        {!isAdmin && !isDealer && (
          <div className="relative group inline-block">
            <button
              onClick={(e) => handleViewPdp(e, item)}
              className="w-6 h-6 border border-grey hover:bg-lightBlue/50 flex items-center justify-center transition"
            >
              <Eye size={14} />
            </button>
            <span className="
    absolute left-1/2 top-full mt-1
    bg-SteelBlue1 text-white text-[10px]
    px-2 py-0 whitespace-nowrap
    transform -translate-x-1/2
    opacity-0 group-hover:opacity-100
    pointer-events-none
    z-50
  ">
              View PDP
            </span>
          </div>
        )}
      </div>
    );
  };

  // ═══════════════════════════════════════════════════════════════
  // RENDER SIGN-OFF DETAILS COLUMN
  // ═══════════════════════════════════════════════════════════════
  const renderSignOffDetails = (item) => {
    const status = item.signOffStatus;

    if (status === "Approved") {
      return (
        <div className="text-xs">
          {item.approvedByName && (
            <p className="text-gray-700">
              <span className="font-medium">Approved By: </span>
              <span>
                {item.approvedByName}
                {item.approvedByDesignation &&
                  `, ${item.approvedByDesignation}`}
              </span>
            </p>
          )}

          {!item.approvedByName &&
            item.pdpSignOff &&
            item.pdpSignOff.length > 0 && (
              <p className="text-gray-700">
                <span className="font-medium">Approved By: </span>
                <span>
                  {item.pdpSignOff[0].approvedBy}
                  {item.pdpSignOff[0].designation &&
                    `, ${item.pdpSignOff[0].designation}`}
                </span>
              </p>
            )}

          {item.signoffMeetingDate && (
            <p className="text-gray-700 mt-1">
              <span className="font-medium">Signoff Meeting Date: </span>
              <span>{formatMeetingDate(item.signoffMeetingDate)}</span>
            </p>
          )}

          {canScheduleMeeting && !item.signoffMeetingDate && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleOpenMeetingPopup(item);
              }}
              className="mt-2 flex items-center gap-1 px-3 py-1.5 bg-green hover:bg-green-600 text-white text-xs font-medium rounded transition"
            >
              <Calendar size={14} />
              Schedule Signoff Meeting
            </button>
          )}
        </div>
      );
    }

    if (status === "Pending Review") {
      return (
        <div className="text-xs">
          <p className="text-orange-600 font-medium">Awaiting Review</p>
          <p className="text-gray-500 text-[10px] mt-0.5">
            Submitted for admin approval
          </p>
        </div>
      );
    }

    if (status === "Started" && item.returnComments) {
      return (
        <div className="text-xs">
          <p className="text-red-600 font-medium flex items-center gap-1">
            <RotateCcw size={12} /> Returned for Revision
          </p>
          <div className="bg-red-50 p-2 rounded border border-red-200 mt-1">
            <p className="text-gray-700 text-[10px]">
              <span className="font-medium">Comment:</span>
            </p>
            <p className="text-red-700 text-[10px] mt-0.5 line-clamp-2">
              {item.returnComments}
            </p>
          </div>
        </div>
      );
    }

    if (status === "Completed") {
      return (
        <div className="text-xs">
          {item.approvedByName && (
            <p className="text-gray-700">
              <span className="font-medium">Approved By: </span>
              <span>
                {item.approvedByName}
                {item.approvedByDesignation &&
                  `, ${item.approvedByDesignation}`}
              </span>
            </p>
          )}

          {!item.approvedByName &&
            item.pdpSignOff &&
            item.pdpSignOff.length > 0 && (
              <p className="text-gray-700">
                <span className="font-medium">Approved By: </span>
                <span>{item.pdpSignOff[0].approvedBy}</span>
              </p>
            )}

          {item.signoffMeetingDate && (
            <p className="text-gray-700 mt-1">
              <span className="font-medium">Signoff Meeting Date: </span>
              <span>{formatMeetingDate(item.signoffMeetingDate)}</span>
            </p>
          )}
        </div>
      );
    }

    if (status === "Created") {
      return <p className="text-xs text-gray-400 italic">Not started yet</p>;
    }

    if (status === "Started") {
      if (item.signoffStats && item.signoffStats.signed > 0) {
        return (
          <div className="text-xs">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div
                  className="bg-blue-500 h-1.5 rounded-full"
                  style={{ width: `${item.signoffStats.percentage}%` }}
                ></div>
              </div>
              <span className="text-gray-600 whitespace-nowrap">
                {item.signoffStats.signed}/{item.signoffStats.total}
              </span>
            </div>
            <p className="text-gray-500">{item.signoffStats.pending} pending</p>
          </div>
        );
      }
      return <p className="text-xs text-blue-500 italic">In progress...</p>;
    }

    return <p className="text-xs text-gray-400 italic">—</p>;
  };
  const getSignOffDetailsText = (item) => {
    if (!item) return "";

    const status = item.signOffStatus;

    if (status === "Approved" || status === "Completed") {
      const approvedBy =
        item.approvedByName ||
        item.pdpSignOff?.[0]?.approvedBy ||
        "";

      const designation =
        item.approvedByDesignation ||
        item.pdpSignOff?.[0]?.designation ||
        "";

      const meetingDate = item.signoffMeetingDate
        ? formatMeetingDate(item.signoffMeetingDate)
        : "";

      return [
        approvedBy && `Approved By: ${approvedBy}${designation ? `, ${designation}` : ""}`,
        meetingDate && `Signoff Meeting Date: ${meetingDate}`,
      ]
        .filter(Boolean)
        .join(" | ");
    }

    if (status === "Pending Review") {
      return "Awaiting Review";
    }

    if (status === "Started" && item.returnComments) {
      return `Returned for Revision: ${item.returnComments}`;
    }

    if (status === "Started") {
      if (item.signoffStats) {
        return `${item.signoffStats.signed}/${item.signoffStats.total} signed, ${item.signoffStats.pending} pending`;
      }
      return "In progress";
    }

    if (status === "Created") {
      return "Not started yet";
    }

    return "—";
  };

  const renderActionItemStatus = (item) => {
    if (item.actionItemStats) {
      return (
        <div className="text-xs">
          <div
            className={`font-medium flex items-center ${getStatusColor(
              item.actionItemStatus
            )}`}
          >
            {getActionItemStatusIcon(item.actionItemStatus)}
            {item.actionItemStatus}
          </div>
          <div className="flex items-center gap-2 mt-1">
            <div className="w-full bg-gray-200 rounded-full h-1.5">
              <div
                className="bg-green h-1.5 rounded-full"
                style={{ width: `${item.actionItemStats.percentage}%` }}
              ></div>
            </div>
            <span className="text-gray-600 whitespace-nowrap">
              {item.actionItemStats.closed}/{item.actionItemStats.total}
            </span>
          </div>
        </div>
      );
    }
    return (
      <div
        className={`font-medium flex items-center ${getStatusColor(
          item.actionItemStatus
        )}`}
      >
        {getActionItemStatusIcon(item.actionItemStatus)}
        {item.actionItemStatus}
      </div>
    );
  };

  const LoadingSkeleton = () => (
    <div className="animate-pulse">
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          className="flex items-center space-x-4 py-3 px-2 border-b border-gray-100"
        >
          <div className="h-4 bg-gray-200 rounded w-12"></div>
          <div className="h-4 bg-gray-200 rounded w-24"></div>
          <div className="h-4 bg-gray-200 rounded w-20"></div>
          <div className="h-4 bg-gray-200 rounded w-20"></div>
          <div className="h-4 bg-gray-200 rounded w-20"></div>
          <div className="h-4 bg-gray-200 rounded w-20"></div>
          <div className="h-4 bg-gray-200 rounded w-20"></div>
          <div className="h-4 bg-gray-200 rounded w-16"></div>
          <div className="h-4 bg-gray-200 rounded w-16"></div>
          <div className="h-4 bg-gray-200 rounded w-32"></div>
          <div className="h-6 bg-gray-200 rounded w-6"></div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="bg-Frostwhite h-screen overflow-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className="flex flex-col w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4 overflow-visible">
        <div className="flex flex-col w-full overflow-visible">
          <h2 className="text-base font-medium text-darkblue1 mb-2 text-left flex-shrink-0">
            Partnership Development Program (PDP) / View PDP
          </h2>

          <div className="flex-shrink-0 mb-2 relative z-20">
            {/* Mobile Filters Toggle */}
            <div className="flex sm:hidden items-center gap-2 mb-2">
              <Searchinput
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search"
                className="flex-1"
                iconColor="text-black"
                bgColor="bg-white"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3 top-4"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />
              <button
                onClick={() => setShowMobileFilters(!showMobileFilters)}
                className="flex items-center gap-1 px-3 py-1.5 border border-black/60 bg-white text-black text-xs font-medium"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-4 h-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"
                  />
                </svg>
                Filters
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className={`w-3 h-3 transition-transform ${showMobileFilters ? "rotate-180" : ""
                    }`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </button>
            </div>

            {/* Mobile Filters */}
            <div
              className={`sm:hidden ${showMobileFilters ? "block" : "hidden"
                } mb-2 overflow-visible`}
            >
              <div className="grid grid-cols-2 gap-2 overflow-visible">
                <Filter
                  name="Year"
                  value={selectedYear}
                  options={yearOptions}
                  onChange={(name, values) => setSelectedYear(values)}
                  placeholder="Year"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black/60"
                  openBgColor="bg-white"
                  textColor="text-black"
                  customWidth="w-full"
                />
                <div ref={marketAreaRef}>
                  <Filter
                    name="Market Area"
                    value={selectedMarketArea}
                    options={marketAreaOptions}
                    onChange={(name, values) => {
                      setSelectedMarketArea(values);
                      setSelectedDealer([]);
                    }}
                    placeholder="Market Area"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-black/60"
                    openBgColor="bg-white"
                    textColor="text-black"
                    customWidth="w-full"
                  />
                </div>
                <div ref={dealerRef}>
                  <Filter
                    name="Dealer"
                    value={selectedDealer}
                    options={filteredDealerOptions}
                    onChange={(name, values) => setSelectedDealer(values)}
                    placeholder="Dealer"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-black/60"
                    openBgColor="bg-white"
                    textColor="text-black"
                    customWidth="w-full"
                  />
                </div>
                <Filter
                  name="Action Item Status"
                  value={selectedStatus}
                  options={["Completed", "In Progress", "Open", "No Action Items"]}
                  onChange={(name, values) => setSelectedStatus(values)}
                  placeholder="Status"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black/60"
                  openBgColor="bg-white"
                  textColor="text-black"
                  customWidth="w-full"
                />
                <Filter
                  name="Sign Off Status"
                  value={selectedSignOffStatus}
                  options={[
                    "Created",
                    "Started",
                    "Pending Review",
                    "Approved",
                    "Completed",
                  ]}
                  onChange={(name, values) => setSelectedSignOffStatus(values)}
                  placeholder="Sign Off"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black/60"
                  openBgColor="bg-white"
                  textColor="text-black"
                  customWidth="w-full"
                />
                <button
                  onClick={handlePreviewAndDownload}
                  className="bg-darkblue1 text-white px-4 py-1.5 flex items-center justify-center gap-2 font-medium text-xs hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
                >
                  <Download className="w-3 h-3" />
                  Download
                </button>
              </div>
            </div>

            {/* Desktop Filters */}
            <div className="hidden sm:flex flex-row justify-between items-center gap-4 overflow-visible">
              <div className="flex flex-row items-center gap-2 overflow-visible">
                <Searchinput
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search"
                  className="w-[1/2]"
                  iconColor="text-black"
                  bgColor="bg-white"
                  borderColor="border-black/60"
                  textColor="text-black"
                  shadow="shadow-none"
                  inputPadding="pl-6 pr-3 py-1.5"
                  iconSize="w-3 h-3"
                  iconLeft="left-3 top-4"
                  inputWidth="w-full"
                  focusRing="focus:ring-1 focus:ring-black/60"
                  hoverInputClasses="hover:bg-white hover:border-black/60"
                />
                <Filter
                  name="Year"
                  value={selectedYear}
                  options={yearOptions}
                  onChange={(name, values) => setSelectedYear(values)}
                  placeholder="Year"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black/60"
                  openBgColor="bg-white"
                  textColor="text-black"
                  customWidth="w-[120px]"
                />
                <div ref={marketAreaRef}>
                  <Filter
                    name="Market Area"
                    value={selectedMarketArea}
                    options={marketAreaOptions}
                    onChange={(name, values) => {
                      setSelectedMarketArea(values);
                      setSelectedDealer([]);
                    }}
                    placeholder="Market Area"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-black/60"
                    openBgColor="bg-white"
                    textColor="text-black"
                    customWidth="w-[150px]"
                  />
                </div>
                <div ref={dealerRef}>
                  <Filter
                    name="Dealer"
                    value={selectedDealer}
                    options={filteredDealerOptions}
                    onChange={(name, values) => setSelectedDealer(values)}
                    placeholder="Dealer"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-black/60"
                    openBgColor="bg-white"
                    textColor="text-black"
                    customWidth="w-[150px]"
                  />
                </div>
                <Filter
                  name="Action Item Status"
                  value={selectedStatus}
                  options={["Completed", "In Progress", "Open", "No Action Items"]}
                  onChange={(name, values) => setSelectedStatus(values)}
                  placeholder="Action Item Status"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black/60"
                  openBgColor="bg-white"
                  textColor="text-black"
                  customWidth="w-[180px]"
                />
                <Filter
                  name="Sign Off Status"
                  value={selectedSignOffStatus}
                  options={[
                    "Created",
                    "Started",
                    "Pending Review",
                    "Approved",
                    "Completed",
                  ]}
                  onChange={(name, values) => setSelectedSignOffStatus(values)}
                  placeholder="Sign Off Status"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black/60"
                  openBgColor="bg-white"
                  textColor="text-black"
                  customWidth="w-[150px]"
                />
              </div>
              <button
                onClick={handlePreviewAndDownload}
                className="bg-darkblue1 text-white px-4 py-1.5 flex items-center justify-center gap-2 font-medium text-xs hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
              >
                <Download className="w-3 h-3" />
                Download
              </button>
            </div>
          </div>

          {/* Table Container */}
          <div
            className={`flex-shrink overflow-hidden bg-white shadow-md border border-Dustyblue w-full relative z-10 lg:max-h-[calc(100vh-12rem)] ${showMobileFilters
              ? "max-h-[calc(100vh-26rem)]"
              : "max-h-[calc(100vh-14rem)]"
              }`}
          >
            {/* Desktop Table */}
            <div className="hidden lg:block h-full">
              <div
                ref={tableContainerRef}
                className="overflow-y-auto overflow-x-auto max-h-full"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                onScroll={handleTableScroll}

              >
                <table className="w-full text-sm border-collapse table-fixed">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                    <tr>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[5%] cursor-pointer"
                        onClick={() => handleSort("year")}
                      >
                        <div className="flex items-center gap-1">
                          Year
                          {sortKey !== "year" && (
                            <ChevronsUpDown className="w-3 h-3 text-white" />
                          )}
                          {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[8%] cursor-pointer"
                        onClick={() => handleSort("marketArea")}
                      >
                        <div className="flex items-center gap-1">
                          Market Area
                          {sortKey === "marketArea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "marketArea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[10%] cursor-pointer"
                        onClick={() => handleSort("dealer")}
                      >
                        <div className="flex items-center gap-1">
                          Dealer
                          {sortKey === "dealer" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "dealer" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[8%] cursor-pointer"
                        onClick={() => handleSort("pdpstartdate")}
                      >
                        <div className="flex items-center gap-1">
                          PDP Start Date
                          {sortKey === "pdpstartdate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "pdpstartdate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>

                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[8%] cursor-pointer"
                        onClick={() => handleSort("pdpenddate")}
                      >
                        <div className="flex items-center gap-1">
                          PDP End Date
                          {sortKey === "pdpenddate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "pdpenddate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                      {/* <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 w-[8%]">
      Physical PDP Start
    </th> */}
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[8%] cursor-pointer"
                        onClick={() => handleSort("physicalpdpstartdate")}
                      >
                        <div className="flex items-center gap-1">
                          Physical PDP Start
                          {sortKey === "physicalpdpstartdate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "physicalpdpstartdate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[8%] cursor-pointer"
                        onClick={() => handleSort("physicalpdpenddate")}
                      >
                        <div className="flex items-center gap-1">
                          Physical PDP End
                          {sortKey === "physicalpdpenddate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "physicalpdpenddate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[12%] cursor-pointer"
                        onClick={() => handleSort("actionItemStatus")}
                      >
                        <div className="flex items-center gap-1">
                          Action Item Status
                          {sortKey === "actionItemStatus" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "actionItemStatus" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[9%] cursor-pointer"
                        onClick={() => handleSort("signOffStatus")}
                      >
                        <div className="flex items-center gap-1">
                          Sign Off Status
                          {sortKey === "signOffStatus" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "signOffStatus" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 w-[18%] cursor-pointer"
                        onClick={() => handleSort("signOffDetails")}
                      >
                        <div className="flex items-center gap-1">
                          Sign Off Details
                          {sortKey === "signOffDetails" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "signOffDetails" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>



                      <th className="px-2 py-3 text-xs border border-grey2 border-t-0 border-b-0 border-r-0 w-[7%]">
                        PDP Details
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {isLoading ? (
                      <tr>
                        <td colSpan="11">
                          <LoadingSkeleton />
                        </td>
                      </tr>
                    ) : sortedData.length > 0 ? (
                      sortedData.map((item, idx) => (
                        <tr
                          key={`${item.id}-${item.dealer}-${idx}`}
                          className="hover:bg-lightBlue/50 text-xs"
                        >
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[20rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.year && item.year.length > 40)
                                    setHoveredCell(item.id + "-year");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.year || "-"}
                              </p>

                              {hoveredCell === item.id + "-year" && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {item.year}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[20rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.marketArea && item.marketArea.length > 40)
                                    setHoveredCell(item.id + "-marketArea");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.marketArea || "-"}
                              </p>

                              {hoveredCell === item.id + "-marketArea" && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {item.marketArea}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[20rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.dealer && item.dealer.length > 20)
                                    setHoveredCell(item.id + "-dealer");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.dealer || "-"}
                              </p>

                              {hoveredCell === item.id + "-dealer" && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {item.dealer}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[20rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.pdpstartdate && item.pdpstartdate.length > 40)
                                    setHoveredCell(item.id + "-pdpstart");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.pdpstartdate || "-"}
                              </p>

                              {hoveredCell === item.id + "-pdpstart" && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {item.pdpstartdate}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[20rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.pdpenddate && item.pdpenddate.length > 40)
                                    setHoveredCell(item.id + "-pdpend");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.pdpenddate || "-"}
                              </p>

                              {hoveredCell === item.id + "-pdpend" && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {item.pdpenddate}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[20rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.physicalpdpstartdate && item.physicalpdpstartdate.length > 40)
                                    setHoveredCell(item.id + "-physicalstart");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.physicalpdpstartdate || "-"}
                              </p>

                              {hoveredCell === item.id + "-physicalstart" && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {item.physicalpdpstartdate}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[20rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.physicalpdpenddate && item.physicalpdpenddate.length > 40)
                                    setHoveredCell(item.id + "-physicalend");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.physicalpdpenddate || "-"}
                              </p>

                              {hoveredCell === item.id + "-physicalend" && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {item.physicalpdpenddate}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[20rem] cursor-pointer"
                                onMouseEnter={() => {
                                  const value = renderActionItemStatus(item);
                                  if (value && value.length > 20)
                                    setHoveredCell(item.id + "-actionStatus");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {renderActionItemStatus(item) || "-"}
                              </p>

                              {hoveredCell === item.id + "-actionStatus" && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {renderActionItemStatus(item)}
                                </span>
                              )}
                            </div>
                          </td>
                          <td
                            className={`px-2 py-1 border border-grey2 border-t-0 border-l-0 font-medium ${getStatusColor(
                              item.signOffStatus
                            )}`}
                          >
                            <div className="relative">
                              <div
                                className="flex items-center gap-1 truncate max-w-[20rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.signOffStatus && item.signOffStatus.length > 20)
                                    setHoveredCell(item.id + "-signOffStatus");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {getSignOffStatusIcon(item.signOffStatus)}
                                <span className="truncate">{item.signOffStatus || "-"}</span>
                              </div>

                              {hoveredCell === item.id + "-signOffStatus" && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {item.signOffStatus}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[20rem] cursor-pointer"
                                onMouseEnter={() => {
                                  const value = getSignOffDetailsText(item);
                                  if (value && value.length > 20) {
                                    setHoveredCell(item.id + "-signOffDetails");
                                  }
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {renderSignOffDetails(item)}
                              </p>

                              {hoveredCell === item.id + "-signOffDetails" && (
                                <span className="absolute left-2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50 ">
                                  {getSignOffDetailsText(item)}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                            {renderPdpDetailsColumn(item, idx)}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          colSpan="11"
                          className="text-center py-6 text-gray-500 italic text-sm"
                        >
                          No data found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
              {showScrollButtons && (
                <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
                  {/* Show UP arrow when scrolling DOWN */}
                  {scrollDirection === 'down' && (
                    <button
                      onClick={scrollToTop}
                      className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                      aria-label="Scroll to top"
                    >
                      <ArrowUp className="w-2 h-2" />
                    </button>
                  )}

                  {/* Show DOWN arrow when scrolling UP */}
                  {scrollDirection === 'up' && (
                    <button
                      onClick={scrollToBottom}
                      className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                      aria-label="Scroll to bottom"
                    >
                      <ArrowDown className="w-2 h-2" />
                    </button>
                  )}
                </div>
              )}



            </div>

            {/* Mobile Cards */}
            <div className="lg:hidden h-full">
              <div
                className="overflow-y-auto space-y-4 p-3 md:p-6 max-h-full"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center py-10">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
                    <span className="ml-3 text-sm text-gray-600">
                      Loading...
                    </span>
                  </div>
                ) : filteredData.length > 0 ? (
                  filteredData.map((item, idx) => (
                    <div
                      key={`${item.id}-${item.dealer}-${idx}`}
                      className="bg-white shadow-md p-4 border border-gray-200"
                    >
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-darkblue1">
                          Year:
                        </span>
                        <span className="text-sm">{item.year}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-darkblue1">
                          Market Area:
                        </span>
                        <span className="text-sm">{item.marketArea}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-darkblue1">
                          Dealer:
                        </span>
                        <span className="text-sm">{item.dealer}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-darkblue1">
                          PDP Start:
                        </span>
                        <span className="text-sm">{item.pdpstartdate}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-darkblue1">
                          PDP End:
                        </span>
                        <span className="text-sm">{item.pdpenddate}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-darkblue1">
                          Action Status:
                        </span>
                        <div className="text-right">
                          {renderActionItemStatus(item)}
                        </div>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-darkblue1">
                          Sign Off:
                        </span>
                        <span
                          className={`text-sm font-medium flex items-center ${getStatusColor(
                            item.signOffStatus
                          )}`}
                        >
                          {getSignOffStatusIcon(item.signOffStatus)}
                          {item.signOffStatus}
                        </span>
                      </div>
                      <div className="mb-3">
                        <span className="font-semibold text-sm text-darkblue1">
                          Sign Off Details:
                        </span>
                        <div className="mt-1">{renderSignOffDetails(item)}</div>
                      </div>
                      <div className="flex justify-end">
                        {renderPdpDetailsColumn(item, idx)}
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-gray-500 italic">
                    No data found
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* MEETING INVITE POPUP */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      {showMeetingPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={handleCloseMeetingPopup}
          ></div>

          <div className="relative bg-white w-full max-w-lg mx-4 shadow-xl rounded-lg overflow-hidden">
            <div className="bg-gradient-to-r from-gray-500 to-gray-600 px-6 py-3">
              <h2 className="text-white text-lg font-medium">
                Schedule Signoff Meeting
              </h2>
            </div>

            <div className="bg-gray-700 px-6 py-2">
              <h3 className="text-white text-sm font-medium">Meeting Details</h3>
            </div>

            <div className="p-6 space-y-4">
              {/* SignOff Meeting Date */}
              <div className="flex items-start gap-4">
                <label className="w-40 text-sm text-gray-700 pt-2 flex-shrink-0">
                  SignOff Meeting Date <span className="text-red-500">*</span>
                </label>
                <div className="flex-1">
                  <div className="relative">
                    <input
                      type="datetime-local"
                      value={meetingDetails.signoffMeetingDate}
                      onChange={(e) =>
                        setMeetingDetails((prev) => ({
                          ...prev,
                          signoffMeetingDate: e.target.value,
                        }))
                      }
                      className={`w-full border ${meetingErrors.signoffMeetingDate
                        ? "border-red-500"
                        : "border-gray-300"
                        } rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500`}
                    />
                    {meetingDetails.signoffMeetingDate && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setMeetingDetails((prev) => ({
                            ...prev,
                            signoffMeetingDate: "",
                          }));
                        }}
                        className="absolute right-2 top-1/2 -translate-y-1/2 bg-blue-500 hover:bg-blue-600 text-white rounded p-1"
                      >
                        <X size={12} />
                      </button>
                    )}
                  </div>
                  {meetingErrors.signoffMeetingDate && (
                    <p className="text-red-500 text-xs mt-1">
                      {meetingErrors.signoffMeetingDate}
                    </p>
                  )}
                </div>
              </div>

              {/* Venue Details */}
              <div className="flex items-start gap-4">
                <label className="w-40 text-sm text-gray-700 pt-2 flex-shrink-0">
                  Venue Details <span className="text-red-500">*</span>
                </label>
                <div className="flex-1">
                  <textarea
                    value={meetingDetails.venueDetails}
                    onChange={(e) =>
                      setMeetingDetails((prev) => ({
                        ...prev,
                        venueDetails: e.target.value,
                      }))
                    }
                    rows={3}
                    className={`w-full border ${meetingErrors.venueDetails
                      ? "border-red-500"
                      : "border-gray-300"
                      } rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none`}
                    placeholder="Enter venue details..."
                  />
                  {meetingErrors.venueDetails && (
                    <p className="text-red-500 text-xs mt-1">
                      {meetingErrors.venueDetails}
                    </p>
                  )}
                </div>
              </div>

              {/* Special Note */}
              <div className="flex items-start gap-4">
                <label className="w-40 text-sm text-gray-700 pt-2 flex-shrink-0">
                  Special Note (Optional)
                </label>
                <div className="flex-1">
                  <textarea
                    value={meetingDetails.specialNote}
                    onChange={(e) =>
                      setMeetingDetails((prev) => ({
                        ...prev,
                        specialNote: e.target.value,
                      }))
                    }
                    rows={3}
                    className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none"
                    placeholder="Enter any special notes..."
                  />
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex justify-center gap-3 px-6 py-4 border-t border-gray-200">
              <button
                type="button"
                onClick={handleCloseMeetingPopup}
                className="flex items-center gap-2 px-6 py-2 bg-gray-500 hover:bg-gray-600 text-white text-sm font-medium rounded transition"
              >
                <X size={16} />
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveMeeting}
                disabled={isSavingMeeting}
                className="flex items-center gap-2 px-6 py-2 bg-green hover:bg-green-600 text-white text-sm font-medium rounded transition disabled:opacity-50"
              >
                {isSavingMeeting ? (
                  <>
                    <svg
                      className="animate-spin h-4 w-4"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                    Saving...
                  </>
                ) : (
                  <>
                    <Calendar size={16} />
                    Schedule Meeting
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* DELETE CONFIRMATION POPUP */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      {isDeleteModalOpen && deletePdpItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => !isDeleting && setIsDeleteModalOpen(false)}
          ></div>

          <div className="relative bg-white w-full max-w-md mx-4 shadow-xl rounded-lg overflow-hidden">
            <div className="bg-gradient-to-r from-red-500 to-red-600 px-6 py-3">
              <h2 className="text-white text-lg font-medium">Delete PDP</h2>
            </div>

            <div className="p-6">
              <div className="flex items-center justify-center mb-4">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                  <Trash2 size={32} className="text-red-600" />
                </div>
              </div>

              <div className="text-center mb-4">
                <h4 className="text-lg font-semibold text-gray-800 mb-2">
                  Are you sure you want to delete this PDP?
                </h4>
                <p className="text-sm text-gray-600">
                  <strong>Year:</strong> {deletePdpItem.year} |{" "}
                  <strong>Dealer:</strong>{" "}
                  {deletePdpItem.dealer || deletePdpItem.dealerName}
                </p>
              </div>

              <p className="text-xs text-center text-red-600 bg-red p-2 rounded mb-4">
                ⚠️ This action cannot be undone. All data associated with this
                PDP will be permanently deleted.
              </p>
            </div>

            <div className="flex justify-center gap-3 px-6 py-4 border-t border-gray-200">
              <button
                type="button"
                onClick={() => setIsDeleteModalOpen(false)}
                disabled={isDeleting}
                className="flex items-center gap-2 px-6 py-2 bg-gray-500 hover:bg-gray-600 text-white text-sm font-medium rounded transition disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="flex items-center gap-2 px-6 py-2 bg-red hover:bg-red-600 text-white text-sm font-medium rounded transition disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <svg
                      className="animate-spin h-4 w-4"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                    Deleting...
                  </>
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                      <g clip-path="url(#clip0_6398_313)">
                        <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012" />
                      </g>
                      <defs>
                        <clipPath id="clip0_6398_313">
                          <rect width="24" height="24" fill="white" transform="translate(4 4)" />
                        </clipPath>
                      </defs>
                    </svg>


                    Delete
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ViewPdp;