import React, { useState, useEffect } from "react";
import Header from "../../../../Components/Header";
import { useNavigate, useLocation } from "react-router-dom";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import { ArrowLeft, ArrowRight, ChevronUp, ChevronDown, Download, Send, X, AlertTriangle, CheckCircle, RotateCcw, ThumbsUp, MessageSquare, Info, Calendar } from "lucide-react";
import Equipment from "./Equipment";
import Uptimeparts from "./Uptimeparts";
import Infrastructure from "./Infrastructure";
import TerritoryFocus from "./TerritoryFocus";
import CompetenceDevelopment from "./CompetencDevelopment";
import Marcom from "./Marcom";
import UploadFiles from "./UploadFiles";
import Others from "./Others";
import SignoffStatus from "./SignofStatus";
import StatusLogsPopup from "./StatusLogsPopup";
import DownloadPPT from "./DownloadPPT";
import { formatDateOnly } from "../../../../util/timeFormat";
import { extractRowData } from "../../../../util/pdpNavigationState";
import { useSelector } from "react-redux";
import ExcelJS from "exceljs";
import { getPdpSignoffsByPdpId } from "../../../../services/PDP/Signoff/signoff.service";
import { uploadTempFile } from "../../../../services/download/bluckDownload.service";
import { 
  submitPDP, 
  approvePDP, 
  returnPDP, 
  getReturnComments 
} from "../../../../services/PDP/SubmitPdp/submitPdp.service";

// ═══════════════════════════════════════════════════════════════
// ROLES ALLOWED TO SUBMIT PDP (Dealer Roles)
// ═══════════════════════════════════════════════════════════════
const SUBMIT_ALLOWED_ROLES = [
  "Dealer Parts Manager",
  "Dealer Finance Head",
  "Dealer Coordinator",
  "Dealer Sales Head",
  "Dealer CST Head",
  "Dealer CEO",
  "Dealer HR Head",
  "Dealer Principal"
];

// ═══════════════════════════════════════════════════════════════
// ROLES ALLOWED TO APPROVE/RETURN PDP (Admin/Manager Roles)
// ═══════════════════════════════════════════════════════════════
const APPROVE_ALLOWED_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Uptime & Parts Manager",
  "Market Area Head"
];

// ═══════════════════════════════════════════════════════════════
// RETURN COMMENTS BANNER COMPONENT
// ═══════════════════════════════════════════════════════════════
const ReturnCommentsBanner = ({ returnData, onDismiss }) => {
  if (!returnData || !returnData.comments) return null;

  const formatDate = (dateString) => {
    if (!dateString) return "";
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      });
    } catch {
      return "";
    }
  };

  return (
    <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4 rounded-r-lg shadow-sm">
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0">
            <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
              <RotateCcw size={20} className="text-red-600" />
            </div>
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-red-800 flex items-center gap-2">
              <AlertTriangle size={16} />
              PDP Returned for Revision
            </h4>
            <div className="mt-2 bg-white border border-red-200 rounded-lg p-3">
              <div className="flex items-center gap-2 text-xs text-red-600 mb-2">
                <MessageSquare size={14} />
                <span className="font-medium">Return Comments:</span>
              </div>
              <p className="text-sm text-gray-800 whitespace-pre-wrap">
                {returnData.comments}
              </p>
            </div>
            {returnData.returnedAt && (
              <div className="mt-2 text-xs text-gray-600">
                <span className="font-medium">Returned on:</span> {formatDate(returnData.returnedAt)}
              </div>
            )}
          </div>
        </div>
        {onDismiss && (
          <button
            onClick={onDismiss}
            className="text-red-400 hover:text-red-600 transition-colors"
          >
            <X size={18} />
          </button>
        )}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// SUCCESS POPUP COMPONENT
// ═══════════════════════════════════════════════════════════════
const SuccessPopup = ({ isOpen, onClose, message, statusText }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative bg-white rounded-lg shadow-2xl w-[90%] max-w-sm mx-4 overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-6">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle size={40} className="text-green-600" />
            </div>
          </div>
          <div className="text-center mb-4">
            <h4 className="text-lg font-semibold text-gray-800 mb-2">
              Success!
            </h4>
            <p className="text-sm text-gray-600">
              {message || "Operation completed successfully!"}
            </p>
          </div>
          {statusText && (
            <div className="flex justify-center mb-4">
              <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                statusText === "Approved" 
                  ? "bg-blue text-blue-700" 
                  : statusText === "Pending Review"
                  ? "bg-orange text-orange-700"
                  : statusText === "Started"
                  ? "bg-yellow text-yellow-700"
                  : "bg-gray text-gray-700"
              }`}>
                Status: {statusText}
              </span>
            </div>
          )}
          <button
            onClick={onClose}
            className="w-full px-4 py-2.5 text-sm font-medium text-white bg-green rounded-lg hover:bg-green-700 transition-colors"
          >
            OK
          </button>
        </div>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// SUBMIT CONFIRMATION POPUP COMPONENT
// ═══════════════════════════════════════════════════════════════
const SubmitConfirmationPopup = ({ isOpen, onClose, onConfirm, isSubmitting }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={!isSubmitting ? onClose : undefined}
      />
      <div className="relative bg-white rounded-lg shadow-2xl w-[90%] max-w-md mx-4 overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="bg-darkblue1 px-4 py-3 flex items-center justify-between">
          <h3 className="text-white font-semibold text-sm flex items-center gap-2">
            <Send size={16} />
            Submit PDP Sheet
          </h3>
          {!isSubmitting && (
            <button
              onClick={onClose}
              className="text-white/80 hover:text-white transition-colors"
            >
              <X size={18} />
            </button>
          )}
        </div>
        <div className="p-5">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-yellow rounded-full flex items-center justify-center">
              <AlertTriangle size={32} className="text-yellow-600" />
            </div>
          </div>
          <div className="text-center mb-4">
            <h4 className="text-lg font-semibold text-gray-800 mb-2">
              Do you wish to submit this sheet?
            </h4>
            <p className="text-sm text-gray-500">
              The status will change to <span className="font-semibold text-orange-600">Pending Review</span>
            </p>
          </div>
          {/* FIX 7: text-orange-50 was nearly invisible (almost white) on orange bg → text-orange-800 */}
          <p className="text-xs text-center text-orange-800 bg-orange p-2 rounded mb-4">
            ⚠️ This action cannot be undone. Please ensure all information is correct before submitting.
          </p>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1 px-4 py-2.5 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              disabled={isSubmitting}
              className="flex-1 px-4 py-2.5 text-sm font-medium text-white bg-green rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Submitting...
                </>
              ) : (
                <>
                  <Send size={16} />
                  Yes, Submit
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// APPROVE PDP POPUP COMPONENT
// ═══════════════════════════════════════════════════════════════
const ApproveConfirmationPopup = ({ isOpen, onClose, onConfirm, isProcessing }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={!isProcessing ? onClose : undefined}
      />
      <div className="relative bg-white rounded-lg shadow-2xl w-[90%] max-w-md mx-4 overflow-hidden">
        <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 px-4 py-3">
          <h3 className="text-white font-semibold text-base">Alert</h3>
        </div>
        
        <div className="bg-orange-50 p-5">
          <div className="flex items-start gap-3 mb-6">
            <div className="flex-shrink-0">
              <AlertTriangle size={24} className="text-yellow-600" />
            </div>
            <p className="text-gray-800 font-medium">
              Do you wish to approve PDP sheet?
            </p>
          </div>

          <div className="flex justify-center gap-3">
            <button
              onClick={onClose}
              disabled={isProcessing}
              className="flex items-center gap-2 px-6 py-2 text-sm font-medium text-white bg-blue rounded hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ArrowLeft size={16} />
              No
            </button>
            <button
              onClick={onConfirm}
              disabled={isProcessing}
              className="flex items-center gap-2 px-6 py-2 text-sm font-medium text-white bg-green rounded hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Processing...
                </>
              ) : (
                <>
                  Yes
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// RETURN PDP POPUP COMPONENT (WITH COMMENTS)
// ═══════════════════════════════════════════════════════════════
const ReturnConfirmationPopup = ({ isOpen, onClose, onConfirm, isProcessing }) => {
  const [comments, setComments] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!isOpen) {
      setComments("");
      setError("");
    }
  }, [isOpen]);

  const handleConfirm = () => {
    if (!comments.trim()) {
      setError("Please enter return back comments");
      return;
    }
    setError("");
    onConfirm(comments.trim());
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={!isProcessing ? onClose : undefined}
      />
      <div className="relative bg-white rounded-lg shadow-2xl w-[90%] max-w-lg mx-4 overflow-hidden">
        <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 px-4 py-3">
          <h3 className="text-white font-semibold text-base">Alert</h3>
        </div>
        
        <div className="bg-orange-50 p-5">
          <div className="flex items-start gap-3 mb-4">
            <div className="flex-shrink-0">
              <AlertTriangle size={24} className="text-yellow-600" />
            </div>
            <p className="text-gray-800 font-medium">
              Do you wish to return back PDP sheet?
            </p>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Return back Comments <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <textarea
                value={comments}
                onChange={(e) => {
                  setComments(e.target.value);
                  if (error) setError("");
                }}
                placeholder="Enter your comments for returning this PDP..."
                className={`w-full h-32 p-3 border rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white ${
                  error ? 'border-red-500' : 'border-gray-300'
                }`}
                disabled={isProcessing}
              />
              {/* FIX 10: pointer-events-none so chevron icon doesn't block textarea input */}
              <div className="absolute top-2 right-2 pointer-events-none">
                <ChevronDown size={16} className="text-gray-400" />
              </div>
            </div>
            {error && (
              <p className="text-red-500 text-xs mt-1">{error}</p>
            )}
          </div>

          <div className="flex justify-center gap-3">
            <button
              onClick={onClose}
              disabled={isProcessing}
              className="flex items-center gap-2 px-6 py-2 text-sm font-medium text-white bg-blue rounded hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ArrowLeft size={16} />
              No
            </button>
            <button
              onClick={handleConfirm}
              disabled={isProcessing}
              className="flex items-center gap-2 px-6 py-2 text-sm font-medium text-white bg-green rounded hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Processing...
                </>
              ) : (
                <>
                  Yes
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

function PDPViewdetails() {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  
  const rowData = React.useMemo(() => {
    return extractRowData(
      { rowData: location.state?.rowData },
      location.state
    );
  }, [location.state]);
  
  const [isExpanded, setIsExpanded] = useState(true);
  const [activeTab, setActiveTab] = useState("Equipment's");
  const [showStatusPopup, setShowStatusPopup] = useState(false);
  const [isPPTPopupOpen, setIsPPTPopupOpen] = useState(false);
  const [othersFilesData, setOthersFilesData] = useState([]);
  const [latestSignoff, setLatestSignoff] = useState(null);
  
  // Submit states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSubmitPopup, setShowSubmitPopup] = useState(false);
  
  // Approve states
  const [isApproving, setIsApproving] = useState(false);
  const [showApprovePopup, setShowApprovePopup] = useState(false);
  
  // Return states
  const [isReturning, setIsReturning] = useState(false);
  const [showReturnPopup, setShowReturnPopup] = useState(false);
  
  // Return comments states
  const [returnData, setReturnData] = useState(null);
  const [showReturnBanner, setShowReturnBanner] = useState(true);
  
  // Success popup states
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [successStatus, setSuccessStatus] = useState("");
  
  const [currentSignOffStatus, setCurrentSignOffStatus] = useState(rowData?.signOffStatus || "Created");
  const { data: userData } = useSelector((state) => state.user);

  const detectedRole = userData?.persona;
  const effectiveRole = detectedRole;

  // ═══════════════════════════════════════════════════════════════
  // CHECK IF USER CAN SUBMIT (Dealer roles, only for Created/Started)
  // ═══════════════════════════════════════════════════════════════
  const canUserSubmit = React.useMemo(() => {
    if (!effectiveRole) return false;
    const isRoleAllowed = SUBMIT_ALLOWED_ROLES.some(
      role => role.toLowerCase() === effectiveRole.toLowerCase()
    );
    const statusAllowsSubmit = ["Created", "Started"].includes(currentSignOffStatus);
    return isRoleAllowed && statusAllowsSubmit;
  }, [effectiveRole, currentSignOffStatus]);

  // ═══════════════════════════════════════════════════════════════
  // CHECK IF USER CAN APPROVE/RETURN (Admin roles, only for Pending Review)
  // ═══════════════════════════════════════════════════════════════
  const canUserApproveOrReturn = React.useMemo(() => {
    if (!effectiveRole) return false;
    const isRoleAllowed = APPROVE_ALLOWED_ROLES.some(
      role => role.toLowerCase() === effectiveRole.toLowerCase()
    );
    const statusAllowsAction = currentSignOffStatus === "Pending Review";
    return isRoleAllowed && statusAllowsAction;
  }, [effectiveRole, currentSignOffStatus]);

  // ═══════════════════════════════════════════════════════════════
  // CHECK IF USER IS A DEALER (to show return comments)
  // ═══════════════════════════════════════════════════════════════
  const isDealer = React.useMemo(() => {
    if (!effectiveRole) return false;
    return SUBMIT_ALLOWED_ROLES.some(
      role => role.toLowerCase() === effectiveRole.toLowerCase()
    );
  }, [effectiveRole]);

  useEffect(() => {
    if (rowData?.signOffStatus) {
      setCurrentSignOffStatus(rowData.signOffStatus);
    }
  }, [rowData?.signOffStatus]);

  // ═══════════════════════════════════════════════════════════════
  // FETCH RETURN COMMENTS IF PDP WAS RETURNED
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const fetchReturnComments = async () => {
      if (!rowData?.id) return;
      
      try {
        const response = await getReturnComments(rowData.id);
        
        if (response && response.data && response.data.length > 0) {
          const latest = response.data[0];
          setReturnData({
            comments: latest.return_comments || latest.comments,
            returnedAt: latest.returned_at || latest.updated_at
          });
        }
      } catch (err) {
        // FIX 5: removed console.warn — use rowData fallback silently
        if (rowData?.returnComments || rowData?.return_back_comment) {
          setReturnData({
            comments: rowData.returnComments || rowData.return_back_comment
          });
        }
      }
    };
    
    // Fetch return comments if status indicates it was returned
    if (rowData?.id && currentSignOffStatus === "Started" && isDealer) {
      fetchReturnComments();
    }
  }, [rowData?.id, currentSignOffStatus, isDealer, rowData?.returnComments, rowData?.return_back_comment]);

  const toggleExpand = () => setIsExpanded(!isExpanded);

  const buttonData = [
    { label: "Equipment's" },
    { label: "Uptime & Parts" },
    { label: "Infrastructure" },
    { label: "Territory Focus" },
    // FIX 1: was "Competence " (trailing space) — never matched case "Competence Development"
    // causing the Competence tab to always show "No content available"
    { label: "Competence" },
    { label: "Marcom" },
    { label: "Upload Files" },
    { label: "PDP Final Sign Off" },
    { label: "Others" },
  ];

  // FIX 5: removed debug useEffect that only had console.log statements

  useEffect(() => {
    const fetchLatestSignoff = async () => {
      if (!rowData?.id) return;
      try {
        const signoffs = await getPdpSignoffsByPdpId(rowData.id);
        const signedOnes = signoffs.filter(s => s.isSigned === 1 || s.isSigned === true);
        if (signedOnes.length > 0) {
          const sorted = signedOnes.sort((a, b) => 
            new Date(b.signed_timestamp) - new Date(a.signed_timestamp)
          );
          const latest = sorted[0];
          setLatestSignoff({
            name: `${latest.user_first_name || ''} ${latest.user_last_name || ''}`.trim() || "Unknown",
            date: latest.signed_timestamp,
            designation: latest.user_persona || latest.category
          });
        }
      } catch (err) {
        // FIX 5: removed console.warn
      }
    };
    fetchLatestSignoff();
  }, [rowData?.id]);

  // ═══════════════════════════════════════════════════════════════
  // FORMAT DATES FOR DISPLAY
  // ═══════════════════════════════════════════════════════════════
  const formatMeetingDate = (dateString) => {
    if (!dateString) return null;
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return null;
      return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      });
    } catch {
      return null;
    }
  };

  const formatSignoffDate = (dateString) => {
    if (!dateString) return null;
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return null;
      return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      });
    } catch {
      return null;
    }
  };

  const signoffMeetingDate = rowData?.signoffMeetingDate || rowData?.sign_off_meeting_date;
  const formattedMeetingDate = formatMeetingDate(signoffMeetingDate);

  // FIX 9: localStorage key now includes rowData.id so it's PDP-specific
  // (prevents persisting the wrong tab when navigating between different PDP records)
  const tabStorageKey = `activePDPViewTab_${rowData?.id || 'default'}`;

  useEffect(() => {
    const fromNav = location.state?.activeTab;
    if (fromNav) {
      setActiveTab(fromNav);
      localStorage.setItem(tabStorageKey, fromNav);
    } else {
      const savedTab = localStorage.getItem(tabStorageKey);
      if (savedTab) setActiveTab(savedTab);
    }
  }, [location.state, tabStorageKey]);

  useEffect(() => {
    if (activeTab) localStorage.setItem(tabStorageKey, activeTab);
  }, [activeTab, tabStorageKey]);

  const handleBack = () => navigate("/pdp/view");

  const handleactionplanner = () => {
    navigate("/pdp/view/actionplannermanagemnet", { state: { rowData, activeTab } });
  };

  // FIX 8: was empty function with no user feedback
  const handledownloadpdpdetails = () => {
    alert("Download Summary feature is not yet available.");
  };

  // ═══════════════════════════════════════════════════════════════
  // SUBMIT PDP HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleSubmitClick = () => {
    if (!rowData?.id) {
      alert("PDP data not found!");
      return;
    }
    setShowSubmitPopup(true);
  };

  const handleConfirmSubmit = async () => {
    try {
      setIsSubmitting(true);
      await submitPDP({ pdpId: rowData.id });
      setCurrentSignOffStatus("Pending Review");
      setReturnData(null);
      setShowSubmitPopup(false);
      setSuccessMessage("PDP has been submitted successfully! The status has been changed to Pending Review.");
      setSuccessStatus("Pending Review");
      setShowSuccessPopup(true);
    } catch (error) {
      // FIX 5: removed console.error
      alert(error.message || "Failed to submit PDP. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // APPROVE PDP HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleApproveClick = () => {
    if (!rowData?.id) {
      alert("PDP data not found!");
      return;
    }
    setShowApprovePopup(true);
  };

  const handleConfirmApprove = async () => {
    try {
      setIsApproving(true);
      await approvePDP({ pdpId: rowData.id });
      setCurrentSignOffStatus("Approved");
      setShowApprovePopup(false);
      setSuccessMessage("PDP has been approved successfully!");
      setSuccessStatus("Approved");
      setShowSuccessPopup(true);
    } catch (error) {
      // FIX 5: removed console.error
      alert(error.message || "Failed to approve PDP. Please try again.");
    } finally {
      setIsApproving(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // RETURN PDP HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleReturnClick = () => {
    if (!rowData?.id) {
      alert("PDP data not found!");
      return;
    }
    setShowReturnPopup(true);
  };

  const handleConfirmReturn = async (comments) => {
    try {
      setIsReturning(true);
      await returnPDP({
        pdpId: rowData.id,
        comments: comments,
      });
      setCurrentSignOffStatus("Started");
      // FIX 4: immediately populate returnData so the banner shows without
      // waiting for the fetchReturnComments useEffect to re-run
      setReturnData({ comments });
      setShowReturnBanner(true);
      setShowReturnPopup(false);
      setSuccessMessage("PDP has been returned successfully. The dealer will be notified with your comments.");
      setSuccessStatus("Started");
      setShowSuccessPopup(true);
    } catch (error) {
      // FIX 5: removed console.error
      alert(error.message || "Failed to return PDP. Please try again.");
    } finally {
      setIsReturning(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // SUCCESS POPUP CLOSE HANDLER
  // ═══════════════════════════════════════════════════════════════
  const handleSuccessClose = () => {
    setShowSuccessPopup(false);
    setSuccessMessage("");
    setSuccessStatus("");
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "Equipment's":
        return <Equipment rowData={rowData} userRole={effectiveRole} />;
      case "Uptime & Parts":
        return <Uptimeparts rowData={rowData} userRole={effectiveRole} />;
      case "Infrastructure":
        return <Infrastructure rowData={rowData} userRole={effectiveRole} />;
      case "Territory Focus": 
        return <TerritoryFocus rowData={rowData} userRole={effectiveRole} />;
      case "Competence":
        return <CompetenceDevelopment rowData={rowData} userRole={effectiveRole} />;
      case "Marcom":
        return <Marcom rowData={rowData} userRole={effectiveRole} />;
      case "Upload Files":
        return <UploadFiles pdpId={rowData?.id} userRole={effectiveRole} />;
      case "PDP Final Sign Off":
        return <SignoffStatus rowData={rowData} userRole={effectiveRole} />;
      case "Others":
        return <Others rowData={rowData} userRole={effectiveRole} onDataReady={setOthersFilesData} />;
      default:
        return (
          <div className="text-center text-gray-500 mt-6">
            No content available for <b>{activeTab}</b>
          </div>
        );
    }
  };

  const handleUploadAndPreview = async () => {
    if (!othersFilesData || othersFilesData.length === 0) {
      alert("No files to process!");
      return;
    }
    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("Others");
      sheet.columns = [
        { header: "Sl. No", key: "slNo", width: 10 },
        { header: "File Name", key: "fileName", width: 40 },
        { header: "Optional Document", key: "optionalDoc", width: 30 },
        { header: "Document URL", key: "docUrl", width: 50 },
      ];
      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF476896" } };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
      othersFilesData.forEach((file, index) => {
        const row = sheet.addRow({
          slNo: index + 1,
          fileName: file.fileName,
          optionalDoc: file.optionalDoc ? file.optionalDoc.name : "No file",
          docUrl: file.optionalDoc?.url || "",
        });
        row.eachCell((cell) => {
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });
      });
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const file = new File([blob], "Others.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const response = await uploadTempFile(file);
      const fileUrl = response ? `https://view.officeapps.live.com/op/view.aspx?src=${response}` : null;
      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        alert("Upload succeeded but no preview available.");
      }
    } catch (error) {
      // FIX 5: removed console.error
      alert("Failed to generate preview.");
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "Completed": return "text-green";
      case "Approved": return "text-darkblue1";
      case "Pending Review": return "text-orange-600";
      case "Started": return "text-blue-500";
      case "Created": return "text-gray-500";
      default: return "text-SteelBlue1";
    }
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
        {/* Header */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between flex-wrap gap-4">
          <div className="flex flex-col w-full lg:w-auto">
            <div className="flex items-center gap-2">
              <ArrowLeft
                onClick={handleBack}
                size={24}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              />
              <h2 className="text-base font-semibold font-VolvoNovum text-darkblue1">
                Partnership Development Program (PDP) – {rowData?.year} Sign Off Sheet
              </h2>
            </div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-1/4 mt-0 ml-[6.5%]"></div>
          </div>

          {/* Action Buttons Area */}
          <div className="flex items-center gap-3 mt-2 lg:mt-0 flex-wrap">
            {/* SIGNOFF MEETING DATE or Latest Sign Off */}
            <span className="flex items-center text-black text-xs font-medium font-VolvoNovum">
              <span className="w-2 h-2 bg-darkblue1 rounded-full mr-2"></span>
              {formattedMeetingDate ? (
                <>
                  <Calendar size={14} className="mr-1 text-darkblue1" />
                  Signoff Meeting Date: {formattedMeetingDate}
                </>
              ) : latestSignoff ? (
                <>
                  Latest Sign Off: {latestSignoff.name}
                  {latestSignoff.designation && `, ${latestSignoff.designation}`}
                  {latestSignoff.date && ` - ${formatSignoffDate(latestSignoff.date)}`}
                </>
              ) : (
                "No Sign Offs Yet"
              )}
            </span>

            {/* SUBMIT BUTTON - For Dealer roles */}
            {canUserSubmit && (
              <button
                onClick={handleSubmitClick}
                className="flex items-center gap-2 px-4 py-1.5 text-xs font-medium bg-green text-white rounded hover:bg-green-700 transition-all duration-200 shadow-md hover:shadow-lg"
              >
                <Send size={14} />
                Submit PDP
              </button>
            )}

            {/* RETURN & APPROVE BUTTONS - For Admin/Manager roles */}
            {canUserApproveOrReturn && (
              <>
                <button
                  onClick={handleReturnClick}
                  className="flex items-center gap-2 px-4 py-1.5 text-xs font-medium bg-red text-white rounded hover:bg-red-600 transition-all duration-200 shadow-md hover:shadow-lg"
                >
                  <RotateCcw size={14} />
                  Return PDP
                </button>
                <button
                  onClick={handleApproveClick}
                  className="flex items-center gap-2 px-4 py-1.5 text-xs font-medium bg-blue text-white rounded hover:bg-blue-700 transition-all duration-200 shadow-md hover:shadow-lg"
                >
                  <ThumbsUp size={14} />
                  Approve PDP
                </button>
              </>
            )}

            
          </div>
        </div>

        {/* RETURN COMMENTS BANNER */}
        {isDealer && returnData && showReturnBanner && currentSignOffStatus === "Started" && (
          <div className="mt-4">
            <ReturnCommentsBanner 
              returnData={returnData} 
              onDismiss={() => setShowReturnBanner(false)}
            />
          </div>
        )}

        {/* Expand/Collapse Section */}
        <div className="relative w-full mt-2">
          {!isExpanded && (
            <div className="flex justify-end mb-2">
              <button
                onClick={toggleExpand}
                className="relative group flex items-center gap-1 p-1 text-sm font-medium bg-Dustyblue rounded-full hover:bg-gray-200 transition text-white"
              >
                <ChevronDown size={14} />
                <span className="absolute left-1/2 top-full -translate-x-1/2 mt-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap pointer-events-none z-50">
                  Expand
                </span>
              </button>
            </div>
          )}

          {isExpanded && (
            <div className="bg-white shadow-[0_4px_10px_#0000001A] p-2 space-y- relative">
              {/* PDP Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 text-center gap-2">
                {[
                  { title: "Year", value: rowData?.year },
                  { title: "Dealer", value: rowData?.dealer || rowData?.dealerName || rowData?.dealerShortName || rowData?.dealerFullName },
{ title: "PDP Start Date", value: formatDateOnly(rowData?.pdpstartdate) },
                 { title: "PDP End Date", value: formatDateOnly(rowData?.pdpenddate) },
{ title: "Physical PDP Start Date", value: formatDateOnly(rowData?.physicalpdpstartdate) },
{ title: "Physical PDP End Date", value: formatDateOnly(rowData?.physicalpdpenddate) },
                  { title: "Status", value: currentSignOffStatus, color: getStatusColor(currentSignOffStatus) },
                ].map((item, i) => (
                  <div
                    key={i}
                    className={`relative py-0 px-3 ${i < 6 ? "border-r border-darkblue1" : ""} flex flex-col items-center justify-center`}
                  >
                    <div className="text-xs font-medium text-black">{item.title}</div>
                    {item.title === "Status" ? (
                      <div className="flex items-center justify-center gap-2 mt-1">
                        <div className={`text-xs font-medium ${item.color || "text-SteelBlue1"}`}>
                          {item.value || "—"}
                        </div>
                        <button
                          onClick={toggleExpand}
                          className="relative group flex items-center justify-center bg-Dustyblue text-white rounded-full p-[3px] hover:bg-gray-200 hover:text-darkblue1 transition translate-x-[150%] translate-y-[-120%]"
                        >
                          <ChevronUp size={14} />
                          <span className="absolute left-1/2 top-full -translate-x-1/2 mt-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap pointer-events-none z-50">
                            Collapse
                          </span>
                        </button>
                      </div>
                    ) : (
                      <div className={`mt-1 text-xs font-medium ${item.color || "text-SteelBlue1"}`}>
                        {item.value || "—"}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="border-t border-SteelBlue/25 mt-2"></div>

              {/* Action Buttons */}
              <div className={`grid gap-2 mt-2 ${activeTab === "Others" ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-5" : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"}`}>
                {[
                  {
                    label: "Action Planner Management",
                    onClick: handleactionplanner,
                    icon: <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 29 29" fill="none"><path fillRule="evenodd" clipRule="evenodd" d="M19.8757 12.8866C22.454 12.8935 24.5365 14.9874 24.5293 17.5657L24.5097 24.5657L3.5098 24.5093L3.52285 19.8427C3.53005 17.2643 5.62424 15.1816 8.20252 15.1885L12.3325 15.1996C13.1414 13.8018 14.649 12.8725 16.3757 12.8772L19.8757 12.8866ZM19.8692 15.2199L16.3692 15.2105C15.0858 15.207 14.0329 16.2542 14.0293 17.5375L14.0163 22.2042L22.1829 22.2261L22.1959 17.5595C22.1995 16.2761 21.1525 15.2233 19.8692 15.2199ZM11.696 17.5313L8.196 17.5219C6.91271 17.5184 5.85978 18.5656 5.85619 19.849L5.84967 22.1822L11.6829 22.1979L11.696 17.5313ZM9.39205 7.02505C11.3217 7.03023 12.8876 8.6048 12.8823 10.5344C12.8769 12.4641 11.3021 14.0302 9.37248 14.025C7.44279 14.0198 5.87689 12.4453 5.88228 10.5156C5.88767 8.586 7.46235 7.01987 9.39205 7.02505ZM9.38594 9.21254C8.66259 9.2106 8.0718 9.79702 8.06977 10.5215C8.06775 11.246 8.65525 11.8356 9.3786 11.8375C10.1019 11.8395 10.6927 11.2531 10.6948 10.5286C10.6968 9.80407 10.1092 9.21449 9.38594 9.21254ZM18.1518 3.54856C20.4034 3.55461 22.23 5.39117 22.2237 7.64287C22.2174 9.89456 20.3806 11.7212 18.129 11.7152C15.8773 11.7091 14.0508 9.87257 14.0571 7.62093C14.0633 5.36924 15.9001 3.54252 18.1518 3.54856ZM18.1453 5.88191C17.1804 5.87932 16.3931 6.66235 16.3904 7.6272C16.3877 8.59199 17.1706 9.3793 18.1355 9.38189C19.1003 9.38449 19.8877 8.60139 19.8904 7.6366C19.8931 6.67175 19.1101 5.8845 18.1453 5.88191Z" fill="#212121"/></svg>
                  },
                  {
                    label: "Download PPT Template",
                    onClick: () => setIsPPTPopupOpen(true),
                    icon: <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none"><path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/><path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/><path d="M1 14.75H12" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
                  },
                  {
                    label: "Download Summary",
                    onClick: handledownloadpdpdetails,
                    icon: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 25 24" fill="none"><path d="M12.083 11.3347L12.0513 22.668M12.0513 22.668L16.0625 18.6788M12.0513 22.668L8.06253 18.6573M6.76634 5.36841C7.7632 5.51525 8.68572 5.98081 9.39598 6.69548M19.407 14.6877C21.4323 14.6932 22.7449 13.0554 22.7506 11.03C22.7527 10.2282 22.492 9.44777 22.0083 8.8083C21.5246 8.16884 20.8446 7.70558 20.0725 7.48949C19.9577 5.99379 19.3419 4.58054 18.3246 3.47824C17.3072 2.37593 15.9478 1.64901 14.4661 1.41498C12.9844 1.18095 11.467 1.4535 10.1592 2.18857C8.85148 2.92363 7.82981 4.07824 7.2594 5.46574C6.06757 5.1319 4.79187 5.2852 3.71296 5.89192C2.63406 6.49865 1.84031 7.50909 1.50634 8.70096C1.17237 9.89284 1.32553 11.1685 1.93214 12.2474C2.53874 13.3262 3.5491 14.1198 4.74094 14.4537" stroke="#212121" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/></svg>,
                  },
                  {
                    label: "Status Logs",
                    onClick: () => setShowStatusPopup(true),
                    icon: <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 33 33" fill="none"><path d="M29.1553 12.0792L29.1814 12.1541L29.2782 12.4778L29.3591 12.7683L29.3936 12.901L29.45 13.1412C30.1819 16.4875 29.6311 19.9868 27.9066 22.9468C26.1859 25.9159 23.4118 28.1297 20.135 29.1488L19.9039 29.2167L19.6203 29.2891L19.2103 29.3851C19.0655 29.4177 18.9155 29.4201 18.7698 29.3921C18.624 29.3641 18.4856 29.3064 18.3631 29.2225C18.2407 29.1386 18.1368 29.0304 18.0581 28.9046C17.9793 28.7788 17.9273 28.6381 17.9054 28.4914C17.8603 28.1901 17.9299 27.8828 18.1006 27.6305C18.2713 27.3781 18.5305 27.199 18.8269 27.1287L19.1568 27.0467C19.3627 26.9932 19.5398 26.9416 19.6881 26.8921C22.3199 26.0115 24.5396 24.2002 25.9304 21.7986C27.3293 19.3988 27.803 16.5706 27.2623 13.8461L27.2234 13.6672L27.1714 13.4585L27.1064 13.2194L27.0283 12.9507C26.9408 12.6574 26.9667 12.3421 27.1008 12.067C27.2349 11.792 27.4675 11.5774 27.7524 11.4657C27.8848 11.4138 28.0262 11.3885 28.1683 11.3913C28.3105 11.394 28.4507 11.4248 28.581 11.4818C28.7113 11.5387 28.8291 11.6208 28.9276 11.7233C29.0261 11.8259 29.1035 11.9468 29.1553 12.0792ZM4.27825 11.3941C4.63499 11.5309 4.86642 11.7449 4.99975 12.0189C5.13309 12.293 5.15858 12.6071 5.07119 12.8991C4.96736 13.2451 4.89227 13.5331 4.84592 13.7631C4.29245 16.4824 4.75089 19.3102 6.13512 21.7151C7.51367 24.1263 9.72595 25.9505 12.3557 26.8444L12.5304 26.9003L12.6297 26.9292L12.8524 26.9903L13.2487 27.0891C13.5464 27.16 13.8066 27.3402 13.9777 27.5939C14.1488 27.8477 14.2183 28.1565 14.1723 28.459C14.1292 28.7428 13.9751 28.9978 13.7441 29.1679C13.513 29.3381 13.2238 29.4096 12.94 29.3666L12.8612 29.3521L12.5323 29.2741L12.2411 29.199L11.9864 29.1269L11.8722 29.0923C8.60785 28.0529 5.85268 25.8259 4.15194 22.8521C2.44087 19.8777 1.91077 16.3686 2.66684 13.0212L2.71135 12.8385L2.76909 12.6244L2.88101 12.2447L2.92484 12.1019C2.96719 11.9665 3.03579 11.8408 3.12673 11.7319C3.21767 11.6231 3.32917 11.5332 3.45485 11.4674C3.58053 11.4016 3.71793 11.3612 3.85921 11.3486C4.00049 11.3359 4.14288 11.3518 4.27825 11.3941ZM16.1 6.90014C21.1497 6.9137 25.2314 11.0178 25.2173 16.0675C25.2032 21.1172 21.0986 25.1993 16.0489 25.1858C10.9992 25.1722 6.9175 21.0681 6.93162 16.0184C6.94574 10.9687 11.0509 6.88658 16.1 6.90014ZM16.0936 9.18585C12.3068 9.17568 9.22791 12.2377 9.21733 16.0245C9.20674 19.8114 12.2684 22.8899 16.0553 22.9001C19.8427 22.9102 22.921 19.8482 22.9316 16.0614C22.9421 12.2745 19.881 9.19602 16.0936 9.18585ZM16.1128 2.32873C19.5445 2.33374 22.8487 3.62886 25.3695 5.95703L25.5057 6.08711L25.6624 6.24411L25.8391 6.42858L26.0362 6.63997C26.1368 6.74908 26.2137 6.87775 26.2624 7.01795C26.311 7.15814 26.3302 7.30686 26.3188 7.45481C26.3074 7.60277 26.2656 7.74679 26.1961 7.87789C26.1265 8.00899 26.0307 8.12435 25.9146 8.21679C25.6763 8.40672 25.3752 8.50016 25.0712 8.4786C24.7672 8.45704 24.4824 8.32205 24.2733 8.10038C24.1494 7.96862 24.0345 7.85079 23.9285 7.74688L23.7291 7.55549L23.6379 7.47353C21.5597 5.63468 18.8815 4.61799 16.1064 4.61444C13.3288 4.60295 10.6426 5.60698 8.55333 7.43759L8.48802 7.4957L8.34307 7.63245L8.17861 7.79487L7.89493 8.08839C7.45936 8.54951 6.74264 8.59959 6.24718 8.20397C6.13606 8.11526 6.04351 8.00553 5.97483 7.88104C5.90614 7.75655 5.86266 7.61974 5.84687 7.47843C5.83108 7.33713 5.84329 7.19409 5.8828 7.0575C5.92231 6.9209 5.98835 6.79343 6.07714 6.68237L6.12874 6.62193L6.36086 6.37627L6.57175 6.16083C6.67183 6.06091 6.76427 5.97259 6.84906 5.89586C9.38113 3.58863 12.6868 2.31564 16.1122 2.32873" fill="#212121"/></svg>
                  },
                  ...(activeTab === "Others" ? [{
                    label: "Download",
                    icon: <Download size={16} />,
                    onClick: handleUploadAndPreview,
                    isSpecialDownload: true,
                  }] : []),
                ].map((btn, idx) => (
                  <button
                    key={idx}
                    onClick={btn.onClick}
                    className={`flex items-center justify-center gap-2 text-xs font-medium px-4 py-1.5 w-full transition ${
                      btn.isSpecialDownload
                        ? "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                        : "border border-darkblue1/30 bg-grayishblue text-black hover:bg-gray-200"
                    }`}
                  >
{btn.icon && btn.icon} 
      {btn.label}
                  
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Tab Buttons */}
        <div className="flex flex-col sm:flex-row w-full gap-2 mt-2">
          {buttonData.map((btn, idx) => {
            const isActive = activeTab === btn.label;
            return (
              <button
                key={idx}
                onClick={() => setActiveTab(btn.label)}
                className={`flex-1 flex items-center justify-center gap-1 py-2 px-2 border transition-all text-xs font-medium shadow-[0_4px_10px_#0000001A] ${
                  isActive ? "bg-Dustyblue text-white text-sm" : "bg-white text-black hover:bg-Dustyblue hover:text-white text-sm"
                }`}
              >
                {btn.label}
              </button>
            );
          })}
        </div>

        {/* Render Tab Content */}
        <div className="mt-4">{renderTabContent()}</div>
      </div>

      {/* Popups */}
      <StatusLogsPopup isOpen={showStatusPopup} onClose={() => setShowStatusPopup(false)} rowData={rowData} />
      <DownloadPPT isOpen={isPPTPopupOpen} onClose={() => setIsPPTPopupOpen(false)} />
      
      <SubmitConfirmationPopup
        isOpen={showSubmitPopup}
        onClose={() => setShowSubmitPopup(false)}
        onConfirm={handleConfirmSubmit}
        isSubmitting={isSubmitting}
      />
      
      <ApproveConfirmationPopup
        isOpen={showApprovePopup}
        onClose={() => setShowApprovePopup(false)}
        onConfirm={handleConfirmApprove}
        isProcessing={isApproving}
      />
      
      <ReturnConfirmationPopup
        isOpen={showReturnPopup}
        onClose={() => setShowReturnPopup(false)}
        onConfirm={handleConfirmReturn}
        isProcessing={isReturning}
      />
      
      <SuccessPopup
        isOpen={showSuccessPopup}
        onClose={handleSuccessClose}
        message={successMessage}
        statusText={successStatus}
      />
    </div>
  );
}

export default PDPViewdetails;