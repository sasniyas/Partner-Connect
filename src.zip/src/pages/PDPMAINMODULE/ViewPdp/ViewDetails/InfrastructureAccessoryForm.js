import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import StyledSelectField from "../../../../Components/StyledSelectField";
import {
  addPdpInfrastructureAsset,
  updatePdpInfrastructureAsset
} from "../../../../services/PDP/SubPDP/pdpInfrastructure/pdpInfrastructureAssets/pdpInfrastructureAssets.service";
import { useKeyboardNavigation } from "../../../../util/useKeyboardNavigation";
const InfrastructureAccessoryForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const location = useLocation();
  const isEditMode = Boolean(id);
  const [menuOpen, setMenuOpen] = useState(false);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fromRef=useRef(null)
  // Get data from navigation state
  const accessoryData = location.state?.accessoryData || null;
  const itemType = location.state?.itemType || "";
  const year = location.state?.year || "";
  const facilityDefinition = location.state?.facilityDefinition || "";
  const isAdmin = location.state?.isAdmin || false;
  const rowData = location.state?.rowData || {};
  const rowIndex = location.state?.rowIndex;
  const returnPath = location.state?.returnPath || "";
  const currentItems = location.state?.currentItems || [];
  const pdpInfrastructureId = location.state?.pdpInfrastructureId || rowData?.id;
  const pdpId = location.state?.pdpId || rowData?.pdpId;

  const [formData, setFormData] = useState({
    slNo: "",
    assetType: "",
    quantity: "",
    yearOfPurchase: "",
    available: "",
    assignedTo: ""
  });

  // Dropdown states
  const [isAssetTypeOpen, setIsAssetTypeOpen] = useState(false);
  const [isAvailableOpen, setIsAvailableOpen] = useState(false);

  // Refs for dropdowns
  const assetTypeRef = useRef(null);
  const availableRef = useRef(null);

  // Dropdown options
  const assetTypeOptions = ["Laptop", "Tab"];
  const availableOptions = ["Yes", "No"];

  // Load data if editing
  useEffect(() => {
    if (isEditMode && accessoryData) {
      setFormData({
        slNo: accessoryData.slNo || "",
        assetType: accessoryData.assetType || accessoryData.asset_type || "",
        quantity: accessoryData.quantity || "",
        yearOfPurchase: accessoryData.yearOfPurchase || accessoryData.yop || "",
        available: accessoryData.available || "",
        assignedTo: accessoryData.assignedTo || accessoryData.assigned_to || "",
      });
    }
  }, [isEditMode, accessoryData]);

  const handleBack = () => {
    if (returnPath) {
      navigate(returnPath, {
        state: {
          itemType,
          items: currentItems,
          rowIndex,
          year,
          facilityDefinition,
          isAdmin,
          rowData
        }
      });
    } else {
      navigate(-1);
    }
  };

  const handleChange = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
    
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    handleChange(name, value);
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.assetType) {
      newErrors.assetType = "Asset type is required";
    }

    if (!formData.quantity) {
      newErrors.quantity = "Quantity is required";
    } else if (isNaN(formData.quantity) || parseInt(formData.quantity) < 0) {
      newErrors.quantity = "Quantity must be a positive number";
    }

    if (formData.yearOfPurchase) {
      const yearNum = parseInt(formData.yearOfPurchase);
      const currentYear = new Date().getFullYear();
      if (yearNum < 1900 || yearNum > currentYear) {
        newErrors.yearOfPurchase = `Year must be between 1900 and ${currentYear}`;
      }
    }

    if (!formData.available) {
      newErrors.available = "Availability status is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    if (!pdpId || !pdpInfrastructureId) {
      alert("Missing required data. Please go back and try again.");
      return;
    }

    setIsSubmitting(true);

    try {
      if (isEditMode) {
        // Update existing accessory
        const updatePayload = {
          id: accessoryData.id,
          asset_type: formData.assetType,
          quantity: parseInt(formData.quantity),
          yop: formData.yearOfPurchase ? parseInt(formData.yearOfPurchase) : null,
          available: formData.available,
          assigned_to: formData.assignedTo || null
        };

        await updatePdpInfrastructureAsset(updatePayload);

        // Transform for UI
        const updatedAccessory = {
          id: accessoryData.id,
          assetType: formData.assetType,
          asset_type: formData.assetType,
          quantity: formData.quantity,
          yearOfPurchase: formData.yearOfPurchase,
          yop: formData.yearOfPurchase,
          available: formData.available,
          assignedTo: formData.assignedTo,
          assigned_to: formData.assignedTo,
          slNo: formData.slNo
        };

        alert("Accessory updated successfully!");
        
        navigate(returnPath, {
          state: {
            itemType,
            items: currentItems,
            rowIndex,
            year,
            facilityDefinition,
            isAdmin,
            rowData,
            updatedAccessory
          }
        });
      } else {
        // Add new accessory
        const addPayload = {
          pdpId: pdpId,
          pdpInfrastructureId: pdpInfrastructureId,
          asset_type: formData.assetType,
          quantity: parseInt(formData.quantity),
          yop: formData.yearOfPurchase ? parseInt(formData.yearOfPurchase) : null,
          available: formData.available,
          assigned_to: formData.assignedTo || null
        };

        await addPdpInfrastructureAsset(addPayload);

        // Transform for UI
        const newAccessory = {
          assetType: formData.assetType,
          asset_type: formData.assetType,
          quantity: formData.quantity,
          yearOfPurchase: formData.yearOfPurchase,
          yop: formData.yearOfPurchase,
          available: formData.available,
          assignedTo: formData.assignedTo,
          assigned_to: formData.assignedTo
        };

        alert("Accessory added successfully!");
        
        navigate(returnPath, {
          state: {
            itemType,
            items: currentItems,
            rowIndex,
            year,
            facilityDefinition,
            isAdmin,
            rowData,
            newAccessory: newAccessory
          }
        });
      }
    } catch (error) {
      console.error("Error saving accessory:", error);
      alert(error.message || "Failed to save accessory. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const getPageTitle = () => {
    const prefix = isEditMode ? "Edit" : "Add";
    return `${prefix} Accessory (${year})`;
  };
useKeyboardNavigation({
  containerRef:fromRef, // your popup div ref

  onSubmit: () => { 
     handleSubmit()
  },

  onCancel: () => {
handleBack()  },
});

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div className="flex items-center gap-2">
              <button
                onClick={handleBack}
               className="bg-darkblue1 text-white  font-medium p-2 rounded-md hover:bg-darkblue1/90 transition flex-shrink-0"
                           >
                             <ArrowLeft size={16} />
              </button>
              <div>
                <h1 className="text-base font-semibold text-darkblue1">
                  {getPageTitle()}
                </h1>
                <p className="text-sm text-gray-600 ">{facilityDefinition}</p>
              </div>
            </div>
          </div>

          {/* Form Container */}
          <div className="bg-white shadow-md border border-gray-300 p-6 ">
            <form 
            ref={fromRef}
            onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 ">
                {/* Asset Type */}
                <StyledSelectField
                  label="Asset Type"
                  placeholder="Select Type"
                  value={formData.assetType}
                  setValue={(val) => handleChange("assetType", val)}
                  options={assetTypeOptions}
                  dropdownOpen={isAssetTypeOpen}
                  setDropdownOpen={setIsAssetTypeOpen}
                  dropdownRef={assetTypeRef}
                  required
                  error={errors.assetType}
                />

                {/* Quantity */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-2">
                    Quantity <span className="text-red1">*</span>
                  </label>
                  <input
                    type="number"
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleInputChange}
                    min="0"
                    className={`w-full px-4 py-1.5 border text-xs  focus:outline-none focus:ring-2 text-sm ${
                      errors.quantity
                        ? "border-red-500 focus:ring-red-500"
                        : "border-black/30 focus:ring-darkblue1"
                    }`}
                    placeholder="Enter quantity"
                  />
                  {errors.quantity && (
                    <p className="text-red1 text-xs mt-1">{errors.quantity}</p>
                  )}
                </div>

                {/* Year of Purchase */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-2">
                    Year of Purchase
                  </label>
                  <input
                    type="number"
                    name="yearOfPurchase"
                    value={formData.yearOfPurchase}
                    onChange={handleInputChange}
                    min="1900"
                    max={new Date().getFullYear()}
                    className={`w-full px-4 py-1.5 border text-xs  focus:outline-none focus:ring-2 text-sm ${
                      errors.yearOfPurchase
                        ? "border-red-500 focus:ring-red-500"
                        : "border-black/30 focus:ring-darkblue1"
                    }`}
                    placeholder="Enter year"
                  />
                  {errors.yearOfPurchase && (
                    <p className="text-red1 text-xs mt-1">{errors.yearOfPurchase}</p>
                  )}
                </div>

                {/* Available */}
                <StyledSelectField
                  label="Available"
                  placeholder="Select Availability"
                  value={formData.available}
                  setValue={(val) => handleChange("available", val)}
                  options={availableOptions}
                  dropdownOpen={isAvailableOpen}
                  setDropdownOpen={setIsAvailableOpen}
                  dropdownRef={availableRef}
                  required
                  error={errors.available}
                />

                {/* Assigned To */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-2">
                    Assigned To
                  </label>
                  <input
                    type="text"
                    name="assignedTo"
                    value={formData.assignedTo}
                    onChange={handleInputChange}
                    className="w-full px-4 py-1.5 text-xs border border-black/30 focus:outline-none focus:ring-2 focus:ring-darkblue1 text-sm"
                    placeholder="Enter assigned person"
                  />
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex flex-wrap gap-4 justify-center lg:justify-end mt-6">
                <button
                  type="button"
                  className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium  hover:bg-mildBlue1 hover:scale-105 transition"
                  onClick={handleBack}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 18 20" fill="none">
<path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 transition ${
                    isSubmitting
                      ? "opacity-50 cursor-not-allowed"
                      : "hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                  }`}
                >
                  {isSubmitting ? (isEditMode ? "Updating..." : "Saving...") : (isEditMode ? "Update" : "Save")}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InfrastructureAccessoryForm;