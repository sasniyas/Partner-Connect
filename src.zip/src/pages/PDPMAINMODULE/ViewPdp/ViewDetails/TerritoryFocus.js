import { Download, Plus, Pencil, Trash2, Save, Lock } from "lucide-react";
import React, { useState, useEffect, useMemo, useCallback } from "react";
import Searchinput from "../../../../Components/Searchinput";
import { ChevronUp, ChevronDown,ChevronsUpDown , X } from "lucide-react";
import StyledSelectField from "../../../../Components/StyledSelectField";
import DeleteModal from "../../../../Components/DeleteModal";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
// ⭐ Import role helper functions
import { canEditData, isEditableStatus, isDealerRole } from "../../../../pages/constants/roles";
// ⭐ Import from existing services
import { getAllSegmentPriorities } from "../../../../services/pdpMaster/segmentPriority.service";
import { getBranchMasters } from "../../../../services/pdpMaster/branchMaster.service";
import { uploadTempFile } from "../../../../services/download/bluckDownload.service";
// ⭐ Import Territory Focus service (6 APIs)
import {
  getPdpTerritoryFocusByPdpId,
  addPdpTerritoryFocus,
  updatePdpTerritoryFocus,
  deletePdpTerritoryFocus,
  getPdpTerritoryFocusEntriesByTerritoryFocusId,
  updatePdpTerritoryFocusEntry,
  getPdpTerritoryFocusEntriesStatsByPdpId,
  updatePdpTerritoryFocusEntriesStats
} from "../../../../services/PDP/TerritoryFocusHyperlink/pdphyperTerritoryFocus.service";

const TerritoryFocus = ({ rowData, userRole }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [showTable, setShowTable] = useState(true);
  const [showBranchModal, setShowBranchModal] = useState(false);
  const [editingBranchIndex, setEditingBranchIndex] = useState(null);
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc" | null
const [expandedCell, setExpandedCell] = useState(null);
  // ⭐ Loading and error states
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState(null);
  const [hoveredCell, setHoveredCell] = useState(null);

  // ⭐ API data states
  const [segmentOptions, setSegmentOptions] = useState([]);
  const [branchMasterData, setBranchMasterData] = useState({});
  const [rawBranchMasters, setRawBranchMasters] = useState([]);
  
  // Editable targets state
  const [targetValues, setTargetValues] = useState({});
  const [isEditingTargets, setIsEditingTargets] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [sortKey1, setSortKey1] = useState(null);
const [sortOrder1, setSortOrder1] = useState(null);
const [hoveredCell1, setHoveredCell1] = useState(null);


  // ⭐ Delete modal state
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteIndex, setDeleteIndex] = useState(null);
  
  // ⭐ Local state for Fill Target popup values (stored locally per branch)
  const [fillTargetData, setFillTargetData] = useState({});
  
  // ⭐ State for the entry data fetched from API
  const [selectedEntryData, setSelectedEntryData] = useState(null);
  
  // ⭐ State for stats data (Territory Focus Targets table)
  const [statsData, setStatsData] = useState(null);
  
  // Local state for editable values in Fill Target popup
  const [LsValues, setLSValues] = useState({
    GPE: "",
    RM: "",
    SDLG: "",
    BREAKER: "",
  });

  const totalLS = 
    Number(LsValues.GPE || 0) +
    Number(LsValues.RM || 0) +
    Number(LsValues.SDLG || 0) +
    Number(LsValues.BREAKER || 0);

  const [CyValues, setCYValues] = useState({
    GPE: "",
    RM: "",
    SDLG: "",
    BREAKER: "",
  });

  const totalCY = 
    Number(CyValues.GPE || 0) +
    Number(CyValues.RM || 0) +
    Number(CyValues.SDLG || 0) +
    Number(CyValues.BREAKER || 0);

  const resetFillEntryFields = () => {
    setLSValues({ GPE: "", RM: "", SDLG: "", BREAKER: "" });
    setCYValues({ GPE: "", RM: "", SDLG: "", BREAKER: "" });
    setSelectedEntryData(null);
  };

  // ⭐ Extract PDP ID and Status
  const pdpId = rowData?.id || null;
  const selectedYear = Number(rowData?.year) || new Date().getFullYear();
  const pdpStatus = rowData?.signOffStatus || rowData?.sign_of_status || "Created";

  // ⭐ FIXED: Check if user can edit (considers both role AND status)
  const canEdit = canEditData(userRole, pdpStatus);
  
  // ⭐ NEW: Check if user is a dealer but editing is locked due to status
  const isStatusLocked = isDealerRole(userRole) && !isEditableStatus(pdpStatus);
  
  // ⭐ Keep isAdmin for backward compatibility (view-only checks)
  const isAdmin = userRole === "Administrator" || 
                  userRole === "Head Of Channel Developement (Region India)" ||
                  userRole === "Uptime & Parts Manager" ||
                  userRole === "Market Area Head";

  // Territory focus metrics
  const territoryMetrics = [
    "EOY Dealer Achievement",
    "PDP Target Volume",
    "Achievement %",
    "Estimated Market Volume",
    "Estimated Market Share %"
  ];

  const METRIC_INDEX = {
    EOY_DEALER_ACHIEVEMENT: 0,
    PDP_TARGET_VOLUME: 1,
    ACHIEVEMENT_PERCENT: 2,
    ESTIMATED_MARKET_VOLUME: 3,
    ESTIMATED_MARKET_SHARE_PERCENT: 4
  };

  // Branch data from API
  const [branchData, setBranchData] = useState([]);

  // ⭐ Transform branch masters to organized structure with IDs
  const organizeBranchMasters = (rawData) => {
    const organized = {};
    
    rawData.forEach(item => {
      const city = item.city_name || item.city || "";
      const branch = item.branch_name || "";
      const districts = item.districts || [];
      
      if (!organized[city]) {
        organized[city] = {
          branches: {}
        };
      }
      
      if (!organized[city].branches[branch]) {
        organized[city].branches[branch] = {
          id: item.id,
          districtsString: Array.isArray(districts) 
            ? districts.map(d => d.district_name).join(", ")
            : districts
        };
      }
    });
    
    return organized;
  };

  // ⭐ Calculate EOY Dealer Achievement totals from fillTargetData
  const calculateEOYTotals = () => {
    const totals = {
      [selectedYear - 1]: { GPE: 0, RM: 0, SDLG: 0, Breaker: 0 },
      [selectedYear]: { GPE: 0, RM: 0, SDLG: 0, Breaker: 0 }
    };

    Object.values(fillTargetData).forEach(data => {
      totals[selectedYear - 1].GPE += Number(data.py_gpe || 0);
      totals[selectedYear - 1].RM += Number(data.py_rm || 0);
      totals[selectedYear - 1].SDLG += Number(data.py_sdlg || 0);
      totals[selectedYear - 1].Breaker += Number(data.py_breaker || 0);
    });

    console.log("📊 Calculated EOY Totals:", totals);
    return totals;
  };

  // ⭐ Calculate PDP Target Volume totals from fillTargetData (vtv_* values)
  const calculatePDPTargetTotals = () => {
    const totals = { GPE: 0, RM: 0, SDLG: 0, Breaker: 0 };

    Object.values(fillTargetData).forEach(data => {
      totals.GPE += Number(data.cy_gpe || 0);
      totals.RM += Number(data.cy_rm || 0);
      totals.SDLG += Number(data.cy_sdlg || 0);
      totals.Breaker += Number(data.cy_breaker || 0);
    });

    console.log("📊 Calculated PDP Target Totals (from vtv_*):", totals);
    return totals;
  };

  // ⭐ Get Total Plan for a specific branch from fillTargetData
  const getTotalPlanForBranch = (branchId) => {
    const data = fillTargetData[branchId];
    if (data) {
      return Number(data.cy_gpe || 0) + Number(data.cy_rm || 0) + 
             Number(data.cy_sdlg || 0) + Number(data.cy_breaker || 0);
    }
    return 0;
  };
const handleSort1 = (key) => {
  if (sortKey1 === key) {
    if (sortOrder1 === "asc") {
      setSortOrder1("desc");
    } else if (sortOrder1 === "desc") {
      setSortKey1(null);
      setSortOrder1(null);
    } else {
      setSortOrder1("asc");
    }
  } else {
    setSortKey1(key);
    setSortOrder1("asc");
  }
};

  // ⭐ Update target values with EOY totals AND PDP Target Volume from vtv_*
  const updateEOYTargetValues = () => {
    const eoyTotals = calculateEOYTotals();
    const pdpTargetTotals = calculatePDPTargetTotals();
    
    setTargetValues(prev => {
      const updated = { ...prev };
      
      ['GPE', 'RM', 'SDLG', 'Breaker'].forEach(category => {
        const pyKey = `${METRIC_INDEX.EOY_DEALER_ACHIEVEMENT}-${category}-${selectedYear - 1}`;
        updated[pyKey] = eoyTotals[selectedYear - 1][category].toString();
        
        const cyKey = `${METRIC_INDEX.EOY_DEALER_ACHIEVEMENT}-${category}-${selectedYear}`;
        updated[cyKey] = eoyTotals[selectedYear][category].toString();
      });
      
      const pyTotal = Object.values(eoyTotals[selectedYear - 1]).reduce((sum, val) => sum + val, 0);
      const cyTotal = Object.values(eoyTotals[selectedYear]).reduce((sum, val) => sum + val, 0);
      
      updated[`${METRIC_INDEX.EOY_DEALER_ACHIEVEMENT}-Total-${selectedYear - 1}`] = pyTotal.toString();
      updated[`${METRIC_INDEX.EOY_DEALER_ACHIEVEMENT}-Total-${selectedYear}`] = cyTotal.toString();
      
      ['GPE', 'RM', 'SDLG', 'Breaker'].forEach(category => {
        const cyPdpKey = `${METRIC_INDEX.PDP_TARGET_VOLUME}-${category}-${selectedYear}`;
        const value = pdpTargetTotals[category];
        updated[cyPdpKey] = value > 0 ? value.toString() : "";
      });
      
      const cyPdpTotal = Object.values(pdpTargetTotals).reduce((sum, val) => sum + val, 0);
      updated[`${METRIC_INDEX.PDP_TARGET_VOLUME}-Total-${selectedYear}`] = cyPdpTotal > 0 ? cyPdpTotal.toString() : "";
      
      console.log("✅ EOY and PDP Target Values Updated");
      return updated;
    });
  };

  // ⭐⭐⭐ NEW: Refresh territory focus data from server
  const refreshTerritoryFocusData = useCallback(async () => {
    if (!pdpId) return;

    try {
      console.log("🔄 Refreshing territory focus data...");
      
      // Fetch fresh data from server
      const territoryData = await getPdpTerritoryFocusByPdpId(pdpId);
      console.log("✅ Territory Focus data refreshed:", territoryData.length, "records");
      
      setBranchData(territoryData);

      // Fetch entries for each territory focus to populate EOY data
      const entriesPromises = territoryData.map(async (item) => {
        try {
          const entries = await getPdpTerritoryFocusEntriesByTerritoryFocusId(item.id);
          if (entries && entries.length > 0) {
            const entry = entries[0];
            return {
              territoryFocusId: item.id,
              data: {
                py_gpe: entry.py_fvsv_gpe || 0,
                py_rm: entry.py_fvsv_rm || 0,
                py_sdlg: entry.py_fvsv_sdlg || 0,
                py_breaker: entry.py_fvsv_breaker || 0,
                py_total: entry.py_fvsv_expectedClosure || 0,
                cy_gpe: entry.vtv_gpe || 0,
                cy_rm: entry.vtv_rm || 0,
                cy_sdlg: entry.vtv_sdlg || 0,
                cy_breaker: entry.vtv_breaker || 0,
                cy_total: entry.vtv_total_plan || 0
              }
            };
          }
          return null;
        } catch (error) {
          console.warn(`⚠️ No entries found for territory focus ${item.id}`);
          return null;
        }
      });

      const entriesResults = await Promise.all(entriesPromises);
      
      const newFillTargetData = {};
      entriesResults.forEach(result => {
        if (result) {
          newFillTargetData[result.territoryFocusId] = result.data;
        }
      });
      
      console.log("✅ Entries refreshed:", Object.keys(newFillTargetData).length, "records");
      setFillTargetData(newFillTargetData);

      return territoryData;
    } catch (error) {
      console.error("❌ Error refreshing data:", error);
      throw error;
    }
  }, [pdpId]);

  // ⭐ Handle Fill Target button click - fetches entry data from API
  const handleFillEntries = async (item) => {
    // ⭐ NEW: Check edit permission
    if (!canEdit) {
      console.warn("⚠️ Cannot fill entries: editing is disabled for status", pdpStatus);
      return;
    }

    try {
      setIsSaving(true);
      setSelectedEntry(item);
      
      // Fetch entries for this territory focus from API
      const entries = await getPdpTerritoryFocusEntriesByTerritoryFocusId(item.id);
      
      console.log("📥 Fetched entries:", entries);
      
      // Get first entry (should only be one entry per territory focus)
      const entryData = entries.length > 0 ? entries[0] : null;
      setSelectedEntryData(entryData);
      
      // Pre-fill with existing values from API
      if (entryData) {
        setLSValues({
          GPE: entryData.py_fvsv_gpe || "",
          RM: entryData.py_fvsv_rm || "",
          SDLG: entryData.py_fvsv_sdlg || "",
          BREAKER: entryData.py_fvsv_breaker || "",
        });
        setCYValues({
          GPE: entryData.vtv_gpe || "",
          RM: entryData.vtv_rm || "",
          SDLG: entryData.vtv_sdlg || "",
          BREAKER: entryData.vtv_breaker || "",
        });
      } else {
        // No entry exists yet, start with empty values
        resetFillEntryFields();
      }
      
      setShowPopup(true);
    } catch (error) {
      console.error("❌ Error fetching entries:", error);
      // Still open popup with empty values if fetch fails
      setSelectedEntryData(null);
      resetFillEntryFields();
      setShowPopup(true);
    } finally {
      setIsSaving(false);
    }
  };

  // ⭐ Fetch initial data
  useEffect(() => {
    const fetchInitialData = async () => {
      if (!pdpId) {
        console.error("❌ PDP ID is missing");
        setError("PDP ID is required");
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);

        console.log("🔄 Fetching Territory Focus data...");
        console.log("  PDP ID:", pdpId);
        console.log("  PDP Status:", pdpStatus);

        // Fetch all data in parallel
        const [territoryData, segmentsResponse, branchMastersResponse, statsResponse] = await Promise.all([
          getPdpTerritoryFocusByPdpId(pdpId),
          getAllSegmentPriorities(),
          getBranchMasters(),
          getPdpTerritoryFocusEntriesStatsByPdpId(pdpId).catch(err => {
            console.warn("⚠️ No stats found:", err.message);
            return null;
          })
        ]);

        console.log("✅ Territory Focus data loaded:", territoryData.length, "records");
        
        if (territoryData.length > 0) {
          console.log("📦 Sample branch data:", territoryData[0]);
        }

        setBranchData(territoryData);

        // ⭐ Store stats data
        if (statsResponse) {
          console.log("✅ Stats data loaded:", statsResponse);
          setStatsData(statsResponse);
        }

        // ⭐ Fetch entries for each territory focus to populate EOY data
        console.log("🔄 Fetching entries for each territory focus...");
        const entriesPromises = territoryData.map(async (item) => {
          try {
            const entries = await getPdpTerritoryFocusEntriesByTerritoryFocusId(item.id);
            if (entries && entries.length > 0) {
              const entry = entries[0];
              return {
                territoryFocusId: item.id,
                data: {
                  py_gpe: entry.py_fvsv_gpe || 0,
                  py_rm: entry.py_fvsv_rm || 0,
                  py_sdlg: entry.py_fvsv_sdlg || 0,
                  py_breaker: entry.py_fvsv_breaker || 0,
                  py_total: entry.py_fvsv_expectedClosure || 0,
                  cy_gpe: entry.vtv_gpe || 0,
                  cy_rm: entry.vtv_rm || 0,
                  cy_sdlg: entry.vtv_sdlg || 0,
                  cy_breaker: entry.vtv_breaker || 0,
                  cy_total: entry.vtv_total_plan || 0
                }
              };
            }
            return null;
          } catch (error) {
            console.warn(`⚠️ No entries found for territory focus ${item.id}`);
            return null;
          }
        });

        const entriesResults = await Promise.all(entriesPromises);
        
        // Build fillTargetData from fetched entries
        const initialFillTargetData = {};
        entriesResults.forEach(result => {
          if (result) {
            initialFillTargetData[result.territoryFocusId] = result.data;
          }
        });
        
        console.log("✅ Entries loaded for EOY calculation:", Object.keys(initialFillTargetData).length, "records");
        setFillTargetData(initialFillTargetData);

        // ⭐ Fetch stats for Territory Focus Targets table
        try {
          const stats = await getPdpTerritoryFocusEntriesStatsByPdpId(pdpId);
          console.log("✅ Stats data loaded:", stats);
          setStatsData(stats);
        } catch (statsError) {
          console.warn("⚠️ No stats found for this PDP:", statsError.message);
          setStatsData(null);
        }

        // Process segment options
        const segmentsArray = Array.isArray(segmentsResponse) 
          ? segmentsResponse 
          : (segmentsResponse?.data || []);
        
        const segments = segmentsArray
          .filter(s => s.isActive !== 0)
          .map(s => ({
            id: s.id,
            name: s.segment_focus_area
          }));
        
        console.log("✅ Segment options loaded:", segments.length);
        setSegmentOptions(segments);

        // Process branch masters
        const branchMastersArray = Array.isArray(branchMastersResponse) 
          ? branchMastersResponse 
          : (branchMastersResponse?.data || []);
        
        console.log("✅ Branch masters loaded:", branchMastersArray.length);
        setRawBranchMasters(branchMastersArray);
        
        const organized = organizeBranchMasters(branchMastersArray);
        setBranchMasterData(organized);
        console.log("✅ Branch masters organized:", Object.keys(organized).length, "cities");

      } catch (error) {
        console.error("❌ Error fetching data:", error);
        setError(error.message || "Failed to load territory focus data");
      } finally {
        setIsLoading(false);
      }
    };

    fetchInitialData();
  }, [pdpId]);

  // ⭐ Initialize target values
  useEffect(() => {
    const initialValues = {};
    
    territoryMetrics.forEach((metric, metricIdx) => {
      ['GPE', 'RM', 'SDLG', 'Breaker', 'Total'].forEach(category => {
        [selectedYear - 1, selectedYear].forEach(year => {
          const key = `${metricIdx}-${category}-${year}`;
          if (!(key in initialValues)) {
            initialValues[key] = "";
          }
        });
      });
    });
    
    setTargetValues(initialValues);
  }, [selectedYear]);

  // ⭐ Populate stats data into targetValues when statsData is loaded
  useEffect(() => {
    if (statsData && Object.keys(targetValues).length > 0) {
      console.log("🔄 Populating stats data into target values...");
      
      setTargetValues(prev => {
        const updated = { ...prev };
        
        // PDP Target Volume (METRIC_INDEX = 1) - Previous Year (selectedYear - 1) from stats API
        updated[`${METRIC_INDEX.PDP_TARGET_VOLUME}-GPE-${selectedYear - 1}`] = statsData.py_gpe_pvtv?.toString() || "";
        updated[`${METRIC_INDEX.PDP_TARGET_VOLUME}-RM-${selectedYear - 1}`] = statsData.py_rm_pvtv?.toString() || "";
        updated[`${METRIC_INDEX.PDP_TARGET_VOLUME}-SDLG-${selectedYear - 1}`] = statsData.py_sdlg_pvtv?.toString() || "";
        updated[`${METRIC_INDEX.PDP_TARGET_VOLUME}-Breaker-${selectedYear - 1}`] = statsData.py_breaker_pvtv?.toString() || "";
        
        // Calculate PDP Target Volume Total for Previous Year
        const pyPvtvTotal = (statsData.py_gpe_pvtv || 0) + (statsData.py_rm_pvtv || 0) + 
                           (statsData.py_sdlg_pvtv || 0) + (statsData.py_breaker_pvtv || 0);
        updated[`${METRIC_INDEX.PDP_TARGET_VOLUME}-Total-${selectedYear - 1}`] = pyPvtvTotal > 0 ? pyPvtvTotal.toString() : "";
        
        // Estimated Market Volume (METRIC_INDEX = 3) - Previous Year (selectedYear - 1)
        updated[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-GPE-${selectedYear - 1}`] = statsData.py_gpe_etmv?.toString() || "";
        updated[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-RM-${selectedYear - 1}`] = statsData.py_rm_etmv?.toString() || "";
        updated[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-SDLG-${selectedYear - 1}`] = statsData.py_sdlg_etmv?.toString() || "";
        updated[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-Breaker-${selectedYear - 1}`] = statsData.py_breaker_etmv?.toString() || "";
        
        // Calculate Estimated Market Volume Total for Previous Year
        const pyEtmvTotal = (statsData.py_gpe_etmv || 0) + (statsData.py_rm_etmv || 0) + 
                           (statsData.py_sdlg_etmv || 0) + (statsData.py_breaker_etmv || 0);
        updated[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-Total-${selectedYear - 1}`] = pyEtmvTotal > 0 ? pyEtmvTotal.toString() : "";
        
        // Estimated Market Volume - Current Year (selectedYear)
        updated[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-GPE-${selectedYear}`] = statsData.gpe_etmv?.toString() || "";
        updated[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-RM-${selectedYear}`] = statsData.rm_etmv?.toString() || "";
        updated[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-SDLG-${selectedYear}`] = statsData.sdlg_etmv?.toString() || "";
        updated[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-Breaker-${selectedYear}`] = statsData.breaker_etmv?.toString() || "";
        
        // Calculate Estimated Market Volume Total for Current Year
        const cyEtmvTotal = (statsData.gpe_etmv || 0) + (statsData.rm_etmv || 0) + 
                           (statsData.sdlg_etmv || 0) + (statsData.breaker_etmv || 0);
        updated[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-Total-${selectedYear}`] = cyEtmvTotal > 0 ? cyEtmvTotal.toString() : "";
        
        console.log("✅ Stats data populated into target values");
        return updated;
      });
    }
  }, [statsData, selectedYear]);

  // ⭐ Recalculate EOY totals and PDP Target Volume whenever fillTargetData changes
  useEffect(() => {
    if (Object.keys(targetValues).length > 0) {
      console.log("🔄 Recalculating EOY totals and PDP Target Volume from fillTargetData...");
      updateEOYTargetValues();
    }
  }, [fillTargetData, selectedYear]);

  const calculatedValues = useMemo(() => {
    const calculated = {};
    
    ["GPE", "RM", "SDLG", "Breaker", "Total"].forEach((category) => {
      [selectedYear - 1, selectedYear].forEach((year) => {
        const eoyKey = `${METRIC_INDEX.EOY_DEALER_ACHIEVEMENT}-${category}-${year}`;
        const pdpKey = `${METRIC_INDEX.PDP_TARGET_VOLUME}-${category}-${year}`;
        const marketVolKey = `${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-${category}-${year}`;
        
        const eoyValue = Number(targetValues[eoyKey] || 0);
        const pdpValue = Number(targetValues[pdpKey] || 0);
        const marketVolValue = Number(targetValues[marketVolKey] || 0);
        
        const achievementKey = `${METRIC_INDEX.ACHIEVEMENT_PERCENT}-${category}-${year}`;
        if (pdpValue > 0) {
          calculated[achievementKey] = ((eoyValue / pdpValue) * 100).toFixed(1);
        } else {
          calculated[achievementKey] = "-";
        }
        
        const marketShareKey = `${METRIC_INDEX.ESTIMATED_MARKET_SHARE_PERCENT}-${category}-${year}`;
        if (marketVolValue > 0) {
          calculated[marketShareKey] = ((pdpValue / marketVolValue) * 100).toFixed(1);
        } else {
          calculated[marketShareKey] = "-";
        }
      });
    });
    
    return calculated;
  }, [targetValues, selectedYear]);

  const getDisplayValue = (metricIdx, category, year) => {
    const key = `${metricIdx}-${category}-${year}`;
    
    if (metricIdx === METRIC_INDEX.ACHIEVEMENT_PERCENT || 
        metricIdx === METRIC_INDEX.ESTIMATED_MARKET_SHARE_PERCENT) {
      return calculatedValues[key] || "-";
    }
    
    return targetValues[key] || "-";
  };

  // ⭐ Save Fill Target entries - calls updatePdpTerritoryFocusEntry API
  const handleSaveFillEntries = async () => {
    if (!selectedEntry?.id) {
      alert("No entry selected");
      return;
    }

    if (!selectedEntryData?.id) {
      alert("No entry data found. Entry may not exist yet.");
      return;
    }

    // ⭐ NEW: Double-check edit permission before saving
    if (!canEdit) {
      alert(`❌ Cannot save. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      return;
    }

    try {
      setIsSaving(true);

      // Prepare data for API
      const entryData = {
        py_fvsv_gpe: parseFloat(LsValues.GPE) || 0,
        py_fvsv_rm: parseFloat(LsValues.RM) || 0,
        py_fvsv_sdlg: parseFloat(LsValues.SDLG) || 0,
        py_fvsv_breaker: parseFloat(LsValues.BREAKER) || 0,
        py_fvsv_expectedClosure: totalLS,
        vtv_gpe: parseFloat(CyValues.GPE) || 0,
        vtv_rm: parseFloat(CyValues.RM) || 0,
        vtv_sdlg: parseFloat(CyValues.SDLG) || 0,
        vtv_breaker: parseFloat(CyValues.BREAKER) || 0,
        vtv_total_plan: totalCY
      };

      console.log("💾 Saving fill entries:", entryData);

      // Call API to update entry
      await updatePdpTerritoryFocusEntry(selectedEntryData.id, entryData);

      // ⭐ Update local state for EOY calculations
      setFillTargetData(prev => ({
        ...prev,
        [selectedEntry.id]: {
          py_gpe: parseFloat(LsValues.GPE) || 0,
          py_rm: parseFloat(LsValues.RM) || 0,
          py_sdlg: parseFloat(LsValues.SDLG) || 0,
          py_breaker: parseFloat(LsValues.BREAKER) || 0,
          py_total: totalLS,
          cy_gpe: parseFloat(CyValues.GPE) || 0,
          cy_rm: parseFloat(CyValues.RM) || 0,
          cy_sdlg: parseFloat(CyValues.SDLG) || 0,
          cy_breaker: parseFloat(CyValues.BREAKER) || 0,
          cy_total: totalCY
        }
      }));

      // ⭐ Update branch data with new totalPlan
      setBranchData(prev => prev.map(item => 
        item.id === selectedEntry.id 
          ? { ...item, totalPlan: totalCY }
          : item
      ));

      setShowPopup(false);
      setSelectedEntryData(null);
      resetFillEntryFields();

    } catch (error) {
      console.error("❌ Error saving fill entries:", error);
      alert(`❌ Failed to save: ${error.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Filter branch data
  const filteredBranchData = branchData.filter(item =>
    Object.values(item).some(val =>
      String(val).toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const filteredMetrics = territoryMetrics.filter(metric =>
    metric.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const sortedData1 = useMemo(() => {
  if (!sortKey1 || !sortOrder1) return filteredMetrics;

  return [...filteredMetrics].sort((a, b) => {

    // ⭐ SORT BY METRIC NAME
    if (sortKey1 === "metric") {
      return sortOrder1 === "asc"
        ? a.localeCompare(b)
        : b.localeCompare(a);
    }

    const metricIdxA = territoryMetrics.indexOf(a);
    const metricIdxB = territoryMetrics.indexOf(b);

    const [category, year] = sortKey1.split("-");

    const valA = Number(getDisplayValue(metricIdxA, category, year)) || 0;
    const valB = Number(getDisplayValue(metricIdxB, category, year)) || 0;

    return sortOrder1 === "asc"
      ? valA - valB
      : valB - valA;
  });

}, [filteredMetrics, sortKey1, sortOrder1, targetValues, calculatedValues]);
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    }
    if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};

const filteredAndSortedBranchData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredBranchData;

  return [...filteredBranchData].sort((a, b) => {
    const valA = (a[sortKey] ?? "").toString().toLowerCase();
    const valB = (b[sortKey] ?? "").toString().toLowerCase();

    return sortOrder === "asc"
      ? valA.localeCompare(valB)
      : valB.localeCompare(valA);
  });
}, [filteredBranchData, sortKey, sortOrder]);

  const handleDownload = async () => {
    if (!filteredBranchData.length && !filteredMetrics.length) {
      alert("No data available to generate preview");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();

      /* =========================================================
         🟢 SHEET 1 : TERRITORY FOCUS DETAILS
      ========================================================= */
      const sheet1 = workbook.addWorksheet("Territory Focus");

      sheet1.columns = [
        { header: "City", key: "city", width: 20 },
        { header: "Branch", key: "branch", width: 20 },
        { header: "Districts", key: "districts", width: 35 },
        { header: "1st Segment Priority", key: "first", width: 20 },
        { header: "2nd Segment Priority", key: "second", width: 20 },
        { header: "3rd Segment Priority", key: "third", width: 20 },
        { header: "4th Segment Priority", key: "fourth", width: 20 },
        { header: "Overall Focus", key: "overall", width: 20 },
        { header: "Responsible Person", key: "person", width: 25 },
        { header: `Total Plan ${selectedYear}`, key: "total", width: 18 },
      ];

      // Header style
       sheet1.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      // District formatter
      const formatDistricts = (districts) => {
        if (Array.isArray(districts)) {
          return districts.map(d => d?.district_name || d).join(", ");
        }
        if (typeof districts === "string") return districts;
        return "";
      };

      filteredBranchData.forEach(item => {
        sheet1.addRow({
          city: item.city || "-",
          branch: item.branch || "-",
          districts: formatDistricts(item.districts),
          first: item.firstSegment || "-",
          second: item.secondSegment || "-",
          third: item.thirdSegment || "-",
          fourth: item.fourthSegment || "-",
          overall: item.overallFocus || "-",
          person: item.responsiblePerson || "-",
          total:
            getTotalPlanForBranch?.(item.id) ??
            item.totalPlan ??
            0,
        });
      });

      sheet1.views = [{ state: "frozen", ySplit: 1 }];

      /* =========================================================
         🟣 SHEET 2 : TERRITORY METRICS
      ========================================================= */
      const sheet2 = workbook.addWorksheet("Territory Metrics");

      sheet2.columns = [
        { header: "Territory Focus", key: "focus", width: 30 },

        { header: `GPE ${selectedYear - 1}`, key: "gpe_py", width: 15 },
        { header: `GPE ${selectedYear}`, key: "gpe_cy", width: 15 },

        { header: `RM ${selectedYear - 1}`, key: "rm_py", width: 15 },
        { header: `RM ${selectedYear}`, key: "rm_cy", width: 15 },

        { header: `SDLG ${selectedYear - 1}`, key: "sdlg_py", width: 15 },
        { header: `SDLG ${selectedYear}`, key: "sdlg_cy", width: 15 },

        { header: `Attachments ${selectedYear - 1}`, key: "br_py", width: 15 },
        { header: `Attachments ${selectedYear}`, key: "br_cy", width: 15 },

        { header: `Total ${selectedYear - 1}`, key: "tot_py", width: 15 },
        { header: `Total ${selectedYear}`, key: "tot_cy", width: 15 },
      ];

      sheet2.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      const cleanValue = (val) => {
        if (val === "-" || val === "" || val == null) return "";
        if (typeof val === "string" && val.includes("%")) {
          return Number(val.replace("%", ""));
        }
        return val;
      };

      filteredMetrics.forEach((metric, metricIdx) => {
        sheet2.addRow({
          focus: metric,

          gpe_py: cleanValue(getDisplayValue(metricIdx, "GPE", selectedYear - 1)),
          gpe_cy: cleanValue(getDisplayValue(metricIdx, "GPE", selectedYear)),

          rm_py: cleanValue(getDisplayValue(metricIdx, "RM", selectedYear - 1)),
          rm_cy: cleanValue(getDisplayValue(metricIdx, "RM", selectedYear)),

          sdlg_py: cleanValue(getDisplayValue(metricIdx, "SDLG", selectedYear - 1)),
          sdlg_cy: cleanValue(getDisplayValue(metricIdx, "SDLG", selectedYear)),

          br_py: cleanValue(getDisplayValue(metricIdx, "Breaker", selectedYear - 1)),
          br_cy: cleanValue(getDisplayValue(metricIdx, "Breaker", selectedYear)),

          tot_py: cleanValue(getDisplayValue(metricIdx, "Total", selectedYear - 1)),
          tot_cy: cleanValue(getDisplayValue(metricIdx, "Total", selectedYear)),
        });
      });

      sheet2.views = [{ state: "frozen", ySplit: 1 }];

      /* =========================================================
         📤 CREATE FILE + UPLOAD TEMP + PREVIEW
      ========================================================= */
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const file = new File(
        [blob],
        `Territory_Focus_${selectedYear}.xlsx`,
        {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        }
      );

      const response = await uploadTempFile(file);

      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        alert("Upload succeeded but preview not available.");
      }
    } catch (error) {
      console.error("❌ Failed to generate Territory Focus preview:", error);
      alert("Failed to generate preview. Check console for details.");
    }
  };

  const handleAddBranch = () => {
    // ⭐ NEW: Check edit permission
    if (!canEdit) {
      console.warn("⚠️ Cannot add branch: editing is disabled for status", pdpStatus);
      return;
    }
    setEditingBranchIndex(null);
    setShowBranchModal(true);
  };

  const handleEditBranch = (index) => {
    // ⭐ NEW: Check edit permission
    if (!canEdit) {
      console.warn("⚠️ Cannot edit branch: editing is disabled for status", pdpStatus);
      return;
    }
    setEditingBranchIndex(index);
    setShowBranchModal(true);
  };

  // ⭐ Open delete modal
  const handleDeleteBranch = (index) => {
    // ⭐ NEW: Check edit permission
    if (!canEdit) {
      console.warn("⚠️ Cannot delete branch: editing is disabled for status", pdpStatus);
      return;
    }

    const branchToDelete = branchData[index];
    
    if (!branchToDelete?.id) {
      alert("Cannot delete: Invalid branch data");
      return;
    }

    setDeleteIndex(index);
    setShowDeleteModal(true);
  };

  // ⭐⭐⭐ FIXED: Confirm delete - actual deletion logic
  const confirmDeleteBranch = async () => {
    if (deleteIndex === null) return;

    const branchToDelete = branchData[deleteIndex];

    // ⭐ Validate that we have a real database ID (not a timestamp)
    if (!branchToDelete?.id || branchToDelete.id > 9999999999) {
      alert("Cannot delete: This branch doesn't have a valid ID. Please refresh the page and try again.");
      setShowDeleteModal(false);
      setDeleteIndex(null);
      return;
    }

    try {
      setIsSaving(true);
      
      await deletePdpTerritoryFocus(branchToDelete.id);
      
      // Remove from local fill target data
      setFillTargetData(prev => {
        const updated = { ...prev };
        delete updated[branchToDelete.id];
        return updated;
      });
      
      const updatedData = branchData.filter((_, idx) => idx !== deleteIndex);
      setBranchData(updatedData);
      
    } catch (error) {
      console.error("❌ Error deleting branch:", error);
      alert(`❌ Failed to delete: ${error.message}`);
    } finally {
      setIsSaving(false);
      setShowDeleteModal(false);
      setDeleteIndex(null);
    }
  };

  // ⭐ Cancel delete
  const cancelDeleteBranch = () => {
    setShowDeleteModal(false);
    setDeleteIndex(null);
  };

  // ⭐⭐⭐ FIXED: Save branch with API call - now refreshes data after add
  const handleSaveBranch = async (branchFormData) => {
    // ⭐ NEW: Double-check edit permission before saving
    if (!canEdit) {
      alert(`❌ Cannot save. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      return;
    }

    try {
      setIsSaving(true);

      console.log("📥 Received form data:", branchFormData);

      if (!branchFormData.branchId) {
        alert("❌ Branch ID is required. Please select a valid city and branch.");
        setIsSaving(false);
        return;
      }
      if (!branchFormData.overallFocus) {
        alert("❌ Overall Focus is required.");
        setIsSaving(false);
        return;
      }

      if (editingBranchIndex !== null) {
        // ⭐ UPDATE existing branch
        const existingBranch = branchData[editingBranchIndex];
        
        // ⭐ Validate that we have a real database ID
        if (!existingBranch?.id || existingBranch.id > 9999999999) {
          alert("Cannot update: This branch doesn't have a valid ID. Please refresh the page and try again.");
          setIsSaving(false);
          return;
        }
        
        const updateData = {
          id: existingBranch.id,
          branchId: parseInt(branchFormData.branchId),
          responsible_person: branchFormData.responsiblePerson || null,
          overall_focus: branchFormData.overallFocus,
          segmentPriorityId_1: branchFormData.segmentPriorityId_1 || null,
          segmentPriorityId_2: branchFormData.segmentPriorityId_2 || null,
          segmentPriorityId_3: branchFormData.segmentPriorityId_3 || null,
          segmentPriorityId_4: branchFormData.segmentPriorityId_4 || null
        };

        console.log("📤 Sending UPDATE data:", updateData);
        
        await updatePdpTerritoryFocus(existingBranch.id, updateData);
        
        // ⭐⭐⭐ REFRESH DATA from server to ensure consistency
        await refreshTerritoryFocusData();
        
      } else {
        // ⭐ ADD new branch
        const newBranchData = {
          pdpId: parseInt(pdpId),
          branchId: parseInt(branchFormData.branchId),
          responsible_person: branchFormData.responsiblePerson || null,
          overall_focus: branchFormData.overallFocus,
          segmentPriorityId_1: branchFormData.segmentPriorityId_1 || null,
          segmentPriorityId_2: branchFormData.segmentPriorityId_2 || null,
          segmentPriorityId_3: branchFormData.segmentPriorityId_3 || null,
          segmentPriorityId_4: branchFormData.segmentPriorityId_4 || null
        };
        
        console.log("📤 Sending ADD data:", newBranchData);
        
        await addPdpTerritoryFocus(newBranchData);
        
        // ⭐⭐⭐ CRITICAL FIX: Refresh data from server to get the correct database ID
        console.log("🔄 Refreshing data after add to get correct ID...");
        await refreshTerritoryFocusData();
      }
      
      setShowBranchModal(false);
      setEditingBranchIndex(null);
      
    } catch (error) {
      console.error("❌ Error saving branch:", error);
      alert(`❌ Failed to save: ${error.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleTargetChange = (metricIdx, category, year, value) => {
    // ⭐ NEW: Check edit permission
    if (!canEdit) {
      console.warn("⚠️ Cannot change targets: editing is disabled for status", pdpStatus);
      return;
    }

    const key = `${metricIdx}-${category}-${year}`;
    setTargetValues(prev => {
      const updated = {
        ...prev,
        [key]: value
      };

      if (category !== 'Total') {
        const categories = ['GPE', 'RM', 'SDLG', 'Breaker'];
        const totalKey = `${metricIdx}-Total-${year}`;
        const total = categories.reduce((sum, cat) => {
          const catKey = `${metricIdx}-${cat}-${year}`;
          return sum + Number(updated[catKey] || 0);
        }, 0);
        updated[totalKey] = total > 0 ? total.toString() : "";
      }

      return updated;
    });
  };

  // ⭐ Save targets - calls updatePdpTerritoryFocusEntriesStats API
  const handleSaveTargets = async () => {
    if (!statsData?.id) {
      alert("No stats record found. Please contact administrator.");
      console.error("❌ Cannot save: statsData.id is missing");
      return;
    }

    // ⭐ NEW: Double-check edit permission before saving
    if (!canEdit) {
      alert(`❌ Cannot save. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      return;
    }

    try {
      setIsSaving(true);
      
      const updateData = {
        py_gpe_pvtv: parseFloat(targetValues[`${METRIC_INDEX.PDP_TARGET_VOLUME}-GPE-${selectedYear - 1}`]) || 0,
        py_rm_pvtv: parseFloat(targetValues[`${METRIC_INDEX.PDP_TARGET_VOLUME}-RM-${selectedYear - 1}`]) || 0,
        py_sdlg_pvtv: parseFloat(targetValues[`${METRIC_INDEX.PDP_TARGET_VOLUME}-SDLG-${selectedYear - 1}`]) || 0,
        py_breaker_pvtv: parseFloat(targetValues[`${METRIC_INDEX.PDP_TARGET_VOLUME}-Breaker-${selectedYear - 1}`]) || 0,
        py_gpe_etmv: parseFloat(targetValues[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-GPE-${selectedYear - 1}`]) || 0,
        py_rm_etmv: parseFloat(targetValues[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-RM-${selectedYear - 1}`]) || 0,
        py_sdlg_etmv: parseFloat(targetValues[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-SDLG-${selectedYear - 1}`]) || 0,
        py_breaker_etmv: parseFloat(targetValues[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-Breaker-${selectedYear - 1}`]) || 0,
        gpe_etmv: parseFloat(targetValues[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-GPE-${selectedYear}`]) || 0,
        rm_etmv: parseFloat(targetValues[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-RM-${selectedYear}`]) || 0,
        sdlg_etmv: parseFloat(targetValues[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-SDLG-${selectedYear}`]) || 0,
        breaker_etmv: parseFloat(targetValues[`${METRIC_INDEX.ESTIMATED_MARKET_VOLUME}-Breaker-${selectedYear}`]) || 0
      };

      console.log("💾 Saving stats:", updateData);
      
      await updatePdpTerritoryFocusEntriesStats(statsData.id, updateData);
      
      setStatsData(prev => ({
        ...prev,
        ...updateData
      }));
      
      setIsEditingTargets(false);
      
    } catch (error) {
      console.error("❌ Error saving targets:", error);
      alert(`❌ Failed to save: ${error.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleFillTargets = () => {
    // ⭐ NEW: Check edit permission
    if (!canEdit) {
      console.warn("⚠️ Cannot fill targets: editing is disabled for status", pdpStatus);
      return;
    }
    setIsEditingTargets(true);
  };

  const getColumnCount = () => {
    let count = 10;
    if (canEdit) count += 2; // ⭐ FIXED: Changed from !isAdmin to canEdit
    return count;
  };

  const isMetricEditable = (metric) => {
    const editableMetrics = [
      "PDP Target Volume",
      "Estimated Market Volume"
    ];
    return editableMetrics.includes(metric);
  };

  const isMetricCalculated = (metric) => {
    const calculatedMetrics = [
      "Achievement %",
      "Estimated Market Share %"
    ];
    return calculatedMetrics.includes(metric);
  };

  // ⭐ NEW: Get status badge color
  const getStatusBadgeColor = (status) => {
    switch (status) {
      case "Completed": return "bg-green-100 text-green-800 border-green-300";
      case "Approved": return "bg-blue-100 text-blue-800 border-blue-300";
      case "Pending Review": return "bg-orange-100 text-orange-800 border-orange-300";
      case "Started": return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "Created": return "bg-gray-100 text-gray-800 border-gray-300";
      default: return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-darkblue1 mx-auto mb-4"></div>
          <p className="text-gray-600 font-medium">Loading territory focus data...</p>
          <p className="text-gray-500 text-sm mt-2">PDP ID: {pdpId}</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="bg-red-50 border border-red-300 p-6 text-center">
        <div className="text-red-600 mb-4">
          <svg className="w-12 h-12 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="text-lg font-semibold mb-2">Error Loading Data</h3>
          <p className="text-sm">{error}</p>
        </div>
        <button
          onClick={() => window.location.reload()}
          className="bg-darkblue1 text-white px-6 py-2 hover:bg-darkblue1/90 transition"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="w-full ">
      {/* ⭐ NEW: Status Lock Banner - Shows when dealer cannot edit due to status */}
      {/* {isStatusLocked && (
        <div className="bg-amber-50 border border-amber-300 rounded-lg p-3 mb-4 flex items-start gap-3">
          <div className="flex-shrink-0 mt-0.5">
            <Lock size={20} className="text-amber-600" />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-amber-800 mb-1">
              Editing Disabled
            </h4>
            <p className="text-xs text-amber-700">
              This PDP is in <span className="font-bold">{pdpStatus}</span> status. 
              Data can only be edited when status is <span className="font-semibold">"Created"</span> or <span className="font-semibold">"Started"</span>.
            </p>
            <p className="text-xs text-amber-600 mt-1">
              {pdpStatus === "Pending Review" && "The PDP is awaiting admin approval."}
              {pdpStatus === "Approved" && "The PDP has been approved and is now read-only."}
              {pdpStatus === "Completed" && "The PDP has been completed and finalized."}
            </p>
          </div>
        </div>
      )} */}

      {/* Search and Action Buttons */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-2">
        <div className="">
          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search"
            className="w-[1/2]"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            focusRing="focus:ring-black/60"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            iconColor="text-black"
          />
        </div>

        <div className="flex gap-2 items-center">
          {/* ⭐ NEW: Status Badge */}
          <div className={`px-3 py-1 flex items-center gap-2 border text-xs font-medium ${getStatusBadgeColor(pdpStatus)}`}>
            {isStatusLocked && <Lock size={12} />}
            <span>{pdpStatus}</span>
          </div>

          <button
            onClick={handleDownload}
            className="bg-darkblue1 text-xs font-medium text-white px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition flex items-center gap-2"
          >
            <Download size={14} className="text-current" />
            Download
          </button>
          <div className="relative group">
            <button
              onClick={() => setShowTable(!showTable)}
              className="flex items-center gap-1 text-sm font-medium bg-Dustyblue text-white p-1 rounded-full hover:bg-darkblue1 transition"
            >
              {showTable ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
            <span className="absolute left-0 top-full -translate-x-1/2 mt-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap pointer-events-none z-50">
              {showTable ? "Collapse" : "Expand"}
            </span>
          </div>
        </div>
      </div>

      {/* Branch Table (First Table) */}
      {showTable && (
        <>
          {/* Desktop View */}
          <div className="overflow-x-auto shadow-lg border border-Dustyblue hidden lg:block mb-4">
            <div className="flex items-center justify-between px-4 py-1 border-b border-Dustyblue">
              <h3 className="text-sm font-semibold text-darkblue1">Territory Focus</h3>
              {/* ⭐ FIXED: Changed from !isAdmin to canEdit */}
              {canEdit && (
                <button
                  onClick={handleAddBranch}
                  disabled={isSaving}
                  className="bg-darkblue1 text-white px-3 py-1.5 text-xs font-medium hover:bg-darkblue1/90 transition flex items-center gap-1 disabled:opacity-50"
                >
                  <Plus size={14} />
                  Add Branch
                </button>
              )}
            </div>

            <table className="w-full text-sm border-collapse table-fixed">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">


  {/* FIRST HEADER ROW */}
  <tr>

    <th rowSpan="2"
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[10%] cursor-pointer"
      onClick={() => handleSort("city")}
    >
      <div className="flex items-center gap-1">
        City
        {sortKey !== "city" && <ChevronsUpDown className="w-3 h-3 text-white" />}
        {sortKey === "city" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "city" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    <th rowSpan="2"
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[10%] cursor-pointer"
      onClick={() => handleSort("branch")}
    >
      <div className="flex items-center gap-1">
        Branch
        {sortKey === "branch" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "branch" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    <th rowSpan="2"
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[10%] cursor-pointer"
      onClick={() => handleSort("district")}
    >
      <div className="flex items-center gap-1">
        Districts
        {sortKey === "district" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "district" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>


    {/* SEGMENT GROUP */}
    <th
      colSpan="4"
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-center w-[40%] font-medium"
    >
      Segment Priority
    </th>


    <th rowSpan="2"
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[10%] cursor-pointer"
      onClick={() => handleSort("overallfocus")}
    >
      <div className="flex items-center gap-1">
        Overall Focus
        {sortKey === "overallfocus" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "overallfocus" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    <th rowSpan="2"
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[10%] cursor-pointer"
      onClick={() => handleSort("responsibleperson")}
    >
      <div className="flex items-center gap-1">
        Responsible Person
        {sortKey === "responsibleperson" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "responsibleperson" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>


    <th rowSpan="2"
      className={`px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[10%] cursor-pointer ${
        !canEdit ? "border-r-0" : ""
      }`}
      onClick={() => handleSort("totalPlan")}
    >
      <div className="flex items-center gap-1 justify-between">
        <span>Total Plan {selectedYear}</span>
        {sortKey === "totalPlan" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "totalPlan" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>

    {canEdit && (
      <th rowSpan="2"
        className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-center whitespace-nowrap font-medium w-[5%]"
      >
        Actions
      </th>
    )}

    {canEdit && (
      <th rowSpan="2"
        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium text-center w-[7%]"
      >
        Fill Target
      </th>
    )}

  </tr>



  {/* SECOND HEADER ROW */}
  <tr>

    <th
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[10%] font-normal cursor-pointer"
      onClick={() => handleSort("firstsegment")}
    >
      <div className="flex items-center  justify-center">
           1<sup className="text-[10px]">st</sup>

        {sortKey === "firstsegment" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "firstsegment" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    <th
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[10%] font-normal cursor-pointer"
      onClick={() => handleSort("secondsegment")}
    >
      <div className="flex items-center justify-center">
          2<sup className="text-[10px]">nd</sup>
        {sortKey === "secondsegment" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "secondsegment" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    <th
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[10%] font-normal cursor-pointer"
      onClick={() => handleSort("thirdsegment")}
    >
      <div className="flex items-center  justify-center">
        3<sup className="text-[10px]">rd</sup>
        {sortKey === "thirdsegment" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "thirdsegment" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    <th
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[10%] font-normal cursor-pointer"
      onClick={() => handleSort("fourthsegment")}
    >
      <div className="flex items-center justify-center">
          4<sup className="text-[10px]">th</sup>
        {sortKey === "fourthsegment" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey === "fourthsegment" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

  </tr>

</thead>     
 <tbody>
                {filteredAndSortedBranchData.length > 0 ? (
                  filteredAndSortedBranchData.map((item, idx) => (
                    <tr
                      key={item.id}
                      className="hover:bg-lightBlue/50 text-xs transition duration-300 cursor-pointer bg-white"
                    >
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs max-w-[100px]">
  <div className="relative w-full">
    <p
      className="truncate w-full block cursor-pointer"
      onMouseEnter={() => {
        if (item.city && item.city.length > 10) {
          setHoveredCell(`city-${item.id}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.city || "-"}
    </p>

    {hoveredCell === `city-${item.id}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-10 shadow-lg">
        {item.city}
      </span>
    )}
  </div>
</td>
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs max-w-[100px]">
  <div className="relative w-full">
    <p
      className="truncate w-full block cursor-pointer"
      onMouseEnter={() => {
        if (item.branch && item.branch.length > 10) {
          setHoveredCell(`branch-${item.id}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.branch || "-"}
    </p>

    {hoveredCell === `branch-${item.id}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-10 shadow-lg">
        {item.branch}
      </span>
    )}
  </div>
</td>
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs max-w-[120px]">
  <div className="relative w-full">
    <p
      className="truncate w-full block cursor-pointer"
      onMouseEnter={() => {
        if (item.districts && item.districts.length > 12) {
          setHoveredCell(`district-${item.id}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.districts || "-"}
    </p>

    {hoveredCell === `district-${item.id}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-10 shadow-lg">
        {item.districts}
      </span>
    )}
  </div>
</td>
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs max-w-[120px]">
  <div className="relative w-full">
    <p
      className="truncate w-full block cursor-pointer"
      onMouseEnter={() => {
        if (item.firstSegment && item.firstSegment.length > 12) {
          setHoveredCell(`seg1-${item.id}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.firstSegment || "-"}
    </p>

    {hoveredCell === `seg1-${item.id}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-10 shadow-lg">
        {item.firstSegment}
      </span>
    )}
  </div>
</td>
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs max-w-[120px]">
  <div className="relative w-full">
    <p
      className="truncate w-full block cursor-pointer"
      onMouseEnter={() => {
        if (item.secondSegment && item.secondSegment.length > 12) {
          setHoveredCell(`seg2-${item.id}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.secondSegment || "-"}
    </p>

    {hoveredCell === `seg2-${item.id}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-10 shadow-lg">
        {item.secondSegment}
      </span>
    )}
  </div>
</td>
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <p
    className={`max-w-[8rem] cursor-pointer ${
      expandedCell === item.id + "-seg3" ? "" : "truncate"
    }`}
    onClick={() =>
      setExpandedCell(
        expandedCell === item.id + "-seg3"
          ? null
          : item.id + "-seg3"
      )
    }
  >
    {item.thirdSegment || "-"}
  </p>
</td>
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <p
    className={`max-w-[8rem] cursor-pointer ${
      expandedCell === item.id + "-seg4" ? "" : "truncate"
    }`}
    onClick={() =>
      setExpandedCell(
        expandedCell === item.id + "-seg4"
          ? null
          : item.id + "-seg4"
      )
    }
  >
    {item.fourthSegment || "-"}
  </p>
</td>
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[10rem] cursor-pointer"
      onMouseEnter={() => {
        if ((item.overallFocus ?? "").length > 20)
          setHoveredCell(item.id + "-focus");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.overallFocus || "-"}
    </p>

    {hoveredCell === item.id + "-focus" && (
      <span className="absolute left-1/2 top-full bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-nowrap transform -translate-x-1/2 z-50">
        {item.overallFocus}
      </span>
    )}
  </div>
</td>
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <p
    className={`max-w-[8rem] cursor-pointer ${
      expandedCell === item.id + "-person" ? "" : "truncate"
    }`}
    onClick={() =>
      setExpandedCell(
        expandedCell === item.id + "-person"
          ? null
          : item.id + "-person"
      )
    }
  >
    {item.responsiblePerson || "-"}
  </p>
</td>
                      <td className={`px-2 py-1 border border-grey2 border-t-0 border-l-0 ${!canEdit ? 'border-r-0' : ''}`}>
                        {getTotalPlanForBranch(item.id) || item.totalPlan || 0}
                      </td>
                      {/* ⭐ FIXED: Changed from !isAdmin to canEdit */}
                      {canEdit && (
                        <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              onClick={() => handleEditBranch(idx)}
                              className="text-blue-600 hover:text-blue-800"
                              title="Edit"
                              disabled={isSaving}
                            >
                              <img
                                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
                                alt="Edit"
                                className="w-4 h-4"
                              />
                            </button>
                            <button
                              onClick={() => handleDeleteBranch(idx)}
                              className="text-red-600 hover:text-red-800"
                              title="Delete"
                              disabled={isSaving}
                            >
                              <img
                                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                                alt="Delete"
                                className="w-4 h-4"
                              />
                            </button>
                          </div>
                        </td>
                      )}
                      {/* ⭐ FIXED: Changed from !isAdmin to canEdit */}
                      {canEdit && (
                        <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-center">
                          <div className="flex items-center justify-center">
                            <button
                              onClick={() => handleFillEntries(item)}
                              disabled={isSaving}
                              className="flex items-center justify-center px-3 py-1 bg-SteelBlue1 text-white text-xs rounded hover:bg-white hover:border hover:border-SteelBlue1 hover:text-SteelBlue1 disabled:opacity-50"
                            >
                              Fill Target
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={getColumnCount()} className="text-center py-4 text-gray-500 italic">
                      No data found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Mobile View */}
          <div className="lg:hidden space-y-4 mb-2">
            {/* ⭐ FIXED: Changed from !isAdmin to canEdit */}
            {canEdit && (
              <button
                onClick={handleAddBranch}
                disabled={isSaving}
                className="w-full bg-[#3d4f5c] text-white px-4 py-2 text-sm font-medium hover:bg-[#4a5f6e] transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Plus size={18} />
                Add Branch
              </button>
            )}

            {filteredBranchData.length > 0 ? (
              filteredBranchData.map((item, idx) => (
                <div
                  key={item.id}
                  className="bg-white shadow-md p-4 border border-gray-200"
                >
                  {/* ⭐ FIXED: Changed from !isAdmin to canEdit */}
                  {canEdit && (
                    <div className="flex justify-end gap-2 mb-3">
                      <button
                        onClick={() => handleEditBranch(idx)}
                        className="text-blue-600 hover:text-blue-800"
                        disabled={isSaving}
                      >
                        <Pencil size={18} />
                      </button>
                      <button
                        onClick={() => handleDeleteBranch(idx)}
                        className="text-red-600 hover:text-red-800"
                        disabled={isSaving}
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  )}
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold text-mildBlue">City:</span>
                    <span className="text-gray-700">{item.city || "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold text-mildBlue">Branch:</span>
                    <span className="text-gray-700">{item.branch || "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold text-mildBlue">Districts:</span>
                    <span className="text-gray-700">{item.districts || "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold text-mildBlue">1st Segment:</span>
                    <span className="text-gray-700">{item.firstSegment || "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold text-mildBlue">2nd Segment:</span>
                    <span className="text-gray-700">{item.secondSegment || "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold text-mildBlue">3rd Segment:</span>
                    <span className="text-gray-700">{item.thirdSegment || "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold text-mildBlue">4th Segment:</span>
                    <span className="text-gray-700">{item.fourthSegment || "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold text-mildBlue">Overall Focus:</span>
                    <span className="text-gray-700">{item.overallFocus || "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold text-mildBlue">Responsible:</span>
                    <span className="text-gray-700">{item.responsiblePerson || "-"}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold text-mildBlue">Total Plan {selectedYear}:</span>
                    <span className="text-gray-700">{getTotalPlanForBranch(item.id) || item.totalPlan || 0}</span>
                  </div>
                  {/* ⭐ FIXED: Changed from !isAdmin to canEdit */}
                  {canEdit && (
                    <div className="flex justify-center mt-3">
                      <button
                        onClick={() => handleFillEntries(item)}
                        disabled={isSaving}
                        className="flex items-center justify-center px-4 py-2 bg-SteelBlue1 text-white text-sm rounded hover:bg-white hover:border hover:border-SteelBlue1 hover:text-SteelBlue1 disabled:opacity-50"
                      >
                        Fill Target
                      </button>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-6 text-gray-500 italic">
                No data found.
              </div>
            )}
          </div>
        </>
      )}

      {/* Territory Focus Targets Table (Second Table) */}
      <div className="overflow-x-auto shadow-lg border border-Dustyblue hidden lg:block">
        <div className="flex items-center justify-between px-4 py-1.5 border-b border-Dustyblue">
          <h3 className="text-sm font-semibold text-darkblue1">Territory Focus Targets</h3>
          {/* ⭐ FIXED: Changed from !isAdmin to canEdit */}
          {canEdit && (
            <div className="flex gap-2">
              {isEditingTargets ? (
                <button
                  onClick={handleSaveTargets}
                  disabled={isSaving}
                  className="bg-darkblue1 text-white px-3 py-1 text-xs font-medium hover:bg-darkblue1/90 transition flex items-center gap-1 disabled:opacity-50"
                >
                  {isSaving ? "Saving..." : "Save"}
                </button>
              ) : (
                <button
                  onClick={handleFillTargets}
                  className="bg-darkblue1 text-white px-3 py-1 text-xs font-medium hover:bg-darkblue1/90 transition"
                >
                  Fill Targets
                </button>
              )}
            </div>
          )}
        </div>

        <table className="w-full border-collapse text-sm text-center">
       <thead>
  <tr className="bg-Dustyblue text-white">

    {/* Territory Focus */}
    <th
      rowSpan="2"
      className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 px-4 text-left font-medium w-[20%] cursor-pointer"
      onClick={() => handleSort1("metric")}
    >
      <div className="flex items-center gap-1">
        Territory Focus
        {sortKey1 === "metric" && sortOrder1 === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey1 === "metric" && sortOrder1 === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Category Headers */}
    <th colSpan="2" className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[16%] font-semibold">
      GPE
    </th>

    <th colSpan="2" className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[16%] font-semibold">
      RM
    </th>

    <th colSpan="2" className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[16%] font-semibold">
      SDLG
    </th>

    <th colSpan="2" className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[16%] font-semibold">
      Attachments
    </th>

    <th colSpan="2" className="py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 w-[16%] font-semibold">
      Total
    </th>

  </tr>

  {/* YEAR ROW */}
 <tr className="bg-Dustyblue text-white">
  {["GPE","RM","SDLG","Breaker","Total"]
    .flatMap((category) => [selectedYear - 1, selectedYear].map((year) => ({ category, year })))
    .map(({ category, year }, index) => {
      const key = `${category}-${year}`;
      const isLast = index === 9;

      return (
        <th
          key={key}
          onClick={() => handleSort1(key)}
          className={`py-1.5 px-2 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[8%] cursor-pointer select-none ${
            isLast ? "border-r-0" : ""
          }`}
        >
          <div className="flex items-center justify-center gap-1">
            {year}

            {sortKey1 === key && sortOrder1 === "asc" && (
              <ChevronUp className="w-3 h-3 text-white" />
            )}

            {sortKey1 === key && sortOrder1 === "desc" && (
              <ChevronDown className="w-3 h-3 text-white" />
            )}
          </div>
        </th>
      );
    })}
</tr>
</thead>
          <tbody>
{sortedData1.map((metric) => {
    const metricIdx = territoryMetrics.indexOf(metric);
              const isCalculated = isMetricCalculated(metric);
              const isEditable = isMetricEditable(metric);

              return (
                     <tr key={metric} className={`text-xs ${isCalculated ? "bg-white" : ""}`}>  
                  <td className="py-1 bg-white px-4 border border-grey2 border-t-0 border-l-0 text-left font-normal w-[20%]">
                    {metric}
                    {isCalculated && (
                      <span className="ml-1 text-[10px] text-gray-500">(Auto)</span>
                    )}
                  </td>

                  {["GPE", "RM", "SDLG", "Breaker", "Total"].map((category) =>
                    [selectedYear - 1, selectedYear].map((year) => {
                      const key = `${metricIdx}-${category}-${year}`;
                      const isPDPTarget2025 = metric === "PDP Target Volume" && year === selectedYear;
                      // ⭐ FIXED: Changed from !isAdmin to canEdit
                      const canEditCell = isEditable && canEdit && isEditingTargets && category !== "Total" && !isPDPTarget2025;
                      const displayValue = getDisplayValue(metricIdx, category, year);

                      return (
                        <td
                          key={`${category}-${year}`}
                          className={`py-1 px-4 bg-white border border-grey2 border-t-0 border-l-0 ${isCalculated ? 'bg-white text-gray-600' : ''} ${isPDPTarget2025 ? 'bg-gray-50' : ''}`}
                        >
                          {canEditCell ? (
                           <input
  type="text"
  value={targetValues[key] || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;

    if (/^\d*\.?\d*$/.test(value)) {
      handleTargetChange(metricIdx, category, year, value);
    }
  }}
  className="w-full px-2 py-1 bg-white text-xs border border-grey2 text-center focus:outline-none focus:ring-1 focus:ring-darkblue1"
/>
                          ) : (
                            <span>
                              {isCalculated 
                                ? (displayValue !== "-" ? `${displayValue}%` : "-")
                                : displayValue
                              }
                            </span>
                          )}
                        </td>
                      );
                    })
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Mobile View for Targets */}
      <div className="lg:hidden mt-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-base font-semibold text-darkblue1">Territory Focus Targets</h3>
          {/* ⭐ FIXED: Changed from !isAdmin to canEdit */}
          {canEdit && (
            <div className="flex gap-2">
              {isEditingTargets ? (
                <button
                  onClick={handleSaveTargets}
                  disabled={isSaving}
                  className="bg-darkblue1 text-white px-3 py-1 text-sm font-medium hover:bg-darkblue1/90 transition flex items-center gap-1 disabled:opacity-50"
                >
                  <Save size={16} />
                  {isSaving ? "Saving..." : "Save"}
                </button>
              ) : (
                <button
                  onClick={handleFillTargets}
                  className="bg-darkblue1 text-white px-3 py-1 text-sm font-medium hover:bg-darkblue1/90 transition"
                >
                  Fill
                </button>
              )}
            </div>
          )}
        </div>

        <div className="grid sm:grid-cols-1 gap-4 mt-2">
          {filteredMetrics.map((metric, metricIdx) => {
            const isCalculated = isMetricCalculated(metric);
            const isEditable = isMetricEditable(metric);

            return (
              <div
                key={metricIdx}
                className={`bg-white shadow-md p-4 border border-gray-200 ${isCalculated ? 'bg-gray-50' : ''}`}
              >
                <h4 className="font-semibold text-md text-darkblue1 mb-3">
                  {metric}
                  {isCalculated && (
                    <span className="ml-2 text-xs text-gray-500 font-normal">(Auto-calculated)</span>
                  )}
                </h4>
                
                {['GPE', 'RM', 'SDLG', 'Attachments', 'Total'].map((category) => (
                  <div key={category} className="mb-3">
                    <p className="font-medium text-sm text-gray-700 mb-2">{category}</p>
                    {[selectedYear - 1, selectedYear].map((year) => {
                      const key = `${metricIdx}-${category}-${year}`;
                      const isPDPTarget2025 = metric === "PDP Target Volume" && year === selectedYear;
                      // ⭐ FIXED: Changed from !isAdmin to canEdit
                      const canEditCell = isEditable && canEdit && isEditingTargets && category !== 'Total' && !isPDPTarget2025;
                      const displayValue = getDisplayValue(metricIdx, category, year);
                      
                      return (
                        <div key={year} className="flex justify-between items-center mb-2">
                          <span className="text-sm text-gray-600">{year}:</span>
                          {canEditCell ? (
                            <input
                              type="number"
                              value={targetValues[key] || ""}
                              onChange={(e) => handleTargetChange(metricIdx, category, year, e.target.value)}
                              className="w-20 px-2 py-1 border border-gray-300 text-center focus:outline-none focus:ring-1 focus:ring-darkblue1"
                              placeholder="0"
                            />
                          ) : (
                            <span className={`text-sm px-2 py-1 min-w-[60px] text-center ${isCalculated ? 'bg-gray-100' : 'bg-gray-50'} ${isPDPTarget2025 ? 'bg-blue-50' : ''}`}>
                              {isCalculated 
                                ? (displayValue !== "-" ? `${displayValue}%` : "-")
                                : displayValue
                              }
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </div>

      {/* Branch Modal */}
      {showBranchModal && (
        <BranchFormModal
          isOpen={showBranchModal}
          onClose={() => {
            setShowBranchModal(false);
            setEditingBranchIndex(null);
          }}
          onSave={handleSaveBranch}
          initialData={editingBranchIndex !== null ? branchData[editingBranchIndex] : null}
          isEdit={editingBranchIndex !== null}
          segmentOptions={segmentOptions}
          branchMasterData={branchMasterData}
          isSaving={isSaving}
        />
      )}

      {/* Delete Confirmation Modal */}
      <DeleteModal
        isOpen={showDeleteModal}
        onClose={cancelDeleteBranch}
        onConfirm={confirmDeleteBranch}
        title="Delete Branch"
        message={`Are you sure you want to delete this branch${deleteIndex !== null && branchData[deleteIndex] ? ` "${branchData[deleteIndex].branch || branchData[deleteIndex].city}"` : ""}? This action cannot be undone.`}
        isLoading={isSaving}
      />

      {/* Fill Target Popup - ⭐ FIXED: Only show when canEdit is true */}
      {showPopup && canEdit && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white p-6 shadow-lg w-[70%] max-w-4xl">
            <div className="relative mb-4 flex items-center justify-center">
              <h2 className="text-lg text-MediumGrey font-semibold text-center w-full">
                Fill Entries - {selectedEntry?.branch || ""}
              </h2>
              <button
                onClick={() => {
                  resetFillEntryFields();
                  setShowPopup(false);
                }}
                className="absolute right-0 text-xl pr-1"
              >
                <img 
                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" 
                  alt="close" 
                  className="w-5 h-5" 
                />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {/* Previous Year box */}
              <div className="border shadow p-4">
                <h3 className="text-black text-center text-sm px-3 py-1 rounded mb-3 font-medium">
                  {selectedYear - 1} Forecasted Volvo Sales Volume (EOY)
                </h3>

                {["GPE", "RM", "SDLG", "Attachments"].map((label) => (
                  <div 
                    key={label} 
                    className="mb-3 flex items-center justify-center gap-0"
                  >
                    <label className="text-xs font-semibold w-24 text-left">
                      {label}
                    </label>
                   <input
  type="text"
  inputMode="decimal"
  className="border border-black/30 px-2 py-1 text-xs w-32 -ml-[20px]"
  value={LsValues[label]}
  onChange={(e) => {
    const value = e.target.value;

    if (/^\d*\.?\d*$/.test(value)) {
      setLSValues({
        ...LsValues,
        [label]: value,
      });
    }
  }}
/>
                  </div>
                ))}

                <div className="mt-3 flex items-center gap-3 bg-grey2 py-2 px-2">
                  <label className="text-xs font-semibold w-24 whitespace-nowrap">
                    (EOY-{selectedYear - 1})Expect Closure by Dec'{selectedYear - 1}
                  </label>
                  <div className="flex-1 text-right font-semibold text-xs">
                    {totalLS}
                  </div>
                </div>
              </div>

              {/* Current Year box */}
              <div className="border shadow p-4">
                <h3 className="text-black px-3 py-1 rounded mb-3 text-center text-sm font-medium">
                  {selectedYear} Volvo Target Volume
                </h3>

                {["GPE", "RM", "SDLG", "Attachments"].map((label) => (
                  <div 
                    key={label} 
                    className="mb-3 flex items-center justify-center gap-0"
                  >
                    <label className="text-xs font-semibold w-24 text-left">
                      {label}
                    </label>
                   <input
  type="text"
  inputMode="decimal"
  className="border border-black/30 px-2 py-1 text-xs w-32 -ml-[20px]"
  value={CyValues[label]}
  onChange={(e) => {
    const value = e.target.value;

    if (/^\d*\.?\d*$/.test(value)) {
      setCYValues({
        ...CyValues,
        [label]: value,
      });
    }
  }}
/>
                  </div>
                ))}

                <div className="mt-3 flex items-center gap-3 bg-grey2 py-2 px-2">
                  <label className="text-xs font-semibold w-24 whitespace-nowrap">
                    Total Plan {selectedYear}
                  </label>
                  <div className="flex-1 text-right font-semibold text-xs">
                    {totalCY}
                  </div>
                </div>
              </div>
            </div>

            {/* Save Button */}
            <div className="flex justify-end mt-4">
              <button
                onClick={handleSaveFillEntries}
                disabled={isSaving}
                className="bg-darkblue1 text-white px-8 py-1.5 text-xs font-medium hover:border hover:border-darkblue1 hover:bg-white hover:text-darkblue1 flex items-center gap-2 disabled:opacity-50"
              >
                {isSaving ? "Saving..." : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ⭐ Branch Form Modal Component (unchanged)
function BranchFormModal({ 
  isOpen, 
  onClose, 
  onSave, 
  initialData, 
  isEdit,
  segmentOptions = [],
  branchMasterData = {},
  isSaving = false
}) {

  const [formData, setFormData] = useState({
    city: "",
    branch: "",
    branchId: null,
    districts: "",
    firstSegment: "",
    segmentPriorityId_1: null,
    secondSegment: "",
    segmentPriorityId_2: null,
    thirdSegment: "",
    segmentPriorityId_3: null,
    fourthSegment: "",
    segmentPriorityId_4: null,
    overallFocus: "",
    responsiblePerson: ""
  });

  const [errors, setErrors] = useState({});

  const [isCityOpen, setIsCityOpen] = useState(false);
  const [isBranchOpen, setIsBranchOpen] = useState(false);
  const [isOverallFocusOpen, setIsOverallFocusOpen] = useState(false);
  const [isFirstSegmentOpen, setIsFirstSegmentOpen] = useState(false);
  const [isSecondSegmentOpen, setIsSecondSegmentOpen] = useState(false);
  const [isThirdSegmentOpen, setIsThirdSegmentOpen] = useState(false);
  const [isFourthSegmentOpen, setIsFourthSegmentOpen] = useState(false);

  const cityRef = React.useRef(null);
  const branchRef = React.useRef(null);
  const overallFocusRef = React.useRef(null);
  const firstSegmentRef = React.useRef(null);
  const secondSegmentRef = React.useRef(null);
  const thirdSegmentRef = React.useRef(null);
  const fourthSegmentRef = React.useRef(null);

  const cityOptions = Object.keys(branchMasterData);

  const branchOptions = formData.city 
    ? Object.keys(branchMasterData[formData.city]?.branches || {})
    : [];

  const segmentNameOptions = segmentOptions.map(s => s.name);
  const overallFocusOptions = ["High", "Medium", "Low"];

  useEffect(() => {
    if (initialData) {
      const findSegmentName = (id) => {
        const segment = segmentOptions.find(s => s.id === id);
        return segment ? segment.name : "";
      };

      setFormData({
        city: initialData.city || "",
        branch: initialData.branch || "",
        branchId: initialData.branchId || null,
        districts: initialData.districts || "",
        firstSegment: initialData.firstSegment || findSegmentName(initialData.segmentPriorityId_1),
        segmentPriorityId_1: initialData.segmentPriorityId_1 || null,
        secondSegment: initialData.secondSegment || findSegmentName(initialData.segmentPriorityId_2),
        segmentPriorityId_2: initialData.segmentPriorityId_2 || null,
        thirdSegment: initialData.thirdSegment || findSegmentName(initialData.segmentPriorityId_3),
        segmentPriorityId_3: initialData.segmentPriorityId_3 || null,
        fourthSegment: initialData.fourthSegment || findSegmentName(initialData.segmentPriorityId_4),
        segmentPriorityId_4: initialData.segmentPriorityId_4 || null,
        overallFocus: initialData.overallFocus || "",
        responsiblePerson: initialData.responsiblePerson || ""
      });
    }
  }, [initialData, segmentOptions]);

  useEffect(() => {
    if (formData.city && formData.branch && branchMasterData[formData.city]?.branches?.[formData.branch]) {
      const branchInfo = branchMasterData[formData.city].branches[formData.branch];
      setFormData(prev => ({ 
        ...prev, 
        districts: branchInfo.districtsString || "",
        branchId: branchInfo.id
      }));
    }
  }, [formData.city, formData.branch, branchMasterData]);

  const findSegmentId = (name) => {
    const segment = segmentOptions.find(s => s.name === name);
    return segment ? segment.id : null;
  };

  const handleChange = (name, value) => {
    setFormData(prev => {
      const newData = { ...prev, [name]: value };

      if (name === "city") {
        newData.branch = "";
        newData.branchId = null;
        newData.districts = "";
      }

      if (name === "branch") {
        newData.districts = "";
        newData.branchId = null;
      }

      if (name === "firstSegment") newData.segmentPriorityId_1 = findSegmentId(value);
      if (name === "secondSegment") newData.segmentPriorityId_2 = findSegmentId(value);
      if (name === "thirdSegment") newData.segmentPriorityId_3 = findSegmentId(value);
      if (name === "fourthSegment") newData.segmentPriorityId_4 = findSegmentId(value);

      return newData;
    });

    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    handleChange(name, value);
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.city) newErrors.city = "City is required";
    if (!formData.branch) newErrors.branch = "Branch is required";
    if (!formData.branchId) newErrors.branch = "Please select a valid branch";
    if (!formData.overallFocus) newErrors.overallFocus = "Overall Focus is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    onSave(formData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">

<div
  className="bg-white shadow-xl max-w-6xl w-full max-h-[95vh] flex flex-col"
  onMouseDown={(e) => {
    const el = e.currentTarget;

    const isScrollbar =
      el.scrollHeight > el.clientHeight &&
      e.nativeEvent.offsetX > el.clientWidth;

    if (isScrollbar) {
      e.stopPropagation();
    }
  }}
>    <div className="relative flex items-center justify-center p-4 border-b sticky top-0 bg-white">
  
  <h2 className="text-base font-bold text-MediumGrey">
    {isEdit ? "Edit Branch" : "Create Branch"}
  </h2>

  <button
    onClick={onClose}
    className="absolute right-4 text-white bg-red1 rounded-full p-1 hover:bg-red-700 transition"
  >
    <X size={12} />
  </button>

</div>

<form
  onSubmit={handleSubmit}
  className="p-6 overflow-y-auto flex-1"
  onMouseDown={(e) => {
    const el = e.currentTarget;

    const isScrollbar =
      el.scrollHeight > el.clientHeight &&
      e.nativeEvent.offsetX > el.clientWidth;

    if (isScrollbar) {
      e.stopPropagation();
    }
  }}
>          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">

            {/* Row 1 */}
            <StyledSelectField
              label="City"
              placeholder="Select City"
              value={formData.city}
              setValue={(val) => handleChange("city", val)}
              options={cityOptions}
              dropdownOpen={isCityOpen}
              setDropdownOpen={setIsCityOpen}
              dropdownRef={cityRef}
              required
              error={errors.city}
            />

            <StyledSelectField
              label="Branch"
              placeholder={formData.city ? "Select Branch" : "Select City first"}
              value={formData.branch}
              setValue={(val) => handleChange("branch", val)}
              options={branchOptions}
              dropdownOpen={isBranchOpen}
              setDropdownOpen={setIsBranchOpen}
              dropdownRef={branchRef}
              required
              error={errors.branch}
              disabled={!formData.city}
            />

           <div>
  <label className="block text-xs font-medium text-gray-700 mb-2">
    Districts
    <span className="ml-2 text-[10px] text-gray-500">(Auto)</span>
  </label>

  <div className="w-full px-4 h-[33px] border border-black/30 bg-gray-100 text-xs text-black flex items-center">
    {formData.districts}
  </div>

  {/* {formData.branchId && (
    <p className="text-[10px] text-gray-400 mt-1">
      Branch ID: {formData.branchId}
    </p>
  )} */}
</div>
            {/* Row 2 */}
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-2">
                Responsible Person
              </label>

              <input
                type="text"
                name="responsiblePerson"
                value={formData.responsiblePerson}
                onChange={handleInputChange}
                className="w-full px-4 py-1.5 border border-black/30 focus:outline-none focus:ring-2 focus:ring-darkblue1 text-xs"
                placeholder="Enter responsible person"
              />
            </div>

            <StyledSelectField
              label="Overall Focus"
              placeholder="Select Focus"
              value={formData.overallFocus}
              setValue={(val) => handleChange("overallFocus", val)}
              options={overallFocusOptions}
              dropdownOpen={isOverallFocusOpen}
              setDropdownOpen={setIsOverallFocusOpen}
              dropdownRef={overallFocusRef}
              required
              error={errors.overallFocus}
            />

            <StyledSelectField
              label="1st Segment Priority"
              placeholder="Select Segment"
              value={formData.firstSegment}
              setValue={(val) => handleChange("firstSegment", val)}
              options={segmentNameOptions}
              dropdownOpen={isFirstSegmentOpen}
              setDropdownOpen={setIsFirstSegmentOpen}
              dropdownRef={firstSegmentRef}
            />

            {/* Row 3 */}
            <StyledSelectField
              label="2nd Segment Priority"
              placeholder="Select Segment"
              value={formData.secondSegment}
              setValue={(val) => handleChange("secondSegment", val)}
              options={segmentNameOptions}
              dropdownOpen={isSecondSegmentOpen}
              setDropdownOpen={setIsSecondSegmentOpen}
              dropdownRef={secondSegmentRef}
            />

            <StyledSelectField
              label="3rd Segment Priority"
              placeholder="Select Segment"
              value={formData.thirdSegment}
              setValue={(val) => handleChange("thirdSegment", val)}
              options={segmentNameOptions}
              dropdownOpen={isThirdSegmentOpen}
              setDropdownOpen={setIsThirdSegmentOpen}
              dropdownRef={thirdSegmentRef}
            />

            <StyledSelectField
              label="4th Segment Priority"
              placeholder="Select Segment"
              value={formData.fourthSegment}
              setValue={(val) => handleChange("fourthSegment", val)}
              options={segmentNameOptions}
              dropdownOpen={isFourthSegmentOpen}
              setDropdownOpen={setIsFourthSegmentOpen}
              dropdownRef={fourthSegmentRef}
            />

          </div>

          <div className="flex justify-end gap-4 mt-6">
            {/* <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 border-2 text-xs border-gray-300 text-gray-700 hover:bg-gray-100 transition"
            >
              Cancel
            </button> */}

            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-1.5 bg-darkblue1 text-xs text-white hover:bg-darkblue1/90 transition disabled:opacity-50"
            >
              {isSaving ? "Saving..." : (isEdit ? "Update" : "Save")}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}

export default TerritoryFocus;