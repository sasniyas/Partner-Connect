import React from "react";
import { X } from "lucide-react";

/**
 * StatusLogsPopup Component (UPDATED)
 * --------------------------
 * A reusable popup modal that displays PDP Status Logs in a Label : Value format.
 * Date Format: DD-MM-YYYY
 * 
 * Props:
 *  - isOpen (boolean): Controls visibility of the popup.
 *  - onClose (function): Closes the popup.
 *  - rowData (object): PDP data to display in logs.
 */

const StatusLogsPopup = ({ isOpen, onClose, rowData }) => {
  if (!isOpen) return null;

  /**
   * Format date to DD-MM-YYYY
   * Handles multiple input formats:
   * - ISO string: "2026-01-03T10:00:00Z"
   * - Date string: "2026-01-03"
   * - Already formatted: "03-01-2026" or "03/01/2026"
   * - Date object
   */
  const formatDateToDDMMYYYY = (dateValue) => {
    if (!dateValue) return "—";

    try {
      // If already in DD-MM-YYYY or DD/MM/YYYY format, just normalize
      if (typeof dateValue === 'string') {
        // Check if already in DD-MM-YYYY or DD/MM/YYYY format
        const ddmmyyyyRegex = /^(\d{2})[-/](\d{2})[-/](\d{4})$/;
        const match = dateValue.match(ddmmyyyyRegex);
        if (match) {
          return `${match[1]}-${match[2]}-${match[3]}`;
        }

        // Check if in YYYY-MM-DD format (ISO date part)
        const yyyymmddRegex = /^(\d{4})-(\d{2})-(\d{2})/;
        const isoMatch = dateValue.match(yyyymmddRegex);
        if (isoMatch) {
          return `${isoMatch[3]}-${isoMatch[2]}-${isoMatch[1]}`;
        }
      }

      // Try parsing as Date object
      const date = new Date(dateValue);

      // Validate date
      if (isNaN(date.getTime())) return "—";

      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();

      return `${day}-${month}-${year}`;
    } catch (error) {
      console.error("Date formatting error:", error);
      return "—";
    }
  };

  // Handle different field naming conventions from API vs frontend
  const getFieldValue = (field1, field2) => {
    return rowData?.[field1] || rowData?.[field2] || null;
  };
  console.log(rowData?.created_at)
  // ✅ UPDATED: Format logs with created_at date
  const logs = [
    {
      label: "PDP Created and Email Notification Sent On",
      value: formatDateToDDMMYYYY(rowData?.created_at || "")
    },
    {
      label: "PDP Sent On",
      value: formatDateToDDMMYYYY(getFieldValue('pdpstartdate', 'pdp_start_date'))
    },
    {
      label: "PDP Sent On",
      value: formatDateToDDMMYYYY(getFieldValue('pdpenddate', 'pdp_end_date'))
    },
    {
      label: "Physical PDP Sent On",
      value: formatDateToDDMMYYYY(getFieldValue('physicalpdpstartdate', 'physical_pdp_start_date'))
    },
    {
      label: "Physical PDP Sent On",
      value: formatDateToDDMMYYYY(getFieldValue('physicalpdpenddate', 'physical_pdp_end_date'))
    },
  ];

  // Handle click outside to close
  const handleOverlayClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 p-4"
        onClick={handleOverlayClick}
      >
        {/* Popup Container */}
        <div className="bg-white shadow-lg w-full max-w-lg sm:max-w-xl md:max-w-2xl lg:w-[45%] p-6 sm:p-8 relative animate-fadeIn">
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-3 right-3 hover:scale-110 transition hover:bg-gray-100 rounded-full p-1"
            aria-label="Close Status Logs Popup"
          >
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
              alt="close"
              className="w-4 h-4"
            />
          </button>

          {/* Heading */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-gray-800 underline underline-offset-4 decoration-2 decoration-darkblue1">
              PDP Status
            </h2>
          </div>

          {/* Status Logs */}
          <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
            {logs && logs.length > 0 ? (
              logs.map((item, index) => (
                <div
                  key={index}
                  className={`flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 text-sm p-3 ${index % 2 === 0 ? 'bg-gray-100' : 'bg-gray-50'
                    }`}
                >
                  {/* Label */}
                  <span className="font-medium text-gray-700 sm:min-w-[280px] lg:whitespace-nowrap">
                    {item.label}:
                  </span>
                  {/* Value - DD-MM-YYYY format */}
                  <span className="text-gray-900 font-normal">
                    {item.value}
                  </span>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-sm text-center py-4">
                No status logs available
              </p>
            )}
          </div>

          {/* Optional: Additional Info Section */}
          {rowData?.signOffStatus && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-gray-700">Current Sign Off Status:</span>
                <span className={`font-semibold px-3 py-1 rounded-full text-xs ${rowData.signOffStatus === 'Completed'
                  ? 'bg-green-100 text-green-700'
                  : rowData.signOffStatus === 'In Progress'
                    ? 'bg-yellow-100 text-yellow-700'
                    : 'bg-gray-100 text-gray-600'
                  }`}>
                  {rowData.signOffStatus}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default StatusLogsPopup;