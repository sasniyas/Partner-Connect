import React, { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { ArrowLeft, Plus, Pencil, Trash2 } from "lucide-react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import DeleteModal from "../../../../Components/DeleteModal";
import Filter from "../../../../Components/Filter";
import Searchinput from "../../../../Components/Searchinput";
import { ChevronDown } from "lucide-react";
import { ChevronUp } from "lucide-react";
import { ArrowUp } from "lucide-react";
import { ArrowDown,ChevronsUpDown } from "lucide-react";

import {
  getPdpInfrastructureAssetsByPdpInfrastructureId,
  deletePdpInfrastructureAsset
} from "../../../../services/PDP/SubPDP/pdpInfrastructure/pdpInfrastructureAssets/pdpInfrastructureAssets.service";

const InfrastructureAccessoriesPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") setSortOrder("desc");
    else {
      setSortKey(null);
      setSortOrder(null);
    }
    return;
  }
  setSortKey(key);
  setSortOrder("asc");
};

  // Get data from navigation state
  const itemType = location.state?.itemType || "";
  const initialAccessories = location.state?.items || [];
  const rowIndex = location.state?.rowIndex;
  const year = location.state?.year || "";
  const facilityDefinition = location.state?.facilityDefinition || "";
  const isAdmin = location.state?.isAdmin || false;
  const rowData = location.state?.rowData || {};
  const pdpInfrastructureId = location.state?.pdpInfrastructureId || rowData?.id;
  const pdpId = location.state?.pdpId || rowData?.pdpId;
  const tableContainerRef = useRef(null);
  const [accessoriesData, setAccessoriesData] = useState([]);
  
  // Search and Filter states
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAssetTypes, setSelectedAssetTypes] = useState([]);
  const [selectedAvailability, setSelectedAvailability] = useState([]);

  // Track the last processed state to prevent duplicates
  const lastProcessedStateRef = useRef(null);

  // Lazy loading states
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const observerRef = useRef();

  const itemsPerLoad = 10;

  // Transform API response to component format
  const transformAssetData = useCallback((apiAsset) => {
    return {
      id: apiAsset.id,
      pdpId: apiAsset.pdpId,
      pdpInfrastructureId: apiAsset.pdpInfrastructureId,
      assetType: apiAsset.asset_type || apiAsset.assetType,
      asset_type: apiAsset.asset_type,
      quantity: apiAsset.quantity?.toString() || "",
      yearOfPurchase: apiAsset.yop?.toString() || apiAsset.yearOfPurchase || "",
      yop: apiAsset.yop,
      available: apiAsset.available || "",
      assignedTo: apiAsset.assigned_to || apiAsset.assignedTo || "",
      assigned_to: apiAsset.assigned_to,
      slNo: apiAsset.slNo || "",
      isActive: apiAsset.isActive,
      isDeleted: apiAsset.isDeleted,
      created_at: apiAsset.created_at,
      updated_at: apiAsset.updated_at
    };
  }, []);

  // Fetch accessories from API
  const fetchAccessories = useCallback(async () => {
    if (!pdpInfrastructureId) {
      // If no infrastructure ID, use initial accessories from state as fallback
      if (initialAccessories && initialAccessories.length > 0) {
        const transformed = initialAccessories.map(transformAssetData);
        setAccessoriesData(transformed);
      } else {
        setAccessoriesData([]);
      }
      setIsLoadingData(false);
      return;
    }

    try {
      setIsLoadingData(true);
      const apiAssets = await getPdpInfrastructureAssetsByPdpInfrastructureId(pdpInfrastructureId);
      const transformed = apiAssets.map((asset, index) => ({
        ...transformAssetData(asset),
        slNo: (index + 1).toString()
      }));
      setAccessoriesData(transformed);
    } catch (error) {
      console.error("Error fetching accessories:", error);
      // Fallback to initial accessories if API fails, but only if they exist
      if (initialAccessories && initialAccessories.length > 0) {
        const transformed = initialAccessories.map(transformAssetData);
        setAccessoriesData(transformed);
      } else {
        setAccessoriesData([]);
      }
      // Don't show alert on every error, only log it
      console.warn("Failed to load accessories from API:", error.message);
    } finally {
      setIsLoadingData(false);
    }
  }, [pdpInfrastructureId, transformAssetData]);

  // Fetch accessories on mount and when pdpInfrastructureId changes
  useEffect(() => {
    fetchAccessories();
  }, [fetchAccessories]);

  // Refetch data when page is loaded/navigated to (location pathname changes)
  useEffect(() => {
    if (pdpInfrastructureId) {
      // Small delay to ensure any previous state is cleared
      const timeoutId = setTimeout(() => {
        fetchAccessories();
      }, 100);
      return () => clearTimeout(timeoutId);
    }
  }, [location.pathname, pdpInfrastructureId, fetchAccessories]);

  // Extract unique values for filters
  const assetTypeOptions = useMemo(() => {
    const uniqueTypes = [...new Set(accessoriesData.map(a => a.assetType))].filter(Boolean);
    return uniqueTypes.sort();
  }, [accessoriesData]);

  const availabilityOptions = ["Yes", "No"];

  // Filter data based on search and filters
  const filteredData = useMemo(() => {
  return accessoriesData.filter(accessory => {
    const searchLower = searchQuery.toLowerCase();

    const matchesSearch =
      String(accessory.assetType ?? "").toLowerCase().includes(searchLower) ||
      String(accessory.quantity ?? "").includes(searchLower) ||
      String(accessory.yearOfPurchase ?? "").includes(searchLower) ||
      String(accessory.available ?? "").toLowerCase().includes(searchLower) ||
      String(accessory.assignedTo ?? "").toLowerCase().includes(searchLower);

    const matchesAssetType =
      selectedAssetTypes.length === 0 ||
      selectedAssetTypes.includes(accessory.assetType);

    const matchesAvailability =
      selectedAvailability.length === 0 ||
      selectedAvailability.includes(accessory.available);

    return matchesSearch && matchesAssetType && matchesAvailability;
  });
}, [accessoriesData, searchQuery, selectedAssetTypes, selectedAvailability]);

const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const A = a[sortKey];
    const B = b[sortKey];

    if (typeof A === "number" && typeof B === "number") {
      return sortOrder === "asc" ? A - B : B - A;
    }

    return sortOrder === "asc"
      ? String(A ?? "").localeCompare(String(B ?? ""))
      : String(B ?? "").localeCompare(String(A ?? ""));
  });
}, [filteredData, sortKey, sortOrder]);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


  // Check if new accessory was added or existing accessory was updated
  useEffect(() => {
    const currentState = location.state;
    
    const stateKey = currentState?.newAccessory 
      ? `new-${JSON.stringify(currentState.newAccessory)}`
      : currentState?.updatedAccessory 
      ? `update-${currentState.updatedAccessory.id}`
      : null;

    if (!stateKey || lastProcessedStateRef.current === stateKey) {
      return;
    }

    lastProcessedStateRef.current = stateKey;

    // Always refetch from API when accessory is added or updated
    if (pdpInfrastructureId) {
      fetchAccessories();
    }

    // Clear state after a short delay to allow fetch to complete
    setTimeout(() => {
      navigate(location.pathname, { 
        replace: true, 
        state: { 
          ...location.state,
          newAccessory: undefined,
          updatedAccessory: undefined
        } 
      });
    }, 300);
  }, [location.state, location.pathname, navigate, fetchAccessories, pdpInfrastructureId]);

  // Load more items function
  const loadMoreItems = useCallback(() => {
    if (isLoading || !hasMore) return;

    setIsLoading(true);
    
    setTimeout(() => {
      const currentLength = displayedItems.length;
      const nextItems = sortedData.slice(currentLength, currentLength + itemsPerLoad);
      
      if (nextItems.length === 0) {
        setHasMore(false);
      } else {
        setDisplayedItems(prev => [...prev, ...nextItems]);
      }
      
      setIsLoading(false);
    }, 300);
  }, [displayedItems.length, sortedData, isLoading, hasMore, itemsPerLoad]);

  // Intersection Observer callback
  const lastItemRef = useCallback(node => {
    if (isLoading) return;
    if (observerRef.current) observerRef.current.disconnect();
    
    observerRef.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        loadMoreItems();
      }
    });
    
    if (node) observerRef.current.observe(node);
  }, [isLoading, hasMore, loadMoreItems]);

  // Reset displayed items when filters change
  useEffect(() => {
    setDisplayedItems(sortedData.slice(0, itemsPerLoad));
    setHasMore(sortedData.length > itemsPerLoad);
    setIsLoading(false);
  }, [sortedData, itemsPerLoad]);

  const handleBack = () => {
    const backPath ="/pdp/viewdetails"


    navigate(backPath, {
      state: {
        activeTab: "Infrastructure",
        rowData: rowData,
        rowIndex: rowIndex
      }
    });
  };

  const handleAddNew = () => {
    const addPath ="/pdp/viewdetails/infrastructure/accessories/add"

    navigate(addPath, {
      state: {
        itemType,
        year,
        facilityDefinition,
        isAdmin,
        rowData,
        rowIndex,
        pdpInfrastructureId: pdpInfrastructureId,
        pdpId: pdpId,
        returnPath: location.pathname,
        currentItems: accessoriesData
      }
    });
  };

  const handleEdit = (accessoryId) => {
    const accessoryToEdit = accessoriesData.find(a => a.id === accessoryId);
    
    const editPath =`/pdp/viewdetails/infrastructure/accessories/edit/${accessoryId}`
      

    navigate(editPath, {
      state: {
        accessoryData: accessoryToEdit,
        itemType,
        year,
        facilityDefinition,
        isAdmin,
        rowData,
        rowIndex,
        pdpInfrastructureId: pdpInfrastructureId,
        pdpId: pdpId,
        returnPath: location.pathname,
        currentItems: accessoriesData
      }
    });
  };

  const handleDelete = async (rowIdx) => {
    if (rowIdx === null || rowIdx < 0 || rowIdx >= accessoriesData.length) return;

    const accessoryToDelete = accessoriesData[rowIdx];
    if (!accessoryToDelete || !accessoryToDelete.id) {
      alert("Invalid accessory selected for deletion");
      return;
    }

    setDeleteLoading(true);

    try {
      await deletePdpInfrastructureAsset(accessoryToDelete.id);
      
      // Refetch accessories from API after successful deletion
      await fetchAccessories();

      setIsDeleteModalOpen(false);
      setSelectedRow(null);
      alert("Accessory deleted successfully!");
    } catch (error) {
      console.error("Error deleting accessory:", error);
      alert(error.message || "Failed to delete accessory. Please try again.");
    } finally {
      setDeleteLoading(false);
    }
  };

  const getPageTitle = () => {
    return `Accessories (${year})`;
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2">
            <div className="flex items-center gap-2">
              <button
                onClick={handleBack}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              >
                <ArrowLeft size={16} />
              </button>
              <div>
                <h1 className="text-base font-semibold text-darkblue1">
                  {getPageTitle()}
                </h1>
                <p className="text-sm text-gray-600 ">{facilityDefinition}</p>
              </div>
            </div>
            {!isAdmin && (
              <button
                onClick={handleAddNew}
                className="bg-darkblue1 text-white px-4 py-1.5  font-medium text-xs hover:bg-darkblue1/90 transition flex items-center justify-center gap-2 w-full sm:w-auto"
              >
                <Plus size={16} />
                Add New Accessory
              </button>
            )}
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col lg:flex-row gap-2 mb-2">
            <div className="">
              <Searchinput
                onChange={(e) => setSearchQuery(e.target.value)}
                value={searchQuery}
                placeholder="Search"
                className="w-[1/2]"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />
            </div>

            <div className="flex flex-wrap gap-2">
              {/* Asset Type Filter */}
              <Filter
                name="assetType"
                placeholder="Asset Type"
                options={assetTypeOptions}
                value={selectedAssetTypes}
                onChange={(name, value) => setSelectedAssetTypes(value)}
                customWidth="w-[120px]"
                textColor="text-black"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
              />

              {/* Availability Filter */}
              <Filter
                name="availability"
                placeholder="Available"
                options={availabilityOptions}
                value={selectedAvailability}
                onChange={(name, value) => setSelectedAvailability(value)}
                customWidth="w-[120px]"
                textColor="text-black"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
              />
            </div>
          </div>

          {/* Desktop Table */}
          <div className="hidden lg:block bg-white  shadow-md border border-Dustyblue overflow-hidden">
             <div
              ref={tableContainerRef}
              className="
    w-full 
    overflow-y-auto 
    overflow-x-hidden

 
      lg:max-h-[65vh] 
      xl:max-h-[58vh] 
      2xl:max-h-[65vh]
  "
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                  onScroll={handleTableScroll}



            >
              <table className="w-full border-collapse" style={{ borderCollapse: 'collapse' }}>
                <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                  <tr>
                    <th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b border-Dustyblue font-medium cursor-pointer select-none"
  onClick={() => handleSort("asset_type")}
>
  <div className="flex items-center gap-1">
    Asset Type
    {sortKey !== "asset_type" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
    {sortKey === "asset_type" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "asset_type" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b border-Dustyblue font-medium cursor-pointer select-none"
  onClick={() => handleSort("quantity")}
>
  <div className="flex items-center gap-1">
    Quantity
    {sortKey === "quantity" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "quantity" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b border-Dustyblue font-medium cursor-pointer select-none"
  onClick={() => handleSort("year_of_purchase")}
>
  <div className="flex items-center gap-1">
    Year of Purchase
    {sortKey === "year_of_purchase" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "year_of_purchase" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b border-Dustyblue font-medium cursor-pointer select-none"
  onClick={() => handleSort("available")}
>
  <div className="flex items-center gap-1">
    Available
    {sortKey === "available" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "available" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className={`${!isAdmin ? '' : 'border-r-0'} px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b border-Dustyblue font-medium cursor-pointer select-none`}
  onClick={() => handleSort("assigned_to")}
>
  <div className="flex items-center gap-1">
    Assigned To
    {sortKey === "assigned_to" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "assigned_to" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

{!isAdmin && (
  <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 border-b border-Dustyblue font-medium text-center">
    Actions
  </th>
)}

                  </tr>
                </thead>
                <tbody>
                  {isLoadingData && displayedItems.length === 0 && (
                    <tr>
                      <td colSpan={isAdmin ? 5 : 6} className="px-6 py-8 text-center text-gray-500">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                          Loading...
                        </div>
                      </td>
                    </tr>
                  )}
                  
                  {!isLoadingData && displayedItems.length === 0 ? (
                    <tr>
                      <td colSpan={isAdmin ? 5 : 6} className="text-center text-sm py-6 text-gray-500 italic">
                        {searchQuery || selectedAssetTypes.length > 0 || selectedAvailability.length > 0
                          ? "No matching accessories found"
                          : "No accessories added yet"}
                        {!isAdmin && !searchQuery && selectedAssetTypes.length === 0 && selectedAvailability.length === 0 && (
                          <p className="text-sm mt-2">Click "Add New Accessory" to get started</p>
                        )}
                      </td>
                    </tr>
                  ) : (
                   displayedItems.map((accessory, index) => (
                      <tr 
                        key={accessory.id}
                        ref={index === displayedItems.length - 1 ? lastItemRef : null}
                        className={`${index % 2 === 0 ? "" : ""} hover:bg-lightBlue/50 text-xs`}
                      >
                       <td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-center text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[20rem] cursor-pointer"
      onMouseEnter={() => {
        if ((accessory.assetType ?? "").length > 20) {
          setHoveredCell(`${accessory.id}-assetType`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {accessory.assetType || "-"}
    </p>

    {hoveredCell === `${accessory.id}-assetType` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {accessory.assetType}
      </span>
    )}
  </div>
</td>
<td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-center text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[10rem] cursor-pointer"
      onMouseEnter={() => {
        if ((`${accessory.quantity}` ?? "").length > 10) {
          setHoveredCell(`${accessory.id}-quantity`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {accessory.quantity ?? "-"}
    </p>

    {hoveredCell === `${accessory.id}-quantity` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {accessory.quantity}
      </span>
    )}
  </div>
</td>

                       <td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-center text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[20rem] cursor-pointer"
      onMouseEnter={() => {
        if ((`${accessory.yearOfPurchase}` ?? "").length > 10) {
          setHoveredCell(`${accessory.id}-year`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {accessory.yearOfPurchase ?? "-"}
    </p>

    {hoveredCell === `${accessory.id}-year` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {accessory.yearOfPurchase}
      </span>
    )}
  </div>
</td>

           
<td className={`${!isAdmin ? 'py-1 border border-grey2 border-t-0 border-l-0' : 'py-1 border border-grey2 border-t-0 border-l-0 border-r-0'}  px-3 py-1 text-center text-xs`}>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            accessory.available === "Yes" 
                              ? "bg-green-100 text-green-800" 
                              : "bg-red-100 text-red-800"
                          }`}>
                            { accessory.available || "-"}
                          </span>
                        </td>


                       <td className={`${!isAdmin ? "py-1 border border-grey2 border-t-0 border-l-0" : ""} px-3 text-center text-sm text-xs`}>
  <div className="relative">
    <p
      className="truncate max-w-[20rem] cursor-pointer"
      onMouseEnter={() => {
        if ((accessory.assignedTo ?? "").length > 20) {
          setHoveredCell(`${accessory.id}-assignedTo`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {accessory.assignedTo || "-"}
    </p>

    {hoveredCell === `${accessory.id}-assignedTo` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {accessory.assignedTo}
      </span>
    )}
  </div>
</td>

                        {!isAdmin && (
                          <td className="py-1 border border-grey2 border-t-0 border-r-0 border px-3  text-center">
                            <div className="flex items-center justify-center gap-4">
                              <div className="relative group">
                                <button onClick={() => handleEdit(accessory.id)}>
                               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>


                                </button>
                                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                                  Edit
                                </span>
                              </div>

                              <div className="relative group">
                                <button
                                  onClick={() => {
                                    const originalIndex = accessoriesData.findIndex(item => item.id === accessory.id);
                                    setSelectedRow(originalIndex);
                                    setIsDeleteModalOpen(true);
                                  }}
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>	

                                </button>
                                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px]  px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                                  Delete
                                </span>
                              </div>
                            </div>
                          </td>
                        )}
                      </tr>
                    ))
                  )}
                  
                  {isLoading && (
                    <tr>
                      <td colSpan={isAdmin ? 5 : 6} className="px-6 py-4 text-center text-gray-500">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                          Loading more...
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
             {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

          </div>

          {/* Mobile/Tablet Cards */}
          <div className="lg:hidden space-y-4">
            {displayedItems.length > 0 ? (
              displayedItems.map((accessory, index) => (
                <div 
                  key={accessory.id} 
                  ref={index === displayedItems.length - 1 ? lastItemRef : null}
                  className="bg-white  shadow-md border-2 border-Dustyblue p-4"
                >
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-sm font-semibold text-darkblue1">
                      {accessory.assetType || "Accessory"}
                    </span>
                    {!isAdmin && (
                      <div className="flex gap-2">
                        <button onClick={() => handleEdit(accessory.id)}>
                          <Pencil size={18} className="text-blue-600" />
                        </button>
                        <button
                          onClick={() => {
                            const originalIndex = accessoriesData.findIndex(item => item.id === accessory.id);
                            setSelectedRow(originalIndex);
                            setIsDeleteModalOpen(true);
                          }}
                        >
                          <Trash2 size={18} className="text-red-600" />
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Asset Type:</span>
                      <span className="text-gray-800">{accessory.assetType || "-"}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Quantity:</span>
                      <span className="text-gray-800">{accessory.quantity || "-"}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Year of Purchase:</span>
                      <span className="text-gray-800">{accessory.yearOfPurchase || "-"}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Available:</span>
                      <span className={`inline-block w-fit px-2 py-1 rounded-full text-xs font-medium ${
                        accessory.available === "Yes" 
                          ? "bg-green-100 text-green-800" 
                          : "bg-red-100 text-red-800"
                      }`}>
                        {accessory.available || "-"}
                      </span>
                    </div>
                    <div className="flex flex-col col-span-2">
                      <span className="font-medium text-gray-600">Assigned to:</span>
                      <span className="text-gray-800">{accessory.assignedTo || "-"}</span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-gray-500 bg-gray-50 rounded-lg">
                <p className="text-lg font-medium mb-2">
                  {searchQuery || selectedAssetTypes.length > 0 || selectedAvailability.length > 0
                    ? "No matching accessories found"
                    : "No accessories added yet"}
                </p>
                {!isAdmin && !searchQuery && selectedAssetTypes.length === 0 && selectedAvailability.length === 0 && (
                  <p className="text-sm">Click "Add New Accessory" to get started</p>
                )}
              </div>
            )}
            
            {isLoading && (
              <div className="px-6 py-4 text-center text-gray-500">
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                  Loading more...
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {isDeleteModalOpen && selectedRow !== null && (
        <DeleteModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            if (!deleteLoading) {
              setIsDeleteModalOpen(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={() => handleDelete(selectedRow)}
          loading={deleteLoading}
          extraMessage="This will delete all the records related to this accessory."
        />
      )}
    </div>
  );
};

export default InfrastructureAccessoriesPage;