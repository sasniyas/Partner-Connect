import React, { useState, useEffect } from "react";
import { X, Send, Frown } from "lucide-react";
import { addPdpActionLog, getPdpActionLogsByActionItem } from "../../../../../services/PDP/PdpActionItem/pdpActionItemLog.service";

const CommentPopup = ({ isOpen, onClose, actionItemId, onCommentAdded }) => {
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (isOpen && actionItemId) {
      loadComments();
    } else {
      // Reset state when popup closes
      setComment("");
      setComments([]);
      setError(null);
    }
  }, [isOpen, actionItemId]);

  const loadComments = async () => {
    if (!actionItemId) return;

    try {
      setIsLoading(true);
      setError(null);
      
      console.log("📡 Loading comments for action item:", actionItemId);
      const response = await getPdpActionLogsByActionItem(actionItemId);
      
      if (response && response.data) {
        // Filter to only show logs with comments
        const logsWithComments = response.data
          .filter(log => log.comment && log.comment.trim() !== "")
          .map(log => ({
            id: log.id,
            comment: log.comment,
            createdDate: log.createdOn,
            updatedBy: log.updated_by_name 
              ? `${log.updated_by_name} ${log.updated_by_lastname || ''}`.trim()
              : log.updated_by_email || "Unknown",
          }));
        
        setComments(logsWithComments);
      }
    } catch (err) {
      console.error("❌ Error loading comments:", err);
      setError(err.message || "Failed to load comments");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!comment.trim() || !actionItemId) return;

    try {
      setIsSubmitting(true);
      setError(null);
      
      console.log("📡 Adding comment:", { actionItemId, comment });
      
      await addPdpActionLog({
        pdp_action_item: actionItemId,
        comment: comment.trim(),
      });
      
      console.log("✅ Comment added successfully");
      
      // Clear input and reload comments
      setComment("");
      await loadComments();
      
      // Notify parent component
      if (onCommentAdded) {
        onCommentAdded();
      }
    } catch (err) {
      console.error("❌ Error adding comment:", err);
      setError(err.message || "Failed to add comment");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Format time helper
  const formatTime = (dateString) => {
    if (!dateString) return "-";
    try {
      const date = new Date(dateString);
      const now = new Date();
      const diffMs = now - date;
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMs / 3600000);
      const diffDays = Math.floor(diffMs / 86400000);

      if (diffMins < 1) return "Just now";
      if (diffMins < 60) return `${diffMins}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      if (diffDays < 7) return `${diffDays}d ago`;
      
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
      });
    } catch {
      return dateString;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-white shadow-lg w-full max-w-lg max-h-[80vh] flex flex-col relative animate-fadeIn">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-gray-200">
          <h2 className="font-semibold text-darkblue1 text-base">Comments</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-red-50 rounded-full transition-colors"
            aria-label="Close"
          >
            <X size={18} className="text-gray-600 hover:text-red-600" />
          </button>
        </div>

        {/* Comments List */}
        <div className="flex-1 overflow-auto p-4">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1 mb-3"></div>
              <span className="text-gray-500 text-sm">Loading comments...</span>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center py-8">
              <Frown size={32} className="text-red-400 mb-3" />
              <span className="text-red-500 text-sm">{error}</span>
            </div>
          ) : comments.length > 0 ? (
            <div className="space-y-4">
              {comments.map((item, idx) => (
                <div key={item.id || idx} className="bg-gray-50 p-3 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-xs font-medium text-darkblue1">{item.updatedBy}</span>
                    <span className="text-xs text-gray-400">{formatTime(item.createdDate)}</span>
                  </div>
                  <p className="text-sm text-gray-700">{item.comment}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-gray-500">
              <Frown size={32} className="text-gray-300 mb-3" />
              <p className="italic text-sm">No comments yet</p>
              <p className="text-xs text-gray-400 mt-1">Be the first to comment!</p>
            </div>
          )}
        </div>

        {/* Comment Input */}
        <form onSubmit={handleSubmit} className="border-t border-gray-200 p-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Add a comment..."
              className="flex-1 px-4 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-darkblue1 focus:border-transparent"
              disabled={isSubmitting}
            />
            <button
              type="submit"
              disabled={!comment.trim() || isSubmitting}
              className={`px-4 py-2 bg-darkblue1 text-white rounded-lg flex items-center gap-2 transition-colors ${
                !comment.trim() || isSubmitting
                  ? "opacity-50 cursor-not-allowed"
                  : "hover:bg-darkblue1/90"
              }`}
            >
              {isSubmitting ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              ) : (
                <Send size={16} />
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Animation styles */}
      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
        .animate-fadeIn {
          animation: fadeIn 0.2s ease-out;
        }
      `}</style>
    </div>
  );
};

export default CommentPopup;