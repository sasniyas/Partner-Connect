import React, { useState, useRef, useEffect, useCallback } from "react";
import Header from "../../../../../Components/Header";
import SubNavbar3 from "../../../../../Components/SubNavbar3";
import { ArrowLeft } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import StyledSelectField from "../../../../../Components/StyledSelectField";
import StyledDateField from "../../../../../Components/StyledDatefield";
import { addPdpActionItem, getUsersByPdpDealer } from "../../../../../services/PDP/PdpActionItem/pdpActionItem.service";
import { getAllUsers } from "../../../../../services/userManagement/userManagement.service";
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation";
import { API } from "../../../../../api";

export default function AddActionForm() {
  const location = useLocation();
  const navigate = useNavigate();
  const rowData = location.state?.rowData;

  const formRef = useRef(null);

  // Try to get pdp_id from multiple possible sources
  const pdp_id =
    location.state?.pdp_id ||
    rowData?.id ||
    rowData?.pdp_id ||
    location.state?.id;

  // Form data state
  const [formData, setFormData] = useState({
    focusArea: "",
    priority: "",
    objective: "",
    targetDate: "",
    actionsToAchieve: "",
    responsibility: "",
  });

  // Dropdown open states
  const [dropdowns, setDropdowns] = useState({
    focusArea: false,
    priority: false,
    responsibility: false,
  });

  const focusAreaRef = useRef();
  const priorityRef = useRef();
  const responsibilityRef = useRef();
  const refs = {
    focusArea: focusAreaRef,
    priority: priorityRef,
    responsibility: responsibilityRef,
  };

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [submitError, setSubmitError] = useState("");

  const [users, setUsers] = useState([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);

  // ═══════════════════════════════════════════════════════════════
  // CURRENT USER — exclude self from responsibility (MM rule)
  // ═══════════════════════════════════════════════════════════════
  const [currentUserId, setCurrentUserId] = useState(null);

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const token =
          localStorage.getItem("userToken") ||
          localStorage.getItem("superUserToken");
        if (!token) return;
        const userData = localStorage.getItem("userData");
        if (userData) {
          const parsed = JSON.parse(userData);
          if (parsed?.id) { setCurrentUserId(parsed.id); return; }
        }
        const response = await fetch(`${API.domain}${API.userManagement.logedInUser}`, {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });
        const result = await response.json();
        if (result?.data?.id) setCurrentUserId(result.data.id);
      } catch {}
    };
    fetchCurrentUser();
  }, []);

  const focusAreaOptions = [
    "Uptime & Parts",
    "DD- CD and Infra",
    "Finance",
    "Key Accounts",
    "Machine Attach- sales",
    "Marcom",
    "People and Culture",
    "Territory Focus",
  ];
  const priorityOptions = ["High", "Medium", "Low"];

  // Close all dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      const anyOpenDropdown = Object.keys(refs).some((key) => {
        const ref = refs[key];
        return ref.current && ref.current.contains(event.target);
      });
      if (!anyOpenDropdown) {
        setDropdowns({ focusArea: false, priority: false, responsibility: false });
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // LOAD USERS — dealer-scoped, same as MM's getUsersByMonthlyMeetingDealer
  // Uses getUsersByPdpDealer(pdpId) → only users mapped to this dealer
  // Falls back to getAllUsers if pdp_id is not available
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const loadUsers = async () => {
      try {
        setIsLoadingUsers(true);
        if (pdp_id) {
          const response = await getUsersByPdpDealer(pdp_id);
          if (response.status && response.data) {
            // Map userId → id for consistency (same as MM pattern)
            const mappedUsers = response.data.map((user) => ({
              id: user.userId,
              firstName: user.firstName,
              lastName: user.lastName,
            }));
            setUsers(mappedUsers);
          } else {
            // Fallback to all users if dealer fetch returns empty
            const usersList = await getAllUsers();
            setUsers(usersList || []);
          }
        } else {
          // No pdp_id available — fallback to all users
          const usersList = await getAllUsers();
          setUsers(usersList || []);
        }
      } catch (error) {
        setUsers([]);
      } finally {
        setIsLoadingUsers(false);
      }
    };
    loadUsers();
  }, [pdp_id]);

  const handleChange = useCallback((field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => {
      if (!prev[field]) return prev;
      return { ...prev, [field]: "" };
    });
  }, []);

  const handleResponsibilityChange = useCallback(
    (selectedLabel) => {
      if (typeof selectedLabel === "object" && selectedLabel !== null) {
        setFormData((prev) => ({ ...prev, responsibility: selectedLabel.value }));
        setErrors((prev) => ({ ...prev, responsibility: "" }));
        return;
      }
      const selectedUser = users.find((user) => {
        const userLabel =
          user.name ||
          `${user.firstName || ""} ${user.lastName || ""}`.trim() ||
          user.email ||
          `User ${user.id}`;
        return userLabel === selectedLabel;
      });
      if (selectedUser) {
        setFormData((prev) => ({ ...prev, responsibility: selectedUser.id }));
        setErrors((prev) => ({ ...prev, responsibility: "" }));
      } else {
        setFormData((prev) => ({ ...prev, responsibility: "" }));
      }
    },
    [users]
  );

  const getResponsibilityDisplayName = useCallback(() => {
    if (!formData.responsibility) return "";
    const user = users.find(
      (u) =>
        u.id === formData.responsibility ||
        u.id === parseInt(formData.responsibility, 10)
    );
    if (user) {
      return (
        user.name ||
        `${user.firstName || ""} ${user.lastName || ""}`.trim() ||
        user.email ||
        `User ${user.id}`
      );
    }
    return "";
  }, [formData.responsibility, users]);

  const validateForm = () => {
    const newErrors = {};
    if (!formData.focusArea) newErrors.focusArea = "Focus Area is required";
    if (!formData.priority) newErrors.priority = "Priority is required";
    if (!formData.objective || formData.objective.trim() === "")
      newErrors.objective = "Objective is required";
    if (!formData.responsibility || formData.responsibility.toString().trim() === "")
      newErrors.responsibility = "Responsibility is required";
    if (!formData.actionsToAchieve || formData.actionsToAchieve.trim() === "")
      newErrors.actionsToAchieve = "Actions to Achieve is required";
    if (!formData.targetDate) newErrors.targetDate = "Target Date is required";
    return newErrors;
  };

  const handleSave = async () => {
    if (!pdp_id) {
      setSubmitError("PDP ID is required. Please go back and select a PDP.");
      return;
    }

    const newErrors = validateForm();
    setErrors(newErrors);
    setSubmitError("");

    if (Object.keys(newErrors).length > 0) {
      const firstErrorField = Object.keys(newErrors)[0];
      const element = document.querySelector(`[name="${firstErrorField}"]`);
      if (element) element.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    try {
      setIsLoading(true);
      setSubmitError("");

      const payload = {
        pdp: parseInt(pdp_id, 10),
        focus_area: formData.focusArea,
        objective: formData.objective.trim(),
        priority: formData.priority,
        actions_to_achieve: formData.actionsToAchieve?.trim() || null,
        responsibility: formData.responsibility
          ? parseInt(formData.responsibility, 10)
          : null,
        target_date: formData.targetDate || null,
        status: "Open", // Only "Open" allowed when creating — same as MM
        isActive: true,
      };

      await addPdpActionItem(payload);

      navigate("/pdp/view/actionplannermanagemnet", {
        state: {
          rowData,
          newRow: true,
          message: "Action item created successfully",
        },
      });
    } catch (err) {
      setSubmitError(
        err.message || "Failed to create action item. Please try again."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => navigate(-1);

  // ═══════════════════════════════════════════════════════════════
  // USER OPTIONS — filter out current user (same as MM rule)
  // Backend enforces: created_by !== responsibility
  // ═══════════════════════════════════════════════════════════════
  const userOptions = React.useMemo(() => {
    return users
      .filter(
        (user) =>
          user.id !== currentUserId &&
          user.id !== parseInt(currentUserId, 10)
      )
      .map((user) => ({
        label:
          user.name ||
          `${user.firstName || ""} ${user.lastName || ""}`.trim() ||
          user.email ||
          `User ${user.id}`,
        value: user.id,
      }));
  }, [users, currentUserId]);

  useKeyboardNavigation({
    containerRef: formRef,
    onSubmit: () => { handleSave(); },
    onCancel: () => { handleCancel(); },
  });

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={false} setMenuOpen={() => {}} />
      <SubNavbar3 />

      <div ref={formRef} className="flex justify-center">
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              size={24}
              onClick={handleCancel}
              className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
            />
            <h2 className="text-base font-semibold font-VolvoNovum text-darkblue1">
              {rowData
                ? `${rowData?.year} - ${rowData.marketArea || "N/A"} - ${
                    rowData.dealer || rowData.dealerName || rowData.dealerShortName || rowData.dealerFullName || "N/A"
                  } - Add New Action Item`
                : "Add New PDP Action Item"}
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[10%] mt-0 ml-[2.7%] mb-4"></div>

          {/* Missing PDP ID warning */}
          {!pdp_id && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 flex items-start gap-2">
              <svg className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
              <p className="text-red-600 text-sm flex-1">
                PDP ID is missing. Please go back and navigate here from a valid PDP record.
              </p>
            </div>
          )}

          {/* Form Card */}
          <div className="bg-white shadow-md border border-Dustyblue p-6 mb-6">
            {/* Row 1 */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-4">
              <div>
                <StyledSelectField
                  label="Focus Area"
                  placeholder="Select Focus Area"
                  value={formData.focusArea}
                  setValue={(val) => handleChange("focusArea", val)}
                  options={focusAreaOptions}
                  dropdownOpen={dropdowns.focusArea}
                  setDropdownOpen={(val) => setDropdowns({ ...dropdowns, focusArea: val })}
                  dropdownRef={refs.focusArea}
                  error={errors.focusArea}
                  required
                />
              </div>

              <div>
                <StyledSelectField
                  label="Priority"
                  placeholder="Select Priority"
                  value={formData.priority}
                  setValue={(val) => handleChange("priority", val)}
                  options={priorityOptions}
                  dropdownOpen={dropdowns.priority}
                  setDropdownOpen={(val) => setDropdowns({ ...dropdowns, priority: val })}
                  dropdownRef={refs.priority}
                  error={errors.priority}
                  required
                />
              </div>

              <div>
                <StyledSelectField
                  label="Responsibility"
                  placeholder={isLoadingUsers ? "Loading users..." : "Select Responsibility"}
                  value={getResponsibilityDisplayName()}
                  setValue={handleResponsibilityChange}
                  options={userOptions}
                  dropdownOpen={dropdowns.responsibility}
                  setDropdownOpen={(val) => setDropdowns({ ...dropdowns, responsibility: val })}
                  dropdownRef={refs.responsibility}
                  error={errors.responsibility}
                  disabled={isLoadingUsers}
                  required
                />
              </div>

              <div className="mt-1">
                <StyledDateField
                  label="Target Date"
                  value={formData.targetDate}
                  setValue={(date) => handleChange("targetDate", date)}
                  required
                  error={errors.targetDate}
                />
              </div>
            </div>

            {/* Row 2 — Text Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
              <div>
                <label className="block text-xs font-medium text-black/70 mb-2">
                  Objective <span className="text-red1">*</span>
                </label>
                <textarea
                  name="objective"
                  value={formData.objective}
                  onChange={(e) => handleChange("objective", e.target.value)}
                  placeholder="Enter objective..."
                  rows={4}
                  className={`w-full px-4 py-2 text-xs focus:outline-none border transition-colors resize-none ${
                    errors.objective
                      ? "border-red1 focus:ring-1 focus:ring-red1"
                      : "border-black/30 focus:ring-1 focus:ring-darkblue1"
                  }`}
                  autoComplete="off"
                />
                {errors.objective && (
                  <p className="text-red1 text-xs mt-1">{errors.objective}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-black/70 mb-2">
                  Actions to Achieve <span className="text-red1">*</span>
                </label>
                <textarea
                  name="actionsToAchieve"
                  value={formData.actionsToAchieve}
                  onChange={(e) => handleChange("actionsToAchieve", e.target.value)}
                  placeholder="Enter actions to achieve..."
                  rows={4}
                  className={`w-full px-4 py-2 text-xs focus:outline-none border transition-colors resize-none ${
                    errors.actionsToAchieve
                      ? "border-red1 focus:ring-1 focus:ring-red1"
                      : "border-black/30 focus:ring-1 focus:ring-darkblue1"
                  }`}
                  autoComplete="off"
                />
                {errors.actionsToAchieve && (
                  <p className="text-red1 text-xs mt-1">{errors.actionsToAchieve}</p>
                )}
              </div>
            </div>
          </div>

          {/* Error Message */}
          {submitError && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 flex items-start gap-2">
              <svg className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
              <p className="text-red-600 text-sm flex-1">{submitError}</p>
            </div>
          )}

          {/* Buttons */}
          <div className="flex justify-end gap-3">
            <button
              onClick={handleCancel}
              disabled={isLoading}
              className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs hover:bg-mildBlue1 hover:scale-105"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={isLoading}
              className={`bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition-all duration-200 ${
                isLoading ? "opacity-50 cursor-not-allowed" : "hover:shadow-lg"
              }`}
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Saving...
                </span>
              ) : (
                "Save"
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}