import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { createPortal } from "react-dom";
import { useNavigate, useLocation } from "react-router-dom";
import Header from "../../../../../Components/Header";
import SubNavbar3 from "../../../../../Components/SubNavbar3";
import Searchinput from "../../../../../Components/Searchinput";
import Filter from "../../../../../Components/Filter";
import {
  ArrowLeft, Plus, Frown, MoreVertical, ChevronDown, ChevronUp,
  ArrowUp, ArrowDown, ChevronsUpDown,
} from "lucide-react";
import LogPopup from "./LogPopup";
import CommentPopup from "./CommentPopup";
import DeleteModal from "../../../../../Components/DeleteModal";
import { getAllPdpActionItem, deletePdpActionItem, getPdpTargetDateHistory } from "../../../../../services/PDP/PdpActionItem/pdpActionItem.service";
import { API } from "../../../../../api";
import ExpandableTargetDate from "../../../../../Components/Expandabletargetdate";

// ═══════════════════════════════════════════════════════════════
// ExpandableText — same as MM's ExpandableText
// ═══════════════════════════════════════════════════════════════
const ExpandableText = ({ text, maxLines = 2 }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [needsExpansion, setNeedsExpansion] = useState(false);
  const textRef = useRef(null);

  useEffect(() => {
    if (textRef.current) {
      const lineHeight = parseInt(window.getComputedStyle(textRef.current).lineHeight) || 16;
      const maxHeight = lineHeight * maxLines;
      setNeedsExpansion(textRef.current.scrollHeight > maxHeight + 5);
    }
  }, [text, maxLines]);

  if (!text || text === "-" || text === "N/A")
    return <span className="text-gray-400">-</span>;

  return (
    <div className="relative">
      <div
        ref={textRef}
        className="whitespace-pre-wrap break-words transition-all duration-200"
        style={
          !isExpanded && needsExpansion
            ? {
                display: "-webkit-box",
                WebkitLineClamp: maxLines,
                WebkitBoxOrient: "vertical",
                overflow: "hidden",
              }
            : {}
        }
      >
        {text}
      </div>
      {needsExpansion && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setIsExpanded(!isExpanded);
          }}
          className="text-blue-600 hover:text-blue-800 text-[10px] font-medium mt-0.5 hover:underline"
        >
          {isExpanded ? "Show less" : "Show more"}
        </button>
      )}
    </div>
  );
};

// ─── Date formatting ────────────────────────────────────────────
const formatDateForDisplay = (dateString) => {
  if (!dateString || dateString === "-" || dateString === "null" || dateString === null)
    return "-";
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "-";
    const day = date.getDate().toString().padStart(2, "0");
    const month = (date.getMonth() + 1).toString().padStart(2, "0");
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  } catch {
    return "-";
  }
};

function ActionPlannerManagement() {
  const navigate = useNavigate();
  const location = useLocation();
  const rowData = location.state?.rowData;
  const activeTab = location.state?.activeTab || "";

  // ── Sort state ──────────────────────────────────────────────
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null);

  // ── Sign-off status ─────────────────────────────────────────
  const signOffStatus =
    rowData?.signOffStatus ||
    rowData?.pdpSignOffStatus ||
    rowData?.sign_of_status ||
    rowData?.sign_off_status ||
    "";
  const isSignOffCompleted = signOffStatus === "Completed";

  // ── Scroll state ────────────────────────────────────────────
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollDirection, setScrollDirection] = useState(null);
  const [lastScrollTop, setLastScrollTop] = useState(0);

  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    if (scrollTop > lastScrollTop) setScrollDirection("down");
    else if (scrollTop < lastScrollTop) setScrollDirection("up");
    setLastScrollTop(scrollTop);

    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  const scrollToTop = () => {
    if (tableContainerRef.current)
      tableContainerRef.current.scrollTo({ top: 0, behavior: "smooth" });
  };
  const scrollToBottom = () => {
    if (tableContainerRef.current)
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth",
      });
  };

  // ── Table state ─────────────────────────────────────────────
  const [tableData, setTableData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [openDropdown, setOpenDropdown] = useState(null);
  const [dropdownStyle, setDropdownStyle] = useState({});
  const [selectedRow, setSelectedRow] = useState(null);
  const [hoveredCell, setHoveredCell] = useState(null);

  const [isLogOpen, setIsLogOpen] = useState(false);
  const [logsData, setLogsData] = useState(null);
  const [isCommentOpen, setIsCommentOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const tableContainerRef = useRef(null);
  const dropdownRef = useRef(null);

  // ── Filter state ─────────────────────────────────────────────
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFocusArea, setSelectedFocusArea] = useState([]);
  const [selectedPriority, setSelectedPriority] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState([]);

  const filterStatusOptions = ["Open", "In Progress", "Closed"];
  const focusAreaOptions = [
    "Uptime & Parts", "DD- CD and Infra", "Finance", "Key Accounts",
    "Machine Attach- sales", "Marcom", "People and Culture", "Territory Focus",
  ];
  const priorityOptions = ["High", "Medium", "Low"];

  // ═══════════════════════════════════════════════════════════════
  // CURRENT USER & ROLE DETECTION — same as MM
  // ═══════════════════════════════════════════════════════════════
  const [currentUserId, setCurrentUserId] = useState(null);
  const [currentUserRole, setCurrentUserRole] = useState(null);

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const userData = localStorage.getItem("userData");
        if (userData) {
          const parsed = JSON.parse(userData);
          if (parsed?.id) setCurrentUserId(parsed.id);
          if (parsed?.persona) setCurrentUserRole(parsed.persona?.toLowerCase());
          else if (parsed?.role) setCurrentUserRole(parsed.role?.toLowerCase());
          else if (parsed?.userRole) setCurrentUserRole(parsed.userRole?.toLowerCase());
          else if (parsed?.user_role) setCurrentUserRole(parsed.user_role?.toLowerCase());
          return;
        }
        const token =
          localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return;

        if (localStorage.getItem("superUserToken")) {
          setCurrentUserRole("admin");
        }

        const response = await fetch(`${API.domain}${API.userManagement.logedInUser}`, {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });
        const result = await response.json();
        if (result?.data?.id) setCurrentUserId(result.data.id);
        if (result?.data?.persona) setCurrentUserRole(result.data.persona?.toLowerCase());
        else if (result?.data?.role) setCurrentUserRole(result.data.role?.toLowerCase());
      } catch (err) {
        console.warn("Failed to fetch current user:", err);
      }
    };
    fetchCurrentUser();
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // PERMISSION HELPERS — same pattern as MM
  // ═══════════════════════════════════════════════════════════════
  const isAdmin = useCallback(() => {
    return (
      currentUserRole === "admin" ||
      currentUserRole === "administrator" ||
      currentUserRole === "superadmin" ||
      currentUserRole === "super_admin"
    );
  }, [currentUserRole]);

  const isCreator = useCallback(
    (item) => {
      if (!currentUserId) return false;
      const createdById = item.createdById || item._original?.created_by;
      return currentUserId === createdById || currentUserId === parseInt(createdById, 10);
    },
    [currentUserId]
  );

  const isResponsiblePerson = useCallback(
    (item) => {
      if (!currentUserId) return false;
      const responsibilityId = item.responsibilityId || item._original?.responsibility;
      return (
        currentUserId === responsibilityId ||
        currentUserId === parseInt(responsibilityId, 10)
      );
    },
    [currentUserId]
  );

  const canViewItem = useCallback(
    (item) => {
      if (isAdmin()) return true;
      if (isCreator(item)) return true;
      if (isResponsiblePerson(item)) return true;
      return false;
    },
    [isAdmin, isCreator, isResponsiblePerson]
  );

  const canFullEdit = useCallback(
    (item) => {
      if (isAdmin()) return true;
      if (isCreator(item)) return true;
      return false;
    },
    [isAdmin, isCreator]
  );

  const canLimitedEdit = useCallback(
    (item) => {
      if (isAdmin() || isCreator(item)) return false;
      if (isResponsiblePerson(item)) return true;
      return false;
    },
    [isAdmin, isCreator, isResponsiblePerson]
  );

  const canDeleteItem = useCallback(
    (item) => isAdmin(),
    [isAdmin]
  );

  // ── getEditAction — returns button label + type (same as MM) ──
  const getEditAction = (item) => {
    if (item.status === "Closed" && !isAdmin()) {
      return { label: "View", type: "view" };
    }
    if (item.status === "Closed" && isAdmin()) {
      return { label: "Edit", type: "full_edit" };
    }
    if (canLimitedEdit(item)) {
      return { label: "Update", type: "limited_edit" };
    }
    if (canFullEdit(item)) {
      return { label: "Edit", type: "full_edit" };
    }
    return { label: "View", type: "view" };
  };

  // ── Transform API data — includes new fields ─────────────────
  const transformApiData = useCallback(
    (apiItem) => ({
      id: apiItem.id,
      pdpId: apiItem.pdp,
      year: rowData?.year || new Date(apiItem.created_on).getFullYear().toString(),
      createdDate: formatDateForDisplay(apiItem.created_on),
      createdBy: apiItem.created_by_info?.user_name || apiItem.created_by_name || "-",
      createdById: apiItem.created_by,
      focusArea: apiItem.focus_area || "-",
      priority: apiItem.priority || "-",
      objective: apiItem.objective || "-",
      actionsToAchieve: apiItem.actions_to_achieve || "-",
      actionsProgressUpdate: apiItem.actions_progress_update || "-",
      closureAction: apiItem.closure_action || "-",    // ← NEW from MM
      comments: apiItem.comments || "",               // ← NEW from MM
      responsibility: apiItem.responsibility_info?.user_name || apiItem.responsibility_name || "-",
      responsibilityId: apiItem.responsibility,
      targetDate: apiItem.target_date,
      completedDate: apiItem.completed_date,
      status: apiItem.status || "Open",
      isActive: apiItem.isActive,
      targetDataChange: apiItem.target_data_change,   // amber badge flag
      updatedOn: apiItem.updated_on,
      _original: apiItem,
    }),
    [rowData?.year]
  );

  // ── Load action items ────────────────────────────────────────
  const loadActionItems = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const filters = {};
      if (rowData?.id) filters.pdp_id = rowData.id;
      const response = await getAllPdpActionItem(filters);
      setTableData(response.map(transformApiData));
    } catch (err) {
      setError(err.message || "Failed to load");
      setTableData([]);
    } finally {
      setIsLoading(false);
    }
  }, [rowData?.id, transformApiData]);

  useEffect(() => {
    loadActionItems();
  }, [loadActionItems]);

  useEffect(() => {
    if (location.state?.newRow || location.state?.updatedRow) {
      loadActionItems();
      navigate(location.pathname, { replace: true, state: { rowData, activeTab } });
    }
  }, [location.state?.newRow, location.state?.updatedRow]);

  // ── Close dropdown on outside click ─────────────────────────
  useEffect(() => {
    const handleClickOutside = (event) => {
      const isInsideContainer = event.target.closest("[data-dropdown-container]");
      const isInsidePortal = dropdownRef.current && dropdownRef.current.contains(event.target);
      if (!isInsideContainer && !isInsidePortal && openDropdown !== null) {
        setOpenDropdown(null);
      }
    };
    if (openDropdown !== null) {
      document.addEventListener("mousedown", handleClickOutside);
      return () => document.removeEventListener("mousedown", handleClickOutside);
    }
  }, [openDropdown]);

  // ── Close dropdown on scroll ─────────────────────────────────
  useEffect(() => {
    const tableContainer = tableContainerRef.current;
    if (!tableContainer || openDropdown === null) return;
    const handleScroll = () => setOpenDropdown(null);
    tableContainer.addEventListener("scroll", handleScroll);
    window.addEventListener("scroll", handleScroll);
    return () => {
      tableContainer.removeEventListener("scroll", handleScroll);
      window.removeEventListener("scroll", handleScroll);
    };
  }, [openDropdown]);

  // ── Sort handler ─────────────────────────────────────────────
  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") { setSortOrder("desc"); return; }
      if (sortOrder === "desc") { setSortKey(null); setSortOrder(null); return; }
    }
    setSortKey(key);
    setSortOrder("asc");
  };

  // ═══════════════════════════════════════════════════════════════
  // ROLE-BASED VISIBILITY — same as MM's visibleData
  // ═══════════════════════════════════════════════════════════════
  const visibleData = useMemo(() => {
    // While user is still loading, show all to avoid flicker
    if (!currentUserId && !currentUserRole) return tableData;
    return tableData.filter((item) => canViewItem(item));
  }, [tableData, canViewItem, currentUserId, currentUserRole]);

  // ── Filtered data ────────────────────────────────────────────
  const filteredData = useMemo(() => {
    return visibleData.filter((item) => {
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesSearch = [
          item.focusArea, item.objective, item.actionsToAchieve, item.actionsProgressUpdate,
          item.closureAction, item.comments, item.responsibility, item.createdBy,
          item.priority, item.status,
        ].some((val) => val && val.toString().toLowerCase().includes(query));
        if (!matchesSearch) return false;
      }
      const matchesFocusArea =
        selectedFocusArea.length === 0 || selectedFocusArea.includes(item.focusArea);
      const matchesPriority =
        selectedPriority.length === 0 || selectedPriority.includes(item.priority);
      const matchesStatus =
        selectedStatus.length === 0 || selectedStatus.includes(item.status);
      return matchesFocusArea && matchesPriority && matchesStatus;
    });
  }, [visibleData, searchQuery, selectedFocusArea, selectedPriority, selectedStatus]);

  // ── Sorted data ──────────────────────────────────────────────
  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredData;
    return [...filteredData].sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];
      if (valA == null) return 1;
      if (valB == null) return -1;
      if (typeof valA === "number" && typeof valB === "number")
        return sortOrder === "asc" ? valA - valB : valB - valA;
      return sortOrder === "asc"
        ? valA.toString().localeCompare(valB.toString())
        : valB.toString().localeCompare(valA.toString());
    });
  }, [filteredData, sortKey, sortOrder]);

  // ── Status / Priority colors ─────────────────────────────────
  const getStatusColor = useCallback((status) => {
    switch (status) {
      case "Closed": case "Completed": return "text-green-600";
      case "In Progress": return "text-orange-600";
      case "Open": return "text-blue-600";
      default: return "text-gray-600";
    }
  }, []);

  const getStatusBgColor = useCallback((status) => {
    switch (status) {
      case "Closed": case "Completed": return "bg-green-100 text-green-700";
      case "In Progress": return "bg-orange-100 text-orange-700";
      case "Open": return "bg-blue-100 text-blue-700";
      default: return "bg-gray-100 text-gray-700";
    }
  }, []);

  const getPriorityColor = useCallback((priority) => {
    switch (priority) {
      case "High": return "bg-red-100 text-red-700";
      case "Medium": return "bg-orange-100 text-orange-700";
      case "Low": return "bg-green-100 text-green-700";
      default: return "bg-gray-100 text-gray-700";
    }
  }, []);

  // ── Handlers ─────────────────────────────────────────────────
  const handleBack = useCallback(() => navigate(-1), [navigate]);

  const handleDeleteClick = useCallback((item) => {
    setSelectedRow(item);
    setIsDeleteOpen(true);
    setOpenDropdown(null);
  }, []);

  const confirmDelete = async () => {
    if (!selectedRow) return;
    try {
      setIsDeleting(true);
      await deletePdpActionItem(selectedRow.id);
      setTableData((prev) => prev.filter((row) => row.id !== selectedRow.id));
      setIsDeleteOpen(false);
      setSelectedRow(null);
    } catch (err) {
      alert(err.message || "Failed to delete");
    } finally {
      setIsDeleting(false);
    }
  };

  const handleAddNew = useCallback(() => {
    const pdpId = rowData?.id || rowData?.pdp_id || rowData?.pdp;
    if (!pdpId) { alert("PDP ID is missing."); return; }
    navigate("/pdp/view/actionplannermanagemnet/add", {
      state: { rowData, pdp_id: pdpId },
    });
  }, [navigate, rowData]);

  const handleEdit = useCallback(
    (item) => {
      navigate("/pdp/view/actionplannermanagemnet/edit", {
        state: { rowData: item, pdpRowData: rowData },
      });
      setOpenDropdown(null);
    },
    [navigate, rowData]
  );

  // ── Log popup — pass full logsData object same as MM ─────────
  const handleViewLogs = useCallback((item) => {
    setLogsData(item);   // pass full row so popup shows topic/responsibility/status
    setSelectedRow(item);
    setIsLogOpen(true);
    setOpenDropdown(null);
  }, []);

  const handleSearchChange = useCallback((e) => setSearchQuery(e.target.value), []);

  // ── Dropdown toggle with portal positioning ───────────────────
  const handleDropdownToggle = useCallback(
    (e, itemId) => {
      e.stopPropagation();
      if (openDropdown === itemId) { setOpenDropdown(null); return; }
      const button = e.currentTarget;
      const buttonRect = button.getBoundingClientRect();
      const spaceBelow = window.innerHeight - buttonRect.bottom;
      const dropdownHeight = 120;
      let style = {
        position: "fixed",
        right: window.innerWidth - buttonRect.right,
        zIndex: 9999,
      };
      if (spaceBelow < dropdownHeight && buttonRect.top > dropdownHeight) {
        style.bottom = window.innerHeight - buttonRect.top + 4;
      } else {
        style.top = buttonRect.bottom + 4;
      }
      setDropdownStyle(style);
      setOpenDropdown(itemId);
    },
    [openDropdown]
  );

  // ── Sort icon ─────────────────────────────────────────────────
  const SortIcon = ({ colKey }) => {
    if (sortKey !== colKey) return null;
    return sortOrder === "asc"
      ? <ChevronUp className="w-3 h-3 text-white" />
      : <ChevronDown className="w-3 h-3 text-white" />;
  };

  // ── Hoverable cell ────────────────────────────────────────────
  const HoverCell = ({ rowId, field, value, maxLen = 10 }) => (
    <div className="relative">
      <p
        className="truncate cursor-pointer"
        onMouseEnter={() => { if (value && value.length > maxLen) setHoveredCell(`${rowId}-${field}`); }}
        onMouseLeave={() => setHoveredCell(null)}
      >
        {value || "-"}
      </p>
      {hoveredCell === `${rowId}-${field}` && (
        <span className="absolute left-1/2 top-full mt-1 bg-darkblue1 text-white text-[10px] px-2 py-0.5 whitespace-nowrap transform -translate-x-1/2 z-10 pointer-events-none">
          {value}
        </span>
      )}
    </div>
  );

  // ── Mobile Card ───────────────────────────────────────────────
  const ActionItemCard = React.memo(({ item }) => {
    const action = getEditAction(item);

    return (
      <div className="bg-white shadow-md border border-gray-300 p-4 mb-4 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between mb-3 pb-3 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBgColor(item.status)}`}>
              {item.status}
            </span>
            {(item.targetDataChange === 1 || item.targetDataChange === true) && (
              <span className="text-[9px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded border border-amber-200">
                Date Chg. Req.
              </span>
            )}
          </div>
          <div className="relative" data-dropdown-container>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setOpenDropdown((prev) => (prev === item.id ? null : item.id));
              }}
              className="p-1.5 hover:bg-gray-100"
            >
              <MoreVertical size={18} />
            </button>
            {openDropdown === item.id && (
              <div className="absolute right-0 mt-1 w-48 bg-white border shadow-lg z-50">
                <button
                  onClick={() => handleEdit(item)}
                  className={`w-full px-3 py-2 text-left text-sm flex items-center gap-2 ${
                    action.type === "view"
                      ? "text-blue-700 hover:bg-blue-50"
                      : action.type === "limited_edit"
                      ? "text-amber-700 hover:bg-amber-50"
                      : "hover:bg-green-50"
                  }`}
                >
                  {action.label}
                </button>
                <button
                  onClick={() => handleViewLogs(item)}
                  className="w-full px-3 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2"
                >
                  Logs
                </button>
                {canDeleteItem(item) && (
                  <button
                    onClick={() => handleDeleteClick(item)}
                    className="w-full px-3 py-2 text-left text-sm hover:bg-red-50 hover:text-red-700 flex items-center gap-2"
                  >
                    Delete
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <span className="text-xs text-gray-600 font-medium">Created By</span>
              <p className="text-sm font-medium mt-0.5">{item.createdBy}</p>
            </div>
            <div>
              <span className="text-xs text-gray-600 font-medium">Created Date</span>
              <p className="text-sm font-medium mt-0.5">{item.createdDate}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <span className="text-xs text-gray-600 font-medium">Focus Area</span>
              <p className="text-sm font-medium mt-0.5">{item.focusArea}</p>
            </div>
            <div>
              <span className="text-xs text-gray-600 font-medium">Priority</span>
              <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium mt-0.5 ${getPriorityColor(item.priority)}`}>
                {item.priority}
              </span>
            </div>
          </div>
          <div>
            <span className="text-xs text-gray-600 font-medium">Objective</span>
            <ExpandableText text={item.objective} maxLines={2} />
          </div>
          <div>
            <span className="text-xs text-gray-600 font-medium">Actions to Achieve</span>
            <ExpandableText text={item.actionsToAchieve} maxLines={2} />
          </div>
          <div>
            <span className="text-xs text-gray-600 font-medium">Progress Update</span>
            <ExpandableText text={item.actionsProgressUpdate} maxLines={2} />
          </div>
          {item.closureAction && item.closureAction !== "-" && (
            <div>
              <span className="text-xs text-gray-600 font-medium">Closure Action</span>
              <ExpandableText text={item.closureAction} maxLines={2} />
            </div>
          )}
          <div>
            <span className="text-xs text-gray-600 font-medium">Responsibility</span>
            <p className="text-sm font-medium mt-0.5">{item.responsibility}</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <span className="text-xs text-gray-600 font-medium">Target Date</span>
              <div className="text-sm font-medium mt-0.5">
                <ExpandableTargetDate
                  currentDate={item.targetDate}
                  actionItemId={item.id}
                  fetchFn={getPdpTargetDateHistory}
                />
              </div>
            </div>
            <div>
              <span className="text-xs text-gray-600 font-medium">Completed Date</span>
              <p className="text-sm font-medium mt-0.5">
                {item.status === "Closed" ? formatDateForDisplay(item.completedDate) : "-"}
              </p>
            </div>
          </div>
          {/* Role-based mobile actions */}
          <div className="border-t pt-2 flex gap-2 mt-2">
            <button
              className={`flex-1 px-3 py-2 text-sm font-medium transition-colors ${
                action.type === "view"
                  ? "bg-blue-100 text-blue-700 hover:bg-blue-200"
                  : action.type === "limited_edit"
                  ? "bg-amber-100 text-amber-700 hover:bg-amber-200"
                  : "bg-green-100 text-green-700 hover:bg-green-200"
              }`}
              onClick={() => handleEdit(item)}
            >
              {action.label}
            </button>
            <button
              className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 text-sm font-medium hover:bg-gray-200"
              onClick={() => handleViewLogs(item)}
            >
              Logs
            </button>
            {canDeleteItem(item) && (
              <button
                className="flex-1 px-3 py-2 bg-red-100 text-red-700 text-sm font-medium hover:bg-red-200"
                onClick={() => handleDeleteClick(item)}
              >
                Delete
              </button>
            )}
          </div>
        </div>
      </div>
    );
  });
  ActionItemCard.displayName = "ActionItemCard";

  // ─────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────
  return (
    <div className="bg-Frostwhite h-screen overflow-hidden flex flex-col">
      <Header menuOpen={false} setMenuOpen={() => {}} />
      <SubNavbar3 />

      <div className="flex flex-col w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
        {/* ── Page Header ── */}
        <div className="flex-shrink-0">
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={24}
              className="cursor-pointer hover:scale-110 transition text-white bg-darkblue1 p-1"
            />
            <h2 className="text-base font-semibold font-VolvoNovum text-darkblue1">
              {rowData
                ? `${rowData?.year} - ${rowData.marketArea || "N/A"} - ${
                    rowData.dealer || rowData.dealerName || rowData.dealerShortName || rowData.dealerFullName || "N/A"
                  } - PDP Action Items`
                : "PDP Action Items"}
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[10%] mt-0 ml-[2.5%] mb-2"></div>
        </div>

        {/* ── Filters ── */}
        <div className="flex-shrink-0 w-full mb-2 flex flex-col lg:flex-row items-center lg:items-start justify-center lg:justify-between gap-2 relative z-20" style={{ overflow: "visible" }}>
          <div className="flex flex-col sm:flex-row flex-wrap gap-2 w-full lg:flex-1 lg:flex-row lg:flex-wrap lg:gap-2 lg:items-center">
            <Searchinput
              value={searchQuery}
              onChange={handleSearchChange}
              placeholder="Search"
              className="w-full sm:w-auto"
              bgColor="bg-white"
              borderColor="border-black/60"
              textColor="text-black"
              focusRing="focus:ring-black/60"
              shadow="shadow-none"
              inputPadding="pl-7 pr-3 py-1.5"
              iconSize="w-3.5 h-3.5"
              iconLeft="left-3"
            />
            <Filter
              name="Focus Area" value={selectedFocusArea} options={focusAreaOptions}
              onChange={(n, v) => setSelectedFocusArea(v)} placeholder="Focus Area"
              customWidth="w-full sm:w-[140px] lg:w-[130px]"
              placeholderColor="text-black" buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white" dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60"
              closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black"
            />
            <Filter
              name="Priority" value={selectedPriority} options={priorityOptions}
              onChange={(n, v) => setSelectedPriority(v)} placeholder="Priority"
              customWidth="w-full sm:w-[110px] lg:w-[100px]"
              placeholderColor="text-black" buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white" dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60"
              closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black"
            />
            <Filter
              name="Status" value={selectedStatus} options={filterStatusOptions}
              onChange={(n, v) => setSelectedStatus(v)} placeholder="Status"
              customWidth="w-full sm:w-[110px] lg:w-[100px]"
              placeholderColor="text-black" buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white" dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60"
              closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black"
            />
          </div>

          {/* ADD NEW — hidden when sign-off completed */}
          {!isSignOffCompleted && (
            <button
              onClick={handleAddNew}
              className="flex-shrink-0 bg-darkblue1 text-xs font-medium text-white flex items-center justify-center px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition-all gap-1 w-full sm:w-auto hover:shadow-lg"
            >
              <Plus className="w-3 h-3" strokeWidth={4} /> Add New
            </button>
          )}
        </div>

        {/* ── Desktop Table ── */}
        <div className="hidden lg:block bg-white shadow-md border border-Dustyblue overflow-hidden">
          <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-hidden max-h-[calc(100vh-220px)]"
            style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
            onScroll={handleTableScroll}
          >
            <style>{`div::-webkit-scrollbar { display: none; }`}</style>
            <table className="w-full text-sm border-collapse table-fixed">
              <thead className="bg-Dustyblue text-white text-xs sticky top-0 z-10 text-left">
                <tr>
                  {[
                    { label: "Created Date", key: "createdDate", w: "w-[8%]" },
                    { label: "Created By", key: "createdBy", w: "w-[8%]" },
                    { label: "Focus Area", key: "focusArea", w: "w-[9%]" },
                    { label: "Objective", key: "objective", w: "w-[12%]" },
                    { label: "Actions", key: "actionsToAchieve", w: "w-[10%]" },
                    { label: "Progress", key: "actionsProgressUpdate", w: "w-[10%]" },
                    { label: "Closure Action", key: "closureAction", w: "w-[9%]" },
                    { label: "Responsibility", key: "responsibility", w: "w-[8%]" },
                    { label: "Priority", key: "priority", w: "w-[5%]" },
                    { label: "Target", key: "targetDate", w: "w-[7%]" },
                    { label: "Completed", key: "completedDate", w: "w-[6%]" },
                    { label: "Status", key: "status", w: "w-[5%]" },
                  ].map((col) => (
                    <th
                      key={col.key}
                      className={`px-1 py-1.5 border border-grey2 border-t-0 border-b-0 ${col.w} cursor-pointer font-normal select-none`}
                      onClick={() => handleSort(col.key)}
                    >
                      <div className="flex items-center gap-1">
                        {col.label} <SortIcon colKey={col.key} />
                      </div>
                    </th>
                  ))}
                  <th className="px-1 py-1.5 border border-grey2 border-t-0 border-b-0 border-r-0 font-normal text-center w-[4%]">
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan="13" className="text-center py-8 text-gray-500">
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-gray-500"></div>
                        Loading...
                      </div>
                    </td>
                  </tr>
                ) : error ? (
                  <tr>
                    <td colSpan="13" className="text-center py-8 text-red-500">
                      <Frown size={24} className="mx-auto mb-2" />
                      {error}
                      <button onClick={loadActionItems} className="mt-2 px-4 py-2 bg-darkblue1 text-white block mx-auto">
                        Retry
                      </button>
                    </td>
                  </tr>
                ) : sortedData.length > 0 ? (
                  sortedData.map((item) => {
                    const rowId = item.id.toString();
                    return (
                      <tr
                        key={rowId}
                        className="hover:bg-lightBlue/50 transition-colors text-xs text-left"
                      >
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 whitespace-nowrap">
                          {item.createdDate}
                        </td>
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 overflow-hidden">
                          <HoverCell rowId={item.id} field="createdBy" value={item.createdBy} maxLen={10} />
                        </td>
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 overflow-hidden">
                          <HoverCell rowId={item.id} field="focusArea" value={item.focusArea} maxLen={14} />
                        </td>
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 overflow-hidden">
                          <ExpandableText text={item.objective} maxLines={2} />
                        </td>
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 overflow-hidden">
                          <ExpandableText text={item.actionsToAchieve} maxLines={2} />
                        </td>
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 overflow-hidden">
                          <ExpandableText text={item.actionsProgressUpdate} maxLines={2} />
                        </td>
                        {/* Closure Action — new column */}
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 overflow-hidden">
                          <ExpandableText text={item.closureAction} maxLines={2} />
                        </td>
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 overflow-hidden">
                          <HoverCell rowId={item.id} field="responsibility" value={item.responsibility} maxLen={10} />
                        </td>
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 text-left">
                          <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(item.priority)}`}>
                            {item.priority}
                          </span>
                        </td>
                        {/* Target Date — with expandable history + amber dot for pending change */}
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0">
                          <ExpandableTargetDate
                            currentDate={item.targetDate}
                            actionItemId={item.id}
                            fetchFn={getPdpTargetDateHistory}
                          />
                        </td>
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 whitespace-nowrap">
                          {item.status === "Closed" ? formatDateForDisplay(item.completedDate) : "-"}
                        </td>
                        <td className={`px-1 py-1 font-semibold border border-grey2 border-t-0 border-l-0 text-left ${getStatusColor(item.status)}`}>
                          {item.status}
                        </td>
                        {/* Actions dropdown */}
                        <td className="px-1 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                          <div className="flex justify-center items-center" data-dropdown-container>
                            <button
                              onClick={(e) => handleDropdownToggle(e, item.id)}
                              className="w-5 h-5 flex items-center justify-center border border-gray-300 hover:bg-gray-100"
                            >
                              <MoreVertical size={14} />
                            </button>
                            {openDropdown === item.id &&
                              createPortal(
                                <div
                                  ref={dropdownRef}
                                  style={dropdownStyle}
                                  className="w-36 bg-white border shadow-lg rounded"
                                >
                                  {(() => {
                                    const action = getEditAction(item);
                                    return (
                                      <button
                                        onClick={() => handleEdit(item)}
                                        className={`w-full px-2 py-1.5 text-left text-xs flex items-center gap-2 transition-colors ${
                                          action.type === "view"
                                            ? "text-blue-700 hover:bg-blue-50"
                                            : action.type === "limited_edit"
                                            ? "text-amber-700 hover:bg-amber-50"
                                            : "text-gray-700 hover:bg-green-50 hover:text-green-700"
                                        }`}
                                      >
                                        {action.type === "view" ? (
                                          <>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24">
                                              <path d="M12 5C6 5 2 12 2 12s4 7 10 7 10-7 10-7-4-7-10-7Z" stroke="#1B365D" strokeWidth="1.5" />
                                              <circle cx="12" cy="12" r="3" stroke="#1B365D" strokeWidth="1.5" />
                                            </svg>
                                            View
                                          </>
                                        ) : action.type === "limited_edit" ? (
                                          <>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                              <path d="M18.988 2.012L21.988 5.012L19.701 7.3L16.701 4.3L18.988 2.012ZM8 16H11L18.287 8.713L15.287 5.713L8 13V16Z" fill="#D97706" />
                                            </svg>
                                            Update
                                          </>
                                        ) : (
                                          <>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                              <path d="M18.988 2.012L21.988 5.012L19.701 7.3L16.701 4.3L18.988 2.012ZM8 16H11L18.287 8.713L15.287 5.713L8 13V16Z" fill="#66B3A6" />
                                              <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6" />
                                            </svg>
                                            Edit
                                          </>
                                        )}
                                      </button>
                                    );
                                  })()}

                                  <button
                                    onClick={() => handleViewLogs(item)}
                                    className="w-full px-2 py-1.5 text-left text-xs hover:bg-gray-50 flex items-center gap-2"
                                  >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="16" viewBox="0 0 16 16" fill="none">
                                      <g clipPath="url(#clip0_1_410)">
                                        <path d="M13.9998 1.83317H12.6665C12.6223 1.83317 12.5799 1.81561 12.5487 1.78436C12.5174 1.7531 12.4998 1.71071 12.4998 1.6665V0.833171C12.4998 0.65636 12.4296 0.48679 12.3046 0.361766C12.1796 0.236742 12.01 0.166504 11.8332 0.166504C11.6564 0.166504 11.4868 0.236742 11.3618 0.361766C11.2367 0.48679 11.1665 0.65636 11.1665 0.833171V3.6065C11.1665 3.78331 11.2367 3.95288 11.3618 4.07791C11.4868 4.20293 11.6564 4.27317 11.8332 4.27317C12.01 4.27317 12.1796 4.20293 12.3046 4.07791C12.4296 3.95288 12.4998 3.78331 12.4998 3.6065V3.33317C12.4998 3.28897 12.5174 3.24658 12.5487 3.21532C12.5799 3.18406 12.6223 3.1665 12.6665 3.1665H13.6665C13.7549 3.1665 13.8397 3.20162 13.9022 3.26414C13.9647 3.32665 13.9998 3.41143 13.9998 3.49984V10.4998C13.9998 10.5882 13.9647 10.673 13.9022 10.7355C13.8397 10.7981 13.7549 10.8332 13.6665 10.8332H11.6665C11.3129 10.8332 10.9737 10.9736 10.7237 11.2237C10.4736 11.4737 10.3332 11.8129 10.3332 12.1665V14.1665C10.3332 14.2549 10.2981 14.3397 10.2355 14.4022C10.173 14.4647 10.0882 14.4998 9.99984 14.4998H2.33317C2.24477 14.4998 2.15998 14.4647 2.09747 14.4022C2.03496 14.3397 1.99984 14.2549 1.99984 14.1665V3.49984C1.99984 3.41143 2.03496 3.32665 2.09747 3.26414C2.15998 3.20162 2.24477 3.1665 2.33317 3.1665H2.99984C3.04404 3.1665 3.08643 3.14894 3.11769 3.11769C3.14894 3.08643 3.1665 3.04404 3.1665 2.99984V1.99984C3.1665 1.95563 3.14894 1.91324 3.11769 1.88199C3.08643 1.85073 3.04404 1.83317 2.99984 1.83317H1.99984C1.64622 1.83317 1.30708 1.97365 1.05703 2.22369C0.80698 2.47374 0.666504 2.81288 0.666504 3.1665V14.4998C0.666504 14.8535 0.80698 15.1926 1.05703 15.4426C1.30708 15.6927 1.64622 15.8332 1.99984 15.8332H10.9998C11.0924 15.8338 11.184 15.8152 11.269 15.7784C11.3539 15.7417 11.4302 15.6877 11.4932 15.6198L15.1598 11.6198C15.2725 11.4959 15.3344 11.334 15.3332 11.1665V3.1665C15.3332 2.81288 15.1927 2.47374 14.9426 2.22369C14.6926 1.97365 14.3535 1.83317 13.9998 1.83317Z" fill="#1B365D" />
                                      </g>
                                    </svg>
                                    Logs
                                  </button>

                                  {canDeleteItem(item) && (
                                    <button
                                      onClick={() => handleDeleteClick(item)}
                                      className="w-full px-2 py-1.5 text-left text-xs hover:bg-red-50 hover:text-red-700 flex items-center gap-1.5"
                                    >
                                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                                        <g clipPath="url(#clip0_6398_313)">
                                          <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012" />
                                        </g>
                                      </svg>
                                      Delete
                                    </button>
                                  )}
                                </div>,
                                document.body
                              )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan="13" className="text-center py-8 text-gray-500">
                      <Frown size={24} className="mx-auto mb-2" />
                      No records found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Scroll buttons */}
          {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto">
              {scrollDirection === "down" && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}
              {scrollDirection === "up" && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* ── Mobile View ── */}
        <div
          className="block lg:hidden overflow-y-auto max-h-[calc(100vh-200px)] pb-4"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          <style>{`div::-webkit-scrollbar { display: none; }`}</style>
          {isLoading ? (
            <div className="bg-white shadow-md border p-8 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-500 mx-auto"></div>
            </div>
          ) : error ? (
            <div className="bg-white shadow-md border p-8 text-center text-red-500">{error}</div>
          ) : sortedData.length > 0 ? (
            sortedData.map((item, idx) => <ActionItemCard key={item.id} item={item} index={idx} />)
          ) : (
            <div className="bg-white shadow-md border p-8 text-center text-gray-500">
              No records found
            </div>
          )}
        </div>
      </div>

      {/* ── Popups ── */}
      <CommentPopup
        isOpen={isCommentOpen}
        onClose={() => setIsCommentOpen(false)}
        actionItemId={selectedRow?.id}
      />
      {/* LogPopup: pass full logsData object same as MM — shows comments in header */}
      <LogPopup
        isOpen={isLogOpen}
        onClose={() => { setIsLogOpen(false); setLogsData(null); }}
        heading={`${logsData?.year || rowData?.year || "PDP"} - ${logsData?.focusArea || "N/A"} - Logs`}
        actionItemId={logsData?.id}
        logsData={logsData}
      />
      <DeleteModal
        isOpen={isDeleteOpen}
        onClose={() => setIsDeleteOpen(false)}
        loading={isDeleting}
        onConfirm={confirmDelete}
        extraMessage="This action cannot be undone."
      />

      <style>{`.line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }`}</style>
    </div>
  );
}

export default ActionPlannerManagement;