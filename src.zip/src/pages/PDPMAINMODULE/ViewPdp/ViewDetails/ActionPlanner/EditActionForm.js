import React, { useState, useRef, useEffect, useCallback } from "react";
import Header from "../../../../../Components/Header";
import SubNavbar3 from "../../../../../Components/SubNavbar3";
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import StyledSelectField from "../../../../../Components/StyledSelectField";
import StyledDateField from "../../../../../Components/StyledDatefield";
import DateChangeRequest from "../../../../../Components/DateChangeRequest";
import {
  getPdpActionItemById,
  updatePdpActionItem,
  getPdpTargetDateHistory,
  getUsersByPdpDealer,
} from "../../../../../services/PDP/PdpActionItem/pdpActionItem.service";
import { getAllUsers } from "../../../../../services/userManagement/userManagement.service";
import { useSelector } from "react-redux";
import { API } from "../../../../../api";

// ═══════════════════════════════════════════════════════════════
// ROLES ALLOWED TO EDIT TARGET DATE (besides Creator) — same as MM
// ═══════════════════════════════════════════════════════════════
const TARGET_DATE_EDIT_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Dealer CEO",
  "Dealer HR Head",
];

// ═══════════════════════════════════════════════════════════════
// TARGET DATE HISTORY SECTION — same as MM's TargetDateHistorySection
// ═══════════════════════════════════════════════════════════════
const TargetDateHistorySection = ({ actionItemId, currentDate }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [previousDates, setPreviousDates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [fetched, setFetched] = useState(false);

  const formatDateForHistoryDisplay = (dateString) => {
    if (!dateString || dateString === "-" || dateString === "N/A" ||
        dateString === "null" || dateString === null) return "-";
    try {
      if (typeof dateString === "string" && dateString.includes("/")) return dateString;
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return "-";
      return `${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`;
    } catch { return "-"; }
  };

  const fetchHistory = useCallback(async () => {
    if (fetched || !actionItemId) { setLoading(false); return; }
    try {
      setLoading(true);
      const response = await getPdpTargetDateHistory(actionItemId);
      if (response.status && response.data && response.data.length > 0) {
        const currentFormatted = formatDateForHistoryDisplay(currentDate);
        const filteredDates = response.data
          .map((d) => formatDateForHistoryDisplay(d))
          .filter((d) => d !== "-" && d !== currentFormatted);
        setPreviousDates([...new Set(filteredDates)]);
      }
    } catch (err) {
      console.warn("Failed to fetch target date history:", err);
    } finally {
      setLoading(false);
      setFetched(true);
    }
  }, [actionItemId, currentDate, fetched]);

  useEffect(() => { fetchHistory(); }, [fetchHistory]);

  if (fetched && previousDates.length === 0) return null;
  if (loading) return null;

  return (
    <div className="mt-0.5">
      <button
        type="button"
        onClick={() => setIsExpanded(!isExpanded)}
        className="inline-flex items-center justify-center w-3.5 h-3.5 rounded-full bg-amber-100 hover:bg-amber-200 transition-colors cursor-pointer"
        title={isExpanded ? "Hide previous dates" : "Show previous dates"}
      >
        {isExpanded
          ? <ChevronUp className="w-2.5 h-2.5 text-amber-700" />
          : <ChevronDown className="w-2.5 h-2.5 text-amber-700" />}
      </button>
      {isExpanded && (
        <div className="mt-0.5 pt-0.5 border-t border-amber-200">
          <span className="text-[8px] text-gray-400 font-medium">Previous:</span>
          {previousDates.map((date, idx) => (
            <div key={idx} className="text-[10px] text-gray-400 line-through leading-tight">
              {date}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════
export default function EditActionForm() {
  const location = useLocation();
  const navigate = useNavigate();
  const rowData = location.state?.rowData;
  const pdpRowData = location.state?.pdpRowData;

  // Get current user persona from Redux — same as MM
  const { data: reduxUserData } = useSelector((state) => state.user);
  const effectivePersona = reduxUserData?.persona || "";

  const [isDateChangeOpen, setIsDateChangeOpen] = useState(false);
  const [apiData, setApiData] = useState(null);
  const [originalTargetDate, setOriginalTargetDate] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState(null);
  const [submitError, setSubmitError] = useState("");
  const [users, setUsers] = useState([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [currentUserId, setCurrentUserId] = useState(null);

  const isMountedRef = useRef(true);
  useEffect(() => { return () => { isMountedRef.current = false; }; }, []);

  // ── Form state — matches all backend pdp_action_item columns
  const [formData, setFormData] = useState({
    focusArea: "",
    priority: "",
    objective: "",
    status: "",
    actionsToAchieve: "",
    actionsProgressUpdate: "",
    closureAction: "",   // closure_action — supported in updated backend
    comments: "",        // comments — supported in updated backend
    responsibility: "",
    targetDate: "",
    completedDate: "",
  });

  const [dropdowns, setDropdowns] = useState({
    focusArea: false,
    priority: false,
    status: false,
    responsibility: false,
  });

  const focusAreaRef = useRef();
  const priorityRef = useRef();
  const statusRef = useRef();
  const responsibilityRef = useRef();
  const refs = { focusArea: focusAreaRef, priority: priorityRef, status: statusRef, responsibility: responsibilityRef };

  const [errors, setErrors] = useState({});
  const statusOptions = ["Open", "In Progress", "Closed"];

  const focusAreaOptions = [
    "Uptime & Parts", "DD- CD and Infra", "Finance", "Key Accounts",
    "Machine Attach- sales", "Marcom", "People and Culture", "Territory Focus",
  ];
  const priorityOptions = ["High", "Medium", "Low"];

  // ── Date utilities ──────────────────────────────────────────
  const formatDateForDisplay = (dateString) => {
    if (!dateString || dateString === "-") return "-";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return "-";
      return `${date.getDate().toString().padStart(2, "0")}-${(date.getMonth() + 1).toString().padStart(2, "0")}-${date.getFullYear()}`;
    } catch { return "-"; }
  };

  const formatDateForInput = (dateString) => {
    if (!dateString || dateString === "-") return "";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return "";
      return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, "0")}-${date.getDate().toString().padStart(2, "0")}`;
    } catch { return ""; }
  };

  // ── Load action item ────────────────────────────────────────
  useEffect(() => {
    const loadActionItem = async () => {
      try {
        setIsLoading(true);
        const actionItemId = rowData?.id || rowData?._original?.id || location.state?.id;
        if (!actionItemId) { setError("Action item ID is required"); setIsLoading(false); return; }

        const data = await getPdpActionItemById(actionItemId);
        setApiData(data);
        const parsedTargetDate = formatDateForInput(data.target_date);
        setOriginalTargetDate(parsedTargetDate);
        setFormData({
          focusArea: data.focus_area || "",
          priority: data.priority || "",
          objective: data.objective || "",
          status: data.status || "Open",
          actionsToAchieve: data.actions_to_achieve || "",
          actionsProgressUpdate: data.actions_progress_update || "",
          closureAction: data.closure_action || "",
          comments: data.comments || "",
          responsibility: data.responsibility || "",
          targetDate: parsedTargetDate,
          completedDate: formatDateForInput(data.completed_date),
        });
      } catch (err) {
        setError(err.message || "Failed to load");
      } finally {
        setIsLoading(false);
      }
    };
    loadActionItem();
  }, [rowData, location.state]);

  // ── Load current user ───────────────────────────────────────
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return;
        const userData = localStorage.getItem("userData");
        if (userData) {
          const parsed = JSON.parse(userData);
          if (parsed?.id) { setCurrentUserId(parsed.id); return; }
        }
        const response = await fetch(`${API.domain}${API.userManagement.logedInUser}`, {
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        });
        const result = await response.json();
        if (result?.data?.id) setCurrentUserId(result.data.id);
      } catch {}
    };
    fetchCurrentUser();
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // LOAD USERS — dealer-scoped, same pattern as MM
  // Uses getUsersByPdpDealer(pdpId) from apiData.pdp once loaded
  // Falls back to getAllUsers if pdp ID not available
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const loadUsers = async () => {
      try {
        setIsLoadingUsers(true);
        const pdpId = apiData?.pdp || rowData?.pdpId || rowData?._original?.pdp;
        if (pdpId) {
          const response = await getUsersByPdpDealer(pdpId);
          if (response.status && response.data) {
            const mappedUsers = response.data.map((user) => ({
              id: user.userId,
              firstName: user.firstName,
              lastName: user.lastName,
            }));
            setUsers(mappedUsers);
          } else {
            const usersList = await getAllUsers();
            setUsers(usersList || []);
          }
        } else {
          const usersList = await getAllUsers();
          setUsers(usersList || []);
        }
      } catch { setUsers([]); }
      finally { setIsLoadingUsers(false); }
    };
    if (apiData !== null || !isLoading) loadUsers();
  }, [apiData?.pdp]);

  // ── Close dropdowns on outside click ───────────────────────
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (!Object.keys(refs).some((k) => refs[k].current?.contains(e.target)))
        setDropdowns({ focusArea: false, priority: false, status: false, responsibility: false });
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // PERMISSION CHECKS — same as MM EditActionitem
  // ═══════════════════════════════════════════════════════════════

  const isResponsiblePerson = useCallback(() => {
    if (!currentUserId || !apiData?.responsibility) return false;
    return currentUserId === apiData.responsibility || currentUserId === parseInt(apiData.responsibility, 10);
  }, [currentUserId, apiData]);

  const isCreatorOfItem = useCallback(() => {
    if (!currentUserId || !apiData?.created_by) return false;
    return currentUserId === apiData.created_by || currentUserId === parseInt(apiData.created_by, 10);
  }, [currentUserId, apiData]);

  const wasAlreadyClosed = useCallback(() => apiData?.status === "Closed", [apiData]);

  const isTargetDateChangeRequested = useCallback(() => {
    return apiData?.target_data_change === 1 || apiData?.target_data_change === true;
  }, [apiData]);

  const canEditTargetDate = useCallback(() => {
    if (isCreatorOfItem()) return true;
    if (TARGET_DATE_EDIT_ROLES.includes(effectivePersona)) return true;
    return false;
  }, [isCreatorOfItem, effectivePersona]);

  const canSeeTargetDateRequest = useCallback(() => canEditTargetDate(), [canEditTargetDate]);

  const getPageTitle = () => isResponsiblePerson() ? "Update Action Item" : "Edit PDP Action Item";

  const hasTargetDateChanged = () =>
    originalTargetDate && formData.targetDate && originalTargetDate !== formData.targetDate;

  const handleChange = useCallback((field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => { if (!prev[field]) return prev; return { ...prev, [field]: "" }; });
  }, []);

  const handleResponsibilityChange = useCallback((selectedLabel) => {
    if (typeof selectedLabel === "object" && selectedLabel !== null) {
      setFormData((prev) => ({ ...prev, responsibility: selectedLabel.value }));
      return;
    }
    const selectedUser = users.find((u) =>
      (u.name || `${u.firstName || ""} ${u.lastName || ""}`.trim() || u.email || `User ${u.id}`) === selectedLabel
    );
    setFormData((prev) => ({ ...prev, responsibility: selectedUser?.id || "" }));
  }, [users]);

  const getResponsibilityDisplayName = useCallback(() => {
    if (!formData.responsibility) return "";
    const user = users.find(
      (u) => u.id === formData.responsibility || u.id === parseInt(formData.responsibility, 10)
    );
    if (user) return user.name || `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.email || `User ${user.id}`;
    return apiData?.responsibility_name || "";
  }, [formData.responsibility, users, apiData]);

  // ═══════════════════════════════════════════════════════════════
  // VALIDATION — same split as MM
  // Responsible: must provide actionsProgressUpdate + closureAction if Closed
  // Admin/Creator: must provide objective + actionsToAchieve + targetDate + closureAction if Closed
  // ═══════════════════════════════════════════════════════════════
  const validateForm = () => {
    const newErrors = {};
    if (isResponsiblePerson()) {
      if (!formData.actionsProgressUpdate || !formData.actionsProgressUpdate.trim())
        newErrors.actionsProgressUpdate = "Action Progress Update is required";
      if (!formData.status) newErrors.status = "Status is required";
      if (formData.status === "Closed" && (!formData.closureAction || !formData.closureAction.trim()))
        newErrors.closureAction = "Closure Action is required when status is Closed";
    } else {
      if (!formData.objective?.trim()) newErrors.objective = "Objective is required";
      if (!formData.actionsToAchieve?.trim()) newErrors.actionsToAchieve = "Actions to Achieve is required";
      if (!formData.targetDate) newErrors.targetDate = "Target Date is required";
      if (!formData.status) newErrors.status = "Status is required";
      if (formData.status === "Closed" && (!formData.closureAction || !formData.closureAction.trim()))
        newErrors.closureAction = "Closure Action is required when status is Closed";
    }
    return newErrors;
  };

  // ═══════════════════════════════════════════════════════════════
  // SAVE HANDLER — mirrors MM's handleSave logic exactly
  // Sends all fields backend supports including closure_action + comments
  // Backend auto-sets completed_date = today when status = Closed + completed_date is null
  // ═══════════════════════════════════════════════════════════════
  const handleUpdate = async () => {
    if (!apiData?.id) return;
    const newErrors = validateForm();
    setErrors(newErrors);
    setSubmitError("");
    if (Object.keys(newErrors).length > 0) return;

    try {
      setIsSaving(true);
      let payload = {};

      if (isResponsiblePerson()) {
        // Responsible person: update progress, status, closure_action only
        payload = {
          id: apiData.id,
          actions_progress_update: formData.actionsProgressUpdate?.trim() || null,
          status: formData.status,
        };
        if (formData.status === "Closed") {
          payload.closure_action = formData.closureAction?.trim() || null;
          // Backend auto-sets completed_date — send null to trigger backend logic
        }
        // Clear completed_date when reopening
        if (formData.status !== "Closed") {
          payload.completed_date = null;
        }
      } else {
        // Admin / Creator: full edit including focus_area, priority, closure_action + comments
        payload = {
          id: apiData.id,
          focus_area: formData.focusArea,
          priority: formData.priority,
          objective: formData.objective?.trim(),
          actions_to_achieve: formData.actionsToAchieve?.trim() || null,
          actions_progress_update: formData.actionsProgressUpdate?.trim() || null,
          closure_action: formData.closureAction?.trim() || null,
          comments: formData.comments?.trim() || null,
          responsibility: formData.responsibility ? parseInt(formData.responsibility, 10) : null,
          target_date: formData.targetDate || null,
          // Backend auto-sets completed_date when Closed; send null when not Closed to clear it
          completed_date: formData.status !== "Closed" ? null : undefined,
          status: formData.status || "Open",
        };

        // Auto-clear target_data_change when authorized user changes date (same as MM)
        if (isTargetDateChangeRequested() && hasTargetDateChanged() && canEditTargetDate()) {
          payload.target_data_change = false;
        }
      }

      await updatePdpActionItem(payload);

      navigate("/pdp/view/actionplannermanagemnet", {
        state: { rowData: pdpRowData, updatedRow: true, message: "Updated successfully" },
      });
    } catch (err) {
      setSubmitError(err.message || "Failed to update");
    } finally {
      if (isMountedRef.current) setIsSaving(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // TARGET DATE CHANGE REQUEST — Responsible Person flow (same as MM)
  // ═══════════════════════════════════════════════════════════════
  const handleTargetDateChangeRequest = async () => {
    if (!apiData?.id) { setIsDateChangeOpen(false); return; }
    try {
      setIsSaving(true);
      await updatePdpActionItem({ id: apiData.id, target_data_change: true });
      setIsDateChangeOpen(false);
      navigate("/pdp/view/actionplannermanagemnet", {
        state: { rowData: pdpRowData, updatedRow: true, message: "Request sent to Admin" },
      });
    } catch (err) {
      setSubmitError(err.message);
      setIsDateChangeOpen(false);
    } finally {
      if (isMountedRef.current) setIsSaving(false);
    }
  };

  const handleCancel = () => navigate(-1);

  const userOptions = React.useMemo(
    () => users.map((u) => ({
      label: u.name || `${u.firstName || ""} ${u.lastName || ""}`.trim() || u.email || `User ${u.id}`,
      value: u.id,
    })),
    [users]
  );

  // ─────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={false} setMenuOpen={() => {}} />
      <SubNavbar3 />

      <div className="flex justify-center">
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">

          {/* Dynamic page title — same as MM */}
          <div className="flex items-center gap-2">
            <ArrowLeft size={24} onClick={handleCancel}
              className="cursor-pointer hover:scale-110 transition text-white bg-darkblue1 p-1" />
            <h2 className="text-base font-semibold font-VolvoNovum text-darkblue1">
              {getPageTitle()}
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[10%] mt-0 ml-[2.7%] mb-4"></div>

          {isLoading && (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-darkblue1"></div>
            </div>
          )}

          {error && !isLoading && (
            <div className="bg-red-50 border border-red-200 p-4 mb-6">
              <p className="text-red-600 text-sm">{error}</p>
              <button onClick={() => navigate(-1)} className="mt-2 text-sm text-red-700 underline">Go back</button>
            </div>
          )}

          {apiData && !isLoading && (
            <>
              {/* ═══════════════════════════════════════════════════════════════ */}
              {/* PDP ACTION ITEM INFO CARD — same layout as MM EditActionitem   */}
              {/* ═══════════════════════════════════════════════════════════════ */}
              <div className="bg-white shadow-md border border-Dustyblue p-2 mb-2">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs text-gray-600">
                  <div>
                    <span className="font-semibold text-darkblue1">Created By:</span>{" "}
                    {rowData?.createdBy || apiData.created_by_info?.user_name || apiData.created_by_name || "-"}
                  </div>
                  <div>
                    <span className="font-semibold text-darkblue1">Created Date:</span>{" "}
                    {rowData?.createdDate || formatDateForDisplay(apiData.created_on) || "-"}
                  </div>
                  <div>
                    <span className="font-semibold text-darkblue1">Year:</span>{" "}
                    {rowData?.year || pdpRowData?.year || "-"}
                  </div>
                  <div>
                    <span className="font-semibold text-darkblue1">Dealer:</span>{" "}
                    {pdpRowData?.dealer || pdpRowData?.dealerName || pdpRowData?.dealerShortName || pdpRowData?.dealerFullName ||
                     rowData?.dealer || rowData?.dealerName || rowData?.dealerShortName || rowData?.dealerFullName || "-"}
                  </div>
                </div>

                {/* No Focus Area here — it's already editable in the form below */}
              </div>

              {/* Form */}
              <div className="bg-white shadow-md border border-grey1 p-6 mb-6">

                {isResponsiblePerson() ? (
                  // ══════════════════════════════════════════════
                  // RESPONSIBLE PERSON VIEW — same as MM
                  // ══════════════════════════════════════════════
                  <div>
                    <div className="bg-blue-50 border border-blue-200 p-3 mb-4">
                      <p className="text-blue-700 text-xs mt-1">
                        You can update progress and change status. To change target date, request Admin/Creator.
                      </p>
                    </div>

                    {isTargetDateChangeRequested() && (
                      <div className="bg-amber-50 border border-amber-200 px-4 py-2 mb-4 flex flex-wrap items-center gap-x-2 gap-y-1">
                        <span className="text-amber-800 font-medium text-xs">⏳ Date Change Request Pending</span>
                        <span className="text-amber-600 text-xs">— Waiting for Admin/Creator</span>
                      </div>
                    )}

                    {wasAlreadyClosed() && (
                      <div className="bg-gray-100 border border-gray-300 p-3 mb-4">
                        <p className="text-gray-700 font-medium text-sm">This action item is Closed — No updates allowed</p>
                      </div>
                    )}

                    {/* Read-only fields */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">Focus Area</label>
                        <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50">{formData.focusArea || "-"}</div>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">Priority</label>
                        <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50">{formData.priority || "-"}</div>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">Responsibility</label>
                        <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50">{getResponsibilityDisplayName() || "-"}</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">Target Date</label>
                        <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50">
                          {formatDateForDisplay(originalTargetDate)}
                        </div>
                        <TargetDateHistorySection actionItemId={apiData.id} currentDate={originalTargetDate} />
                      </div>

                      {/* STATUS — editable for Responsible Person */}
                      <div>
                        {wasAlreadyClosed() ? (
                          <>
                            <label className="block text-xs font-medium text-black/70 mb-2">Status</label>
                            <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50 font-medium text-green-600">
                              {formData.status || "-"}
                            </div>
                          </>
                        ) : (
                          <StyledSelectField
                            label="Status" value={formData.status}
                            setValue={(val) => handleChange("status", val)}
                            options={statusOptions}
                            dropdownOpen={dropdowns.status}
                            setDropdownOpen={(v) => setDropdowns({ ...dropdowns, status: v })}
                            dropdownRef={refs.status}
                            placeholder="Select Status" required error={errors.status}
                          />
                        )}
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">Completed Date</label>
                        <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50">
                          {formData.completedDate ? formatDateForDisplay(formData.completedDate) : "-"}
                        </div>
                      </div>
                    </div>

                    {/* CLOSURE ACTION — only shows when status is Closed (same as MM) */}
                    {formData.status === "Closed" && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <label className="block text-xs font-medium text-black/70 mb-2">
                            Closure Action <span className="text-red1">*</span>
                            {!wasAlreadyClosed() && <span className="text-green-600 text-[10px] ml-1">(Editable)</span>}
                          </label>
                          {!wasAlreadyClosed() ? (
                            <>
                              <textarea
                                value={formData.closureAction}
                                onChange={(e) => handleChange("closureAction", e.target.value)}
                                placeholder="Describe the closure action (required when closing)"
                                rows={3}
                                className={`w-full px-4 py-2 text-xs border resize-none ${
                                  errors.closureAction
                                    ? "border-red1 focus:border-red1"
                                    : "border-black/30 focus:ring-2 focus:ring-darkblue1 focus:outline-none"
                                }`}
                              />
                              {errors.closureAction && <p className="text-xs text-red1 mt-1">{errors.closureAction}</p>}
                            </>
                          ) : (
                            <div className="w-full px-4 py-2 text-xs border border-black/20 bg-gray-50 min-h-[60px] whitespace-pre-wrap">
                              {formData.closureAction || "-"}
                            </div>
                          )}
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-black/70 mb-2">Comments</label>
                          <div className="w-full px-4 py-2 text-xs border border-black/20 bg-gray-50 min-h-[60px] whitespace-pre-wrap">
                            {formData.comments || "-"}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Comments shown separately when not Closed */}
                    {formData.status !== "Closed" && (
                      <div className="mb-4">
                        <label className="block text-xs font-medium text-black/70 mb-2">Comments</label>
                        <div className="w-full px-4 py-2 text-xs border border-black/20 bg-gray-50 min-h-[40px] whitespace-pre-wrap">
                          {formData.comments || "-"}
                        </div>
                      </div>
                    )}

                    {/* Objective + Actions — read-only for responsible person */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">Objective</label>
                        <div className="w-full px-4 py-2 text-xs border border-black/20 bg-gray-50 min-h-[60px] whitespace-pre-wrap">
                          {formData.objective || "-"}
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">Actions to Achieve</label>
                        <div className="w-full px-4 py-2 text-xs border border-black/20 bg-gray-50 min-h-[60px] whitespace-pre-wrap">
                          {formData.actionsToAchieve || "-"}
                        </div>
                      </div>
                    </div>

                    {/* Action Progress Update — Editable for responsible person */}
                    <div>
                      <label className="block text-xs font-medium text-black/70 mb-2">
                        Action Progress Update{" "}
                        {!wasAlreadyClosed() && <span className="text-green-600">(Editable)</span>}
                      </label>
                      <textarea
                        value={formData.actionsProgressUpdate}
                        onChange={(e) => handleChange("actionsProgressUpdate", e.target.value)}
                        placeholder={wasAlreadyClosed() ? "Closed — no updates allowed" : "Enter your progress update here..."}
                        rows={4}
                        disabled={wasAlreadyClosed()}
                        className={`w-full px-4 py-2 text-xs border resize-none ${
                          wasAlreadyClosed()
                            ? "bg-gray-100 cursor-not-allowed border-black/20"
                            : errors.actionsProgressUpdate
                            ? "border-red1"
                            : "border-black/30 focus:ring-2 focus:ring-darkblue1 focus:outline-none"
                        }`}
                      />
                      {errors.actionsProgressUpdate && (
                        <p className="text-xs text-red1 mt-1">{errors.actionsProgressUpdate}</p>
                      )}
                    </div>
                  </div>

                ) : (
                  // ══════════════════════════════════════════════
                  // ADMIN / CREATOR VIEW — same as MM
                  // ══════════════════════════════════════════════
                  <div>
                    {isTargetDateChangeRequested() && !canSeeTargetDateRequest() && (
                      <div className="bg-gray-50 border border-gray-300 p-3 mb-4">
                        <p className="text-gray-700 font-medium text-sm">A target date change has been requested.</p>
                      </div>
                    )}

                    {wasAlreadyClosed() && (
                      <div className="bg-blue-50 border border-blue-200 p-3 mb-4">
                        <p className="text-blue-800 font-medium text-sm">This action item is Closed</p>
                        <p className="text-blue-700 text-xs mt-1">You can change the status to reopen it.</p>
                      </div>
                    )}

                    {/* Row 1: Focus Area, Priority, Responsibility — all editable for Admin/Creator */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <StyledSelectField
                        label="Focus Area"
                        placeholder="Select Focus Area"
                        value={formData.focusArea}
                        setValue={(val) => handleChange("focusArea", val)}
                        options={focusAreaOptions}
                        dropdownOpen={dropdowns.focusArea}
                        setDropdownOpen={(v) => setDropdowns({ ...dropdowns, focusArea: v })}
                        dropdownRef={refs.focusArea}
                      />
                      <StyledSelectField
                        label="Priority"
                        placeholder="Select Priority"
                        value={formData.priority}
                        setValue={(val) => handleChange("priority", val)}
                        options={priorityOptions}
                        dropdownOpen={dropdowns.priority}
                        setDropdownOpen={(v) => setDropdowns({ ...dropdowns, priority: v })}
                        dropdownRef={refs.priority}
                      />
                      <StyledSelectField
                        label="Responsibility"
                        placeholder={isLoadingUsers ? "Loading..." : "Select"}
                        value={getResponsibilityDisplayName()}
                        setValue={handleResponsibilityChange}
                        options={userOptions}
                        dropdownOpen={dropdowns.responsibility}
                        setDropdownOpen={(v) => setDropdowns({ ...dropdowns, responsibility: v })}
                        dropdownRef={refs.responsibility}
                        disabled={isLoadingUsers}
                      />
                    </div>

                    {/* Row 2: Status, Target Date, Date Change Status */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 items-start">
                      <div>
                        <StyledSelectField
                          label="Status" placeholder="Select"
                          value={formData.status === "Open" && wasAlreadyClosed() ? "Reopen" : formData.status}
                          setValue={(v) => handleChange("status", v === "Reopen" ? "Open" : v)}
                          options={wasAlreadyClosed() ? ["Reopen", "In Progress"] : statusOptions}
                          dropdownOpen={dropdowns.status}
                          setDropdownOpen={(v) => setDropdowns({ ...dropdowns, status: v })}
                          dropdownRef={refs.status} error={errors.status} required
                        />
                      </div>

                      {/* Target Date — only editable by Creator + specific roles */}
                      <div>
                        {canEditTargetDate() ? (
                          <StyledDateField
                            label="Target Date"
                            value={formData.targetDate}
                            setValue={(d) => handleChange("targetDate", d)}
                            required
                            error={errors.targetDate}
                          />
                        ) : (
                          <>
                            <label className="block text-xs font-medium text-gray-700 mb-1">
                              Target Date <span className="text-[10px] text-gray-400 ml-1">(Read-only)</span>
                            </label>
                            <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50 cursor-not-allowed">
                              {formatDateForDisplay(formData.targetDate) || "-"}
                            </div>
                          </>
                        )}
                        {errors.targetDate && !canEditTargetDate() && (
                          <p className="text-xs text-red1 mt-1">{errors.targetDate}</p>
                        )}
                        <TargetDateHistorySection actionItemId={apiData.id} currentDate={originalTargetDate} />
                      </div>

                      {/* Date Change Status */}
                      {canEditTargetDate() && (
                        <div>
                          <label className="block text-xs font-medium text-MediumGrey mb-1">Date Change Status</label>
                          <div className={`w-full border px-3 py-1.5 text-xs ${
                            hasTargetDateChanged()
                              ? "border-green-500 bg-green-50 text-green-900"
                              : isTargetDateChangeRequested()
                              ? "border-amber-500 bg-amber-50 text-amber-900"
                              : "border-black/30 text-gray-400 italic"
                          }`}>
                            {hasTargetDateChanged()
                              ? `✓ Changed from: ${formatDateForDisplay(originalTargetDate)}`
                              : isTargetDateChangeRequested()
                              ? `⏳ Requested by ${
                                  apiData?.responsibility_name
                                    ? `${apiData.responsibility_name} ${apiData.responsibility_lastname || ""}`.trim()
                                    : "Assigned person"
                                } | Current: ${formatDateForDisplay(originalTargetDate)}`
                              : "No change requested"}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Objective + Actions — always visible, same as MM layout */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">
                          Objective <span className="text-red1">*</span>
                        </label>
                        <textarea
                          value={formData.objective}
                          onChange={(e) => handleChange("objective", e.target.value)}
                          rows={3}
                          className={`w-full px-4 py-2 text-xs border resize-none ${
                            errors.objective ? "border-red1" : "border-black/30 focus:ring-2 focus:ring-darkblue1 focus:outline-none"
                          }`}
                        />
                        {errors.objective && <p className="text-red1 text-xs mt-1">{errors.objective}</p>}
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">
                          Actions to Achieve <span className="text-red1">*</span>
                        </label>
                        <textarea
                          value={formData.actionsToAchieve}
                          onChange={(e) => handleChange("actionsToAchieve", e.target.value)}
                          rows={3}
                          className={`w-full px-4 py-2 text-xs border resize-none ${
                            errors.actionsToAchieve ? "border-red1" : "border-black/30 focus:ring-2 focus:ring-darkblue1 focus:outline-none"
                          }`}
                        />
                        {errors.actionsToAchieve && <p className="text-red1 text-xs mt-1">{errors.actionsToAchieve}</p>}
                      </div>
                    </div>

                    {/* CLOSURE ACTION — only when status = Closed (same as MM) */}
                    {formData.status === "Closed" && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <label className="block text-xs font-medium text-gray-700 mb-2">
                            Closure Action <span className="text-red1">*</span>
                          </label>
                          <textarea
                            value={formData.closureAction}
                            onChange={(e) => handleChange("closureAction", e.target.value)}
                            className={`w-full border text-xs px-4 py-1.5 resize-none ${
                              errors.closureAction ? "border-red1" : "border-black/30"
                            }`}
                            rows={4} placeholder="Describe the closure action (required)"
                          />
                          {errors.closureAction && <p className="text-xs text-red1 mt-1">{errors.closureAction}</p>}
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-700 mb-2">Comments</label>
                          <textarea
                            value={formData.comments}
                            onChange={(e) => handleChange("comments", e.target.value)}
                            className="w-full border border-black/30 text-xs px-4 py-1.5 resize-none"
                            rows={4} placeholder="Add any additional comments"
                          />
                        </div>
                      </div>
                    )}

                    {/* Comments when not Closed */}
                    {formData.status !== "Closed" && (
                      <div className="mb-4">
                        <label className="block text-xs font-medium text-gray-700 mb-2">Comments</label>
                        <textarea
                          value={formData.comments}
                          onChange={(e) => handleChange("comments", e.target.value)}
                          className="border border-black/30 w-full text-xs px-3 py-1.5 outline-none focus:ring-1 focus:ring-black/30 transition-all resize-none"
                          rows={3} placeholder="Add any additional comments"
                        />
                      </div>
                    )}

                    {/* Action Progress Update */}
                    <div>
                      <label className="block text-xs font-medium text-black/70 mb-2">Action Progress Update</label>
                      <textarea
                        value={formData.actionsProgressUpdate}
                        onChange={(e) => handleChange("actionsProgressUpdate", e.target.value)}
                        rows={4} placeholder="Enter action progress update..."
                        className="border border-black/30 w-full mt-1 text-xs px-3 py-2 outline-none focus:ring-1 focus:ring-black/30 transition-all resize-none"
                      />
                    </div>
                  </div>
                )}
              </div>

              {submitError && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200">
                  <p className="text-red-600 text-sm">{submitError}</p>
                </div>
              )}

              {/* Buttons — same logic as MM */}
              <div className="flex flex-wrap gap-4 justify-center lg:justify-end">
                {isResponsiblePerson() && !wasAlreadyClosed() && !isTargetDateChangeRequested() && (
                  <button type="button"
                    onClick={() => { document.activeElement?.blur(); setIsDateChangeOpen(true); }}
                    disabled={isSaving}
                    className="bg-amber-500 text-white text-xs font-medium px-6 py-1.5 hover:bg-amber-600 transition-all"
                  >
                    Request Target Date Change
                  </button>
                )}

                <button onClick={handleCancel} disabled={isSaving}
                  className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs hover:bg-mildBlue1 hover:scale-105"
                >
                  Cancel
                </button>

                {(!isResponsiblePerson() || !wasAlreadyClosed()) && (
                  <button onClick={handleUpdate} disabled={isSaving}
                    className={`bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 transition-all ${
                      isSaving ? "opacity-50 cursor-not-allowed"
                        : "hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 hover:shadow-lg"
                    }`}
                  >
                    {isSaving ? (
                      <span className="flex items-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        Saving...
                      </span>
                    ) : isResponsiblePerson() ? "Update Progress" : "Save Changes"}
                  </button>
                )}
              </div>
            </>
          )}

          {/* Date Change Request popup — same message as MM */}
          <DateChangeRequest
            isOpen={isDateChangeOpen}
            onCancel={() => setIsDateChangeOpen(false)}
            onConfirm={handleTargetDateChangeRequest}
            message="Your request will be sent to the Creator, Administrator, Head Of Channel Development, Dealer CEO, and Dealer HR Head to update the target date."
          />
        </div>
      </div>
    </div>
  );
}