import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { X, Frown, RefreshCw } from "lucide-react";
import { formatedTime, formatDateOnly } from "../../../../../util/timeFormat";
import { getPdpActionLogsByActionItem } from "../../../../../services/PDP/PdpActionItem/pdpActionItemLog.service";
import { ChevronDown } from "lucide-react";
import { ChevronUp } from "lucide-react";

// ═══════════════════════════════════════════════════════════════
// ExpandableText — same as MM LogActionitemPopup
// Long auto-generated comments need expand/collapse not just truncate
// ═══════════════════════════════════════════════════════════════
const ExpandableText = ({ text, maxLines = 2 }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [needsExpansion, setNeedsExpansion] = useState(false);
  const textRef = useRef(null);

  useEffect(() => {
    if (textRef.current) {
      const lineHeight = parseInt(window.getComputedStyle(textRef.current).lineHeight) || 16;
      const maxHeight = lineHeight * maxLines;
      setNeedsExpansion(textRef.current.scrollHeight > maxHeight + 5);
    }
  }, [text, maxLines]);

  if (!text || text === "-") return <span className="text-gray-400 italic">No comment</span>;

  return (
    <div className="relative">
      <div
        ref={textRef}
        className="whitespace-pre-wrap break-words transition-all duration-200"
        style={
          !isExpanded && needsExpansion
            ? {
                display: "-webkit-box",
                WebkitLineClamp: maxLines,
                WebkitBoxOrient: "vertical",
                overflow: "hidden",
              }
            : {}
        }
      >
        {text}
      </div>
      {needsExpansion && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setIsExpanded(!isExpanded);
          }}
          className="text-blue-600 hover:text-blue-800 text-[10px] font-medium mt-0.5 hover:underline"
        >
          {isExpanded ? "Show less" : "Show more"}
        </button>
      )}
    </div>
  );
};

const LogPopup = ({ isOpen, onClose, heading, actionItemId, logsData }) => {
  const [logs, setLogs] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [logSortKey, setLogSortKey] = useState(null);
  const [logSortOrder, setLogSortOrder] = useState(null);
  const [hoveredCell, setHoveredCell] = useState();
  
  const handleLogSort = (key) => {
    if (logSortKey === key) {
      if (logSortOrder === "asc") {
        setLogSortOrder("desc");
      } else if (logSortOrder === "desc") {
        setLogSortKey(null);
        setLogSortOrder(null);
      }
    } else {
      setLogSortKey(key);
      setLogSortOrder("asc");
    }
  };

  const sortedLogs = useMemo(() => {
    if (!logSortKey) return logs;

    return [...logs].sort((a, b) => {
      const aValue = a[logSortKey];
      const bValue = b[logSortKey];

      // FIX 2: NaN guard for date sort
      if (logSortKey === "createdDate") {
        const dateA = new Date(aValue);
        const dateB = new Date(bValue);
        if (isNaN(dateA)) return 1;
        if (isNaN(dateB)) return -1;
        return logSortOrder === "asc" ? dateA - dateB : dateB - dateA;
      }

      if (typeof aValue === "string") {
        return logSortOrder === "asc"
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }

      return 0;
    });
  }, [logs, logSortKey, logSortOrder]);

  // FIX 1: loadLogs wrapped in useCallback with actionItemId as dep
  const loadLogs = useCallback(async () => {
    if (!actionItemId) {
      setError("Action item ID is required");
      return;
    }

    try {
      setIsLoading(true);
      setError(null);

      const response = await getPdpActionLogsByActionItem(actionItemId);

      if (response && response.data) {
        const transformedLogs = response.data.map((log) => ({
          id: log.id,
          createdDate: log.createdOn,
          updatedBy: log.updated_by_name
            ? `${log.updated_by_name} ${log.updated_by_lastname || ""}`.trim()
            : log.updated_by_email || "Unknown",
          status: log.action_item_status || "-",
          comment: log.comment || "-",
          focusArea: log.focus_area || "-",
          objective: log.objective || "-",
          priority: log.priority || "-",
        }));

        setLogs(transformedLogs);
      } else {
        setLogs([]);
      }
    } catch (err) {
      setError(err.message || "Failed to load action logs");
      setLogs([]);
    } finally {
      setIsLoading(false);
    }
  }, [actionItemId]);

  // FIX 1: loadLogs now in deps array
  // FIX 4: reset hoveredCell, logSortKey, logSortOrder on close
  useEffect(() => {
    if (isOpen && actionItemId) {
      loadLogs();
    } else {
      setLogs([]);
      setError(null);
      setHoveredCell(null);     // FIX 4: reset hover state
      setLogSortKey(null);      // FIX 4: reset sort state
      setLogSortOrder(null);    // FIX 4: reset sort state
    }
  }, [isOpen, actionItemId, loadLogs]);

  // FIX 6: removed unnecessary typeof check — just use formatedTime directly
  const formatLogTime = (dateString) => {
    if (!dateString) return "-";
    try {
      return formatedTime(dateString);
    } catch {
      const date = new Date(dateString);
      return isNaN(date.getTime()) ? "-" : date.toLocaleString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "Open": return "text-blue-600";
      case "Closed":
      case "Completed": return "text-green-600";
      case "In Progress": return "text-orange-600";
      default: return "text-gray-500";
    }
  };

  const getStatusBadgeColor = (status) => {
    switch (status) {
      case "Open": return "bg-blue-100 text-blue-700";
      case "Closed":
      case "Completed": return "bg-green-100 text-green-700";
      case "In Progress": return "bg-orange-100 text-orange-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      {/* Modal container */}
      <div className="bg-white shadow-lg w-full max-w-4xl md:max-w-5xl max-h-[80vh] flex flex-col relative animate-fadeIn">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-gray-200">
          <div>
            <h2 className="font-semibold text-darkblue1 text-base">Action Item Logs</h2>
            {heading && <p className="text-xs text-gray-600 mt-1">{heading}</p>}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={loadLogs}
              disabled={isLoading}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              title="Refresh logs"
            >
              <RefreshCw size={16} className={`text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-red-50 rounded-full transition-colors"
              aria-label="Close"
            >
              <X size={18} className="text-gray-600 hover:text-red-600" />
            </button>
          </div>
        </div>

        {/* Action Item Summary — same as MM's logsData summary card */}
        {logsData && (
          <div className="px-4 py-2 bg-gray-50 border-b border-gray-200 flex-shrink-0">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs text-gray-600">
              <div>
                <span className="font-semibold text-darkblue1">Focus Area:</span>{" "}
                {logsData.focusArea || "-"}
              </div>
              <div>
                <span className="font-semibold text-darkblue1">Responsibility:</span>{" "}
                {logsData.responsibility || "-"}
              </div>
              <div>
                <span className="font-semibold text-darkblue1">Status:</span>{" "}
                <span className={`font-medium ${
                  logsData.status === "Open"
                    ? "text-blue-600"
                    : logsData.status === "Closed"
                    ? "text-green-600"
                    : "text-orange-600"
                }`}>
                  {logsData.status || "-"}
                </span>
              </div>
            </div>
            {/* Comments from edit page — same as MM */}
            {logsData.comments && logsData.comments.trim() !== "" && logsData.comments !== "N/A" && (
              <div className="mt-2 text-xs text-gray-600">
                <span className="font-semibold text-darkblue1">Comments:</span>{" "}
                <span className="whitespace-pre-wrap break-words">{logsData.comments}</span>
              </div>
            )}
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-auto p-4">
          {/* Desktop Table View */}
          <div className="hidden lg:block">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-darkblue1 mb-4"></div>
                <span className="text-gray-500">Loading action logs...</span>
              </div>
            ) : error ? (
              <div className="flex flex-col items-center justify-center py-12">
                <Frown size={40} className="text-red-400 mb-4" />
                <span className="text-red-500 mb-4">{error}</span>
                <button
                  onClick={loadLogs}
                  className="px-4 py-2 bg-darkblue1 text-white text-sm hover:bg-darkblue1/90 transition-colors"
                >
                  Retry
                </button>
              </div>
            ) : logs.length > 0 ? (
              <div className="border border-Dustyblue overflow-hidden">
                <table className="w-full text-sm border-collapse">
                  <thead className="bg-Dustyblue text-white">
                    <tr>
                      <th
                        className="px-3 py-2 text-left text-xs font-medium border-r border-grey2 w-[20%] cursor-pointer"
                        onClick={() => handleLogSort("createdDate")}
                      >
                        Date & Time
                        {logSortKey === "createdDate" && (logSortOrder === "asc"
                          ? <ChevronUp className="inline w-3 h-3" />
                          : <ChevronDown className="inline w-3 h-3" />)}
                      </th>
                      <th
                        className="px-3 py-2 text-left text-xs font-medium border-r border-grey2 w-[20%] cursor-pointer"
                        onClick={() => handleLogSort("updatedBy")}
                      >
                        Updated By
                        {logSortKey === "updatedBy" && (logSortOrder === "asc"
                          ? <ChevronUp className="inline w-3 h-3" />
                          : <ChevronDown className="inline w-3 h-3" />)}
                      </th>
                      <th
                        className="px-3 py-2 text-left text-xs font-medium border-r border-grey2 w-[15%] cursor-pointer"
                        onClick={() => handleLogSort("status")}
                      >
                        Status
                        {logSortKey === "status" && (logSortOrder === "asc"
                          ? <ChevronUp className="inline w-3 h-3" />
                          : <ChevronDown className="inline w-3 h-3" />)}
                      </th>
                      <th
                        className="px-3 py-2 text-left text-xs font-medium w-[45%] cursor-pointer"
                        onClick={() => handleLogSort("comment")}
                      >
                        Comment
                        {logSortKey === "comment" && (logSortOrder === "asc"
                          ? <ChevronUp className="inline w-3 h-3" />
                          : <ChevronDown className="inline w-3 h-3" />)}
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {sortedLogs.map((log, idx) => (
                      <tr
                        key={log.id || idx}
                        className={`hover:bg-lightBlue/50 transition-colors ${idx % 2 === 0 ? "bg-white" : "bg-gray-50"}`}
                      >
                        <td className="px-3 py-2 text-xs border-r border-gray-200 whitespace-nowrap">
                          {formatLogTime(log.createdDate)}
                        </td>

                        {/* FIX 3 & 5: replaced absolute tooltip with native title — no overflow clipping */}
                        <td className="px-3 py-2 text-xs border-r border-gray-200">
                          <p
                            className="break-words"
                            title={log.updatedBy && log.updatedBy.length > 20 ? log.updatedBy : undefined}
                          >
                            {log.updatedBy || "-"}
                          </p>
                        </td>

                        <td className="px-3 py-2 text-xs border-r border-gray-200">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadgeColor(log.status)}`}>
                            {log.status}
                          </span>
                        </td>

                        {/* Comment — use ExpandableText same as MM (auto-generated comments are very long) */}
                        <td className="px-3 py-2 text-xs">
                          <ExpandableText text={log.comment} maxLines={2} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-gray-500">
                <Frown size={40} className="text-gray-300 mb-4" />
                <p className="italic">No action logs found</p>
                <p className="text-xs text-gray-400 mt-2">
                  Logs will appear here when the action item is updated
                </p>
              </div>
            )}
          </div>

          {/* Mobile Card View */}
          <div className="lg:hidden space-y-3">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1 mb-3"></div>
                <span className="text-gray-500 text-sm">Loading action logs...</span>
              </div>
            ) : error ? (
              <div className="flex flex-col items-center justify-center py-8">
                <Frown size={32} className="text-red-400 mb-3" />
                <span className="text-red-500 text-sm mb-3">{error}</span>
                <button
                  onClick={loadLogs}
                  className="px-4 py-2 bg-darkblue1 text-white text-sm hover:bg-darkblue1/90"
                >
                  Retry
                </button>
              </div>
            ) : logs.length > 0 ? (
              logs.map((log, idx) => (
                <div
                  key={log.id || idx}
                  className="bg-white border border-gray-200 p-4 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between items-start mb-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadgeColor(log.status)}`}>
                      {log.status}
                    </span>
                    <span className="text-xs text-gray-500">
                      {formatLogTime(log.createdDate)}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-xs font-medium text-gray-600">Updated By:</span>
                      <span className="text-xs text-gray-900">{log.updatedBy}</span>
                    </div>

                    {log.comment && log.comment !== "-" && (
                      <div>
                        <span className="text-xs font-medium text-gray-600">Comment:</span>
                        <p className="text-xs text-gray-800 mt-1 bg-gray-50 p-2 rounded">
                          {log.comment}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-gray-500">
                <Frown size={32} className="text-gray-300 mb-3" />
                <p className="italic text-sm">No action logs found</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        {logs.length > 0 && (
          <div className="border-t border-gray-200 px-4 py-3 bg-gray-50 flex justify-between items-center">
            <span className="text-xs text-gray-500">
              Total: {logs.length} log{logs.length !== 1 ? "s" : ""}
            </span>
            <button
              onClick={onClose}
              className="px-4 py-1.5 bg-darkblue1 text-white text-xs font-medium hover:bg-darkblue1/90 transition-colors"
            >
              Close
            </button>
          </div>
        )}
      </div>

      {/* Animation styles */}
      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fadeIn { animation: fadeIn 0.2s ease-out; }
      `}</style>
    </div>
  );
};

export default LogPopup;