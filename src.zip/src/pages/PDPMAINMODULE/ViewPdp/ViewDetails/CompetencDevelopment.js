import { Download, Save, AlertCircle, Lock } from "lucide-react";
import React, { useState, useEffect, useRef } from "react";
import Searchinput from "../../../../Components/Searchinput";
import SingleSelectFilter from "../../../../Components/SingleSelelctFilter";
import { useMemo } from "react";
import { ChevronDown ,ChevronsUpDown } from "lucide-react";
import { ChevronUp,ArrowUp,ArrowDown } from "lucide-react";
import { 
  getPdpCompetenceDevelopmentsByPdpId,
  updateMultiplePdpCompeDev,
  getActiveMachines
} from "../../../../services/PDP/CompetenceDevelopmentHyperlink/pdphyperCompetenceDevelopment.service";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../../services/download/bluckDownload.service";

// ⭐ FIXED: Import centralized role functions
import { canEditData, isEditableStatus, isDealerRole, isAdminRole } from "../../../../pages/constants/roles";
import Filter from "../../../../Components/Filter";

const CompetenceDevelopment = ({ rowData, userRole }) => {
  const [searchTerm, setSearchTerm] = useState("");
const [selectedCategories, setSelectedCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState(false);
const [sortKey3, setSortKey3] = useState(null);
const [sortOrder3, setSortOrder3] = useState(null);
const [hoveredCell,setHoveredCell] = useState()
  const pdpId = rowData?.id || null;
  const selectedyear = rowData?.year || new Date().getFullYear();
const tableContainerRef= useRef(null)
  // ⭐ FIXED: Extract PDP status from rowData
  const pdpStatus = rowData?.signOffStatus || rowData?.sign_of_status || "Created";

  // ⭐ FIXED: Use centralized role check instead of just checking "Administrator"
  const isAdmin = isAdminRole(userRole);
  
  // ⭐ NEW: Check if user can edit (considers both role AND status)
  const canEdit = canEditData(userRole, pdpStatus);
  
  // ⭐ NEW: Check if dealer but editing is locked due to status
  const isStatusLocked = isDealerRole(userRole) && !isEditableStatus(pdpStatus);

  const [editableData3, setEditableData3] = useState([]);
  const [apiData, setApiData] = useState([]);
  const [machineData, setMachineData] = useState([]);
  const [categories, setCategories] = useState([]);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
const [expandedCell, setExpandedCell] = useState(null);
const [sortKey2, setSortKey2] = useState(null);
const [sortOrder2, setSortOrder2] = useState(null);
const table2Ref = useRef(null);
const table3Ref = useRef(null);
const [showScroll2, setShowScroll2] = useState(false);
const [scrollDir2, setScrollDir2] = useState(null);
const [lastScroll2, setLastScroll2] = useState(0);

const [showScroll3, setShowScroll3] = useState(false);
const [scrollDir3, setScrollDir3] = useState(null);
const [lastScroll3, setLastScroll3] = useState(0);
const handleScroll2 = (e) => {
  const scrollTop = e.target.scrollTop;
  const scrollHeight = e.target.scrollHeight;
  const clientHeight = e.target.clientHeight;

  if (scrollTop > lastScroll2) {
    setScrollDir2("down");
  } else {
    setScrollDir2("up");
  }

  setLastScroll2(scrollTop);

  const isScrollable = scrollHeight > clientHeight;
  setShowScroll2(isScrollable && scrollTop > 50);
};
const handleScroll3 = (e) => {
  const scrollTop = e.target.scrollTop;
  const scrollHeight = e.target.scrollHeight;
  const clientHeight = e.target.clientHeight;

  if (scrollTop > lastScroll3) {
    setScrollDir3("down");
  } else {
    setScrollDir3("up");
  }

  setLastScroll3(scrollTop);

  const isScrollable = scrollHeight > clientHeight;
  setShowScroll3(isScrollable && scrollTop > 50);
};const scrollTop2 = () => {
  table2Ref.current?.scrollTo({ top: 0, behavior: "smooth" });
};

const scrollBottom2 = () => {
  table2Ref.current?.scrollTo({
    top: table2Ref.current.scrollHeight,
    behavior: "smooth",
  });
};
const scrollTop3 = () => {
  table3Ref.current?.scrollTo({ top: 0, behavior: "smooth" });
};

const scrollBottom3 = () => {
  table3Ref.current?.scrollTo({
    top: table3Ref.current.scrollHeight,
    behavior: "smooth",
  });
};
  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  // ⭐ NEW: Get status badge color
  const getStatusBadgeColor = (status) => {
    switch (status) {
      case "Completed": return "bg-green-100 text-green-800 border-green-300";
      case "Approved": return "bg-blue-100 text-blue-800 border-blue-300";
      case "Pending Review": return "bg-orange-100 text-orange-800 border-orange-300";
      case "Started": return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "Created": return "bg-gray-100 text-gray-800 border-gray-300";
      default: return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };


  // ⭐ Fetch ALL data on mount
  useEffect(() => {
    const fetchAllData = async () => {
      if (!pdpId) {
        console.error("❌ PDP ID is missing");
        setError("PDP ID is required to load competence development data");
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);
        
        console.log("🔍 Fetching all data for PDP ID:", pdpId);
        
        const [competenceData, machinesDataResponse] = await Promise.all([
          getPdpCompetenceDevelopmentsByPdpId(pdpId),
          getActiveMachines(pdpId).catch(err => {
            console.warn("⚠️ Could not fetch active machines:", err);
            return null;
          })
        ]);
        
        console.log("✅ Competence data loaded:", competenceData.length, "records");
        console.log("✅ Active machines data:", machinesDataResponse);
        
        setApiData(competenceData);
        
        // ⭐ Extract unique categories from competence_type
        const uniqueCategories = [...new Set(
          competenceData
            .map(item => item.competence_type)
            .filter(Boolean)
        )];
        
        console.log("✅ Unique categories extracted:", uniqueCategories);
        setCategories(uniqueCategories);
        
        // ⭐ Set machine data from API
        if (machinesDataResponse && machinesDataResponse.data) {
          setMachineData([{
            field1: "Total Active Machine Population",
            LStarget: machinesDataResponse.data.py_target || "0",
            LSeoy: machinesDataResponse.data.py_eoy || "0",
            CYtarget: machinesDataResponse.data.target || "0"
          }]);
        } else {
          setMachineData([{
            field1: "Total Active Machine Population",
            LStarget: "0",
            LSeoy: "0",
            CYtarget: "0"
          }]);
        }
        
      } catch (error) {
        console.error("❌ Error fetching data:", error);
        setError(error.message || "Failed to load data");
      } finally {
        setIsLoading(false);
      }
    };

    fetchAllData();
  }, [pdpId]);

  // ⭐ Success message auto-hide
  useEffect(() => {
    if (saveSuccess) {
      const timer = setTimeout(() => setSaveSuccess(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [saveSuccess]);

  // ⭐ Transform API data for selected category
 const  transformApiDataForCategory = (categories) => {
  if (!apiData || apiData.length === 0) return [];

  let result = [];

  categories.forEach((category) => {
    const categoryData = apiData.filter(
      (item) => item.competence_type === category
    );

    const mapped = categoryData.map((item) => ({
      year: selectedyear,
      competencetype: item.competence_name,
      LS3target: item.py_target_value || item.py_target || 0,
      LS3eoy: item.py_eoy || 0,
      CY3target: item.target || 0,
      remark: item.remarks || "",
      id: item.id,
      category: category // ⭐ important
    }));

    result.push(...mapped);
  });

  return result;
};
  // ⭐ Calculate summary for selected category
 const calculateSummaryForCategory = (categories) => {
  return categories.map((category) => {
    const categoryData = apiData.filter(
      (item) => item.competence_type === category
    );

    return {
      competencedevelopment: category,
      LS2target: categoryData.reduce((sum, i) => sum + (parseFloat(i.py_target_value || i.py_target) || 0), 0),
      LS2eoy: categoryData.reduce((sum, i) => sum + (parseFloat(i.py_eoy) || 0), 0),
      CY2target: categoryData.reduce((sum, i) => sum + (parseFloat(i.target) || 0), 0)
    };
  });
};

  // ⭐ Get data for selected category
  const selectedData = selectedCategories.length
  ? {
      data2: calculateSummaryForCategory(selectedCategories),
      data3: transformApiDataForCategory(selectedCategories)
    }
  : {};
  // Initialize editable data when category changes
 useEffect(() => {
  if (selectedData.data3) {
    setEditableData3(JSON.parse(JSON.stringify(selectedData.data3)));
  }
}, [selectedCategories, apiData]);

  const filteredData1 = machineData.filter(item =>
    Object.values(item).some(val => String(val).toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const filteredData2 = selectedData.data2?.filter(item =>
    Object.values(item).some(val => String(val).toLowerCase().includes(searchTerm.toLowerCase()))
  ) || [];

  const filteredData3 = editableData3.filter(item =>
    Object.values(item).some(val => String(val).toLowerCase().includes(searchTerm.toLowerCase()))
  );
  const handleSort2 = (key) => {
  if (sortKey2 === key) {
    if (sortOrder2 === "asc") {
      setSortOrder2("desc");
      return;
    }
    if (sortOrder2 === "desc") {
      setSortKey2(null);
      setSortOrder2(null);
      return;
    }
  }
  setSortKey2(key);
  setSortOrder2("asc");
};
const filteredAndSortedData2 = useMemo(() => {
  if (!sortKey2 || !sortOrder2) return filteredData2;

  return [...filteredData2].sort((a, b) => {
    const numKeys = ["LS2target", "LS2eoy", "CY2target"];

    if (numKeys.includes(sortKey2)) {
      const valA = Number(a[sortKey2] || 0);
      const valB = Number(b[sortKey2] || 0);
      return sortOrder2 === "asc" ? valA - valB : valB - valA;
    }

    const valA = (a[sortKey2] ?? "").toString().toLowerCase();
    const valB = (b[sortKey2] ?? "").toString().toLowerCase();

    return sortOrder2 === "asc"
      ? valA.localeCompare(valB)
      : valB.localeCompare(valA);
  });
}, [filteredData2, sortKey2, sortOrder2]);
const handleSort3 = (key) => {
  if (sortKey3 === key) {
    if (sortOrder3 === "asc") {
      setSortOrder3("desc");
      return;
    }
    if (sortOrder3 === "desc") {
      setSortKey3(null);
      setSortOrder3(null);
      return;
    }
  }
  setSortKey3(key);
  setSortOrder3("asc");
};
const filteredAndSortedData3 = useMemo(() => {
  if (!sortKey3 || !sortOrder3) return filteredData3;

  return [...filteredData3].sort((a, b) => {
    const numKeys = ["LS3target", "LS3eoy", "CY3target"];

    if (numKeys.includes(sortKey3)) {
      const valA = Number(a[sortKey3] || 0);
      const valB = Number(b[sortKey3] || 0);
      return sortOrder3 === "asc" ? valA - valB : valB - valA;
    }

    const valA = (a[sortKey3] ?? "").toString().toLowerCase();
    const valB = (b[sortKey3] ?? "").toString().toLowerCase();

    return sortOrder3 === "asc"
      ? valA.localeCompare(valB)
      : valB.localeCompare(valA);
  });
}, [filteredData3, sortKey3, sortOrder3]);

  const handleDownload = async () => {
    const hasData =
      (filteredData1 && filteredData1.length > 0) ||
      (filteredData2 && filteredData2.length > 0) ||
      (filteredData3 && filteredData3.length > 0);

    if (!hasData) {
      alert("No data available to generate preview");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();

      /* =====================================================
         🟢 SHEET 1 : OVERALL COMPETENCE TARGETS
      ===================================================== */
      if (filteredData1.length) {
        const sheet1 = workbook.addWorksheet("Overall Targets");

        sheet1.columns = [
          { header: "", key: "label", width: 35 },
          { header: `${selectedyear - 1} Target`, key: "pyTarget", width: 18 },
          { header: `${selectedyear - 1} (EOY)`, key: "pyEoy", width: 18 },
          { header: `${selectedyear} Target`, key: "cyTarget", width: 18 },
        ];

        sheet1.getRow(1).eachCell((cell) => {
          cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
          cell.fill = {
            type: "pattern",
            pattern: "solid",
            fgColor: { argb: "FF476896" },
          };
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });

        filteredData1.forEach(row => {
          sheet1.addRow({
            label: row.field1 || "",
            pyTarget: row.LStarget || "",
            pyEoy: row.LSeoy || "",
            cyTarget: row.CYtarget || "",
          });
        });

        sheet1.views = [{ state: "frozen", ySplit: 1 }];
      }

      /* =====================================================
         🟣 SHEET 2 : CATEGORY WISE COMPETENCE
      ===================================================== */
      if (filteredData2.length) {
        const sheet2 = workbook.addWorksheet("Category Wise");

        sheet2.columns = [
          { header: "Competence Development", key: "name", width: 100 },
          { header: `${selectedyear - 1} Target`, key: "pyTarget", width: 18 },
          { header: `${selectedyear - 1} (EOY)`, key: "pyEoy", width: 18 },
          { header: `${selectedyear} Target`, key: "cyTarget", width: 18 },
        ];

        sheet2.getRow(1).eachCell((cell) => {
          cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
          cell.fill = {
            type: "pattern",
            pattern: "solid",
            fgColor: { argb: "FF476896" },
          };
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });

        filteredData2.forEach(row => {
          sheet2.addRow({
            name: row.competencedevelopment || "",
            pyTarget: row.LS2target || "",
            pyEoy: row.LS2eoy || "",
            cyTarget: row.CY2target || "",
          });
        });

        sheet2.views = [{ state: "frozen", ySplit: 1 }];
      }

      /* =====================================================
         🔵 SHEET 3 : COMPETENCE TYPE DETAILS
      ===================================================== */
      if (filteredData3.length) {
        const sheet3 = workbook.addWorksheet("Competence Type");

        sheet3.columns = [
          { header: "Year", key: "year", width: 12 },
          { header: "Competence Type", key: "type", width: 50 },
          { header: `${selectedyear - 1} Target`, key: "pyTarget", width: 18 },
          { header: `${selectedyear - 1} (EOY)`, key: "pyEoy", width: 18 },
          { header: `${selectedyear} Target`, key: "cyTarget", width: 18 },
          { header: "Remarks", key: "remarks", width: 100 },
        ];

        sheet3.getRow(1).eachCell((cell) => {
          cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
          cell.fill = {
            type: "pattern",
            pattern: "solid",
            fgColor: { argb: "FF476896" },
          };
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });

        filteredData3.forEach(row => {
          sheet3.addRow({
            year: row.year || "",
            type: row.competencetype || "",
            pyTarget: row.LS3target || "",
            pyEoy: row.LS3eoy || "",
            cyTarget: row.CY3target || "",
            remarks: row.remark || "",
          });
        });

        sheet3.views = [{ state: "frozen", ySplit: 1 }];
      }

      /* =====================================================
         📤 CREATE FILE → UPLOAD TEMP → PREVIEW
      ===================================================== */
      const buffer = await workbook.xlsx.writeBuffer();

      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const file = new File(
        [blob],
        `Competence_Development_${selectedyear}.xlsx`,
        {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        }
      );

      const response = await uploadTempFile(file);

      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        alert("Upload succeeded but preview not available.");
      }
    } catch (error) {
      console.error("❌ Failed to generate Competence Excel preview:", error);
      alert("Failed to generate preview. Check console for details.");
    }
  };

  // ⭐ Save functionality
  const handleSaveData = async () => {
    if (!pdpId) {
      alert("❌ PDP ID is missing. Cannot save data.");
      return;
    }

    // ⭐ NEW: Double-check edit permission before saving
    if (!canEdit) {
      alert(`❌ Cannot save. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      return;
    }

    try {
      setIsSaving(true);
      setSaveSuccess(false);
      setError(null);
      
      const rows = editableData3
        .filter(row => row.id)
        .map(row => ({
          id: row.id,
          py_eoy: parseFloat(row.LS3eoy) || 0,
          target: parseFloat(row.CY3target) || 0,
          remarks: row.remark || null
        }));

      console.log("💾 Saving competence development data:");
      console.log("  Rows count:", rows.length);

      await updateMultiplePdpCompeDev(rows);
      
      setSaveSuccess(true);
      
      // Refetch data
      try {
        const updatedData = await getPdpCompetenceDevelopmentsByPdpId(pdpId);
        setApiData(updatedData);
      } catch (refreshError) {
        console.warn("⚠️ Could not refresh data after save:", refreshError);
      }
      
    } catch (error) {
      console.error("❌ Error saving data:", error);
      setError(error.message || "Failed to save data");
    } finally {
      setIsSaving(false);
    }
  };

  const handleFieldChange = (index, field, value) => {
    // ⭐ NEW: Prevent editing if status is locked
    if (!canEdit) {
      console.warn("⚠️ Editing is disabled for this PDP status:", pdpStatus);
      return;
    }
    
    const updatedData = [...editableData3];
    updatedData[index][field] = value;
    setEditableData3(updatedData);
  };

  // ═══════════════════════════════════════════════════════════════
  // LOADING STATE
  // ═══════════════════════════════════════════════════════════════
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-darkblue1 mx-auto mb-4"></div>
          <p className="text-gray-600 font-medium">Loading competence development data...</p>
          <p className="text-gray-500 text-sm mt-2">PDP ID: {pdpId}</p>
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // ERROR STATE
  // ═══════════════════════════════════════════════════════════════
  if (error && !apiData.length) {
    return (
      <div className="bg-red-50 border border-red-300 p-6 text-center">
        <div className="text-red-600 mb-4">
          <AlertCircle className="w-12 h-12 mx-auto mb-2" />
          <h3 className="text-lg font-semibold mb-2">Error Loading Data</h3>
          <p className="text-sm">{error}</p>
        </div>
        <button
          onClick={() => window.location.reload()}
          className="bg-darkblue1 text-white px-6 py-2 hover:bg-darkblue1/90 transition"
        >
          Retry
        </button>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // MAIN RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="w-full space-y-3">
      {/* ⭐ NEW: Status Lock Banner - Shows when dealer cannot edit due to status */}
      {/* {isStatusLocked && (
        <div className="bg-amber-50 border border-amber-300 rounded-lg p-3 flex items-start gap-3">
          <div className="flex-shrink-0 mt-0.5">
            <Lock size={20} className="text-amber-600" />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-amber-800 mb-1">
              Editing Disabled
            </h4>
            <p className="text-xs text-amber-700">
              This PDP is in <span className="font-bold">{pdpStatus}</span> status. 
              Data can only be edited when status is <span className="font-semibold">"Created"</span> or <span className="font-semibold">"Started"</span>.
            </p>
            <p className="text-xs text-amber-600 mt-1">
              {pdpStatus === "Pending Review" && "The PDP is awaiting admin approval."}
              {pdpStatus === "Approved" && "The PDP has been approved and is now read-only."}
              {pdpStatus === "Completed" && "The PDP has been completed and finalized."}
            </p>
          </div>
        </div>
      )} */}

      {/* Success Message */}
      {saveSuccess && (
        <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded flex items-center gap-2">
          <AlertCircle size={18} />
          <span className="text-sm font-medium">Data saved successfully!</span>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded flex items-center gap-2">
          <AlertCircle size={18} />
          <span className="text-sm font-medium">{error}</span>
        </div>
      )}

      {/* Header Section */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 w-full">
        <div className="flex flex-col md:flex-row md:items-center gap-3 flex-wrap w-full">
          <div className="flex flex-row items-center gap-3">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="w-[1/2]"
              bgColor="bg-white"
              borderColor="border-black/60"
              textColor="text-black"
              focusRing="focus:ring-darkblue1"
              shadow="shadow-sm"
              inputPadding="pl-6 pr-3 py-1.5"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              iconColor="text-black"
            />

           <Filter
  name="categories"
  options={categories}
   value={selectedCategories || []}
  onChange={(name, value) => setSelectedCategories(value)}
  placeholder="Select Categories"
              className=""
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-gray-100"
              dropdownBorderColor="border-black/30"
              textColor="text-black"
              customWidth="w-[280px]"
            />
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* ⭐ NEW: Status Badge */}
          <div className={`shadow-sm px-3 py-1.5 flex items-center justify-center gap-2 border rounded ${getStatusBadgeColor(pdpStatus)}`}>
            {isStatusLocked && <Lock size={14} />}
            <span className="w-2 h-2 bg-current rounded-full inline-block opacity-60"></span>
            <span className="text-xs font-medium whitespace-nowrap">{pdpStatus}</span>
          </div>

          <button
            onClick={handleDownload}
            className="bg-darkblue1 text-xs font-medium text-white px-5 py-1.5 hover:bg-darkblue1/90 
                       transition-all duration-200 flex items-center gap-2 whitespace-nowrap shadow-sm"
          >
            <Download size={14} />
            Download
          </button>
        </div>
      </div>

      {/* First Table - Machine Population */}
      <div className="border border-Dustyblue overflow-hidden bg-white shadow-sm">
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4 py-1.5 text-left border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%]"></th>
                <th className="px-4 py-1.5 text-center border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">{+selectedyear - 1} Target</th>
                <th className="px-4 py-1.5 text-center border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">{+selectedyear - 1} (EOY)</th>
                <th className="px-4 py-1.5 text-center border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[20%]">{selectedyear} Target</th>
              </tr>
            </thead>
            <tbody>
              {filteredData1.map((item, idx) => (
                <tr key={idx} className="bg-white text-xs">
                  <td className="px-4 py-1 text-black border border-grey2 border-t-0 border-l-0 font-normal">{item.field1}</td>
                  <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0 text-black">{item.LStarget}</td>
                  <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0 text-black">{item.LSeoy}</td>
                  <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0 text-black">{item.CYtarget}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="md:hidden p-4 space-y-3">
          {filteredData1.length > 0 ? (
            filteredData1.map((item, idx) => (
              <div key={idx} className="bg-white border border-gray-200 p-4 rounded">
                <h4 className="font-medium text-black mb-3">{item.field1}</h4>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-gray-500 block mb-1">{+selectedyear - 1} Target</span>
                    <span className="text-black font-medium">{item.LStarget}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 block mb-1">{+selectedyear - 1} (EOY)</span>
                    <span className="text-black font-medium">{item.LSeoy}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-gray-500 block mb-1">{selectedyear} Target</span>
                    <span className="text-black font-semibold">{item.CYtarget}</span>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-gray-400">No data found.</div>
          )}
        </div>
      </div>

      {/* Show remaining tables only after category selection */}
      {selectedCategories.length > 0  && (
        <>
          {/* Second Table - Category Summary */}
          <div className="border border-Dustyblue overflow-hidden bg-white shadow-sm">
 <div
          ref={table2Ref}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
              maxHeight: filteredAndSortedData2.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
           onScroll={handleScroll2}
          >            <table className="w-full text-xs  table-fixed ">
             <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                  <tr>
 <th
      className="px-4 py-1.5 text-left border border-grey2 border-t-0 border-l-0 font-normal cursor-pointer w-[40%]"
      onClick={() => handleSort2("competencedevelopment")}
    >
      <div className="flex items-center gap-1">
        Competence Development
        {sortKey2 !== "competencedevelopment" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

        {sortKey2 === "competencedevelopment" && sortOrder2 === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey2 === "competencedevelopment" && sortOrder2 === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>                    
<th
      className="px-4 py-1.5 text-center border border-grey2 border-t-0 border-l-0 font-normal cursor-pointer w-[20%]"
      onClick={() => handleSort2("LS2target")}
    >
      <div className="flex items-center justify-center gap-1">
        {+selectedyear - 1} Target
        {sortKey2 === "LS2target" && sortOrder2 === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey2 === "LS2target" && sortOrder2 === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>                     <th
      className="px-4 py-1.5 text-center border border-grey2 border-t-0 border-l-0 font-normal cursor-pointer w-[20%]"
      onClick={() => handleSort2("LS2eoy")}
    >
      <div className="flex items-center justify-center gap-1">
        {+selectedyear - 1} (EOY)
        {sortKey2 === "LS2eoy" && sortOrder2 === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey2 === "LS2eoy" && sortOrder2 === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    <th
      className="px-4 py-1.5 text-center border border-grey2 border-t-0 border-l-0 border-r-0 font-normal cursor-pointer w-[20%]"
      onClick={() => handleSort2("CY2target")}
    >
      <div className="flex items-center justify-center gap-1">
        {selectedyear} Target
        {sortKey2 === "CY2target" && sortOrder2 === "asc" && <ChevronUp className="w-3 h-3" />}
        {sortKey2 === "CY2target" && sortOrder2 === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>                  </tr>
                </thead>
               <tbody>
  {filteredAndSortedData2.map((item, idx) => (
    <tr key={idx} className="bg-white text-xs">

      {/* Competence Development */}
      <td className="px-4 py-1 border border-grey2 border-l-0">
        <div className="relative w-full max-w-[500px]">
          <p
            className="truncate w-full cursor-pointer"
            onMouseEnter={() => {
              if (item.competencedevelopment?.length > 20) {
                setHoveredCell(`comp-${idx}`);
              }
            }}
            onMouseLeave={() => setHoveredCell(null)}
          >
            {item.competencedevelopment}
          </p>

          {hoveredCell === `comp-${idx}` && (
<span className="absolute left-0 top-full -mt-2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 z-10 whitespace-nowrap shadow-lg">            
    {item.competencedevelopment}
            </span>
          )}
        </div>
      </td>

      {/* LS2target */}
      <td className="px-4 py-1 text-center border border-grey2">
       
            {item.LS2target}
      </td>

      {/* LS2eoy */}
      <td className="px-4 py-1 text-center border border-grey2">
            {item.LS2eoy}
      </td>

      {/* CY2target */}
      <td className="px-4 py-1 text-center border border-grey2 border-r-0">
        
            {item.CY2target}
         
        
      </td>

    </tr>
  ))}
</tbody>
{showScroll2 && (
  <div className="fixed bottom-12 right-6 z-40 pointer-events-auto animate-fade-in">
    
    {/* 🔼 Scroll UP */}
    {scrollDir2 === "down" && (
      <button
        onClick={scrollTop2}
        className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
        aria-label="Scroll to top"
      >
        <ArrowUp className="w-2 h-2" />
      </button>
    )}

    {/* 🔽 Scroll DOWN */}
    {scrollDir2 === "up" && (
      <button
        onClick={scrollBottom2}
        className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
        aria-label="Scroll to bottom"
      >
        <ArrowDown className="w-2 h-2" />
      </button>
    )}

  </div>
)}         
              </table>
            </div>

            <div className="md:hidden p-4 space-y-3">
              {filteredData2.length > 0 ? (
                filteredData2.map((item, idx) => (
                  <div key={idx} className="bg-white border border-gray-200 p-4 rounded">
                    <h4 className="font-medium text-black mb-3">{item.competencedevelopment}</h4>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <span className="text-gray-500 block mb-1">{+selectedyear - 1} Target</span>
                        <span className="text-black font-medium">{item.LS2target}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 block mb-1">{+selectedyear - 1} (EOY)</span>
                        <span className="text-black font-medium">{item.LS2eoy}</span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-gray-500 block mb-1">{selectedyear} Target</span>
                        <span className="text-black font-semibold">{item.CY2target}</span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-gray-400">No data found.</div>
              )}
            </div>
          </div>

          {/* Third Table - Detailed Breakdown */}
         <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
          <div
           ref={table3Ref}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
               maxHeight: filteredAndSortedData3.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
            onScroll={handleScroll3}
          >
            <table className="w-full text-xs whitespace-nowrap table-fixed min-w-[350px] lg:min-w-full">
              <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                  <tr>
<th
  className="px-4 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%] cursor-pointer select-none"
  onClick={() => handleSort3("year")}
>
  <div className="flex items-center gap-1">
    Year
    {sortKey3 !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
    {sortKey3 === "year" && sortOrder3 === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey3 === "year" && sortOrder3 === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>
<th
  className="px-4 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[15%] cursor-pointer select-none"
  onClick={() => handleSort3("competencetype")}
>
  <div className="flex items-center gap-1">
    Competence Type
    {sortKey3 === "competencetype" && sortOrder3 === "asc" && (
      <ChevronUp className="w-3 h-3" />
    )}
    {sortKey3 === "competencetype" && sortOrder3 === "desc" && (
      <ChevronDown className="w-3 h-3" />
    )}
  </div>
</th>
<th
  className="px-4 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[6%] cursor-pointer select-none"
  onClick={() => handleSort3("LS3target")}
>
  <div className="flex items-center gap-1">
    {+selectedyear - 1} Target
    {sortKey3 === "LS3target" && sortOrder3 === "asc" && (
      <ChevronUp className="w-3 h-3" />
    )}
    {sortKey3 === "LS3target" && sortOrder3 === "desc" && (
      <ChevronDown className="w-3 h-3" />
    )}
  </div>
</th>
<th
  className="px-4 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[6%] cursor-pointer select-none"
  onClick={() => handleSort3("LS3eoy")}
>
  <div className="flex items-center justify-center gap-1">
    {+selectedyear - 1} (EOY)
    {sortKey3 === "LS3eoy" && sortOrder3 === "asc" && (
      <ChevronUp className="w-3 h-3" />
    )}
    {sortKey3 === "LS3eoy" && sortOrder3 === "desc" && (
      <ChevronDown className="w-3 h-3" />
    )}
  </div>
</th>
<th
  className="px-4 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[8%] cursor-pointer select-none"
  onClick={() => handleSort3("CY3target")}
>
  <div className="flex items-center justify-center gap-1">
    {selectedyear} Target
    {sortKey3 === "CY3target" && sortOrder3 === "asc" && (
      <ChevronUp className="w-3 h-3" />
    )}
    {sortKey3 === "CY3target" && sortOrder3 === "desc" && (
      <ChevronDown className="w-3 h-3" />
    )}
  </div>
</th>
<th
  className="px-4 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 w-[20%] cursor-pointer select-none"
  onClick={() => handleSort3("remark")}
>
  <div className="flex items-center gap-1">
    Remarks
    {sortKey3 === "remark" && sortOrder3 === "asc" && (
      <ChevronUp className="w-3 h-3" />
    )}
    {sortKey3 === "remark" && sortOrder3 === "desc" && (
      <ChevronDown className="w-3 h-3" />
    )}
  </div>
</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAndSortedData3.map((row, idx) => (
                    <tr key={idx}>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-black">
  {row.year}
</td>

<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-black text-xs">
  <div className="relative">
    <p
      className={`max-w-[50rem] cursor-pointer ${
        expandedCell === row.id + "-competencetype"
          ? "whitespace-normal"
          : "truncate"
      }`}
      onClick={() =>
        setExpandedCell(
          expandedCell === row.id + "-competencetype"
            ? null
            : row.id + "-competencetype"
        )
      }
    >
      {row.competencetype || "—"}
    </p>
  </div>
</td>

                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-black text-xs">
  <div className="relative">
    <p
      className={`max-w-[8rem] cursor-pointer ${
        expandedCell === row.id + "-ls3target"
          ? "whitespace-normal"
          : "truncate"
      }`}
      onClick={() =>
        setExpandedCell(
          expandedCell === row.id + "-ls3target"
            ? null
            : row.id + "-ls3target"
        )
      }
    >
      {row.LS3target || "—"}
    </p>
  </div>
</td>

                      <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0">
                        {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                        {canEdit ? (
                          <input
                            type="text"
                            value={row.LS3eoy}
                            onChange={(e) => handleFieldChange(idx, "LS3eoy", e.target.value)}
                            className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1"
                          />
                        ) : (
                          <span className="text-black">{row.LS3eoy}</span>
                        )}
                      </td>
                      <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0">
                        {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                        {canEdit ? (
                          <input
                            type="text"
                            value={row.CY3target}
                            onChange={(e) => handleFieldChange(idx, "CY3target", e.target.value)}
                            className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1"
                          />
                        ) : (
                          <span className="text-black">{row.CY3target}</span>
                        )}
                      </td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
  {canEdit ? (
    <textarea
      value={row.remark}
      onChange={(e) => handleFieldChange(idx, "remark", e.target.value)}
      className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1 resize-none"
      rows="2"
    />
  ) : (
    <div className="relative">
      <p
        className={`cursor-pointer max-w-[20rem] ${
          expandedCell === row.id + "-remark"
            ? "whitespace-normal"
            : "truncate"
        }`}
        onClick={() =>
          setExpandedCell(
            expandedCell === row.id + "-remark"
              ? null
              : row.id + "-remark"
          )
        }
      >
        {row.remark }
      </p>
    </div>
  )}
</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
 {showScroll3 && (
  <div className="fixed bottom-14 right-6 z-40 pointer-events-auto animate-fade-in">
    
    {/* 🔼 Scroll UP */}
    {scrollDir3 === "down" && (
      <button
        onClick={scrollTop3}
        className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
        aria-label="Scroll to top"
      >
        <ArrowUp className="w-2 h-2" />
      </button>
    )}

    {/* 🔽 Scroll DOWN */}
    {scrollDir3 === "up" && (
      <button
        onClick={scrollBottom3}
        className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
        aria-label="Scroll to bottom"
      >
        <ArrowDown className="w-2 h-2" />
      </button>
    )}

  </div>
)}

            <div className="md:hidden p-4 space-y-4">
              {filteredData3.length > 0 ? (
                filteredData3.map((row, idx) => (
                  <div key={idx} className="bg-white border border-gray-200 p-4 space-y-3 rounded">
                    <div className="flex justify-between pb-2 border-b border-gray-200">
                      <span className="text-xs text-gray-500">Year: {row.year}</span>
                      <span className="text-xs bg-gray-100 px-2 py-1 rounded">#{idx + 1}</span>
                    </div>
                    
                    <div>
                      <span className="text-xs text-gray-500 block mb-1">Competence Type</span>
                      <span className="text-sm font-medium text-black">{row.competencetype}</span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <span className="text-gray-500 block mb-1">{+selectedyear - 1} Target</span>
                        <span className="text-black text-xs">{row.LS3target}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 block mb-1">{+selectedyear - 1} (EOY)</span>
                        {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                        {canEdit ? (
                          <input
                            type="text"
                            value={row.LS3eoy}
                            onChange={(e) => handleFieldChange(idx, "LS3eoy", e.target.value)}
                            className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1"
                          />
                        ) : (
                          <span className="text-black">{row.LS3eoy}</span>
                        )}
                      </div>
                      <div>
                        <span className="text-gray-500 block mb-1">{selectedyear} Target</span>
                        {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                        {canEdit ? (
                          <input
                            type="text"
                            value={row.CY3target}
                            onChange={(e) => handleFieldChange(idx, "CY3target", e.target.value)}
                            className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1"
                          />
                        ) : (
                          <span className="text-black font-semibold">{row.CY3target}</span>
                        )}
                      </div>
                    </div>

                    <div>
                      <span className="text-xs text-gray-500 block mb-1">Remarks</span>
                      {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                      {canEdit ? (
                        <textarea
                          value={row.remark}
                          onChange={(e) => handleFieldChange(idx, "remark", e.target.value)}
                          className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1 resize-none"
                          rows="2"
                        />
                      ) : (
                        <span className="text-sm text-black">{row.remark || "—"}</span>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-gray-400">No data found.</div>
              )}
            </div>
          </div>
        </>
      )}

      {/* ⭐ FIXED: Only show Save button when canEdit is true */}
      {selectedCategories.length > 0 && canEdit && (
        <div className="flex justify-end">
          <button
            onClick={handleSaveData}
            disabled={isSaving}
            className="bg-darkblue1 text-white px-5 py-2 text-sm font-medium rounded hover:bg-darkblue1/90 transition-all duration-200 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
          >
            <Save size={16} />
            {isSaving ? "Saving..." : "Save"}
          </button>
        </div>
      )}
    </div>
  );
};

export default CompetenceDevelopment;