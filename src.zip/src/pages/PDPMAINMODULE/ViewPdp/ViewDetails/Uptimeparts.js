import React, { useState, useEffect,useRef } from "react";
import { Download, X, Calendar, Lock, User, CheckCircle, Clock } from "lucide-react";
import Searchinput from "../../../../Components/Searchinput";
import { useNavigate, useLocation } from "react-router-dom";
import { getPdpUptimePartsByPdpId } from "../../../../services/PDP/UptimepartsHyperlink/pdphyperUptimeparts.service";
import { getPdpSignoffsByPdpId, updatePdpSignoff } from "../../../../services/PDP/Signoff/signoff.service";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../../services/download/bluckDownload.service";
import { useSelector } from "react-redux";
import { useMemo } from "react";
import { ChevronsUpDown,ChevronUp,ChevronDown,ArrowUp,ArrowDown } from "lucide-react";
// ═══════════════════════════════════════════════════════════════
// ROLE CONFIGURATIONS FOR SIGNOFF
// ═══════════════════════════════════════════════════════════════

// Roles that can sign "Dealer Uptime & Parts Head" category
const DEALER_SIGNOFF_ROLES = [
  "Dealer CST Head",
  "Dealer CEO",
  "Dealer Principal"
];

// Roles that can sign "Volvo CE MA Uptime & Parts Head" category
const VOLVO_SIGNOFF_ROLES = [
  "Uptime & Parts Manager",
  "Administrator",
  "Head Of Channel Developement (Region India)"
];

// Admin roles (for button text)
const ADMIN_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Uptime & Parts Manager"
];

// ═══════════════════════════════════════════════════════════════
// CATEGORY CONFIGURATION - Display names and DB keys
// ═══════════════════════════════════════════════════════════════
const CATEGORY_CONFIG = {
  'Uptime_Volvo': {
    displayName: 'Volvo CE MA Uptime & Parts Head',
    shortName: 'Volvo CE MA Uptime & Parts Head',
    dbKey: 'Uptime_Volvo'
  },
  'Uptime_Dealer': {
    displayName: 'Dealer Uptime & Parts Head',
    shortName: 'Dealer Uptime & Parts Head',
    dbKey: 'Uptime_Dealer'
  }
};

export default function Uptimeparts({ rowData, userRole }) {
  const [activeView, setActiveView] = useState("retail");
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [uptimePartsData, setUptimePartsData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"
const [hoveredCell, setHoveredCell] = useState(null);
const tableContainerRef = useRef(null);
const [expandedCell, setExpandedCell] = useState(null);
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


  // Signoff states
  const [signoffData, setSignoffData] = useState([]);
  const [isLoadingSignoffs, setIsLoadingSignoffs] = useState(false);
  const [isSigningOff, setIsSigningOff] = useState(null);
  
  const navigate = useNavigate();
  const location = useLocation();

  // Get user data from Redux
  const userData = useSelector((state) => state.user?.data || state.user);

  // ⭐ Extract PDP ID from rowData
  const pdpId = React.useMemo(() => {
    if (rowData?.id) {
      return rowData.id;
    }
    if (location.state?.rowData?.id) {
      return location.state.rowData.id;
    }
    return null;
  }, [rowData, location.state]);

  const selectedyear = React.useMemo(() => {
    if (rowData?.year) {
      return parseInt(rowData.year);
    }
    if (location.state?.rowData?.year) {
      return parseInt(location.state.rowData.year);
    }
    return new Date().getFullYear();
  }, [rowData, location.state]);

  // ═══════════════════════════════════════════════════════════════
  // CHECK IF MEETING HAS BEEN SCHEDULED
  // ═══════════════════════════════════════════════════════════════
  const signoffMeetingDate = rowData?.signoffMeetingDate || rowData?.signoff_meeting_date;
  const isMeetingScheduled = !!signoffMeetingDate;

  // ═══════════════════════════════════════════════════════════════
  // ROLE CHECKS
  // ═══════════════════════════════════════════════════════════════
  const effectiveRole = userRole;
  
  const isAdmin = ADMIN_ROLES.some(
    role => role.toLowerCase() === effectiveRole?.toLowerCase()
  );

  const canSignDealerCategory = DEALER_SIGNOFF_ROLES.some(
    role => role.toLowerCase() === effectiveRole?.toLowerCase()
  );

  const canSignVolvoCategory = VOLVO_SIGNOFF_ROLES.some(
    role => role.toLowerCase() === effectiveRole?.toLowerCase()
  );

  // ⭐ UPDATED: Always show all categories
  const getVisibleCategories = () => {
    return ['Uptime_Volvo', 'Uptime_Dealer'];
  };

  // ⭐ Fetch uptime parts data using getPdpUptimePartsByPdpId
  useEffect(() => {
    const fetchUptimePartsData = async () => {
      if (!pdpId) {
        console.error("❌ PDP ID is missing");
        setError("PDP ID is required to load uptime parts data");
        setIsLoading(false);
        return;
      }

      if (!selectedyear || isNaN(selectedyear)) {
        setError("Invalid year parameter");
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);
        
        const filters = {
          category: activeView === "retail" ? "Retails" : "Key Account",
        };

        const data = await getPdpUptimePartsByPdpId(pdpId, filters);
        setUptimePartsData(data);
      } catch (error) {
        console.error("❌ Error fetching uptime parts data:", error);
        setError(error.message || "Failed to load uptime parts data. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchUptimePartsData();
  }, [pdpId, selectedyear, activeView]);

  // ⭐ Fetch signoff data when modal opens
  useEffect(() => {
    const fetchSignoffData = async () => {
      if (!showModal || !pdpId) return;
      
      setIsLoadingSignoffs(true);
      try {
        const signoffs = await getPdpSignoffsByPdpId(pdpId);
        // Filter for uptime categories only
        const uptimeSignoffs = signoffs.filter(s => 
          s.category === 'Uptime_Volvo' || s.category === 'Uptime_Dealer'
        );
        setSignoffData(uptimeSignoffs);
      } catch (error) {
        console.error("❌ Error fetching signoff data:", error);
      } finally {
        setIsLoadingSignoffs(false);
      }
    };

    fetchSignoffData();
  }, [showModal, pdpId]);

  // ⭐ Generate table data with "Uptime and Parts" as main category
  const generateTableData = () => {
    if (!uptimePartsData || uptimePartsData.length === 0) {
      return [];
    }

    // Group by uptime_parts_category (Category)
    const groupedByCategory = uptimePartsData.reduce((acc, item) => {
      const category = item.uptime_parts_category || "Others";
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(item);
      return acc;
    }, {});

    // Build nested structure: Category → Equipment Make → Details
    const categories = Object.keys(groupedByCategory).map(categoryName => {
      const groupedByMake = groupedByCategory[categoryName].reduce((acc, item) => {
        const make = item.equipment_make || "Unknown";
        if (!acc[make]) {
          acc[make] = [];
        }
        acc[make].push(item);
        return acc;
      }, {});

      const makes = Object.keys(groupedByMake).map(makeName => {
        const detailGroups = groupedByMake[makeName].reduce((acc, item) => {
          const detail = item.details || "Unknown";
          if (!acc[detail]) {
            acc[detail] = {
              detail: detail,
              target: 0,
              total: 0,
              measurement: item.measurement_units || "Units",
              count: 0
            };
          }
          
          acc[detail].count += 1;
          
          const targetValue = parseFloat(item.target || 0);
          const totalValue = parseFloat(item.total || 0);
          
          acc[detail].target += targetValue;
          acc[detail].total += totalValue;
          
          return acc;
        }, {});

        const details = Object.values(detailGroups).map(detailGroup => {
          return {
            detail: detailGroup.detail,
            target: detailGroup.target.toString(),
            total: detailGroup.total.toString(),
            measurement: detailGroup.measurement
          };
        });

        return {
          name: makeName,
          details: details
        };
      });

      return {
        category: categoryName,
        makes: makes
      };
    });

    const tableData = [{
      mainCategory: "Uptime and Parts",
      isHyperlink: true,
      categories: categories
    }];

    return tableData;
  };

  const currentData = generateTableData();
  
  // ⭐ Filter data based on search term
  const filteredData = currentData
    .map((mainSection) => {
      const filteredCategories = mainSection.categories
        .map((categorySection) => {
          const filteredMakes = categorySection.makes
            .map((make) => {
              const filteredDetails = make.details.filter((detail) =>
                [
                  mainSection.mainCategory,
                  categorySection.category,
                  make.name,
                  detail.detail,
                  detail.target,
                  detail.total,
                  detail.measurement
                ].some((value) =>
                  value?.toString().toLowerCase().includes(searchTerm.toLowerCase())
                )
              );
              if (filteredDetails.length > 0) return { ...make, details: filteredDetails };
              return null;
            })
            .filter(Boolean);

          if (filteredMakes.length > 0) return { ...categorySection, makes: filteredMakes };
          return null;
        })
        .filter(Boolean);

      if (filteredCategories.length > 0) return { ...mainSection, categories: filteredCategories };
      return null;
    })
    .filter(Boolean);

  const getTotalRowsForMainSection = (mainSection) =>
    mainSection.categories.reduce((sum, categorySection) => 
      sum + categorySection.makes.reduce((makeSum, make) => makeSum + make.details.length, 0)
    , 0);

  const getTotalRowsForCategory = (categorySection) =>
    categorySection.makes.reduce((sum, make) => sum + make.details.length, 0);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return filteredData
    .map((mainSection) => {
      let sortedCategories = [...mainSection.categories];

      // Sort categories if needed
      if (sortKey === "category") {
        sortedCategories.sort((a, b) => {
          const valA = (a.category ?? "").toLowerCase();
          const valB = (b.category ?? "").toLowerCase();
          return sortOrder === "asc"
            ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: "base" })
            : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: "base" });
        });
      }

      sortedCategories = sortedCategories.map((category) => {
        let sortedMakes = [...category.makes];

        // Sort makes
        if (sortKey === "make") {
          sortedMakes.sort((a, b) => {
            const valA = (a.name ?? "").toLowerCase();
            const valB = (b.name ?? "").toLowerCase();
            return sortOrder === "asc"
              ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: "base" })
              : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: "base" });
          });
        }

        // Sort details
        sortedMakes = sortedMakes.map((make) => {
          const sortedDetails = [...make.details];
          if (["detail", "target", "total", "measurement"].includes(sortKey)) {
            sortedDetails.sort((a, b) => {
              const keyMap = { detail: "detail", target: "target", total: "total", measurement: "measurement" };
              const valA = (a[keyMap[sortKey]] ?? "").toString().toLowerCase();
              const valB = (b[keyMap[sortKey]] ?? "").toString().toLowerCase();
              return sortOrder === "asc"
                ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: "base" })
                : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: "base" });
            });
          }
          return { ...make, details: sortedDetails };
        });

        return { ...category, make: sortedMakes };
      });

      return { ...mainSection, categories: sortedCategories };
    })
    .sort((a, b) => {
      if (sortKey === "mainCategory") {
        const valA = (a.mainCategory ?? "").toLowerCase();
        const valB = (b.mainCategory ?? "").toLowerCase();
        return sortOrder === "asc"
          ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: "base" })
          : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: "base" });
      }
      return 0;
    });
}, [filteredData, sortKey, sortOrder]);

  const handleDownload = async () => {
    if (!filteredData || filteredData.length === 0) {
      alert("No data available to download");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet(`Uptime_Parts_${activeView}`);

      sheet.columns = [
        { header: "Sl. No", key: "slNo", width: 8 },
        { header: "Main Category", key: "mainCategory", width: 25 },
        { header: "Category", key: "category", width: 10 },
        { header: "Equipment Make", key: "make", width: 15 },
        { header: "Details", key: "detail", width: 75 },
        { header: "Target", key: "target", width: 15 },
        { header: "Total", key: "total", width: 15 },
        { header: "Measurement", key: "measurement", width: 15 },
      ];

      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      let slNo = 1;

      filteredData.forEach((mainSection) => {
        mainSection.categories.forEach((categorySection) => {
          categorySection.makes.forEach((make) => {
            make.details.forEach((detail) => {
              const row = sheet.addRow({
                slNo: slNo++,
                mainCategory: mainSection.mainCategory,
                category: categorySection.category,
                make: make.name,
                detail: detail.detail,
                target: detail.target,
                total: detail.total,
                measurement: detail.measurement,
              });

              row.eachCell((cell) => {
                cell.alignment = { vertical: "middle", horizontal: "left" };
              });
            });
          });
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const fileName = `Uptime_Parts_${activeView}_${selectedyear}.xlsx`;

      const file = new File([blob], fileName, {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const response = await uploadTempFile(file);

      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${encodeURIComponent(
            response
          )}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        alert("File uploaded but preview not available.");
      }
    } catch (error) {
      console.error("❌ Uptime Parts download failed:", error);
      alert("Failed to generate Excel preview. Please try again.");
    }
  };

  const handleModalAction = () => {
    if (!isMeetingScheduled) {
      alert("Signoff meeting must be scheduled before initiating the approval process.");
      return;
    }
    setShowModal(true);
  };

  // ⭐ Enhanced navigation - goes to all uptime parts
  const handleMainCategoryClick = () => {
    try {
      if (!pdpId) {
        alert("Missing PDP ID. Please refresh the page and try again.");
        return;
      }
      
      if (!selectedyear) {
        alert("Missing year data. Please refresh the page and try again.");
        return;
      }

      const basePath = activeView === "retail" ? "/pdp/view/retail/uptimeparts" : "/pdp/view/keyaccount/uptimeparts";
      
      const navigationState = {
        pdpId: pdpId,
        selectedYear: selectedyear,
        year: selectedyear,
        category: "Uptime and Parts",
        viewType: activeView,
        userRole: effectiveRole,
        fromPath: location.pathname,
        rowData: rowData || { 
          id: pdpId,
          year: selectedyear
        },
        uptimePartsData: uptimePartsData.filter(item => 
          parseInt(item.year) === selectedyear
        )
      };
      
      window.scrollTo({ top: 0, behavior: "smooth" });
      navigate(basePath, { 
        state: navigationState,
        replace: false
      });
    } catch (error) {
      console.error("❌ Navigation error:", error);
      alert("Failed to navigate. Please try again.");
    }
  };

  // Format meeting date for display
  const formatMeetingDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // SIGNOFF HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleSignOff = async (categoryKey) => {
    const signoffItem = signoffData.find(s => s.category === categoryKey);
    
    if (!signoffItem) {
      alert("Signoff record not found. Please contact administrator.");
      return;
    }

    if (signoffItem.isSigned) {
      alert("This category has already been signed off.");
      return;
    }

    setIsSigningOff(categoryKey);
    try {
      await updatePdpSignoff(signoffItem.id, {
        isSigned: true,
        signed_timestamp: new Date().toISOString(),
        user_id: userData?.id,
        user_persona: effectiveRole
      });

      // Update local state
      setSignoffData(prev => prev.map(item => {
        if (item.category === categoryKey) {
          return {
            ...item,
            isSigned: true,
            signed_timestamp: new Date().toISOString(),
            user_first_name: userData?.first_name || userData?.firstName,
            user_last_name: userData?.last_name || userData?.lastName,
            user_persona: effectiveRole
          };
        }
        return item;
      }));

      alert("Sign off completed successfully!");
    } catch (error) {
      console.error("❌ Signoff failed:", error);
      alert("Failed to sign off. Please try again.");
    } finally {
      setIsSigningOff(null);
    }
  };

  // Get signoff status for a category
  const getSignoffStatus = (categoryKey) => {
    const signoff = signoffData.find(s => s.category === categoryKey);
    if (!signoff) return { exists: false, isSigned: false };
    return {
      exists: true,
      isSigned: signoff.isSigned === 1 || signoff.isSigned === true,
      signedBy: signoff.user_first_name && signoff.user_last_name 
        ? `${signoff.user_first_name} ${signoff.user_last_name}`.trim()
        : 'Not Assigned',
      signedAt: signoff.signed_timestamp,
      designation: signoff.user_persona
    };
  };

  // Calculate completion percentage
  const getCompletionStats = () => {
    const visibleCategories = getVisibleCategories();
    const relevantSignoffs = signoffData.filter(s => visibleCategories.includes(s.category));
    const total = relevantSignoffs.length;
    const signed = relevantSignoffs.filter(s => s.isSigned === 1 || s.isSigned === true).length;
    return { total, signed, percentage: total > 0 ? Math.round((signed / total) * 100) : 0 };
  };

  // Check if user can sign a specific category
  const canUserSign = (categoryKey) => {
    if (categoryKey === 'Uptime_Dealer') {
      return canSignDealerCategory;
    } else if (categoryKey === 'Uptime_Volvo') {
      return canSignVolvoCategory;
    }
    return false;
  };

  // Get button text based on meeting status and role
  const getApprovalButtonText = () => {
    if (!isMeetingScheduled) {
      return "Approval Locked";
    }
    return isAdmin ? "Initiate Approval Process" : "View Sign Off Status";
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12 bg-white border-2 border-Dustyblue">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-darkblue1 mx-auto mb-4"></div>
          <p className="text-gray-600 font-medium">Loading uptime parts data...</p>
          <p className="text-gray-500 text-sm mt-2">PDP ID: {pdpId}</p>
          <p className="text-gray-500 text-sm">Year: {selectedyear}</p>
          <p className="text-gray-500 text-sm">Category: {activeView === "retail" ? "Retails" : "Key Account"}</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="bg-white border-2 border-red-300 p-8 text-center">
        <div className="text-red-600 mb-4">
          <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="text-lg font-semibold mb-2">Error Loading Data</h3>
          <p className="text-sm mb-4">{error}</p>
          <div className="text-xs text-gray-600 space-y-1">
            <p>PDP ID: {pdpId || "Not found"}</p>
            <p>Year: {selectedyear}</p>
            <p>Category: {activeView === "retail" ? "Retails" : "Key Account"}</p>
          </div>
        </div>
        <button
          onClick={() => window.location.reload()}
          className="bg-darkblue1 text-white px-6 py-2 hover:bg-darkblue1/90 transition"
        >
          Retry
        </button>
      </div>
    );
  }

  // Empty state
  if (!uptimePartsData || uptimePartsData.length === 0) {
    return (
      <div className="bg-white border-2 border-gray-300 p-8 text-center">
        <div className="text-gray-500 mb-4">
          <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
          </svg>
          <h3 className="text-lg font-semibold mb-2">No Uptime Parts Data</h3>
          <p className="text-sm mb-4">No uptime parts records found for this PDP.</p>
          <div className="text-xs text-gray-600 space-y-1">
            <p>PDP ID: {pdpId}</p>
            <p>Year: {selectedyear}</p>
            <p>Category: {activeView === "retail" ? "Retails" : "Key Account"}</p>
          </div>
        </div>
      </div>
    );
  }

  const visibleCategories = getVisibleCategories();
  const completionStats = getCompletionStats();

  return (
    <>
      {/* Toggle Buttons */}
      <div className="flex w-full mb-4 overflow-hidden shadow-sm">
        <button
          onClick={() => setActiveView("retail")}
          className={`flex-1 py-2 text-sm font-medium transition-all duration-200 ${
            activeView === "retail"
              ? "bg-darkblue1 text-white shadow-md"
              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
          }`}
        >
          Retail
        </button>
        <button
          onClick={() => setActiveView("key account")}
          className={`flex-1 py-2 text-sm font-medium transition-all duration-200 ${
            activeView === "key account"
              ? "bg-darkblue1 text-white shadow-md"
              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
          }`}
        >
          Key Account
        </button>
      </div>

      <div className="bg-white border border-Dustyblue shadow-[0_4px_10px_#0000001A]">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-0 gap-4 p-4">
          <div className="">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search "
              className="w-[1/2]"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              focusRing="focus:ring-black/60"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-2 sm:py-3"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              iconColor="text-black"
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <button
              onClick={handleDownload}
              disabled={filteredData.length === 0}
              className="bg-darkblue1 text-xs font-medium text-white px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Download size={14} className="text-current" />
              Download
            </button>

            {/* Approval Button */}
            <button
              onClick={handleModalAction}
              disabled={!isMeetingScheduled}
              className={`text-xs font-medium px-4 py-1.5 transition whitespace-nowrap flex items-center justify-center gap-2 ${
                isMeetingScheduled
                  ? "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"
              }`}
              title={!isMeetingScheduled ? "Signoff meeting must be scheduled first" : ""}
            >
              {!isMeetingScheduled && <Lock size={14} />}
              {getApprovalButtonText()}
            </button>
          </div>
        </div>

        {/* Desktop Table */}
        <div className="hidden lg:block overflow-x-auto">
           <div
              ref={tableContainerRef}
                className="overflow-y-auto overflow-x-auto scrollbar-hide"
                style={{
                  maxHeight: sortedData.length > 8 ? "calc(100vh - 320px)" : "auto",
                }}
                 onScroll={handleTableScroll}
              >
                       <table className="w-full text-sm border-collapse table-fixed">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">

  <tr>
    <th
  onClick={() => handleSort("mainCategory")}
  className="text-xs border border-l-0 px-3 py-1.5 font-medium text-left w-[15%] cursor-pointer select-none"
>
  <div className="flex items-center justify-start gap-1 w-full">
    Uptime and Parts
    {sortKey === "mainCategory" ? (
      sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3 text-white" />
      ) : (
        <ChevronDown className="w-3 h-3 text-white" />
      )
    ) : (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
  </div>
</th>


 <th
  onClick={() => handleSort("category")}
  className="text-xs border px-3 py-1.5 font-medium text-left w-[20%] cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Category
    {sortKey === "category" &&
      (sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3 text-white" />
      ) : (
        <ChevronDown className="w-3 h-3 text-white" />
      ))}
  </div>
</th>


    <th
      className="text-xs border px-3 py-1.5 font-medium text-left cursor-pointer w-[15%] select-none"
    >
        Equipment Make

    </th>

    <th
    
      className="text-xs border px-3 py-1.5 font-medium text-left w-[40%] cursor-pointer select-none"
    >
        Details
    </th>

    <th
    
      className="text-xs border px-3 py-1.5 font-medium text-center  w-[10%] cursor-pointer select-none"
    >
        Target
    </th>

   <th
  className="text-xs border px-3 py-1.5 font-medium text-center  w-[10%] cursor-pointer select-none"
>
    Total
   
</th>
    <th
      className="text-xs border border-r-0 px-3 py-1.5 font-medium text-center w-[12%] cursor-pointer select-none"
    >
        Measurement
    </th>
  </tr>
</thead>

            <tbody>
              {sortedData.length > 0 ? (
                sortedData.map((mainSection, mainIdx) => {
                  let mainRowSpan = getTotalRowsForMainSection(mainSection);
                  let mainRowRendered = false;

                  return mainSection.categories.map((categorySection, catIdx) => {
                    let categoryRowSpan = getTotalRowsForCategory(categorySection);
                    let categoryRowRendered = false;

                    return categorySection.makes.map((make, makeIdx) =>
                      make.details.map((detailItem, detailIdx) => {
                        const isFirstRowOfMake = detailIdx === 0;
                        const isFirstRowOfCategory = !categoryRowRendered;
                        const isFirstRowOfMain = !mainRowRendered;
                        
                        if (isFirstRowOfCategory) categoryRowRendered = true;
                        if (isFirstRowOfMain) mainRowRendered = true;

                        return (
                          <tr
                            key={`${mainIdx}-${catIdx}-${makeIdx}-${detailIdx}`}
                            className="hover:bg-lightBlue/50 text-xs"
                          >
                            {isFirstRowOfMain && (
                              <td
                                rowSpan={mainRowSpan}
                                className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-SteelBlue underline cursor-pointer text-left align-middle hover:text-darkblue1 transition"
                                onClick={handleMainCategoryClick}
                              >
<div className="relative">
  <p
    className="truncate max-w-[50rem]"
    onMouseEnter={() => {
      if ((mainSection.mainCategory ?? "").length > 50)
        setHoveredCell(mainSection.id + "-main");
    }}
    onMouseLeave={() => setHoveredCell(null)}
  >
    {mainSection.mainCategory}
  </p>

  {hoveredCell === mainSection.id + "-main" && (
      <span className="absolute left-1/2 top-full bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
      {mainSection.mainCategory}
    </span>
  )}
</div>
                              </td>
                            )}

                           {isFirstRowOfCategory && (
 <td
  rowSpan={categoryRowSpan}
  className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-left align-middle"
>
  <div className="relative w-full">
    <p
      className="truncate w-full max-w-[200px] block cursor-pointer"
      onMouseEnter={() => {
        if (categorySection.category && categorySection.category.length > 30) {
          setHoveredCell(`${mainIdx}-${catIdx}-category`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {categorySection.category}
    </p>

    {hoveredCell === `${mainIdx}-${catIdx}-category` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
        {categorySection.category}
      </span>
    )}
  </div>
</td>
)}

{isFirstRowOfMake && (
  <td
    rowSpan={make.details.length}
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-left align-middle"
  >
    <div className="relative">
      <p
        className="truncate max-w-[50rem] cursor-pointer"
        onMouseEnter={() => {
          if ((make.name ?? "").length > 50)
            setHoveredCell(make.id + "-make");
        }}
        onMouseLeave={() => setHoveredCell(null)}
      >
        {make.name}
      </p>

      {hoveredCell === make.id + "-make" && (
      <span className="absolute left-1/2 top-full bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
          {make.name}
        </span>
      )}
    </div>
  </td>
)}

                  <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-left">
  <div className="relative w-full">
    <p
      className="truncate max-w-[40rem] block cursor-pointer"
      onMouseEnter={() => {
        if (detailItem.detail && detailItem.detail.length > 30) {
          setHoveredCell(
            `${mainIdx}-${catIdx}-${makeIdx}-${detailIdx}-detail`
          );
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {detailItem.detail}
    </p>

    {hoveredCell ===
      `${mainIdx}-${catIdx}-${makeIdx}-${detailIdx}-detail` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
        {detailItem.detail}
      </span>
    )}
  </div>
</td>
                            
                            <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center">
                              {detailItem.target}
                            </td>
                            
                            <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center">
                              {detailItem.total}
                            </td>
                            
                            <td className="border border-grey2 border-t-0 border-r-0 px-3 py-1 text-center">
                              {detailItem.measurement}
                            </td>
                          </tr>
                        );
                      })
                    );
                  });
                })
              ) : (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-gray-500 italic">
                    {searchTerm ? "No matching uptime parts found." : "No uptime parts data available."}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

</div>
        {/* Mobile Card Layout */}
        <div className="lg:hidden space-y-4 p-4">
          {filteredData.length > 0 ? (
            filteredData.map((mainSection) =>
              mainSection.categories.map((categorySection) =>
                categorySection.makes.flatMap((make) =>
                  make.details.map((detailItem, idx) => (
                    <div
                      key={`${mainSection.mainCategory}-${categorySection.category}-${make.name}-${idx}`}
                      className="bg-white shadow-md p-4 border border-gray-200 hover:shadow-lg transition"
                    >
                      <div className="flex justify-between mb-2 pb-2 border-b border-gray-200">
                        <span className="font-semibold text-sm text-darkblue1">Uptime and Parts:</span>
                        <span 
                          className="text-sm text-SteelBlue underline cursor-pointer hover:text-darkblue1 font-medium"
                          onClick={handleMainCategoryClick}
                        >
                          {mainSection.mainCategory}
                        </span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-mildBlue">Category:</span>
                        <span className="text-sm">{categorySection.category}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-mildBlue">Equipment Make:</span>
                        <span className="text-sm">{make.name}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-mildBlue">Details:</span>
                        <span className="text-sm">{detailItem.detail}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-mildBlue">Target:</span>
                        <span className="text-sm font-medium">{detailItem.target}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-sm text-mildBlue">Total:</span>
                        <span className="text-sm font-medium">{detailItem.total}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-semibold text-sm text-mildBlue">Measurement:</span>
                        <span className="text-sm">{detailItem.measurement}</span>
                      </div>
                    </div>
                  ))
                )
              )
            )
          ) : (
            <div className="text-center py-8 text-gray-500 italic bg-gray-50">
              {searchTerm ? "No matching uptime parts found." : "No uptime parts data available."}
            </div>
          )}
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* UPTIME & PARTS APPROVAL PROCESS MODAL */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto rounded-lg">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b relative">
              <div className="text-center flex-1">
                <h2 className="text-lg font-bold text-gray-800">
                  Uptime & Parts Approval Process
                </h2>
                <p className="text-sm text-gray-600 mt-1">
                  Sign off on uptime & parts approvals
                </p>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="absolute top-4 right-4 text-white bg-red rounded-full p-1.5 font-medium hover:bg-red-600 transition"
              >
                <X size={16} />
              </button>
            </div>

            {/* PDP Sign-off Status Header */}
            <div className="bg-gray-700 px-6 py-3 flex items-center justify-between">
              <h3 className="text-white text-sm font-medium">PDP Sign-off Status</h3>
              <div className="flex items-center gap-3">
                <span className="bg-gray-600 text-white text-xs px-3 py-1 rounded">
                  {isAdmin ? "Admin View" : "User View"}
                </span>
                <span className="text-white text-xs">
                  {completionStats.signed}/{completionStats.total} Complete ({completionStats.percentage}%)
                </span>
              </div>
            </div>

            {/* Signoff Cards */}
            <div className="p-6">
              {isLoadingSignoffs ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
                  <span className="ml-3 text-gray-600">Loading signoff status...</span>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {visibleCategories.map((categoryKey) => {
                    const config = CATEGORY_CONFIG[categoryKey];
                    const status = getSignoffStatus(categoryKey);
                    const canSign = canUserSign(categoryKey);

                    return (
                      <div
                        key={categoryKey}
                        className={`border-2 rounded-lg p-5 relative ${
                          status.isSigned 
                            ? 'border-green-300 bg-green-50' 
                            : canSign
                            ? 'border-blue-300 bg-white'
                            : 'border-gray-300 bg-gray-50'
                        }`}
                      >
                        {/* Status Badge */}
                        <div className="absolute -top-2 -right-2">
                          {status.isSigned ? (
                            <span className="bg-green-500 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-md">
                              <CheckCircle size={12} />
                              Completed
                            </span>
                          ) : canSign ? (
                            <span className="bg-orange-500 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-md">
                              <Clock size={12} />
                              Action Required
                            </span>
                          ) : (
                            <span className="bg-gray-500 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-md">
                              <Lock size={12} />
                              Not Authorized
                            </span>
                          )}
                        </div>

                        {/* Card Content */}
                        <div className="flex items-start gap-4 mt-2">
                          {/* User Icon */}
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                            status.isSigned 
                              ? 'bg-green-200' 
                              : canSign
                              ? 'bg-gray-200'
                              : 'bg-gray-200 opacity-60'
                          }`}>
                            <User size={24} className={
                              status.isSigned 
                                ? 'text-green-700' 
                                : canSign
                                ? 'text-gray-600'
                                : 'text-gray-400'
                            } />
                          </div>

                          {/* Details */}
                          <div className="flex-1 min-w-0">
                            {/* Full Category Name - No Truncation */}
                            <h4 className="text-base font-semibold text-gray-800 leading-tight">
                              {config.displayName}
                            </h4>
                            
                            {/* Signed By Info */}
                            <p className="text-sm text-gray-600 mt-1">
                              {status.isSigned ? (
                                <>
                                  <span className="font-medium">{status.signedBy}</span>
                                  {status.designation && (
                                    <span className="text-gray-500"> • {status.designation}</span>
                                  )}
                                </>
                              ) : (
                                <span className="text-gray-500">Not Assigned</span>
                              )}
                            </p>

                            {/* Category Key (small text) */}
                            <p className="text-xs text-gray-400 mt-1">
                              {categoryKey.replace('_', ' ')}
                            </p>

                            {/* Sign Off Button - Only show if user can sign AND not already signed */}
                            {!status.isSigned && canSign && (
                              <button
                                onClick={() => handleSignOff(categoryKey)}
                                disabled={isSigningOff === categoryKey}
                                className="mt-4 bg-darkblue1 text-white text-sm font-medium px-6 py-2 rounded hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                              >
                                {isSigningOff === categoryKey ? (
                                  <>
                                    <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                                    </svg>
                                    Signing...
                                  </>
                                ) : (
                                  "Sign Off Now"
                                )}
                              </button>
                            )}

                            {/* Not Authorized Message */}
                            {!status.isSigned && !canSign && (
                              <p className="text-xs text-gray-500 mt-4 italic">
                                You are not authorized to sign off this category.
                              </p>
                            )}

                            {/* Signed timestamp */}
                            {status.isSigned && status.signedAt && (
                              <p className="text-xs text-green-600 mt-2">
                                Signed on: {new Date(status.signedAt).toLocaleDateString('en-US', {
                                  year: 'numeric',
                                  month: 'short',
                                  day: 'numeric',
                                  hour: 'numeric',
                                  minute: '2-digit'
                                })}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}