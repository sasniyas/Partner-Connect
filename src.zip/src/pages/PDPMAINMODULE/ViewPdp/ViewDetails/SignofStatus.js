import React, { useState, useEffect } from "react";
import { CheckCircle, User, Clock, AlertCircle, Calendar, Lock } from "lucide-react";
import { formatedTime } from "../../../../util/timeFormat";
import Signoffpopup from "../../../../Components/Signoffpopup";
import { 
  getPdpSignoffsByPdpId, 
  updatePdpSignoff,
  getCategoryDisplayName 
} from "../../../../services/PDP/Signoff/signoff.service";

// ═══════════════════════════════════════════════════════════════
// ROLE-BASED VISIBILITY CONFIGURATION
// ═══════════════════════════════════════════════════════════════

// Which roles can see/sign "Dealer Sales Head" (Sales_Head) category
const DEALER_SALES_HEAD_ROLES = [
  "Dealer Sales Head",
  "Dealer CEO",
  "Dealer Principal"
];

// Which roles can see/sign "Volvo CE Retail Sales Manager" (Business_Head) category
const VOLVO_RETAIL_SALES_MANAGER_ROLES = [
  "Market Area Head",
  "Retail Sales Manager",
  "Administrator",
  "Head Of Channel Developement (Region India)"
];

// Which roles can see/sign "Dealer Principal / CEO" (CEO) category
const DEALER_CEO_ROLES = [
  "Dealer Principal",
  "Dealer CEO"
];

// Which roles can see/sign "Head Of Channel Development Region India" (Regional_Head) category
const REGIONAL_HEAD_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)"
];

// Admin roles (for general admin checks)
const ADMIN_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)"
];

// Uptime roles
const DEALER_UPTIME_ROLES = [
  "Dealer CST Head",
  "Dealer CEO",
  "Dealer Principal"
];

const VOLVO_UPTIME_ROLES = [
  "Uptime & Parts Manager",
  "Administrator",
  "Head Of Channel Developement (Region India)"
];

const SignoffStatus = ({ 
  userRole, 
  rowData: parentRowData,
  categories = ['Sales_Head', 'CEO', 'Business_Head', 'Regional_Head'],
  categoryLabels = {} // Optional custom labels
}) => {
  const effectiveRole = userRole;

  // ═══════════════════════════════════════════════════════════════
  // CHECK IF MEETING HAS BEEN SCHEDULED
  // ═══════════════════════════════════════════════════════════════
  const signoffMeetingDate = parentRowData?.signoffMeetingDate || parentRowData?.sign_off_meeting_date;
  const isMeetingScheduled = !!signoffMeetingDate;
  
  // Check if PDP is approved (signoffs only allowed after approval)
  const pdpStatus = parentRowData?.signOffStatus || parentRowData?.sign_of_status;
  const isPdpApproved = pdpStatus === "Approved" || pdpStatus === "Completed";

  // Check if user is admin
  const isAdmin = ADMIN_ROLES.some(
    role => role.toLowerCase() === effectiveRole?.toLowerCase()
  );

  // ═══════════════════════════════════════════════════════════════
  // ROLE-BASED CATEGORY VISIBILITY CHECKS
  // ═══════════════════════════════════════════════════════════════
  const canSeeDealerSalesHead = DEALER_SALES_HEAD_ROLES.some(
    role => role.toLowerCase() === effectiveRole?.toLowerCase()
  );

  const canSeeVolvoRetailSalesManager = VOLVO_RETAIL_SALES_MANAGER_ROLES.some(
    role => role.toLowerCase() === effectiveRole?.toLowerCase()
  );

  const canSeeDealerCEO = DEALER_CEO_ROLES.some(
    role => role.toLowerCase() === effectiveRole?.toLowerCase()
  );

  const canSeeRegionalHead = REGIONAL_HEAD_ROLES.some(
    role => role.toLowerCase() === effectiveRole?.toLowerCase()
  );

  const canSeeDealerUptime = DEALER_UPTIME_ROLES.some(
    role => role.toLowerCase() === effectiveRole?.toLowerCase()
  );

  const canSeeVolvoUptime = VOLVO_UPTIME_ROLES.some(
    role => role.toLowerCase() === effectiveRole?.toLowerCase()
  );

  // ⭐ UPDATED: Always return all categories (for display purposes)
  // Role-based permissions are checked separately with canUserSign()
  const getVisibleCategories = () => {
    return categories;
  };

  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [selectedSignoffIndex, setSelectedSignoffIndex] = useState(null);
  const [signoffData, setSignoffData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(true);
  const [notification, setNotification] = useState({ show: false, message: "", type: "" });
  const [error, setError] = useState(null);

  const showNotification = (message, type = "success") => {
    setNotification({ show: true, message, type });
    setTimeout(() => {
      setNotification({ show: false, message: "", type: "" });
    }, 3000);
  };

  useEffect(() => {
    console.log("📊 SignoffStatus Component Mounted");
    console.log("  parentRowData:", parentRowData);
    console.log("  parentRowData.id:", parentRowData?.id);
    console.log("  categories:", categories);
    console.log("  userRole:", userRole);
    console.log("  effectiveRole:", effectiveRole);
    console.log("  isAdmin:", isAdmin);
    console.log("  pdpStatus:", pdpStatus);
    console.log("  isPdpApproved:", isPdpApproved);
    console.log("  isMeetingScheduled:", isMeetingScheduled);
    console.log("  visibleCategories:", getVisibleCategories());
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // FETCH SIGNOFF DATA
  // ═══════════════════════════════════════════════════════════════
  const fetchSignoffData = async () => {
    if (!parentRowData) {
      console.error("❌ parentRowData is null or undefined");
      setError("Missing PDP data. Please refresh the page.");
      setIsFetching(false);
      return;
    }

    if (!parentRowData.id) {
      console.error("❌ PDP ID is missing from rowData");
      console.log("📦 Available keys in parentRowData:", Object.keys(parentRowData));
      setError("Missing PDP ID. Please contact support.");
      setIsFetching(false);
      return;
    }

    try {
      setIsFetching(true);
      setError(null);
      
      console.log("🔍 Fetching signoffs for PDP ID:", parentRowData.id);
      console.log("🔍 Filter categories:", categories);
      
      const data = await getPdpSignoffsByPdpId(parentRowData.id);
      console.log("📦 Fetched ALL signoff data:", data);

      // Get all categories (not filtering by role visibility)
      const visibleCategories = getVisibleCategories();
      console.log("👁️ All categories to display:", visibleCategories);

      // Filter by requested categories (not by role)
      const filteredData = data.filter(item => visibleCategories.includes(item.category));

      console.log("📦 After category filtering - Count:", filteredData.length);

      // Sort by category order
      const categoryOrder = {
        'Sales_Head': 1,
        'CEO': 2,
        'Business_Head': 3,
        'Regional_Head': 4,
        'Equipments_Volvo': 1,
        'Equipments_Dealer': 2,
        'Equipment_Volvo': 1,
        'Equipment_Dealer': 2,
        'Uptime_Volvo': 1,
        'Uptime_Dealer': 2,
      };

      const sortedData = filteredData.sort((a, b) => {
        const orderA = categoryOrder[a.category] || 999;
        const orderB = categoryOrder[b.category] || 999;
        return orderA - orderB;
      });

      const transformedData = sortedData.map(item => ({
        id: item.id,
        role: getCategoryDisplayName(item.category),
        name: `${item.user_first_name || ''} ${item.user_last_name || ''}`.trim() || "Not Assigned",
        signed: item.isSigned === 1 || item.isSigned === true,
        signedAt: item.signed_timestamp,
        designation: item.user_persona || item.category,
        editable: item.isSigned !== 1 && item.isSigned !== true,
        category: item.category,
        userId: item.userId,
      }));

      console.log("✅ Transformed signoff data (all categories):", transformedData);
      setSignoffData(transformedData);
      setError(null);
      
    } catch (error) {
      console.error("❌ Failed to fetch signoff data:", error);
      setError(error.message || "Failed to load signoffs");
      showNotification(`Error loading signoffs: ${error.message}`, "error");
    } finally {
      setIsFetching(false);
    }
  };

  useEffect(() => {
    if (parentRowData?.id) {
      fetchSignoffData();
    } else {
      console.warn("⚠️ Skipping fetch: parentRowData.id is missing");
      setIsFetching(false);
      setError("No PDP ID provided");
    }
  }, [parentRowData?.id, effectiveRole]); // Re-fetch when role changes

  const stats = {
    total: signoffData.length,
    signed: signoffData.filter(item => item.signed).length,
    pending: signoffData.filter(item => !item.signed).length,
    percentage: signoffData.length > 0 
      ? Math.round((signoffData.filter(item => item.signed).length / signoffData.length) * 100)
      : 0
  };

  // ⭐ UPDATED: Check if user can sign a specific category
  const canUserSign = (category) => {
    switch (category) {
      case 'Sales_Head':
        return canSeeDealerSalesHead;
      case 'Business_Head':
        return canSeeVolvoRetailSalesManager;
      case 'CEO':
        return canSeeDealerCEO;
      case 'Regional_Head':
        return canSeeRegionalHead;
      case 'Equipments_Volvo':
      case 'Equipment_Volvo':
        return canSeeVolvoRetailSalesManager;
      case 'Equipments_Dealer':
      case 'Equipment_Dealer':
        return canSeeDealerSalesHead;
      case 'Uptime_Volvo':
        return canSeeVolvoUptime;
      case 'Uptime_Dealer':
        return canSeeDealerUptime;
      default:
        return false;
    }
  };

  const handleSignOff = (index) => {
    const item = signoffData[index];
    
    // Check if user can sign this category
    if (!canUserSign(item.category)) {
      showNotification("You don't have permission to sign off on this category.", "error");
      return;
    }

    if (item.signed) {
      showNotification("This item is already signed off.", "error");
      return;
    }

    setSelectedSignoffIndex(index);
    setIsPopupOpen(true);
  };

  const confirmSignOff = async () => {
    if (selectedSignoffIndex === null) return;

    const item = signoffData[selectedSignoffIndex];
    
    if (!item.id) {
      showNotification("Error: Signoff record ID is missing.", "error");
      setIsPopupOpen(false);
      return;
    }

    try {
      setIsLoading(true);
      console.log("✍️ Signing off:", item);

      await updatePdpSignoff(item.id, true);
      
      console.log("✅ Sign-off successful");
      showNotification(`Successfully signed off: ${item.role}`, "success");

      await fetchSignoffData();
      
    } catch (error) {
      console.error("❌ Sign-off failed:", error);
      showNotification(`Sign-off failed: ${error.message}`, "error");
    } finally {
      setIsLoading(false);
      setIsPopupOpen(false);
      setSelectedSignoffIndex(null);
    }
  };

  // ⭐ UPDATED: Enhanced action rendering with authorization checks
  const renderSignoffAction = (row, idx) => {
    if (row.signed) {
      return (
        <div className="flex flex-col items-end gap-1 min-w-[140px]">
          <div className="flex items-center text-green font-medium text-xs whitespace-nowrap">
            <CheckCircle size={16} className="mr-1 flex-shrink-0" />
            Signed Off
          </div>
          <div className="text-xs text-gray-600 flex items-center whitespace-nowrap">
            <Clock size={12} className="mr-1 flex-shrink-0" />
            {row.signedAt ? formatedTime(row.signedAt) : "N/A"}
          </div>
        </div>
      );
    }

    // Check if current user can sign this category
    const canSign = canUserSign(row.category);

    if (canSign) {
      return (
        <div className="flex flex-col items-end gap-1 min-w-[140px] h-full justify-center">
          <button
            onClick={() => handleSignOff(idx)}
            disabled={isLoading}
            className="px-3 py-1.5 text-xs font-semibold bg-darkblue1 text-white hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
          >
            {isLoading && selectedSignoffIndex === idx ? "Processing..." : "Sign Off Now"}
          </button>
        </div>
      );
    }

    // User is not authorized to sign this category
    return (
      <div className="flex flex-col items-end gap-1 min-w-[140px]">
        <div className="flex items-center text-gray-500 font-medium text-xs whitespace-nowrap">
          <Lock size={16} className="mr-1 flex-shrink-0" />
          Not Authorized
        </div>
        <div className="text-xs text-gray-400 whitespace-nowrap">No permission</div>
      </div>
    );
  };

  // ═══════════════════════════════════════════════════════════════
  // LOADING STATE
  // ═══════════════════════════════════════════════════════════════
  if (isFetching) {
    return (
      <div className="w-full border border-Dustyblue shadow-sm overflow-hidden">
        <div className="bg-Dustyblue text-white py-1.5 px-4">
          <h2 className="font-semibold text-sm">PDP Sign-off Status</h2>
        </div>
        <div className="flex items-center justify-center py-10">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
          <span className="ml-3 text-sm text-gray-600">Loading signoffs...</span>
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // LOCKED STATE - MEETING NOT SCHEDULED OR PDP NOT APPROVED
  // ═══════════════════════════════════════════════════════════════
  if (!isMeetingScheduled || !isPdpApproved) {
    return (
      <div className="w-full border border-mildBlue shadow-sm overflow-hidden bg-mildBlue/10">
        <div className="bg-mildBlue/50 text-white py-1.5 px-4">
          <h2 className="font-semibold text-sm">PDP Sign-off Status</h2>
        </div>
        <div className="flex flex-col items-center justify-center py-10 px-4">
          <div className="w-16 h-16 bg-mildBlue/10 rounded-full flex items-center justify-center mb-4">
            <Lock className="w-8 h-8 text-mildBlue/70" />
          </div>
          <p className="text-mildBlue/70 font-semibold text-lg mb-2">🔒 Approval Locked</p>
          <p className="text-mildBlue/70 text-sm text-center max-w-md">
            {!isPdpApproved 
              ? "PDP must be approved before signoffs can begin."
              : "Signoff meeting has not been scheduled yet."
            }
          </p>
          <div className="mt-4 p-3 bg-white border border-mildBlue rounded text-xs text-center flex items-center gap-2">
            <Calendar size={14} className="text-mildBlue/70" />
            <p className="text-gray-600">
              {!isPdpApproved 
                ? `Current status: ${pdpStatus || "Unknown"}`
                : "Waiting for admin to schedule signoff meeting..."
              }
            </p>
          </div>
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // ERROR STATE
  // ═══════════════════════════════════════════════════════════════
  if (error) {
    return (
      <div className="w-full border border-red-300 shadow-sm overflow-hidden bg-red-50">
        <div className="bg-red-600 text-white py-1.5 px-4">
          <h2 className="font-semibold text-sm">Error Loading Sign-offs</h2>
        </div>
        <div className="flex flex-col items-center justify-center py-10 px-4">
          <AlertCircle size={48} className="text-red-500 mb-4" />
          <p className="text-red-700 font-medium mb-2">Unable to load signoff data</p>
          <p className="text-red-600 text-sm mb-4 text-center">{error}</p>
          <button
            onClick={() => {
              setError(null);
              fetchSignoffData();
            }}
            className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition"
          >
            Try Again
          </button>
          <div className="mt-4 p-3 bg-white border border-red-200 rounded text-xs text-left w-full max-w-md">
            <p className="font-semibold mb-2">Debug Info:</p>
            <p>PDP ID: {parentRowData?.id || "Missing"}</p>
            <p>Categories: {categories.length > 0 ? categories.join(", ") : "All"}</p>
            <p>Display: {getVisibleCategories().join(", ") || "None"}</p>
            <p>Role: {effectiveRole}</p>
          </div>
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // EMPTY STATE
  // ═══════════════════════════════════════════════════════════════
  if (signoffData.length === 0) {
    return (
      <div className="w-full border border-Dustyblue shadow-sm overflow-hidden">
        <div className="bg-Dustyblue text-white py-1.5 px-4">
          <h2 className="font-semibold text-sm">PDP Sign-off Status</h2>
        </div>
        <div className="flex flex-col items-center justify-center py-10">
          <AlertCircle size={48} className="text-gray-400 mb-2" />
          <p className="text-gray-500 italic">No signoff records available for this PDP.</p>
          <p className="text-xs text-gray-400 mt-1">Role: {effectiveRole}</p>
          <p className="text-xs text-gray-400 mt-1">PDP ID: {parentRowData?.id || "Not found"}</p>
        </div>
      </div>
    );
  }

  // Format meeting date for display
  const formatMeetingDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // MAIN RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="w-full border border-Dustyblue shadow-sm overflow-hidden relative">
      {/* Notification Toast */}
      {notification.show && (
        <div className={`fixed top-4 right-4 z-[9999] px-6 py-3 rounded-lg shadow-lg transform transition-all duration-300 ${
          notification.type === "success" 
            ? "bg-green-500 text-white" 
            : "bg-red-500 text-white"
        }`}>
          <div className="flex items-center gap-2">
            {notification.type === "success" ? (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
            ) : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            )}
            <span className="font-medium">{notification.message}</span>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="bg-Dustyblue text-white py-1.5 px-4">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-sm">PDP Sign-off Status</h2>
          <div className="flex items-center gap-3">
            <span className="text-xs bg-white/20 px-2 py-1">
              {effectiveRole || "User View"}
            </span>
            <span className="text-xs font-medium">
              {stats.signed}/{stats.total} Complete ({stats.percentage}%)
            </span>
          </div>
        </div>
      </div>

      {/* Meeting Scheduled Success Banner */}
      {isMeetingScheduled && (
        <div className="bg-green-50 border-b border-green-200 px-4 py-2">
          <div className="flex items-center gap-2 text-green-800">
            <Calendar size={16} />
            <span className="text-sm">
              <span className="font-medium">Signoff Meeting Scheduled: </span>
              {formatMeetingDate(signoffMeetingDate)}
            </span>
          </div>
        </div>
      )}

      {/* Signoff Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4">
        {signoffData.map((row, idx) => {
          const isAuthorized = canUserSign(row.category);
          
          return (
            <div
              key={`${row.category}-${idx}`}
              className={`relative flex items-center justify-between border p-3 shadow-sm w-full h-[110px] mx-auto transition-colors duration-200 ${
                row.signed 
                  ? "border-green/30 bg-green/5" 
                  : isAuthorized
                  ? "border-black/30 bg-grayishblue hover:shadow-md"
                  : "border-gray-300 bg-gray-50"
              }`}
            >
              {/* User Icon */}
              <div className={`hidden md:flex items-center justify-center w-10 h-10 rounded-full shadow-md mr-4 flex-shrink-0 ${
                row.signed 
                  ? "bg-green/10" 
                  : isAuthorized
                  ? "bg-white"
                  : "bg-gray-200 opacity-60"
              }`}>
                <User 
                  size={20} 
                  className={
                    row.signed 
                      ? "text-green fill-green" 
                      : isAuthorized
                      ? "text-black fill-black"
                      : "text-gray-400 fill-gray-400"
                  } 
                />
              </div>

              {/* Role & User Info */}
              <div className="flex-1 min-w-0 mr-2">
                <div className="text-black text-sm font-bold leading-tight">
                  {row.role}
                </div>
                <div className="text-black text-sm font-semibold truncate">
                  {row.name}
                </div>
                {row.designation && (
                  <div className="text-xs text-gray-600 mt-0.5 truncate">
                    {row.designation}
                  </div>
                )}
              </div>

              {/* Action Button / Status */}
              <div className="flex items-center justify-end flex-shrink-0">
                {renderSignoffAction(row, idx)}
              </div>

              {/* Action Required Badge */}
              {isAuthorized && !row.signed && (
                <div className="absolute -top-2 -right-2">
                  <span className="text-[10px] bg-darkblue1 text-white px-2 py-1 rounded-full inline-block whitespace-nowrap shadow-md">
                    Action Required
                  </span>
                </div>
              )}

              {/* Not Authorized Badge */}
              {!isAuthorized && !row.signed && (
                <div className="absolute -top-2 -right-2">
                  <span className="text-[10px] bg-gray-500 text-white px-2 py-1 rounded-full inline-block whitespace-nowrap shadow-md">
                    Not Authorized
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* All Complete Banner */}
      {stats.pending === 0 && stats.total > 0 && (
        <div className="bg-green/10 border-t border-green/30 px-4 py-3">
          <div className="flex items-center justify-center text-green font-medium text-xs">
            <CheckCircle size={16} className="mr-2" />
            All sign-offs completed successfully!
          </div>
        </div>
      )}

      {/* Signoff Confirmation Popup */}
      <Signoffpopup
        isOpen={isPopupOpen}
        onClose={() => {
          setIsPopupOpen(false);
          setSelectedSignoffIndex(null);
        }}
        onConfirm={confirmSignOff}
        loading={isLoading}
      />
    </div>
  );
};

export default SignoffStatus;