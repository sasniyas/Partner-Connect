import { Download, Plus } from "lucide-react";
import React, { useState, useEffect } from "react";
import DeleteModal from "../../../../Components/DeleteModal";
import { useRef } from "react";
import {
  getPdpUploadFilesByPdpId,
  addPdpUploadFile,
  updatePdpUploadFile,
  deletePdpUploadFile,
  getDefaultPreTemplate,
  getDefaultFinTemplate
} from "../../../../services/PDP/UploadFiles/pdpUploadFiles.service";
import { useMemo } from "react";
import { ChevronDown,ChevronsUpDown } from "lucide-react";
import { ChevronUp } from "lucide-react";
import { useKeyboardNavigation } from "../../../../util/useKeyboardNavigation";
// ──────────────────────────────────────────────
// Modal Component
// ──────────────────────────────────────────────
const Modal = ({ isOpen, onClose, onSave, initialData, mode, activeTab, isLoading }) => {
  const [fileName, setFileName] = useState(initialData?.file_name || "");
  
  const [file, setFile] = useState(null);
  const [errors, setErrors] = useState({ fileName: false, file: false });
  useEffect(() => {
    setFileName(initialData?.file_name || "");
    setFile(null);
    setErrors({ fileName: false, file: false });
  }, [initialData, isOpen]);
const popupRef = useRef(null)
useKeyboardNavigation({
  containerRef: popupRef, // your popup div ref

  onSubmit: () => { 
    handleSave()
  },

  onCancel: () => {
   resetAndClose()
  },
});
  if (!isOpen) return null;

  const validate = () => {
    const newErrors = {
      fileName: !fileName.trim(),
      file: !file && mode === "add",
    };
    setErrors(newErrors);
    return !newErrors.fileName && !newErrors.file;
  };

  const handleSave = () => {
    if (!validate()) return;
    onSave({ fileName, file });
  };

  const resetAndClose = () => {
    setFileName("");
    setFile(null);
    setErrors({ fileName: false, file: false });
    onClose();
  };

  const heading =
    mode === "edit"
      ? `Edit ${activeTab === "pdp" ? "PDP Presentation" : "Finance Reports"} Template`
      : `Add ${activeTab === "pdp" ? "PDP Presentation" : "Finance Reports"} Template`;

  const handleKeyDown = (e) => e.key === "Enter" && !isLoading && handleSave();


  return (
    <div
      className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
      onKeyDown={handleKeyDown}
      tabIndex={0}
    >
      <div 
      ref={popupRef}
      className="bg-white w-96 p-6 shadow-lg relative">
        <button onClick={resetAndClose} className="absolute top-2 right-2" disabled={isLoading}>
          <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>

        </button>

        <h3 className="text-base font-medium mb-4 text-center text-MediumGrey">{heading}</h3>

        <div className="mb-4">
          <label className="block text-xs font-medium mb-1">File Name</label>
          <input
            type="text"
            value={fileName}
            onChange={(e) => {
              setFileName(e.target.value);
              if (errors.fileName) setErrors((prev) => ({ ...prev, fileName: false }));
            }}
            placeholder="Enter File Name"
            disabled={isLoading}
            className={`w-full border text-xs px-4 py-1.5 focus:outline-none ${
              errors.fileName ? "border-red1" : "border-black/30"
            } ${isLoading ? "bg-gray-100 cursor-not-allowed" : ""}`}
          />
          {errors.fileName && (
            <p className="text-red1 text-xs mt-1">Please fill out this field</p>
          )}
        </div>

        <div className="mb-6">
          <label className="block text-xs font-medium mb-1">File</label>
          <div
            className={`relative w-full border text-xs px-4 py-1.5 ${
              isLoading ? "cursor-not-allowed bg-gray-100" : "cursor-pointer bg-white"
            } transition ${
              errors.file ? "border-red1" : "border-black/30 hover:border-darkblue1"
            }`}
            onClick={() => !isLoading && document.getElementById("fileInput").click()}
          >
            <span
              className={`${
                file
                  ? "text-black"
                  : mode === "edit" && initialData?.file_url
                  ? "text-black"
                  : "text-gray-400"
              }`}
            >
              {file
                ? file.name
                : mode === "edit" && initialData?.file_name
                ? `Current: ${initialData.file_name}`
                : "Click to select a file"}
            </span>

            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth="1.8"
              stroke="currentColor"
              className="w-5 h-5 text-darkblue1 absolute right-3 top-2.5 pointer-events-none"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 16V8m0 0l-3 3m3-3l3 3m6 5v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2"
              />
            </svg>
          </div>

          <input
            id="fileInput"
            type="file"
            onChange={(e) => {
              setFile(e.target.files[0]);
              if (errors.file) setErrors((prev) => ({ ...prev, file: false }));
            }}
            disabled={isLoading}
            className="hidden"
          />

          {errors.file && (
            <p className="text-red1 text-xs mt-1">Please select a file</p>
          )}
        </div>

        <div className="text-center">
          <button
          type="button"
            onClick={handleSave}
            disabled={isLoading}
            className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 transition hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? "Processing..." : mode === "edit" ? "Update" : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
};

// ──────────────────────────────────────────────
// Main Component
// ──────────────────────────────────────────────
export default function UploadFiles({ pdpId, userRole }) {
  const [activeTab, setActiveTab] = useState("pdp");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [deleteItem, setDeleteItem] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(true);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [downloadLoading, setDownloadLoading] = useState(false);
    const [hoveredCell,setHoveredCell] = useState (null)
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"
  const [filesData, setFilesData] = useState({ pdp: [], finance: [] });
  const [notification, setNotification] = useState({ show: false, message: "", type: "" });
  const [error, setError] = useState(null);

  useEffect(() => {
    console.log("📊 UploadFiles Component Mounted");
    console.log("  pdpId:", pdpId);
    console.log("  pdpId type:", typeof pdpId);
    console.log("  userRole:", userRole);
  }, [pdpId, userRole]);

  const showNotification = (message, type = "success") => {
    setNotification({ show: true, message, type });
    setTimeout(() => {
      setNotification({ show: false, message: "", type: "" });
    }, 3000);
  };

  useEffect(() => {
    if (pdpId) {
      fetchFiles();
    } else {
      console.warn("⚠️ UploadFiles: pdpId is missing!");
      setError("PDP ID is required to load files.");
      setIsFetching(false);
    }
  }, [pdpId]);

  const fetchFiles = async () => {
    if (!pdpId) {
      console.error("❌ PDP ID is missing");
      showNotification("PDP ID is missing", "error");
      setError("PDP ID is required");
      setIsFetching(false);
      return;
    }

    try {
      setIsFetching(true);
      setError(null);
      console.log("🔍 Fetching files for PDP ID:", pdpId);

      const data = await getPdpUploadFilesByPdpId(pdpId);
      console.log("📦 Fetched files:", data);

      const pdpFiles = data.filter(f => f.category === "Presentation");
      const financeFiles = data.filter(f => f.category === "Finance");

      setFilesData({
        pdp: pdpFiles,
        finance: financeFiles
      });

      console.log("✅ Files loaded - PDP:", pdpFiles.length, "Finance:", financeFiles.length);
    } catch (error) {
      console.error("❌ Error fetching files:", error);
      setError(error.message || "Failed to load files");
      showNotification(error.message || "Failed to load files", "error");
    } finally {
      setIsFetching(false);
    }
  };

  const handleSaveFile = async (formData) => {
    if (!pdpId) {
      showNotification("PDP ID is missing", "error");
      return;
    }

    try {
      setIsLoading(true);
      console.log("💾 Saving file:", formData);
      console.log("💾 Active tab:", activeTab);

      const apiFormData = new FormData();
      apiFormData.append("pdpId", pdpId);
      
      // ⭐ CRITICAL FIX: Match your database category values exactly
      // Try these in order if one doesn't work:
      // Option 1: "Presentation" / "Finance"
      // Option 2: "PDP Presentation" / "Finance Reports"  
      // Option 3: "pdp" / "finance"
      console.log("activeTab",activeTab)
      
      const categoryValue = activeTab === "pdp" ? "Presentation" : "Finance";
      
      console.log("📋 Category being sent:", categoryValue);
      apiFormData.append("category", categoryValue);
      
      apiFormData.append("file_name", formData.fileName);
      
      if (formData.file) {
        apiFormData.append("file", formData.file);
        console.log("📎 File attached:", formData.file.name);
      }

      const userStr = localStorage.getItem("user");
      if (userStr) {
        try {
          const user = JSON.parse(userStr);
          if (user.id) {
            apiFormData.append("uploaded_by", user.id);
            console.log("👤 Uploaded by user ID:", user.id);
          }
        } catch (e) {
          console.warn("Could not parse user data");
        }
      }

      // ⭐ Debug: Log all FormData entries
      console.log("📤 FormData being sent:");
      for (let [key, value] of apiFormData.entries()) {
        console.log(`  ${key}:`, value);
      }

      if (editingItem) {
        apiFormData.append("id", editingItem.id);
        console.log("✏️ Updating file ID:", editingItem.id);
        await updatePdpUploadFile(apiFormData);
        showNotification("File updated successfully!", "success");
      } else {
        console.log("➕ Adding new file");
        await addPdpUploadFile(apiFormData);
        showNotification("File added successfully!", "success");
      }

      await fetchFiles();
      setModalOpen(false);
      setEditingItem(null);
    } catch (error) {
      console.error("❌ Error saving file:", error);
      console.error("❌ Error details:", error.response?.data);
      
      // ⭐ Better error message
      let errorMessage = "Failed to save file";
      if (error.message.includes("category")) {
        errorMessage = "Category validation error. Please check backend category values.";
      } else if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      showNotification(errorMessage, "error");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteClick = (item) => {
    setDeleteItem(item);
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!deleteItem) return;

    try {
      setDeleteLoading(true);
      console.log("🗑️ Deleting file:", deleteItem);

      await deletePdpUploadFile(deleteItem.id);
      showNotification("File deleted successfully!", "success");

      await fetchFiles();
      setIsDeleteModalOpen(false);
      setDeleteItem(null);
    } catch (error) {
      console.error("❌ Error deleting file:", error);
      showNotification(error.message || "Failed to delete file", "error");
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setModalOpen(true);
  };

  const handleDownloadTemplate = async () => {
    try {
      setDownloadLoading(true);
      console.log("📥 Downloading template for:", activeTab);

      if (activeTab === "pdp") {
        await getDefaultPreTemplate();
        showNotification("Presentation template downloaded!", "success");
      } else {
        await getDefaultFinTemplate();
        showNotification("Finance template downloaded!", "success");
      }
    } catch (error) {
      console.error("❌ Error downloading template:", error);
      showNotification(error.message || "Failed to download template", "error");
    } finally {
      setDownloadLoading(false);
    }
  };

  const handleFileDownload = (fileUrl, fileName) => {
    if (!fileUrl) {
      showNotification("File URL not available", "error");
      return;
    }

    try {
      const link = document.createElement('a');
      link.href = fileUrl;
      link.target = '_blank';
      link.download = fileName || 'file';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      showNotification("File download started!", "success");
    } catch (error) {
      console.error("❌ Error downloading file:", error);
      showNotification("Failed to download file", "error");
    }
  };

  const currentFiles = filesData[activeTab];
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return currentFiles;

  return [...currentFiles].sort((a, b) => {
    const valA = (a[sortKey] || "").toString().toLowerCase();
    const valB = (b[sortKey] || "").toString().toLowerCase();

    return sortOrder === "asc"
      ? valA.localeCompare(valB)
      : valB.localeCompare(valA);
  });
}, [currentFiles, sortKey, sortOrder]);

  if (error && !pdpId) {
    return (
      <div className="w-full border-2 border-red-300 bg-red-50 p-8 text-center">
        <div className="text-red-600 mb-4">
          <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="text-lg font-semibold mb-2">PDP ID Required</h3>
          <p className="text-sm">{error}</p>
          <p className="text-xs mt-2 text-gray-600">Please make sure pdpId prop is passed to UploadFiles component.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full">
      {notification.show && (
        <div className={`fixed top-4 right-4 z-[9999] px-6 py-3 rounded-lg shadow-lg transform transition-all duration-300 ${
          notification.type === "success" 
            ? "bg-green-500 text-white" 
            : "bg-red-500 text-white"
        }`}>
          <div className="flex items-center gap-2">
            {notification.type === "success" ? (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
            ) : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            )}
            <span className="font-medium">{notification.message}</span>
          </div>
        </div>
      )}

      <div className="flex w-full mb-4 overflow-hidden">
        <button
          onClick={() => setActiveTab("pdp")}
          className={`flex-1 py-1.5 text-sm font-medium transition ${
            activeTab === "pdp"
              ? "bg-darkblue1 text-white"
              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
          }`}
        >
          PDP Presentation
        </button>
        <button
          onClick={() => setActiveTab("finance")}
          className={`flex-1 py-1.5 text-sm font-medium transition ${
            activeTab === "finance"
              ? "bg-darkblue1 text-white"
              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
          }`}
        >
          Finance Reports
        </button>
      </div>

      <div className="flex justify-end gap-2 mb-2">
        <button
          onClick={handleDownloadTemplate}
          disabled={downloadLoading}
          className="bg-darkblue1 text-xs font-medium text-white px-6 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Download size={14} />
          {downloadLoading ? "Downloading..." : `Download ${activeTab === "pdp" ? "PDP" : "Finance"} Template`}
        </button>
        <button
          onClick={() => {
            setEditingItem(null);
            setModalOpen(true);
          }}
          disabled={isFetching}
          className="bg-darkblue1 text-xs font-medium text-white px-6 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Plus size={14} />
          Add New
        </button>
      </div>

      {isFetching && (
        <div className="flex items-center justify-center py-10 border border-Dustyblue">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
          <span className="ml-3 text-sm text-gray-600">Loading files...</span>
        </div>
      )}

      {error && pdpId && !isFetching && (
        <div className="border-2 border-red-300 bg-red-50 p-6 text-center">
          <p className="text-red-600 mb-2">{error}</p>
          <button
            onClick={() => {
              setError(null);
              fetchFiles();
            }}
            className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition"
          >
            Try Again
          </button>
        </div>
      )}

      {!isFetching && !error && (
        <div className="hidden md:block overflow-x-auto border border-Dustyblue">
          <table className="w-full text-sm border-collapse">
            <thead className="bg-Dustyblue text-white text-left">
              <tr>
<th
    className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[30%] cursor-pointer select-none"
    onClick={() => handleSort("fileName")}
  >
    <div className="flex items-center gap-1">
      File Name
      {sortKey !== "fileName" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
      {sortKey === "fileName" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "fileName" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>              
<th
    className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[30%] cursor-pointer select-none"
    onClick={() => handleSort("uploadedBy")}
  >
    <div className="flex items-center gap-1">
      Uploaded By
      {sortKey === "uploadedBy" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "uploadedBy" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>                
<th
    className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[20%] cursor-pointer select-none"
    onClick={() => handleSort("date")}
  >
    <div className="flex items-center gap-1">
      Date
      {sortKey === "date" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "date" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>               
   <th className="px-3 w-[20%] py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedData.length === 0 ? (
                <tr>
                  <td colSpan={4} className="text-center py-8 text-gray-500 italic">
                    No files uploaded
                  </td>
                </tr>
              ) : (
                sortedData.map((file) => (
                  <tr key={file.id} className="hover:bg-lightBlue/50 text-xs">
                   <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <button
      onClick={() => handleFileDownload(file.file_url, file.file_name)}
      className="text-SteelBlue hover:text-darkblue1 underline truncate max-w-[12rem] text-left"
      onMouseEnter={() => {
        if (file.file_name && file.file_name.length > 20) setHoveredCell(file.id + "-file");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {file.file_name}
    </button>

    {hoveredCell === file.id + "-file" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {file.file_name}
      </span>
    )}
  </div>
</td>

                   <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-default"
      onMouseEnter={() => {
        if (
          file.uploaded_by_firstName &&
          file.uploaded_by_lastName &&
          `${file.uploaded_by_firstName} ${file.uploaded_by_lastName}`.length > 20
        ) {
          setHoveredCell(file.id + "-uploader");
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {file.uploaded_by_firstName && file.uploaded_by_lastName
        ? `${file.uploaded_by_firstName} ${file.uploaded_by_lastName}`
        : "Unknown"}
    </p>

    {hoveredCell === file.id + "-uploader" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {file.uploaded_by_firstName} {file.uploaded_by_lastName}
      </span>
    )}
  </div>
</td>

                    <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0">
                      {file.created_at ? new Date(file.created_at).toLocaleDateString() : "-"}
                    </td>
                    <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                      <div className="flex gap-2 justify-center">
                        <button onClick={() => handleEdit(file)} className="hover:opacity-70">
                         <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

                        </button>
                        <button onClick={() => handleDeleteClick(file)} className="hover:opacity-70">
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>	
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {!isFetching && !error && (
        <div className="md:hidden space-y-4">
          {currentFiles.length === 0 ? (
            <p className="text-center text-gray-500 italic py-8">No files uploaded</p>
          ) : (
            currentFiles.map((file) => (
              <div key={file.id} className="bg-white shadow-md p-4 border border-gray-200">
                <div className="flex justify-between mb-2">
                  <span className="font-semibold text-sm text-mildBlue">File Name:</span>
                  <button
                    onClick={() => handleFileDownload(file.file_url, file.file_name)}
                    className="text-sm text-SteelBlue hover:text-darkblue1 underline break-all text-right"
                  >
                    {file.file_name}
                  </button>
                </div>

                <div className="flex justify-between mb-2">
                  <span className="font-semibold text-sm text-mildBlue">Uploaded By:</span>
                  <span className="text-sm">
                    {file.uploaded_by_firstName && file.uploaded_by_lastName
                      ? `${file.uploaded_by_firstName} ${file.uploaded_by_lastName}`
                      : "Unknown"}
                  </span>
                </div>

                <div className="flex justify-between mb-2">
                  <span className="font-semibold text-sm text-mildBlue">Date:</span>
                  <span className="text-sm">
                    {file.created_at ? new Date(file.created_at).toLocaleDateString() : "-"}
                  </span>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t">
                  <button onClick={() => handleEdit(file)} className="px-3 py-1 hover:opacity-70">
                   <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

                  </button>
                  <button onClick={() => handleDeleteClick(file)} className="px-3 py-1 hover:opacity-70">
                   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>	


                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      <Modal
        isOpen={modalOpen}
        onClose={() => {
          setModalOpen(false);
          setEditingItem(null);
        }}
        onSave={handleSaveFile}
        initialData={editingItem}
        mode={editingItem ? "edit" : "add"}
        activeTab={activeTab}
        isLoading={isLoading}
      />

      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setDeleteItem(null);
        }}
        onConfirm={handleConfirmDelete}
        loading={deleteLoading}
      />
    </div>
  );
}