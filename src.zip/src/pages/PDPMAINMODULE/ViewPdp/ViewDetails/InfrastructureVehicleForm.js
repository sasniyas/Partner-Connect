import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import StyledSelectField from "../../../../Components/StyledSelectField";
import { useKeyboardNavigation } from "../../../../util/useKeyboardNavigation";
const InfrastructureVehicleForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const location = useLocation();
  const isEditMode = Boolean(id);
  const [menuOpen, setMenuOpen] = useState(false);
  const [errors, setErrors] = useState({});

  // Get data from navigation state
  const vehicleData = location.state?.vehicleData || null;
  const vehicleType = location.state?.vehicleType || "";
  const year = location.state?.year || "";
  const facilityDefinition = location.state?.facilityDefinition || "";
  const isAdmin = location.state?.isAdmin || false;
  const rowData = location.state?.rowData || {};
  const rowIndex = location.state?.rowIndex;
  const returnPath = location.state?.returnPath || "";
  const currentVehicles = location.state?.currentVehicles || [];
  const fromRef = useRef(null)
  const [formData, setFormData] = useState({
    slNo: "",
    vehicleType: "",
    make: "",
    model: "",
    regNo: "",
    yearOfPurchase: "",
    vehicleAge: "",
    operatingArea: "",
    utilizationRate: "",
    assignedTo: ""
  });

  // Dropdown states
  const [isVehicleTypeOpen, setIsVehicleTypeOpen] = useState(false);
  const [isMakeOpen, setIsMakeOpen] = useState(false);
  const [isUtilizationOpen, setIsUtilizationOpen] = useState(false);

  // Refs for dropdowns
  const vehicleTypeRef = useRef(null);
  const makeRef = useRef(null);
  const utilizationRef = useRef(null);

  // Dropdown options
  const vehicleTypeOptions = ["Commercial", "Personal"];
  const makeOptions = ["Mahindra", "Maruti", "TATA", "Eicher", "Ashok Leyland", "BharatBenz"];
  const utilizationOptions = ["Daily", "Weekly", "Monthly"];

  // Calculate age automatically when year of purchase changes
  useEffect(() => {
    if (formData.yearOfPurchase) {
      const currentYear = new Date().getFullYear();
      const purchaseYear = parseInt(formData.yearOfPurchase);
      
      if (purchaseYear > 0 && purchaseYear <= currentYear) {
        const age = currentYear - purchaseYear;
        setFormData((prev) => ({ ...prev, vehicleAge: age.toString() }));
      } else {
        setFormData((prev) => ({ ...prev, vehicleAge: "" }));
      }
    } else {
      setFormData((prev) => ({ ...prev, vehicleAge: "" }));
    }
  }, [formData.yearOfPurchase]);

  // Load data if editing
  useEffect(() => {
    if (isEditMode && vehicleData) {
      setFormData({
        slNo: vehicleData.slNo || "",
        vehicleType: vehicleData.vehicleType || "",
        make: vehicleData.make || "",
        model: vehicleData.model || "",
        regNo: vehicleData.regNo || "",
        yearOfPurchase: vehicleData.yearOfPurchase || "",
        vehicleAge: vehicleData.vehicleAge || "",
        operatingArea: vehicleData.operatingArea || "",
        utilizationRate: vehicleData.utilizationRate || "",
        assignedTo: vehicleData.assignedTo || "",
      });
    }
  }, [isEditMode, vehicleData]);

  const handleBack = () => {
    if (returnPath) {
      navigate(returnPath, {
        state: {
          vehicleType,
          vehicles: currentVehicles,
          rowIndex,
          year,
          facilityDefinition,
          isAdmin,
          rowData
        }
      });
    } else {
      navigate(-1);
    }
  };

  const handleChange = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
    
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    handleChange(name, value);
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.vehicleType) {
      newErrors.vehicleType = "Vehicle type is required";
    }

    if (!formData.make) {
      newErrors.make = "Make is required";
    }

    if (!formData.model) {
      newErrors.model = "Model is required";
    }

    if (!formData.regNo) {
      newErrors.regNo = "Registration number is required";
    }

    if (!formData.yearOfPurchase) {
      newErrors.yearOfPurchase = "Year of purchase is required";
    } else {
      const yearNum = parseInt(formData.yearOfPurchase);
      const currentYear = new Date().getFullYear();
      if (yearNum < 1900 || yearNum > currentYear) {
        newErrors.yearOfPurchase = `Year must be between 1900 and ${currentYear}`;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    const vehicleFormData = {
      vehicleType: formData.vehicleType,
      make: formData.make,
      model: formData.model,
      regNo: formData.regNo,
      yearOfPurchase: formData.yearOfPurchase,
      vehicleAge: formData.vehicleAge,
      operatingArea: formData.operatingArea,
      utilizationRate: formData.utilizationRate,
      assignedTo: formData.assignedTo,
    };

    if (isEditMode) {
      const updatedVehicle = {
        ...vehicleFormData,
        id: vehicleData.id,
        slNo: formData.slNo
      };
      
      console.log("Vehicle updated:", updatedVehicle);
      alert("Vehicle updated successfully!");
      
      navigate(returnPath, {
        state: {
          vehicleType,
          vehicles: currentVehicles,
          rowIndex,
          year,
          facilityDefinition,
          isAdmin,
          rowData,
          updatedVehicle
        }
      });
    } else {
      console.log("Vehicle added:", vehicleFormData);
      alert("Vehicle added successfully!");
      
      navigate(returnPath, {
        state: {
          vehicleType,
          vehicles: currentVehicles,
          rowIndex,
          year,
          facilityDefinition,
          isAdmin,
          rowData,
          newVehicle: vehicleFormData
        }
      });
    }
  };

  const getPageTitle = () => {
    const prefix = isEditMode ? "Edit" : "Add";
    if (vehicleType === "sales") {
      return `${prefix} Sales Vehicle - 4-Wheeler (${year})`;
    } else if (vehicleType === "service") {
      return `${prefix} Service Vehicle - 4-Wheeler (${year})`;
    }
    return `${prefix} Vehicle (${year})`;
  };
useKeyboardNavigation({
  containerRef: fromRef, // your popup div ref

  onSubmit: () => { 
    handleSubmit()
  },

  onCancel: () => {
  handleBack()
  },
});

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2">
            <div className="flex items-center gap-2">
              <button
                onClick={handleBack}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              >
                <ArrowLeft size={16} />
              </button>
              <div>
                <h1 className="text-base font-semibold text-darkblue1">
                  {getPageTitle()}
                </h1>
                <p className="text-xs text-gray-600 ">{facilityDefinition}</p>
              </div>
            </div>
          </div>

          {/* Form Container */}
          <div className="bg-white shadow-md border border-gray-300 p-4 ">
            <form 
            ref={fromRef}
            onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                {/* Vehicle Type */}
                <StyledSelectField
                  label="Vehicle Type"
                  placeholder="Select Type"
                  value={formData.vehicleType}
                  setValue={(val) => handleChange("vehicleType", val)}
                  options={vehicleTypeOptions}
                  dropdownOpen={isVehicleTypeOpen}
                  setDropdownOpen={setIsVehicleTypeOpen}
                  dropdownRef={vehicleTypeRef}
                  required
                  error={errors.vehicleType}
                />

                {/* Make */}
                <StyledSelectField
                  label="Make"
                  placeholder="Select Make"
                  value={formData.make}
                  setValue={(val) => handleChange("make", val)}
                  options={makeOptions}
                  dropdownOpen={isMakeOpen}
                  setDropdownOpen={setIsMakeOpen}
                  dropdownRef={makeRef}
                  required
                  error={errors.make}
                />

                {/* Model */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-2">
                    Model <span className="text-red1">*</span>
                  </label>
                  <input
                    type="text"
                    name="model"
                    value={formData.model}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-1.5 border focus:outline-none focus:ring-2 text-xs ${
                      errors.model
                        ? "border-red-500 focus:ring-red-500"
                        : "border-black/30 focus:ring-darkblue1"
                    }`}
                    placeholder="Enter model (e.g., Bolero-220, Ritz)"
                  />
                  {errors.model && (
                    <p className="text-red1 text-xs mt-1">{errors.model}</p>
                  )}
                </div>

                {/* Registration Number */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-2">
                    Registration Number <span className="text-red1">*</span>
                  </label>
                  <input
                    type="text"
                    name="regNo"
                    value={formData.regNo}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-1.5 border focus:outline-none focus:ring-2 text-xs uppercase ${
                      errors.regNo
                        ? "border-red-500 focus:ring-red-500"
                        : "border-black/30 focus:ring-darkblue1"
                    }`}
                    placeholder="e.g., KA02919, RJ192919"
                  />
                  {errors.regNo && (
                    <p className="text-red-500 text-xs mt-1">{errors.regNo}</p>
                  )}
                </div>

                {/* Year of Purchase */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-2">
                    Year of Purchase <span className="text-red1">*</span>
                  </label>
                  <input
                    type="number"
                    name="yearOfPurchase"
                    value={formData.yearOfPurchase}
                    onChange={handleInputChange}
                    min="1900"
                    max={new Date().getFullYear()}
                    className={`w-full px-4 py-1.5 border  focus:outline-none focus:ring-2 text-xs ${
                      errors.yearOfPurchase
                        ? "border-red-500 focus:ring-red-500"
                        : "border-black/30 focus:ring-darkblue1"
                    }`}
                    placeholder="Enter year (e.g., 2023, 2025)"
                  />
                  {errors.yearOfPurchase && (
                    <p className="text-red1 text-xs mt-1">{errors.yearOfPurchase}</p>
                  )}
                </div>

                {/* Vehicle Age (Auto-calculated) */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-2">
                    Vehicle Age (Years)
                  </label>
                  <input
                    type="text"
                    name="vehicleAge"
                    value={formData.vehicleAge}
                    readOnly
                    className="w-full px-4 py-1.5 border border-black/30  bg-gray-100 cursor-not-allowed text-xs"
                    placeholder="Auto calculated"
                  />
                  <p className="text-xs text-gray-500 mt-1">Automatically calculated from year of purchase</p>
                </div>

                {/* Operating Area */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-2">
                    Operating Area
                  </label>
                  <input
                    type="text"
                    name="operatingArea"
                    value={formData.operatingArea}
                    onChange={handleInputChange}
                    className="w-full px-4 py-1.5 border border-black/30  focus:outline-none focus:ring-2 focus:ring-darkblue1 text-xs"
                    placeholder="e.g., Bidar, Jaipur"
                  />
                </div>

                {/* Utilisation Rate */}
                <StyledSelectField
                  label="Utilisation Rate"
                  placeholder="Select Rate"
                  value={formData.utilizationRate}
                  setValue={(val) => handleChange("utilizationRate", val)}
                  options={utilizationOptions}
                  dropdownOpen={isUtilizationOpen}
                  setDropdownOpen={setIsUtilizationOpen}
                  dropdownRef={utilizationRef}
                  required={false}
                />

                {/* Assigned To */}
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-2">
                    Assigned To
                  </label>
                  <input
                    type="text"
                    name="assignedTo"
                    value={formData.assignedTo}
                    onChange={handleInputChange}
                    className="w-full px-4 py-1.5 border border-black/30 r focus:outline-none focus:ring-2 focus:ring-darkblue1 text-xs"
                    placeholder="e.g., User 1, user 2"
                  />
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex flex-wrap gap-4 justify-center lg:justify-end mt-6">
                <button
                  type="button"
                  className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium hover:bg-mildBlue1 hover:scale-105 transition"
                  onClick={handleBack}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 18 20" fill="none">
<path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
                >
                  {isEditMode ? "Update" : "Save"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InfrastructureVehicleForm;