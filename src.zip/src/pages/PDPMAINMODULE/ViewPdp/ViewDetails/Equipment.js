import React, { useState, useEffect,useRef } from "react";
import { Download, X, Calendar, Lock, User, CheckCircle, Clock } from "lucide-react";
import Searchinput from "../../../../Components/Searchinput";
import { useNavigate, useLocation } from "react-router-dom";
import { getPdpEquipmentsByPdpId } from "../../../../services/PDP/Equipmentshyperlink/pdphyperEquipments.service";
import { getPdpSignoffsByPdpId, updatePdpSignoff } from "../../../../services/PDP/Signoff/signoff.service";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../../services/download/bluckDownload.service";
import { useSelector } from "react-redux";
import {useMemo} from "react";
import { ChevronDown,ChevronsUpDown,ArrowUp,ArrowDown } from "lucide-react";
import { ChevronUp } from "lucide-react";
// ═══════════════════════════════════════════════════════════════
// ROLE CONFIGURATIONS FOR SIGNOFF
// ═══════════════════════════════════════════════════════════════

// Roles that can sign "Dealer Sales Head" category
const DEALER_SIGNOFF_ROLES = [
  "Dealer Sales Head",
  "Dealer CEO",
  "Dealer Principal"
];

// Roles that can sign "Volvo CE Retail Sales Manager" category
const VOLVO_SIGNOFF_ROLES = [
  "Market Area Head",
  "Retail Sales Manager",
  "Administrator",
  "Head Of Channel Developement (Region India)"
];

// Admin roles (for button text)
const ADMIN_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Market Area Head",
  "Retail Sales Manager"
];

// ═══════════════════════════════════════════════════════════════
// CATEGORY CONFIGURATION - Display names and DB keys
// ═══════════════════════════════════════════════════════════════
const CATEGORY_CONFIG = {
  'Equipments_Volvo': {
    displayName: 'Volvo CE Retail Sales Manager',
    shortName: 'Volvo CE Retail Sales Manager',
    dbKey: 'Equipments_Volvo'
  },
  'Equipments_Dealer': {
    displayName: 'Dealer Sales Head',
    shortName: 'Dealer Sales Head',
    dbKey: 'Equipments_Dealer'
  }
};

export default function Equipment({ rowData, userRole }) {
  const [activeView, setActiveView] = useState("retail");
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [equipmentData, setEquipmentData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"
const [hoveredCell, setHoveredCell] = useState(null);
const [expandedCell, setExpandedCell] = useState(null);  // Signoff states
  const [signoffData, setSignoffData] = useState([]);
  const [isLoadingSignoffs, setIsLoadingSignoffs] = useState(false);
  const [isSigningOff, setIsSigningOff] = useState(null);
  const tableContainerRef = useRef(null);
  const navigate = useNavigate();
  const location = useLocation();
  
  // Get user data from Redux
  const userData = useSelector((state) => state.user?.data || state.user);

  // ⭐ Extract PDP ID from rowData
  const pdpId = React.useMemo(() => {
    if (rowData?.id) {
      return rowData.id;
    }
    if (location.state?.rowData?.id) {
      return location.state.rowData.id;
    }
    return null;
  }, [rowData, location.state]);

  const selectedyear = React.useMemo(() => {
    if (rowData?.year) {
      return parseInt(rowData.year);
    }
    if (location.state?.rowData?.year) {
      return parseInt(location.state.rowData.year);
    }
    return new Date().getFullYear();
  }, [rowData, location.state]);

  // ═══════════════════════════════════════════════════════════════
  // CHECK IF MEETING HAS BEEN SCHEDULED
  // ═══════════════════════════════════════════════════════════════
  const signoffMeetingDate = rowData?.signoffMeetingDate || rowData?.signoff_meeting_date;
  const isMeetingScheduled = !!signoffMeetingDate;

  // ═══════════════════════════════════════════════════════════════
  // ROLE CHECKS
  // ═══════════════════════════════════════════════════════════════
  const isAdmin = ADMIN_ROLES.some(
    role => role.toLowerCase() === userRole?.toLowerCase()
  );

  const canSignDealerCategory = DEALER_SIGNOFF_ROLES.some(
    role => role.toLowerCase() === userRole?.toLowerCase()
  );

  const canSignVolvoCategory = VOLVO_SIGNOFF_ROLES.some(
    role => role.toLowerCase() === userRole?.toLowerCase()
  );

  // ⭐ UPDATED: Always show all categories
  const getVisibleCategories = () => {
    return ['Equipments_Volvo', 'Equipments_Dealer'];
  };

  // ⭐ Fetch equipment data
  useEffect(() => {
    const fetchEquipmentData = async () => {
      if (!pdpId) {
        console.error("❌ PDP ID is missing");
        setError("PDP ID is required to load equipment data");
        setIsLoading(false);
        return;
      }

      if (!selectedyear || isNaN(selectedyear)) {
        setError("Invalid year parameter");
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);
        
        const filters = {
          category: activeView === "retail" ? "Retails" : "Key Account",
        };

        const data = await getPdpEquipmentsByPdpId(pdpId, filters);
        setEquipmentData(data);
      } catch (error) {
        console.error("❌ Error fetching equipment data:", error);
        setError(error.message || "Failed to load equipment data. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchEquipmentData();
  }, [pdpId, selectedyear, activeView]);

  // ⭐ Fetch signoff data when modal opens
  useEffect(() => {
    const fetchSignoffData = async () => {
      if (!showModal || !pdpId) return;
      
      setIsLoadingSignoffs(true);
      try {
        const signoffs = await getPdpSignoffsByPdpId(pdpId);
        // Filter for equipment categories only
        const equipmentSignoffs = signoffs.filter(s => 
          s.category === 'Equipments_Volvo' || s.category === 'Equipments_Dealer'
        );
        setSignoffData(equipmentSignoffs);
      } catch (error) {
        console.error("❌ Error fetching signoff data:", error);
      } finally {
        setIsLoadingSignoffs(false);
      }
    };

    fetchSignoffData();
  }, [showModal, pdpId]);

  // ⭐ Generate table data from API response
  const generateTableData = (viewType) => {
    if (!equipmentData || equipmentData.length === 0) return [];

    const groupedByType = equipmentData.reduce((acc, item) => {
      const type = item.equipment_type || "Unknown";
      if (!acc[type]) {
        acc[type] = [];
      }
      acc[type].push(item);
      return acc;
    }, {});

    return Object.keys(groupedByType).map(type => {
      const groupedByMake = groupedByType[type].reduce((acc, item) => {
        const make = item.equipment_make || "Unknown";
        if (!acc[make]) {
          acc[make] = [];
        }
        acc[make].push(item);
        return acc;
      }, {});

      const makes = Object.keys(groupedByMake).map(makeName => {
        const lineGroups = groupedByMake[makeName].reduce((acc, item) => {
          const line = item.equipment_line || "Unknown";
          if (!acc[line]) {
            acc[line] = {
              line: line,
              models: [],
              target: 0,
              total: 0,
              count: 0
            };
          }
          
          if (item.equipment_model && !acc[line].models.includes(item.equipment_model)) {
            acc[line].models.push(item.equipment_model);
          }
          
          acc[line].count += 1;
          
          const targetValue = parseFloat(item.target || 0);
          const totalValue = parseFloat(item.total || 0);
          
          acc[line].target += targetValue;
          acc[line].total += totalValue;
          
          return acc;
        }, {});

        const lines = Object.values(lineGroups).map(lineGroup => {
          return {
            line: lineGroup.line,
            models: lineGroup.models,
            target: lineGroup.target.toString(),
            total: lineGroup.total.toString(),
            measurement: "Units"
          };
        });

        return {
          name: makeName,
          lines: lines
        };
      });

      return {
        type: type,
        makes: makes
      };
    });
  };

  const currentData = generateTableData(activeView);
  
  const filteredData = currentData
    .map((section) => {
      const filteredMakes = section.makes
        .map((make) => {
          const filteredLines = make.lines.filter((line) =>
            [
              section.type,
              make.name,
              line.line,
              line.target,
              line.total,
              line.measurement
            ].some((value) =>
              value?.toString().toLowerCase().includes(searchTerm.toLowerCase())
            )
          );
          if (filteredLines.length > 0) return { ...make, lines: filteredLines };
          return null;
        })
        .filter(Boolean);

      if (filteredMakes.length > 0) return { ...section, makes: filteredMakes };
      return null;
    })
    .filter(Boolean);
const flattenedData = useMemo(() => {
  if (!filteredData) return [];

  const rows = [];
  filteredData.forEach(section => {
    section.makes?.forEach(make => {
      make.lines?.forEach(line => {
        rows.push({
          type: section.type,
          make: make.name,
          line: line.line,
          target: parseFloat(line.target ?? 0),
          total: parseFloat(line.total ?? 0),
          measurement: line.measurement,
        });
      });
    });
  });

  return rows;
}, [filteredData]);

  const getTotalRowsForType = (section) =>
    section.makes.reduce((sum, make) => sum + make.lines.length, 0);

  const handleDownload = async () => {
    if (!filteredData || filteredData.length === 0) {
      alert("No data available to download");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet(`Equipment_${activeView}`);

      sheet.columns = [
        { header: "Sl. No", key: "slNo", width: 8 },
        { header: "Equipment Type", key: "type", width: 40 },
        { header: "Make", key: "make", width: 17 },
        { header: "Line", key: "line", width: 25 },
        { header: "Target", key: "target", width: 15 },
        { header: "Total", key: "total", width: 15 },
        { header: "Measurement", key: "measurement", width: 15 },
      ];

      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      let slNo = 1;

      filteredData.forEach((section) => {
        section.makes.forEach((make) => {
          make.lines.forEach((line) => {
            const row = sheet.addRow({
              slNo: slNo++,
              type: section.type,
              make: make.name,
              line: line.line,
              target: line.target,
              total: line.total,
              measurement: line.measurement,
            });

            row.eachCell((cell) => {
              cell.alignment = { vertical: "middle", horizontal: "left" };
            });
          });
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const fileName = `Equipment_${activeView}_${selectedyear}.xlsx`;

      const file = new File([blob], fileName, {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const response = await uploadTempFile(file);

      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${encodeURIComponent(
            response
          )}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        alert("File uploaded but preview not available.");
      }
    } catch (error) {
      console.error("❌ Equipment download failed:", error);
      alert("Failed to generate Excel preview. Please try again.");
    }
  };

  const handleModalAction = () => {
    if (!isMeetingScheduled) {
      alert("Signoff meeting must be scheduled before initiating the approval process.");
      return;
    }
    setShowModal(true);
  };

  const handleEquipmentTypeClick = (equipmentType) => {
    try {
      if (!pdpId) {
        alert("Missing PDP ID. Please refresh the page and try again.");
        return;
      }
      
      if (!selectedyear) {
        alert("Missing year data. Please refresh the page and try again.");
        return;
      }
      
      if (!equipmentType) {
        alert("Missing equipment type. Please try again.");
        return;
      }

      const basePath = "/pdp/view/equipment/details";
      
      const navigationState = {
        pdpId: pdpId,
        selectedYear: selectedyear,
        equipmentType: equipmentType,
        viewType: activeView,
        rowData: rowData || { 
          id: pdpId,
          year: selectedyear,
          dealer: "Unknown"
        },
        userRole: userRole,
        fromPath: location.pathname,
        timestamp: new Date().toISOString()
      };
      
      window.scrollTo({ top: 0, behavior: "smooth" });
      navigate(basePath, { 
        state: navigationState,
        replace: false
      });
    } catch (error) {
      console.error("❌ Navigation error:", error);
      alert("Failed to navigate. Please try again.");
    }
  };
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  // Format meeting date for display
  const formatMeetingDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData]
    .map((section) => {
      let sortedMakes = [...section.makes];

      if (sortKey === "equipmentMake") {
        // sort makes by make.name
        sortedMakes.sort((a, b) => {
          const valA = (a.name ?? "").toLowerCase();
          const valB = (b.name ?? "").toLowerCase();
          return sortOrder === "asc"
            ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: "base" })
            : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: "base" });
        });
      }

      // sort lines
      sortedMakes = sortedMakes.map((make) => {
        const sortedLines = [...make.lines];
        if (["equipmentLine", "target", "total", "measurement"].includes(sortKey)) {
          const dataKeyMap = {
            equipmentLine: "line",
            target: "target",
            total: "total",
            measurement: "measurement",
          };
          const key = dataKeyMap[sortKey];

          sortedLines.sort((a, b) => {
            const valA = (a[key] ?? "").toString().toLowerCase();
            const valB = (b[key] ?? "").toString().toLowerCase();
            return sortOrder === "asc"
              ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: "base" })
              : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: "base" });
          });
        }
        return { ...make, lines: sortedLines };
      });

      return { ...section, makes: sortedMakes };
    })
    .sort((a, b) => {
      if (sortKey === "equipmentType") {
        const valA = (a.type ?? "").toLowerCase();
        const valB = (b.type ?? "").toLowerCase();
        return sortOrder === "asc"
          ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: "base" })
          : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: "base" });
      }
      return 0; // don't sort sections if sortKey is not type
    });
}, [filteredData, sortKey, sortOrder]);
  // ═══════════════════════════════════════════════════════════════
  // SIGNOFF HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleSignOff = async (categoryKey) => {
    const signoffItem = signoffData.find(s => s.category === categoryKey);
    
    if (!signoffItem) {
      alert("Signoff record not found. Please contact administrator.");
      return;
    }

    if (signoffItem.isSigned) {
      alert("This category has already been signed off.");
      return;
    }

    setIsSigningOff(categoryKey);
    try {
      await updatePdpSignoff(signoffItem.id, {
        isSigned: true,
        signed_timestamp: new Date().toISOString(),
        user_id: userData?.id,
        user_persona: userRole
      });

      // Update local state
      setSignoffData(prev => prev.map(item => {
        if (item.category === categoryKey) {
          return {
            ...item,
            isSigned: true,
            signed_timestamp: new Date().toISOString(),
            user_first_name: userData?.first_name || userData?.firstName,
            user_last_name: userData?.last_name || userData?.lastName,
            user_persona: userRole
          };
        }
        return item;
      }));

      alert("Sign off completed successfully!");
    } catch (error) {
      console.error("❌ Signoff failed:", error);
      alert("Failed to sign off. Please try again.");
    } finally {
      setIsSigningOff(null);
    }
  };

  // Get signoff status for a category
  const getSignoffStatus = (categoryKey) => {
    const signoff = signoffData.find(s => s.category === categoryKey);
    if (!signoff) return { exists: false, isSigned: false };
    return {
      exists: true,
      isSigned: signoff.isSigned === 1 || signoff.isSigned === true,
      signedBy: signoff.user_first_name && signoff.user_last_name 
        ? `${signoff.user_first_name} ${signoff.user_last_name}`.trim()
        : 'Not Assigned',
      signedAt: signoff.signed_timestamp,
      designation: signoff.user_persona
    };
  };

  // Calculate completion percentage
  const getCompletionStats = () => {
    const visibleCategories = getVisibleCategories();
    const relevantSignoffs = signoffData.filter(s => visibleCategories.includes(s.category));
    const total = relevantSignoffs.length;
    const signed = relevantSignoffs.filter(s => s.isSigned === 1 || s.isSigned === true).length;
    return { total, signed, percentage: total > 0 ? Math.round((signed / total) * 100) : 0 };
  };

  // Check if user can sign a specific category
  const canUserSign = (categoryKey) => {
    if (categoryKey === 'Equipments_Dealer') {
      return canSignDealerCategory;
    } else if (categoryKey === 'Equipments_Volvo') {
      return canSignVolvoCategory;
    }
    return false;
  };

  // Get button text based on meeting status and role
  const getApprovalButtonText = () => {
    if (!isMeetingScheduled) {
      return "Approval Locked";
    }
    return isAdmin ? "Initiate Approval Process" : "View Sign Off Status";
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12 bg-white border-2 border-Dustyblue">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-darkblue1 mx-auto mb-4"></div>
          <p className="text-gray-600 font-medium">Loading equipment data...</p>
          <p className="text-gray-500 text-sm mt-2">PDP ID: {pdpId}</p>
          <p className="text-gray-500 text-sm">Year: {selectedyear}</p>
          <p className="text-gray-500 text-sm">Category: {activeView === "retail" ? "Retails" : "Key Account"}</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="bg-white border-2 border-red-300 p-8 text-center">
        <div className="text-red-600 mb-4">
          <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="text-lg font-semibold mb-2">Error Loading Data</h3>
          <p className="text-sm mb-4">{error}</p>
          <div className="text-xs text-gray-600 space-y-1">
            <p>PDP ID: {pdpId || "Not found"}</p>
            <p>Year: {selectedyear}</p>
            <p>Category: {activeView === "retail" ? "Retails" : "Key Account"}</p>
          </div>
        </div>
        <button
          onClick={() => window.location.reload()}
          className="bg-darkblue1 text-white px-6 py-2 hover:bg-darkblue1/90 transition"
        >
          Retry
        </button>
      </div>
    );
  }

  // Empty state
  if (!equipmentData || equipmentData.length === 0) {
    return (
      <div className="bg-white border-2 border-gray-300 p-8 text-center">
        <div className="text-gray-500 mb-4">
          <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
          </svg>
          <h3 className="text-lg font-semibold mb-2">No Equipment Data</h3>
          <p className="text-sm mb-4">No equipment records found for this PDP.</p>
          <div className="text-xs text-gray-600 space-y-1">
            <p>PDP ID: {pdpId}</p>
            <p>Year: {selectedyear}</p>
            <p>Category: {activeView === "retail" ? "Retails" : "Key Account"}</p>
          </div>
        </div>
      </div>
    );
  }

  const visibleCategories = getVisibleCategories();
  const completionStats = getCompletionStats();

  return (
    <>
      {/* Toggle Buttons */}
      <div className="flex w-full mb-4 overflow-hidden shadow-sm">
        <button
          onClick={() => setActiveView("retail")}
          className={`flex-1 py-2 text-sm font-medium transition-all duration-200 ${
            activeView === "retail"
              ? "bg-darkblue1 text-white shadow-md"
              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
          }`}
        >
          Retail
        </button>
        <button
          onClick={() => setActiveView("key account")}
          className={`flex-1 py-2 text-sm font-medium transition-all duration-200 ${
            activeView === "key account"
              ? "bg-darkblue1 text-white shadow-md"
              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
          }`}
        >
          Key Account
        </button>
      </div>

      <div className="bg-white border border-Dustyblue shadow-[0_4px_10px_#0000001A]">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-0 gap-4 p-4">
          <div className="">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search "
              className="w-[1/2]"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              focusRing="focus:ring-black/60"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-2 sm:py-3"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              iconColor="text-black"
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <button
              onClick={handleDownload}
              disabled={filteredData.length === 0}
              className="bg-darkblue1 text-xs font-medium text-white px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Download size={14} className="text-current" />
              Download
            </button>

            {/* Approval Button */}
            <button
              onClick={handleModalAction}
              disabled={!isMeetingScheduled}
              className={`text-xs font-medium px-4 py-1.5 transition whitespace-nowrap flex items-center justify-center gap-2 ${
                isMeetingScheduled
                  ? "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"
              }`}
              title={!isMeetingScheduled ? "Signoff meeting must be scheduled first" : ""}
            >
              {!isMeetingScheduled && <Lock size={14} />}
              {getApprovalButtonText()}
            </button>
          </div>
        </div>

        {/* {isMeetingScheduled && (
          <div className="mx-4 mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center gap-2 text-green-800">
              <Calendar size={16} />
              <span className="text-sm">
                <span className="font-medium">Signoff Meeting Scheduled: </span>
                {formatMeetingDate(signoffMeetingDate)}
              </span>
            </div>
          </div>
        )} */}

        {/* Desktop Table */}
          <div className="hidden lg:block overflow-x-auto">
             <div
              ref={tableContainerRef}
                className="overflow-y-auto overflow-x-auto scrollbar-hide"
                style={{
                  maxHeight: sortedData.length > 8 ? "calc(100vh - 240px)" : "auto",
                }}
                 onScroll={handleTableScroll}
              >
                <table className="w-full text-sm border-collapse table-fixed">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
  <tr>
  {/* Equipment Type — center */}
  <th
  onClick={() => handleSort("equipmentType")}
  className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5 w-[30%] font-medium text-left cursor-pointer select-none"
>
  <div className="flex items-center justify-start gap-1">
    Equipment Type
    {sortKey !== "equipmentType" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
    {sortKey === "equipmentType" && (
      sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3 text-white" />
      ) : sortOrder === "desc" ? (
        <ChevronDown className="w-3 h-3 text-white" />
      ) : null
    )}
  </div>
</th>

  {/* Equipment Make — left */}
  <th
    className="text-xs border border-grey2 border-t-0 border-b-0 px-3 py-1.5 w-[12%] font-medium text-left cursor-pointer "
  >
      Equipment Make
  </th>

  {/* Equipment Line — left */}
  <th
    className="text-xs border border-grey2 border-t-0 border-b-0 px-3 py-1.5 w-[25%]  font-medium text-left cursor-pointer select-none"
  >
  
      Equipment Line
      
  
  </th>

  {/* Target — center */}
  <th
    className="text-xs border border-grey2 border-t-0 border-b-0 px-3 py-1.5 w-[10%] font-medium text-center cursor-pointer select-none"
  > 
      Target
  </th>

  {/* Total — center */}
  <th
    className="text-xs border border-grey2 border-t-0 border-b-0 px-3 py-1.5 w-[10%] font-medium text-center cursor-pointer select-none"
  >
      Total
  </th>

  {/* Measurement — center */}
  <th
    className="text-xs border border-grey2 border-t-0 border-b-0 border-r-0 px-3 py-1.5 w-[10%] font-medium text-center cursor-pointer select-none"
  >
      Measurement
  </th>
</tr>


  </thead>

              <tbody>
                {sortedData.length > 0 ? (
                  sortedData.map((section, sectionIdx) => {
                    let typeRowSpan = getTotalRowsForType(section);
                    let typeRowRendered = false;

                    return section.makes.map((make, makeIdx) =>
                      make.lines.map((lineItem, lineIdx) => {
                        const isFirstRowOfMake = lineIdx === 0;
                        const isFirstRowOfType = !typeRowRendered;
                        if (isFirstRowOfType) typeRowRendered = true;

                        return (
                          <tr
                            key={`${sectionIdx}-${makeIdx}-${lineIdx}`}
                            className="hover:bg-lightBlue/50 text-xs"
                          >
                            {isFirstRowOfType && (
                             <td
  rowSpan={typeRowSpan}
  className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-SteelBlue underline cursor-pointer text-left align-middle hover:text-darkblue1 transition"
  onClick={() => handleEquipmentTypeClick(section.type)}
>
  <div className="relative">
    <p
      className="truncate max-w-[50rem]"
      onMouseEnter={() => {
        if ((section.type ?? "").length > 50)
          setHoveredCell(section.id + "-type");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {section.type}
    </p>

    {hoveredCell === section.id + "-type" && (
      <span className="absolute left-1/2 top-full bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {section.type}
      </span>
    )}
  </div>
</td>

                            )}

                            {isFirstRowOfMake && (
                              <td
  rowSpan={make.lines.length}
  className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-left align-middle"
>
  <div className="relative">
    <p
      className="truncate max-w-[50rem] cursor-pointer"
      onMouseEnter={() => {
        if ((make.name ?? "").length > 50)
          setHoveredCell(make.id + "-name");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {make.name}
    </p>

    {hoveredCell === make.id + "-name" && (
      <span className="absolute left-1/2 top-full bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {make.name}
      </span>
    )}
  </div>
</td>

                            )}
                         <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-left">
  <div className="relative">
    <p
      className={`max-w-[50rem] cursor-pointer ${
        expandedCell === lineItem.id + "-line" ? "" : "truncate"
      }`}
      onClick={() =>
        setExpandedCell(
          expandedCell === lineItem.id + "-line"
            ? null
            : lineItem.id + "-line"
        )
      }
    >
      {lineItem.line}
    </p>
  </div>
</td>

                            <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center">
                              {lineItem.target}
                            </td>
                            <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center">
                              {lineItem.total}
                            </td>
                            <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1 text-center">
                              {lineItem.measurement}
                            </td>
                          </tr>
                        );
                      })
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={6} className="text-center py-8 text-gray-500 italic">
                      {searchTerm ? "No matching equipment found." : "No equipment data available."}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
            {showScrollButtons && (
            <div className="fixed bottom-4 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

</div>
        {/* Mobile Card Layout */}
        <div className="lg:hidden space-y-4 p-4">
          {filteredData.length > 0 ? (
            filteredData.map((section) =>
              section.makes.flatMap((make) =>
                make.lines.map((lineItem, idx) => (
                  <div
                    key={`${section.type}-${make.name}-${idx}`}
                    className="bg-white shadow-md p-4 border border-gray-200 hover:shadow-lg transition"
                  >
                    <div className="flex justify-between mb-2">
                      <span className="font-semibold text-sm text-mildBlue">Equipment Type:</span>
                      <span 
                        className="text-sm text-SteelBlue underline cursor-pointer hover:text-darkblue1"
                        onClick={() => handleEquipmentTypeClick(section.type)}
                      >
                        {section.type}
                      </span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="font-semibold text-sm text-mildBlue">Equipment Make:</span>
                      <span className="text-sm">{make.name}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="font-semibold text-sm text-mildBlue">Equipment Line:</span>
                      <span className="text-sm">{lineItem.line}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="font-semibold text-sm text-mildBlue">Target:</span>
                      <span className="text-sm font-medium">{lineItem.target}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="font-semibold text-sm text-mildBlue">Total:</span>
                      <span className="text-sm font-medium">{lineItem.total}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-semibold text-sm text-mildBlue">Measurement:</span>
                      <span className="text-sm">{lineItem.measurement}</span>
                    </div>
                  </div>
                ))
              )
            )
          ) : (
            <div className="text-center py-8 text-gray-500 italic bg-gray-50">
              {searchTerm ? "No matching equipment found." : "No equipment data available."}
            </div>
          )}
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* EQUIPMENT APPROVAL PROCESS MODAL */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto rounded-lg">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b relative">
              <div className="text-center flex-1">
                <h2 className="text-lg font-bold text-gray-800">
                  Equipment Approval Process
                </h2>
                <p className="text-sm text-gray-600 mt-1">
                  Sign off on equipment approvals
                </p>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="absolute top-4 right-4 text-white bg-red rounded-full p-1.5 font-medium hover:bg-red-600 transition"
              >
                <X size={16} />
              </button>
            </div>

            {/* PDP Sign-off Status Header */}
            <div className="bg-gray-700 px-6 py-3 flex items-center justify-between">
              <h3 className="text-white text-sm font-medium">PDP Sign-off Status</h3>
              <div className="flex items-center gap-3">
                <span className="bg-gray-600 text-white text-xs px-3 py-1 rounded">
                  {isAdmin ? "Admin View" : "User View"}
                </span>
                <span className="text-white text-xs">
                  {completionStats.signed}/{completionStats.total} Complete ({completionStats.percentage}%)
                </span>
              </div>
            </div>

            {/* Signoff Cards */}
            <div className="p-6">
              {isLoadingSignoffs ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
                  <span className="ml-3 text-gray-600">Loading signoff status...</span>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {visibleCategories.map((categoryKey) => {
                    const config = CATEGORY_CONFIG[categoryKey];
                    const status = getSignoffStatus(categoryKey);
                    const canSign = canUserSign(categoryKey);

                    return (
                      <div
                        key={categoryKey}
                        className={`border-2 rounded-lg p-5 relative ${
                          status.isSigned 
                            ? 'border-green-300 bg-green-50' 
                            : canSign
                            ? 'border-blue-300 bg-white'
                            : 'border-gray-300 bg-gray-50'
                        }`}
                      >
                        {/* Status Badge */}
                        <div className="absolute -top-2 -right-2">
                          {status.isSigned ? (
                            <span className="bg-green-500 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-md">
                              <CheckCircle size={12} />
                              Completed
                            </span>
                          ) : canSign ? (
                            <span className="bg-orange-500 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-md">
                              <Clock size={12} />
                              Action Required
                            </span>
                          ) : (
                            <span className="bg-gray-500 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-md">
                              <Lock size={12} />
                              Not Authorized
                            </span>
                          )}
                        </div>

                        {/* Card Content */}
                        <div className="flex items-start gap-4 mt-2">
                          {/* User Icon */}
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                            status.isSigned 
                              ? 'bg-green-200' 
                              : canSign
                              ? 'bg-gray-200'
                              : 'bg-gray-200 opacity-60'
                          }`}>
                            <User size={24} className={
                              status.isSigned 
                                ? 'text-green-700' 
                                : canSign
                                ? 'text-gray-600'
                                : 'text-gray-400'
                            } />
                          </div>

                          {/* Details */}
                          <div className="flex-1 min-w-0">
                            {/* Full Category Name - No Truncation */}
                            <h4 className="text-base font-semibold text-gray-800 leading-tight">
                              {config.displayName}
                            </h4>
                            
                            {/* Signed By Info */}
                            <p className="text-sm text-gray-600 mt-1">
                              {status.isSigned ? (
                                <>
                                  <span className="font-medium">{status.signedBy}</span>
                                  {status.designation && (
                                    <span className="text-gray-500"> • {status.designation}</span>
                                  )}
                                </>
                              ) : (
                                <span className="text-gray-500">Not Assigned</span>
                              )}
                            </p>

                            {/* Category Key (small text) */}
                            <p className="text-xs text-gray-400 mt-1">
                              {categoryKey.replace('_', ' ')}
                            </p>

                            {/* Sign Off Button - Only show if user can sign AND not already signed */}
                            {!status.isSigned && canSign && (
                              <button
                                onClick={() => handleSignOff(categoryKey)}
                                disabled={isSigningOff === categoryKey}
                                className="mt-4 bg-darkblue1 text-white text-sm font-medium px-6 py-2 rounded hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                              >
                                {isSigningOff === categoryKey ? (
                                  <>
                                    <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                                    </svg>
                                    Signing...
                                  </>
                                ) : (
                                  "Sign Off Now"
                                )}
                              </button>
                            )}

                            {/* Not Authorized Message */}
                            {!status.isSigned && !canSign && (
                              <p className="text-xs text-gray-500 mt-4 italic">
                                You are not authorized to sign off this category.
                              </p>
                            )}

                            {/* Signed timestamp */}
                            {status.isSigned && status.signedAt && (
                              <p className="text-xs text-green-600 mt-2">
                                Signed on: {new Date(status.signedAt).toLocaleDateString('en-US', {
                                  year: 'numeric',
                                  month: 'short',
                                  day: 'numeric',
                                  hour: 'numeric',
                                  minute: '2-digit'
                                })}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}