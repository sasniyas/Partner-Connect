import React, { useState, useEffect, useRef } from "react";
import { Download, Save, AlertCircle, X, Upload, File, Trash2, Eye, Lock } from "lucide-react";
import Searchinput from "../../../../Components/Searchinput";
import SingleSelectFilter from "../../../../Components/SingleSelelctFilter";
import DeleteModal from "../../../../Components/DeleteModal";
import ExcelJS from "exceljs";
import * as XLSX from "xlsx";
import { useMemo } from "react";
import { ChevronDown } from "lucide-react";
import { ChevronUp,ChevronsUpDown ,ArrowUp,ArrowDown } from "lucide-react";
// ⭐ Import Marcom Service
import {
  getPdpMarcomBrandingByPdpId,
  updateMultiplePdpMarcomBranding,
  updatePdpMarcomSupdoc,
  deletePdpMarcomSupdoc,
  getPdpMarcomMarketingByPdpId,
  updateMultiplePdpMarcomMarketing
} from "../../../../services/PDP/Marcom/marcom.service";
import { uploadTempFile } from "../../../../services/download/bluckDownload.service";

// ⭐ FIXED: Import centralized role functions
import { canEditData, isEditableStatus, isDealerRole, isAdminRole } from "../../../../pages/constants/roles";

// ═══════════════════════════════════════════════════════════════
// FILE UPLOAD MODAL COMPONENT
// ═══════════════════════════════════════════════════════════════
const FileUploadModal = ({ isOpen, onClose, onUpload, currentFile, identifier }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  useEffect(() => {
    if (!isOpen) {
      setSelectedFile(null);
      setUploadProgress(0);
      setIsUploading(false);
    }
  }, [isOpen]);

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    validateAndSetFile(file);
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    validateAndSetFile(file);
  };

  const validateAndSetFile = (file) => {
    if (!file) return;

    const maxSize = 10 * 1024 * 1024; // 10MB
    const allowedTypes = [
      'application/pdf',
      'image/jpeg',
      'image/jpg',
      'image/png',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];

    if (file.size > maxSize) {
      alert("File size must be less than 10MB");
      return;
    }

    if (!allowedTypes.includes(file.type)) {
      alert("Only PDF, JPG, PNG, XLS, and XLSX files are allowed");
      return;
    }

    setSelectedFile(file);
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    setUploadProgress(0);

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval);
          return prev;
        }
        return prev + 10;
      });
    }, 200);

    try {
      await onUpload(identifier, selectedFile);
      setUploadProgress(100);
      
      setTimeout(() => {
        onClose();
      }, 500);
    } catch (error) {
      alert("Upload failed. Please try again.");
    } finally {
      clearInterval(interval);
      setIsUploading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800">
            {currentFile ? "Replace Document" : "Upload Document"}
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition"
            disabled={isUploading}
          >
            <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>

          </button>
        </div>

        <div className="p-6">
          {currentFile && (
            <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Current file:</strong> {currentFile}
              </p>
              <p className="text-xs text-yellow-600 mt-1">
                Uploading a new file will replace the existing one.
              </p>
            </div>
          )}

          {!selectedFile ? (
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-lg p-8 text-center transition ${
                isDragging
                  ? "border-darkblue1 bg-blue-50"
                  : "border-gray-300 hover:border-darkblue1"
              }`}
            >
              <Upload className="mx-auto mb-4 text-gray-400" size={48} />
              <p className="text-sm text-gray-600 mb-2">
                Drag and drop your file here, or
              </p>
              <label className="inline-block px-4 py-2 bg-darkblue1 text-white text-sm font-medium rounded cursor-pointer hover:bg-darkblue1/90 transition">
                Browse Files
                <input
                  type="file"
                  className="hidden"
                  onChange={handleFileSelect}
                  accept=".pdf,.jpg,.jpeg,.png,.xls,.xlsx"
                  disabled={isUploading}
                />
              </label>
              <p className="text-xs text-gray-500 mt-4">
                Supported formats: PDF, JPG, PNG, XLS, XLSX
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <File className="text-darkblue1" size={32} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-800 truncate">
                    {selectedFile.name}
                  </p>
                  <p className="text-xs text-gray-500">
                    {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
                {!isUploading && (
                  <button
                    onClick={() => setSelectedFile(null)}
                    className="text-red-500 hover:text-red-700 transition"
                  >
                    <X size={20} />
                  </button>
                )}
              </div>

              {isUploading && (
                <div>
                  <div className="flex justify-between text-xs text-gray-600 mb-1">
                    <span>Uploading...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-darkblue1 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex items-center justify-end gap-3 p-4 border-t border-gray-200">
          <button
            onClick={onClose}
            disabled={isUploading}
            className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded transition disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={handleUpload}
            disabled={!selectedFile || isUploading}
            className="px-4 py-2 text-sm font-medium text-white bg-darkblue1 rounded hover:bg-darkblue1/90 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isUploading ? "Uploading..." : "Upload"}
          </button>
        </div>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// FILE DISPLAY COMPONENT
// ═══════════════════════════════════════════════════════════════
const FileDisplay = ({ file, onDownload, onDelete, onReplace, canEdit }) => {
  if (!file?.documentName) {
    return (
      <span className="text-xs text-gray-400 italic">No document uploaded</span>
    );
  }

  return (
    <div className="flex items-center gap-2 p-2 bg-gray-50 rounded border border-gray-200">
      <File className="text-darkblue1 flex-shrink-0" size={16} />
      <span className="text-xs text-gray-700 truncate flex-1" title={file.documentName}>
        {file.documentName}
      </span>
      <div className="flex items-center gap-1 flex-shrink-0">
        <button
          onClick={onDownload}
          className="p-1 text-darkblue1 hover:bg-darkblue1 hover:text-white rounded transition"
          title="Download"
        >
          <Download size={14} />
        </button>
        {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
        {canEdit && (
          <>
            <button
              onClick={onReplace}
              className="p-1 text-blue-600 hover:bg-blue-600 hover:text-white rounded transition"
              title="Replace"
            >
              <Upload size={14} />
            </button>
            <button
              onClick={onDelete}
              className="p-1 text-red-600 hover:bg-red-600 hover:text-white rounded transition"
              title="Delete"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>	

            </button>
          </>
        )}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════
// MAIN MARCOM COMPONENT
// ═══════════════════════════════════════════════════════════════
export default function Marcom({ rowData, userRole }) {
  const [activeView, setActiveView] = useState("branding");
  const [searchTerm, setSearchTerm] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [currentUploadIdentifier, setCurrentUploadIdentifier] = useState(null);
  const [currentUploadFile, setCurrentUploadFile] = useState(null);
  const [expandedCell, setExpandedCell] = useState(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [fileToDelete, setFileToDelete] = useState(null);
  const tableContainerRef = useRef()

  const selectedyear = rowData?.year || "2025";
  const pdpId = rowData?.id || null;

  // ⭐ FIXED: Extract PDP status from rowData
  const pdpStatus = rowData?.signOffStatus || rowData?.sign_of_status || "Created";

  // ⭐ FIXED: Use centralized role check instead of just checking "Administrator"
  const isAdmin = isAdminRole(userRole);
  
  // ⭐ NEW: Check if user can edit (considers both role AND status)
  const canEdit = canEditData(userRole, pdpStatus);
  
  // ⭐ NEW: Check if dealer but editing is locked due to status
  const isStatusLocked = isDealerRole(userRole) && !isEditableStatus(pdpStatus);

  const MARKETING_AREAS = [
    "Advertising",
    "Digital Marketing",
    "Event Marketing",
    "Website Management",
    "Merchandise Marketing",
    "Customer Experience Management",
    "Exhibition Participation"
  ];

  const tabs = [
    { id: "branding", label: "Branding" },
    { id: "marketing", label: "Marketing" },
  ];

  const [brandingData, setBrandingData] = useState([]);
  const [marketingData, setMarketingData] = useState([]);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  // ⭐ NEW: Get status badge color
  const getStatusBadgeColor = (status) => {
    switch (status) {
      case "Completed": return "bg-green-100 text-green-800 border-green-300";
      case "Approved": return "bg-blue-100 text-blue-800 border-blue-300";
      case "Pending Review": return "bg-orange-100 text-orange-800 border-orange-300";
      case "Started": return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "Created": return "bg-gray-100 text-gray-800 border-gray-300";
      default: return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  useEffect(() => {
    const loadMarcomData = async () => {
      if (!pdpId) {
        console.error("❌ PDP ID is missing");
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      try {
        const [brandingResponse, marketingResponse] = await Promise.all([
          getPdpMarcomBrandingByPdpId(pdpId),
          getPdpMarcomMarketingByPdpId(pdpId)
        ]);

        setBrandingData(brandingResponse);
        setMarketingData(marketingResponse);
        
      } catch (error) {
        console.error("❌ Error loading marcom data:", error);
        setSaveError(error.message || "Failed to load data. Please refresh the page.");
      } finally {
        setIsLoading(false);
      }
    };

    loadMarcomData();
  }, [pdpId]);

  useEffect(() => {
    if (saveSuccess) {
      const timer = setTimeout(() => setSaveSuccess(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [saveSuccess]);

  const currentData = activeView === "branding" ? brandingData : marketingData;

  const getFilteredData = () => {
    return currentData.filter((item) =>
      Object.values(item).some(val =>
        String(val).toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  };

  const filteredData = getFilteredData();

  const handleBrandingFieldChange = (idx, field, value) => {
    // ⭐ NEW: Prevent editing if status is locked
    if (!canEdit) {
      console.warn("⚠️ Editing is disabled for this PDP status:", pdpStatus);
      return;
    }
    
    const updatedData = [...brandingData];
    updatedData[idx][field] = value;
    setBrandingData(updatedData);
  };

  const handleMarketingFieldChange = (idx, field, value) => {
    // ⭐ NEW: Prevent editing if status is locked
    if (!canEdit) {
      console.warn("⚠️ Editing is disabled for this PDP status:", pdpStatus);
      return;
    }
    
    const updatedData = [...marketingData];
    updatedData[idx][field] = value;
    setMarketingData(updatedData);
  };

  const openUploadModal = (identifier, currentFile = null) => {
    // ⭐ NEW: Prevent opening upload modal if editing is disabled
    if (!canEdit) {
      console.warn("⚠️ Upload is disabled for this PDP status:", pdpStatus);
      return;
    }
    
    setCurrentUploadIdentifier(identifier);
    setCurrentUploadFile(currentFile);
    setUploadModalOpen(true);
  };

  const handleFileUpload = async (identifier, file) => {
    if (!file) return;

    // ⭐ NEW: Double-check edit permission before uploading
    if (!canEdit) {
      throw new Error(`Cannot upload. This PDP is in "${pdpStatus}" status and editing is disabled.`);
    }

    try {
      const recordId = parseInt(identifier.split('-')[1]);
      
      const response = await updatePdpMarcomSupdoc(recordId, file);
      
      const updatedData = [...brandingData];
      const recordIdx = updatedData.findIndex(item => item.id === recordId);
      
      if (recordIdx !== -1) {
        const docUrl = response.data?.supportive_doc_url || response.supportive_doc_url || file.name;
        const docName = docUrl.split('/').pop() || file.name;
        
        updatedData[recordIdx].supportiveDocUrl = docUrl;
        updatedData[recordIdx].documentName = docName;
        setBrandingData(updatedData);
      } else {
        console.warn("⚠️ Record not found in brandingData:", recordId);
      }
      
      setSaveSuccess(true);
    } catch (error) {
      console.error("❌ Upload error in component:", error);
      throw new Error(error.message || "Upload failed. Please try again.");
    }
  };

  const handleFileDownload = (fileUrl, fileName) => {
    if (!fileUrl) return;
    
    if (fileUrl.startsWith('http')) {
      window.open(fileUrl, '_blank');
    } else {
      const a = document.createElement('a');
      a.href = fileUrl;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  const openDeleteModal = (identifier) => {
    // ⭐ NEW: Prevent opening delete modal if editing is disabled
    if (!canEdit) {
      console.warn("⚠️ Delete is disabled for this PDP status:", pdpStatus);
      return;
    }
    
    setFileToDelete(identifier);
    setDeleteModalOpen(true);
  };

  const confirmFileDelete = async () => {
    if (!fileToDelete) return;

    // ⭐ NEW: Double-check edit permission before deleting
    if (!canEdit) {
      alert(`Cannot delete. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      setDeleteModalOpen(false);
      setFileToDelete(null);
      return;
    }

    try {
      const recordId = parseInt(fileToDelete.split('-')[1]);
      
      await deletePdpMarcomSupdoc(recordId);
      
      const updatedData = [...brandingData];
      const recordIdx = updatedData.findIndex(item => item.id === recordId);
      
      if (recordIdx !== -1) {
        updatedData[recordIdx].supportiveDocUrl = null;
        updatedData[recordIdx].documentName = "";
        setBrandingData(updatedData);
      }
      
      setSaveSuccess(true);
    } catch (error) {
      console.error("❌ Delete error:", error);
      alert(`Failed to delete: ${error.message}`);
    } finally {
      setDeleteModalOpen(false);
      setFileToDelete(null);
    }
  };
  const [hoveredCell,setHoveredCell] = useState()
const [sortKey, setSortKey] = useState(null);
    const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"
    const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};
 const handleSaveData = async () => {
    // ⭐ NEW: Double-check edit permission before saving
    if (!canEdit) {
      alert(`Cannot save. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      return;
    }

    setSaveError(null);
    setSaveSuccess(false);
    setIsSaving(true);

    try {
      if (activeView === "branding") {
        const recordsToUpdate = brandingData.map(item => ({
          id: item.id,
          budget: item.budget,
          remarks: item.remarks
        }));

        console.log("💾 Saving branding data:", recordsToUpdate);
        
        await updateMultiplePdpMarcomBranding(recordsToUpdate);
        
        console.log("✅ Branding data saved successfully");
      } else {
        const recordsToUpdate = marketingData.map(item => ({
          id: item.id,
          marketing_area: item.marketingArea,
          count_of_activities: item.countOfActivities,
          activity_description: item.activityDescription,
          amount_spent: item.amountSpent,
          impacts: item.impacts
        }));

        console.log("💾 Saving marketing data:", recordsToUpdate);
        
        await updateMultiplePdpMarcomMarketing(recordsToUpdate);
        
        console.log("✅ Marketing data saved successfully");
      }

      setSaveSuccess(true);
      
      const updatedData = activeView === "branding" 
        ? await getPdpMarcomBrandingByPdpId(pdpId)
        : await getPdpMarcomMarketingByPdpId(pdpId);
      
      if (activeView === "branding") {
        setBrandingData(updatedData);
      } else {
        setMarketingData(updatedData);
      }
      
    } catch (error) {
      console.error("❌ Save error:", error);
      setSaveError(error.message || "Failed to save data. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDownload = () => {
    if (!filteredData.length) return alert("No data to download!");

    const rows = [];

    if (activeView === "branding") {
      rows.push(["Year", "Marcom Master", "Branding Element", "Budget", "Remarks", "Supportive Document"]);

      filteredData.forEach(item => {
        rows.push([
          item.year || "",
          item.marcomType || "",
          item.marcomName || "",
          item.budget || "",
          item.remarks || "",
          item.documentName || "",
        ]);
      });
    } else {
      rows.push([
        "Year",
        "Activity Type",
        "Marketing Area",
        "Target",
        "Count of Activities",
        "Activity Description",
        "Amount Spent",
        "Impacts / Comments",
      ]);

      filteredData.forEach(item => {
        rows.push([
          item.year || "",
          item.activityType || "",
          item.marketingArea || "",
          item.target || "",
          item.countOfActivities || "",
          item.activityDescription || "",
          item.amountSpent || "",
          item.impacts || "",
        ]);
      });
    }

    const worksheet = XLSX.utils.aoa_to_sheet(rows);

    const colWidths = rows[0].map((col, idx) => ({
      wch: Math.max(
        col.toString().length,
        ...rows.slice(1).map(r => (r[idx] ? r[idx].toString().length : 10))
      ) + 2,
    }));
    worksheet["!cols"] = colWidths;

    Object.keys(worksheet).forEach(cell => {
      if (!cell.startsWith("!")) {
        worksheet[cell].s = { alignment: { horizontal: "left", vertical: "center" } };
      }
    });

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, activeView === "branding" ? "Marcom_Branding" : "Marcom_Marketing");
    XLSX.writeFile(workbook, `${activeView === "branding" ? "Branding" : "Marketing"}_Preview.xlsx`);
  };

  // ═══════════════════════════════════════════════════════════════
  // RENDER BRANDING TABLE
  // ═══════════════════════════════════════════════════════════════
  const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const aVal = a[sortKey];
    const bVal = b[sortKey];

    if (aVal == null) return 1;
    if (bVal == null) return -1;

    // number sort
    if (!isNaN(aVal) && !isNaN(bVal)) {
      return sortOrder === "asc" ? aVal - bVal : bVal - aVal;
    }

    // string sort
    return sortOrder === "asc"
      ? String(aVal).localeCompare(String(bVal))
      : String(bVal).localeCompare(String(aVal));
  });
}, [filteredData, sortKey, sortOrder]);

  const renderBrandingTable = () => {
    if (sortedData.length === 0) {
      return (
        <tr>
          <td colSpan="6" className="text-center py-8 text-gray-500 italic">
            No data found.
          </td>
        </tr>
      );
    }

    // ⭐ Group data by Year and Marcom Master
    const groupedData = [];
    let currentGroup = null;

   sortedData.forEach((item) => {
      const groupKey = `${item.year}-${item.marcomType}`;
      
      if (!currentGroup || currentGroup.key !== groupKey) {
        currentGroup = {
          key: groupKey,
          year: item.year,
          marcomType: item.marcomType,
          items: [item]
        };
        groupedData.push(currentGroup);
      } else {
        currentGroup.items.push(item);
      }
    });

    // ⭐ Render grouped rows with rowspan
    const rows = [];
    let globalIdx = 0;

    groupedData.forEach((group) => {
      const rowSpan = group.items.length;
      
      group.items.forEach((item, itemIdx) => {
        const isFirstInGroup = itemIdx === 0;
        
        rows.push(
          <tr key={item.id} className={globalIdx % 2 === 0 ? "bg-white" : "bg-gray-50"}>
            {/* Year column - only show on first row of group */}
            {isFirstInGroup && (
              <td 
                rowSpan={rowSpan} 
                className="border border-grey2 border-t-0 border-l-0 px-3 py-2 text-left text-xs align-middle"
              >
                {group.year}
              </td>
            )}
            
            {/* Marcom Master column - only show on first row of group */}
{isFirstInGroup && (
  <td
  rowSpan={rowSpan}
  className="border border-grey2 border-t-0 border-l-0 px-3 py-2 text-xs align-middle max-w-[180px]"
>
  <div className="relative w-full">
    <p
      className="truncate w-full block cursor-pointer"
      onMouseEnter={() => {
        if (group.marcomType && group.marcomType.length > 15) {
          setHoveredCell(`marcom-${group.key}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {group.marcomType}
    </p>

    {hoveredCell === `marcom-${group.key}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
        {group.marcomType}
      </span>
    )}
  </div>
</td>
)}

            
            {/* Branding Elements - individual row */}
         <td className="border border-grey2 border-t-0 border-l-0 px-3 py-2 text-xs max-w-[180px]">
  <div className="relative w-full">
    <p
      className="truncate w-full block cursor-pointer"
      onMouseEnter={() => {
        if (item.marcomName && item.marcomName.length > 15) {
          setHoveredCell(`marcomName-${item.id}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.marcomName}
    </p>

    {hoveredCell === `marcomName-${item.id}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
        {item.marcomName}
      </span>
    )}
  </div>
</td>

            
            {/* Budget - individual row */}
            <td className="border border-grey2 border-t-0 border-l-0 px-3 py-2">
              {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
              {canEdit ? (
                <input
                  type="text"
                  value={item.budget}
                  onChange={(e) => {
                    const idx = filteredData.findIndex(d => d.id === item.id);
                    handleBrandingFieldChange(idx, "budget", e.target.value);
                  }}
                  className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1"
                  placeholder="Enter budget..."
                />
              ) : (
                <span className="text-xs">{item.budget || "—"}</span>
              )}
            </td>
            
            {/* Remarks - individual row */}
            <td className="border border-grey2 border-t-0 border-l-0 px-3 py-2">
  {canEdit ? (
    <textarea
      value={item.remarks}
      onChange={(e) => {
        const idx = filteredData.findIndex(d => d.id === item.id);
        handleBrandingFieldChange(idx, "remarks", e.target.value);
      }}
      className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1 resize-none"
      rows="2"
      placeholder="Enter remarks..."
    />
  ) : (
  <div className="relative w-full max-w-[180px]">
  <p
    className="truncate w-full block cursor-pointer"
    onMouseEnter={() => {
      if (item.remarks && item.remarks.length > 15) {
        setHoveredCell(`remarks-${item.id}`);
      }
    }}
    onMouseLeave={() => setHoveredCell(null)}
  >
    {item.remarks || "—"}
  </p>

  {hoveredCell === `remarks-${item.id}` && (
    <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
      {item.remarks}
    </span>
  )}
</div>
  )}
</td>

            {/* Supportive Document - individual row */}
           <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-2">
  {canEdit ? (
    item.documentName ? (
      <div className="relative">
        <p
          className="truncate max-w-[12rem] cursor-pointer"
          onMouseEnter={() => setHoveredCell(item.id + "-doc")}
          onMouseLeave={() => setHoveredCell(null)}
        >
          {item.documentName}
        </p>
        {hoveredCell === item.id + "-doc" && (
          <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
            {item.documentName}
          </span>
        )}
        <FileDisplay
          file={item}
          onDownload={() => handleFileDownload(item.supportiveDocUrl, item.documentName)}
          onDelete={() => openDeleteModal(`branding-${item.id}`)}
          onReplace={() => openUploadModal(`branding-${item.id}`, item.documentName)}
          canEdit={canEdit}
        />
      </div>
    ) : (
      <button
        onClick={() => openUploadModal(`branding-${item.id}`)}
        className="w-full px-3 py-1.5 bg-gray-100 border border-gray-300 rounded text-xs text-gray-700 hover:bg-gray-200 transition flex items-center justify-center gap-2"
      >
        <Upload size={14} />
        Upload Document
      </button>
    )
  ) : (
    item.documentName ? (
  <div className="relative w-full max-w-[180px]">
  <p
    className="truncate w-full block cursor-pointer"
    onMouseEnter={() => {
      if (item.documentName && item.documentName.length > 15) {
        setHoveredCell(`doc-${item.id}`);
      }
    }}
    onMouseLeave={() => setHoveredCell(null)}
  >
    {item.documentName}
  </p>

  {hoveredCell === `doc-${item.id}` && (
    <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
      {item.documentName}
    </span>
  )}

  {/* File actions below */}
  <div className="mt-1">
    <FileDisplay
      file={item}
      onDownload={() =>
        handleFileDownload(item.supportiveDocUrl, item.documentName)
      }
      canEdit={false}
    />
  </div>
</div>
    ) : (
      <span className="text-xs text-gray-400 italic">No document</span>
    )
  )}
</td>

          </tr>
        );
        
        globalIdx++;
      });
    });

    return rows;
  };

  // ═══════════════════════════════════════════════════════════════
  // RENDER MARKETING TABLE
  // ═══════════════════════════════════════════════════════════════
  const renderMarketingTable = () => {
    return sortedData.length > 0 ? (
      sortedData.map((item, idx) => (
        <tr key={item.id} className={idx % 2 === 0 ? "bg-white" : "bg-gray-50"}>
          <td className="border border-grey2 border-t-0 border-l-0 px-3 py-2 text-left text-xs">{item.year}</td>
<td className="border border-grey2 border-t-0 border-l-0 px-3 py-2 text-xs">
 <div className="relative w-full max-w-[200px]">
  <p
    className="truncate w-full block cursor-pointer"
    onMouseEnter={() => {
      if (item.activityType && item.activityType.length > 20) {
        setHoveredCell(`activity-${item.id}`);
      }
    }}
    onMouseLeave={() => setHoveredCell(null)}
  >
    {item.activityType || "—"}
  </p>

  {hoveredCell === `activity-${item.id}` && (
    <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
      {item.activityType}
    </span>
  )}
</div>
</td>
         <td className="border border-grey2 border-t-0 border-l-0 px-3 py-2 text-xs">
  {canEdit ? (
    <SingleSelectFilter
      name="marketingArea"
      value={item.marketingArea || ""}
      options={MARKETING_AREAS}
      onChange={(name, value) => handleMarketingFieldChange(idx, "marketingArea", value)}
      placeholder="Select Area"
      customWidth="w-full"
      placeholderColor="text-gray-500"
      buttonBorderColor="border-gray-300"
      dropdownBgColor="bg-white"
      dropdownTextColor="text-black"
      dropdownHoverColor="hover:bg-gray-100"
      dropdownBorderColor="border-gray-300"
      textColor="text-black"
    />
  ) : (
    <div className="relative">
      <p
        className="truncate max-w-[20rem] cursor-pointer"
        onMouseEnter={() => {
          if (item.marketingArea && item.marketingArea.length > 20)
            setHoveredCell(item.id + "-marketingArea");
        }}
        onMouseLeave={() => setHoveredCell(null)}
      >
        {item.marketingArea || "—"}
      </p>

      {hoveredCell === item.id + "-marketingArea" && (
        <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
          {item.marketingArea}
        </span>
      )}
    </div>
  )}
</td>


<td className="border border-grey2 border-t-0 border-l-0 px-3 py-2 text-xs max-w-[180px]">
  <div className="relative w-full">
    <p
      className="truncate w-full block cursor-pointer"
      onMouseEnter={() => {
        if (item.target && item.target.length > 15) {
          setHoveredCell(`target-${item.id}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.target || "—"}
    </p>

    {hoveredCell === `target-${item.id}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
        {item.target}
      </span>
    )}
  </div>
</td>
          
         <td className="border border-grey2 border-t-0 border-l-0 px-3 py-2 text-xs">
  {canEdit ? (
   <input
  type="text"
  inputMode="numeric"
  value={item.countOfActivities}
  placeholder="0"
  onChange={(e) => {
    const value = e.target.value;

    if (/^\d*$/.test(value)) {
      handleMarketingFieldChange(idx, "countOfActivities", value);
    }
  }}
  className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1"
/>
  ) : (
   <div className="relative w-full max-w-[100px]">
  <p
    className="truncate w-full block cursor-pointer"
    onMouseEnter={() => {
      if (item.countOfActivities && String(item.countOfActivities).length > 8) {
        setHoveredCell(`count-${item.id}`);
      }
    }}
    onMouseLeave={() => setHoveredCell(null)}
  >
    {item.countOfActivities || "—"}
  </p>

  {hoveredCell === `count-${item.id}` && (
    <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
      {item.countOfActivities}
    </span>
  )}
</div>
  )}
</td>

          
        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-2 text-xs">
  {canEdit ? (
    <textarea
      value={item.activityDescription}
      onChange={(e) => handleMarketingFieldChange(idx, "activityDescription", e.target.value)}
      className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1 resize-none"
      rows="2"
      placeholder="Enter description..."
    />
  ) : (
 <div className="relative w-full max-w-[200px]">
  <p
    className="truncate w-full block cursor-pointer"
    onMouseEnter={() => {
      if (item.activityDescription && item.activityDescription.length > 20) {
        setHoveredCell(`desc-${item.id}`);
      }
    }}
    onMouseLeave={() => setHoveredCell(null)}
  >
    {item.activityDescription || "—"}
  </p>

  {hoveredCell === `desc-${item.id}` && (
    <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
      {item.activityDescription}
    </span>
  )}
</div>
  )}
</td>

          <td className="border border-grey2 border-t-0 border-l-0 px-3 py-2">
            {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
            {canEdit ? (
            <input
  type="text"
  inputMode="decimal"
  value={item.amountSpent}
  placeholder="0"
  onChange={(e) => {
    const value = e.target.value;

    if (/^\d*\.?\d*$/.test(value)) {
      handleMarketingFieldChange(idx, "amountSpent", value);
    }
  }}
  className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1"
/>
            ) : (
              <span className="text-xs">{item.amountSpent || "—"}</span>
            )}
          </td>
          
         <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-2 text-xs">
  {canEdit ? (
    <textarea
      value={item.impacts}
      onChange={(e) => handleMarketingFieldChange(idx, "impacts", e.target.value)}
      className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-darkblue1 resize-none"
      rows="2"
      placeholder="Enter comments..."
    />
  ) : (
 <div className="relative w-full max-w-[200px]">
  <p
    className="truncate w-full block cursor-pointer"
    onMouseEnter={() => {
      if (item.impacts && item.impacts.length > 20) {
        setHoveredCell(`impact-${item.id}`);
      }
    }}
    onMouseLeave={() => setHoveredCell(null)}
  >
    {item.impacts || "—"}
  </p>

  {hoveredCell === `impact-${item.id}` && (
    <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-50 shadow-lg">
      {item.impacts}
    </span>
  )}
</div>
  )}
</td>

        </tr>
      ))
    ) : (
      <tr>
        <td colSpan="8" className="text-center py-8 text-gray-500 italic">
          No data found.
        </td>
      </tr>
    );
  };

  // ═══════════════════════════════════════════════════════════════
  // LOADING STATE
  // ═══════════════════════════════════════════════════════════════
  if (isLoading) {
    return (
      <div className="w-full h-64 flex items-center justify-center bg-white border-2 border-Dustyblue rounded">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-darkblue1 mx-auto mb-4"></div>
          <p className="text-gray-600 font-medium">Loading Marcom data...</p>
          <p className="text-gray-500 text-sm mt-2">Year: {selectedyear}</p>
        </div>
      </div>
    );
  }
 
    
  // ═══════════════════════════════════════════════════════════════
  // MAIN RENDER
  // ═══════════════════════════════════════════════════════════════
  
  return (
    <div className="w-full space-y-3">
      <FileUploadModal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        onUpload={handleFileUpload}
        currentFile={currentUploadFile}
        identifier={currentUploadIdentifier}
      />

      <DeleteModal
        isOpen={deleteModalOpen}
        onClose={() => {
          setDeleteModalOpen(false);
          setFileToDelete(null);
        }}
        onConfirm={confirmFileDelete}
        title="Delete Document"
        message="Are you sure you want to delete this document? This action cannot be undone."
      />

      {/* ⭐ NEW: Status Lock Banner - Shows when dealer cannot edit due to status */}
      {/* {isStatusLocked && (
        <div className="bg-amber-50 border border-amber-300 rounded-lg p-3 flex items-start gap-3">
          <div className="flex-shrink-0 mt-0.5">
            <Lock size={20} className="text-amber-600" />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-amber-800 mb-1">
              Editing Disabled
            </h4>
            <p className="text-xs text-amber-700">
              This PDP is in <span className="font-bold">{pdpStatus}</span> status. 
              Data can only be edited when status is <span className="font-semibold">"Created"</span> or <span className="font-semibold">"Started"</span>.
            </p>
            <p className="text-xs text-amber-600 mt-1">
              {pdpStatus === "Pending Review" && "The PDP is awaiting admin approval."}
              {pdpStatus === "Approved" && "The PDP has been approved and is now read-only."}
              {pdpStatus === "Completed" && "The PDP has been completed and finalized."}
            </p>
          </div>
        </div>
      )} */}

      {saveSuccess && (
        <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded flex items-center gap-2 animate-fade-in">
          <AlertCircle size={18} />
          <span className="text-sm font-medium">Data saved successfully!</span>
        </div>
      )}

      {saveError && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded flex items-center gap-2 animate-fade-in">
          <AlertCircle size={18} />
          <span className="text-sm font-medium">{saveError}</span>
        </div>
      )}

      {/* ⭐ NEW: Status Badge */}
      <div className="flex items-center justify-between">
        <div className="flex w-full overflow-x-auto shadow-sm">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveView(tab.id)}
              className={`flex-1 min-w-[120px] py-2 px-4 text-sm font-medium transition whitespace-nowrap ${
                activeView === tab.id
                  ? "bg-darkblue1 text-white shadow-md"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        
        {/* Status Badge */}
        <div className={`ml-4 shadow-sm px-3 py-1.5 flex items-center justify-center gap-2 border rounded ${getStatusBadgeColor(pdpStatus)}`}>
          {isStatusLocked && <Lock size={14} />}
          <span className="w-2 h-2 bg-current rounded-full inline-block opacity-60"></span>
          <span className="text-xs font-medium whitespace-nowrap">{pdpStatus}</span>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="w-full sm:w-auto">
          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search"
            className="w-[1/2]"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            focusRing="focus:ring-black/60"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            iconColor="text-black"
          />
        </div>

        <button
          onClick={handleDownload}
          disabled={filteredData.length === 0}
          className="bg-darkblue1 text-xs font-medium text-white px-5 py-1.5 hover:bg-darkblue1/90 transition flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
        >
          <Download size={16} />
          Download
        </button>
      </div>

     <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
          <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
               maxHeight: filteredData.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >
            <table className="w-full text-xs table-fixed min-w-[350px] lg:min-w-full">
              <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
              <tr>
                {activeView === "branding" ? (
                  <>
  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs font-normal tracking-wide w-[8%] cursor-pointer select-none"
    onClick={() => handleSort("year")}
  >
    <div className="flex items-center gap-1">
      Year
      {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
      {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs font-normal tracking-wide w-[25%] cursor-pointer select-none"
    onClick={() => handleSort("marcomType")}
  >
    <div className="flex items-center gap-1">
      Marcom Master
      {sortKey === "marcomType" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "marcomType" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs font-normal tracking-wide w-[20%] cursor-pointer select-none"
    onClick={() => handleSort("marcomName")}
  >
    <div className="flex items-center gap-1">
      Branding Elements
      {sortKey === "marcomName" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "marcomName" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs font-normal tracking-wide w-[12%] cursor-pointer select-none"
    onClick={() => handleSort("budget")}
  >
    <div className="flex items-center gap-1">
      Budget in Lakhs
      {sortKey === "budget" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "budget" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs font-normal tracking-wide w-[15%] cursor-pointer select-none"
    onClick={() => handleSort("remarks")}
  >
    <div className="flex items-center gap-1">
      Remarks
      {sortKey === "remarks" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "remarks" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>


  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs text-xs font-normal tracking-wide w-[15%] cursor-pointer select-none"
    onClick={() => handleSort("supportivedocument")}
  >
    <div className="flex items-center gap-1">
      Supportive Document
      {sortKey === "supportivedocument" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "supportivedocument" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>
</>

                ) : (
                  <>
                    <>
  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs text-xs font-normal w-[8%] cursor-pointer select-none"
    onClick={() => handleSort("year")}
  >
    <div className="flex items-center gap-1">
      Year
      {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
      {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs text-xs font-normal  w-[25%] cursor-pointer select-none"
    onClick={() => handleSort("activityType")}
  >
    <div className="flex items-center gap-1">
      Activity Type
      {sortKey === "activityType" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "activityType" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs text-xs font-normal  w-[25%] cursor-pointer select-none"
    onClick={() => handleSort("marketingArea")}
  >
    <div className="flex items-center gap-1">
      Marketing Area
      {sortKey === "marketingArea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "marketingArea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs font-normal w-[25%] cursor-pointer select-none"
    onClick={() => handleSort("target")}
  >
    <div className="flex items-center gap-1">
      Target
      {sortKey === "target" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "target" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs font-normal  w-[10%] cursor-pointer select-none"
    onClick={() => handleSort("countOfActivities")}
  >
    <div className="flex items-center gap-1">
      Count of Activities
      {sortKey === "countOfActivities" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "countOfActivities" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs font-normal   w-[18%] cursor-pointer select-none"
    onClick={() => handleSort("activityDescription")}
  >
    <div className="flex items-center gap-1">
      Activity Description
      {sortKey === "activityDescription" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "activityDescription" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  <th
    className="border border-grey2 border-t-0 border-l-0 px-3 py-1.5 text-xs font-normal  w-[10%] cursor-pointer select-none"
    onClick={() => handleSort("amountSpent")}
  >
    <div className="flex items-center gap-1">
      Amount Spent
      {sortKey === "amountSpent" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "amountSpent" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

 <th
  className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1.5 text-xs font-normal w-[20%] cursor-pointer select-none"
  onClick={() => handleSort("impacts")}
>
  <div className="flex items-center gap-1">
    Impacts / Comments
    {sortKey === "impacts" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "impacts" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

</>
                 </>
                )}
              </tr>
            </thead>
            <tbody>
              {activeView === "branding" ? renderBrandingTable() : renderMarketingTable()}
            </tbody>
          </table>
        </div>
         {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}


        {/* Mobile View */}
        <div className="lg:hidden p-4 space-y-4">
          {filteredData.length > 0 ? (
            filteredData.map((item, idx) => (
              <div key={item.id} className="border border-gray-200 rounded-lg p-4 bg-white shadow-sm">
                {activeView === "branding" ? (
                  <div className="space-y-3 text-sm">
                    <div>
                      <span className="font-semibold text-darkblue1 block mb-1">Marcom Master:</span>
                      <div className="text-gray-700">{item.marcomType}</div>
                    </div>
                    <div>
                      <span className="font-semibold text-darkblue1 block mb-1">Branding Elements:</span>
                      <div className="text-gray-700">{item.marcomName}</div>
                    </div>
                    {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                    {canEdit && (
                      <>
                        <div>
                          <span className="font-semibold text-darkblue1 block mb-1">Budget in Lakhs:</span>
                          <input
                            type="text"
                            value={item.budget}
                            onChange={(e) => handleBrandingFieldChange(idx, "budget", e.target.value)}
                            placeholder="Enter budget"
                            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-darkblue1"
                          />
                        </div>
                        <div>
                          <span className="font-semibold text-darkblue1 block mb-1">Remarks:</span>
                          <textarea
                            value={item.remarks}
                            onChange={(e) => handleBrandingFieldChange(idx, "remarks", e.target.value)}
                            placeholder="Enter remarks"
                            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-darkblue1 resize-none"
                            rows="3"
                          />
                        </div>
                        <div>
                          <span className="font-semibold text-darkblue1 block mb-1">Supportive Document:</span>
                          {item.documentName ? (
                            <FileDisplay
                              file={item}
                              onDownload={() => handleFileDownload(item.supportiveDocUrl, item.documentName)}
                              onDelete={() => openDeleteModal(`branding-${item.id}`)}
                              onReplace={() => openUploadModal(`branding-${item.id}`, item.documentName)}
                              canEdit={canEdit}
                            />
                          ) : (
                            <button
                              onClick={() => openUploadModal(`branding-${item.id}`)}
                              className="w-full px-4 py-2.5 bg-gray-100 border border-gray-300 rounded text-sm font-medium text-gray-700 hover:bg-gray-200 transition flex items-center justify-center gap-2"
                            >
                              <Upload size={16} />
                              Upload Document
                            </button>
                          )}
                        </div>
                      </>
                    )}
                    {/* ⭐ FIXED: Show read-only view when canEdit is false */}
                    {!canEdit && (
                      <>
                        <div>
                          <span className="font-semibold text-darkblue1">Budget:</span> {item.budget || "—"}
                        </div>
                        <div>
                          <span className="font-semibold text-darkblue1">Remarks:</span> {item.remarks || "—"}
                        </div>
                        {item.documentName && (
                          <FileDisplay
                            file={item}
                            onDownload={() => handleFileDownload(item.supportiveDocUrl, item.documentName)}
                            onDelete={() => {}}
                            onReplace={() => {}}
                            canEdit={false}
                          />
                        )}
                      </>
                    )}
                  </div>
                ) : (
                  <div className="space-y-3 text-sm">
                    <div>
                      <span className="font-semibold text-darkblue1 block mb-1">Activity Type:</span>
                      <div className="text-gray-700">{item.activityType}</div>
                    </div>
                    
                    <div>
                      <span className="font-semibold text-darkblue1 block mb-1">Marketing Area:</span>
                      {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                      {canEdit ? (
                        <SingleSelectFilter
                          name="marketingArea"
                          value={item.marketingArea || ""}
                          options={MARKETING_AREAS}
                          onChange={(name, value) => handleMarketingFieldChange(idx, "marketingArea", value)}
                          placeholder="Select Marketing Area"
                          customWidth="w-full"
                          placeholderColor="text-gray-500"
                          buttonBorderColor="border-gray-300"
                          dropdownBgColor="bg-white"
                          dropdownTextColor="text-black"
                          dropdownHoverColor="hover:bg-gray-100"
                          dropdownBorderColor="border-gray-300"
                          textColor="text-black"
                        />
                      ) : (
                        <div className="text-gray-700">{item.marketingArea || "—"}</div>
                      )}
                    </div>
                    
                    <div>
                      <span className="font-semibold text-darkblue1 block mb-1">Target:</span>
                      <div className="text-gray-700">{item.target || "—"}</div>
                    </div>
                    
                    {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                    {canEdit && (
                      <>
                        <div>
                          <span className="font-semibold text-darkblue1 block mb-1">Count of Activities:</span>
                          <input
                            type="text"
                            value={item.countOfActivities}
                            onChange={(e) => handleMarketingFieldChange(idx, "countOfActivities", e.target.value)}
                            placeholder="Enter count"
                            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-darkblue1"
                          />
                        </div>
                        
                        <div>
                          <span className="font-semibold text-darkblue1 block mb-1">Activity Description:</span>
                          <textarea
                            value={item.activityDescription}
                            onChange={(e) => handleMarketingFieldChange(idx, "activityDescription", e.target.value)}
                            placeholder="Enter description"
                            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-darkblue1 resize-none"
                            rows="3"
                          />
                        </div>
                        
                        <div>
                          <span className="font-semibold text-darkblue1 block mb-1">Amount Spent:</span>
                          <input
                            type="text"
                            value={item.amountSpent}
                            onChange={(e) => handleMarketingFieldChange(idx, "amountSpent", e.target.value)}
                            placeholder="Enter amount"
                            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-darkblue1"
                          />
                        </div>
                        
                        <div>
                          <span className="font-semibold text-darkblue1 block mb-1">Impacts / Comments:</span>
                          <textarea
                            value={item.impacts}
                            onChange={(e) => handleMarketingFieldChange(idx, "impacts", e.target.value)}
                            placeholder="Enter comments"
                            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-darkblue1 resize-none"
                            rows="3"
                          />
                        </div>
                      </>
                    )}
                    
                    {/* ⭐ FIXED: Show read-only view when canEdit is false */}
                    {!canEdit && (
                      <>
                        <div>
                          <span className="font-semibold text-darkblue1">Count:</span> {item.countOfActivities || "—"}
                        </div>
                        <div>
                          <span className="font-semibold text-darkblue1">Description:</span> {item.activityDescription || "—"}
                        </div>
                        <div>
                          <span className="font-semibold text-darkblue1">Amount:</span> {item.amountSpent || "—"}
                        </div>
                        <div>
                          <span className="font-semibold text-darkblue1">Comments:</span> {item.impacts || "—"}
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="text-center text-gray-500 py-8">
              No data found.
            </div>
          )}
        </div>
      </div>

      {/* ⭐ FIXED: Only show Save button when canEdit is true */}
      {canEdit && (
        <div className="flex justify-end pt-2">
          <button
            onClick={handleSaveData}
            disabled={isSaving}
            className={`text-white px-6 py-2 text-sm font-medium rounded transition-all duration-200 flex items-center gap-2 shadow-sm ${
              isSaving 
                ? "bg-gray-400 cursor-not-allowed" 
                : "bg-darkblue1 hover:bg-darkblue1/90 hover:shadow-md"
            }`}
          >
            <Save size={16} />
            {isSaving ? "Saving..." : "Save Data"}
          </button>
        </div>
      )}
    </div>
  );
}