import React, { useState } from "react";
import Header from "../../../../Components/Header";
import { useNavigate } from "react-router-dom";
import DownloadCard from "../../../../Components/DownloadCard";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "react-router-dom";
function DownloadPDPdetails() {
    const location = useLocation();

  const activeTab = location.state?.activeTab || "";

  const navigate =useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const handleBack = () =>{
  navigate("/pdp/viewdetails", { state: { activeTab } });
  }

  return (
       <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className="flex justify-center">
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">

                  
                    <div className="flex flex-col mb-4">
              <div className="flex items-center gap-2">
                <ArrowLeft
                  onClick={handleBack}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1  p-1"
                />
                <h2 className="text-base font-semibold font-VolvoNovum text-darkblue1">
                 PDP Report Downloads
                </h2>
              </div>
              <div className="hidden lg:block h-1 bg-darkblue1 w-[4%] mt-0 ml-[2.7%]"></div>
            </div>

             <div className="w-[75%] items-center mx-auto">   
                  {/* Row 1 */}
<div className="flex flex-col md:flex-row gap-4 mb-6">
  <div className="bg-white  shadow-[0_4px_10px_#00000040] p-6 flex-1 flex flex-col justify-center space-y-6">
    <h1 className="ml-2 font-VolvoNovum text-base font-medium text-darkblue1 ">
      Summary
    </h1>
    
    <DownloadCard
      description="Download the Business Results, Uptime & Parts, and Others Sign-off PDF below."
      fileName="PDP - 2022 SIGN OFF SHEET.pdf"
    />
  </div>

  <div className="bg-white shadow-[0_4px_10px_#00000040] p-6 flex-1 flex flex-col  justify-center space-y-6">
    <h1 className="ml-2 font-VolvoNovum text-base font-medium text-mildBlue ">
      Uptime & Parts
    </h1>

    <DownloadCard
      description="Download PDP Uptime & Parts for 2022-ACT below."
      fileName="PDP Uptime and Parts for 2022-ACT.xls"
    />
  </div>
</div>

{/* Row 2 */}
<div className="flex flex-col md:flex-row gap-4 mb-6">
  <div className="bg-white shadow-[0_4px_10px_#00000040] p-6 flex-1 flex flex-col justify-center space-y-6">
    <h1 className="ml-2 font-VolvoNovum text-base font-medium text-mildBlue">
      Business Results
    </h1>
    <DownloadCard
      description="Download PDP Business Results for 2022-ACT below."
      fileName="PDP Business Results for 2022-ACT.xls"
    />
    <DownloadCard
      description="Download PDP EAAS for 2022-ACT below."
      fileName="PDP Equipment As Service for 2022-ACT.xls"
    />
  </div>

  <div className="bg-white  shadow-[0_4px_10px_#00000040] p-6 flex-1 flex flex-col justify-center space-y-6">
    <h1 className="ml-2 font-VolvoNovum text-base font-medium text-mildBlue ">
      Key Accounts Management (KA)
    </h1>
    <DownloadCard
      description="Download PDP Equipment Sales (KA) for 2022-ACT below."
      fileName="PDP EquipmentSales (KA) for 2022-ACT.xlsx"
    />
    <DownloadCard
      description="Download PDP Uptime & Parts Attachment Sales (KA) for 2022-ACT below."
      fileName="PDP Uptime and Parts Attachments Sales (KA) for 2022-ACT.xlsx"
    />
  </div>
</div>

{/* Row 3 */}
<div className="flex flex-col md:flex-row gap-4 mb-6">
  <div className="bg-white shadow-[0_4px_10px_#00000040] p-6 flex-1 flex flex-col justify-center space-y-6">
    <h1 className="ml-2 font-VolvoNovum text-base font-medium text-darkblue1 ">
      Infrastructure
    </h1>
    <DownloadCard
      description="Download PDP Infrastructure for 2022-ACT below."
      fileName="PDP Infrastructure for 2022-ACT.xlsx"
    />
  </div>

  <div className="bg-white  shadow-[0_4px_10px_#00000040] p-6 flex-1 flex flex-col justify-center space-y-6">
    <h1 className="ml-2 font-VolvoNovum text-base font-medium text-mildBlue ">
      Territory Focus
    </h1>
    <DownloadCard
      description="Download PDP Territory Focus for 2022-ACT below."
      fileName="PDP Territory Focus for 2022-ACT.pdf"
    />
  </div>
</div>

{/* Row 4 */}
<div className="flex flex-col md:flex-row gap-4 mb-14">
  <div className="bg-white shadow-[0_4px_10px_#00000040] p-6 flex-1 flex flex-col justify-center space-y-6">
    <h1 className="ml-2 font-VolvoNovum text-base font-medium text-darkblue1 ">
      Competence Development
    </h1>
    <DownloadCard
      description="Download PDP Competence Development for 2022-ACT below."
      fileName="PDP Competence Development for 2022-ACT.xlsx"
    />
  </div>

  <div className="bg-white  shadow-[0_4px_10px_#00000040] p-6 flex-1 flex flex-col justify-center space-y-6">
    <h1 className="ml-2 font-VolvoNovum text-base font-medium text-mildBlue">
      Marcom
    </h1>
    <DownloadCard
      description="Download PDP Marcom for 2022-ACT below."
      fileName="PDP Marcom for 2022-ACT.xlsx"
    />
  </div>
</div>
</div>    
         </div>
      </div>
    </div>
  );
}

export default DownloadPDPdetails;
