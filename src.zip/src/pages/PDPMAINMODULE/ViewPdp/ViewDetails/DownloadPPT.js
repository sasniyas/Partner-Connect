import React, { useState, useEffect } from "react";
import { getDeafultPreTemplate } from "../../../../services/pdpMaster/presentationTemplate.service";

const DownloadPPT = ({ isOpen, onClose }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [templateUrl, setTemplateUrl] = useState("");
  const [error, setError] = useState("");

  // Fetch template when popup opens
  useEffect(() => {
    if (isOpen) {
      fetchTemplate();
    }
  }, [isOpen]);

  const fetchTemplate = async () => {
    try {
      setIsLoading(true);
      setError("");
      const data = await getDeafultPreTemplate();
      setTemplateUrl(data?.url || "");
    } catch (err) {
      console.error("Error fetching template:", err);
      setError(err.message || "Failed to fetch template");
      setTemplateUrl("");
    } finally {
      setIsLoading(false);
    }
  };

  // Extract filename from URL
  const getFileName = (url) => {
    if (!url) return "PDP_Template.pptx";
    try {
      const urlParts = url.split("/");
      const fileName = urlParts[urlParts.length - 1];
      return decodeURIComponent(fileName.split("?")[0]) || "PDP_Template.pptx";
    } catch {
      return "PDP_Template.pptx";
    }
  };

  // Handle download
  const handleDownload = () => {
    if (templateUrl) {
      window.open(templateUrl, "_blank");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg w-[90%] max-w-md p-10 relative animate-fadeIn">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 hover:scale-110 transition"
          aria-label="Close Popup"
        >
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
            alt="close"
            className="w-4 h-4"
          />
        </button>

        {/* Title */}
        <h2 className="text-base font-medium text-MediumGrey">Download PPT Template</h2>
        <div className="hidden lg:block h-0.5 bg-darkblue1 w-[10%] mt-0 ml-0 mb-4"></div>

        {/* Content */}
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
            <span className="ml-3 text-sm text-gray-600">Loading template...</span>
          </div>
        ) : error ? (
          <div className="text-center py-6">
            <p className="text-red-500 text-sm mb-4">{error}</p>
            <button
              onClick={fetchTemplate}
              className="px-4 py-2 bg-darkblue1 text-white text-xs font-medium hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
            >
              Retry
            </button>
          </div>
        ) : templateUrl ? (
          <div className="border border-gray-200 rounded-lg p-4">
            <p className="text-sm text-gray-600 mb-4">Download the PPT template below.</p>
            
            {/* File Info */}
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded mb-4">
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/download.png"
                alt="file"
                className="w-6 h-6"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-800 truncate">
                  {getFileName(templateUrl)}
                </p>
                <p className="text-xs text-gray-500">PPT Template</p>
              </div>
            </div>

            {/* Download Button */}
            <button
              onClick={handleDownload}
              className="w-full flex items-center justify-center gap-2 bg-darkblue1 text-white px-4 py-2 text-sm font-medium hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
            >
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpmasterHomepage/download1.png"
                alt="download"
                className="w-4 h-4"
              />
              Download Template
            </button>
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-gray-500 text-sm italic">No template uploaded yet.</p>
            <p className="text-xs text-gray-400 mt-2">
              Please upload a template from PDP Master settings.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default DownloadPPT;