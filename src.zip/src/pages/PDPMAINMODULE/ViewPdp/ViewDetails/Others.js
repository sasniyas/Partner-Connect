import React, { useState, useEffect } from "react";
import { Upload, Trash2 } from "lucide-react";
import DeleteModal from "../../../../Components/DeleteModal";
import { 
  getPdpOthersByPdpId, 
  updatePdpOthers, 
  deletePdpOthers 
} from "../../../../services/PDP/Others/others.service";
import { useMemo } from "react";
import { ChevronDown } from "lucide-react";
import { ChevronUp,ChevronsUpDown  } from "lucide-react";
export default function Others({ rowData, userRole, onDataReady }) {
  const [filesData, setFilesData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [uploadingIndex, setUploadingIndex] = useState(null);
  const [notification, setNotification] = useState({ show: false, message: "", type: "" });
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"
  // Delete Modal state
    const [hoveredCell,setHoveredCell] = useState (null)

  const [deleteIndex, setDeleteIndex] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};
const sortedFiles = useMemo(() => {
  if (!sortKey || !sortOrder) return filesData;

  return [...filesData].sort((a, b) => {
    let valA, valB;

    // Map the sort key to actual object values
    if (sortKey === "file_name") {
      valA = a.fileName.toLowerCase();
      valB = b.fileName.toLowerCase();
    } else if (sortKey === "optional_document") {
      valA = a.optionalDoc?.name?.toLowerCase() || "";
      valB = b.optionalDoc?.name?.toLowerCase() || "";
    } else {
      valA = "";
      valB = "";
    }

    if (valA < valB) return sortOrder === "asc" ? -1 : 1;
    if (valA > valB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [filesData, sortKey, sortOrder]);


  // Show notification function
  const showNotification = (message, type = "success") => {
    setNotification({ show: true, message, type });
    setTimeout(() => {
      setNotification({ show: false, message: "", type: "" });
    }, 3000);
  };

  const fetchPdpOthers = async () => {
    if (!rowData) {
      console.error("❌ rowData is null or undefined");
      return;
    }

    if (!rowData.id) {
      console.error("❌ PDP ID is missing from rowData");
      return;
    }

    try {
      setLoading(true);
      const data = await getPdpOthersByPdpId(rowData.id);

      // Transform API data to component format
      const transformedData = data.map(item => ({
        id: item.id,
        fileName: item.file_name || "Unknown Document",
        optionalDoc: item.optional_document_url 
          ? { 
              name: item.file_name || "Uploaded Document", 
              url: item.optional_document_url 
            }
          : null,
        othersId: item.othersId,
        pdpId: item.pdpId,
      }));

      setFilesData(transformedData);
    } catch (error) {
      console.error("❌ Failed to fetch PDP Others:", error.message);
      showNotification(`Error loading files: ${error.message}`, "error");
    } finally {
      setLoading(false);
    }
  };

  // ✅ Fetch PDP Others data on component mount
  useEffect(() => {
    fetchPdpOthers();
  }, [rowData]);

  // ✅ Notify parent component of data changes
  useEffect(() => {
    if (onDataReady) {
      onDataReady(filesData);
    }
  }, [filesData, onDataReady]);

  // ✅ Handle file upload
  const handleUpload = async (index, e) => {
    const selectedFile = e.target.files[0];
    if (!selectedFile) return;

    const fileItem = filesData[index];
    
    // Validate record ID
    if (!fileItem?.id) {
      console.error("❌ Cannot upload: Record ID missing");
      showNotification("Error: Cannot upload file. Record ID is missing.", "error");
      return;
    }

    // Validate file size (10MB limit)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (selectedFile.size > maxSize) {
      showNotification("File size exceeds 10MB limit.", "error");
      return;
    }

    try {
      setUploadingIndex(index);
      
      await updatePdpOthers(fileItem.id, selectedFile);

      // Refetch to get updated data from server
      const updatedData = await getPdpOthersByPdpId(rowData.id);
      
      const transformedData = updatedData.map(item => ({
        id: item.id,
        fileName: item.file_name || "Unknown Document",
        optionalDoc: item.optional_document_url 
          ? { 
              name: item.file_name || "Uploaded Document", 
              url: item.optional_document_url 
            }
          : null,
        othersId: item.othersId,
        pdpId: item.pdpId,
      }));
      
      setFilesData(transformedData);
      showNotification("File uploaded successfully!", "success");
    } catch (error) {
      console.error("❌ Upload failed:", error);
      showNotification(`Upload failed: ${error.message}`, "error");
    } finally {
      setUploadingIndex(null);
    }
  };

  // ✅ Delete entire PDP Others record
  const confirmDelete = async () => {
    if (deleteIndex === null) return;

    const fileItem = filesData[deleteIndex];

    if (!fileItem?.id) {
      console.error("❌ Cannot delete: Record ID missing");
      showNotification("Error: Cannot delete. Record ID is missing.", "error");
      return;
    }

    try {
      setDeleteLoading(true);
      
      await deletePdpOthers(fileItem.id);
      await fetchPdpOthers();
      
      showNotification("File deleted successfully!", "success");
    } catch (error) {
      console.error("❌ Delete failed:", error);
      showNotification(`Delete failed: ${error.message}`, "error");
    } finally {
      setDeleteLoading(false);
      setDeleteIndex(null);
      setModalOpen(false);
    }
  };

  // ✅ Open delete confirmation modal
  const openDeleteModal = (index) => {
    setDeleteIndex(index);
    setModalOpen(true);
  };

  // ✅ Open uploaded file in new tab
  const handleFileClick = (file) => {
    if (file?.url) {
      window.open(file.url, "_blank", "noopener,noreferrer");
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="w-full flex items-center justify-center py-10">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
        <span className="ml-3 text-sm text-gray-600">Loading files...</span>
      </div>
    );
  }

  // Empty state
  if (filesData.length === 0) {
    return (
      <div className="w-full flex flex-col items-center justify-center py-10">
        <p className="text-gray-500 italic mb-2">No documents available for this PDP.</p>
        <p className="text-xs text-gray-400">PDP ID: {rowData?.id || "Not found"}</p>
      </div>
    );
  }
  return (
    <div className="w-full relative">
      {/* Notification Toast */}
      {notification.show && (
        <div className={`fixed top-4 right-4 z-[9999] px-6 py-3 rounded-lg shadow-lg transform transition-all duration-300 ${
          notification.type === "success" 
            ? "bg-green-500 text-white" 
            : "bg-red-500 text-white"
        }`}>
          <div className="flex items-center gap-2">
            {notification.type === "success" ? (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
            ) : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            )}
            <span className="font-medium">{notification.message}</span>
          </div>
        </div>
      )}

      {/* Desktop Table View */}
      <div className="hidden md:block border border-Dustyblue">
        <table className="w-full text-xs border-collapse">
          <thead className="bg-Dustyblue text-white text-left">
            <tr>
             <th
  className="px-3 w-[40%] py-1.5 border border-grey2 border-t-0 border-b-0 border-l-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort("file_name")}
>
  <div className="flex items-center gap-1">
    File Name
    {sortKey !== "file_name" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
    {sortKey === "file_name" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "file_name" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

<th
  className="px-3 w-[40%] py-1.5 border border-grey2 border-t-0 border-b-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort("optional_document")}
>
  <div className="flex items-center gap-1">
    Optional Document
    {sortKey === "optional_document" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "optional_document" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

              <th className="px-3 w-[20%] text-center py-1.5 border border-grey2 border-t-0 border-b-0 border-r-0 font-medium">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {sortedFiles.map((file, idx) => (
              <tr key={file.id || idx} className="hover:bg-lightBlue/50">
                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (file.fileName && file.fileName.length > 50) setHoveredCell(file.id + "-fileName");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {file.fileName}
    </p>

    {hoveredCell === file.id + "-fileName" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {file.fileName}
      </span>
    )}
  </div>
</td>

<td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    {file.optionalDoc ? (
      <>
        <p
          className="truncate max-w-[12rem] cursor-pointer text-blue-600 hover:text-blue-800"
          onMouseEnter={() => {
            if (file.optionalDoc.name.length > 50) setHoveredCell(file.id + "-optionalDoc");
          }}
          onMouseLeave={() => setHoveredCell(null)}
          onClick={() => handleFileClick(file.optionalDoc)}
        >
          {file.optionalDoc.name}
        </p>

        {hoveredCell === file.id + "-optionalDoc" && (
          <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
            {file.optionalDoc.name}
          </span>
        )}
      </>
    ) : (
      <span className="text-gray-400 italic">No file uploaded</span>
    )}
  </div>
</td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                  <div className="flex items-center justify-center gap-2">
                    {/* Delete button - Only show if file exists */}
                    {file.optionalDoc && (
                      <div className="relative group">
                        <button
                          onClick={() => openDeleteModal(idx)}
                          className="w-6 h-6 flex items-center justify-center border border-red1 bg-white text-red1 transition hover:border-2 hover:border-red1"
                          aria-label="Delete file"
                        >
                         <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>
                        </button>
                        <span className="absolute left-1/2 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50 pointer-events-none">
                          Delete
                        </span>
                      </div>
                    )}

                    {/* Upload button */}
                    <label className="relative group cursor-pointer">
                      <div className="flex items-center justify-center w-6 h-6 border border-darkblue1 hover:border-2 hover:border-darkblue1 transition">
                        {uploadingIndex === idx ? (
                          <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-darkblue1"></div>
                        ) : (
                         <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 22 22" fill="none">
<path fill-rule="evenodd" clip-rule="evenodd" d="M11 2.75C11.1373 2.75009 11.2729 2.78102 11.3966 2.84052C11.5204 2.90002 11.6292 2.98656 11.715 3.09375L15.3817 7.67708C15.4614 7.77046 15.5216 7.8789 15.5586 7.99598C15.5956 8.11305 15.6087 8.23637 15.5972 8.35861C15.5856 8.48086 15.5496 8.59953 15.4913 8.70759C15.433 8.81566 15.3536 8.91091 15.2578 8.98769C15.1619 9.06447 15.0517 9.12121 14.9335 9.15456C14.8153 9.1879 14.6917 9.19716 14.5698 9.18179C14.448 9.16643 14.3305 9.12674 14.2243 9.06509C14.1181 9.00344 14.0254 8.92109 13.9517 8.82292L11.9167 6.27917V12.8333C11.9167 13.0764 11.8201 13.3096 11.6482 13.4815C11.4763 13.6534 11.2431 13.75 11 13.75C10.7569 13.75 10.5237 13.6534 10.3518 13.4815C10.1799 13.3096 10.0833 13.0764 10.0833 12.8333V6.27917L8.04833 8.82383C7.97458 8.92201 7.88186 9.00436 7.77567 9.06601C7.66948 9.12766 7.55199 9.16734 7.43017 9.18271C7.30834 9.19808 7.18468 9.18882 7.0665 9.15547C6.94833 9.12213 6.83806 9.06538 6.74224 8.9886C6.64642 8.91182 6.567 8.81657 6.5087 8.70851C6.45039 8.60045 6.4144 8.48177 6.40284 8.35953C6.39128 8.23729 6.4044 8.11397 6.44142 7.9969C6.47844 7.87982 6.5386 7.77138 6.61833 7.678L10.285 3.09467C10.3707 2.98731 10.4795 2.90059 10.6033 2.84093C10.727 2.78127 10.8626 2.7502 11 2.75ZM8.25 12.8333V11.9167H4.58333C4.0971 11.9167 3.63079 12.1098 3.28697 12.4536C2.94315 12.7975 2.75 13.2638 2.75 13.75V17.4167C2.75 17.9029 2.94315 18.3692 3.28697 18.713C3.63079 19.0568 4.0971 19.25 4.58333 19.25H17.4167C17.9029 19.25 18.3692 19.0568 18.713 18.713C19.0568 18.3692 19.25 17.9029 19.25 17.4167V13.75C19.25 13.2638 19.0568 12.7975 18.713 12.4536C18.3692 12.1098 17.9029 11.9167 17.4167 11.9167H13.75V12.8333C13.75 13.5627 13.4603 14.2622 12.9445 14.7779C12.4288 15.2936 11.7293 15.5833 11 15.5833C10.2707 15.5833 9.57118 15.2936 9.05546 14.7779C8.53973 14.2622 8.25 13.5627 8.25 12.8333ZM15.5833 14.6667C15.3402 14.6667 15.1071 14.7632 14.9352 14.9352C14.7632 15.1071 14.6667 15.3402 14.6667 15.5833C14.6667 15.8264 14.7632 16.0596 14.9352 16.2315C15.1071 16.4034 15.3402 16.5 15.5833 16.5H15.5925C15.8356 16.5 16.0688 16.4034 16.2407 16.2315C16.4126 16.0596 16.5092 15.8264 16.5092 15.5833C16.5092 15.3402 16.4126 15.1071 16.2407 14.9352C16.0688 14.7632 15.8356 14.6667 15.5925 14.6667H15.5833Z" fill="#1B365D"/>
</svg>
                        )}
                      </div>
                      <input
                        type="file"
                        className="hidden"
                        onChange={(e) => handleUpload(idx, e)}
                        disabled={uploadingIndex === idx}
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                      />
                      <span className="absolute left-1/2 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50 pointer-events-none">
                        Upload
                      </span>
                    </label>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-4 p-4">
        {filesData.map((file, idx) => (
          <div
            key={file.id || idx}
            className="bg-white shadow-md p-4 border border-gray-200 rounded"
          >
            <div className="flex justify-between mb-2">
              <span className="font-semibold text-sm text-darkblue1">File Name:</span>
              <span className="text-sm">{file.fileName}</span>
            </div>
            <div className="flex justify-between mb-3">
              <span className="font-semibold text-sm text-darkblue1">
                Optional Document:
              </span>
              {file.optionalDoc ? (
                <span
                  onClick={() => handleFileClick(file.optionalDoc)}
                  className="text-blue-600 underline hover:text-blue-800 cursor-pointer text-sm"
                >
                  {file.optionalDoc.name}
                </span>
              ) : (
                <span className="text-gray-400 italic text-sm">No file uploaded</span>
              )}
            </div>
            <div className="flex gap-2 justify-end">
              {/* Upload button */}
              <label className="relative group cursor-pointer">
                <div className="flex items-center justify-center w-8 h-8 border border-darkblue1 rounded hover:bg-darkblue1 hover:text-white transition">
                  {uploadingIndex === idx ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-darkblue1"></div>
                  ) : (
                    <Upload size={16} className="text-darkblue1 group-hover:text-white" />
                  )}
                </div>
                <input
                  type="file"
                  className="hidden"
                  onChange={(e) => handleUpload(idx, e)}
                  disabled={uploadingIndex === idx}
                  accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                />
                <span className="absolute left-1/2 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs px-2 py-1 rounded transition-opacity duration-200 whitespace-nowrap z-50 pointer-events-none">
                  Upload
                </span>
              </label>

              {/* Delete button */}
              {file.optionalDoc && (
                <div className="relative group">
                  <button
                    onClick={() => openDeleteModal(idx)}
                    className="w-8 h-8 flex items-center justify-center border border-red1 bg-red1 text-white rounded hover:bg-red-600 transition"
                    aria-label="Delete file"
                  >
                    <Trash2 size={16} />
                  </button>
                  <span className="absolute left-1/2 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs px-2 py-1 rounded transition-opacity duration-200 whitespace-nowrap z-50 pointer-events-none">
                    Delete
                  </span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Delete Confirmation Modal */}
      <DeleteModal
        isOpen={modalOpen}
        onClose={() => {
          setModalOpen(false);
          setDeleteIndex(null);
        }}
        onConfirm={confirmDelete}
        loading={deleteLoading}
        extraMessage="This will permanently delete this record from the database."
      />
    </div>
  );
}