import { AlertCircle,ArrowDown,ArrowUp,ChevronDown,ChevronUp,ChevronsUpDown,Download,Eye,Lock,Plus,Save,X } from "lucide-react";
import React, { useState, useEffect, useCallback, useRef } from "react";
import Searchinput from "../../../../Components/Searchinput";
import { useLocation, useNavigate } from "react-router-dom";
import { useMemo } from "react";
import {
  getPdpInfrastructuresByPdpId,
  updatePdpInfrastructure
} from "../../../../services/PDP/SubPDP/pdpInfrastructure/pdpInfrastructure.service";
import {
  getPdpInfrastructureLocationCountsByPdpInfrastructureId,
  addPdpInfrastructureLocationCount,
  updatePdpInfrastructureLocationCount,
  deletePdpInfrastructureLocationCount
} from "../../../../services/PDP/SubPDP/pdpInfrastructure/pdpInfrastructureLocation/pdpInfrastructure.service";
import {
  getPdpInfrastructureVehiclesByPdpInfrastructureId,
  updatePdpInfrastructureVehicle
} from "../../../../services/PDP/SubPDP/pdpInfrastructure/pdpInfrastructureVehicle/pdpInfrastructureVehicle.service";
import {
  getPdpInfrastructureToolsByPdpInfrastructureId
} from "../../../../services/PDP/SubPDP/pdpInfrastructure/pdpInfrastructureTools/pdpInfrastructureTools.service";
import {
  getPdpInfrastructureAssetsByPdpInfrastructureId
} from "../../../../services/PDP/SubPDP/pdpInfrastructure/pdpInfrastructureAssets/pdpInfrastructureAssets.service";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../../services/download/bluckDownload.service";

// ⭐ FIXED: Import centralized role functions
import { canEditData, isEditableStatus, isDealerRole, isAdminRole } from "../../../../pages/constants/roles";
import DeleteModal from "../../../../Components/DeleteModal";

const Infrastructure = ({ rowData: propsRowData, userRole }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [showTable, setShowTable] = useState(true);
  const [showAddLocationModal, setShowAddLocationModal] = useState(false);
  const [selectedRowIndex, setSelectedRowIndex] = useState(null);
  const [editingLocation, setEditingLocation] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [savingIds, setSavingIds] = useState(new Set());
  const [modifiedRows, setModifiedRows] = useState(new Map());
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState("asc"); // "asc" or "desc"
const [hoveredCell,setHoveredCell] =useState ()
  const location = useLocation();
  const navigate = useNavigate();
  const tableContainerRef = useRef(null);
const [expandedCell, setExpandedCell] = useState(null);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
const [showDeleteModal, setShowDeleteModal] = useState(false);
const [deleteLocationId, setDeleteLocationId] = useState(null);
const [deleteLoading, setDeleteLoading] = useState(false);

  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

const [activeMenu, setActiveMenu] = useState(null);
const [expandedRows, setExpandedRows] = useState({});

useEffect(() => {
  const closeMenu = () => setActiveMenu(null);
  window.addEventListener("click", closeMenu);
  return () => window.removeEventListener("click", closeMenu);
}, []);
  // ⭐ Extract rowData and detect user role
  const rowData = React.useMemo(() => {
    return propsRowData || location.state?.rowData || {};
  }, [propsRowData, location.state]);

  // ⭐ FIXED: Extract PDP status from rowData
  const pdpStatus = rowData?.signOffStatus || rowData?.sign_of_status || "Created";

  // ⭐ FIXED: Use centralized role check instead of just checking "Administrator"
  const isAdmin = isAdminRole(userRole);
  
  // ⭐ NEW: Check if user can edit (considers both role AND status)
  const canEdit = canEditData(userRole, pdpStatus);
  
  // ⭐ NEW: Check if dealer but editing is locked due to status
  const isStatusLocked = isDealerRole(userRole) && !isEditableStatus(pdpStatus);

  // Get pdpId from rowData
  const pdpId = rowData?.id;

  // ⭐ NEW: Get status badge color
  const getStatusBadgeColor = (status) => {
    switch (status) {
      case "Completed": return "bg-green-100 text-green-800 border-green-300";
      case "Approved": return "bg-blue-100 text-blue-800 border-blue-300";
      case "Pending Review": return "bg-orange-100 text-orange-800 border-orange-300";
      case "Started": return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "Created": return "bg-gray-100 text-gray-800 border-gray-300";
      default: return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  // First table data (same for both roles)
  const [data, setData] = useState([
    {
      field1: "Total - No. of Branches/Touch points",
      CYtarget: "0",
      CYeoy: "0",
      nextyeartarget: "0"
    },
  ]);

  // ⭐ Second table data - fetched from API
  const [data2, setData2] = useState([]);

  // ⭐ Fetch PDP Infrastructure data from API
  const fetchPdpInfrastructures = useCallback(async () => {
    if (!pdpId) {
      console.warn("PDP ID not found, skipping fetch");
      return;
    }

    try {
      setIsLoading(true);
      setError(null);

      const apiData = await getPdpInfrastructuresByPdpId(pdpId);
      console.log("INfraDta", apiData);

      // Transform API response to component data structure
      const transformedData = apiData.map((item) => {
        const facilityTypeLower = (item.facility_type || "").toLowerCase();
        const facilityDefinitionLower = (item.facility_definition || "").toLowerCase();

        const isVehicle = facilityTypeLower.includes("vehicle") ||
          facilityDefinitionLower.includes("vehicle") ||
          facilityDefinitionLower.includes("4-wheeler");

        const isTool = facilityTypeLower.includes("tool") ||
          facilityDefinitionLower.includes("tool");

        const isAccessory = facilityTypeLower.includes("accessory") ||
          facilityTypeLower.includes("accessories") ||
          facilityDefinitionLower.includes("accessory") ||
          facilityDefinitionLower.includes("accessories") ||
          facilityDefinitionLower.includes("laptop") ||
          facilityDefinitionLower.includes("tab");

        const hasManagement = isVehicle || isTool || isAccessory;

        let itemType = null;
        let vehicleType = null;
        if (isVehicle) {
          itemType = "vehicle";
          if (facilityTypeLower.includes("sales") || facilityDefinitionLower.includes("sales")) {
            vehicleType = "sales";
          } else if (facilityTypeLower.includes("service") || facilityDefinitionLower.includes("service")) {
            vehicleType = "service";
          }
        } else if (isTool) {
          itemType = "tool";
        } else if (isAccessory) {
          itemType = "accessory";
        }

        const pyTarget = parseInt(item.py_target) || 0;
        const achievement = parseInt(item.py_achievement_eoy) || 0;
        let calculatedAchievement = item.py_achievement ? String(item.py_achievement) : "0.00";

        if (pyTarget === 0 && achievement > 0) {
          calculatedAchievement = (achievement * 100).toFixed(2);
        } else if (pyTarget > 0 && achievement > 0) {
          calculatedAchievement = ((achievement / pyTarget) * 100).toFixed(2);
        }

        return {
          id: item.id,
          pdpId: item.pdpId,
          infrastructureId: item.infrastructureId,
          category: item.category,
          year: String(item.pdp_year || ""),
          facilityType: item.facility_type || "",
          facilityDefinition: item.facility_definition || "",
          CY2target: item.py_target ? String(item.py_target) : "",
          CY2achievement: item.py_achievement_eoy ? String(item.py_achievement_eoy) : "",
          achievement: calculatedAchievement,
          nextyear2target: item.target ? String(item.target) : "",
          locations: [],
          loaction: "",
          items: [],
          hasManagement: hasManagement,
          itemType: itemType,
          vehicleType: vehicleType,
          _apiData: item
        };
      });

      // Fetch location counts and vehicles for each infrastructure row
      const dataWithLocationsAndVehicles = await Promise.all(
        transformedData.map(async (item) => {
          try {
            if (!item.hasManagement) {
              const locationCounts = await getPdpInfrastructureLocationCountsByPdpInfrastructureId(item.id);
              const locations = locationCounts.map((loc) => ({
                id: loc.id,
                name: loc.location || "",
                count: loc.count || 0,
                pdpId: loc.pdpId,
                pdpInfrastructureId: loc.pdpInfrastructureId
              }));

              const locationString = locations.map(loc => loc.name).filter(Boolean).join(", ");

              return {
                ...item,
                locations: locations,
                loaction: locationString
              };
            }

            if (item.hasManagement && item.itemType === "vehicle") {
              const vehicles = await getPdpInfrastructureVehiclesByPdpInfrastructureId(item.id);
              const vehicleItems = vehicles.map((vehicle) => ({
                id: vehicle.id,
                pdpId: vehicle.pdpId,
                pdpInfrastructureId: vehicle.pdpInfrastructureId,
                vehicle_type: vehicle.vehicle_type,
                make: vehicle.make,
                model: vehicle.model,
                registration_number: vehicle.registration_number,
                yop: vehicle.yop,
                vehicle_age: vehicle.vehicle_age,
                operating_area: vehicle.operating_area || "",
                utilisation_rate: vehicle.utilisation_rate || "",
                assigned_to: vehicle.assigned_to || "",
                isActive: vehicle.isActive,
                isDeleted: vehicle.isDeleted,
                created_at: vehicle.created_at,
                updated_at: vehicle.updated_at
              }));

              return {
                ...item,
                items: vehicleItems
              };
            }

            if (item.hasManagement && item.itemType === "tool") {
              const tools = await getPdpInfrastructureToolsByPdpInfrastructureId(item.id);
              const toolItems = tools.map((tool, index) => ({
                id: tool.id,
                pdpId: tool.pdpId,
                pdpInfrastructureId: tool.pdpInfrastructureId,
                tool_type: tool.tool_type,
                tool_name: tool.tool_name,
                toolType: tool.tool_type,
                toolName: tool.tool_name,
                quantity: tool.quantity?.toString() || "",
                yop: tool.yop,
                yearOfPurchase: tool.yop?.toString() || "",
                available: tool.available,
                slNo: (index + 1).toString(),
                isActive: tool.isActive,
                isDeleted: tool.isDeleted,
                created_at: tool.created_at,
                updated_at: tool.updated_at
              }));

              return {
                ...item,
                items: toolItems
              };
            }

            if (item.hasManagement && item.itemType === "accessory") {
              const assets = await getPdpInfrastructureAssetsByPdpInfrastructureId(item.id);
              const assetItems = assets.map((asset, index) => ({
                id: asset.id,
                pdpId: asset.pdpId,
                pdpInfrastructureId: asset.pdpInfrastructureId,
                asset_type: asset.asset_type,
                assetType: asset.asset_type,
                quantity: asset.quantity?.toString() || "",
                yop: asset.yop,
                yearOfPurchase: asset.yop?.toString() || "",
                available: asset.available,
                assigned_to: asset.assigned_to || "",
                assignedTo: asset.assigned_to || "",
                slNo: (index + 1).toString(),
                isActive: asset.isActive,
                isDeleted: asset.isDeleted,
                created_at: asset.created_at,
                updated_at: asset.updated_at
              }));

              return {
                ...item,
                items: assetItems
              };
            }

            return item;
          } catch (err) {
            console.error(`Error fetching data for infrastructure ${item.id}:`, err);
            return item;
          }
        })
      );

      setData2(dataWithLocationsAndVehicles);

      // Calculate first table totals from API data
      if (dataWithLocationsAndVehicles.length > 0) {
        const totalTarget = dataWithLocationsAndVehicles.reduce((sum, item) => {
          return sum + (parseInt(item.CY2target) || 0);
        }, 0);
        const totalAchievement = dataWithLocationsAndVehicles.reduce((sum, item) => {
          return sum + (parseInt(item.CY2achievement) || 0);
        }, 0);
        const totalNextYearTarget = dataWithLocationsAndVehicles.reduce((sum, item) => {
          return sum + (parseInt(item.nextyear2target) || 0);
        }, 0);

        setData([{
          field1: "Total - No. of Branches/Touch points",
          CYtarget: String(totalTarget),
          CYeoy: String(totalAchievement),
          nextyeartarget: String(totalNextYearTarget)
        }]);
      }
    } catch (err) {
      console.error("Error fetching PDP Infrastructure data:", err);
      setError(err.message || "Failed to fetch infrastructure data");
    } finally {
      setIsLoading(false);
    }
  }, [pdpId]);

  // ⭐ Fetch PDP Infrastructure data on component mount
  useEffect(() => {
    fetchPdpInfrastructures();
  }, [fetchPdpInfrastructures]);

  // ⭐ Refetch items for a specific infrastructure row
  const refetchItemsForRow = useCallback(async (infrastructureId, rowIndex, itemType) => {
    try {
      if (rowIndex === undefined || rowIndex < 0 || !itemType) return;

      let items = [];

      if (itemType === "vehicle") {
        const vehicles = await getPdpInfrastructureVehiclesByPdpInfrastructureId(infrastructureId);
        items = vehicles.map((vehicle) => ({
          id: vehicle.id,
          pdpId: vehicle.pdpId,
          pdpInfrastructureId: vehicle.pdpInfrastructureId,
          vehicle_type: vehicle.vehicle_type,
          make: vehicle.make,
          model: vehicle.model,
          registration_number: vehicle.registration_number,
          yop: vehicle.yop,
          vehicle_age: vehicle.vehicle_age,
          operating_area: vehicle.operating_area || "",
          utilisation_rate: vehicle.utilisation_rate || "",
          assigned_to: vehicle.assigned_to || "",
          isActive: vehicle.isActive,
          isDeleted: vehicle.isDeleted,
          created_at: vehicle.created_at,
          updated_at: vehicle.updated_at
        }));
      } else if (itemType === "tool") {
        const tools = await getPdpInfrastructureToolsByPdpInfrastructureId(infrastructureId);
        items = tools.map((tool, index) => ({
          id: tool.id,
          pdpId: tool.pdpId,
          pdpInfrastructureId: tool.pdpInfrastructureId,
          tool_type: tool.tool_type,
          tool_name: tool.tool_name,
          toolType: tool.tool_type,
          toolName: tool.tool_name,
          quantity: tool.quantity?.toString() || "",
          yop: tool.yop,
          yearOfPurchase: tool.yop?.toString() || "",
          available: tool.available,
          slNo: (index + 1).toString(),
          isActive: tool.isActive,
          isDeleted: tool.isDeleted,
          created_at: tool.created_at,
          updated_at: tool.updated_at
        }));
      } else if (itemType === "accessory") {
        const assets = await getPdpInfrastructureAssetsByPdpInfrastructureId(infrastructureId);
        items = assets.map((asset, index) => ({
          id: asset.id,
          pdpId: asset.pdpId,
          pdpInfrastructureId: asset.pdpInfrastructureId,
          asset_type: asset.asset_type,
          assetType: asset.asset_type,
          quantity: asset.quantity?.toString() || "",
          yop: asset.yop,
          yearOfPurchase: asset.yop?.toString() || "",
          available: asset.available,
          assigned_to: asset.assigned_to || "",
          assignedTo: asset.assigned_to || "",
          slNo: (index + 1).toString(),
          isActive: asset.isActive,
          isDeleted: asset.isDeleted,
          created_at: asset.created_at,
          updated_at: asset.updated_at
        }));
      }

      setData2(prevData => {
        const updated = [...prevData];
        if (rowIndex < updated.length && updated[rowIndex]) {
          updated[rowIndex] = { ...updated[rowIndex], items: items };
        }
        return updated;
      });
    } catch (err) {
      console.error(`Error refetching items for infrastructure ${infrastructureId}:`, err);
    }
  }, []);

  // ⭐ Update items when returning from any management page
  useEffect(() => {
    if (location.state?.updatedItems && location.state?.rowIndex !== undefined) {
      const rowIndex = location.state.rowIndex;

      setData2(prevData => {
        if (rowIndex >= 0 && rowIndex < prevData.length && prevData[rowIndex]) {
          const updatedData = [...prevData];
          if (updatedData[rowIndex]) {
            updatedData[rowIndex] = {
              ...updatedData[rowIndex],
              items: location.state.updatedItems
            };
          }

          const row = updatedData[rowIndex];
          if (row && row.hasManagement && row.id && row.itemType) {
            refetchItemsForRow(row.id, rowIndex, row.itemType);
          }

          return updatedData;
        }
        return prevData;
      });

      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location.state, navigate, refetchItemsForRow]);
const handleSort = (key) => {
  if (sortKey !== key) {
    // New column clicked → start with ascending
    setSortKey(key);
    setSortOrder("asc");
  } else {
    // Same column clicked → toggle asc → desc → normal
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null); // back to normal
    } else {
      setSortOrder("asc");
    }
  }
};


  // Filter first table
  const filteredData1 = data.filter(item =>
    Object.values(item).some(val =>
      String(val).toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  // Filter second table
  const filteredData2 = data2.filter(item =>
    Object.entries(item).some(([key, val]) => {
      if (key === "locations" || key === "showIcon" || key === "items" || key === "hasManagement") return false;
      return String(val).toLowerCase().includes(searchTerm.toLowerCase());
    })
  );
const sortedData2 = useMemo(() => {
  if (!filteredData2) return [];

  if (!sortKey || !sortOrder) return filteredData2; // normal / unsorted

  return [...filteredData2].sort((a, b) => {
    const valA = a[sortKey] ?? "";
    const valB = b[sortKey] ?? "";

    if (typeof valA === "number" && typeof valB === "number") {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    return sortOrder === "asc"
      ? valA.toString().localeCompare(valB.toString(), undefined, { numeric: true })
      : valB.toString().localeCompare(valA.toString(), undefined, { numeric: true });
  });
}, [filteredData2, sortKey, sortOrder]);

  // Get year from first data item or rowData
  const selectedyear = data2.length > 0 ? data2[0].year : (rowData?.year || "");

  // ⭐ Handle field change for user editing
  const handleFieldChange = useCallback((rowId, fieldName, value) => {
    // ⭐ NEW: Prevent editing if status is locked
    if (!canEdit) {
      console.warn("⚠️ Editing is disabled for this PDP status:", pdpStatus);
      return;
    }

    if (fieldName !== 'nextyear2target' && fieldName !== 'CY2achievement') {
      return;
    }

    setData2(prevData => {
      const rowToUpdate = prevData.find(item => item.id === rowId);
      if (!rowToUpdate) return prevData;

      setModifiedRows(prevModified => {
        const newMap = new Map(prevModified);
        if (!newMap.has(rowId)) {
          newMap.set(rowId, {
            originalNextYearTarget: rowToUpdate.nextyear2target,
            originalAchievement: rowToUpdate.CY2achievement,
            originalAchievementPercent: rowToUpdate.achievement
          });
        }
        return newMap;
      });

      return prevData.map(item => {
        if (item.id === rowId) {
          let updatedItem = { ...item, [fieldName]: value };

          if (fieldName === 'CY2achievement') {
            const pyTarget = parseInt(item.CY2target) || 0;
            const achievement = parseInt(value) || 0;

            let calculatedPercentStr = "0.00";
            if (pyTarget > 0) {
              calculatedPercentStr = ((achievement / pyTarget) * 100).toFixed(2);
            } else if (achievement > 0) {
              calculatedPercentStr = (achievement * 100).toFixed(2);
            }
            updatedItem.achievement = calculatedPercentStr;
          }

          return updatedItem;
        }
        return item;
      });
    });
  }, [canEdit, pdpStatus]);

  // ⭐ Handle save for all modified rows
  const handleSaveAll = useCallback(async () => {
    // ⭐ NEW: Double-check edit permission before saving
    if (!canEdit) {
      alert(`❌ Cannot save. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      return;
    }

    if (modifiedRows.size === 0) return;

    const rowIdsToSave = Array.from(modifiedRows.keys());
    setSavingIds(new Set(rowIdsToSave));

    const savePromises = rowIdsToSave.map(async (rowId) => {
      const row = data2.find(item => item.id === rowId);
      if (!row) return;

      const modifiedRow = modifiedRows.get(rowId);
      if (!modifiedRow) return;

      const targetNum = parseInt(row.nextyear2target) || 0;
      const achievementNum = parseInt(row.CY2achievement) || 0;
      const pyTargetNum = parseInt(row.CY2target) || 0;

      let calculatedPercent = 0.00;
      if (pyTargetNum > 0) {
        calculatedPercent = parseFloat(((achievementNum / pyTargetNum) * 100).toFixed(2));
      } else if (achievementNum > 0) {
        calculatedPercent = parseFloat((achievementNum * 100).toFixed(2));
      }

      const updatePayload = {
        id: rowId,
        target: targetNum,
        py_achievement_eoy: achievementNum,
        py_achievement: calculatedPercent
      };

      try {
        await updatePdpInfrastructure(updatePayload);
        return { success: true, rowId };
      } catch (err) {
        console.error(`Error updating row ${rowId}:`, err);
        return { success: false, rowId, error: err };
      }
    });

    try {
      const results = await Promise.all(savePromises);
      const failedRows = results.filter(r => !r.success);

      if (failedRows.length > 0) {
        setData2(prevData => {
          return prevData.map(item => {
            const failedRow = failedRows.find(f => f.rowId === item.id);
            if (failedRow) {
              const modifiedRow = modifiedRows.get(item.id);
              if (modifiedRow) {
                return {
                  ...item,
                  nextyear2target: modifiedRow.originalNextYearTarget,
                  CY2achievement: modifiedRow.originalAchievement,
                  achievement: modifiedRow.originalAchievementPercent
                };
              }
            }
            return item;
          });
        });
        alert(`Failed to save ${failedRows.length} row(s). Please try again.`);
      } else {
        setModifiedRows(new Map());
        await fetchPdpInfrastructures();
      }
    } catch (err) {
      console.error("Error saving rows:", err);
      alert("Failed to save changes. Please try again.");
    } finally {
      setSavingIds(new Set());
    }
  }, [data2, modifiedRows, fetchPdpInfrastructures, canEdit, pdpStatus]);

  // ⭐ Handle save for a specific row
  const handleSaveRow = useCallback(async (rowId) => {
    // ⭐ NEW: Double-check edit permission before saving
    if (!canEdit) {
      alert(`❌ Cannot save. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      return;
    }

    const row = data2.find(item => item.id === rowId);
    if (!row) return;

    const modifiedRow = modifiedRows.get(rowId);
    if (!modifiedRow) return;

    const targetNum = parseInt(row.nextyear2target) || 0;
    const achievementNum = parseInt(row.CY2achievement) || 0;
    const pyTargetNum = parseInt(row.CY2target) || 0;

    let calculatedPercent = 0.00;
    if (pyTargetNum > 0) {
      calculatedPercent = parseFloat(((achievementNum / pyTargetNum) * 100).toFixed(2));
    } else if (achievementNum > 0) {
      calculatedPercent = parseFloat((achievementNum * 100).toFixed(2));
    }

    const updatePayload = {
      id: rowId,
      target: targetNum,
      py_achievement_eoy: achievementNum,
      py_achievement: calculatedPercent
    };

    setSavingIds(prev => new Set(prev).add(rowId));

    try {
      await updatePdpInfrastructure(updatePayload);

      setModifiedRows(prev => {
        const newMap = new Map(prev);
        newMap.delete(rowId);
        return newMap;
      });

      await fetchPdpInfrastructures();
    } catch (err) {
      console.error("Error updating field:", err);
      setData2(prevData => {
        return prevData.map(item => {
          if (item.id === rowId) {
            return {
              ...item,
              nextyear2target: modifiedRow.originalNextYearTarget,
              CY2achievement: modifiedRow.originalAchievement,
              achievement: modifiedRow.originalAchievementPercent
            };
          }
          return item;
        });
      });
      setModifiedRows(prev => {
        const newMap = new Map(prev);
        newMap.delete(rowId);
        return newMap;
      });
      alert(err.message || "Failed to update. Please try again.");
    } finally {
      setSavingIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(rowId);
        return newSet;
      });
    }
  }, [data2, modifiedRows, fetchPdpInfrastructures, canEdit, pdpStatus]);

  const handleDownload = async () => {
    if (!filteredData2 || filteredData2.length === 0) {
      alert("No data available to generate preview");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("Infrastructure");

      sheet.columns = [
        { header: "Sl. No", key: "slNo", width: 8 },
        { header: "Facility Type", key: "facilityType", width: 40 },
        { header: "Facility Definition", key: "facilityDefinition", width: 150 },
        { header: `${+selectedyear - 1} Target`, key: "CY2target", width: 15 },
        { header: `${+selectedyear - 1} Achievement EOY`, key: "CY2achievement", width: 15 },
        { header: "Achievement %", key: "achievement", width: 15 },
        { header: `${+selectedyear} Target`, key: "nextyear2target", width: 15 },
        { header: "Locations", key: "loaction", width: 30 },
      ];

      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      filteredData2.forEach((item, index) => {
        const row = sheet.addRow({
          slNo: index + 1,
          facilityType: item.facilityType || "",
          facilityDefinition: item.facilityDefinition || "",
          CY2target: item.CY2target || "",
          CY2achievement: item.CY2achievement || "",
          achievement: item.achievement || "",
          nextyear2target: item.nextyear2target || "",
          loaction: item.loaction || "",
        });

        row.eachCell((cell) => {
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const file = new File([blob], "Infrastructure.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const response = await uploadTempFile(file);
      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        console.warn("Upload succeeded but no file URL returned");
        alert("Upload succeeded but no preview available.");
      }
    } catch (error) {
      console.error("Preview generation failed:", error);
      alert("Failed to generate preview. Check console for details.");
    }
  };

  const handleAddLocation = (rowIndex) => {
    // ⭐ NEW: Prevent adding location if editing is disabled
    if (!canEdit) {
      console.warn("⚠️ Adding location is disabled for this PDP status:", pdpStatus);
      return;
    }
    setSelectedRowIndex(rowIndex);
    setShowAddLocationModal(true);
  };

  const handleSaveLocation = async (newLocation) => {
    // ⭐ NEW: Double-check edit permission before saving
    if (!canEdit) {
      alert(`❌ Cannot save. This PDP is in "${pdpStatus}" status and editing is disabled.`);
      return;
    }

    if (selectedRowIndex === null || !data2[selectedRowIndex]) {
      alert("Invalid row selection");
      return;
    }

    const row = data2[selectedRowIndex];

    try {
      if (newLocation.id) {
        await updatePdpInfrastructureLocationCount({
          id: newLocation.id,
          location: newLocation.name,
          count: parseInt(newLocation.count) || 0
        });
      } else {
        await addPdpInfrastructureLocationCount({
          pdpId: row.pdpId,
          pdpInfrastructureId: row.id,
          location: newLocation.name,
          count: parseInt(newLocation.count) || 0
        });
      }

      const locationCounts = await getPdpInfrastructureLocationCountsByPdpInfrastructureId(row.id);
      const locations = locationCounts.map((loc) => ({
        id: loc.id,
        name: loc.location || "",
        count: loc.count || 0,
        pdpId: loc.pdpId,
        pdpInfrastructureId: loc.pdpInfrastructureId
      }));

      const locationString = locations.map(loc => loc.name).filter(Boolean).join(", ");

      setData2(prevData => {
        const updatedData = [...prevData];
        updatedData[selectedRowIndex] = {
          ...updatedData[selectedRowIndex],
          locations: locations,
          loaction: locationString
        };
        return updatedData;
      });

      setShowAddLocationModal(false);
    } catch (err) {
      console.error("Error saving location:", err);
      alert(err.message || "Failed to save location. Please try again.");
    }
  };
const handleDeleteLocation = async () => {
  if (!deleteLocationId) return;

  try {
    setDeleteLoading(true);

    await deletePdpInfrastructureLocationCount(deleteLocationId);

    // refresh locations
    const updatedData = await Promise.all(
      data2.map(async (item) => {
        const locationCounts =
          await getPdpInfrastructureLocationCountsByPdpInfrastructureId(item.id);

        const locations = locationCounts.map((loc) => ({
          id: loc.id,
          name: loc.location || "",
          count: loc.count || 0,
          pdpId: loc.pdpId,
          pdpInfrastructureId: loc.pdpInfrastructureId,
        }));

        const locationString = locations.map((loc) => loc.name).join(", ");

        return {
          ...item,
          locations,
          loaction: locationString,
        };
      })
    );

    setData2(updatedData);

    setShowDeleteModal(false);
    setDeleteLocationId(null);

  } catch (err) {
    console.error("Error deleting location:", err);
    alert(err.message || "Failed to delete location.");
  } finally {
    setDeleteLoading(false);
  }
};
  // ⭐ Navigate to Management Pages
  const handleNavigateToManagement = (rowIndex, row) => {
    if (!row.hasManagement || !row.itemType) {
      console.warn("No management page configured for this facility type");
      return;
    }

    let navigationPath = "";

    if (row.itemType === "vehicle") {
      navigationPath = "/pdp/viewdetails/infrastructure/vehicles";
    } else if (row.itemType === "tool") {
      navigationPath = "/pdp/viewdetails/infrastructure/tools";
    } else if (row.itemType === "accessory") {
      navigationPath = "/pdp/viewdetails/infrastructure/accessories";
    } else {
      navigationPath = `/pdp/viewdetails/infrastructure/${row.itemType}s`;
    }

    if (navigationPath) {
      navigate(navigationPath, {
        state: {
          itemType: row.itemType,
          vehicleType: row.vehicleType,
          items: row.items || [],
          rowIndex: rowIndex,
          year: selectedyear,
          facilityDefinition: row.facilityDefinition,
          facilityType: row.facilityType,
          isAdmin: isAdmin,
          canEdit: canEdit, // ⭐ NEW: Pass canEdit to child pages
          pdpStatus: pdpStatus, // ⭐ NEW: Pass pdpStatus to child pages
          rowData: rowData,
          pdpInfrastructureId: row.id,
          pdpId: row.pdpId || pdpId
        }
      });
    }
  };

  // ⭐ Get icon label based on itemType
  const getIconLabel = (itemType) => {
    if (!itemType) return "Manage";
    const displayName = itemType.charAt(0).toUpperCase() + itemType.slice(1);
    return `Manage ${displayName}s`;
  };
const renderLocationCell = (row, idx) => {

  // ⭐ HAS MANAGEMENT PAGE
  if (row.hasManagement) {
    return (
      <div className="flex items-center gap-2">
        <div className="flex justify-center w-full">

          {isAdmin ? (
            <div className="relative group inline-block">
              <button
                onClick={() => handleNavigateToManagement(idx, row)}
                className="w-6 h-6 flex items-center justify-center bg-white text-darkblue1 border border-darkblue1 transition"
              >
                <Eye size={16} />
              </button>

              <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none z-50">
                {`View ${row.itemType}s`}
              </span>
            </div>

          ) : (

            <div className="flex flex-col items-center gap-1">

              <div className="relative group inline-block">
                <button
                  onClick={() => handleNavigateToManagement(idx, row)}
                  className="w-6 h-6 flex items-center justify-center bg-white text-darkblue1 border border-darkblue1 transition font-bold text-lg shadow-sm"
                >
                  +
                </button>

                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none z-50">
                  {getIconLabel(row.itemType)}
                </span>
              </div>

              {row.items && row.items.length > 0 && (
                <span className="text-xs text-gray-600 text-center">
                  ({row.items.length} {row.itemType}{row.items.length !== 1 ? "s" : ""})
                </span>
              )}

            </div>

          )}

        </div>
      </div>
    );
  }



  // ⭐ READ ONLY VIEW
  if (isAdmin || !canEdit) {
    if (row.locations && row.locations.length > 0) {
      return (
        <div className="flex flex-col gap-1">
          {row.locations.map((loc, locIdx) => (
            <div key={loc.id || locIdx} className="flex items-center gap-2">
              <span className="text-xs">
                {loc.name}
                {loc.count !== undefined &&
                  loc.count !== null &&
                  loc.count !== 0 &&
                  ` (${loc.count})`}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return <span className="text-gray-400 italic text-xs">N/A</span>;
  }



  // ⭐ DELETE LOCATION
 

  // ⭐ EDIT LOCATION
  const handleEditLocation = (loc) => {
    setSelectedRowIndex(idx);
    setShowAddLocationModal(true);
    setEditingLocation(loc);
  };



  const locationCount = row.locations ? row.locations.length : 0;

  const visibleLocations = expandedRows[idx]
    ? row.locations
    : row.locations.slice(0, 2);



  return (
    <div className="flex flex-col gap-1 w-full">

      {/* CASE 0: NO LOCATIONS */}
      {locationCount === 0 && (
        <div className="flex justify-center w-full">
          <button
            onClick={() => {
              setEditingLocation(null);
              handleAddLocation(idx);
            }}
            className="font-bold text-base"
          >
            +
          </button>
        </div>
      )}



      {/* CASE 1: 1 OR 2 LOCATIONS */}
      {(locationCount === 1 || locationCount === 2) && (
        <>
          <div className="flex justify-between w-full">

            <span className="text-xs">
              ({locationCount} Location{locationCount > 1 ? "s" : ""})
            </span>

            <button
              onClick={() => {
                setEditingLocation(null);
                handleAddLocation(idx);
              }}
              className="font-bold text-base"
            >
              +
            </button>

          </div>

          {row.locations.map((loc, locIdx) => (
            <div
              key={loc.id || locIdx}
className="flex items-start justify-between w-full bg-grey2/50 rounded-md px-2 py-1"            >

              <span className="text-xs flex-1 text-left">
                {loc.name}
                {loc.count ? ` (${loc.count})` : ""}
              </span>

              <div className="flex gap-2 flex-shrink-0">

                <button
                  onClick={() => handleEditLocation(loc)}
                  className="text-green-600 text-xs"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

                </button>

                <button
onClick={() => {
  setDeleteLocationId(loc.id);
  setShowDeleteModal(true);
}}                  className="text-red-600 text-xs"
                >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>

                </button>

              </div>

            </div>
          ))}
        </>
      )}



      {/* CASE 2: MORE THAN 2 LOCATIONS */}
      {locationCount > 2 && (
        <>
          <div className="flex items-center justify-between w-full">

            <div className="flex items-center gap-2">

              <button
                onClick={() =>
                  setExpandedRows((prev) => ({
                    ...prev,
                    [idx]: !prev[idx],
                  }))
                }
              >
                {expandedRows[idx] ? (
                  <ChevronUp className="w-3 h-3" />
                ) : (
                  <ChevronDown className="w-3 h-3" />
                )}
              </button>

              <span className="text-xs font-medium">
                ({locationCount} Locations)
              </span>

            </div>

            <button
              onClick={() => {
                setEditingLocation(null);
                handleAddLocation(idx);
              }}
              className="font-bold text-base"
            >
              +
            </button>

          </div>

          {visibleLocations.map((loc, locIdx) => (
            <div
              key={loc.id || locIdx}
className="flex items-start justify-between w-full bg-grey2/50 rounded-md px-2 py-1">
            

              <span className="text-xs flex-1 text-left">
                {loc.name}
                {loc.count ? ` (${loc.count})` : ""}
              </span>

              <div className="flex gap-2 flex-shrink-0">

                <button
                  onClick={() => handleEditLocation(loc)}
                  className="text-green-600 text-xs"
                >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

                </button>

                <button
 onClick={() => {
    setDeleteLocationId(loc.id);
    setShowDeleteModal(true);
  }}                  className="text-red-600 text-xs"
                >
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>

                </button>

              </div>

            </div>
          ))}
        </>
      )}

    </div>
  );
};
  // Show loading state
  if (isLoading) {
    return (
      <div className="w-full flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1 mx-auto mb-4"></div>
          <p className="text-sm text-gray-600">Loading infrastructure data...</p>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="w-full flex items-center justify-center py-12">
        <div className="text-center">
          <p className="text-sm text-red-600 mb-2">Error: {error}</p>
          <button
            onClick={() => window.location.reload()}
            className="text-sm text-darkblue1 hover:underline"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full overflow-hidden">
      {/* ⭐ NEW: Status Lock Banner - Shows when dealer cannot edit due to status */}
      {/* {isStatusLocked && (
        <div className="bg-amber-50 border border-amber-300 rounded-lg p-3 mb-3 flex items-start gap-3">
          <div className="flex-shrink-0 mt-0.5">
            <Lock size={20} className="text-amber-600" />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-amber-800 mb-1">
              Editing Disabled
            </h4>
            <p className="text-xs text-amber-700">
              This PDP is in <span className="font-bold">{pdpStatus}</span> status. 
              Data can only be edited when status is <span className="font-semibold">"Created"</span> or <span className="font-semibold">"Started"</span>.
            </p>
            <p className="text-xs text-amber-600 mt-1">
              {pdpStatus === "Pending Review" && "The PDP is awaiting admin approval."}
              {pdpStatus === "Approved" && "The PDP has been approved and is now read-only."}
              {pdpStatus === "Completed" && "The PDP has been completed and finalized."}
            </p>
          </div>
        </div>
      )} */}

      {/* Search and Actions Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-2">
        <div className="">
          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search"
            className="w-[1/2]"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            focusRing="focus:ring-black/60"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            iconColor="text-black"
          />
        </div>

        <div className="flex gap-2 items-center">
          {/* ⭐ NEW: Status Badge */}
          <div className={`shadow-sm px-3 py-1.5 flex items-center justify-center gap-2 border rounded ${getStatusBadgeColor(pdpStatus)}`}>
            {isStatusLocked && <Lock size={14} />}
            <span className="w-2 h-2 bg-current rounded-full inline-block opacity-60"></span>
            <span className="text-xs font-medium whitespace-nowrap">{pdpStatus}</span>
          </div>

          {/* ⭐ FIXED: Only show Save button when canEdit is true */}
          {canEdit && (
            <button
              onClick={handleSaveAll}
              disabled={savingIds.size > 0 || modifiedRows.size === 0}
              className={`text-xs font-medium px-4 py-1.5 transition flex items-center gap-2 ${savingIds.size > 0 || modifiedRows.size === 0
                ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                : "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                }`}
              title={modifiedRows.size === 0 ? "No changes to save" : `Save ${modifiedRows.size} change(s)`}
            >
              {savingIds.size > 0 ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Saving...
                </>
              ) : (
                <>
                  <Save size={14} />
                  Save {modifiedRows.size > 0 && `(${modifiedRows.size})`}
                </>
              )}
            </button>
          )}
          <button
            onClick={handleDownload}
            className="bg-darkblue1 text-xs font-medium text-white px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition flex items-center gap-2"
          >
            <Download size={14} className="text-current" />
            Download
          </button>
          <div className="relative group">
            <button
              onClick={() => setShowTable(!showTable)}
              className="flex items-center gap-1 text-sm font-medium bg-Dustyblue text-white p-1 rounded-full hover:bg-darkblue1 transition"
            >
              {showTable ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>

            <span className="absolute left-0 top-full -translate-x-1/2 mt-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap pointer-events-none z-50">
              {showTable ? "Collapse" : "Expand"}
            </span>
          </div>
        </div>
      </div>

      {/* ========== FIRST TABLE (Same for Admin & User) ========== */}
      {showTable && (
        <div className="hidden lg:block w-full mb-4 border border-Dustyblue overflow-hidden">
          <table className="w-full overflow-hidden text-sm border-collapse">
            <thead className="bg-Dustyblue text-white text-left">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-xs font-medium w-[30%]"></th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-xs font-medium text-base">
                  {+selectedyear - 1} Target
                </th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-xs font-medium text-base">
                  {+selectedyear - 1} Achievement EOY
                </th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 text-xs font-medium">
                  {selectedyear} Target
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredData1.map((item, idx) => (
                <tr
                  key={idx}
                  className="hover:bg-lightBlue/50 transition duration-300 cursor-pointer text-xs"
                >
                  <td className="px-4 py-1 py-1 border border-grey2 border-t-0 border-l-0">{item.field1}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.CYtarget}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.CYeoy}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">{item.nextyeartarget}</td>
                </tr>
              ))}
              {filteredData1.length === 0 && (
                <tr>
                  <td colSpan={4} className="text-center py-4 text-gray-500 italic">
                    No data found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Mobile View - First Table */}
      <div className="lg:hidden space-y-4">
        {filteredData1.length > 0 ? (
          filteredData1.map((item, idx) => (
            <div
              key={idx}
              className="bg-white shadow-md p-4 border border-gray-200 mb-2"
            >
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-mildBlue"></span>
                <span className="text-sm">{item.field1}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-mildBlue text-base">
                  {+selectedyear - 1} Target:
                </span>
                <span className="text-sm">{item.CYtarget}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-mildBlue text-base">
                  {+selectedyear - 1} (EOY):
                </span>
                <span className="text-sm">{item.CYeoy}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-mildBlue text-base">
                  {selectedyear} Target:
                </span>
                <span className="text-sm">{item.nextyeartarget}</span>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-6 text-gray-500 italic">No data found.</div>
        )}
      </div>

      {/* ========== SECOND TABLE - Desktop View ========== */}
      <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer ">
          <div
            ref={tableContainerRef}
className="overflow-y-auto overflow-x-hidden scrollbar-hide"            style={{
               maxHeight: sortedData2.length > 8 ? "calc(100vh - 200px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >
            <table className="w-full text-xs table-fixed border-collapse">
<thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">

  {/* ROW 1 */}
  <tr>

    {/* Year */}
    <th rowSpan="2"
      onClick={() => handleSort("year")}
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer w-[4%]"
    >
      <div className="flex items-center gap-1">
        Year
        {sortKey !== "year" && <ChevronsUpDown className="w-3 h-3 text-white" />}
        {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Facility Type */}
    <th rowSpan="2"
      onClick={() => handleSort("facilityType")}
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer w-[10%]"
    >
      <div className="flex items-center gap-1">
        Facility Type
        {sortKey === "facilityType" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "facilityType" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Definition */}
    <th rowSpan="2"
      onClick={() => handleSort("facilityDefinition")}
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer w-[15%]"
    >
      <div className="flex items-center gap-1">
        Definition
        {sortKey === "facilityDefinition" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "facilityDefinition" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Selected Year */}
    <th colSpan="2"
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[20%] font-normal  text-center"
    >
      {+selectedyear - 1}
    </th>

    {/* Achievement % */}
    <th rowSpan="2"
      onClick={() => handleSort("achievement")}
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 text-center font-medium cursor-pointer w-[10%]"
    >
      <div className="flex items-center justify-center  gap-1">
        Achievement %
        {sortKey === "achievement" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "achievement" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Next Year */}
    <th colSpan="1"
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 w-[10%] font-normal  text-center"
    >
      {selectedyear}
    </th>

    {/* Location */}
    <th rowSpan="2"
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-normal  text-center w-[15%]"
    >
      Location & Count
    </th>

  </tr>


  {/* ROW 2 */}
  <tr>

    {/* CY Target */}
    <th
      onClick={() => handleSort("CY2target")}
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-normal cursor-pointer"
    >
      <div className="flex items-center justify-center gap-1">
        Target
        {sortKey === "CY2target" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "CY2target" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* CY Achievement */}
    <th
      onClick={() => handleSort("CY2achievement")}
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-normal  cursor-pointer"
    >
      <div className="flex items-center justify-center gap-1">
        Achievement EOY
        {sortKey === "CY2achievement" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "CY2achievement" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Next Year Target */}
    <th
      onClick={() => handleSort("nextyear2target")}
      className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-normal  cursor-pointer"
    >
      <div className="flex items-center justify-center gap-1">
        Target
        {sortKey === "nextyear2target" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "nextyear2target" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

  </tr>

</thead>
    <tbody>
            {sortedData2.map((row, idx) => (
              <tr
                key={idx}
                className="hover:bg-lightBlue/50 transition duration-300 cursor-pointer text-xs "
              >
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-left">
    <div className="relative">
      <p
        className="truncate max-w-[20rem] cursor-pointer"
        onMouseEnter={() => {
          if (row.year && row.year.length > 40) setHoveredCell(row.id + "-year");
        }}
        onMouseLeave={() => setHoveredCell(null)}
      >
        {row.year || "-"}
      </p>
      {hoveredCell === row.id + "-year" && (
        <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
          {row.year}
        </span>
      )}
    </div>
  </td>

 {/* Facility Type */}
 <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-left max-w-[200px]">
  <div className="relative w-full">
    <p
      className="truncate w-full block cursor-pointer"
      onMouseEnter={() => {
        if (row.facilityType && row.facilityType.length > 15) {
          setHoveredCell(`facility-${row.id}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.facilityType || "-"}
    </p>

    {hoveredCell === `facility-${row.id}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-10 shadow-lg">
        {row.facilityType}
      </span>
    )}
  </div>
</td>
{/* Facility Definition */}
 <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-left max-w-[200px]">
  <div className="relative w-full">
    <p
      className="truncate w-full block cursor-pointer"
      onMouseEnter={() => {
        if (row.facilityDefinition && row.facilityDefinition.length > 15) {
          setHoveredCell(`facilityDef-${row.id}`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.facilityDefinition || "-"}
    </p>

    {hoveredCell === `facilityDef-${row.id}` && (
      <span className="absolute left-0 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-10 shadow-lg">
        {row.facilityDefinition}
      </span>
    )}
  </div>
</td>
{/* CY2 Target */}
  <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center">
    <div className="relative">
      <p
        className="truncate max-w-[20rem] cursor-pointer"
        onMouseEnter={() => {
          if (row.CY2target && row.CY2target.length > 40) setHoveredCell(row.id + "-CY2target");
        }}
        onMouseLeave={() => setHoveredCell(null)}
      >
        {row.CY2target || "-"}
      </p>
      {hoveredCell === row.id + "-CY2target" && (
        <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
          {row.CY2target}
        </span>
      )}
    </div>
  </td>

               {/* CY2 Achievement (editable) */}
  <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center">
    {canEdit ? (
     <input
  type="text"
  value={row.CY2achievement || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;

    if (/^\d*\.?\d*$/.test(value)) {
      handleFieldChange(row.id, "CY2achievement", value);
    }
  }}
  className="w-full px-2 py-1 text-xs border border-gray-300 text-center focus:outline-none focus:ring-1 focus:ring-darkblue1 bg-white"
  disabled={savingIds.has(row.id)}
/>
    ) : (
      <div className="relative">
        <p
          className="truncate max-w-[20rem] cursor-pointer"
          onMouseEnter={() => {
            if (row.CY2achievement && row.CY2achievement.length > 40)
              setHoveredCell(row.id + "-CY2achievement");
          }}
          onMouseLeave={() => setHoveredCell(null)}
        >
          {row.CY2achievement || "-"}
        </p>
        {hoveredCell === row.id + "-CY2achievement" && (
          <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
            {row.CY2achievement}
          </span>
        )}
      </div>
    )}
  </td>

  {/* Achievement */}
  <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center">
    <div className="relative">
      <p
        className="truncate max-w-[20rem] cursor-pointer"
        onMouseEnter={() => {
          if (row.achievement && row.achievement.length > 40) setHoveredCell(row.id + "-achievement");
        }}
        onMouseLeave={() => setHoveredCell(null)}
      >
        {row.achievement || "-"}
      </p>
      {hoveredCell === row.id + "-achievement" && (
        <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
          {row.achievement}
        </span>
      )}
    </div>
  </td>

  {/* Next Year 2 Target (editable) */}
  <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center">
    {canEdit ? (
      <input
  type="text"
  value={row.nextyear2target || ""}
  placeholder="0"
  inputMode="decimal"
  onChange={(e) => {
    const value = e.target.value;

    if (/^\d*\.?\d*$/.test(value)) {
      handleFieldChange(row.id, "nextyear2target", value);
    }
  }}
  className="w-full px-2 py-1 text-xs border border-gray-300 text-center focus:outline-none focus:ring-1 focus:ring-darkblue1 bg-white"
  disabled={savingIds.has(row.id)}
/>
    ) : (
      <div className="relative">
        <p
          className="truncate max-w-[20rem] cursor-pointer"
          onMouseEnter={() => {
            if (row.nextyear2target && row.nextyear2target.length > 40)
              setHoveredCell(row.id + "-nextyear2target");
          }}
          onMouseLeave={() => setHoveredCell(null)}
        >
          {row.nextyear2target || "-"}
        </p>
        {hoveredCell === row.id + "-nextyear2target" && (
          <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
            {row.nextyear2target}
          </span>
        )}
      </div>
    )}
  </td>


                <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-center">
                  {renderLocationCell(row, idx)}
                </td>
              </tr>
            ))}
            {filteredData2.length === 0 && (
              <tr>
                <td colSpan={8} className="text-center py-4 text-gray-500 italic">
                  No data found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
        {showScrollButtons && (
            <div className="fixed bottom-4 right-4 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

</div>
      {/* ========== SECOND TABLE - Mobile View ========== */}
      <div className="lg:hidden space-y-4">
        {filteredData2.length > 0 ? (
          filteredData2.map((row, idx) => (
            <div key={idx} className="bg-white shadow-md p-4 border border-gray-200">
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-sm text-mildBlue">Year:</span>
                <span className="text-sm">{row.year}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-sm text-mildBlue">Facility Type:</span>
                <span className="text-sm">{row.facilityType}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-sm text-mildBlue">Definition:</span>
                <span className="text-sm">{row.facilityDefinition}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-sm text-mildBlue">
                  {+selectedyear - 1} Target:
                </span>
                <span className="text-sm">{row.CY2target || "N/A"}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-sm text-mildBlue">
                  {+selectedyear - 1} EOY:
                </span>
                {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                {canEdit ? (
                  <input
                    type="number"
                    value={row.CY2achievement}
                    onChange={(e) => handleFieldChange(row.id, 'CY2achievement', e.target.value)}
                    className="w-24 px-2 py-1 text-sm border border-gray-300 text-center focus:outline-none focus:ring-1 focus:ring-darkblue1"
                    placeholder="0"
                    disabled={savingIds.has(row.id)}
                  />
                ) : (
                  <span className="text-sm">{row.CY2achievement || "N/A"}</span>
                )}
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-sm text-mildBlue">Achievement %:</span>
                <span className={`text-sm ${savingIds.has(row.id) ? "opacity-50" : ""}`}>
                  {row.achievement || "0.00"}
                </span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-sm text-mildBlue">
                  {selectedyear} Target:
                </span>
                {/* ⭐ FIXED: Use canEdit instead of !isAdmin */}
                {canEdit ? (
                  <input
                    type="number"
                    value={row.nextyear2target}
                    onChange={(e) => handleFieldChange(row.id, 'nextyear2target', e.target.value)}
                    className="w-24 px-2 py-1 text-sm border border-gray-300 text-center focus:outline-none focus:ring-1 focus:ring-darkblue1"
                    placeholder="0"
                    disabled={savingIds.has(row.id)}
                  />
                ) : (
                  <span className="text-sm">{row.nextyear2target || "N/A"}</span>
                )}
              </div>
              <div className="flex justify-between items-start">
                <span className="font-semibold text-sm text-mildBlue">Location & Count:</span>
                <div className="flex flex-col items-end">
                  {renderLocationCell(row, idx)}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-6 text-gray-500 italic">No data found.</div>
        )}
      </div>

      {/* ⭐ FIXED: Add/Edit Location Modal - Only for Users with canEdit on non-manageable rows */}
      {canEdit && showAddLocationModal && (
        <AddLocationModal
          onClose={() => {
            setShowAddLocationModal(false);
            setEditingLocation(null);
          }}
          onSave={handleSaveLocation}
          editingLocation={editingLocation}
        />
      )}
      {showDeleteModal && (
  <DeleteModal
    isOpen={showDeleteModal}
    onClose={() => {
      setShowDeleteModal(false);
      setDeleteLocationId(null);
    }}
    onConfirm={handleDeleteLocation}
    loading={deleteLoading}
  />
)}
    </div>
  );
};

// ========== ADD/EDIT LOCATION MODAL COMPONENT ========== 
function AddLocationModal({ onClose, onSave, editingLocation }) {
  const [location, setLocation] = useState(editingLocation?.name || "");
  const [count, setCount] = useState(editingLocation?.count?.toString() || "");

  useEffect(() => {
    if (editingLocation) {
      setLocation(editingLocation.name || "");
      setCount(editingLocation.count?.toString() || "");
    } else {
      setLocation("");
      setCount("");
    }
  }, [editingLocation]);

  const handleSave = () => {
    if (!location.trim()) {
      alert("Please enter a location");
      return;
    }
    onSave({
      id: editingLocation?.id,
      name: location.trim(),
      count: count.trim()
    });
    setLocation("");
    setCount("");
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white shadow-xl max-w-md w-full relative">
        <div className="flex items-center justify-center p-4 border-b relative">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-medium text-MediumGrey">
              {editingLocation ? "Edit Location" : "Add New Location"}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white bg-red1 rounded-full p-1 hover:bg-red-700 transition"
            aria-label="Close"
          >
            <X size={12} />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-2">
              Location<span className="text-red1">*</span>
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full px-3 py-1.5 border border-black/30 focus:outline-none text-xs"
              placeholder="Enter location"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-2">
              Count
            </label>
            <input
              type="number"
              value={count}
              onChange={(e) => setCount(e.target.value)}
              className="w-full px-3 py-1.5 border border-gray-300 focus:outline-none text-xs"
              placeholder="Enter count (optional)"
              min="0"
            />
          </div>
          <div className="flex items-center justify-center gap-4 mt-2">
            <button
              onClick={handleSave}
              className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
            >
              Save
            </button>
          </div>
        </div>
      </div>
      
    </div>
  );
}

export default Infrastructure;