import React, { useEffect, useState } from "react";
import Header from "../../../../../Components/Header";
import { Download } from "lucide-react";
import { jsPDF } from "jspdf"; // ✅ Correct import form
import autoTable from "jspdf-autotable"; // ✅ Must import like this

export default function TerritoryDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [data1, setData1] = useState([]);
  const [data2, setData2] = useState([]);
  const [year, setYear] = useState("");

  // 🔹 Receive data from parent tab
  useEffect(() => {
    const handler = (event) => {
      if (event.origin !== window.location.origin) return;
      if (event.data?.type === "INIT_TERRITORY_DATA") {
        setData1(event.data.payload.data1 || []);
        setData2(event.data.payload.data2 || []);
        setYear(event.data.payload.year || "");
        console.log("✅ Received data:", event.data.payload);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // 🔹 Handle PDF Download
   const handleDownload = () => {
    if (!data1.length && !data2.length) {
      alert("No data to download!");
      return;
    }

    const doc = new jsPDF({
      orientation: "landscape",
      unit: "pt",
      format: "A4",
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const title = `Territory Focus Report - ${year}`;
    doc.setFontSize(18);
    doc.setTextColor(32, 55, 100);
    doc.text(title, pageWidth / 2, 40, { align: "center" });

    // =========================
    // 🟢 TABLE 1: Territory Focus Details
    // =========================
    const table1Columns = [
      "City",
      "Branch",
      "Districts",
      "1st Segment",
      "2nd Segment",
      "3rd Segment",
      "4th Segment",
      "Overall Focus",
      "Responsible Person",
      `Total Plan ${year}`,
    ];

    const table1Rows = data1.map((item) => [
      item.city,
      item.branch,
      item.districts,
      item.fisrtsegmnet,
      item.secondsegmnet,
      item.thirdsegmnet,
      item.fourthsegmnet,
      item.overallfocus,
      item.responsibleperson,
      item.CYtotalplan,
    ]);

    autoTable(doc, {
      head: [table1Columns],
      body: table1Rows,
      startY: 60,
      theme: "grid",
      styles: {
        fontSize: 8,
        halign: "center",
        valign: "middle",
      },
      headStyles: {
        fillColor: [32, 55, 100], // darkblue1
        textColor: [255, 255, 255],
        halign: "center",
        fontStyle: "bold",
      },
      alternateRowStyles: { fillColor: [245, 247, 250] },
    });

    let finalY = doc.lastAutoTable.finalY + 40;

    // =========================
    // 🟣 TABLE 2: Territory Metrics
    // =========================
    doc.setFontSize(16);
    doc.setTextColor(224, 105, 0); // burnt orange
    // doc.text("Territory Metrics", pageWidth / 2, finalY, { align: "center" });

    const nextYear = Number(year) + 1;

    const table2Columns = [
      "Territory Focus",
      `GPE ${year}`,
      `GPE ${nextYear}`,
      `RM ${year}`,
      `RM ${nextYear}`,
      `SDLG ${year}`,
      `SDLG ${nextYear}`,
      `Attachment ${year}`,
      `Attachment ${nextYear}`,
      `Total ${year}`,
      `Total ${nextYear}`,
    ];

    const table2Rows = data2.map((label) => [
      label,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
    ]);

    autoTable(doc, {
      head: [table2Columns],
      body: table2Rows,
      startY: finalY + 15,
      theme: "grid",
      styles: {
        fontSize: 8,
        halign: "center",
        valign: "middle",
      },
      headStyles: {
        fillColor: [32, 55, 100], // same as web table header
        textColor: [255, 255, 255],
        halign: "center",
        fontStyle: "bold",
      },
      alternateRowStyles: { fillColor: [245, 247, 250] },
    });

    // ✅ Save File
    doc.save(`Territory_Focus_${year}.pdf`);
  };



  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        {/* Top bar */}
        <div className="mt-10 flex justify-between items-center mb-2">
          <h2 className="text-lg font-semibold text-darkblue1">Territory Focus</h2>
          <button
            onClick={handleDownload}
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-sm  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          >
          
            Download
          </button>
        </div>

        {/* 🟢 Table 1 */}
        <div className="bg-white shadow-md border border-Dustyblue mb-6 overflow-x-auto">
          <table className="w-full min-w-[800px] text-sm">
            <thead className="bg-Dustyblue text-white text-xs">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">City</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Branch</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Districts</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">1st Segment</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">2nd Segment</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">3rd Segment</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">4th Segment</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Overall Focus</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Responsible Person</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Total Plan {year}</th>
              </tr>
            </thead>
            <tbody>
              {data1.length === 0 ? (
                <tr>
                  <td colSpan={10} className="text-center py-4 text-gray-500 italic">
                    No data available
                  </td>
                </tr>
              ) : (
                data1.map((item, idx) => (
                  <tr key={idx} className="text-xs hover:bg-lightBlue/50">
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{item.city}</td>
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{item.branch}</td>
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{item.districts}</td>
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{item.fisrtsegmnet}</td>
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{item.secondsegmnet}</td>
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{item.thirdsegmnet}</td>
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{item.fourthsegmnet}</td>
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{item.overallfocus}</td>
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{item.responsibleperson}</td>
                    <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{item.CYtotalplan}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* 🟣 Table 2 */}
        <div className="bg-white  shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full text-sm text-center border-collapse">
            <thead>
              <tr className="bg-darkblue1 text-white">
                <th rowSpan="2" className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-2 text-left font-semibold">
                  Territory Focus
                </th>
                <th colSpan="2" className="text-xs border border-grey2 border-l-0 border  px-3 py-1.5 font-semibold">GPE</th>
                <th colSpan="2" className="text-xs border border-grey2 border-t-0 border-l-0  px-3 py-1.5 font-semibold">RM</th>
                <th colSpan="2" className="text-xs border border-grey2 border-t-0 border-l-0  px-3 py-1.5 font-semibold">SDLG</th>
                <th colSpan="2" className="text-xs border border-grey2 border-t-0 border-l-0  px-3 py-1.5 font-semibold">Attachment</th>
                <th colSpan="2" className="text-xs border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1.5 font-semibold">Total</th>
              </tr>
              <tr className="bg-Dustyblue text-white">
                {Array(5)
                  .fill([year, Number(year) + 1])
                  .flat()
                  .map((y, i) => (
                    <th key={i} className="border border-grey2 border-t-0 border-l-0 text-xs px-3 py-2 font-medium">{y}</th>
                  ))}
              </tr>
            </thead>
            <tbody>
              {data2.length === 0 ? (
                <tr>
                  <td colSpan={11} className="text-center py-4 text-gray-500 italic">
                    No data available
                  </td>
                </tr>
              ) : (
                data2.map((label, i) => (
                  <tr key={i} className="hover:bg-lightBlue/50 text-xs">
                    <td className="border px-4 py-1 border border-grey2 border-t-0 border-l-0 text-left">{label}</td>
                    {Array(10)
                      .fill("")
                      .map((_, j) => (
                        <td key={j} className="border px-3 py-2"></td>
                      ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
