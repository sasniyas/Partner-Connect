import React, { useState, useEffect } from "react";
import Header from "../../../../../Components/Header";
import { Download } from "lucide-react";
import * as XLSX from "xlsx";

export default function EquipmentDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [activeView, setActiveView] = useState("retail");

  // Listen for data from parent window
  useEffect(() => {
    const handler = (event) => {
      if (event.origin !== window.location.origin) return;
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
        setActiveView(event.data.activeView || "retail");
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const handleDownloadExcel = () => {
    if (!tableData.length) return alert("No data to download!");

    const rows = [["Equipment Type", "Equipment Make", "Equipment Line", "Target", "Total", "Measurement"]];

    tableData.forEach(section => {
      section.makes.forEach(make => {
        make.lines.forEach(line => {
          rows.push([
            section.type,
            make.name,
            line.line,
            line.target,
            line.total,
            line.measurement
          ]);
        });
      });
    });

    const worksheet = XLSX.utils.aoa_to_sheet(rows);

    // Left-align all cells
    Object.keys(worksheet).forEach(cell => {
      if (!cell.startsWith("!")) {
        worksheet[cell].s = { alignment: { horizontal: "left", vertical: "center" } };
      }
    });

    // Auto column width
    const colWidths = rows[0].map((col, idx) => ({
      wch: Math.max(
        col.length,
        ...rows.slice(1).map(r => (r[idx] ? r[idx].toString().length : 10))
      ) + 2
    }));
    worksheet["!cols"] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, activeView === "retail" ? "Retail_Equipment" : "Key_Account_Equipment");
    XLSX.writeFile(workbook, `${activeView === "retail" ? "Retail" : "KeyAccount"}_Equipment.xlsx`);
  };

  const getTotalRowsForType = (section) =>
    section.makes.reduce((sum, make) => sum + make.lines.length, 0);

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col  p-4">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className="mt-10 mb-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold text-darkblue1">
          {activeView === "retail" ? "Retail Equipment" : "Key Account Equipment"}
        </h2>

        <button
          onClick={handleDownloadExcel}
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-sm  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
        >
        
          Download
        </button>
      </div>

      {/* Table with styled borders */}
      <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-Dustyblue">
          <thead className="bg-Dustyblue text-white text-left">
            <tr>
              <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5">Equipment Type</th>
              <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0px-3 py-1.5">Equipment Make</th>
              <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5">Equipment Line</th>
              <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5">Target</th>
              <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5">Total</th>
              <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 px-3 py-1.5">Measurement</th>
            </tr>
          </thead>
          <tbody>
            {tableData.length === 0 ? (
              <tr>
                <td colSpan={6} className="text-center py-6 text-gray-500 italic">
                  No data available
                </td>
              </tr>
            ) : (
              tableData.map((section, sectionIdx) => {
                let typeRowSpan = getTotalRowsForType(section);
                let typeRowRendered = false;

                return section.makes.map((make, makeIdx) =>
                  make.lines.map((lineItem, lineIdx) => {
                    const isFirstRowOfType = !typeRowRendered;
                    if (isFirstRowOfType) typeRowRendered = true;
                    const isFirstRowOfMake = lineIdx === 0;

                    return (
                      <tr key={`${sectionIdx}-${makeIdx}-${lineIdx}`} className="odd:bg-white even:bg-gray-50 hover:bg-lightBlue/50 transition">
                        {isFirstRowOfType && (
                          <td rowSpan={typeRowSpan} className="border border-black/30 px-3 py-2 font-semibold text-SteelBlue cursor-pointer">
                            {section.type}
                          </td>
                        )}
                        {isFirstRowOfMake && (
                          <td rowSpan={make.lines.length} className="border border-black/30 px-3 py-2">
                            {make.name}
                          </td>
                        )}
                        <td className="border border-grey2 border-t-0 border-l-0px-3 py-1">{lineItem.line}</td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{lineItem.target}</td>
                        <td className="bborder border-grey2 border-t-0 border-l-0 px-3 py-1">{lineItem.total}</td>
                        <td className="border border-grey2 border-t-0 border-l-0 bordeer-r-0 px-3 py-1">{lineItem.measurement}</td>
                      </tr>
                    );
                  })
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
