import React, { useState, useEffect } from "react";
import Header from "../../../../../Components/Header";
import { Download } from "lucide-react";
import * as XLSX from "xlsx";

export default function Infrastructuredownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]);

  // Receive data from parent
  useEffect(() => {
    const handler = (event) => {
      if (event.origin !== window.location.origin) return;
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // Excel download logic
  const handleDownloadExcel = () => {
    if (!tableData.length) return alert("No data to download!");

    const formattedData = tableData.map((item, index) => ({
      "Sl. No": index + 1,
      Year: item.year,
      "Facility Type": item.facilityType,
      Definition: item.facilityDefinition,
      "CY Target": item.CY2target || "",
      "CY Achievement (EOY)": item.CY2achievement || "",
      "Achievement %": item.achievement || "",
      "Next Year Target": item.nextyear2target || "",
      "Location & Count": item.loaction || "N/A",
    }));

    const worksheet = XLSX.utils.json_to_sheet(formattedData);

    // Left-align all cells
    Object.keys(worksheet).forEach((cell) => {
      if (!cell.startsWith("!")) {
        worksheet[cell].s = { alignment: { horizontal: "left", vertical: "center" } };
      }
    });

    // Auto column width
    const colWidths = Object.keys(formattedData[0]).map((key) => ({
      wch: Math.max(
        key.length,
        ...formattedData.map((row) => (row[key] ? row[key].toString().length : 10))
      ) + 2,
    }));
    worksheet["!cols"] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Infrastructure");
    XLSX.writeFile(workbook, "Infrastructure.xlsx");
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        {/* Header */}
        <div className="mt-10 mb-4 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">
            Infrastructure 
          </h2>

          <button
            onClick={handleDownloadExcel}
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-sm  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          >
          
            Download
          </button>
        </div>

        {/* Table */}
        <div className="bg-white shadow-md  border border-Dustyblue overflow-x-auto">
          <table className="w-full text-sm border-collapse border border-Dustyblue">
            <thead className="bg-Dustyblue text-white text-left">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Sl. No</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Year</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Facility Type</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Definition</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">CY Target</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">CY Achievement (EOY)</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Achievement %</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Next Year Target</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0">Location & Count</th>
              </tr>
            </thead>
            <tbody>
              {tableData.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-6 text-gray-500 italic">
                    No data available
                  </td>
                </tr>
              ) : (
                tableData.map((row, index) => (
                  <tr
                    key={index}
                    className="text-xs hover:bg-lightBlue/50 transition"
                  >
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{index + 1}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{row.year}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{row.facilityType}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{row.facilityDefinition}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{row.CY2target}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{row.CY2achievement}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{row.achievement}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{row.nextyear2target}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                      {row.loaction || (
                        <span className="text-gray-400 italic">N/A</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
