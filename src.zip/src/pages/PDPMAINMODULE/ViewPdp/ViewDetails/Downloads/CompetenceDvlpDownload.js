import React, { useEffect, useState } from "react";
import Header from "../../../../../Components/Header";
import { Download } from "lucide-react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

export default function CompetenceDvlpDownload() {
  const [year, setYear] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [data1, setData1] = useState([]);
  const [data2, setData2] = useState([]);
  const [data3, setData3] = useState([]);

  // 🟢 Receive data from opener window
  useEffect(() => {
    const handler = (event) => {
      if (event.origin !== window.location.origin) return;
      if (event.data?.type === "INIT_COMPETENCE_DATA") {
        const { year, selectedCategory, data1, data2, data3 } = event.data.payload;
        setYear(year || "");
        setSelectedCategory(selectedCategory || "");
        setData1(data1 || []);
        setData2(data2 || []);
        setData3(data3 || []);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // 🟣 Handle PDF Download
  const handleDownload = () => {
    if (!data1.length && !data2.length && !data3.length) {
      alert("No data to download!");
      return;
    }

    const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "A4" });
    const pageWidth = doc.internal.pageSize.getWidth();

    doc.setFontSize(18);
    doc.setTextColor(32, 55, 100);
    doc.text(`Competence Development Report - ${year}`, pageWidth / 2, 40, { align: "center" });

    // 1️⃣ Base Table
    if (data1.length) {
      autoTable(doc, {
        startY: 60,
        head: [["", `${+year - 1} Target`, `${+year - 1} (EOY)`, `${year} Target`]],
        body: data1.map((r) => [r.field1, r.LStarget, r.LSeoy, r.CYtarget]),
        theme: "grid",
        styles: { fontSize: 9, halign: "center", valign: "middle" },
        headStyles: { fillColor: [32, 55, 100], textColor: [255, 255, 255] },
        alternateRowStyles: { fillColor: [245, 247, 250] },
      });
    }

    let finalY = doc.lastAutoTable.finalY + 30;

    // 2️⃣ Second Table
    if (data2.length) {
      doc.setFontSize(14);
      doc.setTextColor(224, 105, 0);
      doc.text(`Category: ${selectedCategory}`, 40, finalY);
      autoTable(doc, {
        startY: finalY + 10,
        head: [
          ["Competence Development", `${+year - 1} Target`, `${+year - 1} (EOY)`, `${year} Target`],
        ],
        body: data2.map((r) => [r.competencedevelopment, r.LS2target, r.LS2eoy, r.CY2target]),
        theme: "grid",
        styles: { fontSize: 9, halign: "center", valign: "middle" },
        headStyles: { fillColor: [32, 55, 100], textColor: [255, 255, 255] },
        alternateRowStyles: { fillColor: [245, 247, 250] },
      });
      finalY = doc.lastAutoTable.finalY + 30;
    }

    // 3️⃣ Third Table
    if (data3.length) {
      autoTable(doc, {
        startY: finalY,
        head: [
          [
            "Year",
            "Competence Type",
            `${+year - 1} Target`,
            `${+year - 1} (EOY)`,
            `${year} Target`,
            "Remarks",
          ],
        ],
        body: data3.map((r) => [
          r.year,
          r.competencetype,
          r.LS3target,
          r.LS3eoy,
          r.CY3target,
          r.remark,
        ]),
        theme: "grid",
        styles: { fontSize: 9, halign: "center", valign: "middle" },
        headStyles: { fillColor: [32, 55, 100], textColor: [255, 255, 255] },
        alternateRowStyles: { fillColor: [245, 247, 250] },
      });
    }

    doc.save(`Competence_Development_${selectedCategory}_${year}.pdf`);
  };

  // 🟢 Simple Preview Rendering
  return (
    
     <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header  />
     <div className=" w-full p-4">
      <div className=" mt-10 flex justify-between items-center mb-4">
        <h1 className="text-xl font-semibold text-darkblue1">
          Competence Development 
        </h1>
        <button
          onClick={handleDownload}
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-sm hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
        >
        
          Download 
        </button>
      </div>

      {/* Table 1 */}
      {data1.length > 0 && (
        <div className="overflow-x-auto border border-gray-300  mb-6">
          <table className="w-full text-sm border-collapse">
            <thead className="bg-Dustyblue text-white text-left">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0"></th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">{+year - 1} Target</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">{+year - 1} (EOY)</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0">{year} Target</th>
              </tr>
            </thead>
            <tbody>
              {data1.map((r, i) => (
                <tr key={i} className="text-xs text-left">
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.field1}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.LStarget}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.LSeoy}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">{r.CYtarget}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Table 2 */}
      {data2.length > 0 && (
        <div className="overflow-x-auto border border-gray-300  mb-6">
          {/* <h2 className="font-medium text-burntorange mb-2">
            Category: {selectedCategory}
          </h2> */}
          <table className="w-full text-sm border-collapse">
            <thead className="bg-Dustyblue text-white text-left">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Competence Development</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">{+year - 1} Target</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">{+year - 1} (EOY)</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0">{year} Target</th>
              </tr>
            </thead>
            <tbody>
              {data2.map((r, i) => (
                <tr key={i} className="text-left text-xs">
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.competencedevelopment}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.LS2target}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.LS2eoy}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">{r.CY2target}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Table 3 */}
      {data3.length > 0 && (
        <div className="overflow-x-auto border border-gray-300 ">
          <table className="w-full text-sm border-collapse">
            <thead className="bg-Dustyblue text-white text-left">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Year</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Competence Type</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">{+year - 1} Target</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">{+year - 1} (EOY)</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">{year} Target</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0">Remarks</th>
              </tr>
            </thead>
            <tbody>
              {data3.map((r, i) => (
                <tr key={i} className="text-left text-xs">
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.year}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.competencetype}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.LS3target}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.LS3eoy}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{r.CY3target}</td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">{r.remark}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
    </div>
  );
}
