import React, { useState, useEffect } from "react";
import Header from "../../../../../Components/Header";
import { Download } from "lucide-react";
import * as XLSX from "xlsx";

export default function MarcomDownloadPreview() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [data, setData] = useState([]);
  const [activeView, setActiveView] = useState("branding");

  // 🧩 Listen for data from parent window
  useEffect(() => {
    const handler = (event) => {
      if (event.origin !== window.location.origin) return;
      if (event.data?.type === "INIT_DATA") {
        setData(event.data.payload.data || []);
        setActiveView(event.data.payload.activeView || "branding");
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // 🧩 Download Excel
  const handleDownloadExcel = () => {
    if (!data.length) return alert("No data to download!");

    const rows = [];

    if (activeView === "branding") {
      rows.push(["Year", "Marcom Master", "Branding Element", "Budget", "Remarks", "Supportive Document"]);
      data.forEach(section => {
        section.elements.forEach(el => {
          el.lines.forEach(line => {
            rows.push([section.year, section.MarcomMaster, el.name, line.budget, line.remark, line.supportivedocument]);
          });
        });
      });
    } else {
      rows.push([
        "Year",
        "Activity Type",
        "Marketing Area",
        "Target",
        "Count of Activities",
        "Activity Description",
        "Amount Spent",
        "Impacts / Comments",
      ]);
      data.forEach(item => {
        rows.push([
          item.year,
          item.activityType,
          item.marketingArea,
          item.target,
          item.countOfActivities,
          item.activityDescription,
          item.amountSpent,
          item.impactsComments,
        ]);
      });
    }

    const worksheet = XLSX.utils.aoa_to_sheet(rows);

    // Left-align all cells
    Object.keys(worksheet).forEach((cell) => {
      if (!cell.startsWith("!")) {
        worksheet[cell].s = { alignment: { horizontal: "left", vertical: "center" } };
      }
    });

    // Auto column width
    const colWidths = rows[0].map((col, idx) => ({
      wch: Math.max(
        col.length,
        ...rows.slice(1).map(r => (r[idx] ? r[idx].toString().length : 10))
      ) + 2,
    }));
    worksheet["!cols"] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, activeView === "branding" ? "Marcom_Branding" : "Marcom_Marketing");
    XLSX.writeFile(workbook, `${activeView === "branding" ? "Branding" : "Marketing"}_Preview.xlsx`);
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        {/* 🔹 Header Section */}
        <div className="mt-10 mb-4 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">
            {activeView === "branding" ? "Marcom/Branding" : "Marcom/Marketing "}
          </h2>

          {/* ✅ Download Button */}
          <button
            onClick={handleDownloadExcel}
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-sm   hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          >
            Download
          </button>
        </div>

        {/* 🔹 Table Section */}
        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full min-w-[800px] text-sm">
            <thead className="bg-Dustyblue text-white text-left">
              {activeView === "branding" ? (
                <tr>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Year</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Marcom Master</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Branding Element</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0  font-medium">Budget</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Remarks</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium">Supportive Document</th>
                </tr>
              ) : (
                <tr>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Year</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Activity Type</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Marketing Area</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Target</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Count of Activities</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Activity Description</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Amount Spent</th>
                  <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium">Impacts / Comments</th>
                </tr>
              )}
            </thead>
            <tbody>
              {data.length === 0 ? (
                <tr>
                  <td
                    colSpan={activeView === "branding" ? 6 : 8}
                    className="text-center py-6 text-gray-500 italic"
                  >
                    No data available
                  </td>
                </tr>
              ) : activeView === "branding" ? (
                data.map((section, sectionIdx) =>
                  section.elements.map((el, elIdx) =>
                    el.lines.map((line, lineIdx) => (
                      <tr key={`${sectionIdx}-${elIdx}-${lineIdx}`} className=" hover:bg-lightBlue/50 text-xs">
                        {lineIdx === 0 && <td rowSpan={el.lines.length} className="px-6 py-4">{section.year}</td>}
                        {lineIdx === 0 && <td rowSpan={el.lines.length} className="px-6 py-4">{section.MarcomMaster}</td>}
                        {lineIdx === 0 && <td rowSpan={el.lines.length} className="px-6 py-4">{el.name}</td>}
                        <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0">{line.budget}</td>
                        <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0">{line.remark}</td>
                        <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">{line.supportivedocument}</td>
                      </tr>
                    ))
                  )
                )
              ) : (
                data.map((item, idx) => (
                  <tr key={idx} className="text-xs hover:bg-lightBlue/50">
                    <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0">{item.year}</td>
                    <td className="px-6 py-1  border border-grey2 border-t-0 border-l-0">{item.activityType}</td>
                    <td className="px-6 py-1  border border-grey2 border-t-0 border-l-0">{item.marketingArea}</td>
                    <td className="px-6 py-1  border border-grey2 border-t-0 border-l-0">{item.target}</td>
                    <td className="px-6 py-1  border border-grey2 border-t-0 border-l-0">{item.countOfActivities}</td>
                    <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0">{item.activityDescription}</td>
                    <td className="px-6 py-1  border border-grey2 border-t-0 border-l-0">{item.amountSpent}</td>
                    <td className="px-6 py-1  border border-grey2 border-t-0 border-l-0 border-r-0">{item.impactsComments}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
