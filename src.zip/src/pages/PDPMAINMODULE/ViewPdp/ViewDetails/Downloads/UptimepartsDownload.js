import React, { useState, useEffect } from "react";
import Header from "../../../../../Components/Header";
import { Download } from "lucide-react";
import * as XLSX from "xlsx";

export default function EquipmentDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [activeView, setActiveView] = useState("retail");

  // Listen for data from parent window
  useEffect(() => {
    const handler = (event) => {
      if (event.origin !== window.location.origin) return;
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
        setActiveView(event.data.activeView || "retail");
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const handleDownloadExcel = () => {
    if (!tableData.length) return alert("No data to download!");

    const rows = [["Equipment Type", "Equipment Make", "Equipment Line", "Target", "Total", "Measurement"]];

    tableData.forEach(section => {
      section.makes.forEach(make => {
        make.lines.forEach(line => {
          rows.push([
            section.type,
            make.name,
            line.line,
            line.target,
            line.total,
            line.measurement
          ]);
        });
      });
    });

    const worksheet = XLSX.utils.aoa_to_sheet(rows);

    // Left-align all cells
    Object.keys(worksheet).forEach(cell => {
      if (!cell.startsWith("!")) {
        worksheet[cell].s = { alignment: { horizontal: "left", vertical: "center" } };
      }
    });

    // Auto column width
    const colWidths = rows[0].map((col, idx) => ({
      wch: Math.max(
        col.length,
        ...rows.slice(1).map(r => (r[idx] ? r[idx].toString().length : 10))
      ) + 2
    }));
    worksheet["!cols"] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, activeView === "retail" ? "Retail_Uptimeparts" : "Key_Account_Uptimeparts");
    XLSX.writeFile(workbook, `${activeView === "retail" ? "Retail" : "KeyAccount"}_Uptimeparts.xlsx`);
  };

  const getTotalRowsForType = (section) =>
    section.makes.reduce((sum, make) => sum + make.lines.length, 0);

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col  p-4">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className="mt-10 mb-2 flex justify-between items-center">
        <h2 className="text-lg font-semibold text-darkblue1">
          {activeView === "retail" ? "Retail Uptime & parts" : "Key Account Uptime & parts"}
        </h2>

        <button
          onClick={handleDownloadExcel}
            className="bg-darkblue1 text-white font-medium px-4 py-2  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
        >
          
          Download
        </button>
      </div>

      {/* Table with styled borders */}
      <div className="bg-white shadow-md  border border-Dustyblue overflow-x-auto">
         <table className="w-full border border-Dustyblue  overflow-hidden text-sm border-collapse">
            <thead className="bg-Dustyblue text-white text-left">
              <tr>
<th className="border border-Dustyblue border-r-black/30 px-3 py-2">
 Uptime and Parts
</th>
                <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5">Equipment Make</th>
                <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5">Equipment Line</th>
                <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5">Target</th>
                <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 px-3 py-1.5">Total</th>
                <th className="text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 px-3 py-1.5">Measurement</th>
              </tr>
            </thead>
            <tbody>
              {tableData.map((section, sectionIdx) => {
                let typeRowSpan = getTotalRowsForType(section);
                let typeRowRendered = false;

                return section.makes.map((make, makeIdx) =>
                  make.lines.map((lineItem, lineIdx) => {
                    const isFirstRowOfMake = lineIdx === 0;
                    const isFirstRowOfType = !typeRowRendered;
                    if (isFirstRowOfType) typeRowRendered = true;

                    return (
                      <tr
                        key={`${sectionIdx}-${makeIdx}-${lineIdx}`}
                        className="hover:bg-lightBlue/50 transition duration-300 cursor-pointer text-xs"
                      >
                        {isFirstRowOfType && (
                          <td
                            rowSpan={typeRowSpan}
                            className="border border-grey2 border-t-0 border-l-0 px-3 py-1 font-semibold text-SteelBlue underline cursor-pointer"
                          >
                            {section.category}
                          </td>
                        )}
                        {isFirstRowOfMake && (
                          <td
                            rowSpan={make.lines.length}
                            className="border border-grey2 border-t-0 border-l-0 px-3 py-1"
                          >
                            {make.name}
                          </td>
                        )}
<td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">
  {lineItem.line}
</td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{lineItem.target}</td>
                        <td className="border border-grey2 border-t-0 border-l-0 px-3 py-1">{lineItem.total}</td>
                        <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-3 py-1">{lineItem.measurement}</td>
                      </tr>
                    );
                  })
                );
              })}
            </tbody>
            {tableData.length === 0 && (
  <tr>
    <td colSpan={6} className="text-center py-4 text-gray-500 italic">
      No data found.
    </td>
  </tr>
)}

          </table>
     
      </div>
    </div>
  );
}
