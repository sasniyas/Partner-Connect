import React, { useState, useEffect } from "react";
import Header from "../../../../../Components/Header";
import { Download } from "lucide-react";
import * as XLSX from "xlsx";

export default function OthersDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]);

  // 🧩 Listen for data from parent window
  useEffect(() => {
    const handler = (event) => {
      if (event.origin !== window.location.origin) return;
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // 🧩 Download Excel file
 const handleDownloadExcel = () => {
  if (!tableData.length) return alert("No files to download!");

  const formattedData = tableData.map((file, index) => ({
  "Sl. No": (index + 1).toString(), // <-- make it string
  "File Name": file.fileName,
  "Optional Document": file.optionalDoc ? file.optionalDoc.name : "No file",
  "Document URL": file.optionalDoc?.url || "",
}));

  const worksheet = XLSX.utils.json_to_sheet(formattedData, {
    header: ["Sl. No", "File Name", "Optional Document"],
  });

  // Left-align all cells
  Object.keys(worksheet).forEach((cell) => {
    if (!cell.startsWith("!")) {
      worksheet[cell].s = { alignment: { horizontal: "left", vertical: "center" } };
    }
  });

  // Auto column width
  const colWidths = ["Sl. No", "File Name", "Optional Document"].map((key) => ({
    wch: Math.max(
      key.length,
      ...formattedData.map((row) => (row[key] ? row[key].toString().length : 10))
    ) + 2,
  }));
  worksheet["!cols"] = colWidths;

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Others ");
  XLSX.writeFile(workbook, "Others.xlsx");
};



  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "ml-60" : ""
        } p-4`}
      >
        {/* 🔹 Header Section */}
        <div className="mt-10 mb-4 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">
            Others 
          </h2>

          {/* ✅ Download Button */}
          <button
            onClick={handleDownloadExcel}
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-smhover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          >
           
            Download
          </button>
        </div>

        {/* 🔹 Table Section */}
        <div className="bg-white shadow-md  border border-Dustyblue overflow-x-auto">
          <table className="w-full min-w-[600px] text-sm">
            <thead className="bg-Dustyblue text-white text-left text-xs">
              <tr>
                <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0  font-medium">Sl. No</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">File Name</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium">Optional Document</th>
              </tr>
            </thead>
            <tbody>
              {tableData.length === 0 ? (
                <tr>
                  <td
                    colSpan={3}
                    className="text-center py-6 text-gray-500 italic"
                  >
                    No files uploaded
                  </td>
                </tr>
              ) : (
                tableData.map((file, index) => (
                  <tr
                    key={index}
                    className="text-xsv text-left hover:bg-lightBlue/50"
                  >
                    <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0">{index + 1}</td>
                    <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0">{file.fileName}</td>
                    <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0">
                      {file.optionalDoc ? (
                        <a
                          href={URL.createObjectURL(file.optionalDoc)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 underline hover:text-blue-800"
                        >
                          {file.optionalDoc.name}
                        </a>
                      ) : (
                        <span className="text-gray-400 italic">No file</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
