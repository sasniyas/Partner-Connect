import React, { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { ArrowLeft, Plus, Pencil, Trash2 } from "lucide-react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import DeleteModal from "../../../../Components/DeleteModal";
import Filter from "../../../../Components/Filter";
import Searchinput from "../../../../Components/Searchinput";
import { ChevronUp,ChevronsUpDown,ArrowUp,ArrowDown } from "lucide-react";
import { ChevronDown } from "lucide-react";
const InfrastructureVehiclesPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") setSortOrder("desc");
    else {
      setSortKey(null);
      setSortOrder(null);
    }
    return;
  }
  setSortKey(key);
  setSortOrder("asc");
};
  // Get data from navigation state
  const vehicleType = location.state?.vehicleType || "";
  const initialVehicles = location.state?.vehicles || [];
  const rowIndex = location.state?.rowIndex;
  const year = location.state?.year || "";
  const facilityDefinition = location.state?.facilityDefinition || "";
  const isAdmin = location.state?.isAdmin || false;
  const rowData = location.state?.rowData || {};

  const [vehiclesData, setVehiclesData] = useState(initialVehicles);
  
  // Search and Filter states
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedVehicleTypes, setSelectedVehicleTypes] = useState([]);
  const [selectedMakes, setSelectedMakes] = useState([]);
  const [selectedUtilizationRates, setSelectedUtilizationRates] = useState([]);
const tableContainerRef = useRef(null);
  // Track the last processed state to prevent duplicates
  const lastProcessedStateRef = useRef(null);

  // Lazy loading states
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(false);
  const observerRef = useRef();

  const itemsPerLoad = 10;

  // Extract unique values for filters
  const vehicleTypeOptions = useMemo(() => {
    const uniqueTypes = [...new Set(vehiclesData.map(v => v.vehicleType))].filter(Boolean);
    return uniqueTypes.sort();
  }, [vehiclesData]);

  const makeOptions = useMemo(() => {
    const uniqueMakes = [...new Set(vehiclesData.map(v => v.make))].filter(Boolean);
    return uniqueMakes.sort();
  }, [vehiclesData]);

  const utilizationRateOptions = useMemo(() => {
    const uniqueRates = [...new Set(vehiclesData.map(v => v.utilizationRate))].filter(Boolean);
    return uniqueRates.sort();
  }, [vehiclesData]);

  // Filter data based on search and filters
  const filteredData = useMemo(() => {
    return vehiclesData.filter(vehicle => {
      // Search filter
      const searchLower = searchQuery.toLowerCase();
      const matchesSearch = 
        vehicle.vehicleType?.toLowerCase().includes(searchLower) ||
        vehicle.make?.toLowerCase().includes(searchLower) ||
        vehicle.model?.toLowerCase().includes(searchLower) ||
        vehicle.regNo?.toLowerCase().includes(searchLower) ||
        vehicle.operatingArea?.toLowerCase().includes(searchLower) ||
        vehicle.assignedTo?.toLowerCase().includes(searchLower) ||
        vehicle.yearOfPurchase?.toLowerCase().includes(searchLower);

      // Dropdown filters
      const matchesVehicleType = selectedVehicleTypes.length === 0 || selectedVehicleTypes.includes(vehicle.vehicleType);
      const matchesMake = selectedMakes.length === 0 || selectedMakes.includes(vehicle.make);
      const matchesUtilization = selectedUtilizationRates.length === 0 || selectedUtilizationRates.includes(vehicle.utilizationRate);

      return matchesSearch && matchesVehicleType && matchesMake && matchesUtilization;
    });
  }, [vehiclesData, searchQuery, selectedVehicleTypes, selectedMakes, selectedUtilizationRates]);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const A = a[sortKey];
    const B = b[sortKey];

    if (typeof A === "number" && typeof B === "number") {
      return sortOrder === "asc" ? A - B : B - A;
    }

    return sortOrder === "asc"
      ? String(A ?? "").localeCompare(String(B ?? ""))
      : String(B ?? "").localeCompare(String(A ?? ""));
  });
}, [filteredData, sortKey, sortOrder]);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


  // Check if new vehicle was added or existing vehicle was updated
  useEffect(() => {
    const currentState = location.state;
    
    const stateKey = currentState?.newVehicle 
      ? `new-${JSON.stringify(currentState.newVehicle)}`
      : currentState?.updatedVehicle 
      ? `update-${currentState.updatedVehicle.id}`
      : null;

    if (!stateKey || lastProcessedStateRef.current === stateKey) {
      return;
    }

    if (currentState?.newVehicle) {
      const newVehicle = {
        ...currentState.newVehicle,
        id: Date.now() + Math.random(),
        slNo: (vehiclesData.length + 1).toString()
      };
      
      setVehiclesData(prev => [newVehicle, ...prev]);
      lastProcessedStateRef.current = stateKey;
      
      setTimeout(() => {
        navigate(location.pathname, { 
          replace: true, 
          state: { 
            ...location.state,
            newVehicle: undefined,
            vehicles: [newVehicle, ...vehiclesData]
          } 
        });
      }, 100);
      
    } else if (currentState?.updatedVehicle) {
      const updatedVehicle = currentState.updatedVehicle;
      
      setVehiclesData(prev => 
        prev.map(vehicle => 
          vehicle.id === updatedVehicle.id ? updatedVehicle : vehicle
        )
      );
      
      lastProcessedStateRef.current = stateKey;
      
      setTimeout(() => {
        navigate(location.pathname, { 
          replace: true, 
          state: { 
            ...location.state,
            updatedVehicle: undefined,
            vehicles: vehiclesData.map(v => v.id === updatedVehicle.id ? updatedVehicle : v)
          } 
        });
      }, 100);
    }
  }, [location.state, location.pathname, navigate, vehiclesData]);

  // Load more items function
  const loadMoreItems = useCallback(() => {
    if (isLoading || !hasMore) return;

    setIsLoading(true);
    
    setTimeout(() => {
      const currentLength = displayedItems.length;
      const nextItems = sortedData.slice(currentLength, currentLength + itemsPerLoad);
      
      if (nextItems.length === 0) {
        setHasMore(false);
      } else {
        setDisplayedItems(prev => [...prev, ...nextItems]);
      }
      
      setIsLoading(false);
    }, 300);
  }, [displayedItems.length, sortedData, isLoading, hasMore, itemsPerLoad]);

  // Intersection Observer callback
  const lastItemRef = useCallback(node => {
    if (isLoading) return;
    if (observerRef.current) observerRef.current.disconnect();
    
    observerRef.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        loadMoreItems();
      }
    });
    
    if (node) observerRef.current.observe(node);
  }, [isLoading, hasMore, loadMoreItems]);

  // Reset displayed items when filters change
  useEffect(() => {
    setDisplayedItems(sortedData.slice(0, itemsPerLoad));
    setHasMore(sortedData.length > itemsPerLoad);
    setIsLoading(false);
  }, [sortedData, itemsPerLoad]);

  const handleBack = () => {
    // Navigate back to infrastructure with updated vehicles
    const backPath = "/pdp/viewdetails"
console.log("Back Data",rowIndex)
    navigate(backPath, {
      state: {
        activeTab: "Infrastructure",
        rowData: rowData,
        updatedVehicles: vehiclesData,
        rowIndex: rowIndex
      }
    });
  };

  const handleAddNew = () => {
    const addPath ="/pdp/viewdetails/infrastructure/vehicles/add"

    navigate(addPath, {
      state: {
        vehicleType,
        year,
        facilityDefinition,
        isAdmin,
        rowData,
        rowIndex,
        returnPath: location.pathname,
        currentVehicles: vehiclesData
      }
    });
  };

  const handleEdit = (vehicleId) => {
    const vehicleToEdit = vehiclesData.find(v => v.id === vehicleId);
    
    const editPath =`/pdp/viewdetails/infrastructure/vehicles/edit/${vehicleId}`

    navigate(editPath, {
      state: {
        vehicleData: vehicleToEdit,
        vehicleType,
        year,
        facilityDefinition,
        isAdmin,
        rowData,
        rowIndex,
        returnPath: location.pathname,
        currentVehicles: vehiclesData
      }
    });
  };

  const handleDelete = async (rowIdx) => {
    if (rowIdx === null) return;

    setDeleteLoading(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));

      const updated = [...vehiclesData];
      updated.splice(rowIdx, 1);
      
      // Re-number the slNo
      const renumbered = updated.map((v, idx) => ({
        ...v,
        slNo: (idx + 1).toString()
      }));
      
      setVehiclesData(renumbered);
      setDisplayedItems(renumbered.slice(0, displayedItems.length - 1));

      setIsDeleteModalOpen(false);
      setSelectedRow(null);
      alert("Vehicle deleted successfully!");
    } catch (error) {
      console.error("Error deleting vehicle:", error);
      alert("Failed to delete vehicle");
    } finally {
      setDeleteLoading(false);
    }
  };

  const getPageTitle = () => {
    if (vehicleType === "sales") {
      return `Sales Vehicles - 4-Wheeler (${year})`;
    } else if (vehicleType === "service") {
      return `Service Vehicles - 4-Wheeler (${year})`;
    }
    return `Vehicles (${year})`;
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2">
            <div className="flex items-center gap-2">
              <button
                onClick={handleBack}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              >
                <ArrowLeft size={16} />
              </button>
              <div>
                <h1 className="text-base  font-semibold text-darkblue1">
                  {getPageTitle()}
                </h1>
                <p className="text-sm text-gray-600 ">{facilityDefinition}</p>
              </div>
            </div>
            {!isAdmin && (
              <button
                onClick={handleAddNew}
                className="bg-darkblue1 text-white px-4 py-1.5  font-medium text-xs hover:bg-darkblue1/90 transition flex items-center justify-center gap-2 w-full sm:w-auto"
              >
                <Plus size={12} />
                Add New Vehicle
              </button>
            )}
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col lg:flex-row gap-2 mb-2">
            <div className="">
              <Searchinput
                onChange={(e) => setSearchQuery(e.target.value)}
                value={searchQuery}
                placeholder="Search"
                className="w-[1/2]"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-8 pr-3 py-2"
                iconSize="w-4 h-4"
                iconLeft="left-3"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />
            </div>

            <div className="flex flex-wrap gap-2">
              {/* Vehicle Type Filter */}
              <Filter
                name="vehicleType"
                placeholder="Vehicle Type"
                options={vehicleTypeOptions}
                value={selectedVehicleTypes}
                onChange={(name, value) => setSelectedVehicleTypes(value)}
                customWidth="w-[120px]"
                textColor="text-black"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
              />

              {/* Make Filter */}
              <Filter
                name="make"
                placeholder="Make"
                options={makeOptions}
                value={selectedMakes}
                onChange={(name, value) => setSelectedMakes(value)}
                customWidth="w-[120px]"
                textColor="text-black"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
              />

              {/* Utilization Rate Filter */}
              <Filter
                name="utilizationRate"
                placeholder="Utilisation Rate"
                options={utilizationRateOptions}
                value={selectedUtilizationRates}
                onChange={(name, value) => setSelectedUtilizationRates(value)}
                customWidth="w-[160px]"
                textColor="text-black"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
              />
            </div>
          </div>

          {/* Desktop Table */}
          <div className="hidden lg:block bg-white  shadow-md border   border-Dustyblue overflow-hidden">
             <div
              ref={tableContainerRef}
              className="
    w-full 
    overflow-y-auto 
    overflow-x-hidden

 
      lg:max-h-[65vh] 
      xl:max-h-[58vh] 
      2xl:max-h-[65vh]
  "
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                 onScroll={handleTableScroll}
            >
              <table className="w-full border-collapse" style={{ borderCollapse: 'collapse' }}>
                <thead className="bg-Dustyblue text-white sticky top-0 z-10 text-left">
                  <tr>
                   <th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort("vehicleType")}
>
  <div className="flex items-center gap-1">
    Vehicle Type
    {sortKey !== "vehicleType" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
    {sortKey === "vehicleType" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "vehicleType" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort("make")}
>
  <div className="flex items-center gap-1">
    Make
    {sortKey === "make" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "make" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort("model")}
>
  <div className="flex items-center gap-1">
    Model
    {sortKey === "model" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "model" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort("regNo")}
>
  <div className="flex items-center gap-1">
    Reg No.
    {sortKey === "regNo" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "regNo" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort("yearOfPurchase")}
>
  <div className="flex items-center gap-1">
    Yr of Purchase
    {sortKey === "yearOfPurchase" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "yearOfPurchase" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort("vehicleAge")}
>
  <div className="flex items-center gap-1">
    Vehicle Age
    {sortKey === "vehicleAge" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "vehicleAge" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort("operatingArea")}
>
  <div className="flex items-center gap-1">
    Operating Area
    {sortKey === "operatingArea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "operatingArea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium cursor-pointer select-none"
  onClick={() => handleSort("utilisationRate")}
>
  <div className="flex items-center gap-1">
    Utilisation rate
    {sortKey === "utilisationRate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "utilisationRate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

<th
  className={`${!isAdmin ? 'py-1.5 text-xs border border-grey2 border-t-0 border-l-0' : 'py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0'} px-3 font-medium cursor-pointer select-none`}
  onClick={() => handleSort("assignedTo")}
>
  <div className="flex items-center gap-1">
    Assigned to
    {sortKey === "assignedTo" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
    {sortKey === "assignedTo" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
  </div>
</th>

                    {!isAdmin && (
                      <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 text-center font-medium ">Actions</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {isLoadingData && displayedItems.length === 0 && (
                    <tr>
                      <td colSpan={isAdmin ? 9 : 10} className="px-6 py-8 text-center text-gray-500">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                          Loading...
                        </div>
                      </td>
                    </tr>
                  )}
                  
                  {!isLoadingData && displayedItems.length === 0 ? (
                    <tr>
                      <td colSpan={isAdmin ? 9 : 10} className="text-center py-8 text-gray-500 italic">
                        {searchQuery || selectedVehicleTypes.length > 0 || selectedMakes.length > 0 || selectedUtilizationRates.length > 0
                          ? "No matching vehicles found"
                          : "No vehicles added yet"}
                        {!isAdmin && !searchQuery && selectedVehicleTypes.length === 0 && selectedMakes.length === 0 && selectedUtilizationRates.length === 0 && (
                          <p className="text-sm mt-2">Click "Add New Vehicle" to get started</p>
                        )}
                      </td>
                    </tr>
                  ) : (
                    displayedItems.map((vehicle, index) => (
                      <tr 
                        key={vehicle.id}
                        ref={index === displayedItems.length - 1 ? lastItemRef : null}
                        className={`${index % 2 === 0 ? "" : ""} hover:bg-lightBlue/50 text-xs text-left`}
                      >
                       <td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[20rem] cursor-pointer"
      onMouseEnter={() => {
        if ((vehicle.vehicleType ?? "").length > 20)
          setHoveredCell(`${vehicle.id}-vehicleType`);
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {vehicle.vehicleType || "-"}
    </p>

    {hoveredCell === `${vehicle.id}-vehicleType` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {vehicle.vehicleType}
      </span>
    )}
  </div>
</td>

                      <td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[20rem] cursor-pointer"
      onMouseEnter={() => {
        if ((vehicle.make ?? "").length > 20)
          setHoveredCell(`${vehicle.id}-make`);
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {vehicle.make || "-"}
    </p>

    {hoveredCell === `${vehicle.id}-make` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {vehicle.make}
      </span>
    )}
  </div>
</td>

                       <td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[20rem] cursor-pointer"
      onMouseEnter={() => {
        if ((vehicle.model ?? "").length > 20)
          setHoveredCell(`${vehicle.id}-model`);
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {vehicle.model || "-"}
    </p>

    {hoveredCell === `${vehicle.id}-model` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {vehicle.model}
      </span>
    )}
  </div>
</td>
<td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[15rem] cursor-pointer"
      onMouseEnter={() => {
        if ((vehicle.regNo ?? "").length > 15)
          setHoveredCell(`${vehicle.id}-regNo`);
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {vehicle.regNo || "-"}
    </p>

    {hoveredCell === `${vehicle.id}-regNo` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {vehicle.regNo}
      </span>
    )}
  </div>
</td>
<td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[10rem] cursor-pointer"
      onMouseEnter={() => {
        if ((vehicle.yearOfPurchase ?? "").length > 5)
          setHoveredCell(`${vehicle.id}-yearOfPurchase`);
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {vehicle.yearOfPurchase || "-"}
    </p>

    {hoveredCell === `${vehicle.id}-yearOfPurchase` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {vehicle.yearOfPurchase}
      </span>
    )}
  </div>
</td>
<td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[10rem] cursor-pointer"
      onMouseEnter={() => {
        if ((vehicle.vehicleAge ?? "").length > 5)
          setHoveredCell(`${vehicle.id}-vehicleAge`);
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {vehicle.vehicleAge || "-"}
    </p>

    {hoveredCell === `${vehicle.id}-vehicleAge` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {vehicle.vehicleAge}
      </span>
    )}
  </div>
</td>

                       <td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[20rem] cursor-pointer"
      onMouseEnter={() => {
        if ((vehicle.operatingArea ?? "").length > 20)
          setHoveredCell(`${vehicle.id}-operatingArea`);
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {vehicle.operatingArea || "-"}
    </p>

    {hoveredCell === `${vehicle.id}-operatingArea` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {vehicle.operatingArea}
      </span>
    )}
  </div>
</td>

                       <td className="py-1 border border-grey2 border-t-0 border-l-0 px-3 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[15rem] cursor-pointer"
      onMouseEnter={() => {
        if ((vehicle.utilizationRate ?? "").length > 15)
          setHoveredCell(`${vehicle.id}-utilizationRate`);
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {vehicle.utilizationRate || "-"}
    </p>

    {hoveredCell === `${vehicle.id}-utilizationRate` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {vehicle.utilizationRate}
      </span>
    )}
  </div>
</td>

                       <td className={`${!isAdmin ? 'py-1 border border-grey2 border-t-0 border-l-0' : 'py-1 border border-grey2 border-t-0 border-l-0 border-r-0'} px-3 text-xs`}>
  <div className="relative">
    <p
      className="truncate max-w-[20rem] cursor-pointer"
      onMouseEnter={() => {
        if ((vehicle.assignedTo ?? "").length > 20)
          setHoveredCell(`${vehicle.id}-assignedTo`);
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {vehicle.assignedTo || "-"}
    </p>

    {hoveredCell === `${vehicle.id}-assignedTo` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {vehicle.assignedTo}
      </span>
    )}
  </div>
</td>

                        {!isAdmin && (
                          <td className="py-1 border border-grey2 border-t-0 border-l-0 px-3  text-center">
                            <div className="flex items-center justify-center gap-4">
                              <div className="relative group">
                                <button onClick={() => handleEdit(vehicle.id)}>
                                  <img
                                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
                                  alt="Edit"
                                  className="w-5 h-5"
                                />
                                </button>
                                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                                  Edit
                                </span>
                              </div>

                              <div className="relative group">
                                <button
                                  onClick={() => {
                                    const originalIndex = vehiclesData.findIndex(item => item.id === vehicle.id);
                                    setSelectedRow(originalIndex);
                                    setIsDeleteModalOpen(true);
                                  }}
                                >
                                  <img
                                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                                  alt="Delete"
                                  className="w-5 h-5"
                                />
                                </button>
                                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                                  Delete
                                </span>
                              </div>
                            </div>
                          </td>
                        )}
                      </tr>
                    ))
                  )}
                  
                  {isLoading && (
                    <tr>
                      <td colSpan={isAdmin ? 9 : 10} className="px-6 py-4 text-center text-gray-500">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                          Loading more...
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
              {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

          </div>

          {/* Mobile/Tablet Cards */}
          <div className="lg:hidden space-y-4">
            {displayedItems.length > 0 ? (
              displayedItems.map((vehicle, index) => (
                <div 
                  key={vehicle.id} 
                  ref={index === displayedItems.length - 1 ? lastItemRef : null}
                  className="bg-white shadow-md border-2 border-Dustyblue p-4"
                >
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-sm font-semibold text-darkblue1">
                      {vehicle.vehicleType || "Vehicle"}
                    </span>
                    {!isAdmin && (
                      <div className="flex gap-2">
                        <button onClick={() => handleEdit(vehicle.id)}>
                          <Pencil size={18} className="text-blue-600" />
                        </button>
                        <button
                          onClick={() => {
                            const originalIndex = vehiclesData.findIndex(item => item.id === vehicle.id);
                            setSelectedRow(originalIndex);
                            setIsDeleteModalOpen(true);
                          }}
                        >
                          <Trash2 size={18} className="text-red-600" />
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Vehicle Type:</span>
                      <span className="text-gray-800">{vehicle.vehicleType || "-"}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Make:</span>
                      <span className="text-gray-800">{vehicle.make || "-"}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Model:</span>
                      <span className="text-gray-800">{vehicle.model || "-"}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Reg No:</span>
                      <span className="text-gray-800">{vehicle.regNo || "-"}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Year:</span>
                      <span className="text-gray-800">{vehicle.yearOfPurchase || "-"}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Age:</span>
                      <span className="text-gray-800">{vehicle.vehicleAge || "-"}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Operating Area:</span>
                      <span className="text-gray-800">{vehicle.operatingArea || "-"}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-gray-600">Utilization:</span>
                      <span className="text-gray-800">{vehicle.utilizationRate || "-"}</span>
                    </div>
                    <div className="flex flex-col col-span-2">
                      <span className="font-medium text-gray-600">Assigned to:</span>
                      <span className="text-gray-800">{vehicle.assignedTo || "-"}</span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-gray-500 bg-gray-50">
                <p className="text-lg font-medium mb-2">
                  {searchQuery || selectedVehicleTypes.length > 0 || selectedMakes.length > 0 || selectedUtilizationRates.length > 0
                    ? "No matching vehicles found"
                    : "No vehicles added yet"}
                </p>
                {!isAdmin && !searchQuery && selectedVehicleTypes.length === 0 && selectedMakes.length === 0 && selectedUtilizationRates.length === 0 && (
                  <p className="text-sm">Click "Add New Vehicle" to get started</p>
                )}
              </div>
            )}
            
            {isLoading && (
              <div className="px-6 py-4 text-center text-gray-500">
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                  Loading more...
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {isDeleteModalOpen && selectedRow !== null && (
        <DeleteModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            if (!deleteLoading) {
              setIsDeleteModalOpen(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={() => handleDelete(selectedRow)}
          loading={deleteLoading}
          extraMessage="This will delete all the records related to this vehicle."
        />
      )}
    </div>
  );
};

export default InfrastructureVehiclesPage;