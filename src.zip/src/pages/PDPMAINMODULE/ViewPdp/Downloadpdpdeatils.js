"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";

function Downloadpdpddeatils() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]);

  // ✅ Receive data from parent via postMessage
  useEffect(() => {
    const handler = (event) => {
      if (event.data?.type === "INIT_PDP_DATA") {
        setTableData(event.data.payload || []);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // ✅ Helper to format date
  const formatDate = (dateStr) => {
    if (!dateStr) return "—";
    const date = new Date(dateStr);
    return isNaN(date.getTime()) ? dateStr : date.toLocaleDateString("en-GB");
  };

  // ✅ Flatten nested dealer data for consistent table + Excel
  const flattenedData = tableData.flatMap((item) =>
    item.dealers && Array.isArray(item.dealers)
      ? item.dealers.map((dealerItem) => ({
          year: item.year || "—",
          marketArea: item.marketArea || "—",
          dealer: dealerItem.dealer || "—",
          pdpstartdate: dealerItem.pdpstartdate || "—",
          pdpenddate: dealerItem.pdpenddate || "—",
          physicalpdpstartdate: dealerItem.physicalpdpstartdate || "—",
          physicalpdpenddate: dealerItem.physicalpdpenddate || "—",
          actionItemStatus: dealerItem.actionItemStatus || "—",
          signOffStatus: dealerItem.signOffStatus || "—",
          pdpSignOff: dealerItem.pdpSignOff || [],
        }))
      : [
          {
            year: item.year || "—",
            marketArea: item.marketArea || "—",
            dealer: item.dealer || "—",
            pdpstartdate: item.pdpstartdate || "—",
            pdpenddate: item.pdpenddate || "—",
            physicalpdpstartdate: item.physicalpdpstartdate || "—",
            physicalpdpenddate: item.physicalpdpenddate || "—",
            actionItemStatus: item.actionItemStatus || "—",
            signOffStatus: item.signOffStatus || "—",
            pdpSignOff: item.pdpSignOff || [],
          },
        ]
  );

  // ✅ Download Excel
  const handleDownloadExcel = () => {
    if (!flattenedData || flattenedData.length === 0) return;

    const excelData = flattenedData.map((row, index) => ({
      "Sl. No": String(index + 1),
      "Year": row.year,
      "Market Area": row.marketArea,
      "Dealer": row.dealer,
      "PDP Start Date": formatDate(row.pdpstartdate),
      "PDP End Date": formatDate(row.pdpenddate),
      "Physical PDP Start Date": formatDate(row.physicalpdpstartdate),
      "Physical PDP End Date": formatDate(row.physicalpdpenddate),
      "Action Item Status": row.actionItemStatus,
      "Sign Off Status": row.signOffStatus,
      "Approved By": row.pdpSignOff?.[0]?.approvedBy || "—",
      "Email": row.pdpSignOff?.[0]?.email || "—",
      "Sign Off Date": formatDate(row.pdpSignOff?.[0]?.signOffDate),
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "View PDP");
    XLSX.writeFile(workbook, "View_PDP.xlsx");
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "ml-60" : ""
        } p-4`}
      >
        <div className="mt-10 mb-4 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">
            View PDP
          </h2>
          <button
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-xs hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadExcel}
          >
            Download
          </button>
        </div>

        {/* ✅ Table Section */}
          <div className="bg-white shadow-md  border border-Dustyblue w-full overflow-hidden">

  <table className="w-full text-sm ">
    <thead className="bg-Dustyblue text-white text-left text-xs">
  <tr>                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 border-l-0 w-[4%]">Sl.No</th>

                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 border-l-0 w-[4%]">Year</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 w-[10%]">Market Area</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 w-[5%]">Dealer</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 w-[9%]">PDP Start Date</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 w-[9%]">PDP End Date</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 w-[9%]">Physical PDP Start Date</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 w-[9%]">Physical PDP End Date</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 w-[8%]">Action Item Status</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-00 w-[7%]">Sign Off Status</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-b-0 w-[25%]">Sign Off Details</th>
                    </tr>
    </thead>

            <tbody>
              {flattenedData.length === 0 ? (
                <tr>
                  <td
                    colSpan={11}
                    className="text-center py-8 text-gray-500 italic"
                  >
                    No data found
                  </td>
                </tr>
              ) : (
                flattenedData.map((row, index) => (
                  <tr
                    key={index}
                    className="hover:bg-lightBlue/50 text-xs"
                  >
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{index + 1}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{row.year}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{row.marketArea}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{row.dealer}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{formatDate(row.pdpstartdate)}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{formatDate(row.pdpenddate)}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{formatDate(row.physicalpdpstartdate)}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{formatDate(row.physicalpdpenddate)}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{row.actionItemStatus}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{row.signOffStatus}</td>
                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border-r-0 ">
                      {row.pdpSignOff?.length > 0 ? (
                        row.pdpSignOff.map((s, i) => (
                          <div
                            key={i}
                            className="border-t border-gray-200 mt-1 pt-1 text-xs"
                          >
                            <p>Approved By: {s.approvedBy}</p>
                            <p>Email: {s.email}</p>
                            <p>Date: {formatDate(s.signOffDate)}</p>
                          </div>
                        ))
                      ) : (
                        <div className="text-xs">
                          <p>Approved By: —</p>
                          <p>Email: —</p>
                          <p>Date: —</p>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Downloadpdpddeatils;
