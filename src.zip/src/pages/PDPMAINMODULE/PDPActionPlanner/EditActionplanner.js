
import React, { useState, useRef, useEffect } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import StyledSelectField from "../../../Components/StyledSelectField";
import StyledDateField from "../../../Components/StyledDatefield";
import { formatDateOnly } from "../../../util/timeFormat";
import DateChangeRequest from "../../../Components/DateChangeRequest";

export default function EditActionplanner() {
  const location = useLocation();
  const navigate = useNavigate();
  const rowData = location.state?.rowData;
const [isDateChangeOpen, setIsDateChangeOpen] = useState(false);

  // 🧩 Form data (prefilled)
  const [formData, setFormData] = useState({
    focusArea: rowData?.focusArea || "",
    priority: rowData?.priority || "",
    objective: rowData?.objective || "",
    startDate: rowData?.startDate || "",
    endDate: rowData?.endDate || "",
    createdDate: rowData?.createdDate || "",
    pdfSignOffDate: rowData?.pdpSignOffDate || "",
    status: rowData?.status || "",
    actionsToAchieve: rowData?.actionsToAchieve || "",
targetDate: rowData?.targetDate || "",
    actionsProgressUpdate: rowData?.actionsProgressUpdate || "",
    responsibility: rowData?.responsibility || "",
    marketAreaUser: rowData?.marketAreaUser || "",
    hoUser: rowData?.hoUser || "",
    comments: rowData?.comments || "",
  });

  // 🧩 Dropdown open states
  const [dropdowns, setDropdowns] = useState({
    focusArea: false,
    priority: false,
    objective: false,
    status: false,
    responsibility: false,
    dealerUser: false,
    marketAreaUser: false,
    hoUser: false,
  });

  const refs = {
    focusArea: useRef(),
    priority: useRef(),
    objective: useRef(),
    status: useRef(),
    responsibility: useRef(),
    dealerUser: useRef(),
    marketAreaUser: useRef(),
    hoUser: useRef(),
  };

  const [errors, setErrors] = useState({});

  // 🧠 Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      const anyOpen = Object.keys(refs).some((key) => {
        const ref = refs[key];
        return ref.current && ref.current.contains(event.target);
      });
      if (!anyOpen) {
        setDropdowns({
          focusArea: false,
          priority: false,
          objective: false,
          status: false,
          dealerUser: false,
          marketAreaUser: false,
          hoUser: false,
        });
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const handleUpdate = () => {
    const requiredFields =
      rowData?.id === 127
        ? ["targetDate"]
        : [
            "focusArea",
            "priority",
            "objective",
            "responsibility",
            "actionsToAchieve",
            "targetDate",
            "status",
          ];

    const newErrors = {};
    requiredFields.forEach((field) => {
      if (!formData[field]) newErrors[field] = `${formatLabel(field)} is required`;
    });

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      const updatedRow = {
        ...rowData,
        ...formData,
      };
      navigate("/pdp/view/actionplannermanagemnet", { state: { updatedRow } });
    }
  };

  const formatLabel = (field) =>
    field
      .replace(/([A-Z])/g, " $1")
      .replace(/^./, (str) => str.toUpperCase())
      .replace("Pdf", "PDP");

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={false} setMenuOpen={() => {}} />
      <SubNavbar3 />

      <div className="flex justify-center">
        <div className="w-full mt-[20%] md:mt-[8%] lg:mt-[8%] overflow-y-auto p-4 lg:p-12">
          {/* Header */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              size={28}
              onClick={() => navigate(-1)}
              className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 rounded-md p-1"
            />
            <h2 className="text-lg font-semibold font-VolvoNovum text-darkblue1">
              Edit PDP Action Item ({rowData?.year || ""})
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[10%] mt-0 ml-[2.5%] mb-4"></div>

          {/* Info Header */}
          <div className="bg-white shadow-md rounded-lg border border-Dustyblue p-4 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-700">
              <div>
                <span className="font-semibold text-darkblue1">Year:</span>{" "}
                {rowData.year || "-"}
              </div>
              <div>
                <span className="font-semibold text-darkblue1">Created By:</span>{" "}
                {rowData.createdBy || "-"}
              </div>
              <div>
                <span className="font-semibold text-darkblue1">Created Date:</span>{" "}
                {rowData.createdDate || "-"}
              </div>
            </div>
          </div>

          {/* Conditional Section */}
          <div className="bg-white shadow-md rounded-lg border border-Dustyblue p-6 mb-6">
            {rowData?.id === 127 ? (
              <>
                {/* 🟩 Target Date */}
                

                {/* 🟦 Actions Progress Update */}
                <div className="mb-2">
                  <label className="block text-sm font-medium text-black/70 mb-2">
                    Actions Progress Update
                  </label>
                  <input
                    value={formData.actionsProgressUpdate}
                    onChange={(e) =>
                      handleChange("actionsProgressUpdate", e.target.value)
                    }
                    placeholder="Enter progress update..."
                    className="w-full px-4 py-2 text-sm rounded-lg border border-black/30 focus:outline-none"
                  />
                </div>
              </>
            ) : (
              <>
                {/* 🟣 Default Form (All Fields) */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-2">
                  <div>
                    <label className="block text-sm font-medium text-black/70 mb-2">
                      Focus Area <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.focusArea || ""}
                      readOnly
                      className="w-full px-4 py-2 text-sm rounded-lg border border-black/30 bg-gray-100 text-black/70 cursor-not-allowed"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-black/70 mb-2">
                      Priority <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.priority || ""}
                      readOnly
                      className="w-full px-4 py-2 text-sm rounded-lg border border-black/30 bg-gray-100 text-black/70 cursor-not-allowed"
                    />
                  </div>

                  <StyledSelectField
                    label="Responsibility"
                    placeholder="Select Responsibility"
                    value={formData.responsibility}
                    setValue={(val) => handleChange("responsibility", val)}
                    options={[
                      "Dealer Principal",
                      "Branch Manager",
                      "Service Head",
                      "Sales Head",
                      "Technician",
                    ]}
                    dropdownOpen={dropdowns.responsibility}
                    setDropdownOpen={(val) =>
                      setDropdowns({ ...dropdowns, responsibility: val })
                    }
                    dropdownRef={refs.responsibility}
                    error={errors.responsibility}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-2">
                  <StyledSelectField
                    label="Status"
                    placeholder="Select Status"
                    value={formData.status}
                    setValue={(val) => handleChange("status", val)}
                    options={["In Progress", "Closed"]}
                    dropdownOpen={dropdowns.status}
                    setDropdownOpen={(val) =>
                      setDropdowns({ ...dropdowns, status: val })
                    }
                    dropdownRef={refs.status}
                    error={errors.status}
                  />
<div className="">
                  {/* <StyledDateField
                    label="Target Date"
                    value={formData.targetDate}
                    setValue={(date) => handleChange("targetDate", date)}
                    required
                    error={errors.targetDate}
                  /> */}
                  <StyledDateField
                    label="Target Date"
                    value={formData.targetDate}
                    setValue={(date) => handleChange("targetDate", date)}
                    required
                    error={errors.targetDate}
                  />
</div>
                  {/* Target Date Change */}
                  <div className="mt-1">
                    <label className="block text-sm font-medium text-MediumGrey mb-1">
                      Target Date Change
                    </label>
                    <div
                      className={`w-full border rounded-md px-3 py-2 text-sm ${
                        rowData?.targetDate &&
                        formData.targetDate &&
                        formData.targetDate !== rowData.targetDate
                          ? "border-black/30 text-black"
                          : "border-black/30 text-black italic"
                      }`}
                    >
                      {rowData?.targetDate &&
                      formData.targetDate &&
                      formData.targetDate !== rowData.targetDate ? (
                        <>
                          <span className="font-semibold">
                            Target Date Change Previous Target Date:{" "}
                          </span>
                          <span className="font-medium text-darkblue1">
                            {(rowData.targetDate)}
                          </span>
                        </>
                      ) : (
                        "No change requested"
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-2">
                  <div className="md:col-span-1">
                    <label className="block text-sm font-medium text-black/70 mb-2">
                      Objective <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.objective}
                      onChange={(e) =>
                        handleChange("objective", e.target.value)
                      }
                      placeholder="Enter objective..."
                      className={`w-full px-4 py-2 text-sm rounded-lg focus:outline-none border ${
                        errors.objective
                          ? "border-red-600 focus:ring-red-600"
                          : "border-black/30 focus:ring-black/30"
                      }`}
                    />
                    {errors.objective && (
                      <p className="text-red-600 text-xs mt-1">
                        {errors.objective}
                      </p>
                    )}
                  </div>

                  <div className="md:col-span-1">
                    <label className="block text-sm font-medium text-black/70 mb-2">
                      Actions to Achieve
                    </label>
                    <input
                      value={formData.actionsToAchieve}
                      onChange={(e) =>
                        handleChange("actionsToAchieve", e.target.value)
                      }
                      placeholder="Enter actions to achieve..."
                      className={`w-full px-4 py-2 text-sm rounded-lg resize-none focus:outline-none border ${
                        errors.actionsToAchieve
                          ? "border-red1 focus:ring-red1"
                          : "border-black/30 focus:ring-black/30"
                      }`}
                    />
                    {errors.actionsToAchieve && (
                      <p className="text-red1 text-xs mt-1">
                        {errors.actionsToAchieve}
                      </p>
                    )}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Save Button */}
         <div className="flex justify-end mt-6 gap-3">
  {rowData?.id === 127 && (
    <button
      onClick={() => setIsDateChangeOpen(true)} // ✅ open popup
      className="bg-lightgreen text-sm font-medium text-white px-6 py-1.5 rounded-md hover:bg-white hover:text-lightgreen hover:border hover:border-lightgreen transition"
    >
      Target Date Change Request
    </button>
  )}

  <button
    onClick={handleUpdate}
    className="bg-darkblue1 text-sm font-medium text-white px-6 py-1.5 rounded-md hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
  >
    Save
  </button>
</div>

{/* ✅ Popup for confirmation */}
<DateChangeRequest
  isOpen={isDateChangeOpen}
  onCancel={() => setIsDateChangeOpen(false)}
  onConfirm={() => {
    
    setIsDateChangeOpen(false);
  }}
  message="Do you want to request a Target Date Change for this item?"
/>

        </div>
      </div>
    </div>
  );
}
