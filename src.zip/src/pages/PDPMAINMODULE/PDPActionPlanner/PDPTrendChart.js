import React, { useState, useRef, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import Header from "../../../Components/Header";
import { useNavigate, useLocation } from "react-router-dom";
import Filter from "../../../Components/Filter";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, Menu, Loader2 } from "lucide-react";
import { getAllPdpActionItem } from "../../../services/PDP/PdpActionItem/pdpActionItem.service";
import { getMarketAreas, getActiveDealers, getAllPdp } from "../../../services/PDP/CrudPdp/crudPdp.service";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../services/download/bluckDownload.service";
import { LabelList } from "recharts";
import html2canvas from "html2canvas";

function PDPTrendChart() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [showChartMenu, setShowChartMenu] = useState(false);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState(null);
  const [chartData, setChartData] = useState([]);
  const [summary, setSummary] = useState(null);
  const [allActionItems, setAllActionItems] = useState([]);
  const [allPdps, setAllPdps] = useState([]);
    const [isFullScreen, setIsFullScreen] = useState(false);
    const [activeKey, setActiveKey] = useState(null);

const [expandedFilters, setExpandedFilters] = useState({
  years: false,
  marketAreas: false,
  dealers: false
});
  // Dynamic options from API
  const [yearOptions, setYearOptions] = useState([]);
  const [marketAreaOptions, setMarketAreaOptions] = useState([]);
  const [dealerOptions, setDealerOptions] = useState([]);
  const [allDealers, setAllDealers] = useState([]);
  const [allMarketAreas, setAllMarketAreas] = useState([]);

  const navigate = useNavigate();
  const location = useLocation();
  const chartRef = useRef(null);
  const chartContainerRef = useRef(null);
  const menuRef = useRef(null);

  const togglePopup = () => setShowPopup(!showPopup);

  // Filters now store arrays for multiple selection
  const [filters, setFilters] = useState({
    year: [],
    marketArea: [],
    dealer: [],
  });

  // Helper function to get array of values from filter (always returns array)
  const getFilterArray = (filterValue) => {
    if (Array.isArray(filterValue)) {
      return filterValue;
    }
    return filterValue ? [filterValue] : [];
  };

  // Helper function to format selected values for display
const formatSelectedValues = (values, type, maxDisplay = 2) => {
  const arr = getFilterArray(values);

  if (arr.length === 0) return "";

  if (expandedFilters[type] || arr.length <= maxDisplay) {
    return (
      <>
        {arr.join(", ")}
        {arr.length > maxDisplay && (
          <span
            className="ml-1 text-SteelBlue1 cursor-pointer underline"
            onClick={() =>
              setExpandedFilters(prev => ({
                ...prev,
                [type]: false
              }))
            }
          >
            {" "}show less
          </span>
        )}
      </>
    );
  }

  return (
    <>
      {arr.slice(0, maxDisplay).join(", ")}
      <span
        className="ml-1 text-SteelBlue1 cursor-pointer underline"
        onClick={() =>
          setExpandedFilters(prev => ({
            ...prev,
            [type]: true
          }))
        }
      >
        +{arr.length - maxDisplay} more
      </span>
    </>
  );
};  // Fetch all data on component mount
  useEffect(() => {
    const fetchAllData = async () => {
      setInitialLoading(true);
      setError(null);

      try {
        const [marketAreasRes, dealersRes, actionItemsRes, pdpsRes] = await Promise.all([
          getMarketAreas(),
          getActiveDealers(),
          getAllPdpActionItem(),
          getAllPdp()
        ]);

        // Process Market Areas
        console.log("Market Areas data:", marketAreasRes);
        if (Array.isArray(marketAreasRes)) {
          const options = marketAreasRes.map(ma => ma.marketarea).filter(Boolean).sort();
          setMarketAreaOptions(options);
          setAllMarketAreas(marketAreasRes);
        }

        // Process Dealers
        console.log("Dealers data:", dealersRes);
        if (Array.isArray(dealersRes)) {
          setAllDealers(dealersRes);
        }

        // Process PDPs
        console.log("PDPs data:", pdpsRes);
        if (Array.isArray(pdpsRes)) {
          setAllPdps(pdpsRes);
          
          // Extract unique years from PDPs
          const yearsSet = new Set();
          pdpsRes.forEach(pdp => {
            if (pdp.year) {
              yearsSet.add(String(pdp.year));
            }
          });
          const uniqueYears = Array.from(yearsSet).sort((a, b) => Number(b) - Number(a));
          setYearOptions(uniqueYears);
        }

        // Process Action Items
        console.log("Action Items data:", actionItemsRes);
        if (Array.isArray(actionItemsRes)) {
          setAllActionItems(actionItemsRes);
        }

      } catch (err) {
        console.error("Error fetching data:", err);
        setError("Failed to load data. Please refresh the page.");
      } finally {
        setInitialLoading(false);
      }
    };

    fetchAllData();
  }, []);

  // Filter dealers when market area changes - SUPPORTS MULTIPLE SELECTION
  useEffect(() => {
    const selectedMarketAreas = getFilterArray(filters.marketArea);

    if (selectedMarketAreas.length === 0) {
      setDealerOptions([]);
      if (filters.dealer.length > 0) {
        setFilters(prev => ({ ...prev, dealer: [] }));
      }
      return;
    }

    console.log("Selected market areas:", selectedMarketAreas);

    // Filter dealers that belong to ANY of the selected market areas
    const filteredDealers = allDealers.filter(dealer => {
      return selectedMarketAreas.includes(dealer.marketName);
    });

    console.log("Filtered dealers count:", filteredDealers.length);

    // Get dealer names and sort
    const options = filteredDealers
      .map(d => d.dealerName || d.dealerShortName)
      .filter(Boolean)
      .sort();

    setDealerOptions(options);

    // Reset dealers that are not in filtered list
    const currentDealers = getFilterArray(filters.dealer);
    const validDealers = currentDealers.filter(d => options.includes(d));
    if (validDealers.length !== currentDealers.length) {
      setFilters(prev => ({ ...prev, dealer: validDealers }));
    }
  }, [filters.marketArea, allDealers]);

  // Process chart data when filters change - SUPPORTS MULTIPLE SELECTION
 useEffect(() => {
  const selectedYears = getFilterArray(filters.year);
  const selectedMarketAreas = getFilterArray(filters.marketArea);
  const selectedDealers = getFilterArray(filters.dealer);

  setLoading(true);
  setError(null);

  try {

    const matchingPdpIds = allPdps
      .filter((pdp) => {

        const yearMatch =
          selectedYears.length === 0 ||
          selectedYears.includes(String(pdp.year));

        const marketAreaMatch =
          selectedMarketAreas.length === 0 ||
          selectedMarketAreas.includes(pdp.market_area_name);

        const dealerMatch =
          selectedDealers.length === 0 ||
          selectedDealers.includes(pdp.dealer_name);

        return yearMatch && marketAreaMatch && dealerMatch;
      })
      .map((pdp) => pdp.id);

    const filteredItems = allActionItems.filter((item) =>
      matchingPdpIds.includes(item.pdp)
    );

    const months = [
      { month: 1, name: "January" },
      { month: 2, name: "February" },
      { month: 3, name: "March" },
      { month: 4, name: "April" },
      { month: 5, name: "May" },
      { month: 6, name: "June" },
      { month: 7, name: "July" },
      { month: 8, name: "August" },
      { month: 9, name: "September" },
      { month: 10, name: "October" },
      { month: 11, name: "November" },
      { month: 12, name: "December" }
    ];

    const result = months.map((m) => ({
      month: m.name,
      month_number: m.month,
      Open: 0,
      Ongoing: 0,
      Closed: 0,
    }));

    filteredItems.forEach((item) => {
      if (!item.created_on) return;

      const createdDate = new Date(item.created_on);
      const monthIndex = createdDate.getMonth();

      const status = (item.status || "").toLowerCase();

      if (status === "open") result[monthIndex].Open += 1;
      else if (status === "in progress" )
        result[monthIndex].Ongoing += 1;
      else if (status === "closed") result[monthIndex].Closed += 1;
    });

    const totals = result.reduce(
      (acc, m) => ({
        totalOpen: acc.totalOpen + m.Open,
        totalOngoing: acc.totalOngoing + m.Ongoing,
        totalClosed: acc.totalClosed + m.Closed,
      }),
      { totalOpen: 0, totalOngoing: 0, totalClosed: 0 }
    );

    setChartData(result);

    setSummary({
      years: selectedYears.length === 0 ? ["All Years"] : selectedYears,
      marketAreas:
        selectedMarketAreas.length === 0
          ? ["All Market Areas"]
          : selectedMarketAreas,
      dealers:
        selectedDealers.length === 0 ? ["All Dealers"] : selectedDealers,
      ...totals,
      totalItems:
        totals.totalOpen + totals.totalOngoing + totals.totalClosed,
    });

  } catch (err) {
    console.error("Error processing chart data:", err);
    setError("Failed to process chart data");
  } finally {
    setLoading(false);
  }
}, [filters.year, filters.marketArea, filters.dealer, allActionItems, allPdps]);
  // Handle filter change with proper reset logic
  const handleFilterChange = (name, value) => {
    setFilters((prev) => {
      // Ensure value is always an array
      const arrayValue = Array.isArray(value) ? value : (value ? [value] : []);
      const newFilters = { ...prev, [name]: arrayValue };

      // Reset dependent filters
      if (name === "marketArea") {
        newFilters.dealer = [];
      }

      return newFilters;
    });
  };

  const handleBack = () => {
    navigate("/pdp/PDPActionPlanner");
  };

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowChartMenu(false);
      }
    };

    if (showChartMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showChartMenu]);

  // Check if all filters have at least one selection
  const selectedYears = getFilterArray(filters.year);
  const selectedMarketAreas = getFilterArray(filters.marketArea);
  const selectedDealers = getFilterArray(filters.dealer);
  const isFilterComplete = selectedYears.length > 0 && selectedMarketAreas.length > 0 && selectedDealers.length > 0;

  // Get filtered action items for export - SUPPORTS MULTIPLE SELECTION
  const getFilteredActionItems = () => {
    if (!isFilterComplete) return [];

    const yearNumbers = selectedYears.map(y => parseInt(y));

    // Find PDPs matching the selected filters
    const matchingPdpIds = allPdps
      .filter(pdp => {
        const yearMatch = yearNumbers.includes(pdp.year);
        const marketAreaMatch = selectedMarketAreas.includes(pdp.market_area_name);
        const dealerMatch = selectedDealers.includes(pdp.dealer_name);
        return yearMatch && marketAreaMatch && dealerMatch;
      })
      .map(pdp => pdp.id);

    // Create a map of PDP ID to PDP details for export
    const pdpMap = {};
    allPdps.forEach(pdp => {
      pdpMap[pdp.id] = pdp;
    });

    return allActionItems
      .filter(item => matchingPdpIds.includes(item.pdp))
      .map(item => ({
        ...item,
        pdpDetails: pdpMap[item.pdp] || {}
      }));
  };

  // Format date for display (dd/mm/yyyy)
  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "";
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  // Format name helper
  const formatName = (firstName, lastName) => {
    const first = firstName || '';
    const last = lastName || '';
    return `${first} ${last}`.trim() || '';
  };

  // Export and preview Action Items - SUPPORTS MULTIPLE SELECTION
  const handleExportActionItems = async () => {
  setExporting(true);

  try {

    // Decide export data
    const filteredItems = isFilterComplete
      ? getFilteredActionItems()
      : allActionItems.map((item) => ({
          ...item,
          pdpDetails: allPdps.find((p) => p.id === item.pdp) || {},
        }));

    if (!filteredItems || filteredItems.length === 0) {
      alert("No action items found.");
      setExporting(false);
      togglePopup();
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("PDP Action Items");

    // Headers
    sheet.columns = [
      { header: "S.No", key: "slNo", width: 6 },
      { header: "Year", key: "year", width: 8 },
      { header: "Month", key: "month", width: 12 },
      { header: "Created Date", key: "createdDate", width: 12 },
      { header: "Focus Area", key: "focusArea", width: 20 },
      { header: "Objective", key: "objective", width: 40 },
      { header: "Actions to Achieve", key: "actionsToAchieve", width: 40 },
      { header: "Progress Update", key: "progressUpdate", width: 40 },
      { header: "Responsibility", key: "responsibility", width: 20 },
      { header: "Priority", key: "priority", width: 12 },
      { header: "Target Date", key: "targetDate", width: 12 },
      { header: "Completed Date", key: "completedDate", width: 14 },
      { header: "Status", key: "status", width: 12 },
      { header: "Created By", key: "createdBy", width: 20 },
      { header: "Market Area", key: "marketArea", width: 15 },
      { header: "Dealer", key: "dealer", width: 25 },
    ];

    // Header Style
    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });

    // Data Rows
    filteredItems.forEach((item, index) => {
      const pdpDetails = item.pdpDetails || {};
      const createdDate = item.created_on ? new Date(item.created_on) : null;

      const row = sheet.addRow({
        slNo: index + 1,
        year:
          pdpDetails.year ||
          (createdDate ? createdDate.getFullYear() : ""),
        month: createdDate
          ? createdDate.toLocaleString("default", { month: "long" })
          : "",
        createdDate: formatDate(item.created_on),
        focusArea: item.focus_area || "",
        objective: item.objective || "",
        actionsToAchieve: item.actions_to_achieve || "",
        progressUpdate: item.actions_progress_update || "",
        responsibility: item.responsibility_name || "",
        priority: item.priority || "",
        targetDate: formatDate(item.target_date),
        completedDate: formatDate(item.completed_date),
        status: item.status || "",
        createdBy: item.created_by_name || "",
        marketArea: pdpDetails.market_area_name || "",
        dealer: pdpDetails.dealer_name || "",
      });

      row.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
    });

    // Generate File
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const fileName = isFilterComplete
      ? "Filtered_PDP_Action_Items.xlsx"
      : "All_PDP_Action_Items.xlsx";

    const file = new File([blob], fileName, {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    // Upload temp file
    const response = await uploadTempFile(file);

    const fileUrl = response
      ? `https://view.officeapps.live.com/op/view.aspx?src=${encodeURIComponent(
          response
        )}`
      : null;

    if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    } else {
      console.warn("Upload succeeded but no file URL returned");
      alert("Upload succeeded but no preview available.");
    }

  } catch (err) {
    console.error("Failed to export Action Items:", err);
    alert("Failed to export Action Items. Check console for details.");
  } finally {
    setExporting(false);
    togglePopup();
  }
};  // Chart export functions
const addFilterHeader = () => {
  if (!chartRef.current) return null;

  const header = document.createElement("div");

  header.id = "export-filter-header";

  header.style.cssText =
    "padding:12px 16px;border-bottom:1px solid #e5e7eb;background:#ffffff;font-family:Arial,sans-serif;";

  header.innerHTML = `
    <div style="font-size:11px;color:#555;line-height:1.6;">
      <span style="font-weight:600;color:#1B365D;">Years:</span> ${
        selectedYears.length ? selectedYears.join(", ") : "All"
      }
      &nbsp;&nbsp;|&nbsp;&nbsp;
      <span style="font-weight:600;color:#1B365D;">Market Areas:</span> ${
        selectedMarketAreas.length ? selectedMarketAreas.join(", ") : "All"
      }
      &nbsp;&nbsp;|&nbsp;&nbsp;
      <span style="font-weight:600;color:#1B365D;">Dealers:</span> ${
        selectedDealers.length ? selectedDealers.join(", ") : "All"
      }
    </div>
  `;

  chartRef.current.insertBefore(header, chartRef.current.firstChild);

  return header;
};
const removeFilterHeader = () => {
  const header = document.getElementById("export-filter-header");
  if (header) header.remove();
};
  const handleExportPNG = async () => {
  if (!chartRef.current) return;

  setShowChartMenu(false);

  // Hide recharts tooltip
  const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
  tooltips.forEach((t) => (t.style.display = "none"));

  setTimeout(async () => {
    const header = addFilterHeader();

    try {
      const canvas = await html2canvas(chartRef.current, {
        backgroundColor: "#ffffff",
        scale: 2,
        useCORS: true,
        scrollY: -window.scrollY
      });

      const link = document.createElement("a");

      const fileName =
        selectedYears.length > 0
          ? `pdp-trend-chart-${selectedYears.join("-")}.png`
          : `pdp-trend-chart-all.png`;

      link.download = fileName;
      link.href = canvas.toDataURL("image/png");

      link.click();

    } catch (error) {
      console.error("Error exporting PNG:", error);
    } finally {
      removeFilterHeader();
      tooltips.forEach((t) => (t.style.display = ""));
    }
  }, 200);
};


const handleExportJPEG = async () => {
  if (!chartRef.current) return;

  setShowChartMenu(false);

  const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
  tooltips.forEach((t) => (t.style.display = "none"));

  setTimeout(async () => {
    const header = addFilterHeader();

    try {
      const canvas = await html2canvas(chartRef.current, {
        backgroundColor: "#ffffff",
        scale: 2,
        useCORS: true,
        scrollY: -window.scrollY,
      });

      const link = document.createElement("a");

      const fileName =
        selectedYears.length > 0
          ? `pdp-trend-chart-${selectedYears.join("-")}.jpeg`
          : `pdp-trend-chart-all.jpeg`;

      link.download = fileName;
      link.href = canvas.toDataURL("image/jpeg", 0.95);

      link.click();

    } catch (error) {
      console.error("Error exporting JPEG:", error);
    } finally {
      removeFilterHeader();
      tooltips.forEach((t) => (t.style.display = ""));
    } 
  }, 200);
};
 const handleExportSVG = async () => {
  if (!chartRef.current) return;

  setShowChartMenu(false);

  const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
  tooltips.forEach((t) => (t.style.display = "none"));

  setTimeout(async () => {
    const header = addFilterHeader();

    try {
      const canvas = await html2canvas(chartRef.current, {
        backgroundColor: "#ffffff",
        scale: 2,
        useCORS: true,
        scrollY: -window.scrollY
      });

      const imgData = canvas.toDataURL("image/png");

      const width = canvas.width;
      const height = canvas.height;

      const svgData = `
        <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="100%" 
    height="100%" 
    viewBox="0 0 ${canvas.width} ${canvas.height}"
    preserveAspectRatio="xMidYMid meet"
  >
    <image 
      href="${imgData}" 
      width="${canvas.width}" 
      height="${canvas.height}" 
    />
  </svg>
      `;

      const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
      const url = URL.createObjectURL(blob);

      const link = document.createElement("a");

      const fileName =
        selectedYears.length > 0
          ? `pdp-trend-chart-${selectedYears.join("-")}.svg`
          : `pdp-trend-chart-all.svg`;

      link.download = fileName;
      link.href = url;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      URL.revokeObjectURL(url);

    } catch (error) {
      console.error("Error exporting SVG:", error);
    } finally {
      removeFilterHeader();
      tooltips.forEach((t) => (t.style.display = ""));
    }
  }, 200);
};

 const handlePrint = async () => {
  if (!chartRef.current) return;

  setShowChartMenu(false);

  // Hide recharts tooltip before capture
  const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
  tooltips.forEach((t) => (t.style.display = "none"));

  try {
    await new Promise((resolve) => setTimeout(resolve, 200));

    const canvas = await html2canvas(chartRef.current, {
      backgroundColor: "#ffffff",
      scale: 2,
      useCORS: true,
      scrollY: -window.scrollY,
    });

    const imgData = canvas.toDataURL("image/png");

    const printWindow = window.open("", "", "width=1100,height=800");

    printWindow.document.write(`
      <html>
        <head>
          <title>PDP Trend Chart</title>
          <style>
            body{
              margin:0;
              padding:20px;
              font-family:Arial, sans-serif;
              text-align:center;
            }

            h1{
              color:#1e3a5f;
              font-size:18px;
              margin-bottom:6px;
            }

            .filters{
              font-size:12px;
              color:#555;
              margin-bottom:16px;
            }

            img{
              max-width:100%;
              height:auto;
              border:1px solid #e5e7eb;
            }

            @media print{
              body{margin:0;padding:10px;}
              img{border:none;}
            }
          </style>
        </head>

        <body>

          <h1>PDP Action Items Trend</h1>

          <div class="filters">
            Years: ${selectedYears.length ? selectedYears.join(", ") : "All"} 
            &nbsp;|&nbsp;
            Market Areas: ${selectedMarketAreas.length ? selectedMarketAreas.join(", ") : "All"}
            &nbsp;|&nbsp;
            Dealers: ${selectedDealers.length ? selectedDealers.join(", ") : "All"}
          </div>

          <img src="${imgData}" alt="PDP Trend Chart" />

        </body>
      </html>
    `);

    printWindow.document.close();

    printWindow.onload = () => {
      setTimeout(() => {
        printWindow.focus();
        printWindow.print();
      }, 300);
    };

  } catch (error) {
    console.error("Error printing chart:", error);
  } finally {
    tooltips.forEach((t) => (t.style.display = ""));
  }
};
  const handleFullScreen = () => {
  if (!chartRef.current) return;

  const element = chartRef.current;

  if (!document.fullscreenElement) {
    const request =
      element.requestFullscreen ||
      element.webkitRequestFullscreen ||
      element.msRequestFullscreen;

    if (request) {
      request.call(element);
    }
  } else {
    const exit =
      document.exitFullscreen ||
      document.webkitExitFullscreen ||
      document.msExitFullscreen;

    if (exit) {
      exit.call(document);
    }
  }

  setShowChartMenu(false);
};
useEffect(() => {
  const handleFullScreenChange = () => {
    setIsFullScreen(
      !!(
        document.fullscreenElement ||
        document.webkitFullscreenElement ||
        document.msFullscreenElement
      )
    );
  };

  document.addEventListener("fullscreenchange", handleFullScreenChange);
  document.addEventListener("webkitfullscreenchange", handleFullScreenChange);
  document.addEventListener("msfullscreenchange", handleFullScreenChange);

  return () => {
    document.removeEventListener("fullscreenchange", handleFullScreenChange);
    document.removeEventListener("webkitfullscreenchange", handleFullScreenChange);
    document.removeEventListener("msfullscreenchange", handleFullScreenChange);
  };
}, []);
 const handleDownloadCSV = () => {
  try {
    const filterRows = [
      `Years:,"${selectedYears.join(", ") || "All"}"`,
      `Market Areas:,"${selectedMarketAreas.join(", ") || "All"}"`,
      `Dealers:,"${selectedDealers.join(", ") || "All"}"`
    ];

    filterRows.push("");

    const headers = ["Month", "Open", "In Progress", "Closed", "Total"];

    const rows = chartData.map((row) => [
      row.month,
      Number(row.Open),
      Number(row.Ongoing),
      Number(row.Closed),
      Number(row.Open) + Number(row.Ongoing) + Number(row.Closed)
    ]);

    const csvContent = [
      ...filterRows,
      headers.join(","),
      ...rows.map((r) => r.join(","))
    ].join("\n");

    const blob = new Blob(["\uFEFF" + csvContent], {
      type: "text/csv;charset=utf-8;"
    });

    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");

    const fileName =
      selectedYears.length > 0
        ? `pdp-trend-chart-${selectedYears.join("-")}.csv`
        : `pdp-trend-chart-all.csv`;

    link.download = fileName;
    link.href = url;
    link.click();

    URL.revokeObjectURL(url);
  } catch (error) {
    console.error("Error downloading CSV:", error);
  }

  setShowChartMenu(false);
};
const handleDownloadXLS = async () => {
  try {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("PDP Trend Chart");

    const filterInfoStyle = {
      font: { bold: true, color: { argb: "FF1B365D" } },
      alignment: { horizontal: "left", vertical: "middle" }
    };

    const yearRow = sheet.addRow([
      "Years:",
      selectedYears.join(", ") || "All"
    ]);
    yearRow.getCell(1).font = filterInfoStyle.font;

    const areaRow = sheet.addRow([
      "Market Areas:",
      selectedMarketAreas.join(", ") || "All"
    ]);
    areaRow.getCell(1).font = filterInfoStyle.font;

    const dealerRow = sheet.addRow([
      "Dealers:",
      selectedDealers.join(", ") || "All"
    ]);
    dealerRow.getCell(1).font = filterInfoStyle.font;

    sheet.addRow([]);

    const headerRow = sheet.addRow([
      "Month",
      "Open",
      "In Progress",
      "Closed",
      "Total"
    ]);

    headerRow.eachCell((cell) => {
      cell.font = { bold: true };
      cell.alignment = { horizontal: "left", vertical: "middle" };
    });

    sheet.getColumn(1).width = 15;
    sheet.getColumn(2).width = 10;
    sheet.getColumn(3).width = 14;
    sheet.getColumn(4).width = 10;
    sheet.getColumn(5).width = 10;

    chartData.forEach((row) => {
      const dataRow = sheet.addRow([
        row.month,
        Number(row.Open),
        Number(row.Ongoing),
        Number(row.Closed),
        Number(row.Open) + Number(row.Ongoing) + Number(row.Closed)
      ]);

      dataRow.eachCell((cell) => {
        cell.alignment = { horizontal: "left", vertical: "middle" };
      });
    });

    const buffer = await workbook.xlsx.writeBuffer();

    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    });

    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");

    const fileName =
      selectedYears.length > 0
        ? `pdp-trend-chart-${selectedYears.join("-")}.xlsx`
        : `pdp-trend-chart-all.xlsx`;

    link.href = url;
    link.download = fileName;
    link.click();

    URL.revokeObjectURL(url);
  } catch (error) {
    console.error("Error downloading Excel:", error);
  }

  setShowChartMenu(false);
};
 const handleViewDataTable = () => {
  const tableWindow = window.open("", "", "width=700,height=600");

  const years = selectedYears?.length ? selectedYears.join(", ") : "All";
  const markets = selectedMarketAreas?.length ? selectedMarketAreas.join(", ") : "All";
  const dealers = selectedDealers?.length ? selectedDealers.join(", ") : "All";

  tableWindow.document.write(`
    <html>
      <head>
        <title>PDP Trend Data Table</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
          .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
          h2 { color: #1e3a5f; margin-bottom: 5px; }
          .filters { font-size: 12px; color: #666; margin-bottom: 15px; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
          th { background-color: #1e3a5f; color: white; }
          tr:nth-child(even) { background-color: #f9f9f9; }
          .total-row { background-color: #e8f4fc !important; font-weight: bold; }
        </style>
      </head>

      <body>
        <div class="container">

          <h2>PDP Action Items Trend</h2>

          <div class="filters">
            <p><strong>Years:</strong> ${years}</p>
            <p><strong>Market Areas:</strong> ${markets}</p>
            <p><strong>Dealers:</strong> ${dealers}</p>
          </div>

          <table>
            <thead>
              <tr>
                <th>Month</th>
                <th>Open</th>
                <th>In Progress</th>
                <th>Closed</th>
                <th>Total</th>
              </tr>
            </thead>

            <tbody>

              ${chartData
                .map(
                  (row) => `
                    <tr>
                      <td>${row.month}</td>
                      <td>${row.Open}</td>
                      <td>${row.Ongoing}</td>
                      <td>${row.Closed}</td>
                      <td><strong>${Number(row.Open) + Number(row.Ongoing) + Number(row.Closed)}</strong></td>
                    </tr>
                  `
                )
                .join("")}

              ${
                summary
                  ? `
                  <tr class="total-row">
                    <td><strong>TOTAL</strong></td>
                    <td><strong>${summary.totalOpen}</strong></td>
                    <td><strong>${summary.totalOngoing}</strong></td>
                    <td><strong>${summary.totalClosed}</strong></td>
                    <td><strong>${summary.totalItems}</strong></td>
                  </tr>
                `
                  : ""
              }

            </tbody>
          </table>

        </div>
      </body>
    </html>
  `);

  tableWindow.document.close();
  setShowChartMenu(false);
};

  // Chart Colors
  const CHART_COLORS = {
    open: "#0E2941",
    "in progress": "#4FA194",
    closed: "#C17A76",
  };
  // Custom Tooltip
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const total = payload.reduce((sum, entry) => sum + entry.value, 0);
      return (
        <div className="bg-white p-3 border border-gray-200 rounded shadow-md">
          <p className="font-medium text-gray-800 mb-2 pb-1 border-b text-sm">{label}</p>
          {payload.map((entry, index) => (
            <div key={index} className="flex justify-between items-center gap-4 text-xs py-0.5">
              <span className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: entry.fill }}></span>
                {entry.name}:
              </span>
              <span className="font-medium">{entry.value}</span>
            </div>
          ))}
          <div className="flex justify-between items-center gap-4 text-xs font-semibold text-gray-700 mt-2 pt-1 border-t">
            <span>Total:</span>
            <span>{total}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[5rem] p-2 lg:px-4">
          <div className="w-full max-w-7xl mx-auto">

            {/* Page Header */}
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-4 pt-3">
              <div>
                <div className="flex items-center gap-2 text-sm font-semibold font-VolvoNovum text-darkblue1">
                  <ArrowLeft
                    onClick={handleBack}
                    size={22}
                    className="cursor-pointer hover:scale-105 transition text-white bg-darkblue1 p-1"
                  />
                  Trend Chart - PDP Action Items
                </div>
                <hr className="hidden lg:block w-[50%] border-t-2 border-darkblue1 mt-1 ml-7" />
              </div>

              <button
  onClick={togglePopup}
  disabled={loading || initialLoading}
  className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded transition ${
    !loading && !initialLoading
      ? "bg-darkblue1 text-white hover:bg-opacity-90"
      : "bg-gray-200 text-gray-400 cursor-not-allowed"
  }`}
>
  <img
    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/export1.png"
    alt="export"
    className={`w-3 h-3 ${loading || initialLoading ? "opacity-50" : ""}`}
  />
  Export Action Items
</button>
            </div>

            {/* Filters - Multiple Selection Enabled */}
            <div className="flex flex-wrap gap-2 mb-5">
              <Filter
                name="year"
                value={filters.year}
                options={yearOptions}
                onChange={handleFilterChange}
                placeholder="Year"
                placeholderColor="text-black"
                textColor="text-black"
                buttonBorderColor="border-gray-300"
                dropdownBorderColor="border-gray-300"
                dropdownHoverColor="hover:bg-gray-50"
                customWidth="w-full sm:w-32"
                multiple={true}
              />
              <Filter
                name="marketArea"
                value={filters.marketArea}
                options={marketAreaOptions}
                onChange={handleFilterChange}
                placeholder="Market Area"
                placeholderColor="text-black"
                textColor="text-black"
                buttonBorderColor="border-gray-300"
                dropdownBorderColor="border-gray-300"
                dropdownHoverColor="hover:bg-gray-50"
                customWidth="w-full sm:w-40"
                multiple={true}
              />
              <Filter
                name="dealer"
                value={filters.dealer}
                options={dealerOptions}
                onChange={handleFilterChange}
                placeholder="Dealership"
                placeholderColor="text-black"
                textColor="text-black"
                buttonBorderColor="border-gray-300"
                dropdownBorderColor="border-gray-300"
                dropdownHoverColor="hover:bg-gray-50"
                customWidth="w-full sm:w-48"
                multiple={true}
              />
            </div>

        {/* Selected Filters Summary */}
{(selectedYears.length > 0 ||
  selectedMarketAreas.length > 0 ||
  selectedDealers.length > 0) && (
  <div className="flex flex-wrap gap-2 mb-4">

    {selectedYears.length > 0 && (
      <span className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded">
Years: {formatSelectedValues(selectedYears, "years", 2)}     
 </span>
    )}

    {selectedMarketAreas.length > 0 && (
      <span className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded">
        Areas: {formatSelectedValues(selectedMarketAreas, "marketAreas", 2)}
      </span>
    )}

    {selectedDealers.length > 0 && (
      <span className="text-xs bg-purple-50 text-purple-700 px-2 py-1 rounded">
        Dealers: {formatSelectedValues(selectedDealers, "dealers", 2)}
      </span>
    )}

  </div>
)}

            {/* Error State */}
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-3 py-2 rounded text-xs mb-4">
                {error}
              </div>
            )}

            {/* Content States */}
          {initialLoading ? (
  <div className="bg-white rounded shadow-sm border border-gray-200 p-10 flex flex-col items-center justify-center min-h-[400px]">
    <Loader2 className="w-8 h-8 text-darkblue1 animate-spin mb-3" />
    <p className="text-gray-500 text-sm">Loading data...</p>
  </div>

) : loading ? (

  <div className="bg-white rounded shadow-sm border border-gray-200 p-10 flex flex-col items-center justify-center min-h-[400px]">
    <Loader2 className="w-8 h-8 text-darkblue1 animate-spin mb-3" />
    <p className="text-gray-500 text-sm">Processing chart data...</p>
  </div>

) : summary && summary.totalItems === 0 ? (

  <div className="bg-white rounded shadow-sm border border-dashed border-gray-300 p-10 flex flex-col items-center justify-center min-h-[400px]">
    <h3 className="text-base font-medium text-gray-500 mb-1">No Action Items Found</h3>
    <p className="text-gray-400 text-center text-xs">
      No data found for the selected filters
    </p>
  </div>

) : (
           <div
  className={`bg-white rounded shadow-sm border border-gray-200 p-5 ${
    isFullScreen
      ? "!w-screen !h-screen !fixed !inset-0 !z-[9999] !rounded-none !border-none flex flex-col"
      : ""
  }`}
  ref={chartRef}
>

  {/* HEADER ROW */}
  <div className="flex items-center justify-between">

    {/* LEFT: HEADING */}
    <h2 className="text-sm font-semibold text-darkblue1 font-VolvoNovum whitespace-nowrap">
      PDP Action Items Monthly Trend
    </h2>

    {/* RIGHT SIDE */}
    <div className="flex items-center gap-4">

      {/* SUMMARY BADGES */}
      {summary && (
        <div className="flex items-center gap-4">

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-slate-100 border border-slate-200">
            <span className="text-xs text-slate-600">Open</span>
            <span className="text-xs font-semibold text-slate-800">
              {summary.totalOpen}
            </span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-emerald-50 border border-emerald-100">
            <span className="text-xs text-slate-600">In Progress</span>
            <span className="text-xs font-semibold text-slate-800">
              {summary.totalOngoing}
            </span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-rose-50 border border-rose-100">
            <span className="text-xs text-slate-600">Closed</span>
            <span className="text-xs font-semibold text-slate-800">
              {summary.totalClosed}
            </span>
          </div>

          <div className="px-3 py-1.5 rounded-md bg-gray-100 border border-gray-200 text-xs font-semibold text-gray-800">
            Total: {summary.totalItems}
          </div>

        </div>
      )}

      {/* MENU ICON */}
      <div className="relative" ref={menuRef}>
        <button
          onClick={() => setShowChartMenu(!showChartMenu)}
          className="p-1.5 hover:bg-gray-100 rounded transition"
        >
          <Menu size={16} className="text-gray-500" />
        </button>

        {showChartMenu && (
          <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-gray-200 rounded shadow-lg z-50 py-1">

            <button
              onClick={handleFullScreen}
              className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
            >
              View full screen
            </button>

            <button
              onClick={handlePrint}
              className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
            >
              Print chart
            </button>

            <div className="border-t border-gray-100 my-1"></div>

            <button
              onClick={handleExportPNG}
              className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
            >
              Download PNG
            </button>

            <button
              onClick={handleExportJPEG}
              className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
            >
              Download JPEG
            </button>

            <button
              onClick={handleExportSVG}
              className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
            >
              Download SVG
            </button>

            <div className="border-t border-gray-100 my-1"></div>

            <button
              onClick={handleDownloadCSV}
              className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
            >
              Download CSV
            </button>

            <button
              onClick={handleDownloadXLS}
              className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
            >
              Download XLS
            </button>

            <button
              onClick={handleViewDataTable}
              className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
            >
              View data table
            </button>

          </div>
        )}
      </div>

    </div>
  </div>
               <div ref={chartContainerRef} className={isFullScreen ? "flex-1 min-h-0" : ""}>
  <ResponsiveContainer width="100%" height={isFullScreen ? "100%" : 400}>
    <BarChart
      data={chartData}
      margin={{ top: 10, right: 30, left: 10, bottom: 5 }}
    >
      <CartesianGrid
        strokeDasharray="3 3"
        stroke="#e5e7eb"
        vertical={false}
      />

      <XAxis
        dataKey="month"
        tick={{ fontSize: 11, fill: "#4b5563" }}
        axisLine={{ stroke: "#d1d5db" }}
        tickLine={false}
        interval={0}
        angle={0}
        textAnchor="middle"
        height={40}
      />

      <YAxis
        tick={{ fontSize: 11, fill: "#4b5563" }}
        axisLine={{ stroke: "#d1d5db" }}
        tickLine={false}
        allowDecimals={false}
        label={{
          value: "No. of Action Items",
          angle: -90,
          position: "insideLeft",
          style: {
            fontSize: 12,
            fill: "#4b5563",
            fontWeight: 500,
          },
        }}
        width={60}
      />

      <Tooltip
        content={<CustomTooltip />}
        cursor={{ fill: "rgba(0,0,0,0.03)" }}
      />

      <Legend
        verticalAlign="top"
        align="center"
        iconType="square"
        iconSize={10}
        wrapperStyle={{ paddingBottom: 10 }}
        onClick={(e) => {
          const key = e.dataKey;
          setActiveKey(activeKey === key ? null : key);
        }}
        formatter={(value) => (
          <span
            style={{
              fontSize: "12px",
              color: "#374151",
              marginLeft: "4px",
            }}
          >
            {value}
          </span>
        )}
      />

      {/* OPEN */}
      <Bar
        dataKey="Open"
        name="Open"
        fill={CHART_COLORS.open}
        radius={[2, 2, 0, 0]}
        maxBarSize={35}
        opacity={activeKey && activeKey !== "Open" ? 0.2 : 1}
      >
        <LabelList
          dataKey="Open"
          position="top"
          formatter={(value) => (value > 0 ? value : "")}
          style={{
            fontSize: 11,
            fill: "#374151",
            fontWeight: 500,
          }}
        />
      </Bar>

      {/* ONGOING */}
      <Bar
        dataKey="Ongoing"
        name="In Progress"
        fill={CHART_COLORS["in progress"]}
        radius={[2, 2, 0, 0]}
        maxBarSize={35}
        opacity={activeKey && activeKey !== "Ongoing" ? 0.2 : 1}
      >
        <LabelList
          dataKey="Ongoing"
          position="top"
          formatter={(value) => (value > 0 ? value : "")}
          style={{
            fontSize: 11,
            fill: "#374151",
            fontWeight: 500,
          }}
        />
      </Bar>

      {/* CLOSED */}
      <Bar
        dataKey="Closed"
        name="Closed"
        fill={CHART_COLORS.closed}
        radius={[2, 2, 0, 0]}
        maxBarSize={35}
        opacity={activeKey && activeKey !== "Closed" ? 0.2 : 1}
      >
        <LabelList
          dataKey="Closed"
          position="top"
          formatter={(value) => (value > 0 ? value : "")}
          style={{
            fontSize: 11,
            fill: "#374151",
            fontWeight: 500,
          }}
        />
      </Bar>

    </BarChart>
  </ResponsiveContainer>
</div>
 </div>
            )}
          </div>
        </div>
      </div>

      {/* Export Popup - Shows Multiple Selections */}
    {showPopup && (
  <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
    <div className="bg-white rounded-lg shadow-lg p-5 max-w-md w-full">

      <h3 className="text-sm font-semibold text-darkblue1 mb-3">
        Export PDP Action Items
      </h3>

      <div className="bg-gray-50 rounded p-3 mb-4 text-xs space-y-2">

        <div className="flex justify-between">
          <span className="text-gray-500">Years:</span>
          <span className="font-medium text-gray-700 text-right max-w-[200px]">
            {selectedYears.length > 0
              ? formatSelectedValues(selectedYears, 3)
              : "All"}
          </span>
        </div>

        <div className="flex justify-between">
          <span className="text-gray-500">Market Areas:</span>
          <span className="font-medium text-gray-700 text-right max-w-[200px]">
            {selectedMarketAreas.length > 0
              ? formatSelectedValues(selectedMarketAreas, 3)
              : "All"}
          </span>
        </div>

        <div className="flex justify-between">
          <span className="text-gray-500">Dealers:</span>
          <span className="font-medium text-gray-700 text-right max-w-[200px]">
            {selectedDealers.length > 0
              ? formatSelectedValues(selectedDealers, 3)
              : "All"}
          </span>
        </div>

        <div className="flex justify-between pt-2 mt-2 border-t border-gray-200">
          <span className="text-gray-500">Total Items:</span>
          <span className="font-semibold text-darkblue1">
            {summary?.totalItems ?? allActionItems.length}
          </span>
        </div>

      </div>

      <div className="flex justify-end gap-2">

        <button
          onClick={togglePopup}
          className="px-3 py-1.5 text-xs text-gray-600 hover:bg-gray-100 rounded border border-gray-300"
          disabled={exporting}
        >
          Cancel
        </button>

        <button
          onClick={handleExportActionItems}
          disabled={exporting}
          className="px-3 py-1.5 text-xs bg-darkblue1 text-white rounded hover:bg-opacity-90 flex items-center gap-1.5"
        >
          {exporting ? (
            <>
              <Loader2 className="w-3 h-3 animate-spin" />
              Exporting...
            </>
          ) : (
            <>
              <svg
                className="w-3 h-3"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                />
              </svg>
              Export to Excel
            </>
          )}
        </button>

      </div>
    </div>
  </div>
)}
    </div>
  );
}

export default PDPTrendChart;