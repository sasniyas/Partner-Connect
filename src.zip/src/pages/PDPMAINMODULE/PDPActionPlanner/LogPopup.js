import React from "react";

const LogPopup = ({ logsData, onClose }) => {
  if (!logsData) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
      <div className="bg-white rounded-lg shadow-lg px-6 py-6 w-[50%] relative">
        {/* Header with Close Button */}
        <div className="flex justify-between items-center mb-0">
          <h2 className="text-base text-black font-semibold">Action Item Logs</h2>
          <button onClick={onClose}>
            <img 
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" 
              alt="close" 
              className="w-5 h-5" 
            />
          </button>
        </div>
        <hr className="w-[15%] border-t-2 ml-[1px] border-darkorange mb-2" />

        {/* Logs Subheader */}
        <h3 className="text-center text-MediumGrey font-medium text-base mb-4">
          {logsData.year} - {logsData.marketArea} - {logsData.dealerName}
        </h3>

        {/* Logs Table */}
        <div className="border border-Dustyblue rounded-md mb-6 bg-white overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-Dustyblue text-white font-volovNovum font-medium">
              <tr>
               <th className="px-3 py-2 w-[25%]">Created Date</th>
          <th className="px-3 py-2 w-[40%]">Updated By</th>
          <th className="px-3 py-2 w-[25%]">Status</th>
          <th className="px-3 py-2 w-[25%]">Comment</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {logsData.logs && logsData.logs.length > 0 ? (
                logsData.logs.map((log, index) => (
                  <tr key={index}>
                    <td className="text-left py-4 px-8">
                      {new Date(log.createdDate).toLocaleDateString("en-GB", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </td>
                    <td className="text-left py-4 px-4">{log.updatedBy || "-"}</td>
                    <td
                      className={`text-left py-4 px-4 ${
                        log.status === "Open"
                          ? "text-mildBlue"
                          : log.status === "Closed"
                          ? "text-green6"
                          : log.status === "On Going"
                          ? "text-burntorange1"
                          : "text-gray-500"
                      }`}
                    >
                      {log.status}
                    </td>
                    <td className="text-left py-4 px-4">{log.comments || "No comments"}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="text-center py-8 text-gray-500 italic">
                    No logs available for this action item
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default LogPopup;