import React, { useState, useEffect, useRef, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import Searchinput from "../../../Components/Searchinput";
import Filter from "../../../Components/Filter";
import DeleteModal from "../../../Components/DeleteModal";
import { ArrowLeft, Download, TrendingUp, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { useLocation } from "react-router-dom";
import { getAllPdpWithActionItemCounts } from "../../../services/PDP/CrudPdp/crudPdp.service";
import { getMarketAreas } from "../../../services/PDP/CrudPdp/crudPdp.service";
import { getActiveDealers } from "../../../services/PDP/CrudPdp/crudPdp.service";
import { deletePdp } from "../../../services/PDP/CrudPdp/crudPdp.service";
import { getPdpSignoffsByPdpId, getSignoffStats } from "../../../services/PDP/Signoff/signoff.service";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../services/download/bluckDownload.service";
import { ChevronDown, ChevronsUpDown,ArrowUp,ArrowDown } from "lucide-react";
import { ChevronUp } from "lucide-react";

function AllActionPlannerManagement() {
  const navigate = useNavigate();
  const location = useLocation();
  const rowData = location.state?.rowData;

  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"

  // Table data state
  const [hoveredCell, setHoveredCell] = useState(null);

  const [tableData, setTableData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filter options state
  const [yearOptions, setYearOptions] = useState([]);
  const [marketAreaOptions, setMarketAreaOptions] = useState([]);
  const [dealerOptions, setDealerOptions] = useState([]);
  const [allDealers, setAllDealers] = useState([]);

  const handleBack = () => {
    navigate("/pdp/viewdetails");
  };

  // Filters
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedYear, setSelectedYear] = useState([]);
  const [selectedMarketArea, setSelectedMarketArea] = useState([]);
  const [selectedDealer, setSelectedDealer] = useState([]);
  const tableContainerRef = useRef(null);

  // Delete Modal State
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  // Calculate Sign Off Status from signoff data
  const calculateSignOffStatus = (signoffs) => {
    if (!signoffs || signoffs.length === 0) {
      return "Not Started";
    }
    const stats = getSignoffStats(signoffs);
    if (stats.percentage === 100) {
      return "Completed";
    } else if (stats.percentage > 0) {
      return "In Progress";
    } else {
      return "Not Started";
    }
  };

  // Get status color
  const getStatusColor = (status) => {
    switch (status) {
      case "Completed":
        return "text-green-600";
      case "In Progress":
        return "text-yellow-600";
      case "Not Started":
        return "text-gray-500";
      default:
        return "text-gray-600";
    }
  };

  // Get status icon
  const getStatusIcon = (status) => {
    switch (status) {
      case "Completed":
        return <CheckCircle size={14} className="inline mr-1" />;
      case "In Progress":
        return <Clock size={14} className="inline mr-1" />;
      case "Not Started":
        return <AlertCircle size={14} className="inline mr-1" />;
      default:
        return null;
    }
  };

  // ── FIX 4: refreshPdpData declared BEFORE the useEffect that calls it ──────
  const refreshPdpData = async () => {
    try {
      const data = await getAllPdpWithActionItemCounts();

      const mappedDataWithSignoffs = await Promise.all(
        data.map(async (item) => {
          let signOffStatus = "Not Started";
          let signoffStats = null;

          try {
            if (item.id) {
              const signoffs = await getPdpSignoffsByPdpId(item.id);
              signOffStatus = calculateSignOffStatus(signoffs);
              if (signoffs && signoffs.length > 0) {
                signoffStats = getSignoffStats(signoffs);
              }
            }
          } catch (err) {
            console.warn(`Failed to fetch signoffs for PDP ${item.id}:`, err.message);
          }

          return {
            id: item.id,
            year: String(item.year),
            marketArea: item.market_area_name || "-",
            dealerName: item.dealer_name || "-",
            pdpSignOffStatus: signOffStatus,
            signoffStats: signoffStats,
            openCount: item.action_item_counts?.open || 0,
            ongoingCount: item.action_item_counts?.ongoing || 0,
            closedCount: item.action_item_counts?.closed || 0,
          };
        })
      );

      setTableData(mappedDataWithSignoffs);
    } catch (err) {
      console.error("Error refreshing PDP data:", err);
    }
  };

  // Fetch PDP data with action item counts and signoff status
  useEffect(() => {
    const fetchPdpData = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const data = await getAllPdpWithActionItemCounts();

        const mappedDataWithSignoffs = await Promise.all(
          data.map(async (item) => {
            let signOffStatus = "Not Started";
            let signoffStats = null;

            try {
              if (item.id) {
                const signoffs = await getPdpSignoffsByPdpId(item.id);
                signOffStatus = calculateSignOffStatus(signoffs);
                if (signoffs && signoffs.length > 0) {
                  signoffStats = getSignoffStats(signoffs);
                }
              }
            } catch (err) {
              console.warn(`Failed to fetch signoffs for PDP ${item.id}:`, err.message);
            }

            return {
              id: item.id,
              year: String(item.year),
              marketArea: item.market_area_name || "-",
              dealerName: item.dealer_name || "-",
              pdpSignOffStatus: signOffStatus,
              signoffStats: signoffStats,
              openCount: item.action_item_counts?.open || 0,
              ongoingCount: item.action_item_counts?.ongoing || 0,
              closedCount: item.action_item_counts?.closed || 0,
            };
          })
        );

        setTableData(mappedDataWithSignoffs);

        // Extract unique values for filters
        const uniqueYears = [...new Set(mappedDataWithSignoffs.map((item) => item.year))].sort();
        const uniqueMarketAreas = [
          ...new Set(mappedDataWithSignoffs.map((item) => item.marketArea).filter(Boolean)),
        ].sort();
        setYearOptions(uniqueYears);
        setMarketAreaOptions(uniqueMarketAreas);
      } catch (err) {
        console.error("Error fetching PDP data:", err);
        setError(err.message || "Failed to fetch PDP data");
      } finally {
        setIsLoading(false);
      }
    };

    fetchPdpData();
  }, []);

  // Fetch Market Areas
  useEffect(() => {
    const fetchMarketAreas = async () => {
      try {
        const areas = await getMarketAreas();
        const areaNames = areas.map((area) => area.marketarea).sort();
        setMarketAreaOptions((prev) => {
          const combined = [...new Set([...prev, ...areaNames])].sort();
          return combined;
        });
      } catch (err) {
        console.error("Error fetching market areas:", err);
      }
    };
    fetchMarketAreas();
  }, []);

  // Fetch Dealers
  useEffect(() => {
    const fetchDealers = async () => {
      try {
        const dealers = await getActiveDealers();
        setAllDealers(dealers);
        const dealerNames = dealers
          .filter((d) => d.dealerName)
          .map((d) => d.dealerName)
          .sort();
        setDealerOptions(dealerNames);
      } catch (err) {
        console.error("Error fetching dealers:", err);
      }
    };
    fetchDealers();
  }, []);

  // Update dealer options when market area filter changes
  useEffect(() => {
    if (!allDealers.length) return;

    let options = [];
    if (!selectedMarketArea.length) {
      options = allDealers
        .filter((d) => d.dealerName)
        .map((d) => d.dealerName)
        .sort();
    } else {
      options = allDealers
        .filter((d) =>
          selectedMarketArea.some(
            (ma) =>
              ma.toLowerCase() ===
              String(d.marketName || d.market_area_name).toLowerCase()
          )
        )
        .filter((d) => d.dealerName)
        .map((d) => d.dealerName)
        .sort();
    }
    setDealerOptions(options);
  }, [selectedMarketArea, allDealers]);

  // Filtered data
  const filteredData = useMemo(() => {
    return tableData.filter((item) => {
      const matchesSearch = Object.values(item).some((val) =>
        val?.toString().toLowerCase().includes(searchQuery.toLowerCase())
      );
      const matchesYear = selectedYear.length ? selectedYear.includes(item.year) : true;
      const matchesMarketArea = selectedMarketArea.length
        ? selectedMarketArea.includes(item.marketArea)
        : true;
      const matchesDealer = selectedDealer.length
        ? selectedDealer.includes(item.dealerName)
        : true;

      return matchesSearch && matchesYear && matchesMarketArea && matchesDealer;
    });
  }, [tableData, searchQuery, selectedYear, selectedMarketArea, selectedDealer]);

  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc");
        return;
      } else if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
        return;
      }
    }
    setSortKey(key);
    setSortOrder("asc");
  };

  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredData;

    return [...filteredData].sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];

      if (typeof valA === "number" && typeof valB === "number") {
        return sortOrder === "asc" ? valA - valB : valB - valA;
      }

      const strA = (valA || "").toString().toLowerCase();
      const strB = (valB || "").toString().toLowerCase();

      return sortOrder === "asc" ? strA.localeCompare(strB) : strB.localeCompare(strA);
    });
  }, [filteredData, sortKey, sortOrder]);

  // ── FIX 4: useEffect that uses refreshPdpData is now AFTER its declaration ──
  useEffect(() => {
    if (location.state?.newRow || location.state?.updatedRow) {
      refreshPdpData();
      navigate(location.pathname, { replace: true });
    }
  }, [location.state, navigate]);

  // Top Trend Chart button
  const handleTrendChart = () => {
    navigate("/pdp/PDPActionPlanner/PDPTrendChart", {
      state: {
        rowData: {
          year: selectedYear.length === 1 ? selectedYear[0] : "All Years",
          marketArea: selectedMarketArea.length === 1 ? selectedMarketArea[0] : "All Areas",
          dealerName: selectedDealer.length === 1 ? selectedDealer[0] : "All Dealers",
        },
        filters: {
          years: selectedYear.length > 0 ? selectedYear : yearOptions,
          marketAreas: selectedMarketArea.length > 0 ? selectedMarketArea : marketAreaOptions,
          dealers: selectedDealer.length > 0 ? selectedDealer : dealerOptions,
        },
        showAll: true,
      },
    });
  };

  const handleExportActionItems = async () => {
    if (!filteredData || filteredData.length === 0) {
      alert("No data available to generate preview");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("PDP Action Planner List");

      sheet.columns = [
        { header: "Year", key: "year", width: 10 },
        { header: "Market Area", key: "marketArea", width: 25 },
        { header: "Dealer Name", key: "dealerName", width: 50 },
        { header: "Sign Off Status", key: "signOffStatus", width: 20 },
        { header: "Open Count", key: "openCount", width: 15 },
        { header: "Ongoing Count", key: "ongoingCount", width: 18 },
        { header: "Closed Count", key: "closedCount", width: 15 },
      ];

      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      filteredData.forEach((item) => {
        const row = sheet.addRow({
          year: item.year || "-",
          marketArea: item.marketArea || "-",
          dealerName: item.dealerName || "-",
          signOffStatus: item.pdpSignOffStatus || "-",
          openCount: item.openCount || 0,
          ongoingCount: item.ongoingCount || 0,
          closedCount: item.closedCount || 0,
        });

        row.eachCell((cell) => {
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const file = new File([blob], "PDP_Action_Planner_List.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const response = await uploadTempFile(file);
      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        alert("Upload succeeded but preview not available");
      }
    } catch (error) {
      console.error("Action Items export failed:", error);
      alert("Failed to generate Action Items preview");
    }
  };

  // ── FIX 3: actual API delete call before updating local state ──────────────
  const handleConfirmDelete = async () => {
    if (itemToDelete) {
      try {
        setIsDeleting(true);
        await deletePdp(itemToDelete.id);
        setTableData((prev) => prev.filter((row) => row.id !== itemToDelete.id));
        setItemToDelete(null);
        setDeleteModalVisible(false);
      } catch (err) {
        alert(err.message || "Failed to delete");
      } finally {
        setIsDeleting(false);
      }
    }
  };

  const handleViewDetails = (item) => {
    navigate("/pdp/view/actionplannermanagemnet", {
      state: { rowData: item },
    });
  };

  // Render Sign Off Status with progress
  const renderSignOffStatus = (item) => {
    if (item.signoffStats) {
      return (
        <div className="text-xs">
          <div className={`font-semibold flex items-center ${getStatusColor(item.pdpSignOffStatus)}`}>
            {getStatusIcon(item.pdpSignOffStatus)}
            {item.pdpSignOffStatus}
          </div>
          <div className="flex items-center gap-2 mt-1">
            <div className="w-16 bg-gray-200 rounded-full h-1.5">
              <div
                className="bg-green-500 h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${item.signoffStats.percentage}%` }}
              ></div>
            </div>
            <span className="text-gray-600 whitespace-nowrap">
              {item.signoffStats.signed}/{item.signoffStats.total}
            </span>
          </div>
        </div>
      );
    }

    return (
      <div className={`font-semibold flex items-center ${getStatusColor(item.pdpSignOffStatus)}`}>
        {getStatusIcon(item.pdpSignOffStatus)}
        {item.pdpSignOffStatus}
      </div>
    );
  };

  return (
    <div className="">
      <div className="flex justify-center">
        <div className="w-full overflow-x-hidden overflow-y-auto">
          {/* Header */}
          <div className="w-full flex justify-center mb-2">
            <h2 className="text-xl font-semibold text-darkblue1 font-VolvoNovum">
              PDP Action Planner List
            </h2>
          </div>

          {/* Filters - All in One Row */}
          <div className="w-full mb-2 flex flex-wrap items-center justify-between gap-2">
            {/* 🔍 Search + Filters (Left) */}
            <div className="flex flex-wrap items-center gap-2">
              {/* Search */}
              <Searchinput
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search"
                className="w-[180px]"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-4 py-2"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />

              {/* Year */}
              <Filter
                name="year"
                value={selectedYear}
                options={yearOptions}
                onChange={(name, values) => setSelectedYear(values)}
                placeholder="Year"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
                customWidth="w-[120px]"
              />

              {/* Market Area */}
              <Filter
                name="marketArea"
                value={selectedMarketArea}
                options={marketAreaOptions}
                onChange={(name, values) => setSelectedMarketArea(values)}
                placeholder="Market Area"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
                customWidth="w-[120px]"
              />

              {/* Dealer */}
              <Filter
                name="dealer"
                value={selectedDealer}
                options={dealerOptions}
                onChange={(name, values) => setSelectedDealer(values)}
                placeholder="Dealer"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
                customWidth="w-[220px]"
              />
            </div>

            {/* 📊 Buttons (Right) */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleTrendChart}
                className="flex items-center gap-2 text-xs bg-darkblue1 font-medium text-white px-4 py-1.5 hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition-colors shadow-md whitespace-nowrap"
              >
                <TrendingUp className="w-3 h-3" />
                Trend Chart
              </button>

              <button
                onClick={handleExportActionItems}
                className="flex items-center gap-2 text-xs bg-darkblue1 font-medium text-white px-4 py-1.5 hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition-colors shadow-md whitespace-nowrap"
              >
                <Download className="w-3 h-3" />
                Export
              </button>
            </div>
          </div>

          {/* Loading State */}
          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
              <span className="ml-3 text-gray-600">Loading PDP data...</span>
            </div>
          )}

          {/* Error State */}
          {error && !isLoading && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 mb-4">
              <p className="font-semibold">Error loading data</p>
              <p>{error}</p>
            </div>
          )}

          {/* Desktop Table View */}
          {!isLoading && !error && (
            <div className="hidden lg:block bg-white shadow-md border border-Dustyblue w-full overflow-hidden">
              <div
                ref={tableContainerRef}
                  onScroll={handleTableScroll}
                className="w-full overflow-y-auto overflow-x-hidden max-h-[calc(100vh-200px)]"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
              >
                <style jsx>{`
                  div::-webkit-scrollbar {
                    display: none;
                  }
                `}</style>
                <table className="w-full text-sm border-collapse table-fixed">
                  <thead className="bg-Dustyblue text-white  text-xs text-left sticky top-0 z-10">
                    <tr>
                      <th
                        className="px-3 py-1.5 border border-grey2 border-t-0 border-l-0 w-[8%] font-normal cursor-pointer select-none"
                        onClick={() => handleSort("year")}
                      >
                        <div className="flex items-center gap-1">
                          Year
                          {sortKey !== "year" && <ChevronsUpDown className="w-3 h-3 text-white" />}
                          {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>

                      <th
                        className="px-3 py-1.5 border border-grey2 border-t-0 border-l-0 w-[15%] font-normal cursor-pointer select-none"
                        onClick={() => handleSort("marketArea")}
                      >
                        <div className="flex items-center gap-1">
                          Market Area
                          {/* FIX 2: added missing ChevronsUpDown for unsorted state */}
                          {sortKey === "marketArea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "marketArea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>

                      <th
                        className="px-3 py-1.5 border border-grey2 border-t-0 border-l-0 w-[20%] font-normal cursor-pointer select-none"
                        onClick={() => handleSort("dealerName")}
                      >
                        <div className="flex items-center gap-1">
                          Dealer Name
                          {/* FIX 2: added missing ChevronsUpDown for unsorted state */}
                          {sortKey === "dealerName" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "dealerName" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>

                      {/* FIX 1: was onClick={() => handleSort("signOffStatus")}
                          "signOffStatus" key doesn't exist in data — data field is "pdpSignOffStatus" */}
                      <th
                        className="px-3 py-1.5 border border-grey2 border-t-0 border-l-0 w-[17%] font-normal cursor-pointer select-none"
                        onClick={() => handleSort("pdpSignOffStatus")}
                      >
                        <div className="flex items-center gap-1">
                          Sign Off Status
                          {/* FIX 2: added missing ChevronsUpDown for unsorted state */}
                          {sortKey === "pdpSignOffStatus" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "pdpSignOffStatus" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>

                      <th className="px-3 py-1.5 text-left border border-grey2 border-t-0 border-l-0 font-normal w-[30%]">
                        Action Items Counts
                      </th>
                      <th className="px-3 py-1.5 text-center border border-grey2 border-t-0 border-l-0 border-r-0 font-normal w-[10%]">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {sortedData.length > 0 ? (
                      sortedData.map((item, idx) => (
                        <tr
                          key={idx}
                          className="hover:bg-lightBlue/50 text-left text-xs transition duration-300 cursor-pointer"
                        >
                          <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0">{item.year}</td>
                          <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 overflow-hidden">
  <div className="relative max-w-[12rem]">
    
    <p
      className="truncate cursor-pointer"
      onMouseEnter={() => {
        if (item.marketArea && item.marketArea.length > 20) {
          setHoveredCell(`${item.id}-marketArea`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.marketArea}
    </p>

    {hoveredCell === `${item.id}-marketArea` && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50 shadow-lg">
        {item.marketArea}
      </span>
    )}

  </div>
</td>
<td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 overflow-hidden">
  <div className="relative max-w-[12rem]">
    
    <p
      className="truncate cursor-pointer"
      onMouseEnter={() => {
        if (item.dealerName && item.dealerName.length > 20) {
          setHoveredCell(`${item.id}-dealerName`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.dealerName}
    </p>

    {hoveredCell === `${item.id}-dealerName` && (
      <span className="absolute left-1/2 top-full -mt-2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50 shadow-lg">
        {item.dealerName}
      </span>
    )}

  </div>
</td>
                          <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0">
                            {renderSignOffStatus(item)}
                          </td>
                          <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0">
                            <div className="flex gap-3 flex-wrap">
                              <span>Open: <span className="font-semibold">{item.openCount || 0}</span></span>
                              <span>Ongoing: <span className="font-semibold">{item.ongoingCount || 0}</span></span>
                              <span>Closed: <span className="font-semibold">{item.closedCount || 0}</span></span>
                            </div>
                          </td>
                          <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                            <div className="flex items-center justify-center gap-3">
                              {/* Action Item - Orange */}
                              <div className="relative group">
                                <button
                                  onClick={() => handleViewDetails(item)}
                                  className="text-orange-600 hover:text-orange-700 hover:scale-110 transition-all"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                    <path d="M16.5 4.5H20.25V21.75H3.75V4.5H7.5V6H16.5V4.5ZM6.75 12H17.25V10.5H6.75V12ZM6.75 18H17.25V16.5H6.75V18ZM9 4.5V2.25H15V4.5H9Z" fill="#E06900" />
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full mt-1 -translate-x-1/2 bg-SteelBlue text-white text-[10px] px-2 py-0 whitespace-nowrap z-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                                  Action Item
                                </span>
                              </div>

                              {/* Delete - Red */}
                              <div className="relative group">
                                <button
                                  onClick={() => {
                                    setItemToDelete(item);
                                    setDeleteModalVisible(true);
                                  }}
                                  className="text-red-600 hover:text-red-700 hover:scale-110 transition-all"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                                    <g clipPath="url(#clip0_6398_313)">
                                      <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012" />
                                    </g>
                                    <defs>
                                      <clipPath id="clip0_6398_313">
                                        <rect width="24" height="24" fill="white" transform="translate(4 4)" />
                                      </clipPath>
                                    </defs>
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full mt-1 -translate-x-1/2 bg-SteelBlue text-white text-[10px] px-2 py-0 whitespace-nowrap z-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                                  Delete
                                </span>
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="6" className="text-center py-8 text-gray-500 italic">
                          No data found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
              {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

            </div>
          )}

          {/* Card View — Small & Medium Screens */}
          {!isLoading && !error && (
            <div
              className="block lg:hidden space-y-4 mt-4 overflow-y-auto max-h-[calc(100vh-200px)]"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
            >
              <style jsx>{`
                div::-webkit-scrollbar {
                  display: none;
                }
              `}</style>
              {filteredData.length > 0 ? (
                filteredData.map((item, idx) => (
                  <div key={idx} className="bg-white shadow-md p-4 border border-gray-300">
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="font-semibold text-gray-600">Year:</span>
                        <span className="text-gray-900">{item.year}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-semibold text-gray-600">Market Area:</span>
                        <span className="text-gray-900">{item.marketArea}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-semibold text-gray-600">Dealer Name:</span>
                        <span className="text-gray-900">{item.dealerName}</span>
                      </div>
                      <div className="flex justify-between items-start">
                        <span className="font-semibold text-gray-600">Sign Off Status:</span>
                        <div className="text-right">{renderSignOffStatus(item)}</div>
                      </div>
                      <div className="flex flex-col gap-1">
                        <span className="font-semibold text-gray-600">Action Items Counts:</span>
                        <div className="flex gap-4 text-sm text-gray-900 ml-2">
                          <span>Open: <span className="font-semibold">{item.openCount || 0}</span></span>
                          <span>Ongoing: <span className="font-semibold">{item.ongoingCount || 0}</span></span>
                          <span>Closed: <span className="font-semibold">{item.closedCount || 0}</span></span>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end gap-4 mt-4 pt-3 border-t border-gray-200">
                      <button
                        onClick={() => handleViewDetails(item)}
                        className="text-orange-600 hover:text-orange-700 transition-colors p-1"
                        title="Action Item"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M16.5 4.5H20.25V21.75H3.75V4.5H7.5V6H16.5V4.5ZM6.75 12H17.25V10.5H6.75V12ZM6.75 18H17.25V16.5H6.75V18ZM9 4.5V2.25H15V4.5H9Z" fill="#E06900" />
                        </svg>
                      </button>

                      <button
                        onClick={() => {
                          setItemToDelete(item);
                          setDeleteModalVisible(true);
                        }}
                        className="text-red-600 hover:text-red-700 transition-colors p-1"
                        title="Delete"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                          <g clipPath="url(#clip0_6398_313)">
                            <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012" />
                          </g>
                          <defs>
                            <clipPath id="clip0_6398_313">
                              <rect width="24" height="24" fill="white" transform="translate(4 4)" />
                            </clipPath>
                          </defs>
                        </svg>
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-gray-500 italic py-4">No data found</p>
              )}
            </div>
          )}
        </div>
      </div>

      <DeleteModal
        isOpen={deleteModalVisible}
        onClose={() => setDeleteModalVisible(false)}
        loading={isDeleting}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}

export default AllActionPlannerManagement;