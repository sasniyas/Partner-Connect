import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import Filter from "../../../Components/Filter";
import DeleteModal from "../../../Components/DeleteModal";
import LogPopup from "./LogPopup";
import { ArrowLeft, Download, ChevronDown, ChevronUp, MoreVertical, Menu, X } from "lucide-react";
import { formatDateOnly } from "../../../util/timeFormat";
import DateChangeRequest from "../../../Components/DateChangeRequest";

function PDPActionItems() {
  const navigate = useNavigate();
  const location = useLocation();
  const rowData = location.state?.rowData;

  const [menuOpen, setMenuOpen] = useState(false);

  console.log("Received rowData:", rowData);

  // Action Items Data
  const [actionItems, setActionItems] = useState([
    {
      id: 1,
      year: "2025",
      createdDate: "10/10/2025",
      createdBy: "Admin",
      focusArea: "Uptime & Parts",
      priority: "Medium",
      objective: "Improve uptime performance",
      actionsToAchieve: "Regular maintenance checks",
      actionsProgressUpdate: "50% completed",
      responsibility: "Service Manager",
      targetDate: "21/11/2023",
      completedDate: "22/11/2023",
      pdpSignOffDate: "",
      status: "Open",
    },
    {
      id: 2,
      year: "2025",
      createdDate: "15/10/2025",
      createdBy: "John Doe",
      focusArea: "Sales",
      priority: "High",
      objective: "Increase sales by 20%",
      actionsToAchieve: "Implement new marketing strategy",
      actionsProgressUpdate: "Planning phase",
      responsibility: "Regional Manager",
      targetDate: "21/11/2023",
      completedDate: "22/11/2023",
      pdpSignOffDate: "",
      status: "On Going",
    },
    {
      id: 3,
      year: "2025",
      createdDate: "20/10/2025",
      createdBy: "Jane Smith",
      focusArea: "Service",
      priority: "Low",
      objective: "Enhance customer service",
      actionsToAchieve: "Training sessions for staff",
      actionsProgressUpdate: "Completed",
      responsibility: "Technical Head",
      targetDate: "21/11/2023",
      completedDate: "22/11/2023",
      pdpSignOffDate: "25/11/2023",
      status: "Closed",
    },
    {
      id: 4,
      year: "2025",
      createdDate: "25/10/2025",
      createdBy: "Mike Johnson",
      focusArea: "Marketing",
      priority: "Medium",
      objective: "Launch new campaign",
      actionsToAchieve: "Create marketing materials",
      actionsProgressUpdate: "In progress",
      responsibility: "Area Manager",
      targetDate: "21/11/2023",
      completedDate: "22/11/2023",
      pdpSignOffDate: "",
      status: "On Going",
    },
    {
      id: 5,
      year: "2025",
      createdDate: "30/10/2025",
      createdBy: "Sarah Williams",
      focusArea: "Operations",
      priority: "High",
      objective: "Optimize operations",
      actionsToAchieve: "Process improvement",
      actionsProgressUpdate: "Completed",
      responsibility: "Territory Manager",
      targetDate: "21/11/2023",
      completedDate: "22/11/2023",
      pdpSignOffDate: "01/12/2023",
      status: "Closed",
    },
    {
      id: 6,
      year: "2025",
      createdDate: "05/11/2025",
      createdBy: "Tom Brown",
      focusArea: "Uptime & Parts",
      priority: "Medium",
      objective: "Reduce downtime",
      actionsToAchieve: "Implement preventive maintenance",
      actionsProgressUpdate: "75% completed",
      responsibility: "Warranty Manager",
      targetDate: "21/11/2023",
      completedDate: "22/11/2023",
      pdpSignOffDate: "",
      status: "On Going",
    },
    {
      id: 7,
      year: "2025",
      createdDate: "10/11/2025",
      createdBy: "Emily Davis",
      focusArea: "Sales",
      priority: "Low",
      objective: "Customer retention",
      actionsToAchieve: "Loyalty program implementation",
      actionsProgressUpdate: "Planning",
      responsibility: "Supply Chain Head",
      targetDate: "21/11/2023",
      completedDate: "22/11/2023",
      pdpSignOffDate: "",
      status: "On Going",
    },
   {
     id: 127,
    year: "2025",
    createdDate: "2025-01-05",
    createdBy: "sasmiya",
    focusArea: "Sales Growth",
    priority: "High",
    objective: "Increase revenue",
    actionsToAchieve: "Campaign launch, Training",
    actionsProgressUpdate: "Ongoing, 50% done",
    responsibility: "John Doe",
    targetDate: "2025-12-10",
    completedDate: "-",
    pdpSignOffDate: "2025-01-15",
    status: "In Progress",
  }, 
  ]);

  // Filter States
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedYear, setSelectedYear] = useState([]);
  const [selectedFocusArea, setSelectedFocusArea] = useState([]);
  const [selectedPriority, setSelectedPriority] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState([]);
  const [showFilters, setShowFilters] = useState(false);
  const [isDateChangeOpen,setIsDateChangeOpen] =useState()
  const [selectedRow, setSelectedRow] = useState(null);

  // Expand/Collapse and Dropdown States
  const [expandedRows, setExpandedRows] = useState(new Set());
  const [dropdownId, setDropdownId] = useState(null);
  const dropdownRefs = useRef({});

  // Delete Modal State
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [rowToDelete, setRowToDelete] = useState(null);

  // Log Popup State
  const [isLogsPopupOpen, setIsLogsPopupOpen] = useState(false);
  const [logsData, setLogsData] = useState(null);

  // Filter Options
  const yearOptions = ["2023", "2024", "2025", "2026"];
  const focusAreaOptions = ["Uptime & Parts", "Sales", "Service", "Marketing", "Operations"];
  const priorityOptions = ["High", "Medium", "Low"];
  const statusOptions = ["Open", "On Going", "Closed"];

  // Load items from localStorage on mount
 
const handleDateChangeClick = (item, event) => {
  if (event) event.stopPropagation();
  setSelectedRow(item);
  setIsDateChangeOpen(true);
  setDropdownId(null);
};

  // Listen for updates from EditActionItem page
  useEffect(() => {
    if (location.state?.updatedItem && location.state?.timestamp) {
      const updatedItem = location.state.updatedItem;
     setActionItems((prev) => {
  const index = prev.findIndex((item) => item.id === updatedItem.id);
  if (index !== -1) {
    const newItems = [...prev];
    newItems[index] = updatedItem;
    return newItems;
  }
  return prev; // do not add new records
});

      
      // Clear the state after processing
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  // Filtered Data
  const filteredData = useMemo(() => {
    return actionItems.filter((item) => {
      const matchesSearch = Object.values(item).some((val) =>
        val?.toString().toLowerCase().includes(searchQuery.toLowerCase())
      );
      const matchesYear = selectedYear.length ? selectedYear.includes(item.year) : true;
      const matchesFocusArea = selectedFocusArea.length
        ? selectedFocusArea.includes(item.focusArea)
        : true;
      const matchesPriority = selectedPriority.length
        ? selectedPriority.includes(item.priority)
        : true;
      const matchesStatus = selectedStatus.length ? selectedStatus.includes(item.status) : true;

      return matchesSearch && matchesYear && matchesFocusArea && matchesPriority && matchesStatus;
    });
  }, [actionItems, searchQuery, selectedYear, selectedFocusArea, selectedPriority, selectedStatus]);

  // Lazy Loading
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLazyLoading, setIsLazyLoading] = useState(false);
  const observerRef = useRef();
  const itemsPerLoad = 10;

  const loadMoreItems = useCallback(() => {
    if (isLazyLoading || !hasMore) return;
    setIsLazyLoading(true);
    setTimeout(() => {
      const currentLength = displayedItems.length;
      const nextItems = filteredData.slice(currentLength, currentLength + itemsPerLoad);
      if (nextItems.length === 0) setHasMore(false);
      else setDisplayedItems((prev) => [...prev, ...nextItems]);
      setIsLazyLoading(false);
    }, 300);
  }, [displayedItems, filteredData, isLazyLoading, hasMore]);

  const lastItemRef = useCallback(
    (node) => {
      if (isLazyLoading) return;
      if (observerRef.current) observerRef.current.disconnect();
      observerRef.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore) loadMoreItems();
      });
      if (node) observerRef.current.observe(node);
    },
    [isLazyLoading, hasMore, loadMoreItems]
  );

  useEffect(() => {
    setDisplayedItems(filteredData.slice(0, itemsPerLoad));
    setHasMore(filteredData.length > itemsPerLoad);
  }, [filteredData]);

  // Toggle expand/collapse for a row
  const toggleRowExpand = (id) => {
    setExpandedRows((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  // Toggle dropdown menu
  const toggleDropdown = (id, event) => {
    if (event) {
      event.stopPropagation();
    }
    setDropdownId((prev) => (prev === id ? null : id));
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      // Check if click is outside all dropdowns
      let clickedOutside = true;
      Object.values(dropdownRefs.current).forEach(ref => {
        if (ref && ref.contains(event.target)) {
          clickedOutside = false;
        }
      });

      // Check if clicked on modal/popup
      const isModalClick = event.target.closest('[role="dialog"]') || 
                          event.target.closest('.fixed.inset-0');

      if (clickedOutside && !isModalClick) {
        setDropdownId(null);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleBack = () => {
    navigate("/pdp/PDPActionPlanner");
  };

  const handleExportActionItems = () => {
    console.log("Export Action Items clicked");
  };

  const handleEdit = (item, event) => {
    if (event) {
      event.stopPropagation();
    }
    console.log("Edit item:", item);
    setDropdownId(null);
    navigate("/pdp/PDPActionPlanner/editactionplanner", { state: { rowData: item } });
  };

  const handleView = (item, event) => {
    if (event) {
      event.stopPropagation();
    }
    console.log("View item:", item);
    setDropdownId(null);
    // Navigate to view page or open view modal
  };

  const handleLogs = (item, event) => {
    if (event) {
      event.stopPropagation();
    }
    console.log("View logs for:", item);
    setDropdownId(null);
    
    // Generate multiple logs data for the item to show history
    const logs = [
      {
        createdDate: item.createdDate || new Date().toISOString(),
        updatedBy: item.createdBy || "Admin",
        status: "Open",
        comments: "Action item created",
      },
      {
        createdDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        updatedBy: "Manager",
        status: "On Going",
        comments: item.actionsProgressUpdate || "Work in progress",
      },
    ];

    // Add closed status if applicable
    if (item.status === "Closed") {
      logs.push({
        createdDate: item.completedDate ? new Date(item.completedDate).toISOString() : new Date().toISOString(),
        updatedBy: item.createdBy || "Admin",
        status: "Closed",
        comments: "Action item completed successfully",
      });
    }

    setLogsData({
      year: rowData?.year || "2025",
      marketArea: rowData?.marketArea || "Central",
      dealerName: rowData?.dealerName || "ENCORE",
      logs: logs,
    });
    setIsLogsPopupOpen(true);
  };

  const closeLogsPopup = () => {
    setIsLogsPopupOpen(false);
    setLogsData(null);
  };

  const handleDeleteClick = (item, event) => {
    if (event) {
      event.stopPropagation();
    }
    setRowToDelete(item);
    setIsDeleteModalOpen(true);
    setDropdownId(null);
  };

 const confirmDelete = () => {
  if (rowToDelete) {
    const updatedItems = actionItems.filter((row) => row.id !== rowToDelete.id);
    setActionItems(updatedItems);
    setRowToDelete(null);
    setIsDeleteModalOpen(false);
  }
};


  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
    setRowToDelete(null);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "Open":
        return "text-mildBlue";
      case "On Going":
      case "In Progress":
        return "text-burntorange1";
      case "Closed":
        return "text-green6";
      default:
        return "text-gray-600";
    }
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      {/* Navigation Bar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      {/* Main Content - Moves Right when Sidebar Opens */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="flex justify-center">
            <div className="w-full p-2 lg:w-full overflow-x-hidden overflow-y-auto lg:p-4">
              <div className="flex items-center gap-2 ">
             <ArrowLeft
                               onClick={handleBack}
                               size={28}
                               className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 rounded-md p-1"
                             />            
                                             <h2 className="text-lg font-semibold font-VolvoNovum text-darkblue1">
                  {rowData?.year || "2023"}-{rowData?.marketArea || "Central"}-
                  {rowData?.dealerName || "ENCORE"}, PDP Action Item List
                </h2>
              </div>
<div className="hidden lg:block h-1 bg-darkblue1 w-[10%] mt-0 ml-[2.5%] "></div>
              {/* Filters and Export Button */}
              <div className="w-full mb-0">
                {/* Desktop - Single Row Layout */}
                <div className="hidden lg:flex items-center justify-center gap-4 mb-0 rounded-xl py-4">
                  <div className="w-64">
                    <input
                      type="text"
                      placeholder="Search"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full px-4 py-2 border border-black/60 rounded-md bg-FrostWhite text-black focus:outline-none focus:ring-1 focus:ring-black/60 hover:bg-white hover:border-black/60"
                    />
                  </div>

                  <Filter
                    name="year"
                    value={selectedYear}
                    options={yearOptions}
                    onChange={(name, value) => setSelectedYear(value)}
                    className="w-36"
                    placeholder="Year"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-black"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />
                  <Filter
                    name="focusArea"
                    value={selectedFocusArea}
                    options={focusAreaOptions}
                    onChange={(name, value) => setSelectedFocusArea(value)}
                    className="w-40"
                    placeholder="Focus Area"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-black"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />
                  <Filter
                    name="priority"
                    value={selectedPriority}
                    options={priorityOptions}
                    onChange={(name, value) => setSelectedPriority(value)}
                    className="w-32"
                    placeholder="Priority"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-black"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />
                  <Filter
                    name="status"
                    value={selectedStatus}
                    options={statusOptions}
                    onChange={(name, value) => setSelectedStatus(value)}
                    className="w-32"
                    placeholder="Status"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-black"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />
                  
                  <button
                    onClick={handleExportActionItems}
                    className="flex items-center gap-2 bg-darkblue1 text-white px-4 py-2 rounded-md hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition-colors shadow-md whitespace-nowrap"
                  >
                    <Download size={16} />
                    <span className="font-medium">Export Action Items</span>
                  </button>
                </div>

                {/* Mobile/Tablet Layout */}
                <div className="lg:hidden bg-white rounded-xl p-4 mb-6">
                  <div className="flex flex-col sm:flex-row gap-3 mb-3">
                    <div className="flex-1">
                      <input
                        type="text"
                        placeholder="Search"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full px-4 py-2 border border-black/60 rounded-md bg-FrostWhite text-black focus:outline-none focus:ring-1 focus:ring-black/60 hover:bg-white hover:border-black/60"
                      />
                    </div>
                    <button
                      onClick={() => setShowFilters(!showFilters)}
                      className="flex items-center justify-center gap-2 px-4 py-2 border border-black rounded-md bg-white hover:bg-gray-50 sm:w-auto whitespace-nowrap"
                    >
                      {showFilters ? <X size={16} /> : <Menu size={16} />}
                      <span className="text-sm">Filters</span>
                    </button>
                  </div>

                  {showFilters && (
                    <div className="space-y-3 border-t pt-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <Filter
                          name="year"
                          value={selectedYear}
                          options={yearOptions}
                          onChange={(name, value) => setSelectedYear(value)}
                          className="w-full"
                          placeholder="Year"
                          placeholderColor="text-black"
                          buttonBorderColor="border-black"
                          dropdownBgColor="bg-white"
                          dropdownTextColor="text-black"
                          dropdownHoverColor="hover:bg-lightBlue/50"
                          dropdownBorderColor="border-black"
                          closedBgColor="bg-white"
                          hoverRingColor="ring-black"
                          openBgColor="bg-white"
                          textColor="text-black"
                        />
                        <Filter
                          name="focusArea"
                          value={selectedFocusArea}
                          options={focusAreaOptions}
                          onChange={(name, value) => setSelectedFocusArea(value)}
                          className="w-full"
                          placeholder="Focus Area"
                          placeholderColor="text-black"
                          buttonBorderColor="border-black"
                          dropdownBgColor="bg-white"
                          dropdownTextColor="text-black"
                          dropdownHoverColor="hover:bg-lightBlue/50"
                          dropdownBorderColor="border-black"
                          closedBgColor="bg-white"
                          hoverRingColor="ring-black"
                          openBgColor="bg-white"
                          textColor="text-black"
                        />
                        <Filter
                          name="priority"
                          value={selectedPriority}
                          options={priorityOptions}
                          onChange={(name, value) => setSelectedPriority(value)}
                          className="w-full"
                          placeholder="Priority"
                          placeholderColor="text-black"
                          buttonBorderColor="border-black"
                          dropdownBgColor="bg-white"
                          dropdownTextColor="text-black"
                          dropdownHoverColor="hover:bg-lightBlue/50"
                          dropdownBorderColor="border-black"
                          closedBgColor="bg-white"
                          hoverRingColor="ring-black"
                          openBgColor="bg-white"
                          textColor="text-black"
                        />
                        <Filter
                          name="status"
                          value={selectedStatus}
                          options={statusOptions}
                          onChange={(name, value) => setSelectedStatus(value)}
                          className="w-full"
                          placeholder="Status"
                          placeholderColor="text-black"
                          buttonBorderColor="border-black"
                          dropdownBgColor="bg-white"
                          dropdownTextColor="text-black"
                          dropdownHoverColor="hover:bg-lightBlue/50"
                          dropdownBorderColor="border-black"
                          closedBgColor="bg-white"
                          hoverRingColor="ring-black"
                          openBgColor="bg-white"
                          textColor="text-black"
                        />
                      </div>
                      
                      <button
                        onClick={handleExportActionItems}
                        className="w-full flex items-center justify-center gap-2 bg-darkblue1 text-white px-4 py-2 rounded-md hover:bg-darkblue1/90 transition-colors shadow-md"
                      >
                        <Download size={16} />
                        <span className="font-medium">Export Action Items</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Desktop Table View */}
              <div className="hidden lg:block bg-white shadow-md rounded-lg border border-gray-300 w-full overflow-hidden">
                <table className="w-full text-sm border-collapse table-fixed">
                  <thead className="bg-Dustyblue text-white text-xs sticky top-0 z-10">
                    <tr>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[3%] align-middle text-center leading-tight text-[10px]">
                        Expand
                      </th>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[4%] align-middle text-center leading-tight">
                        Year
                      </th>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[6%] align-middle text-center leading-tight">
                        Created Date
                      </th>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[6%] align-middle text-center leading-tight">
                        Created By
                      </th>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[7%] align-middle text-center leading-tight">
                        Focus Area
                      </th>
                     
                      <th className="px-1 py-2 border border-black/30 font-bold w-[10%] align-middle text-center leading-tight">
                        Objective
                      </th>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[10%] align-middle text-center leading-tight">
                        Actions to Achieve
                      </th>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[10%] align-middle text-center leading-tight">
                        Actions Progress Update
                      </th>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[7%] align-middle text-center leading-tight">
                        Responsibility
                      </th>
                       <th className="px-1 py-2 border border-black/30 font-bold w-[5%] align-middle text-center leading-tight">
                        Priority
                      </th>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[6%] align-middle text-center leading-tight">
                        Target Date
                      </th>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[6%] align-middle text-center leading-tight">
                        Completed Date
                      </th>
                      {/* <th className="px-1 py-2 border border-black/30 font-bold w-[7%] align-middle text-center leading-tight">
                        PDP Sign Off Date
                      </th> */}
                      <th className="px-1 py-2 border border-black/30 font-bold w-[5%] align-middle text-center leading-tight">
                        Status
                      </th>
                      <th className="px-1 py-2 border border-black/30 font-bold w-[4%] align-middle text-center leading-tight">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {displayedItems.length > 0 ? (
                      displayedItems.map((item, idx) => {
                        const rowId = `${item.id}-${idx}`;
                        const isExpanded = expandedRows.has(rowId);
                        
                        return (
                          <tr
                            key={rowId}
                            ref={idx === displayedItems.length - 1 ? lastItemRef : null}
                            className={`${
                              idx % 2 === 0 ? "bg-white" : "bg-gray-50"
                            } hover:bg-blue-50 transition-colors border-b border-gray-200`}
                          >
                            {/* Expand/Collapse Button */}
                            <td className="px-2 py-4 border border-black/30 text-center">
                              <button
                                onClick={() => toggleRowExpand(rowId)}
                                className="w-6 h-6 flex items-center justify-center rounded-md border border-gray-300 hover:bg-gray-100 transition-colors mx-auto"
                              >
                                {isExpanded ? (
                                  <ChevronUp size={16} className="text-gray-600" />
                                ) : (
                                  <ChevronDown size={16} className="text-gray-600" />
                                )}
                              </button>
                            </td>

                            <td className="px-2 py-4 border border-black/30 text-gray-900 text-xs">{item.year}</td>
                            <td className="px-2 py-4 border border-black/30 text-gray-900 text-xs">
                              <div className={`${isExpanded ? '' : 'truncate'}`}>
                                {item.createdDate}
                              </div>
                            </td>
                            <td className="px-2 py-4 border border-black/30 text-gray-900 text-xs">
                              <div className={`${isExpanded ? '' : 'truncate'}`}>
                                {item.createdBy}
                              </div>
                            </td>
                            <td className="px-2 py-4 border border-black/30 text-gray-900 text-xs">
                              <div className={`${isExpanded ? '' : 'truncate'}`}>
                                {item.focusArea}
                              </div>
                            </td>
                           
                            <td className={`px-2 border border-black/30 text-gray-900 text-xs ${isExpanded ? 'py-4' : 'py-2'}`}>
                              <div className={`${isExpanded ? 'whitespace-normal' : 'truncate'}`}>
                                {item.objective}
                              </div>
                            </td>
                            <td className={`px-2 border border-black/30 text-gray-900 text-xs ${isExpanded ? 'py-4' : 'py-2'}`}>
                              <div className={`${isExpanded ? 'whitespace-normal' : 'truncate'}`}>
                                {item.actionsToAchieve}
                              </div>
                            </td>
                            <td className={`px-2 border border-black/30 text-gray-900 text-xs ${isExpanded ? 'py-4' : 'py-2'}`}>
                              <div className={`${isExpanded ? 'whitespace-normal' : 'truncate'}`}>
                                {item.actionsProgressUpdate}
                              </div>
                            </td>
                            <td className="px-2 py-4 border border-black/30 text-gray-900 text-xs">
                              <div className={`${isExpanded ? '' : 'truncate'}`}>
                                {item.responsibility}
                              </div>
                            </td>
                             <td className="px-2 py-4 border border-black/30 text-gray-900 text-xs">
                              <div className={`${isExpanded ? '' : 'truncate'}`}>
                                {item.priority}
                              </div>
                            </td>
                            <td className="px-2 py-4 border border-black/30 text-gray-900 text-xs">{(item.targetDate)}</td>
                            <td className="px-2 py-4 border border-black/30 text-xs whitespace-nowrap">{(item.completedDate)}</td>
                            {/* <td className="px-2 py-4 border border-black/30 text-xs">{(item.pdpSignOffDate)}</td> */}
                            <td
                              className={`px-2 py-4 font-semibold border border-black/30 text-center text-xs ${getStatusColor(
                                item.status
                              )}`}
                            >
                              {item.status}
                            </td>
                            
                            {/* Three-Dot Actions Menu */}
                            <td className="border border-black/30 px-1 py-2">
                              <div 
                                className="flex justify-center items-center relative" 
                                ref={(el) => dropdownRefs.current[rowId] = el}
                              >
                                <button
                                  onClick={(e) => toggleDropdown(rowId, e)}
                                  className="w-8 h-8 flex items-center justify-center rounded-md border border-gray-300 hover:bg-gray-100 transition-colors"
                                >
                                  <MoreVertical size={16} className="text-gray-600" />
                                </button>
                                {dropdownId === rowId && (
                                  <div
  className={`absolute right-0 ${
    item.id === 127 ? "w-50" : "w-40"
  } bg-white border border-gray-200 rounded-md shadow-lg z-[999]
  ${
    displayedItems.length > 3 && idx >= displayedItems.length - 3
      ? "bottom-full mb-1"
      : "top-full mt-1"
  }`}
>
                                    <div className="py-1">
                                      <button
                                        onClick={(e) => handleEdit(item, e)}
                                        className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-green-50 hover:text-green-700 flex items-center gap-2"
                                      >
                                        <img
                                          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/edit.png"
                                          alt="Edit"
                                          className="w-3 h-3"
                                        />
                                        Edit
                                      </button>
                                      <button
                                        onClick={(e) => handleLogs(item, e)}
                                        className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                      >
                                        <img
                                          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/log.png"
                                          alt="Logs"
                                          className="w-3 h-3"
                                        />
                                        Logs
                                      </button>
                                       {item.id === 127 && (
            <button
              // onClick={() => {
              //   navigate("/pdp/view/actionplannermanagemnet/targetdatechange", { state: { rowData: item } });
              //   setOpenDropdown(null);
              // }}
              onClick={() => handleDateChangeClick(item)}
              className="w-full px-3 py-2 text-left text-sm text-blue-700 hover:bg-blue-50 flex items-center gap-2 whitespace-nowrap"
            >
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/priority.png"
                alt="Target Date Change"
                className="w-3.5 h-3.5"
              />
              Date Change Request
            </button>
          )}
                                      <button
                                        onClick={(e) => handleDeleteClick(item, e)}
                                        className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-red-50 hover:text-red-700 flex items-center gap-2"
                                      >
                                        <img
                                          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                                          alt="Delete"
                                          className="w-3 h-3"
                                        />
                                        Delete
                                      </button>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan="15" className="text-center py-8 text-gray-500 italic">
                          No data found
                        </td>
                      </tr>
                    )}
                    {isLazyLoading && (
                      <tr>
                        <td colSpan="15" className="px-6 py-4 text-center text-gray-500">
                          <div className="flex items-center justify-center gap-2">
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                            Loading more...
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card View */}
              <div className="block lg:hidden space-y-4 mt-4">
                {displayedItems.length > 0 ? (
                  displayedItems.map((item, idx) => {
                    const rowId = `${item.id}-${idx}`;
                    
                    return (
                      <div
                        key={rowId}
                        className="bg-white shadow-md rounded-lg p-4 border border-gray-300"
                      >
                        {/* Fields */}
                        <div className="space-y-3 text-sm">
                          <div className="flex justify-between">
                            <span className="font-semibold text-gray-600">Year:</span>
                            <span className="text-gray-900">{item.year}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-semibold text-gray-600">Created Date:</span>
                            <span className="text-gray-900">{item.createdDate}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-semibold text-gray-600">Created By:</span>
                            <span className="text-gray-900">{item.createdBy}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-semibold text-gray-600">Focus Area:</span>
                            <span className="text-gray-900">{item.focusArea}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-semibold text-gray-600">Priority:</span>
                            <span className="text-gray-900">{item.priority}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-semibold text-gray-600">Target Date:</span>
                            <span className="text-gray-900">{item.targetDate}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="font-semibold text-gray-600">Completed Date:</span>
                            <span className="text-gray-900">{item.completedDate}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="font-semibold text-gray-600">Status:</span>
                            <span className={`text-xs font-semibold ${getStatusColor(item.status)}`}>
                              {item.status}
                            </span>
                          </div>
                        </div>

                        {/* Actions for mobile */}
                        <div className="flex justify-end gap-4 mt-4 pt-3 border-t border-gray-200">
                          <div 
                            className="relative" 
                            ref={(el) => dropdownRefs.current[`mobile-${rowId}`] = el}
                          >
                            <button
                              onClick={(e) => toggleDropdown(rowId, e)}
                              className="w-8 h-8 flex items-center justify-center rounded-md border border-gray-300 hover:bg-gray-100 transition-colors"
                            >
                              <MoreVertical size={16} className="text-gray-600" />
                            </button>
                            {dropdownId === rowId && (
                              <div className="absolute right-0 bottom-full mb-1 w-40 bg-white border border-gray-200 rounded-md shadow-lg z-[999]">
                                <div className="py-1">
                                  <button
                                    onClick={(e) => handleEdit(item, e)}
                                    className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-green-50 hover:text-green-700 flex items-center gap-2"
                                  >
                                    <img
                                      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/edit.png"
                                      alt="Edit"
                                      className="w-3 h-3"
                                    />
                                    Edit
                                  </button>
                                  <button
                                    onClick={(e) => handleLogs(item, e)}
                                    className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                  >
                                    <img
                                      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/log.png"
                                      alt="Logs"
                                      className="w-3 h-3"
                                    />
                                    Logs
                                  </button>
                                  <button
onClick={(e) => handleDateChangeClick(item, e)}
                                    className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-red-50 hover:text-red-700 flex items-center gap-2"
                                  >
                                    <img
                                      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                                      alt="Delete"
                                      className="w-3 h-3"
                                    />
                                    Delete
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-center text-gray-500 italic py-4">No data found</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Delete Modal */}
      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={closeDeleteModal}
        onConfirm={confirmDelete}
      />

      {/* Logs Popup */}
      {isLogsPopupOpen && <LogPopup logsData={logsData} onClose={closeLogsPopup} />}
      <DateChangeRequest
        isOpen={isDateChangeOpen}
        onCancel={() => setIsDateChangeOpen(false)}
        // onConfirm={handleConfirmDateChange}
        message="Do you want to request a Target Date Change ?"
      />
    </div>
  );
}

export default PDPActionItems;


