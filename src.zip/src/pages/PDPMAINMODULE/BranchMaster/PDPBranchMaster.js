import { useState, useEffect, useRef, useMemo } from "react"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../Components/SubNavbar3"
import { ArrowLeft, Plus } from "lucide-react"
import Searchinput from "../../../Components/Searchinput"
import Filter from "../../../Components/Filter"
import DeleteModal from "../../../Components/DeleteModal"
import * as XLSX from "xlsx";
import ActivateStatus from "../../../Components/ActivateStatus"
import DeactivateStatus from "../../../Components/DeactivateStatus"
import { ChevronUp, ChevronDown,ChevronsUpDown } from "lucide-react";
import { getMarketAreas } from "../../../services/pdpMaster/marketArea.service.js";
import { getDealers } from "../../../services/pdpMaster/dealership.service.js";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../services/download/bluckDownload.service.js"
import { saveAs } from "file-saver";
import { getAllCities, getAllDistricts } from "../../../services/pdpMaster/mainData.service.js";
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import {
  getBranchMasters,
  addBranchMaster,
  updateBranchMaster,
  toggleBranchMaster,
  deleteBranchMaster
} from "../../../services/pdpMaster/branchMaster.service.js";
import Header from "../../../Components/Header"
import StyledDateField from "../../../Components/StyledDatefield.js"
import { formatDateOnly } from "../../../util/timeFormat.js"
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation.js"

function PDPBranchMaster() {
  // API Data States
  const [marketAreas, setMarketAreas] = useState([]);
  const [dealers, setDealers] = useState([]);
  const [cities, setCities] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [marketAreaSearch, setMarketAreaSearch] = useState("");
  const [dealerSearch, setDealerSearch] = useState("");
  const [citySearch, setCitySearch] = useState("");
  const [districtSearch, setDistrictSearch] = useState("");
  const popupRef= useRef()
  const facilityTypes = [
    "Touch Point",
    "3S Facility",
    "2S Facility",
    "35 Facility",
    "25 Facility"
  ];

  const developmentStatusOptions = ["New", "In Progress", "Completed"];
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState("asc"); // asc | desc
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};

  const [selectedMarketAreas, setSelectedMarketAreas] = useState([]);
  const [selectedDealerships, setSelectedDealerships] = useState([]);
  const [selectedCities, setSelectedCities] = useState([]);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [selectedDealership, setSelectedDealership] = useState(null);
  const [selectedCity, setSelectedCity] = useState(null);
  const [selectedFacilityType, setSelectedFacilityType] = useState("");
  const [selectedRow, setSelectedRow] = useState(null);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [selectedDistricts, setSelectedDistricts] = useState([]);
  const [expandedRow, setExpandedRow] = useState(null);
  const [selectedFacilityTypes, setSelectedFacilityTypes] = useState([]);
  const [selectedDevelopmentStatus, setSelectedDevelopmentStatus] = useState([]);
  const [facilityTypeSearch, setFacilityTypeSearch] = useState("");

  const [menuOpen, setMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const dropdownRef = useRef(null)
  const tableContainerRef = useRef(null)

  const [tableData, setTableData] = useState([]);
  const [formData, setFormData] = useState({
    market_area_id: "",
    dealership_id: "",
    city_id: "",
    district_ids: [],
    branch_name: "",
    facility_type: "",
    development_status: "",
    target_date: "",
  });

  const [isEditing, setIsEditing] = useState(false)
  const [editIndex, setEditIndex] = useState(null)
  const [errors, setErrors] = useState({})
  const [searchQuery, setSearchQuery] = useState("")
  const [deleteIndex, setDeleteIndex] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const fileInputRef = useRef(null)

  // API Loading Functions
  const loadMarketAreas = async () => {
    try {
      setLoading(true);
      const data = await getMarketAreas();
      setMarketAreas(data || []);
    } catch (error) {
      console.error("Error loading market areas:", error);
      setError("Failed to load market areas");
    } finally {
      setLoading(false);
    }
  };

  const loadDealers = async () => {
    try {
      setLoading(true);
      const data = await getDealers();
      setDealers(data || []);
    } catch (error) {
      console.error("Error loading dealers:", error);
      setError("Failed to load dealers");
    } finally {
      setLoading(false);
    }
  };

  const loadCities = async () => {
    try {
      setLoading(true);
      const data = await getAllCities();
      setCities(data || []);
    } catch (error) {
      console.error("Error loading cities:", error);
      setError("Failed to load cities");
    } finally {
      setLoading(false);
    }
  };

  const loadDistricts = async () => {
    try {
      setLoading(true);
      const data = await getAllDistricts();
      setDistricts(data || []);
    } catch (error) {
      console.error("Error loading districts:", error);
      setError("Failed to load districts");
    } finally {
      setLoading(false);
    }
  };

  const loadBranchMasters = async () => {
    try {
      setLoading(true);
      const data = await getBranchMasters();
      setTableData(data || []);
    } catch (error) {
      console.error("Error loading branch masters:", error);
      setError("Failed to load branch masters");
    } finally {
      setLoading(false);
    }
  };

  const toggleDropdown = (name) => {
    setActiveDropdown((prev) => (prev === name ? null : name));
  };

  const toggleExpand = (id) => {
    setExpandedRow(expandedRow === id ? null : id);
  };

  const handleBulkUploadClick = () => {
    fileInputRef.current.click()
  }

  const filteredData = useMemo(() => {
    return tableData?.filter(item => {
      const matchesMarketArea = selectedMarketAreas.length > 0 ? selectedMarketAreas.includes(item.marketarea) : true;
      const matchesDealership = selectedDealerships.length > 0 ? selectedDealerships.includes(item.dealer_name) : true;
      const matchesCity = selectedCities.length > 0 ? selectedCities.includes(item.city_name) : true;
      const matchesFacilityType = selectedFacilityTypes.length > 0 ? selectedFacilityTypes.includes(item.facility_type) : true;
      const matchesDevelopmentStatus = selectedDevelopmentStatus.length > 0 ? selectedDevelopmentStatus.includes(item.development_status) : true;
      const matchesSearch = Object.values(item).some(val =>
        val?.toString().toLowerCase().includes(searchQuery.toLowerCase())
      );
      return matchesMarketArea && matchesDealership && matchesCity && matchesFacilityType && matchesDevelopmentStatus && matchesSearch;
    }) || [];
  }, [tableData, selectedMarketAreas, selectedDealerships, selectedCities, selectedFacilityTypes, selectedDevelopmentStatus, searchQuery]);
const sortedData = useMemo(() => {
  if (!sortKey) return filteredData;

  return [...filteredData].sort((a, b) => {
    let valA = a[sortKey];
    let valB = b[sortKey];

    // Date sorting
    if (sortKey === "target_date") {
      return sortOrder === "asc"
        ? new Date(valA || 0) - new Date(valB || 0)
        : new Date(valB || 0) - new Date(valA || 0);
    }

    // String sorting
    valA = (valA || "").toString().toLowerCase();
    valB = (valB || "").toString().toLowerCase();

    return sortOrder === "asc"
      ? valA.localeCompare(valB)
      : valB.localeCompare(valA);
  });
}, [filteredData, sortKey, sortOrder]);


  // Load all data on component mount
  useEffect(() => {
    const loadAllData = async () => {
      await Promise.all([
        loadMarketAreas(),
        loadDealers(),
        loadCities(),
        loadDistricts(),
        loadBranchMasters()
      ]);
    };
    loadAllData();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (!e.target.closest(".dropdown-wrapper")) {
        setActiveDropdown(null);
          setMarketAreaSearch("");
          setDealerSearch("") // ⭐ reset filter
          setCitySearch("")
          setCitySearch("")
          setDistrictSearch("")
           setFacilityTypeSearch("")
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  
  const handlePreviewAndDownload = async () => {
    if (!filteredData || filteredData.length === 0) {
      alert("No data available to generate preview");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("Branch Master");

      // ===== HEADERS =====
      sheet.columns = [
        { header: "Market Area", key: "marketarea", width: 25 },
        { header: "Dealership", key: "dealer_name", width: 25 },
        { header: "City", key: "city_name", width: 20 },
        { header: "Districts", key: "districts", width: 30 },
        { header: "Branch Name", key: "branch_name", width: 25 },
        { header: "Facility Type", key: "facility_type", width: 20 },
        { header: "Dev Status", key: "development_status", width: 20 },
        { header: "Target Date", key: "target_date", width: 15 },
      ];

      // ===== HEADER STYLE =====
      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" }, // Dusty blue
        };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      // ===== DATA ROWS =====
      filteredData.forEach((item) => {
        sheet.addRow({
          marketarea: item.marketarea || "-",
          dealer_name: item.dealer_name || "-",
          city_name: item.city_name || "-",
          districts:
            item.districts?.map((d) => d.district_name).join(", ") || "-",
          branch_name: item.branch_name || "-",
          facility_type: item.facility_type || "-",
          development_status: item.development_status || "-",
          target_date: item.target_date
            ? formatDateOnly(item.target_date)
            : "-",
        });
      });

      // ===== CREATE FILE =====
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const file = new File([blob], "Branch_Master.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      // ===== UPLOAD TEMP FILE =====
      const response = await uploadTempFile(file);

      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        alert("Upload succeeded but preview not available");
      }
    } catch (error) {
      console.error("Preview generation failed:", error);
      alert("Failed to generate preview");
    }
  };

const getDistrictNames = (districts = []) =>
  districts.map(d => d.district_name).join(", ");
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
    document.getElementById("saveBranchBtn")?.click();
  },

onCancel: () => {
  setIsAddUserOpen(false)
  setFormData({
    market_area_id: "",
    dealership_id: "",
    city_id: "",
    district_ids: [],
    branch_name: "",
    facility_type: "",
    development_status: "",
  })
  setErrors({})
  setIsEditing(false)
  setEditIndex(null)
  // setSearchTerms({
  //   marketArea: "",
  //   dealership: "",
  //   city: "",
  //   district: "",
  //   facilityType: "",
  //   developmentStatus: "",
  // })
}

});


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      {/* Main Container with Responsive Padding */}
      <div className={`transition-all duration-300 ${menuOpen ? "" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full transition-all duration-300 ease-in-out">

            {/* 🔹 Heading - Responsive */}
            <div className="flex items-center justify-center mb-2">
              <h2 className="text-xl font-medium font-VolvoNovum text-darkblue1">
                Branch Master
              </h2>
            </div>

            {/* Error Display - Responsive */}
            {error && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-3 sm:px-4 py-2 sm:py-3 mb-3 text-sm sm:text-base">
                {error}
                <button
                  onClick={() => setError(null)}
                  className="float-right font-bold text-red-700 ml-2"
                >
                  ×
                </button>
              </div>
            )}

           {/* 🔹 Filters Section - Single Line Layout */}
            <div className="flex flex-wrap items-center gap-3 mb-3 w-full">
              {/* Search Input */}
              <div className="w-full md:w-auto md:flex-1 md:max-w-[250px]">
                <Searchinput
                  onChange={(e) => setSearchQuery(e.target.value)}
                  value={searchQuery}
                  placeholder="Search"
                  className="w-full"
                  iconColor="text-black"
                  bgColor="bg-FrostWhite"
                  borderColor="border-black/60"
                  textColor="text-black"
                  shadow="shadow-none"
                  inputPadding="pl-8 pr-3 py-2"
                  iconSize="w-4 h-4"
                  iconLeft="left-3"
                  inputWidth="w-full"
                  focusRing="focus:ring-1 focus:ring-black/60"
                  hoverInputClasses="hover:bg-white hover:border-black/60"
                />
              </div>

              {/* Market Area */}
              <div className="">
                <Filter
                  name="marketarea"
                  placeholder="Market Area"
                  options={marketAreas.map((area) => area.marketarea)}
                  value={selectedMarketAreas}
                  onChange={(name, value) => {
                    setSelectedMarketAreas(value);
                    setSelectedDealerships([]);
                    setSelectedCities([]);
                  }}
                  customWidth="w-full"
                  textColor="text-black"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                />
              </div>

              {/* Dealership */}
              <div className="">
                <Filter
                  name="dealership"
                  placeholder="Dealership"
                  options={dealers.map((dealer) => dealer.dealerName)}
                  value={selectedDealerships}
                  onChange={(name, value) => {
                    setSelectedDealerships(value);
                    setSelectedCities([]);
                  }}
                  customWidth="w-full"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  textColor="text-black"
                />
              </div>

              {/* City */}
              <div className="">
                <Filter
                  name="city"
                  placeholder="City"
                  options={cities.map((city) => city.city_name)}
                  value={selectedCities}
                  onChange={(name, value) => setSelectedCities(value)}
                  customWidth="w-full"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  textColor="text-black"
                />
              </div>

              {/* Facility Type */}
              <div className="">
                <Filter
                  name="facilitytype"
                  placeholder="Facility Type"
                  options={facilityTypes}
                  value={selectedFacilityTypes}
                  onChange={(name, value) => setSelectedFacilityTypes(value)}
                  customWidth="w-full"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  textColor="text-black"
                />
              </div>

              {/* Development Status */}
              <div className="">
                <Filter
                  name="developmentstatus"
                  placeholder="Dev Status"
                  options={developmentStatusOptions}
                  value={selectedDevelopmentStatus}
                  onChange={(name, value) => setSelectedDevelopmentStatus(value)}
                  customWidth="w-full"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  textColor="text-black"
                />
              </div>

              {/* Download Button */}
              <div className="w-[calc(50%-6px)] sm:w-auto sm:min-w-[120px]">
                <button
                  onClick={handlePreviewAndDownload}
                  className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1 flex items-center justify-center gap-2 hover:bg-darkblue1 hover:text-white transition w-full"
                >
                   <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
<path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D"/>
</svg>
           
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"className="w-3 h-3 hidden group-hover:block">
<path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white"/>
</svg>

                  <span className="font-semibold">Download</span>
                </button>
              </div>
            </div>


            {/* 🔹 Table Section - Responsive */}
            <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
              <div
                ref={tableContainerRef}
                className="w-full overflow-y-auto overflow-x-hidden max-h-[calc(100vh-220px)]"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                  onScroll={handleTableScroll}

              >
                <style jsx>{`
                  div::-webkit-scrollbar {
                    display: none;
                  }
                `}</style>
                <table className="w-full text-xs border-collapse table-fixed">
                   <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10 font-normal text-xs">
                    <tr>
<th
  onClick={() => handleSort("marketarea")}
  className="text-left px-2 py-1.5 border border-grey2 border-t-0 border-l-0 w-[10%] font-normal cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Market Area
     {sortKey !== "marketarea" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
    {sortKey === "marketarea" &&
      (sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3" />
      ) : (
        <ChevronDown className="w-3 h-3" />
      ))}
  </div>
</th>
                      <th
  onClick={() => handleSort("dealer_name")}
  className="text-left px-2 py-1.5 border border-grey2 border-t-0 border-l-0 w-[14%] font-normal cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Dealership
    {sortKey === "dealer_name" &&
      (sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3" />
      ) : (
        <ChevronDown className="w-3 h-3" />
      ))}
  </div>
</th>

<th
  onClick={() => handleSort("city_name")}
  className="text-left px-2 py-1.5 border border-grey2 border-t-0 border-l-0 w-[10%] font-normal cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    City
    {sortKey === "city_name" &&
      (sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3" />
      ) : (
        <ChevronDown className="w-3 h-3" />
      ))}
  </div>
</th>

<th
  onClick={() => handleSort("districts")}
  className="text-left px-2 py-1.5 border border-grey2 border-t-0 border-l-0 w-[14%] font-normal cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Districts
    {sortKey === "districts" &&
      (sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3" />
      ) : (
        <ChevronDown className="w-3 h-3" />
      ))}
  </div>
</th>

<th
  onClick={() => handleSort("branch_name")}
  className="text-left px-2 py-1.5 border border-grey2 border-t-0 border-l-0 w-[14%] font-normal cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Branch Name
    {sortKey === "branch_name" &&
      (sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3" />
      ) : (
        <ChevronDown className="w-3 h-3" />
      ))}
  </div>
</th>

<th
  onClick={() => handleSort("facility_type")}
  className="text-left px-2 py-1.5 border border-grey2 border-t-0 border-l-0 w-[10%] font-normal cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Facility Type
    {sortKey === "facility_type" &&
      (sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3" />
      ) : (
        <ChevronDown className="w-3 h-3" />
      ))}
  </div>
</th>

<th
  onClick={() => handleSort("development_status")}
  className="text-left px-2 py-1.5 border border-grey2 border-t-0 border-l-0 w-[10%] font-normal cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Dev Status
    {sortKey === "development_status" &&
      (sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3" />
      ) : (
        <ChevronDown className="w-3 h-3" />
      ))}
  </div>
</th>

<th
  onClick={() => handleSort("target_date")}
  className="text-left px-2 py-1.5 border border-grey2 border-t-0 border-l-0 w-[10%] font-normal cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Target Date
    {sortKey === "target_date" &&
      (sortOrder === "asc" ? (
        <ChevronUp className="w-3 h-3" />
      ) : (
        <ChevronDown className="w-3 h-3" />
      ))}
  </div>
</th>

                      <th className="text-center px-2 py-1.5 border border-grey2 border-t-0 border-l-0 border-r-0 font-normal w-[8%]">Actions</th>
                    </tr>
                  </thead>

                  <tbody className="text-black">
                    {sortedData.length > 0 ? (
                      sortedData.map((item, index) => (
                        <tr
                          key={index}
                          className="hover:bg-gray-100 transition-colors text-xs text-left"
                        >
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate cursor-pointer"
      onMouseEnter={() => {
        if (item.marketarea && item.marketarea.length > 25) {
          setHoveredCell(`${item.id}-marketarea`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.marketarea || "-"}
    </p>

    {hoveredCell === `${item.id}-marketarea` && (
      <span className="absolute left-1/2 top-full mt-0 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0 ">
        {item.marketarea}
      </span>
    )}
  </div>
</td>

                         <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate cursor-pointer"
      onMouseEnter={() => {
        if (item.dealer_name && item.dealer_name.length > 30) {
          setHoveredCell(`${item.id}-dealer`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.dealer_name || "-"}
    </p>

    {hoveredCell === `${item.id}-dealer` && (
      <span className="absolute left-1/2 top-full mt-0 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {item.dealer_name}
      </span>
    )}
  </div>
</td>

                       <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate cursor-pointer"
      onMouseEnter={() => {
        if (item.city_name && item.city_name.length > 20) {
          setHoveredCell(`${item.id}-city`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.city_name || "-"}
    </p>

    {hoveredCell === `${item.id}-city` && (
      <span className="absolute left-1/2 top-full mt-0 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0 ">
        {item.city_name}
      </span>
    )}
  </div>
</td>

                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">
  {item?.districts && Array.isArray(item.districts) && item.districts.length > 0 ? (
    <div
      className="relative"
      onMouseEnter={() => {
        if (item.districts.length > 2 && expandedRow !== item.id) {
          setHoveredCell(`${item.id}-districts`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {(expandedRow === item.id
        ? item.districts
        : item.districts.slice(0, 2)
      ).map((d, i, arr) => (
        <div key={i} className="flex items-center gap-1">
          <span className="text-xs truncate max-w-[12rem]">
            {d.district_name}
          </span>

          {i === arr.length - 1 && item.districts.length > 2 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleExpand(item.id);
              }}
              className="flex items-center text-blue-600 hover:text-blue-800 text-xs flex-shrink-0"
            >
              {expandedRow === item.id ? (
                <ChevronUp className="w-3 h-3" />
              ) : (
                <ChevronDown className="w-3 h-3" />
              )}
            </button>
          )}
        </div>
      ))}

      {/* 🔥 Hover Tooltip */}
      {hoveredCell === `${item.id}-districts` && (
        <span className="absolute left-1/2 top-full mt-0 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0 ">
          {getDistrictNames(item.districts)}
        </span>
      )}
    </div>
  ) : (
    <span className="text-gray-500">-</span>
  )}
</td>

                         <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate cursor-pointer"
      onMouseEnter={() => {
        if (item.branch_name && item.branch_name.length > 30) {
          setHoveredCell(`${item.id}-branch`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.branch_name || "-"}
    </p>

    {hoveredCell === `${item.id}-branch` && (
      <span className="absolute left-1/2 top-full mt-0 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0 ">
        {item.branch_name}
      </span>
    )}
  </div>
</td>

                         <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate cursor-pointer"
      onMouseEnter={() => {
        if (item.facility_type && item.facility_type.length > 20) {
          setHoveredCell(`${item.id}-facility`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.facility_type || "-"}
    </p>

    {hoveredCell === `${item.id}-facility` && (
      <span className="absolute left-1/2 top-full mt-0 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0 ">
        {item.facility_type}
      </span>
    )}
  </div>
</td>

                         <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate cursor-pointer"
      onMouseEnter={() => {
        if (item.development_status && item.development_status.length > 20) {
          setHoveredCell(`${item.id}-devstatus`);
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.development_status || "-"}
    </p>

    {hoveredCell === `${item.id}-devstatus` && (
      <span className="absolute left-1/2 top-full mt-0 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0 ">
        {item.development_status}
      </span>
    )}
  </div>
</td>

                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 whitespace-nowrap">
                            {item.target_date ? formatDateOnly(item.target_date) : "-"}
                          </td>
                          
                          {/* Actions */}
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                            <div className="flex items-center justify-center gap-2">
                              {/* Edit Button */}
                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setFormData({
                                      market_area_id: item.market_area_id,
                                      dealership_id: item.dealership_id,
                                      city_id: item.city_id,
                                      district_ids: item.districts?.map(d => d.district_id) || [],
                                      branch_name: item.branch_name,
                                      facility_type: item.facility_type,
                                      development_status: item.development_status || "",
                                      target_date: item.target_date || "",
                                    });
                                    setIsEditing(true);
                                    setEditIndex(item.id);
                                    setIsAddUserOpen(true);
                                  }}
                                  className="text-blue-600 hover:underline p-1"
                                >
                                 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

                                </button>
                                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0 pointer-events-none">
                                  Edit
                                </span>
                              </div>

                              {/* Delete Button */}
                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setDeleteIndex(item.id);
                                    setIsDeleteModalOpen(true);
                                  }}
                                  className="text-blue-600 hover:underline p-1"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>	

                                </button>
                                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0 pointer-events-none">
                                  Delete
                                </span>
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={9} className="text-center py-8 text-gray-500 italic text-sm">
                          No data found
                        </td>
                      </tr>
                    )}
                  </tbody>

                </table>
              </div>
               {showScrollButtons && (
            <div className="fixed bottom-10 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

            </div>
          </div>
        </div>
      </div>

      {/* 🔹 Modal - Fully Responsive */}
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center p-3 sm:p-4">
          <div 
           ref={popupRef}
     tabIndex={0}
          className="bg-white p-4 sm:p-6 w-full max-w-xl max-h-[90vh] overflow-y-auto relative">
            <h2 className="text-base sm:text-lg font-semibold text-center mb-4 sm:mb-6 text-MediumGrey">
              {isEditing ? "Edit Branch Master" : "Add Branch Master"}
            </h2>
            <button
              onClick={() => {
                setIsAddUserOpen(false)
                setFormData({
                  market_area_id: "", dealership_id: "", city_id: "", district_ids: [],
                  branch_name: "", facility_type: "", development_status: "", target_date: ""
                });
                setErrors({})
                setIsEditing(false)
                setEditIndex(null)
              }}
              className="absolute top-3 right-3 sm:top-4 sm:right-4 text-red-600 font-bold"
            >
<svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>


            </button>

            {/* Form Grid - Responsive */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
              {/* Market Area */}
              
<div className="sm:col-span-1 dropdown-wrapper relative">
  <label className="text-xs font-medium text-black/70">
    Market Area <span className="text-red1">*</span>
  </label>

  <div className="relative w-full">

    <input
      type="text"
      readOnly
      value={marketAreas.find(area => area.id === formData.market_area_id)?.marketarea || ""}
      placeholder="Select Market Area"
       onKeyDown={(e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      setActiveDropdown("marketArea");
    }

    if (e.key === "Escape") {
       e.stopPropagation();
      setActiveDropdown(null);
    }
  }}
      onClick={() => {
        if (activeDropdown === "marketArea") {
          setActiveDropdown(null);
          setMarketAreaSearch(""); // reset search
        } else {
          setActiveDropdown("marketArea");
        }
        
      }}
      className={`border w-full mt-1 text-xs  px-2  py-1.5 outline-none cursor-pointer focus:ring-1 focus:ring-black/30 bg-transparent
      ${activeDropdown === "marketArea" ? "border-b-white" : ""}
      ${errors.marketArea ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
      `}
    />

    {/* Dropdown Arrow */}
   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"onClick={() => toggleDropdown("marketArea")}
                    className={`w-3 h-3 absolute right-2 sm:right-3 top-[14px] cursor-pointer transform transition-transform duration-200 ${activeDropdown === "marketArea" ? "rotate-180" : "rotate-0"
                      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>

    {/* Dropdown */}
    {activeDropdown === "marketArea" && (
<div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200">
        {/* Search input (only when >5 options) */}
        {marketAreas.length > 5 && (
          <div className="p-2  sticky top-0 bg-white">
            <input
              type="text"
              value={marketAreaSearch}
              onChange={(e) => setMarketAreaSearch(e.target.value)}
              placeholder="Search market area..."
              className="w-full text-xs  px-2 py-1 border border-gray-300 outline-none"

            />
          </div>
        )}

        {marketAreas
          .filter((area) => area.id !== formData.market_area_id)
          .filter((area) =>
            area.marketarea
              .toLowerCase()
              .includes(marketAreaSearch.toLowerCase())
          )
          .map((area) => (
            <div
              key={area.id}
              onMouseDown={(e) => {
                e.preventDefault();
                setFormData({
                  ...formData,
                  market_area_id: area.id,
                  dealership_id: ""
                });

                setActiveDropdown(null);
                setMarketAreaSearch(""); // reset search
              }}
              
              className="px-2 sm:px-3 py-2 text-xs cursor-pointer hover:bg-gray-100"
            >
              {area.marketarea}
            </div>
          ))}

      </div>
    )}

  </div>

  {errors.marketArea && (
    <p className="text-red1 text-xs mt-1">{errors.marketArea}</p>
  )}
</div>
            {/* Dealership */}
<div className="col-span-1 sm:col-span-2 dropdown-wrapper relative">
  <label className="text-xs font-medium text-black/70">
    Dealership <span className="text-red1">*</span>
  </label>

  <div className="relative w-full">

    <input
      type="text"
      readOnly
      value={dealers.find(dealer => dealer.id === formData.dealership_id)?.dealerName || ""}
      placeholder="Select Dealership"
      onClick={() => {
        if (activeDropdown === "dealership") {
          setActiveDropdown(null);
          setDealerSearch("");
        } else {
          setActiveDropdown("dealership");
        }
      }}
      className={`border w-full mt-1 text-xs  px-2 py-1.5 outline-none cursor-pointer
      ${activeDropdown === "dealership" ? "border-b-white" : ""}
      ${errors.dealership ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
      `}
    />

    {/* Arrow */}
   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => {
        if (activeDropdown === "dealership") {
          setActiveDropdown(null);
          setDealerSearch("");
        } else {
          setActiveDropdown("dealership");
        }
      }}
      className={`w-3 h-3 absolute right-2 sm:right-3 top-[14px] cursor-pointer transform transition-transform duration-200 ${
        activeDropdown === "dealership" ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>

    {activeDropdown === "dealership" && (
<div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200">
        {/* Search input */}
        {dealers.length > 5 && (
          <div className="p-2  sticky top-0 bg-white">
            <input
              type="text"
              value={dealerSearch}
              onChange={(e) => setDealerSearch(e.target.value)}
              placeholder="Search dealership..."
              className="w-full text-xs  px-2 py-1 border border-gray-300 outline-none"
            />
          </div>
        )}

        {dealers
          .filter((d) => d.id !== formData.dealership_id)
          .filter((d) =>
            d.dealerName.toLowerCase().includes(dealerSearch.toLowerCase())
          )
          .map((d) => (
            <div
              key={d.id}
              onMouseDown={(e) => {
                e.preventDefault();
                setFormData({ ...formData, dealership_id: d.id });
                setActiveDropdown(null);
                setDealerSearch(""); // reset filter
              }}
              className="px-2 sm:px-3 py-2 text-xs cursor-pointer hover:bg-gray-100"
            >
              {d.dealerName}
            </div>
          ))}

      </div>
    )}

  </div>

  {errors.dealership && (
    <p className="text-red1 text-xs mt-1">{errors.dealership}</p>
  )}
</div>
              {/* City */}
             {/* City */}
<div className="col-span-1 sm:col-span-3 dropdown-wrapper relative">
  <label className="text-xs font-medium text-black/70">
    City <span className="text-red1">*</span>
  </label>

  <div className="relative w-full">

    <input
      type="text"
      readOnly
      value={cities.find(city => city.id === formData.city_id)?.city_name || ""}
      placeholder="Select City"
      disabled={!formData.dealership_id}
      onClick={() => {
        if (!formData.dealership_id) return;

        if (activeDropdown === "city") {
          setActiveDropdown(null);
          setCitySearch("");
        } else {
          setActiveDropdown("city");
        }
      }}
      className={`border w-full mt-1 text-xs  px-2 sm:px-3 py-2 outline-none cursor-pointer
      ${activeDropdown === "city" ? "border-b-white" : ""}
      ${errors.city ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
      ${!formData.dealership_id ? "bg-gray-100 cursor-not-allowed" : "bg-transparent"}
      `}
    />

    {/* Arrow */}
   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => {
        if (!formData.dealership_id) return;

        if (activeDropdown === "city") {
          setActiveDropdown(null);
          setCitySearch("");
        } else {
          setActiveDropdown("city");
        }
      }}
      className={`w-3 h-3 absolute right-2 sm:right-3 top-[14px] cursor-pointer transform transition-transform duration-200 ${
        activeDropdown === "city" ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>

    {activeDropdown === "city" && formData.dealership_id && (
<div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200">
        {/* Search bar */}
        {cities.length > 5 && (
          <div className="p-2 sticky top-0 bg-white">
            <input
              type="text"
              value={citySearch}
              onChange={(e) => setCitySearch(e.target.value)}
              placeholder="Search city..."
              className="w-full text-xs  px-2 py-1 border border-gray-300 outline-none"
            />
          </div>
        )}

        {cities
          .filter(c => c.id !== formData.city_id)
          .filter(c =>
            c.city_name.toLowerCase().includes(citySearch.toLowerCase())
          )
          .map((city) => (
            <div
              key={city.id}
              onMouseDown={(e) => {
                e.preventDefault();
                setFormData({ ...formData, city_id: city.id });
                setActiveDropdown(null);
                setCitySearch("");
              }}
              className="px-2 sm:px-3 py-2 text-xs  cursor-pointer hover:bg-gray-100"
            >
              {city.city_name}
            </div>
          ))}

      </div>
    )}

  </div>

  {errors.city && (
    <p className="text-red1 text-xs mt-1">{errors.city}</p>
  )}
</div>

              {/* District */}
            {/* District */}
<div className="col-span-1 sm:col-span-3 dropdown-wrapper relative">
  <label className="text-xs font-medium text-black/70">
    District <span className="text-red1">*</span>
  </label>

  <div className="relative w-full">

    <div
      onClick={() => {
        if (!formData.city_id) return;

        if (activeDropdown === "district") {
          setActiveDropdown(null);
          setDistrictSearch("");
        } else {
          setActiveDropdown("district");
        }
      }}
      className={`border w-full mt-1 text-xs  px-2 sm:px-3 py-1.5 outline-none cursor-pointer flex flex-wrap gap-1 
      ${activeDropdown === "district" ? "border-b-white" : ""}
      ${errors.district ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
      ${!formData.city_id ? "bg-gray-100 cursor-not-allowed" : ""}
      `}
    >

      {formData.district_ids.length > 0 ? (
        formData.district_ids.map((districtId) => {
          const district = districts.find(d => d.id === districtId);

          return (
            <span
              key={districtId}
              className="flex items-center gap-1 sm:gap-2 bg-grey2 text-black px-2 py-0.5  text-xs"
            >
              {district?.district_name}

              <button
                type="button"
                className="hover:text-red-500"
                onClick={(e) => {
                  e.stopPropagation();

                  setFormData(prev => ({
                    ...prev,
                    district_ids: prev.district_ids.filter(d => d !== districtId)
                  }));
                }}
              >
                <svg width="14" height="14" viewBox="0 0 20 20">
                  <circle cx="10" cy="10" r="8" fill="#BF2012" />
                  <path d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
              </button>

            </span>
          );
        })
      ) : (
        <span className="text-black/60 text-xs sm:text-sm">
          Select District
        </span>
      )}

    </div>

    {/* Arrow */}
   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => formData.city_id && toggleDropdown("district")}
                    className={`w-3 h-3  absolute right-2 sm:right-3 top-3 cursor-pointer transform transition-transform duration-200 ${activeDropdown === "district" ? "rotate-180" : "rotate-0"
                      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>    {activeDropdown === "district" && formData.city_id && (
<div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200">
        {/* Search */}
        {districts.length > 5 && (
          <div className="p-2  sticky top-0 bg-white">
            <input
              type="text"
              value={districtSearch}
              onChange={(e) => setDistrictSearch(e.target.value)}
              placeholder="Search district..."
              className="w-full text-xs sm:text-sm px-2 py-1 border border-gray-300 outline-none"
            />
          </div>
        )}

        {districts
          .filter(d =>
            d.district_name
              .toLowerCase()
              .includes(districtSearch.toLowerCase())
          )
          .map((dist) => {

            const selected = formData.district_ids.includes(dist.id);

            return (
              <div
                key={dist.id}
                onMouseDown={(e) => {
                  e.preventDefault();

                  setFormData(prev => ({
                    ...prev,
                    district_ids: selected
                      ? prev.district_ids.filter(d => d !== dist.id)
                      : [...prev.district_ids, dist.id]
                  }));
                }}
                className={`px-2 sm:px-3 py-2 text-xs cursor-pointer hover:bg-gray-100 ${
                  selected ? "bg-gray-200 font-medium" : ""
                }`}
              >
                {dist.district_name}
              </div>
            );

          })}

      </div>
    )}

  </div>

  {errors.district && (
    <p className="text-red1 text-xs mt-1">{errors.district}</p>
  )}
</div>

              {/* Branch Name */}
              <div className="col-span-1 sm:col-span-3">
                <label className="text-xs  text-gray-600 mb-1 block">Branch Name <span className="text-red1">*</span></label>
                <input
                  type="text"
                  value={formData.branch_name || ""}
                  onChange={(e) => setFormData({ ...formData, branch_name: e.target.value })}
                  placeholder="Enter Branch Name"
                  className={`w-full border px-2 sm:px-3 py-1.5 text-xs focus:outline-none focus:ring-1
                    ${errors.branchName ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                  `}
                />
                {errors.branchName && (
                  <p className="text-red1 text-xs mt-1">{errors.branchName}</p>
                )}
              </div>

              {/* Facility Type */}
          <div className="col-span-1 dropdown-wrapper relative">

  <label className="text-xs font-medium text-black/70">
    Facility Type <span className="text-red1">*</span>
  </label>

  <div className="relative w-full">

    <input
      type="text"
      readOnly
      value={formData.facility_type || ""}
      placeholder="Select Facility Type"
      onClick={() => {
        if (activeDropdown === "facilityType") {
          setActiveDropdown(null);
          setFacilityTypeSearch("");
        } else {
          setActiveDropdown("facilityType");
        }
      }}
      className={`border w-full mt-1 text-xs  sm:px-3 py-1.5 outline-none cursor-pointer
      ${activeDropdown === "facilityType" ? "border-b-white" : ""}
      ${errors.facilityType ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
      `}
    />

    {/* Arrow */}
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"  onClick={() => {
        if (activeDropdown === "facilityType") {
          setActiveDropdown(null);
          setFacilityTypeSearch("");
        } else {
          setActiveDropdown("facilityType");
        }
      }}
      className={`w-3 h-3 absolute right-2 sm:right-3 top-[14px] cursor-pointer transform transition-transform duration-200 ${
        activeDropdown === "facilityType" ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>

    {activeDropdown === "facilityType" && (
      <div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto">

        {/* Search */}
        {facilityTypes.length > 5 && (
          <div className="p-2  sticky top-0 bg-white">
            <input
              type="text"
              value={facilityTypeSearch}
              onChange={(e) => setFacilityTypeSearch(e.target.value)}
              placeholder="Search facility type..."
              className="w-full text-xs px-2 py-1 border border-gray-300 outline-none"
            />
          </div>
        )}

        {facilityTypes
          .filter(ft => ft !== formData.facility_type)
          .filter(ft =>
            ft.toLowerCase().includes(facilityTypeSearch.toLowerCase())
          )
          .map((ft) => (
            <div
              key={ft}
              onMouseDown={(e) => {
                e.preventDefault();
                setFormData({ ...formData, facility_type: ft });
                setActiveDropdown(null);
                setFacilityTypeSearch("");
              }}
              className="px-2 sm:px-3 py-2 text-xs cursor-pointer hover:bg-gray-100"
            >
              {ft}
            </div>
          ))}

      </div>
    )}

  </div>

  {errors.facilityType && (
    <p className="text-red1 text-xs mt-1">{errors.facilityType}</p>
  )}

</div>

              {/* Development Status - NOT REQUIRED IN EDIT MODE */}
              <div className="col-span-1 sm:col-span-2 dropdown-wrapper relative">
                <label className="text-xs  font-medium text-black/70">
                  Development Status <span className="text-red1">{!isEditing && "*"}</span>
                </label>
                <div className="relative w-full">
                  <input
                    type="text"
                    readOnly
                    value={formData.development_status || ""}
                    placeholder={isEditing ? "Auto-populated" : "Select Development Status"}
                    onClick={() => !isEditing && toggleDropdown("developmentStatus")}
                    disabled={isEditing}
                    className={`border w-full mt-1 text-xs  px-2 sm:px-3 py-1.5 outline-none ${isEditing ? "bg-gray-100 cursor-not-allowed" : "cursor-pointer"}
                      ${activeDropdown === "developmentStatus" ? " border-b-white" : ""}
                      ${errors.development_status ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                    `}
                  />

                  {!isEditing && (
                    // <img
                    //   src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/dropdown.png"
                    //   alt="Dropdown"
                    //   onClick={() => toggleDropdown("developmentStatus")}
                    //   className={`w-3 h-3 sm:w-4 sm:h-4 absolute right-2 sm:right-3 top-[14px] cursor-pointer transform transition-transform duration-200 ${activeDropdown === "developmentStatus" ? "rotate-180" : "rotate-0"
                    //     }`}
                    // />
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => toggleDropdown("developmentStatus")}
                       className={`w-3 h-3 absolute right-2 sm:right-3 top-[14px] cursor-pointer transform transition-transform duration-200 ${activeDropdown === "developmentStatus" ? "rotate-180" : "rotate-0"
                         }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>
                  )}

                  {activeDropdown === "developmentStatus" && !isEditing && (
                    <div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-30 overflow-y-auto">
                      {developmentStatusOptions
                        .filter((st) => st !== formData.development_status)
                        .map((st) => (
                          <div
                            key={st}
                            onMouseDown={(e) => {
                              e.preventDefault();
                              setFormData({ ...formData, development_status: st });
                              setActiveDropdown(null);
                            }}
                            className="px-2 sm:px-3 py-2 text-xs sm:text-sm cursor-pointer hover:bg-gray-100"
                          >
                            {st}
                          </div>
                        ))}
                    </div>
                  )}
                </div>
                {errors.development_status && (
                  <p className="text-red1 text-xs mt-1">{errors.development_status}</p>
                )}
              </div>

              {/* Target Date - Conditional */}
              {(formData.development_status === "New" ||
                formData.development_status === "In Progress") && (
                  <div className="col-span-1 sm:col-span-3">
                    <StyledDateField
label={
  <>
    Target Date <span className="text-red1">*</span>
  </>
}                      value={formData.target_date || ""}
                      setValue={(value) => setFormData({ ...formData, target_date: value })}
                    />
                    {errors.target_date && (
                      <p className="text-red1 text-xs mt-1">{errors.target_date}</p>
                    )}
                  </div>
                )}
            </div>

            {/* Save Button - Responsive */}
            <button
              onClick={async () => {
                const newErrors = {};
                if (!formData.market_area_id) newErrors.marketArea = "Please select Market Area";
                if (!formData.dealership_id) newErrors.dealership = "Please select Dealership";
                if (!formData.city_id) newErrors.city = "Please select City";
                if (!formData.district_ids || formData.district_ids.length === 0) newErrors.district = "Please select District";
                if (!formData.branch_name) newErrors.branchName = "Please enter Branch Name";
                if (!formData.facility_type) newErrors.facilityType = "Please select Facility Type";

                // Development Status required only for ADD mode, not EDIT
                if (!isEditing && !formData.development_status) newErrors.development_status = "Please select Development Status";

                if ((formData.development_status === "New" || formData.development_status === "In Progress") && !formData.target_date) {
                  newErrors.target_date = "Please select Target Date";
                }

                if (Object.keys(newErrors).length > 0) {
                  setErrors(newErrors);
                  return;
                }

                try {
                  setLoading(true);

                  const payload = {
                    ...formData,
                    development_status: formData.development_status || null,
                    target_date: formData.target_date || null,
                  };

                  if (isEditing) {
                    await updateBranchMaster(editIndex, payload);
                  } else {
                    await addBranchMaster(payload);
                  }

                  await loadBranchMasters();

                  setFormData({
                    market_area_id: "", dealership_id: "", city_id: "", district_ids: [],
                    branch_name: "", facility_type: "", development_status: "", target_date: ""
                  });
                  setErrors({});
                  setIsAddUserOpen(false);
                  setIsEditing(false);
                  setEditIndex(null);
                } catch (error) {
                  console.error("Error saving branch master:", error);
                  setError(error.message || "Failed to save branch master");
                } finally {
                  setLoading(false);
                }
              }}
              disabled={loading}
              className="mt-4 sm:mt-6 bg-darkblue1 text-xs  font-medium text-white px-8 py-2 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "Saving..." : isEditing ? "Update" : "Save"}
            </button>
          </div>
        </div>
      )}

      {/* Modals */}
      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={async () => {
          if (deleteIndex !== null) {
            try {
              setLoading(true);
              await deleteBranchMaster(deleteIndex);
              await loadBranchMasters();
              setDeleteIndex(null);
            } catch (error) {
              console.error("Error deleting branch master:", error);
              setError(error.message || "Failed to delete branch master");
            } finally {
              setLoading(false);
            }
          }
          setIsDeleteModalOpen(false);
        }}
      />

      {showActivateModal && selectedRow !== null && (
        <ActivateStatus
          isOpen={showActivateModal}
          onClose={() => setShowActivateModal(false)}
          onConfirm={async () => {
            try {
              setLoading(true);
              await toggleBranchMaster(selectedRow);
              await loadBranchMasters();
              setShowActivateModal(false);
              setSelectedRow(null);
            } catch (error) {
              console.error("Error activating branch master:", error);
              setError(error.message || "Failed to activate branch master");
            } finally {
              setLoading(false);
            }
          }}
        />
      )}

      {showDeactivateModal && selectedRow !== null && (
        <DeactivateStatus
          isOpen={showDeactivateModal}
          onClose={() => setShowDeactivateModal(false)}
          onConfirm={async () => {
            try {
              setLoading(true);
              await toggleBranchMaster(selectedRow);
              await loadBranchMasters();
              setShowDeactivateModal(false);
              setSelectedRow(null);
            } catch (error) {
              console.error("Error deactivating branch master:", error);
              setError(error.message || "Failed to deactivate branch master");
            } finally {
              setLoading(false);
            }
          }}
        />
      )}
    </div>
  )
}

export default PDPBranchMaster;