"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";
import { ChevronUp, ChevronDown } from "lucide-react";

function PDPBranchMasterDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]); // ⬅️ now controlled by postMessage
const [expandedRow, setExpandedRow] = useState(null);
const toggleExpand = (id) => {
  setExpandedRow(expandedRow === id ? null : id);
};
  // ✅ Listen for postMessage from parent window
  useEffect(() => {
    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const handleDownloadExcel = () => {
  if (!tableData || tableData.length === 0) return;

  const excelData = tableData.map((item, index) => ({
  "Sl. No": String(index + 1),
  "Market Area": item.marketArea,
   "Dealership":item.dealership,
   "City": item.city ,  // ✅ use lowercase
    "Districts": Array.isArray(item.district) ? item.district.join(" ,") : item.district || "",
   "Branch Name":item.branchName,
   "Facility Type":item.facilityType,
   "Development Status":item.developmnet,
   "Target Date":item.target_date ,
   "Status":item.status
}));
  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // 👇 Apply left alignment style explicitly
  Object.keys(worksheet).forEach((cell) => {
    if (cell.startsWith("A")) {
      worksheet[cell].s = { alignment: { horizontal: "left" } };
    }
  });

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Branch Master");
  XLSX.writeFile(workbook, "Branch_Master.xlsx");
};


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-4 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">Branch Master


</h2>
          <button
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-sm  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadExcel}
          >
            Download 
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue  overflow-x-auto">
          <table className="w-full min-w-[600px] text-sm text-left whitespace-nowrap">
            <thead className="bg-Dustyblue text-white text-xs">
              <tr>
                             <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0  font-medium">Sl. No</th>

           <th className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%]">Market Area</th>
                    <th className="text-left px-4 py-1 text-xs border border-grey2 border-t-0 border-l-0 border-b-0   font-medium w-[10%]">Dealership</th>
                    <th className="text-left px-4 py-1 text-xs border border-grey2 border-t-0 border-l-0 border-b-0  font-medium w-[10%]">City</th>
                                        <th className="text-left px-4 py-1 text-xs border border-grey2 border-t-0 border-l-0 border-b-0  font-medium w-[10%]">Districts</th>
                                        <th className="text-left px-4 py-1 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[15%]">Branch Name</th>
                                        <th className="text-left px-4 py-1 text-xs border border-grey2 border-t-0 border-l-0 border-b-0  font-medium w-[30%]">Facility Type</th>
                                        <th className="text-left px-4 py-1 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 text-center font-medium w-[25%]">Status </th>

              </tr>
            </thead>
            <tbody>
              {tableData.length > 0 ? (
                tableData.map((item, index) => (
                  <tr key={index} className="hover:bg-lightBlue/50">
                                        <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{index+1}</td>

                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
  {item.marketArea || "-"}
</td>

      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
  {item.dealership || "-"}
</td>

     <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
  {item.city || "-"}
</td>
     <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
  {item?.district && Array.isArray(item.district) && item.district.length > 0 ? (
    (expandedRow === item.id
      ? item.district
      : item.district.slice(0, 2)
    ).map((d, i, arr) => (
      <div key={i} className="flex items-center gap-4">
        <span>{d}</span>
        {i === arr.length - 1 && item.district.length > 2 && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleExpand(item.id);
            }}
            className="flex items-center text-blue-600 hover:text-blue-800 text-xs"
          >
            {expandedRow === item.id ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </button>
        )}
      </div>
    ))
  ) : (
    <span className="text-gray-500">-</span>
  )}
</td>

      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.branchName}</td>
      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.facilityType}</td>
          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-center ">{item.status}</td>



                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default PDPBranchMasterDownload;
