import React, { useState } from 'react';
import axios from 'axios';
import ForgotPasswordEmailPreview from '../../Components/ForgotPasswordEmailPreview';
import SuccessMessage from '../Management/UserMangement/SuccessMessage';
import { API } from '../../api';

const ForgotPassword = () => {
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [email, setEmail] = useState(""); // store email input
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState(null); // optional success/error message

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email.trim()) {
      // alert("Please enter your email");
      return;
    }
    setIsPopupOpen(true);
  };

  const handleSendEmail = async () => {
  setIsPopupOpen(false);
  setIsLoading(true);

  try {
    const response = await axios.put(
      `${API.domain}${API.userManagement.forgotPassword}`,
      { email },
      { headers: { "Content-Type": "application/json" } }
    );

    if (response.data.status) {
      setMessage({
        title: "success",
       description: `Password reset email sent to ${email}.`,
      });
    } else {
      setMessage({
        type: "error",
        text: response.data.message || "Failed to send reset email",
      });
    }
  } catch (error) {
    console.error("Forgot password error:", error);

    // Show backend error message if available
    const msg =
      error.response?.data?.message ||
      "Something went wrong while sending password reset email.";
    setMessage({ type: "error", text: msg });
  } finally {
    setIsLoading(false);
  }
};


  return (
    <div className="min-h-screen flex flex-col lg:flex-row overflow-hidden">
      {/* Left Side Image */}
      <div className="hidden lg:block lg:w-1/2">
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvologin 2.png"
          alt="Truck"
          className="w-full h-screen object-cover"
        />
      </div>

      {/* Right Side Form */}
      <div className="w-full lg:w-1/2 h-screen flex flex-col justify-center px-6 bg-white">
        {/* Logo */}
        <div className="flex justify-center mb-10 mt-[-50px]">
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/volvo-spread-word-mark1214[1].jpg"
            alt="Volvo"
            className="w-40 h-auto"
          />
        </div>

        <div className="max-w-sm w-full px-6 mx-auto">
          <h2 className="text-4xl font-bold mb-6 font-VolvoNovum">Forgot Password?</h2>
         
          <form onSubmit={handleSubmit} className="space-y-5">
            <input
              type="email"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border-0 border-b-2 border-black/60 py-1.5 text-sm text-black placeholder:text-black/70 font-VolvoNovum focus:outline-none focus:border-black"
            />

            <button
              type="submit"
              className="w-full bg-darkblue1 text-white  py-1.5 text-sm font-medium hover:bg-opacity-90 transition flex items-center justify-center gap-2"
              disabled={isLoading}
            >
              <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/Vector (1).png" alt="Send Icon" className="w-3 h-3" />
              <span>{isLoading ? "Sending..." : "Send"}</span>
            </button>

            <p className="text-xs text-grey font-medium text-center">
              Go back to Login?{' '}
              <a
                href="/"
                className="text-darkblue1 font-medium underline hover:scale-110 transition-transform inline-block"
              >
                Click here
              </a>
            </p>
          </form>

          {message && (
            <p
              className={`mt-4 text-sm text-center ${
                message.type === "success" ? "text-green-600" : "text-red1"
              }`}
            >
              {message.text}
            </p>
          )}
        </div>
      </div>
<ForgotPasswordEmailPreview
  isOpen={isPopupOpen}
  onClose={() => setIsPopupOpen(false)}
  onSend={handleSendEmail}
  email={email}  // <-- Add this
  isLoading={isLoading}
/>
 {message?.title === "success" && (
  <SuccessMessage
    message={message}
    onClose={() => setMessage(null)}
  />
)}

{/* ❌ Show text message only for errors */}
{message?.type === "error" && (
  <p className="mt-4 text-center text-red1">{}</p>
)}
    </div>
  );
};

export default ForgotPassword;
