import React, { useState, useEffect } from "react";

const CancelmeetingModal = ({ isOpen, onClose, meetingData, onConfirm, isLoading = false }) => {
  const [reason, setReason] = useState("");
  const [reasonError, setReasonError] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setReason("");
      setReasonError(false);
    }
  }, [isOpen]);
 const handleCancelMeeting = () => {
    if (!reason.trim()) {
      setReasonError(true);
      return;
    }

    if (onConfirm) {
      onConfirm(reason);
    } else {
      console.error("onConfirm callback is not provided");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
      <div className="bg-white  p-8 shadow-xl w-[90%] max-w-[600px] relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-4 text-red-600 hover:scale-110"
        >
          <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>

        </button>

        {/* Title */}
        <div className="text-center mb-6">
          <h2 className="text-base font-semibold text-MediumGrey">Cancel Meeting</h2>
        </div>

        {/* Form Fields */}
        <div className="space-y-2">
          <div>
            <label className="block text-xs font-medium text-black/60 mb-1">
              Cancellation Reason <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => {
                setReason(e.target.value);
                setReasonError(false);
              }}
              placeholder="Enter the reason"
              className={`w-full border border-black/30 px-3 py-1.5   focus:outline-none focus:ring-1 focus:ring-black/30 text-xs ${
                reasonError ? "border-red1" : "border-gray-300"
              }`}
            />
            {reasonError && (
              <p className="text-red1 text-xs mt-1">Please enter a reason.</p>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 mt-6">
          <button
            onClick={handleCancelMeeting}
            disabled={isLoading}
            className="px-4 py-1.5 text-xs   bg-red2 text-red1  font-medium hover:border hover:border-red1 hover:bg-white disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? "Cancelling..." : "Cancel Meeting"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CancelmeetingModal;
