import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { API } from "../../../api";
import Header from "../../../Components/Header";
import { useNavigate, useLocation } from "react-router-dom";
import Filter from "../../../Components/Filter";
import SubNavbar3 from "../../../Components/SubNavbar3";
import Searchinput from "../../../Components/Searchinput";
import { ArrowLeft, Plus, MoreVertical, Frown } from "lucide-react";
import { ChevronUp, ChevronDown, ChevronsUpDown } from "lucide-react";
import { ArrowUp, ArrowDown } from "lucide-react";
import LogActionitemPopup from "./LogActionitemPopup";
import DeleteModal from "../../../Components/DeleteModal";
import ExpandableTargetDate from "../../../Components/Expandabletargetdate";
import {
  getAllActionItems,
  deleteActionItem,
} from "../../../services/monthlyMeeting/actionItem/actionItem.service";

// ═══════════════════════════════════════════════════════════════
// DATE FORMATTING HELPERS
// ═══════════════════════════════════════════════════════════════
const formatDateForDisplay = (dateString) => {
  if (!dateString || dateString === "-" || dateString === "N/A" || dateString === "null" || dateString === null)
    return "-";
  try {
    if (dateString.includes("/")) return dateString;
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "-";
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  } catch {
    return "-";
  }
};

// ═══════════════════════════════════════════════════════════════
// EXPANDABLE TEXT COMPONENT
// ═══════════════════════════════════════════════════════════════
const ExpandableText = ({ text, maxLines = 2 }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [needsExpansion, setNeedsExpansion] = useState(false);
  const textRef = useRef(null);

  useEffect(() => {
    if (textRef.current) {
      const lineHeight =
        parseInt(window.getComputedStyle(textRef.current).lineHeight) || 16;
      const maxHeight = lineHeight * maxLines;
      setNeedsExpansion(textRef.current.scrollHeight > maxHeight + 5);
    }
  }, [text, maxLines]);

  if (!text || text === "N/A" || text === "-")
    return <span className="text-gray-400">-</span>;

  return (
    <div className="relative">
      <div
        ref={textRef}
        className="whitespace-pre-wrap break-words transition-all duration-200"
        style={
          !isExpanded && needsExpansion
            ? {
                display: "-webkit-box",
                WebkitLineClamp: maxLines,
                WebkitBoxOrient: "vertical",
                overflow: "hidden",
              }
            : {}
        }
      >
        {text}
      </div>
      {needsExpansion && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setIsExpanded(!isExpanded);
          }}
          className="text-blue-600 hover:text-blue-800 text-[10px] font-medium mt-0.5 hover:underline"
        >
          {isExpanded ? "Show less" : "Show more"}
        </button>
      )}
    </div>
  );
};

function ActionItemView() {
  const location = useLocation();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [tableData, setTableData] = useState([]);
  const [isLogOpen, setIsLogOpen] = useState(false);
  const [currentLog, setCurrentLog] = useState(null);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [rowToDelete, setRowToDelete] = useState(null);
  const [loadingDelete, setLoadingDelete] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null);
  const [hoveredCell, setHoveredCell] = useState(null);
  const [filter, setFilter] = useState({ status: "", department: "" });
  const [dropdownId, setDropdownId] = useState(null);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0 });

  const { meeting } = location.state || {};
  const year = meeting?.year || "N/A";
  const dealerName = meeting?.dealer || "";
  const tableContainerRef = useRef(null);

  // ═══════════════════════════════════════════════════════════════
  // CURRENT USER & ROLE DETECTION
  // ═══════════════════════════════════════════════════════════════
  const [currentUserId, setCurrentUserId] = useState(null);
  const [currentUserRole, setCurrentUserRole] = useState(null);

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const userData = localStorage.getItem("userData");
        if (userData) {
          const parsed = JSON.parse(userData);
          if (parsed?.id) setCurrentUserId(parsed.id);
          // Check persona first (SubNavbar3 uses userData.persona for role checks)
          if (parsed?.persona) setCurrentUserRole(parsed.persona?.toLowerCase());
          else if (parsed?.role) setCurrentUserRole(parsed.role?.toLowerCase());
          else if (parsed?.userRole) setCurrentUserRole(parsed.userRole?.toLowerCase());
          else if (parsed?.user_role) setCurrentUserRole(parsed.user_role?.toLowerCase());
          return;
        }

        const token =
          localStorage.getItem("userToken") ||
          localStorage.getItem("superUserToken");
        if (!token) return;

        if (localStorage.getItem("superUserToken")) {
          setCurrentUserRole("admin");
        }

        const response = await fetch(
          `${API.domain}${API.userManagement.logedInUser}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const result = await response.json();
        if (result?.data?.id) setCurrentUserId(result.data.id);
        if (result?.data?.persona) setCurrentUserRole(result.data.persona?.toLowerCase());
        else if (result?.data?.role) setCurrentUserRole(result.data.role?.toLowerCase());
      } catch (err) {
        console.warn("Failed to fetch current user:", err);
      }
    };
    fetchCurrentUser();
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // PERMISSION HELPERS
  // ═══════════════════════════════════════════════════════════════

  const isAdmin = useCallback(() => {
    // Only check role/persona - do NOT use superUserToken here
    // superUserToken just means the session was initiated by admin, not that the current user IS admin
    return (
      currentUserRole === "admin" ||
      currentUserRole === "administrator" ||
      currentUserRole === "superadmin" ||
      currentUserRole === "super_admin"
    );
  }, [currentUserRole]);

  const isCreator = useCallback(
    (item) => {
      if (!currentUserId) return false;
      const createdById =
        item.createdById ||
        item.originalData?.created_by ||
        item.created_by;
      return (
        currentUserId === createdById ||
        currentUserId === parseInt(createdById, 10)
      );
    },
    [currentUserId]
  );

  const isResponsiblePerson = useCallback(
    (item) => {
      if (!currentUserId) return false;
      const responsibilityId =
        item.responsibilityId ||
        item.originalData?.responsibility ||
        item.responsibility_id;
      return (
        currentUserId === responsibilityId ||
        currentUserId === parseInt(responsibilityId, 10)
      );
    },
    [currentUserId]
  );

  const canViewItem = useCallback(
    (item) => {
      if (isAdmin()) return true;
      if (isCreator(item)) return true;
      if (isResponsiblePerson(item)) return true;
      return false;
    },
    [isAdmin, isCreator, isResponsiblePerson]
  );

  const canFullEdit = useCallback(
    (item) => {
      if (isAdmin()) return true;
      if (isCreator(item)) return true;
      return false;
    },
    [isAdmin, isCreator]
  );

  const canLimitedEdit = useCallback(
    (item) => {
      if (isAdmin()) return false;
      if (isCreator(item)) return false;
      if (isResponsiblePerson(item)) return true;
      return false;
    },
    [isAdmin, isCreator, isResponsiblePerson]
  );

  const canDelete = useCallback(
    (item) => {
      if (isAdmin()) return true;
      return false;
    },
    [isAdmin]
  );

  // ═══════════════════════════════════════════════════════════════
  // MEETING STATUS CHECK
  // ═══════════════════════════════════════════════════════════════
  const meetingStatus = meeting?.status || "";
  const isMeetingCancelled = meetingStatus === "Cancelled";
  const isMeetingCompleted = meetingStatus === "Completed";
  const hideAddButton = isMeetingCancelled || isMeetingCompleted;

  const formatMeetingDate = (dateString) => {
    if (!dateString) return "";
    try {
      const dateObj = new Date(dateString);
      if (isNaN(dateObj.getTime())) return "";
      const day = String(dateObj.getDate()).padStart(2, "0");
      const month = String(dateObj.getMonth() + 1).padStart(2, "0");
      const yr = dateObj.getFullYear();
      return `${day}/${month}/${yr}`;
    } catch {
      return "";
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // FETCH DATA
  // ═══════════════════════════════════════════════════════════════
  const fetchActionItems = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const filters = {
        monthly_meeting_id: meeting?.id,
        ...filter,
      };

      const response = await getAllActionItems(filters);

      if (response.status && response.data) {
        const transformedData = response.data.map((item) => ({
          id: item.id,
          createdDate: formatDateForDisplay(item.created_on),
          createdBy:
            `${item.created_by_name || ""} ${item.created_by_lastname || ""}`.trim() ||
            "N/A",
          createdById: item.created_by,
          department: item.department_name || "N/A",
          departmentId: item.department,
          topicOfDiscussion: item.topic_of_discussion || "N/A",
          responsibility:
            `${item.responsibility_name || ""} ${item.responsibility_lastname || ""}`.trim() ||
            "N/A",
          responsibilityId: item.responsibility,
          targetDate: formatDateForDisplay(item.target_date),
          completedDate: formatDateForDisplay(item.completed_date),
          closureAction: item.closure_action || "N/A",
          status: item.status || "N/A",
          comments: item.comments || "",
          targetDateChange: item.target_date_change || false,
          originalData: item,
        }));

        setTableData(transformedData);
      } else {
        setTableData([]);
      }
    } catch (err) {
      console.error("Error fetching action items:", err);
      setError(err.message || "Failed to fetch action items");
      setTableData([]);
    } finally {
      setLoading(false);
    }
  }, [meeting?.id, filter]);

  useEffect(() => {
    if (meeting?.id) {
      fetchActionItems();
    }
  }, [meeting?.id, fetchActionItems]);

  useEffect(() => {
    if (meeting?.id) {
      fetchActionItems();
    }
  }, [filter, fetchActionItems]);

  useEffect(() => {
    if (location.state?.newItem || location.state?.updatedItem) {
      fetchActionItems();
      navigate(location.pathname, {
        replace: true,
        state: { meeting },
      });
    }
  }, [location.state?.newItem, location.state?.updatedItem]);

  // ═══════════════════════════════════════════════════════════════
  // DROPDOWN HANDLING
  // ═══════════════════════════════════════════════════════════════
  const handleDropdownToggle = (id, event) => {
    if (dropdownId === id) {
      setDropdownId(null);
    } else {
      const button = event.currentTarget;
      const rect = button.getBoundingClientRect();
      const dropdownHeight = 120;
      const spaceBelow = window.innerHeight - rect.bottom;

      const top = spaceBelow < dropdownHeight
        ? rect.top + window.scrollY - dropdownHeight
        : rect.bottom + window.scrollY + 4;

      setDropdownPosition({
        top,
        left: rect.right - 144 + window.scrollX,
      });
      setDropdownId(id);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (event.target.closest(".dropdown-trigger")) return;
      if (event.target.closest(".dropdown-menu")) return;
      setDropdownId(null);
    };
    if (dropdownId !== null) {
      document.addEventListener("click", handleClickOutside);
      return () => document.removeEventListener("click", handleClickOutside);
    }
  }, [dropdownId]);

  useEffect(() => {
    const handleScroll = () => setDropdownId(null);
    window.addEventListener("scroll", handleScroll, true);
    return () => window.removeEventListener("scroll", handleScroll, true);
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // FILTER & SORT
  // ═══════════════════════════════════════════════════════════════
  const handleFilterChange = (name, value) => {
    setFilter((prev) => ({ ...prev, [name]: value }));
  };

  const handleBack = () => navigate(-1);

  const visibleData = useMemo(() => {
    return tableData.filter((item) => canViewItem(item));
  }, [tableData, canViewItem]);

  // ═══════════════════════════════════════════════════════════════
  // FILTER OPTIONS DERIVED FROM TABLE DATA
  // Department: all unique departments from visible data
  // Status: all unique statuses from visible data
  // ═══════════════════════════════════════════════════════════════
  const departmentOptions = useMemo(() => {
    const depts = [...new Set(
      visibleData
        .map((item) => (item.department || "").toString())
        .filter((v) => v && v !== "N/A")
    )];
    return depts.sort((a, b) => a.localeCompare(b));
  }, [visibleData]);

  const statusOptions = useMemo(() => {
    const statuses = [...new Set(
      visibleData
        .map((item) => (item.status || "").toString())
        .filter((v) => v && v !== "N/A")
    )];
    // Custom sort: Open first, In Progress, then Closed
    const order = { "Open": 1, "In Progress": 2, "Closed": 3 };
    return statuses.sort((a, b) => (order[a] || 99) - (order[b] || 99));
  }, [visibleData]);

  const filteredItems = useMemo(() => {
    return visibleData.filter((item) => {
      const matchesSearch = Object.values(item).some((value) => {
        if (value === null || value === undefined || typeof value === "object")
          return false;
        return value.toString().toLowerCase().includes(searchQuery.toLowerCase());
      });
      const matchesStatus =
        !filter.status ||
        item.status?.toLowerCase() === filter.status.toLowerCase();
      const matchesDept =
        !filter.department ||
        item.department?.toLowerCase() === filter.department.toLowerCase();
      return matchesSearch && matchesStatus && matchesDept;
    });
  }, [visibleData, searchQuery, filter]);

  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc");
      } else if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
      } else {
        setSortOrder("asc");
      }
    } else {
      setSortKey(key);
      setSortOrder("asc");
    }
  };

  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredItems;
    return [...filteredItems].sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];
      if (valA == null) return 1;
      if (valB == null) return -1;
      if (!isNaN(valA) && !isNaN(valB)) {
        return sortOrder === "asc" ? valA - valB : valB - valA;
      }
      const strA = valA ? valA.toString().toLowerCase() : "";
      const strB = valB ? valB.toString().toLowerCase() : "";
      if (strA < strB) return sortOrder === "asc" ? -1 : 1;
      if (strA > strB) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [filteredItems, sortKey, sortOrder]);

  // ═══════════════════════════════════════════════════════════════
  // ACTIONS
  // ═══════════════════════════════════════════════════════════════
  const handleConfirmDelete = async () => {
    if (!rowToDelete) return;
    setLoadingDelete(true);
    try {
      await deleteActionItem(rowToDelete.id);
      setTableData((prev) => prev.filter((item) => item.id !== rowToDelete.id));
      setIsDeleteOpen(false);
      setRowToDelete(null);
    } catch (error) {
    } finally {
      setLoadingDelete(false);
    }
  };

  const getEditAction = (row) => {
    if (row.status === "Closed" && !isAdmin()) {
      return { label: "View", type: "view" };
    }
    if (row.status === "Closed" && isAdmin()) {
      return { label: "Edit", type: "full_edit" };
    }
    if (canLimitedEdit(row)) {
      return { label: "Update", type: "limited_edit" };
    }
    if (canFullEdit(row)) {
      return { label: "Edit", type: "full_edit" };
    }
    return { label: "View", type: "view" };
  };

  // ═══════════════════════════════════════════════════════════════
  // SCROLL STATES
  // ═══════════════════════════════════════════════════════════════
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollDirection, setScrollDirection] = useState(null);
  const [lastScrollTop, setLastScrollTop] = useState(0);

  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    if (scrollTop > lastScrollTop) setScrollDirection("down");
    else if (scrollTop < lastScrollTop) setScrollDirection("up");
    setLastScrollTop(scrollTop);

    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth",
      });
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // STATUS COLOR HELPERS
  // ═══════════════════════════════════════════════════════════════
  const getStatusColor = (status) => {
    switch (status) {
      case "Open":
        return "text-mildBlue";
      case "Closed":
      case "Completed":
        return "text-green6";
      case "In Progress":
      case "OnGoing":
        return "text-burntorange1";
      default:
        return "text-gray-500";
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // TABLE COLUMNS
  // ═══════════════════════════════════════════════════════════════
  const columns = [
    { key: "createdDate", label: "Created Date", width: "8%" },
    { key: "createdBy", label: "Created By", width: "9%" },
    { key: "topicOfDiscussion", label: "Topic of Discussion", width: "18%" },
    { key: "department", label: "Department", width: "9%" },
    { key: "responsibility", label: "Responsibility", width: "9%" },
    { key: "targetDate", label: "Target Date", width: "8%" },
    { key: "closedDate", label: "Closed Date", width: "8%" },
    { key: "status", label: "Status", width: "5%" },
    { key: "closureAction", label: "Closure Action", width: "18%" },
  ];

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:p-2">
          {/* Page Header */}
          <h2 className="flex items-center gap-2 text-base font-semibold font-VolvoNovum text-darkblue1 flex-wrap mb-0">
            <ArrowLeft
              onClick={handleBack}
              size={24}
              className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
            />
            {year}{dealerName ? ` — ${dealerName}` : ""} — Monthly Meetings Action Item List
          </h2>
          <hr className="hidden lg:block w-[5%] border-t-4 border-darkblue1 mb-2 ml-9" />

          {/* ═══════════════════════════════════════════════════════════ */}
          {/* FILTERS — Options derived from table data                  */}
          {/* ═══════════════════════════════════════════════════════════ */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 md:gap-12 lg:gap-18 mb-2">
            <div className="flex flex-col sm:flex-row items-center gap-2 w-full sm:w-auto">
              <Searchinput
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search"
                className=""
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3 top-4"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />

              {/* Department — options from table data */}
              <Filter
                name="department"
                value={filter.department}
                options={departmentOptions}
                onChange={handleFilterChange}
                className=""
                placeholder="Department"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
                customWidth=""
              />

              {/* Status — options from table data */}
              <Filter
                name="status"
                value={filter.status}
                options={statusOptions}
                onChange={handleFilterChange}
                className=""
                placeholder="Status"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />

            </div>

            {!hideAddButton && (
              <div className="w-full md:w-full lg:w-full flex justify-end items-center">
                <button
                  onClick={() =>
                    navigate("/addactionitem", {
                      state: { year, meetingId: meeting?.id },
                    })
                  }
                  className="flex items-center gap-2 bg-darkblue1 text-white px-4 py-1.5 text-xs font-medium hover:border hover:border-darkblue1 hover:bg-white hover:text-darkblue1 transition duration-200"
                >
                  <Plus className="w-3 h-3" strokeWidth={3} />
                  Add New
                </button>
              </div>
            )}
          </div>

          {/* Loading State */}
          {loading && (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
              <span className="ml-3 text-gray-600">Loading action items...</span>
            </div>
          )}

          {/* Error State */}
          {error && !loading && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 mb-4">
              <p className="font-semibold">Error loading data</p>
              <p>{error}</p>
              <button
                onClick={fetchActionItems}
                className="mt-2 px-4 py-2 bg-darkblue1 text-white text-sm"
              >
                Retry
              </button>
            </div>
          )}

          {/* Desktop Table */}
          {!loading && !error && (
            <div className="hidden lg:block bg-white shadow-md border border-Dustyblue relative">
              <div
                ref={tableContainerRef}
                className="overflow-y-auto overflow-x-auto scrollbar-hide"
                style={{
                  maxHeight: sortedData.length > 8 ? "calc(100vh - 280px)" : "auto",
                  scrollbarWidth: "none",
                  msOverflowStyle: "none",
                }}
                onScroll={handleTableScroll}
              >
                <style jsx>{`
                  div::-webkit-scrollbar {
                    display: none;
                  }
                `}</style>

                <table className="w-full text-[10px] table-fixed">
                  <thead className="bg-Dustyblue font-medium text-white sticky top-0 z-20">
                    <tr>
                      {columns.map(({ key, label, width }) => (
                        <th
                          key={key}
                          className="px-1 py-1.5 text-[10px] border border-grey2 border-t-0 border-l-0 border-b-0 text-left font-medium cursor-pointer select-none"
                          style={{ width }}
                          onClick={() => handleSort(key)}
                        >
                          <div className="flex items-center gap-1">
                            {label}
                            {sortKey === key && sortOrder === "asc" && (
                              <ChevronUp className="w-3 h-3 text-white" />
                            )}
                            {sortKey === key && sortOrder === "desc" && (
                              <ChevronDown className="w-3 h-3 text-white" />
                            )}
                            {sortKey !== key && key === "createdDate" && (
                              <ChevronsUpDown className="w-3 h-3 text-white" />
                            )}
                          </div>
                        </th>
                      ))}
                      <th className="px-1 py-1.5 text-[10px] border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 w-[5%] text-center font-medium">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody className="relative z-0">
                    {sortedData.length > 0 ? (
                      sortedData.map((row, index) => (
                        <tr
                          key={row.id || index}
                          className="hover:bg-lightBlue/50 transition text-[10px] font-normal align-top"
                        >
                          {/* Created Date */}
                          <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 text-xs whitespace-nowrap">
                            {row.createdDate || "-"}
                          </td>

                          {/* Created By */}
                          <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate cursor-pointer"
                                onMouseEnter={() =>
                                  row.createdBy &&
                                  row.createdBy.length > 14 &&
                                  setHoveredCell(`${row.id}-createdBy`)
                                }
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {row.createdBy || "-"}
                              </p>
                              {hoveredCell === `${row.id}-createdBy` && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {row.createdBy}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Topic of Discussion */}
                          <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate cursor-pointer"
                                onMouseEnter={() =>
                                  row.topicOfDiscussion &&
                                  row.topicOfDiscussion.length > 18 &&
                                  setHoveredCell(`${row.id}-topic`)
                                }
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {row.topicOfDiscussion || "-"}
                              </p>
                              {hoveredCell === `${row.id}-topic` && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {row.topicOfDiscussion}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Department */}
                          <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate cursor-pointer"
                                onMouseEnter={() =>
                                  row.department &&
                                  row.department.length > 14 &&
                                  setHoveredCell(`${row.id}-department`)
                                }
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {row.department || "-"}
                              </p>
                              {hoveredCell === `${row.id}-department` && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {row.department}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Responsibility */}
                          <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate cursor-pointer"
                                onMouseEnter={() =>
                                  row.responsibility &&
                                  row.responsibility.length > 14 &&
                                  setHoveredCell(`${row.id}-responsibility`)
                                }
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {row.responsibility || "-"}
                              </p>
                              {hoveredCell === `${row.id}-responsibility` && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {row.responsibility}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* TARGET DATE — EXPANDABLE */}
                          <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 text-xs">
                            <ExpandableTargetDate
                              currentDate={row.targetDate || "-"}
                              actionItemId={row.id}
                            />
                          </td>

                          {/* Completed Date */}
                          <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 text-xs whitespace-nowrap">
                            {row.completedDate || "-"}
                          </td>

                          {/* Status */}
                          <td
                            className={`px-1 py-1.5 font-semibold border border-grey2 border-t-0 border-l-0 text-left ${getStatusColor(
                              row.status
                            )}`}
                          >
                            {row.status || "-"}
                          </td>

                          {/* Closure Action */}
                          <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate cursor-pointer"
                                onMouseEnter={() =>
                                  row.closureAction &&
                                  row.closureAction.length > 18 &&
                                  setHoveredCell(`${row.id}-closure`)
                                }
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {row.closureAction || "-"}
                              </p>
                              {hoveredCell === `${row.id}-closure` && (
                                <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                                  {row.closureAction}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Actions */}
                          <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 border-r-0 align-middle">
                            <div className="flex items-center justify-center">
                              <button
                                type="button"
                                className="dropdown-trigger w-5 h-5 flex items-center justify-center hover:bg-white hover:border-gray-400 transition-all duration-200 cursor-pointer"
                                onClick={(e) => handleDropdownToggle(row.id, e)}
                              >
                                <MoreVertical size={14} className="text-gray-600" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          colSpan={10}
                          className="text-center py-8 text-gray-500"
                        >
                          <Frown size={24} className="mx-auto mb-2" />
                          No records found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Scroll buttons */}
              {showScrollButtons && (
                <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
                  {scrollDirection === "down" && (
                    <button
                      onClick={scrollToTop}
                      className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                      aria-label="Scroll to top"
                    >
                      <ArrowUp className="w-2 h-2" />
                    </button>
                  )}
                  {scrollDirection === "up" && (
                    <button
                      onClick={scrollToBottom}
                      className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                      aria-label="Scroll to bottom"
                    >
                      <ArrowDown className="w-2 h-2" />
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Mobile View */}
          {!loading && !error && (
            <div className="lg:hidden flex flex-col gap-4">
              {sortedData.length > 0 ? (
                sortedData.map((row, index) => (
                  <div
                    key={row.id || index}
                    className="bg-white shadow-md border border-Dustyblue p-4"
                  >
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <span className="font-semibold text-gray-600">
                            Created Date:
                          </span>
                          <br />
                          {row.createdDate}
                        </div>
                        <div>
                          <span className="font-semibold text-gray-600">
                            Created By:
                          </span>
                          <br />
                          {row.createdBy}
                        </div>
                        <div>
                          <span className="font-semibold text-gray-600">
                            Department:
                          </span>
                          <br />
                          {row.department}
                        </div>
                        <div>
                          <span className="font-semibold text-gray-600">
                            Status:
                          </span>
                          <br />
                          <span className={`font-semibold ${getStatusColor(row.status)}`}>
                            {row.status}
                          </span>
                        </div>
                      </div>
                      <div className="border-t pt-2">
                        <div className="text-sm space-y-1">
                          <div>
                            <span className="font-semibold text-gray-600">
                              Topic:
                            </span>
                            <br />
                            {row.topicOfDiscussion}
                          </div>
                          <div>
                            <span className="font-semibold text-gray-600">
                              Responsibility:
                            </span>
                            <br />
                            {row.responsibility}
                          </div>
                          <div>
                            <span className="font-semibold text-gray-600">
                              Closure Action:
                            </span>
                            <br />
                            {row.closureAction}
                          </div>
                        </div>
                      </div>
                      <div className="border-t pt-2">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <span className="font-semibold text-gray-600">
                              Target Date:
                            </span>
                            <br />
                            <ExpandableTargetDate
                              currentDate={row.targetDate || "-"}
                              actionItemId={row.id}
                            />
                          </div>
                          <div>
                            <span className="font-semibold text-gray-600">
                              Closed Date:
                            </span>
                            <br />
                            {row.completedDate}
                          </div>
                        </div>
                      </div>
                      {row.comments && (
                        <div className="border-t pt-2">
                          <div className="text-sm">
                            <span className="font-semibold text-gray-600">
                              Comments:
                            </span>
                            <br />
                            {row.comments}
                          </div>
                        </div>
                      )}

                      {/* Mobile Action Buttons - Role-based */}
                      <div className="border-t pt-2 flex gap-2">
                        <button
                          className={`flex-1 px-3 py-2 text-sm font-medium transition-colors ${
                            getEditAction(row).type === "view"
                              ? "bg-blue-100 text-blue-700 hover:bg-blue-200"
                              : getEditAction(row).type === "limited_edit"
                              ? "bg-amber-100 text-amber-700 hover:bg-amber-200"
                              : "bg-green-100 text-green-700 hover:bg-green-200"
                          }`}
                          onClick={() =>
                            navigate("/editactionitem", {
                              state: {
                                rowData: row,
                                meetingData: meeting,
                                editType: getEditAction(row).type,
                              },
                            })
                          }
                        >
                          {getEditAction(row).label}
                        </button>

                        <button
                          className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 text-sm font-medium hover:bg-gray-200 transition-colors"
                          onClick={() => {
                            setCurrentLog(row);
                            setIsLogOpen(true);
                          }}
                        >
                          Logs
                        </button>

                        {canDelete(row) && (
                          <button
                            className="flex-1 px-3 py-2 bg-red-100 text-red-700 text-sm font-medium hover:bg-red-200 transition-colors"
                            onClick={() => {
                              setRowToDelete(row);
                              setIsDeleteOpen(true);
                            }}
                          >
                            Delete
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <Frown size={24} className="mx-auto mb-2 text-gray-400" />
                  <p className="text-gray-500 italic">No records found</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* DROPDOWN MENU PORTAL - Role-Based Actions */}
      {dropdownId !== null && (
        <div
          className="dropdown-menu fixed w-36 bg-white border border-gray-200 rounded-md shadow-xl z-[9999] overflow-hidden"
          style={{
            top: `${dropdownPosition.top}px`,
            left: `${dropdownPosition.left}px`,
          }}
        >
          <div className="py-1">
            {(() => {
              const row = sortedData.find((item) => item.id === dropdownId);
              if (!row) return null;
              const action = getEditAction(row);
              return (
                <button
                  type="button"
                  onClick={() => {
                    navigate("/editactionitem", {
                      state: {
                        rowData: row,
                        meetingData: meeting,
                        editType: action.type,
                      },
                    });
                    setDropdownId(null);
                  }}
                  className={`w-full px-3 py-2 text-left text-xs flex items-center gap-2 transition-colors duration-150 ${
                    action.type === "view"
                      ? "text-blue-700 hover:bg-blue-50"
                      : action.type === "limited_edit"
                      ? "text-amber-700 hover:bg-amber-50"
                      : "text-gray-700 hover:bg-green-50 hover:text-green-700"
                  }`}
                >
                  {action.type === "view" ? (
                    <>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24">
                        <path d="M12 5C6 5 2 12 2 12s4 7 10 7 10-7 10-7-4-7-10-7Z" stroke="#1B365D" strokeWidth="1.5" />
                        <circle cx="12" cy="12" r="3" stroke="#1B365D" strokeWidth="1.5" />
                      </svg>
                      View
                    </>
                  ) : action.type === "limited_edit" ? (
                    <>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M18.988 2.012L21.988 5.012L19.701 7.3L16.701 4.3L18.988 2.012ZM8 16H11L18.287 8.713L15.287 5.713L8 13V16Z" fill="#D97706" />
                      </svg>
                      Update
                    </>
                  ) : (
                    <>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M18.988 2.012L21.988 5.012L19.701 7.3L16.701 4.3L18.988 2.012ZM8 16H11L18.287 8.713L15.287 5.713L8 13V16Z" fill="#66B3A6" />
                      </svg>
                      {action.label}
                    </>
                  )}
                </button>
              );
            })()}

            <button
              type="button"
              onClick={() => {
                const row = sortedData.find((item) => item.id === dropdownId);
                if (row) {
                  setCurrentLog(row);
                  setIsLogOpen(true);
                }
                setDropdownId(null);
              }}
              className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2 transition-colors duration-150"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="16" viewBox="0 0 16 16" fill="none">
                <g clipPath="url(#clip0_log)">
                  <path d="M13.9993 1.83366H12.666C12.6218 1.83366 12.5794 1.8161 12.5482 1.78484C12.5169 1.75359 12.4993 1.71119 12.4993 1.66699V0.833659C12.4993 0.656848 12.4291 0.487279 12.3041 0.362254C12.1791 0.23723 12.0095 0.166992 11.8327 0.166992C11.6559 0.166992 11.4863 0.23723 11.3613 0.362254C11.2363 0.487279 11.166 0.656848 11.166 0.833659V3.60699C11.166 3.7838 11.2363 3.95337 11.3613 4.0784C11.4863 4.20342 11.6559 4.27366 11.8327 4.27366C12.0095 4.27366 12.1791 4.20342 12.3041 4.0784C12.4291 3.95337 12.4993 3.7838 12.4993 3.60699V3.33366C12.4993 3.28946 12.5169 3.24706 12.5482 3.21581C12.5794 3.18455 12.6218 3.16699 12.666 3.16699H13.666C13.7544 3.16699 13.8392 3.20211 13.9017 3.26462C13.9642 3.32714 13.9993 3.41192 13.9993 3.50033V10.5003C13.9993 10.5887 13.9642 10.6735 13.9017 10.736C13.8392 10.7985 13.7544 10.8337 13.666 10.8337H11.666C11.3124 10.8337 10.9733 10.9741 10.7232 11.2242C10.4732 11.4742 10.3327 11.8134 10.3327 12.167V14.167C10.3327 14.2554 10.2976 14.3402 10.2351 14.4027C10.1725 14.4652 10.0878 14.5003 9.99935 14.5003H2.33268C2.24428 14.5003 2.15949 14.4652 2.09698 14.4027C2.03447 14.3397 1.99935 14.2554 1.99935 14.167V3.50033C1.99935 3.41192 2.03447 3.32714 2.09698 3.26462C2.15949 3.20211 2.24428 3.16699 2.33268 3.16699H2.99935C3.04355 3.16699 3.08594 3.14943 3.1172 3.11818C3.14846 3.08692 3.16602 3.04453 3.16602 3.00033V2.00033C3.16602 1.95612 3.14846 1.91373 3.1172 1.88247C3.08594 1.85122 3.04355 1.83366 2.99935 1.83366H1.99935C1.64573 1.83366 1.30659 1.97413 1.05654 2.22418C0.806491 2.47423 0.666016 2.81337 0.666016 3.16699V14.5003C0.666016 14.8539 0.806491 15.1931 1.05654 15.4431C1.30659 15.6932 1.64573 15.8337 1.99935 15.8337H10.9993C11.0919 15.8343 11.1835 15.8156 11.2685 15.7789C11.3534 15.7422 11.4298 15.6882 11.4927 15.6203L15.1593 11.6203C15.272 11.4964 15.3339 11.3345 15.3327 11.167V3.16699C15.3327 2.81337 15.1922 2.47423 14.9422 2.22418C14.6921 1.97413 14.353 1.83366 13.9993 1.83366Z" fill="#1B365D" />
                </g>
                <defs>
                  <clipPath id="clip0_log">
                    <rect width="16" height="16" fill="white" />
                  </clipPath>
                </defs>
              </svg>
              Logs
            </button>

            {(() => {
              const row = sortedData.find((item) => item.id === dropdownId);
              if (!row || !canDelete(row)) return null;
              return (
                <button
                  type="button"
                  onClick={() => {
                    if (row) {
                      setRowToDelete(row);
                      setIsDeleteOpen(true);
                    }
                    setDropdownId(null);
                  }}
                  className="w-full px-2 py-2 text-left text-xs text-gray-700 hover:bg-red-50 hover:text-red-700 flex items-center gap-1 transition-colors duration-150"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                    <g clipPath="url(#clip0_del)">
                      <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012" />
                    </g>
                    <defs>
                      <clipPath id="clip0_del">
                        <rect width="24" height="24" fill="white" transform="translate(4 4)" />
                      </clipPath>
                    </defs>
                  </svg>
                  Delete
                </button>
              );
            })()}
          </div>
        </div>
      )}

      {/* Popups */}
      {isLogOpen && currentLog && (
        <LogActionitemPopup
          actionItemId={currentLog?.id}
          logsData={currentLog}
          onClose={() => {
            setIsLogOpen(false);
            setCurrentLog(null);
          }}
        />
      )}

      <DeleteModal
        isOpen={isDeleteOpen}
        onClose={() => {
          setIsDeleteOpen(false);
          setRowToDelete(null);
        }}
        onConfirm={handleConfirmDelete}
        loading={loadingDelete}
      />
    </div>
  );
}

export default ActionItemView;