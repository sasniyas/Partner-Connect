import React, { useState, useRef, useEffect, useCallback } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, Calendar, ChevronDown, ChevronUp } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { API } from "../../../api";
import StyledSelectField from "../../../Components/StyledSelectField";
import { updateActionItem, getActionItemById, getTargetDateHistory, getUsersByMonthlyMeetingDealer } from "../../../services/monthlyMeeting/actionItem/actionItem.service";
import { getDepartments } from "../../../services/monthlyMeetingMaster/departmentMaster.service";
import { getAllUsers } from "../../../services/userManagement/userManagement.service";
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation";
import DateChangeRequest from "../../../Components/DateChangeRequest";
import { useSelector } from "react-redux";

// ═══════════════════════════════════════════════════════════════
// ROLES ALLOWED TO EDIT TARGET DATE (besides Creator)
// ═══════════════════════════════════════════════════════════════
const TARGET_DATE_EDIT_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Dealer CEO",
  "Dealer HR Head",
];

// ═══════════════════════════════════════════════════════════════
// TARGET DATE HISTORY COMPONENT (for Edit Page)
// Auto-fetches on mount — shows if previous dates exist
// ═══════════════════════════════════════════════════════════════
const TargetDateHistorySection = ({ actionItemId, currentDate }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [previousDates, setPreviousDates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [fetched, setFetched] = useState(false);

  const formatDateForHistoryDisplay = (dateString) => {
    if (!dateString || dateString === "-" || dateString === "N/A" || dateString === "null" || dateString === null)
      return "-";
    try {
      if (typeof dateString === "string" && dateString.includes("/")) return dateString;
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return "-";
      const day = String(date.getDate()).padStart(2, "0");
      const month = String(date.getMonth() + 1).padStart(2, "0");
      const year = date.getFullYear();
      return `${day}/${month}/${year}`;
    } catch {
      return "-";
    }
  };

  const fetchHistory = useCallback(async () => {
    if (fetched || !actionItemId) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      const response = await getTargetDateHistory(actionItemId);
      if (response.status && response.data && response.data.length > 0) {
        const currentFormatted = formatDateForHistoryDisplay(currentDate);
        const filteredDates = response.data
          .map((d) => formatDateForHistoryDisplay(d))
          .filter((d) => d !== "-" && d !== currentFormatted);
        const uniqueDates = [...new Set(filteredDates)];
        setPreviousDates(uniqueDates);
      }
    } catch (err) {
      console.warn("Failed to fetch target date history:", err);
    } finally {
      setLoading(false);
      setFetched(true);
    }
  }, [actionItemId, currentDate, fetched]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const handleToggle = () => {
    setIsExpanded(!isExpanded);
  };

  if (fetched && previousDates.length === 0) return null;
  if (loading) return null;

  return (
    <div className="mt-0.5">
      <button
        type="button"
        onClick={handleToggle}
        className="inline-flex items-center justify-center w-3.5 h-3.5 rounded-full bg-amber-100 hover:bg-amber-200 transition-colors cursor-pointer"
        title={isExpanded ? "Hide previous dates" : "Show previous dates"}
      >
        {isExpanded ? (
          <ChevronUp className="w-2.5 h-2.5 text-amber-700" />
        ) : (
          <ChevronDown className="w-2.5 h-2.5 text-amber-700" />
        )}
      </button>

      {isExpanded && (
        <div className="mt-0.5 pt-0.5 border-t border-amber-200">
          <span className="text-[8px] text-gray-400 font-medium">Previous:</span>
          {previousDates.map((date, idx) => (
            <div key={idx} className="text-[10px] text-gray-400 line-through leading-tight">
              {date}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

function EditActionitem({ isOpen, onClose }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { state } = useLocation();
  const row = state?.rowData || {};
  const meetingData = state?.meetingData || {};
  const formRef = useRef(null);

  // ═══════════════════════════════════════════════════════════════
  // GET CURRENT USER PERSONA/ROLE FROM REDUX (same as SubNavbar3)
  // ═══════════════════════════════════════════════════════════════
  const { data: reduxUserData } = useSelector((state) => state.user);
  const effectivePersona = reduxUserData?.persona || "";

  const [data, setData] = useState({
    id: row.id || row.originalData?.id || "",
    monthly_meeting_id: row.originalData?.monthly_meeting_id || "",
    department: "",
    topicOfDiscussion: "",
    responsibility: "",
    targetDate: "",
    completedDate: "",
    closureAction: "",
    status: "",
    comments: "",
    statusChangeDate: "",
    actionProgressUpdate: "",
  });
  const [originalStatus, setOriginalStatus] = useState("");
  const [apiData, setApiData] = useState(null);
  const [originalTargetDate, setOriginalTargetDate] = useState("");
  const [currentUserId, setCurrentUserId] = useState(null);
  // ═══════════════════════════════════════════════════════════════
  // MEETING AGENDA STATE — from navigation state or fetched via API
  // getActionItemById already returns mm.agenda_text from backend
  // ═══════════════════════════════════════════════════════════════
  const [meetingAgenda, setMeetingAgenda] = useState(
    meetingData?.agenda || meetingData?.agenda_text || row.originalData?.agenda_text || ""
  );

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(true);
  const [departments, setDepartments] = useState([]);
  const [departmentsLoading, setDepartmentsLoading] = useState(true);
  const [users, setUsers] = useState([]);
  const [usersLoading, setUsersLoading] = useState(true);
  const isClosed = data.status === "Closed";

  const departmentRef = useRef(null);
  const dealerRef = useRef(null);
  const statusRef = useRef(null);
  const targetRef = useRef(null);
  const completedRef = useRef(null);

  const [isDepartmentOpen, setIsDepartmentOpen] = useState(false);
  const [isResponsibilityOpen, setIsResponsibilityOpen] = useState(false);
  const [isStatusOpen, setIsStatusOpen] = useState(false);
  const [isDateChangeOpen, setIsDateChangeOpen] = useState(false);
  const [isDateChangeOpenpopup, setIsDateChangeOpenpopup] = useState(false);
  const [isResponsibleStatusOpen, setIsResponsibleStatusOpen] = useState(false);
  const responsibleStatusRef = useRef(null);
  const statusOptions = ["Open", "In Progress", "Closed"];

  const formatMeetingDateForDisplay = (dateString) => {
    if (!dateString) return "-";
    try {
      if (dateString.includes("/")) return dateString;
      const dateObj = new Date(dateString);
      if (isNaN(dateObj.getTime())) return "-";
      const day = String(dateObj.getDate()).padStart(2, "0");
      const month = String(dateObj.getMonth() + 1).padStart(2, "0");
      const year = dateObj.getFullYear();
      return `${day}/${month}/${year}`;
    } catch {
      return "-";
    }
  };

  const resolvedMeetingDate = meetingData?.meetingDate || row.meetingDate || row.originalData?.meeting_date || "";
  const resolvedDealer = meetingData?.dealer || row.dealer || row.originalData?.dealer_name || "";

  // ═══════════════════════════════════════════════════════════════
  // LOAD CURRENT USER
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return;
        const userData = localStorage.getItem("userData");
        if (userData) {
          const parsed = JSON.parse(userData);
          if (parsed?.id) { setCurrentUserId(parsed.id); return; }
        }
        const response = await fetch(`${API.domain}${API.userManagement.logedInUser}`, {
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }
        });
        const result = await response.json();
        if (result?.data?.id) setCurrentUserId(result.data.id);
      } catch {}
    };
    fetchCurrentUser();
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // PERMISSION CHECKS
  // ═══════════════════════════════════════════════════════════════
  const isResponsiblePerson = useCallback(() => {
    if (!currentUserId || !apiData?.responsibility) return false;
    return currentUserId === apiData.responsibility || currentUserId === parseInt(apiData.responsibility, 10);
  }, [currentUserId, apiData]);

  const isCreatorOfItem = useCallback(() => {
    if (!currentUserId || !apiData?.created_by) return false;
    return currentUserId === apiData.created_by || currentUserId === parseInt(apiData.created_by, 10);
  }, [currentUserId, apiData]);

  const wasAlreadyClosed = useCallback(() => {
    return apiData?.status === "Closed";
  }, [apiData]);

  const isTargetDateChangeRequested = useCallback(() => {
    return apiData?.target_date_change === 1 || apiData?.target_date_change === true;
  }, [apiData]);

  const canEditTargetDate = useCallback(() => {
    if (isCreatorOfItem()) return true;
    if (TARGET_DATE_EDIT_ROLES.includes(effectivePersona)) return true;
    return false;
  }, [isCreatorOfItem, effectivePersona]);

  const canSeeTargetDateRequest = useCallback(() => {
    return canEditTargetDate();
  }, [canEditTargetDate]);

  const isFieldDisabled = (fieldName) => {
    if (isResponsiblePerson()) {
      if (wasAlreadyClosed()) return true;
      if (fieldName === "status") return false;
      if (fieldName === "actionProgressUpdate") return false;
      if (fieldName === "closureAction" && data.status === "Closed") return false;
      return true;
    }
    if (fieldName === "topicOfDiscussion") return true;
    if (fieldName === "targetDate") return !canEditTargetDate();
    if (dataLoading) return true;
    return false;
  };

  const getPageTitle = () => {
    if (isResponsiblePerson()) return "Update Action Item";
    return "Edit Action Item Details";
  };

  const hasTargetDateChanged = () => {
    return originalTargetDate && data.targetDate && originalTargetDate !== data.targetDate;
  };

  const formatDateForDisplay = (dateString) => {
    if (!dateString || dateString === "-") return "-";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return "-";
      const day = date.getDate().toString().padStart(2, '0');
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const year = date.getFullYear();
      return `${day}-${month}-${year}`;
    } catch { return "-"; }
  };

  const fetchDepartments = async () => {
    try {
      setDepartmentsLoading(true);
      const departmentsData = await getDepartments();
      setDepartments(departmentsData);
    } catch (error) {
      console.error("Error fetching departments:", error);
      setErrors({ departments: "Failed to load departments" });
    } finally {
      setDepartmentsLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      setUsersLoading(true);
      const mId = row.originalData?.monthly_meeting_id || data.monthly_meeting_id;
      if (mId) {
        const response = await getUsersByMonthlyMeetingDealer(mId);
        if (response.status && response.data) {
          const mappedUsers = response.data.map((user) => ({
            id: user.userId,
            firstName: user.firstName,
            lastName: user.lastName,
          }));
          setUsers(mappedUsers);
        } else {
          setUsers([]);
        }
      } else {
        const usersData = await getAllUsers();
        setUsers(usersData);
      }
    } catch (error) {
      console.error("Error fetching users:", error);
      setErrors({ users: "Failed to load users" });
    } finally {
      setUsersLoading(false);
    }
  };

  const fetchActionItem = async () => {
    try {
      setDataLoading(true);

      const formatDateForInput = (dateString) => {
        if (!dateString) return "";
        try {
          const date = new Date(dateString);
          if (isNaN(date.getTime())) return "";
          const year = date.getFullYear();
          const month = String(date.getMonth() + 1).padStart(2, "0");
          const day = String(date.getDate()).padStart(2, "0");
          return `${year}-${month}-${day}`;
        } catch {
          return "";
        }
      };

      if (row.originalData) {
        const item = row.originalData;
        const statusVal = item.status || "";
        setOriginalStatus(statusVal);
        setApiData(item);
        setOriginalTargetDate(formatDateForInput(item.target_date));

        // Set meeting agenda from originalData if available
        if (item.agenda_text && !meetingAgenda) {
          setMeetingAgenda(item.agenda_text);
        }

        setData({
          id: item.id || "",
          monthly_meeting_id: item.monthly_meeting_id || "",
          department: item.department_name || "",
          topicOfDiscussion: item.topic_of_discussion || "",
          responsibility:
            item.responsibility_name && item.responsibility_lastname
              ? `${item.responsibility_name} ${item.responsibility_lastname}`
              : "",
          targetDate: formatDateForInput(item.target_date),
          completedDate: formatDateForInput(item.completed_date),
          closureAction: item.closure_action || "",
          status: statusVal,
          comments: item.comments || "",
          statusChangeDate: "",
          actionProgressUpdate: item.action_progress_update || "",
        });

        // If no agenda_text in originalData, fetch by ID to get it
        // (getActionItemById already returns mm.agenda_text)
        if (!item.agenda_text && !meetingAgenda && item.id) {
          try {
            const response = await getActionItemById(item.id);
            if (response.status && response.data?.agenda_text) {
              setMeetingAgenda(response.data.agenda_text);
            }
          } catch (err) {
            console.warn("Could not fetch agenda_text:", err);
          }
        }

        setDataLoading(false);
        return;
      }

      const actionItemId = row.id || state?.actionItemId;
      if (!actionItemId) {
        console.warn("No action item ID found in state");
        setErrors({ submit: "Action item ID is required" });
        setDataLoading(false);
        return;
      }

      const response = await getActionItemById(actionItemId);
      if (response.status && response.data) {
        const item = response.data;
        const statusVal = item.status || "";
        setOriginalStatus(statusVal);
        setApiData(item);
        setOriginalTargetDate(formatDateForInput(item.target_date));

        // Set meeting agenda from API response (getActionItemById returns mm.agenda_text)
        if (item.agenda_text) {
          setMeetingAgenda(item.agenda_text);
        }

        setData({
          id: item.id || "",
          monthly_meeting_id: item.monthly_meeting_id || "",
          department: item.department_name || "",
          topicOfDiscussion: item.topic_of_discussion || "",
          responsibility:
            item.responsibility_name && item.responsibility_lastname
              ? `${item.responsibility_name} ${item.responsibility_lastname}`
              : "",
          targetDate: formatDateForInput(item.target_date),
          completedDate: formatDateForInput(item.completed_date),
          closureAction: item.closure_action || "",
          status: statusVal,
          comments: item.comments || "",
          statusChangeDate: "",
          actionProgressUpdate: item.action_progress_update || "",
        });
      } else {
        throw new Error(response.message || "Failed to fetch action item");
      }
    } catch (error) {
      console.error("Error fetching action item:", error);
      setErrors({ submit: error.message || "Failed to load action item" });
    } finally {
      setDataLoading(false);
    }
  };

  useEffect(() => {
    fetchDepartments();
    fetchUsers();
    fetchActionItem();
  }, []);

  const handleChange = (key, value) => {
    setData((prev) => ({ ...prev, [key]: value }));
    if (errors[key]) {
      setErrors((prev) => ({ ...prev, [key]: undefined }));
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (departmentRef.current && !departmentRef.current.contains(event.target))
        setIsDepartmentOpen(false);
      if (dealerRef.current && !dealerRef.current.contains(event.target))
        setIsResponsibilityOpen(false);
      if (statusRef.current && !statusRef.current.contains(event.target))
        setIsStatusOpen(false);
      if (responsibleStatusRef.current && !responsibleStatusRef.current.contains(event.target))
        setIsResponsibleStatusOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const openCalendar = (ref) => {
    if (ref.current) ref.current.showPicker?.();
  };

  // ═══════════════════════════════════════════════════════════════
  // SAVE HANDLER
  // ═══════════════════════════════════════════════════════════════
  const handleSave = async () => {
    const newErrors = {};

    if (isResponsiblePerson()) {
      if (!data.actionProgressUpdate || !data.actionProgressUpdate.trim()) {
        newErrors.actionProgressUpdate = "Action Progress Update is required";
      }
      if (!data.status) {
        newErrors.status = "Status is required";
      }
      if (data.status === "Closed" && (!data.closureAction || !data.closureAction.trim())) {
        newErrors.closureAction = "Closure Action is required when status is Closed";
      }
    } else {
      if (!data.department) newErrors.department = "Department is required";
      if (!data.responsibility) newErrors.responsibility = "Responsibility is required";
      if (!data.targetDate) newErrors.targetDate = "Target Date is required";
      if (!data.status) newErrors.status = "Status is required";
      if (data.status === "Closed" && (!data.closureAction || !data.closureAction.trim())) {
        newErrors.closureAction = "Closure Action is required when status is Closed";
      }
    }

    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    setErrors((prev) => ({ ...prev, submit: undefined }));

    if (!data.id) {
      setErrors({ submit: "Action item ID is required" });
      return;
    }

    try {
      setLoading(true);

      let updateData = {};

      if (isResponsiblePerson()) {
        updateData = {
          id: data.id,
          action_progress_update: data.actionProgressUpdate?.trim() || null,
          status: data.status,
        };

        if (data.status === "Closed") {
          updateData.closure_action = data.closureAction?.trim() || null;
          if (!data.completedDate) {
            const today = new Date();
            const yyyy = today.getFullYear();
            const mm = String(today.getMonth() + 1).padStart(2, "0");
            const dd = String(today.getDate()).padStart(2, "0");
            updateData.completed_date = `${yyyy}-${mm}-${dd}`;
          } else {
            updateData.completed_date = data.completedDate;
          }
        }

        if (data.status !== "Closed") {
          updateData.completed_date = null;
        }
      } else {
        if (departmentsLoading || departments.length === 0) {
          setErrors({ submit: "Departments are still loading. Please wait..." });
          setLoading(false);
          return;
        }
        if (usersLoading || users.length === 0) {
          setErrors({ submit: "Users are still loading. Please wait..." });
          setLoading(false);
          return;
        }

        const selectedDepartment = departments.find((dep) => dep.name === data.department);
        if (!selectedDepartment) {
          throw new Error(`Department "${data.department}" not found. Please select a valid department.`);
        }

        const selectedResponsibility = users.find(
          (user) => `${user.firstName} ${user.lastName}`.trim() === data.responsibility
        );
        if (!selectedResponsibility) {
          throw new Error(`Responsibility "${data.responsibility}" not found. Please select a valid user.`);
        }

        let completedDateValue = data.completedDate || null;
        if (data.status === "Closed" && !completedDateValue) {
          const today = new Date();
          const yyyy = today.getFullYear();
          const mm = String(today.getMonth() + 1).padStart(2, "0");
          const dd = String(today.getDate()).padStart(2, "0");
          completedDateValue = `${yyyy}-${mm}-${dd}`;
        }

        updateData = {
          id: data.id,
          monthly_meeting_id: data.monthly_meeting_id || null,
          department: selectedDepartment.id,
          topic_of_discussion: data.topicOfDiscussion,
          closure_action: data.closureAction?.trim() || null,
          responsibility: selectedResponsibility.id,
          target_date: data.targetDate || null,
          completed_date: completedDateValue,
          status: data.status,
          comments: data.comments?.trim() || null,
          action_progress_update: data.actionProgressUpdate?.trim() || null,
        };

        // Auto-clear target_date_change flag when authorized user changes the target date
        if (isTargetDateChangeRequested() && hasTargetDateChanged() && canEditTargetDate()) {
          updateData.target_date_change = false;
        }

        if (data.status !== "Closed") {
          updateData.completed_date = null;
        }
      }

      const response = await updateActionItem(updateData);

      if (response.status) {
        navigate(-1);
      } else {
        throw new Error(response.message || "Failed to update action item");
      }
    } catch (error) {
      console.error("Error updating action item:", error);
      setErrors({ submit: error.message || "Failed to update action item" });
    } finally {
      setLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // TARGET DATE CHANGE REQUEST (Responsible Person)
  // ═══════════════════════════════════════════════════════════════
  const handleTargetDateChangeRequest = async () => {
    if (!data.id) {
      setIsDateChangeOpenpopup(false);
      return;
    }
    try {
      setLoading(true);
      await updateActionItem({ id: data.id, target_date_change: true });
      setIsDateChangeOpenpopup(false);
      navigate(-1);
    } catch (err) {
      setErrors({ submit: err.message || "Failed to send target date change request" });
      setIsDateChangeOpenpopup(false);
    } finally {
      setLoading(false);
    }
  };

  useKeyboardNavigation({
    containerRef: formRef,
    onSubmit: () => { handleSave(); },
    onCancel: () => { navigate(-1); },
  });

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }
    return () => { document.body.style.overflow = "auto"; };
  }, [isOpen]);

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <div className="hidden lg:block">
        <SubNavbar3 />
      </div>

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full transition-all duration-300 ease-in-out">
            <div>
              <div className="flex items-center gap-2">
                <ArrowLeft
                  onClick={() => navigate(-1)}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
                />
                <h1 className="text-base font-semibold text-darkblue1">{getPageTitle()}</h1>
              </div>
              <hr className="hidden lg:block w-[7%] border-t-4 border-darkblue1 mt-1 ml-[34px] mb-4" />
            </div>

            {/* ═══════════════════════════════════════════════════════════════ */}
            {/* MEETING INFO CARD — with Meeting Agenda                       */}
            {/* ═══════════════════════════════════════════════════════════════ */}
            <div className="bg-white shadow-md border border-Dustyblue p-2 mb-2">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs text-gray-600">
                <div>
                  <span className="font-semibold text-darkblue1">Created By:</span>{" "}
                  {row.createdBy || "-"}
                </div>
                <div>
                  <span className="font-semibold text-darkblue1">Created Date:</span>{" "}
                  {row.createdDate || "-"}
                </div>
                <div>
                  <span className="font-semibold text-darkblue1">Meeting Date:</span>{" "}
                  {formatMeetingDateForDisplay(resolvedMeetingDate)}
                </div>
                <div>
                  <span className="font-semibold text-darkblue1">Dealer:</span>{" "}
                  {resolvedDealer || "-"}
                </div>
              </div>

              {/* Meeting Agenda — shown below the info row */}
              {meetingAgenda && (
                <div className="mt-2 pt-2 border-t border-gray-100 text-xs text-gray-600">
                  <span className="font-semibold text-darkblue1">Meeting Agenda:</span>{" "}
                  {meetingAgenda.length > 120 ? meetingAgenda.substring(0, 120) + "..." : meetingAgenda}
                </div>
              )}
            </div>

            {/* Form Card */}
            <div className="bg-white shadow-lg border border-Dustyblue p-6">
              {dataLoading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="flex flex-col items-center gap-4">
                    <div ref={formRef} className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
                    <p className="text-sm text-gray-600">Loading action item...</p>
                  </div>
                </div>
              ) : isResponsiblePerson() ? (
                /* ═══════════════════════════════════════════════════════════════ */
                /* RESPONSIBLE PERSON VIEW                                        */
                /* ═══════════════════════════════════════════════════════════════ */
                <div ref={formRef}>
                  <div className="bg-blue-50 border border-blue-200 p-3 mb-4">
                    <p className="text-blue-700 text-xs mt-1">You can update progress and change status. To change target date, request Admin/Creator.</p>
                  </div>

                  {isTargetDateChangeRequested() && (
                    <div className="bg-amber-50 border border-amber-200 px-4 py-2 mb-4 flex flex-wrap items-center gap-x-2 gap-y-1">
                      <span className="text-amber-800 font-medium text-xs">⏳ Date Change Request Pending</span>
                      <span className="text-amber-600 text-xs">— Waiting for Admin/Creator</span>
                    </div>
                  )}

                  {wasAlreadyClosed() && (
                    <div className="bg-gray-100 border border-gray-300 p-3 mb-4">
                      <p className="text-gray-700 font-medium text-sm">This action item is Closed — No updates allowed</p>
                    </div>
                  )}

                  {/* Read-only fields */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="lg:col-span-2">
                      <label className="block text-xs font-medium text-black/70 mb-2">Topic of Discussion</label>
                      <div className="border w-full text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all focus:ring-black/30 bg-gray-50">{data.topicOfDiscussion || "-"}</div>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-black/70 mb-2">Department</label>
                      <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50">{data.department || "-"}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <label className="block text-xs font-medium text-black/70 mb-2">Responsibility</label>
                      <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50">{data.responsibility || "-"}</div>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-black/70 mb-2">Target Date</label>
                      <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50">{formatDateForDisplay(originalTargetDate)}</div>
                      <TargetDateHistorySection
                        actionItemId={data.id}
                        currentDate={originalTargetDate}
                      />
                    </div>
                    {/* STATUS — EDITABLE for Responsible Person */}
                    <div>
                      {wasAlreadyClosed() ? (
                        <>
                          <label className="block text-xs font-medium text-black/70 mb-2">Status</label>
                          <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50 font-medium text-green-600">{data.status || "-"}</div>
                        </>
                      ) : (
                        <StyledSelectField
                          label="Status"
                          value={data.status}
                          setValue={(val) => handleChange("status", val)}
                          options={statusOptions}
                          dropdownOpen={isResponsibleStatusOpen}
                          setDropdownOpen={setIsResponsibleStatusOpen}
                          dropdownRef={responsibleStatusRef}
                          placeholder="Select Status"
                          required
                          error={errors.status}
                          disabled={false}
                        />
                      )}
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-black/70 mb-2">Completed Date</label>
                      <div className="w-full px-4 py-1.5 text-xs border border-black/20 bg-gray-50">{data.completedDate ? formatDateForDisplay(data.completedDate) : "-"}</div>
                    </div>
                  </div>

                  {/* CLOSURE ACTION — Only shows when status is Closed */}
                  {data.status === "Closed" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">
                          Closure Action <span className="text-red1">*</span>
                          {!wasAlreadyClosed() && (
                            <span className="text-green-600 text-[10px] ml-1">(Editable)</span>
                          )}
                        </label>
                        {!wasAlreadyClosed() ? (
                          <>
                            <textarea
                              value={data.closureAction}
                              onChange={(e) => handleChange("closureAction", e.target.value)}
                              placeholder="Describe the closure action (required when closing)"
                              rows={3}
                              className={`w-full px-4 py-2 text-xs border resize-none ${
                                errors.closureAction
                                  ? "border-red1 focus:border-red1"
                                  : "border-black/30 focus:ring-2 focus:ring-darkblue1 focus:outline-none"
                              }`}
                            />
                            {errors.closureAction && (
                              <p className="text-xs text-red1 mt-1">{errors.closureAction}</p>
                            )}
                          </>
                        ) : (
                          <div className="w-full px-4 py-2 text-xs border border-black/20 bg-gray-50 min-h-[60px] whitespace-pre-wrap">{data.closureAction || "-"}</div>
                        )}
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">Comments</label>
                        <div className="w-full px-4 py-2 text-xs border border-black/20 bg-gray-50 min-h-[60px] whitespace-pre-wrap">{data.comments || "-"}</div>
                      </div>
                    </div>
                  )}

                  {/* Comments shown separately when status is NOT Closed */}
                  {data.status !== "Closed" && (
                    <div className="grid grid-cols-1 gap-4 mb-4">
                      <div>
                        <label className="block text-xs font-medium text-black/70 mb-2">Comments</label>
                        <div className="w-full px-4 py-2 text-xs border border-black/20 bg-gray-50 min-h-[60px] whitespace-pre-wrap">{data.comments || "-"}</div>
                      </div>
                    </div>
                  )}

                  {/* Editable: Action Progress Update */}
                  <div>
                    <label className="block text-xs font-medium text-black/70 mb-2">
                      Action Progress Update {!wasAlreadyClosed() && <span className="text-green-600">(Editable)</span>}
                    </label>
                    <textarea
                      value={data.actionProgressUpdate}
                      onChange={(e) => handleChange("actionProgressUpdate", e.target.value)}
                      placeholder={wasAlreadyClosed() ? "Closed — no updates allowed" : "Enter your progress update here..."}
                      rows={4}
                      disabled={wasAlreadyClosed()}
                      className={`w-full px-4 py-2 text-xs border resize-none ${wasAlreadyClosed() ? "bg-gray-100 cursor-not-allowed border-black/20" : "border-black/30 focus:ring-2 focus:ring-darkblue1 focus:outline-none"}`}
                    />
                    {errors.actionProgressUpdate && (
                      <p className="text-xs text-red1 mt-1">{errors.actionProgressUpdate}</p>
                    )}
                  </div>
                </div>
              ) : (
                /* ═══════════════════════════════════════════════════════════════ */
                /* ADMIN / CREATOR VIEW — No separate banner needed              */
                /* Date Change Status field handles the request display          */
                /* ═══════════════════════════════════════════════════════════════ */
                <div ref={formRef}>
                  {/* Show info if request exists but user cannot edit target date */}
                  {isTargetDateChangeRequested() && !canSeeTargetDateRequest() && (
                    <div className="bg-gray-50 border border-gray-300 p-3 mb-4">
                      <p className="text-gray-700 font-medium text-sm">A target date change has been requested.</p>
                    </div>
                  )}

                  {wasAlreadyClosed() && (
                    <div className="bg-blue-50 border border-blue-200 p-3 mb-4">
                      <p className="text-blue-800 font-medium text-sm">This action item is Closed</p>
                      <p className="text-blue-700 text-xs mt-1">You can change the status to reopen it.</p>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Row 1: Topic of Discussion (span 2) + Department */}
                    <div className="lg:col-span-2">
                      <label className="block text-xs font-medium text-black/70">Topic of Discussion</label>
                      <input type="text" value={data.topicOfDiscussion} readOnly className="border w-full mt-2 text-xs px-3 py-1.5 outline-none focus:ring-1 focus:ring-black/30 transition-all
 bg-gray-100 border-gray-300 text-black cursor-not-allowed" />
                    </div>

                    <StyledSelectField
                      label="Department" placeholder={departmentsLoading || dataLoading ? "Loading..." : "Select Department"}
                      value={data.department} setValue={(val) => handleChange("department", val)}
                      options={departments.map((dep) => dep.name)}
                      dropdownOpen={isDepartmentOpen} setDropdownOpen={setIsDepartmentOpen} dropdownRef={departmentRef}
                      required error={errors.department || errors.departments} disabled={false}
                    />

                    {/* Row 2: Responsibility, Target Date, Date Change Status, Status */}
                    <div className="col-span-1 md:col-span-3 grid grid-cols-1 md:grid-cols-4 gap-4">
                      <StyledSelectField
                        label="Responsibility" value={data.responsibility}
                        setValue={(val) => handleChange("responsibility", val)}
                        options={users
                          .filter((user) => user.id !== currentUserId && user.id !== parseInt(currentUserId, 10))
                          .map((user) => `${user.firstName} ${user.lastName}`.trim())}
                        dropdownOpen={isResponsibilityOpen} setDropdownOpen={setIsResponsibilityOpen} dropdownRef={dealerRef}
                        placeholder="Select Responsibility" required error={errors.responsibility} disabled={false}
                      />

                      {/* TARGET DATE — Only editable by Creator + specific roles */}
                      <div className="relative">
                        <label className="block text-xs font-medium text-gray-700">
                          Target Date
                          {!canEditTargetDate() && (
                            <span className="text-[10px] text-gray-400 ml-1">(Read-only)</span>
                          )}
                        </label>
                        {canEditTargetDate() ? (
                          <>
                            <input ref={targetRef} type="date" value={data.targetDate}
                              onChange={(e) => handleChange("targetDate", e.target.value)}
                              className="border border-black/30 w-full mt-2 text-xs px-3 py-1.5 outline-none focus:ring-1 focus:ring-black/30 transition-all
"
                            />
                            <Calendar size={14} className="absolute right-3 top-10 transform -translate-y-1/2 cursor-pointer text-gray-600" onClick={() => openCalendar(targetRef)} />
                          </>
                        ) : (
                          <div className="w-full px-4 py-1.5 mt-2 text-xs border border-black/20 bg-gray-50 cursor-not-allowed">
                            {formatDateForDisplay(data.targetDate) || "-"}
                          </div>
                        )}
                        {errors.targetDate && <p className="text-xs text-red1 mt-1">{errors.targetDate}</p>}
                        <TargetDateHistorySection
                          actionItemId={data.id}
                          currentDate={originalTargetDate}
                        />
                      </div>

                      {/* Date Change Status — shows request status, no separate banner needed */}
                      {canEditTargetDate() && (
                        <div className="mt-1">
                          <label className="block text-xs font-medium text-MediumGrey mb-1">Date Change Status</label>
                          <div className={`w-full border px-3 py-1.5 text-xs ${hasTargetDateChanged() ? "border-green-500 bg-green-50 text-green-900" : isTargetDateChangeRequested() ? "border-amber-500 bg-amber-50 text-amber-900" : "border-black/30 text-gray-400 italic"}`}>
                            {hasTargetDateChanged()
                              ? `✓ Changed from: ${formatDateForDisplay(originalTargetDate)}`
                              : isTargetDateChangeRequested()
                                ? `⏳ Requested by ${apiData?.responsibility_name ? `${apiData.responsibility_name} ${apiData.responsibility_lastname || ''}`.trim() : "Assigned person"} | Current: ${formatDateForDisplay(originalTargetDate)}`
                                : "No change requested"}
                          </div>
                        </div>
                      )}

                      {/* Status */}
                      <StyledSelectField
                        label="Status" value={data.status} setValue={(val) => handleChange("status", val)}
                        options={wasAlreadyClosed() ? ["Open", "In Progress"] : statusOptions} dropdownOpen={isStatusOpen} setDropdownOpen={setIsStatusOpen} dropdownRef={statusRef}
                        placeholder="Select Status" required error={errors.status} disabled={false}
                      />
                    </div>

                    {/* CLOSURE ACTION — Only shows when status is Closed */}
                    {data.status === "Closed" && (
                      <div className="col-span-1 md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-gray-700">
                            Closure Action <span className="text-red1">*</span>
                          </label>
                          <textarea value={data.closureAction} onChange={(e) => handleChange("closureAction", e.target.value)}
                            className={`w-full border border-black/30 text-xs px-4 py-1.5 resize-none mt-2 ${
                              errors.closureAction ? "border-red1" : ""
                            }`} rows={4}
                            placeholder="Describe the closure action (required)" disabled={false}
                          />
                          {errors.closureAction && <p className="text-xs text-red1 mt-1">{errors.closureAction}</p>}
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-700">Comments</label>
                          <textarea value={data.comments} onChange={(e) => handleChange("comments", e.target.value)}
                            className="w-full border border-black/30 text-xs px-4 py-1.5 resize-none mt-2" rows={4}
                            placeholder="Add any additional comments" disabled={false}
                          />
                        </div>
                      </div>
                    )}

                    {/* Comments shown separately when status is NOT Closed */}
                    {data.status !== "Closed" && (
                      <div className="col-span-1 md:col-span-3">
                        <label className="block text-xs font-medium text-gray-700">Comments</label>
                        <textarea value={data.comments} onChange={(e) => handleChange("comments", e.target.value)}
                          className="border border-black/30 w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 focus:ring-black/30 transition-all
 resize-none" rows={4}
                          placeholder="Add any additional comments" disabled={false}
                        />
                      </div>
                    )}

                    {/* Row 4: Action Progress Update */}
                    <div className="col-span-1 md:col-span-3">
                      <label className="block text-xs font-medium text-gray-700">Action Progress Update</label>
                      <textarea value={data.actionProgressUpdate} onChange={(e) => handleChange("actionProgressUpdate", e.target.value)}
                        rows={4} disabled={false} placeholder="Enter action progress update..."
                        className="border border-black/30 w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 focus:ring-black/30 transition-all
 py-2 mt-2 resize-none "
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Error Display */}
              {errors.submit && (
                <div className="bg-red-50 border border-red-200 p-4 mb-4 mt-4">
                  <p className="text-red-600">{errors.submit}</p>
                </div>
              )}

              {/* Buttons */}
              <div className="flex flex-wrap gap-4 justify-center lg:justify-end mt-10">
                {isResponsiblePerson() && !wasAlreadyClosed() && !isTargetDateChangeRequested() && (
                  <button type="button"
                    onClick={() => { document.activeElement?.blur(); setIsDateChangeOpenpopup(true); }}
                    className="bg-amber-500 text-white text-xs font-medium px-6 py-1.5 hover:bg-amber-600 transition-all"
                  >
                    Request Target Date Change
                  </button>
                )}

                <button type="button"
                  className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs hover:bg-mildBlue1 hover:scale-105"
                  onClick={() => navigate(-1)} disabled={loading}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 18 20" fill="none">
                    <path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" />
                    <path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Cancel
                </button>

                {(!isResponsiblePerson() || !wasAlreadyClosed()) && (
                  <button onClick={handleSave} type="button" disabled={loading || dataLoading}
                    className="bg-darkblue1 text-white text-xs px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <div className="flex items-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        Saving...
                      </div>
                    ) : isResponsiblePerson() ? "Update Progress" : "Save Changes"}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <DateChangeRequest
        isOpen={isDateChangeOpenpopup}
        onCancel={() => setIsDateChangeOpenpopup(false)}
        onConfirm={handleTargetDateChangeRequest}
        message="Your request will be sent to the Creator, Administrator, Head Of Channel Development, Dealer CEO, and Dealer HR Head to update the target date."
      />
    </div>
  );
}

export default EditActionitem;