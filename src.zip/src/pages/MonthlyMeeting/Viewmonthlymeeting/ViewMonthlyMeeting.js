import React, { useState, useEffect } from "react";
import { useRef } from "react";
import Filter from "../../../Components/Filter";
import DeleteModal from "../../../Components/DeleteModal";
import { useNavigate } from "react-router-dom";
import AtenteesPopup from "./AtenteesPopup";
import Searchinput from "../../../Components/Searchinput";
import { getAllMonthlyMeetings, deleteMonthlyMeeting } from "../../../services/monthlyMeeting/monthlyMeeting/monthlyMeeting.service";
import { useMemo } from "react";
import { ChevronUp, ChevronDown, ChevronsUpDown } from "lucide-react";
import { ArrowUp } from "lucide-react";
import { ArrowDown } from "lucide-react";
import { useLocation } from "react-router-dom";
import { MoreVertical } from "lucide-react";
import {
  getAllFiles
} from "../../../services/monthlyMeetingMaster/fileMaster.service";

const ViewMonthlyMeeting = () => {
  const location = useLocation();
  const [filters, setFilters] = useState({
    year: [],
    month: [],
    marketArea: [],
    dealer: [],
    status: [],
  });

  const navigate = useNavigate();
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [attendeesPopupVisible, setAttendeesPopupVisible] = useState(false);
  const [selectedAttendees, setSelectedAttendees] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
 const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
  const [hoveredCell, setHoveredCell] = useState(null);
  const tableContainerRef = useRef(null);
const [dropdownId, setDropdownId] = useState(null);
const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0 });

  // Navigate to create page with meeting data for editing
  const handleEdit = (meeting) => {
    navigate("/monthlymeetinghomepage", {
      state: { meeting }
    });
  };

  // Fetch meetings from API
  const fetchMeetings = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await getAllMonthlyMeetings();

      if (response.status && response.data) {
        const transformedMeetings = response.data.map(meeting => {
          let year = "";
          let meetingDateStr = meeting.meeting_date || null;

          try {
            if (meetingDateStr) {
              const dateObj = new Date(meetingDateStr);
              if (!isNaN(dateObj.getTime())) {
                year = dateObj.getFullYear().toString();
              }
            }
          } catch (error) {
            console.warn("Date parsing error for meeting:", meeting.id, error);
          }

          return {
            id: meeting.id,
            year: year || new Date().getFullYear().toString(),
            createdby: meeting.created_by_name || "Unknown",
            marketArea: meeting.marketarea || "Unknown",
            dealer: meeting.dealer_name || "Unknown",
            meetingDate: meetingDateStr,
            status: meeting.status || "Created",
            attendees: (meeting.dealer_users?.length || 0) + (meeting.volvo_users?.length || 0) + (meeting.external_emails?.length || 0) + (meeting.optional_emails?.length || 0),
            // Store raw arrays from backend
            dealerUser: meeting.dealer_users || [],
            volvoUser: meeting.volvo_users || [],
            externalEmail: meeting.external_emails || [],
            optionalEmail: meeting.optional_emails || [],
            // Backend fields mapped directly
            meeting_mode: meeting.meeting_mode,
            meeting_venue: meeting.meeting_venue,
            meeting_link: meeting.meeting_link,
            meet_link: meeting.meeting_link,
            agenda_text: meeting.agenda_text,
            agenda_file_url: meeting.agenda_file_url || null,
            // FIX 1: Added agenda file name and type for edit mode file display
            agenda_file_name: meeting.agenda_file_name || (meeting.agenda_file_url ? meeting.agenda_file_url.split("/").pop() : null),
            agenda_file_type: meeting.agenda_file_type || null,
            market_area_id: meeting.market_area_id,
            dealer_id: meeting.dealer_id,
            created_by: meeting.created_by,
            start_time: meeting.start_time,
            end_time: meeting.end_time,
            recurring_meeting: meeting.recurring_meeting,
            is_reoccuring: meeting.is_reoccuring,
            next_meeting_date: meeting.next_meeting_date,
            limit_date: meeting.limit_date,
            createdOn: meeting.createdOn,
            cancelled_by: meeting.cancelled_by,
            cancelled_by_name: meeting.cancelled_by_name,
            cancellation_reason: meeting.cancellation_reason,
            cancellation_timestamp: meeting.cancellation_timestamp,
          };
        });

setMeetings([...transformedMeetings].reverse());      } else {
        setError(response.message || "Failed to fetch meetings");
      }
    } catch (error) {
      console.error("Error fetching meetings:", error);
      setError(error.message || "Failed to fetch meetings");
    } finally {
      setIsLoading(false);
    }
  };

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (event.target.closest(".dropdown-trigger")) return;
      if (event.target.closest(".dropdown-menu")) return;
      setDropdownId(null);
    };
    if (dropdownId !== null) {
      document.addEventListener("click", handleClickOutside);
      return () => document.removeEventListener("click", handleClickOutside);
    }
  }, [dropdownId]);

  // Close dropdown on scroll
  useEffect(() => {
    const handleScroll = () => setDropdownId(null);
    window.addEventListener("scroll", handleScroll, true);
    return () => window.removeEventListener("scroll", handleScroll, true);
  }, []);

  // Dropdown toggle with position calculation
  const handleDropdownToggle = (id, event) => {
    if (dropdownId === id) {
      setDropdownId(null);
    } else {
      const button = event.currentTarget;
      const rect = button.getBoundingClientRect();
      const dropdownHeight = 160; // approximate height of 4-item dropdown
      const spaceBelow = window.innerHeight - rect.bottom;

      const top = spaceBelow < dropdownHeight
        ? rect.top + window.scrollY - dropdownHeight
        : rect.bottom + window.scrollY + 4;

      setDropdownPosition({
        top,
        left: rect.right - 176 + window.scrollX, // 176 = w-44 (11rem)
      });
      setDropdownId(id);
    }
  };

  // Refresh meetings when navigating back from edit/create
  useEffect(() => {
    fetchMeetings();
  }, []);

  // Re-fetch if navigated back with a refresh signal
  useEffect(() => {
    if (location.state?.activeTab === "viewmonthlymeeting") {
      fetchMeetings();
    }
  }, [location.state]);

  const handleDelete = async () => {
    if (!itemToDelete) return;

    try {
      setIsLoading(true);
      const response = await deleteMonthlyMeeting(itemToDelete.id);

      if (response.status) {
        setMeetings(prev => prev.filter(meeting => meeting.id !== itemToDelete.id));
        setItemToDelete(null);
        setDeleteModalVisible(false);
      } else {
        setError(response.message || "Failed to delete meeting");
      }
    } catch (error) {
      console.error("Error deleting meeting:", error);
      setError(error.message || "Failed to delete meeting");
    } finally {
      setIsLoading(false);
    }
  };

  const [searchTerm, setSearchTerm] = useState("");
  const [meetings, setMeetings] = useState([]);
  const [showDownloadPopup, setShowDownloadPopup] = useState(false);
  const [masterFiles, setMasterFiles] = useState([]);
  const [isLoadingMasters, setIsLoadingMasters] = useState(false);

  useEffect(() => {
    const fetchMasterFiles = async () => {
      if (!showDownloadPopup) return;
      setIsLoadingMasters(true);
      try {
        const data = await getAllFiles();
        const activeFiles = (data || []).filter(file => file.isActive === true || file.isActive === 1);
        setMasterFiles(activeFiles);
      } catch (error) {
        console.error("Error fetching master files:", error);
        setMasterFiles([]);
      } finally {
        setIsLoadingMasters(false);
      }
    };
    fetchMasterFiles();
  }, [showDownloadPopup]);

  // Filter options derived from meetings data
  const yearOptions = useMemo(() => {
    const years = [...new Set(meetings.map(m => m.year).filter(Boolean))];
    return years.sort();
  }, [meetings]);

  const monthOptions = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const marketAreaOptions = useMemo(() => {
    const areas = [...new Set(meetings.map(m => m.marketArea).filter(a => a && a !== "Unknown"))];
    return areas.sort();
  }, [meetings]);

  const dealerOptions = useMemo(() => {
    let relevantMeetings = meetings;
    if (filters.marketArea.length > 0) {
      relevantMeetings = meetings.filter(m => filters.marketArea.includes(m.marketArea));
    }
    const dealers = [...new Set(relevantMeetings.map(m => m.dealer).filter(d => d && d !== "Unknown"))];
    return dealers.sort();
  }, [meetings, filters.marketArea]);

  const statusOptions = useMemo(() => {
    const statuses = [...new Set(meetings.map(m => m.status).filter(Boolean))];
    return statuses.sort();
  }, [meetings]);

  const handleFilterChange = (name, selectedValues) => {
    setFilters((prev) => {
      const newFilters = { ...prev, [name]: selectedValues };
      if (name === "marketArea") {
        newFilters.dealer = [];
      }
      return newFilters;
    });
  };

  useEffect(() => {
    if (filters.dealer.length > 0) {
      const validDealers = filters.dealer.filter(d => dealerOptions.includes(d));
      if (validDealers.length !== filters.dealer.length) {
        setFilters(prev => ({ ...prev, dealer: validDealers }));
      }
    }
  }, [dealerOptions]);

  const filteredMeetings = meetings.filter((meeting) => {
    let meetingMonth = "";
    try {
      if (meeting.meetingDate) {
        const dateObj = new Date(meeting.meetingDate);
        if (!isNaN(dateObj.getTime())) {
          meetingMonth = dateObj.toLocaleString("default", { month: "long" });
        }
      }
    } catch (error) {
      console.warn("Date filtering error for meeting:", meeting.id, error);
    }

    return (
      (filters.year.length === 0 || filters.year.includes(meeting.year)) &&
      (filters.month.length === 0 || filters.month.includes(meetingMonth)) &&
      (filters.marketArea.length === 0 || filters.marketArea.includes(meeting.marketArea)) &&
      (filters.dealer.length === 0 || filters.dealer.includes(meeting.dealer)) &&
      (filters.status.length === 0 || filters.status.includes(meeting.status)) &&
      (searchTerm === "" ||
        meeting.year?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        meeting.marketArea?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        meeting.dealer?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        meeting.status?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        meeting.start_time?.toLowerCase().includes(searchTerm.toLowerCase())||
          meeting.createdby?.toLowerCase().includes(searchTerm.toLowerCase()) // ✅ added

      )
    );
  });

  const handleDownload = (file) => {
    if (!file?.fileUrl) return;
    window.open(file.fileUrl, "_blank");
  };

  const handletrendchart = () => {
    navigate("/trendchart");
  };

  const handleActionItem = (meeting) => {
    navigate("/actionitemview", {
      state: { meeting },
    });
  };

  // Navigate to view details page with all backend fields
  const handleViewdetails = (meeting) => {
    const enrichedMeeting = {
      id: meeting.id,
      year: meeting.year,
      createdby: meeting.createdby,
      marketArea: meeting.marketArea,
      dealer: meeting.dealer,
      status: meeting.status,
      // Date fields
      dateTime: meeting.meetingDate,
      meetingDate: meeting.meetingDate,
      startTime: meeting.start_time || "",
      endTime: meeting.end_time || "",
      start_time: meeting.start_time || "",
      end_time: meeting.end_time || "",
      // Meeting mode fields
      venue: meeting.meeting_mode || "Physical",
      meeting_mode: meeting.meeting_mode || "Physical",
      location: meeting.meeting_venue || "",
      meeting_venue: meeting.meeting_venue || "",
      link: meeting.meeting_link || "",
      meet_link: meeting.meeting_link || "",
      meeting_link: meeting.meeting_link || "",
      // Agenda
      agenda: meeting.agenda_text || "",
      agenda_text: meeting.agenda_text || "",
      // Recurring fields
      recurringMeeting: meeting.recurring_meeting || "One-time Meeting",
      recurring_meeting: meeting.recurring_meeting || "One-time Meeting",
      is_reoccuring: meeting.is_reoccuring,
      next_meeting_date: meeting.next_meeting_date || "",
      limit_date: meeting.limit_date || "",
      // Users
      dealerUser: meeting.dealerUser || [],
      volvoUser: meeting.volvoUser || [],
      externalEmail: meeting.externalEmail || [],
      optionalEmail: meeting.optionalEmail || [],
      // IDs
      market_area_id: meeting.market_area_id,
      dealer_id: meeting.dealer_id,
      created_by: meeting.created_by,
      // Dates
      createdDate: meeting.createdOn || new Date().toISOString(),
      createdOn: meeting.createdOn,
      // FIX 2: Pass agenda file fields for view details page
      attachment: meeting.agenda_file_url || null,
      agenda_file_url: meeting.agenda_file_url || null,
      agenda_file_name: meeting.agenda_file_name || (meeting.agenda_file_url ? meeting.agenda_file_url.split("/").pop() : null),
      agenda_file_type: meeting.agenda_file_type || null,
      attachmentName: meeting.agenda_file_name || (meeting.agenda_file_url ? meeting.agenda_file_url.split("/").pop() : "Agenda File"),
      attachmentType: meeting.agenda_file_type || (meeting.agenda_file_url ? "application/pdf" : null),
      // Cancellation
      cancelled_by: meeting.cancelled_by,
      cancelled_by_name: meeting.cancelled_by_name,
      cancellation_reason: meeting.cancellation_reason,
      cancellation_timestamp: meeting.cancellation_timestamp,
    };

    navigate("/monthlymeetingviewdetails", { state: { meeting: enrichedMeeting } });
  };

  const handleAttendeesClick = (meeting) => {
    setSelectedAttendees({
      dealerUser: meeting.dealerUser || [],
      volvoUser: meeting.volvoUser || [],
      externalEmail: meeting.externalEmail || [],
      optionalEmail: meeting.optionalEmail || []
    });
    setAttendeesPopupVisible(true);
  };

  // FIX 5: Clean sort with 3-state toggle (asc → desc → default)
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

 const sortedData = useMemo(() => {
  // 🔥 Default: show normal data
  if (!sortKey || !sortOrder) {
    return filteredMeetings;
  }

  return [...filteredMeetings].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [filteredMeetings, sortKey, sortOrder]);

  // Scroll states
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null);
  const [lastScrollTop, setLastScrollTop] = useState(0);

  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    if (scrollTop > lastScrollTop) {
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);
    setScrollPosition(scrollTop);

    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: tableContainerRef.current.scrollHeight, behavior: "smooth" });
    }
  };

  // FIX 3: Helper to get delete confirmation text
  const getDeleteItemName = () => {
    if (!itemToDelete) return "";
    const dealer = itemToDelete.dealer || "Unknown";
    const date = (() => {
      try {
        if (!itemToDelete.meetingDate) return "";
        const dateObj = new Date(itemToDelete.meetingDate);
        if (isNaN(dateObj.getTime())) return "";
        const day = String(dateObj.getDate()).padStart(2, "0");
        const month = String(dateObj.getMonth() + 1).padStart(2, "0");
        const year = dateObj.getFullYear();
        return `${day}-${month}-${year}`;
      } catch {
        return "";
      }
    })();
    return date ? `${dealer} (${date})` : dealer;
  };

  return (
    <div className="w-full px-2 sm:px-4">
      {/* Top buttons */}
      <div className="w-full flex flex-col sm:flex-row items-center justify-between mt-2 mb-2 gap-2">
        <div className="hidden sm:block w-1/3"></div>
        <div className="w-full sm:w-1/3 flex justify-center">
          <h2 className="text-sm sm:text-lg font-semibold text-darkblue1 font-VolvoNovum">
            View Monthly Meeting
          </h2>
        </div>
        <div className="w-full sm:w-1/3 flex justify-center sm:justify-end">
         <button
  onClick={() => setShowDownloadPopup(true)}
  className="group h-8 px-4 bg-darkblue1 text-white text-xs font-medium flex items-center gap-2 border border-darkblue1 transition-all duration-200 hover:bg-white hover:text-darkblue1"
>
  {/* Default Icon (Blue → hidden on hover) */}
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 16 16"
    className="w-3 h-3 block group-hover:hidden"
    fill="currentColor"
  >
    <path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" />
  </svg>

  {/* Hover Icon (White → shows on hover) */}
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 16 16"
    className="w-3 h-3 hidden group-hover:block"
    fill="currentColor"
  >
    <path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" />
  </svg>

  Download Masters
</button>
        </div>
      </div>

      <div>
        {/* Filters */}
        <div className="w-full mb-2">
          <div className="flex flex-wrap gap-2 items-center">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="w-full sm:w-auto sm:min-w-[140px] sm:max-w-[180px]"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              focusRing="focus:ring-black/60"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-1.5"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              iconColor="text-black"
            />

            <Filter
              name="year"
              value={filters.year}
              options={yearOptions}
              onChange={handleFilterChange}
              placeholder="Year"
              placeholderColor="text-black"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-[calc(50%-4px)] sm:w-[120px]"
            />

            <Filter
              name="month"
              value={filters.month}
              options={monthOptions}
              onChange={handleFilterChange}
              placeholder="Month"
              placeholderColor="text-black"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-[calc(50%-4px)] sm:w-[120px]"
              disableSorting={true}
            />

            <Filter
              name="marketArea"
              value={filters.marketArea}
              options={marketAreaOptions}
              onChange={handleFilterChange}
              placeholder="Market Area"
              placeholderColor="text-black"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-[calc(50%-4px)] sm:w-[140px]"
            />

            <Filter
              name="dealer"
              value={filters.dealer}
              options={dealerOptions}
              onChange={handleFilterChange}
              placeholder="Dealership"
              placeholderColor="text-black"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-[calc(50%-4px)] sm:w-[140px]"
            />

            <Filter
              name="status"
              value={filters.status}
              options={statusOptions}
              onChange={handleFilterChange}
              placeholder="Status"
              textColor="text-black"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-[calc(50%-4px)] sm:w-[120px]"
            />

            <button
                    onClick={handletrendchart}
                    className="h-8 px-4 bg-darkblue1 text-white font-VlovoNovum text-xs font-medium flex items-center justify-center gap-2 border border-transparent transition duration-200 hover:bg-white hover:text-darkblue1 hover:border-darkblue1 group flex-1"
                  >
                   <svg xmlns="http://www.w3.org/2000/svg" width="16" height="12" viewBox="0 0 16 12" fill="none"    className="w-3 h-3 transition duration-200 group-hover:filter group-hover:brightness-0 group-hover:saturate-100"
>
<path d="M15.5 10H2V0.5C2 0.22375 1.77625 0 1.5 0H0.5C0.22375 0 0 0.22375 0 0.5V11C0 11.5522 0.447812 12 1 12H15.5C15.7762 12 16 11.7762 16 11.5V10.5C16 10.2238 15.7762 10 15.5 10ZM14.5 1H10.8106C10.1425 1 9.80781 1.80781 10.2803 2.28031L11.2928 3.29281L9 5.58594L6.70719 3.29313C6.31656 2.9025 5.68344 2.9025 5.29313 3.29313L3.14656 5.43969C2.95125 5.635 2.95125 5.95156 3.14656 6.14688L3.85344 6.85375C4.04875 7.04906 4.36531 7.04906 4.56063 6.85375L6 5.41406L8.29281 7.70687C8.68344 8.0975 9.31656 8.0975 9.70687 7.70687L12.7069 4.70687L13.7194 5.71938C14.1919 6.19187 14.9997 5.85719 14.9997 5.18906V1.5C15 1.22375 14.7762 1 14.5 1Z" fill="white"/>
</svg>
                    <span className="whitespace-nowrap">Trend Chart</span>
                  </button>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700">
            {error}
          </div>
        )}

        {/* Desktop Table */}
        <div className="hidden lg:block bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
          <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
              maxHeight: sortedData.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >
            <table className="w-full text-xs whitespace-nowrap table-fixed">
              <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                <tr>
                  <th className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[6%] cursor-pointer select-none" onClick={() => handleSort("year")}>
                    <div className="flex items-center gap-1">
                      Year
                      {sortKey !== "year" && <ChevronsUpDown className="w-3 h-3 text-white" />}
                      {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>
                  <th className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[13%] cursor-pointer select-none" onClick={() => handleSort("createdby")}>
                    <div className="flex items-center gap-1">
                      Created By
                      {sortKey === "createdby" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "createdby" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>
                  <th className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[11%] cursor-pointer select-none" onClick={() => handleSort("marketArea")}>
                    <div className="flex items-center gap-1">
                      Market Area
                      {sortKey === "marketArea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "marketArea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>
                  <th className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[27%] cursor-pointer select-none" onClick={() => handleSort("dealer")}>
                    <div className="flex items-center gap-1">
                      Dealership
                      {sortKey === "dealer" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "dealer" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>
                  <th className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[16%] cursor-pointer select-none" onClick={() => handleSort("meetingDate")}>
                    <div className="flex items-center gap-1">
                      Meeting Date & Time
                      {sortKey === "meetingDate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "meetingDate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>
                  <th className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[9%] cursor-pointer select-none" onClick={() => handleSort("status")}>
                    <div className="flex items-center gap-1">
                      Status
                      {sortKey === "status" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "status" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>
                  <th className="text-center py-1.5 px-2 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%]">Attendees</th>
                  <th className="text-center py-1.5 px-2 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[10%]">Actions</th>
                </tr>
              </thead>

              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan="8" className="text-center py-8 text-gray-500 italic">
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        Loading meetings...
                      </div>
                    </td>
                  </tr>
                ) : sortedData.length === 0 ? (
                  <tr>
                    <td colSpan="8" className="text-center py-4 text-gray-500 italic">
                      No data found
                    </td>
                  </tr>
                ) : (
                  sortedData.map((meeting) => (
<tr
  key={meeting.id}
  className={`hover:bg-lightBlue/50 text-xs font-normal transition ${
    meeting.status === "Cancelled" || meeting.status === "Completed"
      ? "text-gray-400"
      : ""
  }`}
>                      <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">{meeting.year}</td>
                      <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                        <div className="relative">
                          <p
                            className="truncate max-w-full cursor-pointer"
                            onMouseEnter={() => { if (meeting.createdby && meeting.createdby.length > 18) setHoveredCell(meeting.id + "-createdby"); }}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {meeting.createdby}
                          </p>
                          {hoveredCell === meeting.id + "-createdby" && (
                            <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                              {meeting.createdby}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                        <div className="relative">
                          <p
                            className="truncate max-w-full cursor-pointer"
                            onMouseEnter={() => { if (meeting.marketArea && meeting.marketArea.length > 18) setHoveredCell(meeting.id + "-marketArea"); }}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {meeting.marketArea}
                          </p>
                          {hoveredCell === meeting.id + "-marketArea" && (
                            <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                              {meeting.marketArea}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                        <div className="relative">
                          <p
                            className="truncate max-w-full cursor-pointer"
                            onMouseEnter={() => { if (meeting.dealer && meeting.dealer.length > 50) setHoveredCell(meeting.id + "-dealer"); }}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {meeting.dealer}
                          </p>
                          {hoveredCell === meeting.id + "-dealer" && (
                            <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
                              {meeting.dealer}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-2 py-1 text-xs border border-grey2 border-t-0 border-l-0">
                        {(() => {
                          if (!meeting.meetingDate) return "N/A";
                          try {
                            const dateObj = new Date(meeting.meetingDate);
                            if (isNaN(dateObj.getTime())) return "N/A";
                            const day = String(dateObj.getDate()).padStart(2, "0");
                            const month = String(dateObj.getMonth() + 1).padStart(2, "0");
                            const year = dateObj.getFullYear();
                            return (
                              <>
                                {`${day}-${month}-${year}`}
                                {meeting.start_time && (
                                  <>
                                    <span className="mx-1">|</span>
                                    <span className="font-normal">{meeting.start_time}</span>
                                  </>
                                )}
                              </>
                            );
                          } catch (error) {
                            return "N/A";
                          }
                        })()}
                      </td>
                      <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">
                        <span
                          className={`inline-block text-center font-medium ${
                            meeting.status === "Completed"
                              ? "text-green1"
                              : meeting.status === "Cancelled"
                              ? "text-red1"
                              : "text-darkblue1"
                          }`}
                        >
                          {meeting.status}
                        </span>
                      </td>
                      <td className="py-1 border border-grey2 border-t-0 border-l-0">
                        <div className="flex items-center justify-center">
                          <button
                            onClick={() => handleAttendeesClick(meeting)}
                            className="border-2 border-grey p-1 hover:scale-110 transition"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none">
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="#212121"/>
</svg>
                          </button>
                        </div>
                      </td>

                      {/* Actions - Just the MoreVertical button (dropdown is portal) */}
                      <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                        <div className="flex items-center justify-center">
                          <button
                            type="button"
                            className="dropdown-trigger w-5 h-5 flex items-center justify-center   hover:bg-white  transition-all duration-200"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDropdownToggle(meeting.id, e);
                            }}
                          >
                            <MoreVertical size={14} className="text-gray-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {scrollDirection === 'down' && (
                <button onClick={scrollToTop} className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm" aria-label="Scroll to top">
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}
              {scrollDirection === 'up' && (
                <button onClick={scrollToBottom} className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm" aria-label="Scroll to bottom">
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* ═══════════════════════════════════════════════════════════════ */}
        {/* DROPDOWN MENU PORTAL - Fixed position, outside the table       */}
        {/* ═══════════════════════════════════════════════════════════════ */}
        {dropdownId !== null && (
          <div
            className="dropdown-menu fixed w-44 bg-white border border-gray-200 rounded-md shadow-xl z-[9999] overflow-hidden"
            style={{
              top: `${dropdownPosition.top}px`,
              left: `${dropdownPosition.left}px`,
            }}
          >
            <div className="py-1">
              {/* View Details */}
              {(() => {
                const meeting = sortedData.find((m) => m.id === dropdownId);
                if (!meeting) return null;
                return (
                  <>
                    <button
                      onClick={() => {
                        handleViewdetails(meeting);
                        setDropdownId(null);
                      }}
                      className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-indigo-50 hover:text-black flex items-center gap-2 transition-colors duration-150"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M9.59922 7.19961H20.3992V9.59961H9.59922V7.19961ZM9.59922 3.59961H22.7992V5.99961H9.59922V3.59961ZM1.19922 3.59961H8.39922V10.7996H1.19922V3.59961ZM9.59922 16.7996H20.3992V19.1996H9.59922V16.7996ZM9.59922 13.1996H22.7992V15.5996H9.59922V13.1996ZM1.19922 13.1996H8.39922V20.3996H1.19922V13.1996Z" fill="#2C4730"/>
                      </svg>
                      View Details
                    </button>

                    {/* Edit (Hidden for Cancelled/Completed) */}
                    {meeting.status !== "Cancelled" && meeting.status !== "Completed" && (
                      <button
                        onClick={() => {
                          handleEdit(meeting);
                          setDropdownId(null);
                        }}
                        className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-indigo-50 hover:text-black flex items-center gap-2 transition-colors duration-150"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                          <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                        </svg>
                        Edit
                      </button>
                    )}

                    {/* Action Item */}
                    <button
                      onClick={() => {
                        handleActionItem(meeting);
                        setDropdownId(null);
                      }}
                      className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-indigo-50 hover:text-black flex items-center gap-2 transition-colors duration-150"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M16.5 4.5H20.25V21.75H3.75V4.5H7.5V6H16.5V4.5ZM6.75 12H17.25V10.5H6.75V12ZM6.75 18H17.25V16.5H6.75V18ZM9 4.5V2.25H15V4.5H9Z" fill="#E06900"/>
                      </svg>
                      Action Item
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => {
                        setItemToDelete(meeting);
                        setDeleteModalVisible(true);
                        setDropdownId(null);
                      }}
                      className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-indigo-50 hover:text-black flex items-center gap-1 transition-colors duration-150"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                        <g clipPath="url(#clip0_vmm_del)">
                          <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                        </g>
                        <defs>
                          <clipPath id="clip0_vmm_del">
                            <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                          </clipPath>
                        </defs>
                      </svg>
                      Delete
                    </button>
                  </>
                );
              })()}
            </div>
          </div>
        )}

        {/* Mobile / Tablet Cards */}
        <div className="lg:hidden flex flex-col gap-3">
          {isLoading ? (
            <div className="text-center py-8 text-gray-500 italic">
              <div className="flex items-center justify-center gap-2">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                Loading meetings...
              </div>
            </div>
          ) : sortedData.length === 0 ? (
            <div className="text-center py-8 text-gray-500 italic">No data found</div>
          ) : (
            sortedData.map((meeting) => (
              <div key={meeting.id} className="bg-white shadow-md p-3 border border-Dustyblue text-xs">
                <div className="flex justify-between mb-1.5">
                  <span className="font-medium text-gray-500">Year:</span>
                  <span className="text-gray-700">{meeting.year}</span>
                </div>
                <div className="flex justify-between mb-1.5">
                  <span className="font-medium text-gray-500 flex-shrink-0 mr-2">Created By:</span>
                  <span className="text-gray-700 truncate text-right">{meeting.createdby}</span>
                </div>
                <div className="flex justify-between mb-1.5">
                  <span className="font-medium text-gray-500 flex-shrink-0 mr-2">Market Area:</span>
                  <span className="text-gray-700 truncate text-right">{meeting.marketArea}</span>
                </div>
                <div className="flex justify-between mb-1.5">
                  <span className="font-medium text-gray-500 flex-shrink-0 mr-2">Dealer:</span>
                  <span className="text-gray-700 truncate text-right max-w-[60%]">{meeting.dealer}</span>
                </div>
                <div className="flex justify-between mb-1.5">
                  <span className="font-medium text-gray-500 flex-shrink-0 mr-2">Date & Time:</span>
                  <span className="text-gray-700">
                    {(() => {
                      try {
                        if (!meeting.meetingDate) return "N/A";
                        const dateObj = new Date(meeting.meetingDate);
                        if (isNaN(dateObj.getTime())) return "N/A";
                        const day = String(dateObj.getDate()).padStart(2, "0");
                        const month = String(dateObj.getMonth() + 1).padStart(2, "0");
                        const year = dateObj.getFullYear();
                        const dateStr = `${day}/${month}/${year}`;
                        return meeting.start_time ? `${dateStr} | ${meeting.start_time}` : dateStr;
                      } catch (error) {
                        return "N/A";
                      }
                    })()}
                  </span>
                </div>
                <div className="flex justify-between mb-1.5">
                  <span className="font-medium text-gray-500">Status:</span>
                  <span className={`font-medium ${
                    meeting.status === "Completed" ? "text-green1" : meeting.status === "Cancelled" ? "text-red1" : "text-darkblue1"
                  }`}>
                    {meeting.status}
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-grey2">
                  <button
                    onClick={() => handleAttendeesClick(meeting)}
                    className="border border-grey2 px-2 py-1 text-xs hover:bg-lightBlue/50 transition flex items-center gap-1"
                  >
                    👁 Attendees
                  </button>
                  <div className="flex items-center gap-3">
                    <div className="relative group">
                      <button onClick={() => handleViewdetails(meeting)}>📋</button>
                      <span className="absolute top-full mt-0 left-1/2 transform -translate-x-1/2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">View</span>
                    </div>
                    {meeting.status !== "Cancelled" && meeting.status !== "Completed" && (
                    <div className="relative group">
                      <button onClick={() => handleEdit(meeting)}>✏️</button>
                      <span className="absolute top-full mt-0 left-1/2 transform -translate-x-1/2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">Edit</span>
                    </div>
                    )}
                    <div className="relative group">
                      <button onClick={() => handleActionItem(meeting)}>📝</button>
                      <span className="absolute top-full mt-0 left-1/2 transform -translate-x-1/2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">Action Item</span>
                    </div>
                    <div className="relative group">
                      <button onClick={() => { setItemToDelete(meeting); setDeleteModalVisible(true); }}>🗑️</button>
                      <span className="absolute top-full mt-0 left-1/2 transform -translate-x-1/2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">Delete</span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Download Masters Popup */}
      {showDownloadPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white w-[90%] sm:w-[80%] md:w-[70%] lg:w-[60%] max-h-[80vh] flex flex-col shadow-lg overflow-hidden">
            <div className="bg-white px-4 py-3 flex justify-between items-center flex-shrink-0">
              <h2 className="text-sm sm:text-base font-semibold text-MediumGrey">Download Masters</h2>
              <button onClick={() => setShowDownloadPopup(false)}>✕</button>
            </div>
            <div className="mx-3 sm:mx-4 mb-3 sm:mb-4 border border-Dustyblue flex-1 min-h-0 overflow-hidden flex flex-col">
              {isLoadingMasters ? (
                <div className="flex items-center justify-center py-8 text-gray-500">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500 mr-2"></div>
                  Loading files...
                </div>
              ) : masterFiles.length === 0 ? (
                <p className="text-center text-gray-500 py-8 italic">No master files available</p>
              ) : (
                <div className="overflow-auto flex-1 scrollbar-hide" style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}>
                  <table className="w-full text-xs table-fixed min-w-[500px]">
                    <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                      <tr>
                        <th className="px-2 sm:px-3 py-1.5 font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[30%]">File Name</th>
                        <th className="px-2 sm:px-3 py-1.5 font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[35%]">File</th>
                        <th className="px-2 sm:px-3 py-1.5 font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[17%]">Uploaded By</th>
                        <th className="px-2 sm:px-3 py-1.5 font-medium border-0 w-[18%]">Upload Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {masterFiles.map((file) => (
                        <tr key={file.id} className="hover:bg-lightBlue/50">
                          <td className="px-2 sm:px-3 py-1 border border-grey2 border-t-0 border-l-0">
                            <p className="truncate max-w-full" title={file.fileName}>{file.fileName || "Untitled File"}</p>
                          </td>
                          <td className="px-2 sm:px-3 py-1 border border-grey2 border-t-0 border-l-0">
                            {file.fileUrl ? (
                              <button onClick={() => handleDownload(file)} className="text-SteelBlue1 underline truncate max-w-full block text-left hover:text-darkblue1" title={file.fileUrl?.split("/").pop()}>
                                {(() => {
                                  const name = file.fileUrl.substring(file.fileUrl.lastIndexOf("/") + 1);
                                  return name.length > 40 ? `${name.substring(0, 40)}...` : name;
                                })()}
                              </button>
                            ) : (
                              <span className="text-gray-400">No file</span>
                            )}
                          </td>
                          <td className="px-2 sm:px-3 py-1 border border-grey2 border-t-0 border-l-0">
                            <p className="truncate max-w-full" title={file.uploadedUser}>{file.uploadedUser || "-"}</p>
                          </td>
                          <td className="px-2 sm:px-3 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                            {file.createdOn
                              ? new Date(file.createdOn).toLocaleDateString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" })
                              : "-"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* FIX 3: Pass itemName to DeleteModal for confirmation text */}
      <DeleteModal
        isOpen={deleteModalVisible}
        onClose={() => {
          setDeleteModalVisible(false);
          setItemToDelete(null);
        }}
        onConfirm={handleDelete}
        loading={isLoading}
        itemName={getDeleteItemName()}
      />

      <AtenteesPopup
        isOpen={attendeesPopupVisible}
        onClose={() => setAttendeesPopupVisible(false)}
        attendees={selectedAttendees}
      />
    </div>
  );
};

export default ViewMonthlyMeeting;