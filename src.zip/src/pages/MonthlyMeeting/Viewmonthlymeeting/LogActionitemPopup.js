import React, { useState, useEffect, useRef } from "react";
import { X } from "lucide-react";
import { getActionLogs } from "../../../services/monthlyMeeting/actionLog/actionLog.service";
import { useMemo } from "react";
import { ChevronUp, ChevronDown } from "lucide-react";

// Format log date/time using LOCAL timezone to avoid 1-day offset
const formatLogDateTime = (dateString) => {
  if (!dateString || dateString === "-" || dateString === "N/A" || dateString === "null" || dateString === null)
    return "-";
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "-";
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    return `${day}-${month}-${year} ${hours}:${minutes}`;
  } catch {
    return "-";
  }
};

// Expandable Text Component for long comments
const ExpandableText = ({ text, maxLines = 2 }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [needsExpansion, setNeedsExpansion] = useState(false);
  const textRef = useRef(null);

  useEffect(() => {
    if (textRef.current) {
      const lineHeight = parseInt(window.getComputedStyle(textRef.current).lineHeight) || 16;
      const maxHeight = lineHeight * maxLines;
      setNeedsExpansion(textRef.current.scrollHeight > maxHeight + 5);
    }
  }, [text, maxLines]);

  if (!text || text === "-") return <span className="text-gray-400">-</span>;

  return (
    <div className="relative">
      <div
        ref={textRef}
        className="whitespace-pre-wrap break-words transition-all duration-200"
        style={
          !isExpanded && needsExpansion
            ? {
                display: "-webkit-box",
                WebkitLineClamp: maxLines,
                WebkitBoxOrient: "vertical",
                overflow: "hidden",
              }
            : {}
        }
      >
        {text}
      </div>
      {needsExpansion && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setIsExpanded(!isExpanded);
          }}
          className="text-blue-600 hover:text-blue-800 text-[10px] font-medium mt-0.5 hover:underline"
        >
          {isExpanded ? "Show less" : "Show more"}
        </button>
      )}
    </div>
  );
};

function LogActionitemPopup({ actionItemId, logsData, onClose }) {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const popupRef = useRef(null);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return logs;

  return [...logs].sort((a, b) => {
    let valA, valB;

    switch (sortKey) {
      case "created_on":
        valA = new Date(a.createdOn || a.created_on);
        valB = new Date(b.createdOn || b.created_on);
        break;

      case "updatedBy":
        valA = (a.updated_by_name || a.updated_by || "").toLowerCase();
        valB = (b.updated_by_name || b.updated_by || "").toLowerCase();
        break;

      case "status":
        valA = (a.present_status || "").toLowerCase();
        valB = (b.present_status || "").toLowerCase();
        break;

      case "comments":
        valA = (a.comments || "").toLowerCase();
        valB = (b.comments || "").toLowerCase();
        break;

      default:
        return 0;
    }

    if (valA < valB) return sortOrder === "asc" ? -1 : 1;
    if (valA > valB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [logs, sortKey, sortOrder]);


  // Fetch logs for the action item
  useEffect(() => {
    const fetchLogs = async () => {
      if (!actionItemId) {
        setLoading(false);
        setError("No action item ID provided");
        return;
      }

      try {
        setLoading(true);
        setError(null);
        const response = await getActionLogs(actionItemId);

        if (response.status && response.data) {
          setLogs(response.data);
        } else {
          setLogs([]);
        }
      } catch (err) {
        console.error("Error fetching action logs:", err);
        setError(err.message || "Failed to fetch logs");
        setLogs([]);
      } finally {
        setLoading(false);
      }
    };

    fetchLogs();
  }, [actionItemId]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  // Close on click outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (popupRef.current && !popupRef.current.contains(e.target)) {
        onClose();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [onClose]);

  // Lock body scroll when popup is open
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "auto";
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
  <div
    ref={popupRef}
    className="bg-white 
      w-[90%] sm:w-[80%] md:w-[70%] lg:w-[60%] 
      h-[80vh]   /* ✅ fixed height */
      flex flex-col shadow-lg overflow-hidden"
  >
        {/* Header */}
        <div className="bg-white px-4 py-3 flex justify-between items-center flex-shrink-0 border-b border-grey2">
          <h2 className="text-sm sm:text-base font-semibold text-darkblue1">
            Action Item Logs
          </h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded transition-colors"
          >
            <X size={18} className="text-gray-600" />
          </button>
        </div>

        {/* Action Item Summary */}
        {logsData && (
          <div className="px-4 py-2 bg-gray-50 border-b border-grey2 flex-shrink-0">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs text-gray-600">
              <div>
                <span className="font-semibold text-darkblue1">Topic:</span>{" "}
                {logsData.topicOfDiscussion || "-"}
              </div>
              <div>
                <span className="font-semibold text-darkblue1">Responsibility:</span>{" "}
                {logsData.responsibility || "-"}
              </div>
              <div>
                <span className="font-semibold text-darkblue1">Status:</span>{" "}
                <span
                  className={`font-medium ${
                    logsData.status === "Open"
                      ? "text-mildBlue"
                      : logsData.status === "Closed"
                      ? "text-green6"
                      : "text-burntorange1"
                  }`}
                >
                  {logsData.status || "-"}
                </span>
              </div>
            </div>
            {/* Action Item Comments - from edit page */}
            {logsData.comments && logsData.comments.trim() !== "" && logsData.comments !== "N/A" && (
              <div className="mt-2 text-xs text-gray-600">
                <span className="font-semibold text-darkblue1">Comments:</span>{" "}
                <span className="whitespace-pre-wrap break-words">{logsData.comments}</span>
              </div>
            )}
          </div>
        )}

      <div className="bg-white   overflow-hidden p-4">
  <div
    className="overflow-y-auto overflow-x-auto border border-Dustyblue scrollbar-hide"
    style={{
      maxHeight: logs.length > 8 ? "calc(100vh - 240px)" : "auto",
    }}
  >
    <table className="w-full text-xs table-fixed border border-Dustyblue ">
      

<thead className="bg-Dustyblue text-white sticky top-0 z-10">
  <tr>

    {/* # (no sorting) */}
    <th className="text-left px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%]">
      #
    </th>

    {/* Date */}
    <th
      onClick={() => handleSort("created_on")}
      className="text-left px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer w-[20%]"
    >
      <div className="flex items-center gap-1">
        Date & Time
        {sortKey === "created_on" &&
          (sortOrder === "asc" ? (
            <ChevronUp className="w-3 h-3" />
          ) : (
            <ChevronDown className="w-3 h-3" />
          ))}
      </div>
    </th>

    {/* Updated By */}
    <th
      onClick={() => handleSort("updatedBy")}
      className="text-left px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer w-[20%]"
    >
      <div className="flex items-center gap-1">
        Updated By
        {sortKey === "updatedBy" &&
          (sortOrder === "asc" ? (
            <ChevronUp className="w-3 h-3" />
          ) : (
            <ChevronDown className="w-3 h-3" />
          ))}
      </div>
    </th>

    {/* Status */}
    <th
      onClick={() => handleSort("status")}
      className="text-left px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer w-[15%]"
    >
      <div className="flex items-center gap-1">
        Status
        {sortKey === "status" &&
          (sortOrder === "asc" ? (
            <ChevronUp className="w-3 h-3" />
          ) : (
            <ChevronDown className="w-3 h-3" />
          ))}
      </div>
    </th>

    {/* Comments */}
    <th
      onClick={() => handleSort("comments")}
      className="text-left px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium cursor-pointer w-[40%]"
    >
      <div className="flex items-center gap-1">
        Comments
        {sortKey === "comments" &&
          (sortOrder === "asc" ? (
            <ChevronUp className="w-3 h-3" />
          ) : (
            <ChevronDown className="w-3 h-3" />
          ))}
      </div>
    </th>

  </tr>
</thead>

      <tbody>
        {sortedData.map((log, index) => (
          <tr key={log.id || index} className="hover:bg-lightBlue/50 transition">
            
            <td className="px-2 py-1.5 border">{index + 1}</td>

            <td className="px-2 py-1.5 border whitespace-nowrap">
              {formatLogDateTime(log.createdOn || log.created_on)}
            </td>

            <td className="px-2 py-1.5 border">
              {log.updated_by_name
                ? `${log.updated_by_name} ${log.updated_by_lastname || ""}`.trim()
                : log.updated_by || "-"}
            </td>

            <td className="px-2 py-1.5 border">
              <span
                className={`font-medium ${
                  log.present_status === "Open"
                    ? "text-mildBlue"
                    : log.present_status === "Closed"
                    ? "text-green6"
                    : "text-burntorange1"
                }`}
              >
                {log.present_status || "-"}
              </span>
            </td>

            <td className="px-2 py-1.5 border">
              <div className="truncate max-w-[300px]">
                <ExpandableText text={log.comments || "-"} maxLines={2} />
              </div>
            </td>

          </tr>
        ))}
      </tbody>

    </table>
  </div>
</div>
        {/* Footer */}
        <div className="px-4 py-2 border-t border-grey2 flex justify-end flex-shrink-0">
          <button
            onClick={onClose}
            className="bg-darkblue1 text-white text-xs px-6 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition duration-200"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

export default LogActionitemPopup;