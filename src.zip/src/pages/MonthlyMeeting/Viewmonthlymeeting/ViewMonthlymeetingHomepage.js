import React, { useState, useEffect } from "react";
import Header from "../../../Components/Header";
// import CreateMonthlyMeeting from "../CreateMonthlyMeeting/CreateMonthlyMeeting";
import { useNavigate } from "react-router-dom";
import SubNavbar3 from "../../../Components/SubNavbar3"
import ViewMonthlymeeting from "./ViewMonthlyMeeting";
function ViewMonthlymeetingHomepage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isMonthlyDropdownOpen, setIsMonthlyDropdownOpen] = useState(false);
  const [isActionDropdownOpen, setIsActionDropdownOpen] = useState(false);
  const navigate = useNavigate();

  

  return (
    <div className="bg-Frostwhite h-screen overflow-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 flex-1 overflow-hidden ${
          menuOpen ? "ml-60" : ""
        }`}
      >
                <div className="w-full mt-[4.5rem] lg:mt-[6rem] h-[calc(100vh-4.5rem)] lg:h-[calc(100vh-6rem)] overflow-y-auto">

        {/* 🔹 Tabs with Dropdowns */}
        <div className="flex w-full mb-0 relative z-10">
          {/* Monthly Meeting Dropdown */}
          <div
            className="w-1/2 relative text-center bg-white border-b-2 mt-0  border-SteelBlue1"
            onMouseEnter={() => setIsMonthlyDropdownOpen(true)}
            onMouseLeave={() => setIsMonthlyDropdownOpen(false)}
          >
            <button className="w-full py-2.5 text-sm text-SteelBlue1 font-medium">
              Monthly Meeting
            </button>

      {isMonthlyDropdownOpen && (
  <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-0 bg-white  px-6 py-2 w-full">
    <ul className="flex items-center justify-center text-xs font-normal">
      <li
        className="hover:text-darkblue1 hover:font-bold cursor-pointer whitespace-nowrap"
        onClick={() => navigate("/monthlymeetinghomepage")}
      >
        Create Monthly Meeting
      </li>

      {/* Divider */}
      <div className="h-6 w-px bg-gray-300 mx-4" />

      <li
        className="text-darkblue1 font-bold cursor-pointer whitespace-nowrap"
        onClick={() => navigate("/viewmonthlymeeting")}
      >
        View Monthly Meeting
      </li>
    </ul>
  </div>
)}
</div>
          {/* Action Items Dropdown */}
         <div
            className="w-1/2 relative text-center bg-grey2 border-b-2 border-grey2"
            onMouseEnter={() => setIsActionDropdownOpen(true)}
            onMouseLeave={() => setIsActionDropdownOpen(false)}
          >
            <button 
            onClick={() => navigate("/actionitemhomepage")}
            className="w-full py-2.5 text-sm text-black font-medium">
              Action Items
            </button>

          </div>
        </div>

        {/* 🔹 Content Area */}
        <div className="w-full flex justify-center">
          <div className="w-full transition-all duration-300 ease-in-out">
          <ViewMonthlymeeting />
          </div>
        </div>
      </div>

      {/* 🔹 Scroll to Top Button */}
    
    </div></div>

  );
}

export default ViewMonthlymeetingHomepage;