import React, { useState, useEffect } from "react";

const TagList = ({ label, items, bg = "bg-grey2", text = "text-black" }) => (
  <div className="mb-2">
    <label className="block text-xs font-medium text-black/60 ">{label}</label>
    <div className=" border border-black/30 px-2 py-1.5 flex flex-wrap gap-2 items-center bg-white">
      {items && items.length > 0 ? (
        items.map((item, idx) => {
          let displayValue = "N/A";
          
          // Handle different data structures from API
          if (typeof item === "string") {
            displayValue = item;
          } else if (item && typeof item === "object") {
            // Handle API response structure: {user_id, user_name}
            if (item.user_name) {
              displayValue = item.user_name;
            } else if (item.email) {
              displayValue = item.email;
            } else if (item.name) {
              displayValue = item.name;
            } else if (item.label) {
              displayValue = item.label;
            }
          }

          return (
            <span
              key={idx}
              className={`px-3 py-1  text-xs ${bg} ${text} shadow-sm`}
            >
              {displayValue}
            </span>
          );
        })
      ) : (
        <span className="text-gray-400 text-xs">No {label.toLowerCase()}</span>
      )}
    </div>
  </div>
);

const AtenteesPopup = ({ isOpen, onClose, attendees }) => {
  const [dealerUsers, setDealerUsers] = useState([]);
  const [volvoUsers, setVolvoUsers] = useState([]);
  const [externalAttendees, setExternalAttendees] = useState([]);
  const [optionalAttendees, setOptionalAttendees] = useState([]);

  useEffect(() => {
    if (attendees) {
      // Handle the API data structure properly
      setDealerUsers(attendees.dealerUser || []);
      setVolvoUsers(attendees.volvoUser || []);
      setExternalAttendees(attendees.externalEmail || []);
      setOptionalAttendees(attendees.optionalEmail || []);
    }
  }, [attendees]);

  if (!isOpen) return null;

  // Calculate total attendees
  const totalAttendees = dealerUsers.length + volvoUsers.length + externalAttendees.length + optionalAttendees.length;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
      <div className="bg-white p-8 shadow-xl w-[90%] max-w-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-red-500 hover:scale-110 transition-transform"
        >
<svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>
        </button>

        {/* Popup Title */}
        <div className="text-center mb-2">
          <h2 className="text-base font-semibold text-MediumGrey ">
            Meeting Attendees
          </h2>
          <p className="text-xs text-gray-600">
            Total: {totalAttendees} attendees
          </p>
        </div>

        {/* Tag Display Fields */}
        <div className="space-y-2">
          <TagList 
            label={`Dealer Users (${dealerUsers.length})`} 
            items={dealerUsers} 
            bg="bg-grey2 "
          text="text-black"
          />
          
          <TagList
            label={`Volvo Users (${volvoUsers.length})`}
            items={volvoUsers}
          bg="bg-grey2 "
          text="text-black"
          />
          
          <TagList
            label={`External Attendees (${externalAttendees.length})`}
            items={externalAttendees}
             bg="bg-grey2 "
          text="text-black"
          />
          
          <TagList
            label={`Optional Attendees (${optionalAttendees.length})`}
            items={optionalAttendees}
           bg="bg-grey2 "
          text="text-black"
          />
        </div>

        {/* Summary */}
        {totalAttendees === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500 text-xs">No attendees assigned to this meeting</p>
          </div>
        )}

        {/* Close Button */}
        <div className="flex justify-end mt-2 pt-4 border-t border-gray-200">
          <button
            onClick={onClose}
            className="px-6 py-1.5 bg-darkblue1  text-xs text-white hover:bg-opacity-80 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default AtenteesPopup;
