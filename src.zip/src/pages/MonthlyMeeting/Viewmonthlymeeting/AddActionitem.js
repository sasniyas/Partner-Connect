import React, { useState, useRef, useEffect } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, Calendar } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { API } from "../../../api";
import StyledSelectField from "../../../Components/StyledSelectField";
import { createActionItem, getUsersByMonthlyMeetingDealer } from "../../../services/monthlyMeeting/actionItem/actionItem.service";
import { getDepartments } from "../../../services/monthlyMeetingMaster/departmentMaster.service";
import { getAllUsers } from "../../../services/userManagement/userManagement.service";
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation";

function AddActionitem() {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { state } = useLocation();
  const year = state?.year || "";
  const meetingId = state?.meetingId || "";
  const formRef = useRef(null);

  const [data, setData] = useState({
    department: "",
    topicOfDiscussion: "",
    responsibility: "",
    targetDate: "",
    completedDate: "",
    status: "Open",
    comments: "",
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [departments, setDepartments] = useState([]);
  const [departmentsLoading, setDepartmentsLoading] = useState(true);
  const [users, setUsers] = useState([]);
  const [usersLoading, setUsersLoading] = useState(true);
  const [currentUserId, setCurrentUserId] = useState(null);

  const departmentRef = useRef(null);
  const dealerRef = useRef(null);
  const statusRef = useRef(null);
  const targetRef = useRef(null);
  const completedRef = useRef(null);

  const [isDepartmentOpen, setIsDepartmentOpen] = useState(false);
  const [isResponsibilityOpen, setIsResponsibilityOpen] = useState(false);
  const [isStatusOpen, setIsStatusOpen] = useState(false);
  const statusOptions = ["Open"]; // Bug Fix #5: Only "Open" allowed when creating

  // ═══════════════════════════════════════════════════════════════
  // LOAD CURRENT USER - to filter out from responsibility dropdown
  // Backend rule: created_by !== responsibility
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return;
        const userData = localStorage.getItem("userData");
        if (userData) {
          const parsed = JSON.parse(userData);
          if (parsed?.id) { setCurrentUserId(parsed.id); return; }
        }
        const response = await fetch(`${API.domain}${API.userManagement.logedInUser}`, {
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }
        });
        const result = await response.json();
        if (result?.data?.id) setCurrentUserId(result.data.id);
      } catch {}
    };
    fetchCurrentUser();
  }, []);

  // Fetch departments from API
  const fetchDepartments = async () => {
    try {
      setDepartmentsLoading(true);
      const departmentsData = await getDepartments();
      setDepartments(departmentsData);
    } catch (error) {
      console.error("Error fetching departments:", error);
      setErrors((prev) => ({ ...prev, departments: "Failed to load departments" }));
    } finally {
      setDepartmentsLoading(false);
    }
  };

  // Fetch users mapped to this meeting's dealer
  const fetchUsers = async () => {
    try {
      setUsersLoading(true);
      if (!meetingId) {
        // Fallback to all users if no meetingId
        const usersData = await getAllUsers();
        setUsers(usersData);
      } else {
        const response = await getUsersByMonthlyMeetingDealer(meetingId);
        if (response.status && response.data) {
          // Map userId to id for consistency with existing code
          const mappedUsers = response.data.map((user) => ({
            id: user.userId,
            firstName: user.firstName,
            lastName: user.lastName,
          }));
          setUsers(mappedUsers);
        } else {
          setUsers([]);
        }
      }
    } catch (error) {
      console.error("Error fetching users:", error);
      setErrors((prev) => ({ ...prev, users: "Failed to load users" }));
    } finally {
      setUsersLoading(false);
    }
  };

  useEffect(() => {
    fetchDepartments();
    fetchUsers();
  }, []);

  const handleChange = (key, value) => {
    setData((prev) => ({ ...prev, [key]: value }));
    // Clear error when field is changed
    if (errors[key]) {
      setErrors((prev) => ({ ...prev, [key]: undefined }));
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (departmentRef.current && !departmentRef.current.contains(event.target))
        setIsDepartmentOpen(false);
      if (dealerRef.current && !dealerRef.current.contains(event.target))
        setIsResponsibilityOpen(false);
      if (statusRef.current && !statusRef.current.contains(event.target))
        setIsStatusOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const openCalendar = (ref) => {
    if (ref.current) ref.current.showPicker?.();
  };

  const handleSave = async () => {
    const newErrors = {};

    if (!data.department) newErrors.department = "Department is required";
    if (!data.topicOfDiscussion) newErrors.topicOfDiscussion = "Topic of Discussion is required";
    if (!data.responsibility) newErrors.responsibility = "Responsibility is required";
    if (!data.targetDate) newErrors.targetDate = "Target Date is required";
    if (!data.status) newErrors.status = "Status is required";

    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    if (!meetingId) {
      setErrors({ submit: "Meeting ID is required. Please go back and try again." });
      return;
    }

    try {
      setLoading(true);

      if (departmentsLoading || departments.length === 0) {
        setErrors({ submit: "Departments are still loading. Please wait..." });
        setLoading(false);
        return;
      }
      if (usersLoading || users.length === 0) {
        setErrors({ submit: "Users are still loading. Please wait..." });
        setLoading(false);
        return;
      }

      const selectedDepartment = departments.find((dep) => dep.name === data.department);
      if (!selectedDepartment) {
        throw new Error(`Department "${data.department}" not found. Please select a valid department.`);
      }

      const selectedResponsibility = users.find(
        (user) => `${user.firstName} ${user.lastName}`.trim() === data.responsibility
      );
      if (!selectedResponsibility) {
        throw new Error(`Responsibility "${data.responsibility}" not found. Please select a valid user.`);
      }

      const payload = {
        monthly_meeting_id: meetingId,
        department: selectedDepartment.id,
        topic_of_discussion: data.topicOfDiscussion,
        closure_action: null,
        responsibility: selectedResponsibility.id,
        target_date: data.targetDate || null,
        completed_date: data.completedDate || null,
        status: data.status,
        comments: data.comments?.trim() || null,
      };

      const response = await createActionItem(payload);

      if (response.status) {
        // alert("Action item created successfully!");
        navigate(-1);
      } else {
        throw new Error(response.message || "Failed to create action item");
      }
    } catch (error) {
      console.error("Error creating action item:", error);
      setErrors({ submit: error.message || "Failed to create action item" });
      // alert(`Failed to create: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  useKeyboardNavigation({
    containerRef: formRef,
    onSubmit: handleSave,
    onCancel: () => navigate(-1),
  });

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <div className="hidden lg:block">
        <SubNavbar3 />
      </div>

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full transition-all duration-300 ease-in-out">
            <div>
              <div className="flex items-center gap-2">
                <ArrowLeft
                  onClick={() => navigate(-1)}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
                />
                <h1 className="text-base font-semibold text-darkblue1">
                  Add New Action Item
                </h1>
              </div>
              <hr className="hidden lg:block w-[7%] border-t-4 border-darkblue1 mt-1 ml-[34px] mb-4" />
            </div>

            {/* Form Card */}
            <div className="bg-Frostwhite shadow-lg border border-Dustyblue p-6">
              <div ref={formRef} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Row 1: Topic of Discussion (span 2) + Department */}
                <div className="lg:col-span-2">
                  <label className="block text-xs font-medium text-black/70">
                    Topic of Discussion <span className="text-red1">*</span>
                  </label>
                  <input
                    type="text"
                    value={data.topicOfDiscussion}
                    onChange={(e) => handleChange("topicOfDiscussion", e.target.value)}
                    placeholder="Enter topic of discussion"
                    className={`border w-full mt-2 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all 
                      ${errors.topicOfDiscussion ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                    `}
                  />
                  {errors.topicOfDiscussion && (
                    <p className="text-xs text-red1 mt-1">{errors.topicOfDiscussion}</p>
                  )}
                </div>

                <StyledSelectField
                  label="Department"
                  placeholder={departmentsLoading ? "Loading..." : "Select Department"}
                  value={data.department}
                  setValue={(val) => handleChange("department", val)}
                  options={departments.map((dep) => dep.name)}
                  dropdownOpen={isDepartmentOpen}
                  setDropdownOpen={setIsDepartmentOpen}
                  dropdownRef={departmentRef}
                  required
                  error={errors.department || errors.departments}
                  disabled={departmentsLoading}
                />

                {/* Row 2: Responsibility, Target Date, Status */}
                <StyledSelectField
                  label="Responsibility"
                  value={data.responsibility}
                  setValue={(val) => handleChange("responsibility", val)}
                  options={users
                    .filter((user) => user.id !== currentUserId && user.id !== parseInt(currentUserId, 10))
                    .map((user) => `${user.firstName} ${user.lastName}`.trim())}
                  dropdownOpen={isResponsibilityOpen}
                  setDropdownOpen={setIsResponsibilityOpen}
                  dropdownRef={dealerRef}
                  placeholder={usersLoading ? "Loading..." : "Select Responsibility"}
                  required
                  error={errors.responsibility}
                  disabled={usersLoading}
                />

                {/* Target Date */}
                <div className="relative">
                  <label className="block text-xs font-medium text-gray-700">
                    Target Date <span className="text-red1">*</span>
                  </label>
                  <input
                    ref={targetRef}
                    type="date"
                    value={data.targetDate}
                    onChange={(e) => handleChange("targetDate", e.target.value)}
                    className={`border w-full mt-2 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
 ${
                      errors.targetDate ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                    }`}
                  />
                  <Calendar
                    size={14}
                    className="absolute right-3 top-10 transform -translate-y-1/2 cursor-pointer text-gray-600"
                    onClick={() => openCalendar(targetRef)}
                  />
                  {errors.targetDate && (
                    <p className="text-xs text-red1 mt-1">{errors.targetDate}</p>
                  )}
                </div>

                <StyledSelectField
                  label="Status"
                  value={data.status}
                  setValue={(val) => handleChange("status", val)}
                  options={statusOptions}
                  dropdownOpen={isStatusOpen}
                  setDropdownOpen={setIsStatusOpen}
                  dropdownRef={statusRef}
                  placeholder="Select Status"
                  required
                  error={errors.status}
                />

                {/* Row 3: Comments (full width) */}
                <div className="col-span-1 md:col-span-3">
                  <label className="block text-xs font-medium text-gray-700">Comments</label>
                  <textarea
                    value={data.comments}
                    onChange={(e) => handleChange("comments", e.target.value)}
                    className="border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all border-black/30 focus:ring-black/30
"
                    rows={4}
                    placeholder="Add any additional comments"
                  />
                </div>
              </div>

              {/* Error Display */}
              {errors.submit && (
                <div className="bg-red-50 border border-red-200 p-4 mb-4 mt-4">
                  <p className="text-red-600">{errors.submit}</p>
                </div>
              )}

              {/* Buttons */}
              <div className="flex flex-wrap gap-4 justify-center lg:justify-end mt-10">
                <button
                  type="button"
                  className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs hover:bg-mildBlue1 hover:scale-105"
                  onClick={() => navigate(-1)}
                  disabled={loading}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="12"
                    height="12"
                    viewBox="0 0 18 20"
                    fill="none"
                  >
                    <path
                      d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101"
                      stroke="#1B365D"
                      strokeWidth="1.5"
                      strokeMiterlimit="10"
                      strokeLinecap="round"
                    />
                    <path
                      d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512"
                      stroke="#1B365D"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  Cancel
                </button>

                <button
                  onClick={handleSave}
                  type="button"
                  disabled={loading || departmentsLoading || usersLoading}
                  className="bg-darkblue1 text-white text-xs px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      Saving...
                    </div>
                  ) : (
                    "Save"
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddActionitem;