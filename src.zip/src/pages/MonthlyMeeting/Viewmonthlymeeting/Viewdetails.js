import { useState, useEffect, useRef } from "react"
import Header from "../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../Components/SubNavbar3"
import { ArrowLeft, ChevronDown } from "lucide-react"
import { useLocation } from "react-router-dom"
import CancelmeetingModal from "./CancelmeetingModal"
import CompleteMeetingModal from "./CompleteMeetingModal"
import { format } from "date-fns"
import { updateMonthlyMeeting, getMonthlyMeetingById } from "../../../services/monthlyMeeting/monthlyMeeting/monthlyMeeting.service"
import {
  getMonthlyMeetingTemplatesByMonthlyMeeting,
  addMonthlyMeetingTemplate,
  deleteMonthlyMeetingTemplate,
} from "../../../services/monthlyMeeting/monthlyMeeting/monthlyMeetingTemplate.service"
import SuccessMessage from "../../../pages/Management/UserMangement/SuccessMessage"

function Viewdetails() {
  const [menuOpen, setMenuOpen] = useState(false)
  const navigate = useNavigate()
  const location = useLocation()
  const meetingData = location.state?.meeting || {}

  // Actions dropdown state
  const [actionsOpen, setActionsOpen] = useState(false)
  const actionsRef = useRef(null)
const [isDragging, setIsDragging] = useState(false);
  // Modals
  const [showCancelPopup, setShowCancelPopup] = useState(false)
  const [showCompleteModal, setShowCompleteModal] = useState(false)
  const [showTemplatePopup, setShowTemplatePopup] = useState(false)

  // Loading & messages
  const [isLoading, setIsLoading] = useState(false)
  const [isCloning, setIsCloning] = useState(false)
  const [successMessage, setSuccessMessage] = useState(null)

  // Template
  const [templateData, setTemplateData] = useState([])
  const [isLoadingTemplates, setIsLoadingTemplates] = useState(false)
  const [selectedUploadFile, setSelectedUploadFile] = useState(null)
  const [isSingleUploading, setIsSingleUploading] = useState(false)
  const [isDeletingTemplate, setIsDeletingTemplate] = useState(null)
  const uploadFileInputRef = useRef(null)

  // ─── Helpers ───────────────────────────────────────────────
  const formatDisplayDate = (dateString) => {
    if (!dateString) return "N/A"
    try {
      const date = new Date(dateString)
      if (isNaN(date.getTime())) return "N/A"
      return format(date, "dd-MM-yyyy")
    } catch {
      return "N/A"
    }
  }

  const formatFullDate = (dateString) => {
    if (!dateString) return "N/A"
    try {
      const date = new Date(dateString)
      if (isNaN(date.getTime())) return "N/A"
      return format(date, "EEEE, MMMM dd, yyyy 'at' hh:mm a")
    } catch {
      return "N/A"
    }
  }

  const isRecurring = () => {
    const val = meetingData.recurringMeeting || meetingData.recurring_meeting
    return val && val !== "One-time Meeting"
  }

  // Read values from meetingData
  const createdBy = meetingData.createdby || meetingData.created_by_name || ""
  const createdDate = meetingData.createdDate || meetingData.createdOn || ""
  const marketArea = meetingData.marketArea || meetingData.marketarea || ""
  const dealer = meetingData.dealer || meetingData.dealer_name || ""
  const year = meetingData.year || ""
  const meetingDate = meetingData.dateTime || meetingData.meetingDate || meetingData.meeting_date || ""
  const startTime = meetingData.startTime || meetingData.start_time || ""
  const endTime = meetingData.endTime || meetingData.end_time || ""
  const venue = meetingData.venue || meetingData.meeting_mode || "Physical"
  const locationValue = meetingData.location || meetingData.meeting_venue || ""
  const link = meetingData.link || meetingData.meet_link || meetingData.meeting_link || ""
  const agenda = meetingData.agenda || meetingData.agenda_text || ""
  const recurringMeeting = meetingData.recurringMeeting || meetingData.recurring_meeting || "One-time Meeting"
  const limitDate = meetingData.limit_date || meetingData.limitDate || ""
  const nextMeetingDate = meetingData.next_meeting_date || meetingData.nextMeetingDate || ""
  const dealerUser = meetingData.dealerUser || meetingData.dealer_users || []
  const volvoUser = meetingData.volvoUser || meetingData.volvo_users || []
  const externalEmail = meetingData.externalEmail || meetingData.external_emails || []
  const optionalEmail = meetingData.optionalEmail || meetingData.optional_emails || []
  const attachment = meetingData.attachment || meetingData.agenda_file_url || null
  // FIX 3: Use agenda_file_name from data for proper display
  const attachmentName = meetingData.attachmentName || meetingData.agenda_file_name || (attachment ? attachment.split("/").pop() : null)
  const status = meetingData.status || "Created"
  const remarks = meetingData.remarks || meetingData.remark || ""

  // Cancellation info
  const cancelledByName = meetingData.cancelled_by_name || ""
  const cancellationReason = meetingData.cancellation_reason || ""
  const cancellationTimestamp = meetingData.cancellation_timestamp || ""

  // ─── Close dropdown on outside click ──────────────────────
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (actionsRef.current && !actionsRef.current.contains(e.target)) {
        setActionsOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // ─── Navigation handlers ──────────────────────────────────
  const handleBack = () => {
    navigate("/viewmonthlymeeting", { state: { activeTab: "viewmonthlymeeting" } })
  }

  // EDIT → navigate to CreateMonthlyMeeting page with meeting data
  const handleEdit = () => {
    navigate("/monthlymeetinghomepage", {
      state: { meeting: meetingData },
    })
  }
  // -------drag-------
const handleDragOver = (e) => {
  e.preventDefault();
  e.stopPropagation();
  setIsDragging(true);
};

const handleDragLeave = (e) => {
  e.preventDefault();
  e.stopPropagation();
  setIsDragging(false);
};

const handleDrop = (e) => {
  e.preventDefault();
  e.stopPropagation();
  setIsDragging(false);

  const file = e.dataTransfer.files[0];
  if (file) {
    setSelectedUploadFile(file);
  }
};
  // FIX 1: Clone → fetch meeting by ID, then navigate with cloneMeeting state
  // CreateMonthlyMeeting now handles location.state.cloneMeeting
  const handleClone = async () => {
    try {
      setIsCloning(true)
      if (!meetingData.id) {
        alert("Meeting ID is missing")
        return
      }

      const response = await getMonthlyMeetingById(meetingData.id)
      const m = response.data

      // Build clone data — no id so CreateMonthlyMeeting treats it as new
      const cloneData = {
        market_area_id: m.market_area_id,
        dealer_id: m.dealer_id,
        marketArea: m.marketarea || m.marketArea || "",
        dealer: m.dealer_name || m.dealer || "",
        meetingDate: m.meeting_date || "",
        start_time: m.start_time || "",
        end_time: m.end_time || "",
        recurring_meeting: m.recurring_meeting || "One-time Meeting",
        meeting_mode: m.meeting_mode || "Physical",
        meeting_venue: m.meeting_venue || "",
        meeting_link: m.meeting_link || "",
        meet_link: m.meeting_link || "",
        agenda_text: m.agenda_text || "",
        agenda_file_url: m.agenda_file_url || m.agenda_link || null,
        limit_date: m.limit_date || "",
        next_meeting_date: m.next_meeting_date || "",
        dealer_users: m.dealer_users || [],
        volvo_users: m.volvo_users || [],
        external_emails: m.external_emails || [],
        optional_emails: m.optional_emails || [],
      }

      navigate("/monthlymeetinghomepage", {
        state: { cloneMeeting: cloneData },
      })
    } catch (error) {
      console.error("Error cloning:", error)
      setSuccessMessage({ title: "Error", description: "Failed to fetch meeting data for cloning." })
      setTimeout(() => setSuccessMessage(null), 3000)
    } finally {
      setIsCloning(false)
    }
  }

  const handleActionItem = () => {
    navigate("/actionitemview", { state: { meeting: meetingData } })
  }

  // ─── Complete Meeting ─────────────────────────────────────
  const handleConfirmComplete = async () => {
    if (!meetingData.id) {
      alert("Meeting ID is missing")
      return
    }
    setIsLoading(true)
    try {
      const response = await updateMonthlyMeeting({ id: meetingData.id, status: "Completed" })
      if (response?.status) {
        setShowCompleteModal(false)
        navigate("/viewmonthlymeeting", { state: { activeTab: "viewmonthlymeeting" } })
      } else {
        throw new Error(response?.message || "Failed to complete meeting")
      }
    } catch (error) {
      alert(error.message || "Failed to complete meeting.")
    } finally {
      setIsLoading(false)
    }
  }

  // ─── Cancel Meeting ───────────────────────────────────────
  const handleConfirmCancel = async (cancellationReason) => {
    if (!meetingData.id) {
      alert("Meeting ID is missing")
      return
    }
    if (!cancellationReason?.trim()) {
      alert("Cancellation reason is required")
      return
    }
    setIsLoading(true)
    try {
      const response = await updateMonthlyMeeting({
        id: meetingData.id,
        status: "Cancelled",
        cancellation_reason: cancellationReason.trim(),
      })
      if (response?.status) {
        setShowCancelPopup(false)
        navigate("/viewmonthlymeeting", { state: { activeTab: "viewmonthlymeeting" } })
      } else {
        throw new Error(response?.message || "Failed to cancel meeting")
      }
    } catch (error) {
      alert(error.message || "Failed to cancel meeting.")
    } finally {
      setIsLoading(false)
    }
  }

  // ─── Attachment Click ─────────────────────────────────────
  // FIX 5: Handle both URL and base64 attachments for all file types
  const handleAttachmentClick = () => {
    if (!attachment) return

    // HTTP/HTTPS URL — open in new tab (works for PDF, images, etc.)
    if (typeof attachment === "string" && attachment.startsWith("http")) {
      window.open(attachment, "_blank")
      return
    }

    // Base64 data URL — handle based on type
    if (typeof attachment === "string" && attachment.startsWith("data:")) {
      const mimeMatch = attachment.match(/^data:([^;]+);/)
      const mimeType = mimeMatch ? mimeMatch[1] : ""

      if (mimeType.startsWith("image/")) {
        // Image — render in new window
        const newWindow = window.open()
        if (newWindow) {
          newWindow.document.write(
            `<html><head><title>${attachmentName || "Attachment"}</title></head><body style="margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh;background:#f0f0f0;"><img src="${attachment}" style="max-width:100%;max-height:100%;object-fit:contain;" /></body></html>`
          )
        }
      } else if (mimeType === "application/pdf") {
        // PDF — embed in new window
        const newWindow = window.open()
        if (newWindow) {
          newWindow.document.write(
            `<html><head><title>${attachmentName || "Attachment"}</title></head><body style="margin:0;"><embed src="${attachment}" type="application/pdf" width="100%" height="100%" style="position:absolute;top:0;left:0;right:0;bottom:0;" /></body></html>`
          )
        }
      } else {
        // Other file types — trigger download
        const link = document.createElement("a")
        link.href = attachment
        link.download = attachmentName || "attachment"
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
      }
    }
  }

  // ─── Templates ────────────────────────────────────────────
  useEffect(() => {
    const fetchTemplates = async () => {
      if (showTemplatePopup && meetingData?.id) {
        setIsLoadingTemplates(true)
        try {
          const response = await getMonthlyMeetingTemplatesByMonthlyMeeting(meetingData.id)
          if (response?.data) setTemplateData(response.data)
        } catch (error) {
          console.error("Error fetching templates:", error)
        } finally {
          setIsLoadingTemplates(false)
        }
      }
    }
    fetchTemplates()
  }, [showTemplatePopup, meetingData?.id])

  // Single file upload — calls addMonthlyMeetingTemplate service
  const handleSingleFileUpload = async () => {
    if (!selectedUploadFile || !meetingData?.id) return

    setIsSingleUploading(true)
    try {
      const result = await addMonthlyMeetingTemplate({
        monthly_meeting: meetingData.id,
        file: selectedUploadFile,
      })

      if (result?.status) {
        // Refresh template list
        const updated = await getMonthlyMeetingTemplatesByMonthlyMeeting(meetingData.id)
        if (updated?.data) setTemplateData(updated.data)
        setSelectedUploadFile(null)
        if (uploadFileInputRef.current) uploadFileInputRef.current.value = ""
        setSuccessMessage({ title: "Success", description: "File uploaded successfully!" })
        setTimeout(() => setSuccessMessage(null), 3000)
      } else {
        throw new Error(result?.message || "Failed to upload")
      }
    } catch (error) {
      console.error("Error uploading file:", error)
      setSuccessMessage({ title: "Error", description: error.message || "Failed to upload file." })
      setTimeout(() => setSuccessMessage(null), 3000)
    } finally {
      setIsSingleUploading(false)
    }
  }

  // Delete template file — calls deleteMonthlyMeetingTemplate service
  const handleDeleteTemplate = async (templateId) => {
    if (!templateId) return
    setIsDeletingTemplate(templateId)
    try {
      const result = await deleteMonthlyMeetingTemplate(templateId)

      if (result?.status) {
        setTemplateData(prev => prev.filter(t => t.id !== templateId))
        setSuccessMessage({ title: "Success", description: "File deleted successfully!" })
        setTimeout(() => setSuccessMessage(null), 3000)
      } else {
        throw new Error(result?.message || "Failed to delete")
      }
    } catch (error) {
      console.error("Error deleting template:", error)
      setSuccessMessage({ title: "Error", description: error.message || "Failed to delete file." })
      setTimeout(() => setSuccessMessage(null), 3000)
    } finally {
      setIsDeletingTemplate(null)
    }
  }

  // ─── Helper: format user display name ─────────────────────
  const getUserDisplayName = (user) => {
    if (typeof user === "string") return user
    return user?.user_name || user?.name || user?.email || String(user)
  }

  // ─── Actions dropdown items (conditional) ─────────────────
  const isCancelledOrCompleted = status === "Cancelled" || status === "Completed"

  const actionItems = [
  {
    label: "Action Items",
    icon: (
      <span className="w-4 h-4 flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M16.5 4.5H20.25V21.75H3.75V4.5H7.5V6H16.5V4.5ZM6.75 12H17.25V10.5H6.75V12ZM6.75 18H17.25V16.5H6.75V18ZM9 4.5V2.25H15V4.5H9Z" fill="#E06900"/>
</svg>
      </span>
    ),
    onClick: handleActionItem,
    show: true,
  },
  {
    label: "Upload Files",
    icon: (
      <span className="w-4 h-4 flex items-center justify-center">
       <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
<path d="M11.9675 12.498L11.9675 4M11.9675 4L8.97971 6.9993M11.9675 4L14.9554 6.9993M15.9513 16.961C15.2064 16.8529 14.5163 16.5057 13.9843 15.9712M6.48985 9.9986C4.97702 9.9986 4 11.2293 4 12.748C4.00005 13.3492 4.19643 13.9339 4.55907 14.4124C4.92171 14.8909 5.43061 15.2369 6.00782 15.3973C6.09663 16.5186 6.55956 17.5771 7.32178 18.4016C8.08399 19.226 9.10094 19.7684 10.2082 19.9409C11.3155 20.1134 12.4483 19.9059 13.4236 19.3521C14.3989 18.7983 15.1596 17.9305 15.5828 16.889C16.4737 17.1369 17.4263 17.0194 18.2309 16.5623C19.0356 16.1052 19.6263 15.3459 19.8733 14.4516C20.1203 13.5572 20.0032 12.601 19.5479 11.7933C19.0925 10.9855 18.3362 10.3925 17.4452 10.1446" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
      </span>
    ),
    onClick: () => setShowTemplatePopup(true),
    show: !isCancelledOrCompleted,
  },
  {
    label: "Edit",
    icon: (
      <span className="w-4 h-4 flex items-center justify-center">
       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

      </span>
    ),
    onClick: handleEdit,
    show: !isCancelledOrCompleted,
  },
  {
    label: "Clone Meeting",
    icon: (
      <span className="w-4 h-4 flex items-center justify-center">
       <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"     className="w-4 h-4"
>
<rect x="0.5" y="0.5" width="10.0003" height="13.6086" stroke="#204D80"/>
<path d="M3 5L6 5" stroke="#204D80" stroke-linecap="round"/>
<path d="M3 7L7 7" stroke="#204D80" stroke-linecap="round"/>
<path d="M3 9H8" stroke="#204D80" stroke-linecap="round"/>
<rect x="13.5" y="9.89136" width="10.0003" height="13.6086" stroke="#204D80"/>
<path d="M16 14.3914L19 14.3914" stroke="#204D80" stroke-linecap="round"/>
<path d="M16 16.3914L20 16.3914" stroke="#204D80" stroke-linecap="round"/>
<path d="M16 18.3914H21" stroke="#204D80" stroke-linecap="round"/>
<path d="M5.5 15.6523V19.8262H10.5002" stroke="#204D80" stroke-linecap="round"/>
<path d="M11.7558 19.4864C11.8298 19.5242 11.8915 19.5798 11.9345 19.6472C11.9775 19.7147 12.0001 19.7917 12.0001 19.8701C12.0001 19.9486 11.9775 20.0255 11.9345 20.093C11.8915 20.1605 11.8298 20.2161 11.7558 20.2539L8.6125 21.8591C8.5407 21.8957 8.45987 21.9143 8.37796 21.9131C8.29606 21.9118 8.21591 21.8908 8.14542 21.8521C8.07493 21.8133 8.01652 21.7582 7.97595 21.6921C7.93538 21.626 7.91405 21.5513 7.91406 21.4752V18.2648C7.91408 18.1887 7.93544 18.114 7.97605 18.0479C8.01666 17.9818 8.07511 17.9267 8.14564 17.888C8.21617 17.8492 8.29635 17.8283 8.37827 17.8271C8.46019 17.8259 8.54103 17.8446 8.61281 17.8812L11.7558 19.4864Z" fill="#204D80"/>
<path d="M12.2441 3.74641C12.1701 3.78419 12.1084 3.83972 12.0654 3.90722C12.0224 3.97472 11.9998 4.0517 11.9998 4.13011C11.9998 4.20853 12.0224 4.28551 12.0654 4.35301C12.1084 4.42051 12.1701 4.47604 12.2441 4.51382L15.3875 6.11897C15.4593 6.15559 15.5401 6.1742 15.622 6.17298C15.7039 6.17175 15.7841 6.15073 15.8546 6.11199C15.9251 6.07325 15.9835 6.01812 16.024 5.95204C16.0646 5.88595 16.0859 5.81119 16.0859 5.73513V2.52481C16.0859 2.44873 16.0646 2.37396 16.024 2.30787C15.9833 2.24179 15.9249 2.18668 15.8544 2.14796C15.7838 2.10924 15.7036 2.08826 15.6217 2.08709C15.5398 2.08591 15.459 2.10458 15.3872 2.14125L12.2441 3.74641Z" fill="#204D80"/>
<path d="M13.9863 4.17401H18.9865V8.3479" stroke="#204D80" stroke-linecap="round"/>
</svg>
      </span>
    ),
    onClick: handleClone,
    show: true,
    loading: isCloning,
  },
  {
    label: "Cancel Meeting",
    icon: (
      <span className="w-4 h-4 flex items-center justify-center">
       <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
<path d="M7.8 14.8293L11 11.6293L14.2 14.8293L14.8293 14.2L11.6293 11L14.8293 7.8L14.2 7.17067L11 10.3707L7.8 7.17067L7.17067 7.8L10.3707 11L7.17067 14.2L7.8 14.8293ZM11.0027 19C9.89689 19 8.85689 18.7902 7.88267 18.3707C6.90904 17.9505 6.06193 17.3804 5.34133 16.6604C4.62074 15.9404 4.05037 15.0942 3.63022 14.1218C3.21007 13.1493 3 12.1096 3 11.0027C3 9.8957 3.21007 8.8557 3.63022 7.88267C4.04978 6.90904 4.61896 6.06193 5.33778 5.34133C6.05659 4.62074 6.90311 4.05037 7.87733 3.63022C8.85156 3.21007 9.89156 3 10.9973 3C12.1031 3 13.1431 3.21007 14.1173 3.63022C15.091 4.04978 15.9381 4.61926 16.6587 5.33867C17.3793 6.05807 17.9496 6.90459 18.3698 7.87822C18.7899 8.85185 19 9.89155 19 10.9973C19 12.1031 18.7902 13.1431 18.3707 14.1173C17.9511 15.0916 17.381 15.9387 16.6604 16.6587C15.9399 17.3787 15.0936 17.949 14.1218 18.3698C13.1499 18.7905 12.1102 19.0006 11.0027 19ZM11 18.1111C12.9852 18.1111 14.6667 17.4222 16.0444 16.0444C17.4222 14.6667 18.1111 12.9852 18.1111 11C18.1111 9.01481 17.4222 7.33333 16.0444 5.95555C14.6667 4.57778 12.9852 3.88889 11 3.88889C9.01481 3.88889 7.33333 4.57778 5.95556 5.95555C4.57778 7.33333 3.88889 9.01481 3.88889 11C3.88889 12.9852 4.57778 14.6667 5.95556 16.0444C7.33333 17.4222 9.01481 18.1111 11 18.1111Z" fill="#BF2012"/>
</svg>
      </span>
    ),
    onClick: () => setShowCancelPopup(true),
    show: !isCancelledOrCompleted,
    danger: true,
  },
  {
    label: "Complete Meeting",
    icon: (
      <span className="w-4 h-4 flex items-center justify-center">
       <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
<path d="M15.6484 8.64844L16.3516 9.35156L10.5 15.2031L7.64844 12.3516L8.35156 11.6484L10.5 13.7969L15.6484 8.64844ZM12 4C12.7344 4 13.4427 4.09375 14.125 4.28125C14.8073 4.46875 15.4453 4.73698 16.0391 5.08594C16.6328 5.4349 17.1719 5.85156 17.6562 6.33594C18.1406 6.82031 18.5573 7.36198 18.9062 7.96094C19.2552 8.5599 19.5234 9.19792 19.7109 9.875C19.8984 10.5521 19.9948 11.2604 20 12C20 12.7344 19.9062 13.4427 19.7188 14.125C19.5312 14.8073 19.263 15.4453 18.9141 16.0391C18.5651 16.6328 18.1484 17.1719 17.6641 17.6562C17.1797 18.1406 16.638 18.5573 16.0391 18.9062C15.4401 19.2552 14.8021 19.5234 14.125 19.7109C13.4479 19.8984 12.7396 19.9948 12 20C11.2656 20 10.5573 19.9062 9.875 19.7188C9.19271 19.5312 8.55469 19.263 7.96094 18.9141C7.36719 18.5651 6.82812 18.1484 6.34375 17.6641C5.85938 17.1797 5.44271 16.638 5.09375 16.0391C4.74479 15.4401 4.47656 14.8047 4.28906 14.1328C4.10156 13.4609 4.00521 12.75 4 12C4 11.2656 4.09375 10.5573 4.28125 9.875C4.46875 9.19271 4.73698 8.55469 5.08594 7.96094C5.4349 7.36719 5.85156 6.82812 6.33594 6.34375C6.82031 5.85938 7.36198 5.44271 7.96094 5.09375C8.5599 4.74479 9.19531 4.47656 9.86719 4.28906C10.5391 4.10156 11.25 4.00521 12 4ZM12 19C12.6406 19 13.2578 18.9167 13.8516 18.75C14.4453 18.5833 15.0026 18.349 15.5234 18.0469C16.0443 17.7448 16.5182 17.3776 16.9453 16.9453C17.3724 16.513 17.737 16.0417 18.0391 15.5312C18.3411 15.0208 18.5781 14.4635 18.75 13.8594C18.9219 13.2552 19.0052 12.6354 19 12C19 11.3594 18.9167 10.7422 18.75 10.1484C18.5833 9.55469 18.349 8.9974 18.0469 8.47656C17.7448 7.95573 17.3776 7.48177 16.9453 7.05469C16.513 6.6276 16.0417 6.26302 15.5312 5.96094C15.0208 5.65885 14.4635 5.42188 13.8594 5.25C13.2552 5.07812 12.6354 4.99479 12 5C11.3594 5 10.7422 5.08333 10.1484 5.25C9.55469 5.41667 8.9974 5.65104 8.47656 5.95312C7.95573 6.25521 7.48177 6.6224 7.05469 7.05469C6.6276 7.48698 6.26302 7.95833 5.96094 8.46875C5.65885 8.97917 5.42188 9.53646 5.25 10.1406C5.07812 10.7448 4.99479 11.3646 5 12C5 12.6406 5.08333 13.2578 5.25 13.8516C5.41667 14.4453 5.65104 15.0026 5.95312 15.5234C6.25521 16.0443 6.6224 16.5182 7.05469 16.9453C7.48698 17.3724 7.95833 17.737 8.46875 18.0391C8.97917 18.3411 9.53646 18.5781 10.1406 18.75C10.7448 18.9219 11.3646 19.0052 12 19Z" fill="#50A265"/>
</svg>
      </span>
    ),
    onClick: () => setShowCompleteModal(true),
    show: !isCancelledOrCompleted,
  },
].filter((item) => item.show);  // ─── Read-only field component ────────────────────────────
  const ReadOnlyField = ({ label, value, colSpan = false }) => (
    <div className={colSpan ? "lg:col-span-3" : ""}>
      <label className="block text-[11px] font-medium text-black/50 mb-1">{label}</label>
      <div className="w-full border border-black/20 bg-gray-50/50 px-3 py-2 text-xs text-black/80 min-h-[36px] flex items-center">
        {value || <span className="text-black/30">N/A</span>}
      </div>
    </div>
  )

  // ─── Multi-value read-only field ──────────────────────────
  const ReadOnlyChips = ({ label, values = [] }) => {
    const items = Array.isArray(values) ? values : []
    return (
      <div>
        <label className="block text-[11px] font-medium text-black/50 mb-1">{label}</label>
        <div className="w-full border border-black/20 bg-gray-50/50 px-3 py-2 text-xs min-h-[36px] flex flex-wrap items-center gap-1.5">
          {items.length > 0 ? (
            items.map((item, i) => (
              <span
                key={i}
                className="inline-block px-2 py-0.5 bg-grey2 text-darkblue1 text-[11px] font-medium"
              >
                {getUserDisplayName(item)}
              </span>
            ))
          ) : (
            <span className="text-black/30">N/A</span>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[5rem] p-2 lg:px-4">
          <div className="w-full transition-all duration-300 ease-in-out">
            {/* ─── Header Row ─────────────────────────────────── */}
            <div className="pt-4 px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                {/* Left: Back + Title */}
                <div className="flex items-center gap-2">
                  <ArrowLeft
                    onClick={handleBack}
                    size={24}
                    className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
                  />
                  <div>
                    <h2 className="text-base font-semibold font-VolvoNovum text-darkblue1">
                      Monthly Meeting Details
                    </h2>
                    <hr className="w-full border-t-[3px] border-darkblue1 mt-0.5" />
                  </div>
                </div>

                {/* Right: Status Badge + Actions Dropdown */}
                <div className="flex items-center gap-3">
                  {/* Status Badge */}
                  <span
                    className={`inline-flex items-center px-3 py-1 text-xs font-semibold ${
                      status === "Completed"
                        ? "bg-green-100 text-green-700 border border-green-300"
                        : status === "Cancelled"
                        ? "bg-red-100 text-red-700 border border-red-300"
                        : "bg-blue-100 text-darkblue1 border border-blue-300"
                    }`}
                  >
                    {status}
                  </span>

                  {/* Actions Dropdown */}
                <div className="relative flex justify-center" ref={actionsRef}>
  
  <button
    onClick={() => setActionsOpen(!actionsOpen)}
    disabled={isLoading || isCloning}
    className="flex items-center justify-center gap-2 px-4 py-1.5 w-48 bg-darkblue1 text-white text-xs font-medium hover:bg-darkblue1/90 transition disabled:opacity-50"
  >
    {isCloning ? (
      <>
        <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
        Cloning...
      </>
    ) : (
      <>
        <span>Actions</span>

        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          className={`w-4 h-4 transition-transform duration-300 ${
            actionsOpen ? "rotate-180" : "rotate-0"
          }`}
          fill="none"
        >
          <path
            d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
            fill="currentColor"
          />
        </svg>
      </>
    )}
  </button>

 {actionsOpen && !isCloning && (
  <div className="absolute top-full mt-1 w-48 bg-white border border-black/15 shadow-lg z-50">
    {actionItems.map((item, i) => (
      <button
        key={i}
        onClick={() => {
          setActionsOpen(false);
          item.onClick();
        }}
        disabled={isLoading || item.loading}
        className={`w-full px-4 py-2 text-xs transition flex items-center gap-2 text-left ${
          item.danger
            ? "text-red1 hover:bg-red-50"
            : "text-black/80 hover:bg-lightBlue/50"
        } disabled:opacity-50`}
      >
        {item.loading ? (
          <span className="flex items-center gap-2">
            <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-gray-500"></div>
            {item.label}...
          </span>
        ) : (
          <>
            {item.icon}
            <span>{item.label}</span>
          </>
        )}
      </button>
    ))}
  </div>
)}

</div>
</div>
</div>
              {/* Created on info */}
              <div className="flex items-center gap-2 mt-3 mb-4">
                <div className="w-2.5 h-2.5 rounded-full bg-darkblue1"></div>
                <span className="text-[11px] font-medium text-black/50">
                  Meeting created on: {formatFullDate(createdDate)}
                </span>
              </div>
            </div>

            {/* ─── Meeting Details Grid ────────────────────────── */}
            <div className="px-4 sm:px-6 lg:px-8">
              <div className="bg-white border border-black/10 p-4 sm:p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
                  {/* Row 1 */}
                  <ReadOnlyField label="Created By" value={createdBy} />
                  <div className="flex gap-4">
                    <div className="w-1/2">
                      <ReadOnlyField label="Created Date" value={formatDisplayDate(createdDate)} />
                    </div>
                    <div className="w-1/2">
                      <ReadOnlyField label="Year" value={year} />
                    </div>
                  </div>
                  <ReadOnlyField
                    label="Meeting Date"
                    value={formatDisplayDate(meetingDate)}
                  />

                  {/* Row 2 */}
                  <div className="flex gap-4">
                    <div className="w-1/2">
                      <ReadOnlyField label="Start Time" value={startTime} />
                    </div>
                    <div className="w-1/2">
                      <ReadOnlyField label="End Time" value={endTime} />
                    </div>
                  </div>
                  <ReadOnlyField label="Market Area" value={marketArea} />
                  <ReadOnlyField label="Dealership" value={dealer} />

                  {/* Row 3 */}
                  <ReadOnlyField label="Meeting Mode" value={venue} />
                  {venue === "Physical" ? (
                    <ReadOnlyField label="Venue" value={locationValue} />
                  ) : (
                    <ReadOnlyField label="Meeting Link" value={link} />
                  )}
                  <ReadOnlyField label="Frequency of Meeting" value={recurringMeeting} />

                  {/* Row 4 - Recurring fields (conditional) */}
                  {isRecurring() && (
                    <>
                      <ReadOnlyField label="Repeat Until" value={formatDisplayDate(limitDate)} />
                      <ReadOnlyField label="Next Meeting Date" value={formatDisplayDate(nextMeetingDate)} />
                    </>
                  )}

                  {/* Attendees */}
                  <ReadOnlyChips label="Dealer User" values={dealerUser} />
                  <ReadOnlyChips label="Volvo User" values={volvoUser} />
                  <ReadOnlyChips label="External Attendee" values={externalEmail} />
                  <ReadOnlyChips label="Optional Attendee" values={optionalEmail} />
                </div>

                {/* Agenda - full width */}
                <div className="mt-4">
                  <label className="block text-[11px] font-medium text-black/50 mb-1">Agenda</label>
                  <div className="w-full border border-black/20 bg-gray-50/50 px-4 py-3 text-xs text-black/80 min-h-[80px]">
                    {/* Attachment */}
                    {attachment && (
                      <div className="mb-2">
                        <div
                          onClick={handleAttachmentClick}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-lightBlue text-darkblue1 text-[11px] font-medium cursor-pointer hover:bg-lightBlue/70 transition"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48" />
                          </svg>
                          {attachmentName || "View Attachment"}
                        </div>
                      </div>
                    )}
                    <div className="whitespace-pre-wrap">
                      {agenda || <span className="text-black/30">No agenda provided</span>}
                    </div>
                  </div>
                </div>

                {/* Remarks - read only */}
                {remarks && (
                  <div className="mt-4">
                    <label className="block text-[11px] font-medium text-black/50 mb-1">Remarks</label>
                    <div className="w-full border border-black/20 bg-gray-50/50 px-4 py-3 text-xs text-black/80 min-h-[60px] whitespace-pre-wrap">
                      {remarks}
                    </div>
                  </div>
                )}

                {/* Cancellation Info - only show if cancelled */}
                {status === "Cancelled" && (
                  <div className="mt-4 p-4 bg-red-50 border border-red-200">
                    <h3 className="text-xs font-semibold text-red1 mb-2">Cancellation Details</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-[11px] font-medium text-black/50 mb-0.5">
                          Cancelled By
                        </label>
                        <span className="text-xs text-black/80">{cancelledByName || "N/A"}</span>
                      </div>
                      <div>
                        <label className="block text-[11px] font-medium text-black/50 mb-0.5">
                          Cancelled On
                        </label>
                        <span className="text-xs text-black/80">
                          {cancellationTimestamp ? formatFullDate(cancellationTimestamp) : "N/A"}
                        </span>
                      </div>
                      <div className="sm:col-span-1">
                        <label className="block text-[11px] font-medium text-black/50 mb-0.5">
                          Reason
                        </label>
                        <span className="text-xs text-black/80">{cancellationReason || "N/A"}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ─── Template Upload Popup ──────────────────────────── */}
      {showTemplatePopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white w-[90%] sm:w-[60%] lg:w-[45%] max-w-[600px] relative flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="px-6 pt-5 pb-3 flex justify-between items-center">
              <h2 className="text-sm font-semibold text-center flex-1">Upload Filled Templates</h2>
              <button
                className="absolute top-3 right-3 w-6 h-6 rounded-full bg-red1 text-white flex items-center justify-center text-xs hover:bg-red-700 transition"
                onClick={() => {
                  setShowTemplatePopup(false)
                  setSelectedUploadFile(null)
                  if (uploadFileInputRef.current) uploadFileInputRef.current.value = ""
                }}
              >
                ✕
              </button>
            </div>

            {/* Select File + Upload Button */}
            {!isCancelledOrCompleted && (
              <div className="px-6 pb-4">
                <label className="block text-xs font-medium text-black/70 mb-1.5">Select File</label>
                <div className="flex items-center gap-2">
                  <div
  onClick={() => uploadFileInputRef.current?.click()}
  onDragOver={handleDragOver}
  onDragLeave={handleDragLeave}
  onDrop={handleDrop}
  className={`flex-1 h-[36px]  border-2 border-dashed px-3 flex flex-col items-center justify-center text-xs cursor-pointer transition bg-white
    ${isDragging ? "border-darkblue1 bg-lightBlue/20" : "border-black/30 hover:border-black/50"}
  `}
>
  <span className={selectedUploadFile ? "text-black font-medium" : "text-gray-400"}>
    {selectedUploadFile
      ? selectedUploadFile.name
      : "Click or Drag & Drop file here"}
  </span>

 
</div>
                  <input
                    ref={uploadFileInputRef}
                    type="file"
                    accept=".xlsx,.xls,.pdf,.doc,.docx,.ppt,.pptx,.csv,.txt,.jpg,.jpeg,.png"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files[0]
                      if (file) setSelectedUploadFile(file)
                    }}
                  />
                  <button
                    onClick={handleSingleFileUpload}
                    disabled={!selectedUploadFile || isSingleUploading}
                    className={`h-[36px] px-5 text-xs font-medium transition ${
                      !selectedUploadFile || isSingleUploading
                        ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                        : "bg-darkblue1 text-white hover:bg-darkblue1/90"
                    }`}
                  >
                    {isSingleUploading ? "Uploading..." : "Upload"}
                  </button>
                </div>
              </div>
            )}

            {/* Uploaded Files Table */}
            <div className="px-6 pb-6 flex-1 overflow-hidden flex flex-col min-h-0">
              <div className="border border-Dustyblue flex-1 overflow-hidden flex flex-col">
                {/* Table Header */}
                <div className="bg-Dustyblue text-white text-xs font-medium flex flex-shrink-0">
                  <div className="flex-1 px-3 py-2">Uploaded Files</div>
                  <div className="w-[100px] px-3 py-2 text-center">Actions</div>
                </div>

                {/* Table Body */}
                <div className="overflow-y-auto flex-1" style={{ maxHeight: "250px" }}>
                  {isLoadingTemplates ? (
                    <div className="flex items-center justify-center py-8 text-gray-500">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-gray-500 mr-2"></div>
                      <span className="text-xs">Loading files...</span>
                    </div>
                  ) : templateData.filter(t => t.upload_fileLink).length === 0 ? (
                    <div className="flex items-center justify-center py-8">
                      <span className="text-xs text-gray-400 italic">No files uploaded</span>
                    </div>
                  ) : (
                    templateData
                      .filter(t => t.upload_fileLink)
                      .map((t) => {
                        const fileName = t.upload_fileLink
                          ? t.upload_fileLink.substring(t.upload_fileLink.lastIndexOf("/") + 1)
                          : `File ${t.id}`
                        return (
                          <div
                            key={t.id}
                            className="flex items-center border-b border-grey2 last:border-b-0 hover:bg-lightBlue/30 transition"
                          >
                            <div className="flex-1 px-3 py-2 text-xs text-black/80 truncate" title={fileName}>
                              {fileName.length > 45 ? `${fileName.substring(0, 45)}...` : fileName}
                            </div>
                            <div className="w-[100px] px-3 py-2 flex items-center justify-center gap-2">
                              {/* View/Download */}
                              <button
                                onClick={() => window.open(t.upload_fileLink, "_blank")}
                                className="text-darkblue1 hover:text-blue-800 transition"
                                title="View File"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                  <circle cx="12" cy="12" r="3" />
                                </svg>
                              </button>
                              {/* Delete - only if not cancelled/completed */}
                              {!isCancelledOrCompleted && (
                                <button
                                  onClick={() => handleDeleteTemplate(t.id)}
                                  disabled={isDeletingTemplate === t.id}
                                  className="text-red1 hover:text-red-700 transition disabled:opacity-50"
                                  title="Delete File"
                                >
                                  {isDeletingTemplate === t.id ? (
                                    <div className="animate-spin rounded-full h-3.5 w-3.5 border-b-2 border-red1"></div>
                                  ) : (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                      <polyline points="3 6 5 6 21 6" />
                                      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                                    </svg>
                                  )}
                                </button>
                              )}
                            </div>
                          </div>
                        )
                      })
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ─── Modals ─────────────────────────────────────────── */}
      {showCancelPopup && (
        <CancelmeetingModal
          isOpen={showCancelPopup}
          meetingData={meetingData}
          onClose={() => setShowCancelPopup(false)}
          onConfirm={handleConfirmCancel}
          isLoading={isLoading}
        />
      )}

      <CompleteMeetingModal
        isOpen={showCompleteModal}
        onClose={() => setShowCompleteModal(false)}
        onConfirm={handleConfirmComplete}
        isLoading={isLoading}
      />

      {successMessage && (
        <SuccessMessage message={successMessage} onClose={() => setSuccessMessage(null)} />
      )}
    </div>
  )
}

export default Viewdetails