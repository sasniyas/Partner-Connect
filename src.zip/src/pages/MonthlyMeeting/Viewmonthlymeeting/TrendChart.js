import React, { useState, useRef, useEffect, useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import Header from "../../../Components/Header";
import { useNavigate } from "react-router-dom";
import Filter from "../../../Components/Filter";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, Menu, Loader2 } from "lucide-react";
import { getAllActionItems } from "../../../services/monthlyMeeting/actionItem/actionItem.service";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../services/download/bluckDownload.service";
import { LabelList } from "recharts";
import html2canvas from "html2canvas";

function TrendChart() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [showChartMenu, setShowChartMenu] = useState(false);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState(null);
  const [chartData, setChartData] = useState([]);
  const [summary, setSummary] = useState(null);
  const [allActionItems, setAllActionItems] = useState([]);
  const [activeKey, setActiveKey] = useState(null);

  const navigate = useNavigate();
  const chartRef = useRef(null);
  const chartContainerRef = useRef(null);
  const menuRef = useRef(null);

  const togglePopup = () => setShowPopup(!showPopup);

  // Filters store arrays for multiple selection
  const [filters, setFilters] = useState({
    year: [],
    marketArea: [],
    dealer: [],
    status: [],
  });

  const [expandedFilters, setExpandedFilters] = useState({
    marketAreas: false,
    dealers: false,
  });

  // Helper function to get array of values from filter (always returns array)
  const getFilterArray = (filterValue) => {
    if (Array.isArray(filterValue)) {
      return filterValue;
    }
    return filterValue ? [filterValue] : [];
  };

  // Helper function to format selected values for display
  const formatSelectedValues = (values, type, maxDisplay = 2) => {
    const arr = getFilterArray(values);
    if (arr.length === 0) return null;

    const isExpanded = expandedFilters[type];

    if (arr.length <= maxDisplay || isExpanded) {
      return (
        <>
          {arr.join(", ")}
          {arr.length > maxDisplay && (
            <span
              className="ml-1 text-SteelBlue1 underline cursor-pointer"
              onClick={() =>
                setExpandedFilters((prev) => ({
                  ...prev,
                  [type]: false,
                }))
              }
            >
              Show less
            </span>
          )}
        </>
      );
    }

    return (
      <>
        {arr.slice(0, maxDisplay).join(", ")}
        <span
          className="ml-1 text-SteelBlue1 underline cursor-pointer"
          onClick={() =>
            setExpandedFilters((prev) => ({
              ...prev,
              [type]: true,
            }))
          }
        >
          +{arr.length - maxDisplay} more
        </span>
      </>
    );
  };

  // ═══════════════════════════════════════════════════════════════
  // FETCH ALL DATA ON MOUNT
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const fetchAllData = async () => {
      setInitialLoading(true);
      setError(null);

      try {
        const actionItemsRes = await getAllActionItems();

        // Process Action Items
        const actionItemsData = actionItemsRes?.data || actionItemsRes || [];
        if (Array.isArray(actionItemsData)) {
          setAllActionItems(actionItemsData);
        }
      } catch (err) {
        console.error("Error fetching data:", err);
        setError("Failed to load data. Please refresh the page.");
      } finally {
        setInitialLoading(false);
      }
    };

    fetchAllData();
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // DEPENDENT FILTER OPTIONS (derived from allActionItems)
  //
  // Year: all unique years (independent)
  // Market Area: depends on Year
  // Dealer: depends on Year + Market Area
  // Status: depends on Year + Market Area + Dealer
  // ═══════════════════════════════════════════════════════════════

  const safeString = (v) => (v || "").toString();

  // Helper: extract year from an action item
  const getItemYear = (item) => {
    if (item.meeting_year) return String(item.meeting_year);
    if (item.meeting_date) {
      const date = new Date(item.meeting_date);
      if (!isNaN(date.getTime())) return String(date.getFullYear());
    }
    return "";
  };

  // Year — independent, all unique years from data
  const yearOptions = useMemo(() => {
    const years = [
      ...new Set(
        allActionItems.map((item) => getItemYear(item)).filter((v) => v)
      ),
    ];
    return years.sort((a, b) => Number(b) - Number(a)); // newest first
  }, [allActionItems]);

  // Market Area — depends on selected Year(s)
  const marketAreaOptions = useMemo(() => {
    let source = allActionItems;
    if (filters.year.length > 0) {
      source = source.filter((item) =>
        filters.year.includes(getItemYear(item))
      );
    }

    const areas = [
      ...new Set(
        source
          .map((item) => safeString(item.marketarea))
          .filter((v) => v && v !== "N/A")
      ),
    ];
    return areas.sort((a, b) => a.localeCompare(b));
  }, [allActionItems, filters.year]);

  // Dealer — depends on selected Year(s) + Market Area(s)
  const dealerOptions = useMemo(() => {
    let source = allActionItems;
    if (filters.year.length > 0) {
      source = source.filter((item) =>
        filters.year.includes(getItemYear(item))
      );
    }
    if (filters.marketArea.length > 0) {
      source = source.filter((item) =>
        filters.marketArea.includes(safeString(item.marketarea))
      );
    }

    const dealerNames = [
      ...new Set(
        source
          .map((item) => safeString(item.dealer_name))
          .filter((v) => v && v !== "N/A")
      ),
    ];
    return dealerNames.sort((a, b) => a.localeCompare(b));
  }, [allActionItems, filters.year, filters.marketArea]);

  // Status — depends on selected Year(s) + Market Area(s) + Dealer(s)
  const statusOptions = useMemo(() => {
    let source = allActionItems;
    if (filters.year.length > 0) {
      source = source.filter((item) =>
        filters.year.includes(getItemYear(item))
      );
    }
    if (filters.marketArea.length > 0) {
      source = source.filter((item) =>
        filters.marketArea.includes(safeString(item.marketarea))
      );
    }
    if (filters.dealer.length > 0) {
      source = source.filter((item) =>
        filters.dealer.includes(safeString(item.dealer_name))
      );
    }

    const statuses = [
      ...new Set(
        source
          .map((item) => safeString(item.status))
          .filter((v) => v && v !== "N/A")
      ),
    ];
    // Custom sort: Open first, In Progress, then Closed
    const order = { Open: 1, "In Progress": 2, Closed: 3 };
    return statuses.sort((a, b) => (order[a] || 99) - (order[b] || 99));
  }, [allActionItems, filters.year, filters.marketArea, filters.dealer]);

  // ═══════════════════════════════════════════════════════════════
  // DEPENDENT FILTER HANDLER
  // Year → Market Area → Dealer → Status (cascade reset)
  // ═══════════════════════════════════════════════════════════════
  const handleFilterChange = (name, value) => {
    setFilters((prev) => {
      const arrayValue = Array.isArray(value) ? value : value ? [value] : [];
      const updated = { ...prev, [name]: arrayValue };

      // Full cascade reset
      if (name === "year") {
        updated.marketArea = [];
        updated.dealer = [];
        updated.status = [];
      }

      if (name === "marketArea") {
        updated.dealer = [];
        updated.status = [];
      }

      if (name === "dealer") {
        updated.status = [];
      }

      return updated;
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // PROCESS CHART DATA WHEN FILTERS CHANGE OR DATA LOADS
  // Now shows ALL data by default, filters narrow down
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    // Don't process while initial loading
    if (initialLoading || allActionItems.length === 0) {
      return;
    }

    const selectedYears = getFilterArray(filters.year);
    const selectedMarketAreas = getFilterArray(filters.marketArea);
    const selectedDealers = getFilterArray(filters.dealer);
    const selectedStatuses = getFilterArray(filters.status);

    setLoading(true);
    setError(null);

    try {
      // Filter action items — empty filter means "show all" for that field
      const filteredItems = allActionItems.filter((item) => {
        const itemYear = getItemYear(item);

        const matchesYear =
          selectedYears.length === 0 || selectedYears.includes(itemYear);

        const matchesMarketArea =
          selectedMarketAreas.length === 0 ||
          selectedMarketAreas.includes(safeString(item.marketarea));

        const matchesDealer =
          selectedDealers.length === 0 ||
          selectedDealers.includes(safeString(item.dealer_name));

        const matchesStatus =
          selectedStatuses.length === 0 ||
          selectedStatuses.includes(safeString(item.status));

        return matchesYear && matchesMarketArea && matchesDealer && matchesStatus;
      });

      // Initialize all 12 months
      const months = [
        { month: 1, name: "January" },
        { month: 2, name: "February" },
        { month: 3, name: "March" },
        { month: 4, name: "April" },
        { month: 5, name: "May" },
        { month: 6, name: "June" },
        { month: 7, name: "July" },
        { month: 8, name: "August" },
        { month: 9, name: "September" },
        { month: 10, name: "October" },
        { month: 11, name: "November" },
        { month: 12, name: "December" },
      ];

      const result = months.map((m) => ({
        month: m.name,
        month_number: m.month,
        Open: 0,
        Ongoing: 0,
        Closed: 0,
      }));

      // Aggregate counts by month and status
      filteredItems.forEach((item) => {
        if (!item.meeting_date) return;

        const meetingDate = new Date(item.meeting_date);
        const monthIndex = meetingDate.getMonth();

        const status = (item.status || "").toLowerCase();
        if (status === "open") {
          result[monthIndex].Open += 1;
        } else if (status === "in progress") {
          result[monthIndex].Ongoing += 1;
        } else if (status === "closed") {
          result[monthIndex].Closed += 1;
        }
      });

      // Calculate totals
      const totals = result.reduce(
        (acc, month) => ({
          totalOpen: acc.totalOpen + month.Open,
          totalOngoing: acc.totalOngoing + month.Ongoing,
          totalClosed: acc.totalClosed + month.Closed,
        }),
        { totalOpen: 0, totalOngoing: 0, totalClosed: 0 }
      );

      setChartData(result);
      setSummary({
        years: selectedYears.length > 0 ? selectedYears : yearOptions,
        marketAreas: selectedMarketAreas,
        dealers: selectedDealers,
        ...totals,
        totalItems: totals.totalOpen + totals.totalOngoing + totals.totalClosed,
      });
    } catch (err) {
      console.error("Error processing chart data:", err);
      setError("Failed to process chart data");
    } finally {
      setLoading(false);
    }
  }, [filters.year, filters.marketArea, filters.dealer, filters.status, allActionItems, initialLoading]);

  const handleBack = () => {
    navigate("/viewmonthlymeeting");
  };

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowChartMenu(false);
      }
    };

    if (showChartMenu) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showChartMenu]);

  // Derived filter values for display/export
  const selectedYears = getFilterArray(filters.year);
  const selectedMarketAreas = getFilterArray(filters.marketArea);
  const selectedDealers = getFilterArray(filters.dealer);
  const selectedStatuses = getFilterArray(filters.status);

  // Check if any filter is active
  const hasActiveFilters =
    selectedYears.length > 0 ||
    selectedMarketAreas.length > 0 ||
    selectedDealers.length > 0 ||
    selectedStatuses.length > 0;

  // Chart always has data once loaded (no required filters)
  const hasChartData = summary && summary.totalItems > 0;

  // Get filtered action items for export
  const getFilteredActionItems = () => {
    return allActionItems.filter((item) => {
      const itemYear = getItemYear(item);

      const matchesYear =
        selectedYears.length === 0 || selectedYears.includes(itemYear);
      const matchesMarketArea =
        selectedMarketAreas.length === 0 ||
        selectedMarketAreas.includes(safeString(item.marketarea));
      const matchesDealer =
        selectedDealers.length === 0 ||
        selectedDealers.includes(safeString(item.dealer_name));
      const matchesStatus =
        selectedStatuses.length === 0 ||
        selectedStatuses.includes(safeString(item.status));

      return matchesYear && matchesMarketArea && matchesDealer && matchesStatus;
    });
  };

  // Format date for display (dd/mm/yyyy)
  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "";
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  // Format name helper
  const formatName = (firstName, lastName) => {
    const first = firstName || "";
    const last = lastName || "";
    return `${first} ${last}`.trim() || "";
  };

  // Build display label for export headers
  const getExportYearsLabel = () => {
    return selectedYears.length > 0 ? selectedYears.join(", ") : "All Years";
  };
  const getExportMarketAreasLabel = () => {
    return selectedMarketAreas.length > 0 ? selectedMarketAreas.join(", ") : "All Market Areas";
  };
  const getExportDealersLabel = () => {
    return selectedDealers.length > 0 ? selectedDealers.join(", ") : "All Dealers";
  };

  // ═══════════════════════════════════════════════════════════════
  // EXPORT
  // ═══════════════════════════════════════════════════════════════
  const handleExportActionItems = async () => {
    setExporting(true);

    try {
      const filteredItems = getFilteredActionItems();

      if (!filteredItems || filteredItems.length === 0) {
        alert("No action items found for the selected filters.");
        setExporting(false);
        togglePopup();
        return;
      }

      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("Action Items");

      sheet.columns = [
        { header: "Sl. No", key: "slNo", width: 8 },
        { header: "Year", key: "year", width: 10 },
        { header: "Meeting Date", key: "meetingDate", width: 15 },
        { header: "Market Area", key: "marketArea", width: 20 },
        { header: "Dealership", key: "dealer", width: 40 },
        { header: "Created Date", key: "createdDate", width: 15 },
        { header: "Created By", key: "createdBy", width: 20 },
        { header: "Topic of Discussion", key: "topic", width: 75 },
        { header: "Department", key: "department", width: 20 },
        { header: "Responsibility", key: "responsibility", width: 25 },
        { header: "Target Date", key: "targetDate", width: 15 },
        { header: "Closed Date", key: "completedDate", width: 18 },
        { header: "Status", key: "status", width: 15 },
        { header: "Closure Action", key: "closureAction", width: 75 },
      ];

      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      filteredItems.forEach((item, index) => {
        const meetingDate = item.meeting_date
          ? new Date(item.meeting_date)
          : null;

        const row = sheet.addRow({
          slNo: index + 1,
          year:
            item.meeting_year ||
            (meetingDate ? meetingDate.getFullYear() : ""),
          meetingDate: formatDate(item.meeting_date),
          department: item.department_name || "",
          topic: item.topic_of_discussion || "",
          closureAction: item.closure_action || "",
          responsibility: formatName(
            item.responsibility_name,
            item.responsibility_lastname
          ),
          targetDate: formatDate(item.target_date),
          completedDate: formatDate(item.completed_date),
          status: item.status || "",
          createdBy: formatName(
            item.created_by_name,
            item.created_by_lastname
          ),
          createdDate: formatDate(item.created_on),
          marketArea: item.marketarea || "",
          dealer: item.dealer_name || "",
        });

        row.eachCell((cell) => {
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const file = new File([blob], "Action_Items.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const response = await uploadTempFile(file);
      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${encodeURIComponent(
            response
          )}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        console.warn("Upload succeeded but no file URL returned");
        alert("Upload succeeded but no preview available.");
      }
    } catch (err) {
      console.error("Failed to export Action Items:", err);
      alert("Failed to export Action Items. Check console for details.");
    } finally {
      setExporting(false);
      togglePopup();
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // CHART EXPORT FUNCTIONS
  // ═══════════════════════════════════════════════════════════════
  const addFilterHeader = () => {
    if (!chartRef.current) return null;

    const header = document.createElement("div");
    header.id = "export-filter-header";
    header.style.cssText =
      "padding: 12px 16px; border-bottom: 1px solid #e5e7eb; background: #ffffff; font-family: Arial, sans-serif;";

    header.innerHTML = `
      <div style="font-size: 11px; color: #555; line-height: 1.6;">
        <span style="font-weight: 600; color: #1B365D;">Years:</span> ${getExportYearsLabel()}
        &nbsp;&nbsp;|&nbsp;&nbsp;
        <span style="font-weight: 600; color: #1B365D;">Market Areas:</span> ${getExportMarketAreasLabel()}
        &nbsp;&nbsp;|&nbsp;&nbsp;
        <span style="font-weight: 600; color: #1B365D;">Dealers:</span> ${getExportDealersLabel()}
        ${selectedStatuses.length > 0 ? `&nbsp;&nbsp;|&nbsp;&nbsp;<span style="font-weight: 600; color: #1B365D;">Status:</span> ${selectedStatuses.join(", ")}` : ""}
      </div>
    `;

    chartRef.current.insertBefore(header, chartRef.current.firstChild);
    return header;
  };

  const removeFilterHeader = () => {
    const header = document.getElementById("export-filter-header");
    if (header) header.remove();
  };

  const handleExportPNG = async () => {
    if (!chartRef.current) return;
    setShowChartMenu(false);

    const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
    tooltips.forEach((t) => (t.style.display = "none"));

    setTimeout(async () => {
      const header = addFilterHeader();
      try {
        const canvas = await html2canvas(chartRef.current, {
          backgroundColor: "#ffffff",
          scale: 2,
          useCORS: true,
        });

        const link = document.createElement("a");
        link.download = `trend-chart${selectedYears.length > 0 ? "-" + selectedYears.join("-") : ""}.png`;
        link.href = canvas.toDataURL("image/png");
        link.click();
      } catch (error) {
        console.error("Error exporting PNG:", error);
      } finally {
        removeFilterHeader();
        tooltips.forEach((t) => (t.style.display = ""));
      }
    }, 200);
  };

  const handleExportJPEG = async () => {
    if (!chartRef.current) return;
    setShowChartMenu(false);

    const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
    tooltips.forEach((t) => (t.style.display = "none"));

    setTimeout(async () => {
      const header = addFilterHeader();
      try {
        const canvas = await html2canvas(chartRef.current, {
          backgroundColor: "#ffffff",
          scale: 2,
          useCORS: true,
          scrollY: -window.scrollY,
        });

        const link = document.createElement("a");
        link.download = `trend-chart${selectedYears.length > 0 ? "-" + selectedYears.join("-") : ""}.jpeg`;
        link.href = canvas.toDataURL("image/jpeg", 0.95);
        link.click();
      } catch (error) {
        console.error("Error exporting JPEG:", error);
      } finally {
        removeFilterHeader();
        tooltips.forEach((t) => (t.style.display = ""));
      }
    }, 200);
  };

  const handleExportSVG = async () => {
    if (!chartRef.current) return;
    setShowChartMenu(false);

    const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
    tooltips.forEach((t) => (t.style.display = "none"));

    setTimeout(async () => {
      const header = addFilterHeader();
      try {
        const canvas = await html2canvas(chartRef.current, {
          backgroundColor: "#ffffff",
          scale: 2,
          useCORS: true,
          scrollY: -window.scrollY,
        });

        const imgData = canvas.toDataURL("image/png");

        const svgContent = `
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="100%" 
    height="100%" 
    viewBox="0 0 ${canvas.width} ${canvas.height}"
    preserveAspectRatio="xMidYMid meet"
  >
    <image 
      href="${imgData}" 
      width="${canvas.width}" 
      height="${canvas.height}" 
    />
  </svg>
`;

        const blob = new Blob([svgContent], {
          type: "image/svg+xml;charset=utf-8",
        });

        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.download = `trend-chart${selectedYears.length > 0 ? "-" + selectedYears.join("-") : ""}.svg`;
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
      } catch (error) {
        console.error("Error exporting SVG:", error);
      } finally {
        removeFilterHeader();
        tooltips.forEach((t) => (t.style.display = ""));
      }
    }, 200);
  };

  const handlePrint = async () => {
    if (!chartRef.current) return;
    setShowChartMenu(false);

    const tooltips = document.querySelectorAll(".recharts-tooltip-wrapper");
    tooltips.forEach((t) => (t.style.display = "none"));

    try {
      await new Promise((resolve) => setTimeout(resolve, 200));

      const canvas = await html2canvas(chartRef.current, {
        backgroundColor: "#ffffff",
        scale: 2,
        useCORS: true,
        scrollY: -window.scrollY,
      });

      const imgData = canvas.toDataURL("image/png");

      const printWindow = window.open("", "", "width=1100,height=800");
      printWindow.document.write(`
        <html>
          <head>
            <title>Trend Chart - Action Items</title>
            <style>
              body {
                margin: 0;
                padding: 20px;
                font-family: Arial, sans-serif;
                text-align: center;
              }
              h1 {
                color: #1e3a5f;
                font-size: 18px;
                margin-bottom: 4px;
              }
              .filters {
                font-size: 12px;
                color: #555;
                margin-bottom: 16px;
              }
              img {
                max-width: 100%;
                height: auto;
                border: 1px solid #e5e7eb;
              }
              @media print {
                body { margin: 0; padding: 10px; }
                img { border: none; }
              }
            </style>
          </head>
          <body>
            <h1>Monthly Meeting Action Items — Trend Chart</h1>
            <div class="filters">
              Years: ${getExportYearsLabel()} &nbsp;|&nbsp; 
              Market Areas: ${getExportMarketAreasLabel()} &nbsp;|&nbsp; 
              Dealers: ${getExportDealersLabel()}
              ${selectedStatuses.length > 0 ? ` &nbsp;|&nbsp; Status: ${selectedStatuses.join(", ")}` : ""}
            </div>
            <img src="${imgData}" alt="Trend Chart" />
          </body>
        </html>
      `);
      printWindow.document.close();

      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.focus();
          printWindow.print();
        }, 300);
      };
    } catch (error) {
      console.error("Error printing chart:", error);
    } finally {
      tooltips.forEach((t) => (t.style.display = ""));
    }
  };

  const [isFullScreen, setIsFullScreen] = useState(false);

  const handleFullScreen = () => {
    const element = chartRef.current;
    if (!element) return;

    if (!document.fullscreenElement) {
      const request =
        element.requestFullscreen ||
        element.webkitRequestFullscreen ||
        element.msRequestFullscreen;

      if (request) {
        request.call(element).catch((err) => {
          console.error("Fullscreen error:", err);
        });
      }
    } else {
      const exit =
        document.exitFullscreen ||
        document.webkitExitFullscreen ||
        document.msExitFullscreen;
      if (exit) exit.call(document);
    }

    setShowChartMenu(false);
  };

  useEffect(() => {
    const handleFullScreenChange = () => {
      setIsFullScreen(!!document.fullscreenElement);
    };

    document.addEventListener("fullscreenchange", handleFullScreenChange);
    document.addEventListener("webkitfullscreenchange", handleFullScreenChange);

    return () => {
      document.removeEventListener("fullscreenchange", handleFullScreenChange);
      document.removeEventListener("webkitfullscreenchange", handleFullScreenChange);
    };
  }, []);

  const handleDownloadCSV = () => {
    try {
      const filterRows = [
        `Years:,"${getExportYearsLabel()}"`,
        `Market Areas:,"${getExportMarketAreasLabel()}"`,
        `Dealers:,"${getExportDealersLabel()}"`,
      ];
      if (selectedStatuses.length > 0) {
        filterRows.push(`Status:,"${selectedStatuses.join(", ")}"`);
      }
      filterRows.push("");

      const headers = ["Month", "Open", "In Progress", "Closed", "Total"];

      const rows = chartData.map((row) => [
        row.month,
        Number(row.Open),
        Number(row.Ongoing),
        Number(row.Closed),
        Number(row.Open) + Number(row.Ongoing) + Number(row.Closed),
      ]);

      const csvContent = [
        ...filterRows,
        headers.join(","),
        ...rows.map((r) => r.join(",")),
      ].join("\n");

      const blob = new Blob(["\uFEFF" + csvContent], {
        type: "text/csv;charset=utf-8;",
      });

      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.download = `trend-chart${selectedYears.length > 0 ? "-" + selectedYears.join("-") : ""}.csv`;
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading CSV:", error);
    }

    setShowChartMenu(false);
  };

  const handleDownloadXLS = async () => {
    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("Trend Chart");

      const filterInfoStyle = { font: { bold: true, color: { argb: "FF1B365D" } }, alignment: { horizontal: "left", vertical: "middle" } };

      const yearRow = sheet.addRow(["Years:", getExportYearsLabel()]);
      yearRow.getCell(1).font = filterInfoStyle.font;

      const areaRow = sheet.addRow(["Market Areas:", getExportMarketAreasLabel()]);
      areaRow.getCell(1).font = filterInfoStyle.font;

      const dealerRow = sheet.addRow(["Dealers:", getExportDealersLabel()]);
      dealerRow.getCell(1).font = filterInfoStyle.font;

      if (selectedStatuses.length > 0) {
        const statusRow = sheet.addRow(["Status:", selectedStatuses.join(", ")]);
        statusRow.getCell(1).font = filterInfoStyle.font;
      }

      sheet.addRow([]);

      const headerRow = sheet.addRow(["Month", "Open", "In Progress", "Closed", "Total"]);
      headerRow.eachCell((cell) => {
        cell.font = { bold: true };
        cell.alignment = { horizontal: "left", vertical: "middle" };
      });

      sheet.getColumn(1).width = 15;
      sheet.getColumn(2).width = 10;
      sheet.getColumn(3).width = 14;
      sheet.getColumn(4).width = 10;
      sheet.getColumn(5).width = 10;

      chartData.forEach((row) => {
        const dataRow = sheet.addRow([
          row.month,
          Number(row.Open),
          Number(row.Ongoing),
          Number(row.Closed),
          Number(row.Open) + Number(row.Ongoing) + Number(row.Closed),
        ]);
        dataRow.eachCell((cell) => {
          cell.alignment = { horizontal: "left", vertical: "middle" };
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();

      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `trend-chart${selectedYears.length > 0 ? "-" + selectedYears.join("-") : ""}.xlsx`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading Excel:", error);
    }

    setShowChartMenu(false);
  };

  const handleViewDataTable = () => {
    const tableWindow = window.open("", "", "width=700,height=600");
    tableWindow.document.write(`
      <html>
        <head>
          <title>Data Table</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
            .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            h2 { color: #1e3a5f; margin-bottom: 5px; }
            .filters { font-size: 12px; color: #666; margin-bottom: 15px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
            th { background-color: #1e3a5f; color: white; }
            tr:nth-child(even) { background-color: #f9f9f9; }
            .total-row { background-color: #e8f4fc !important; font-weight: bold; }
          </style>
        </head>
        <body>
          <div class="container">
            <h2>Monthly Meeting Action Items</h2>
            <div class="filters">
              <p><strong>Years:</strong> ${getExportYearsLabel()}</p>
              <p><strong>Market Areas:</strong> ${getExportMarketAreasLabel()}</p>
              <p><strong>Dealers:</strong> ${getExportDealersLabel()}</p>
              ${selectedStatuses.length > 0 ? `<p><strong>Status:</strong> ${selectedStatuses.join(", ")}</p>` : ""}
            </div>
            <table>
              <thead>
                <tr><th>Month</th><th>Open</th><th>In Progress</th><th>Closed</th><th>Total</th></tr>
              </thead>
              <tbody>
                ${chartData
                  .map(
                    (row) =>
                      `<tr><td>${row.month}</td><td>${row.Open}</td><td>${row.Ongoing}</td><td>${row.Closed}</td><td><strong>${row.Open + row.Ongoing + row.Closed}</strong></td></tr>`
                  )
                  .join("")}
                ${
                  summary
                    ? `<tr class="total-row"><td><strong>TOTAL</strong></td><td><strong>${summary.totalOpen}</strong></td><td><strong>${summary.totalOngoing}</strong></td><td><strong>${summary.totalClosed}</strong></td><td><strong>${summary.totalItems}</strong></td></tr>`
                    : ""
                }
              </tbody>
            </table>
          </div>
        </body>
      </html>
    `);
    tableWindow.document.close();
    setShowChartMenu(false);
  };

  // Chart Colors
  const CHART_COLORS = {
    open: "#0E2941",
    "in progress": "#4FA194",
    closed: "#C17A76",
  };

  // Custom Tooltip
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const total = payload.reduce((sum, entry) => sum + entry.value, 0);
      return (
        <div className="bg-white p-3 border border-gray-200 rounded shadow-md">
          <p className="font-medium text-gray-800 mb-2 pb-1 border-b text-sm">
            {label}
          </p>
          {payload.map((entry, index) => (
            <div
              key={index}
              className="flex justify-between items-center gap-4 text-xs py-0.5"
            >
              <span className="flex items-center gap-2">
                <span
                  className="w-2.5 h-2.5 rounded-sm"
                  style={{ backgroundColor: entry.fill }}
                ></span>
                {entry.name}:
              </span>
              <span className="font-medium">{entry.value}</span>
            </div>
          ))}
          <div className="flex justify-between items-center gap-4 text-xs font-semibold text-gray-700 mt-2 pt-1 border-t">
            <span>Total:</span>
            <span>{total}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[5rem] p-2 lg:px-4">
          <div className="w-full max-w-7xl mx-auto">
            {/* Page Header */}
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-4 pt-3">
              <div>
                <div className="flex items-center gap-2 text-sm font-semibold font-VolvoNovum text-darkblue1">
                  <ArrowLeft
                    onClick={handleBack}
                    size={22}
                    className="cursor-pointer hover:scale-105 transition text-white bg-darkblue1 p-1"
                  />
                  Trend Chart - Action Items
                </div>
                <hr className="hidden lg:block w-[50%] border-t-2 border-darkblue1 mt-1 ml-7" />
              </div>

              <button
                onClick={togglePopup}
                disabled={loading || initialLoading || !hasChartData}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded transition ${
                  !loading && !initialLoading && hasChartData
                    ? "bg-darkblue1 text-white hover:bg-opacity-90"
                    : "bg-gray-200 text-gray-400 cursor-not-allowed"
                }`}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 21 21"
                  fill="none"
                  className={`w-3 h-3 ${
                    loading || initialLoading || !hasChartData
                      ? "opacity-50"
                      : ""
                  }`}
                >
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M16.17 7.2615C15.9591 7.47218 15.6731 7.59051 15.375 7.59051C15.0769 7.59051 14.7909 7.47218 14.58 7.2615L11.625 4.3065V15.375C11.625 15.6734 11.5065 15.9595 11.2955 16.1705C11.0845 16.3815 10.7984 16.5 10.5 16.5C10.2016 16.5 9.91548 16.3815 9.7045 16.1705C9.49353 15.9595 9.375 15.6734 9.375 15.375V4.3065L6.42 7.2615C6.20674 7.46022 5.92467 7.5684 5.63322 7.56326C5.34176 7.55812 5.06369 7.44005 4.85757 7.23393C4.65145 7.02781 4.53338 6.74974 4.52824 6.45828C4.5231 6.16683 4.63128 5.88476 4.83 5.6715L9.705 0.7965L10.5 0L11.295 0.795L16.17 5.67C16.2745 5.77448 16.3575 5.89853 16.4141 6.03506C16.4706 6.1716 16.4998 6.31795 16.4998 6.46575C16.4998 6.61355 16.4706 6.7599 16.4141 6.89644C16.3575 7.03297 16.2745 7.15702 16.17 7.2615ZM2.25 13.125C2.25 12.8266 2.13147 12.5405 1.9205 12.3295C1.70952 12.1185 1.42337 12 1.125 12C0.826631 12 0.540483 12.1185 0.329505 12.3295C0.118526 12.5405 4.44604e-09 12.8266 0 13.125V18C0 18.7956 0.316071 19.5587 0.87868 20.1213C1.44129 20.6839 2.20435 21 3 21H18C18.7956 21 19.5587 20.6839 20.1213 20.1213C20.6839 19.5587 21 18.7956 21 18V13.125C21 12.8266 20.8815 12.5405 20.6705 12.3295C20.4595 12.1185 20.1734 12 19.875 12C19.5766 12 19.2905 12.1185 19.0795 12.3295C18.8685 12.5405 18.75 12.8266 18.75 13.125V18C18.75 18.1989 18.671 18.3897 18.5303 18.5303C18.3897 18.671 18.1989 18.75 18 18.75H3C2.80109 18.75 2.61032 18.671 2.46967 18.5303C2.32902 18.3897 2.25 18.1989 2.25 18V13.125Z"
                    fill="white"
                  />
                </svg>
                Export Action Items
              </button>
            </div>

            {/* ═══════════════════════════════════════════════════════════ */}
            {/* FILTERS — All optional, narrow down from full data          */}
            {/* Dependent: Year → Market Area → Dealer → Status            */}
            {/* ═══════════════════════════════════════════════════════════ */}
            <div className="flex flex-wrap gap-2 mb-5">
              {/* Year — independent, options from table data */}
              <Filter
                name="year"
                value={filters.year}
                options={yearOptions}
                onChange={handleFilterChange}
                placeholder="Year"
                placeholderColor="text-black"
                textColor="text-black"
                buttonBorderColor="border-gray-300"
                dropdownBorderColor="border-gray-300"
                dropdownHoverColor="hover:bg-gray-50"
                customWidth="w-full sm:w-32"
                multiple={true}
              />
              {/* Market Area — depends on Year */}
              <Filter
                name="marketArea"
                value={filters.marketArea}
                options={marketAreaOptions}
                onChange={handleFilterChange}
                placeholder="Market Area"
                placeholderColor="text-black"
                textColor="text-black"
                buttonBorderColor="border-gray-300"
                dropdownBorderColor="border-gray-300"
                dropdownHoverColor="hover:bg-gray-50"
                customWidth="w-full sm:w-40"
                multiple={true}
              />
              {/* Dealer — depends on Year + Market Area */}
              <Filter
                name="dealer"
                value={filters.dealer}
                options={dealerOptions}
                onChange={handleFilterChange}
                placeholder="Dealership"
                placeholderColor="text-black"
                textColor="text-black"
                buttonBorderColor="border-gray-300"
                dropdownBorderColor="border-gray-300"
                dropdownHoverColor="hover:bg-gray-50"
                customWidth="w-full sm:w-48"
                multiple={true}
              />
              {/* Status — depends on Year + Market Area + Dealer */}
              <Filter
                name="status"
                value={filters.status}
                options={statusOptions}
                onChange={handleFilterChange}
                placeholder="Status"
                placeholderColor="text-black"
                textColor="text-black"
                buttonBorderColor="border-gray-300"
                dropdownBorderColor="border-gray-300"
                dropdownHoverColor="hover:bg-gray-50"
                customWidth="w-full sm:w-36"
                multiple={true}
              />
            </div>

            {/* Selected Filters Summary — only show when filters are active */}
            {hasActiveFilters && (
              <div className="flex flex-wrap gap-2 mb-4">
                {selectedYears.length > 0 && (
                  <span className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded">
                    Years: {selectedYears.join(", ")}
                  </span>
                )}

                {selectedMarketAreas.length > 0 && (
                  <span className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded">
                    Areas:{" "}
                    {formatSelectedValues(
                      selectedMarketAreas,
                      "marketAreas",
                      2
                    )}
                  </span>
                )}

                {selectedDealers.length > 0 && (
                  <span className="text-xs bg-purple-50 text-purple-700 px-2 py-1 rounded">
                    Dealers:{" "}
                    {formatSelectedValues(selectedDealers, "dealers", 2)}
                  </span>
                )}

                {selectedStatuses.length > 0 && (
                  <span className="text-xs bg-orange-50 text-orange-700 px-2 py-1 rounded">
                    Status: {selectedStatuses.join(", ")}
                  </span>
                )}
              </div>
            )}

            {/* Error State */}
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-3 py-2 rounded text-xs mb-4">
                {error}
              </div>
            )}

            {/* Content States */}
            {initialLoading ? (
              <div className="bg-white rounded shadow-sm border border-gray-200 p-10 flex flex-col items-center justify-center min-h-[400px]">
                <Loader2 className="w-8 h-8 text-darkblue1 animate-spin mb-3" />
                <p className="text-gray-500 text-sm">Loading data...</p>
              </div>
            ) : loading ? (
              <div className="bg-white rounded shadow-sm border border-gray-200 p-10 flex flex-col items-center justify-center min-h-[400px]">
                <Loader2 className="w-8 h-8 text-darkblue1 animate-spin mb-3" />
                <p className="text-gray-500 text-sm">
                  Processing chart data...
                </p>
              </div>
            ) : summary && summary.totalItems === 0 ? (
              <div className="bg-white rounded shadow-sm border border-dashed border-gray-300 p-10 flex flex-col items-center justify-center min-h-[400px]">
                <svg
                  className="w-16 h-16 text-gray-300 mb-3"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={1.5}
                    d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
                  />
                </svg>
                <h3 className="text-base font-medium text-gray-500 mb-1">
                  No Action Items Found
                </h3>
                <p className="text-gray-400 text-center text-xs">
                  {hasActiveFilters
                    ? "No data found for the selected filters. Try adjusting your filters."
                    : "No action items available."}
                </p>
              </div>
            ) : (
              <div
                className={`bg-white rounded shadow-sm border border-gray-200 p-5 ${
                  isFullScreen
                    ? "!w-screen !h-screen !fixed !inset-0 !z-[9999] !rounded-none !border-none flex flex-col"
                    : ""
                }`}
                ref={chartRef}
              >
                {/* HEADER ROW */}
                <div className="flex items-center justify-between ">
                  {/* LEFT: HEADING */}
                  <h2 className="text-sm font-semibold text-darkblue1 font-VolvoNovum whitespace-nowrap">
                    Monthly Meeting Action Items
                    {!hasActiveFilters && (
                      <span className="text-xs font-normal text-gray-400 ml-2">(All Data)</span>
                    )}
                  </h2>

                  {/* RIGHT: SUMMARY + MENU */}
                  <div className="flex items-center gap-4">
                    {/* SUMMARY BADGES */}
                    {summary && (
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-slate-100 border border-slate-200">
                          <span className="text-xs text-slate-600">Open</span>
                          <span className="text-xs font-semibold text-slate-800">
                            {summary.totalOpen}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-emerald-50 border border-emerald-100">
                          <span className="text-xs text-slate-600">
                            In Progress
                          </span>
                          <span className="text-xs font-semibold text-slate-800">
                            {summary.totalOngoing}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-rose-50 border border-rose-100">
                          <span className="text-xs text-slate-600">Closed</span>
                          <span className="text-xs font-semibold text-slate-800">
                            {summary.totalClosed}
                          </span>
                        </div>

                        <div className="px-3 py-1.5 rounded-md bg-gray-100 border border-gray-200 text-xs font-semibold text-gray-800">
                          Total: {summary.totalItems}
                        </div>
                      </div>
                    )}

                    {/* MENU ICON */}
                    <div className="relative" ref={menuRef}>
                      <button
                        onClick={() => setShowChartMenu(!showChartMenu)}
                        className="p-1.5 hover:bg-gray-100 rounded transition"
                      >
                        <Menu size={16} className="text-gray-500" />
                      </button>

                      {showChartMenu && (
                        <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-gray-200 rounded shadow-lg z-50 py-1">
                          <button
                            onClick={handleFullScreen}
                            className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
                          >
                            View full screen
                          </button>

                          <button
                            onClick={handlePrint}
                            className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
                          >
                            Print chart
                          </button>

                          <div className="border-t border-gray-100 my-1"></div>

                          <button
                            onClick={handleExportPNG}
                            className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
                          >
                            Download PNG
                          </button>

                          <button
                            onClick={handleExportJPEG}
                            className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
                          >
                            Download JPEG
                          </button>

                          <button
                            onClick={handleExportSVG}
                            className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
                          >
                            Download SVG
                          </button>

                          <div className="border-t border-gray-100 my-1"></div>

                          <button
                            onClick={handleDownloadCSV}
                            className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
                          >
                            Download CSV
                          </button>

                          <button
                            onClick={handleDownloadXLS}
                            className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
                          >
                            Download XLS
                          </button>

                          <button
                            onClick={handleViewDataTable}
                            className="w-full px-3 py-1.5 text-left text-xs text-gray-600 hover:bg-gray-50"
                          >
                            View data table
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div ref={chartContainerRef} className={isFullScreen ? "flex-1 min-h-0" : ""}>
                  <ResponsiveContainer width="100%" height={isFullScreen ? "100%" : 400}>
                    <BarChart
                      data={chartData}
                      margin={{ top: 10, right: 30, left: 10, bottom: 5 }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="#e5e7eb"
                        vertical={false}
                      />
                      <XAxis
                        dataKey="month"
                        tick={{ fontSize: 11, fill: "#4b5563" }}
                        axisLine={{ stroke: "#d1d5db" }}
                        tickLine={false}
                        interval={0}
                        angle={0}
                        textAnchor="end"
                        height={70}
                      />
                      <YAxis
                        tick={{ fontSize: 11, fill: "#4b5563" }}
                        axisLine={{ stroke: "#d1d5db" }}
                        tickLine={false}
                        allowDecimals={false}
                        label={{
                          value: "No. of Action Items",
                          angle: -90,
                          position: "insideLeft",
                          style: {
                            fontSize: 12,
                            fill: "#4b5563",
                            fontWeight: 500,
                          },
                          offset: 0,
                        }}
                        width={60}
                      />
                      <Tooltip
                        content={<CustomTooltip />}
                        cursor={{ fill: "rgba(0, 0, 0, 0.03)" }}
                      />
                      <Legend
                        verticalAlign="top"
                        align="center"
                        iconType="square"
                        iconSize={10}
                        wrapperStyle={{ paddingBottom: 10 }}
                        onClick={(e) => {
                          const key = e.dataKey;
                          if (activeKey === key) {
                            setActiveKey(null);
                          } else {
                            setActiveKey(key);
                          }
                        }}
                        formatter={(value) => (
                          <span
                            style={{
                              fontSize: "12px",
                              color: "#374151",
                              marginLeft: "4px",
                            }}
                          >
                            {value}
                          </span>
                        )}
                      />
                      <Bar
                        dataKey="Open"
                        name="Open"
                        fill={CHART_COLORS.open}
                        radius={[2, 2, 0, 0]}
                        maxBarSize={35}
                        opacity={
                          activeKey && activeKey !== "Open" ? 0.2 : 1
                        }
                      >
                        <LabelList
                          dataKey="Open"
                          position="top"
                          formatter={(value) => (value > 0 ? value : "")}
                          style={{
                            fontSize: 11,
                            fill: "#374151",
                            fontWeight: 500,
                          }}
                        />
                      </Bar>

                      <Bar
                        dataKey="Ongoing"
                        name="In Progress"
                        fill={CHART_COLORS["in progress"]}
                        radius={[2, 2, 0, 0]}
                        maxBarSize={35}
                        opacity={
                          activeKey && activeKey !== "Ongoing" ? 0.2 : 1
                        }
                      >
                        <LabelList
                          dataKey="Ongoing"
                          position="top"
                          formatter={(value) => (value > 0 ? value : "")}
                          style={{
                            fontSize: 11,
                            fill: "#374151",
                            fontWeight: 500,
                          }}
                        />
                      </Bar>

                      <Bar
                        dataKey="Closed"
                        name="Closed"
                        fill={CHART_COLORS.closed}
                        radius={[2, 2, 0, 0]}
                        maxBarSize={35}
                        opacity={
                          activeKey && activeKey !== "Closed" ? 0.2 : 1
                        }
                      >
                        <LabelList
                          dataKey="Closed"
                          position="top"
                          formatter={(value) => (value > 0 ? value : "")}
                          style={{
                            fontSize: 11,
                            fill: "#374151",
                            fontWeight: 500,
                          }}
                        />
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Export Popup */}
      {showPopup && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-lg p-5 max-w-md w-full">
            <h3 className="text-sm font-semibold text-darkblue1 mb-3">
              Export Action Items
            </h3>
            <div className="bg-gray-50 rounded p-3 mb-4 text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-500">Years:</span>
                <span className="font-medium text-gray-700 text-right max-w-[200px]">
                  {getExportYearsLabel()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Market Areas:</span>
                <span className="font-medium text-gray-700 text-right max-w-[200px]">
                  {selectedMarketAreas.length > 0
                    ? formatSelectedValues(selectedMarketAreas, "marketAreas", 3)
                    : "All"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Dealers:</span>
                <span className="font-medium text-gray-700 text-right max-w-[200px]">
                  {selectedDealers.length > 0
                    ? formatSelectedValues(selectedDealers, "dealers", 3)
                    : "All"}
                </span>
              </div>
              {selectedStatuses.length > 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Status:</span>
                  <span className="font-medium text-gray-700 text-right max-w-[200px]">
                    {selectedStatuses.join(", ")}
                  </span>
                </div>
              )}
              {summary && (
                <div className="flex justify-between pt-2 mt-2 border-t border-gray-200">
                  <span className="text-gray-500">Total Items:</span>
                  <span className="font-semibold text-darkblue1">
                    {summary.totalItems}
                  </span>
                </div>
              )}
            </div>
            <div className="flex justify-end gap-2">
              <button
                onClick={togglePopup}
                className="px-3 py-1.5 text-xs text-gray-600 hover:bg-gray-100 rounded border border-gray-300"
                disabled={exporting}
              >
                Cancel
              </button>
              <button
                onClick={handleExportActionItems}
                disabled={exporting}
                className="px-3 py-1.5 text-xs bg-darkblue1 text-white rounded hover:bg-opacity-90 flex items-center gap-1.5"
              >
                {exporting ? (
                  <>
                    <Loader2 className="w-3 h-3 animate-spin" />
                    Exporting...
                  </>
                ) : (
                  <>
                    <svg
                      className="w-3 h-3"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                      />
                    </svg>
                    Export to Excel
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default TrendChart;