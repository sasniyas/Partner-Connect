import React, { useState, useEffect } from "react";
import Header from "../../../../Components/Header";
import { useNavigate } from "react-router-dom";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import Actionitem from "./Actionitem";

function Actionitemhome() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isMonthlyDropdownOpen, setIsMonthlyDropdownOpen] = useState(false);
  const [isActionDropdownOpen, setIsActionDropdownOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
<div className="bg-Frostwhite min-h-screen  flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300  ${
          menuOpen ? "ml-60" : ""
        }`}
      >
                <div className="w-full mt-[4.5rem] lg:mt-[6rem]">

        {/* Top Navigation Tabs with Dropdowns */}
        <div className="flex w-full relative z-10">
          {/* Monthly Meeting Tab (Inactive) */}
          <div
            className="w-1/2 relative text-center bg-grey2 border-b-2 border-grey2"
            onMouseEnter={() => setIsMonthlyDropdownOpen(true)}
            onMouseLeave={() => setIsMonthlyDropdownOpen(false)}
          >
            <button
              className="w-full py-2.5 text-sm text-black font-medium"
              onClick={() => navigate("/viewmonthlymeeting")}
            >
              Monthly Meeting
            </button>

            {isMonthlyDropdownOpen && (
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-0 bg-white px-6 py-4 w-[500px]">
                <ul className="flex items-center justify-center text-xs font-normal space-x-4 text-center">
                  <li
                    className="hover:text-darkblue1 hover:font-bold whitespace-nowrap cursor-pointer"
                    onClick={() => navigate("/monthlymeetinghomepage")}
                  >
                    Create Monthly Meeting
                  </li>
                  <div className="h-6 w-px bg-gray-300" />
                  <li
                    className="hover:text-darkblue1 hover:font-bold whitespace-nowrap cursor-pointer"
                    onClick={() => navigate("/viewmonthlymeeting")}
                  >
                    View Monthly Meeting
                  </li>
                </ul>
              </div>
            )}
          </div>

          {/* Action Items Tab (Active) */}
          <div className="w-1/2 relative text-center bg-white border-b-2 border-SteelBlue1">
            <button
              onClick={() => navigate("/actionitemhomepage")}
              className="w-full py-2.5 text-sm text-SteelBlue1 font-medium"
            >
              Action Items
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="w-full flex justify-center  ">
  <div className="w-full   transition-all duration-300 ease-in-out">
    <Actionitem />
  </div>
</div>

      </div>
    </div>
    </div>
  );
}

export default Actionitemhome;