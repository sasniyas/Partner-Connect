import React, { useState, useEffect, useRef } from "react";

const CommentPopup = ({ actionItemData, onClose }) => {
  const modalRef = useRef(null);
  
  const [editingIndex, setEditingIndex] = useState(null);
  const [editedComment, setEditedComment] = useState("");

  // Close on ESC key
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    document.addEventListener("keydown", handleEsc);
    return () => document.removeEventListener("keydown", handleEsc);
  }, [onClose]);

  // Close on click outside
  const handleBackdropClick = (e) => {
    if (modalRef.current && !modalRef.current.contains(e.target)) {
      onClose();
    }
  };

  const handleEditClick = (index, currentText) => {
    setEditingIndex(index);
    setEditedComment(currentText);
  };

  const handleCancelEdit = () => {
    setEditingIndex(null);
    setEditedComment("");
  };

  const handleSaveComment = (index) => {
    // In real implementation, this would call an API to save the comment
    setEditingIndex(null);
    setEditedComment("");
  };

  // Check if we have comments
  const hasComments = actionItemData?.comments && actionItemData.comments.trim() !== '';

  return (
    <div 
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={handleBackdropClick}
    >
      <div 
        ref={modalRef}
        className="bg-white rounded-lg shadow-2xl px-6 py-6 w-full max-w-3xl max-h-[80vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex justify-between items-center mb-0">
          <h2 className="text-base text-black font-semibold">Comments</h2>
          <button 
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors duration-200"
          >
            <img 
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" 
              alt="close" 
              className="w-5 h-5" 
            />
          </button>
        </div>
        <hr className="w-[10%] border-t-2 ml-[1px] border-darkorange mb-4" />

        {/* Action Item Info */}
        {actionItemData && (
          <div className="bg-gray-50 border border-gray-200 rounded p-3 mb-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
              <div>
                <span className="font-medium text-gray-600">Department:</span>
                <span className="ml-2 text-gray-800">{actionItemData.department || '-'}</span>
              </div>
              <div>
                <span className="font-medium text-gray-600">Responsibility:</span>
                <span className="ml-2 text-gray-800">{actionItemData.responsibility || '-'}</span>
              </div>
              <div className="md:col-span-2">
                <span className="font-medium text-gray-600">Topic:</span>
                <span className="ml-2 text-gray-800">{actionItemData.topicOfDiscussion || '-'}</span>
              </div>
            </div>
          </div>
        )}

        {/* Comments Section */}
        {hasComments ? (
          <div className="border border-Dustyblue rounded-md overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-Dustyblue text-white">
                <tr>
                  <th className="text-left px-4 py-2 font-medium text-xs">Date</th>
                  <th className="text-left px-4 py-2 font-medium text-xs">Created By</th>
                  <th className="text-left px-4 py-2 font-medium text-xs">Comments</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-t text-black/80 hover:bg-gray-50">
                  <td className="px-4 py-3 text-xs whitespace-nowrap align-top">
                    {actionItemData.createdDate || '-'}
                  </td>
                  <td className="px-4 py-3 text-xs whitespace-nowrap align-top">
                    {actionItemData.createdBy || '-'}
                  </td>
                  <td className="px-4 py-3 text-xs align-top">
                    {editingIndex === 0 ? (
                      <div>
                        <textarea
                          value={editedComment}
                          onChange={(e) => setEditedComment(e.target.value)}
                          className="w-full border border-gray-300 rounded px-2 py-1 text-xs resize-none focus:outline-none focus:ring-1 focus:ring-darkblue1"
                          rows={3}
                        />
                        <div className="flex gap-2 mt-2">
                          <button
                            onClick={handleCancelEdit}
                            className="text-red1 text-xs font-medium border border-red1 px-3 py-1 rounded hover:bg-red1 hover:text-white transition duration-200"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleSaveComment(0)}
                            className="text-darkblue1 text-xs font-medium border border-darkblue1 px-3 py-1 rounded hover:bg-darkblue1 hover:text-white transition duration-200"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex justify-between items-start gap-2">
                        <span className="break-words whitespace-pre-wrap">{actionItemData.comments}</span>
                        <div className="relative group flex-shrink-0">
                          <img
                            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/edit.png"
                            alt="Edit"
                            className="w-4 h-4 cursor-pointer hover:scale-110 transition-transform"
                            onClick={() => handleEditClick(0, actionItemData.comments)}
                          />
                          <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-gray-800 text-white text-[10px] rounded px-2 py-0.5 whitespace-nowrap pointer-events-none">
                            Edit
                          </span>
                        </div>
                      </div>
                    )}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        ) : (
          <div className="bg-amber-50 text-amber-700 px-4 py-4 rounded-md border border-amber-200">
            <div className="flex items-center justify-center gap-2">
              <img 
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/warning.png" 
                alt="warning" 
                className="w-4 h-4" 
              />
              <p className="text-sm font-medium">
                There are no comments for this action item.
              </p>
            </div>
          </div>
        )}

        {/* Close Button */}
        <div className="flex justify-end mt-4">
          <button
            onClick={onClose}
            className="px-6 py-1.5 bg-darkblue1 text-xs text-white hover:bg-opacity-80 transition-colors rounded"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default CommentPopup;