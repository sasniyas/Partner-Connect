import React, { useState, useRef, useEffect, useCallback } from "react";
import { API } from "../../../../api";
import Filter from "../../../../Components/Filter";
import DownloadPopup from "../../../../Components/Downloadpopup";
import DeleteModal from "../../../../Components/DeleteModal";
import Searchinput from "../../../../Components/Searchinput";
import { ChevronDown, ChevronUp, MoreVertical, Menu, X, ChevronsUpDown, ArrowUp, ArrowDown } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { getAllActionItems, deleteActionItem } from "../../../../services/monthlyMeeting/actionItem/actionItem.service";
import { getDepartments } from "../../../../services/monthlyMeetingMaster/departmentMaster.service";
import { getMarketAreas } from "../../../../services/pdpMaster/marketArea.service";
import { getDealers } from "../../../../services/pdpMaster/dealership.service";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../../services/download/bluckDownload.service";
import { useMemo } from "react";
import LogActionitemPopup from "../../Viewmonthlymeeting/LogActionitemPopup";
import ExpandableTargetDate from "../../../../Components/Expandabletargetdate";

// Expandable Text Component for long text in table cells
const ExpandableText = ({ text, maxLines = 2 }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [needsExpansion, setNeedsExpansion] = useState(false);
  const textRef = useRef(null);

  useEffect(() => {
    if (textRef.current) {
      const lineHeight = parseInt(window.getComputedStyle(textRef.current).lineHeight) || 16;
      const maxHeight = lineHeight * maxLines;
      setNeedsExpansion(textRef.current.scrollHeight > maxHeight + 5);
    }
  }, [text, maxLines]);

  if (!text || text === "N/A") return <span className="text-gray-400">-</span>;

  return (
    <div className="relative">
      <div
        ref={textRef}
        className="whitespace-pre-wrap break-words transition-all duration-200"
        style={
          !isExpanded && needsExpansion
            ? {
                display: "-webkit-box",
                WebkitLineClamp: maxLines,
                WebkitBoxOrient: "vertical",
                overflow: "hidden",
              }
            : {}
        }
      >
        {text}
      </div>
      {needsExpansion && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setIsExpanded(!isExpanded);
          }}
          className="text-blue-600 hover:text-blue-800 text-[10px] font-medium mt-0.5 hover:underline"
        >
          {isExpanded ? "Show less" : "Show more"}
        </button>
      )}
    </div>
  );
};

const Actionitem = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { state } = location;

  const [filters, setFilters] = useState({
    year: [],
    marketArea: [],
    dealer: [],
    department: [],
    status: [],
  });

  const [tableData, setTableData] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [marketAreas, setMarketAreas] = useState([]);
  const [dealers, setDealers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [searchText, setSearchText] = useState("");
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [dropdownId, setDropdownId] = useState(null);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0 });
  const [showPopup, setShowPopup] = useState(false);
  const [isLogsPopupOpen, setIsLogsPopupOpen] = useState(false);
  const [logsData, setLogsData] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [rowToDelete, setRowToDelete] = useState(null);

  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState("table");
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);
  const [hoveredCell, setHoveredCell] = useState(null);

  // ========== SCROLL STATES ==========
  const tableContainerRef = useRef(null);
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollDirection, setScrollDirection] = useState(null);
  const [lastScrollTop, setLastScrollTop] = useState(0);

  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    if (scrollTop > lastScrollTop) {
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: tableContainerRef.current.scrollHeight, behavior: "smooth" });
    }
  };

  const [selectedRow, setSelectedRow] = useState(null);

  // ═══════════════════════════════════════════════════════════════
  // CURRENT USER & ROLE DETECTION
  // ═══════════════════════════════════════════════════════════════
  const [currentUserId, setCurrentUserId] = useState(null);
  const [currentUserRole, setCurrentUserRole] = useState(null);

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const userData = localStorage.getItem("userData");
        if (userData) {
          const parsed = JSON.parse(userData);
          if (parsed?.id) setCurrentUserId(parsed.id);
          // Check persona first (SubNavbar3 uses userData.persona for role checks)
          if (parsed?.persona) setCurrentUserRole(parsed.persona?.toLowerCase());
          else if (parsed?.role) setCurrentUserRole(parsed.role?.toLowerCase());
          else if (parsed?.userRole) setCurrentUserRole(parsed.userRole?.toLowerCase());
          else if (parsed?.user_role) setCurrentUserRole(parsed.user_role?.toLowerCase());
          return;
        }

        const token =
          localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return;

        if (localStorage.getItem("superUserToken")) {
          setCurrentUserRole("admin");
        }

        const response = await fetch(
          `${API.domain}${API.userManagement.logedInUser}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const result = await response.json();
        if (result?.data?.id) setCurrentUserId(result.data.id);
        if (result?.data?.persona) setCurrentUserRole(result.data.persona?.toLowerCase());
        else if (result?.data?.role) setCurrentUserRole(result.data.role?.toLowerCase());
      } catch (err) {
        console.warn("Failed to fetch current user:", err);
      }
    };
    fetchCurrentUser();
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // PERMISSION HELPERS
  // ═══════════════════════════════════════════════════════════════
  const isAdmin = useCallback(() => {
    // Only check role/persona - do NOT use superUserToken here
    // superUserToken just means the session was initiated by admin, not that the current user IS admin
    return (
      currentUserRole === "admin" ||
      currentUserRole === "administrator" ||
      currentUserRole === "superadmin" ||
      currentUserRole === "super_admin"
    );
  }, [currentUserRole]);

  const isCreator = useCallback(
    (item) => {
      if (!currentUserId) return false;
      const createdById =
        item.createdById || item.originalData?.created_by || item.created_by;
      return currentUserId === createdById || currentUserId === parseInt(createdById, 10);
    },
    [currentUserId]
  );

  const isResponsiblePerson = useCallback(
    (item) => {
      if (!currentUserId) return false;
      const responsibilityId =
        item.responsibilityId || item.originalData?.responsibility || item.responsibility_id;
      return (
        currentUserId === responsibilityId ||
        currentUserId === parseInt(responsibilityId, 10)
      );
    },
    [currentUserId]
  );

  const canViewItem = useCallback(
    (item) => {
      if (isAdmin()) return true;
      if (isCreator(item)) return true;
      if (isResponsiblePerson(item)) return true;
      return false;
    },
    [isAdmin, isCreator, isResponsiblePerson]
  );

  const canFullEdit = useCallback(
    (item) => {
      if (isAdmin()) return true;
      if (isCreator(item)) return true;
      return false;
    },
    [isAdmin, isCreator]
  );

  const canLimitedEdit = useCallback(
    (item) => {
      if (isAdmin()) return false;
      if (isCreator(item)) return false;
      if (isResponsiblePerson(item)) return true;
      return false;
    },
    [isAdmin, isCreator, isResponsiblePerson]
  );

  const canDelete = useCallback(
    (item) => {
      if (isAdmin()) return true;
      return false;
    },
    [isAdmin]
  );

  const getEditAction = (row) => {
    if (row.status === "Closed" && !isAdmin()) {
      return { label: "View", type: "view" };
    }
    if (row.status === "Closed" && isAdmin()) {
      return { label: "Edit", type: "full_edit" };
    }
    if (canLimitedEdit(row)) {
      return { label: "Update", type: "limited_edit" };
    }
    if (canFullEdit(row)) {
      return { label: "Edit", type: "full_edit" };
    }
    return { label: "View", type: "view" };
  };

  // ═══════════════════════════════════════════════════════════════
  // TABLE COLUMNS & SORT
  // ═══════════════════════════════════════════════════════════════
  const columns = [
    { label: "Year", key: "year", width: "w-[3%]" },
    { label: "Meeting Date", key: "meetingDate", width: "w-[6%]" },
    { label: "Market Area", key: "marketArea", width: "w-[6%]" },
    { label: "Dealership", key: "dealership", width: "w-[7%]" },
    { label: "Created Date", key: "createdDate", width: "w-[6%]" },
    { label: "Created By", key: "createdBy", width: "w-[6%]" },
    { label: "Topic of Discussion", key: "topicOfDiscussion", width: "w-[15%]" },
    { label: "Department", key: "department", width: "w-[6%]" },
    { label: "Responsibility", key: "responsibility", width: "w-[7%]" },
    { label: "Target Date", key: "targetDate", width: "w-[6%]" },
    { label: "Closed Date", key: "closedDate", width: "w-[6%]" },
    { label: "Status", key: "status", width: "w-[4%]" },
    { label: "Closure Action", key: "closureAction", width: "w-[15%]" },
  ];

  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState("normal");

  const handleSort = (key) => {
    if (sortKey !== key) {
      setSortKey(key);
      setSortOrder("asc");
    } else {
      setSortOrder((prev) =>
        prev === "normal" ? "asc" : prev === "asc" ? "desc" : "normal"
      );
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // FETCH DATA
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        const [departmentsData, marketAreasData, dealersData, actionItemsResponse] =
          await Promise.all([
            getDepartments(),
            getMarketAreas(),
            getDealers(),
            getAllActionItems(),
          ]);

        setDepartments(departmentsData);
        setMarketAreas(marketAreasData);
        setDealers(dealersData);

        if (actionItemsResponse.status && actionItemsResponse.data) {
          const transformedData = actionItemsResponse.data.map((item) => {
            const formatDate = (dateString) => {
              if (!dateString) return "N/A";
              try {
                const date = new Date(dateString);
                if (isNaN(date.getTime())) return "N/A";
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, "0");
                const day = String(date.getDate()).padStart(2, "0");
                return `${day}/${month}/${year}`;
              } catch (error) {
                return "N/A";
              }
            };

            const formatName = (firstName, lastName) => {
              const first = firstName || "";
              const last = lastName || "";
              const fullName = `${first} ${last}`.trim();
              return fullName || "N/A";
            };

            return {
              id: item.id,
              year: item.meeting_year || new Date().getFullYear(),
              marketArea: item.marketarea || "N/A",
              dealer: item.dealer_name || "N/A",
              createdDate: formatDate(item.created_on),
              createdBy: formatName(item.created_by_name, item.created_by_lastname),
              createdById: item.created_by,
              department: item.department_name || "N/A",
              topicOfDiscussion: item.topic_of_discussion || "N/A",
              issue: item.topic_of_discussion || "N/A",
              closureAction: item.closure_action || "N/A",
              responsibility: formatName(item.responsibility_name, item.responsibility_lastname),
              responsibilityId: item.responsibility,
              meetingDate: formatDate(item.meeting_date),
              targetDate: formatDate(item.target_date),
              completedDate: formatDate(item.completed_date),
              status: item.status || "N/A",
              comments: item.comments || "",
              actionProgressUpdate: item.action_progress_update || "",
              targetDateChange: item.target_date_change || false,
              originalData: item,
            };
          });
          setTableData(transformedData);
        } else {
          setTableData([]);
        }
      } catch (err) {
        console.error("Error fetching data:", err);
        setError(err.message || "Failed to fetch data");
        setTableData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (state?.updatedItem) {
      const updatedItem = state.updatedItem;
      setTableData((prevData) =>
        prevData.map((item) =>
          item.id === updatedItem.id ? { ...item, ...updatedItem } : item
        )
      );
      window.history.replaceState({}, document.title);
    }
  }, [state]);

  useEffect(() => {
    const handleResize = () => {
      setScreenWidth(window.innerWidth);
      if (window.innerWidth < 1024) {
        setViewMode("card");
      } else {
        setViewMode("table");
      }
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (event.target.closest(".dropdown-trigger")) return;
      if (event.target.closest(".dropdown-menu")) return;
      setDropdownId(null);
    };
    if (dropdownId !== null) {
      document.addEventListener("click", handleClickOutside);
      return () => document.removeEventListener("click", handleClickOutside);
    }
  }, [dropdownId]);

  useEffect(() => {
    const handleScroll = () => setDropdownId(null);
    window.addEventListener("scroll", handleScroll, true);
    return () => window.removeEventListener("scroll", handleScroll, true);
  }, []);

  const handleDropdownToggle = (id, event) => {
    if (dropdownId === id) {
      setDropdownId(null);
    } else {
      const button = event.currentTarget;
      const rect = button.getBoundingClientRect();
      const dropdownHeight = 120;
      const spaceBelow = window.innerHeight - rect.bottom;

      const top = spaceBelow < dropdownHeight
        ? rect.top + window.scrollY - dropdownHeight
        : rect.bottom + window.scrollY + 4;

      setDropdownPosition({
        top,
        left: rect.right - 144 + window.scrollX,
      });
      setDropdownId(id);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString || dateString === "N/A") return "-";
    if (dateString.includes("/")) return dateString;
    if (dateString.includes("-")) {
      const [year, month, day] = dateString.split("-");
      return `${day}/${month}/${year}`;
    }
    return dateString;
  };

  // ═══════════════════════════════════════════════════════════════
  // DEPENDENT FILTER HANDLER
  // Year → Market Area → Dealer (cascade reset)
  // Department & Status are independent
  // ═══════════════════════════════════════════════════════════════
  const handleFilterChange = (name, newValueArray) => {
    setFilters((prev) => {
      const updated = { ...prev, [name]: newValueArray };

      // Full cascade: Year → Market Area → Dealer → Department → Status
      if (name === "year") {
        updated.marketArea = [];
        updated.dealer = [];
        updated.department = [];
        updated.status = [];
      }

      if (name === "marketArea") {
        updated.dealer = [];
        updated.department = [];
        updated.status = [];
      }

      if (name === "dealer") {
        updated.department = [];
        updated.status = [];
      }

      if (name === "department") {
        updated.status = [];
      }

      return updated;
    });
  };

  const handleEdit = (row) => {
    setSelectedRow(row);
    setIsPopupOpen(true);
    setDropdownId(null);
  };

  const closePopup = () => {
    setIsPopupOpen(false);
    setSelectedRow(null);
  };

  // ═══════════════════════════════════════════════════════════════
  // ROLE-BASED VISIBILITY FILTER
  // ═══════════════════════════════════════════════════════════════
  const visibleData = useMemo(() => {
    return tableData.filter((item) => canViewItem(item));
  }, [tableData, canViewItem]);

  // ═══════════════════════════════════════════════════════════════
  // DEPENDENT DROPDOWN OPTIONS (derived from visible table data)
  //
  // Year: all unique years from visibleData
  // Market Area: unique market areas from visibleData filtered by selected year(s)
  // Dealer: unique dealers from visibleData filtered by selected year(s) + market area(s)
  // Department: all unique departments (independent)
  // Status: static list (independent)
  // ═══════════════════════════════════════════════════════════════
  const yearOptions = useMemo(() => {
    const years = [...new Set(visibleData.map((item) => String(item.year)))];
    return years.sort((a, b) => b.localeCompare(a)); // newest first
  }, [visibleData]);

  const marketAreaOptions = useMemo(() => {
    const safeString = (v) => (v || "").toString();

    // If year filter is active, only show market areas from those years
    let source = visibleData;
    if (filters.year.length > 0) {
      source = visibleData.filter((item) =>
        filters.year.includes(safeString(item.year))
      );
    }

    const areas = [...new Set(
      source
        .map((item) => safeString(item.marketArea))
        .filter((v) => v && v !== "N/A")
    )];
    return areas.sort((a, b) => a.localeCompare(b));
  }, [visibleData, filters.year]);

  const dealerOptions = useMemo(() => {
    const safeString = (v) => (v || "").toString();

    // Filter by selected year(s) first
    let source = visibleData;
    if (filters.year.length > 0) {
      source = source.filter((item) =>
        filters.year.includes(safeString(item.year))
      );
    }

    // Then filter by selected market area(s)
    if (filters.marketArea.length > 0) {
      source = source.filter((item) =>
        filters.marketArea.includes(safeString(item.marketArea))
      );
    }

    const dealerNames = [...new Set(
      source
        .map((item) => safeString(item.dealer))
        .filter((v) => v && v !== "N/A")
    )];
    return dealerNames.sort((a, b) => a.localeCompare(b));
  }, [visibleData, filters.year, filters.marketArea]);

  const departmentOptions = useMemo(() => {
    const safeString = (v) => (v || "").toString();

    // Filter by selected Year → Market Area → Dealer
    let source = visibleData;
    if (filters.year.length > 0) {
      source = source.filter((item) =>
        filters.year.includes(safeString(item.year))
      );
    }
    if (filters.marketArea.length > 0) {
      source = source.filter((item) =>
        filters.marketArea.includes(safeString(item.marketArea))
      );
    }
    if (filters.dealer.length > 0) {
      source = source.filter((item) =>
        filters.dealer.includes(safeString(item.dealer))
      );
    }

    const depts = [...new Set(
      source
        .map((item) => safeString(item.department))
        .filter((v) => v && v !== "N/A")
    )];
    return depts.sort((a, b) => a.localeCompare(b));
  }, [visibleData, filters.year, filters.marketArea, filters.dealer]);

  const statusOptions = useMemo(() => {
    const safeString = (v) => (v || "").toString();

    // Filter by selected Year → Market Area → Dealer → Department
    let source = visibleData;
    if (filters.year.length > 0) {
      source = source.filter((item) =>
        filters.year.includes(safeString(item.year))
      );
    }
    if (filters.marketArea.length > 0) {
      source = source.filter((item) =>
        filters.marketArea.includes(safeString(item.marketArea))
      );
    }
    if (filters.dealer.length > 0) {
      source = source.filter((item) =>
        filters.dealer.includes(safeString(item.dealer))
      );
    }
    if (filters.department.length > 0) {
      source = source.filter((item) =>
        filters.department.includes(safeString(item.department))
      );
    }

    const statuses = [...new Set(
      source
        .map((item) => safeString(item.status))
        .filter((v) => v && v !== "N/A")
    )];
    // Custom sort: Open first, In Progress, then Closed
    const order = { "Open": 1, "In Progress": 2, "Closed": 3 };
    return statuses.sort((a, b) => (order[a] || 99) - (order[b] || 99));
  }, [visibleData, filters.year, filters.marketArea, filters.dealer, filters.department]);

  // ═══════════════════════════════════════════════════════════════
  // FILTERED DATA (applies all filters + search)
  // ═══════════════════════════════════════════════════════════════
  const filteredData = useMemo(() => {
    return visibleData.filter((item) => {
      const safeString = (value) => (value || "").toString();

      const matchesFilters =
        (filters.year.length === 0 || filters.year.includes(safeString(item.year))) &&
        (filters.marketArea.length === 0 ||
          filters.marketArea.includes(safeString(item.marketArea))) &&
        (filters.dealer.length === 0 || filters.dealer.includes(safeString(item.dealer))) &&
        (filters.department.length === 0 ||
          filters.department.includes(safeString(item.department))) &&
        (filters.status.length === 0 || filters.status.includes(safeString(item.status)));

      const matchesSearchText =
        !searchText ||
        safeString(item.year).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.marketArea).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.dealer).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.department).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.topicOfDiscussion).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.issue).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.status).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.createdBy).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.createdDate).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.closureAction).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.responsibility).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.meetingDate).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.targetDate).toLowerCase().includes(searchText.toLowerCase()) ||
        safeString(item.completedDate).toLowerCase().includes(searchText.toLowerCase());

      return matchesFilters && matchesSearchText;
    });
  }, [visibleData, filters, searchText]);

  const togglePopup = () => {
    if (filteredData.length === 0) {
      return;
    }
    setShowPopup(!showPopup);
  };

  const handleLogs = (row) => {
    setDropdownId(null);
    setLogsData(row);
    setIsLogsPopupOpen(true);
  };

  const closeLogsPopup = () => {
    setIsLogsPopupOpen(false);
    setLogsData(null);
  };

  const handleDeleteClick = (row) => {
    setDropdownId(null);
    setRowToDelete(row);
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
    setRowToDelete(null);
  };

  const confirmDelete = async () => {
    if (!rowToDelete) return;
    try {
      await deleteActionItem(rowToDelete.id);
      const updatedData = tableData.filter((item) => item.id !== rowToDelete.id);
      setTableData(updatedData);
      setIsDeleteModalOpen(false);
      setRowToDelete(null);
    } catch (error) {
    }
  };

  // Card component for mobile/tablet view
  const ActionItemCard = ({ row, index }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const action = getEditAction(row);

    return (
      <div className="bg-white border border-gray-200 shadow-sm mb-4 p-4 hover:shadow-md transition-shadow">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-gray-600">#{row.year}</span>
            <span
              className={`px-2 py-1 rounded-full text-xs font-medium ${
                row.status === "Open"
                  ? "bg-blue-100 text-blue-700"
                  : row.status === "Closed"
                  ? "bg-green-100 text-green-700"
                  : "bg-orange-100 text-orange-700"
              }`}
            >
              {row.status}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button onClick={() => setIsExpanded(!isExpanded)} className="p-1 hover:bg-gray-100">
              {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </button>
            <div className="relative">
              <button
                onClick={(e) => handleDropdownToggle(row.id, e)}
                className="dropdown-trigger p-1 hover:bg-gray-100"
              >
                <MoreVertical size={16} />
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <span className="text-gray-600">Market Area:</span>
              <p className="font-medium">{row.marketArea}</p>
            </div>
            <div>
              <span className="text-gray-600">Created By:</span>
              <p className="font-medium">{row.createdBy}</p>
            </div>
          </div>

          <div>
            <span className="text-gray-600 text-sm">Dealer:</span>
            <p className="font-medium text-sm">{row.dealer}</p>
          </div>

          <div>
            <span className="text-gray-600 text-sm">Topic:</span>
            <p className={`text-sm ${isExpanded ? "" : "line-clamp-2"}`}>
              {row.topicOfDiscussion}
            </p>
          </div>

          {isExpanded && (
            <>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-600">Department:</span>
                  <p className="font-medium">{row.department}</p>
                </div>
                <div>
                  <span className="text-gray-600">Responsibility:</span>
                  <p className="font-medium">{row.responsibility || "-"}</p>
                </div>
              </div>

              <div>
                <span className="text-gray-600 text-sm">Closure Action:</span>
                <p className="text-sm mt-1">{row.closureAction}</p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-600">Created Date:</span>
                  <p className="font-medium">{formatDate(row.createdDate)}</p>
                </div>
                <div>
                  <span className="text-gray-600">Meeting Date:</span>
                  <p className="font-medium">{formatDate(row.meetingDate)}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-600">Target Date:</span>
                  <div className="font-medium">
                    <ExpandableTargetDate
                      currentDate={row.targetDate || "-"}
                      actionItemId={row.id}
                    />
                  </div>
                </div>
                <div>
                  <span className="text-gray-600">Closed Date:</span>
                  <p className="font-medium">{formatDate(row.completedDate)}</p>
                </div>
              </div>

              {/* Mobile Action Buttons - Role Based */}
              <div className="border-t pt-2 flex gap-2 mt-2">
                <button
                  className={`flex-1 px-3 py-2 text-sm font-medium transition-colors ${
                    action.type === "view"
                      ? "bg-blue-100 text-blue-700 hover:bg-blue-200"
                      : action.type === "limited_edit"
                      ? "bg-amber-100 text-amber-700 hover:bg-amber-200"
                      : "bg-green-100 text-green-700 hover:bg-green-200"
                  }`}
                  onClick={() =>
                    navigate("/editactionitem", {
                      state: { rowData: row, editType: action.type },
                    })
                  }
                >
                  {action.label}
                </button>
                <button
                  className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 text-sm font-medium hover:bg-gray-200 transition-colors"
                  onClick={() => handleLogs(row)}
                >
                  Logs
                </button>
                {canDelete(row) && (
                  <button
                    className="flex-1 px-3 py-2 bg-red-100 text-red-700 text-sm font-medium hover:bg-red-200 transition-colors"
                    onClick={() => handleDeleteClick(row)}
                  >
                    Delete
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    );
  };

  // ═══════════════════════════════════════════════════════════════
  // EXPORT
  // ═══════════════════════════════════════════════════════════════
  const handleExportActionItems = async () => {
    if (!filteredData || filteredData.length === 0) {
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("Action Items");

      sheet.columns = [
        { header: "Sl. No", key: "slNo", width: 8 },
        { header: "Year", key: "year", width: 10 },
        { header: "Meeting Date", key: "meetingDate", width: 15 },
        { header: "Market Area", key: "marketArea", width: 20 },
        { header: "Dealership", key: "dealer", width: 40 },
        { header: "Created Date", key: "createdDate", width: 15 },
        { header: "Created By", key: "createdBy", width: 20 },
        { header: "Topic of Discussion", key: "topic", width: 75 },
        { header: "Department", key: "department", width: 20 },
        { header: "Responsibility", key: "responsibility", width: 25 },
        { header: "Target Date", key: "targetDate", width: 15 },
        { header: "Closed Date", key: "completedDate", width: 18 },
        { header: "Status", key: "status", width: 15 },
        { header: "Closure Action", key: "closureAction", width: 75 },
        { header: "Action Progress Update", key: "actionProgressUpdate", width: 50 },
        { header: "Comments", key: "comments", width: 40 },
      ];

      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF476896" } };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      filteredData.forEach((item, index) => {
        const row = sheet.addRow({
          slNo: index + 1,
          year: item.year,
          marketArea: item.marketArea,
          dealer: item.dealer,
          department: item.department,
          topic: item.topicOfDiscussion,
          closureAction: item.closureAction,
          responsibility: item.responsibility,
          createdBy: item.createdBy,
          createdDate: item.createdDate,
          meetingDate: item.meetingDate,
          targetDate: item.targetDate,
          completedDate: item.completedDate,
          status: item.status,
          actionProgressUpdate: item.actionProgressUpdate || "",
          comments: item.comments || "",
        });
        row.eachCell((cell) => {
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const file = new File([blob], "Action_Items.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const fileUrl = await uploadTempFile(file);
      if (fileUrl) {
        const previewUrl = `https://view.officeapps.live.com/op/view.aspx?src=${fileUrl}`;
        window.open(previewUrl, "_blank", "noopener,noreferrer");
      }
    } catch (error) {
    }
  };

  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder || sortOrder === "normal") return filteredData;
    return [...filteredData].sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];
      if (!isNaN(valA) && !isNaN(valB)) {
        return sortOrder === "asc" ? valA - valB : valB - valA;
      }
      const strA = valA ? valA.toString().toLowerCase() : "";
      const strB = valB ? valB.toString().toLowerCase() : "";
      if (strA < strB) return sortOrder === "asc" ? -1 : 1;
      if (strA > strB) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [filteredData, sortKey, sortOrder]);

  return (
    <div className="w-full px-4 justify-center">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mt-2 mb-2">
        <h2 className="text-lg font-semibold text-darkblue1 sm:absolute sm:left-1/2 sm:transform sm:-translate-x-1/2">
          Action Items
        </h2>
        <div className="w-full sm:w-auto flex justify-center sm:justify-end sm:ml-auto">
          <button
            onClick={handleExportActionItems}
            className="group px-4 py-1.5 text-xs font-medium bg-darkblue1 text-white flex items-center justify-center gap-1 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition duration-200 w-full sm:w-auto"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 21 21"
              fill="none"
              className="w-3 h-3 transition duration-200 group-hover:filter group-hover:brightness-0 group-hover:saturate-100"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M16.17 7.2615C15.9591 7.47218 15.6731 7.59051 15.375 7.59051C15.0769 7.59051 14.7909 7.47218 14.58 7.2615L11.625 4.3065V15.375C11.625 15.6734 11.5065 15.9595 11.2955 16.1705C11.0845 16.3815 10.7984 16.5 10.5 16.5C10.2016 16.5 9.91548 16.3815 9.7045 16.1705C9.49353 15.9595 9.375 15.6734 9.375 15.375V4.3065L6.42 7.2615C6.20674 7.46022 5.92467 7.5684 5.63322 7.56326C5.34176 7.55812 5.06369 7.44005 4.85757 7.23393C4.65145 7.02781 4.53338 6.74974 4.52824 6.45828C4.5231 6.16683 4.63128 5.88476 4.83 5.6715L9.705 0.7965L10.5 0L11.295 0.795L16.17 5.67C16.2745 5.77448 16.3575 5.89853 16.4141 6.03506C16.4706 6.1716 16.4998 6.31795 16.4998 6.46575C16.4998 6.61355 16.4706 6.7599 16.4141 6.89644C16.3575 7.03297 16.2745 7.15702 16.17 7.2615ZM2.25 13.125C2.25 12.8266 2.13147 12.5405 1.9205 12.3295C1.70952 12.1185 1.42337 12 1.125 12C0.826631 12 0.540483 12.1185 0.329505 12.3295C0.118526 12.5405 4.44604e-09 12.8266 0 13.125V18C0 18.7956 0.316071 19.5587 0.87868 20.1213C1.44129 20.6839 2.20435 21 3 21H18C18.7956 21 19.5587 20.6839 20.1213 20.1213C20.6839 19.5587 21 18.7956 21 18V13.125C21 12.8266 20.8815 12.5405 20.6705 12.3295C20.4595 12.1185 20.1734 12 19.875 12C19.5766 12 19.2905 12.1185 19.0795 12.3295C18.8685 12.5405 18.75 12.8266 18.75 13.125V18C18.75 18.1989 18.671 18.3897 18.5303 18.5303C18.3897 18.671 18.1989 18.75 18 18.75H3C2.80109 18.75 2.61032 18.671 2.46967 18.5303C2.32902 18.3897 2.25 18.1989 2.25 18V13.125Z"
                fill="white"
              />
            </svg>
            <span className="font-VlovoNovum">Export Action items</span>
          </button>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* DESKTOP FILTERS — Dependent: Year → Market Area → Dealer       */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      <div className="hidden lg:flex flex-col md:flex-row md:items-center md:justify-between gap-4 md:gap-12 lg:gap-18 mb-2">
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
          <div>
            <Searchinput
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              placeholder="Search"
              className="w-[1/2]"
              iconColor="text-black"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-2"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              inputWidth="w-full"
              focusRing="focus:ring-1 focus:ring-black/60"
              hoverInputClasses="hover:bg-white hover:border-black/60"
            />
          </div>

          {/* Year — independent, options from table data */}
          <Filter name="year" value={filters.year} options={yearOptions} onChange={handleFilterChange} placeholder="Year" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" customWidth="w-[120px]" />

          {/* Market Area — depends on Year */}
          <Filter name="marketArea" value={filters.marketArea} options={marketAreaOptions} onChange={handleFilterChange} placeholder="Market Area" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" customWidth="w-[120px]" />

          {/* Dealer — depends on Year + Market Area */}
          <Filter name="dealer" value={filters.dealer} options={dealerOptions} onChange={handleFilterChange} placeholder="Dealership" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" customWidth="w-[120px]" />

          {/* Department — independent, options from table data */}
          <Filter name="department" value={filters.department} options={departmentOptions} onChange={handleFilterChange} placeholder="Department" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" customWidth="w-[120px]" />

          {/* Status — independent */}
          <Filter name="status" value={filters.status} options={statusOptions} onChange={handleFilterChange} placeholder="Status" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" customWidth="w-[120px]" />
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* MOBILE/TABLET FILTERS — Same dependent logic                   */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      <div className="lg:hidden bg-white p-4 mb-4">
        <div className="flex flex-col sm:flex-row gap-3 mb-3">
          <div className="flex-1">
            <Searchinput
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              placeholder="Search"
              className="w-full"
              iconColor="text-black"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              shadow="shadow-none"
              inputPadding="pl-8 pr-3 py-2"
              iconSize="w-4 h-4"
              iconLeft="left-3"
              inputWidth="w-full"
              focusRing="focus:ring-1 focus:ring-black/60"
              hoverInputClasses="hover:bg-white hover:border-black/60"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center justify-center gap-2 px-4 py-2 border border-black bg-white hover:bg-gray-50 sm:w-auto whitespace-nowrap"
          >
            {showFilters ? <X size={16} /> : <Menu size={16} />}
            <span className="text-sm">Filters</span>
          </button>
        </div>

        {showFilters && (
          <div className="space-y-3 border-t pt-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Filter name="year" value={filters.year} options={yearOptions} onChange={handleFilterChange} className="w-full" placeholder="Year" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" />
              <Filter name="marketArea" value={filters.marketArea} options={marketAreaOptions} onChange={handleFilterChange} className="w-full" placeholder="Market Area" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" />
              <Filter name="dealer" value={filters.dealer} options={dealerOptions} onChange={handleFilterChange} className="w-full" placeholder="Dealer" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" />
              <Filter name="department" value={filters.department} options={departmentOptions} onChange={handleFilterChange} className="w-full" placeholder="Department" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" />
              <Filter name="status" value={filters.status} options={statusOptions} onChange={handleFilterChange} className="w-full sm:col-span-2" placeholder="Status" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" />
            </div>
          </div>
        )}
      </div>

      {/* Table View */}
      {viewMode === "table" ? (
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
          <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
              maxHeight: sortedData.length > 8 ? "calc(100vh - 240px)" : "auto",
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            }}
            onScroll={handleTableScroll}
          >
            <style jsx>{`
              div::-webkit-scrollbar {
                display: none;
              }
            `}</style>
            <table className="w-full text-sm text-left table-fixed">
              <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                <tr>
                  {columns.map((col) => (
                    <th
                      key={col.key}
                      onClick={() => handleSort(col.key)}
                      className={`px-1 py-1.5 text-[10px] border border-grey2 border-t-0 border-l-0 border-b-0 font-medium text-left cursor-pointer ${col.width}`}
                    >
                      <div className="flex items-center gap-1">
                        {col.label}
                        {sortKey === col.key && sortOrder === "asc" && (
                          <ChevronUp className="w-3 h-3 text-white" />
                        )}
                        {sortKey === col.key && sortOrder === "desc" && (
                          <ChevronDown className="w-3 h-3 text-white" />
                        )}
                        {sortKey !== col.key && col.key === "year" && (
                          <ChevronsUpDown className="w-3 h-3 text-white" />
                        )}
                      </div>
                    </th>
                  ))}
                  <th className="py-1.5 text-center text-[10px] border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[4%]">
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {sortedData.length === 0 ? (
                  <tr>
                    <td colSpan={14} className="text-center py-4 text-gray-500">
                      No records found.
                    </td>
                  </tr>
                ) : (
                  sortedData.map((row, index) => (
                    <tr
                      key={row.id || index}
                      className="hover:bg-lightBlue/50 text-[10px] align-top"
                    >
                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0">{row.year}</td>
                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 whitespace-nowrap">{formatDate(row.meetingDate)}</td>

                      {/* Market Area */}
                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 ">
                        <div className="relative">
                          <p className="truncate max-w-[12rem] cursor-pointer" onMouseEnter={() => { if (row.marketArea && row.marketArea.length > 20) setHoveredCell(`${row.id}-marketArea`); }} onMouseLeave={() => setHoveredCell(null)}>
                            {row.marketArea || "N/A"}
                          </p>
                          {hoveredCell === `${row.id}-marketArea` && (
                            <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">{row.marketArea}</span>
                          )}
                        </div>
                      </td>

                      {/* Dealer */}
                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 ">
                        <div className="relative">
                          <p className="truncate max-w-[12rem] cursor-pointer" onMouseEnter={() => { if (row.dealer && row.dealer.length > 20) setHoveredCell(`${row.id}-dealer`); }} onMouseLeave={() => setHoveredCell(null)}>
                            {row.dealer || "N/A"}
                          </p>
                          {hoveredCell === `${row.id}-dealer` && (
                            <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">{row.dealer}</span>
                          )}
                        </div>
                      </td>

                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 whitespace-nowrap">{formatDate(row.createdDate)}</td>

                      {/* Created By */}
                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 ">
                        <div className="relative">
                          <p className="truncate max-w-[12rem] cursor-pointer" onMouseEnter={() => { if (row.createdBy && row.createdBy.length > 10) setHoveredCell(`${row.id}-createdBy`); }} onMouseLeave={() => setHoveredCell(null)}>
                            {row.createdBy || "N/A"}
                          </p>
                          {hoveredCell === `${row.id}-createdBy` && (
                            <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">{row.createdBy}</span>
                          )}
                        </div>
                      </td>

                      {/* Topic of Discussion */}
                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 ">
                        <ExpandableText text={row.topicOfDiscussion} maxLines={2} />
                      </td>

                      {/* Department */}
                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 ">
                        <div className="relative">
                          <p className="truncate max-w-[12rem] cursor-pointer" onMouseEnter={() => { if (row.department && row.department.length > 10) setHoveredCell(`${row.id}-department`); }} onMouseLeave={() => setHoveredCell(null)}>
                            {row.department || "N/A"}
                          </p>
                          {hoveredCell === `${row.id}-department` && (
                            <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">{row.department}</span>
                          )}
                        </div>
                      </td>

                      {/* Responsibility */}
                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 ">
                        <div className="relative">
                          <p className="truncate max-w-[12rem] cursor-pointer" onMouseEnter={() => { if (row.responsibility && row.responsibility.length > 10) setHoveredCell(`${row.id}-responsibility`); }} onMouseLeave={() => setHoveredCell(null)}>
                            {row.responsibility || "-"}
                          </p>
                          {hoveredCell === `${row.id}-responsibility` && (
                            <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">{row.responsibility || "-"}</span>
                          )}
                        </div>
                      </td>

                      {/* TARGET DATE — EXPANDABLE */}
                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 ">
                        <ExpandableTargetDate
                          currentDate={row.targetDate || "-"}
                          actionItemId={row.id}
                        />
                      </td>

                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 whitespace-nowrap">{formatDate(row.completedDate)}</td>

                      {/* Status */}
                      <td className={`px-1 py-1.5 font-semibold border border-grey2 border-t-0 border-l-0 text-left ${row.status === "Open" ? "text-mildBlue" : row.status === "Closed" ? "text-green6" : "text-burntorange1"}`}>
                        {row.status}
                      </td>

                      {/* Closure Action */}
                      <td className="px-1 py-1.5 border border-grey2 border-t-0 border-l-0 ">
                        <ExpandableText text={row.closureAction} maxLines={2} />
                      </td>

                      {/* Actions */}
                      <td className="border border-grey2 border-t-0 border-l-0 border-r-0 px-1 py-1.5">
                        <div className="flex justify-center items-center">
                          <button
                            onClick={(e) => handleDropdownToggle(row.id, e)}
                            className="dropdown-trigger w-5 h-5 flex items-center justify-center  hover:bg-white  transition-colors cursor-pointer"
                          >
                            <MoreVertical size={14} className="text-gray-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {sortedData.length === 0 ? (
            <div className="text-center py-8 text-gray-500 bg-white border">No records found.</div>
          ) : (
            sortedData.map((row, index) => (
              <ActionItemCard key={row.id} row={row} index={index} />
            ))
          )}
        </div>
      )}

      {/* DROPDOWN MENU PORTAL - Role-Based */}
      {dropdownId !== null && (
        <div
          className="dropdown-menu fixed w-36 bg-white border border-gray-200 rounded-md shadow-xl z-[9999] overflow-hidden"
          style={{
            top: `${dropdownPosition.top}px`,
            left: `${dropdownPosition.left}px`,
          }}
        >
          <div className="py-1">
            {(() => {
              const row = sortedData.find((item) => item.id === dropdownId);
              if (!row) return null;
              const action = getEditAction(row);
              return (
                <button
                  type="button"
                  onClick={() => {
                    navigate("/editactionitem", {
                      state: { rowData: row, editType: action.type },
                    });
                    setDropdownId(null);
                  }}
                  className={`w-full px-3 py-2 text-left text-xs flex items-center gap-2 transition-colors duration-150 ${
                    action.type === "view"
                      ? "text-blue-700 hover:bg-blue-50"
                      : action.type === "limited_edit"
                      ? "text-amber-700 hover:bg-amber-50"
                      : "text-gray-700 hover:bg-green-50 hover:text-green-700"
                  }`}
                >
                  {action.type === "view" ? (
                    <>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24">
                        <path d="M12 5C6 5 2 12 2 12s4 7 10 7 10-7 10-7-4-7-10-7Z" stroke="#1B365D" strokeWidth="1.5" />
                        <circle cx="12" cy="12" r="3" stroke="#1B365D" strokeWidth="1.5" />
                      </svg>
                      View
                    </>
                  ) : action.type === "limited_edit" ? (
                    <>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M18.988 2.012L21.988 5.012L19.701 7.3L16.701 4.3L18.988 2.012ZM8 16H11L18.287 8.713L15.287 5.713L8 13V16Z" fill="#D97706" />
                      </svg>
                      Update
                    </>
                  ) : (
                    <>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M18.988 2.012L21.988 5.012L19.701 7.3L16.701 4.3L18.988 2.012ZM8 16H11L18.287 8.713L15.287 5.713L8 13V16Z" fill="#66B3A6" />
                      </svg>
                      Edit
                    </>
                  )}
                </button>
              );
            })()}

            <button
              type="button"
              onClick={() => {
                const row = sortedData.find((item) => item.id === dropdownId);
                if (row) handleLogs(row);
                setDropdownId(null);
              }}
              className="w-full px-3 py-1 text-left text-xs text-gray-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2 transition-colors duration-150"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="16" viewBox="0 0 16 16" fill="none">
                <g clipPath="url(#clip0_9798_472)">
                  <path d="M13.9993 1.83366H12.666C12.6218 1.83366 12.5794 1.8161 12.5482 1.78484C12.5169 1.75359 12.4993 1.71119 12.4993 1.66699V0.833659C12.4993 0.656848 12.4291 0.487279 12.3041 0.362254C12.1791 0.23723 12.0095 0.166992 11.8327 0.166992C11.6559 0.166992 11.4863 0.23723 11.3613 0.362254C11.2363 0.487279 11.166 0.656848 11.166 0.833659V3.60699C11.166 3.7838 11.2363 3.95337 11.3613 4.0784C11.4863 4.20342 11.6559 4.27366 11.8327 4.27366C12.0095 4.27366 12.1791 4.20342 12.3041 4.0784C12.4291 3.95337 12.4993 3.7838 12.4993 3.60699V3.33366C12.4993 3.28946 12.5169 3.24706 12.5482 3.21581C12.5794 3.18455 12.6218 3.16699 12.666 3.16699H13.666C13.7544 3.16699 13.8392 3.20211 13.9017 3.26462C13.9642 3.32714 13.9993 3.41192 13.9993 3.50033V10.5003C13.9993 10.5887 13.9642 10.6735 13.9017 10.736C13.8392 10.7985 13.7544 10.8337 13.666 10.8337H11.666C11.3124 10.8337 10.9733 10.9741 10.7232 11.2242C10.4732 11.4742 10.3327 11.8134 10.3327 12.167V14.167C10.3327 14.2554 10.2976 14.3402 10.2351 14.4027C10.1725 14.4652 10.0878 14.5003 9.99935 14.5003H2.33268C2.24428 14.5003 2.15949 14.4652 2.09698 14.4027C2.03447 14.3397 1.99935 14.2554 1.99935 14.167V3.50033C1.99935 3.41192 2.03447 3.32714 2.09698 3.26462C2.15949 3.20211 2.24428 3.16699 2.33268 3.16699H2.99935C3.04355 3.16699 3.08594 3.14943 3.1172 3.11818C3.14846 3.08692 3.16602 3.04453 3.16602 3.00033V2.00033C3.16602 1.95612 3.14846 1.91373 3.1172 1.88247C3.08594 1.85122 3.04355 1.83366 2.99935 1.83366H1.99935C1.64573 1.83366 1.30659 1.97413 1.05654 2.22418C0.806491 2.47423 0.666016 2.81337 0.666016 3.16699V14.5003C0.666016 14.8539 0.806491 15.1931 1.05654 15.4431C1.30659 15.6932 1.64573 15.8337 1.99935 15.8337H10.9993C11.0919 15.8343 11.1835 15.8156 11.2685 15.7789C11.3534 15.7422 11.4298 15.6882 11.4927 15.6203L15.1593 11.6203C15.272 11.4964 15.3339 11.3345 15.3327 11.167V3.16699C15.3327 2.81337 15.1922 2.47423 14.9422 2.22418C14.6921 1.97413 14.353 1.83366 13.9993 1.83366Z" fill="#1B365D" />
                </g>
              </svg>
              Logs
            </button>

            {(() => {
              const row = sortedData.find((item) => item.id === dropdownId);
              if (!row || !canDelete(row)) return null;
              return (
                <button
                  type="button"
                  onClick={() => {
                    if (row) handleDeleteClick(row);
                    setDropdownId(null);
                  }}
                  className="w-full px-2 py-1 text-left text-xs text-gray-700 hover:bg-red-50 hover:text-red-700 flex items-center gap-2 transition-colors duration-150"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                    <g clipPath="url(#clip0_6398_313)">
                      <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012" />
                    </g>
                  </svg>
                  Delete
                </button>
              );
            })()}
          </div>
        </div>
      )}

      {/* Popups */}
      {isLogsPopupOpen && (
        <LogActionitemPopup actionItemId={logsData?.id} logsData={logsData} onClose={closeLogsPopup} />
      )}
      {isDeleteModalOpen && (
        <DeleteModal isOpen={isDeleteModalOpen} onClose={closeDeleteModal} onConfirm={confirmDelete} />
      )}
    </div>
  );
};

export default Actionitem;