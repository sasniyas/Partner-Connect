import React, { useState } from "react";
import Filter from "../../../../Components/Filter";

// import EditPopup from "./EditAction";
import DownloadPopup from "../../../../Components/Downloadpopup";
// import CommentPopup from "./CommentPopup";
// import LogPopup from "./LogPopup";
import DeleteModal from "../../../../Components/DeleteModal";
import Searchinput from "../../../../Components/Searchinput";
import { ArrowLeft,ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import PdpCommentPopup from "./PdpCommentPopup";
import PdpLogPopup from "./PdpLogPopup";
import { ChevronDown, ChevronUp } from "lucide-react";

const mockData = [
{
    id: 1,
    year: 2024,
    marketArea: "North",
    dealer:  "Drs Earthwork Pvt Ltd",
    createdDate: "2024-06-01",
    createdBy: "John Doe",
    department: "Uptime & parts",
    topicOfDiscussion:"Inventory Issues",
    issue: "Low inventory",
    closureAction: "Increase stock",
    meetingDate: "2024-06-15",
    targetDate: "2024-06-30",
    revisionDate: "2024-07-10",
    status: "Open",
  },
  {
    id: 2,
    year: 2024,
    marketArea: "North",
    dealer: "ESDEE SOLUTECH",
    createdDate: "2024-05-15",
    createdBy: "Jane Smith",
    department: "DD-CD & Infra",
        topicOfDiscussion:"Inventory Issues",

    issue: "Delayed deliveries",
    closureAction: "Optimize logistics",
    meetingDate: "2024-05-20",
    targetDate: "2024-06-05",
    revisionDate: "2024-06-10",
    status: "in Progress",
  },
  {
    id: 3,
    year: 2024,
    marketArea: "East",
    dealer: "POLLUTECH ENGINEERING",
    createdDate: "2024-05-15",
    createdBy: "Jane Smith",
    department: "Key Accounts",
        topicOfDiscussion:"Inventory Issues",

    issue: "Delayed deliveries",
    closureAction: "Optimize logistics",
    meetingDate: "2024-05-20",
    targetDate: "2024-06-05",
    revisionDate: "2024-06-10",
    status: "in Progress",
  },
];

const PdpActionitem = () => {
    const [filters, setFilters] = useState({
        year: "",
        marketArea: "",
        dealer: "",
        department: "",
        status: "",
      });
      
      const yearOptions = ["2021" , "2022", "2023", "2024", "2025","2026", "2027", "2028", "2029", "2030"];
      const marketAreaOptions = ["North", "Central", "South", "East", "West"];
      const dealerOptions =
      [
       "Advanced Construction Technologies Pvt. Ltd",
       "Alpha Teknisk Pvt. Ltd. (DL)",
       "Alpha Teknisk Pvt. Ltd. (UP)",
       "Bses India Pvt. Ltd.",
       "Drs Earthwork Pvt Ltd",
       "Encore Heavy Machinery Pvt Ltd",
       "ESDEE SOLUTECH",
       "INFRA EQUIP PVT. LTD",
       "Navin Infrasolutions Pvt.Ltd",
       "PACT Machines Pvt Ltd",
       "PAL Infrastructure Solutions",
       "POLLUTECH ENGINEERING",
       "Ramanand Power System Private Limited (TS)",
       "Ramanand Power System Private Limited (AP)",
       "Suchita Earthmoving Solutions",
       "Suchita Millennium Projects Pvt Ltd (BH)",
       "Suchita Millennium Projects Pvt Ltd (WB)",
       "SVP Mining Technologies Pvt Ltd",
       "TEAM ENGINEERS",
       "West India Equipment's Pvt. Ltd.",
       "Test Dealer"
     ];
     const navigate = useNavigate();
  const statusOptions = ["Open", "OnGoing", "Closed"];
const departmentOptions = ["Uptime & parts","DD-CD & Infra","Finance", "Key Accounts", "Machine-Attach Sales", "Macrom"];
const [searchText, setSearchText] = useState("");
const [isPopupOpen, setIsPopupOpen] = useState(false); // State to track popup visibility
  const [dropdownId, setDropdownId] = useState(null); // State to track the open dropdown
  const [isCommentsPopupOpen, setIsCommentsPopupOpen] = useState(false); // State to track comments popup visibility
const [commentsData, setCommentsData] = useState([]); // State to store comments data
const [showPopup, setShowPopup] = useState(false); // State to control popup visibility
const [isLogsPopupOpen, setIsLogsPopupOpen] = useState(false); // State to track logs popup visibility
const [logsData, setLogsData] = useState(null); // State to store logs data for the selected row
const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
const [rowToDelete, setRowToDelete] = useState(null);
const [meetings, setMeetings] = useState(mockData); // Initialize state with mockData
const [isExpanded, setIsExpanded] = useState(false);
const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const [selectedRow, setSelectedRow] = useState({
    issue: "",
    closureAction: "",
    commentedBy:"",
    comments:"",
    atentee:""
    // Add other fields as needed
  });
  const handleFilterChange = (name, newValueArray) => {
  setFilters((prev) => ({
    ...prev,
    [name]: newValueArray, // directly set the new array
  }));
};

  const toggleDropdown = (id) => {
    setDropdownId((prevId) => (prevId === id ? null : id)); // Toggle dropdown
  };
  const handleEdit = (row) => {
    setSelectedRow(row); // Store the selected row data
    setIsPopupOpen(true); // Open the popup
    setDropdownId(null); // Close the dropdown

  };

  const closePopup = () => {
    setIsPopupOpen(false); // Close the popup
    setSelectedRow(null); // Clear the selected row data
  };
  // Filtered data
  const filteredData = meetings.filter((item) => {
  const matchesFilters =
    (filters.year.length === 0 || filters.year.includes(item.year.toString())) &&
    (filters.marketArea.length === 0 || filters.marketArea.includes(item.marketArea)) &&
    (filters.dealer.length === 0 || filters.dealer.includes(item.dealer)) &&
    (filters.department.length === 0 || filters.department.includes(item.department)) &&
    (filters.status.length === 0 || filters.status.includes(item.status));

  const matchesSearchText =
    !searchText ||
    item.year.toString().includes(searchText) ||
    item.marketArea.toLowerCase().includes(searchText.toLowerCase()) ||
    item.dealer.toLowerCase().includes(searchText.toLowerCase()) ||
    item.department.toLowerCase().includes(searchText.toLowerCase()) ||
    (item.topicOfDiscussion || "").toLowerCase().includes(searchText.toLowerCase()) ||
    item.issue.toLowerCase().includes(searchText.toLowerCase()) ||
    item.status.toLowerCase().includes(searchText.toLowerCase()) ||
    item.createdBy.toLowerCase().includes(searchText.toLowerCase()) ||
    item.createdDate.toLowerCase().includes(searchText.toLowerCase()) ||
    item.closureAction.toLowerCase().includes(searchText.toLowerCase()) ||
    item.meetingDate.toLowerCase().includes(searchText.toLowerCase()) ||
    item.targetDate.toLowerCase().includes(searchText.toLowerCase()) ||
    item.revisionDate.toLowerCase().includes(searchText.toLowerCase());

  return matchesFilters && matchesSearchText;
});
const paginatedData = filteredData.slice(
  (currentPage - 1) * itemsPerPage,
  currentPage * itemsPerPage
);  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const togglePopup = () => {
    console.log("Filtered Data:", filteredData); // Debug filtered data
    if (filteredData.length === 0) {
      alert("No data available to download.");
      return;
    }
    setShowPopup(!showPopup);
  };

  const handleComments = (row) => {
    setDropdownId(null); // Close the dropdown menu

    if (row.comments && row.comments.length > 0) {
      setCommentsData(row.comments); // Set the comments data if available
    } else {
      setCommentsData([]); // Set empty data if no comments
    }
    setIsCommentsPopupOpen(true); // Open the comments popup
  };
  
  const closeCommentsPopup = () => {
    setIsCommentsPopupOpen(false); // Close the comments popup
    setCommentsData([]); // Clear the comments data
  };
  const handleLogs = (row) => {
    setDropdownId(null); // Close the dropdown menu
    setLogsData(row); // Set the row data for the logs popup
    setIsLogsPopupOpen(true); // Open the logs popup
  };
  
  const closeLogsPopup = () => {
    setIsLogsPopupOpen(false); // Close the logs popup
    setLogsData(null); // Clear the logs data
  };

  const handleDeleteClick = (row) => {
    setDropdownId(null); // Close the dropdown menu
    setRowToDelete(row);
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
    setRowToDelete(null);
  };

  const confirmDelete = () => {
    // Remove the row from the state
    const updatedData = meetings.filter((item) => item !== rowToDelete);
    setMeetings(updatedData); // Update the state with the filtered data
    setIsDeleteModalOpen(false); // Close the modal
    setRowToDelete(null); // Clear the row to delete
  };

  return (
<div className="w-full max-w-[1290px] ">

<div className="relative flex items-center justify-between w-full mb-2 px-4">
  {/* Centered Heading */}
  <h2 className="absolute left-1/2 transform -translate-x-1/2 text-lg md:text-xl font-semibold text-darkblue1">
    PDP Action Item
  </h2>

  {/* Export Button */}
  <div className="ml-auto mr-[-14px]">
    <button
      onClick={togglePopup}
      className="group px-6 py-2 text-sm font-medium bg-darkblue1 text-white rounded-lg flex items-center justify-center gap-1 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition duration-200"
    >
      <img
        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/export1.png"
        alt="Export"
        className="w-4 h-4 transition duration-200 group-hover:filter group-hover:brightness-0 group-hover:saturate-100"
      />
      <span className="font-VlovoNovum">Export Action items</span>
    </button>
  </div>
</div>

        
    {showPopup && ( // Only show the popup when `showPopup` is true
      <DownloadPopup
        title="Action Items"
        fileName="Action Items.xlsx"
        fileContent={filteredData}
        description="Action items have been exported. Click the link below to download the Excel file."
        onClose={togglePopup} // Close the popup when the close button is clicked
        lineColor="border-mildBlue"
      />
    )}

      {/* Filters */}
     
<div className="w-full flex justify-center">
        <div className="w-full bg-white rounded-xl mb-6 mt-6 ">    
               <div className="flex justify-center gap-2">
              <Searchinput
      value={searchText}
      onChange={(e) => {
        setSearchText(e.target.value);
        // setCurrentPage(1);
      }}
      placeholder="Search"
      className="w-80"
      iconColor="text-black"
      bgColor="bg-FrostWhite"
      borderColor="border-black/60"
      textColor="text-black"
      shadow="shadow-none"
      inputPadding="pl-8 pr-3 py-2"
      iconSize="w-4 h-4"
      iconLeft="left-3"
      inputWidth="w-full"
      focusRing="focus:ring-1 focus:ring-black/60"
      hoverInputClasses="hover:bg-white hover:border-black/60"
    />

            <Filter
            name="year"
            value={filters.year}
            options={yearOptions}
            onChange={handleFilterChange}
            className="w-48"
            placeholder="Year"
           placeholderColor="text-black"
  buttonBorderColor="border-black"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
            
          />
          <Filter
  name="marketArea"
  value={filters.marketArea}
  options={marketAreaOptions}
  onChange={handleFilterChange}
  className="w-48"
  placeholder="-Select Market Area-"
   placeholderColor="text-black"
  buttonBorderColor="border-black"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
/>
<Filter
  name="dealer"
  value={filters.dealer}
  options={dealerOptions}
  onChange={handleFilterChange}
  className="w-48"
  placeholder="-Select Dealer-"
  placeholderColor="text-black"
  buttonBorderColor="border-black"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
/>

<Filter
  name="status"
  value={filters.status}
  options={statusOptions}
  onChange={handleFilterChange}
  className="w-48"
  placeholder="Status"
  placeholderColor="text-black"
  buttonBorderColor="border-black"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
/>
<Filter
  name="department"
  value={filters.department}
  options={departmentOptions}
  onChange={handleFilterChange}
  className="w-48"
  placeholder="Department"
  placeholderColor="text-black"
  buttonBorderColor="border-black"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
/>
    
        </div>
      </div>
 </div>
 {/* Table Wrapper */}
<div className="flex items-start gap-2 ml-[-48px]">
      {/* Expand/Collapse Button - Left of Table */}
     <div className="relative group">
      
  <div className="flex items-center justify-center h-full w-full">
  <button
    onClick={() => setIsExpanded((prev) => !prev)}
    className="h-10 w-10 rounded-md bg-Dustyblue text-white font-bold text-xl hover:bg-blue-800 transition flex items-center justify-center"
  >
    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
  </button>
</div>


  {/* Custom Tooltip */}
  <div className="absolute left-10 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-1 transition-opacity duration-200 z-50 whitespace-nowrap">
    {isExpanded ? "Collapse Table" : "Expand Table"}
  </div>
</div>


  {/* Table Container */}
  <div className="shadow-md rounded-lg border border-Dustyblue overflow-hidden cursor-pointer w-full">
      <table className="w-full text-sm text-left">
        <thead className="bg-Dustyblue text-white text-base">
          <tr>
            <th className="px-4 py-3 w-[4%] border border-black/30 font-medium">Year</th>
            <th className="px-4 py-3 w-[10%] border border-black/30 font-medium">Market Area</th>
            <th className="px-4 py-3 w-[10%] border border-black/30 font-medium">Dealer</th>
            <th className="px-4 py-3 w-[10%] border border-black/30 font-medium">Created Date</th>
            <th className="px-4 py-3 w-[12%]  border border-black/30 font-medium">Created By</th>
           
            <th className="px-4 py-3 border border-black/30 font-medium">Department</th>
           
            <th className="px-4 py-3 border border-black/30 font-medium">Topic of Discussion</th>
            {isExpanded && (
              <>
                <th className="px-4 py-3 border border-black/30 font-medium">Closure Action</th>
                <th className="px-4 py-3 border border-black/30 font-medium">Meeting Date</th>
                <th className="px-4 py-3 border border-black/30 font-medium">Target Date</th>
                <th className="px-4 py-3 border border-black/30 font-medium">Revision Date</th>
              </>
            )}
            <th className="px-4 py-3 border border-black/30 font-medium">Status</th>
            <th className="px-2 py-3 border border-black/30 font-medium">Actions</th>
          </tr>
        </thead>

        <tbody>
          {paginatedData.length === 0 ? (
            <tr>
              <td colSpan={isExpanded ? 15 : 9} className="text-center py-4 text-gray-500">
                No records found.
              </td>
            </tr>
          ) : (
            paginatedData.map((row, index) => (
              <tr
                key={index}
                className={`${
                  index % 2 === 0 ? "bg-white" : "bg-gery1"
                } hover:bg-lightBlue`}
              >
                <td className="px-4 py-4 border border-black/30">{row.year}</td>
                <td className="px-4 py-4 border border-black/30">{row.marketArea}</td>
<td className="px-4 py-4 border border-black/30">
  <div className="relative ">
    {row.dealer}
    <span className="absolute top-full left-1/2 -translate-x-1/2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-black text-white text-[10px] rounded px-2 py-[1px] z-50 whitespace-nowrap pointer-events-none">
      {row.dealer}
    </span>
  </div>
</td>
                <td className="px-4 py-4 border border-black/30 whitespace-nowrap">{row.createdDate}</td>
<td className="px-4 py-4 border border-black/30">
  <div className="relative ">
    {row.createdBy}
    <span className="absolute top-full left-1/2 -translate-x-1/2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-black text-white text-[10px] rounded px-2 py-[1px] z-50 whitespace-nowrap pointer-events-none">
      {row.createdBy}
    </span>
  </div>
</td>
               
<td className="px-4 py-4 border border-black/30">
  <div className="relative ">
    {row.department}
    <span className="absolute top-full left-1/2 -translate-x-1/2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-black text-white text-[10px] rounded px-2 py-[1px] z-50 whitespace-nowrap pointer-events-none">
      {row.department}
    </span>
  </div>
</td>
               
 <td className="px-4 py-2 border border-black/30 text-left">
  <div className="relative group w-fit">
    {row.topicOfDiscussion}
    <span className="absolute top-full left-1/2 -translate-x-1/2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-black text-white text-[10px] rounded px-2 py-[1px] z-50 whitespace-nowrap pointer-events-none">
      {row.topicOfDiscussion}
    </span>
  </div>
</td>
                
                {isExpanded && (
                  <>
<td className="px-4 py-4 border border-black/30">
  <div className="relative group w-fit">
    {row.closureAction}
    <span className="absolute top-full left-1/2 -translate-x-1/2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-black text-white text-[10px] rounded px-2 py-[1px] z-50 whitespace-nowrap pointer-events-none">
      {row.closureAction}
    </span>
  </div>
</td>
                    <td className="px-4 py-4 border border-black/30 whitespace-nowrap">{row.meetingDate}</td>
                    <td className="px-4 py-4 border border-black/30 whitespace-nowrap">{row.targetDate}</td>
                    <td className="px-4 py-4 border border-black/30 whitespace-nowrap">{row.revisionDate}</td>
                  </>
                )}
                <td
                  className={`px-4 py-4 font-semibold border border-black/30 ${
                    row.status === "Open"
                      ? "text-mildBlue"
                      : row.status === "Closed"
                      ? "text-green6"
                      : "text-burntorange1"
                  }`}
                >
                  {row.status}
                </td>

                {/* Actions Column */}
                <td
                className={` border border-black/30 ${
    isExpanded ? "w-[110px] px-1 py-2" : "w-[90px] px-2 py-2"
  }`}
                >
                  <div className="grid grid-cols-2 gap-x-[2px] gap-y-2">
                    {/* Button Wrapper */}
                    {[
//                       {
// onClick: () =>
//   navigate("/editmonthlymeetingactionitem", {
//     state: {
//       year: row.year,
//       marketArea: row.marketArea,
//       dealer: row.dealer,
//     },
//   }),
//                         img: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/edit.png",
//                         label: "Edit",
//                         border: "border-green1",
//                       },
{
  onClick: () =>
    navigate("/editmonthlymeetingactionitem", {
      state: {
        rowData: row, // pass full row
      },
    }),
  img: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/edit.png",
  label: "Edit",
  border: "border-green1",
},

                      {
                        onClick: () => handleComments(row),
                        img: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/comment.png",
                        label: "Comment",
                        border: "border-green1",
                      },
                      {
                        onClick: () => handleLogs(row),
                        img: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/log.png",
                        label: "Logs",
                        border: "border-black",
                      },
                      {
                        onClick: () => handleDeleteClick(row),
                        img: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/delete.png",
                        label: "Delete",
                        border: "border-red1",
                      },
                    ].map((btn, i) => (
                      <div key={i} className="relative group">
                        <button
                          onClick={btn.onClick}
                          className={`w-7 h-7 flex items-center justify-center rounded-md border ${btn.border} hover:bg-white`}
                        >
                          <img src={btn.img} alt={btn.label} className="w-[12px] h-[12px]" />
                        </button>
                        <span className="absolute top-[110%] left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-black text-white text-[10px] rounded px-2 py-[1px] z-50 whitespace-nowrap pointer-events-none">
                          {btn.label}
                        </span>
                      </div>
                    ))}
                  </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>


</div>
  {totalPages > 1 && (
  <div className="flex justify-end mt-4 gap-2">
    <button
      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
      disabled={currentPage === 1}
      className="w-9 h-9 flex items-center justify-center rounded-lg bg-darkblue1 text-white text-lg font-bold hover:scale-110 transition disabled:opacity-50 disabled:cursor-not-allowed"
    >
      <ArrowLeft size={20} />
    </button>
    <button
      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
      disabled={currentPage === totalPages}
      className="w-9 h-9 flex items-center justify-center rounded-lg bg-darkblue1 text-white text-lg font-bold hover:scale-110 transition disabled:opacity-50 disabled:cursor-not-allowed"
    >
      <ArrowRight size={20} />
    </button>
    
  </div>

  
)}



{isCommentsPopupOpen && (
  <PdpCommentPopup
    comments={commentsData} // Pass the comments data
    onClose={closeCommentsPopup} // Pass the close function
  />
)}
   {isLogsPopupOpen && (
  <PdpLogPopup
    logsData={logsData} // Pass the logs data
    onClose={closeLogsPopup} // Pass the close function
  />
)} 
 {isDeleteModalOpen && (
        <DeleteModal
          isOpen={isDeleteModalOpen}
          onClose={closeDeleteModal}
          onConfirm={confirmDelete}
        />
      )}  
    </div>
  );
};

export default PdpActionitem;
