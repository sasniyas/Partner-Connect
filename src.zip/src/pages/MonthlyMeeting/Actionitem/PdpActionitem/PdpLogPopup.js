import React from "react";

const PdpLogPopup= ({ logsData, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg px-6 py-6 w-[50%] relative">
        {/* Header with Close Button */}
        <div className="flex justify-between items-center mb-0">
          <h2 className="text-base text-black font-semibold">Action Item Logs</h2>

          <button
            onClick={onClose}
            className=" "
          >
                              <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" alt="close" className="w-5 h-5" />

          </button>
        </div>
            <hr className="w-[15%] border-t-2 ml-[1px] border-darkorange mb-2" />

        {/* Logs Subheader */}
        <h3 className="text-center text-MediumGrey font-medium  text-base mb-4">
          {logsData.year} - {logsData.marketArea} - {logsData.dealer}
        </h3>

        {/* Logs Table */}
        <div className="border border-Dustyblue rounded-md  mb-6 bg-white overflow-hidden">
          <table className="w-full text-sm ">
            <thead className="bg-Dustyblue  text-white font-volovNovum  font-medium ">
              <tr>
                <th className="text-left py-4 px-8">Created Date</th>
                <th className="text-left py-4 px-4">Updated By</th>
                <th className="text-left py-4 px-4">Present Status</th>
                <th className="text-left py-4 px-4">Comments</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              <tr>
                <td className="text-left py-4 px-8 ">{logsData.createdDate}</td>
                <td className="text-left py-4 px-4">
  
    {logsData.createdBy}
 
</td>
                <td
  className={`text-left py-4 px-4 ${
    logsData.status === "Open"
      ? "text-mildBlue"
      : logsData.status === "Closed"
      ? "text-green6"
      : logsData.status === "On Going"
      ? "text-burntorange1"
      : "text-gray-500" // optional default color
  }`}
>
  {logsData.status}
</td>

                <td className="text-left py-4 px-4">{logsData.comments || "No comments"}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PdpLogPopup;