



import React, { useState, useEffect } from "react";
import Header from "../../../../Components/Header";
import { useNavigate } from "react-router-dom";
import SubNavbar3 from "../../../../Components/SubNavbar3";
// import Actionitem from "./Actionitem";
import PdpActionitem from "./PdpActionitem";

function PdPActionitemhome() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isMonthlyDropdownOpen, setIsMonthlyDropdownOpen] = useState(false);
  const [isActionDropdownOpen, setIsActionDropdownOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 mt-16 lg:mt-[150px] ${
          menuOpen ? "ml-60" : ""
        }`}
      >
        {/* 🔹 Top Navigation Tabs with Dropdowns */}
        <div className="flex w-full mb-4 relative z-10">
          {/* Monthly Meeting Tab (Inactive) */}
          <div
            className="w-1/2 relative text-center bg-grey2 border-b-2 border-grey2"
            onMouseEnter={() => setIsMonthlyDropdownOpen(true)}
            onMouseLeave={() => setIsMonthlyDropdownOpen(false)}
          >
            <button
              className="w-full py-4 text-base text-black font-normal"
              onClick={() => navigate("/monthlymeetinghomepage")}
            >
              Monthly Meeting
            </button>

            {isMonthlyDropdownOpen && (
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-0 bg-white px-6 py-4 w-[500px]">
                <ul className="flex items-center justify-center text-sm font-normal space-x-4 text-center">
                  <li
                    className="hover:text-darkblue1 hover:font-bold whitespace-nowrap cursor-pointer"
                    onClick={() => navigate("/monthlymeetinghomepage")}
                  >
                    Create Monthly Meeting
                  </li>
                  <div className="h-6 w-px bg-gray-300" />
                  <li
                    className="hover:text-darkblue1 hover:font-bold whitespace-nowrap cursor-pointer"
                    onClick={() => navigate("/viewmonthlymeeting")}
                  >
                    View Monthly Meeting
                  </li>
                </ul>
              </div>
            )}
          </div>

          {/* Action Items Tab (Active) */}
          <div
            className="w-1/2 relative text-center bg-white border-b-2 border-SteelBlue1"
            onMouseEnter={() => setIsActionDropdownOpen(true)}
            onMouseLeave={() => setIsActionDropdownOpen(false)}
          >
            <button
            onClick={() => navigate("/actionitemhomepage")}
             className="w-full py-4 text-base text-SteelBlue1 font-medium">
              Action Items
            </button>

            {isActionDropdownOpen && (
               <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-0 bg-white px-6 py-4 w-[500px]">
                <ul className="flex items-center justify-center text-sm font-normal space-x-4 text-center">
 
                  <li
        className="hover:text-darkblue1 hover:font-bold whitespace-nowrap cursor-pointer"
                    onClick={() => navigate("/actionitemhomepage")}
                  >
                    Monthly Meeting Action Item
                  </li>
                                    <div className="h-6 w-px bg-gray-300" />

                  <li
                    // className="hover:text-darkblue1 hover:font-bold whitespace-nowrap cursor-pointer"
                            className="text-darkblue1 font-bold whitespace-nowrap cursor-pointer"
 
                     onClick={() => navigate("/pdpactionitemhome")}
                  >
                    PDP Action Item
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* 🔹 Sub-Tab Buttons */}
       
        {/* 🔹 Main Content */}
        <div className="w-full flex justify-center mt-4">
          <div className="w-full max-w-[1280px] min-h-[700px] transition-all duration-300 ease-in-out">
            <PdpActionitem />
          </div>
        </div>
      </div>

      {/* 🔹 Scroll to Top Button */}
      {showScrollTop && (
        <div className="mt-12 mb-2 flex justify-end pr-4">
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="bg-Silvergrey text-black font-bold px-4 py-2 rounded-lg shadow-lg hover:scale-110 transition duration-200"
          >
            ↑
          </button>
        </div>
      )}
    </div>
  );
}

export default PdPActionitemhome;
