// import React from "react";

// const CommentPopup = ({ comments, onClose }) => {
//   return (
//     <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
//       <div className="bg-white rounded-lg shadow-lg px-12 py-6 w-[400px]">
//         <div className="flex justify-end  items-center mr-[-30px] mt-[-15px] mb-4">
//           <button 
//             onClick={onClose}
//           >
//             <img src= "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/close.png" alt="close" className="w-4 h-4 hover:scale-110 right-10 top1/2"/>
//           </button>
//         </div>
//         {comments.length > 0 ? (
//           <div className="border border-darkBlue rounded-md pb-4">
//             <table className="w-full bg-white text-sm">
//               <thead className="bg-sky/30 text-darkBlue">
//                 <tr>
//                   <th className="text-left">Commented Date</th>
//                   <th className="text-left">Commented By</th>
//                   <th className="text-left">Comments</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {comments.map((comment, index) => (
//                   <tr key={index}>
//                     <td>{comment.date}</td>
//                     <td>{comment.commentedBy}</td>
//                     <td>{comment.text}</td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         ) : (
//           <div className="bg-red2 text-red1 px-2 py-2 rounded-md mb-6 ">
//   <div className="flex items-center justify-center space-x-2 ">
//     <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/warning.png" alt="warning" className="w-4 h-4" />
//     <p className="text-sm font-VolvoNovum font-medium">There are no comments at this moment.</p>
//   </div>
// </div>

//         )}
//       </div>
//     </div>
//   );
// };

// export default CommentPopup;


// import React from "react";
// import { useState } from "react";
// const CommentPopup = ({ comments = [], onClose }) => {
//   // Dummy data fallback if no props passed
//   const dummyComments = [
//     { date: "2025-07-21", commentedBy: "Anand S", text: "Please close the pending task." },
//     { date: "2025-07-20", commentedBy: "Sasmiya CM", text: "Reviewed and updated as requested." },
//     { date: "2025-07-19", commentedBy: "John D", text: "Waiting for client confirmation." },
//   ];

//   const commentList = comments.length > 0 ? comments : dummyComments;
// const [editingIndex, setEditingIndex] = useState(null);
// const [editedComment, setEditedComment] = useState("");

// const handleEditClick = (index, currentText) => {
//   setEditingIndex(index);
//   setEditedComment(currentText);
// };

// const handleCancelEdit = () => {
//   setEditingIndex(null);
//   setEditedComment("");
// };

// const handleSaveComment = (index) => {
//   const updatedComments = [...commentList];
//   updatedComments[index].text = editedComment;
//   setCommentList(updatedComments);
//   setEditingIndex(null);
//   setEditedComment("");
// };

//   return (
//     <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
//       <div className="bg-white rounded-lg shadow-lg px-8 py-6 w-[800px]">
//         {/* Close Button */}
//         <div className="flex justify-end -mt-2 -mr-2 mb-3">
//           <button onClick={onClose}>
//             <img
//               src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/close.png"
//               alt="close"
//               className="w-4 h-4 hover:scale-110 transition"
//             />
//           </button>
//         </div>

//         {/* Comment Table */}
//         {commentList.length > 0 ? (
//           <div className="border border-Dustyblue rounded-md overflow-hidden">
//             <table className="w-full text-sm">
//               <thead className="bg-Dustyblue text-white  font-medium">
//                 <tr>
//                   <th className="text-left px-3 py-2">Commented Date</th>
//                   <th className="text-left px-3 py-2">Commented By</th>
//                   <th className="text-left px-3 py-2">Comments</th>
//                 </tr>
//               </thead>
//               <tbody>
//   {commentList.map((comment, index) => (
//     <tr key={index} className="border-t text-black/80">
//       <td className="px-3 py-2">{comment.date}</td>
//       <td className="px-3 py-2">{comment.commentedBy}</td>
//       <td className="px-3 py-2 relative group">
//         {editingIndex === index ? (
//           <div>
//             <textarea
//               value={editedComment}
//               onChange={(e) => setEditedComment(e.target.value)}
//               className="w-full border rounded px-2 py-1 text-sm"
//               rows={2}
//             />
//             <div className="flex gap-2 mt-1">
//               <button
//                 onClick={() => handleSaveComment(index)}
//                 className="text-green-600 text-xs font-medium hover:underline"
//               >
//                 Save
//               </button>
//               <button
//                 onClick={handleCancelEdit}
//                 className="text-red-600 text-xs font-medium hover:underline"
//               >
//                 Cancel
//               </button>
//             </div>
//           </div>
//         ) : (
//           <div className="flex justify-between items-center">
//             <span>{comment.text}</span>
//             <img
//               src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/edit.png"
//               alt="Edit"
//               className="w-4 h-4 ml-2 cursor-pointer hover:scale-110"
//               onClick={() => handleEditClick(index, comment.text)}
//             />
//           </div>
//         )}
//       </td>
//     </tr>
//   ))}
// </tbody>

//             </table>
//           </div>
//         ) : (
//           <div className="bg-red2 text-red1 px-3 py-3 rounded-md">
//             <div className="flex items-center justify-center gap-2">
//               <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/warning.png" alt="warning" className="w-4 h-4" />
//               <p className="text-sm font-VolvoNovum font-medium">
//                 There are no comments at this moment.
//               </p>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default CommentPopup;


import React, { useState, useEffect } from "react";

const PdpCommentPopup = ({ comments = [], onClose }) => {
  const dummyComments = [
    { date: "2025-07-21", commentedBy: "Anand S", text: "Please close the pending task." },
    { date: "2025-07-20", commentedBy: "Sasmiya CM", text: "Reviewed and updated as requested." },
    { date: "2025-07-19", commentedBy: "John D", text: "Waiting for client confirmation." },
  ];

  const [commentList, setCommentList] = useState([]);
  const [editingIndex, setEditingIndex] = useState(null);
  const [editedComment, setEditedComment] = useState("");

  // Initialize comment list
  useEffect(() => {
    setCommentList(comments.length > 0 ? comments : dummyComments);
  }, [comments]);

  const handleEditClick = (index, currentText) => {
    setEditingIndex(index);
    setEditedComment(currentText);
  };

  const handleCancelEdit = () => {
    setEditingIndex(null);
    setEditedComment("");
  };

  const handleSaveComment = (index) => {
    const updatedComments = [...commentList];
    updatedComments[index].text = editedComment;
    setCommentList(updatedComments);
    setEditingIndex(null);
    setEditedComment("");
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg px-8 py-6 w-[800px]">
        {/* Close Button */}
        <div className="flex justify-end -mt-2 -mr-2 mb-3">
          <button onClick={onClose}>
                   <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" alt="close" className="w-5 h-5" />

          </button>
        </div>

        {/* Comment Table */}
        {commentList.length > 0 ? (
          <div className="border border-Dustyblue rounded-md overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-Dustyblue text-white">
                <tr>
                  <th className="text-left px-3 py-2  font-medium">Commented Date</th>
                  <th className="text-left px-3 py-2  font-medium">Commented By</th>
                  <th className="text-left px-3 py-2  font-medium">Comments</th>
                </tr>
              </thead>
              <tbody>
                {commentList.map((comment, index) => (
                  <tr key={index} className="border-t text-black/80">
                    <td className="px-3 py-2">{comment.date}</td>
                    <td className="px-3 py-2">{comment.commentedBy}</td>
                  <td className="px-3 py-2 relative group">
  {editingIndex === index ? (
    <div>
      <textarea
        value={editedComment}
        onChange={(e) => setEditedComment(e.target.value)}
        className="w-full border rounded px-2 py-1 text-sm resize-none"
        rows={2}
      />
      <div className="flex gap-2 mt-1">
        <button
          onClick={handleCancelEdit}
          className="text-red1 text-xs font-medium border border-red1 px-2 py-1 rounded hover:bg-red1 hover:text-white transition duration-200"
        >
          Cancel
        </button>
        <button
          onClick={() => handleSaveComment(index)}
          className="text-darkblue1 text-xs font-medium border border-darkblue1 px-2 py-1 rounded hover:bg-darkblue1 hover:text-white transition duration-200"
        >
          Save
        </button>
      </div>
    </div>
  ) : (
    <div className="flex justify-between items-center">
      <span>{comment.text}</span>

      {/* Edit Icon with Tooltip */}
      <div className="relative group ml-2">
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/edit.png"

          alt="Edit"
          className="w-4 h-4 cursor-pointer hover:scale-110"
          onClick={() => handleEditClick(index, comment.text)}
        />
        <span className="absolute top-[110%] left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-black text-white text-[10px] rounded px-2 py-[1px] z-50 whitespace-nowrap pointer-events-none">
          edit
        </span>
      </div>
    </div>
  )}
</td>

                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="bg-red2 text-red1 px-3 py-3 rounded-md">
            <div className="flex items-center justify-center gap-2">
              <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthlymeeting/warning.png" alt="warning" className="w-4 h-4" />
              <p className="text-sm font-VolvoNovum font-medium">
                There are no comments at this moment.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PdpCommentPopup;
