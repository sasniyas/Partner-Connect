import React, { useState, useEffect } from "react";
import Header from "../../Components/Header";
import CreateMonthlyMeeting from "./CreateMonthlyMeeting";
import { useNavigate } from "react-router-dom";
import SubNavbar3 from "../../Components/SubNavbar3";

function MonthlymeetingHomepage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isMonthlyDropdownOpen, setIsMonthlyDropdownOpen] = useState(false);
  const [isActionDropdownOpen, setIsActionDropdownOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="bg-Frostwhite min-h-screen  flex-col  ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "ml-60" : ""
        }`}
      >
                <div className="w-full mt-[4.5rem] lg:mt-[6rem] ">

        {/* 🔹 Tabs with Dropdowns */}
        <div className="flex w-full relative z-10">
          {/* Monthly Meeting Dropdown */}
          <div
            className="w-1/2 relative text-center bg-white border-b-2 border-SteelBlue1"
            onMouseEnter={() => setIsMonthlyDropdownOpen(true)}
            onMouseLeave={() => setIsMonthlyDropdownOpen(false)}
          >
            <button 
            onClick={() => navigate("/monthlymeetinghomepage")}
            className="w-full py-2.5 text-sm text-SteelBlue1 font-medium">
              Monthly Meeting
            </button>

     {isMonthlyDropdownOpen && (
  <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-0 bg-white px-6 py-4 w-[500px] ">
    <ul className="flex items-center justify-center text-xs font-normal space-x-4 text-center">
      <li
        className="text-darkblue1 font-bold whitespace-nowrap cursor-pointer"
        onClick={() => navigate("/monthlymeetinghomepage")}
      >
        Create Monthly Meeting
      </li>

      {/* Divider */}
      <div className="h-6 w-px bg-gray-300" />

      <li
        className="hover:text-darkblue1 hover:font-bold whitespace-nowrap cursor-pointer"
        onClick={() => navigate("/viewmonthlymeeting")}
      >
        View Monthly Meeting
      </li>
    </ul>
  </div>
)}


          </div>

          {/* Action Items Dropdown */}
          <div
            className="w-1/2 relative text-center bg-grey2 border-b-2 border-grey2"
            onMouseEnter={() => setIsActionDropdownOpen(true)}
            onMouseLeave={() => setIsActionDropdownOpen(false)}
          >
            <button 
            onClick={() => navigate("/actionitemhomepage")}
            className="w-full py-2.5 text-sm text-black font-normal">
              Action Items
            </button>

            {/* {isActionDropdownOpen && (
   <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-0 bg-white px-6 py-4 w-[500px] ">
    <ul className="flex items-center justify-center text-sm font-normal space-x-4 text-center">
                  <li
        className="hover:text-darkblue1 hover:font-bold whitespace-nowrap cursor-pointer"
                    onClick={() => navigate("/actionitemhomepage")}
                  >
                    Monthly Meeting Action Item
                  </li>
                   <div className="h-6 w-px bg-gray-300" />

                  <li
        className="hover:text-darkblue1 hover:font-bold whitespace-nowrap cursor-pointer"
                    onClick={() => navigate("/pdpactionitemhome")}
                  >
                    PDP Action Item
                  </li>
                </ul>
              </div>
            )} */}
          </div>
        </div>

        {/* 🔹 Content Area */}
        <div className="w-full flex justify-center overflow-y-hidden">
          <div className="w-full   transition-all duration-300 ease-in-out">
            <CreateMonthlyMeeting />
          </div>
        </div>
      </div>

      {/* 🔹 Scroll to Top Button */}
   
    </div>
    </div>
  );
}

export default MonthlymeetingHomepage;
