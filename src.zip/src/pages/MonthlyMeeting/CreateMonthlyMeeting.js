import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { addMonthlyMeeting, updateMonthlyMeeting, getAllMonthlyMeetings, getMonthlyMeetingById } from "../../services/monthlyMeeting/monthlyMeeting/monthlyMeeting.service";
import { getMarketAreas } from "../../services/pdpMaster/marketArea.service";
import { getDealers } from "../../services/pdpMaster/dealership.service";
import { getDealerUsers, getVolvoUsers } from "../../services/userManagement/userManagement.service";
import { useKeyboardNavigation } from "../../util/useKeyboardNavigation";
import TimeSelector from "../../Components/TimeSelector";
import { useLocation } from "react-router-dom";

const CreateMonthlyMeeting = () => {
  const navigate = useNavigate();
  const [isEditMode, setIsEditMode] = useState(false);
  const [editingData, setEditingData] = useState(null);
  const location = useLocation();
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isDataLoading, setIsDataLoading] = useState(true);
  const [isCloneMode, setIsCloneMode] = useState(false);
  const [hasPreviousMeetings, setHasPreviousMeetings] = useState(false);
  const [isCloneCheckLoading, setIsCloneCheckLoading] = useState(true);
  const [marketAreaSearch, setMarketAreaSearch] = useState("");
  const [dealerSearch, setDealerSearch] = useState("");
  const [dealerUserSearch, setDealerUserSearch] = useState(""); // FIX 1: Added dealer user search state
  const [volvoUserSearch, setVolvoUserSearch] = useState("");
  const [startOpen, setStartOpen] = useState(false);
  const [endOpen, setEndOpen] = useState(false);
const marketListRef = useRef(null);
  const startRef = useRef(null);
  const endRef = useRef(null);

  // API Data
  const [marketAreas, setMarketAreas] = useState([]);
  const [dealers, setDealers] = useState([]);
  const [filteredDealers, setFilteredDealers] = useState([]);
  const [dealerUsers, setDealerUsers] = useState([]);
  const [volvoUsers, setVolvoUsers] = useState([]);
  const formRef = useRef(null);

  // Refs
  const wrapperRef = useRef(null);
  const meetingDateRef = useRef(null);
  const externalEmailRef = useRef(null);
  const optionalEmailRef = useRef(null);
  const repeatUntilRef = useRef(null);

  // Dropdown states
  const [isOpen, setIsOpen] = useState(false);
  const [isDealerOpen, setIsDealerOpen] = useState(false);
  const [isRecurringOpen, setIsRecurringOpen] = useState(false);
  const [isDealerUserOpen, setIsDealerUserOpen] = useState(false);
  const [isVolvoUserOpen, setIsVolvoUserOpen] = useState(false);
  const [isVenueOpen, setIsVenueOpen] = useState(false);

  // Email input states
  const [externalEmailInput, setExternalEmailInput] = useState("");
  const [optionalEmailInput, setOptionalEmailInput] = useState("");

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const convertToMinutes = (timeStr) => {
    if (!timeStr) return null;
    const [time, modifier] = timeStr.split(" ");
    let [hours, minutes] = time.split(":").map(Number);
    if (modifier === "PM" && hours !== 12) hours += 12;
    if (modifier === "AM" && hours === 12) hours = 0;
    return hours * 60 + minutes;
  };

  // Helper to flush any pending email inputs — returns the updated data without mutating state directly
  const flushPendingEmails = () => {
    const updatedExternalEmail = [...formData.externalEmail];
    const updatedOptionalEmail = [...formData.optionalEmail];
    let hasChanges = false;

    const extEmail = externalEmailInput.trim().replace(/[,;]$/, "");
    if (extEmail && emailRegex.test(extEmail)) {
      updatedExternalEmail.push(extEmail);
      setExternalEmailInput("");
      hasChanges = true;
    }

    const optEmail = optionalEmailInput.trim().replace(/[,;]$/, "");
    if (optEmail && emailRegex.test(optEmail)) {
      updatedOptionalEmail.push(optEmail);
      setOptionalEmailInput("");
      hasChanges = true;
    }

    if (hasChanges) {
      setFormData(prev => ({
        ...prev,
        externalEmail: updatedExternalEmail,
        optionalEmail: updatedOptionalEmail,
      }));
    }

    // Return the snapshot with flushed emails for immediate use
    return {
      ...formData,
      externalEmail: updatedExternalEmail,
      optionalEmail: updatedOptionalEmail,
    };
  };

  // Form data - aligned with backend fields
  const [formData, setFormData] = useState({
    marketArea: "",
    market_area_id: null,
    dealer: "",
    dealer_id: null,
    meetingDate: "",
    startTime: "",
    endTime: "",
    recurringMeeting: "",
    repeatUntil: "",       // maps to backend limit_date
    nextMeetingDate: "",   // maps to backend next_meeting_date
    dealerUser: [],
    dealerUserIds: [],
    volvoUser: [],
    volvoUserIds: [],
    externalEmail: [],
    optionalEmail: [],
    venue: "",
    location: "",
    link: "",
    agenda: "",
    agendaFile: null,
    agenda_file: null,
    existing_agenda_file_url: null,
  });
const getRepeatUntilMaxDate = () => {
  if (!formData.meetingDate) return "";

  const meeting = new Date(formData.meetingDate);
  const maxDate = new Date(meeting);

  if (formData.recurringMeeting === "Weekly") {
    maxDate.setMonth(maxDate.getMonth() + 6); // 6 months
  } else {
    maxDate.setFullYear(maxDate.getFullYear() + 1); // 1 year
  }

  return maxDate.toISOString().split("T")[0];
};
  // Options
  const venueOptions = ["Virtual", "Physical"].sort();
  const recurringMeetingOptions = [
    "Annually",
    "Half Yearly",
    "Monthly",
    "One-time Meeting",
    "Quarterly",
    "Weekly",
  ].sort();

  // Close all dropdowns
  const closeAllDropdowns = () => {
    setIsOpen(false);
    setIsDealerOpen(false);
    setIsRecurringOpen(false);
    setIsDealerUserOpen(false);
    setIsVolvoUserOpen(false);
    setIsVenueOpen(false);

    setMarketAreaSearch ("");
    setDealerSearch("");
    setDealerUserSearch("");
    setVolvoUserSearch ("");
    
  };

  // Close dropdowns when clicking outside
  useEffect(() => {
  const handleClickOutside = (event) => {
    if (!event.target.closest(".dropdown-wrapper")) {
      closeAllDropdowns();
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        startRef.current?.contains(e.target) ||
        endRef.current?.contains(e.target)
      ) {
        return;
      }
      setStartOpen(false);
      setEndOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Load data on mount
  useEffect(() => {
    const loadData = async () => {
      try {
        setIsDataLoading(true);
        const [marketAreasData, dealersData, dealerUsersData, volvoUsersData] = await Promise.all([
          getMarketAreas(),
          getDealers(),
          getDealerUsers(),
          getVolvoUsers(),
        ]);

        setMarketAreas((marketAreasData || []).filter(ma => ma.isActive === 1));
        setDealers((dealersData || []).filter(d => d.isActive === 1));
        setDealerUsers((dealerUsersData || []).filter(u => u.status === "ACTIVE"));
        setVolvoUsers((volvoUsersData || []).filter(u => u.status === "ACTIVE"));
      } catch (error) {
        console.error("Error loading data:", error);
        setErrors({ data: "Failed to load data. Please refresh the page." });
      } finally {
        setIsDataLoading(false);
      }
    };
    loadData();
  }, []);

  // Check if previous meetings exist for clone availability
  useEffect(() => {
    const checkCloneAvailability = async () => {
      try {
        setIsCloneCheckLoading(true);
        const response = await getAllMonthlyMeetings();
        const allMeetings = response?.data?.data || response?.data || [];
        setHasPreviousMeetings(Array.isArray(allMeetings) && allMeetings.length > 0);
      } catch (error) {
        console.error("Error checking clone availability:", error);
        setHasPreviousMeetings(false);
      } finally {
        setIsCloneCheckLoading(false);
      }
    };
    checkCloneAvailability();
  }, []);

  // Toggle functions
  const toggleDropdown = (setter, currentState) => {
    closeAllDropdowns();
    setter(!currentState);
  };

  // Handle market area select
  const handleMarketAreaSelect = (marketAreaId, marketAreaName) => {
    setFormData(prev => ({
      ...prev,
      marketArea: marketAreaName,
      market_area_id: marketAreaId,
      dealer: "",
      dealer_id: null,
    }));
    setFilteredDealers(dealers.filter(dealer => dealer.market_id === marketAreaId));
    setIsOpen(false);
    setErrors(prev => ({ ...prev, marketArea: "" }));
  };

  // Handle dealer select
  const handleDealerSelect = (dealerId, dealerName) => {
    setFormData(prev => ({
      ...prev,
      dealer: dealerName,
      dealer_id: dealerId,
    }));
    setIsDealerOpen(false);
    setErrors(prev => ({ ...prev, dealer: "" }));
  };

  // Handle change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setErrors(prev => ({ ...prev, [name]: "" }));
  };

  // Handle date change
  // FIX 3: Auto-clear repeatUntil if it becomes invalid when meetingDate changes
  const handleDateChange = (e) => {
    const newDate = e.target.value;
    setFormData(prev => ({
      ...prev,
      meetingDate: newDate,
      // Clear repeatUntil if it's now before the new meeting date
      repeatUntil:
        prev.repeatUntil && newDate && prev.repeatUntil < newDate
          ? ""
          : prev.repeatUntil,
    }));
    setErrors(prev => ({ ...prev, meetingDate: "" }));
  };

  // Handle file attachment
  const handleAgendaAttachment = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({
          ...prev,
          agendaFile: { name: file.name, type: file.type, preview: reader.result },
          agenda_file: file,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.market_area_id)
      newErrors.marketArea = "Please fill this field";

    if (!formData.dealer_id)
      newErrors.dealer = "Please fill this field";

    if (!formData.meetingDate)
      newErrors.meetingDate = "Please fill this field";

    if (!formData.startTime)
      newErrors.startTime = "Please fill this field";

    if (!formData.endTime)
      newErrors.endTime = "Please fill this field";

    // End Time must be after Start Time
    if (formData.startTime && formData.endTime) {
      const startMinutes = convertToMinutes(formData.startTime);
      const endMinutes = convertToMinutes(formData.endTime);
      if (startMinutes !== null && endMinutes !== null && endMinutes <= startMinutes) {
        newErrors.endTime = "End time must be after start time";
      }
    }

    if (formData.dealerUser.length === 0)
      newErrors.dealerUser = "Please fill this field";

    if (formData.volvoUser.length === 0)
      newErrors.volvoUser = "Please fill this field";

    if (!formData.recurringMeeting)
      newErrors.recurringMeeting = "Please fill this field";

    // Repeat Until validation (only if not One-time Meeting) - maps to backend limit_date
    if (
      formData.recurringMeeting &&
      formData.recurringMeeting !== "One-time Meeting" &&
      !formData.repeatUntil?.trim()
    ) {
      newErrors.repeatUntil = "Please fill this field";
    }

    if (!formData.venue)
      newErrors.venue = "Please fill this field";

    if (!formData.agenda?.trim())
      newErrors.agenda = "Please fill this field";

    if (formData.venue === "Virtual" && !formData.link)
      newErrors.link = "Please fill this field";

    if (formData.venue === "Physical" && !formData.location)
      newErrors.location = "Please fill this field";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle submit - CREATE new meeting via API
  // FIX 2: Flush pending emails before submit
  const handleSubmit = async () => {
    closeAllDropdowns();

    // Flush any pending email inputs and get snapshot
    const currentData = flushPendingEmails();

    if (!validateForm()) {
      window.scrollTo(0, 0);
      return;
    }

    setIsLoading(true);

    try {
      const isRecurring = currentData.recurringMeeting && currentData.recurringMeeting !== "One-time Meeting";

      const meetingData = {
        market_area_id: currentData.market_area_id,
        dealer_id: currentData.dealer_id,
        meeting_date: currentData.meetingDate,
        start_time: currentData.startTime,
        end_time: currentData.endTime,
        recurring_meeting: currentData.recurringMeeting,
        meeting_mode: currentData.venue,
        meeting_venue: currentData.venue === "Physical" ? currentData.location : "",
        meet_link: currentData.venue === "Virtual" ? currentData.link : "",
        agenda_text: currentData.agenda,
        agenda_file: currentData.agenda_file,
        dealerUserIds: currentData.dealerUserIds,
        volvoUserIds: currentData.volvoUserIds,
        externalEmails: currentData.externalEmail || [],
        optionalEmails: currentData.optionalEmail || [],
        // Backend fields for recurring meetings
        limit_date: isRecurring ? currentData.repeatUntil : null,
        next_meeting_date: isRecurring ? currentData.nextMeetingDate : null,
      };

      const response = await addMonthlyMeeting(meetingData);
      if (response.status) {
        window.scrollTo(0, 0);
        navigate("/viewmonthlymeeting");
      } else {
        setErrors({ submit: response.message || "Failed to create meeting" });
      }
    } catch (error) {
      setErrors({ submit: error.message || "Failed to create meeting" });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle update - UPDATE existing meeting via API
  // FIX 2: Flush pending emails before update
  const handleUpdate = async () => {
    closeAllDropdowns();

    // Flush any pending email inputs and get snapshot
    const currentData = flushPendingEmails();

    if (!validateForm()) {
      window.scrollTo(0, 0);
      return;
    }

    setIsLoading(true);

    try {
      const isRecurring = currentData.recurringMeeting && currentData.recurringMeeting !== "One-time Meeting";

      const payload = {
        id: editingData.id,
        market_area_id: currentData.market_area_id,
        dealer_id: currentData.dealer_id,
        meeting_date: currentData.meetingDate,
        start_time: currentData.startTime,
        end_time: currentData.endTime,
        recurring_meeting: currentData.recurringMeeting,
        meeting_mode: currentData.venue,
        meeting_venue: currentData.venue === "Physical" ? currentData.location : "",
        meet_link: currentData.venue === "Virtual" ? currentData.link : "",
        agenda_text: currentData.agenda,
        // Send new file if uploaded, otherwise preserve existing file reference
        agenda_file: currentData.agenda_file || null,
        existing_agenda_file_url: !currentData.agenda_file ? currentData.existing_agenda_file_url : null,
        // Flag to tell backend if file was removed
        remove_agenda_file: !currentData.agendaFile && !currentData.agenda_file && !currentData.existing_agenda_file_url,
        dealerUserIds: currentData.dealerUserIds,
        volvoUserIds: currentData.volvoUserIds,
        externalEmails: currentData.externalEmail || [],
        optionalEmails: currentData.optionalEmail || [],
        limit_date: isRecurring ? currentData.repeatUntil : null,
        next_meeting_date: isRecurring ? currentData.nextMeetingDate : null,
      };

      const response = await updateMonthlyMeeting(payload);
      if (response.status) {
        window.scrollTo(0, 0);
        navigate("/viewmonthlymeeting");
      } else {
        setErrors({ submit: response.message || "Failed to update meeting" });
      }
    } catch (error) {
      setErrors({ submit: error.message || "Failed to update meeting" });
    } finally {
      setIsLoading(false);
    }
  };

  // Load edit data from navigation state
  useEffect(() => {
    if (location.state?.meeting && dealers.length > 0) {
      const meeting = location.state.meeting;

      setIsEditMode(true);
      setEditingData(meeting);

      // Filter dealers for selected market
      if (meeting.market_area_id) {
        setFilteredDealers(
          dealers.filter(d => d.market_id === meeting.market_area_id)
        );
      }

      const formatDateForInput = (dateString) => {
        if (!dateString) return "";
        const date = new Date(dateString);
        if (isNaN(date)) return "";
        return date.toISOString().split("T")[0];
      };

      setFormData({
        marketArea: meeting.marketArea || meeting.marketarea || "",
        market_area_id: meeting.market_area_id || null,
        dealer: meeting.dealer || meeting.dealer_name || "",
        dealer_id: meeting.dealer_id || null,
        meetingDate: formatDateForInput(meeting.meetingDate || meeting.dateTime || meeting.meeting_date),
        startTime: meeting.start_time || "",
        endTime: meeting.end_time || "",
        recurringMeeting: meeting.recurring_meeting || "",
        repeatUntil: formatDateForInput(meeting.limit_date || ""),
        nextMeetingDate: formatDateForInput(meeting.next_meeting_date || ""),
        dealerUser:
          meeting.dealerUser?.map(u => ({
            id: u.user_id || u.id,
            name: u.user_name || u.name
          })) || [],
        dealerUserIds:
          meeting.dealerUser?.map(u => u.user_id || u.id) || [],
        volvoUser:
          meeting.volvoUser?.map(u => ({
            id: u.user_id || u.id,
            name: u.user_name || u.name
          })) || [],
        volvoUserIds:
          meeting.volvoUser?.map(u => u.user_id || u.id) || [],
        externalEmail: meeting.externalEmail || meeting.external_emails || [],
        optionalEmail: meeting.optionalEmail || meeting.optional_emails || [],
        venue: meeting.meeting_mode || "",
        location: meeting.meeting_venue || "",
        link: meeting.meet_link || meeting.meeting_link || "",
        agenda: meeting.agenda_text || "",
        // Load existing file from backend if available
        agendaFile: meeting.agenda_file_url || meeting.agenda_link || meeting.agenda_file_name
          ? {
              name: meeting.agenda_file_name || (meeting.agenda_file_url || meeting.agenda_link)?.split("/").pop() || "Attached File",
              type: meeting.agenda_file_type || ((meeting.agenda_file_url || meeting.agenda_link)?.match(/\.(jpg|jpeg|png|gif|svg|webp|bmp)$/i) ? "image/" + ((meeting.agenda_file_url || meeting.agenda_link).split(".").pop().toLowerCase() === "svg" ? "svg+xml" : (meeting.agenda_file_url || meeting.agenda_link).split(".").pop().toLowerCase()) : "application/octet-stream"),
              preview: meeting.agenda_file_url || meeting.agenda_link || "",
              isExisting: true, // Flag to identify this is from backend, not a new upload
            }
          : null,
        agenda_file: null, // null means no new file uploaded yet; backend keeps old file
        existing_agenda_file_url: meeting.agenda_file_url || meeting.agenda_link || null, // preserve existing file reference
      });
    }
  }, [location.state, dealers]);

  // Handle clone from ViewDetails page (receives cloneMeeting state)
  useEffect(() => {
    if (location.state?.cloneMeeting && dealers.length > 0) {
      const m = location.state.cloneMeeting;

      if (m.market_area_id) {
        setFilteredDealers(dealers.filter(d => d.market_id === m.market_area_id));
      }

      const formatDateForInput = (dateString) => {
        if (!dateString) return "";
        const date = new Date(dateString);
        if (isNaN(date)) return "";
        return date.toISOString().split("T")[0];
      };

      setFormData({
        marketArea: m.marketArea || m.marketarea || "",
        market_area_id: m.market_area_id || null,
        dealer: m.dealer || m.dealer_name || "",
        dealer_id: m.dealer_id || null,
        meetingDate: formatDateForInput(m.meetingDate || m.meeting_date || ""),
        startTime: m.start_time || m.startTime || "",
        endTime: m.end_time || m.endTime || "",
        recurringMeeting: m.recurring_meeting || m.recurringMeeting || "",
        repeatUntil: formatDateForInput(m.limit_date || m.repeatUntil || ""),
        nextMeetingDate: formatDateForInput(m.next_meeting_date || m.nextMeetingDate || ""),
        dealerUser: (m.dealer_users || m.dealerUser || []).map(u => ({
          id: u.user_id || u.id,
          name: u.user_name || u.name
        })),
        dealerUserIds: (m.dealer_users || m.dealerUser || []).map(u => u.user_id || u.id),
        volvoUser: (m.volvo_users || m.volvoUser || []).map(u => ({
          id: u.user_id || u.id,
          name: u.user_name || u.name
        })),
        volvoUserIds: (m.volvo_users || m.volvoUser || []).map(u => u.user_id || u.id),
        externalEmail: m.external_emails || m.externalEmail || [],
        optionalEmail: m.optional_emails || m.optionalEmail || [],
        venue: m.meeting_mode || m.venue || "",
        link: (m.meeting_mode || m.venue) === "Virtual" ? (m.meeting_link || m.meet_link || m.link || "") : "",
        location: (m.meeting_mode || m.venue) === "Physical" ? (m.meeting_venue || m.location || "") : "",
        agenda: m.agenda_text || m.agenda || "",
        agendaFile: (m.agenda_file_url || m.agenda_link)
          ? {
              name: (m.agenda_file_url || m.agenda_link)?.split("/").pop() || "Attached File",
              type: (m.agenda_file_url || m.agenda_link)?.match(/\.(jpg|jpeg|png|gif|svg|webp|bmp)$/i) ? "image/" + ((m.agenda_file_url || m.agenda_link).split(".").pop().toLowerCase() === "svg" ? "svg+xml" : (m.agenda_file_url || m.agenda_link).split(".").pop().toLowerCase()) : "application/octet-stream",
              preview: m.agenda_file_url || m.agenda_link || "",
              isExisting: true,
            }
          : null,
        agenda_file: null,
        existing_agenda_file_url: m.agenda_file_url || m.agenda_link || null,
      });

      setIsCloneMode(true);
      setIsEditMode(false);
      setEditingData(null);
      setErrors({});
      setExternalEmailInput("");
      setOptionalEmailInput("");
      setDealerUserSearch("");
      setVolvoUserSearch("");
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [location.state, dealers]);

  // Handle cancel
  const handleCancel = () => {
    if (isCloneMode) {
      setIsCloneMode(false);
    }
    resetForm();
    navigate("/viewmonthlymeeting");
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      marketArea: "", market_area_id: null, dealer: "", dealer_id: null,
      meetingDate: "", startTime: "", endTime: "", recurringMeeting: "",
      repeatUntil: "", nextMeetingDate: "",
      dealerUser: [], dealerUserIds: [], volvoUser: [], volvoUserIds: [],
      externalEmail: [], optionalEmail: [], venue: "", location: "", link: "",
      agenda: "", agendaFile: null, agenda_file: null, existing_agenda_file_url: null,
    });
    setFilteredDealers([]);
    setErrors({});
    setExternalEmailInput("");
    setOptionalEmailInput("");
    setDealerUserSearch("");
    setVolvoUserSearch("");
    setMarketAreaSearch("");
    setDealerSearch("");
  };

  // Handle clone
  const handleClone = async () => {
    try {
      if (isDataLoading) {
        alert("Please wait for data to load.");
        return;
      }

      const response = await getAllMonthlyMeetings();
      const allMeetings = response?.data?.data || response?.data || [];

      if (!Array.isArray(allMeetings) || allMeetings.length === 0) {
        alert("No previous meeting found to clone.");
        return;
      }

      const sortedMeetings = [...allMeetings].sort((a, b) =>
        new Date(b.meeting_date || 0) - new Date(a.meeting_date || 0)
      );
      const latestMeetingSummary = sortedMeetings[0];

      // Fetch full meeting details by ID (includes agenda_file_url, users, emails etc.)
      const fullResponse = await getMonthlyMeetingById(latestMeetingSummary.id);
      // Service returns { status: true, data: { ...meeting } }
      const latestMeeting = fullResponse?.data || latestMeetingSummary;
      // Backend may return file URL as agenda_file_url or agenda_link
      const fileUrl = latestMeeting.agenda_file_url || latestMeeting.agenda_link || null;

      if (latestMeeting.market_area_id) {
        setFilteredDealers(dealers.filter(d => d.market_id === latestMeeting.market_area_id));
      }

      const formatDateForInput = (dateString) => {
        if (!dateString) return "";
        const date = new Date(dateString);
        if (isNaN(date)) return "";
        return date.toISOString().split("T")[0];
      };

      setFormData({
        marketArea: latestMeeting.marketarea || latestMeeting.marketArea || "",
        market_area_id: latestMeeting.market_area_id || null,
        dealer: latestMeeting.dealer_name || latestMeeting.dealer || "",
        dealer_id: latestMeeting.dealer_id || null,
        meetingDate: formatDateForInput(latestMeeting.meeting_date),
        startTime: latestMeeting.start_time || "",
        endTime: latestMeeting.end_time || "",
        recurringMeeting: latestMeeting.recurring_meeting || "",
        repeatUntil: formatDateForInput(latestMeeting.limit_date || ""),
        nextMeetingDate: formatDateForInput(latestMeeting.next_meeting_date || ""),
        dealerUser: latestMeeting.dealer_users?.map(u => ({ id: u.user_id, name: u.user_name })) || [],
        volvoUser: latestMeeting.volvo_users?.map(u => ({ id: u.user_id, name: u.user_name })) || [],
        dealerUserIds: latestMeeting.dealer_users?.map(u => u.user_id) || [],
        volvoUserIds: latestMeeting.volvo_users?.map(u => u.user_id) || [],
        externalEmail: latestMeeting.external_emails || latestMeeting.externalEmail || [],
        optionalEmail: latestMeeting.optional_emails || latestMeeting.optionalEmail || [],
        venue: latestMeeting.meeting_mode || "",
        link: latestMeeting.meeting_mode === "Virtual" ? (latestMeeting.meet_link || latestMeeting.meeting_link || "") : "",
        location: latestMeeting.meeting_mode === "Physical" ? (latestMeeting.meeting_venue || "") : "",
        agenda: latestMeeting.agenda_text || "",
        agendaFile: fileUrl
          ? {
              name: latestMeeting.agenda_file_name || fileUrl.split("/").pop() || "Attached File",
              type: latestMeeting.agenda_file_type || (fileUrl.match(/\.(jpg|jpeg|png|gif|svg|webp|bmp)$/i) ? "image/" + (fileUrl.split(".").pop().toLowerCase() === "svg" ? "svg+xml" : fileUrl.split(".").pop().toLowerCase()) : "application/octet-stream"),
              preview: fileUrl,
              isExisting: true,
            }
          : null,
        agenda_file: null,
        existing_agenda_file_url: fileUrl,
      });

      setIsCloneMode(true);
      setIsEditMode(false);
      setEditingData(null);
      setErrors({});
      setExternalEmailInput("");
      setOptionalEmailInput("");
      setDealerUserSearch("");
      setVolvoUserSearch("");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (error) {
      console.error("Error cloning meeting:", error);
      alert("Failed to clone meeting.");
    }
  };

  useKeyboardNavigation({
    containerRef: formRef,
    onSubmit: () => {
      if (isEditMode) handleUpdate();
      else handleSubmit();
    },
    onCancel: () => handleCancel(),
  });

  // ============ RENDER ============
  return (
    <div className="flex flex-col px-4 lg:px-20 xl:px-32">
      <div ref={formRef} className="w-full max-w-7xl mx-auto">
        {/* Title */}
        <div className="relative flex items-center justify-center mt-2 mb-2">
          <h1 className="text-lg font-semibold text-darkblue1 text-center w-full">
            {isCloneMode
              ? "Cloned Meeting"
              : isEditMode
              ? "Edit Meeting"
              : "Create Meeting"}
          </h1>

          {!isCloneMode && !isEditMode && (
            <>
              {/* Desktop Clone Button */}
              <div className="absolute right-4 hidden md:block">
                <div className="relative group">
                  <button
                    type="button"
                    onClick={handleClone}
                    disabled={isDataLoading || isCloneCheckLoading || !hasPreviousMeetings}
                    className={`flex items-center gap-1.5 text-xs px-4 py-1.5 font-medium transition-all duration-200
                      ${isDataLoading || isCloneCheckLoading || !hasPreviousMeetings
                        ? "border border-gray-300 text-gray-400 bg-gray-50 cursor-not-allowed"
                        : "border border-darkblue1 text-darkblue1 hover:bg-darkblue1 hover:text-white cursor-pointer"
                      }`}
                  >
                    {/* Lock icon when disabled, Clone icon when enabled */}
                    {isDataLoading || isCloneCheckLoading || !hasPreviousMeetings ? (
                   <svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 24 24"
  fill="none"
  className="w-4 h-4"
>
  <rect x="0.5" y="0.5" width="10.0003" height="13.6086" stroke="currentColor"/>
  <path d="M3 5L6 5" stroke="currentColor" strokeLinecap="round"/>
  <path d="M3 7L7 7" stroke="currentColor" strokeLinecap="round"/>
  <path d="M3 9H8" stroke="currentColor" strokeLinecap="round"/>
  <rect x="13.5" y="9.89136" width="10.0003" height="13.6086" stroke="currentColor"/>
  <path d="M16 14.3914L19 14.3914" stroke="currentColor" strokeLinecap="round"/>
  <path d="M16 16.3914L20 16.3914" stroke="currentColor" strokeLinecap="round"/>
  <path d="M16 18.3914H21" stroke="currentColor" strokeLinecap="round"/>
  <path d="M5.5 15.6523V19.8262H10.5002" stroke="currentColor" strokeLinecap="round"/>
  <path d="M11.7558 19.4864Z" fill="currentColor"/>
  <path d="M12.2441 3.74641Z" fill="currentColor"/>
  <path d="M13.9863 4.17401H18.9865V8.3479" stroke="currentColor" strokeLinecap="round"/>
</svg>
                    ) : (
                     <svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 24 24"
  fill="none"
  className="w-4 h-4 "
>
  <rect x="0.5" y="0.5" width="10.0003" height="13.6086" stroke="currentColor"/>
  <path d="M3 5L6 5" stroke="currentColor" strokeLinecap="round"/>
  <path d="M3 7L7 7" stroke="currentColor" strokeLinecap="round"/>
  <path d="M3 9H8" stroke="currentColor" strokeLinecap="round"/>
  <rect x="13.5" y="9.89136" width="10.0003" height="13.6086" stroke="currentColor"/>
  <path d="M16 14.3914L19 14.3914" stroke="currentColor" strokeLinecap="round"/>
  <path d="M16 16.3914L20 16.3914" stroke="currentColor" strokeLinecap="round"/>
  <path d="M16 18.3914H21" stroke="currentColor" strokeLinecap="round"/>
  <path d="M5.5 15.6523V19.8262H10.5002" stroke="currentColor" strokeLinecap="round"/>
  <path d="M11.7558 19.4864Z" fill="currentColor"/>
  <path d="M12.2441 3.74641Z" fill="currentColor"/>
  <path d="M13.9863 4.17401H18.9865V8.3479" stroke="currentColor" strokeLinecap="round"/>
</svg>

                    )}
                    {isDataLoading || isCloneCheckLoading
                      ? "Loading..."
                      : "Clone Last Meeting"}
                  </button>

                  {/* Tooltip on hover when disabled */}
                  {!isDataLoading && !isCloneCheckLoading && !hasPreviousMeetings && (
                    <span className="absolute -bottom-9 right-0 bg-gray-800 text-white text-[10px] px-2.5 py-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-50 shadow-lg">
                      No previous meetings available to clone
                      <span className="absolute -top-1 right-4 w-2 h-2 bg-gray-800 rotate-45"></span>
                    </span>
                  )}
                </div>
              </div>

              {/* Mobile Clone Button */}
              <div className="absolute right-0 md:hidden">
                <div className="relative group">
                  <button
                    type="button"
                    onClick={handleClone}
                    disabled={isDataLoading || isCloneCheckLoading || !hasPreviousMeetings}
                    className={`flex items-center gap-1 text-xs px-3 py-1.5 font-medium transition-all duration-200
                      ${isDataLoading || isCloneCheckLoading || !hasPreviousMeetings
                        ? "border border-gray-300 text-gray-400 bg-gray-50 cursor-not-allowed"
                        : "border border-darkblue1 text-darkblue1 hover:bg-darkblue1 hover:text-white cursor-pointer"
                      }`}
                  >
                    {isDataLoading || isCloneCheckLoading || !hasPreviousMeetings ? (
                      <svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 24 24"
  fill="none"
  className="w-4 h-4 "
>
  <rect x="0.5" y="0.5" width="10.0003" height="13.6086" stroke="currentColor"/>
  <path d="M3 5L6 5" stroke="currentColor" strokeLinecap="round"/>
  <path d="M3 7L7 7" stroke="currentColor" strokeLinecap="round"/>
  <path d="M3 9H8" stroke="currentColor" strokeLinecap="round"/>
  <rect x="13.5" y="9.89136" width="10.0003" height="13.6086" stroke="currentColor"/>
  <path d="M16 14.3914L19 14.3914" stroke="currentColor" strokeLinecap="round"/>
  <path d="M16 16.3914L20 16.3914" stroke="currentColor" strokeLinecap="round"/>
  <path d="M16 18.3914H21" stroke="currentColor" strokeLinecap="round"/>
  <path d="M5.5 15.6523V19.8262H10.5002" stroke="currentColor" strokeLinecap="round"/>
  <path d="M11.7558 19.4864Z" fill="currentColor"/>
  <path d="M12.2441 3.74641Z" fill="currentColor"/>
  <path d="M13.9863 4.17401H18.9865V8.3479" stroke="currentColor" strokeLinecap="round"/>
</svg>
                    ) : (
                      <svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 24 24"
  fill="none"
  className="w-4 h-4 "
>
  <rect x="0.5" y="0.5" width="10.0003" height="13.6086" stroke="currentColor"/>
  <path d="M3 5L6 5" stroke="currentColor" strokeLinecap="round"/>
  <path d="M3 7L7 7" stroke="currentColor" strokeLinecap="round"/>
  <path d="M3 9H8" stroke="currentColor" strokeLinecap="round"/>
  <rect x="13.5" y="9.89136" width="10.0003" height="13.6086" stroke="currentColor"/>
  <path d="M16 14.3914L19 14.3914" stroke="currentColor" strokeLinecap="round"/>
  <path d="M16 16.3914L20 16.3914" stroke="currentColor" strokeLinecap="round"/>
  <path d="M16 18.3914H21" stroke="currentColor" strokeLinecap="round"/>
  <path d="M5.5 15.6523V19.8262H10.5002" stroke="currentColor" strokeLinecap="round"/>
  <path d="M11.7558 19.4864Z" fill="currentColor"/>
  <path d="M12.2441 3.74641Z" fill="currentColor"/>
  <path d="M13.9863 4.17401H18.9865V8.3479" stroke="currentColor" strokeLinecap="round"/>
</svg>
                    )}
                    Clone
                  </button>

                  {/* Tooltip on hover when disabled */}
                  {!isDataLoading && !isCloneCheckLoading && !hasPreviousMeetings && (
                    <span className="absolute -bottom-9 right-0 bg-gray-800 text-white text-[10px] px-2.5 py-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-50 shadow-lg">
                      No meetings to clone
                      <span className="absolute -top-1 right-2 w-2 h-2 bg-gray-800 rotate-45"></span>
                    </span>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Form */}
      <div className="w-full max-w-7xl mx-auto p-4">
        <div className="flex justify-center">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 w-full" ref={wrapperRef}>

            {/* Market Area */}
            <div className="w-full">
              <label className="block text-xs font-medium text-black/70 mb-1">
                Market Area <span className="text-red1">*</span>
              </label>
              <div className="relative dropdown-wrapper">
                <div
                  onClick={() => toggleDropdown(setIsOpen, isOpen)}
                  className={`w-full h-[34px] border w-full  text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
  flex items-center text-xs 
                    ${errors.marketArea ? "border-red1 focus:ring-red1" : isOpen ? "border-black/30 border-b-white" : "border-black/30 focus:ring-black/30"}`}
                    tabIndex={0}
                     onKeyDown={(e) => {
    // ENTER → open
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setIsOpen(true);
   }

    // ESC → close
  if (e.key === "Escape") {
  e.preventDefault();
  e.stopPropagation();
  e.nativeEvent.stopImmediatePropagation(); // ✅ MAIN FIX
  closeAllDropdowns();
}
  }}
  
                >
                  <span className={`truncate ${formData.marketArea ? "text-black" : "text-gray-400"}`}>
                    {formData.marketArea || "-Select Market Area-"}
                  </span>
                  
                </div>
 
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 pointer-events-none transition-transform duration-200 ${
        isOpen ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>


  
                {isOpen && (
                  <ul className="absolute z-50 w-full mt-0 bg-white border border-black border-t-white shadow-md max-h-40 overflow-y-auto">
                    {marketAreas.length > 5 && (
                     <li className="sticky top-0 bg-white px-3 py-2 z-10">
  <input
    type="text"
    placeholder="Search market area..."
    value={marketAreaSearch}
    onChange={(e) => setMarketAreaSearch(e.target.value)}

    onKeyDown={(e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation(); // 🔥 VERY IMPORTANT

        setIsOpen(false);          // close dropdown only
        setMarketAreaSearch("");   // optional (remove if you don’t want clear)
      }

      if (e.key === "ArrowDown") {
        e.preventDefault();
        e.stopPropagation();

        const first = e.currentTarget
          .closest("ul")
          ?.querySelector("li[tabindex]");
        first?.focus();
      }
    }}

    className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
    autoFocus
  />
</li>
                    )}

                    {isDataLoading ? (
                      <li className="px-4 py-2 text-xs text-gray-500">Loading...</li>
                    ) : (
                      marketAreas
                        .filter(area => area.marketarea !== formData.marketArea)
                        .filter(area =>
                          !marketAreaSearch ||
                          area.marketarea.toLowerCase().includes(marketAreaSearch.toLowerCase())
                        )
                        .sort((a, b) => a.marketarea.localeCompare(b.marketarea))
                        .map(area => (
                          <li
  tabIndex={0}
  key={area.id}
  onMouseDown={(e) => {
    e.preventDefault();
    handleMarketAreaSelect(area.id, area.marketarea);
    setIsOpen(false);
    setMarketAreaSearch("");
  }}
  onKeyDown={(e) => {
    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );

    const currentIndex = items.indexOf(e.currentTarget);

    // ⬇️ DOWN
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex + 1) % items.length]?.focus();
    }

    // ⬆️ UP
    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex - 1 + items.length) % items.length]?.focus();
    }

    // ⏎ ENTER → select
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      handleMarketAreaSelect(area.id, area.marketarea);
      setIsOpen(false);
      setMarketAreaSearch("");
    }

   if (e.key === "Escape") {
  e.preventDefault();
  closeAllDropdowns();
  e.stopPropagation();
  e.nativeEvent.stopImmediatePropagation(); // ✅ MAIN FIX
  e.stopPropagation()
}
  }}
  className="px-4 py-1.5 text-xs hover:bg-lightBlue cursor-pointer truncate"
>
  {area.marketarea}
</li>
                        ))
                    )}

                    {!isDataLoading &&
                      marketAreas.filter(area =>
                        !marketAreaSearch ||
                        area.marketarea.toLowerCase().includes(marketAreaSearch.toLowerCase())
                      ).length === 0 && (
                        <li className="px-4 py-2 text-xs text-gray-500 cursor-default">
                          No market areas found
                        </li>
                      )}
                  </ul>
                )}
              </div>
              {errors.marketArea && <p className="text-xs text-red1 mt-1">{errors.marketArea}</p>}
            </div>

            {/* Dealer */}
            <div className="w-full">
              <label className="block text-xs font-medium text-black/70 mb-1">
                Dealership <span className="text-red1">*</span>
              </label>
              <div className="relative dropdown-wrapper">
                <div
                  onClick={() => toggleDropdown(setIsDealerOpen, isDealerOpen)}
                  className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
 h-[34px] flex items-center text-xs 
    ${
      errors.dealer
        ? "border-red1 focus:ring-red1"
        : isDealerOpen
        ? "border-black/30 border-b-white"
        : "border-black/30 focus:ring-black/30"
    }`}
                    tabIndex={0}
                     onKeyDown={(e) => {
    // ⏎ ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setIsDealerOpen(true);
    }

    // ❌ ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      setIsDealerOpen(false);
    }
  }}
               >
                  <span className={`truncate ${formData.dealer ? "text-black" : "text-gray-400"}`}>
                    {formData.dealer || "-Select Dealer-"}
                  </span>
                </div>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 pointer-events-none transition-transform duration-200 ${
        isDealerOpen ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>


                {isDealerOpen && (
                  <ul className="absolute z-50 w-full mt-0 bg-white border border-black border-t-white shadow-md max-h-40 overflow-y-auto">
                    {filteredDealers.length > 5 && (
                      <li className="sticky top-0 bg-white px-3 py-2 z-10">
                        <input
                          type="text"
                          placeholder="Search dealer..."
                          value={dealerSearch}
                          onChange={(e) => setDealerSearch(e.target.value)}
                          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
                          autoFocus
                           onKeyDown={(e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation(); // 🔥 important

      setIsDealerOpen(false);   // close dealer dropdown
      setDealerSearch("");      // optional (remove if not needed)
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation();

      const first = e.currentTarget
        .closest("ul")
        ?.querySelector("li[tabindex]");
      first?.focus();
    }
  }}


                        />
                      </li>
                    )}

                    {isDataLoading ? (
                      <li className="px-4 py-2 text-xs text-gray-500">Loading...</li>
                    ) : filteredDealers
                        .filter(d => d.dealerName !== formData.dealer)
                        .filter(d =>
                          !dealerSearch ||
                          d.dealerName.toLowerCase().includes(dealerSearch.toLowerCase())
                        )
                        .sort((a, b) => a.dealerName.localeCompare(b.dealerName))
                        .map(dealer => (
                          <li
  tabIndex={0}
  key={dealer.id}
  onMouseDown={(e) => {
    e.preventDefault();
    handleDealerSelect(dealer.id, dealer.dealerName);
    setIsDealerOpen(false);
    setDealerSearch("");
  }}
  onKeyDown={(e) => {
    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );

    const currentIndex = items.indexOf(e.currentTarget);

    // ⬇️ DOWN
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex + 1) % items.length]?.focus();
    }

    // ⬆️ UP
    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex - 1 + items.length) % items.length]?.focus();
    }

    // ⏎ ENTER → select
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      handleDealerSelect(dealer.id, dealer.dealerName);
      setIsDealerOpen(false);
      setDealerSearch("");
    }

    // ❌ ESC → close
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsDealerOpen(false);
    }
  }}
  className="px-4 py-1.5 text-xs hover:bg-lightBlue cursor-pointer truncate"
>
  {dealer.dealerName}
</li>
                        ))}

                    {!isDataLoading &&
                      filteredDealers.filter(d =>
                        !dealerSearch ||
                        d.dealerName.toLowerCase().includes(dealerSearch.toLowerCase())
                      ).length === 0 && (
                        <li className="px-4 py-2 text-xs text-gray-500 cursor-default">
                          No dealers found
                        </li>
                      )}
                  </ul>
                )}
              </div>
              {errors.dealer && <p className="text-xs text-red1 mt-1">{errors.dealer}</p>}
            </div>

            {/* Dealer User - FIX 1: Search is now fully wired up */}
            <div className="w-full">
              <label className="block text-xs font-medium text-black/70 mb-1">
                Dealer User <span className="text-red1">*</span>
              </label>
              <div className="relative dropdown-wrapper">
                <div
                  onClick={() => toggleDropdown(setIsDealerUserOpen, isDealerUserOpen)}
                  className={` min-h-[34px] max-h-[68px] border w-full text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
 flex flex-wrap gap-1 items-center cursor-pointer transition overflow-y-auto
                    ${errors.dealerUser ? "border-red1 focus:ring-red1" : isDealerUserOpen ? "border-black border-b-white" : "border-black/30 focus:ring-black/30"}`}
                    tabIndex={0}
                     onKeyDown={(e) => {
    // ⏎ ENTER → open
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setIsDealerUserOpen(true);
    }

    // ❌ ESC → close
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsDealerUserOpen(false);
    }
  }}
                >
                  {formData.dealerUser.length > 0 ? (
                    formData.dealerUser.map(user => (
                      <span key={user.id} className="bg-grey2 text-black text-xs px-2 py-0.5 flex items-center gap-1 flex-shrink-0 max-w-[140px]">
                        <span className="truncate">{user.name}</span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setFormData(prev => ({
                              ...prev,
                              dealerUser: prev.dealerUser.filter(u => u.id !== user.id),
                              dealerUserIds: prev.dealerUserIds.filter(id => id !== user.id),
                            }));
                          }}
                          className="hover:opacity-70 flex-shrink-0"
                        >
                         <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>
                        </button>
                      </span>
                    ))
                  ) : (
                    <span className="text-gray-400 text-xs py-0.5">-Select Dealer User-</span>
                  )}
                </div>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 pointer-events-none transition-transform duration-200 ${
        isDealerUserOpen ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>


                {isDealerUserOpen && (
                  <ul className="absolute z-50 w-full mt-0 bg-white border border-black border-t-white shadow-md max-h-40 overflow-y-auto">
                    {dealerUsers.length > 5 && (
                     <li className="sticky top-0 bg-white px-3 py-2 z-10">
  <input
    type="text"
    placeholder="Search user..."
    value={dealerUserSearch}
    onChange={(e) => setDealerUserSearch(e.target.value)}

    onKeyDown={(e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation(); // 🔥 must

        setIsDealerUserOpen(false);  // close only this dropdown
        setDealerUserSearch("");     // optional (remove if not needed)
      }

      if (e.key === "ArrowDown") {
        e.preventDefault();
        e.stopPropagation();

        const first = e.currentTarget
          .closest("ul")
          ?.querySelector("li[tabindex]");
        first?.focus();
      }
    }}

    className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
    autoFocus
  />
</li>
                    )}

                    {isDataLoading ? (
                      <li className="px-4 py-2 text-xs text-gray-500">Loading...</li>
                    ) : dealerUsers
                        .filter(u => !formData.dealerUser.some(s => s.id === u.id))
                        .filter(u =>
                          !dealerUserSearch ||
                          `${u.firstName} ${u.lastName}`.toLowerCase().includes(dealerUserSearch.toLowerCase())
                        ).length === 0 ? (
                      <li className="px-4 py-2 text-xs text-gray-400">No users available</li>
                    ) : (
                      dealerUsers
                        .filter(u => !formData.dealerUser.some(s => s.id === u.id))
                        .filter(u =>
                          !dealerUserSearch ||
                          `${u.firstName} ${u.lastName}`.toLowerCase().includes(dealerUserSearch.toLowerCase())
                        )
                        .sort((a, b) =>
                          `${a.firstName} ${a.lastName}`.trim().localeCompare(`${b.firstName} ${b.lastName}`.trim())
                        )
                        .map(user => (
                         <li
  tabIndex={0}
  key={user.id}
  onMouseDown={(e) => {
    e.preventDefault();
    e.stopPropagation();

    setFormData(prev => ({
      ...prev,
      dealerUser: [
        ...prev.dealerUser,
        { id: user.id, name: `${user.firstName} ${user.lastName}`.trim() }
      ],
      dealerUserIds: [...prev.dealerUserIds, user.id],
    }));

    setErrors(prev => ({ ...prev, dealerUser: "" }));
  }}
  onKeyDown={(e) => {
    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );

    const currentIndex = items.indexOf(e.currentTarget);

    // ⬇️ DOWN
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex + 1) % items.length]?.focus();
    }

    // ⬆️ UP
    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex - 1 + items.length) % items.length]?.focus();
    }

    // ⏎ ENTER → ADD (not close 🔥)
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()

      setFormData(prev => ({
        ...prev,
        dealerUser: [
          ...prev.dealerUser,
          { id: user.id, name: `${user.firstName} ${user.lastName}`.trim() }
        ],
        dealerUserIds: [...prev.dealerUserIds, user.id],
      }));

      setErrors(prev => ({ ...prev, dealerUser: "" }));
    }

    // ❌ ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsDealerUserOpen(false);
    }
  }}
  className="px-4 py-1.5 text-xs hover:bg-lightBlue cursor-pointer truncate"
>
  {`${user.firstName} ${user.lastName}`.trim()}
</li>
                        ))
                    )}
                  </ul>
                )}
              </div>
              {errors.dealerUser && <p className="text-xs text-red1 mt-1">{errors.dealerUser}</p>}
            </div>

            {/* Volvo User */}
            <div className="w-full">
              <label className="block text-xs font-medium text-black/70 mb-1">
                Volvo User <span className="text-red1">*</span>
              </label>
              <div className="relative dropdown-wrapper">
                <div
                  onClick={() => toggleDropdown(setIsVolvoUserOpen, isVolvoUserOpen)}
                  className={` min-h-[34px] max-h-[68px] border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
 items-center cursor-pointer transition overflow-y-auto
                    ${errors.volvoUser ? "border-red1 focus:ring-red1" : isVolvoUserOpen ? "border-black border-b-white" : "border-black/30 focus:ring-black/30"}`}
                    tabIndex={0}
                     onKeyDown={(e) => {
    // ⏎ ENTER → open
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setIsVolvoUserOpen(true);
    }

    // ❌ ESC → close
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsVolvoUserOpen(false);
    }
  }}
                >
                  {formData.volvoUser.length > 0 ? (
                    formData.volvoUser.map(user => (
                      <span key={user.id} className="bg-grey2 text-black text-xs px-2 py-0.5 flex items-center gap-1 flex-shrink-0 max-w-[140px]">
                        <span className="truncate">{user.name}</span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            
                            setFormData(prev => ({
                              ...prev,
                              volvoUser: prev.volvoUser.filter(u => u.id !== user.id),
                              volvoUserIds: prev.volvoUserIds.filter(id => id !== user.id),
                            }));
                          }}
                          className="hover:opacity-70 flex-shrink-0"
                        >
                          <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>
                        </button>
                      </span>
                    ))
                  ) : (
                    <span className="text-gray-400 text-xs py-0.5">-Select Volvo User-</span>
                  )}
                </div>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 pointer-events-none transition-transform duration-200 ${
        isVolvoUserOpen ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>


                {isVolvoUserOpen && (
                  <ul className="absolute z-50 w-full mt-0 bg-white border border-black border-t-white shadow-md max-h-40 overflow-y-auto">
                    {volvoUsers.length > 5 && (
                      <li className="sticky top-0 bg-white px-3 py-2 z-10 border-b">
  <input
    type="text"
    placeholder="Search user..."
    value={volvoUserSearch}
    onChange={(e) => setVolvoUserSearch(e.target.value)}

    onKeyDown={(e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation(); // 🔥 key fix

        setIsVolvoUserOpen(false);  // close only this dropdown
        setVolvoUserSearch("");     // optional
      }

      if (e.key === "ArrowDown") {
        e.preventDefault();
        e.stopPropagation();

        const first = e.currentTarget
          .closest("ul")
          ?.querySelector("li[tabindex]");
        first?.focus();
      }
    }}

    className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
    autoFocus
  />
</li>
                    )}

                    {isDataLoading ? (
                      <li className="px-4 py-2 text-xs text-gray-500">Loading...</li>
                    ) : volvoUsers
                        .filter(u => !formData.volvoUser.some(s => s.id === u.id))
                        .filter(u =>
                          !volvoUserSearch ||
                          `${u.firstName} ${u.lastName}`.toLowerCase().includes(volvoUserSearch.toLowerCase())
                        ).length === 0 ? (
                      <li className="px-4 py-2 text-xs text-gray-400">No users available</li>
                    ) : (
                      volvoUsers
                        .filter(u => !formData.volvoUser.some(s => s.id === u.id))
                        .filter(u =>
                          !volvoUserSearch ||
                          `${u.firstName} ${u.lastName}`.toLowerCase().includes(volvoUserSearch.toLowerCase())
                        )
                        .sort((a, b) =>
                          `${a.firstName} ${a.lastName}`.trim().localeCompare(`${b.firstName} ${b.lastName}`.trim())
                        )
                        .map(user => (
                         <li
  tabIndex={0}
  key={user.id}
  onMouseDown={(e) => {
    e.preventDefault();
    e.stopPropagation();

    setFormData(prev => ({
      ...prev,
      volvoUser: [
        ...prev.volvoUser,
        { id: user.id, name: `${user.firstName} ${user.lastName}`.trim() }
      ],
      volvoUserIds: [...prev.volvoUserIds, user.id],
    }));

    setErrors(prev => ({ ...prev, volvoUser: "" }));
  }}
  onKeyDown={(e) => {
    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );

    const currentIndex = items.indexOf(e.currentTarget);

    // ⬇️ DOWN
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex + 1) % items.length]?.focus();
    }

    // ⬆️ UP
    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex - 1 + items.length) % items.length]?.focus();
    }

    // ⏎ ENTER → ADD (multi-select)
    if (e.key === "Enter") {
      e.preventDefault();
e.stopPropagation()
      setFormData(prev => ({
        ...prev,
        volvoUser: [
          ...prev.volvoUser,
          { id: user.id, name: `${user.firstName} ${user.lastName}`.trim() }
        ],
        volvoUserIds: [...prev.volvoUserIds, user.id],
      }));

      setErrors(prev => ({ ...prev, volvoUser: "" }));
    }

    // ❌ ESC → close
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsVolvoUserOpen(false);
    }
  }}
  className="px-4 py-1.5 text-xs hover:bg-lightBlue cursor-pointer truncate"
>
  {`${user.firstName} ${user.lastName}`.trim()}
</li>
                        ))
                    )}
                  </ul>
                )}
              </div>
              {errors.volvoUser && <p className="text-xs text-red1 mt-1">{errors.volvoUser}</p>}
            </div>

            {/* Meeting Date */}
            <div className="w-full">
              <label className="block text-xs font-medium text-black/70 mb-1">
                Meeting Date <span className="text-red1">*</span>
              </label>
              <div className="relative ">
                <input
                  type="date"
                  ref={meetingDateRef}
                  value={formData.meetingDate || ""}
                  onChange={handleDateChange}
                  min={isEditMode ? undefined : new Date().toISOString().split("T")[0]}
                  onClick={() => {
                    closeAllDropdowns();
                    meetingDateRef.current.blur();
                    setTimeout(() => meetingDateRef.current.showPicker(), 50);
                  }}
                   onKeyDown={(e) => {
    // ⏎ ENTER → open calendar
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      closeAllDropdowns();
      meetingDateRef.current.blur();
      setTimeout(() => meetingDateRef.current.showPicker(), 50);
    }

    // ❌ ESC → close calendar
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      meetingDateRef.current.blur(); // 🔥 this closes picker
    }
  }}
                  className={`w-full h-[34px] border w-full  text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
 bg-transparent transition
                    ${errors.meetingDate ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                    ${!formData.meetingDate ? "text-gray-400" : "text-black"}`}
                />
                     <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
    fill="none"
    onClick={() => {
                    closeAllDropdowns();
                    meetingDateRef.current.blur();
                    setTimeout(() => meetingDateRef.current.showPicker(), 50);
                  }}
  >
    <path
      d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
    />
    <path
      d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path
      d="M18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18C16.7348 18 16.4804 17.8946 16.2929 17.7071C16.1054 17.5196 16 17.2652 16 17C16 16.7348 16.1054 16.4804 16.2929 16.2929C16.4804 16.1054 16.7348 16 17 16C17.2652 16 17.5196 16.1054 17.7071 16.2929C17.8946 16.4804 18 16.7348 18 17ZM18 13C18 13.2652 17.8946 13.5196 17.7071 13.7071C17.5196 13.8946 17.2652 14 17 14C16.7348 14 16.4804 13.8946 16.2929 13.7071C16.1054 13.5196 16 13.2652 16 13C16 12.7348 16.1054 12.4804 16.2929 12.2929C16.4804 12.1054 16.7348 12 17 12C17.2652 12 17.5196 12.1054 17.7071 12.2929C17.8946 12.4804 18 12.7348 18 13ZM13 17C13 17.2652 12.8946 17.5196 12.7071 17.7071C12.5196 17.8946 12.2652 18 12 18C11.7348 18 11.4804 17.8946 11.2929 17.7071C11.1054 17.5196 11 17.2652 11 17C11 16.7348 11.1054 16.4804 11.2929 16.2929C11.4804 16.1054 11.7348 16 12 16C12.2652 16 12.5196 16.1054 12.7071 16.2929C12.8946 16.4804 13 16.7348 13 17ZM13 13C13 13.2652 12.8946 13.5196 12.7071 13.7071C12.5196 13.8946 12.2652 14 12 14C11.7348 14 11.4804 13.8946 11.2929 13.7071C11.1054 13.5196 11 13.2652 11 13C11 12.7348 11.1054 12.4804 11.2929 12.2929C11.4804 12.1054 11.7348 12 12 12C12.2652 12 12.5196 12.1054 12.7071 12.2929C12.8946 12.4804 13 12.7348 13 13ZM8 17C8 17.2652 7.89464 17.5196 7.70711 17.7071C7.51957 17.8946 7.26522 18 7 18C6.73478 18 6.48043 17.8946 6.29289 17.7071C6.10536 17.5196 6 17.2652 6 17C6 16.7348 6.10536 16.4804 6.29289 16.2929C6.48043 16.1054 6.73478 16 7 16C7.26522 16 7.51957 16.1054 7.70711 16.2929C7.89464 16.4804 8 16.7348 8 17ZM8 13C8 13.2652 7.89464 13.5196 7.70711 13.7071C7.51957 13.8946 7.26522 14 7 14C6.73478 14 6.48043 13.8946 6.29289 13.7071C6.10536 13.5196 6 13.2652 6 13C6 12.7348 6.10536 12.4804 6.29289 12.2929C6.48043 12.1054 6.73478 12 7 12C7.26522 12 7.51957 12.1054 7.70711 12.2929C7.89464 12.4804 8 12.7348 8 13Z"
      fill="black"
      fillOpacity="0.7"
    />
  </svg>
              </div>
              {errors.meetingDate && <p className="text-xs text-red1 mt-1">{errors.meetingDate}</p>}
            </div>

            {/* Start Time & End Time */}
            <div className="w-full">
              <div className="flex gap-2">
                <div className="w-1/2" ref={startRef}>
                  <TimeSelector
                    label="Start Time"
                    value={formData.startTime}
                    setValue={(val) => {
                      setErrors(prev => ({ ...prev, startTime: "" }));
                      setFormData(prev => ({
                        ...prev,
                        startTime: val,
                        endTime:
                          prev.endTime &&
                          convertToMinutes(prev.endTime) !== null &&
                          convertToMinutes(val) !== null &&
                          convertToMinutes(prev.endTime) <= convertToMinutes(val)
                            ? ""
                            : prev.endTime,
                      }));
                    }}
                    dropdownOpen={startOpen}
                    setDropdownOpen={(val) => {
                      setStartOpen(val);
                      if (val) setEndOpen(false);
                    }}
                    dropdownRef={startRef}
                    required
                    error={errors.startTime}
                  />
                </div>

                <div className="w-1/2" ref={endRef}>
                  <TimeSelector
                    label="End Time"
                    value={formData.endTime}
                    setValue={(val) => {
                      // FIX 4: Inline validation for end time
                      if (
                        formData.startTime &&
                        convertToMinutes(val) !== null &&
                        convertToMinutes(formData.startTime) !== null &&
                        convertToMinutes(val) <= convertToMinutes(formData.startTime)
                      ) {
                        setErrors(prev => ({ ...prev, endTime: "End time must be after start time" }));
                      } else {
                        setErrors(prev => ({ ...prev, endTime: "" }));
                      }
                      setFormData(prev => ({ ...prev, endTime: val }));
                    }}
                    dropdownOpen={endOpen}
                    setDropdownOpen={(val) => {
                      setEndOpen(val);
                      if (val) setStartOpen(false);
                    }}
                    dropdownRef={endRef}
                    required
                    error={errors.endTime}
                  />
                </div>
              </div>
            </div>

            {/* Recurring Meeting + Repeat Until */}
            <div className="w-full">
              <div className="flex gap-2">
                <div className={
                  formData.recurringMeeting && formData.recurringMeeting !== "One-time Meeting"
                    ? "w-1/2"
                    : "w-full"
                }>
                  <label className="block text-xs font-medium text-black/70 mb-1">
                    Frequency of Meeting <span className="text-red1">*</span>
                  </label>
                  <div className="relative">
                    <div
                      onClick={() => toggleDropdown(setIsRecurringOpen, isRecurringOpen)}
                      className={` h-[34px] border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
 flex items-center text-xs cursor-pointer transition
                        ${errors.recurringMeeting ? "border-red1 focus:ring-red1" : isRecurringOpen ? "border-black border-b-white" : "border-black/30 focus:ring-black/30"}`}
                        tabIndex={0}
                         onKeyDown={(e) => {
    // ⏎ ENTER → open
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setIsRecurringOpen(true);
    }

    // ⬇️ DOWN → open + focus first item
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      setIsRecurringOpen(true);

      setTimeout(() => {
        const firstItem = e.currentTarget.parentElement.querySelector("li");
        firstItem?.focus();
      }, 50);
    }

    // ❌ ESC → close
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsRecurringOpen(false);
    }
  }}
                    >
                      <span className={`truncate ${formData.recurringMeeting ? "text-black" : "text-gray-400"}`}>
                        {formData.recurringMeeting || "-Select Recurring Meeting-"}
                      </span>
                    </div>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 pointer-events-none transition-transform duration-200 ${
        isRecurringOpen ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>


                    {isRecurringOpen && (
                      <ul className="absolute z-50 w-full mt-0 bg-white border border-black border-t-white shadow-md max-h-60 overflow-y-auto">
                        {recurringMeetingOptions
                          .filter(opt => opt !== formData.recurringMeeting)
                          .map((option, idx) => (
                          <li
  tabIndex={0}
  key={idx}
  onMouseDown={(e) => {
    e.preventDefault();

    setFormData(prev => ({
      ...prev,
      recurringMeeting: option,
      repeatUntil: option === "One-time Meeting" ? "" : prev.repeatUntil,
      nextMeetingDate: option === "One-time Meeting" ? "" : prev.nextMeetingDate,
    }));

    setIsRecurringOpen(false);
    setErrors(prev => ({ ...prev, recurringMeeting: "", repeatUntil: "" }));
  }}
  onKeyDown={(e) => {
    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );

    const index = items.indexOf(e.currentTarget);

    // ⬇️ DOWN
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    // ⬆️ UP
    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsRecurringOpen(false);
    }
    // ⏎ ENTER → select
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()

      setFormData(prev => ({
        ...prev,
        recurringMeeting: option,
        repeatUntil: option === "One-time Meeting" ? "" : prev.repeatUntil,
        nextMeetingDate: option === "One-time Meeting" ? "" : prev.nextMeetingDate,
      }));

      setIsRecurringOpen(false);
      setErrors(prev => ({ ...prev, recurringMeeting: "", repeatUntil: "" }));
    }

    // ❌ ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      setIsRecurringOpen(false);
    }
  }}
  className="px-4 py-1.5 text-xs hover:bg-lightBlue cursor-pointer truncate"
>
  {option}
</li>
                          ))}
                      </ul>
                    )}
                  </div>
                  {errors.recurringMeeting && (
                    <p className="text-xs text-red1 mt-1">{errors.recurringMeeting}</p>
                  )}
                </div>

                {/* Repeat Until - maps to backend limit_date */}
                {formData.recurringMeeting &&
                  formData.recurringMeeting !== "One-time Meeting" && (
                    <div className="w-1/2">
                      <label className="block text-xs font-medium text-black/70 mb-1">
                        Repeat Until <span className="text-red1">*</span>
                      </label>
                      <div className="relative">
                       <input
  type="date"
  ref={repeatUntilRef}
  value={formData.repeatUntil || ""}
  min={formData.meetingDate}
  max={getRepeatUntilMaxDate()}
  onChange={(e) => {
    setFormData(prev => ({ ...prev, repeatUntil: e.target.value }));
    setErrors(prev => ({ ...prev, repeatUntil: "" }));
  }}
  onClick={() => {
    closeAllDropdowns();
    repeatUntilRef.current?.showPicker?.();
  }}
  className={`w-full h-[34px] px-4 pr-10 py-1.5 text-xs border cursor-pointer bg-transparent transition
    ${errors.repeatUntil ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
    ${!formData.repeatUntil ? "text-gray-400" : "text-black"}`}
/>
                             <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
    fill="none"
    onClick={() => {
                            closeAllDropdowns();
                            repeatUntilRef.current?.showPicker?.();
                          }}
  >
    <path
      d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
    />
    <path
      d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path
      d="M18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18C16.7348 18 16.4804 17.8946 16.2929 17.7071C16.1054 17.5196 16 17.2652 16 17C16 16.7348 16.1054 16.4804 16.2929 16.2929C16.4804 16.1054 16.7348 16 17 16C17.2652 16 17.5196 16.1054 17.7071 16.2929C17.8946 16.4804 18 16.7348 18 17ZM18 13C18 13.2652 17.8946 13.5196 17.7071 13.7071C17.5196 13.8946 17.2652 14 17 14C16.7348 14 16.4804 13.8946 16.2929 13.7071C16.1054 13.5196 16 13.2652 16 13C16 12.7348 16.1054 12.4804 16.2929 12.2929C16.4804 12.1054 16.7348 12 17 12C17.2652 12 17.5196 12.1054 17.7071 12.2929C17.8946 12.4804 18 12.7348 18 13ZM13 17C13 17.2652 12.8946 17.5196 12.7071 17.7071C12.5196 17.8946 12.2652 18 12 18C11.7348 18 11.4804 17.8946 11.2929 17.7071C11.1054 17.5196 11 17.2652 11 17C11 16.7348 11.1054 16.4804 11.2929 16.2929C11.4804 16.1054 11.7348 16 12 16C12.2652 16 12.5196 16.1054 12.7071 16.2929C12.8946 16.4804 13 16.7348 13 17ZM13 13C13 13.2652 12.8946 13.5196 12.7071 13.7071C12.5196 13.8946 12.2652 14 12 14C11.7348 14 11.4804 13.8946 11.2929 13.7071C11.1054 13.5196 11 13.2652 11 13C11 12.7348 11.1054 12.4804 11.2929 12.2929C11.4804 12.1054 11.7348 12 12 12C12.2652 12 12.5196 12.1054 12.7071 12.2929C12.8946 12.4804 13 12.7348 13 13ZM8 17C8 17.2652 7.89464 17.5196 7.70711 17.7071C7.51957 17.8946 7.26522 18 7 18C6.73478 18 6.48043 17.8946 6.29289 17.7071C6.10536 17.5196 6 17.2652 6 17C6 16.7348 6.10536 16.4804 6.29289 16.2929C6.48043 16.1054 6.73478 16 7 16C7.26522 16 7.51957 16.1054 7.70711 16.2929C7.89464 16.4804 8 16.7348 8 17ZM8 13C8 13.2652 7.89464 13.5196 7.70711 13.7071C7.51957 13.8946 7.26522 14 7 14C6.73478 14 6.48043 13.8946 6.29289 13.7071C6.10536 13.5196 6 13.2652 6 13C6 12.7348 6.10536 12.4804 6.29289 12.2929C6.48043 12.1054 6.73478 12 7 12C7.26522 12 7.51957 12.1054 7.70711 12.2929C7.89464 12.4804 8 12.7348 8 13Z"
      fill="black"
      fillOpacity="0.7"
    />
  </svg>
                      </div>
                      {errors.repeatUntil && (
                        <p className="text-xs text-red1 mt-1">{errors.repeatUntil}</p>
                      )}
                    </div>
                  )}
              </div>
            </div>

            {/* Meeting Mode */}
            <div className="w-full">
              <label className="block text-xs font-medium text-black/70 mb-1">
                Meeting Mode <span className="text-red1">*</span>
              </label>
              <div className="relative">
                <div
                  onClick={() => toggleDropdown(setIsVenueOpen, isVenueOpen)}
                  className={` h-[34px] border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1focus:ring-black/30  transition-all flex items-center text-xs cursor-pointer transition
                    ${errors.venue ? "border-red1 focus:ring-red1" : isVenueOpen ? "border-black border-b-white" : "border-black/30 focus:ring-black/30"}`}
                    tabIndex={0}
                     onKeyDown={(e) => {
    // ⏎ ENTER → toggle dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setIsVenueOpen((prev) => !prev);
    }

    // ⬇️ DOWN → open + focus first item
    if (e.key === "ArrowDown") {
      e.preventDefault();
e.stopPropagation()
      if (!isVenueOpen) {
        setIsVenueOpen(true);

        setTimeout(() => {
          const firstItem = document.querySelector(
            ".venue-dropdown li[tabindex]"
          );
          firstItem?.focus();
        }, 50);
      }
    }

    // ❌ ESC → close
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsVenueOpen(false);
    }
  }}
                >
                  <span className={`truncate ${formData.venue ? "text-black" : "text-gray-400"}`}>
                    {formData.venue || "-Select Venue-"}
                  </span>
                </div>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 pointer-events-none transition-transform duration-200 ${
        isVenueOpen ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>


                {isVenueOpen && (
                  <ul className="absolute z-50 w-full mt-0 bg-white border border-black border-t-white shadow-md max-h-60 overflow-y-auto">
                    {venueOptions
                      .filter(v => v !== formData.venue)
                      .map((venue, idx) => (
                       <li
  tabIndex={0}
  key={idx}
  onMouseDown={(e) => {
    e.preventDefault(); // 🔥 VERY IMPORTANT

    setFormData(prev => ({
      ...prev,
      venue,
      location: "",
      link: ""
    }));

    setIsVenueOpen(false);
    setErrors(prev => ({ ...prev, venue: "", location: "", link: "" }));
  }}
  onKeyDown={(e) => {
    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );

    const index = items.indexOf(e.currentTarget);

    // ⬇️ DOWN
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation();
      items[(index + 1) % items.length]?.focus();
    }

    // ⬆️ UP
    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation();
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    // ⏎ ENTER
    if (e.key === "Enter") {
      e.preventDefault();
e.stopPropagation();
      setFormData(prev => ({
        ...prev,
        venue,
        location: "",
        link: ""
      }));

      setIsVenueOpen(false);
      setErrors(prev => ({ ...prev, venue: "", location: "", link: "" }));
    }

    // ❌ ESC
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      setIsVenueOpen(false);
    }
  }}
  className="px-4 py-1.5 text-xs hover:bg-lightBlue cursor-pointer truncate"
>
  {venue}
</li>
                      ))}
                  </ul>
                )}
              </div>
              {errors.venue && <p className="text-xs text-red1 mt-1">{errors.venue}</p>}
            </div>

            {/* Venue / Link Field */}
            {formData.venue === "Physical" && (
              <div className="w-full">
                <label className="block text-xs font-medium text-black/70 mb-1">
                  Venue <span className="text-red1">*</span>
                </label>
                <input
                  type="text"
                  name="location"
                  value={formData.location || ""}
                  onChange={handleChange}
                  placeholder="Enter location"
                  className={`w-full h-[34px] border w-full text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
 bg-transparent
                    ${errors.location ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                />
                {errors.location && <p className="text-xs text-red1 mt-1">{errors.location}</p>}
              </div>
            )}

            {formData.venue === "Virtual" && (
              <div className="w-full">
                <label className="block text-xs font-medium text-black/70 mb-1">
                  Enter Link <span className="text-red1">*</span>
                </label>
                <input
                  type="url"
                  name="link"
                  value={formData.link || ""}
                  onChange={handleChange}
                  placeholder="Enter meeting link"
                  className={`border w-full text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all h-[34px]  bg-transparent
                    ${errors.link ? "border-red1 focus:ring-red1" : "border-black focus:ring-1 focus:ring-black"}`}
                />
                {errors.link && <p className="text-xs text-red1 mt-1">{errors.link}</p>}
              </div>
            )}

            {/* External Attendee Email */}
            <div className="w-full">
              <label className="block text-xs font-medium text-black/70 mb-1">External Attendee Email</label>
              <div
                onClick={(e) => {
                  if (!e.target.closest('button')) {
                    externalEmailRef.current?.focus();
                    closeAllDropdowns();
                  }
                }}
                className={`min-h-[34px] max-h-[68px] border w-full  text-xs px-3 py-1 outline-none focus:ring-1 transition-all
 flex flex-wrap gap-1 items-center cursor-text overflow-y-auto
                  ${errors.externalEmail ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-1 focus:ring-black/30"}`}
              >
                {formData.externalEmail.map((email, idx) => (
                  <span key={idx} className="bg-grey2 text-black text-xs px-2 py-0.5 flex items-center gap-1 flex-shrink-0 max-w-[160px]">
                    <span className="truncate">{email}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setFormData(prev => ({
                          ...prev,
                          externalEmail: prev.externalEmail.filter((_, i) => i !== idx),
                        }));
                      }}
                      className="hover:opacity-70 flex-shrink-0"
                    >
                     <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>


                    </button>
                  </span>
                ))}
                <input
                  ref={externalEmailRef}
                  type="text"
                  value={externalEmailInput}
                  onChange={(e) => setExternalEmailInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === " " || e.key === "Enter" || e.key === ",") {
                      e.preventDefault();
                      const email = externalEmailInput.trim().replace(/[,;]$/, "");
                      if (email && emailRegex.test(email)) {
                        setFormData(prev => ({
                          ...prev,
                          externalEmail: [...prev.externalEmail, email],
                        }));
                        setExternalEmailInput("");
                      }
                    }
                  }}
                  // FIX 5: Also handle email on blur
                  onBlur={() => {
                    const email = externalEmailInput.trim().replace(/[,;]$/, "");
                    if (email && emailRegex.test(email)) {
                      setFormData(prev => ({
                        ...prev,
                        externalEmail: [...prev.externalEmail, email],
                      }));
                      setExternalEmailInput("");
                    }
                  }}
                  placeholder={formData.externalEmail.length === 0 ? "Type Email and press space" : ""}
                  className="flex-1 min-w-[100px] h-6 text-xs outline-none bg-transparent"
                />
              </div>
              {errors.externalEmail && <p className="text-xs text-red1 mt-1">{errors.externalEmail}</p>}
            </div>

            {/* Optional Attendee Email */}
            <div className="w-full">
              <label className="block text-xs font-medium text-black/70 mb-1">Optional Attendee Email</label>
              <div
                onClick={(e) => {
                  if (!e.target.closest('button')) {
                    optionalEmailRef.current?.focus();
                    closeAllDropdowns();
                  }
                }}
                className={` min-h-[34px] max-h-[68px] border w-full mt-1 text-xs px-3 py-1 outline-none focus:ring-1 transition-all
  items-center cursor-text overflow-y-auto
                  ${errors.optionalEmail ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-1 focus:ring-black/30"}`}
              >
                {formData.optionalEmail.map((email, idx) => (
                  <span key={idx} className="bg-grey2 text-black text-xs px-2 py-0.5 flex items-center gap-1 flex-shrink-0 max-w-[160px]">
                    <span className="truncate">{email}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setFormData(prev => ({
                          ...prev,
                          optionalEmail: prev.optionalEmail.filter((_, i) => i !== idx),
                        }));
                      }}
                      className="hover:opacity-70 flex-shrink-0"
                    >
                      <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>


                    </button>
                  </span>
                ))}
                <input
                  ref={optionalEmailRef}
                  type="text"
                  value={optionalEmailInput}
                  onChange={(e) => setOptionalEmailInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === " " || e.key === "Enter" || e.key === ",") {
                      e.preventDefault();
                      const email = optionalEmailInput.trim().replace(/[,;]$/, "");
                      if (email && emailRegex.test(email)) {
                        setFormData(prev => ({
                          ...prev,
                          optionalEmail: [...prev.optionalEmail, email],
                        }));
                        setOptionalEmailInput("");
                      }
                    }
                  }}
                  // FIX 5: Also handle email on blur
                  onBlur={() => {
                    const email = optionalEmailInput.trim().replace(/[,;]$/, "");
                    if (email && emailRegex.test(email)) {
                      setFormData(prev => ({
                        ...prev,
                        optionalEmail: [...prev.optionalEmail, email],
                      }));
                      setOptionalEmailInput("");
                    }
                  }}
                  placeholder={formData.optionalEmail.length === 0 ? "Type Email and press Space" : ""}
                  className="flex-1 min-w-[100px] h-6 text-xs outline-none bg-transparent"
                />
              </div>
              {errors.optionalEmail && <p className="text-xs text-red1 mt-1">{errors.optionalEmail}</p>}
            </div>

            {/* Agenda - spans 2 columns */}
            <div className="w-full sm:col-span-2">
              <label className="block text-xs font-medium text-black/70 mb-1">
                Agenda <span className="text-red1">*</span>
              </label>
              <div
                className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all

                  ${errors.agenda ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
              >
                {formData.agendaFile && (
                  <div className="mb-2 flex justify-between items-start">
                    {formData.agendaFile.type?.startsWith("image/") && !formData.agendaFile.type?.includes("svg") ? (
                      <div className="relative w-16 h-16 flex-shrink-0">
                        <img
                          src={formData.agendaFile.preview}
                          alt="Attachment"
                          className="w-full h-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setFormData(prev => ({
                              ...prev,
                              agendaFile: null,
                              agenda_file: null,
                              existing_agenda_file_url: null,
                            }))
                          }
                          className="absolute -top-2 -right-2 text-white w-5 h-5 flex items-center justify-center text-xs rounded-full"
                        >
                          <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>
                        </button>
                      </div>
                    ) : (
                      <div className="relative max-w-[200px] border border-gray-300 bg-gray-100 p-2 text-xs flex items-center gap-2">
<span
  onClick={(e) => {
    e.stopPropagation();

    if (!formData.agendaFile.preview) return;

    // If SVG → open centered preview
    if (formData.agendaFile.type?.includes("svg")) {
      const w = window.open();
      if (w) {
        w.document.write(`
          <html>
            <head>
              <title>${formData.agendaFile.name}</title>
            </head>
            <body style="margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh;background:#f0f0f0;">
              <img src="${formData.agendaFile.preview}" style="max-width:90%;max-height:90%;object-fit:contain;" />
            </body>
          </html>
        `);
      }
    } else {
      // Normal files (pdf, doc, image etc.)
      window.open(formData.agendaFile.preview, "_blank");
    }
  }}
  className="truncate text-blue-600 hover:text-blue-800 cursor-pointer underline"
>
  {formData.agendaFile.name}
</span>                        {/* Show download link for existing backend files */}
                        {formData.agendaFile.isExisting && formData.agendaFile.preview && (
                          <a
                            href={formData.agendaFile.preview}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => {
                              e.stopPropagation();
                              // For SVG files, open in wrapper for better display
                              if (formData.agendaFile.type?.includes("svg")) {
                                e.preventDefault();
                                const w = window.open();
                                if (w) {
                                  w.document.write(
                                    `<html><head><title>${formData.agendaFile.name}</title></head><body style="margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh;background:#f0f0f0;"><img src="${formData.agendaFile.preview}" style="max-width:90%;max-height:90%;object-fit:contain;" /></body></html>`
                                  );
                                }
                              }
                            }}
                            className="text-blue hover:text-blue-800 flex-shrink-0"
                           
                          >
                            ↗
                          </a>
                        )}
                        <button
                          type="button"
                          onClick={() =>
                            setFormData(prev => ({
                              ...prev,
                              agendaFile: null,
                              agenda_file: null,
                              existing_agenda_file_url: null,
                            }))
                          }
                          className=""
                        >
                        <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>


                        </button>
                      </div>
                    )}
                  </div>
                )}

                <textarea
                  name="agenda"
                  value={formData.agenda}
                  onChange={handleChange}
                  onFocus={closeAllDropdowns}
                  placeholder="Enter the agenda and main discussion points for the meeting"
                  className="appearance-none resize-none w-full bg-transparent outline-none text-xs"
                  rows="4"
                />

                <button
                  type="button"
                  onClick={() => document.getElementById("agendaAttachment").click()}
                  className="absolute top-2 right-2 p-1 hover:scale-110 transition-transform"
                >
                       <svg xmlns="http://www.w3.org/2000/svg" width="28" height="32" viewBox="0 0 28 32" fill="none" className="w-3.5 h-3.5 object-contain">
<path d="M17.4421 3.454C18.3804 2.5154 19.6532 1.98799 20.9804 1.98781C22.3075 1.98762 23.5805 2.51466 24.5191 3.453C25.4577 4.39134 25.9851 5.6641 25.9853 6.99129C25.9854 8.31849 25.4584 9.5914 24.5201 10.53L11.4001 23.41L11.3941 23.416C11.0169 23.7803 10.5117 23.9819 9.98726 23.9773C9.46286 23.9728 8.96124 23.7625 8.59042 23.3916C8.21961 23.0208 8.00927 22.5192 8.00471 21.9948C8.00015 21.4704 8.20174 20.9652 8.56606 20.588L21.4461 7.708C21.6282 7.5194 21.729 7.2668 21.7267 7.0046C21.7245 6.7424 21.6193 6.49159 21.4339 6.30618C21.2485 6.12077 20.9977 6.0156 20.7355 6.01333C20.4733 6.01105 20.2207 6.11184 20.0321 6.294L7.15206 19.174C6.40382 19.922 5.9824 20.936 5.98006 21.994C5.98006 24.194 7.77006 25.994 9.98006 25.994C11.0375 25.9927 12.0514 25.5728 12.8001 24.826L25.9201 11.946L25.9261 11.94C27.24 10.6312 27.9809 8.85454 27.9861 7C27.9861 3.14 24.8461 1.98153e-08 20.9861 1.98153e-08C19.1344 -0.000139206 17.3581 0.73339 16.0461 2.04L2.92606 14.92L2.92006 14.926C1.99024 15.8551 1.25352 16.959 0.752362 18.1741C0.251204 19.3893 -0.00447713 20.6916 5.93239e-05 22.006C5.93239e-05 27.526 4.48006 32.006 10.0001 32.006C12.7601 32.006 15.2601 30.886 17.0801 29.086L25.7201 20.446C25.9022 20.2574 26.003 20.0048 26.0007 19.7426C25.9985 19.4804 25.8933 19.2296 25.7079 19.0442C25.5225 18.8588 25.2717 18.7536 25.0095 18.7513C24.7473 18.749 24.4947 18.8498 24.3061 19.032L15.6661 27.672C14.9239 28.4165 14.0416 29.0065 13.0701 29.4082C12.0987 29.8098 11.0573 30.015 10.0061 30.012C5.58606 30.012 2.00606 26.432 2.00606 22.012C2.00606 19.812 2.90006 17.812 4.34606 16.352L17.4661 3.472L17.4721 3.466L17.4421 3.454Z" fill="black"/>
</svg>
                </button>

                <input
                  id="agendaAttachment"
                  type="file"
                  className="hidden"
                  accept="image/*,.pdf,.doc,.docx"
                  onChange={handleAgendaAttachment}
                />
              </div>
              {errors.agenda && <p className="text-xs text-red1 mt-1">{errors.agenda}</p>}
            </div>

          </div>
        </div>

        {/* Error Messages */}
        {errors.data && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200">
            <p className="text-red-600 text-xs">{errors.data}</p>
          </div>
        )}

        {errors.submit && (
          <div className="mt-4">
            <p className="text-red1 text-xs">{errors.submit}</p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-4 justify-end mt-4">
          <button
            type="button"
            onClick={handleCancel}
            className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium hover:bg-mildBlue1 hover:scale-105 transition"
          >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 18 20" fill="none">
<path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
            Cancel
          </button>

          <button
            type="button"
            onClick={isEditMode ? handleUpdate : handleSubmit}
            disabled={isLoading}
            className={`text-xs font-medium px-8 py-1.5 transition-colors
              ${isLoading
                ? "bg-gray-400 text-white cursor-not-allowed"
                : "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
              }`}
          >
            {isLoading
              ? isEditMode ? "Updating..." : "Saving..."
              : isEditMode ? "Update" : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreateMonthlyMeeting;