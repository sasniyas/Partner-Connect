// import React from "react";
// import { useState } from "react";
// import DealerUser from "./DealerUser/DealerUser";
// import VolvoUser from "./VolvoUser/VolvoUser";
// import { useLocation } from "react-router-dom";
// const ContactMangement = () =>{
//   const location = useLocation();
//   const [activeTab, setActiveTab] = useState("dealerUsers");
//   const handleTabClick = (tab, route) => {
//     setActiveTab(tab);
//     // If you want navigation, use this line (with react-router-dom)
//     // navigate(route);
//     console.log("Navigate to:", route);
//   };

//     return (
//         <div className="w-full flex justify-center  ">
//       <div className="w-full">
//                   <h2 className="text-xl font-semibold text-darkblue1 text-center mb-2">Contact Management System</h2>
//     <div className="w-full grid grid-cols-5 divide-x divide-black/30 border border-black/30 overflow-hidden mb-2">
//         <button
//           onClick={() => handleTabClick("dealerUsers", "/dealer-users")}
//           className={`py-2 font-medium text-xs transition ${
//             activeTab === "dealerUsers"
//               ? "bg-DustyBlue1 text-white"
//               : "bg-white text-black"
//           }`}
//         >
//           Dealer Users
//         </button>

//         <button
//           onClick={() => handleTabClick("volvoUsers", "/volvo-users")}
//           className={`py-2 font-medium text-xs transition ${
//             activeTab === "volvoUsers"
//               ? "bg-DustyBlue1 text-white"
//               : "bg-white text-black"
//           }`}
//         >
//           Volvo Users
//         </button>

//         <button
//           onClick={() => handleTabClick("dealerAddressBook", "/dealer-address-book")}
//           className={`py-2 font-medium text-xs transition ${
//             activeTab === "dealerAddressBook"
//               ? "bg-DustyBlue1 text-white"
//               : "bg-white text-black"
//           }`}
//         >
//           Dealer Address Book
//         </button>

//         <button
//           onClick={() => handleTabClick("orgStructure", "/org-structure")}
//           className={`py-2 font-medium text-xs transition ${
//             activeTab === "orgStructure"
//               ? "bg-DustyBlue1 text-white"
//               : "bg-white text-black"
//           }`}
//         >
//           Org Structure
//         </button>

//         <button
//           onClick={() => handleTabClick("chatter", "/chatter")}
//           className={`py-2 font-medium text-xs transition ${
//             activeTab === "chatter"
//               ? "bg-DustyBlue1 text-white"
//               : "bg-white text-black"
//           }`}
//         >
//           Chatter
//         </button>
//       </div>

//       {/* Tab Content Placeholder */}
//       <div className="">
//   {activeTab === "dealerUsers" && <DealerUser />}       
//    {activeTab === "volvoUsers" && <VolvoUser/>}
//         {activeTab === "dealerAddressBook" && <p>Dealer Address Book Content</p>}
//         {activeTab === "orgStructure" && <p>Org Structure Content</p>}
//         {activeTab === "chatter" && <p>Chatter Content</p>}
//       </div>
//         </div>
//         </div>

//     )
// }

// export default ContactMangement;



import React, { useState, useEffect } from "react";
import DealerUser from "./DealerUser/DealerUser";
import VolvoUser from "./VolvoUser/VolvoUser";
import { useLocation } from "react-router-dom";
import DealerAdress from "./DealerAdressBook/DealerAdress";
import Chatter from "./Chatter/Chatter";
import Orgstructure from "./OrgStructure/OrgStructure";

const ContactManagement = () => {
  const location = useLocation();

  // Default tab
  const [activeTab, setActiveTab] = useState("dealerUsers");

  // Update tab if coming from Add/Edit page
  useEffect(() => {
    if (location.state?.activeTab) {
      setActiveTab(location.state.activeTab);
    }
  }, [location.state]);

  const handleTabClick = (tab, route) => {
    setActiveTab(tab);
    console.log("Navigate to:", route);
  };

  return (
    <div className="w-full flex justify-center">
      <div className="w-full">
        <h2 className="text-xl font-semibold text-darkblue1 text-center mb-2">
          Contact Management System
        </h2>

        {/* Tabs */}
        <div className="w-full grid grid-cols-5 divide-x divide-black/30 border border-black/30 overflow-hidden mb-2">
          <button
            onClick={() => handleTabClick("dealerUsers", "/dealer-users")}
            className={`py-2 font-medium text-xs transition ${
              activeTab === "dealerUsers"
                ? "bg-DustyBlue1 text-white"
                : "bg-white text-black"
            }`}
          >
            Dealer Users
          </button>

          <button
            onClick={() => handleTabClick("volvoUsers", "/volvo-users")}
            className={`py-2 font-medium text-xs transition ${
              activeTab === "volvoUsers"
                ? "bg-DustyBlue1 text-white"
                : "bg-white text-black"
            }`}
          >
            Volvo Users
          </button>

          <button
            onClick={() => handleTabClick("dealerAddressBook", "/dealer-address-book")}
            className={`py-2 font-medium text-xs transition ${
              activeTab === "dealerAddressBook"
                ? "bg-DustyBlue1 text-white"
                : "bg-white text-black"
            }`}
          >
            Dealer Address Book
          </button>

          <button
            onClick={() => handleTabClick("orgStructure", "/org-structure")}
            className={`py-2 font-medium text-xs transition ${
              activeTab === "orgStructure"
                ? "bg-DustyBlue1 text-white"
                : "bg-white text-black"
            }`}
          >
            Org Structure
          </button>

          <button
            onClick={() => handleTabClick("chatter", "/chatter")}
            className={`py-2 font-medium text-xs transition ${
              activeTab === "chatter"
                ? "bg-DustyBlue1 text-white"
                : "bg-white text-black"
            }`}
          >
            Chatter
          </button>
        </div>

        {/* Tab Content */}
        <div className="">
          {activeTab === "dealerUsers" && <DealerUser />}
          {activeTab === "volvoUsers" && <VolvoUser />}
          {activeTab === "dealerAddressBook" && <DealerAdress/>}
          {activeTab === "orgStructure" && <Orgstructure/>}
          {activeTab === "chatter" && <Chatter/>}
        </div>
      </div>
    </div>
  );
};

export default ContactManagement;
