"use client"
import { useState, useRef } from "react"
import Header from "../../../Components/Header"
import SubNavbar3 from "../../../Components/SubNavbar3"
import { ArrowLeft } from "lucide-react"
import { useNavigate, useLocation } from "react-router-dom"
import StyledSelectField from "../../../Components/StyledSelectField"
import StyledDateField from "../../../Components/StyledDatefield"
import { useEffect } from "react"
const EditDealerUser = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const [menuOpen, setMenuOpen] = useState(false)
  const normalizeYesNo = (val) => (val?.toLowerCase() === "yes" ? "yes" : "no")
const fileInputRef = useRef(null);
const [selectedFileName, setSelectedFileName] = useState("");
const [errors, setErrors] = useState({});

  // Dropdown options
  const marketAreaOptions = [
    { label: "North", value: "north" },
    { label: "South", value: "south" },
    { label: "East", value: "east" },
    { label: "West", value: "west" },
  ]
const reportingManagerOptions = [
  { label: "Alice Johnson", value: "alice.johnson" },
  { label: "Bob Smith", value: "bob.smith" },
  { label: "Carol Lee", value: "carol.lee" },
  { label: "David Kim", value: "david.kim" },
  { label: "Emma Davis", value: "emma.davis" },
];

  const dealerOptions = [
    { label: "Alpha Teknisk Pvt. Ltd.", value: "alpha" },
    { label: "BSES India Pvt. Ltd.", value: "bses" },
    { label: "ESDEE SOLUTECH", value: "esdee" },
    { label: "PAL Infrastructure Solutions", value: "pal" },
    { label: "Time Equipment", value: "time" },
  ]

  const departmentOptions = [
    { label: "Sales", value: "Sales" },
    { label: "Service", value: "Service" },
    { label: "HR", value: "HR" },
  ]

  const workLocationOptions = [
    { label: "Head Quarter", value: "Head Quarter" },
    { label: "Branch Location", value: "Branch Location" },
  ]

  const activeOptions = [
    { label: "Yes", value: "yes" },
    { label: "No", value: "no" },
  ]

  const initialUser = location.state?.user || {}

  const [formData, setFormData] = useState({
    marketArea:
      marketAreaOptions.find((opt) => opt.label === initialUser.marketArea)?.value || initialUser.marketArea || "",

    dealer: dealerOptions.find((opt) => opt.label === initialUser.dealer)?.value || initialUser.dealer || "",

    department:
      departmentOptions.find((opt) => opt.label === initialUser.department)?.value || initialUser.department || "",

    workLocation:
      workLocationOptions.find((opt) => opt.label === initialUser.workLocation)?.value ||
      initialUser.workLocation ||
      "",

    active: normalizeYesNo(initialUser.active),

    firstName: initialUser.firstName || "",
    lastName: initialUser.lastName || "",
    vdnId: initialUser.vdnId || "",
    phoneNumber: initialUser.phone || "",
    designation: initialUser.designation || "",
    email: initialUser.email || "",
    joiningDate: initialUser.joiningDate || "",
    experience: initialUser.yearsExp || "",
    notes: initialUser.notes || "",
    resignationDate: initialUser.resignationDate || "",
  })

  // Dropdown open states
  const [dropdowns, setDropdowns] = useState({
    marketArea: false,
    dealer: false,
    department: false,
    workLocation: false,
    active: false,
  })

  const refs = {
    marketArea: useRef(),
    dealer: useRef(),
    department: useRef(),
    workLocation: useRef(),
    active: useRef(),
  }
  useEffect(() => {
    const closeDropdown = (e) => {
      Object.keys(refs).forEach((key) => {
        if (refs[key]?.current && !refs[key].current.contains(e.target)) {
          setDropdowns((prev) => ({ ...prev, [key]: false }))
        }
      })
    }
    document.addEventListener("mousedown", closeDropdown)
    return () => document.removeEventListener("mousedown", closeDropdown)
  }, [])

  const handleBack = () => {
    navigate("/contactmanagemnet", { state: { activeTab: "dealerUsers" } })
  }
  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleSave = () => {
    navigate("/contactmanagemnet", { state: { updatedUser: formData } })
  }

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="flex flex-col w-full mb-3">
            <div className="flex items-center gap-2">
              <ArrowLeft
                onClick={handleBack}
                size={20}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
              />
              <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">Edit Contact</h2>
            </div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-7"></div>
          </div>

          {/* Form */}
          <div className="bg-white px-6 py-4 rounded shadow-md">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-12 gap-y-2">
              {/* Market Area */}
              <StyledSelectField
                label="Market Area"
                placeholder="Select Market Area"
                value={marketAreaOptions.find((opt) => opt.value === formData.marketArea)?.label || ""}
                setValue={(label) => {
                  const selected = marketAreaOptions.find((opt) => opt.label === label)
                  handleChange("marketArea", selected?.value || "")
                }}
                options={marketAreaOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.marketArea}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, marketArea: val }))}
                dropdownRef={refs.marketArea}
              />

              {/* Dealer */}
              <StyledSelectField
                label="Dealer"
                placeholder="Select Dealer"
                value={dealerOptions.find((opt) => opt.value === formData.dealer)?.label || ""}
                setValue={(label) => {
                  const selected = dealerOptions.find((opt) => opt.label === label)
                  handleChange("dealer", selected?.value || "")
                }}
                options={dealerOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.dealer}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, dealer: val }))}
                dropdownRef={refs.dealer}
              />

              {/* First Name */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">First Name</label>
                <input
                  type="text"
                  placeholder="Enter First Name"
                  value={formData.firstName}
                  onChange={(e) => handleChange("firstName", e.target.value)}
                  className="border text-xs px-4 py-1.5 border-black/30 hover:ring-1 hover:ring-black/30"
                />
              </div>

              {/* Last Name */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Last Name</label>
                <input
                  type="text"
                  placeholder="Enter Last Name"
                  value={formData.lastName}
                  onChange={(e) => handleChange("lastName", e.target.value)}
                  className="border text-xs px-4 py-1.5 border-black/30 hover:ring-1 hover:ring-black/30"
                />
              </div>

              {/* VDN ID */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">VDN ID</label>
                <input
                  type="text"
                  value={formData.vdnId}
                  onChange={(e) => handleChange("vdnId", e.target.value)}
                  className="border text-xs px-4 py-1.5 border-black/30"
                />
              </div>

              {/* Phone Number */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Phone Number</label>
                <input
                  type="text"
                  maxLength={10}
                  value={formData.phoneNumber}
                  onChange={(e) => handleChange("phoneNumber", e.target.value)}
                  className="border text-xs px-4 py-1.5 border-black/30"
                />
              </div>

              {/* Department */}
              <StyledSelectField
                label="Department"
                placeholder="Select Department"
                value={departmentOptions.find((opt) => opt.label === formData.department)?.label || ""}
                setValue={(label) => {
                  const selected = departmentOptions.find((opt) => opt.label === label)
                  handleChange("department", selected?.value || "")
                }}
                options={departmentOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.department}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, department: val }))}
                dropdownRef={refs.department}
              />

              {/* Designation */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Designation</label>
                <input
                  type="text"
                  placeholder="Enter Designation"
                  value={formData.designation}
                  onChange={(e) => handleChange("designation", e.target.value)}
                  className="border text-xs px-4 py-1.5 border-black/30"
                />
              </div>

              {/* Email */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Email ID</label>
                <input
                  type="email"
                  placeholder="Enter Email"
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  className="border text-xs px-4 py-1.5 border-black/30"
                />
              </div>

              {/* Work Location */}
              <div>
              <StyledSelectField
                label="Work Location"
                placeholder="Select Work Location"
                value={workLocationOptions.find((opt) => opt.value === formData.workLocation)?.label || ""}
                setValue={(label) => {
                  const selected = workLocationOptions.find((opt) => opt.label === label)
                  handleChange("workLocation", selected?.value || "")
                }}
                options={workLocationOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.workLocation}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, workLocation: val }))}
                dropdownRef={refs.workLocation}
              /></div>
              {/* Joining Date */}
              <div className="mt-1 col-span-1">
                <StyledDateField
                  label="Joining Date"
                  value={formData.joiningDate}
                  setValue={(val) => handleChange("joiningDate", val)}
                />
              </div>

              {/* Experience */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Years of Experience</label>
                <input
                  type="text"
                  maxLength={2}
                  value={formData.experience}
                  onChange={(e) => handleChange("experience", e.target.value)}
                  className="border text-xs px-4 py-1.5 border-black/30"
                />
              </div>
<div>
  <StyledSelectField
    label="Reporting Manager"
    placeholder="Select Reporting Manager"
    value={
      reportingManagerOptions.find((opt) => opt.value === formData.reportingManager)?.label || ""
    }
    setValue={(label) => {
      const selected = reportingManagerOptions.find((opt) => opt.label === label);
      handleChange("reportingManager", selected?.value || "");
    }}
    options={reportingManagerOptions.map((opt) => opt.label)}
    dropdownOpen={dropdowns.reportingManager}
    setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, reportingManager: val }))}
    dropdownRef={refs.reportingManager}
    // error={errors.reportingManager}
  />
</div>

<div className="flex flex-col mt-1">
  <label className="text-xs mb-1">Upload Image</label>
  <div
    className={`flex items-center px-4 py-1.5 text-xs border  cursor-pointer ${
      errors.image
        ? "border-red1"
        : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
    onClick={() => fileInputRef.current.click()}
  >
    <input
      type="file"
      accept="image/*"
      ref={fileInputRef}
      style={{ display: "none" }}
      onChange={(e) => {
        const file = e.target.files[0];
        setSelectedFileName(file ? file.name : "");
        handleChange("image", file); // store in formData
      }}
    />
    <span className="flex-1">{selectedFileName || "Choose an image..."}</span>
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      viewBox="0 0 16 16"
      className="ml-2 text-black/50"
    >
      <path d="M.5 9.9a.5.5 0 0 1 .5-.5h4v-4a.5.5 0 0 1 1 0v4h4a.5.5 0 0 1 0 1h-4v4a.5.5 0 0 1-1 0v-4h-4a.5.5 0 0 1-.5-.5z" />
    </svg>
  </div>
</div>

              {/* Active */}
              <StyledSelectField
                label="Active"
                placeholder="Select Active"
                value={activeOptions.find((opt) => opt.value === formData.active)?.label || ""}
                setValue={(label) => {
                  const selected = activeOptions.find((opt) => opt.label === label)
                  handleChange("active", selected?.value || "")
                }}
                options={activeOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.active}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, active: val }))}
                dropdownRef={refs.active}
              />

              {/* Resignation Date */}
              {formData.active === "no" && (
                <StyledDateField
                  label="Resignation Date"
                  value={formData.resignationDate}
                  setValue={(val) => handleChange("resignationDate", val)}
                />
              )}

              {/* Notes */}
              <div className="flex flex-col col-span-3">
                <label className="text-xs font-medium text-black mb-3">Notes</label>
                <textarea
                  placeholder="Enter Notes"
                  value={formData.notes}
                  onChange={(e) => handleChange("notes", e.target.value)}
                  className="border text-xs px-4 py-2 resize-none h-28 border-black/30"
                />
              </div>
            </div>

            {/* Save Button */}
            <div className="mt-4 flex justify-end">
              <button
                onClick={handleSave}
                className="bg-darkblue1 text-white px-8 py-1.5 transition text-xs hover:border hover:border-darkblue1 hover:bg-white hover:text-darkblue1"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default EditDealerUser
