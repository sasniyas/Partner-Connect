"use client"

import { useState, useRef, useEffect } from "react"
import Searchinput from "../../../Components/Searchinput"
import Filter from "../../../Components/Filter"
import { MoreVertical, Eye, CircleOff } from "lucide-react"
import { useNavigate, useLocation } from "react-router-dom"
import DeleteModal from "../../../Components/DeleteModal"
import ActivateStatus from "../../../Components/ActivateStatus"
import DeactivateStatus from "../../../Components/DeactivateStatus"
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";

const DealerUser = () => {
  const location = useLocation()
  const navigate = useNavigate()

  const stats = [
    { title: "Total Employee", value: 248, color: "text-SteelBlue1" },
    { title: "Active Employee", value: 248, color: "text-SteelBlue1" },
    { title: "Resigned Employee", value: 248, color: "text-SteelBlue1" },
    { title: "Total Tenure", value: 248, color: "text-SteelBlue1" },
  ]

  // Filters
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedDealer, setSelectedDealer] = useState("")
  const [selectedDepartment, setSelectedDepartment] = useState("")
  const [selectedActive, setSelectedActive] = useState("")
  const [selectedMarketArea, setSelectedMarketArea] = useState("")
  const [deleteItem, setDeleteItem] = useState(null)
  const [loading, setLoading] = useState(false)
// Selected row index for modal
const [selectedRow, setSelectedRow] = useState(null);
const fileInputRef = useRef(null);

// Activate/Deactivate modals
const [showActivateModal, setShowActivateModal] = useState(false);
const [showDeactivateModal, setShowDeactivateModal] = useState(false);

// Loading state for activation/deactivation
const [statusLoading, setStatusLoading] = useState(false);

  // Add User dropdown
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const addUserButtonRef = useRef(null)
  const addUserDropdownRef = useRef(null)
  const [addUserButtonWidth, setAddUserButtonWidth] = useState(0)
  const [viewContact, setViewContact] = useState(null)

  // Table row dropdowns
  const [dropdownId, setDropdownId] = useState(null)
  const dropdownRefs = useRef({})

  const tableContainerRef = useRef(null)

  // Dummy options
  const marketAreaOptions = ["North", "South", "East", "West", "Central"]
  const dealerOptions = ["NAVIN", "DRS", "PAL"]
  const departmentOptions = ["Sales", "Service", "HR"]
  const activeOptions = ["Yes", "No"]

  // Dummy table data
  const dummyData = [
    {
      vdnId: "VDN01",
      marketArea: "North",
      dealer: "NAVIN",
      firstName: "John",
      lastName: "Doe",
      department: "Sales",
      designation: "Manager",
      phone: "9876500001",
      email: "john1@example.com",
      workLocation: "Branch Location",
      joiningDate: "2021-01-12",
      yearsExp: "5",
      active: "Yes",
      resignationDate: "-",
    },
    {
      vdnId: "VDN02",
      marketArea: "South",
      dealer: "DRS",
      firstName: "Amit",
      lastName: "Sharma",
      department: "Service",
      designation: "Executive",
      phone: "9876500002",
      email: "amit@example.com",
      workLocation: "Head Quarter",
      joiningDate: "2020-03-22",
      yearsExp: "4",
      active: "Yes",
      resignationDate: "-",
    },
    {
      vdnId: "VDN03",
      marketArea: "East",
      dealer: "PAL",
      firstName: "Priya",
      lastName: "Singh",
      department: "HR",
      designation: "Lead",
      phone: "9876500003",
      email: "priya@example.com",
      workLocation: "Head Quarter",
      joiningDate: "2019-11-10",
      yearsExp: "6",
      active: "No",
      resignationDate: "2024-01-05",
    },
  ]

  const [tableData, setTableData] = useState(dummyData)

  const isAdded = useRef(false)

  useEffect(() => {
    if (location.state?.newUser && !isAdded.current) {
      isAdded.current = true // prevent duplicate inserts

      const newUser = location.state.newUser

      const formattedUser = {
        vdnId: newUser.vdnId,
        marketArea: newUser.marketArea,
        dealer: newUser.dealer,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        department: newUser.department,
        designation: newUser.designation,
        phone: newUser.phoneNumber,
        email: newUser.email,
        workLocation: newUser.workLocation,
        joiningDate: newUser.joiningDate,
        yearsExp: newUser.experience,
        active: newUser.active,
        resignationDate: newUser.active === "no" ? newUser.resignationDate : "-",
        notes: newUser.notes,
      }

      setTableData((prev) => [formattedUser, ...prev])
    }
  }, [location.state])
  useEffect(() => {
    if (location.state?.updatedUser) {
      const updated = location.state.updatedUser

      setTableData((prev) =>
        prev.map((item) =>
          item.vdnId === updated.vdnId
            ? {
                ...item,
                marketArea: updated.marketArea,
                dealer: updated.dealer,
                firstName: updated.firstName,
                lastName: updated.lastName,
                department: updated.department,
                designation: updated.designation,
                phone: updated.phoneNumber,
                email: updated.email,
                workLocation: updated.workLocation,
                joiningDate: updated.joiningDate,
                yearsExp: updated.experience,
                active: updated.active,
                resignationDate: updated.active === "no" ? updated.resignationDate : "-",

                notes: updated.notes,
              }
            : item,
        ),
      )
    }
  }, [location.state])

  const filteredItems = tableData.filter((item) => {
    const searchLower = (searchTerm || "").toLowerCase()

    // Text search across multiple fields
    const matchesSearch = [
      `${item.firstName || ""} ${item.lastName || ""}`,
      item.email,
      item.designation,
      item.department,
      item.marketArea,
      item.dealer,
      item.active,
    ].some((field) => field?.toString().toLowerCase().includes(searchLower))

    // Filter by selected Market Area
    const matchesMarketArea = selectedMarketArea?.length > 0 ? selectedMarketArea.includes(item.marketArea) : true

    // Filter by selected Dealer
    const matchesDealer = selectedDealer?.length > 0 ? selectedDealer.includes(item.dealer) : true

    // Filter by selected Department
    const matchesDepartment = selectedDepartment?.length > 0 ? selectedDepartment.includes(item.department) : true

    // Filter by Active status
    const matchesActive = selectedActive?.length > 0 ? selectedActive.includes(item.active) : true

    // Return items that match all conditions
    return matchesSearch && matchesMarketArea && matchesDealer && matchesDepartment && matchesActive
  })

  // Set Add User button width
  useEffect(() => {
    if (addUserButtonRef.current) {
      setAddUserButtonWidth(addUserButtonRef.current.offsetWidth)
    }
  }, [])

  // Close dropdowns when clicked outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        addUserDropdownRef.current &&
        !addUserDropdownRef.current.contains(e.target) &&
        addUserButtonRef.current &&
        !addUserButtonRef.current.contains(e.target)
      ) {
        setIsAddUserOpen(false)
      }

      const isClickInsideRowDropdown = Object.values(dropdownRefs.current).some((ref) => ref && ref.contains(e.target))
      if (!isClickInsideRowDropdown) {
        setDropdownId(null)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // Add User actions
  const handleAddUser = () => navigate("/contactmanagemnet/adduser")
  // const handleBulkUpload = () => console.log("Bulk Upload clicked")
  const handleClose = () => setViewContact(null)

  // Table actions
  const handleView = (item) => {
    setViewContact(item)
    setDropdownId(null) // <-- closes the dropdown
    // setShowViewPopup(true); // if you use a popup state
  }

  const handleEdit = (item) => {
    navigate("/contactmanagemnet/edituser", {
      state: {
        user: {
          ...item,
          active: item.active?.toLowerCase(), // Yes → yes
        },
      },
    })

    setDropdownId(null)
  }

  const handleDeactivate = (item) => console.log("Deactivate", item)
  const handleDeleteClick = (item) => {
    setDeleteItem(item) // store the actual item for deletion
  }

  const handleConfirmDelete = () => {
    setLoading(true)
    setTimeout(() => {
      // simulate API call or deletion
      setTableData((prev) => prev.filter((row) => row.vdnId !== deleteItem.vdnId))
      setDeleteItem(null) // close modal
      setLoading(false)
    }, 500)
  }
// In DealerUser
const handlePreviewAndDownload = () => {
  const data = filteredItems;
  const newWindow = window.open("/dealeruser/download", "_blank");

  const handleReady = (event) => {
    if (event.source === newWindow && event.data?.type === "READY_FOR_DATA") {
      newWindow.postMessage({ type: "INIT_DATA", payload: data }, "*");
      window.removeEventListener("message", handleReady);
    }
  };

  window.addEventListener("message", handleReady);
};
const handleConfirmDeactivate = () => {
  setStatusLoading(true);
  setTimeout(() => {
    setTableData((prev) =>
      prev.map((item, i) =>
        i === selectedRow ? { ...item, active: "No" } : item
      )
    );
    setShowDeactivateModal(false);
    setStatusLoading(false);
  }, 500); // simulate API call
};

const handleConfirmActivate = () => {
  setStatusLoading(true);
  setTimeout(() => {
    setTableData((prev) =>
      prev.map((item, i) =>
        i === selectedRow ? { ...item, active: "Yes" } : item
      )
    );
    setShowActivateModal(false);
    setStatusLoading(false);
  }, 500); // simulate API call
};




const handleDownloadTemplate = async () => {
  if (!dealerOptions.length || !marketAreaOptions.length) {
    alert("Please ensure Market Areas and Dealers are available.")
    return
  }

  const workbook = new ExcelJS.Workbook()
  const sheet = workbook.addWorksheet("Dealer Users")

  // ================== COLUMNS ==================
  sheet.columns = [
    { header: "Market Area", key: "market_area", width: 20 },
    { header: "Dealership", key: "dealer_name", width: 30 },
    { header: "First Name", key: "first_name", width: 20 },
    { header: "Last Name", key: "last_name", width: 20 },
    { header: "Department", key: "department", width: 15 },
    { header: "Designation", key: "designation", width: 20 },
    { header: "Phone Number", key: "phone", width: 20 },
    { header: "Email", key: "email", width: 30 },
    { header: "Work Location", key: "work_location", width: 20 },
    { header: "Joining Date", key: "joining_date", width: 15 },
    { header: "Years Exp.", key: "years_exp", width: 10 },
    { header: "Active", key: "active", width: 10 },
    { header: "Resignation Date", key: "resignation_date", width: 15 },
    { header: "Notes", key: "notes", width: 30 },
  ]

  // ================== HEADER STYLE ==================
  sheet.getRow(1).eachCell((cell) => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } }
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FF476896" },
    }
    cell.alignment = { vertical: "middle", horizontal: "left" }
      cell.protection = { locked: true }; // unlock dummy row for editing
  })

  // ================== SAMPLE ROW ==================
  const sampleRow = sheet.addRow({
    market_area: marketAreaOptions[0] || "",
    dealer_name: dealerOptions[0] || "",
    first_name: "John",
    last_name: "Doe",
    department: "Sales",
    designation: "Manager",
    phone: "9876500001",
    email: "john@example.com",
    work_location: "Branch Location",
    joining_date: "2021-01-12",
    years_exp: 5,
    active: "Yes",
    resignation_date: "",
    notes: "Sample note",
  })

  sampleRow.eachCell((cell) => {
    cell.alignment = { vertical: "middle", horizontal: "left" }
  })

  // ================== DROPDOWN VALUES ==================
  const marketAreaList = marketAreaOptions.join(",")
  const dealerList = dealerOptions.join(",")
  const departmentList = ["Sales", "Service", "HR"].join(",")
  const activeList = ["Yes", "No"].join(",")
  const workLocationList = ["Branch Location", "Head Quarter"].join(",")

  sheet.dataValidations.add("A2:A1000", { type: "list", allowBlank: false, formulae: [`"${marketAreaList}"`] })
  sheet.dataValidations.add("B2:B1000", { type: "list", allowBlank: false, formulae: [`"${dealerList}"`] })
  sheet.dataValidations.add("E2:E1000", { type: "list", allowBlank: false, formulae: [`"${departmentList}"`] })
  sheet.dataValidations.add("I2:I1000", { type: "list", allowBlank: false, formulae: [`"${workLocationList}"`] })
  sheet.dataValidations.add("L2:L1000", { type: "list", allowBlank: false, formulae: [`"${activeList}"`] })

  // ================== FREEZE HEADER ==================
  sheet.views = [{ state: "frozen", ySplit: 1 }] // Header always visible

  // ================== SAVE FILE ==================
  const buffer = await workbook.xlsx.writeBuffer()
  const blob = new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  })
  saveAs(blob, "Dealer_Users_Template.xlsx")
}

const handleBulkUpload = (e) => {
  const file = e.target.files[0];
  if (!file) return;

  // Open preview tab
  const previewTab = window.open("/dealeruser/bulkupload", "_blank");
  if (!previewTab) {
    alert("Popup blocked! Please allow popups.");
    return;
  }

  const reader = new FileReader();

  reader.onload = (event) => {
    const data = new Uint8Array(event.target.result);
    const workbook = XLSX.read(data, { type: "array" });
    const sheetName = workbook.SheetNames[0];

    // Read Excel → JSON
    let rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
      defval: "",
    });

    // Remove completely empty rows
    rows = rows.filter((row) =>
      Object.values(row).some((val) => val !== "")
    );

    // Normalize rows for Dealer User
    const formattedRows = rows.map((row, index) => ({
      slNo: index + 1,
      marketArea: row["Market Area"] || "",
      dealer: row["Dealership"] || "",
      firstName: row["First Name"] || "",
      lastName: row["Last Name"] || "",
      department: row["Department"] || "",
      designation: row["Designation"] || "",
      phone: row["Phone Number"] || "",
      email: row["Email"] || "",
      workLocation: row["Work Location"] || "",
      joiningDate: row["Joining Date"] || "",
      yearsExp: row["Years Exp."] || "",
      active: row["Active"] || "",
      resignationDate: row["Resignation Date"] || "",
      notes: row["Notes"] || "",

      // Basic validation flag (preview page can use this)
      hasError:
        !row["Market Area"] ||
        !row["Dealership"] ||
        !row["First Name"] ||
        !row["Phone Number"] ||
        !row["Active"],
    }));

    // Send data to preview page
    previewTab.postMessage(
      {
        type: "DEALER_USER_BULK_PREVIEW",
        payload: {
          uploadedRows: formattedRows,
          existingRows: tableData, // existing dealer users
        },
      },
      "*"
    );
  };

  reader.readAsArrayBuffer(file);

 ;
};



  return (
    <div className="">
      {/* Stats */}
      <div className="bg-white shadow-[0_4px_10px_#0000001A] p-2 mb-2">
        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 text-center gap-2">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`relative py-0 px-3 ${
                index < stats.length - 1 ? "border-r border-darkblue1" : ""
              } flex items-center justify-center bg-white`}
            >
              <div className="flex items-center gap-1 text-xs font-VolvoNovum font-medium">
                <span className="text-black">{stat.title} :</span>
                <span className={`font-bold ${stat.color}`}>{stat.value}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top Bar */}
      <div className="flex justify-between items-center mt-4">
        <div className="flex gap-2">
          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search"
            className="w-[1/2]"
            iconColor="text-black"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            inputWidth="w-full"
            focusRing="focus:ring-1 focus:ring-black/60"
            hoverInputClasses="hover:bg-white hover:border-black/60"
          />

          {/* Filters */}
          <Filter
            name="Market Area"
            value={selectedMarketArea}
            options={marketAreaOptions}
            onChange={(name, value) => setSelectedMarketArea(value)}
            placeholder=" Market Area"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />
          <Filter
            name="Dealer"
            value={selectedDealer}
            options={dealerOptions}
            onChange={(name, value) => setSelectedDealer(value)}
            placeholder="Dealership"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />
          <Filter
            name="Department"
            value={selectedDepartment}
            options={departmentOptions}
            onChange={(name, value) => setSelectedDepartment(value)}
            placeholder="Department"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />
          <Filter
            name="Active"
            value={selectedActive}
            options={activeOptions}
            onChange={(name, value) => setSelectedActive(value)}
            placeholder="Active"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[100px]"
          />
        </div>

        {/* Add User Dropdown */}
        <div className="flex gap-2">
          <div className="relative inline-block">
            <button
              ref={addUserButtonRef}
              onClick={() => setIsAddUserOpen(!isAddUserOpen)}
              className="py-2 px-3 w-[150px] text-xs font-medium bg-darkblue1 text-white flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <img
                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/add user.png"
                  className="w-4 h-4"
                  alt="add"
                />
                Add User
              </span>
            </button>

            {isAddUserOpen && (
              <div
                ref={addUserDropdownRef}
                className="absolute top-full left-0 mt-1 bg-white border border-darkblue1 shadow-lg z-50"
                style={{ width: addUserButtonWidth }}
              >
                <button onClick={handleAddUser} className="w-full px-3 py-1 text-xs hover:bg-lightBlue/50 flex gap-2">
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/addnew.png"
                    alt="add"
                    className="w-4 h-3"
                  />
                  Add User
                </button>

                <button
  onClick={() => navigate("/dealeruser/bulkupload")}
        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
      >
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/bulkupload.png"
          className="w-3 h-3"
          alt="bulk"
        />
        Bulk Upload
      </button>
       <input
    type="file"
    ref={fileInputRef}
    className="hidden"
    accept=".xlsx,.xls"
    onChange={handleBulkUpload}
  />

                <button
                  onClick={() => {
                    handleDownloadTemplate()
                    setIsAddUserOpen(false)
                  }}
                  className="w-full px-3 py-1 text-xs hover:bg-lightBlue/50 flex gap-2"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/download.png"
                    alt="download"
                    className="w-3 h-3"
                  />
                  Template
                </button>
              </div>
            )}
          </div>

          {/* Download Button */}
          <button 
           onClick={handlePreviewAndDownload}
          className="py-2 px-6 text-xs border border-black/30 hover:bg-lightBlue/50 flex items-center gap-2">
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Scorecard/template.png"
              alt="bulk"
              className="w-4 h-4"
            />
            Download
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white shadow-md border border-Dustyblue mt-3">
        <div
                ref={tableContainerRef}
                className="overflow-y-auto overflow-x-auto max-h-full"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
              >
          <table className="text-sm w-full">
            <thead className="bg-Dustyblue text-white text-left text-xs sticky top-0 z-10">
              <tr>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%]">VDN ID</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%]">Market Area</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%]">Dealership</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%]">Name</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[7%]">Department</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[7%]">Designation</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[7%]">Phone Number</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%]">Email ID</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%]">Work Location</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%]">Joining Date</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[2%]">Years Exp.</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[4%]">Active</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%]">Resignation Date</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 text-center w-[5%]">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.length > 0 ? (
                filteredItems.map((item, idx) => {
                  const rowId = `${item.vdnId}-${idx}`;
                        const isActive = item.active === "Yes";

                  return (
<tr
          key={rowId}
          className={`hover:bg-lightBlue/50 cursor-pointer text-black text-xs ${
            isActive ? "text-black":"text-gray-400"// grey out text if inactive
          }`}
        >                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.vdnId}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.marketArea}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.dealer}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        {(item.firstName || "") + " " + (item.lastName || "")}
                      </td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.department}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.designation}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.phone}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.email}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.workLocation}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.joiningDate}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.yearsExp}</td>
<td
  className={`px-4 py-1 border border-grey2 border-t-0 border-l-0 ${
    item.active === "Yes" ? "text-saturatedgreen" : "text-red1"
  }`}
>
  {item.active}
</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.resignationDate}</td>
                      <td className="py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0 text-xs">
                        <div className="relative flex items-center justify-center">
                          <button
                            onClick={() => setDropdownId(dropdownId === rowId ? null : rowId)}
                            className="w-6 h-6 flex items-center justify-center border border-gray-300 hover:bg-gray-100"
                          >
                            <MoreVertical size={16} className="text-black" />
                          </button>

                          {dropdownId === rowId && (
                            <div
                              ref={(el) => (dropdownRefs.current[rowId] = el)}
                              className="absolute right-0 mt-1 bg-white w-40 border border-gray-200 shadow-lg z-50"
                            >
                              <div className="py-1 flex flex-col">
                                <button
                                  onClick={() => handleView(item)}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <Eye size={16} /> View
                                </button>

                                <button
                                  onClick={() => {
                                    handleEdit(item)
                                    setDropdownId(null) // close dropdown after click
                                  }}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <img
                                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
                                    alt="Edit"
                                    className="w-4 h-4"
                                  />
                                  Edit
                                </button>

    <button
  onClick={() => {
    setSelectedRow(idx); // store index of row
    const currentStatus = filteredItems[idx].active;
    if (currentStatus === "Yes") {
      setShowDeactivateModal(true); // show deactivate popup
    } else {
      setShowActivateModal(true); // show activate popup
    }
    setDropdownId(null); // close dropdown
  }}
  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
>
  <img
    src={
      filteredItems[idx].active === "Yes"
        ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/deactive.png"
        : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/active.png"
    }
    alt="Toggle Status"
    className="w-4 h-4"
  />
  <span>{filteredItems[idx].active === "Yes" ? "Deactivate" : "Activate"}</span>
</button>


    
                                <button
                                  onClick={() => handleDeleteClick(item)} // row here is the actual item
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <img
                                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                                    alt="Delete"
                                    className="w-4 h-4"
                                  />
                                  Delete
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  )
                })
              ) : (
                <tr>
                  <td colSpan="14" className="text-center py-8 text-xs text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      {viewContact && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white w-[50%] p-8 shadow-lg relative">
            <div className="relative mb-4">
              {/* Title (always centered) */}
              <h2 className="font-semibold text-sm text-MediumGrey text-center">Contact Card</h2>

              {/* Close button (absolute at top-right) */}
              <button onClick={handleClose} className="absolute top-0 right-0 text-red-500 hover:text-red-700">
                <img
                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
                  alt="close"
                  className="w-4 h-4"
                />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="bg-grey2 p-2 ">
                <strong>Name:</strong> {(viewContact.firstName || "") + " " + (viewContact.lastName || "")}
              </div>

              <div className="bg-grey2 p-2 ">
                <strong>Email ID:</strong> {viewContact.email}
              </div>

              <div className="bg-grey2 p-2 ">
                <strong>VDN ID:</strong> {viewContact.vdnId}
              </div>

              <div className="bg-grey2 p-2 ">
                <strong>Contact Number:</strong> {viewContact.phone}
              </div>

              <div className="bg-grey2 p-2 ">
                <strong>Dealer Name:</strong> {viewContact.dealer}
              </div>

              <div className="bg-grey2 p-2 ">
                <strong>Market Area:</strong> {viewContact.marketArea}
              </div>

              <div className="bg-grey2 p-2 ">
                <strong>Designation:</strong> {viewContact.designation}
              </div>

              <div className="bg-grey2 p-2 ">
                <strong>Work Location:</strong> {viewContact.workLocation}
              </div>

              {/* Notes full width */}
             <div className="bg-grey2 p-2 col-span-2">
          <strong>Notes:</strong>
          <p className="whitespace-pre-wrap">{viewContact.notes || "No notes available."}</p>
        </div>
            </div>
          </div>
        </div>
      )}
      {deleteItem && (
        <DeleteModal
          isOpen={true}
          onClose={() => setDeleteItem(null)} // only No button closes
          onConfirm={handleConfirmDelete}
          loading={loading}
          extraMessage="This row will be permanently deleted."
        />
      )}

      <ActivateStatus
  isOpen={showActivateModal}
  onClose={() => setShowActivateModal(false)}
  onConfirm={handleConfirmActivate}
  loading={statusLoading}
/>

<DeactivateStatus
  isOpen={showDeactivateModal}
  onClose={() => setShowDeactivateModal(false)}
  onConfirm={handleConfirmDeactivate}
  loading={statusLoading}
/>

    </div>
  )
}

export default DealerUser
