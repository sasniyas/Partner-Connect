"use client";
import React, { useState } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

function DealerUserBulkUpload() {
  const [rows, setRows] = useState([]);
  const [fileName, setFileName] = useState("");

  const marketAreaOptions = ["North", "South", "East", "West", "Central"];
  const dealerOptions = ["Alpha Teknisk Pvt. Ltd.", "ESDEE SOLUTECH", "BSES India Pvt. Ltd."];
  const departmentOptions = ["Sales", "Service", "HR"];
  const activeOptions = ["Yes", "No"];
  const workLocationOptions = ["Branch Location", "Head Quarter"];

  const navigate = useNavigate();

  // ================= BACK =================
 const handleBack = () => {
    navigate("/contactmanagemnet", { state: { activeTab: "dealerUsers" } })
  }
  // ================= FILE UPLOAD =================
  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (event) => {
      const workbook = XLSX.read(event.target.result, { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];

      let json = XLSX.utils.sheet_to_json(sheet, { defval: "" });
      json = json.filter(row => Object.values(row).some(v => v !== ""));

      const normalize = (str) => (str || "").toString().trim();

      const finalRows = json.map((row, index) => {
        const marketArea = normalize(row["Market Area"]);
        const dealerName = normalize(row["Dealership"]);
        const firstName = normalize(row["First Name"]);
        const lastName = normalize(row["Last Name"]);
        const department = normalize(row["Department"]);
        const designation = normalize(row["Designation"]);
        const phone = normalize(row["Phone Number"]);
        const email = normalize(row["Email"]);
        const workLocation = normalize(row["Work Location"]);
        const joiningDate = normalize(row["Joining Date"]);
        const yearsExp = normalize(row["Years Exp."]);
        const active = normalize(row["Active"]);
        const resignationDate = normalize(row["Resignation Date"]);
        const notes = normalize(row["Notes"]);

        const errors = [];
        if (!marketAreaOptions.includes(marketArea)) errors.push("Invalid Market Area");
        if (!dealerOptions.includes(dealerName)) errors.push("Invalid Dealer");
        if (!firstName) errors.push("First Name required");
        if (!phone) errors.push("Phone required");
        if (!activeOptions.includes(active)) errors.push("Invalid Active status");

        return {
          id: index + 1,
          market_area: marketArea,
          dealer_name: dealerName,
          first_name: firstName,
          last_name: lastName,
          department,
          designation,
          phone,
          email,
          work_location: workLocation,
          joining_date: joiningDate,
          years_exp: yearsExp,
          active,
          resignation_date: resignationDate,
          notes,
          hasError: errors.length > 0,
          errors,
        };
      });

      setRows(finalRows);
    };

    reader.readAsArrayBuffer(file);
  };

  // ================= CELL CHANGE =================
  const handleCellChange = (idx, key, value) => {
    const updated = [...rows];
    updated[idx][key] = value;

    updated[idx].hasError =
      !marketAreaOptions.includes(updated[idx].market_area) ||
      !dealerOptions.includes(updated[idx].dealer_name) ||
      !updated[idx].first_name ||
      !updated[idx].phone ||
      !activeOptions.includes(updated[idx].active);

    setRows(updated);
  };

  // ================= SAVE =================
  const handleSave = () => {
    if (rows.some(r => r.hasError)) {
      alert("Please fix highlighted rows.");
      return;
    }

    const payload = rows.map(r => ({
      market_area: r.market_area,
      dealer_name: r.dealer_name,
      first_name: r.first_name,
      last_name: r.last_name,
      department: r.department,
      designation: r.designation,
      phone: r.phone,
      email: r.email,
      work_location: r.work_location,
      joining_date: r.joining_date,
      years_exp: r.years_exp,
      active: r.active,
      resignation_date: r.resignation_date,
      notes: r.notes,
    }));

    console.log("FINAL PAYLOAD:", payload);
    // 🔴 BULK SAVE API CALL HERE
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header />
      <SubNavbar3 />

      <div className="flex-1 flex justify-center">
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">

          {/* Back */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">
              Dealer User Bulk Upload
            </h2>
          </div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-7  mb-2"></div>

          {/* Browse + Save */}
          <div className="mb-4 flex items-center gap-2 w-full max-w-md">
            <div className="flex-1 flex items-center border px-3 py-1.5 bg-white text-xs">
              <span className="truncate">{fileName || "No file selected"}</span>
              <input
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleBulkUpload}
                id="bulk-dealer-upload"
              />
            </div>

            <label
              htmlFor="bulk-dealer-upload"
              className="px-2 py-1.5 bg-darkblue1 text-white text-xs cursor-pointer"
            >
              Browse
            </label>

            <button
              onClick={handleSave}
              className="px-3 py-1.5 bg-darkblue1 text-white text-xs"
            >
              Save
            </button>
          </div>

          {/* TABLE */}
          {rows.length ? (
            <div className="overflow-auto border border-Dustyblue mb-2">
              <div className="overflow-y-auto max-h-[400px] relative">
                <table className="w-full text-xs bg-white border-collapse whitrespace-nowrap">
                  <thead className="bg-Dustyblue text-white sticky top-0">
                    <tr>
                      {["Market Area","Dealership","First Name","Last Name","Department","Designation","Phone","Email","Work Location","Joining Date","Years Exp.","Active","Resignation Date","Notes"]
                        .map(h => <th key={h} className="border px-2 py-1">{h}</th>)}
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((row, i) => (
                      <tr key={i} className={row.hasError ? "bg-red-100" : ""}>
                        <td className="border px-2">
                          <select
                            value={row.market_area}
                            onChange={e => handleCellChange(i,"market_area",e.target.value)}
                            className="w-full border"
                          >
                            <option value="">Select</option>
                            {marketAreaOptions.map(m => (
                              <option key={m} value={m}>{m}</option>
                            ))}
                          </select>
                        </td>

                        <td className="border px-2">
                          <select
                            value={row.dealer_name}
                            onChange={e => handleCellChange(i,"dealer_name",e.target.value)}
                            className="w-full border"
                          >
                            <option value="">Select</option>
                            {dealerOptions.map(d => (
                              <option key={d} value={d}>{d}</option>
                            ))}
                          </select>
                        </td>

                        <td className="border px-2">
                          <input
                            value={row.first_name}
                            onChange={e => handleCellChange(i,"first_name",e.target.value)}
                            className="w-full border"
                          />
                        </td>

                        <td className="border px-2">
                          <input
                            value={row.last_name}
                            onChange={e => handleCellChange(i,"last_name",e.target.value)}
                            className="w-full border"
                          />
                        </td>

                        <td className="border px-2">
                          <select
                            value={row.department}
                            onChange={e => handleCellChange(i,"department",e.target.value)}
                            className="w-full border"
                          >
                            <option value="">Select</option>
                            {departmentOptions.map(d => (
                              <option key={d} value={d}>{d}</option>
                            ))}
                          </select>
                        </td>

                        <td className="border px-2">
                          <input
                            value={row.designation}
                            onChange={e => handleCellChange(i,"designation",e.target.value)}
                            className="w-full border"
                          />
                        </td>

                        <td className="border px-2">
                          <input
                            value={row.phone}
                            onChange={e => handleCellChange(i,"phone",e.target.value)}
                            className="w-full border"
                          />
                        </td>

                        <td className="border px-2">
                          <input
                            value={row.email}
                            onChange={e => handleCellChange(i,"email",e.target.value)}
                            className="w-full border"
                          />
                        </td>

                        <td className="border px-2">
                          <select
                            value={row.work_location}
                            onChange={e => handleCellChange(i,"work_location",e.target.value)}
                            className="w-full border"
                          >
                            <option value="">Select</option>
                            {workLocationOptions.map(w => (
                              <option key={w} value={w}>{w}</option>
                            ))}
                          </select>
                        </td>

                        <td className="border px-2">
                          <input
                            value={row.joining_date}
                            onChange={e => handleCellChange(i,"joining_date",e.target.value)}
                            className="w-full border"
                            type="date"
                          />
                        </td>

                        <td className="border px-2">
                          <input
                            value={row.years_exp}
                            onChange={e => handleCellChange(i,"years_exp",e.target.value)}
                            className="w-full border"
                            type="number"
                          />
                        </td>

                        <td className="border px-2">
                          <select
                            value={row.active}
                            onChange={e => handleCellChange(i,"active",e.target.value)}
                            className="w-full border"
                          >
                            <option value="">Select</option>
                            {activeOptions.map(a => (
                              <option key={a} value={a}>{a}</option>
                            ))}
                          </select>
                        </td>

                        <td className="border px-2">
                          <input
                            value={row.resignation_date}
                            onChange={e => handleCellChange(i,"resignation_date",e.target.value)}
                            className="w-full border"
                            type="date"
                          />
                        </td>

                        <td className="border px-2">
                          <input
                            value={row.notes}
                            onChange={e => handleCellChange(i,"notes",e.target.value)}
                            className="w-full border"
                          />
                        </td>

                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <p className="text-gray-500 text-center py-6 italic">No data loaded.</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default DealerUserBulkUpload;
