import React, { useState, useRef } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import StyledSelectField from "../../../Components/StyledSelectField";
import StyledDateField from "../../../Components/StyledDatefield";
import { useEffect } from "react";
const DealerAddUser = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
// Validation regex: only letters and space
const nameRegex = /^[A-Za-z ]+$/;
const phoneRegex = /^[0-9]{10}$/;
const fileInputRef = useRef(null);
const [selectedFileName, setSelectedFileName] = useState(""); // <-- Add this state
  // Dropdown options
  const marketAreaOptions = [
    { label: "North", value: "North" },
    { label: "South", value: "South" },
    { label: "East", value: "East" },
    { label: "West", value: "West" },
  ];
const reportingManagerOptions = [
  { label: "Alice Johnson", value: "alice.johnson" },
  { label: "Bob Smith", value: "bob.smith" },
  { label: "Carol Lee", value: "carol.lee" },
  { label: "David Kim", value: "david.kim" },
  { label: "Emma Davis", value: "emma.davis" },
];

  const dealerOptions = [
    { label: "NAVIN", value: "NAVIN" },
    { label: "DRS", value: "DRS" },
    { label: "PAL", value: "PAL" },
  ];
const departmentOptions = [
    { label: "Sales", value: "Sales" },
    { label: "Service", value: "Service" },
    { label: "HR", value: "HR" },
  ]
  

  const workLocationOptions = [
    { label: "Head Quarter", value: "Head Quarter" },
    { label: "Branch Location", value: "Branch Location" },
   
  ];

  const activeOptions = [
    { label: "Yes", value: "Yes" },
    { label: "No", value: "No" },
  ];

  // Form state
  const [formData, setFormData] = useState({
    marketArea: "",
    dealer: "",
    firstName: "",
    lastName: "",
    vdnId: "VDN-04",
    phoneNumber: "",
    department: "",
    designation: "",
    email: "",
    workLocation: "",
    joiningDate: "",
    experience: "",
    active: "",
    notes: "",
    resignationDate:""
  });

  // Dropdown open states
  const [dropdowns, setDropdowns] = useState({
    marketArea: false,
    dealer: false,
    department: false,
    workLocation: false,
    active: false,
  });
const designationOptions = [
  { label: "Manager", value: "manager" },
  { label: "Team Lead", value: "team_lead" },
  { label: "Developer", value: "developer" },
];

  // Refs for dropdowns (if your StyledSelectField uses them)
  const refs = {
    marketArea: useRef(),
    dealer: useRef(),
    department: useRef(),
    workLocation: useRef(),
    active: useRef(),
  };
useEffect(() => {
    const closeDropdown = (e) => {
      Object.keys(refs).forEach((key) => {
        if (refs[key]?.current && !refs[key].current.contains(e.target)) {
          setDropdowns((prev) => ({ ...prev, [key]: false }))
        }
      })
    }
    document.addEventListener("mousedown", closeDropdown)
    return () => document.removeEventListener("mousedown", closeDropdown)
  }, [])

  // Error state
  const [errors, setErrors] = useState({});

const handleBack = () => {
navigate("/contactmanagemnet", { state: { activeTab: "dealerUsers" } });
};
  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
    setErrors((prev) => ({ ...prev, [field]: "" })); // clear error on change
  };

 const handleSave = () => {
  let requiredFields = [
    "marketArea",
    "dealer",
    "firstName",
    "lastName",
    "vdnId",
    "phoneNumber",
    "department",
    "designation",
    "email",
    "workLocation",
    "joiningDate",
    "experience",
    "active",
    "notes",
    "reportingManager", // ✅ added reporting manager
    "image",            // ✅ added uploaded image
  ];

  // ✅ add resignationDate only if active = "no"
  if (formData.active === "no") {
    requiredFields.push("resignationDate");
  }

  let newErrors = {};

  // ✅ validate all required fields
  requiredFields.forEach((field) => {
    if (!formData[field]) {
      newErrors[field] = "This field is required";
    }
  });

  setErrors(newErrors);

  // ✅ navigate only if no errors
  if (Object.keys(newErrors).length === 0) {
    navigate("/contactmanagemnet", {
      state: { newUser: { ...formData } },
    });
  }
};




  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="flex flex-col w-full mb-3">
            <div className="flex items-center gap-2">
              <ArrowLeft
                onClick={handleBack}
                size={20}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
              />
              <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                Add New Contact
              </h2>
            </div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-7"></div>
          </div>

          {/* Form */}
          <div className="bg-white px-6 py-4 rounded shadow-md">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-12 gap-y-2">

              {/* Market Area */}
              <StyledSelectField
                label="Market Area"
                placeholder="Select Market Area"
                value={
                  marketAreaOptions.find((opt) => opt.value === formData.marketArea)?.label || ""
                }
                setValue={(label) => {
                  const selected = marketAreaOptions.find((opt) => opt.label === label);
                  handleChange("marketArea", selected?.value || "");
                }}
                options={marketAreaOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.marketArea}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, marketArea: val }))}
                dropdownRef={refs.marketArea}
                error={errors.marketArea}
              />

              {/* Dealer */}
              <StyledSelectField
                label="Dealership"
                placeholder="Select Dealership"
                value={
                  dealerOptions.find((opt) => opt.value === formData.dealer)?.label || ""
                }
                setValue={(label) => {
                  const selected = dealerOptions.find((opt) => opt.label === label);
                  handleChange("dealer", selected?.value || "");
                }}
                options={dealerOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.dealer}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, dealer: val }))}
                dropdownRef={refs.dealer}
                error={errors.dealer}
              />

              {/* First Name */}
              <div className="flex flex-col">
  <label className="text-xs font-medium text-black/70 mb-2">First Name</label>

  <input
    type="text"
    placeholder="Enter First Name"
    value={formData.firstName}
    onChange={(e) => {
      const value = e.target.value;
      handleChange("firstName", value);

      if (value.trim() === "") {
        setErrors((prev) => ({ ...prev, firstName: "" }));
      } else if (!nameRegex.test(value)) {
        setErrors((prev) => ({ ...prev, firstName: "Only letters and spaces allowed" }));
      } else {
        setErrors((prev) => ({ ...prev, firstName: "" }));
      }
    }}
    className={`border text-xs px-4 py-1.5 ${
      errors.firstName ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
  />

  {errors.firstName && (
    <span className="text-red1 text-xs">{errors.firstName}</span>
  )}
</div>


              {/* Last Name */}
             <div className="flex flex-col">
  <label className="text-xs font-medium text-black/70 mb-2">Last Name</label>

  <input
    type="text"
    placeholder="Enter Last Name"
    value={formData.lastName}
    onChange={(e) => {
      const value = e.target.value;
      handleChange("lastName", value);

      if (value.trim() === "") {
        setErrors((prev) => ({ ...prev, lastName: "" }));
      } else if (!nameRegex.test(value)) {
        setErrors((prev) => ({ ...prev, lastName: "Only letters and spaces allowed" }));
      } else {
        setErrors((prev) => ({ ...prev, lastName: "" }));
      }
    }}
    className={`border text-xs px-4 py-1.5 ${
      errors.lastName ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
  />

  {errors.lastName && (
    <span className="text-red1 text-xs">{errors.lastName}</span>
  )}
</div>


              {/* VDN ID */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">VDN ID</label>
                <input
                  type="text"
                  value={formData.vdnId}
                  onChange={(e) => handleChange("vdnId", e.target.value)}
                  className={`border text-xs px-4 py-1.5  text-xs ${
                    errors.vdnId ? "border-red1" : "border-black/30"
                  }`}
                />
                {errors.vdnId && <span className="text-red1 text-xs">{errors.vdnId}</span>}
              </div>

              {/* Phone Number */}
              <div className="flex flex-col">
  <label className="text-xs font-medium text-black/70 mb-2">Phone Number</label>

  <input
    type="text"
    maxLength={10}                 // prevents typing more than 10 digits
    placeholder="Enter Phone Number"
    value={formData.phoneNumber}
    onChange={(e) => {
      const value = e.target.value;

      // Allow only digits
      if (/^[0-9]*$/.test(value)) {
        handleChange("phoneNumber", value);
      }

      // Validation messages
      if (value.trim() === "") {
        setErrors((prev) => ({
          ...prev,
          phoneNumber: "",
        }));
      } else if (value.length !== 10) {
        setErrors((prev) => ({
          ...prev,
          phoneNumber: "Phone number must be 10 digits",
        }));
      } else {
        setErrors((prev) => ({ ...prev, phoneNumber: "" }));
      }
    }}
    className={`border text-xs px-4 py-1.5 text-sm ${
      errors.phoneNumber ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
  />

  {errors.phoneNumber && (
    <span className="text-red1 text-xs">{errors.phoneNumber}</span>
  )}
</div>


              {/* Department */}
              <StyledSelectField
                label="Department"
                placeholder="Select Department"
                value={
                  departmentOptions.find((opt) => opt.value === formData.department)?.label || ""
                }
                setValue={(label) => {
                  const selected = departmentOptions.find((opt) => opt.label === label);
                  handleChange("department", selected?.value || "");
                }}
                options={departmentOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.department}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, department: val }))}
                dropdownRef={refs.department}
                error={errors.department}
              />

              {/* Designation */}
            {/* Designation */}
<StyledSelectField
  label="Designation"
  placeholder="Select Designation"
  value={
    designationOptions.find((opt) => opt.value === formData.designation)?.label || ""
  }
  setValue={(label) => {
    const selected = designationOptions.find((opt) => opt.label === label);
    handleChange("designation", selected?.value || "");
  }}
  options={designationOptions.map((opt) => opt.label)}
  dropdownOpen={dropdowns.designation}
  setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, designation: val }))}
  dropdownRef={refs.designation}
  error={errors.designation}
/>


              {/* Email */}
             <div className="flex flex-col">
  <label className="text-xs font-medium text-black/70 mb-2">Email ID</label>
  <input
    type="email"
    placeholder="Enter Email"
    value={formData.email}
    onChange={(e) => {
      const value = e.target.value;
      handleChange("email", value);

      // Live validation
      if (value.trim() === "") {
        setErrors((prev) => ({ ...prev, email: "" }));
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        setErrors((prev) => ({ ...prev, email: "Invalid email" }));
      } else {
        setErrors((prev) => ({ ...prev, email: "" }));
      }
    }}
    className={`border text-xs px-4 py-1.5 ${
      errors.email ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
  />

  {errors.email && (
    <span className="text-red1 text-xs">{errors.email}</span>
  )}
</div>


              {/* Work Location */}
              <div>
              <StyledSelectField
                label="Work Location"
                placeholder="Select Work Location"
                value={
                  workLocationOptions.find((opt) => opt.value === formData.workLocation)?.label || ""
                }
                setValue={(label) => {
                  const selected = workLocationOptions.find((opt) => opt.label === label);
                  handleChange("workLocation", selected?.value || "");
                }}
                options={workLocationOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.workLocation}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, workLocation: val }))}
                dropdownRef={refs.workLocation}
                error={errors.workLocation}
              />
              </div>
<div className="mt-1">
              {/* Joining Date */}
             <StyledDateField
  label="Joining Date"
  value={formData.joiningDate}
  setValue={(val) => handleChange("joiningDate", val)}
  error={errors.joiningDate}
/>
</div>

              {/* Years of Experience */}
             <div className="flex flex-col">
  <label className="text-xs font-medium text-black/70 mb-2">
    Years of Experience
  </label>

  <input
    type="text"
    placeholder="Enter Years of Experience"
    value={formData.experience}
    maxLength={2} // optional → allows only 0–99
    onChange={(e) => {
      const value = e.target.value;

      // Allow only digits
      if (/^[0-9]*$/.test(value)) {
        handleChange("experience", value);
      }

      // Validation messages
      if (value.trim() === "") {
        setErrors((prev) => ({
          ...prev,
          experience: "",
        }));
      } else {
        setErrors((prev) => ({ ...prev, experience: "" }));
      }
    }}
    className={`border text-xs px-4 py-1.5 text-xs ${
      errors.experience ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
  />

  {errors.experience && (
    <span className="text-red1 text-xs">{errors.experience}</span>
  )}
</div>
<div>
  <StyledSelectField
    label="Reporting Manager"
    placeholder="Select Reporting Manager"
    value={
      reportingManagerOptions.find((opt) => opt.value === formData.reportingManager)?.label || ""
    }
    setValue={(label) => {
      const selected = reportingManagerOptions.find((opt) => opt.label === label);
      handleChange("reportingManager", selected?.value || "");
    }}
    options={reportingManagerOptions.map((opt) => opt.label)}
    dropdownOpen={dropdowns.reportingManager}
    setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, reportingManager: val }))}
    dropdownRef={refs.reportingManager}
    error={errors.reportingManager}
  />
</div>



<div className="flex flex-col mt-1">
  <label className="text-xs mb-1">Upload Image</label>
  <div
    className={`flex items-center px-4 py-1.5 text-xs border cursor-pointer ${
      errors.image
        ? "border-red1"
        : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
    onClick={() => fileInputRef.current.click()}
  >
    <input
      type="file"
      accept="image/*"
      ref={fileInputRef}
      style={{ display: "none" }}
      onChange={(e) => {
        const file = e.target.files[0];
        setSelectedFileName(file ? file.name : "");
        handleChange("image", file); // store in formData
      }}
    />
    <span className="flex-1">{selectedFileName || "Choose an image..."}</span>
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      viewBox="0 0 16 16"
      className="ml-2 text-black/50"
    >
      <path d="M.5 9.9a.5.5 0 0 1 .5-.5h4v-4a.5.5 0 0 1 1 0v4h4a.5.5 0 0 1 0 1h-4v4a.5.5 0 0 1-1 0v-4h-4a.5.5 0 0 1-.5-.5z" />
    </svg>
  </div>
  {errors.image && <span className="text-red1 text-xs mt-1">{errors.image}</span>}
</div>


              {/* Active */}
              <StyledSelectField
                label="Active"
                placeholder="Select Active"
                value={
                  activeOptions.find((opt) => opt.value === formData.active)?.label || ""
                }
                setValue={(label) => {
                  const selected = activeOptions.find((opt) => opt.label === label);
                  handleChange("active", selected?.value || "");
                }}
                options={activeOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.active}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, active: val }))}
                dropdownRef={refs.active}
                error={errors.active}
              />
{/* Resignation Date – only when Active = No */}
<div className="mt-1">
{formData.active === "no" && (
  <StyledDateField
    label="Resignation Date"
    value={formData.resignationDate}
    setValue={(val) => handleChange("resignationDate", val)}
    error={errors.resignationDate}
  />
)}
</div>
              {/* Notes */}
              <div className="flex flex-col col-span-3">
  <label className="text-xs font-medium text-black mb-3">Notes</label>
  <textarea
    placeholder="Enter Notes"
    value={formData.notes}
    onChange={(e) => handleChange("notes", e.target.value)}
    className={`border text-xs px-4 py-2 text-xs resize-none h-28 ${
      errors.notes ? "border-red1" : "border-black/30"
    }`}
  />
  {errors.notes && <span className="text-red1 text-xs">{errors.notes}</span>}
</div>


            </div>

            {/* Save Button */}
            <div className="mt-4 flex justify-end">
              <button
                onClick={handleSave}
                className="bg-darkblue1 text-white px-8 py-1.5 transition text-xs hover:border hover:border-darkblue1 hover:bg-white hover:text-darkblue1"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DealerAddUser;
