// // import { Smile, Paperclip, Send } from "lucide-react";
// // import Filter from "../../../Components/Filter";
// // import { useState } from "react";
// // import Searchinput from "../../../Components/Searchinput";

// // export default function Chatter() {
// //   const users = [
// //   { id: 0, name: "Jagath Jain", role: "Regional Manager", code: "VC1001", time: "10:00 AM", active: false },
// //   { id: 1, name: "Priya Sharma", role: "Sales Executive", code: "VC1002", time: "10:15 AM", active: false },
// //   { id: 2, name: "Rahul Verma", role: "Manager", code: "VC1003", time: "10:30 AM", active: true },
// //   { id: 3, name: "Sneha Kapoor", role: "Sales Executive", code: "VC1004", time: "10:45 AM", active: false },
// //   { id: 4, name: "Ankit Singh", role: "Regional Manager", code: "VC1005", time: "11:00 AM", active: false },
// //   { id: 5, name: "Neha Reddy", role: "Sales Executive", code: "VC1006", time: "11:15 AM", active: false },
// //   { id: 6, name: "Vikram Das", role: "Manager", code: "VC1007", time: "11:30 AM", active: false },
// //   { id: 7, name: "Riya Kapoor", role: "Sales Executive", code: "VC1008", time: "11:45 AM", active: false },
// // ];


// //   // FILTER STATES
// //   const [selectedMarketArea, setSelectedMarketArea] = useState(""); // string only
// //   const [selectedDealer, setSelectedDealer] = useState("");
// //   const [selectedDesignation, setSelectedDesignation] = useState("");
// //   const [searchTerm, setSearchTerm] = useState("");

// //   // FILTER OPTIONS
// //    const marketAreaOptions = ["North", "South", "East", "West", "Central"];


// //   const dealerOptions = [
// //     "Jagath Jain",
// //     "Priya Sharma",
// //     "Rahul Verma",
// //     "Sneha Kapoor",
// //     "Ankit Singh",
// //   ];

// //   const designationOptions = [
// //     "Regional Manager",
// //     "Sales Executive",
// //     "Manager",
    
// //   ];

// //   const messages = [
// //     { text: "Hello", time: "09:00 AM", type: "in" },
// //     { text: "Good Morning!", time: "09:00 AM", type: "in" },
// //     { date: "20/11/2025" },
// //     { text: "Very Good Morning", time: "06:04 AM", type: "out" },
// //     {
// //       text:
// //         "Yes absolutely, I know my numbers are down but I've been focusing on quality over quantity",
// //       time: "06:04 AM",
// //       type: "out",
// //     },
// //     { date: "20/11/2025" },
// //     {
// //       text: "Lorem ipsum is a dummy or placeholder text commonly",
// //       time: "06:04 AM",
// //       type: "out",
// //     },
// //   ];
// // const filteredUsers = users.filter(u => {
// //   const matchesMarket = selectedMarketArea ? u.market === selectedMarketArea : true;
// //   const matchesDealer = selectedDealer ? u.dealer === selectedDealer : true;
// //   const matchesDesignation = selectedDesignation ? u.role === selectedDesignation : true;
// //   const matchesSearch = u.name.toLowerCase().includes(searchTerm.toLowerCase());
// //   return matchesMarket && matchesDealer && matchesDesignation && matchesSearch;
// // });

// //   return (
// //     <div className="flex h-[calc(72vh-20px)] -mt-2 bg-white">
// //       {/* LEFT PANEL */}
// //       <div className="w-90 border-r flex flex-col">
// //         <div className="p-3">
// //           {/* Top Row */}
// //           <div className="flex items-center justify-between">
// //             <div>
// //               <h2 className="text-sm font-semibold text-darkblue1">Dealer Users</h2>
// //               <div className="hidden lg:block h-1 bg-darkblue1 w-10 mt-0 mb-3"></div>
// //             </div>

            
// //           </div>

// //           {/* Filters */}
         
// //           {/* Search */}
// //           <Searchinput
// //             value={searchTerm}
// //             onChange={(e) => setSearchTerm(e.target.value)}
// //             placeholder="Search"
// //             className="w-[240px]"
// //             iconColor="text-black"
// //             bgColor="bg-FrostWhite"
// //             borderColor="border-black/60"
// //             textColor="text-black"
// //             shadow="shadow-none"
// //             inputPadding="pl-6 pr-3 py-1.5"
// //             iconSize="w-3 h-3"
// //             iconLeft="left-3"
// //             inputWidth="w-full"
// //             focusRing="focus:ring-1 focus:ring-black/60"
// //             hoverInputClasses="hover:bg-white hover:border-black/60"
// //           />
// //         </div>

// //         {/* Tabs */}
// //         <div className="flex items-center text-xs p-3 -mt-4">
// //           <div className="flex gap-2">
// //             <button className="px-4 py-1 border bg-darkblue1 text-white font-medium">All</button>
// //             <button className="px-4 py-1 border border-gray-300 text-gray-500">Groups</button>
// //           </div>
// //           <div className="flex-1" />
// //           <button className="px-3 py-1 border bg-darkblue1 text-white font-medium hover:bg-white hover:text-darkblue1 hover:border-darkblue1">
// //             +
// //           </button>
// //         </div>

// //        {/* User List */}
// // <div className="flex-1 overflow-y-auto">
// //   {filteredUsers.map((u) => (
// //     <div
// //       key={u.id}
// //       className={`flex gap-3 p-3 border-b cursor-pointer ${
// //         u.active ? "text-black" : "text-gray-500"
// //       }`}
// //     >
// //       {/* Avatar with initials */}
// //       <div className="w-8 h-8 rounded bg-gray-200 text-black flex items-center justify-center text-xs font-semibold">
// //         {u.name
// //           .split(" ")
// //           .map((n) => n[0])
// //           .join("")
// //           .toUpperCase()}
// //       </div>

// //       {/* User info */}
// //       <div className="flex-1">
// //         <div className="flex justify-between text-sm">
// //           <span>{u.name}</span>
// //           <span className="text-xs">{u.time}</span>
// //         </div>
// //         <p className="text-xs opacity-80">{u.role}</p>
// //         <p className="text-xs opacity-60">{u.code}</p>
// //       </div>
// //     </div>
// //   ))}
// // </div>
// //         </div>

// //       {/* RIGHT CHAT WINDOW */}
// //       <div className="flex-1 flex flex-col">
// //         {/* Header */}
// //         <div className="h-12 border-b flex items-center px-4 gap-2">
// //           <div className="w-7 h-7 bg-gray-300 rounded flex items-center justify-center text-xs font-semibold">
// //             JJ
// //           </div>
// //           <span className="text-sm font-medium">Jagath Jain</span>
// //         </div>

// //         {/* Messages */}
// //         <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
// //           {messages.map((m, i) =>
// //             m.date ? (
// //               <div key={i} className="text-xs text-gray-400 text-center">
// //                 {m.date}
// //               </div>
// //             ) : (
// //               <div key={i} className={`flex ${m.type === "out" ? "justify-end" : "justify-start"}`}>
// //                 <div
// //                   className={`max-w-md px-3 py-2 rounded text-sm ${
// //                     m.type === "out" ? "bg-blue-100 text-right" : "bg-white border"
// //                   }`}
// //                 >
// //                   <p>{m.text}</p>
// //                   <span className="block text-[10px] text-gray-400 mt-1">{m.time}</span>
// //                 </div>
// //               </div>
// //             )
// //           )}
// //         </div>

// //         {/* Input */}
// //         <div className="h-14 border-t flex items-center gap-3 px-4">
// //           <Smile className="w-5 h-5 text-gray-500 cursor-pointer" />
// //           <Paperclip className="w-5 h-5 text-gray-500 cursor-pointer" />
// //           <input placeholder="Type a message" className="flex-1 border rounded px-3 py-2 text-sm" />
// //           <Send className="w-5 h-5 text-gray-700 cursor-pointer" />
// //         </div>
// //       </div>
// //     </div>
// //   );
// // }


// import { Smile, Paperclip, Send } from "lucide-react";
// import Filter from "../../../Components/Filter";
// import { useState } from "react";
// import Searchinput from "../../../Components/Searchinput";

// export default function Chatter() {
//   const users = [
//     { id: 0, name: "Jagath Jain", role: "Regional Manager", code: "VC1001", time: "10:00 AM", active: false },
//     { id: 1, name: "Priya Sharma", role: "Sales Executive", code: "VC1002", time: "10:15 AM", active: false },
//     { id: 2, name: "Rahul Verma", role: "Manager", code: "VC1003", time: "10:30 AM", active: true },
//     { id: 3, name: "Sneha Kapoor", role: "Sales Executive", code: "VC1004", time: "10:45 AM", active: false },
//     { id: 4, name: "Ankit Singh", role: "Regional Manager", code: "VC1005", time: "11:00 AM", active: false },
//     { id: 5, name: "Neha Reddy", role: "Sales Executive", code: "VC1006", time: "11:15 AM", active: false },
//     { id: 6, name: "Vikram Das", role: "Manager", code: "VC1007", time: "11:30 AM", active: false },
//     { id: 7, name: "Riya Kapoor", role: "Sales Executive", code: "VC1008", time: "11:45 AM", active: false },
//   ];

//   // FILTER STATES
//   const [selectedMarketArea, setSelectedMarketArea] = useState(""); 
//   const [selectedDealer, setSelectedDealer] = useState("");
//   const [selectedDesignation, setSelectedDesignation] = useState("");
//   const [searchTerm, setSearchTerm] = useState("");

//   // Track selected user
//   const [activeUser, setActiveUser] = useState(users[0]);

//   const marketAreaOptions = ["North", "South", "East", "West", "Central"];
//   const dealerOptions = ["Jagath Jain", "Priya Sharma", "Rahul Verma", "Sneha Kapoor", "Ankit Singh"];
//   const designationOptions = ["Regional Manager", "Sales Executive", "Manager"];

//   const messages = [
//     { text: "Hello", time: "09:00 AM", type: "in" },
//     { text: "Good Morning!", time: "09:00 AM", type: "in" },
//     { date: "20/11/2025" },
//     { text: "Very Good Morning", time: "06:04 AM", type: "out" },
//     { text: "Yes absolutely, I know my numbers are down but I've been focusing on quality over quantity", time: "06:04 AM", type: "out" },
//     { date: "20/11/2025" },
//     { text: "Lorem ipsum is a dummy or placeholder text commonly", time: "06:04 AM", type: "out" },
//   ];

//   const filteredUsers = users.filter(u => {
//     const matchesMarket = selectedMarketArea ? u.market === selectedMarketArea : true;
//     const matchesDealer = selectedDealer ? u.dealer === selectedDealer : true;
//     const matchesDesignation = selectedDesignation ? u.role === selectedDesignation : true;
//     const matchesSearch = u.name.toLowerCase().includes(searchTerm.toLowerCase());
//     return matchesMarket && matchesDealer && matchesDesignation && matchesSearch;
//   });

//   return (
//     <div className="flex h-[calc(72vh-20px)] -mt-2 bg-white">
//       {/* LEFT PANEL */}
//       <div className="w-90 border-r flex flex-col">
//         <div className="p-3">
//           <div className="flex items-center justify-between">
//             <div>
//               <h2 className="text-sm font-semibold text-darkblue1">Dealer Users</h2>
//               <div className="hidden lg:block h-1 bg-darkblue1 w-10 mt-0 mb-3"></div>
//             </div>
//           </div>

//           <Searchinput
//             value={searchTerm}
//             onChange={(e) => setSearchTerm(e.target.value)}
//             placeholder="Search"
//             className="w-[240px]"
//             iconColor="text-black"
//             bgColor="bg-FrostWhite"
//             borderColor="border-black/60"
//             textColor="text-black"
//             shadow="shadow-none"
//             inputPadding="pl-6 pr-3 py-1.5"
//             iconSize="w-3 h-3"
//             iconLeft="left-3"
//             inputWidth="w-full"
//             focusRing="focus:ring-1 focus:ring-black/60"
//             hoverInputClasses="hover:bg-white hover:border-black/60"
//           />
//         </div>

//         <div className="flex items-center text-xs p-3 -mt-4">
//           <div className="flex gap-2">
//             <button className="px-4 py-1 border bg-darkblue1 text-white font-medium">All</button>
//             <button className="px-4 py-1 border border-gray-300 text-gray-500">Groups</button>
//           </div>
//           <div className="flex-1" />
//           <button className="px-3 py-1 border bg-darkblue1 text-white font-medium hover:bg-white hover:text-darkblue1 hover:border-darkblue1">+</button>
//         </div>

//         {/* User List */}
//         <div className="flex-1 overflow-y-auto">
//           {filteredUsers.map((u) => (
//             <div
//               key={u.id}
//               onClick={() => setActiveUser(u)} // select user
//               className={`flex gap-3 p-3 border-b cursor-pointer ${
//                 activeUser?.id === u.id ? "bg-blue-50 text-black" : u.active ? "text-black" : "text-gray-500"
//               }`}
//             >
//               <div className="w-8 h-8 rounded bg-gray-200 text-black flex items-center justify-center text-xs font-semibold">
//                 {u.name.split(" ").map((n) => n[0]).join("").toUpperCase()}
//               </div>
//               <div className="flex-1">
//                 <div className="flex justify-between text-sm">
//                   <span>{u.name}</span>
//                   <span className="text-xs">{u.time}</span>
//                 </div>
//                 <p className="text-xs opacity-80">{u.role}</p>
//                 <p className="text-xs opacity-60">{u.code}</p>
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>

//       {/* RIGHT CHAT WINDOW */}
//       <div className="flex-1 flex flex-col">
//         <div className="h-12 border-b flex items-center px-4 gap-2">
//           <div className="w-7 h-7 bg-gray-300 rounded flex items-center justify-center text-xs font-semibold">
//             {activeUser.name.split(" ").map((n) => n[0]).join("").toUpperCase()}
//           </div>
//           <span className="text-sm font-medium">{activeUser.name}</span>
//         </div>

//         <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
//           {messages.map((m, i) =>
//             m.date ? (
//               <div key={i} className="text-xs text-gray-400 text-center">{m.date}</div>
//             ) : (
//               <div key={i} className={`flex ${m.type === "out" ? "justify-end" : "justify-start"}`}>
//                 <div className={`max-w-md px-3 py-2 rounded text-sm ${m.type === "out" ? "bg-blue-100 text-right" : "bg-white border"}`}>
//                   <p>{m.text}</p>
//                   <span className="block text-[10px] text-gray-400 mt-1">{m.time}</span>
//                 </div>
//               </div>
//             )
//           )}
//         </div>

//         <div className="h-14 border-t flex items-center gap-3 px-4">
//           <Smile className="w-5 h-5 text-gray-500 cursor-pointer" />
//           <Paperclip className="w-5 h-5 text-gray-500 cursor-pointer" />
//           <input placeholder="Type a message" className="flex-1 border rounded px-3 py-2 text-sm" />
//           <Send className="w-5 h-5 text-gray-700 cursor-pointer" />
//         </div>
//       </div>
//     </div>
//   );
// }


import { Smile, Paperclip, Send } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import Searchinput from "../../../Components/Searchinput";

export default function Chatter() {
  const users = [
    { id: 0, name: "Jagath Jain", role: "Regional Manager", code: "VC1001", time: "10:00 AM" },
    { id: 1, name: "Priya Sharma", role: "Sales Executive", code: "VC1002", time: "10:15 AM" },
    { id: 2, name: "Rahul Verma", role: "Manager", code: "VC1003", time: "10:30 AM" },
    { id: 3, name: "Sneha Kapoor", role: "Sales Executive", code: "VC1004", time: "10:45 AM" },
    { id: 4, name: "Ankit Singh", role: "Regional Manager", code: "VC1005", time: "11:00 AM" },
    { id: 5, name: "Neha Reddy", role: "Sales Executive", code: "VC1006", time: "11:15 AM" },
    { id: 6, name: "Vikram Das", role: "Manager", code: "VC1007", time: "11:30 AM" },
    { id: 7, name: "Riya Kapoor", role: "Sales Executive", code: "VC1008", time: "11:45 AM" },
  ];

  // FILTER STATES
  const [searchTerm, setSearchTerm] = useState("");
  const [activeUser, setActiveUser] = useState(users[0]);
  const [messagesPerUser, setMessagesPerUser] = useState({
    0: [
      { text: "Hello", time: "09:00 AM", type: "in" },
      { text: "Good Morning!", time: "09:00 AM", type: "in" },
      { date: "20/11/2025" },
      { text: "Very Good Morning", time: "06:04 AM", type: "out" },
    ],
    1: [],
    2: [],
    3: [],
    4: [],
    5: [],
    6: [],
    7: [],
  });
  const [newMessage, setNewMessage] = useState("");

  const filteredUsers = users.filter(u =>
    u.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const chatEndRef = useRef(null);

  // Auto scroll to bottom on new message or user change
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messagesPerUser, activeUser]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return; // prevent empty messages
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const updatedMessages = {
      ...messagesPerUser,
      [activeUser.id]: [
        ...messagesPerUser[activeUser.id],
        { text: newMessage.trim(), time, type: "out" },
      ],
    };
    setMessagesPerUser(updatedMessages);
    setNewMessage(""); // clear input
  };

  return (
    <div className="flex h-[calc(72vh-20px)] -mt-2 bg-white">
      {/* LEFT PANEL */}
      <div className="w-90 border-r flex flex-col">
        <div className="p-3">
          <h2 className="text-sm font-semibold text-darkblue1">Dealer Users</h2>
          <div className="hidden lg:block h-1 bg-darkblue1 w-10 mt-0 mb-3"></div>

          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search"
            className="w-[240px]"
            iconColor="text-black"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            inputWidth="w-full"
            focusRing="focus:ring-1 focus:ring-black/60"
            hoverInputClasses="hover:bg-white hover:border-black/60"
          />
        </div>
  <div className="flex items-center text-xs p-3 -mt-4">
           <div className="flex gap-2">
            <button className="px-4 py-1 border bg-darkblue1 text-white font-medium">All</button>
            <button className="px-4 py-1 border border-gray-300 text-gray-500">Groups</button>
          </div>
          <div className="flex-1" />
        <button className="px-3 py-1 border bg-darkblue1 text-white font-medium hover:bg-white hover:text-darkblue1 hover:border-darkblue1">
            +
           </button>
        </div>
        {/* User List */}
        <div className="flex-1 overflow-y-auto">
          {filteredUsers.map((u) => (
            <div
              key={u.id}
              onClick={() => setActiveUser(u)}
              className={`flex gap-3 p-3 border-b cursor-pointer ${
                activeUser?.id === u.id ? "bg-blue-50 text-black" : "text-gray-500"
              }`}
            >
              <div className="w-8 h-8 rounded bg-gray-200 text-black flex items-center justify-center text-xs font-semibold">
                {u.name.split(" ").map((n) => n[0]).join("").toUpperCase()}
              </div>
              <div className="flex-1">
                <div className="flex justify-between text-sm">
                  <span>{u.name}</span>
                  <span className="text-xs">{u.time}</span>
                </div>
                <p className="text-xs opacity-80">{u.role}</p>
                <p className="text-xs opacity-60">{u.code}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* RIGHT CHAT WINDOW */}
      <div className="flex-1 flex flex-col">
        <div className="h-12 border-b flex items-center px-4 gap-2">
          <div className="w-7 h-7 bg-gray-300 rounded flex items-center justify-center text-xs font-semibold">
            {activeUser.name.split(" ").map((n) => n[0]).join("").toUpperCase()}
          </div>
          <span className="text-sm font-medium">{activeUser.name}</span>
        </div>

        <div className="flex-1 overflow-y-auto  p-6 space-y-6 bg-gray-50">
          {(messagesPerUser[activeUser.id] || []).map((m, i) =>
            m.date ? (
             <div key={i} className="flex justify-center">
  <div className="text-xs text-gray-500 text-center bg-gray-200 rounded-md py-1 px-3">
    {m.date}
  </div>
</div>


            ) : (
              <div
                key={i}
                className={`flex items-end ${
                  m.type === "out" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`relative max-w-[60%] rounded-lg px-4 py-1 text-xs break-words
                    ${
                      m.type === "out"
                        ? "bg-lightBlue/50 border border-blue text-black rounded-br-none"
                        : "bg-white text-black rounded-bl-none border border-gray-300"
                    }`}
                >
                  <p>{m.text}</p>
                  <span
                    className={`block text-[10px] mt-1 ${
                      m.type === "out" ? "text-gray-600 text-right" : "text-gray-600"
                    }`}
                  >
                    {m.time}
                  </span>
                </div>
              </div>
            )
          )}
          <div ref={chatEndRef} />
        </div>

        <div className="h-14 border-t flex items-center gap-3 px-4">
          <Smile className="w-5 h-5 text-gray-500 cursor-pointer" />
          <Paperclip className="w-5 h-5 text-gray-500 cursor-pointer" />
          <input
            placeholder="Type a message"
            className="flex-1 border rounded px-3 py-2 text-sm"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
          />
          <Send className="w-5 h-5 text-gray-700 cursor-pointer" onClick={handleSendMessage} />
        </div>
      </div>
    </div>
  );
}
