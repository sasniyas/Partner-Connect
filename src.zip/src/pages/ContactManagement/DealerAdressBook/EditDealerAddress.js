


"use client"

import { useState, useRef, useEffect } from "react"
import Header from "../../../Components/Header"
import SubNavbar3 from "../../../Components/SubNavbar3"
import { ArrowLeft, Upload } from "lucide-react"
import { useNavigate, useLocation } from "react-router-dom"
import StyledSelectField from "../../../Components/StyledSelectField"

const EditDealerAddress = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const dealerData = location.state?.dealerData || {} // existing dealer data

  const [menuOpen, setMenuOpen] = useState(false)
  const [isDealerAddressOpen, setIsDealerAddressOpen] = useState(false)
  const [isBranchAddressOpen, setIsBranchAddressOpen] = useState(false)
  const [selectedBranchAddress, setSelectedBranchAddress] = useState("")
  const [addressType, setAddressType] = useState("HQ") // "HQ" | "BRANCH"
  const [isBrandModalOpen, setIsBrandModalOpen] = useState(false)
  const [selectedDealerAddress, setSelectedDealerAddress] = useState(dealerData.dealerAddress || null)
  const [branchAddresses, setBranchAddresses] = useState(dealerData.branchAddresses || [])
  const [editingBranchIndex, setEditingBranchIndex] = useState(null)

  const [brandForm, setBrandForm] = useState({
    brandName: "",
    brandLogo: "",
    productSegment: "",
    productName: "",
    sinceWhen: "",
    yearsOfAssociation: "",
    location: "",
  })

  const [brands, setBrands] = useState(dealerData.brands || [])

  const handlePincodeChange = async (e) => {
    const pincode = e.target.value
    setHqAddress((prev) => ({ ...prev, pincode }))

    if (pincode.length === 6) {
      try {
        const res = await fetch(`https://api.postalpincode.in/pincode/${pincode}`)
        const data = await res.json()

        if (data[0]?.Status === "Success") {
          const postOffice = data[0].PostOffice[0]
          setHqAddress((prev) => ({
            ...prev,
            city: postOffice.District,
            state: postOffice.State,
          }))
        }
      } catch (error) {
        console.error("Invalid Pincode", error)
      }
    }
  }

  // Dropdown options
  const marketAreaOptions = [
    { label: "North", value: "North" },
    { label: "South", value: "South" },
    { label: "East", value: "East" },
    { label: "West", value: "West" },
  ]

  const dealerOptions = [
    { label: "Alpha Teknisk Pvt. Ltd.", value: "alpha" },
    { label: "BSES India Pvt. Ltd.", value: "bses" },
    { label: "ESDEE SOLUTECH", value: "esdee" },
    { label: "PAL Infrastructure Solutions", value: "pal" },
    { label: "Time Equipment", value: "time" },
  ]

  const dealerAddressOptions = [
    { label: "Head Quarter", value: "Head Quarter" },
    { label: "Branch Location", value: "Branch Location" },
  ]

  const [hqAddress, setHqAddress] = useState({
    city: "",
    state: "",
    pincode: "",
    address: "",
  })

  const activeOptions = [
    { label: "Yes", value: "Yes" },
    { label: "No", value: "No" },
  ]

  const [formData, setFormData] = useState({
    marketArea: dealerData.marketArea || "",
    dealer: dealerData.dealer || "",
    logo: dealerData.logo || "",
    principalName: dealerData.principalName || "",
    dealerAddress: dealerData.dealerAddress || "",
    branchLocation: dealerData.branchLocation || "",
    website: dealerData.website || "",
    association: dealerData.association || "",
    active: dealerData.active || "",
    notes: dealerData.notes || "",
    branchAddresses: dealerData.branchAddresses || [],
  })

  const [errors, setErrors] = useState({})

  // Dropdown open states
  const [dropdowns, setDropdowns] = useState({
    marketArea: false,
    dealer: false,
    dealerAddress: false,
    active: false,
  })

  // Refs for dropdowns
  const refs = {
    marketArea: useRef(),
    dealer: useRef(),
    dealerAddress: useRef(),
    active: useRef(),
  }

  // Close dropdowns on click outside
  useEffect(() => {
    const closeDropdown = (e) => {
      Object.keys(refs).forEach((key) => {
        if (refs[key]?.current && !refs[key].current.contains(e.target)) {
          setDropdowns((prev) => ({ ...prev, [key]: false }))
        }
      })
    }
    document.addEventListener("mousedown", closeDropdown)
    return () => document.removeEventListener("mousedown", closeDropdown)
  }, [])

  const handleBack = () => {
    navigate("/contactmanagemnet", { state: { activeTab: "dealerAddressBook" } })
  }

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value })
    setErrors((prev) => ({ ...prev, [field]: "" }))
  }

  const handleSave = () => {
    const newErrors = {}

    // Validate formData fields
    if (!formData.marketArea) newErrors.marketArea = "This field is required"
    if (!formData.dealer) newErrors.dealer = "This field is required"
    if (!formData.principalName) newErrors.principalName = "This field is required"
    if (!formData.website) newErrors.website = "This field is required"
    if (!formData.association) newErrors.association = "This field is required"
    if (!formData.active) newErrors.active = "This field is required"
    if (!formData.notes) newErrors.notes = "This field is required"

    // Validate HQ Address
    if (!selectedDealerAddress) newErrors.dealerAddress = "HQ Address is required"

    // Validate Branch Addresses
    if (branchAddresses.length === 0) newErrors.branchAddress = "At least one branch address is required"

    // Validate Brands
    if (brands.length === 0) newErrors.brands = "At least one brand is required"

    setErrors(newErrors)

    // If no errors, save all data
    if (Object.keys(newErrors).length === 0) {
      const updatedData = {
        ...formData,
        dealerAddress: selectedDealerAddress,
        branchAddresses: branchAddresses,
        branchCount: branchAddresses.length,
        brands: brands,
        brandsCount: brands.length,
      }

      navigate("/contactmanagemnet", {
        state: { updatedDealerData: updatedData, activeTab: "dealerAddressBook" },
      })
    }
  }

  const handleSaveAddress = () => {
    const { city, state, pincode, address } = hqAddress

    if (!city || !state || !pincode) {
      alert("City, State & Pincode required")
      return
    }

    if (addressType === "HQ") {
      setSelectedDealerAddress({ city, state, pincode, address })
    } else {
      setBranchAddresses((prev) => [...prev, { city, state, pincode, address }])
    }

    setIsDealerAddressOpen(false)
    setHqAddress({ city: "", state: "", pincode: "", address: "" })
  }

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="flex flex-col w-full mb-3">
            <div className="flex items-center gap-2">
              <ArrowLeft
                onClick={handleBack}
                size={20}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
              />
              <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">Edit Dealer Address</h2>
            </div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-7"></div>
          </div>

          {/* Form */}
          <div className="bg-white px-6 py-4 rounded shadow-md">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-12 gap-y-2">
              {/* Market Area */}
              <StyledSelectField
                label="Market Area"
                placeholder="Select Market Area"
                value={marketAreaOptions.find((opt) => opt.value === formData.marketArea)?.label || ""}
                setValue={(label) => {
                  const selected = marketAreaOptions.find((opt) => opt.label === label)
                  handleChange("marketArea", selected?.value || "")
                }}
                options={marketAreaOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.marketArea}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, marketArea: val }))}
                dropdownRef={refs.marketArea}
                error={errors.marketArea}
              />

              {/* Dealer */}
              <StyledSelectField
                label="Dealership"
                placeholder="Select Dealer"
                value={dealerOptions.find((opt) => opt.value === formData.dealer)?.label || ""}
                setValue={(label) => {
                  const selected = dealerOptions.find((opt) => opt.label === label)
                  handleChange("dealer", selected?.value || "")
                }}
                options={dealerOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.dealer}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, dealer: val }))}
                dropdownRef={refs.dealer}
                error={errors.dealer}
              />

              {/* Logo */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Logo</label>
                <label
                  htmlFor="logo-upload"
                  className={`relative cursor-pointer border border-black/30  flex items-center gap-3 px-3 py-1.5 text-gray-400 text-xs hover:bg-gray-50 ${
                    errors.logo ? "border-red1" : ""
                  }`}
                >
                  {formData.logo ? (
                    <img
                      src={formData.logo || "/placeholder.svg"}
                      alt="Logo Preview"
                      className="object-contain h-4 w-4 rounded"
                    />
                  ) : (
                    <span className="truncate">Choose a file (png, jpeg - max 5MB)</span>
                  )}
                  <Upload size={16} className="ml-auto text-gray-400" />
                  <input
                    type="file"
                    id="logo-upload"
                    accept="image/png, image/jpeg"
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    onChange={(e) => {
                      const file = e.target.files[0]
                      if (!file) return
                      const validTypes = ["image/png", "image/jpeg"]
                      if (!validTypes.includes(file.type)) {
                        alert("Only PNG or JPEG files are allowed.")
                        return
                      }
                      const maxSize = 5 * 1024 * 1024
                      if (file.size > maxSize) {
                        alert("File size must be less than 5MB.")
                        return
                      }
                      const fileURL = URL.createObjectURL(file)
                      handleChange("logo", fileURL)
                    }}
                  />
                </label>
                {errors.logo && <span className="text-red1 text-xs mt-1">{errors.logo}</span>}
              </div>

              {/* Dealer Principal Name */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Dealer Principal Name</label>
                <input
                  type="text"
                  placeholder="Enter Dealer Principal Name"
                  value={formData.principalName}
                  onChange={(e) => handleChange("principalName", e.target.value)}
                  className={`border text-xs px-4 py-1.5 ${
                    errors.principalName ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
                  }`}
                />
                {errors.principalName && <span className="text-red1 text-xs">{errors.principalName}</span>}
              </div>

              {/* Dealer HQ Address */}
              <div className="flex flex-col gap-1 mt-1">
                <label className="text-xs font-medium text-gray-600">
                  Dealer HQ Address <span className="text-red-500">*</span>
                </label>

                <button
                  type="button"
                  onClick={() => {
                    setAddressType("HQ")
                    setHqAddress(selectedDealerAddress || { city: "", state: "", pincode: "", address: "" })
                    setIsDealerAddressOpen(true)
                  }}
                  className={`border px-3 py-1.5 text-xs text-left  flex justify-between items-center
      ${selectedDealerAddress ? "bg-white text-black cursor-pointer" : "bg-darkblue1 text-white"}
      ${errors.dealerAddress ? "border-red-500" : "border-black/30"}
    `}
                >
                  <span>
                    {selectedDealerAddress
                      ? `${selectedDealerAddress.city || ""}${selectedDealerAddress.city && selectedDealerAddress.state ? ", " : ""}${selectedDealerAddress.state || ""}${(selectedDealerAddress.city || selectedDealerAddress.state) && selectedDealerAddress.pincode ? ", " : ""}${selectedDealerAddress.pincode || ""}`
                      : "Add HQ Address"}
                  </span>
                </button>

                {errors.dealerAddress && <span className="text-xs text-red-500">{errors.dealerAddress}</span>}
              </div>

              {/* Branch Address */}
              <div className="flex flex-col gap-1 mt-1">
                <label className="text-xs font-medium text-gray-600">
                  Branch Address <span className="text-red-500">*</span>
                </label>

                <button
                  type="button"
                  onClick={() => {
                    setAddressType("BRANCH")
                    setHqAddress({ city: "", state: "", pincode: "", address: "" })
                    setEditingBranchIndex(null)
                    setIsDealerAddressOpen(true)
                  }}
                  className={`border px-3 py-1.5 bg-darkblue1 text-xs text-left text-white flex justify-between items-center
    ${errors.branchAddress ? "border-red-500" : "border-black/30"}
  `}
                >
                  <span>+ Add Branch Address</span>
                </button>

                {errors.branchAddress && <span className="text-xs text-red-500">{errors.branchAddress}</span>}
              </div>

              {/* Branch Address Box */}
              {branchAddresses.length > 0 && (
                <div className="mt-2 border border-black/20 p-2 text-xs bg-white">
                  <div className="font-semibold mb-1"> Added Branch Address ({branchAddresses.length})</div>

                  {branchAddresses.map((branch, idx) => (
                    <div key={idx} className="flex justify-between items-center mb-2 p-2 bg-gray-100 ">
                      {/* City, State, Pincode */}
                      <div className="flex gap-4 text-xs">
                        <div>
                          <b></b> {branch.city}
                        </div>
                        <div>
                          <b></b> {branch.state}
                        </div>
                        <div>
                          <b></b> {branch.pincode}
                        </div>
                      </div>

                      {/* Edit / Delete Buttons */}
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            setAddressType("BRANCH")
                            setHqAddress(branch)
                            setEditingBranchIndex(idx)
                            setIsDealerAddressOpen(true)
                          }}
                        >
                          <img
                            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
                            alt="Edit"
                            className="w-4 h-4"
                          />
                        </button>
                        <button
                          onClick={() => {
                            const filtered = branchAddresses.filter((_, i) => i !== idx)
                            setBranchAddresses(filtered)
                          }}
                        >
                          <img
                            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                            alt="Delete"
                            className="w-4 h-4"
                          />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Company Website */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Company Website</label>
                <input
                  type="text"
                  placeholder="Enter Company Website"
                  value={formData.website}
                  onChange={(e) => handleChange("website", e.target.value)}
                  className={`border text-xs px-4 py-1.5 ${
                    errors.website ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
                  }`}
                />
                {errors.website && <span className="text-red1 text-xs">{errors.website}</span>}
              </div>

              {/* Association with Volvo */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Association with Volvo</label>
                <input
                  type="text"
                  placeholder="Enter Years and Months "
                  value={formData.association}
                  onChange={(e) => handleChange("association", e.target.value)}
                  className={`border text-xs px-4 py-1.5 ${
                    errors.association ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
                  }`}
                />
                {errors.association && <span className="text-red1 text-xs">{errors.association}</span>}
              </div>

              {/* Active */}
              <StyledSelectField
                label="Active"
                placeholder="Select Active"
                value={activeOptions.find((opt) => opt.value === formData.active)?.label || ""}
                setValue={(label) => {
                  const selected = activeOptions.find((opt) => opt.label === label)
                  handleChange("active", selected?.value || "")
                }}
                options={activeOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.active}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, active: val }))}
                dropdownRef={refs.active}
                error={errors.active}
              />

              <div className="flex flex-col gap-1 mt-1">
                <label className="text-xs font-medium text-gray-600">
                  Brands <span className="text-red-500">*</span>
                </label>

                <button
                  type="button"
                  onClick={() => setIsBrandModalOpen(true)}
                  className="border px-3 py-1.5 bg-darkblue1 text-xs text-left text-white"
                >
                  + Add Brand
                </button>
              </div>
              {brands.length > 0 && (
                <div className="col-span-2 mt-1 overflow-x-auto">
                  <table className="w-full border border-black/20 text-xs whitespace-nowrap">
                    <thead className="bg-[#3f5169] text-white">
                      <tr>
                        <th className="border px-3 py-2 text-left">Brand Name</th>
                        <th className="border px-3 py-2 text-left">Product Segment</th>
                        <th className="border px-3 py-2 text-left">Product Name</th>
                        <th className="border px-3 py-2 text-left">Association Year</th>
                        <th className="border px-3 py-2 text-left">Brand Location</th>
                        <th className="border px-3 py-2 text-left">Logo</th>
                      </tr>
                    </thead>

                    <tbody>
                      {brands.map((brand, index) => (
                        <tr key={index} className="bg-white">
                          <td className="border px-3 py-2">{brand.brandName}</td>
                          <td className="border px-3 py-2">{brand.productSegment}</td>
                          <td className="border px-3 py-2">{brand.productName}</td>
                          <td className="border px-3 py-2">{brand.yearsOfAssociation}</td>
                          <td className="border px-3 py-2">{brand.location}</td>

                          <td className="border px-3 py-2">
                            {brand.brandLogo ? (
                              <img
                                src={URL.createObjectURL(brand.brandLogo) || "/placeholder.svg"}
                                alt="logo"
                                className="h-5"
                              />
                            ) : (
                              "-"
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Notes */}
              <div className="flex flex-col col-span-3">
                <label className="text-xs font-medium text-black mb-3">Notes</label>
                <textarea
                  placeholder="Enter Notes"
                  value={formData.notes}
                  onChange={(e) => handleChange("notes", e.target.value)}
                  className={`border text-xs px-4 py-2 text-xs resize-none h-28 ${
                    errors.notes ? "border-red1" : "border-black/30"
                  }`}
                />
                {errors.notes && <span className="text-red1 text-xs">{errors.notes}</span>}
              </div>
            </div>

            {/* Save Button */}
            <div className="mt-4 flex justify-end">
              <button
                onClick={handleSave}
                className="bg-darkblue1 text-white px-8 py-1.5 transition text-xs hover:border hover:border-darkblue1 hover:bg-white hover:text-darkblue1"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* HQ/Branch Address Modal */}
      {isDealerAddressOpen && (
        <>
          {/* Overlay */}
          <div className="fixed inset-0 bg-black bg-opacity-40 z-40" onClick={() => setIsDealerAddressOpen(false)} />

          {/* Modal */}
          <div
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2
      bg-white w-[520px] max-w-[95%] p-6 z-50 shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-base font-semibold text-darkblue1 border-b-2 border-darkblue1 inline-block">
                {addressType === "HQ" ? "Edit HQ Location" : "Add/Edit Branch Location"}
              </h3>

              <button onClick={() => setIsDealerAddressOpen(false)}>
                <div className="w-6 h-6 rounded-full bg-red-600 flex items-center justify-center text-white font-bold">
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
                    alt="close"
                    className="w-4 h-4"
                  />
                </div>
              </button>
            </div>

            {/* Form */}
            <div className="grid grid-cols-2 gap-4">
              {/* City */}
              <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-gray-600">
                  City <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={hqAddress.city}
                  onChange={(e) => setHqAddress({ ...hqAddress, city: e.target.value })}
                  className="border border-black/30 px-3 py-1.5 text-xs"
                />
              </div>

              {/* State */}
              <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-gray-600">
                  State <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={hqAddress.state}
                  onChange={(e) => setHqAddress({ ...hqAddress, state: e.target.value })}
                  className="border border-black/30 px-3 py-1.5 text-xs"
                />
              </div>

              {/* Pincode */}
              <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-gray-600">
                  Pincode <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={hqAddress.pincode}
                  onChange={handlePincodeChange}
                  className="border border-black/30 px-3 py-1.5 text-xs"
                />
              </div>

              {/* Full Address */}
              <div className="flex flex-col gap-1">
                <label className="text-xs font-medium text-gray-600">Full Address</label>
                <input
                  type="text"
                  value={hqAddress.address}
                  onChange={(e) => setHqAddress({ ...hqAddress, address: e.target.value })}
                  className="border border-black/30 px-3 py-1.5 text-xs"
                />
              </div>
            </div>

            {/* Save Button */}
            <div className="flex justify-center mt-6">
              <button
                onClick={() => {
                  if (addressType === "HQ") {
                    setSelectedDealerAddress(hqAddress)
                  } else {
                    if (editingBranchIndex !== null) {
                      const updatedBranches = [...branchAddresses]
                      updatedBranches[editingBranchIndex] = hqAddress
                      setBranchAddresses(updatedBranches)
                      setEditingBranchIndex(null)
                    } else {
                      setBranchAddresses([...branchAddresses, hqAddress])
                    }
                  }
                  setHqAddress({ city: "", state: "", pincode: "", address: "" })
                  setIsDealerAddressOpen(false)
                }}
                className="bg-darkblue1 text-white px-8 py-1 text-xs "
              >
                Save
              </button>
            </div>
          </div>
        </>
      )}

      {/* Brand Modal */}
      {isBrandModalOpen && (
        <>
          {/* Overlay */}
          <div className="fixed inset-0 bg-black bg-opacity-40 z-40" onClick={() => setIsBrandModalOpen(false)} />

          {/* Modal */}
          <div
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2
      bg-white w-[720px] max-w-[95%] p-6 z-50 shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-base font-semibold text-darkblue1 border-b-2 border-darkblue1">Add Multibrand</h3>

              <button onClick={() => setIsBrandModalOpen(false)}>✕</button>
            </div>

            {/* Form */}
            <div className="grid grid-cols-2 gap-4 text-xs">
              <input
                placeholder="Brand Name"
                value={brandForm.brandName}
                onChange={(e) => setBrandForm({ ...brandForm, brandName: e.target.value })}
                className="border px-3 py-2"
              />

              <input
                type="file"
                className="border px-3 py-2"
                onChange={(e) =>
                  setBrandForm({
                    ...brandForm,
                    brandLogo: e.target.files[0],
                  })
                }
              />

              <input
                placeholder="Product Segment"
                value={brandForm.productSegment}
                onChange={(e) => setBrandForm({ ...brandForm, productSegment: e.target.value })}
                className="border px-3 py-2"
              />

              <input
                placeholder="Product Name"
                value={brandForm.productName}
                onChange={(e) => setBrandForm({ ...brandForm, productName: e.target.value })}
                className="border px-3 py-2"
              />

              <input
                placeholder="Since When"
                value={brandForm.sinceWhen}
                onChange={(e) => setBrandForm({ ...brandForm, sinceWhen: e.target.value })}
                className="border px-3 py-2"
              />

              <input
                placeholder="Years of Association"
                value={brandForm.yearsOfAssociation}
                onChange={(e) =>
                  setBrandForm({
                    ...brandForm,
                    yearsOfAssociation: e.target.value,
                  })
                }
                className="border px-3 py-2"
              />

              <input
                placeholder="Location"
                value={brandForm.location}
                onChange={(e) => setBrandForm({ ...brandForm, location: e.target.value })}
                className="border px-3 py-2 col-span-2"
              />
            </div>

            {/* Save */}
            <div className="flex justify-center mt-6">
              <button
                onClick={() => {
                  setBrands((prev) => [...prev, brandForm])
                  setBrandForm({
                    brandName: "",
                    brandLogo: "",
                    productSegment: "",
                    productName: "",
                    sinceWhen: "",
                    yearsOfAssociation: "",
                    location: "",
                  })
                  setIsBrandModalOpen(false)
                }}
                className="bg-darkblue1 text-white px-10 py-2 text-xs"
              >
                Save
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

export default EditDealerAddress
