import React, { useState, useRef, useEffect } from "react";
import Searchinput from "../../../Components/Searchinput";
import Filter from "../../../Components/Filter";
import { MoreVertical, CircleOff, Eye } from "lucide-react";
import DeleteModal from "../../../Components/DeleteModal";
import ActivateStatus from "../../../Components/ActivateStatus";
import DeactivateStatus from "../../../Components/DeactivateStatus";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import LocationCards from "../../../Components/LoactionCards";

const DealerAdress = () => {
  const navigate = useNavigate();
    const location = useLocation();

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMarketArea, setSelectedMarketArea] = useState("");
  const [selectedDealer, setSelectedDealer] = useState("");
  const [dealername, setDealername] = useState("");
  const [selectedActive, setSelectedActive] = useState("");
  const [loading, setLoading] = useState(false);
const [deleteItem, setDeleteItem] = useState(null);
const [selectedRow, setSelectedRow] = useState(null);
const [showDeactivateModal, setShowDeactivateModal] = useState(false);
const [showActivateModal, setShowActivateModal] = useState(false);
const [statusLoading, setStatusLoading] = useState(false);
const [isBrandModalOpen, setIsBrandModalOpen] = useState(false);
const [viewBrands, setViewBrands] = useState([]);
const [brandSearchTerm, setBrandSearchTerm] = useState("");
const [selectedBrandName, setSelectedBrandName] = useState("");
const [selectedProductSegment, setSelectedProductSegment] = useState("");
const [selectedProductCategory, setSelectedProductCategory] = useState("");
const [selectedLocation, setSelectedLocation] = useState("");

  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [dropdownId, setDropdownId] = useState(null);
  const [viewContact, setViewContact] = useState(null)

  const dropdownRefs = useRef({});
  const tableContainerRef = useRef(null);

  const addUserDropdownRef = useRef(null);
  const addUserButtonRef = useRef(null);
  const [addUserButtonWidth, setAddUserButtonWidth] = useState(150);
const filteredBrands = viewBrands.filter((brand) => {
  const brandName = brand.brandName ? brand.brandName.toLowerCase() : "";
  const productSegment = brand.productSegment ? brand.productSegment.toLowerCase() : "";
  const productCategory = brand.productCategory ? brand.productCategory.toLowerCase() : "";
  const location = brand.location ? brand.location.toLowerCase() : "";
  const searchTermLower = brandSearchTerm ? brandSearchTerm.toLowerCase() : "";

  const selectedBrandNameLower = typeof selectedBrandName === "string" ? selectedBrandName.toLowerCase() : "";
  const selectedProductSegmentLower = typeof selectedProductSegment === "string" ? selectedProductSegment.toLowerCase() : "";
  const selectedProductCategoryLower = typeof selectedProductCategory === "string" ? selectedProductCategory.toLowerCase() : "";
  const selectedLocationLower = typeof selectedLocation === "string" ? selectedLocation.toLowerCase() : "";

  const matchesSearch =
    brandName.includes(searchTermLower) ||
    productSegment.includes(searchTermLower) ||
    productCategory.includes(searchTermLower) ||
    location.includes(searchTermLower);

  const matchesBrandName =
    selectedBrandNameLower === "" || brandName === selectedBrandNameLower;

  const matchesProductSegment =
    selectedProductSegmentLower === "" || productSegment === selectedProductSegmentLower;

  const matchesProductCategory =
    selectedProductCategoryLower === "" || productCategory === selectedProductCategoryLower;

  const matchesLocation =
    selectedLocationLower === "" || location === selectedLocationLower;

  return matchesSearch && matchesBrandName && matchesProductSegment && matchesProductCategory && matchesLocation;
});


  // Options
  const marketAreaOptions = ["North", "South", "East", "West", "Central"];
  const dealerOptions = [
    "NAVIN",
    "DRS",
    "PAL",
  ];
  const activeOptions = ["Yes", "No"];

  // Data
  const [tableData, setTableData] = useState([
    {
      id:1,
      marketArea: "North",
      dealer: "NAVIN",
      logo: "https://via.placeholder.com/40",
      principleName: "Rajesh Kumar",
      website: "https://alpha.com",
      association: "10 Years",
      active: "Yes",
    },
    {id:2,
      marketArea: "South",
      dealer: "DRS",
      logo: "https://via.placeholder.com/40",
      principleName: "Vignesh",
      website: "https://esdee.com",
      association: "6 Years",
      active: "No",
    },
    {
      id:3,
      marketArea: "East",
      dealer: "PAL",
      logo: "https://via.placeholder.com/40",
      principleName: "Ankit Sharma",
      website: "https://bses.com",
      association: "4 Years",
      active: "Yes",
    },
  ]);

const isAdded = useRef(false);

useEffect(() => {
  const userData = location.state?.newUser || location.state?.updatedDealer;
  if (userData && !isAdded.current) {
    isAdded.current = true; // prevent duplicate inserts

    setTableData((prev) => {
      const rowData = {
        id: userData.id || prev.length + 1, // auto-increment ID if new
        marketArea: userData.marketArea,
        dealer: userData.dealer,
        logo: userData.logo || "https://via.placeholder.com/40",
        principleName: userData.principalName,
        dealerAddress: userData.dealerAddress,
        branchLocation: userData.branchLocation || "",
        website: userData.website,
        association: userData.association,
        active: userData.active,
        notes: userData.notes,
        brands: userData.brands || [],               // store full brands array
        brandsCount: userData.brands?.length || 0,  // store total brands
        branchAddress:userData.branchAddress,
       
      };

      if (location.state?.updatedDealer) {
        // EDIT: update existing row
        return prev.map((row) =>
          row.id === userData.id ? { ...row, ...rowData } : row
        );
      } else {
        // ADD: prepend new row
        return [rowData, ...prev];
      }
    });
  }
}, [location.state]);

  // Filtering
const filteredData = tableData.filter((row) => {
  const search = searchTerm.trim().toLowerCase();

  // ---------- SEARCH ----------
  const matchesSearch =
    search === "" ||
    [
      row.marketArea,
      row.dealer,
      row.principleName,
      row.association,
      row.active,
      row.website,
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase()
      .includes(search);

  // ---------- FILTERS (ARRAY SAFE) ----------
  const matchesMarketArea =
    !selectedMarketArea?.length ||
    selectedMarketArea.includes(row.marketArea);

  const matchesDealer =
    !selectedDealer?.length ||
    selectedDealer.includes(row.dealer);

  const matchesActive =
    !selectedActive?.length ||
    selectedActive.includes(row.active);

  return (
    matchesSearch &&
    matchesMarketArea &&
    matchesDealer &&
    matchesActive
  );
});


  // Button width
  useEffect(() => {
    if (addUserButtonRef.current) {
      setAddUserButtonWidth(addUserButtonRef.current.offsetWidth);
    }
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        addUserDropdownRef.current &&
        !addUserDropdownRef.current.contains(event.target) &&
        !addUserButtonRef.current.contains(event.target)
      ) {
        setIsAddUserOpen(false);
      }

      // close action dropdowns
      Object.keys(dropdownRefs.current).forEach((id) => {
        if (
          dropdownRefs.current[id] &&
          !dropdownRefs.current[id].contains(event.target)
        ) {
          setDropdownId(null);
        }
      });
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () =>
      document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Handlers
  const handleAddUser = () => navigate("/dealeradressbook/Adddealeradress")
  const handleBulkUpload = () => {};
  const handleDownloadTemplate = () => {};
const handleView = (item) => {
    setViewContact(item)
    setDropdownId(null) // <-- closes the dropdown
    // setShowViewPopup(true); // if you use a popup state
  }
  const handleEdit = (item) => {
  navigate("/dealeradressbook/Editdealeradress", {
    state: { dealerData: item }, // pass the row data
  });
};  const handleDeactivate = (item) => {};
const handleDeleteClick = (item) => {
  setDeleteItem(item); // store the actual item for deletion
};
  const handleClose = () => setViewContact(null)

const handleConfirmDelete = () => {
  setLoading(true);

  setTimeout(() => {
    setTableData((prev) =>
      prev.filter((row) => row.id !== deleteItem.id)
    );
    setDeleteItem(null);
    setLoading(false);
  }, 500);
};
const handleConfirmDeactivate = () => {
  setTableData((prev) =>
    prev.map((item) =>
      item.marketArea === selectedRow.marketArea &&
      item.dealer === selectedRow.dealer
        ? { ...item, active: "No" }
        : item
    )
  );

  setShowDeactivateModal(false);
  setSelectedRow(null);
};

const handleConfirmActivate = () => {
  setTableData((prev) =>
    prev.map((item) =>
      item.marketArea === selectedRow.marketArea &&
      item.dealer === selectedRow.dealer
        ? { ...item, active: "Yes" }
        : item
    )
  );

  setShowActivateModal(false);
  setSelectedRow(null);
};
const handlePreviewAndDownload = () => {
  const data = filteredData; // send filtered table data

  const newWindow = window.open(
    "/dealeradressbook/download",
    "_blank"
  );

  const handleReady = (event) => {
    if (
      event.source === newWindow &&
      event.data?.type === "READY_FOR_DATA"
    ) {
      newWindow.postMessage(
        { type: "INIT_DATA", payload: data },
        "*"
      );
      window.removeEventListener("message", handleReady);
    }
  };

  window.addEventListener("message", handleReady);
};
const handleDownload = () => {
  // For now, just console log the filtered brands
  console.log("Download filtered brands:", filteredBrands);
  // You can add real CSV/Excel export logic here later
};

  return (
    <div>
      {/* ---------------- FILTERS + BUTTONS ---------------- */}
      <div className="flex justify-between items-center mt-4">
        <div className="flex gap-2">
          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search"
            className="w-[1/2]"
            iconColor="text-black"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            inputWidth="w-full"
            focusRing="focus:ring-1 focus:ring-black/60"
            hoverInputClasses="hover:bg-white hover:border-black/60"
          />

          <Filter
            name="Market Area"
            value={selectedMarketArea}
            options={marketAreaOptions}
            onChange={(name, value) => setSelectedMarketArea(value)}
            placeholder=" Market Area"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />

          <Filter
            name="Dealer"
            value={selectedDealer}
            options={dealerOptions}
            onChange={(name, value) => setSelectedDealer(value)}
            placeholder="Dealership"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />

          <Filter
            name="Active"
            value={selectedActive}
            options={activeOptions}
            onChange={(name, value) => setSelectedActive(value)}
            placeholder="Active"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[100px]"
          />
        </div>

        {/* ADD + DOWNLOAD */}
        <div className="flex gap-2">
          <div className="relative w-fit">
            <button
              ref={addUserButtonRef}
              onClick={() => setIsAddUserOpen(!isAddUserOpen)}
              className="py-2 px-3 w-[150px] text-xs font-medium bg-darkblue1 text-white flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <img
                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/add user.png"
                  className="w-4 h-4"
                  alt="add"
                />
                Add User
              </span>
            </button>

            {isAddUserOpen && (
              <div
                ref={addUserDropdownRef}
                className="absolute top-full left-0 mt-1 bg-white border border-darkblue1 shadow-lg z-[9999]"
                style={{ width: addUserButtonWidth }}
              >
                <button
                  onClick={handleAddUser}
                  className="w-full px-3 py-1 text-xs hover:bg-lightBlue/50 flex gap-2"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/addnew.png"
                    alt="add"
                    className="w-4 h-3"
                  />
                  Add User
                </button>

                <button
                  onClick={() => {
                    handleBulkUpload();
                    setIsAddUserOpen(false);
                  }}
                  className="w-full px-3 py-1 text-xs hover:bg-lightBlue/50 flex gap-2"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/bulkupload.png"
                    alt="add"
                    className="w-3 h-3"
                  />
                  Bulk Upload
                </button>

                <button
                  onClick={() => {
                    handleDownloadTemplate();
                    setIsAddUserOpen(false);
                  }}
                  className="w-full px-3 py-1 text-xs hover:bg-lightBlue/50 flex gap-2"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/download.png"
                    alt="download"
                    className="w-3 h-3"
                  />
                  Template
                </button>
              </div>
            )}
          </div>

          <button
            onClick={handlePreviewAndDownload}

           className="py-2 px-6 text-xs border border-black/30 hover:bg-lightBlue/50 flex items-center gap-2">
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Scorecard/template.png"
              alt="bulk"
              className="w-4 h-4"
            />
            Download
          </button>
        </div>
      </div>

      {/* ---------------- TABLE ---------------- */}
      <div className="bg-white shadow-md border border-Dustyblue mt-3">
        <div
                ref={tableContainerRef}
                className="overflow-y-auto overflow-x-auto max-h-full"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
              >
          <table className="text-sm w-full">
            <thead className="bg-Dustyblue text-white text-left text-xs sticky top-0 z-10">
              <tr>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                  Market Area
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                  Dealership
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                  Logo
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                  Dealer Principle Name
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                  Dealer Address
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                  Company Website
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                  Association With Volvo
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                  Active
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                  Non-Volvo Brands
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody>
              {filteredData.length === 0 ? (
                <tr>
                  <td
                    colSpan="8"
                    className="text-center text-sm py-3 text-gray-500"
                  >
                    No matching records found
                  </td>
                </tr>
              ) : (
                filteredData.map((row, index) => {
const rowId = `${row.marketArea}-${row.dealer}`;
                        const isActive = row.active === "Yes";

                  return (
  <tr
          key={rowId}
          className={`hover:bg-lightBlue/50 cursor-pointer text-black text-xs ${
            isActive ? "text-black":"text-gray-400"
          }`}
        >                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        {row.marketArea}
                      </td>

                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        {row.dealer}
                      </td>

                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        <img
                          src={row.logo}
                          alt="logo"
                          className="w-5 h-5"
                        />
                      </td>

                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        {row.principleName}
                      </td>
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
  {row.dealerAddress
    ? `${row.dealerAddress.city || ''}${row.dealerAddress.city && row.dealerAddress.state ? ', ' : ''}${row.dealerAddress.state || ''}${(row.dealerAddress.city || row.dealerAddress.state) && row.dealerAddress.pincode ? ', ' : ''}${row.dealerAddress.pincode || ''}`
    : "-"}
</td>

                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        <a
                          href={row.website || "#"}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 underline"
                        >
                          {row.website || "N/A"}
                        </a>
                      </td>

                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        {row.association}
                      </td>

                      <td
  className={`px-4 py-1 border border-grey2 border-t-0 border-l-0 ${
    row.active === "Yes" ? "text-saturatedgreen" : "text-red1"
  }`}
>
  {row.active}
</td>
{/* <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 flex items-center gap-2">
  <div className="flex items-center gap-2 rounded px-2 py-1">
    <span className="text-xs font-medium">{row.brandsCount} </span>
    {row.brandsCount > 0 && (
      <button
        onClick={() => {
          setViewBrands(row.brands || []);
          setIsBrandModalOpen(true);
        }}
        className="text-xs text-blue-600 underline"
      >
        View
      </button>
    )}
  </div>
</td> */}

 <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                           <span className="text-xs font-medium">{row.brandsCount} </span>
                           <button
        onClick={() => {
          setViewBrands(row.brands || []);
          setIsBrandModalOpen(true);
          setDealername(row.dealer);
        }}
        className="text-xs text-blue-600 border py-1 px-1"
      >
                                         <Eye size={16} />
      </button>

                      </td>

                      {/* ACTIONS */}
                      <td className="py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0 text-xs">
                        <div className="relative flex items-center justify-center">
                          <button
                            onClick={() =>
                              setDropdownId(
                                dropdownId === rowId ? null : rowId
                              )
                            }
                            className="w-6 h-6 flex items-center justify-center border border-gray-300 hover:bg-gray-100"
                          >
                            <MoreVertical size={16} className="text-black" />
                          </button>

                          {dropdownId === rowId && (
                            <div
                              ref={(el) => (dropdownRefs.current[rowId] = el)}
                              className="absolute right-0 mt-10 bg-white w-40 border border-gray-200 shadow-lg z-50"
                            >
                              <div className="py-1 flex flex-col">
                                <button
                                  onClick={() => handleView(row)}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <Eye size={16} /> View
                                </button>

                                <button
                                  onClick={() => {
                                    handleEdit(row);
                                    setDropdownId(null);
                                  }}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <img
                                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
                                    alt="Edit"
                                    className="w-4 h-4"
                                  />
                                  Edit
                                </button>

                                <button
  onClick={() => {
    setSelectedRow(row); // store actual row

    if (row.active === "Yes") {
      setShowDeactivateModal(true);
    } else {
      setShowActivateModal(true);
    }

    setDropdownId(null); // close dropdown
  }}
  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
>
  <img
    src={
      row.active === "Yes"
        ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/deactive.png"
        : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/active.png"
    }
    alt="Toggle Status"
    className="w-4 h-4"
  />
  <span>{row.active === "Yes" ? "Deactivate" : "Activate"}</span>
</button>


                                 <button
                                 onClick={() => handleDeleteClick(row)} // row here is the actual item
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                   <img
                                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                                alt="Delete"
                                className="w-4 h-4"
                              />
                                   Delete
                                </button>
  
                              </div>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
     {viewContact && (
  <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
    <div className="bg-white w-[70%] p-8 shadow-lg relative max-h-[80vh] overflow-y-auto rounded-md">

      {/* Header */}
      <div className="relative mb-6 flex justify-center">
        <h2 className="font-semibold text-sm text-darkblue1">View details</h2>
        <button
          onClick={handleClose}
          className="absolute top-0 right-0 text-red-600 hover:text-red-800"
        >
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
            alt="close"
            className="w-5 h-5"
          />
        </button>
      </div>

      {/* Dealer Info Grid */}
      <div className="grid grid-cols-2 gap-4 text-xs mb-4">
        <div className="bg-gray-100 p-2">
          <strong>Dealer:</strong> {viewContact.dealer || "N/A"}
        </div>
        <div className="bg-gray-100 p-2">
          <strong>Dealer Principle Name:</strong> {viewContact.principleName || "N/A"}
        </div>
        <div className="bg-gray-100 p-2">
          <strong>Company Website:</strong>{" "}
          {viewContact.website ? (
            <a href={viewContact.website} target="_blank" rel="noreferrer" className="text-blue-600 underline">
              {viewContact.website}
            </a>
          ) : (
            "N/A"
          )}
        </div>
        <div className="bg-gray-100 p-2">
          <strong>Market Area:</strong> {viewContact.marketArea || "N/A"}
        </div>
        <div className="bg-gray-100 p-2">
          <strong>Association With Volvo:</strong> {viewContact.association || "N/A"}
        </div>
        <div className="bg-gray-100 p-2">
          <strong>Active:</strong> {viewContact.active || "No"}
        </div>
      </div>

      {/* Dealer HQ */}
      <div className="mb-2 text-center text-xs font-semibold">
        Dealer HQ:{" "}
        <span className="font-normal">
          {viewContact.dealerHQ || "Golden Palm, 4rth main Road, 3rd block, sector-62, Noida, UP, 201309 New Delhi"}
        </span>
      </div>

      {/* LocationCards (Sample Locations) */}
      <div className="mb-6">
        <h3 className="text-center text-darkblue1 text-sm ">Our All Branches</h3>
        <LocationCards /> {/* Your existing LocationCards component */}
      </div>

      {/* Branch Cards (Real branches) */}
     

      {/* Brand Cards */}
      <div className="mb-2">
        <h3 className="text-left text-darkblue1 text-sm mb-3">Non-Volvo brands: Total Brands (3)</h3>
        {viewContact.brands && viewContact.brands.length > 0 ? (
          <div className="grid grid-cols-3 gap-4 text-xs">
            {viewContact.brands.map((brand, i) => (
              <div key={i} className="border rounded p-3 bg-black/10 shadow-sm">
                <div className="flex items-center gap-2 mb-2 font-semibold text-sm">
                  <img
                    src={brand.logo || "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/marketareaatble/sandvik.png"}
                    alt={brand.name || "Brand"}
                    className="w-5 h-5"
                  />
                  {brand.name || "Brand Name"}
                </div>
                <div><strong>Brand Name:</strong> {brand.brandName || "N/A"}</div>
                <div><strong>Product Segment:</strong> {brand.productSegment || "N/A"}</div>
                <div><strong>Product Category:</strong> {brand.productCategory || "N/A"}</div>
                <div><strong>Location:</strong> {brand.location || "N/A"}</div>
                <div><strong>Association Date:</strong> {brand.associationDate || "N/A"}</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center text-gray-500 text-xs"></div>
        )}
      </div>

    </div>
  </div>
)}


      {deleteItem && (
  <DeleteModal
    isOpen={true}
    onClose={() => setDeleteItem(null)} // only No button closes
    onConfirm={handleConfirmDelete}
    loading={loading}
    extraMessage="This row will be permanently deleted."
  />
)}


 <ActivateStatus
  isOpen={showActivateModal}
  onClose={() => setShowActivateModal(false)}
  onConfirm={handleConfirmActivate}
  loading={statusLoading}
/>

<DeactivateStatus
  isOpen={showDeactivateModal}
  onClose={() => setShowDeactivateModal(false)}
  onConfirm={handleConfirmDeactivate}
  loading={statusLoading}
/>
{isBrandModalOpen && (
  <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-6">
    <div className="bg-white w-[90%] max-w-[1000px] p-6 rounded-md shadow-lg max-h-[80vh] overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-sm font-semibold text-darkblue1 underline">
          {dealername}
        </h2>
        <button
          onClick={() => setIsBrandModalOpen(false)}
          className="text-red-600 hover:text-red-800"
        >
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
            alt="Close"
            className="w-5 h-5"
          />
        </button>
      </div>

      {/* Brand count */}
      <p className="text-xs font-semibold mb-3">
        Added Non-VOLVO Brands: ({viewBrands.length})
      </p>

      {/* Filters & Search + Download */}
      <div className="flex flex-wrap gap-3 items-center mb-4">
        {/* Search Input */}
        <Searchinput
          value={brandSearchTerm}
          onChange={(e) => setBrandSearchTerm(e.target.value)}
          placeholder="Search"
          className="w-[1/2]"
          iconColor="text-black"
          bgColor="bg-FrostWhite"
          borderColor="border-black/60"
          textColor="text-black"
          shadow="shadow-none"
          inputPadding="pl-6 pr-3 py-1.5"
          iconSize="w-3 h-3"
          iconLeft="left-3"
          inputWidth="w-full"
          focusRing="focus:ring-1 focus:ring-black/60"
          hoverInputClasses="hover:bg-white hover:border-black/60"
        />

        {/* Brand Name Filter */}
        <Filter
          name="Brand name"
          value={selectedBrandName}
          options={[...new Set(viewBrands.map(b => b.brandName))].filter(Boolean)}
          onChange={(name, value) => setSelectedBrandName(value)}
          placeholder="Brand name"
          customWidth="w-[150px]"
           placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
          // rest of your styling props
        />

        {/* Product Segment Filter */}
        <Filter
          name="Product Segment"
          value={selectedProductSegment}
          options={[...new Set(viewBrands.map(b => b.productSegment))].filter(Boolean)}
          onChange={(name, value) => setSelectedProductSegment(value)}
          placeholder="Product Segment"
 placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"        />

        {/* Product Category Filter */}
        <Filter
          name="Product Category"
          value={selectedProductCategory}
          options={[...new Set(viewBrands.map(b => b.productCategory))].filter(Boolean)}
          onChange={(name, value) => setSelectedProductCategory(value)}
          placeholder="Product Category"
 placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"        />

        {/* Location Filter */}
        <Filter
          name="Location"
          value={selectedLocation}
          options={[...new Set(viewBrands.map(b => b.location))].filter(Boolean)}
          onChange={(name, value) => setSelectedLocation(value)}
          placeholder="Location"
 placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[100px]"        />

        {/* Download Button */}
        {/* <button
          onClick={handleDownload} // implement this to download filtered data
          className="ml-auto bg-blue-700 hover:bg-blue-800 text-white text-sm px-3 py-1 rounded"
          title="Download"
        >
          Download
        </button> */}
         <button
          onClick={handleDownload} // implement this to download filtered data

           className="py-2 px-6 text-xs border border-black/30 hover:bg-lightBlue/50 flex items-center gap-2">
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Scorecard/template.png"
              alt="bulk"
              className="w-4 h-4"
            />
            Download
          </button>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-xs border border-black/20 whitespace-nowrap">
          <thead className="bg-[#3f5169] text-white text-left">
            <tr>
              <th className="border px-3 py-2">Logo</th>
              <th className="border px-3 py-2">Brand Name</th>
              <th className="border px-3 py-2">Product Segment</th>
              <th className="border px-3 py-2">Product Category</th>
              <th className="border px-3 py-2">Years of Association</th>
              <th className="border px-3 py-2">Location</th>
            </tr>
          </thead>
          <tbody>
            {filteredBrands.length > 0 ? (
              filteredBrands.map((brand, idx) => (
                <tr key={idx} className="bg-white">
                  <td className="border px-3 py-2">
                    {brand.brandLogo ? (
                      <img
                        src={URL.createObjectURL(brand.brandLogo)}
                        alt="logo"
                        className="h-6"
                      />
                    ) : (
                      "-"
                    )}
                  </td>
                  <td className="border px-3 py-2">{brand.brandName}</td>
                  <td className="border px-3 py-2">{brand.productSegment}</td>
                  <td className="border px-3 py-2">{brand.productName}</td>
                  <td className="border px-3 py-2">{brand.yearsOfAssociation}</td>
                  <td className="border px-3 py-2">{brand.location}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" className="text-center text-gray-500 italic py-4">
                  No matching brands found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  </div>
)}

    </div>
  );
};

export default DealerAdress;
const InfoCard = ({ label, value, link }) => (
  <div className="bg-gray-100 border border-gray-300 p-2 rounded text-xs">
    <strong>{label}:</strong>
    {link ? (
      <div className="mt-1">
        <a href={link} target="_blank" rel="noreferrer" className="text-blue-600 underline">
          {value}
        </a>
      </div>
    ) : (
      <div className="mt-1">{value || "N/A"}</div>
    )}
  </div>
);
const BranchCard = ({ city, mapLink, address }) => (
  <div className="border bg-white rounded-md p-3 text-center text-xs shadow-sm flex flex-col items-center">
    <strong className="mb-1">{city || "Unknown City"}</strong>
    {mapLink ? (
      <a
        href={mapLink}
        target="_blank"
        rel="noreferrer"
        className="flex items-center gap-1 mb-2 text-blue-600 underline"
      >
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/location.png"
          alt="location icon"
          className="w-4 h-4"
        />
        View Location
      </a>
    ) : (
      <div className="mb-2 text-gray-400">No location link</div>
    )}
    <p className="text-gray-700 leading-tight">{address || "No address provided"}</p>
  </div>
);
