import React, { useState, useRef, useEffect } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, Upload } from "lucide-react";
import { useNavigate } from "react-router-dom";
import StyledSelectField from "../../../Components/StyledSelectField";
import StyledDateField from "../../../Components/StyledDatefield";

const AddDealerAddress = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [isDealerAddressOpen, setIsDealerAddressOpen] = useState(false);
// const [selectedDealerAddress, setSelectedDealerAddress] = useState("");
const [isBranchAddressOpen, setIsBranchAddressOpen] = useState(false);
const [selectedBranchAddress, setSelectedBranchAddress] = useState("");
const [addressType, setAddressType] = useState("HQ"); // "HQ" | "BRANCH"
// const [branchAddresses, setBranchAddresses] = useState([]);
const [isBrandModalOpen, setIsBrandModalOpen] = useState(false);
const [selectedDealerAddress, setSelectedDealerAddress] = useState(null); // single HQ address
const [branchAddresses, setBranchAddresses] = useState([]); // array of branch addresses
const [addressErrors, setAddressErrors] = useState({});

const [editingBranchIndex, setEditingBranchIndex] = useState(null); // for branch edit mode

const [brandForm, setBrandForm] = useState({
  brandName: "",
  brandLogo: "",
  productSegment: "",
  productName: "",
  sinceWhen: "",
  yearsOfAssociation: "",
  location: "",
});
const brandDropdownRefs = {
  productSegment: useRef(null),
  productCategory: useRef(null),
};
const [brandDropdownOpen, setBrandDropdownOpen] = useState({
  productSegment: false,
  productCategory: false,
});
useEffect(() => {
  const closeDropdown = (e) => {
    // existing handler for other dropdowns
    Object.keys(refs).forEach((key) => {
      if (refs[key]?.current && !refs[key].current.contains(e.target)) {
        setDropdowns((prev) => ({ ...prev, [key]: false }));
      }
    });

    // brand modal dropdowns
    Object.keys(brandDropdownRefs).forEach((key) => {
      if (
        brandDropdownRefs[key]?.current &&
        !brandDropdownRefs[key].current.contains(e.target)
      ) {
        setBrandDropdownOpen((prev) => ({ ...prev, [key]: false }));
      }
    });
  };

  document.addEventListener("mousedown", closeDropdown);
  return () => document.removeEventListener("mousedown", closeDropdown);
}, []);

const [brands, setBrands] = useState([]);


const [brandErrors, setBrandErrors] = useState({});

const handlePincodeChange = async (e) => {
  const pincode = e.target.value;

  setHqAddress((prev) => ({ ...prev, pincode }));

  // Only trigger API for valid 6-digit pincode
  if (pincode.length === 6) {
    try {
      const res = await fetch(
        `https://api.postalpincode.in/pincode/${pincode}`
      );
      const data = await res.json();

      if (data[0]?.Status === "Success") {
        const postOffice = data[0].PostOffice[0];

        setHqAddress((prev) => ({
          ...prev,
          city: postOffice.District,
          state: postOffice.State,
        }));
      }
    } catch (error) {
      console.error("Invalid Pincode", error);
    }
  }
};

  // Dropdown options
  const marketAreaOptions = [
    { label: "North", value: "North" },
    { label: "South", value: "South" },
    { label: "East", value: "East" },
    { label: "West", value: "West" },
  ];

  const dealerOptions = [
    { label: "Alpha Teknisk Pvt. Ltd.", value: "alpha" },
    { label: "BSES India Pvt. Ltd.", value: "bses" },
    { label: "ESDEE SOLUTECH", value: "esdee" },
    { label: "PAL Infrastructure Solutions", value: "pal" },
    { label: "Time Equipment", value: "time" },
  ];

  const dealerAddressOptions = [
    { label: "Head Quarter", value: "Head Quarter" },
    { label: "Branch Location", value: "Branch Location" },
  ];
const [hqAddress, setHqAddress] = useState({
  city: "",
  state: "",
  pincode: "",
  address: "",
});
  const activeOptions = [
    { label: "Yes", value: "Yes" },
    { label: "No", value: "No" },
  ];

  // Form state
  const [formData, setFormData] = useState({
    marketArea: "",
    dealer: "",
    logo: "",
    principalName: "",
    dealerAddress: "",
    branchLocation: "",
    website: "",
    association: "",
    active: "",
    notes: "",
  });

  const [errors, setErrors] = useState({});

  // Dropdown open states
  const [dropdowns, setDropdowns] = useState({
    marketArea: false,
    dealer: false,
    dealerAddress: false,
    active: false,
  });

  // Refs for dropdowns
  const refs = {
    marketArea: useRef(),
    dealer: useRef(),
    dealerAddress: useRef(),
    active: useRef(),
  };

  // Close dropdowns on click outside
  useEffect(() => {
    const closeDropdown = (e) => {
      Object.keys(refs).forEach((key) => {
        if (refs[key]?.current && !refs[key].current.contains(e.target)) {
          setDropdowns((prev) => ({ ...prev, [key]: false }));
        }
      });
    };
    document.addEventListener("mousedown", closeDropdown);
    return () => document.removeEventListener("mousedown", closeDropdown);
  }, []);

  const handleBack = () => {
    navigate("/contactmanagemnet", { state: { activeTab: "dealerAddressBook" } });
  };

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
    setErrors((prev) => ({ ...prev, [field]: "" })); // clear error
  };

const handleSave = () => {
  let newErrors = {};

  // Validate formData fields
  if (!formData.marketArea) newErrors.marketArea = "This field is required";
  if (!formData.dealer) newErrors.dealer = "This field is required";
  if (!formData.principalName) newErrors.principalName = "This field is required";
  if (!formData.website) newErrors.website = "This field is required";
  if (!formData.association) newErrors.association = "This field is required";
  if (!formData.active) newErrors.active = "This field is required";
  if (!formData.notes) newErrors.notes = "This field is required";
    if (!formData.sinceWhen) newErrors.sinceWhen = "This field is required";
if (!formData.logo) newErrors.logo = "This field is required";

  // Validate HQ Address
  if (!selectedDealerAddress) newErrors.dealerAddress = "This field is required";

  // Validate Branch Addresses
  if (branchAddresses.length === 0) newErrors.branchAddress = "At least one branch address is required";

  // Validate Brands
  if (brands.length === 0) newErrors.brands = "At least one brand is required";

  setErrors(newErrors);

  // If no errors, save all data
  if (Object.keys(newErrors).length === 0) {
    const dataToSave = {
      ...formData,
      dealerAddress: selectedDealerAddress,
      branchAddresses: branchAddresses,
            branchCount: branchAddresses.length, // <-- add total branch count
      brands: brands,
      brandsCount: brands.length,
    };

    navigate("/contactmanagemnet", {
      state: { newUser: dataToSave, activeTab: "dealerAddressBook" },
    });
  }
};

const handleSaveAddress = () => {
  const { city, state, pincode, address } = hqAddress;

  if (!city || !state || !pincode) {
    alert("City, State & Pincode required");
    return;
  }

  if (addressType === "HQ") {
    setSelectedDealerAddress({ city, state, pincode, address });
  } else {
    setBranchAddresses((prev) => [
      ...prev,
      { city, state, pincode, address },
    ]);
  }

  setIsDealerAddressOpen(false);
  setHqAddress({ city: "", state: "", pincode: "", address: "" });
};

const closeDealerAddressModal = () => {
  setIsDealerAddressOpen(false);
  setHqAddress({ city: "", state: "", pincode: "", address: "" });
  setAddressErrors({});
  setEditingBranchIndex(null);
};

const validateAddress = () => {
  const errors = {};

  if (!hqAddress.city.trim()) errors.city = "This field is required";
  if (!hqAddress.state.trim()) errors.state = "This field is required";
  if (!hqAddress.pincode.trim()) errors.pincode = "This field is required";
  if (!hqAddress.address.trim()) errors.address = "This field is required";

  setAddressErrors(errors);

  return Object.keys(errors).length === 0;
};
const validateBrandForm = () => {
  const errors = {};

  if (!brandForm.brandName.trim()) errors.brandName = "This field is required";
  if (!brandForm.brandLogo) errors.brandLogo = "This field is required";
  if (!brandForm.productSegment.trim()) errors.productSegment = "This field is required";
  if (!brandForm.productName.trim()) errors.productName = "This field is required";
  if (!brandForm.sinceWhen.trim()) errors.sinceWhen = "This field is required";
  if (!brandForm.yearsOfAssociation.trim())
    errors.yearsOfAssociation = "This field is required";
  if (!brandForm.location.trim()) errors.location = "This field is required";

  setBrandErrors(errors);
  return Object.keys(errors).length === 0;
};
const closeBrandModal = () => {
  setIsBrandModalOpen(false);
  setBrandForm({
    brandName: "",
    brandLogo: null,
    productSegment: "",
    productName: "",
    sinceWhen: "",
    yearsOfAssociation: "",
    location: "",
  });
  setBrandErrors({});
};
// Example Product Category Options
const productCategoryOptions = [
  { label: "Consumer Electronics", value: "consumer_electronics" },
  { label: "Kitchen Appliances", value: "kitchen_appliances" },
  { label: "Men’s Clothing", value: "mens_clothing" },
  { label: "Women’s Clothing", value: "womens_clothing" },
  { label: "Outdoor Gear", value: "outdoor_gear" },
  { label: "Personal Care", value: "personal_care" },
  { label: "Fitness Equipment", value: "fitness_equipment" },
  { label: "Automotive Parts", value: "automotive_parts" },
  { label: "Office Furniture", value: "office_furniture" },
  { label: "Baby & Kids", value: "baby_kids" },
];
// Example Product Segment Options
const productSegmentOptions = [
  { label: "Electronics", value: "electronics" },
  { label: "Home Appliances", value: "home_appliances" },
  { label: "Fashion & Apparel", value: "fashion_apparel" },
  { label: "Automotive", value: "automotive" },
  { label: "Health & Beauty", value: "health_beauty" },
  { label: "Sports & Fitness", value: "sports_fitness" },
  { label: "Food & Beverages", value: "food_beverages" },
  { label: "Industrial", value: "industrial" },
  { label: "Furniture", value: "furniture" },
  { label: "Toys & Games", value: "toys_games" },
];

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="flex flex-col w-full mb-3">
            <div className="flex items-center gap-2">
              <ArrowLeft
                onClick={handleBack}
                size={20}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
              />
              <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                Add New Contact
              </h2>
            </div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-7"></div>
          </div>

          {/* Form */}
          <div className="bg-white px-6 py-4 rounded shadow-md">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-12 gap-y-2">
              
              {/* Market Area */}
              <StyledSelectField
                label="Market Area"
                placeholder="Select Market Area"
                value={
                  marketAreaOptions.find((opt) => opt.value === formData.marketArea)?.label || ""
                }
                setValue={(label) => {
                  const selected = marketAreaOptions.find((opt) => opt.label === label);
                  handleChange("marketArea", selected?.value || "");
                }}
                options={marketAreaOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.marketArea}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, marketArea: val }))}
                dropdownRef={refs.marketArea}
                error={errors.marketArea}
              />

              {/* Dealer */}
              <StyledSelectField
                label="Dealership"
                placeholder="Select Dealer"
                value={dealerOptions.find((opt) => opt.value === formData.dealer)?.label || ""}
                setValue={(label) => {
                  const selected = dealerOptions.find((opt) => opt.label === label);
                  handleChange("dealer", selected?.value || "");
                }}
                options={dealerOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.dealer}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, dealer: val }))}
                dropdownRef={refs.dealer}
                error={errors.dealer}
              />

              {/* Logo */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Logo</label>
                <label
                  htmlFor="logo-upload"
                  className={`relative cursor-pointer border border-black/30  flex items-center gap-3 px-3 py-1.5 text-gray-400 text-xs hover:bg-gray-50 ${
                    errors.logo ? "border-red1" : ""
                  }`}
                >
                  {formData.logo ? (
                    <img src={formData.logo} alt="Logo Preview" className="object-contain h-4 w-4 rounded" />
                  ) : (
                    <span className="truncate">Choose a file (png, jpeg - max 5MB)</span>
                  )}
                  <Upload size={16} className="ml-auto text-gray-400" />
                  <input
                    type="file"
                    id="logo-upload"
                    accept="image/png, image/jpeg"
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    onChange={(e) => {
                      const file = e.target.files[0];
                      if (!file) return;
                      const validTypes = ["image/png", "image/jpeg"];
                      if (!validTypes.includes(file.type)) {
                        alert("Only PNG or JPEG files are allowed.");
                        return;
                      }
                      const maxSize = 5 * 1024 * 1024;
                      if (file.size > maxSize) {
                        alert("File size must be less than 5MB.");
                        return;
                      }
                      const fileURL = URL.createObjectURL(file);
                      handleChange("logo", fileURL);
                    }}
                  />
                </label>
                {errors.logo && <span className="text-red1 text-xs mt-1">{errors.logo}</span>}
              </div>
<div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Company Website</label>
                <input
                  type="text"
                  placeholder="Enter Company Website"
                  value={formData.website}
                  onChange={(e) => handleChange("website", e.target.value)}
                  className={`border text-xs px-4 py-1.5 ${
                    errors.website ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
                  }`}
                />
                {errors.website && <span className="text-red1 text-xs">{errors.website}</span>}
              </div>
              {/* Dealer Principal Name */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Dealer Principal Name</label>
                <input
                  type="text"
                  placeholder="Enter Dealer Principal Name"
                  value={formData.principalName}
                  onChange={(e) => handleChange("principalName", e.target.value)}
                  className={`border text-xs px-4 py-1.5 ${
                    errors.principalName ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
                  }`}
                />
                {errors.principalName && <span className="text-red1 text-xs">{errors.principalName}</span>}
              </div>

         {/* Dealer HQ Address */}
<div className="flex flex-col gap-1 mt-1">
  <label className="text-xs font-medium text-gray-600">
    Dealer HQ Address <span className="text-red-500">*</span>
  </label>

  <button
    type="button"
    onClick={() => {
      setAddressType("HQ");
      setIsDealerAddressOpen(true);
    }}
    className={`border px-3 py-1.5 text-xs text-left flex justify-between items-center
      ${selectedDealerAddress ? "bg-white text-black" : "bg-darkblue1 text-white"}
      ${errors.dealerAddress ? "border-red-500" : "border-black/30"}
    `}
  >
    <span>
      {selectedDealerAddress
        ? `${selectedDealerAddress.city || ""}${
            selectedDealerAddress.city && selectedDealerAddress.state ? ", " : ""
          }${selectedDealerAddress.state || ""}${
            (selectedDealerAddress.city || selectedDealerAddress.state) &&
            selectedDealerAddress.pincode
              ? ", "
              : ""
          }${selectedDealerAddress.pincode || ""}`
        : "Add HQ Address"}
    </span>

    {selectedDealerAddress && (
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation(); // prevent parent click
          setAddressType("HQ");
          setHqAddress(selectedDealerAddress); // preload data
          setIsDealerAddressOpen(true);
        }}
        className="ml-3"
      >
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
          alt="Edit"
          className="w-4 h-4"
        />
      </button>
    )}
  </button>

  {errors.dealerAddress && (
    <span className="text-xs text-red1">{errors.dealerAddress}</span>
  )}
</div>

<StyledDateField
  label="Since When"
  value={formData.sinceWhen}
  setValue={(val) => handleChange("sinceWhen", val)}
  error={errors.sinceWhen}
/>
 <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">Association with Volvo</label>
                <input
                  type="text"
                  placeholder="Enter Years and Months "
                  value={formData.association}
                  onChange={(e) => handleChange("association", e.target.value)}
                  className={`border text-xs px-4 py-1.5 ${
                    errors.association ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
                  }`}
                />
                {errors.association && <span className="text-red1 text-xs">{errors.association}</span>}
              </div>
                <StyledSelectField
                label="Active"
                placeholder="Select Active"
                value={activeOptions.find((opt) => opt.value === formData.active)?.label || ""}
                setValue={(label) => {
                  const selected = activeOptions.find((opt) => opt.label === label);
                  handleChange("active", selected?.value || "");
                }}
                options={activeOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.active}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, active: val }))}
                dropdownRef={refs.active}
                error={errors.active}
              />
{/* Branch Address */}
<div className="flex flex-col gap-1 mt-1">
  <label className="text-xs font-medium text-gray-600">
    Branch Address 
  </label>

<button
  type="button"
  onClick={() => {
    setAddressType("BRANCH");
    setHqAddress({ city: "", state: "", pincode: "", address: "" }); // clear form for new branch
    setEditingBranchIndex(null); // not editing, adding new
    setIsDealerAddressOpen(true);
  }}
  className={`border px-3 py-1.5 bg-darkblue1 text-xs text-left text-white flex justify-between items-center
    ${errors.branchAddress ? "border-red-500" : "border-black/30"}
  `}
>
  <span>+ Add Branch Address</span>
</button>

  {errors.branchAddress && (
    <span className="text-xs text-red1">
      {errors.branchAddress}
    </span>
  )}
</div>
 

              {/* Conditional Branch Location */}
            
             
            



{/* Branch Address Box */}
{branchAddresses.length > 0 && (
  <div className="mt-2 border border-black/20 p-2 text-xs bg-white">
    <div className="font-semibold mb-1"> Added Branch Address ({branchAddresses.length})</div>

    {branchAddresses.map((branch, idx) => (
      <div
        key={idx}
        className="flex justify-between items-center mb-2 p-2 bg-gray-100 "
      >
        {/* City, State, Pincode */}
        <div className="flex gap-4 text-xs">
          <div><b></b> {branch.city}</div>
          <div><b></b> {branch.state}</div>
          <div><b></b> {branch.pincode}</div>
        </div>

        {/* Edit / Delete Buttons */}
        <div className="flex gap-2">
          <button
            onClick={() => {
              setAddressType("BRANCH");
              setHqAddress(branch);
              setEditingBranchIndex(idx);
              setIsDealerAddressOpen(true);
            }}
          >
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
              alt="Edit"
              className="w-4 h-4"
            />
          </button>
          <button
            onClick={() => {
              const filtered = branchAddresses.filter((_, i) => i !== idx);
              setBranchAddresses(filtered);
            }}
          >
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
              alt="Delete"
              className="w-4 h-4"
            />
          </button>
        </div>
      </div>
    ))}
  </div>
)}






              {/* Company Website */}
              

              {/* Association with Volvo */}
             

              {/* Active */}
            
<div className="flex flex-col gap-1 mt-1">
  <label className="text-xs font-medium text-gray-600">
    Brands <span className="text-red-500">*</span>
  </label>

  <button
    type="button"
    onClick={() => setIsBrandModalOpen(true)}
    className={`border px-3 py-1.5 text-xs text-left
      ${errors.brands ? "border-red-500 bg-darkblue1 text-white" : "bg-darkblue1 text-white"}
    `}
  >
    + Add Brand
  </button>

  {/* ✅ ERROR MESSAGE */}
  {errors.brands && (
    <span className="text-xs text-red1">{errors.brands}</span>
  )}
</div>
{brands.length > 0 && (
  <div className="col-span-2 mt-1 overflow-x-auto">
    <table className="w-full border border-black/20 text-xs whitespace-nowrap">
     <thead className="bg-[#3f5169] text-white">
  <tr>
   
        <th className="border px-3 py-2 text-left">Logo</th>
 <th className="border px-3 py-2 text-left">
      Brand Name
    </th>
    <th className="border px-3 py-2 text-left">Product Segment</th>
    <th className="border px-3 py-2 text-left">Product Category</th>
    <th className="border px-3 py-2 text-left">Association with Volvo</th>
    <th className="border px-3 py-2 text-left">Location</th>
  </tr>
</thead>


      <tbody>
        {brands.map((brand, index) => (
          <tr key={index} className="bg-white">
             <td className="border px-3 py-2">
              {brand.brandLogo ? (
                <img
                  src={URL.createObjectURL(brand.brandLogo)}
                  alt="logo"
                  className="h-5"
                />
              ) : (
                "-"
              )}
            </td>
            <td className="border px-3 py-2">{brand.brandName}</td>
            <td className="border px-3 py-2">{brand.productSegment}</td>
            <td className="border px-3 py-2">{brand.productName}</td>
            <td className="border px-3 py-2">{brand.yearsOfAssociation}</td>
            <td className="border px-3 py-2">{brand.location}</td>

           
          </tr>
        ))}
      </tbody>
    </table>
  </div>
)}

              {/* Notes */}
              <div className="flex flex-col col-span-3">
                <label className="text-xs font-medium text-black mb-3">Notes</label>
                <textarea
                  placeholder="Enter Notes"
                  value={formData.notes}
                  onChange={(e) => handleChange("notes", e.target.value)}
                  className={`border text-xs px-4 py-2 text-xs resize-none h-28 ${
                    errors.notes ? "border-red1" : "border-black/30"
                  }`}
                />
                {errors.notes && <span className="text-red1 text-xs">{errors.notes}</span>}
              </div>
            </div>

            {/* Save Button */}
            <div className="mt-4 flex justify-end">
              <button
                 onClick={  handleSave  }
                className="bg-darkblue1 text-white px-8 py-1.5 transition text-xs hover:border hover:border-darkblue1 hover:bg-white hover:text-darkblue1"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    {isDealerAddressOpen && (
  <>
    {/* Overlay */}
    <div
      className="fixed inset-0 bg-black bg-opacity-40 z-40"
      onClick={closeDealerAddressModal}
    />

    {/* Modal */}
    <div
      className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2
      bg-white w-[520px] max-w-[95%] p-6 z-50 shadow-lg"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-base font-semibold text-darkblue1 border-b-2 border-darkblue1 inline-block">
          {addressType === "HQ" ? "Add HQ Location" : "Add Branch Location"}
        </h3>

        <button onClick={closeDealerAddressModal}>
          <div className="w-6 h-6 rounded-full bg-red-600 flex items-center justify-center">
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
              alt="close"
              className="w-4 h-4"
            />
          </div>
        </button>
      </div>

      {/* Form */}
      <div className="grid grid-cols-2 gap-4">

        {/* City */}
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-600">
            City <span className="text-red-500"></span>
          </label>
          <input
            type="text"
            value={hqAddress.city}
            onChange={(e) => {
              setHqAddress({ ...hqAddress, city: e.target.value });
              setAddressErrors({ ...addressErrors, city: "" });
            }}
            className={`border px-3 py-1.5 text-xs ${
              addressErrors.city ? "border-red1" : "border-black/30"
            }`}
          />
          {addressErrors.city && (
            <span className="text-xs text-red1">{addressErrors.city}</span>
          )}
        </div>

        {/* State */}
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-600">
            State <span className="text-red-500"></span>
          </label>
          <input
            type="text"
            value={hqAddress.state}
            onChange={(e) => {
              setHqAddress({ ...hqAddress, state: e.target.value });
              setAddressErrors({ ...addressErrors, state: "" });
            }}
            className={`border px-3 py-1.5 text-xs ${
              addressErrors.state ? "border-red1" : "border-black/30"
            }`}
          />
          {addressErrors.state && (
            <span className="text-xs text-red1">{addressErrors.state}</span>
          )}
        </div>

        {/* Pincode */}
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-600">
            Pincode <span className="text-red-500"></span>
          </label>
          <input
            type="text"
            value={hqAddress.pincode}
             onChange={handlePincodeChange} // use the function here

            className={`border px-3 py-1.5 text-xs ${
              addressErrors.pincode ? "border-red1" : "border-black/30"
            }`}
          />
          {addressErrors.pincode && (
            <span className="text-xs text-red1">{addressErrors.pincode}</span>
          )}
        </div>

        {/* Full Address */}
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-600">
            Full Address <span className="text-red-500"></span>
          </label>
          <input
            type="text"
            value={hqAddress.address}
            onChange={(e) => {
              setHqAddress({ ...hqAddress, address: e.target.value });
              setAddressErrors({ ...addressErrors, address: "" });
            }}
            className={`border px-3 py-1.5 text-xs ${
              addressErrors.address ? "border-red1" : "border-black/30"
            }`}
          />
          {addressErrors.address && (
            <span className="text-xs text-red1">{addressErrors.address}</span>
          )}
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-center mt-6">
        <button
          onClick={() => {
            if (!validateAddress()) return;

            if (addressType === "HQ") {
              setSelectedDealerAddress(hqAddress);
            } else {
              if (editingBranchIndex !== null) {
                const updatedBranches = [...branchAddresses];
                updatedBranches[editingBranchIndex] = hqAddress;
                setBranchAddresses(updatedBranches);
                setEditingBranchIndex(null);
              } else {
                setBranchAddresses([...branchAddresses, hqAddress]);
              }
            }

            closeDealerAddressModal();
          }}
          className="bg-darkblue1 text-white px-8 py-1 text-xs"
        >
          Save
        </button>
      </div>
    </div>
  </>
)}

{isBrandModalOpen && (
  <>
    {/* Overlay */}
    <div
      className="fixed inset-0 bg-black bg-opacity-40 z-40"
      onClick={closeBrandModal}
    />

    {/* Modal */}
    <div
      className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2
      bg-white w-[720px] max-w-[95%] p-6 z-50 shadow-lg"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-base font-semibold text-darkblue1 border-b-2 border-darkblue1">
          Add Multibrand
        </h3>

        <button onClick={closeBrandModal}> <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
              alt="close"
              className="w-4 h-4"
            /></button>
      </div>

      {/* Form */}
      <div className="grid grid-cols-2 gap-4 text-xs">

        {/* Brand Name */}
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-600">
            Brand Name 
          </label>
          <input
            placeholder="Brand Name "
            value={brandForm.brandName}
            onChange={(e) => {
              setBrandForm({ ...brandForm, brandName: e.target.value });
              setBrandErrors({ ...brandErrors, brandName: "" });
            }}
            className={`border px-3 py-2 ${
              brandErrors.brandName ? "border-red1" : "border-black/30"
            }`}
          />
          {brandErrors.brandName && (
            <span className="text-red1">{brandErrors.brandName}</span>
          )}
        </div>
{/* Product Segment */}
<div ref={brandDropdownRefs.productSegment} className="relative w-full">
  <StyledSelectField
    label="Product Segment"
    placeholder="Select Product Segment"
    value={
      productSegmentOptions.find((opt) => opt.value === brandForm.productSegment)?.label || ""
    }
    setValue={(label) => {
      const selected = productSegmentOptions.find((opt) => opt.label === label);
      setBrandForm({ ...brandForm, productSegment: selected?.value || "" });
      setBrandErrors({ ...brandErrors, productSegment: "" });
    }}
    options={productSegmentOptions.map((opt) => opt.label)}
    dropdownOpen={brandDropdownOpen.productSegment}
    setDropdownOpen={(val) =>
      setBrandDropdownOpen((p) => ({ ...p, productSegment: val }))
    }
    dropdownRef={brandDropdownRefs.productSegment}
    error={brandErrors.productSegment}
  />
</div>

{/* Product Category */}
<div ref={brandDropdownRefs.productCategory} className="relative w-full">
  <StyledSelectField
    label="Product Category"
    placeholder="Select Product Category"
    value={
      productCategoryOptions.find((opt) => opt.value === brandForm.productName)?.label || ""
    }
    setValue={(label) => {
      const selected = productCategoryOptions.find((opt) => opt.label === label);
      setBrandForm({ ...brandForm, productName: selected?.value || "" });
      setBrandErrors({ ...brandErrors, productName: "" });
    }}
    options={productCategoryOptions.map((opt) => opt.label)}
    dropdownOpen={brandDropdownOpen.productCategory}
    setDropdownOpen={(val) =>
      setBrandDropdownOpen((p) => ({ ...p, productCategory: val }))
    }
    dropdownRef={brandDropdownRefs.productCategory}
    error={brandErrors.productName}
  />
</div>


           {/* Since When (Date Picker) */}
<div className="flex flex-col gap-1">
  <StyledDateField
    label="Since When"
    value={brandForm.sinceWhen}
    setValue={(val) => {
      setBrandForm({ ...brandForm, sinceWhen: val });
      setBrandErrors({ ...brandErrors, sinceWhen: "" });
    }}
    error={brandErrors.sinceWhen}
  />
</div>

        <div className="flex flex-col gap-1">
           <label className="text-xs font-medium text-gray-600">
           Association With Volvo
          </label>
          <input
            placeholder="Association With Volvo "
            value={brandForm.yearsOfAssociation}
            onChange={(e) => {
              setBrandForm({ ...brandForm, yearsOfAssociation: e.target.value });
              setBrandErrors({ ...brandErrors, yearsOfAssociation: "" });
            }}
            className={`border px-3 py-2 ${
              brandErrors.yearsOfAssociation ? "border-red1" : "border-black/30"
            }`}
          />
          {brandErrors.yearsOfAssociation && (
            <span className="text-red1">
              {brandErrors.yearsOfAssociation}
            </span>
          )}
        </div>
         <div className="flex flex-col gap-1 ">
           <label className="text-xs font-medium text-gray-600">
            Brand Location
          </label>
          <input
            placeholder="Brand Location "
            value={brandForm.location}
            onChange={(e) => {
              setBrandForm({ ...brandForm, location: e.target.value });
              setBrandErrors({ ...brandErrors, location: "" });
            }}
            className={`border px-3 py-2 ${
              brandErrors.location ? "border-red1" : "border-black/30"
            }`}
          />
          {brandErrors.location && (
            <span className="text-red1">{brandErrors.location}</span>
          )}
        </div>

        {/* Logo */}
       <div className="flex flex-col gap-1 col-span-2">
  <label className="text-xs font-medium text-gray-600">
    Upload Logo
  </label>

  {/* Hidden file input */}
  <input
    type="file"
    accept="image/*"
    id="brandLogoUpload"
    className="hidden"
    onChange={(e) => {
      if (e.target.files && e.target.files[0]) {
        setBrandForm({ ...brandForm, brandLogo: e.target.files[0] });
        setBrandErrors({ ...brandErrors, brandLogo: "" });
      }
    }}
  />

  {/* Custom styled input with icon at right */}
  <label
    htmlFor="brandLogoUpload"
    className={`flex items-center justify-between px-3 py-2 border cursor-pointer ${
      brandErrors.brandLogo ? "border-red1 bg-red-50" : "border-black/30 bg-white"
    }`}
  >
    {/* File name or placeholder */}
    <span className="text-xs text-gray-700 truncate">
      {brandForm.brandLogo ? brandForm.brandLogo.name : "Click to upload"}
    </span>

    {/* Upload icon at right */}
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className="h-4 w-4 text-darkblue1"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeWidth={2}
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M12 12v8m0-8l-4 4m4-4l4 4M12 4v8"
      />
    </svg>
  </label>

  {/* Error message */}
  {brandErrors.brandLogo && (
    <span className="text-xs text-red1">{brandErrors.brandLogo}</span>
  )}
</div>

        {/* Product Segment */}
        

        {/* Product Name */}
       

        {/* Since When */}
    

        {/* Years of Association */}
        

        {/* Location */}
             </div>

      {/* Save */}
      <div className="flex justify-center mt-6">
        <button
          onClick={() => {
            if (!validateBrandForm()) return;

            setBrands((prev) => [...prev, brandForm]);
            closeBrandModal();
          }}
          className="bg-darkblue1 text-white px-10 py-2 text-xs"
        >
          Save
        </button>
      </div>
    </div>
  </>
)}

    </div>
  );
};

export default AddDealerAddress;
