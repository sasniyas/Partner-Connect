import React, { useState } from "react";

const users = [
  {
    name: "Alex Martin",
    role: "Sales Manager",
    img: "https://i.pravatar.cc/100?img=1",
    team: [
      { name: "Riya", role: "Sales Executive" },
      { name: "Karan", role: "Sales Coordinator" },
      { name: "Sam", role: "Intern" },
      { name: "Karan", role: "Sales Coordinator" },
      { name: "Karan", role: "Sales Coordinator" },
    ],
  },
  {
    name: "Priya Shah",
    role: "Service Lead",
    img: "https://i.pravatar.cc/100?img=2",
    team: [
      { name: "Neha", role: "Support Executive" },
      { name: "Amit", role: "Customer Success" },
      { name: "Karan", role: "Sales Coordinator" },
      { name: "Karan", role: "Sales Coordinator" },
    ],
  },
  {
    name: "Rahul Verma",
    role: "HR Manager",
    img: "https://i.pravatar.cc/100?img=3",
    team: [
      { name: "Sonal", role: "HR Executive" },
      { name: "Vikas", role: "Recruiter" },
    ],
  },
  {
    name: "Anita Roy",
    role: "Finance Head",
    img: "https://i.pravatar.cc/100?img=4",
    team: [
      { name: "Rohit", role: "Accountant" },
      { name: "Pooja", role: "Finance Analyst" },
    ],
  },
];

// Recursive Team component
function Team({ members, expanded, toggleExpandLevel }) {
  const displayMembers = !expanded && members.length > 2 ? members.slice(0, 2) : members;

  return (
    <div className="flex gap-3 justify-center flex-wrap mt-2 w-full">
      {displayMembers.map((member, idx) => (
        <div
          key={idx}
          className="bg-white shadow-sm px-3 py-2 w-[160px] text-center rounded border border-gray-200"
        >
          <p className="text-xs font-semibold">{member.name}</p>
          <p className="text-[11px] text-gray-500">{member.role}</p>

          {member.team && member.team.length > 0 && (
            <Team members={member.team} expanded={true} toggleExpandLevel={toggleExpandLevel} />
          )}
        </div>
      ))}

      {!expanded && members.length > 2 && (
        <div
          onClick={toggleExpandLevel}
          className="flex items-center justify-center bg-gray-200 rounded w-[40px] text-gray-600 cursor-pointer select-none"
        >
          ...
        </div>
      )}
    </div>
  );
}

function OrgStructure() {
  const [expandedIndex, setExpandedIndex] = useState(null);

  const toggleExpand = (index) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };

  return (
    <div className="bg-gray-100 flex flex-col items-center ">

      {/* ===== LEVEL 1: PARENT ===== */}
<div className="relative flex items-center gap-3 bg-darkblue1 text-white shadow-lg px-4 py-2 w-[240px] rounded">
        <img
          src="https://i.pravatar.cc/100?img=8"
          alt="Profile"
          className="w-10 h-10 rounded-full"
        />
        <div>
          <p className="text-sm font-semibold">John Doe</p>
          <p className="text-[11px] text-gray-200">Director</p>
          {users.length > 0 && (
            <p className="flex items-center gap-1 text-[10px] mt-1 text-black bg-white px-2 py-[2px] rounded w-fit">
              {users.length} Total
            </p>
          )}
        </div>

        <div className="absolute left-1/2 -bottom-8 h-8 w-px bg-gray-400"></div>
        <div
          className="absolute left-1/2 -bottom-[38px] -translate-x-1/2
          w-0 h-0 border-l-4 border-r-4 border-t-6
          border-l-transparent border-r-transparent border-t-gray-400"
        />
      </div>

      {/* ===== LEVEL 2 CONNECTOR ===== */}
      <div className="relative w-[80%] h-px bg-gray-400 mt-10">
        {users.map((_, i) => (
          <div
            key={i}
            className="absolute top-0 h-6 w-px bg-gray-400"
            style={{ left: `${(100 / (users.length * 2)) * (2 * i + 1)}%` }}
          >
            <div
              className="absolute -bottom-[6px] left-1/2 -translate-x-1/2
              w-0 h-0 border-l-3 border-r-3 border-t-5
              border-l-transparent border-r-transparent border-t-gray-400"
            />
          </div>
        ))}
      </div>

      {/* ===== LEVEL 2 + LEVEL 3 ===== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mt-6 w-[90%]">
        {users.map((user, i) => (
          <div
            key={i}
            className="flex flex-col items-center cursor-pointer"
            onClick={() => toggleExpand(i)}
          >
            {/* LEVEL 2 CARD */}
            <div className="bg-white shadow-md px-3 py-2 w-[200px] text-center rounded border border-gray-300">
              <div className="flex items-center gap-3 justify-center">
                <img src={user.img} alt="" className="w-9 h-9 rounded-full" />
                <div>
                  <p className="text-xs font-semibold">{user.name}</p>
                  <p className="text-[11px] text-gray-500">{user.role}</p>
                </div>
              </div>

              {user.team?.length > 0 && (
                <p className="flex items-center gap-1 text-[10px] mt-1 text-black bg-gray-100 px-2 py-[2px] rounded mx-auto w-fit">
                  {user.team.length} Total
                </p>
              )}
            </div>

            {/* line down */}
            <div className="w-px h-6 bg-gray-400"></div>

            {/* LEVEL 3 TEAM */}
            <Team
              members={user.team}
              expanded={expandedIndex === i}
              toggleExpandLevel={() => toggleExpand(i)}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

export default OrgStructure;
