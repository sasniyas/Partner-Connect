
import React, { useState, useRef, useEffect } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import StyledSelectField from "../../../Components/StyledSelectField";

const EditVolvoUser = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const user = location.state?.user;

  const [menuOpen, setMenuOpen] = useState(false);
  const [marketArea, setMarketAreas] = useState([]);
  const [selectedStates, setSelectedStates] = useState([]);
  const [isMarketAreaDropdownOpen, setIsMarketAreaDropdownOpen] = useState(false);
  const [isStateDropdownOpen, setIsStateDropdownOpen] = useState(false);

  const statesList = [
    { label: "Punjab", value: "punjab", marketArea: "North" },
    { label: "Haryana", value: "haryana", marketArea: "North" },
    { label: "Tamil Nadu", value: "tamilnadu", marketArea: "South" },
    { label: "Karnataka", value: "karnataka", marketArea: "South" },
    { label: "West Bengal", value: "westbengal", marketArea: "East" },
    { label: "Odisha", value: "odisha", marketArea: "East" },
    { label: "Maharashtra", value: "maharashtra", marketArea: "West" },
    { label: "Gujarat", value: "gujarat", marketArea: "West" },
  ];

  const marketAreaRef = useRef(null);
  const stateRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (marketAreaRef.current && !marketAreaRef.current.contains(event.target)) {
        setIsMarketAreaDropdownOpen(false);
      }
      if (stateRef.current && !stateRef.current.contains(event.target)) {
        setIsStateDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const nameRegex = /^[A-Za-z ]+$/;

  const marketAreasOpions = [
    { label: "North", value: "North" },
    { label: "South", value: "South" },
    { label: "East", value: "East" },
    { label: "West", value: "West" },
  ];

  const departmentOptions = [
    { label: "Sales", value: "Sales" },
    { label: "Service", value: "Service" },
    { label: "HR", value: "HR" },
  ];

  const workLocationOptions = [
    { label: "Head Quarter", value: "Head Quarter" },
    { label: "Market Area", value: "Market Area" },
  ];

  const activeOptions = [
    { label: "Yes", value: "Yes" },
    { label: "No", value: "No" },
  ];

  const [formData, setFormData] = useState({
    marketArea: "",
    firstName: "",
    lastName: "",
    vcnId: "",
    phone: "",
    department: "",
    designation: "",
    email: "",
    workLocation: "",
    active: "",
    notes: "",
  });

  const [dropdowns, setDropdowns] = useState({
    marketArea: false,
    department: false,
    workLocation: false,
    active: false,
  });

  const refs = {
    marketArea: useRef(),
    department: useRef(),
    workLocation: useRef(),
    active: useRef(),
  };

  useEffect(() => {
    if (user) {
      setFormData({
        marketArea: "",
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        vcnId: user.vcnId || "",
        phone: user.phone || "",
        department: user.department || "",
        designation: user.designation || "",
        email: user.email || "",
        workLocation: user.workLocation || "",
        active: user.active || "",
        notes: user.notes || "",
      });
setMarketAreas(
  Array.isArray(user.marketArea)
    ? user.marketArea
    : user.marketArea
    ? [user.marketArea]
    : []
);
      setSelectedStates(user.selectedStates || []);
    }
  }, [user]);

  const [errors, setErrors] = useState({});

  const handleBack = () => {
    navigate("/contactmanagemnet", { state: { activeTab: "volvoUsers" } });
  };

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const handleSave = () => {
    let requiredFields = [
      "firstName",
      "lastName",
      "vcnId",
      "phone",
      "department",
      "designation",
      "email",
      "workLocation",
      "active",
    ];

    let newErrors = {};

    requiredFields.forEach((field) => {
      if (!formData[field]) {
        newErrors[field] = "This field is required";
      }
    });

    if (formData.workLocation === "Market Area") {
      if (marketArea.length === 0) {
        newErrors.marketArea = "Please select at least one Market Area";
      }
      if (selectedStates.length === 0) {
        newErrors.selectedStates = "Please select at least one State";
      }
    }

    setErrors(newErrors);

   if (Object.keys(newErrors).length === 0) {
    const updatedUser = {
      ...formData,
      marketArea: formData.workLocation === "Market Area" ? marketArea : [],
      selectedStates: formData.workLocation === "Market Area" ? selectedStates : [],
      id: user?.id,
    };

    navigate("/contactmanagemnet", {
      state: { updatedUser, activeTab: "volvoUsers" },
    });
    }
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="flex flex-col w-full mb-3">
            <div className="flex items-center gap-2">
              <ArrowLeft
                onClick={handleBack}
                size={20}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              />
              <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                Edit Contact
              </h2>
            </div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-7"></div>
          </div>

          {/* Form */}
          <div className="bg-white px-6 py-4 rounded shadow-md">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-12 gap-y-2">
  {/* VDN ID */}
              <div className="flex flex-col">
                <label className="text-xs font-medium text-black/70 mb-2">VDN ID</label>
                <input
                  type="text"
                  value={formData.vcnId}
                  onChange={(e) => handleChange("vcnId", e.target.value)}
                  className={`border text-xs px-4 py-1.5  text-xs ${
                    errors.vcnId ? "border-red1" : "border-black/30"
                  }`}
                />
                {errors.vcnId && <span className="text-red1 text-xs">{errors.vcnId}</span>}
              </div>

               <div className="flex flex-col">
  <label className="text-xs font-medium text-black/70 mb-2">First Name</label>

  <input
    type="text"
    placeholder="Enter First Name"
    value={formData.firstName}
    onChange={(e) => {
      const value = e.target.value;
      handleChange("firstName", value);

      if (value.trim() === "") {
        setErrors((prev) => ({ ...prev, firstName: "" }));
      } else if (!nameRegex.test(value)) {
        setErrors((prev) => ({ ...prev, firstName: "Only letters and spaces allowed" }));
      } else {
        setErrors((prev) => ({ ...prev, firstName: "" }));
      }
    }}
    className={`border text-xs px-4 py-1.5 ${
      errors.firstName ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
  />

  {errors.firstName && (
    <span className="text-red1 text-xs">{errors.firstName}</span>
  )}
</div>


              {/* Last Name */}
             <div className="flex flex-col">
  <label className="text-xs font-medium text-black/70 mb-2">Last Name</label>

  <input
    type="text"
    placeholder="Enter Last Name"
    value={formData.lastName}
    onChange={(e) => {
      const value = e.target.value;
      handleChange("lastName", value);

      if (value.trim() === "") {
        setErrors((prev) => ({ ...prev, lastName: "" }));
      } else if (!nameRegex.test(value)) {
        setErrors((prev) => ({ ...prev, lastName: "Only letters and spaces allowed" }));
      } else {
        setErrors((prev) => ({ ...prev, lastName: "" }));
      }
    }}
    className={`border text-xs px-4 py-1.5 ${
      errors.lastName ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
  />

  {errors.lastName && (
    <span className="text-red1 text-xs">{errors.lastName}</span>
  )}
</div>
<div>
<StyledSelectField
                label="Department"
                placeholder="Select Department"
                value={
                  departmentOptions.find((opt) => opt.value === formData.department)?.label || ""
                }
                setValue={(label) => {
                  const selected = departmentOptions.find((opt) => opt.label === label);
                  handleChange("department", selected?.value || "");
                }}
                options={departmentOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.department}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, department: val }))}
                dropdownRef={refs.department}
                error={errors.department}
              />
              </div>
                {/* Designation */}
              <div className="flex flex-col ">
                <label className="text-xs font-medium text-black/70 mb-2">Designation</label>
                <input
                  type="text"
                  placeholder="Enter Designation"
                  value={formData.designation}
                  onChange={(e) => handleChange("designation", e.target.value)}
                  className={`border text-xs px-4 py-1.5  text-xs ${
                    errors.designation ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
                  }`}
                />
                {errors.designation && <span className="text-red1 text-xs">{errors.designation}</span>}
              </div>

              {/* Email */}
             <div className="flex flex-col">
  <label className="text-xs font-medium text-black/70 mb-2">Email ID</label>
  <input
    type="email"
    placeholder="Enter Email"
    value={formData.email}
    onChange={(e) => {
      const value = e.target.value;
      handleChange("email", value);

      // Live validation
      if (value.trim() === "") {
        setErrors((prev) => ({ ...prev, email: "" }));
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        setErrors((prev) => ({ ...prev, email: "Invalid email" }));
      } else {
        setErrors((prev) => ({ ...prev, email: "" }));
      }
    }}
    className={`border text-xs px-4 py-1.5 ${
      errors.email ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
  />

  {errors.email && (
    <span className="text-red1 text-xs">{errors.email}</span>
  )}
</div> {/* Phone Number */}
              <div className="flex flex-col">
  <label className="text-xs font-medium text-black/70 mb-2">Phone Number</label>

  <input
    type="text"
    maxLength={10}                 // prevents typing more than 10 digits
    placeholder="Enter Phone Number"
    value={formData.phone}
    onChange={(e) => {
      const value = e.target.value;

      // Allow only digits
      if (/^[0-9]*$/.test(value)) {
        handleChange("phoneNumber", value);
      }

      // Validation messages
      if (value.trim() === "") {
        setErrors((prev) => ({
          ...prev,
          phone: "",
        }));
      } else if (value.length !== 10) {
        setErrors((prev) => ({
          ...prev,
          phone: "Phone number must be 10 digits",
        }));
      } else {
        setErrors((prev) => ({ ...prev, phone: "" }));
      }
    }}
    className={`border text-xs px-4 py-1.5 text-sm ${
      errors.phone ? "border-red1" : "border-black/30 hover:ring-1 hover:ring-black/30"
    }`}
  />

  {errors.phone && (
    <span className="text-red1 text-xs">{errors.phone}</span>
  )}
</div>
<div>
 <StyledSelectField
                label="Active"
                placeholder="Select Active"
                value={
                  activeOptions.find((opt) => opt.value === formData.active)?.label || ""
                }
                setValue={(label) => {
                  const selected = activeOptions.find((opt) => opt.label === label);
                  handleChange("active", selected?.value || "");
                }}
                options={activeOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.active}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, active: val }))}
                dropdownRef={refs.active}
                error={errors.active}
              />
              </div>
              <div>
                <StyledSelectField
                label="Work Location"
                placeholder="Select Work Location"
                value={
                  workLocationOptions.find((opt) => opt.value === formData.workLocation)?.label || ""
                }
                setValue={(label) => {
                  const selected = workLocationOptions.find((opt) => opt.label === label);
                  handleChange("workLocation", selected?.value || "");
                }}
                options={workLocationOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.workLocation}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, workLocation: val }))}
                dropdownRef={refs.workLocation}
                error={errors.workLocation}
              />
              </div>
              {/* Market Area */}
            {/* Market Area Multi-Select */}
{/* Market Area Multi-Select */}
<div>
{formData.workLocation === "Market Area" && (
  <div className="relative w-full" ref={marketAreaRef}>
    <label className="text-xs font-medium text-black/70 mb-1">Market Area *</label>

    <div
      className={`relative border px-3 py-1.5 pr-10 text-xs cursor-pointer flex items-center flex-wrap gap-1 transition-all duration-200 ${
        errors.marketArea
          ? "border-red1"
          : isMarketAreaDropdownOpen
            ? "bg-white border-black/30 text-black border-b-white"
            : "bg-white border-black/30 hover:border-2 focus:outline-none focus:border-2"
      }`}
      onClick={() => setIsMarketAreaDropdownOpen((v) => !v)}
    >
      {marketArea.length > 0 ? (
        marketArea.map((val) => (
          <span
            key={val}
            className="bg-grey2 px-2 py-0.5 rounded text-black text-xs flex items-center gap-1"
          >
            {marketAreasOpions.find((m) => m.value === val)?.label}
            <span
              className="cursor-pointer text-xs"
              onClick={(e) => {
                e.stopPropagation()
                setMarketAreas((prev) => prev.filter((v) => v !== val))
                setSelectedStates([]) // reset states if MA deselected
              }}
            >
             <img
                            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
                            alt="Close"
                            className="w-3 h-3"
                          />
            </span>
          </span>
        ))
      ) : (
        <span className="text-black/60">-Select Market Areas-</span>
      )}

      {/* Dropdown arrow */}
    <img
        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Vector (25).png"
        alt="Dropdown Icon"
        className={`w-3 h-3 absolute right-3 top-1/2 -translate-y-1/2 transition-transform duration-200 ${
          isMarketAreaDropdownOpen ? "rotate-180" : "rotate-0"
        }`}
      />
    </div>

    {/* Dropdown List */}
    {isMarketAreaDropdownOpen && (
      <ul className="absolute w-full bg-white border border-black/30 border-t-white max-h-40 overflow-auto shadow-md z-50">
        {marketAreasOpions
          .sort((a, b) => a.label.localeCompare(b.label))
          .map((m) => (
            <li
              key={m.value}
              className={`px-3 py-1.5 text-xs cursor-pointer hover:bg-lightBlue flex items-center gap-2 ${
                marketArea.includes(m.value) ? "bg-lightBlue font-semibold" : ""
              }`}
              onClick={(e) => {
                e.stopPropagation()
                setMarketAreas((prev) =>
                  prev.includes(m.value)
                    ? prev.filter((v) => v !== m.value)
                    : [...prev, m.value]
                )
              }}
            >
              <input type="checkbox" checked={marketArea.includes(m.value)} readOnly />
              {m.label}
            </li>
          ))}
      </ul>
    )}

    {errors.marketArea && (
      <p className="text-red1 text-xs mt-1">{errors.marketArea}</p>
    )}
  </div>
)}
</div>
{/* States Multi-Select */}
<div>
{marketArea.length > 0 && formData.workLocation === "Market Area" &&    (
  <div className="relative w-full " ref={stateRef}>
    <label className="text-xs font-medium text-black/70 mb-1">States *</label>

    <div
      className={`relative  border px-3 py-1.5 pr-10 text-xs cursor-pointer flex items-center flex-wrap gap-1 transition-all duration-200 ${
        errors.selectedStates
          ? "border-red1"
          : isStateDropdownOpen
            ? "bg-white border-black/30 text-black border-b-white"
            : "bg-white border-black/30 hover:border-2 focus:outline-none focus:border-2"
      }`}
      onClick={() => setIsStateDropdownOpen((v) => !v)}
    >
      {selectedStates.length > 0 ? (
        selectedStates.map((val) => (
          <span
            key={val}
            className="bg-grey2 px-2 py-0.5 rounded text-black text-xs flex items-center gap-1"
          >
            {statesList.find((s) => s.value === val)?.label}
            <span
              className="cursor-pointer text-xs"
              onClick={(e) => {
                e.stopPropagation()
                setSelectedStates((prev) => prev.filter((v) => v !== val))
              }}
            >
              <img
                            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
                            alt="Close"
                            className="w-3 h-3"
                          />
            </span>
          </span>
        ))
      ) : (
        <span className="text-black/60">Select States *</span>
      )}

      {/* Dropdown arrow */}
      <img
        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Vector (25).png"
        alt="Dropdown Icon"
        className={`w-3 h-3 absolute right-3 top-1/2 -translate-y-1/2 transition-transform duration-200 ${
          isMarketAreaDropdownOpen ? "rotate-180" : "rotate-0"
        }`}
      />
    </div>

    {/* Dropdown List */}
    {isStateDropdownOpen && (
      <ul className="absolute w-full bg-white border border-black/30 border-t-white max-h-40 overflow-auto shadow-md z-50">
        {statesList
          .filter((s) => marketArea.includes(s.marketArea))
          .sort((a, b) => a.label.localeCompare(b.label))
          .map((s) => (
            <li
              key={s.value}
              className={`px-3 py-1.5 text-xs cursor-pointer hover:bg-lightBlue flex items-center gap-2 ${
                selectedStates.includes(s.value) ? "bg-lightBlue font-semibold" : ""
              }`}
              onClick={(e) => {
                e.stopPropagation()
                setSelectedStates((prev) =>
                  prev.includes(s.value)
                    ? prev.filter((v) => v !== s.value)
                    : [...prev, s.value]
                )
              }}
            >
              <input type="checkbox" checked={selectedStates.includes(s.value)} readOnly />
              {s.label}
            </li>
          ))}
      </ul>
    )}

    {errors.selectedStates && <p className="text-red1 text-xs mt-1">{errors.selectedStates}</p>}
  </div>
)}
</div>

              {/* Notes */}
              <div className="flex flex-col col-span-3">
  <label className="text-xs font-medium text-black mb-3">Notes</label>
  <textarea
    placeholder="Enter Notes"
    value={formData.notes}
    onChange={(e) => handleChange("notes", e.target.value)}
    className={`border text-xs px-4 py-2 text-xs resize-none h-28 ${
      errors.notes ? "border-red1" : "border-black/30"
    }`}
  />
  {errors.notes && <span className="text-red1 text-xs">{errors.notes}</span>}
</div>


            </div>

            {/* Save Button */}
            <div className="mt-4 flex justify-end">
              <button
                 onClick={handleSave}
                className="bg-darkblue1 text-white px-8 py-1.5 transition text-xs hover:border hover:border-darkblue1 hover:bg-white hover:text-darkblue1"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditVolvoUser;
