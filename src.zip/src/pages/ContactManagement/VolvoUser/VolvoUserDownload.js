"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";

const VolvoUserDownload = () => {
  const [tableData, setTableData] = useState([]);
  const [menuOpen, setMenuOpen] = useState();

  // ✅ Listen for postMessage from parent window
  useEffect(() => {
    // Notify parent that we are ready
    window.opener?.postMessage({ type: "READY_FOR_DATA" }, "*");

    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const handleDownloadExcel = () => {
    if (!tableData || tableData.length === 0) return;

    const excelData = tableData.map((row, index) => ({
      "Sl. No": index + 1,
      "VDN ID": row.vdnId,
      "Market Area": Array.isArray(row.marketArea) ? row.marketArea.join(", ") : row.marketArea,
      "Name": `${row.firstName || ""} ${row.lastName || ""}`,
      "Department": row.department,
      "Designation": row.designation,
      "Phone Number": row.phone,
      "Email ID": row.email,
      "Work Location": row.workLocation,
      "Active": row.active,
      "Resignation Date": row.resignationDate || "-",
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);

    // Optional: Left align first column
    Object.keys(worksheet).forEach((cell) => {
      if (cell.startsWith("A")) {
        worksheet[cell].s = { alignment: { horizontal: "left" } };
      }
    });

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Volvo Users");
    XLSX.writeFile(workbook, "Volvo_Users.xlsx");
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">Volvo Users</h2>
          <button
            className="bg-darkblue1 text-white text-sm font-medium px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadExcel}
          >
            Download
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 font-medium w-[5%]">VDN ID</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 font-medium w-[10%]">Market Area</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 font-medium w-[15%]">Name</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 font-medium w-[7%]">Department</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 font-medium w-[7%]">Designation</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 font-medium w-[10%]">Phone Number</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 font-medium w-[10%]">Email ID</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 font-medium w-[10%]">Work Location</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 font-medium w-[5%]">Active</th>
              </tr>
            </thead>
            <tbody>
              {tableData.length > 0 ? (
                tableData.map((item, index) => (
                  <tr key={index} className="hover:bg-lightBlue/50 text-xs font-normal">
                    <td className="px-4 py-1 border border-grey2">{item.vdnId}</td>
                    <td className="px-4 py-1 border border-grey2">
                      {Array.isArray(item.marketArea) ? item.marketArea.join(", ") : item.marketArea}
                    </td>
                    <td className="px-4 py-1 border border-grey2">{`${item.firstName || ""} ${item.lastName || ""}`}</td>
                    <td className="px-4 py-1 border border-grey2">{item.department}</td>
                    <td className="px-4 py-1 border border-grey2">{item.designation}</td>
                    <td className="px-4 py-1 border border-grey2">{item.phone}</td>
                    <td className="px-4 py-1 border border-grey2">{item.email}</td>
                    <td className="px-4 py-1 border border-grey2">{item.workLocation}</td>
                    <td className="px-4 py-1 border border-grey2">{item.active}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={11} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default VolvoUserDownload;
