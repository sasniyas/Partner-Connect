import React from "react"
import Header from "../../Components/Header"
import { useState } from "react"

import SubNavbar3 from "../../Components/SubNavbar3"
import ContactMangement from "./ContactManagement"

const ContactManagementHome = () => {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <div className="bg-Frostwhite h-screen  flex flex-col  ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      {/* Main Content */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
       
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
        <ContactMangement/>
        </div>
      </div>
    </div>
  )
}

export default ContactManagementHome