
import React, { useRef } from "react";
import DeactivateAccount from "../../Components/DeactivateAccount";
import ChangePassword from "../../Components/ChangePassword";
import {formatedTime} from "../../util/timeFormat"

const UserProfilePopup = ({ user, onClose, profileImage, setProfileImage }) => {
  const fileInputRef = useRef(null);
  // const [isDeactivateOpen, setIsDeactivateOpen] = React.useState(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = React.useState(false);

  const handleIconClick = () => fileInputRef.current.click();

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setProfileImage(imageUrl);
    }
  };

  // const handleDeactivateConfirm = () => {
  //   // Perform deactivation logic here
  //   console.log("User deactivated:", user);
  //   // setIsDeactivateOpen(false);
  //   onClose();
  // };

  const handlePasswordSave = ({ currentPassword, newPassword }) => {
    // Call API or logic to change password here
    console.log("Password change request:", currentPassword, newPassword);
    setIsChangePasswordOpen(false);
  };

 const fields = [
  { key: "firstName", label: "First Name" },
  { key: "middleName", label: "Middle Name" }, // only show if exists
  { key: "lastName", label: "Last Name" },
  { key: "email", label: "Email Address" },
  { key: "role", label: "User Type" },
  { key: "persona", label: "User Role" },
  { key: "activationMailTimestamp", label: "Activation Mail" },
  { key: "lastLoginTime", label: "Date of Last Login" },
];

  return (
    <>
      <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
        <div className="bg-white  w-[45%]  shadow-lg p-6 relative flex flex-col">
          {/* Close Button */}
          <button onClick={onClose} className="absolute top-4 right-4 p-2">
          <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>

          </button>

          {/* Profile Header */}
          <div className="flex flex-row items-center justify-center gap-4 ">
            <input
              type="file"
              accept="image/*"
              className="hidden"
              ref={fileInputRef}
              onChange={handleImageChange}
            />
            <div
              onClick={handleIconClick}
              className="w-16 h-16 rounded-full bg-white shadow flex items-center justify-center cursor-pointer relative group"
            >
              {profileImage ? (
                <img
                  src={profileImage}
                  alt="Profile"
                  className="w-full h-full object-cover rounded-full"
                />
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none" >
<path fill-rule="evenodd" clip-rule="evenodd" d="M24 8C21.8783 8 19.8434 8.84285 18.3431 10.3431C16.8429 11.8434 16 13.8783 16 16C16 18.1217 16.8429 20.1566 18.3431 21.6569C19.8434 23.1571 21.8783 24 24 24C26.1217 24 28.1566 23.1571 29.6569 21.6569C31.1571 20.1566 32 18.1217 32 16C32 13.8783 31.1571 11.8434 29.6569 10.3431C28.1566 8.84285 26.1217 8 24 8ZM20 26C17.8783 26 15.8434 26.8429 14.3431 28.3431C12.8429 29.8434 12 31.8783 12 34V36C12 37.0609 12.4214 38.0783 13.1716 38.8284C13.9217 39.5786 14.9391 40 16 40H32C33.0609 40 34.0783 39.5786 34.8284 38.8284C35.5786 38.0783 36 37.0609 36 36V34C36 31.8783 35.1571 29.8434 33.6569 28.3431C32.1566 26.8429 30.1217 26 28 26H20Z" fill="#1B365D"/>
</svg>
              )}
              <span className="absolute left-1/2 top-full mt-2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-1 transition-opacity duration-200 whitespace-nowrap z-50">
                Choose photo
              </span>
            </div>
            <div className="flex flex-col">
              <h2 className="text-lg  font-semibold text-darkblue1 text-center sm:text-left">
                {user.firstName} {user.middleName} {user.lastName}
              </h2>
            </div>
          </div>

          {/* Info Grid (Read-only) */}
        <div className="mt-2 border border-black/70  overflow-hidden flex-1">
  {fields.map((item, index) => {
    // Skip middleName completely if it's empty/null
    if (item.key === "middleName" && !user?.middleName) return null;

    return (
      <div
        key={item.key}
        className={`flex flex-col sm:flex-row sm:items-center justify-between px-4 py-1.5 text-xs whitespace-nowrap ${
          index < fields.length - 1 ? "border-b border-black/70" : ""
        }`}
      >
        <div className="w-1/5 text-black  text-xs font-medium mb-1 sm:mb-0">
          {item.label}
        </div>
        <div className="w-full sm:w-2/3 text-black text-xs ">
          {["lastLoginTime", "activationMailTimestamp"].includes(item.key) && user[item.key]
            ? formatedTime(user[item.key])
            : user[item.key] || "-"}
        </div>
      </div>
    );
  })}
</div>


          {/* Action Buttons */}
          <div className="flex justify-end gap-4 mt-6">
            {/* <button
              onClick={() => setIsChangePasswordOpen(true)}
              className="px-4 py-2 rounded-lg text-sm bg-darkblue1 text-white font-medium hover:scale-105 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition-colors"
            >
              Change Password
            </button> */}
            {/* <button
              onClick={() => setIsDeactivateOpen(true)}
              className="px-4 py-2 rounded-lg text-sm bg-red2 text-red1 font-medium hover:scale-105 hover:bg-white hover:text-red1 hover:border hover:border-red1 transition-colors"
            >
              Deactivate User
            </button> */}
          </div>
        </div>
      </div>

      {/* Modals */}
      {/* <DeactivateAccount
        isOpen={isDeactivateOpen}
        onClose={() => setIsDeactivateOpen(false)}
        onConfirm={handleDeactivateConfirm}
      /> */}
      <ChangePassword
        isOpen={isChangePasswordOpen}
        onClose={() => setIsChangePasswordOpen(false)}
        onSave={handlePasswordSave}
      />
    </>
  );
};

export default UserProfilePopup;
