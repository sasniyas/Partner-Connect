// import React, { useState } from "react";
// import Header from "../../Components/Header";
// // import Dashboard from "../Homepage/Dashboard";

// function HomePage() {
//   const [menuOpen, setMenuOpen] = useState(false);

//   return (
//     <div className="bg-gray-100 min-h-screen flex flex-col">
//       {/* Navigation Bar */}
//       <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

//       {/* Main Content - Moves Right when Sidebar Opens */}
//       {/* <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : "ml-0"} mt-[-10px] p-4`}> */}
//       <div
//         className={`transition-all duration-300 mt-16 p-14 ${
//           menuOpen ? "ml-60" : "ml-[65px]"
//         }`}
//       >
//         {/* <img src="/homepageimage.png" alt="home page"/> */}
//         {/* <Dashboard/> */}
//       </div>
//     </div>
//   );
// }

// export default HomePage;


// import React, { useState } from "react";
// import Header from "../../Components/Header";
// import Dashboard from "./Dashboard";
// function Outlook() {
//   const [menuOpen, setMenuOpen] = useState(false);

//   return (
//     <div className="bg-black/15  min-h-screen flex flex-col">
//       {/* Navigation Bar */}
//       <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

//       {/* Main Content */}
//       <div
//         className={`
//           transition-all duration-300 mt-16 p-4 sm:p-6 md:p-10 lg:p-14
//           ${menuOpen ? "lg:ml-60" : "ml-0 lg:ml-[65px]"}
//         `}
//       >
//         {/* Replace or uncomment below as needed */}
//         {/* <img src="/homepageimage.png" alt="home page" /> */}
//         <Dashboard />
//       </div>
//     </div>
//   );
// }

// export default Outlook;
import React, { useState } from "react";
import { useSelector } from "react-redux";
import Header from "../../Components/Header";
// import SubNavbar from "../../Components/SubNavbar";
import Dashboard from "./Dashboard";
import SubNavbar3 from "../../Components/SubNavbar3";

function Outlook() {
  const [menuOpen, setMenuOpen] = useState(false);
 const { data: user } = useSelector((state) => state.user);
 console.log("Haee I am user",user)
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      {/* Header */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
<div className="hidden lg:block">
  <SubNavbar3 />
</div>

      {/* Sub Navigation */}
      {/* <SubNavbar /> */}
{/* <SubNavbar3/> */}
      {/* Main Content */}
    <div
  className={`
    transition-all duration-300 // 64px header + ~64px subnav
    ${menuOpen ? "lg:ml-60" : "ml-0 lg:ml-[10px]"}
    flex justify-center
  `}
>
  {/* <div className="w-full max-w-screen-xl px-4 sm:px-6 md:px-10 lg:px-12"> */}
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">

    <Dashboard />
  </div>
</div>
    </div>
  );
}

export default Outlook;
