import React from "react";
import Header from "../../../Components/Header";
import { useState } from "react";
import SubNavbar3 from "../../../Components/SubNavbar3";
import Createscorecard from "./Createscorecard";

const Createscorecardhome = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="bg-Frostwhite h-screen  flex flex-col">
      {/* Navigation Bar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      
      {/* Main Content - Moves Right when Sidebar Opens */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        {/* ✅ Reduced by another 0.5% (total 1% reduction from original) */}
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <Createscorecard/>
        </div>
      </div>
    </div>
  );
};

export default Createscorecardhome;