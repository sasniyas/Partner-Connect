import React, { useState, useRef, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import StyledSelectField from "../../../Components/StyledSelectField";
import StyledDateField from "../../../Components/StyledDatefield";

import { getMarketAreas } from "../../../services/pdpMaster/marketArea.service";
import { getDealers } from "../../../services/pdpMaster/dealership.service";
// ⭐ Import scorecard services
import { 
  addScorecard, 
  updateScorecard, 
  getAuditors,
  getAllScorecards 
} from "../../../services/scorecard/scorecard.service";
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation";

const CreateScorecard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // ✅ Get edit data from navigation state
  const editData = location.state?.item;
  const isEditMode = location.state?.isEdit || false;

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isCloneMode, setIsCloneMode] = useState(false);
  const [isDataLoading, setIsDataLoading] = useState(true);

  // ✅ Refs for dropdowns
  const yearRef = useRef(null);
  const marketAreaRef = useRef(null);
  const dealerRef = useRef(null);
  const frequencyRef = useRef(null);
  const quarterRef = useRef(null);
  const leadAuditorRef = useRef(null);
  const coAuditorRef = useRef(null);
  const auditLocationRef = useRef(null);

  // ✅ State for API data
  const [marketAreas, setMarketAreas] = useState([]);
  const [dealers, setDealers] = useState([]);
  const [filteredDealers, setFilteredDealers] = useState([]);
  const [auditors, setAuditors] = useState([]);

  // Form data
  const [formData, setFormData] = useState({
    id: null,
    year: "",
    marketarea: "",
    marketAreaId: null,
    dealer: "",
    dealerId: null,
    frequency: "",
    quarter: "",
    auditStartDate: "",
    auditEndDate: "",
    physicalAuditStartDate: "",
    physicalAuditEndDate: "",
    leadAuditor: "",
    leadAuditorId: null,
    coAuditor: "",
    coAuditorId: null,
    auditLocation: "",
    branch: "",
    branchId: null,
    remarks: "",
  });

  // Dropdown states
  const [dropdowns, setDropdowns] = useState({
    year: false,
    marketarea: false,
    dealer: false,
    frequency: false,
    quarter: false,
    leadAuditor: false,
    coAuditor: false,
    auditLocation: false,
  });

  // Year options (current year + 10 years)
  const currentYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 11 }, (_, i) => ({
    label: String(currentYear + i),
    value: String(currentYear + i),
  }));

  const frequencyOptions = [
    { label: "Annual", value: "Annual" },
    { label: "Quarterly", value: "Quarterly" },
  ];

  // ⭐ Quarter options for Quarterly frequency (Q1, Q2, Q3)
  const quarterOptions = [
    { label: "Q1", value: "Q1" },
    { label: "Q2", value: "Q2" },
    { label: "Q3", value: "Q3" },
  ];

  // ⭐ Quarter option for Annual frequency (Q4 only - displayed as disabled)
  const annualQuarterOptions = [
    { label: "Q4", value: "Q4" },
  ];

  const auditLocationOptions = [
    { label: "HQ", value: "HQ" },
    { label: "Branch", value: "Branch" },
  ];
const isCreateMode = !isEditMode && !isCloneMode;
  // ✅ Load data from APIs on component mount
  useEffect(() => {
    const loadData = async () => {
      try {
        setIsDataLoading(true);

        // Fetch market areas and dealers
        const [marketAreasData, dealersData] = await Promise.all([
          getMarketAreas(),
          getDealers(),
        ]);

        console.log("Raw Market Areas Response:", marketAreasData);
        console.log("Raw Dealers Response:", dealersData);

        // ✅ Filter only active items - handle different response structures
        const rawMarketAreas = marketAreasData?.data?.data || marketAreasData?.data || marketAreasData || [];
        const rawDealers = dealersData?.data?.data || dealersData?.data || dealersData || [];

        const activeMarketAreas = rawMarketAreas.filter(
          (ma) => ma.isActive === 1
        );
        const activeDealers = rawDealers.filter(
          (d) => d.isActive === 1
        );

        console.log("Active Market Areas:", activeMarketAreas);
        console.log("Active Dealers:", activeDealers);

        setMarketAreas(activeMarketAreas);
        setDealers(activeDealers);

        // ⭐ Fetch auditors from API
        try {
          const auditorsData = await getAuditors();
          console.log("Auditors loaded:", auditorsData);
          setAuditors(auditorsData);
        } catch (auditorError) {
          console.warn("Failed to load auditors, using mock data:", auditorError);
          // Fallback mock auditors
          const mockAuditors = [
            { id: 1, label: "John Doe", value: "John Doe" },
            { id: 2, label: "Emma Smith", value: "Emma Smith" },
            { id: 3, label: "Robert Brown", value: "Robert Brown" },
          ];
          setAuditors(mockAuditors);
        }

        console.log("✅ Data loaded successfully");
      } catch (error) {
        console.error("Error loading data:", error);
        setErrors({ data: "Failed to load market areas, dealers, and other data." });
      } finally {
        setIsDataLoading(false);
      }
    };

    loadData();
  }, []);

  // ✅ Populate form data in edit mode after data is loaded
  useEffect(() => {
     if (isEditMode === true && editData && !isDataLoading && marketAreas.length > 0 && dealers.length > 0) {
      console.log("✅ Populating edit data:", editData);

      // Find market area
      const selectedMarket = marketAreas.find(
        (ma) => ma.id === editData.marketAreaId || ma.marketarea === editData.marketArea
      );

      // Filter dealers for the market area
      const filtered = dealers.filter(
        (dealer) => dealer.market_id === selectedMarket?.id
      );
      setFilteredDealers(filtered);

      // Find dealer
      const selectedDealer = filtered.find(
        (d) => d.id === editData.dealerId || d.dealerName === editData.dealer
      );

      // Find auditors
      const selectedLeadAuditor = auditors.find(
        (a) => a.id === editData.leadAuditorId || a.value === editData.leadAuditor
      );
      const selectedCoAuditor = auditors.find(
        (a) => a.id === editData.coAuditorId || a.value === editData.coAuditor
      );

      // ⭐ Populate form data - use Raw dates for form inputs (YYYY-MM-DD format)
      setFormData({
        id: editData.id, // ✅ Store ID for update
        year: editData.year || "",
        marketarea: editData.marketArea || selectedMarket?.marketarea || "",
        marketAreaId: editData.marketAreaId || selectedMarket?.id || null,
        dealer: editData.dealer || selectedDealer?.dealerName || "",
        dealerId: editData.dealerId || selectedDealer?.id || null,
        frequency: editData.frequency || "",
        quarter: editData.quarter || editData.quarterFrequency || "",
        // ⭐ Use Raw dates for form inputs (YYYY-MM-DD format required by input type="date")
        auditStartDate: editData.auditStartDateRaw || editData.auditStartDate || "",
        auditEndDate: editData.auditEndDateRaw || editData.auditEndDate || "",
        physicalAuditStartDate: editData.physicalAuditStartDateRaw || editData.physicalAuditStartDate || "",
        physicalAuditEndDate: editData.physicalAuditEndDateRaw || editData.physicalAuditEndDate || "",
        leadAuditor: editData.leadAuditor || selectedLeadAuditor?.value || "",
        leadAuditorId: editData.leadAuditorId || selectedLeadAuditor?.id || null,
        coAuditor: editData.coAuditor || selectedCoAuditor?.value || "",
        coAuditorId: editData.coAuditorId || selectedCoAuditor?.id || null,
        auditLocation: editData.auditLocation || "",
        branch: editData.branch || "", // ⭐ Populate branch from API data
        branchId: editData.branchId || null,
        remarks: editData.remarks || "",
      });
    }
  }, [isEditMode, editData, isDataLoading, marketAreas, dealers, auditors]);
useEffect(() => {
  if (!isEditMode && !isCloneMode) {
    setFormData({
      id: null,
      year: "",
      marketarea: "",
      marketAreaId: null,
      dealer: "",
      dealerId: null,
      frequency: "",
      quarter: "",
      auditStartDate: "",
      auditEndDate: "",
      physicalAuditStartDate: "",
      physicalAuditEndDate: "",
      leadAuditor: "",
      leadAuditorId: null,
      coAuditor: "",
      coAuditorId: null,
      auditLocation: "",
      branch: "",
      branchId: null,
      remarks: "",
    });

    setFilteredDealers([]);
    setErrors({});
  }
}, [isEditMode, isCloneMode]);
  // Close dropdowns when clicking outside
  useEffect(() => {
    const refs = [
      yearRef,
      marketAreaRef,
      dealerRef,
      frequencyRef,
      quarterRef,
      leadAuditorRef,
      coAuditorRef,
      auditLocationRef,
    ];

    const handleClickOutside = (event) => {
      const clickedInside = refs.some(
        (ref) => ref.current && ref.current.contains(event.target)
      );

      if (!clickedInside) {
        setDropdowns((prev) =>
          Object.keys(prev).reduce((acc, key) => {
            acc[key] = false;
            return acc;
          }, {})
        );
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // ✅ Handle market area selection with dealer filtering
  const handleMarketAreaSelect = (value) => {
    const selectedArea = marketAreas.find((area) => area.marketarea === value);
    
    console.log("Selected Market Area:", selectedArea);
    
    setFormData((prev) => ({
      ...prev,
      marketarea: value,
      marketAreaId: selectedArea?.id || null,
      dealer: "",
      dealerId: null,
    }));

    // Filter dealers based on selected market area
    const filtered = dealers.filter((dealer) => dealer.market_id === selectedArea?.id);
    
    console.log("Filtered Dealers for market_id", selectedArea?.id, ":", filtered);
    
    setFilteredDealers(filtered);
    setErrors((prev) => ({ ...prev, marketarea: "" }));
  };

  // ⭐ Handle frequency change - auto-set Q4 for Annual
  const handleFrequencyChange = (value) => {
    if (isEditMode) return;

    setFormData((prev) => ({
      ...prev,
      frequency: value,
      // ⭐ Auto-set Q4 when Annual is selected, clear when Quarterly
      quarter: value === "Annual" ? "Q4" : "",
    }));
    setErrors((prev) => ({ ...prev, frequency: "", quarter: "" }));
  };

  // ✅ Validation function
  const validateForm = () => {
    const newErrors = {};

    if (!isEditMode && !formData.year)
      newErrors.year = "Please fill out this field";
    if (!isEditMode && !formData.marketarea)
      newErrors.marketarea = "Please fill out this field";
    if (!isEditMode && !formData.dealer)
      newErrors.dealer = "Please fill out this field";
    if (!isEditMode && !formData.frequency)
      newErrors.frequency = "Please fill out this field";
    // ⭐ Quarter validation - only for Quarterly frequency (Annual auto-sets Q4)
    if (formData.frequency === "Quarterly" && !formData.quarter)
      newErrors.quarter = "Please fill out this field";
    if (!formData.auditStartDate)
      newErrors.auditStartDate = "Please fill out this field";
    if (!formData.auditEndDate) 
      newErrors.auditEndDate = "Please fill out this field";
    if (!formData.physicalAuditStartDate)
      newErrors.physicalAuditStartDate = "Please fill out this field";
    if (!formData.physicalAuditEndDate)
      newErrors.physicalAuditEndDate = "Please fill out this field";
    if (!formData.leadAuditor) 
      newErrors.leadAuditor = "Please fill out this field";
    if (!formData.coAuditor) 
      newErrors.coAuditor = "Please fill out this field";
    if (!formData.auditLocation)
      newErrors.auditLocation = "Please fill out this field";
    // Branch is optional - no validation needed
   

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // ✅ Save handler with API integration (Create or Update)
  const handleSave = async (e) => {
  if (e) e.preventDefault();

    // Close all dropdowns
    setDropdowns(
      Object.keys(dropdowns).reduce((acc, key) => ({ ...acc, [key]: false }), {})
    );

    if (!validateForm()) {
      window.scrollTo(0, 0);
      return;
    }

    setIsLoading(true);

    try {
      // Prepare data for API - match backend field names exactly
      const scorecardData = {
        year: formData.year,
        market_area_id: formData.marketAreaId,
        dealer_id: formData.dealerId,
        frequency: formData.frequency,
        // ⭐ Use formData.quarter directly (already set to Q4 for Annual)
        quarter_frequency: formData.quarter,
        audit_start_date: formData.auditStartDate,
        audit_end_date: formData.auditEndDate,
        physical_audit_start_date: formData.physicalAuditStartDate,
        physical_audit_end_date: formData.physicalAuditEndDate,
        lead_auditor: formData.leadAuditorId,
        co_auditor: formData.coAuditorId,
        audit_location: formData.auditLocation,
        branch: formData.branch || null, // ⭐ Add branch field
        remarks: formData.remarks,
      };

      console.log(
        isEditMode ? "✅ Updating scorecard:" : "✅ Creating scorecard:",
        scorecardData
      );

      if (isEditMode) {
        // ✅ UPDATE EXISTING SCORECARD
        if (!formData.id) {
          throw new Error("Scorecard ID is missing for update");
        }

        await updateScorecard(formData.id, scorecardData);
        console.log("✅ Scorecard updated successfully");
      } else {
        // ✅ CREATE NEW SCORECARD
        await addScorecard(scorecardData);
        console.log("✅ Scorecard created successfully");
      }

      // Success - navigate to view page
      window.scrollTo(0, 0);
      navigate("/scorecard/viewreview", { 
        state: { 
          ...formData,
          isUpdated: isEditMode 
        } 
      });
    } catch (error) {
      console.error(
        isEditMode ? "Error updating scorecard:" : "Error creating scorecard:",
        error
      );
      setErrors({ 
        submit: error.message || `Failed to ${isEditMode ? "update" : "create"} scorecard` 
      });
      window.scrollTo(0, 0);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
  // Always reset form
  setFormData({
    id: null,
    year: "",
    marketarea: "",
    marketAreaId: null,
    dealer: "",
    dealerId: null,
    frequency: "",
    quarter: "",
    auditStartDate: "",
    auditEndDate: "",
    physicalAuditStartDate: "",
    physicalAuditEndDate: "",
    leadAuditor: "",
    leadAuditorId: null,
    coAuditor: "",
    coAuditorId: null,
    auditLocation: "",
    branch: "",
    branchId: null,
    remarks: "",
  });

  setErrors({});
  setFilteredDealers([]);
  window.scrollTo(0, 0);

  if (isCloneMode) {
    // 🔥 IMPORTANT: stay on same page
    setIsCloneMode(false);
    return;
  }

  // 🔥 Only for add/edit → go to view page
  navigate("/scorecard/viewreview");
};
  const formRef = useRef(null);
useKeyboardNavigation({
  containerRef: formRef, // your popup div ref

 handleSubmit: handleSave,
  onCancel: handleCancel,
});

  // ✅ Clone handler - fetches latest scorecard from API
  const handleClone = async () => {
    try {
      console.log("=== Starting Clone Process ===");

      if (isDataLoading) {
        alert("Please wait for data to load before cloning.");
        return;
      }

      if (marketAreas.length === 0 || dealers.length === 0) {
        alert("Required data not loaded. Please refresh the page.");
        return;
      }

      // ⭐ Fetch all scorecards and get the latest one
      let apiData = null;
      try {
        const allScorecards = await getAllScorecards();
        if (allScorecards && allScorecards.length > 0) {
          // Get the most recent scorecard (first item since sorted by id DESC)
          apiData = allScorecards[0];
          console.log("✅ Latest scorecard fetched:", apiData);
        }
      } catch (fetchError) {
        console.warn("Failed to fetch scorecards, using mock data:", fetchError);
      }

      // Fallback to mock data if API fails
      if (!apiData) {
        apiData = {
          id: 123,
          year: "2024",
          marketAreaId: marketAreas[0]?.id,
          marketArea: marketAreas[0]?.marketarea,
          dealerId: null,
          dealer: null,
          frequency: "Quarterly",
          quarter: "Q4",
          auditStartDateRaw: "2024-12-01",
          auditEndDateRaw: "2024-12-15",
          physicalAuditStartDateRaw: "2024-11-28",
          physicalAuditEndDateRaw: "2024-12-20",
          leadAuditorId: auditors[0]?.id || 1,
          leadAuditor: auditors[0]?.value || "John Doe",
          coAuditorId: auditors[1]?.id || 2,
          coAuditor: auditors[1]?.value || "Emma Smith",
          auditLocation: "Branch",
          branchId: 1,
          branch: "Branch 1",
          remarks: "Q4 2024 Audit - Original Record",
        };
      }

      const selectedMarketArea = marketAreas.find(
        (ma) => ma.id === apiData.marketAreaId
      );

      const filtered = dealers.filter(
        (dealer) => dealer.market_id === apiData.marketAreaId
      );

      let selectedDealer = null;
      if (apiData.dealerId) {
        selectedDealer = filtered.find((d) => d.id === apiData.dealerId);
      }

      if (!selectedDealer && filtered.length > 0) {
        selectedDealer = filtered[0];
      }

      // ⭐ Determine quarter based on frequency
      let clonedQuarter = apiData.quarter || apiData.quarterFrequency || "";
      if (apiData.frequency === "Annual") {
        clonedQuarter = "Q4";
      }

      // ⭐ Use Raw dates for form inputs
      const clonedFormData = {
        id: null, // ⭐ Clear ID for new record
        year: apiData.year || "",
        marketarea: selectedMarketArea?.marketarea || apiData.marketArea || "",
        marketAreaId: apiData.marketAreaId || null,
        dealer: selectedDealer?.dealerName || apiData.dealer || "",
        dealerId: selectedDealer?.id || apiData.dealerId || null,
        frequency: apiData.frequency || "",
        quarter: clonedQuarter,
        auditStartDate: apiData.auditStartDateRaw || apiData.auditStartDate || "",
        auditEndDate: apiData.auditEndDateRaw || apiData.auditEndDate || "",
        physicalAuditStartDate: apiData.physicalAuditStartDateRaw || apiData.physicalAuditStartDate || "",
        physicalAuditEndDate: apiData.physicalAuditEndDateRaw || apiData.physicalAuditEndDate || "",
        leadAuditor: apiData.leadAuditor || "",
        leadAuditorId: apiData.leadAuditorId || null,
        coAuditor: apiData.coAuditor || "",
        coAuditorId: apiData.coAuditorId || null,
        auditLocation: apiData.auditLocation || "",
        branch: apiData.branch || "",
        branchId: apiData.branchId || null,
        remarks: `${apiData.remarks || ""} (Cloned)`,
      };

      setFilteredDealers(filtered);
      setFormData(clonedFormData);
      setIsCloneMode(true);
      setErrors({});

      window.scrollTo({ top: 0, behavior: "smooth" });

      console.log("✅ Clone successful");
    } catch (error) {
      console.error("❌ Error cloning scorecard:", error);
      alert(`Failed to clone scorecard: ${error.message || "Unknown error"}`);
    }
  };

  return (
    <div className="w-full flex justify-center">
      <div
    
       className="w-full max-w-7xl">
        {/* ===== Title ===== */}
        <div className="w-full flex items-center justify-between px-2 mb-2">
          <h2 className="text-center text-xl font-semibold text-darkblue1 font-VolvoNovum flex-1 text-center">
            {isEditMode 
              ? "Edit Review" 
              : isCloneMode 
              ? "Cloned Review" 
              : "Create Review"}
          </h2>

          {!isCloneMode && !isEditMode && (
            <>
              {/* Desktop Clone Button */}
              <div className="hidden md:block">
                <button
                  onClick={handleClone}
                  disabled={isDataLoading}
                  className={`flex items-center justify-center gap-2 text-xs font-medium px-6 py-1 bg-lightBlue text-mildBlue hover:bg-white hover:border hover:border-mildBlue transition ${
                    isDataLoading ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"  className="w-3.5 h-3.5">
<rect x="0.5" y="0.5" width="10.0003" height="13.6086" stroke="#204D80"/>
<path d="M3 5L6 5" stroke="#204D80" stroke-linecap="round"/>
<path d="M3 7L7 7" stroke="#204D80" stroke-linecap="round"/>
<path d="M3 9H8" stroke="#204D80" stroke-linecap="round"/>
<rect x="13.5" y="9.89136" width="10.0003" height="13.6086" stroke="#204D80"/>
<path d="M16 14.3914L19 14.3914" stroke="#204D80" stroke-linecap="round"/>
<path d="M16 16.3914L20 16.3914" stroke="#204D80" stroke-linecap="round"/>
<path d="M16 18.3914H21" stroke="#204D80" stroke-linecap="round"/>
<path d="M5.5 15.6523V19.8262H10.5002" stroke="#204D80" stroke-linecap="round"/>
<path d="M11.7558 19.4864C11.8298 19.5242 11.8915 19.5798 11.9345 19.6472C11.9775 19.7147 12.0001 19.7917 12.0001 19.8701C12.0001 19.9486 11.9775 20.0255 11.9345 20.093C11.8915 20.1605 11.8298 20.2161 11.7558 20.2539L8.6125 21.8591C8.5407 21.8957 8.45987 21.9143 8.37796 21.9131C8.29606 21.9118 8.21591 21.8908 8.14542 21.8521C8.07493 21.8133 8.01652 21.7582 7.97595 21.6921C7.93538 21.626 7.91405 21.5513 7.91406 21.4752V18.2648C7.91408 18.1887 7.93544 18.114 7.97605 18.0479C8.01666 17.9818 8.07511 17.9267 8.14564 17.888C8.21617 17.8492 8.29635 17.8283 8.37827 17.8271C8.46019 17.8259 8.54103 17.8446 8.61281 17.8812L11.7558 19.4864Z" fill="#204D80"/>
<path d="M12.2444 3.74641C12.1704 3.78419 12.1087 3.83972 12.0657 3.90722C12.0227 3.97472 12 4.0517 12 4.13011C12 4.20853 12.0227 4.28551 12.0657 4.35301C12.1087 4.42051 12.1704 4.47604 12.2444 4.51382L15.3877 6.11897C15.4595 6.15559 15.5404 6.1742 15.6223 6.17298C15.7042 6.17175 15.7843 6.15073 15.8548 6.11199C15.9253 6.07325 15.9837 6.01812 16.0243 5.95204C16.0649 5.88595 16.0862 5.81119 16.0862 5.73513V2.52481C16.0862 2.44873 16.0648 2.37396 16.0242 2.30787C15.9836 2.24179 15.9251 2.18668 15.8546 2.14796C15.7841 2.10924 15.7039 2.08826 15.622 2.08709C15.54 2.08591 15.4592 2.10458 15.3874 2.14125L12.2444 3.74641Z" fill="#204D80"/>
<path d="M13.9863 4.17401H18.9865V8.3479" stroke="#204D80" stroke-linecap="round"/>
</svg>
                  {isDataLoading ? "Loading..." : "Clone"}
                </button>
              </div>

              {/* Mobile Clone Button */}
              <div className="md:hidden border border-black  group">
                <button
                  onClick={handleClone}
                  disabled={isDataLoading}
                  className={`p-2  hover:bg-lightBlue relative ${
                    isDataLoading ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Kpimaster/clone.png"
                    alt="Clone"
                    className="w-4 h-4"
                  />
                  <span className="absolute -bottom-8 right-0 bg-black text-white text-xs  px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                    {isDataLoading ? "Loading..." : "Clone"}
                  </span>
                </button>
              </div>
            </>
          )}
        </div>

        {/* ===== Form ===== */}
        <form 
           ref={formRef}
        onSubmit={handleSave}>
          <div className="border border-black/30 p-2 space-y-0 bg-white">
            {/* === Row 1: Audit Info === */}
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-darkblue1 mb-0 font-VolvoNovum">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="23" viewBox="0 0 20 23" fill="none" className="w-4 h-4">
<path d="M14.875 2.625H19.25V22.75H0V2.625H4.375V4.375H14.875V2.625ZM3.5 11.375H15.75V9.625H3.5V11.375ZM3.5 18.375H15.75V16.625H3.5V18.375ZM6.125 2.625V0H13.125V2.625H6.125Z" fill="#1B365D"/>
</svg>
                Audit Info
              </h3>

              {/* ⭐ Updated grid - always show 5 columns when frequency is selected */}
              <div
                className={`grid gap-4 sm:grid-cols-2 mb-2 lg:${
                  formData.frequency ? "grid-cols-5" : "grid-cols-4"
                }`}
              >
                <div>
                  <StyledSelectField
                    label="Year"
                    required={true} 
                    placeholder="Select Year"
                    value={formData.year}
                    setValue={(v) => {
                      if (!isEditMode) {
                        setFormData({ ...formData, year: v });
                        setErrors((prev) => ({ ...prev, year: "" }));
                      }
                    }}
                    options={yearOptions}
                    dropdownOpen={dropdowns.year}
                    setDropdownOpen={(val) =>
                      !isEditMode && setDropdowns({ ...dropdowns, year: val })
                    }
                    dropdownRef={yearRef}
                    error={!isEditMode ? errors.year : ""}
                    disabled={isEditMode}
                  />
                </div>

                <div>
                  <StyledSelectField
                    label="Market Area"
                    placeholder="Select Market Area"
                    required={true}
                    value={formData.marketarea}
                    setValue={(v) => {
                      if (!isEditMode) {
                        handleMarketAreaSelect(v);
                      }
                    }}
                    options={marketAreas.map(ma => ({
                      label: ma.marketarea,
                      value: ma.marketarea
                    }))}
                    dropdownOpen={dropdowns.marketarea}
                    setDropdownOpen={(val) =>
                      !isEditMode && setDropdowns({ ...dropdowns, marketarea: val }) 
                    }
                    dropdownRef={marketAreaRef}
                    error={!isEditMode ? errors.marketarea : ""} 
                    disabled={isEditMode || isDataLoading}        
                  />
                </div>

                <div>
                  <StyledSelectField
                    label="Dealer"
                    placeholder="Select Dealer"
                    required={true}
                    value={formData.dealer}
                    setValue={(v) => {
                      if (!isEditMode) {
                        const selectedDealer = filteredDealers.find((d) => d.dealerName === v);
                        setFormData({
                          ...formData,
                          dealer: v,
                          dealerId: selectedDealer?.id || null,
                        });
                        setErrors((prev) => ({ ...prev, dealer: "" }));
                      }
                    }}
                    options={filteredDealers.map((d) => ({
                      label: d.dealerName,
                      value: d.dealerName,
                    }))}
                    dropdownOpen={dropdowns.dealer}
                    setDropdownOpen={(val) =>
                      !isEditMode && setDropdowns({ ...dropdowns, dealer: val })
                    }
                    dropdownRef={dealerRef}
                    error={!isEditMode ? errors.dealer : ""}
                    disabled={isEditMode || isDataLoading || filteredDealers.length === 0} 
                  />
                </div>

                <div>
                  <StyledSelectField
                    label="Frequency"
                    placeholder="Select Frequency"
                    required={true}
                    value={formData.frequency}
                    setValue={handleFrequencyChange}
                    options={frequencyOptions}
                    dropdownOpen={dropdowns.frequency}
                    setDropdownOpen={(val) =>
                      !isEditMode && setDropdowns({ ...dropdowns, frequency: val })
                    }
                    dropdownRef={frequencyRef}
                    error={!isEditMode ? errors.frequency : ""}
                    disabled={isEditMode}
                  />
                </div>

                {/* ⭐ Show Quarter field when frequency is selected (both Annual and Quarterly) */}
                {formData.frequency && (
                  <div>
                    <StyledSelectField
                      label="Quarter"
                      required={true}
                      placeholder="Select Quarter"
                      value={formData.quarter}
                      setValue={(v) => {
                        // ⭐ Only allow change if Quarterly (Annual is locked to Q4)
                        if (formData.frequency === "Quarterly") {
                          setFormData({ ...formData, quarter: v });
                          setErrors((prev) => ({ ...prev, quarter: "" }));
                        }
                      }}
                      // ⭐ Show Q4 option for Annual, Q1-Q3 for Quarterly
                      options={formData.frequency === "Annual" ? annualQuarterOptions : quarterOptions}
                      dropdownOpen={dropdowns.quarter}
                      setDropdownOpen={(val) => {
                        // ⭐ Only allow dropdown to open if Quarterly
                        if (formData.frequency === "Quarterly") {
                          setDropdowns({ ...dropdowns, quarter: val });
                        }
                      }}
                      dropdownRef={quarterRef}
                      error={formData.frequency === "Quarterly" ? errors.quarter : ""}
                      // ⭐ Disable for Annual (Q4 is auto-selected and locked)
                      disabled={formData.frequency === "Annual"}
                    />
                  </div>
                )}
              </div>
            </div>

            {/* === Row 2: Audit Date === */}
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-darkblue1 font-VolvoNovum">
               <svg xmlns="http://www.w3.org/2000/svg" width="23" height="25" viewBox="0 0 23 25" fill="none" className="w-4 h-4">
<path d="M20 22.5H2.5V8.75H20M16.25 0V2.5H6.25V0H3.75V2.5H2.5C1.1125 2.5 0 3.6125 0 5V22.5C0 23.163 0.263392 23.7989 0.732233 24.2678C1.20107 24.7366 1.83696 25 2.5 25H20C20.663 25 21.2989 24.7366 21.7678 24.2678C22.2366 23.7989 22.5 23.163 22.5 22.5V5C22.5 4.33696 22.2366 3.70107 21.7678 3.23223C21.2989 2.76339 20.663 2.5 20 2.5H18.75V0M17.5 13.75H11.25V20H17.5V13.75Z" fill="#1B365D"/>
</svg>
                Audit Date 
              </h3>

              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div>
                  <StyledDateField
                    label="Audit Start Date"
                    required  ={true}
                    value={formData.auditStartDate}
                    setValue={(v) => {
                      setFormData({ ...formData, auditStartDate: v });
                      setErrors((prev) => ({ ...prev, auditStartDate: "" }));
                    }}
                    error={errors.auditStartDate}
                  />
                </div>

                <div>
                  <StyledDateField
                    label="Audit End Date"
                     required  ={true}
                    value={formData.auditEndDate}
                    setValue={(v) => {
                      setFormData({ ...formData, auditEndDate: v });
                      setErrors((prev) => ({ ...prev, auditEndDate: "" }));
                    }}
                    error={errors.auditEndDate}
                    min={formData.auditStartDate}
                  />
                </div>

                <div>
                  <StyledDateField
                    label="Physical Audit Start Date"
                     required  ={true}
                    value={formData.physicalAuditStartDate}
                    setValue={(v) => {
                      setFormData({ ...formData, physicalAuditStartDate: v });
                      setErrors((prev) => ({ ...prev, physicalAuditStartDate: "" }));
                    }}
                    error={errors.physicalAuditStartDate}
                  />
                </div>

                <div>
                  <StyledDateField
                    label="Physical Audit End Date"
                    required  ={true}
                    value={formData.physicalAuditEndDate}
                    setValue={(v) => {
                      setFormData({ ...formData, physicalAuditEndDate: v });
                      setErrors((prev) => ({ ...prev, physicalAuditEndDate: "" }));
                    }}
                    error={errors.physicalAuditEndDate}
                    min={formData.physicalAuditStartDate}
                  />
                </div>
              </div>
            </div>

            {/* === Row 3: Auditor Info === */}
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-darkblue1 font-VolvoNovum">
                <svg xmlns="http://www.w3.org/2000/svg" width="27" height="17" viewBox="0 0 27 17" fill="none" className="w-4 h-4">
<path d="M13.5 0C14.5443 0 15.5458 0.414843 16.2842 1.15327C17.0227 1.89169 17.4375 2.89321 17.4375 3.9375C17.4375 4.98179 17.0227 5.98331 16.2842 6.72173C15.5458 7.46016 14.5443 7.875 13.5 7.875C12.4557 7.875 11.4542 7.46016 10.7158 6.72173C9.97734 5.98331 9.5625 4.98179 9.5625 3.9375C9.5625 2.89321 9.97734 1.89169 10.7158 1.15327C11.4542 0.414843 12.4557 0 13.5 0ZM5.625 2.8125C6.255 2.8125 6.84 2.98125 7.34625 3.285C7.1775 4.89375 7.65 6.49125 8.6175 7.74C8.055 8.82 6.93 9.5625 5.625 9.5625C4.72989 9.5625 3.87145 9.20692 3.23851 8.57399C2.60558 7.94105 2.25 7.08261 2.25 6.1875C2.25 5.29239 2.60558 4.43395 3.23851 3.80101C3.87145 3.16808 4.72989 2.8125 5.625 2.8125ZM21.375 2.8125C22.2701 2.8125 23.1286 3.16808 23.7615 3.80101C24.3944 4.43395 24.75 5.29239 24.75 6.1875C24.75 7.08261 24.3944 7.94105 23.7615 8.57399C23.1286 9.20692 22.2701 9.5625 21.375 9.5625C20.07 9.5625 18.945 8.82 18.3825 7.74C19.3629 6.47351 19.8182 4.87818 19.6537 3.285C20.16 2.98125 20.745 2.8125 21.375 2.8125ZM6.1875 14.3438C6.1875 12.015 9.46125 10.125 13.5 10.125C17.5387 10.125 20.8125 12.015 20.8125 14.3438V16.3125H6.1875V14.3438ZM0 16.3125V14.625C0 13.0612 2.12625 11.745 5.00625 11.3625C4.3425 12.1275 3.9375 13.185 3.9375 14.3438V16.3125H0ZM27 16.3125H23.0625V14.3438C23.0625 13.185 22.6575 12.1275 21.9937 11.3625C24.8737 11.745 27 13.0612 27 14.625V16.3125Z" fill="#1B365D"/>
</svg>
                Auditor Info
              </h3>

              <div
                className={`grid gap-4 sm:grid-cols-2 lg:grid-cols-${
                  formData.auditLocation === "Branch" ? "4" : "3"
                } mb-2`}
              >
                <div>
                  <StyledSelectField
                    label="Lead Auditor"
                    placeholder="Select Lead Auditor"
                    required  ={true}
                    value={formData.leadAuditor}
                    setValue={(v) => {
                      const selectedAuditor = auditors.find((a) => a.value === v);
                      setFormData({
                        ...formData,
                        leadAuditor: v,
                        leadAuditorId: selectedAuditor?.id || null,
                      });
                      setErrors((prev) => ({ ...prev, leadAuditor: "" }));
                    }}
                    options={auditors}
                    dropdownOpen={dropdowns.leadAuditor}
                    setDropdownOpen={(val) =>
                      setDropdowns({ ...dropdowns, leadAuditor: val })
                    }
                    dropdownRef={leadAuditorRef}
                    error={errors.leadAuditor}
                  />
                </div>

                <div>
                  <StyledSelectField
                    label="Co Auditor"
                    required  ={true}
                    placeholder="Select Co Auditor"
                    value={formData.coAuditor}
                    setValue={(v) => {
                      const selectedAuditor = auditors.find((a) => a.value === v);
                      setFormData({
                        ...formData,
                        coAuditor: v,
                        coAuditorId: selectedAuditor?.id || null,
                      });
                      setErrors((prev) => ({ ...prev, coAuditor: "" }));
                    }}
                    options={auditors}
                    dropdownOpen={dropdowns.coAuditor}
                    setDropdownOpen={(val) =>
                      setDropdowns({ ...dropdowns, coAuditor: val })
                    }
                    dropdownRef={coAuditorRef}
                    error={errors.coAuditor}
                  />
                </div>

                <div>
                  <StyledSelectField
                    label="Audit Location"
                    required  ={true}
                    placeholder="Select Audit Location"
                    value={formData.auditLocation}
                    setValue={(v) => {
                      setFormData({
                        ...formData,
                        auditLocation: v,
                        branch: "",
                        branchId: null,
                      });
                      setErrors((prev) => ({ ...prev, auditLocation: "" }));
                    }}
                    options={auditLocationOptions}
                    dropdownOpen={dropdowns.auditLocation}
                    setDropdownOpen={(val) =>
                      setDropdowns({ ...dropdowns, auditLocation: val })
                    }
                    dropdownRef={auditLocationRef}
                    error={errors.auditLocation}
                  />
                </div>

                {formData.auditLocation === "Branch" && (
                  <div>
                    <label className="block text-xs font-medium text-black mb-1">
                      Branch   
       <span className="text-red1">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="Enter Branch Name"
                      value={formData.branch}
                      onChange={(e) => {
                        setFormData({
                          ...formData,
                          branch: e.target.value,
                        });
                        setErrors((prev) => ({ ...prev, branch: "" }));
                      }}
                      className="w-full border border-black/30 px-3 py-1.5 text-xs focus:border-black/30 focus:ring-1 focus:ring-black/30 outline-none"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* === Row 4: Remarks === */}
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-darkblue1 mb-2 font-VolvoNovum">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" className="w-4 h-4">
<path d="M4 6H2V20C2 20.5304 2.21071 21.0391 2.58579 21.4142C2.96086 21.7893 3.46957 22 4 22H18V20H4V6ZM18.7 7.35L17.7 8.35L15.65 6.3L16.65 5.3C16.86 5.08 17.21 5.08 17.42 5.3L18.7 6.58C18.92 6.79 18.92 7.14 18.7 7.35ZM9 12.94L15.06 6.88L17.12 8.94L11.06 15H9V12.94ZM20 4V16H8V4H20ZM20 2H8C6.9 2 6 2.9 6 4V16C6 17.1 6.9 18 8 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2Z" fill="#1B365D"/>
</svg>
                Remarks
              </h3>

              <textarea
                placeholder="Enter remarks here..."
                value={formData.remarks}
                onChange={(e) => {
                  setFormData({ ...formData, remarks: e.target.value });
                  setErrors((prev) => ({ ...prev, remarks: "" }));
                }}
                className={`w-full border ${
                  errors.remarks ? "border-red1" : "border-black/30"
                } px-3 py-1.5 text-xs focus:border-black/30 focus:ring-1 focus:ring-black/30 outline-none resize-none h-24`}
              ></textarea>
              
            </div>
          </div>

          {/* Data Loading Error */}
          {errors.data && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 ">
              <p className="text-red-600 text-xs">{errors.data}</p>
            </div>
          )}

          {/* API Error */}
          {errors.submit && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 ">
              <p className="text-red-600 text-xs">{errors.submit}</p>
            </div>
          )}

          {/* === Action Buttons === */}
          <div className="w-full flex justify-end gap-3 mt-2">
            <button
              type="button"
              onClick={handleCancel}
              className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium hover:bg-mildBlue1 hover:scale-105"
            >
               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 18 20" fill="none"className="w-3 h-3">
<path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
              Cancel
            </button>

            <button
              type="submit"
              disabled={isLoading || isDataLoading}
              className={`text-xs font-medium px-8 py-1.5  transition ${
                isLoading || isDataLoading
                  ? "bg-gray-400 text-white cursor-not-allowed"
                  : "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
              }`}
            >
              {isLoading 
                ? "Saving..." 
                : isEditMode 
                ? "Update" 
                : "Save"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateScorecard;