import React, { useState } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import Scoring from "./Scoring";

const ScoringHome = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      {/* Navigation Bar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      
      {/* Main Content - Moves Right when Sidebar Opens */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex-1 flex flex-col
          overflow-hidden
        `}
      >
        {/* Content Container with proper spacing */}
        <div className="flex-1 overflow-y-auto mt-[4.5rem] sm:mt-[5rem] lg:mt-[6rem] px-2 sm:px-4 lg:px-6 pb-4">
          <Scoring />
        </div>
      </div>
    </div>
  );
};

export default ScoringHome;