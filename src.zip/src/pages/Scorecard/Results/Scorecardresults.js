import React, { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, LabelList } from "recharts";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { Menu, Download, X, ArrowLeft, RefreshCw } from "lucide-react";
import Filter from "../../../Components/Filter";
import Searchinput from "../../../Components/Searchinput";
import * as XLSX from "xlsx";
import { ChevronDown,ChevronUp,ChevronsUpDown,ArrowUp,ArrowDown } from "lucide-react";

// ═══════════════════════════════════════════════════════════════
// 📡 API SERVICE IMPORTS
// ═══════════════════════════════════════════════════════════════
import { getAllScorecardScoreViews } from "../../../services/scorecard/scoringScoreView.service";

const ScorecardResults = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showChartMenu, setShowChartMenu] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const chartRef = useRef(null);
  const chartContainerRef = useRef(null);
  const menuRef = useRef(null);
  const observerRef = useRef();
  const tableContainerRef = useRef(null);

  // ═══════════════════════════════════════════════════════════════
  // 📊 STATE MANAGEMENT
  // ═══════════════════════════════════════════════════════════════
  const [allTableData, setAllTableData] = useState([]);
  const [rawApiData, setRawApiData] = useState([]); // Store raw API data for drill-down
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [isLazyLoading, setIsLazyLoading] = useState(false);
  const [error, setError] = useState(null);
  const ITEMS_PER_LOAD = 10;

  // ═══════════════════════════════════════════════════════════════
  // 🔍 DRILL-DOWN STATE
  // ═══════════════════════════════════════════════════════════════
  const [drillDownOpen, setDrillDownOpen] = useState(false);
  const [drillDownData, setDrillDownData] = useState(null);
  const [showDrillDownMenu, setShowDrillDownMenu] = useState(false);
  const drillDownMenuRef = useRef(null);
  const drillDownChartRef = useRef(null);
  const drillDownChartContainerRef = useRef(null);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  // Filter states
  const [filters, setFilters] = useState({
    year: [],
    quarter: [],
    marketArea: [],
    dealer: [],
    strategicObjective: [],
    subKPI: [],
  });

  // Filter options (will be populated from API data)
  const [filterOptions, setFilterOptions] = useState({
    years: [],
    quarters: ["Q1", "Q2", "Q3", "Q4"],
    marketAreas: [],
    dealers: [],
    strategicObjectives: [],
    subKPIs: [],
  });
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH DATA FROM API
  // ═══════════════════════════════════════════════════════════════
  const fetchScorecardData = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const data = await getAllScorecardScoreViews();

      console.log("📊 Scorecard Score Views from API:", data.length, "records");
      if (data.length > 0) {
        console.log("📋 Sample record:", data[0]);
      }

      // Store raw data for drill-down functionality
      setRawApiData(data);

      // Group data by Year, Quarter, Strategic Objective, Market Area, and Dealer
      // This allows proper filtering while still aggregating scores
      const groupedData = {};

      data.forEach((item) => {
        const year = item.year || item.scorecardYear || new Date().getFullYear();
        const quarter = item.quarter || item.scorecardQuarter || "Q1";
        const marketArea = item.auditLocation || item.scorecardAuditLocation || "";
        const dealer = item.dealer || item.branch || item.scorecardBranch || "";
        const objective = item.strategicObjective || "";
        const subKpi = item.subKpi || item.subKpiName || "";
        
        const key = `${year}-${quarter}-${objective}-${marketArea}-${dealer}`;

        if (!groupedData[key]) {
          groupedData[key] = {
            id: key,
            year: year,
            quarter: quarter,
            marketArea: marketArea,
            dealer: dealer,
            strategicObjective: objective,
            maxScoreSum: 0,
            finalScoreSum: 0,
            count: 0,
            subKpis: new Set(),
            items: [],
          };
        }

        // Aggregate scores
        groupedData[key].maxScoreSum += parseFloat(item.maxScore) || 0;
        groupedData[key].finalScoreSum += parseFloat(item.finalScore) || 0;
        groupedData[key].count += 1;
        if (subKpi) groupedData[key].subKpis.add(subKpi);
        groupedData[key].items.push(item);
      });

      // Transform grouped data to table format
      const transformedData = Object.values(groupedData).map((group, index) => {
        const achieved = group.maxScoreSum > 0
          ? ((group.finalScoreSum / group.maxScoreSum) * 100).toFixed(2)
          : 0;

        return {
          id: index + 1,
          year: group.year,
          quarter: group.quarter,
          marketArea: group.marketArea,
          dealer: group.dealer,
          strategicObjective: group.strategicObjective,
          subKpis: Array.from(group.subKpis), // Convert Set to Array for filtering
          subKpiCount: group.count, // Number of Sub-KPIs aggregated
          maxScore: group.maxScoreSum.toFixed(2),
          finalScore: group.finalScoreSum.toFixed(2),
          achieved: parseFloat(achieved),
        };
      });

      // Sort by year and quarter
      transformedData.sort((a, b) => {
        if (a.year !== b.year) return b.year - a.year;
        const quarterOrder = { Q1: 1, Q2: 2, Q3: 3, Q4: 4 };
        return quarterOrder[a.quarter] - quarterOrder[b.quarter];
      });

      setAllTableData(transformedData);

      // Extract unique filter options from data
      const years = [...new Set(transformedData.map(item => String(item.year)).filter(Boolean))].sort((a, b) => b - a);
      const quarters = [...new Set(transformedData.map(item => item.quarter).filter(Boolean))].sort();
      const marketAreas = [...new Set(transformedData.map(item => item.marketArea).filter(Boolean))].sort();
      const dealers = [...new Set(transformedData.map(item => item.dealer).filter(Boolean))].sort();
      const strategicObjectives = [...new Set(transformedData.map(item => item.strategicObjective).filter(Boolean))].sort();

      // Extract Sub KPIs from raw data
      const subKPIs = [...new Set(data.map(item => item.subKpi || item.subKpiName).filter(Boolean))].sort();

      setFilterOptions(prev => ({
        ...prev,
        years: years.length > 0 ? years : prev.years,
        quarters: quarters.length > 0 ? quarters : prev.quarters,
        marketAreas,
        dealers,
        strategicObjectives,
        subKPIs,
      }));

      console.log("✅ Transformed data:", transformedData.length, "aggregated records");

    } catch (err) {
      console.error("❌ Error fetching scorecard data:", err);
      setError(err.message || "Failed to load scorecard data");
      setAllTableData([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial fetch
  useEffect(() => {
    fetchScorecardData();
  }, [fetchScorecardData]);

  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔍 FILTERED ITEMS
  // ═══════════════════════════════════════════════════════════════
  const filteredTableData = useMemo(() => {
    return allTableData.filter((row) => {
      // SubKPI filter - check if any of the row's subKpis match the filter
      const matchesSubKPI = filters.subKPI.length === 0 || 
        (row.subKpis && row.subKpis.some(kpi => filters.subKPI.includes(kpi)));

      return (
        (filters.year.length === 0 || filters.year.includes(String(row.year))) &&
        (filters.quarter.length === 0 || filters.quarter.includes(row.quarter)) &&
        (filters.marketArea.length === 0 || filters.marketArea.includes(row.marketArea)) &&
        (filters.dealer.length === 0 || filters.dealer.includes(row.dealer)) &&
        (filters.strategicObjective.length === 0 ||
          filters.strategicObjective.includes(row.strategicObjective)) &&
        matchesSubKPI &&
        (searchTerm === "" ||
          row.strategicObjective?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          row.dealer?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          row.marketArea?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          String(row.year).includes(searchTerm))
      );
    });
  }, [allTableData, filters, searchTerm]);

  // ═══════════════════════════════════════════════════════════════
  // 📈 CHART DATA - Generate from filtered table data
  // ═══════════════════════════════════════════════════════════════
  const chartData = useMemo(() => {
    // Group data by year-quarter and aggregate by strategic objective
    const groupedData = {};

    filteredTableData.forEach((row) => {
      const quarterKey = `${row.year}-${row.quarter}`;

      if (!groupedData[quarterKey]) {
        groupedData[quarterKey] = {
          quarter: quarterKey,
          "Customer Excellence": 0,
          "Business growth & Sustainability": 0,
          "Distribution Excellence": 0,
          "Business Process": 0,
          "People & Culture": 0,
          // Track counts for averaging if multiple entries per objective
          counts: {
            "Customer Excellence": 0,
            "Business growth & Sustainability": 0,
            "Distribution Excellence": 0,
            "Business Process": 0,
            "People & Culture": 0,
          }
        };
      }

      // Map strategic objective to chart category (more precise matching)
      const objectiveName = (row.strategicObjective || "").toLowerCase();
      let chartCategory = null;
      
      // Use exact matching with common variations
      if (objectiveName.includes("customer excellence") || 
          (objectiveName.includes("customer") && !objectiveName.includes("business"))) {
        chartCategory = "Customer Excellence";
      } else if (objectiveName.includes("business growth") || 
                 objectiveName.includes("sustainability") ||
                 objectiveName.includes("growth & sustainability") ||
                 objectiveName.includes("growth and sustainability")) {
        chartCategory = "Business growth & Sustainability";
      } else if (objectiveName.includes("distribution excellence") || 
                 objectiveName.includes("distribution")) {
        chartCategory = "Distribution Excellence";
      } else if (objectiveName.includes("business process") || 
                 (objectiveName.includes("process") && !objectiveName.includes("distribution"))) {
        chartCategory = "Business Process";
      } else if (objectiveName.includes("people") || 
                 objectiveName.includes("culture") ||
                 objectiveName.includes("people & culture") ||
                 objectiveName.includes("people and culture")) {
        chartCategory = "People & Culture";
      }

      // Add to chart data if category matched
      if (chartCategory) {
        groupedData[quarterKey][chartCategory] += parseFloat(row.achieved) || 0;
        groupedData[quarterKey].counts[chartCategory] += 1;
      }
    });

    // Calculate averages and convert to array
    const result = Object.values(groupedData).map(item => {
      const { counts, ...data } = item;
      
      // Average the values if there are multiple entries
      Object.keys(counts).forEach(key => {
        if (counts[key] > 1) {
          data[key] = parseFloat((data[key] / counts[key]).toFixed(2));
        }
      });
      
      return data;
    });

    // Sort by quarter
    return result.sort((a, b) => {
      const [yearA, quarterA] = a.quarter.split('-');
      const [yearB, quarterB] = b.quarter.split('-');

      if (yearA !== yearB) {
        return parseInt(yearA) - parseInt(yearB);
      }

      const quarterOrder = { Q1: 1, Q2: 2, Q3: 3, Q4: 4 };
      return quarterOrder[quarterA] - quarterOrder[quarterB];
    });
  }, [filteredTableData]);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 DRILL-DOWN HANDLER - Click on bar to see dealer breakdown
  // ═══════════════════════════════════════════════════════════════
  const handleBarClick = useCallback((data, index, event, dataKey) => {
    if (!data || !dataKey) return;
    
    const quarterKey = data.quarter; // e.g., "2026-Q1"
    const [year, quarter] = quarterKey.split('-');
    const strategicObjective = dataKey; // e.g., "Customer Excellence"
    
    console.log("📊 Bar clicked:", { quarterKey, year, quarter, strategicObjective, value: data[dataKey] });
    
    // Filter raw API data for the clicked quarter and strategic objective
    const filteredDealerData = rawApiData.filter(item => {
      const itemYear = String(item.year || item.scorecardYear || "");
      const itemQuarter = item.quarter || item.scorecardQuarter || "";
      const itemObjective = (item.strategicObjective || "").toLowerCase();
      
      // Match year and quarter
      const yearMatch = itemYear === year;
      const quarterMatch = itemQuarter === quarter;
      
      // Match strategic objective based on category
      let objectiveMatch = false;
      if (strategicObjective === "Customer Excellence") {
        objectiveMatch = itemObjective.includes("customer excellence") || 
                        (itemObjective.includes("customer") && !itemObjective.includes("business"));
      } else if (strategicObjective === "Business growth & Sustainability") {
        objectiveMatch = itemObjective.includes("business growth") || 
                        itemObjective.includes("sustainability") ||
                        itemObjective.includes("growth & sustainability") ||
                        itemObjective.includes("growth and sustainability");
      } else if (strategicObjective === "Distribution Excellence") {
        objectiveMatch = itemObjective.includes("distribution excellence") || 
                        itemObjective.includes("distribution");
      } else if (strategicObjective === "Business Process") {
        objectiveMatch = itemObjective.includes("business process") || 
                        (itemObjective.includes("process") && !itemObjective.includes("distribution"));
      } else if (strategicObjective === "People & Culture") {
        objectiveMatch = itemObjective.includes("people") || 
                        itemObjective.includes("culture") ||
                        itemObjective.includes("people & culture") ||
                        itemObjective.includes("people and culture");
      }
      
      return yearMatch && quarterMatch && objectiveMatch;
    });
    
    console.log("📊 Filtered dealer data:", filteredDealerData.length, "records");
    
    // Group by dealer and calculate scores
    const dealerScores = {};
    filteredDealerData.forEach(item => {
      const dealerName = item.dealer || item.branch || item.scorecardBranch || "Unknown";
      const marketArea = item.auditLocation || item.scorecardAuditLocation || "";
      
      if (!dealerScores[dealerName]) {
        dealerScores[dealerName] = {
          dealer: dealerName,
          marketArea: marketArea,
          maxScore: 0,
          finalScore: 0,
          count: 0,
        };
      }
      
      dealerScores[dealerName].maxScore += parseFloat(item.maxScore) || 0;
      dealerScores[dealerName].finalScore += parseFloat(item.finalScore) || 0;
      dealerScores[dealerName].count += 1;
    });
    
    // Convert to array and calculate achieved percentage
    const dealerChartData = Object.values(dealerScores).map(dealer => ({
      dealer: dealer.dealer,
      marketArea: dealer.marketArea,
      achieved: dealer.maxScore > 0 
        ? parseFloat(((dealer.finalScore / dealer.maxScore) * 100).toFixed(2))
        : 0,
      maxScore: dealer.maxScore.toFixed(2),
      finalScore: dealer.finalScore.toFixed(2),
      count: dealer.count,
    })).sort((a, b) => b.achieved - a.achieved); // Sort by achieved descending
    
    console.log("📊 Dealer chart data:", dealerChartData);
    
    // Get unique market areas for subtitle
    const marketAreas = [...new Set(dealerChartData.map(d => d.marketArea).filter(Boolean))];
    
    setDrillDownData({
      quarterKey,
      year,
      quarter,
      strategicObjective,
      parentValue: data[dataKey],
      dealerData: dealerChartData,
      marketAreas: marketAreas,
    });
    setDrillDownOpen(true);
  }, [rawApiData]);

  // Close drill-down modal
  const closeDrillDown = useCallback(() => {
    setDrillDownOpen(false);
    setDrillDownData(null);
    setShowDrillDownMenu(false);
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // 📊 TOTALS CALCULATION
  // ═══════════════════════════════════════════════════════════════
  const totals = useMemo(() => {
    if (filteredTableData.length === 0) {
      return {
        subKpiCount: 0,
        maxScore: 0,
        finalScore: 0,
        achieved: 0,
      };
    }

    const sum = filteredTableData.reduce(
      (acc, row) => ({
        subKpiCount: acc.subKpiCount + (row.subKpiCount || 0),
        maxScore: acc.maxScore + parseFloat(row.maxScore),
        finalScore: acc.finalScore + parseFloat(row.finalScore),
      }),
      { subKpiCount: 0, maxScore: 0, finalScore: 0 }
    );

    return {
      subKpiCount: sum.subKpiCount,
      maxScore: sum.maxScore.toFixed(2),
      finalScore: sum.finalScore.toFixed(2),
      achieved: sum.maxScore > 0 ? ((sum.finalScore / sum.maxScore) * 100).toFixed(2) : 0,
    };
  }, [filteredTableData]);

  // ═══════════════════════════════════════════════════════════════
  // ♾️ LAZY LOADING
  // ═══════════════════════════════════════════════════════════════
  const loadMoreItems = useCallback(() => {
    if (isLazyLoading || !hasMore) return;

    setIsLazyLoading(true);

    setTimeout(() => {
      const currentLength = displayedItems.length;
      const nextItems = filteredTableData.slice(currentLength, currentLength + ITEMS_PER_LOAD);

      if (nextItems.length === 0) {
        setHasMore(false);
      } else {
        setDisplayedItems((prev) => [...prev, ...nextItems]);
        if (currentLength + nextItems.length >= filteredTableData.length) {
          setHasMore(false);
        }
      }

      setIsLazyLoading(false);
    }, 300);
  }, [displayedItems.length, filteredTableData, isLazyLoading, hasMore]);

  // Reset displayed items when filters change
  useEffect(() => {
    setDisplayedItems(filteredTableData.slice(0, ITEMS_PER_LOAD));
    setHasMore(filteredTableData.length > ITEMS_PER_LOAD);
  }, [filteredTableData]);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return displayedItems;

  return [...displayedItems].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [displayedItems, sortKey, sortOrder]);


  // Intersection Observer for infinite scroll
  const lastItemRef = useCallback(
    (node) => {
      if (isLazyLoading) return;
      if (observerRef.current) observerRef.current.disconnect();

      observerRef.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore) {
          loadMoreItems();
        }
      });

      if (node) observerRef.current.observe(node);
    },
    [isLazyLoading, hasMore, loadMoreItems]
  );

  // ═══════════════════════════════════════════════════════════════
  // 🎯 CHART MENU HANDLERS
  // ═══════════════════════════════════════════════════════════════

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowChartMenu(false);
      }
      if (drillDownMenuRef.current && !drillDownMenuRef.current.contains(event.target)) {
        setShowDrillDownMenu(false);
      }
    };

    if (showChartMenu || showDrillDownMenu) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showChartMenu, showDrillDownMenu]);

  // Close drill-down on Escape key
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === 'Escape' && drillDownOpen) {
        closeDrillDown();
      }
    };
    
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [drillDownOpen, closeDrillDown]);

  const handleExportPNG = () => {
    if (chartContainerRef.current) {
      try {
        const svg = chartContainerRef.current.querySelector("svg");
        if (svg) {
          const clonedSvg = svg.cloneNode(true);
          const svgRect = svg.getBoundingClientRect();
          const svgWidth = svgRect.width;
          const svgHeight = svgRect.height;

          const canvas = document.createElement("canvas");
          const scale = 2;
          canvas.width = svgWidth * scale;
          canvas.height = svgHeight * scale;

          const ctx = canvas.getContext("2d");
          ctx.scale(scale, scale);
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, svgWidth, svgHeight);

          const svgString = new XMLSerializer().serializeToString(clonedSvg);
          const svgBlob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
          const svgUrl = URL.createObjectURL(svgBlob);

          const img = new Image();
          img.onload = () => {
            ctx.drawImage(img, 0, 0, svgWidth, svgHeight);
            canvas.toBlob((blob) => {
              const url = URL.createObjectURL(blob);
              const link = document.createElement("a");
              link.download = "scorecard-trend-chart.png";
              link.href = url;
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              URL.revokeObjectURL(url);
              URL.revokeObjectURL(svgUrl);
            }, "image/png");
          };

          img.onerror = () => {
            alert("Error exporting chart. Please try again.");
            URL.revokeObjectURL(svgUrl);
          };

          img.src = svgUrl;
        }
      } catch (error) {
        console.error("Error exporting PNG:", error);
        alert("Error exporting chart. Please try again.");
      }
    }
    setShowChartMenu(false);
  };

  const handleExportJPEG = () => {
    if (chartContainerRef.current) {
      try {
        const svg = chartContainerRef.current.querySelector("svg");
        if (svg) {
          const clonedSvg = svg.cloneNode(true);
          const svgRect = svg.getBoundingClientRect();
          const svgWidth = svgRect.width;
          const svgHeight = svgRect.height;

          const canvas = document.createElement("canvas");
          const scale = 2;
          canvas.width = svgWidth * scale;
          canvas.height = svgHeight * scale;

          const ctx = canvas.getContext("2d");
          ctx.scale(scale, scale);
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, svgWidth, svgHeight);

          const svgString = new XMLSerializer().serializeToString(clonedSvg);
          const svgBlob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
          const svgUrl = URL.createObjectURL(svgBlob);

          const img = new Image();
          img.onload = () => {
            ctx.drawImage(img, 0, 0, svgWidth, svgHeight);
            canvas.toBlob(
              (blob) => {
                const url = URL.createObjectURL(blob);
                const link = document.createElement("a");
                link.download = "scorecard-trend-chart.jpeg";
                link.href = url;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
                URL.revokeObjectURL(svgUrl);
              },
              "image/jpeg",
              0.95
            );
          };

          img.onerror = () => {
            alert("Error exporting chart. Please try again.");
            URL.revokeObjectURL(svgUrl);
          };

          img.src = svgUrl;
        }
      } catch (error) {
        console.error("Error exporting JPEG:", error);
        alert("Error exporting chart. Please try again.");
      }
    }
    setShowChartMenu(false);
  };

  const handleExportSVG = () => {
    if (chartContainerRef.current) {
      try {
        const svg = chartContainerRef.current.querySelector("svg");
        if (svg) {
          const svgData = new XMLSerializer().serializeToString(svg);
          const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
          const url = URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.download = "scorecard-trend-chart.svg";
          link.href = url;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        }
      } catch (error) {
        console.error("Error exporting SVG:", error);
        alert("Error exporting chart. Please try again.");
      }
    }
    setShowChartMenu(false);
  };

  const handlePrint = () => {
    const printContent = chartRef.current.innerHTML;
    const printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write(`
      <html>
        <head>
          <title>Scorecard Trends</title>
          <style>
            body { margin: 20px; font-family: Arial, sans-serif; }
            h1 { text-align: center; }
            @media print {
              body { margin: 0; }
            }
          </style>
        </head>
        <body>
          <h1>Dealer Scorecard Trends(Qtrly)</h1>
          ${printContent}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
    setShowChartMenu(false);
  };

  const handleFullScreen = () => {
    if (chartRef.current) {
      if (chartRef.current.requestFullscreen) {
        chartRef.current.requestFullscreen();
      } else if (chartRef.current.webkitRequestFullscreen) {
        chartRef.current.webkitRequestFullscreen();
      } else if (chartRef.current.mozRequestFullScreen) {
        chartRef.current.mozRequestFullScreen();
      } else if (chartRef.current.msRequestFullscreen) {
        chartRef.current.msRequestFullscreen();
      }
    }
    setShowChartMenu(false);
  };

  const handleDownloadChartCSV = () => {
    try {
      if (chartData.length === 0) {
        alert("No chart data to download");
        return;
      }

      const headers = ["Quarter", ...Object.keys(chartData[0]).filter((k) => k !== "quarter")];
      const csvContent = [
        headers.join(","),
        ...chartData.map((row) =>
          [row.quarter, ...headers.slice(1).map((h) => row[h])].join(",")
        ),
      ].join("\n");

      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.download = "scorecard-trend-data.csv";
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading CSV:", error);
      alert("Error downloading CSV. Please try again.");
    }
    setShowChartMenu(false);
  };

  const handleViewDataTable = () => {
    if (chartData.length === 0) {
      alert("No chart data to display");
      setShowChartMenu(false);
      return;
    }

    const tableWindow = window.open("", "", "width=800,height=600");
    tableWindow.document.write(`
      <html>
        <head>
          <title>Scorecard Data Table</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #6B8CA8; color: white; }
            tr:nth-child(even) { background-color: #f2f2f2; }
          </style>
        </head>
        <body>
          <h2>Dealer Scorecard Trends - Data Table</h2>
          <table>
            <thead>
              <tr>
                <th>Quarter</th>
                <th>Customer Excellence</th>
                <th>Business Growth & Sustainability</th>
                <th>Distribution Excellence</th>
                <th>Business Process</th>
                <th>People & Culture</th>
              </tr>
            </thead>
            <tbody>
              ${chartData
                .map(
                  (row) => `
                <tr>
                  <td>${row.quarter}</td>
                  <td>${row["Customer Excellence"]}</td>
                  <td>${row["Business growth & Sustainability"]}</td>
                  <td>${row["Distribution Excellence"]}</td>
                  <td>${row["Business Process"]}</td>
                  <td>${row["People & Culture"]}</td>
                </tr>
              `
                )
                .join("")}
            </tbody>
          </table>
        </body>
      </html>
    `);
    tableWindow.document.close();
    setShowChartMenu(false);
  };

  const handleExportPDF = () => {
    alert("PDF export functionality will be implemented with a PDF library.");
    setShowChartMenu(false);
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔍 DRILL-DOWN CHART EXPORT HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleDrillDownExportPNG = () => {
    if (drillDownChartContainerRef.current) {
      try {
        const svg = drillDownChartContainerRef.current.querySelector("svg");
        if (svg) {
          const clonedSvg = svg.cloneNode(true);
          const svgRect = svg.getBoundingClientRect();
          const svgWidth = svgRect.width;
          const svgHeight = svgRect.height;

          const canvas = document.createElement("canvas");
          const scale = 2;
          canvas.width = svgWidth * scale;
          canvas.height = svgHeight * scale;

          const ctx = canvas.getContext("2d");
          ctx.scale(scale, scale);
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, svgWidth, svgHeight);

          const svgString = new XMLSerializer().serializeToString(clonedSvg);
          const svgBlob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
          const svgUrl = URL.createObjectURL(svgBlob);

          const img = new Image();
          img.onload = () => {
            ctx.drawImage(img, 0, 0, svgWidth, svgHeight);
            canvas.toBlob((blob) => {
              const url = URL.createObjectURL(blob);
              const link = document.createElement("a");
              link.download = `dealer-scores-${drillDownData?.quarterKey || 'chart'}.png`;
              link.href = url;
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              URL.revokeObjectURL(url);
              URL.revokeObjectURL(svgUrl);
            }, "image/png");
          };

          img.onerror = () => {
            alert("Error exporting chart. Please try again.");
            URL.revokeObjectURL(svgUrl);
          };

          img.src = svgUrl;
        }
      } catch (error) {
        console.error("Error exporting PNG:", error);
        alert("Error exporting chart. Please try again.");
      }
    }
    setShowDrillDownMenu(false);
  };

  const handleDrillDownDownloadCSV = () => {
    if (!drillDownData?.dealerData || drillDownData.dealerData.length === 0) {
      alert("No data to download");
      return;
    }

    try {
      const headers = ["Dealer", "Market Area", "Achieved %", "Max Score", "Final Score"];
      const csvContent = [
        headers.join(","),
        ...drillDownData.dealerData.map((row) =>
          [
            `"${row.dealer}"`,
            `"${row.marketArea}"`,
            row.achieved,
            row.maxScore,
            row.finalScore
          ].join(",")
        ),
      ].join("\n");

      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.download = `dealer-scores-${drillDownData.quarterKey}-${drillDownData.strategicObjective.replace(/\s+/g, '-')}.csv`;
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading CSV:", error);
      alert("Error downloading CSV. Please try again.");
    }
    setShowDrillDownMenu(false);
  };

  const handleDrillDownFullScreen = () => {
    if (drillDownChartRef.current) {
      if (drillDownChartRef.current.requestFullscreen) {
        drillDownChartRef.current.requestFullscreen();
      } else if (drillDownChartRef.current.webkitRequestFullscreen) {
        drillDownChartRef.current.webkitRequestFullscreen();
      } else if (drillDownChartRef.current.mozRequestFullScreen) {
        drillDownChartRef.current.mozRequestFullScreen();
      } else if (drillDownChartRef.current.msRequestFullscreen) {
        drillDownChartRef.current.msRequestFullscreen();
      }
    }
    setShowDrillDownMenu(false);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-300  shadow-lg">
          <p className="font-semibold text-gray-800 mb-1">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} style={{ color: entry.fill }} className="text-sm">
              {entry.name}: {entry.value}%
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  // Custom tooltip for drill-down chart
  const DrillDownTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-gray-300 shadow-lg min-w-[200px]">
          <p className="font-semibold text-gray-800 mb-2 border-b pb-1">{label}</p>
          <div className="space-y-1 text-sm">
            <p className="text-gray-600">
              <span className="font-medium">Market Area:</span> {data.marketArea || '-'}
            </p>
            <p style={{ color: '#2196F3' }}>
              <span className="font-medium">Achieved:</span> {data.achieved}%
            </p>
            <p className="text-gray-600">
              <span className="font-medium">Max Score:</span> {data.maxScore}
            </p>
            <p className="text-gray-600">
              <span className="font-medium">Final Score:</span> {data.finalScore}
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  // ═══════════════════════════════════════════════════════════════
  // 📥 DOWNLOAD HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleDownloadExcel = () => {
    try {
      const dataToExport = [
        ...filteredTableData.map((row) => ({
          Year: row.year,
          Quarter: row.quarter,
          "Market Area": row.marketArea || '-',
          Dealer: row.dealer || '-',
          "Strategic Objective": row.strategicObjective,
          "Sub-KPIs": row.subKpiCount,
          "Max Score": row.maxScore,
          "Final Score": row.finalScore,
          "Achieved %": row.achieved,
        })),
        // Add totals row
        {
          Year: "",
          Quarter: "",
          "Market Area": "",
          Dealer: "",
          "Strategic Objective": "TOTAL",
          "Sub-KPIs": totals.subKpiCount,
          "Max Score": totals.maxScore,
          "Final Score": totals.finalScore,
          "Achieved %": totals.achieved,
        },
      ];

      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Scorecard Results");

      // Auto-size columns
      const maxWidth = 20;
      const wscols = Object.keys(dataToExport[0]).map(() => ({ wch: maxWidth }));
      worksheet["!cols"] = wscols;

      XLSX.writeFile(workbook, "Scorecard_Results.xlsx");
    } catch (error) {
      console.error("Error downloading Excel:", error);
      alert("Error downloading Excel file. Please try again.");
    }
  };

  const handleDownloadCSV = () => {
    try {
      const headers = [
        "Year",
        "Quarter",
        "Market Area",
        "Dealer",
        "Strategic Objective",
        "Sub-KPIs",
        "Max Score",
        "Final Score",
        "Achieved %",
      ];

      const csvContent = [
        headers.join(","),
        ...filteredTableData.map((row) =>
          [
            row.year,
            row.quarter,
            `"${row.marketArea || '-'}"`,
            `"${row.dealer || '-'}"`,
            `"${row.strategicObjective}"`,
            row.subKpiCount,
            row.maxScore,
            row.finalScore,
            row.achieved,
          ].join(",")
        ),
        // Add totals row
        [
          "",
          "",
          "",
          "",
          "TOTAL",
          totals.subKpiCount,
          totals.maxScore,
          totals.finalScore,
          totals.achieved,
        ].join(","),
      ].join("\n");

      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.download = "Scorecard_Results.csv";
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading CSV:", error);
      alert("Error downloading CSV. Please try again.");
    }
  };

  // Bar colors matching your design
  const CHART_COLORS = {
    "Customer Excellence": "#6B8CA8",
    "Business growth & Sustainability": "#8BA9C1",
    "Distribution Excellence": "#5A7A95",
    "Business Process": "#7D9BB5",
    "People & Culture": "#4E6B82",
  };

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "lg:ml-60" : ""
        } flex justify-center flex-1`}
      >
        <div className="w-full mt-[4.5rem] sm:mt-[5rem] lg:mt-[6rem] p-2 lg:px-4 pb-6">
          {/* Page Title */}
          <div className="flex items-center justify-center mb-3">
            <h2 className="text-lg sm:text-xl font-semibold text-darkblue1 font-VolvoNovum">
              Scorecard Dashboard
            </h2>
          </div>

          {/* Error State */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded p-4 mb-4">
              <div className="flex items-center justify-between">
                <span className="text-red-600 text-sm">{error}</span>
                <button
                  onClick={fetchScorecardData}
                  className="text-red-600 hover:text-red-800 text-sm underline"
                >
                  Retry
                </button>
              </div>
            </div>
          )}

          {/* Filters Row */}
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="w-[1/2]"
              iconColor="text-black"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              shadow="shadow-none"
              inputPadding="pl-7 pr-3 py-1.5"
              iconSize="w-3.5 h-3.5"
              iconLeft="left-3"
              inputWidth="w-full"
              focusRing="focus:ring-1 focus:ring-black/60"
              hoverInputClasses="hover:bg-white hover:border-black/60"
            />
            <Filter
              name="year"
              value={filters.year}
              options={filterOptions.years}
              onChange={handleFilterChange}
              placeholder="Year"
              customWidth="w-28"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />
            <Filter
              name="quarter"
              value={filters.quarter}
              options={filterOptions.quarters}
              onChange={handleFilterChange}
              placeholder="Quarter"
              customWidth="w-28"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />
            <Filter
              name="marketArea"
              value={filters.marketArea}
              options={filterOptions.marketAreas}
              onChange={handleFilterChange}
              placeholder="Market Area"
              customWidth="w-36"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />
            <Filter
              name="dealer"
              value={filters.dealer}
              options={filterOptions.dealers}
              onChange={handleFilterChange}
              placeholder="Dealer"
              customWidth="w-36"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />
            <Filter
              name="strategicObjective"
              value={filters.strategicObjective}
              options={filterOptions.strategicObjectives}
              onChange={handleFilterChange}
              placeholder="Strategic Objective"
              customWidth="w-48"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />
            <Filter
              name="subKPI"
              value={filters.subKPI}
              options={filterOptions.subKPIs}
              onChange={handleFilterChange}
              placeholder="Sub KPI No."
              customWidth="w-40"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />
          </div>

          {/* Chart Section */}
          <div
            className="bg-white  shadow-md border border-gray-200 p-4 sm:p-6 mb-4 relative"
            ref={chartRef}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="text-center flex-1">
                <h2 className="text-base sm:text-lg font-semibold text-gray-800 font-VolvoNovum">
                  Dealer Scorecard Trends(Qtrly)
                </h2>
                <p className="text-xs text-gray-500 mt-1">Click on any bar to see dealer breakdown</p>
              </div>

              {/* Chart Menu Button */}
              <div className="relative" ref={menuRef}>
                <button
                  onClick={() => setShowChartMenu(!showChartMenu)}
                  className="p-1 hover:bg-gray-100  transition"
                  aria-label="Chart options"
                  disabled={chartData.length === 0}
                >
                  <Menu size={18} className={`${chartData.length === 0 ? 'text-gray-400' : 'text-gray-600'}`} />
                </button>

                {showChartMenu && chartData.length > 0 && (
                  <div className="absolute right-0 top-full mt-2 w-56 bg-white border border-gray-200  shadow-lg z-50">
                    <button
                      onClick={handleFullScreen}
                      className="w-full px-4 py-1 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                    >
                      <svg
                        className="w-4 h-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"
                        />
                      </svg>
                      View in full screen
                    </button>
                    <button
                      onClick={handlePrint}
                      className="w-full px-4 py-1 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                    >
                      <svg
                        className="w-4 h-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"
                        />
                      </svg>
                      Print chart
                    </button>
                    <div className="border-t border-gray-200 my-1"></div>
                    <button
                      onClick={handleExportPNG}
                      className="w-full px-4 py-1 text-left text-xs text-gray-700 hover:bg-gray-50"
                    >
                      Download PNG image
                    </button>
                    <button
                      onClick={handleExportJPEG}
                      className="w-full px-4 py-1 text-left text-xs text-gray-700 hover:bg-gray-50"
                    >
                      Download JPEG image
                    </button>
                    <button
                      onClick={handleExportSVG}
                      className="w-full px-4 py-1 text-left text-xs text-gray-700 hover:bg-gray-50"
                    >
                      Download SVG vector image
                    </button>
                    <button
                      onClick={handleExportPDF}
                      className="w-full px-4 py-1 text-left text-xs text-gray-700 hover:bg-gray-50"
                    >
                      Download PDF document
                    </button>
                    <div className="border-t border-gray-200 my-1"></div>
                    <button
                      onClick={handleDownloadChartCSV}
                      className="w-full px-4 py-1 text-left text-xs text-gray-700 hover:bg-gray-50"
                    >
                      Download CSV
                    </button>
                    <button
                      onClick={handleViewDataTable}
                      className="w-full px-4 py-1 text-left text-xs text-gray-700 hover:bg-gray-50"
                    >
                      View data table
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Bar Chart or Loading/Empty State */}
            {isLoading ? (
              <div className="flex flex-col items-center justify-center h-[400px] text-gray-400">
                <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-gray-500 mb-4"></div>
                <p className="text-sm font-medium">Loading chart data...</p>
              </div>
            ) : chartData.length > 0 ? (
              <div ref={chartContainerRef}>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={chartData} margin={{ top: 20, right: 20, left: 0, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                    <XAxis
                      dataKey="quarter"
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      axisLine={{ stroke: "#e5e7eb" }}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fontSize: 11, fill: "#6b7280" }}
                      axisLine={{ stroke: "#e5e7eb" }}
                      tickLine={false}
                      unit="%"
                    />
                    <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(0, 0, 0, 0.05)" }} />
                    <Legend
                      wrapperStyle={{ paddingTop: "20px" }}
                      iconType="circle"
                      formatter={(value) => (
                        <span style={{ fontSize: "11px", color: "#374151" }}>{value}</span>
                      )}
                    />
                    <Bar
                      dataKey="Customer Excellence"
                      fill="#6B8CA8"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={40}
                      cursor="pointer"
                      onClick={(data, index, event) => handleBarClick(data, index, event, "Customer Excellence")}
                    />
                    <Bar
                      dataKey="Business growth & Sustainability"
                      fill="#8BA9C1"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={40}
                      cursor="pointer"
                      onClick={(data, index, event) => handleBarClick(data, index, event, "Business growth & Sustainability")}
                    />
                    <Bar
                      dataKey="Distribution Excellence"
                      fill="#5A7A95"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={40}
                      cursor="pointer"
                      onClick={(data, index, event) => handleBarClick(data, index, event, "Distribution Excellence")}
                    />
                    <Bar
                      dataKey="Business Process"
                      fill="#7D9BB5"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={40}
                      cursor="pointer"
                      onClick={(data, index, event) => handleBarClick(data, index, event, "Business Process")}
                    />
                    <Bar
                      dataKey="People & Culture"
                      fill="#4E6B82"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={40}
                      cursor="pointer"
                      onClick={(data, index, event) => handleBarClick(data, index, event, "People & Culture")}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-[400px] text-gray-400">
                <svg className="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
                <p className="text-sm font-medium">No chart data available</p>
                <p className="text-xs mt-1">Try adjusting your filters</p>
              </div>
            )}
          </div>

          {/* Table Section */}
          <div className="bg-white  shadow-md border border-gray-200 p-4">
            {/* Table Header with Download Button */}
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-semibold text-gray-800 font-VolvoNovum">
                Scorecard Results
              </h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadExcel}
                  disabled={filteredTableData.length === 0}
                  className="flex items-center gap-2 px-4 py-1 bg-green-600 text-white  hover:bg-green-700 transition text-xs font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Download size={16} />
                  Excel
                </button>
                <button
                  onClick={handleDownloadCSV}
                  disabled={filteredTableData.length === 0}
                  className="flex items-center gap-2 px-4 py-1 bg-darkblue1 text-white  hover:bg-darkblue2 transition text-xs font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Download size={16} />
                  CSV
                </button>
              </div>
            </div>

            {/* Table */}
            <div
              ref={tableContainerRef}
              className="bg-white shadow-md border border-Dustyblue overflow-auto hide-scrollbar"
              style={{ maxHeight: "400px" }}
               onScroll={handleTableScroll}

            >
              <style jsx>{`
                .hide-scrollbar::-webkit-scrollbar {
                  display: none;
                }
                .hide-scrollbar {
                  -ms-overflow-style: none;
                  scrollbar-width: none;
                }
              `}</style>

              <table className="w-full text-xs border-collapse min-w-[1200px]">
                <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                  <tr>
                
  {/* Year */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[6%] cursor-pointer select-none"
    onClick={() => handleSort("year")}
  >
    <div className="flex items-center gap-1">
      Year
      {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
      {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Quarter */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%]cursor-pointer select-none"
    onClick={() => handleSort("quarter")}
  >
    <div className="flex items-center gap-1">
      Quarter
      {sortKey === "quarter" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "quarter" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Market Area */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer w-[10%] select-none"
    onClick={() => handleSort("marketArea")}
  >
    <div className="flex items-center gap-1">
      Market Area
      {sortKey === "marketArea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "marketArea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Dealer */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer w-[12%] select-none"
    onClick={() => handleSort("dealer")}
  >
    <div className="flex items-center gap-1">
      Dealer
      {sortKey === "dealer" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "dealer" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Strategic Objective */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer w-[15%] select-none"
    onClick={() => handleSort("strategicObjective")}
  >
    <div className="flex items-center gap-1">
      Strategic Objective
      {sortKey === "strategicObjective" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "strategicObjective" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Sub-KPIs */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
    onClick={() => handleSort("subKpis")}
  >
    <div className="flex items-center justify-center gap-1">
      Sub-KPIs
      {sortKey === "subKpis" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "subKpis" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Max Score */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 w-[8%] font-medium cursor-pointer select-none"
    onClick={() => handleSort("maxScore")}
  >
    <div className="flex items-center justify-center gap-1">
      Max Score
      {sortKey === "maxScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "maxScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Final Score */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%] font-medium cursor-pointer select-none"
    onClick={() => handleSort("finalScore")}
  >
    <div className="flex items-center justify-center gap-1">
      Final Score
      {sortKey === "finalScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "finalScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Achieved % */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 w-[10%] font-medium cursor-pointer select-none"
    onClick={() => handleSort("achieved")}
  >
    <div className="flex items-center justify-center gap-1">
      Achieved %
      {sortKey === "achieved" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "achieved" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>
</tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    <tr>
                      <td
                        colSpan="9"
                        className="text-center py-8 text-xs text-gray-500 italic"
                      >
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                          Loading data...
                        </div>
                      </td>
                    </tr>
                  ) : sortedData.length > 0 ? (
                    <>
                      {sortedData.map((row, index) => {
                        const isLast = index === sortedData.length - 1;
                        return (
                          <tr
                            key={row.id}
                            ref={isLast ? lastItemRef : null}
                            className={`hover:bg-lightBlue/50 transition`}
                          >
                            <td className="px-4 py-1 text-left border border-grey2 border-t-0 border-l-0 text-gray-800">
                              {row.year}
                            </td>
                            <td className="px-4 py-1 text-left border border-grey2 border-t-0 border-l-0 text-gray-800">
                              {row.quarter}
                            </td>
                            <td className="px-4 py-1 text-left border border-grey2 border-t-0 border-l-0 text-gray-800">
                              {row.marketArea || '-'}
                            </td>
                            <td className="px-4 py-1 text-xs text-gray-800 border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.dealer?.length > 22)
          setHoveredCell(row.id + "-dealer");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.dealer || "-"}
    </p>

    {hoveredCell === row.id + "-dealer" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {row.dealer}
      </span>
    )}
  </div>
</td>
                          <td className="px-4 py-1 text-xs text-gray-800 border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.strategicObjective?.length > 22)
          setHoveredCell(row.id + "-strategicObjective");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.strategicObjective || "-"}
    </p>

    {hoveredCell === row.id + "-strategicObjective" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {row.strategicObjective}
      </span>
    )}
  </div>
</td>
                            <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0 text-gray-800">
                              {row.subKpiCount}
                            </td>
                            <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0 text-gray-800">
                              {row.maxScore}
                            </td>
                            <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0 text-gray-800">
                              {row.finalScore}
                            </td>
                            <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0 text-gray-800">
                              {row.achieved}%
                            </td>
                          </tr>
                        );
                      })}

                      {/* Total/Summary Row */}
                      <tr className="bg-Dustyblue text-white font-bold sticky bottom-0">
                        <td className="px-2 py-1 text-left border border-grey2 border-t-2 border-t-black border-l-0" colSpan="5">
                          TOTAL
                        </td>
                        <td className="px-2 py-1 text-center border border-grey2 border-t-2 border-t-black border-l-0">
                          {totals.subKpiCount}
                        </td>
                        <td className="px-2 py-1 text-center border border-grey2 border-t-2 border-t-black border-l-0">
                          {totals.maxScore}
                        </td>
                        <td className="px-2 py-1 text-center border border-grey2 border-t-2 border-t-black border-l-0">
                          {totals.finalScore}
                        </td>
                        <td className="px-2 py-1 text-center border border-grey2 border-t-2 border-t-black border-l-0 border-r-0">
                          {totals.achieved}%
                        </td>
                      </tr>

                      {/* Loading more indicator */}
                      {isLazyLoading && (
                        <tr>
                          <td colSpan="9" className="px-6 py-3 text-center text-gray-500">
                            <div className="flex items-center justify-center gap-2">
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                              <span className="text-xs">Loading more...</span>
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  ) : (
                    <tr>
                      <td
                        colSpan="9"
                        className="text-center py-8 text-xs text-gray-500 italic border border-grey2 border-t-0 border-l-0 border-r-0"
                      >
                        No data found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
             {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

          </div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* 🔍 DRILL-DOWN MODAL */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      {drillDownOpen && drillDownData && (
        <div 
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget) closeDrillDown();
          }}
        >
          <div 
            className="bg-white w-full max-w-6xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col animate-fadeIn"
            ref={drillDownChartRef}
          >
            {/* Modal Header */}
            <div className="bg-Dustyblue text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button
                  onClick={closeDrillDown}
                  className="flex items-center gap-2 px-3 py-1.5 bg-green-500 hover:bg-green-600 text-white text-sm font-medium transition"
                >
                  <RefreshCw size={14} />
                  Refresh
                </button>
                <button
                  onClick={closeDrillDown}
                  className="flex items-center gap-2 px-3 py-1.5 bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium transition"
                >
                  <ArrowLeft size={14} />
                  Back
                </button>
              </div>
              <h2 className="text-lg font-semibold font-VolvoNovum">
                Overall Dealer Score
              </h2>
              <button
                onClick={closeDrillDown}
                className="p-1 hover:bg-white/20 rounded transition"
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="flex-1 overflow-auto p-6">
              {/* Subtitle Info */}
              <div className="text-center mb-6">
                <p className="text-sm font-semibold text-gray-700">
                  {drillDownData.marketAreas.length > 0 
                    ? drillDownData.marketAreas.join(", ")
                    : "All Market Areas"
                  }
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  {drillDownData.strategicObjective}
                </p>
              </div>

              {/* Quarter Badge */}
              <div className="flex items-center justify-end mb-4">
                <span className="px-3 py-1 bg-gray-100 text-gray-700 text-sm font-medium rounded">
                  {drillDownData.quarterKey}
                </span>
                
                {/* Chart Menu Button */}
                <div className="relative ml-4" ref={drillDownMenuRef}>
                  <button
                    onClick={() => setShowDrillDownMenu(!showDrillDownMenu)}
                    className="p-1 hover:bg-gray-100 transition"
                    aria-label="Chart options"
                  >
                    <Menu size={18} className="text-gray-600" />
                  </button>

                  {showDrillDownMenu && (
                    <div className="absolute right-0 top-full mt-2 w-56 bg-white border border-gray-200 shadow-lg z-50">
                      <button
                        onClick={handleDrillDownFullScreen}
                        className="w-full px-4 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                        </svg>
                        View in full screen
                      </button>
                      <div className="border-t border-gray-200 my-1"></div>
                      <button
                        onClick={handleDrillDownExportPNG}
                        className="w-full px-4 py-2 text-left text-xs text-gray-700 hover:bg-gray-50"
                      >
                        Download PNG image
                      </button>
                      <button
                        onClick={handleDrillDownDownloadCSV}
                        className="w-full px-4 py-2 text-left text-xs text-gray-700 hover:bg-gray-50"
                      >
                        Download CSV
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Dealer Chart */}
              {drillDownData.dealerData.length > 0 ? (
                <div ref={drillDownChartContainerRef}>
                  <ResponsiveContainer width="100%" height={450}>
                    <BarChart 
                      data={drillDownData.dealerData} 
                      margin={{ top: 30, right: 30, left: 20, bottom: 120 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                      <XAxis
                        dataKey="dealer"
                        tick={{ fontSize: 10, fill: "#6b7280" }}
                        axisLine={{ stroke: "#e5e7eb" }}
                        tickLine={false}
                        interval={0}
                        angle={-45}
                        textAnchor="end"
                        height={100}
                      />
                      <YAxis
                        tick={{ fontSize: 11, fill: "#6b7280" }}
                        axisLine={{ stroke: "#e5e7eb" }}
                        tickLine={false}
                        label={{ 
                          value: 'Dealer Final Ranking', 
                          angle: -90, 
                          position: 'insideLeft',
                          style: { textAnchor: 'middle', fontSize: 12, fill: '#6b7280' }
                        }}
                      />
                      <Tooltip content={<DrillDownTooltip />} cursor={{ fill: "rgba(0, 0, 0, 0.05)" }} />
                      <Legend 
                        wrapperStyle={{ paddingTop: "20px" }}
                        iconType="circle"
                        content={() => (
                          <div className="flex justify-center mt-4">
                            <div className="flex items-center gap-2">
                              <div className="w-3 h-3 rounded-full bg-[#2196F3]"></div>
                              <span className="text-xs text-gray-600">Dealer Name</span>
                            </div>
                          </div>
                        )}
                      />
                      <Bar
                        dataKey="achieved"
                        fill="#2196F3"
                        radius={[4, 4, 0, 0]}
                        maxBarSize={50}
                      >
                        <LabelList 
                          dataKey="achieved" 
                          position="top" 
                          formatter={(value) => `${value} (${((value / drillDownData.parentValue) * 100).toFixed(1)}%)`}
                          style={{ fontSize: 9, fill: '#374151' }}
                          angle={-45}
                          offset={10}
                        />
                        {drillDownData.dealerData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={index === 0 ? "#2196F3" : "#90CAF9"} 
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-[400px] text-gray-400">
                  <svg className="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  <p className="text-sm font-medium">No dealer data available</p>
                  <p className="text-xs mt-1">No dealers found for this selection</p>
                </div>
              )}

              {/* Attribution */}
              <div className="text-right mt-4">
                <span className="text-[10px] text-gray-400">Highcharts.com</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Animation styles */}
      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
        .animate-fadeIn {
          animation: fadeIn 0.2s ease-out;
        }
      `}</style>
    </div>
  );
};

export default ScorecardResults;