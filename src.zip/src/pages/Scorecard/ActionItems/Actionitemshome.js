import React, { useState } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import Actionitems from "./Actionitems";

const Actionitemshome = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
   <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      {/* Navigation Bar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      
      {/* Main Content - Moves Right when Sidebar Opens */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex-1 flex flex-col
          overflow-hidden
        `}
      >
        {/* Content Container with proper spacing */}
        <div className="w-full mt-[4.5rem] lg:mt-[6.5rem] px-2 lg:px-4 ">
          <Actionitems />
        </div>
      </div>
    </div>
  );
};

export default Actionitemshome;