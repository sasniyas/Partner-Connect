import React, { useState, useEffect, useRef } from "react";
import { ArrowLeft, X } from "lucide-react";
import StyledSelectField from "../../../Components/StyledSelectField";

// ═══════════════════════════════════════════════════════════════
// 📡 API SERVICE IMPORTS
// ═══════════════════════════════════════════════════════════════
import { updateScorecardActionItem } from "../../../services/scorecard/scorecardScoreView.service";

const EditActionItemPopup = ({ isOpen, onClose, item, onUpdate }) => {
  // ═══════════════════════════════════════════════════════════════
  // 📊 STATE MANAGEMENT
  // ═══════════════════════════════════════════════════════════════
  const [isLoading, setIsLoading] = useState(false);

  const [form, setForm] = useState({
    status: "",
    finalScore: "",
    endDate: "",
  });

  const [errors, setErrors] = useState({
    status: "",
    finalScore: "",
    endDate: "",
  });

  const [dropdowns, setDropdowns] = useState({
    status: false,
  });

  const refs = {
    status: useRef(null),
  };

  // Status options matching backend ALLOWED_STATUSES
  const statusOptions = ["Created", "In Progress", "Closed", "Completed"];

  // ═══════════════════════════════════════════════════════════════
  // 🔄 INITIALIZE FORM
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    if (isOpen && item) {
      setForm({
        status: item.status || "Created",
        finalScore: item.finalScore !== undefined ? String(item.finalScore) : "",
        endDate: item.endDate ? formatDateForInput(item.endDate) : (item.targetDate ? formatDateForInput(item.targetDate) : ""),
      });
      setErrors({});
    }
  }, [isOpen, item]);

  // Helper to format date for input
  const formatDateForInput = (dateString) => {
    if (!dateString) return "";
    try {
      // If already in YYYY-MM-DD format
      if (dateString.includes("-") && dateString.length === 10) {
        return dateString;
      }
      // If in DD/MM/YYYY format
      if (dateString.includes("/")) {
        const parts = dateString.split("/");
        if (parts.length === 3) {
          return `${parts[2]}-${parts[1].padStart(2, "0")}-${parts[0].padStart(2, "0")}`;
        }
      }
      const date = new Date(dateString);
      return date.toISOString().split("T")[0];
    } catch {
      return "";
    }
  };

  if (!isOpen || !item) return null;

  // ═══════════════════════════════════════════════════════════════
  // 🎯 EVENT HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }));
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 💾 SAVE CHANGES
  // ═══════════════════════════════════════════════════════════════
  const handleSave = async () => {
    // Validate
    let tempErrors = {};

    if (!form.status) {
      tempErrors.status = "Please select a status";
    }

    if (form.finalScore && isNaN(parseFloat(form.finalScore))) {
      tempErrors.finalScore = "Please enter a valid number";
    }

    if (Object.keys(tempErrors).length > 0) {
      setErrors(tempErrors);
      return;
    }

    setIsLoading(true);
    try {
      // Build update payload
      const updateData = {
        id: item.id,
        action_item_status: form.status,
      };

      // Only include optional fields if they have values
      if (form.finalScore !== "" && form.finalScore !== null) {
        updateData.final_score = parseFloat(form.finalScore);
      }

      if (form.endDate) {
        updateData.end_date = form.endDate;
      }

      // Call API
      await updateScorecardActionItem(updateData);

      // Call parent callback with updated data
      if (onUpdate) {
        onUpdate({
          ...item,
          status: form.status,
          finalScore: form.finalScore ? parseFloat(form.finalScore) : item.finalScore,
          endDate: form.endDate || item.endDate,
          targetDate: form.endDate || item.targetDate,
        });
      }

      // Close popup
      handleClose();
    } catch (err) {
      console.error("Error updating action item:", err);
      alert(err.message || "Failed to update action item");
    } finally {
      setIsLoading(false);
    }
  };

  // Handle close
  const handleClose = () => {
    setForm({
      status: "",
      finalScore: "",
      endDate: "",
    });
    setErrors({});
    onClose();
  };

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 w-full max-w-lg shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleClose}
              size={20}
              className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
            />
            <h2 className="text-sm sm:text-base font-semibold text-darkblue1">
              Edit Action Item
            </h2>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X size={18} />
          </button>
        </div>

        <div className="hidden lg:block h-1 bg-darkblue1 w-[15%] ml-7 -mt-2 mb-4"></div>

        {/* Item Info - Read Only */}
        <div className="mb-4 p-3 bg-gray-50 border border-gray-200 text-xs">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-gray-500">Sub KPI:</span>
              <span className="ml-2 font-medium">{item.subKPI || item.subKpi || "—"}</span>
            </div>
            <div>
              <span className="text-gray-500">Max Score:</span>
              <span className="ml-2 font-medium">{item.maxScore || 0}</span>
            </div>
            <div>
              <span className="text-gray-500">Created By:</span>
              <span className="ml-2 font-medium">{item.createdByName || item.createdBy || "—"}</span>
            </div>
            <div>
              <span className="text-gray-500">Assigned To:</span>
              <span className="ml-2 font-medium">{item.assignedTo || "—"}</span>
            </div>
          </div>
        </div>

        {/* Edit Form */}
        <div className="space-y-4">
          {/* Status */}
          <div>
            <StyledSelectField
              label="Status"
              placeholder="Select Status"
              value={form.status}
              setValue={(val) => handleChange("status", val)}
              options={statusOptions}
              dropdownOpen={dropdowns.status}
              setDropdownOpen={(val) =>
                setDropdowns((prev) => ({ ...prev, status: val }))
              }
              dropdownRef={refs.status}
              error={errors.status}
            />
          </div>

          {/* Final Score */}
          <div>
            <label className="block text-xs font-medium text-black/70 mb-1">
              Final Score
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              max={item.maxScore || 100}
              value={form.finalScore}
              onChange={(e) => handleChange("finalScore", e.target.value)}
              placeholder={`Enter score (max: ${item.maxScore || 100})`}
              className={`w-full px-3 py-1.5 border text-xs focus:outline-none ${
                errors.finalScore ? "border-red-500" : "border-black/30"
              }`}
            />
            {errors.finalScore && (
              <p className="text-xs text-red-500 mt-1">{errors.finalScore}</p>
            )}
          </div>

          {/* End Date / Target Date */}
          <div>
            <label className="block text-xs font-medium text-black/70 mb-1">
              Target Date
            </label>
            <input
              type="date"
              value={form.endDate}
              onChange={(e) => handleChange("endDate", e.target.value)}
              className={`w-full px-3 py-1.5 border text-xs focus:outline-none ${
                errors.endDate ? "border-red-500" : "border-black/30"
              }`}
            />
            {errors.endDate && (
              <p className="text-xs text-red-500 mt-1">{errors.endDate}</p>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-center gap-3 mt-6">
          <button
            onClick={handleClose}
            disabled={isLoading}
            className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-4 py-1.5 text-xs font-medium hover:bg-mildBlue1"
          >
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/cancel.png"
              alt=""
              className="w-3 h-3"
            />
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={isLoading}
            className="px-6 py-1.5 bg-darkblue1 text-white text-xs font-medium hover:bg-opacity-90 transition disabled:opacity-50"
          >
            {isLoading ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditActionItemPopup;