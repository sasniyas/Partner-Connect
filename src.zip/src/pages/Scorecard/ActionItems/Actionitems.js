import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronDown, ChevronUp, MoreVertical, Menu, X ,ChevronsUpDown,ArrowUp,ArrowDown} from "lucide-react";
import Filter from "../../../Components/Filter";
import Searchinput from "../../../Components/Searchinput";
import DeleteModal from "../../../Components/DeleteModal";
import DownloadPopup from "../../../Components/Downloadpopup";
import CommentsPopup from "./Commentspopup";
import AssignActionPopup from "./Assignactionpopup";
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../services/download/bluckDownload.service";
// ═══════════════════════════════════════════════════════════════
// 📡 API SERVICE IMPORTS
// ═══════════════════════════════════════════════════════════════
import {
  getAllScorecardActionItems,
  updateScorecardActionItem,
  deleteScorecardActionItem,
} from "../../../services/scorecard/scorecardScoreView.service";

const ActionItems = ({ userRole: propsUserRole }) => {
  const navigate = useNavigate();

  // ═══════════════════════════════════════════════════════════════
  // 👤 USER ROLE - Get from props (passed from parent component)
  // ═══════════════════════════════════════════════════════════════
  // userRole is passed as prop from parent (e.g., "admin" or "user")
  const userRole = propsUserRole || "user";
  const isAdmin = userRole === "admin" || userRole === "Admin";
  
  // Debug: Log role
  console.log("👤 User Role:", userRole, "| Is Admin:", isAdmin);

  // ═══════════════════════════════════════════════════════════════
  // 📊 STATE MANAGEMENT
  // ═══════════════════════════════════════════════════════════════
  const [allItems, setAllItems] = useState([]);
  const [displayedItems, setDisplayedItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [dropdownId, setDropdownId] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLazyLoading, setIsLazyLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [isMobileView, setIsMobileView] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [showDownloadPopup, setShowDownloadPopup] = useState(false);
  const [error, setError] = useState(null);
  
  // Modal states
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [commentsModalVisible, setCommentsModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [assignModalVisible, setAssignModalVisible] = useState(false);
  const [itemToAssign, setItemToAssign] = useState(null);

  const observerRef = useRef();
  const dropdownRefs = useRef({});
  const tableContainerRef = useRef(null);
  const ITEMS_PER_LOAD = 10;

  // Filter state
  const [filters, setFilters] = useState({
    year: [],
    quarter: [],
    marketArea: [],
    dealer: [],
    createdBy: [],
    strategicObjective: [],
    status: [],
  });
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  // Filter options (will be populated from API data)
  const [filterOptions, setFilterOptions] = useState({
    years: [],
    quarters: ["Q1", "Q2", "Q3", "Q4"],
    dealers: [],
    createdByOptions: ["User", "System"],
    strategicObjectives: [],
    statuses: ["Created", "In Progress", "Completed", "Closed"],
  });

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH DATA FROM API
  // ═══════════════════════════════════════════════════════════════
  const fetchActionItems = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const data = await getAllScorecardActionItems();
      
      // Debug: Log raw data from service to check threshold/minScore values
      console.log("📊 Action Items from API:", data);
      if (data.length > 0) {
        console.log("📋 Sample item fields:", {
          threshold: data[0].threshold,
          minScore: data[0].minScore,
          maxScore: data[0].maxScore,
          finalScore: data[0].finalScore,
        });
      }
      
      // Transform API data to match component structure
      // API already returns: threshold, minScore, maxScore, finalScore, reviewerScore
      const transformedData = data.map((item) => ({
        id: item.id,
        createdBy: item.createdById ? "User" : "System",
        year: item.year || new Date().getFullYear(),
        quarter: item.quarter || "Q1",
        dealer: item.dealerName || "",
        strategicObjective: item.strategicObjective || "",
        subKPI: item.subKpi || "",
        kpiNo: item.kpiNo || "",
        createdByName: item.createdBy || "System",
        createdById: item.createdById,
        createdByEmail: item.createdByEmail || "",
        createdDate: item.createdDate || "",
        createdAt: item.createdAt,
        maxScore: item.maxScore || 0,
        reviewerScore: item.reviewerScore || 0,
        threshold: item.threshold || item.minScore || 0, // Use threshold from API (minScore)
        minScore: item.minScore || 0,
        finalScore: item.finalScore || 0,
        assignedTo: item.assignedTo || "",
        assignedToId: item.assignedToId,
        assignedToEmail: item.assignedToEmail || "",
        status: item.status || "Created",
        targetDate: item.endDate ? formatDate(item.endDate) : "",
        endDate: item.endDate,
        remarks: item.remarks || "",
        scoreViewId: item.scoreViewId,
        scorecardId: item.scorecardId,
        comments: [], // Will be fetched separately if needed
      }));

      setAllItems(transformedData);

      // Extract unique filter options from data
      const years = [...new Set(transformedData.map(item => item.year).filter(Boolean))].sort((a, b) => b - a);
      const dealers = [...new Set(transformedData.map(item => item.dealer).filter(Boolean))].sort();
      const strategicObjectives = [...new Set(transformedData.map(item => item.strategicObjective).filter(Boolean))].sort();

      setFilterOptions(prev => ({
        ...prev,
        years: years.map(String),
        dealers,
        strategicObjectives,
      }));

    } catch (err) {
      console.error("Error fetching action items:", err);
      setError(err.message || "Failed to load action items");
      setAllItems([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Helper function to format date
  const formatDate = (dateString) => {
    if (!dateString) return "";
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString("en-GB"); // DD/MM/YYYY
    } catch {
      return dateString;
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchActionItems();
  }, [fetchActionItems]);

  // ═══════════════════════════════════════════════════════════════
  // 📱 SCREEN SIZE CHECK
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 1024);
    };
    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  // Handle filter change
  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔍 FILTERED ITEMS
  // ═══════════════════════════════════════════════════════════════
  const filteredItems = useMemo(() => {
    return allItems.filter((item) => {
      return (
        (filters.year.length === 0 || filters.year.includes(String(item.year))) &&
        (filters.quarter.length === 0 || filters.quarter.includes(item.quarter)) &&
        (filters.dealer.length === 0 || filters.dealer.includes(item.dealer)) &&
        (filters.createdBy.length === 0 || filters.createdBy.includes(item.createdBy)) &&
        (filters.strategicObjective.length === 0 ||
          filters.strategicObjective.includes(item.strategicObjective)) &&
        (filters.status.length === 0 || filters.status.includes(item.status)) &&
        (searchTerm === "" ||
          String(item.year).includes(searchTerm.toLowerCase()) ||
          item.quarter?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.dealer?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.createdBy?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.strategicObjective?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.subKPI?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.createdByName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.status?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.assignedTo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.remarks?.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    });
  }, [allItems, filters, searchTerm]);

  // ═══════════════════════════════════════════════════════════════
  // ♾️ LAZY LOADING
  // ═══════════════════════════════════════════════════════════════
  const loadMoreItems = useCallback(() => {
    if (isLazyLoading || !hasMore) return;

    setIsLazyLoading(true);

    setTimeout(() => {
      const currentLength = displayedItems.length;
      const nextItems = filteredItems.slice(currentLength, currentLength + ITEMS_PER_LOAD);

      if (nextItems.length === 0) {
        setHasMore(false);
      } else {
        setDisplayedItems((prev) => [...prev, ...nextItems]);
        if (currentLength + nextItems.length >= filteredItems.length) {
          setHasMore(false);
        }
      }

      setIsLazyLoading(false);
    }, 300);
  }, [displayedItems.length, filteredItems, isLazyLoading, hasMore]);

  // Reset displayed items when filters change
  useEffect(() => {
    setDisplayedItems(filteredItems.slice(0, ITEMS_PER_LOAD));
    setHasMore(filteredItems.length > ITEMS_PER_LOAD);
  }, [filteredItems]);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return displayedItems;

  return [...displayedItems].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [displayedItems, sortKey, sortOrder]);
  // Intersection Observer
  const lastItemRef = useCallback(
    (node) => {
      if (isLazyLoading) return;
      if (observerRef.current) observerRef.current.disconnect();

      observerRef.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore) {
          loadMoreItems();
        }
      });

      if (node) observerRef.current.observe(node);
    },
    [isLazyLoading, hasMore, loadMoreItems]
  );

  // ═══════════════════════════════════════════════════════════════
  // 🎯 EVENT HANDLERS
  // ═══════════════════════════════════════════════════════════════
  
  // Toggle dropdown with auto-scroll
  const toggleDropdown = (id, e) => {
    e.stopPropagation();
    
    const newDropdownId = dropdownId === id ? null : id;
    setDropdownId(newDropdownId);
    
    if (newDropdownId && tableContainerRef.current) {
      setTimeout(() => {
        const dropdownElement = dropdownRefs.current[newDropdownId];
        const container = tableContainerRef.current;
        
        if (dropdownElement && container) {
          const dropdownRect = dropdownElement.getBoundingClientRect();
          const containerRect = container.getBoundingClientRect();
          
          const isOpeningDown = dropdownElement.classList.contains('top-full') || 
                                dropdownRect.top > containerRect.top;
          
          if (isOpeningDown) {
            const dropdownBottom = dropdownRect.bottom;
            const containerBottom = containerRect.bottom;
            
            if (dropdownBottom > containerBottom) {
              const scrollAmount = dropdownBottom - containerBottom + 20;
              container.scrollBy({
                top: scrollAmount,
                behavior: 'smooth'
              });
            }
          }
        }
      }, 50);
    }
  };

  // Handle actions
  const handleComments = (item) => {
    setDropdownId(null);
    setSelectedItem(item);
    setCommentsModalVisible(true);
  };

  // Handle comment added/updated/deleted
  const handleCommentUpdate = (itemId, updatedComments) => {
    setAllItems((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, comments: updatedComments } : item
      )
    );
    
    setDisplayedItems((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, comments: updatedComments } : item
      )
    );
  };

  const handleAssign = (item) => {
    setDropdownId(null);
    setItemToAssign(item);
    setAssignModalVisible(true);
  };

  const handleAssignComplete = async (assignmentData) => {
    console.log("Assignment completed:", assignmentData);
    
    // Update the items with the new assignment (API already called in popup)
    setAllItems((prev) =>
      prev.map((item) =>
        item.id === itemToAssign.id
          ? { 
              ...item, 
              assignedTo: assignmentData.assignTo, 
              targetDate: formatDate(assignmentData.endDate),
              status: "In Progress"
            }
          : item
      )
    );
    setDisplayedItems((prev) =>
      prev.map((item) =>
        item.id === itemToAssign.id
          ? { 
              ...item, 
              assignedTo: assignmentData.assignTo, 
              targetDate: formatDate(assignmentData.endDate),
              status: "In Progress"
            }
          : item
      )
    );

    // Close modal
    setAssignModalVisible(false);
    setItemToAssign(null);
  };

  const handleDelete = (item) => {
    setDropdownId(null);
    setItemToDelete(item);
    setDeleteModalVisible(true);
  };

  const confirmDelete = async () => {
    if (!itemToDelete) return;

    setDeleteLoading(true);

    try {
      // Call API to delete
      await deleteScorecardActionItem(itemToDelete.id);

      setAllItems((prev) => prev.filter((item) => item.id !== itemToDelete.id));
      setDisplayedItems((prev) => prev.filter((item) => item.id !== itemToDelete.id));

      setDeleteModalVisible(false);
      setItemToDelete(null);
    } catch (error) {
      console.error("Error deleting item:", error);
      alert(error.message || "Failed to delete action item");
    } finally {
      setDeleteLoading(false);
    }
  };

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutsideDropdown = (event) => {
      if (
        dropdownId !== null &&
        !Object.values(dropdownRefs.current).some((ref) => ref?.contains(event.target))
      ) {
        setDropdownId(null);
      }
    };

    document.addEventListener("mousedown", handleClickOutsideDropdown);
    return () => document.removeEventListener("mousedown", handleClickOutsideDropdown);
  }, [dropdownId]);

  // ═══════════════════════════════════════════════════════════════
  // 📱 MOBILE CARD COMPONENT
  // ═══════════════════════════════════════════════════════════════
  const ActionItemCard = ({ item, index, isLast }) => {
    return (
      <div
        ref={isLast ? lastItemRef : null}
        className="bg-white border border-gray-200 p-3 mb-3 shadow-sm"
      >
        <div className="flex justify-between items-start mb-2">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold text-black">{item.year}</span>
              <span className="text-xs font-semibold text-black">{item.quarter}</span>
              <span
                className={`text-xs font-medium px-2 py-0.5 rounded ${
                  item.status === "Completed" || item.status === "Closed"
                    ? "bg-green-100 text-green-700"
                    : item.status === "In Progress"
                    ? "bg-orange-100 text-orange-700"
                    : "bg-blue-100 text-blue-700"
                }`}
              >
                {item.status}
              </span>
            </div>
            <p className="text-xs text-gray-600">{item.strategicObjective}</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setDropdownId(dropdownId === item.id ? null : item.id);
                }}
                className="p-1.5 hover:bg-gray-100 transition-colors"
              >
                <MoreVertical size={16} className="text-black" />
              </button>

              {dropdownId === item.id && (
                <div
                  className={`absolute right-0 w-44 bg-white border border-gray-300 shadow-lg z-10 ${
                    sortedData.length > 5 && index >= sortedData.length - 3
                      ? "bottom-full mb-1"
                      : "top-full mt-1"
                  }`}
                >
                  {/* Message Log - Always visible for all roles */}
                  <button
                    onClick={() => handleComments(item)}
                    className="w-full flex items-center gap-2 py-2 px-3 hover:bg-gray-50 text-sm text-gray-700 border-b border-gray-100"
                  >
                    <img
                      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/log.png"
                      alt="Message Log"
                      className="w-3 h-3"
                    />
                    <span>{item.status === "Closed" ? "View Messages" : "Message Log"}</span>
                  </button>
                  
                  {/* Assign button - Only for User role, Hidden when Closed */}
                  {!isAdmin && item.status !== "Closed" && (
                    <button
                      onClick={() => handleAssign(item)}
                      className="w-full flex items-center gap-2 py-2 px-3 hover:bg-gray-50 text-sm text-gray-700 border-b border-gray-100"
                    >
                      <svg className="w-4 h-4 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                      <span>Assign</span>
                    </button>
                  )}
                  
                  {/* Delete button:
                      - User: Always visible (no restrictions)
                      - Admin: Only when NOT assigned (no assignedTo)
                  */}
                  {(!isAdmin || (isAdmin && !(item.assignedTo || item.assignedToName))) && (
                    <button
                      onClick={() => handleDelete(item)}
                      className="w-full flex items-center gap-2 py-2 px-3 hover:bg-gray-50 text-sm text-gray-700"
                    >
                      <img
                        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/delete.png"
                        alt="Delete"
                        className="w-3 h-3"
                      />
                      <span>Delete</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-1.5 mb-2">
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Dealer:</span>
            <span className="text-xs text-black text-right">{item.dealer}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Sub KPI:</span>
            <span className="text-xs text-black text-right">{item.subKPI}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Created By (Role):</span>
            <span className="text-xs text-black text-right">{item.createdBy}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Created By (Name):</span>
            <span className="text-xs text-black text-right">{item.createdByName}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Threshold:</span>
            <span className="text-xs text-black text-right">{item.threshold}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Assigned To:</span>
            <span className="text-xs text-black text-right">{item.assignedTo || "—"}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Target Date:</span>
            <span className="text-xs text-black text-right">{item.targetDate || "—"}</span>
          </div>
        </div>
      </div>
    );
  };
const downloadExcel = async () => {
  if (!sortedData || sortedData.length === 0) {
    alert("No data available to generate preview");
    return;
  }

  try {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Action Items");

    // ===== HEADERS =====
    sheet.columns = [
      { header: "Created By", key: "createdBy", width: 20 },
      { header: "Year", key: "year", width: 10 },
      { header: "Quarter", key: "quarter", width: 10 },
      { header: "Dealer", key: "dealer", width: 20 },
      { header: "Strategic Objective", key: "strategicObjective", width: 25 },
      { header: "Sub KPI", key: "subKPI", width: 20 },
      { header: "Created By ", key: "createdByName", width: 20 },
      { header: "Created Date", key: "createdDate", width: 15 },
      { header: "Max Score", key: "maxScore", width: 10 },
      { header: "Reviewer Score", key: "reviewerScore", width: 15 },
      { header: "Threshold", key: "threshold", width: 10 },
      { header: "Final Score", key: "finalScore", width: 10 },
      { header: "Assigned To", key: "assignedTo", width: 15 },
      { header: "Status", key: "status", width: 15 },
      { header: "Target Date", key: "targetDate", width: 15 },
    ];

    // ===== OPTIONAL: HEADER STYLE =====
    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });

    // ===== DATA ROWS =====
    sortedData.forEach((item) => {
      const row = sheet.addRow({
        createdBy: item.createdBy,
        year: item.year,
        quarter: item.quarter,
        dealer: item.dealer,
        strategicObjective: item.strategicObjective,
        subKPI: item.subKPI,
        createdByName: item.createdByName,
        createdDate: item.createdDate,
        maxScore: item.maxScore,
        reviewerScore: item.reviewerScore,
        threshold: item.threshold,
        finalScore: item.finalScore,
        assignedTo: item.assignedTo || "—",
        status: item.status,
        targetDate: item.targetDate || "—",
      });

      row.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
    });

    // ===== CREATE FILE =====
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const file = new File([blob], "ActionItems.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    // ===== UPLOAD TEMP FILE FOR PREVIEW =====
    const response = await uploadTempFile(file); // <-- your API call
    const fileUrl = response
      ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
      : null;

    if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    } else {
      console.warn("Upload succeeded but no file URL returned");
      alert("Upload succeeded but no preview available.");
    }
  } catch (error) {
    console.error("Preview generation failed:", error);
    alert("Failed to generate preview. Check console for details.");
  }
};


  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="w-full h-screen flex flex-col">
      {/* Title - Centered */}
      <div className="flex items-center justify-center relative">
        <h2 className="text-xl font-semibold text-darkblue1 font-VolvoNovum">
          Action Items
        </h2>

        <div className="absolute right-0 flex items-center gap-2">
          <button
             onClick={downloadExcel}
            className="flex items-center justify-center sm:justify-between text-xs font-medium bg-darkblue1 text-white px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
          >
            <span>Download</span>
           
          </button>
        </div>
      </div>

      {/* Desktop Filters - Horizontal Layout */}
      <div className="hidden lg:flex items-center gap-2 py-2">
        <Searchinput
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search"
          className="w-[1/2]"
          iconColor="text-black"
          bgColor="bg-FrostWhite"
          borderColor="border-black/60"
          textColor="text-black"
          shadow="shadow-none"
          inputPadding="pl-7 pr-3 py-1.5"
          iconSize="w-3.5 h-3.5"
          iconLeft="left-3"
          inputWidth="w-full"
          focusRing="focus:ring-1 focus:ring-black/60"
          hoverInputClasses="hover:bg-white hover:border-black/60"
        />
        <Filter
          name="year"
          value={filters.year}
          options={filterOptions.years}
          onChange={handleFilterChange}
          placeholder="Year"
          customWidth="w-28"
          placeholderColor="text-black"
          buttonBorderColor="border-black/60"
          dropdownBgColor="bg-white"
          dropdownTextColor="text-black"
          dropdownHoverColor="hover:bg-lightBlue/50"
          dropdownBorderColor="border-black/60"
          closedBgColor="bg-white"
          hoverRingColor="ring-black"
          openBgColor="bg-white"
          textColor="text-black"
        />
        <Filter
          name="createdBy"
          value={filters.createdBy}
          options={filterOptions.createdByOptions}
          onChange={handleFilterChange}
          placeholder="Created By"
          customWidth="w-32"
          placeholderColor="text-black"
          buttonBorderColor="border-black/60"
          dropdownBgColor="bg-white"
          dropdownTextColor="text-black"
          dropdownHoverColor="hover:bg-lightBlue/50"
          dropdownBorderColor="border-black/60"
          closedBgColor="bg-white"
          hoverRingColor="ring-black"
          openBgColor="bg-white"
          textColor="text-black"
        />
       
        <Filter
          name="quarter"
          value={filters.quarter}
          options={filterOptions.quarters}
          onChange={handleFilterChange}
          placeholder="Quarter"
          customWidth="w-28"
          placeholderColor="text-black"
          buttonBorderColor="border-black/60"
          dropdownBgColor="bg-white"
          dropdownTextColor="text-black"
          dropdownHoverColor="hover:bg-lightBlue/50"
          dropdownBorderColor="border-black/60"
          closedBgColor="bg-white"
          hoverRingColor="ring-black"
          openBgColor="bg-white"
          textColor="text-black"
        />
        <Filter
          name="dealer"
          value={filters.dealer}
          options={filterOptions.dealers}
          onChange={handleFilterChange}
          placeholder="Dealer"
          customWidth="w-36"
          placeholderColor="text-black"
          buttonBorderColor="border-black/60"
          dropdownBgColor="bg-white"
          dropdownTextColor="text-black"
          dropdownHoverColor="hover:bg-lightBlue/50"
          dropdownBorderColor="border-black/60"
          closedBgColor="bg-white"
          hoverRingColor="ring-black"
          openBgColor="bg-white"
          textColor="text-black"
        />
         <Filter
          name="strategicObjective"
          value={filters.strategicObjective}
          options={filterOptions.strategicObjectives}
          onChange={handleFilterChange}
          placeholder="Strategic Objective"
          customWidth="w-48"
          placeholderColor="text-black"
          buttonBorderColor="border-black/60"
          dropdownBgColor="bg-white"
          dropdownTextColor="text-black"
          dropdownHoverColor="hover:bg-lightBlue/50"
          dropdownBorderColor="border-black/60"
          closedBgColor="bg-white"
          hoverRingColor="ring-black"
          openBgColor="bg-white"
          textColor="text-black"
        />
        
        <Filter
          name="status"
          value={filters.status}
          options={filterOptions.statuses}
          onChange={handleFilterChange}
          placeholder="Status"
          customWidth="w-32"
          placeholderColor="text-black"
          buttonBorderColor="border-black/60"
          dropdownBgColor="bg-white"
          dropdownTextColor="text-black"
          dropdownHoverColor="hover:bg-lightBlue/50"
          dropdownBorderColor="border-black/60"
          closedBgColor="bg-white"
          hoverRingColor="ring-black"
          openBgColor="bg-white"
          textColor="text-black"
        />
      </div>

      {/* Mobile Filters */}
      <div className="lg:hidden py-2">
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="flex-1">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="w-full"
              iconColor="text-black"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              shadow="shadow-none"
              inputPadding="pl-7 pr-3 py-1.5"
              iconSize="w-3.5 h-3.5"
              iconLeft="left-3"
              inputWidth="w-full"
              focusRing="focus:ring-1 focus:ring-black/60"
              hoverInputClasses="hover:bg-white hover:border-black/60"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center justify-center gap-2 px-4 py-2 border border-black bg-white hover:bg-gray-50"
          >
            {showFilters ? <X size={16} /> : <Menu size={16} />}
            <span className="text-sm">Filters</span>
          </button>
        </div>

        {showFilters && (
          <div className="bg-white border border-gray-200 p-3 space-y-2 mt-2">
            <div className="grid grid-cols-2 gap-2">
              <Filter
                name="year"
                value={filters.year}
                options={filterOptions.years}
                onChange={handleFilterChange}
                placeholder="Year"
                customWidth="w-full"
                placeholderColor="text-black"
                buttonBorderColor="border-black"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />
              <Filter
                name="quarter"
                value={filters.quarter}
                options={filterOptions.quarters}
                onChange={handleFilterChange}
                placeholder="Quarter"
                customWidth="w-full"
                placeholderColor="text-black"
                buttonBorderColor="border-black"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />
              <Filter
                name="dealer"
                value={filters.dealer}
                options={filterOptions.dealers}
                onChange={handleFilterChange}
                placeholder="Dealer"
                customWidth="w-full"
                placeholderColor="text-black"
                buttonBorderColor="border-black"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />
              <Filter
                name="status"
                value={filters.status}
                options={filterOptions.statuses}
                onChange={handleFilterChange}
                placeholder="Status"
                customWidth="w-full"
                placeholderColor="text-black"
                buttonBorderColor="border-black"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />
            </div>
          </div>
        )}
      </div>

      {/* Error State */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded p-4 mb-4">
          <div className="flex items-center justify-between">
            <span className="text-red-600 text-sm">{error}</span>
            <button
              onClick={fetchActionItems}
              className="text-red-600 hover:text-red-800 text-sm underline"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Data Display - Auto height based on content */}
      <div className="flex-1 min-h-0">
        {isMobileView ? (
          /* Mobile Card View */
          <div className="overflow-y-auto hide-scrollbar" style={{ maxHeight: 'calc(100vh - 200px)' }}>
            <style jsx>{`
              .hide-scrollbar::-webkit-scrollbar {
                display: none;
              }
              .hide-scrollbar {
                -ms-overflow-style: none;
                scrollbar-width: none;
              }
            `}</style>
            
            <div className="space-y-3 pb-4">
              {isLoading && sortedData.length === 0 ? (
                <div className="bg-white border border-gray-200 p-6 text-center">
                  <div className="flex items-center justify-center gap-2">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                    <span className="text-gray-500 text-sm">Loading action items...</span>
                  </div>
                </div>
              ) : sortedData.length > 0 ? (
                <>
                  {sortedData.map((item, index) => (
                    <ActionItemCard
                      key={`${item.id}-${index}`}
                      item={item}
                      index={index}
                      isLast={index === sortedData.length - 1}
                    />
                  ))}
                  {isLazyLoading && (
                    <div className="flex justify-center py-3">
                      <div className="flex items-center gap-2">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        <span className="text-sm text-gray-500">Loading more...</span>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="bg-white border border-gray-200 p-6 text-center text-gray-500">
                  No action items found
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Desktop Table View */
          
          <div 
            ref={tableContainerRef}
            className="bg-white shadow-md border border-Dustyblue overflow-auto hide-scrollbar" 
            style={{ maxHeight: 'calc(100vh - 200px)' }}
  onScroll={handleTableScroll}
          >
            <style jsx>{`
              .hide-scrollbar::-webkit-scrollbar {
                display: none;
              }
              .hide-scrollbar {
                -ms-overflow-style: none;
                scrollbar-width: none;
              }
            `}</style>
            
<table className="w-full text-xs border-collapse table-fixed">      
          <thead className="bg-Dustyblue text-white sticky top-0 z-20">
              <tr>
  {/* Year */}
  <th
    className="py-1.5 px-1 text-left text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[3%] cursor-pointer select-none"
    onClick={() => handleSort("year")}
  >
    <div className="flex items-center gap-1">
      Year
      {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}


      {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Created By */}
  <th
    className="py-1.5 px-1 text-left text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("createdBy")}
  >
    <div className="flex items-center gap-1">
      Created By
      {sortKey === "createdBy" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "createdBy" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Quarter */}
  <th
    className="py-1.5 px-1 text-center text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("quarter")}
  >
    <div className="flex items-center justify-center gap-1">
      Quarter
      {sortKey === "quarter" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "quarter" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Dealer */}
  <th
    className="py-1.5 px-1 text-left text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("dealer")}
  >
    <div className="flex items-center gap-1">
      Dealer
      {sortKey === "dealer" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "dealer" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Strategic Objective */}
  <th
    className="py-1.5 px-1 text-left text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[6%] cursor-pointer select-none"
    onClick={() => handleSort("strategicObjective")}
  >
    <div className="flex items-center gap-1">
      Strategic Objective
      {sortKey === "strategicObjective" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "strategicObjective" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Sub KPI */}
  <th
    className="py-1.5 px-1 text-left text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("subKPI")}
  >
    <div className="flex items-center gap-1">
      Sub KPI
      {sortKey === "subKPI" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "subKPI" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Created By (Second) */}
  <th
    className="py-1.5 px-1 text-left text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[6%] cursor-pointer select-none"
    onClick={() => handleSort("createdByName")}
  >
    <div className="flex items-center gap-1">
      Created By
      {sortKey === "createdByName" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "createdByName" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Created Date */}
  <th
    className="py-1.5 px-1 text-left text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[7%] cursor-pointer select-none"
    onClick={() => handleSort("createdDate")}
  >
    <div className="flex items-center gap-1">
      Created Date
      {sortKey === "createdDate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "createdDate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Max Score */}
  <th
    className="py-1.5 px-1 text-center text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("maxScore")}
  >
    <div className="flex items-center justify-center gap-1">
      Max Score
      {sortKey === "maxScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "maxScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Reviewer Score */}
  <th
    className="py-1.5 px-1 text-center text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[6%] cursor-pointer select-none"
    onClick={() => handleSort("reviewerScore")}
  >
    <div className="flex items-center justify-center gap-1">
      Reviewer Score
      {sortKey === "reviewerScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "reviewerScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Threshold */}
  <th
    className="py-1.5 px-1 text-center text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("threshold")}
  >
    <div className="flex items-center justify-center gap-1">
      Threshold
      {sortKey === "threshold" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "threshold" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Final Score */}
  <th
    className="py-1.5 px-1 text-center text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("finalScore")}
  >
    <div className="flex items-center justify-center gap-1">
      Final Score
      {sortKey === "finalScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "finalScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Assigned To */}
  <th
    className="py-1.5 px-1 text-left text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("assignedTo")}
  >
    <div className="flex items-center gap-1">
      Assigned To
      {sortKey === "assignedTo" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "assignedTo" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Status */}
  <th
    className="py-1.5 px-1 text-left text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("status")}
  >
    <div className="flex items-center gap-1">
      Status
      {sortKey === "status" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "status" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Target Date */}
  <th
    className="py-1.5 px-1 text-left text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[6%] cursor-pointer select-none"
    onClick={() => handleSort("targetDate")}
  >
    <div className="flex items-center gap-1">
      Target Date
      {sortKey === "targetDate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "targetDate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

                  <th className="px-1 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 w-[3%]">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {isLoading && sortedData.length === 0 ? (
                  <tr>
                    <td colSpan="16" className="text-center py-8 text-xs text-gray-500 italic">
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        Loading action items...
                      </div>
                    </td>
                  </tr>
                ) : sortedData.length > 0 ? (
                  <>
                    {sortedData.map((item, idx) => {
                      const rowId = `${item.id}-${idx}`;
                      const isLast = idx === sortedData.length - 1;

                      return (
                        <React.Fragment key={rowId}>
                          <tr
                            ref={isLast ? lastItemRef : null}
                            className="hover:bg-lightBlue/50 cursor-pointer"
                          >
                            
                            <td className="px-1 py-1 text-left border border-grey2 border-t-0 border-l-0 text-xs">
                              {item.year}
                            </td>
                          <td className="px-1 py-1 text-xs text-left border border-grey2 border-t-0 border-l-0 z-0">
  <div className="relative">
    <p
      className="truncate max-w-[10rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.createdBy?.length > 18)
          setHoveredCell(item.id + "-createdBy");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.createdBy || "-"}
    </p>

    {hoveredCell === item.id + "-createdBy" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {item.createdBy}
      </span>
    )}
  </div>
</td>
                            <td className="px-1 py-1 text-center border border-grey2 border-t-0 border-l-0 text-xs">
                              {item.quarter}
                            </td>
                           <td className="px-1 py-1 text-xs text-left border border-grey2 border-t-0 border-l-0 z-0">
  <div className="relative">
    <p
      className="truncate max-w-[6rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.dealer?.length > 18)
          setHoveredCell(item.id + "-dealer");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.dealer || "-"}
    </p>

    {hoveredCell === item.id + "-dealer" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {item.dealer}
      </span>
    )}
  </div>
</td>
                           <td className="px-1 py-1 text-xs text-left border border-grey2 border-t-0 border-l-0 z-0">
  <div className="relative">
    <p
      className="truncate max-w-[5rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.strategicObjective?.length > 18)
          setHoveredCell(item.id + "-strategicObjective");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.strategicObjective || "-"}
    </p>

    {hoveredCell === item.id + "-strategicObjective" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {item.strategicObjective}
      </span>
    )}
  </div>
</td>
                         <td className="px-1 py-1 text-xs text-left border border-grey2 border-t-0 border-l-0 z-0">
  <div className="relative">
    <p
      className="truncate max-w-[5rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.subKPI?.length > 18)
          setHoveredCell(item.id + "-subKPI");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.subKPI || "-"}
    </p>

    {hoveredCell === item.id + "-subKPI" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {item.subKPI}
      </span>
    )}
  </div>
</td>
                           <td className="px-1 py-1 text-xs text-left border border-grey2 border-t-0 border-l-0 z-0">
  <div className="relative">
    <p
      className="truncate max-w-[5rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.createdByName?.length > 18)
          setHoveredCell(item.id + "-createdByName");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.createdByName || "-"}
    </p>

    {hoveredCell === item.id + "-createdByName" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {item.createdByName}
      </span>
    )}
  </div>
</td>
<td className="px-1 py-1 text-xs text-left border border-grey2 border-t-0 border-l-0 z-0">
  <div className="relative">
    <p
      className="truncate max-w-[6rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.createdDate?.length > 18)
          setHoveredCell(item.id + "-createdDate");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.createdDate || "-"}
    </p>

    {hoveredCell === item.id + "-createdDate" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {item.createdDate}
      </span>
    )}
  </div>
</td>
                            <td className="px-1 py-1 text-center border border-grey2 border-t-0 border-l-0 text-xs">
                              {item.maxScore}
                            </td>
                            <td className="px-1 py-1 text-center border border-grey2 border-t-0 border-l-0 text-xs">
                              {item.reviewerScore}
                            </td>
                            <td className="px-1 py-1 text-center border border-grey2 border-t-0 border-l-0 text-xs">
                              {item.threshold}
                            </td>
                            <td className="px-1 py-1 text-center border border-grey2 border-t-0 border-l-0 text-xs">
                              {item.finalScore}
                            </td>
                         <td className="px-1 py-1 text-xs text-left border border-grey2 border-t-0 border-l-0 z-0">
  <div className="relative">
    <p
      className="truncate max-w-[4rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.assignedTo?.length > 10)
          setHoveredCell(item.id + "-assignedTo");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.assignedTo || "—"}
    </p>

    {hoveredCell === item.id + "-assignedTo" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {item.assignedTo}
      </span>
    )}
  </div>
</td>
                          <td className="px-1 py-1 text-xs text-left border border-grey2 border-t-0 border-l-0 z-0">
  <div className="relative">
    <span
      className={`inline-block text-center font-medium truncate max-w-[5rem] cursor-pointer ${
        item.status === "Completed" || item.status === "Closed"
          ? "text-green"
          : item.status === "In Progress"
          ? "text-orange-600"
          : "text-mildBlue"
      }`}
      onMouseEnter={() => {
        if (item.status?.length > 18)
          setHoveredCell(item.id + "-status");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.status}
    </span>

    {hoveredCell === item.id + "-status" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {item.status}
      </span>
    )}
  </div>
</td>
                            <td className="px-1 py-1 text-left border border-grey2 border-t-0 border-l-0 text-xs">
                              {item.targetDate || "—"}
                            </td>
                            
                            {/* Action Column - Dropdown */}
                            <td className="px-1 py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0 text-xs">
                              <div className="flex justify-center relative">
                                <button
                                  onClick={(e) => toggleDropdown(rowId, e)}
                                  className="w-5 h-5 flex items-center justify-center hover:bg-gray-100"
                                >
                                  <MoreVertical size={14} className="text-black" />
                                </button>

                                {dropdownId === rowId && (
                                  <div
                                    ref={(el) => (dropdownRefs.current[rowId] = el)}
                                    className={`absolute bg-white w-32 border border-gray-200 shadow-lg z-10 ${
                                      displayedItems.length > 5 && idx >= displayedItems.length - 3
                                        ? "bottom-full right-0 mb-1"
                                        : "top-full right-0 mt-1"
                                    }`}
                                  >
                                    <div className="py-0.5 flex flex-col">
                                      {/* Message Log - Always visible for all roles */}
                                      <button
                                        onClick={() => handleComments(item)}
                                        className="w-full px-2.5 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2 border-b border-gray-100"
                                      >
                                        <img
                                          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/log.png"
                                          alt="Message Log"
                                          className="w-3 h-3"
                                        />
                                        <span>{item.status === "Closed" ? "View Messages" : "Message Log"}</span>
                                      </button>
                                      
                                      {/* Assign button - Only for User role, Hidden when Closed */}
                                      {!isAdmin && item.status !== "Closed" && (
                                        <button
                                          onClick={() => handleAssign(item)}
                                          className="w-full px-2.5 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2 border-b border-gray-100"
                                        >
                                          <svg className="w-3.5 h-3.5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                          </svg>
                                          <span>Assign</span>
                                        </button>
                                      )}
                                      
                                      {/* Delete button:
                                          - User: Always visible (no restrictions)
                                          - Admin: Only when NOT assigned (no assignedTo)
                                      */}
                                      {(!isAdmin || (isAdmin && !(item.assignedTo || item.assignedToName))) && (
                                        <button
                                          onClick={() => handleDelete(item)}
                                          className="w-full px-2.5 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                        >
                                          <img
                                            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/delete.png"
                                            alt="Delete"
                                            className="w-3 h-3"
                                          />
                                          <span>Delete</span>
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>
                            </td>
                          </tr>
                        </React.Fragment>
                      );
                    })}

                    {isLazyLoading && (
                      <tr>
                        <td colSpan="16" className="px-6 py-3 text-center text-gray-500">
                          <div className="flex items-center justify-center gap-2">
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                            <span className="text-xs">Loading more...</span>
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                ) : (
                  <tr>
                    <td colSpan="16" className="text-center py-8 text-xs text-gray-500 italic">
                      No action items found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
        )}
         {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}



      </div>

      {/* Delete Modal */}
      <DeleteModal
        isOpen={deleteModalVisible}
        onClose={() => {
          if (!deleteLoading) {
            setDeleteModalVisible(false);
            setItemToDelete(null);
          }
        }}
        onConfirm={confirmDelete}
        loading={deleteLoading}
        extraMessage="This action cannot be undone."
      />

      {/* Download Popup */}
      {showDownloadPopup && (
        <DownloadPopup
          title="Action Items"
          fileName="Action_Items.xlsx"
          fileContent={filteredItems}
          description="Action items have been exported. Click the link below to download the Excel file."
          onClose={() => setShowDownloadPopup(false)}
          lineColor="border-mildBlue"
        />
      )}

      {/* Message Log Modal */}
      <CommentsPopup
        isOpen={commentsModalVisible}
        onClose={() => {
          setCommentsModalVisible(false);
          setSelectedItem(null);
        }}
        item={selectedItem}
        isAdmin={isAdmin}
        onCommentAdded={handleCommentUpdate}
        onStatusChange={(itemId, newStatus) => {
          // Update status in allItems
          setAllItems((prev) =>
            prev.map((item) =>
              item.id === itemId ? { ...item, status: newStatus } : item
            )
          );
          // Update status in displayedItems
          setDisplayedItems((prev) =>
            prev.map((item) =>
              item.id === itemId ? { ...item, status: newStatus } : item
            )
          );
          // Update selectedItem status
          setSelectedItem((prev) =>
            prev && prev.id === itemId ? { ...prev, status: newStatus } : prev
          );
        }}
      />

      {/* Assign Action Modal */}
      <AssignActionPopup
        isOpen={assignModalVisible}
        onClose={() => {
          setAssignModalVisible(false);
          setItemToAssign(null);
        }}
        item={itemToAssign}
        onAssign={handleAssignComplete}
      />
    </div>
  );
};

export default ActionItems;