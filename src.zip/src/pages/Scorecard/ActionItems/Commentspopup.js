import React, { useState, useEffect, useMemo } from "react";
import { X, MoreVertical, ArrowLeft, Download ,ChevronDown,ChevronUp} from "lucide-react";
import DeleteModal from "../../../Components/DeleteModal";
import Filter from "../../../Components/Filter";
import Searchinput from "../../../Components/Searchinput";
import ExcelJS from "exceljs";

// ═══════════════════════════════════════════════════════════════
// 📡 API SERVICE IMPORTS
// ═══════════════════════════════════════════════════════════════
import {
  getScorecardActionLogsByActionItemId,
  addScorecardActionLog,
  updateScorecardActionLog,
  deleteScorecardActionLog,
  updateScorecardActionItem,
} from "../../../services/scorecard/scorecardScoreView.service";
import { uploadTempFile } from "../../../services/download/bluckDownload.service";
const CommentsPopup = ({ isOpen, onClose, item, isAdmin = false, onCommentAdded, onStatusChange }) => {
  const [showAddMessageModal, setShowAddMessageModal] = useState(false);
  const [showEditMessageModal, setShowEditMessageModal] = useState(false);
  const [newComment, setNewComment] = useState("");
  const [supportingDocument, setSupportingDocument] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [dropdownId, setDropdownId] = useState(null);
  const [editingComment, setEditingComment] = useState(null);
  const [editingIndex, setEditingIndex] = useState(null);
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [commentToDelete, setCommentToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [closeConfirmVisible, setCloseConfirmVisible] = useState(false); // Close Item confirmation modal
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState([]);
  const [timeFilter, setTimeFilter] = useState([]);
  const [popupView, setPopupView] = useState("TABLE"); 
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  // TABLE | ADD | EDIT
  const [editData, setEditData] = useState(null);

  // Local state to store current comments
  const [localComments, setLocalComments] = useState([]);

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH COMMENTS FROM API
  // ═══════════════════════════════════════════════════════════════
  const fetchComments = async () => {
    if (!item?.id) return;

    setIsLoading(true);
    try {
      const data = await getScorecardActionLogsByActionItemId(item.id);

      // Transform API data to local format
      const transformedComments = data.map((log) => ({
        id: log.id,
        commentedById: log.commentedBy || null,  // User ID who commented
        commentedBy: log.commentedByName || "User",  // User name
        date: log.createdDate || "",
        time: "",
        text: log.comments || "",
        supportingDocument: log.supportingDocUrl || null,
      }));

      setLocalComments(transformedComments);
    } catch (err) {
      console.error("Error fetching comments:", err);
      setLocalComments([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Update local comments when item changes or popup opens
  useEffect(() => {
    if (isOpen && item?.id) {
      fetchComments();
      setPopupView("TABLE");
      setNewComment("");
      setSupportingDocument(null);
    } else if (item && item.comments) {
      setLocalComments(item.comments);
    } else if (item) {
      setLocalComments([]);
    }
  }, [isOpen, item]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownId !== null && !event.target.closest('.dropdown-container')) {
        setDropdownId(null);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [dropdownId]);

  // Helper function to check if date matches time filter
  const matchesTimeFilter = (dateString) => {
    if (timeFilter.length === 0) return true;

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const commentDate = parseDate(dateString);
    if (!commentDate) return true;
    commentDate.setHours(0, 0, 0, 0);

    for (const filter of timeFilter) {
      if (filter === "Today") {
        if (commentDate.getTime() === today.getTime()) return true;
      } else if (filter === "This Week") {
        const weekAgo = new Date(today);
        weekAgo.setDate(today.getDate() - 7);
        if (commentDate >= weekAgo) return true;
      } else if (filter === "This Month") {
        const monthAgo = new Date(today);
        monthAgo.setMonth(today.getMonth() - 1);
        if (commentDate >= monthAgo) return true;
      } else if (filter === "All Time") {
        return true;
      }
    }
    return false;
  };

  // Helper function to parse date in DD/MM/YYYY format
  const parseDate = (dateString) => {
    if (!dateString) return null;
    const parts = dateString.split('/');
    if (parts.length !== 3) return null;
    // DD/MM/YYYY format
    return new Date(parts[2], parts[1] - 1, parts[0]);
  };

  // Filter comments based on search and filters
  const filteredComments = useMemo(() => {
    if (!item) return [];
    
    return localComments.filter((comment) => {
      // Search filter
      const matchesSearch = searchTerm === "" ||
        comment.commentedBy?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        comment.text?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        comment.date?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        comment.supportingDocument?.toLowerCase().includes(searchTerm.toLowerCase());

      // Status filter
      const matchesStatus = statusFilter.length === 0 || statusFilter.includes(item.status);

      // Time filter
      const matchesTime = matchesTimeFilter(comment.date);

      return matchesSearch && matchesStatus && matchesTime;
    });
  }, [localComments, searchTerm, statusFilter, timeFilter, item]);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredComments;

  return [...filteredComments].sort((a, b) => {
    let valA = a[sortKey];
    let valB = b[sortKey];

    /* -------------------- DATE + TIME SORTING -------------------- */
  if (sortKey === "date" || sortKey === "createdDate" || sortKey === "editedDate") {

  const getDateTime = (item) => {
    const rawDate =
      item[sortKey] ||     // 👈 use actual clicked column
      item.date ||
      item.createdDate ||
      item.editedDate;

    if (!rawDate) return null;

    const parts = rawDate.split("/");
    if (parts.length !== 3) return null;

    const [day, month, year] = parts;

    let hours = 0;
    let minutes = 0;

    if (item.time) {
      const timeParts = item.time.split(":");
      hours = parseInt(timeParts[0]) || 0;
      minutes = parseInt(timeParts[1]) || 0;
    }

    return new Date(
      Number(year),
      Number(month) - 1,
      Number(day),
      hours,
      minutes
    );
  };

  const dateA = getDateTime(a);
  const dateB = getDateTime(b);

  if (!dateA && !dateB) return 0;
  if (!dateA) return sortOrder === "asc" ? 1 : -1;
  if (!dateB) return sortOrder === "asc" ? -1 : 1;

  return sortOrder === "asc"
    ? dateA - dateB
    : dateB - dateA;
}

    /* -------------------- STRING SORTING -------------------- */
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (!strA && !strB) return 0;
    if (!strA) return sortOrder === "asc" ? 1 : -1;
    if (!strB) return sortOrder === "asc" ? -1 : 1;

    return sortOrder === "asc"
      ? strA.localeCompare(strB)
      : strB.localeCompare(strA);
  });
}, [filteredComments, sortKey, sortOrder]);
  // Filter options
  const statusOptions = ["Created", "In Progress", "Closed", "Completed"];
  const timeOptions = ["Today", "This Week", "This Month", "All Time"];

  // Debug: Log item status
  console.log("📋 CommentsPopup - Item status:", item?.status, "| Full item:", item);

  if (!isOpen || !item) return null;

  // ═══════════════════════════════════════════════════════════════
  // 💾 ADD NEW COMMENT WITH API
  // ═══════════════════════════════════════════════════════════════
  const handleSubmit = async () => {
    if (!newComment.trim()) {
      alert("Please enter a comment");
      return;
    }

    setIsSubmitting(true);

    try {
      // Call API to add comment
      const response = await addScorecardActionLog({
        actionItemId: item.id,
        comments: newComment,
        file: supportingDocument,
      });

      const currentTime = new Date();
      const newCommentObj = {
        id: response?.id || Date.now(),
        commentedById: response?.commentedBy || null,  // User ID who commented
        commentedBy: response?.commentedByName || "Current User",
        date: currentTime.toLocaleDateString("en-GB"),
        time: currentTime.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true }),
        text: newComment,
        supportingDocument: response?.supportingDocUrl || (supportingDocument ? supportingDocument.name : null),
      };

      const updatedComments = [newCommentObj, ...localComments];
      
      // Update local state immediately
      setLocalComments(updatedComments);
      
      // Call the parent handler to update the state
      if (onCommentAdded) {
        onCommentAdded(item.id, updatedComments);
      }

      // Reset form
      setNewComment("");
      setSupportingDocument(null);
      setPopupView("TABLE");

      console.log("Message added successfully", updatedComments);
    } catch (error) {
      console.error("Error adding comment:", error);
      alert(error.message || "Failed to add message");
    } finally {
      setIsSubmitting(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // ✏️ EDIT COMMENT WITH API
  // ═══════════════════════════════════════════════════════════════
  const handleEditSubmit = async () => {
    if (!newComment.trim()) {
      alert("Please enter a comment");
      return;
    }

    if (!editData?.id) {
      alert("No comment selected for editing");
      return;
    }

    setIsSubmitting(true);

    try {
      // Call API to update comment
      await updateScorecardActionLog({
        id: editData.id,
        comments: newComment,
        file: supportingDocument,
      });

      const currentTime = new Date();
      
      const updatedComments = localComments.map((comment) =>
        comment.id === editData.id
          ? {
              ...comment,
              text: newComment,
              supportingDocument: supportingDocument ? supportingDocument.name : comment.supportingDocument,
              editedDate: currentTime.toLocaleDateString("en-GB"),
              editedTime: currentTime.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true }),
            }
          : comment
      );

      // Update local state immediately
      setLocalComments(updatedComments);
      
      if (onCommentAdded) {
        onCommentAdded(item.id, updatedComments);
      }

      setNewComment("");
      setSupportingDocument(null);
      setPopupView("TABLE");
      setEditingComment(null);
      setEditingIndex(null);
      setEditData(null);
      
      console.log("Message updated successfully", updatedComments);
    } catch (error) {
      console.error("Error updating comment:", error);
      alert(error.message || "Failed to update message");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (comment, index) => {
    setDropdownId(null);
    setEditingComment(comment);
    setEditingIndex(index);
    setNewComment(comment.text);
    setSupportingDocument(comment.supportingDocument ? { name: comment.supportingDocument } : null);
    setShowEditMessageModal(true);
  };

  // ═══════════════════════════════════════════════════════════════
  // 🗑️ DELETE COMMENT WITH API
  // ═══════════════════════════════════════════════════════════════
  const handleDelete = (index) => {
    setDropdownId(null);
    setCommentToDelete(index);
    setDeleteModalVisible(true);
  };

  const confirmDelete = async () => {
    if (commentToDelete === null) return;

    setDeleteLoading(true);

    try {
      // Get the comment to delete
      const commentObj = localComments[commentToDelete];
      
      // Call API to delete
      if (commentObj?.id) {
        await deleteScorecardActionLog(commentObj.id);
      }

      const updatedComments = [...localComments];
      updatedComments.splice(commentToDelete, 1);
      
      // Update local state immediately
      setLocalComments(updatedComments);
      
      if (onCommentAdded) {
        onCommentAdded(item.id, updatedComments);
      }

      setDeleteModalVisible(false);
      setCommentToDelete(null);
      
      console.log("Message deleted successfully", updatedComments);
    } catch (error) {
      console.error("Error deleting comment:", error);
      alert(error.message || "Failed to delete message");
    } finally {
      setDeleteLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔒 CLOSE ACTION ITEM
  // ═══════════════════════════════════════════════════════════════
  const handleCloseItem = () => {
    if (!item?.id) return;
    // Show custom confirmation modal
    setCloseConfirmVisible(true);
  };

  const confirmCloseItem = async () => {
    if (!item?.id) return;

    setIsClosing(true);

    try {
      // Call API to update status to "Closed"
      await updateScorecardActionItem({
        id: item.id,
        action_item_status: "Closed",
      });

      // Add a log entry for the closure
      await addScorecardActionLog({
        actionItemId: item.id,
        comments: "Action item closed",
      });

      // Refresh comments to show the closure log
      await fetchComments();

      // Notify parent to update status
      if (onStatusChange) {
        onStatusChange(item.id, "Closed");
      }

      setCloseConfirmVisible(false);
      console.log("Action item closed successfully");
    } catch (error) {
      console.error("Error closing action item:", error);
      alert(error.message || "Failed to close action item");
    } finally {
      setIsClosing(false);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSupportingDocument(file);
    }
  };

  const handleCloseAddModal = () => {
    if (!isSubmitting) {
      setShowAddMessageModal(false);
      setNewComment("");
      setSupportingDocument(null);
    }
  };

  const handleCloseEditModal = () => {
    if (!isSubmitting) {
      setShowEditMessageModal(false);
      setNewComment("");
      setSupportingDocument(null);
      setEditingComment(null);
      setEditingIndex(null);
    }
  };

  const toggleDropdown = (index, e) => {
    e.stopPropagation();
    setDropdownId(dropdownId === index ? null : index);
  };

  const handleFilterChange = (name, value) => {
    if (name === "status") {
      setStatusFilter(value);
    } else if (name === "time") {
      setTimeFilter(value);
    }
  };

  const handleDownloadComments = async () => {
  if (!filteredComments || filteredComments.length === 0) {
    alert("No comments available to download");
    return;
  }

  try {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Comments Log");

    // ===== HEADERS =====
    sheet.columns = [
      { header: "System / User", key: "systemUser", width: 20 },
      { header: "Commented By", key: "commentedBy", width: 20 },
      { header: "Comments", key: "comments", width: 40 },
      { header: "Created Date", key: "createdDate", width: 20 },
      { header: "Supporting Document", key: "supportingDocument", width: 25 },
      { header: "Status", key: "status", width: 15 },
      { header: "Action Details", key: "actionDetails", width: 30 },
    ];

    // ===== HEADER STYLE =====
    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" }, // Dusty blue
      };
      cell.alignment = {
        vertical: "middle",
        horizontal: "left",
      };
    });

    // ===== DATA ROWS =====
    filteredComments.forEach((comment) => {
      const row = sheet.addRow({
        systemUser: item.createdBy || "-",
        commentedBy: comment.commentedBy || "-",
        comments: comment.text || "-",
        createdDate: comment.editedDate
          ? `${comment.date} (Edited: ${comment.editedDate})`
          : comment.date || "-",
        supportingDocument: comment.supportingDocument || "-",
        status: item.status || "-",
        actionDetails: `${comment.date || ""} ${comment.time || ""} By ${comment.commentedBy || ""}`,
      });

      // ✅ FORCE LEFT ALIGNMENT FOR ALL CELLS
      row.eachCell((cell) => {
        cell.alignment = {
          vertical: "middle",
          horizontal: "left",
        };
      });
    });

    // ===== CREATE FILE =====
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const file = new File([blob], "Comments_Log.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    // ===== UPLOAD TEMP FILE FOR PREVIEW =====
    const response = await uploadTempFile(file);

    const fileUrl = response
      ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
      : null;

    if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    } else {
      alert("Upload succeeded but preview not available");
    }
  } catch (error) {
    console.error("Comments export failed:", error);
    alert("Failed to generate comments preview");
  }
};

  return (
    <>
      {/* Main Message Log Modal */}
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div
          onClick={(e) => e.stopPropagation()}
          className={`
            bg-white p-6 shadow-lg relative
            ${
              popupView === "TABLE"
                ? "w-[90%]"
              : popupView === "EDIT"
                ? "w-[50%]"
              : popupView === "ADD"
                ? "w-[50%]"
              : "w-[70%]"
            }
          `}
        >          
          {/* Header */}
          {popupView === "TABLE" && (
            <>
              {/* HEADER */}
              <div className="flex items-center justify-between px-6 py-3">
                <div className="flex items-center gap-1">
                  <ArrowLeft
                    onClick={onClose}
                    size={20}
                    className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
                  />

                  <h2 className="text-base font-semibold text-darkblue1">
                    {item.subKPI}
                  </h2>
                </div>

                <div className="flex items-center gap-3">
                  <span
                    className={`px-3 py-1 text-xs font-medium ${
                      item.status === "Completed" || item.status === "Closed"
                        ? "bg-green-100 text-green-700"
                        : item.status === "In Progress"
                        ? "bg-orange-100 text-orange-700"
                        : "bg-blue-100 text-blue-700"
                    }`}
                  >
                    {item.status}
                  </span>
                </div>
              </div>

              <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] -mt-3 ml-12"></div>

              {/* CONTENT */}
              <div className="flex-1 overflow-y-auto p-4 hide-scrollbar">
                <style jsx>{`
                  .hide-scrollbar::-webkit-scrollbar {
                    display: none;
                  }
                  .hide-scrollbar {
                    -ms-overflow-style: none;
                    scrollbar-width: none;
                  }
                `}</style>

                {/* FILTERS */}
                <div className="flex items-center justify-between mb-3 gap-2">
                  <div className="flex items-center gap-2">

                    <Searchinput
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Search"
                      className="w-[1/2]"
                      iconColor="text-black"
                      bgColor="bg-FrostWhite"
                      borderColor="border-black"
                      textColor="text-black"
                      shadow="shadow-none"
                      inputPadding="pl-7 pr-3 py-1.5"
                      iconSize="w-3.5 h-3.5"
                      iconLeft="left-3"
                      inputWidth="w-full"
                      focusRing="focus:ring-1 focus:ring-black/60"
                      hoverInputClasses="hover:bg-white hover:border-black/60"
                    />

                    <Filter
                      name="status"
                      value={statusFilter}
                      options={statusOptions}
                      onChange={handleFilterChange}
                      placeholder="Status"
                      customWidth="w-32"
                      placeholderColor="text-black"
                      buttonBorderColor="border-black/60"
                      dropdownBgColor="bg-white"
                      dropdownTextColor="text-black"
                      dropdownHoverColor="hover:bg-lightBlue/50"
                      dropdownBorderColor="border-black/60"
                      closedBgColor="bg-white"
                      hoverRingColor="ring-black"
                      openBgColor="bg-white"
                      textColor="text-black"
                    />

                    <Filter
                      name="time"
                      value={timeFilter}
                      options={timeOptions}
                      onChange={handleFilterChange}
                      placeholder="All Time"
                      customWidth="w-32"
                      placeholderColor="text-black"
                      buttonBorderColor="border-black/60"
                      dropdownBgColor="bg-white"
                      dropdownTextColor="text-black"
                      dropdownHoverColor="hover:bg-lightBlue/50"
                      dropdownBorderColor="border-black/60"
                      closedBgColor="bg-white"
                      hoverRingColor="ring-black"
                      openBgColor="bg-white"
                      textColor="text-black"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Add New Button - For User: visible when In Progress
                        For Admin: visible when In Progress AND messages exist */}
                    {item.status === "In Progress" && (!isAdmin || (isAdmin && localComments.length > 0)) && (
                      <button
                        onClick={() => setPopupView("ADD")}
                        className="px-4 py-1.5 bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition text-xs font-medium flex items-center gap-2"
                      >
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                        </svg>
                        Add New
                      </button>
                    )}

                    {/* Close Item Button - Only visible when assigned person has replied
                        Hidden for Admin */}
                    {item.status === "In Progress" && !isAdmin && 
                     localComments.some(c => 
                       c.text && 
                       c.commentedById &&  // Must be a user comment (has commentedById)
                       !c.text.startsWith("Action item assigned to") && 
                       !c.text.startsWith("Action item closed") &&
                       c.commentedById !== item.createdById  // Response from someone other than creator
                     ) && (
                      <button
                        onClick={handleCloseItem}
                        disabled={isClosing}
                        className="px-4 py-1.5 bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition text-xs font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {isClosing ? (
                          <>
                            <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                            Closing...
                          </>
                        ) : (
                          <>
                            <svg
                              className="w-4 h-4"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                            Close Item
                          </>
                        )}
                      </button>
                    )}

                    {/* Show Closed badge when item is closed */}
                    {item.status === "Closed" && (
                      <div className="px-4 py-1.5 bg-gray-100 border border-gray-300 text-gray-600 text-xs font-medium flex items-center gap-2">
                        <svg
                          className="w-4 h-4 text-green-600"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Item Closed
                      </div>
                    )}

                    <button
                    onClick={handleDownloadComments}
                      className="px-4 py-1.5 bg-darkblue1 text-white border border-darkblue1 hover:bg-white hover:text-darkblue1 transition text-xs font-medium flex items-center gap-2"
                    >
                      <Download size={14} className="text-current" />
                      Download
                    </button>
                  </div>
                </div>

                {/* Show message if not assigned yet (status is Created) - Only for User, not Admin */}
                {!isAdmin && item.status === "Created" && (
                  <div className="bg-yellow-50 border border-yellow-300 text-yellow-800 px-4 py-2 mb-3 text-xs">
                    <span className="font-medium">Note:</span> Please assign the action item first to add responses.
                  </div>
                )}

                {/* TABLE */}
                {/* Message Table */}
                <div className="bg-white shadow-md border border-Dustyblue overflow-auto hide-scrollbar">
                  <style jsx>{`
                    .hide-scrollbar::-webkit-scrollbar {
                      display: none;
                    }
                    .hide-scrollbar {
                      -ms-overflow-style: none;
                      scrollbar-width: none;
                    }
                  `}</style>
                  <table className="w-full text-xs border-collapse">
                    <thead className="bg-Dustyblue text-white sticky top-0 z-20">
                    <tr>
  {/* System / User */}
  <th
    onClick={() => handleSort("createdBy")}
    className="px-1.5 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[15%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      System / User
      {sortKey === "createdBy" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "createdBy" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Comments By */}
  <th
    onClick={() => handleSort("commentedBy")}
    className="px-1.5 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Comments by
      {sortKey === "commentedBy" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "commentedBy" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Comments */}
  <th
    onClick={() => handleSort("text")}
    className="px-1.5 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Comments
      {sortKey === "text" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "text" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Created Date */}
  <th
    onClick={() => handleSort("editedDate")}
    className="px-1.5 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[15%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Created Date
      {sortKey === "editedDate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "editedDate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Supporting Document */}
  <th
    onClick={() => handleSort("supportingDocument")}
    className="px-1.5 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 border-b-0  w-[15%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Supporting Document
      {sortKey === "supportingDocument" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "supportingDocument" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Status */}
  <th
    onClick={() => handleSort("status")}
    className="px-1.5 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[8%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Status
      {sortKey === "status" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "status" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Action Details */}
  <th
    onClick={() => handleSort("date")}
    className="px-1.5 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[12%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Action Details
      {sortKey === "date" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "date" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Action (no sort) */}
  <th className="px-1.5 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0">
    Action
  </th>
</tr>
                    </thead>
                    <tbody>
                      {isLoading ? (
                        <tr>
                          <td colSpan="8" className="text-center py-8 text-xs text-gray-500 italic">
                            <div className="flex items-center justify-center gap-2">
                              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                              Loading messages...
                            </div>
                          </td>
                        </tr>
                      ) : sortedData.length > 0 ? (
                        sortedData.map((comment, index) => {
                          // Get the original index from localComments for edit/delete operations
                          const originalIndex = localComments.findIndex(c => c === comment);
                          
                          return (
                            <tr key={`comment-${item.id}-${originalIndex}-${index}`} className="hover:bg-lightBlue/50">
                              <td className="px-1.5 py-1 text-left border border-grey2 border-t-0 border-l-0 text-xs">
                                <div className="">{item.createdBy}</div>
                              </td>
                              <td className="px-1.5 py-1 text-left border border-grey2 border-t-0 border-l-0 text-xs">
                                <div className="">{comment.commentedBy}</div>
                              </td>
                              <td className="px-1.5 py-1 text-left border border-grey2 border-t-0 border-l-0 text-xs">
                                <div className="">{comment.text}</div>
                              </td>
                              <td className="px-1.5 py-1 text-left border border-grey2 border-t-0 border-l-0 text-xs">
                                {comment.date}
                                {comment.editedDate && (
                                  <div className="text-[10px] text-gray-500 italic">
                                    Edited: {comment.editedDate}
                                  </div>
                                )}
                              </td>
                              <td className="px-1.5 py-1 text-left border border-grey2 border-t-0 border-l-0 text-xs">
                                <div className="truncate">{comment.supportingDocument || "-"}</div>
                              </td>
                              <td className="px-1.5 py-1 text-left border border-grey2 border-t-0 border-l-0 text-xs">
                                <span className={`inline-block text-center font-medium ${
                                  item.status === "Completed" || item.status === "Closed"
                                    ? "text-green"
                                    : item.status === "In Progress"
                                    ? "text-orange-600"
                                    : "text-mildBlue"
                                }`}>
                                  {item.status}
                                </span>
                              </td>
                              <td className="px-1.5 py-1 text-left border border-grey2 border-t-0 border-l-0 text-xs">
                                <div className="truncate">
                                  {comment.date} {comment.time || ""}
                                  <br />
                                  By {comment.commentedBy}
                                </div>
                              </td>
                              <td className="px-1.5 py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0 text-xs">
                                {/* Hide action dropdown when item is Closed OR for Admin */}
                                {item.status === "Closed" || isAdmin ? (
                                  <span className="text-gray-400 text-xs">—</span>
                                ) : (
                                  <div className="flex justify-center relative dropdown-container">
                                    <button
                                      onClick={(e) => toggleDropdown(originalIndex, e)}
                                      className="w-5 h-5 flex items-center justify-center  hover:bg-gray-100"
                                    >
                                      <MoreVertical size={14} className="text-black" />
                                    </button>

                                    {dropdownId === originalIndex && (
                                      <div
                                        className={`absolute bg-white w-32 border border-gray-200  shadow-lg z-10 ${
                                          filteredComments.length > 3 && index >= filteredComments.length - 2
                                            ? "bottom-full right-0 mb-1"
                                            : "top-full right-0 mt-1"
                                        }`}
                                      >
                                        <div className="py-0.5 flex flex-col">
                                          <button
                                            onClick={() => {
                                              setEditData(comment);
                                              setEditingIndex(originalIndex);
                                              setNewComment(comment.text || "");
                                              setSupportingDocument(comment.supportingDocument ? { name: comment.supportingDocument } : null);
                                              setPopupView("EDIT");
                                              setDropdownId(null);
                                            }}
                                            className="w-full px-2.5 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2 border-b border-gray-100"
                                          >
                                            <img
                                              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/edit.png"
                                              alt="Edit"
                                              className="w-3 h-3"
                                            />
                                            <span>Edit</span>
                                          </button>
                                          <button
                                            onClick={() => handleDelete(originalIndex)}
                                            className="w-full px-2.5 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                          >
                                            <img
                                              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Monthly meeting/delete.png"
                                              alt="Delete"
                                              className="w-3 h-3"
                                            />
                                          <span>Delete</span>
                                        </button>
                                      </div>
                                    </div>
                                  )}
                                </div>
                                )}
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan="8" className="text-center py-8 text-xs text-gray-500 italic">
                            No messages found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* Add Message Modal */}
          {popupView === "ADD" && (
            <div className="">
              {/* Modal Header */}
              <div className="flex items-center justify-between px-6 py-3 ">
                <h3 className="text-base font-semibold text-MediumGrey">Add Message</h3>
              </div>
              <div className="hidden lg:block h-1 bg-MediumGrey w-[5%] -mt-3 ml-6 "></div>

              {/* Modal Content */}
              <div className="flex-1  p-6 ">
                <div className="grid grid-cols-2 gap-4 mb-2">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Created Date
                    </label>
                    <input
                      type="text"
                      value={item.createdDate}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Generated By
                    </label>
                    <input
                      type="text"
                      value={item.createdBy}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-2">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      User Name
                    </label>
                    <input
                      type="text"
                      value={item.createdByName}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300 bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Quarter
                    </label>
                    <input
                      type="text"
                      value={item.quarter}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-2">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Strategic Objective
                    </label>
                    <input
                      type="text"
                      value={item.strategicObjective}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      KPI
                    </label>
                    <input
                      type="text"
                      value={item.subKPI}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-2">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Sub KPI
                    </label>
                    <input
                      type="text"
                      value={item.subKPI}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Supporting Document
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={supportingDocument?.name || ""}
                        disabled
                        placeholder="No file chosen"
                        className="flex-1 px-3 py-1.5 border border-gray-300  bg-white text-gray-600 text-xs"
                      />
                      <label className="px-3 py-1.5 border border-gray-300  bg-white hover:bg-gray-50 cursor-pointer text-xs font-medium text-gray-700 flex items-center gap-1.5">
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                        </svg>
                        Browse...
                        <input
                          type="file"
                          onChange={handleFileChange}
                          className="hidden"
                          disabled={isSubmitting}
                        />
                      </label>
                    </div>
                  </div>
                </div>

                <div className="">
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">
                    Comments <span className="text-red-600">*</span>
                  </label>
                  <textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Enter your message..."
                    rows={6}
                    disabled={isSubmitting}
                    className="w-full px-3 py-2 border border-gray-300  focus:outline-none focus:ring-2 focus:ring-darkblue1 text-xs resize-none"
                  />
                </div>
              </div>

              {/* Modal Footer */}
              <div className="flex justify-center gap-3 px-6 py-1 -mt-4 mb-2">
                <button
                  onClick={() => setPopupView("TABLE")}
                  disabled={isSubmitting}
                  className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium  hover:bg-mildBlue1 hover:scale-105"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/cancel.png"
                    alt=""
                    className="w-3 h-3"/>           
                  Cancel
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="px-5 py-1.5 bg-darkblue1 text-white  hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition text-xs font-medium flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? "Saving..." : "Save"}
                </button>
              </div>
            </div>
          )}
  

          {/* Edit Message Modal */}
          {popupView === "EDIT" && (
            <div className="">
              <div className="flex items-center justify-between px-6 py-3 ">
                <h3 className="text-base font-semibold text-MediumGrey">Edit Message</h3>
              </div>
              <div className="hidden lg:block h-1 bg-MediumGrey w-[5%] -mt-3 ml-6 "></div>

              <div className="flex-1 overflow-y-auto p-6 hide-scrollbar">
                <div className="grid grid-cols-2 gap-4 mb-2">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Created Date
                    </label>
                    <input
                      type="text"
                      value={item.createdDate}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Generated By
                    </label>
                    <input
                      type="text"
                      value={item.createdBy}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-2">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      User Name
                    </label>
                    <input
                      type="text"
                      value={item.createdByName}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Quarter
                    </label>
                    <input
                      type="text"
                      value={item.quarter}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-2">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Strategic Objective
                    </label>
                    <input
                      type="text"
                      value={item.strategicObjective}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      KPI
                    </label>
                    <input
                      type="text"
                      value={item.subKPI}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-2">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Sub KPI
                    </label>
                    <input
                      type="text"
                      value={item.subKPI}
                      disabled
                      className="w-full px-3 py-1.5 border border-gray-300  bg-gray-50 text-gray-600 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                      Supporting Document
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={supportingDocument?.name || ""}
                        disabled
                        placeholder="No file chosen"
                        className="flex-1 px-3 py-1.5 border border-gray-300  bg-white text-gray-600 text-xs"
                      />
                      <label className="px-3 py-1.5 border border-gray-300  bg-white hover:bg-gray-50 cursor-pointer text-xs font-medium text-gray-700 flex items-center gap-1.5">
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                        </svg>
                        Browse...
                        <input
                          type="file"
                          onChange={handleFileChange}
                          className="hidden"
                          disabled={isSubmitting}
                        />
                      </label>
                    </div>
                  </div>
                </div>

                <div className="">
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">
                    Comments <span className="text-red-600">*</span>
                  </label>
                  <textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Enter your message..."
                    rows={6}
                    disabled={isSubmitting}
                    className="w-full px-3 py-2 border border-gray-300  focus:outline-none focus:ring-2 focus:ring-darkblue1 text-xs resize-none"
                  />
                </div>
              </div>

              <div className="flex justify-center gap-3 px-6 py-1 -mt-4 mb-2">
                <button
                  onClick={() => setPopupView("TABLE")}
                  disabled={isSubmitting}
                  className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium  hover:bg-mildBlue1 hover:scale-105"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/cancel.png"
                    alt=""
                    className="w-3 h-3"/>           
                  Cancel
                </button>
                <button
                  onClick={handleEditSubmit}
                  disabled={isSubmitting}
                  className="px-5 py-1.5 bg-darkblue1 text-white  hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition text-xs font-medium flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? "Saving..." : "Save"}
                </button>
              </div>
            </div>
          )}

          {/* Delete Modal */}
          <DeleteModal
            isOpen={deleteModalVisible}
            onClose={() => {
              if (!deleteLoading) {
                setDeleteModalVisible(false);
                setCommentToDelete(null);
              }
            }}
            onConfirm={confirmDelete}
            loading={deleteLoading}
            extraMessage="This message will be permanently removed from the action item."
          />

          {/* Close Item Confirmation Modal */}
          {closeConfirmVisible && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60]">
              <div className="bg-white p-6 shadow-lg max-w-md w-full mx-4">
                <div className="flex items-start gap-3 mb-4">
                  <div className="flex-shrink-0">
                    <svg className="w-8 h-8 text-orange-500" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-gray-800 mb-1">
                      Are you sure you want to close this action item?
                    </h3>
                    <p className="text-xs text-red-600">
                      <span className="font-medium">*Note:</span> Once closed, you cannot assign or add messages.
                    </p>
                  </div>
                </div>
                
                <div className="flex justify-center gap-3 mt-6">
                  <button
                    onClick={() => {
                      if (!isClosing) {
                        setCloseConfirmVisible(false);
                      }
                    }}
                    disabled={isClosing}
                    className="border-2 border-red2 text-red px-4  py-1.5 text-xs font-bold  hover:bg-red2 hover:shadow-md hover:scale-105 transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    No
                  </button>
                  <button
                    onClick={confirmCloseItem}
                    disabled={isClosing}
                    className="bg-green4 text-green5 text-xs border-2 border-transparent font-bold font-VolvoNovum px-5  py-1.5  transition duration-200 "
                  >
                    {isClosing ? (
                      <>
                        <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                        Closing...
                      </>
                    ) : (
                      "Yes"
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default CommentsPopup;