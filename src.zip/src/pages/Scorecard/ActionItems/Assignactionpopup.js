import React, { useState, useEffect, useCallback } from "react";
import StyledSelectField from "../../../Components/StyledSelectField";
import { ArrowLeft } from "lucide-react";
import { useRef } from "react";
import { FaRegCalendar } from "react-icons/fa";

// ═══════════════════════════════════════════════════════════════
// 📡 API SERVICE IMPORTS
// ═══════════════════════════════════════════════════════════════
import {
  updateScorecardActionItem,
  getScorecardActionLogsByActionItemId,
  addScorecardActionLog,
} from "../../../services/scorecard/scorecardScoreView.service";

import { getAuditors } from "../../../services/scorecard/scorecard.service";

const AssignActionPopup = ({ isOpen, onClose, item, onAssign }) => {
  const [selectedRowId, setSelectedRowId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(false);
  
  // Dealer Users from API
  const [dealerUsers, setDealerUsers] = useState([]);
  const [usersLoading, setUsersLoading] = useState(false);
  
  const assignToOptions = ["External User", "Internal User"];
  const assignrefs = {
    assignTo: useRef(null),
    dealerUser: useRef(null)
  };

  const [assigndropdowns, setAssignDropdowns] = useState({
    assignTo: false,
    dealerUser: false
  });

  const [assignform, setAssignForm] = useState({
    assignTo: "",
    email: "",
    dealerUser: "",      // Display name
    dealerUserId: null,  // User ID for API
    endDate: ""
  });

  const [errors, setErrors] = useState({
    assignTo: "",
    dealerUser: "",
    email: "",
    endDate: "",
  });

  const [dummyRows, setDummyRows] = useState([
    {
      id: 1,
      createdBy: "User",
      subKpi: "MTTR (Mean Time to Repair)",
      createdDate: "21/06/2024 , 04:30 PM",
      maxScore: 0,
      finalScore: 0,
      remarks: "-",
      status: "In Progress",
      assignedTo: "Akshada Shinde (Dealer Principal)"
    },
    {
      id: 2,
      createdBy: "User",
      subKpi: "MTTR (Mean Time to Repair)",
      createdDate: "22/06/2024 , 10:00 AM",
      maxScore: 0,
      finalScore: 0,
      remarks: "-",
      status: "Created",
      assignedTo: "Meyuri Pawar"
    }
  ]);

  const [tableData, setTableData] = useState(dummyRows);
  const [isAssigned, setIsAssigned] = useState(false);
  const [assignedData, setAssignedData] = useState(null);
  const [assignmentHistory, setAssignmentHistory] = useState([]);

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH ASSIGNMENT HISTORY FROM API
  // ═══════════════════════════════════════════════════════════════
  const fetchAssignmentHistory = async () => {
    console.log("📋 fetchAssignmentHistory called, item.id:", item?.id);
    
    if (!item?.id) {
      console.log("📋 No item.id, skipping fetch");
      return;
    }

    setHistoryLoading(true);
    try {
      console.log("📋 Calling getScorecardActionLogsByActionItemId with ID:", item.id);
      const logs = await getScorecardActionLogsByActionItemId(item.id);
      
      console.log("📋 Action Logs received:", logs);
      console.log("📋 Logs length:", logs?.length || 0);
      
      // Get the Sub KPI name from item for display
      const subKpiName = item.subKpi || item.sub_kpi_subKpiName || item.subKpiName || "Action Item";
      
      // Map API response to table format
      // Service returns: commentedByName, comments, createdDate, supportingDocUrl
      const assignmentLogs = (logs || []).map((log) => ({
        id: log.id,
        commentsBy: log.commentedByName || log.commented_by_name ? "User" : "System",
        actionItem: subKpiName,
        comment: log.comments || "",
        createdDate: log.createdDate || log.created_at || "",
        supportingDoc: log.supportingDocUrl || log.supporting_doc_url || null,
      }));

      console.log("📋 Mapped logs for table:", assignmentLogs);
      setAssignmentHistory(assignmentLogs);
    } catch (err) {
      console.error("❌ Error fetching assignment history:", err);
      setAssignmentHistory([]);
    } finally {
      setHistoryLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 👥 FETCH DEALER USERS (Auditors) FROM API
  // ═══════════════════════════════════════════════════════════════
  const fetchDealerUsers = useCallback(async () => {
    setUsersLoading(true);
    try {
      const auditorsData = await getAuditors();
      console.log("📋 Auditors/Dealer Users loaded:", auditorsData);
      
      // Debug: Log first user's fields to see available properties
      if (auditorsData && auditorsData.length > 0) {
        console.log("📋 First user object keys:", Object.keys(auditorsData[0]));
        console.log("📋 First user full object:", auditorsData[0]);
      }
      
      setDealerUsers(auditorsData || []);
    } catch (err) {
      console.error("Error fetching dealer users:", err);
      setDealerUsers([]);
    } finally {
      setUsersLoading(false);
    }
  }, []);

  // Helper function to format date for input (YYYY-MM-DD)
  const formatDateForInput = (dateString) => {
    if (!dateString) return "";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        // Try parsing DD/MM/YYYY format
        const parts = dateString.split('/');
        if (parts.length === 3) {
          return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
        }
        return "";
      }
      return date.toISOString().split('T')[0];
    } catch {
      return "";
    }
  };

  // Fetch dealer users and history when popup opens
  useEffect(() => {
    const loadData = async () => {
      if (isOpen) {
        console.log("📋 Popup opened, isOpen:", isOpen, "item:", item);
        
        // Fetch dealer users for dropdown
        fetchDealerUsers();
        
        // Fetch assignment history/messages
        if (item?.id) {
          console.log("📋 Calling fetchAssignmentHistory for item.id:", item.id);
          
          setHistoryLoading(true);
          try {
            const logs = await getScorecardActionLogsByActionItemId(item.id);
            
            console.log("📋 Action Logs API Response:", logs);
            console.log("📋 Logs count:", logs?.length || 0);
            
            // Get the Sub KPI name from item for display
            const subKpiName = item.subKpi || item.sub_kpi_subKpiName || item.subKpiName || item.subKPI || "Action Item";
            
            // Map API response to table format
            const assignmentLogs = (logs || []).map((log) => ({
              id: log.id,
              commentsBy: log.commentedByName ? "User" : "System",
              actionItem: subKpiName,
              comment: log.comments || "",
              createdDate: log.createdDate || "",
              supportingDoc: log.supportingDocUrl || null,
            }));

            console.log("📋 Mapped logs for table:", assignmentLogs);
            setAssignmentHistory(assignmentLogs);
          } catch (err) {
            console.error("❌ Error fetching assignment history:", err);
            setAssignmentHistory([]);
          } finally {
            setHistoryLoading(false);
          }
        }
        setErrors({});
      }
    };
    
    loadData();
  }, [isOpen, item?.id, fetchDealerUsers]);

  // Pre-fill form AFTER dealer users are loaded (so we can match ID)
  useEffect(() => {
    if (isOpen && item) {
      // Pre-fill form with existing assignment data
      if (item.assignedTo || item.assignedToName || item.assigned_to) {
        const assignedName = item.assignedToName || item.assignedTo || "";
        // Try to get ID from item - backend returns assigned_to as ID
        const assignedId = item.assigned_to || item.assignedToId || null;
        const isEmail = assignedName.includes("@");
        
        // If we have dealer users loaded, try to find the user ID by name
        let foundUserId = assignedId;
        if (!isEmail && dealerUsers.length > 0 && !foundUserId) {
          const matchedUser = dealerUsers.find(user => {
            const userName = user.label || user.value || `${user.firstName || ""} ${user.lastName || ""}`.trim();
            return userName.toLowerCase() === assignedName.toLowerCase();
          });
          if (matchedUser) {
            foundUserId = matchedUser.id || matchedUser.userId || matchedUser.user_id || matchedUser.auditorId || null;
            console.log("📋 Found user ID by name match:", foundUserId);
          }
        }
        
        console.log("📋 Pre-filling form:", { assignedName, assignedId, foundUserId, isEmail });
        
        setAssignForm({
          assignTo: isEmail ? "External User" : "Internal User",
          email: isEmail ? assignedName : "",
          dealerUser: !isEmail ? assignedName : "",
          dealerUserId: !isEmail ? foundUserId : null,
          endDate: item.endDate ? formatDateForInput(item.endDate) : (item.targetDate ? formatDateForInput(item.targetDate) : ""),
        });
      } else {
        // Reset form if no previous assignment
        setAssignForm({
          assignTo: "",
          email: "",
          dealerUser: "",
          dealerUserId: null,
          endDate: "",
        });
      }
    }
  }, [isOpen, item, dealerUsers]);

  if (!isOpen) return null;

  // Handle input change
  const handleChangeassign = (eOrField, val) => {
    // StyledSelectField → passes (fieldName, value)
    if (typeof eOrField === "string") {
      setAssignForm((prev) => ({ ...prev, [eOrField]: val }));
      return;
    }

    // Normal <input> event
    const { name, value } = eOrField.target;
    setAssignForm((prev) => ({ ...prev, [name]: value }));
  };

  // ═══════════════════════════════════════════════════════════════
  // 💾 HANDLE ASSIGN WITH API
  // ═══════════════════════════════════════════════════════════════
  const handleAssign = async () => {
    let tempErrors = {};

    if (!assignform.assignTo) tempErrors.assignTo = "Please select Assign To";
    if (!assignform.endDate) tempErrors.endDate = "Please select End Date";
    if (assignform.assignTo === "Internal User" && !assignform.dealerUser)
      tempErrors.dealerUser = "Please select Dealer User";
    if (assignform.assignTo === "External User" && !assignform.email)
      tempErrors.email = "Please enter External Email";

    // Validate that we have a user ID for internal users
    if (assignform.assignTo === "Internal User" && !assignform.dealerUserId) {
      tempErrors.dealerUser = "User ID not found. Please re-select the user.";
      console.error("❌ No user ID found for selected dealer user:", assignform.dealerUser);
    }

    if (Object.keys(tempErrors).length > 0) {
      setErrors(tempErrors);
      return;
    }

    // For display purposes (name)
    const assignedDisplayValue =
      assignform.assignTo === "External User"
        ? assignform.email
        : assignform.dealerUser;

    // For API - send user ID for internal users, null for external
    const assignedToId =
      assignform.assignTo === "Internal User"
        ? assignform.dealerUserId
        : null;

    console.log("📤 Assigning with:", {
      itemId: item.id,
      assignedToId,
      assignedDisplayValue,
      endDate: assignform.endDate
    });

    setIsLoading(true);
    try {
      // Call API to update action item with assignment info
      // Backend expects assigned_to as user ID (number)
      await updateScorecardActionItem({
        id: item.id,
        action_item_status: "In Progress",
        assigned_to: assignedToId,  // Send user ID, not name
        end_date: assignform.endDate,
      });

      // Add action log for the assignment
      await addScorecardActionLog({
        actionItemId: item.id,
        comments: `Action item assigned to ${assignedDisplayValue}`,
      });

      // Get the Sub KPI name from item for display
      const subKpiName = item.subKpi || item.sub_kpi_subKpiName || item.subKpiName || item.subKPI || "Action Item";

      // Refresh the history from API to get the new entry
      try {
        const logs = await getScorecardActionLogsByActionItemId(item.id);
        const assignmentLogs = (logs || []).map((log) => ({
          id: log.id,
          commentsBy: log.commentedByName ? "User" : "System",
          actionItem: subKpiName,
          comment: log.comments || "",
          createdDate: log.createdDate || "",
          supportingDoc: log.supportingDocUrl || null,
        }));
        setAssignmentHistory(assignmentLogs);
      } catch (fetchErr) {
        console.error("Error refreshing history:", fetchErr);
        // Fallback: Add to local history
        setAssignmentHistory((prev) => [
          {
            commentsBy: "User",
            actionItem: subKpiName,
            comment: `Action item assigned to ${assignedDisplayValue}`,
            createdDate: new Date().toLocaleDateString("en-GB"),
          },
          ...prev,
        ]);
      }

      // Update only the selected row (if using local table)
      setTableData((prev) =>
        prev.map((row) =>
          row.id === selectedRowId
            ? { ...row, assignedTo: assignedDisplayValue, status: "In Progress" }
            : row
        )
      );

      // Call parent callback
      if (onAssign) {
        onAssign({
          assignTo: assignedDisplayValue,
          assignToId: assignedToId,
          assignToType: assignform.assignTo,
          endDate: assignform.endDate,
        });
      }

      // Reset form
      setAssignForm({ assignTo: "", dealerUser: "", dealerUserId: null, email: "", endDate: "" });
      setErrors({ assignTo: "", dealerUser: "", email: "", endDate: "" });

    } catch (err) {
      console.error("Error assigning action item:", err);
      alert(err.message || "Failed to assign action item");
    } finally {
      setIsLoading(false);
    }
  };

  // Handle close
  const handleClose = () => {
    setAssignForm({
      assignTo: "",
      dealerUser: "",
      dealerUserId: null,
      email: "",
      endDate: "",
    });
    setIsAssigned(false);
    setAssignedData(null);
    setAssignmentHistory([]);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 ">
      <div className="bg-white p-4 w-full max-w-3xl shadow-2xl">
        {/* Header */}
        <div className="flex items-center gap-2">
          <ArrowLeft
            onClick={() => {
              // Reset form fields
              setAssignForm({
                assignTo: "",
                dealerUser: "",
                email: "",
                endDate: "",
              });

              // Clear validation errors
              setErrors({
                assignTo: "",
                dealerUser: "",
                email: "",
                endDate: "",
              });

              // Close the popup
              handleClose()
            }}
            size={20}
            className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
          />

          <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
            {(item?.assignedTo || item?.assignedToName) ? "Reassign Action Item" : "Assign Action Item"}
          </h2>
        </div>

        <div className="hidden lg:block h-1 bg-darkblue1 w-[8%] ml-7"></div>

        {/* Current Assignment Info - Show if already assigned */}
        {(item?.assignedTo || item?.assignedToName) && (
          <div className="bg-blue-50 border border-blue-200 p-3 mt-3 mb-2">
            <h4 className="text-xs font-semibold text-blue-800 mb-2">Current Assignment:</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
              <div>
                <span className="text-gray-500">Assigned To:</span>
                <p className="font-medium text-black">{item?.assignedTo || item?.assignedToName || "—"}</p>
              </div>
              <div>
                <span className="text-gray-500">Status:</span>
                <p className="font-medium text-black">{item?.status || "—"}</p>
              </div>
              <div>
                <span className="text-gray-500">Target Date:</span>
                <p className="font-medium text-black">{item?.targetDate || (item?.endDate ? new Date(item.endDate).toLocaleDateString("en-GB") : "—")}</p>
              </div>
              <div>
                <span className="text-gray-500">Sub KPI:</span>
                <p className="font-medium text-black">{item?.subKPI || item?.subKpi || "—"}</p>
              </div>
            </div>
          </div>
        )}

        {/* ASSIGN FORM */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">

          {/* Assign To */}
          <div>
            <StyledSelectField
              label="Assign To"
              placeholder="Select User Type"
              value={assignform.assignTo}
              setValue={(val) => handleChangeassign("assignTo", val)}
              options={assignToOptions}
              dropdownOpen={assigndropdowns.assignTo}
              setDropdownOpen={(val) =>
                setAssignDropdowns((prev) => ({ ...prev, assignTo: val }))
              }
              dropdownRef={assignrefs.assignTo}
              error={errors.assignTo}
            />
          </div>

          {/* End Date */}
          <div className="mb-2">
            <label className="block text-xs font-medium text-black/60 mb-2">
              End Date
            </label>
            <div
              className={`relative flex items-center px-3 py-1.5 cursor-pointer border ${
                errors.endDate ? "border-red1" : "border-black/30"
              }`}
              onClick={() => document.getElementById("endDateInput").showPicker?.()}
            >
              <input
                id="endDateInput"
                type="date"
                name="endDate"
                value={assignform.endDate}
                onChange={(e) => {
                  handleChangeassign(e);
                  if (e.target.value) setErrors((prev) => ({ ...prev, endDate: "" }));
                }}
                className="w-full text-xs bg-transparent outline-none cursor-pointer"
              />
              <FaRegCalendar
                className="absolute right-3 text-xs cursor-pointer text-black"
                onClick={(e) => {
                  e.stopPropagation();
                  document.getElementById("endDateInput").showPicker?.();
                }}
              />
            </div>
            {errors.endDate && <p className="text-xs text-red1 mt-1">{errors.endDate}</p>}
          </div>

          {/* Internal User → Select Dealer */}
          {assignform.assignTo === "Internal User" && (
            <div className="md:col-span-2">
              <StyledSelectField
                label="Select Dealer User"
                placeholder={usersLoading ? "Loading users..." : "Select Dealer User"}
                value={assignform.dealerUser}
                setValue={(val) => {
                  // Find the selected user to get their ID
                  const selectedUser = dealerUsers.find(user => {
                    const userName = user.label || user.value || `${user.firstName || ""} ${user.lastName || ""}`.trim();
                    return userName === val;
                  });
                  
                  console.log("📋 Selected user object:", selectedUser);
                  console.log("📋 All keys:", selectedUser ? Object.keys(selectedUser) : []);
                  
                  // Try multiple possible field names for user ID
                  const userId = selectedUser?.id || 
                                 selectedUser?.userId || 
                                 selectedUser?.user_id || 
                                 selectedUser?.auditorId ||
                                 selectedUser?.auditor_id ||
                                 selectedUser?.userID ||
                                 selectedUser?.ID ||
                                 null;
                  
                  console.log("📋 User ID found:", userId);
                  
                  // Store both display name and user ID
                  setAssignForm(prev => ({
                    ...prev,
                    dealerUser: val,
                    dealerUserId: userId
                  }));
                  if (val) setErrors((prev) => ({ ...prev, dealerUser: "" }));
                }}
                options={dealerUsers.map(user => ({
                  label: user.label || user.value || `${user.firstName || ""} ${user.lastName || ""}`.trim(),
                  value: user.label || user.value || `${user.firstName || ""} ${user.lastName || ""}`.trim(),
                }))}
                dropdownOpen={assigndropdowns.dealerUser}
                setDropdownOpen={(val) =>
                  setAssignDropdowns((prev) => ({ ...prev, dealerUser: val }))
                }
                dropdownRef={assignrefs.dealerUser}
                error={errors.dealerUser}
                disabled={usersLoading}
              />
              {/* Debug: Show selected user ID */}
              {assignform.dealerUserId && (
                <p className="text-[10px] text-green-600 mt-1">✓ User ID: {assignform.dealerUserId}</p>
              )}
              {assignform.dealerUser && !assignform.dealerUserId && (
                <p className="text-[10px] text-red-500 mt-1">⚠ No User ID found - check console</p>
              )}
            </div>
          )}

          {/* External User → Email */}
          {assignform.assignTo === "External User" && (
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-black mb-2">
                External Email
              </label>
              <input
                type="email"
                name="email"
                value={assignform.email}
                onChange={(e) => {
                  handleChangeassign(e);
                  if (e.target.value) setErrors((prev) => ({ ...prev, email: "" }));
                }}
                placeholder="Enter external user email"
                className={`w-full px-3 py-2 border rounded text-xs bg-white ${
                  errors.email ? "border-red1" : "border-Dustyblue"
                }`}
              />
              {errors.email && <p className="text-xs text-red1 mt-1">{errors.email}</p>}
            </div>
          )}

        </div>

        {/* Assign Button */}
        <div className="flex justify-end mt-4 mb-2">
          <button
            onClick={handleAssign}
            disabled={isLoading}
            className="px-8 py-1.5 bg-darkblue1 text-white text-xs font-medium hover:bg-opacity-90 transition disabled:opacity-50"
          >
            {isLoading ? "Assigning..." : "Assign"}
          </button>
        </div>

        {/* List of Messages Table */}
        <div className="border border-gray-300 bg-white">
          <div className="bg-white text-black text-sm font-medium px-3 py-2">
            List of Messages
          </div>
            <table className="w-full text-xs border-collapse table-fixed">
              <thead className="bg-Dustyblue text-white text-xs text-left  sticky top-0 z-10">              <tr>
                <th className="p-2 border  border-grey2 border-t-0 border-l-0 border-b-0 font-normal border-gray-300">Comments By</th>
                <th className="p-2 border  border-grey2 border-t-0 border-l-0 border-b-0 font-normal border-gray-300">ActionItem </th>
                <th className="p-2 border  border-grey2 border-t-0 border-l-0 border-b-0 font-normal  border-gray-300">Comments</th>
                <th className="p-2 border  border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-normal border-gray-300">Created Date</th>
              </tr>
            </thead>

            <tbody>
              {historyLoading ? (
                <tr>
                  <td colSpan="4" className="text-center py-4 text-gray-500">
                    <div className="flex items-center justify-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                      Loading...
                    </div>
                  </td>
                </tr>
              ) : assignmentHistory.length === 0 ? (
                <tr>
                  <td colSpan="4" className="text-center py-4 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              ) : (
                assignmentHistory.map((historyItem, index) => (
                  <tr key={index} className="font-normal text-xs border-b border-gray-200 hover:bg-gray-50">
                    <td className="p-2 border  border-grey2 border-t-0 border-l-0 border-b-0">{historyItem.commentsBy}</td>
                    <td className="p-2 border  border-grey2 border-t-0 border-l-0 border-b-0">{historyItem.actionItem}</td>
                    <td className="p-2 border  border-grey2 border-t-0 border-l-0 border-b-0">{historyItem.comment}</td>
                    <td className="p-2 border  border-grey2 border-t-0 border-l-0 border-b-0">{historyItem.createdDate}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
};

export default AssignActionPopup;