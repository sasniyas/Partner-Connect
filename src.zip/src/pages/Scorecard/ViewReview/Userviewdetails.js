import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, X } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import Filter from "../../../Components/Filter";
import Searchinput from "../../../Components/Searchinput";
import StyledSelectField from "../../../Components/StyledSelectField";
import { FaRegCalendar } from "react-icons/fa";
import DeleteModal from "../../../Components/DeleteModal";

// ═══════════════════════════════════════════════════════════════
// 📡 API SERVICE IMPORTS
// ═══════════════════════════════════════════════════════════════
import {
  getScorecardScoreViewsByScorecardId,
  getScorecardActionItemsByScoreViewId,
  addScorecardActionItem,
  updateScorecardActionItem,
  deleteScorecardActionItem,
  getScorecardActionLogsByActionItemId,
  addScorecardActionLog,
  uploadScorecardScoreViewDoc,
} from "../../../services/scorecard/scorecardScoreView.service";

import { getAuditors } from "../../../services/scorecard/scorecard.service";

const UserViewDetails = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Get data from navigation state
  const rowData = location.state?.rowData;
  const scorecardId = location.state?.scorecardId;
  const parentRowData = location.state?.parentRowData;
  const scoreViewsFromParent = location.state?.scoreViewsData || [];

  // ═══════════════════════════════════════════════════════════════
  // 📊 DATA STATE
  // ═══════════════════════════════════════════════════════════════
  // Always start with empty array - data will be fetched fresh from API
  const [scoreViewsData, setScoreViewsData] = useState([]);
  const [actionItems, setActionItems] = useState([]);
  const [responses, setResponses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedScoreViewId, setSelectedScoreViewId] = useState(null);
  const [selectedScoreView, setSelectedScoreView] = useState(null);
  const [selectedActionItem, setSelectedActionItem] = useState(null);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 SEARCH & FILTER STATE
  // ═══════════════════════════════════════════════════════════════
  const [searchTerm, setSearchTerm] = useState("");
  const [ressearchQuery, setResSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    kpiNo: [],
    strategicObjective: [],
    scored: [],
  });

  // ═══════════════════════════════════════════════════════════════
  // 📱 UI STATE
  // ═══════════════════════════════════════════════════════════════
  const [menuOpen, setMenuOpen] = useState(false);
  const [showCriteriaModal, setShowCriteriaModal] = useState(false);
  const [selectedCriteria, setSelectedCriteria] = useState(null);
  const [isMobileView, setIsMobileView] = useState(false);
  const [showUploadPopup, setShowUploadPopup] = useState(false);
  const [showActionPopup, setShowActionPopup] = useState(false);
  const [popupView, setPopupView] = useState("ACTION_TABLE");
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteRowId, setDeleteRowId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [dropdownId, setDropdownId] = useState(null);
  const [closeConfirmVisible, setCloseConfirmVisible] = useState(false);
  const [isClosingItem, setIsClosingItem] = useState(false);

  // ═══════════════════════════════════════════════════════════════
  // 👥 DEALER USERS STATE (for Assign dropdown)
  // ═══════════════════════════════════════════════════════════════
  const [dealerUsers, setDealerUsers] = useState([]);
  const [usersLoading, setUsersLoading] = useState(false);

  // ═══════════════════════════════════════════════════════════════
  // 📤 UPLOAD STATE
  // ═══════════════════════════════════════════════════════════════
  const [uploadLoading, setUploadLoading] = useState(false);
  const [selectedUploadItem, setSelectedUploadItem] = useState(null);

  // ═══════════════════════════════════════════════════════════════
  // ♾️ INFINITE SCROLL STATE
  // ═══════════════════════════════════════════════════════════════
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [batchSize, setBatchSize] = useState(10);
  const [rowsToShow, setRowsToShow] = useState(10);

  const tableContainerRef = useRef(null);
  const observerTarget = useRef(null);
  const wrapperRefs = useRef({});
  const popupRef = useRef(null);
  const fileInputRef = useRef(null);

  // ═══════════════════════════════════════════════════════════════
  // 📝 FORM STATE - ADD ACTION ITEM
  // ═══════════════════════════════════════════════════════════════
  const [form, setForm] = useState({
    year: parentRowData?.year || rowData?.year || "",
    quarter: parentRowData?.quarter || rowData?.quarter || "",
    strategicObjective: rowData?.strategicObjective || "",
    kpi: "",
    subKpi: "",
    comments: "",
  });

  const [errors, setErrors] = useState({
    year: "",
    quarter: "",
    subKpi: "",
    comments: "",
  });

  const [dropdowns, setDropdowns] = useState({
    year: false,
    quarter: false,
  });

  const refs = {
    year: useRef(null),
    quarter: useRef(null),
  };

  // ═══════════════════════════════════════════════════════════════
  // 📝 FORM STATE - ADD RESPONSE
  // ═══════════════════════════════════════════════════════════════
  const [responseForm, setResponseForm] = useState({
    year: "",
    quarter: "",
    strategicObjective: "",
    kpi: "",
    subKpi: "",
    comments: "",
    file: null,
  });

  const [responseErrors, setResponseErrors] = useState({
    year: "",
    quarter: "",
    comments: "",
  });

  const [responseDropdowns, setResponseDropdowns] = useState({
    quarter: false,
  });

  const responseRefs = {
    quarter: useRef(null),
  };

  // ═══════════════════════════════════════════════════════════════
  // 📝 FORM STATE - ASSIGN
  // ═══════════════════════════════════════════════════════════════
  const [assignform, setAssignForm] = useState({
    assignTo: "",
    email: "",
    dealerUser: "",
    dealerUserId: null,  // User ID for API
    endDate: "",
  });

  const [assignErrors, setAssignErrors] = useState({
    assignTo: "",
    dealerUser: "",
    email: "",
    endDate: "",
  });

  const [assigndropdowns, setAssignDropdowns] = useState({
    assignTo: false,
    dealerUser: false,
  });

  const assignrefs = {
    assignTo: useRef(null),
    dealerUser: useRef(null),
  };

  const [selectedRowId, setSelectedRowId] = useState(null);
  const [selectedActionItemForAssign, setSelectedActionItemForAssign] = useState(null);
  const [assignmentHistory, setAssignmentHistory] = useState([]);

  // ═══════════════════════════════════════════════════════════════
  // 📝 FORM STATE - FILE UPLOAD
  // ═══════════════════════════════════════════════════════════════
  const [formData, setFormData] = useState({
    file: "",
    fileObject: null,
  });

  // Filter options
  const kpiNoOptions = useMemo(() => {
    const kpiNos = new Set();
    scoreViewsData.forEach(item => {
      if (item.kpiNo) kpiNos.add(item.kpiNo);
    });
    return Array.from(kpiNos).sort();
  }, [scoreViewsData]);

  const strategicObjectiveOptions = useMemo(() => {
    const objectives = new Set();
    scoreViewsData.forEach(item => {
      if (item.strategicObjective) objectives.add(item.strategicObjective);
    });
    return Array.from(objectives).sort();
  }, [scoreViewsData]);

  const assignToOptions = ["External User", "Internal User"];

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH DATA
  // ═══════════════════════════════════════════════════════════════
  const fetchScoreViews = useCallback(async (forceRefresh = false) => {
    if (!scorecardId) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      console.log("📡 Fetching score views for scorecardId:", scorecardId);
      const data = await getScorecardScoreViewsByScorecardId(scorecardId);
      console.log("✅ Fetched score views:", data.length, "records");

      // Debug: Log supporting doc fields
      if (data.length > 0) {
        console.log("📋 Sample data - supportingDoc fields:", {
          supportingDoc: data[0].supportingDoc,
          uploadedBy: data[0].uploadedBy,
          uploadedByName: data[0].uploadedByName,
          uploadedOn: data[0].uploadedOn,
        });
      }

      // Filter by strategic objective if coming from UserView
      const filtered = rowData?.strategicObjective
        ? data.filter(item => item.strategicObjective === rowData.strategicObjective)
        : data;
      setScoreViewsData(filtered);
    } catch (err) {
      console.error("Error fetching score views:", err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [scorecardId, rowData]);

  const fetchActionItems = useCallback(async (scoreViewId) => {
    if (!scoreViewId) return;

    setActionLoading(true);
    try {
      const data = await getScorecardActionItemsByScoreViewId(scoreViewId);

      // For each action item, fetch its first log comment to display as "Remarks"
      const itemsWithRemarks = await Promise.all(
        data.map(async (item) => {
          try {
            const logs = await getScorecardActionLogsByActionItemId(item.id);
            // Logs are sorted DESC by created_at, so reverse to get chronological order
            const chronologicalLogs = [...logs].reverse();

            // Find the first comment that is NOT an assignment message or closure message
            const firstUserComment = chronologicalLogs.find(log =>
              log.comments &&
              !log.comments.startsWith("Action item assigned to") &&
              !log.comments.startsWith("Action item closed")
            );

            return {
              ...item,
              remarks: firstUserComment?.comments || "",  // Only show first user comment
              firstComment: firstUserComment?.comments || "",
            };
          } catch (err) {
            console.warn("Failed to fetch logs for action item:", item.id);
            return { ...item, remarks: "" };
          }
        })
      );

      setActionItems(itemsWithRemarks);
    } catch (err) {
      console.error("Error fetching action items:", err);
      setActionItems([]);
    } finally {
      setActionLoading(false);
    }
  }, []);

  const fetchResponses = useCallback(async (actionItemId) => {
    if (!actionItemId) return;

    try {
      const data = await getScorecardActionLogsByActionItemId(actionItemId);
      setResponses(data);
    } catch (err) {
      console.error("Error fetching responses:", err);
      setResponses([]);
    }
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // 👥 FETCH DEALER USERS (Auditors for Assign dropdown)
  // ═══════════════════════════════════════════════════════════════
  const fetchDealerUsers = useCallback(async () => {
    setUsersLoading(true);
    try {
      const auditorsData = await getAuditors();
      console.log("📋 Auditors/Dealer Users loaded:", auditorsData);

      // Debug: Log first user's fields to see available properties
      if (auditorsData && auditorsData.length > 0) {
        console.log("📋 First user object keys:", Object.keys(auditorsData[0]));
        console.log("📋 First user full object:", auditorsData[0]);
      }

      setDealerUsers(auditorsData || []);
    } catch (err) {
      console.error("Error fetching dealer users:", err);
      setDealerUsers([]);
    } finally {
      setUsersLoading(false);
    }
  }, []);

  // Initial fetch
  useEffect(() => {
    fetchScoreViews();
    fetchDealerUsers();
  }, [fetchScoreViews, fetchDealerUsers]);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 FILTERED DATA
  // ═══════════════════════════════════════════════════════════════
  const filteredData = useMemo(() => {
    const search = (searchTerm || "").trim().toLowerCase();

    return scoreViewsData.filter((item) => {
      const matchesSearch =
        search === "" ||
        (item.kpiNo || "").toLowerCase().includes(search) ||
        (item.strategicObjective || "").toLowerCase().includes(search) ||
        (item.kpi || "").toLowerCase().includes(search) ||
        (item.subKpi || "").toLowerCase().includes(search);

      const matchesKpiNo =
        filters.kpiNo.length === 0 || filters.kpiNo.includes(item.kpiNo);

      const matchesStrategicObjective =
        filters.strategicObjective.length === 0 ||
        filters.strategicObjective.includes(item.strategicObjective);

      return matchesSearch && matchesKpiNo && matchesStrategicObjective;
    });
  }, [scoreViewsData, filters, searchTerm]);

  const filteredResponses = useMemo(() => {
    if (!ressearchQuery) return responses;

    return responses.filter((item) => {
      return (
        (item.systemUser?.toLowerCase() || "").includes(ressearchQuery.toLowerCase()) ||
        (item.commentsBy?.toLowerCase() || "").includes(ressearchQuery.toLowerCase()) ||
        (item.comments?.toLowerCase() || "").includes(ressearchQuery.toLowerCase()) ||
        (item.createdDate?.toLowerCase() || "").includes(ressearchQuery.toLowerCase())
      );
    });
  }, [ressearchQuery, responses]);

  // ═══════════════════════════════════════════════════════════════
  // ♾️ INFINITE SCROLL
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const calculateRowsToShow = () => {
      setRowsToShow(10);
      setBatchSize(10);
    };
    calculateRowsToShow();
    window.addEventListener("resize", calculateRowsToShow);
    return () => window.removeEventListener("resize", calculateRowsToShow);
  }, []);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 1024);
    };
    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  useEffect(() => {
    setDisplayedItems(filteredData.slice(0, rowsToShow));
    setHasMore(filteredData.length > rowsToShow);
  }, [filteredData, rowsToShow]);

  const loadMoreItems = useCallback(() => {
    if (isLoadingMore || !hasMore) return;

    setIsLoadingMore(true);
    setTimeout(() => {
      setDisplayedItems((prevDisplayed) => {
        const currentLength = prevDisplayed.length;
        const nextBatch = filteredData.slice(currentLength, currentLength + batchSize);
        if (nextBatch.length > 0) {
          setHasMore(currentLength + nextBatch.length < filteredData.length);
          return [...prevDisplayed, ...nextBatch];
        } else {
          setHasMore(false);
          return prevDisplayed;
        }
      });
      setIsLoadingMore(false);
    }, 300);
  }, [filteredData, batchSize, hasMore, isLoadingMore]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore) {
          loadMoreItems();
        }
      },
      { threshold: 0.1 }
    );

    const currentTarget = observerTarget.current;
    if (currentTarget) observer.observe(currentTarget);
    return () => {
      if (currentTarget) observer.unobserve(currentTarget);
    };
  }, [loadMoreItems, hasMore, isLoadingMore]);

  // ═══════════════════════════════════════════════════════════════
  // 🔧 HELPER FUNCTIONS
  // ═══════════════════════════════════════════════════════════════
  const formatDateDisplay = (dateString) => {
    if (!dateString) return "";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return dateString;
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();
      return `${day}/${month}/${year}`;
    } catch {
      return dateString;
    }
  };

  // Helper function to format date for input (YYYY-MM-DD)
  const formatDateForInput = (dateString) => {
    if (!dateString) return "";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        // Try parsing DD/MM/YYYY format
        const parts = dateString.split('/');
        if (parts.length === 3) {
          return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
        }
        return "";
      }
      return date.toISOString().split('T')[0];
    } catch {
      return "";
    }
  };

  const getFileName = (url) => {
    if (!url) return "";
    try {
      const parts = url.split('/');
      return parts[parts.length - 1] || "Document";
    } catch {
      return "Document";
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🎯 EVENT HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleBack = () => navigate(-1);

  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const handleViewCriteria = (criteria) => {
    setSelectedCriteria(criteria);
    setShowCriteriaModal(true);
  };

  const handleDownloadDocument = (fileName) => {
    if (fileName) {
      window.open(fileName, "_blank");
    }
  };

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }));
    }
  };

  const handleResponseChange = (field, value) => {
    setResponseForm((prev) => ({ ...prev, [field]: value }));
    if (responseErrors[field]) {
      setResponseErrors((prev) => ({ ...prev, [field]: "" }));
    }
  };

  const handleChangeAssign = (eOrField, val) => {
    if (typeof eOrField === "string") {
      setAssignForm((prev) => ({ ...prev, [eOrField]: val }));
      if (assignErrors[eOrField]) {
        setAssignErrors((prev) => ({ ...prev, [eOrField]: "" }));
      }
      return;
    }
    const { name, value } = eOrField.target;
    setAssignForm((prev) => ({ ...prev, [name]: value }));
    if (assignErrors[name]) {
      setAssignErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 📤 OPEN UPLOAD POPUP
  // ═══════════════════════════════════════════════════════════════
  const handleOpenUploadPopup = (item) => {
    setSelectedUploadItem(item);
    setFormData({
      file: item.supportingDoc || "",
      fileObject: null,
    });
    setShowUploadPopup(true);
  };

  // ═══════════════════════════════════════════════════════════════
  // 📤 SAVE UPLOADED DOCUMENT
  // ═══════════════════════════════════════════════════════════════
  const handleSaveUpload = async () => {
    if (!formData.fileObject) {
      alert("Please select a file to upload");
      return;
    }

    if (!selectedUploadItem?.id) {
      alert("No score view selected");
      return;
    }

    setUploadLoading(true);
    try {
      console.log("📤 Uploading file for score view:", selectedUploadItem.id);
      await uploadScorecardScoreViewDoc(selectedUploadItem.id, formData.fileObject);
      console.log("✅ File uploaded successfully");

      // Force refresh score views data from API to get updated supporting_doc and uploaded_by
      await fetchScoreViews(true);

      setShowUploadPopup(false);
      setFormData({ file: "", fileObject: null });
      setSelectedUploadItem(null);
      alert("Document uploaded successfully!");
    } catch (err) {
      console.error("❌ Upload failed:", err);
      alert("Failed to upload document: " + err.message);
    } finally {
      setUploadLoading(false);
    }
  };

  // Open action items popup
  const handleOpenActionPopup = (item) => {
    setSelectedScoreViewId(item.id);
    setSelectedScoreView(item);
    setForm({
      year: parentRowData?.year || rowData?.year || "",
      quarter: parentRowData?.quarter || rowData?.quarter || "",
      strategicObjective: item.strategicObjective || rowData?.strategicObjective || "",
      kpi: item.kpi || "",
      subKpi: item.subKpi || "",
      comments: "",
    });
    setShowActionPopup(true);
    setPopupView("ACTION_TABLE");
    fetchActionItems(item.id);
  };

  // ═══════════════════════════════════════════════════════════════
  // 💾 SAVE ACTION ITEM
  // ═══════════════════════════════════════════════════════════════
  const handleSaveAction = async () => {
    if (!selectedScoreViewId) {
      alert("No score view selected");
      return;
    }

    // Validate comments
    if (!form.comments || form.comments.trim() === "") {
      setErrors({ comments: "Please enter comments" });
      return;
    }

    setActionLoading(true);
    try {
      // Create the action item (backend doesn't have remarks field)
      const newActionItem = await addScorecardActionItem({
        scoreViewId: selectedScoreViewId,
        status: "Created",
        subKpi: selectedScoreView?.subKpi || form.subKpi || "",
        strategicObjective: selectedScoreView?.strategicObjective || form.strategicObjective || "",
        maxScore: selectedScoreView?.maxScore || 0,
      });

      // Add the comment to action_log table (this is where comments are stored)
      if (form.comments && newActionItem.id) {
        try {
          await addScorecardActionLog({
            actionItemId: newActionItem.id,
            comments: form.comments,
          });
        } catch (logErr) {
          console.warn("Failed to add initial comment:", logErr);
        }
      }

      // Refresh action items from API to get proper data with first comment
      await fetchActionItems(selectedScoreViewId);

      // Only clear comments, keep the score view data for next add
      setForm(prev => ({ ...prev, comments: "" }));
      setErrors({});
      setPopupView("ACTION_TABLE");
    } catch (err) {
      console.error("Error adding action item:", err);
      alert(err.message || "Failed to add action item");
    } finally {
      setActionLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🗑️ DELETE ACTION ITEM
  // ═══════════════════════════════════════════════════════════════
  const handleConfirmDelete = async () => {
    if (!deleteRowId) return;

    setDeleteLoading(true);
    try {
      await deleteScorecardActionItem(deleteRowId);
      setActionItems((prev) => prev.filter((row) => row.id !== deleteRowId));
      setDeleteModalOpen(false);
      setDeleteRowId(null);
    } catch (err) {
      console.error("Error deleting action item:", err);
      alert(err.message || "Failed to delete action item");
    } finally {
      setDeleteLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 📤 ASSIGN ACTION ITEM
  // ═══════════════════════════════════════════════════════════════
  const handleAssign = async () => {
    let tempErrors = {};

    if (!assignform.assignTo) tempErrors.assignTo = "Please select Assign To";
    if (!assignform.endDate) tempErrors.endDate = "Please select End Date";
    if (assignform.assignTo === "Internal User" && !assignform.dealerUser)
      tempErrors.dealerUser = "Please select Dealer User";
    if (assignform.assignTo === "External User" && !assignform.email)
      tempErrors.email = "Please enter External Email";

    // Validate that we have a user ID for internal users
    if (assignform.assignTo === "Internal User" && !assignform.dealerUserId) {
      tempErrors.dealerUser = "User ID not found. Please re-select the user.";
      console.error("❌ No user ID found for selected dealer user:", assignform.dealerUser);
    }

    if (Object.keys(tempErrors).length > 0) {
      setAssignErrors(tempErrors);
      return;
    }

    // For display purposes (name)
    const assignedDisplayValue =
      assignform.assignTo === "External User"
        ? assignform.email
        : assignform.dealerUser;

    // For API - send user ID for internal users
    const assignedToId =
      assignform.assignTo === "Internal User"
        ? assignform.dealerUserId
        : null;

    console.log("📤 Assigning with:", {
      actionItemId: selectedRowId,
      assignedToId,
      assignedDisplayValue,
      endDate: assignform.endDate
    });

    setActionLoading(true);
    try {
      await updateScorecardActionItem({
        id: selectedRowId,
        assigned_to: assignedToId,  // Send user ID
        end_date: assignform.endDate,
        action_item_status: "In Progress",
      });

      // Add action log entry for the assignment
      await addScorecardActionLog({
        actionItemId: selectedRowId,
        comments: `Action item assigned to ${assignedDisplayValue}`,
      });

      setActionItems((prev) =>
        prev.map((row) =>
          row.id === selectedRowId
            ? { ...row, assignedTo: assignedDisplayValue, assignedToName: assignedDisplayValue, assignedToId: assignedToId, status: "In Progress" }
            : row
        )
      );

      // Refresh assignment history from API
      const logs = await getScorecardActionLogsByActionItemId(selectedRowId);
      setAssignmentHistory(logs || []);

      setAssignForm({ assignTo: "", dealerUser: "", dealerUserId: null, email: "", endDate: "" });
      setAssignErrors({});
      setPopupView("ACTION_TABLE");
    } catch (err) {
      console.error("Error assigning action item:", err);
      alert(err.message || "Failed to assign action item");
    } finally {
      setActionLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 💾 SAVE RESPONSE (Action Log)
  // ═══════════════════════════════════════════════════════════════
  const handleSaveResponse = async () => {
    let tempErrors = {};

    if (!responseForm.comments) tempErrors.comments = "Please enter comments";

    if (Object.keys(tempErrors).length > 0) {
      setResponseErrors(tempErrors);
      return;
    }

    setActionLoading(true);
    try {
      await addScorecardActionLog({
        actionItemId: selectedActionItem?.id,
        comments: responseForm.comments,
        file: responseForm.file || null,
      });

      // Refresh responses from API to get the actual data including supporting_doc_url
      await fetchResponses(selectedActionItem?.id);

      // Only clear comments and file, keep other data
      setResponseForm(prev => ({ ...prev, comments: "", file: null }));
      setResponseErrors({});
      setPopupView("RESPONSE_TABLE");
    } catch (err) {
      console.error("Error adding response:", err);
      alert(err.message || "Failed to add response");
    } finally {
      setActionLoading(false);
    }
  };

  // Open response view
  const handleViewResponses = (actionItem) => {
    setSelectedActionItem(actionItem);
    setResponseForm({
      year: form.year || parentRowData?.year || rowData?.year || "",
      quarter: form.quarter || parentRowData?.quarter || rowData?.quarter || "",
      strategicObjective: actionItem.strategicObjective || selectedScoreView?.strategicObjective || "",
      kpi: actionItem.kpi || selectedScoreView?.kpi || "",
      subKpi: actionItem.subKpi || selectedScoreView?.subKpi || "",
      comments: "",
      file: null,
    });
    fetchResponses(actionItem.id);
    setPopupView("RESPONSE_TABLE");
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔒 CLOSE ACTION ITEM
  // ═══════════════════════════════════════════════════════════════
  const handleCloseItem = () => {
    if (!selectedActionItem?.id) return;
    setCloseConfirmVisible(true);
  };

  const confirmCloseItem = async () => {
    if (!selectedActionItem?.id) return;

    setIsClosingItem(true);

    try {
      // Call API to update status to "Closed"
      await updateScorecardActionItem({
        id: selectedActionItem.id,
        status: "Closed",
      });

      // Add a log entry for the closure
      await addScorecardActionLog({
        actionItemId: selectedActionItem.id,
        comments: "Action item closed",
      });

      // Refresh responses to show the closure log
      await fetchResponses(selectedActionItem.id);

      // Update action items list
      setActionItems((prev) =>
        prev.map((item) =>
          item.id === selectedActionItem.id
            ? { ...item, status: "Closed" }
            : item
        )
      );

      // Update selected action item
      setSelectedActionItem((prev) =>
        prev ? { ...prev, status: "Closed" } : prev
      );

      setCloseConfirmVisible(false);
      console.log("Action item closed successfully");
    } catch (error) {
      console.error("Error closing action item:", error);
      alert(error.message || "Failed to close action item");
    } finally {
      setIsClosingItem(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 📱 MOBILE CARD COMPONENT
  // ═══════════════════════════════════════════════════════════════
  const MobileAuditCard = ({ item, index }) => (
    <div className="bg-white border border-gray-200 p-3 mb-3 shadow-sm">
      <div className="flex justify-between items-start mb-2">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold text-darkblue1">KPI {item.kpiNo}</span>
            <span className={`text-xs font-medium px-2 py-0.5 ${item.finalScore > 0 ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
              }`}>
              {item.finalScore > 0 ? "Scored" : "Not Scored"}
            </span>
          </div>
          <p className="text-xs font-medium text-black">{item.strategicObjective}</p>
          <p className="text-xs text-gray-600">{item.kpi}</p>
        </div>
      </div>

      <div className="space-y-1.5 border-t pt-2">
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Sub KPI:</span>
          <span className="text-xs text-black text-right line-clamp-2 flex-1 ml-2">{item.subKpi}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Max Score:</span>
          <span className="text-xs text-black font-medium">{item.maxScore}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Final Score:</span>
          <span className="text-xs text-darkblue1 font-semibold">{item.finalScore}</span>
        </div>
      </div>

      <div className="flex gap-2 mt-3 pt-2 border-t">
        <button
          onClick={() => handleOpenActionPopup(item)}
          className="flex-1 text-xs bg-darkblue1 text-white hover:bg-blue-700 py-1.5 transition"
        >
          View Actions
        </button>
      </div>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header Section */}
          <div className="flex flex-col w-full mb-3">
            <div className="flex items-center gap-2">
              <ArrowLeft
                onClick={handleBack}
                size={20}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
              />
              <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                {rowData?.strategicObjective || "Score Details"} - {parentRowData?.year || rowData?.year}, {parentRowData?.quarter || rowData?.quarter}
              </h2>
            </div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-[150px] sm:w-[200px] ml-7"></div>
          </div>

          {/* Loading State */}
          {isLoading && (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
              <span className="ml-3 text-gray-600">Loading data...</span>
            </div>
          )}

          {/* Error State */}
          {error && !isLoading && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
              <span className="text-red-600">{error}</span>
            </div>
          )}

          {/* Main Content */}
          {!isLoading && !error && (
            <>
              {/* Filters Row */}
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-3 w-full">
                <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
                  <Searchinput
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search"
                    className="w-[1/2]"
                    iconColor="text-black"
                    bgColor="bg-FrostWhite"
                    borderColor="border-black"
                    textColor="text-black"
                    shadow="shadow-none"
                    inputPadding="pl-7 pr-3 py-1.5"
                    iconSize="w-3.5 h-3.5"
                    iconLeft="left-3"
                    inputWidth="w-full"
                    focusRing="focus:ring-1 focus:ring-black/60"
                    hoverInputClasses="hover:bg-white hover:border-black/60"
                  />

                  <Filter
                    name="kpiNo"
                    value={filters.kpiNo}
                    options={kpiNoOptions}
                    onChange={handleFilterChange}
                    placeholder="KPI No"
                    customWidth="w-[130px] sm:w-[140px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-gray-300"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />

                  <Filter
                    name="strategicObjective"
                    value={filters.strategicObjective}
                    options={strategicObjectiveOptions}
                    onChange={handleFilterChange}
                    placeholder="Strategic Objective"
                    customWidth="w-[170px] sm:w-[200px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-gray-300"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />
                </div>
              </div>

              {/* Data Display */}
              {isMobileView ? (
                <div className="space-y-3">
                  {displayedItems.length > 0 ? (
                    <>
                      {displayedItems.map((item, index) => (
                        <MobileAuditCard key={`${item.id}-${index}`} item={item} index={index} />
                      ))}
                      {isLoadingMore && (
                        <div className="flex justify-center py-3">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        </div>
                      )}
                      <div ref={observerTarget} className="h-2" />
                    </>
                  ) : (
                    <div className="bg-white border border-gray-200 rounded-lg p-6 text-center text-gray-500">
                      No records found
                    </div>
                  )}
                </div>
              ) : (
                <div className="bg-white shadow-md border border-Dustyblue">
                  <div
                    ref={tableContainerRef}
                    className="hide-scrollbar overflow-y-auto overflow-x-auto max-h-[calc(100vh-280px)] sm:max-h-[calc(100vh-260px)] md:max-h-[calc(100vh-240px)] lg:max-h-[calc(100vh-220px)] xl:max-h-[calc(100vh-200px)]"
                  >
                    <style jsx>{`
                      .hide-scrollbar::-webkit-scrollbar { display: none; }
                      .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
                    `}</style>

                    <table className="w-full text-xs border-collapse">
                      <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                        <tr>
                          <th className="px-2 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 w-[5%]">KPI No</th>
                          <th className="px-2 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 w-[10%]">Strategic Objective</th>
                          <th className="px-2 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 w-[10%]">KPI</th>
                          <th className="px-2 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 w-[12%]">Sub KPI</th>
                          <th className="px-2 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 w-[5%]">Criteria</th>
                          <th className="px-2 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 w-[5%]">Max Score</th>
                          <th className="px-2 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 w-[6%]">Reviewer Score</th>
                          <th className="px-2 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 w-[5%]">Threshold</th>
                          <th className="px-2 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 w-[5%]">Final Score</th>
                          <th className="px-2 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 w-[5%]">Excluded</th>
                          <th className="px-2 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 w-[8%]">Supporting Template</th>
                          <th className="px-2 py-1.5 text-center font-medium border border-grey2 border-t-0 border-l-0 w-[6%]">Supporting Doc</th>
                          <th className="px-2 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 w-[8%]">Uploaded By</th>
                          <th className="px-2 py-1.5 text-left font-medium border border-grey2 border-t-0 border-l-0 w-[6%]">Scored By</th>
                          <th className="px-2 py-1.5 text-center font-medium border-t-0 border-l-0 border-r-0 w-[4%]">Action Items</th>
                        </tr>
                      </thead>

                      <tbody>
                        {displayedItems.length > 0 ? (
                          <>
                            {displayedItems.map((item, index) => (
                              <tr
                                key={`${item.id}-${index}`}
                                className={`text-xs transition ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'
                                  } hover:bg-lightBlue/30`}
                              >
                                <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">{item.kpiNo}</td>
                                <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">{item.strategicObjective}</td>
                                <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">{item.kpi}</td>
                                <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">{item.subKpi}</td>
                                <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                  <button
                                    onClick={() => handleViewCriteria({
                                      scoring: item.scoringCriteria || "",
                                      definition: item.criteriaDefinition || "",
                                    })}
                                    className="inline-flex items-center justify-center w-full hover:bg-gray-200 transition p-1"
                                  >
                                    <svg className="w-4 h-4 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
                                      <path d="M9 2a2 2 0 00-2 2v8a2 2 0 002 2h6a2 2 0 002-2V6.414A2 2 0 0016.414 5L14 2.586A2 2 0 0012.586 2H9z" />
                                      <path d="M3 8a2 2 0 012-2v10h8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z" />
                                    </svg>
                                  </button>
                                </td>
                                <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">{item.maxScore}</td>
                                <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">{item.reviewerScore || "—"}</td>
                                <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">{item.minScore || "—"}</td>
                                <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">{item.finalScore || "—"}</td>
                                <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${item.isExcluded ? "bg-yellow-100 text-yellow-700" : "bg-gray-100 text-gray-600"
                                    }`}>
                                    {item.isExcluded ? "Yes" : "No"}
                                  </span>
                                </td>
                                {/* Supporting Template - from sub_kpi_master.doc */}
                                <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                  {item.subKpiDoc ? (
                                    <button
                                      onClick={() => handleDownloadDocument(item.subKpiDoc)}
                                      className="text-blue-600 hover:text-blue-800 underline text-xs"
                                      title="Download Template"
                                    >
                                      Download
                                    </button>
                                  ) : (
                                    "—"
                                  )}
                                </td>
                                {/* Supporting Doc - user uploaded, with upload button */}
                                <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                  <div className="flex items-center justify-center gap-1">
                                    {/* Show download link if document exists */}
                                    {item.supportingDoc && (
                                      <button
                                        onClick={() => handleDownloadDocument(item.supportingDoc)}
                                        className="text-blue-600 hover:text-blue-800 underline text-[10px]"
                                        title="Download"
                                      >
                                        View
                                      </button>
                                    )}
                                    {/* Upload button */}
                                    <button
                                      onClick={() => handleOpenUploadPopup(item)}
                                      className="relative group w-6 h-6 flex items-center justify-center"
                                      title="Upload"
                                    >
                                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.8" stroke="currentColor" className="w-4 h-4 text-darkblue1">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 16V8m0 0l-3 3m3-3l3 3m6 5v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2" />
                                      </svg>
                                      <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 opacity-0 group-hover:opacity-100 transition z-20 whitespace-nowrap">
                                        Upload
                                      </span>
                                    </button>
                                  </div>
                                </td>
                                {/* Uploaded By - from scorecard_scoreview.uploaded_by */}
                                <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                  {item.uploadedByName ? (
                                    <>
                                      <div className="font-medium text-black text-xs">{item.uploadedByName}</div>
                                      {item.uploadedOn && (
                                        <div className="text-gray-600 text-[10px]">{formatDateDisplay(item.uploadedOn)}</div>
                                      )}
                                    </>
                                  ) : (
                                    "—"
                                  )}
                                </td>
                                {/* Scored By */}
                                <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                  {item.reviewerName ? (
                                    <div className="font-medium text-black text-xs">{item.reviewerName}</div>
                                  ) : (
                                    "—"
                                  )}
                                </td>
                                <td className="py-1 text-center border border-grey2">
                                  <button
                                    onClick={() => handleOpenActionPopup(item)}
                                    className="w-6 h-6 border border-grey flex items-center justify-center mx-auto hover:bg-lightBlue/50"
                                  >
                                   <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" className="w-3 h-2">
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="#212121"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
</svg>
                                  </button>
                                </td>
                              </tr>
                            ))}

                            {isLoadingMore && (
                              <tr>
                                <td colSpan={15} className="py-3 text-center text-gray-500">
                                  <div className="flex items-center justify-center gap-2">
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                                    Loading more...
                                  </div>
                                </td>
                              </tr>
                            )}

                            <tr ref={observerTarget}>
                              <td colSpan={15} className="h-0 p-0"></td>
                            </tr>
                          </>
                        ) : (
                          <tr className="hover:bg-gray-50">
                            <td colSpan={15} className="px-2 py-4 border border-grey2 text-center text-gray-500 italic">
                              No records found
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Criteria Display Modal */}
      {showCriteriaModal && selectedCriteria && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white max-w-3xl w-full shadow-2xl">
            <div className="bg-Dustyblue text-white px-4 py-3 flex items-center justify-between">
              <h3 className="text-sm font-semibold">Criteria Display</h3>
              <button
                onClick={() => setShowCriteriaModal(false)}
                className="bg-red-600 hover:bg-red-700 text-white rounded-full p-1 transition"
              >
                <X size={16} />
              </button>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-semibold text-black mb-3">Scoring Criteria:</h4>
                  <div className="bg-gray-100 p-4 text-xs text-black whitespace-pre-line">
                    {selectedCriteria.scoring || "—"}
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-black mb-3">Criteria Definition:</h4>
                  <div className="bg-gray-100 p-4 text-xs text-black">
                    {selectedCriteria.definition || "—"}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Upload Document Popup */}
      {showUploadPopup && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white w-[90%] max-w-[500px] h-auto shadow-lg p-6 relative">
            <button
              onClick={() => {
                setShowUploadPopup(false);
                setFormData({ file: "", fileObject: null });
                setSelectedUploadItem(null);
              }}
              className="absolute top-2 right-2 text-gray-500 hover:text-black"
            >
              <X size={16} />
            </button>
            <h2 className="text-base font-semibold text-center text-MediumGrey mb-4">
              View & Upload Supporting Document
            </h2>

            {/* Show existing document if any */}
            {selectedUploadItem?.supportingDoc && (
              <div className="mb-4 p-3 bg-gray-50 rounded">
                <p className="text-xs text-gray-600 mb-1">Current Document:</p>
                <button
                  onClick={() => handleDownloadDocument(selectedUploadItem.supportingDoc)}
                  className="text-blue-600 text-xs underline hover:text-blue-800"
                >
                  {getFileName(selectedUploadItem.supportingDoc)}
                </button>
                {selectedUploadItem.uploadedByName && (
                  <p className="text-[10px] text-gray-500 mt-1">
                    Uploaded by: {selectedUploadItem.uploadedByName}
                    {selectedUploadItem.uploadedOn && ` on ${formatDateDisplay(selectedUploadItem.uploadedOn)}`}
                  </p>
                )}
              </div>
            )}

            {/* File input */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={formData.fileObject ? formData.fileObject.name : ""}
                placeholder="Choose file..."
                className="flex-1 px-2 py-1.5 border border-black/30 text-xs bg-gray-50"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 bg-darkblue1 text-white text-xs hover:bg-darkblue1/80"
              >
                Browse
              </button>
            </div>
            <input
              type="file"
              ref={fileInputRef}
              style={{ display: "none" }}
              accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xlsx,.xls"
              onChange={(e) => {
                const file = e.target.files[0];
                if (file) {
                  setFormData({ ...formData, fileObject: file });
                }
              }}
            />
            <p className="text-[10px] text-gray-500 mt-1">
              Supported formats: PDF, JPG, PNG, DOC, DOCX, XLSX
            </p>

            <div className="flex justify-center gap-3 mt-6">
              <button
                onClick={() => {
                  setShowUploadPopup(false);
                  setFormData({ file: "", fileObject: null });
                  setSelectedUploadItem(null);
                }}
                className="px-6 py-1.5 border border-darkblue1 text-darkblue1 text-xs font-medium hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveUpload}
                disabled={uploadLoading || !formData.fileObject}
                className="px-6 py-1.5 bg-darkblue1 text-white text-xs font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {uploadLoading ? "Uploading..." : "Upload"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Action Items Popup */}
      {showActionPopup && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div
            ref={popupRef}
            onClick={(e) => e.stopPropagation()}
            className={`bg-white p-6 shadow-lg relative ${popupView === "ACTION_TABLE" ? "w-[90%]" :
                popupView === "RESPONSE_TABLE" ? "w-[80%]" :
                  popupView === "ADD_ACTION" ? "w-[50%]" :
                    popupView === "ADD_RESPONSE" ? "w-[50%]" :
                      popupView === "ADD_ASIGN" ? "w-[50%]" : "w-[70%]"
              }`}
          >
            {/* ACTION TABLE VIEW */}
            {popupView === "ACTION_TABLE" && (
              <>
                <div className="flex flex-col w-full mb-2">
                  <div className="flex items-center gap-2">
                    <ArrowLeft
                      onClick={() => setShowActionPopup(false)}
                      size={20}
                      className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
                    />
                    <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                      Action Items
                    </h2>
                  </div>
                  <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-7"></div>
                </div>

                <div className="flex justify-end mb-2">
                  <button
                    onClick={() => setPopupView("ADD_ACTION")}
                    className="bg-darkblue1 text-white text-xs px-4 py-1"
                  >
                    + Add Action Item
                  </button>
                </div>

                {actionLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-darkblue1"></div>
                    <span className="ml-2 text-gray-600 text-sm">Loading...</span>
                  </div>
                ) : (
                  <div className="bg-white border border-Dustyblue shadow max-h-[70vh] overflow-auto hide-scrollbar">
                    <style jsx>{`
                      .hide-scrollbar::-webkit-scrollbar { display: none; }
                      .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
                    `}</style>
                    <table className="w-full text-xs">
                      <thead className="bg-Dustyblue text-white sticky top-0 text-left z-20">
                        <tr>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Created By</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Review Sub KPI</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Created Date</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0 text-center">Max Score</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0 text-center">Final Score</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Remarks</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Status</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Assigned To</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0 border-r-0 text-center sticky right-0 bg-Dustyblue z-10">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {actionItems.length === 0 ? (
                          <tr>
                            <td colSpan={9} className="text-center p-3 italic text-gray-500">
                              No data found
                            </td>
                          </tr>
                        ) : (
                          actionItems.map((item, i) => (
                            <tr key={item.id || i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1">{item.createdByName || item.createdBy || "User"}</td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1">{item.subKpi || selectedScoreView?.subKpi || "-"}</td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1">{item.createdDate || formatDateDisplay(item.createdAt)}</td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1 text-center">{item.maxScore || selectedScoreView?.maxScore || 0}</td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1 text-center">{item.finalScore || 0}</td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1">{item.remarks || item.comments || "—"}</td>
                              <td className={`border border-grey2 border-t-0 border-l-0 p-1 text-xs font-medium ${item.status === "Completed" || item.status === "Closed" ? "text-green-600" :
                                  item.status === "In Progress" ? "text-blue-600" : "text-black"
                                }`}>
                                {item.status || "Created"}
                              </td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1">{item.assignedToName || item.assignedTo || "—"}</td>
                              <td className={`border border-grey2 border-t-0 border-l-0 border-r-0 text-center sticky right-0 ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'} z-10`}>
                                <div className="flex items-center justify-center gap-2">
                                  {/* View */}
                                  <div className="relative group">
                                    <button
                                      onClick={() => handleViewResponses(item)}
                                      className="w-5 h-5 border border-black flex items-center justify-center hover:bg-lightBlue/50"
                                    >
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"  className="w-3 h-2">
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="#212121"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
</svg>                                    </button>
                                    <span className="absolute left-1/2 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                                      View
                                    </span>
                                  </div>

                                  {item.status !== "Completed" && item.status !== "Closed" && (
                                    <>
                                      {/* Assign */}
                                      <div className="relative group">
                                        <button
                                          onClick={async () => {
                                            setSelectedRowId(item.id);
                                            setSelectedActionItemForAssign(item);

                                            // Pre-fill form with existing assignment data
                                            if (item.assignedTo || item.assignedToName || item.assignedToId) {
                                              const assignedValue = item.assignedToName || item.assignedTo || "";
                                              const assignedId = item.assignedToId || null;
                                              const isEmail = assignedValue.includes("@");

                                              setAssignForm({
                                                assignTo: isEmail ? "External User" : "Internal User",
                                                email: isEmail ? assignedValue : "",
                                                dealerUser: !isEmail ? assignedValue : "",
                                                dealerUserId: !isEmail ? assignedId : null,
                                                endDate: item.endDate ? formatDateForInput(item.endDate) : "",
                                              });
                                            } else {
                                              // Reset form if no previous assignment
                                              setAssignForm({ assignTo: "", dealerUser: "", dealerUserId: null, email: "", endDate: "" });
                                            }
                                            setAssignErrors({});

                                            setPopupView("ADD_ASIGN");
                                            // Fetch action logs for this action item
                                            try {
                                              console.log("📋 Fetching action logs for item.id:", item.id);
                                              const logs = await getScorecardActionLogsByActionItemId(item.id);
                                              console.log("📋 Action Logs API Response:", logs);
                                              console.log("📋 Logs count:", logs?.length || 0);
                                              setAssignmentHistory(logs || []);
                                            } catch (err) {
                                              console.error("Error fetching action logs:", err);
                                              setAssignmentHistory([]);
                                            }
                                          }}
                                          className="w-5 h-5 border border-black flex items-center justify-center hover:bg-lightBlue/50"
                                        >
                                          <svg className="w-4 h-4 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                          </svg>
                                        </button>
                                        <span className="absolute left-1/2 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                                          {item.assignedTo || item.assignedToName ? "Reassign" : "Assign"}
                                        </span>
                                      </div>

                                      {/* Delete */}
                                      <div className="relative group">
                                        <button
                                          onClick={() => {
                                            setDeleteRowId(item.id);
                                            setDeleteModalOpen(true);
                                          }}
                                          className="w-5 h-5 border border-black flex items-center justify-center hover:bg-lightBlue/50"
                                        >
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>
                                        </button>
                                        <span className="absolute left-1/2 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                                          Delete
                                        </span>
                                      </div>
                                    </>
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}

            {/* ADD ACTION VIEW */}
            {popupView === "ADD_ACTION" && (
              <>
                <h2 className="text-base font-semibold text-MediumGrey">Manual Action Item Form</h2>
                <div className="hidden lg:block h-1 bg-MediumGrey w-[10%] mb-4"></div>

                <form className="w-full">
                  <div className="grid grid-cols-2 gap-4">
                    {/* Year - Read Only */}
                    <div className="mt-1">
                      <label className="block text-xs font-medium mb-1 text-black/70">
                        Year
                      </label>
                      <input
                        type="text"
                        className="w-full p-1.5 text-xs border border-black/30 bg-gray-100 text-gray-700 cursor-not-allowed"
                        value={form.year}
                        readOnly
                        disabled
                      />
                    </div>

                    {/* Quarter - Read Only */}
                    <div className="mt-1">
                      <label className="block text-xs font-medium mb-1 text-black/70">
                        Quarter
                      </label>
                      <input
                        type="text"
                        className="w-full p-1.5 text-xs border border-black/30 bg-gray-100 text-gray-700 cursor-not-allowed"
                        value={form.quarter}
                        readOnly
                        disabled
                      />
                    </div>

                    {/* Strategic Objective - Read Only */}
                    <div>
                      <label className="block text-xs text-black/70 font-medium mb-1">Strategic Objective</label>
                      <input
                        type="text"
                        className="w-full p-1.5 border border-black/30 text-xs bg-gray-100 text-gray-700 cursor-not-allowed"
                        value={form.strategicObjective}
                        readOnly
                        disabled
                      />
                    </div>

                    {/* KPI - Read Only */}
                    <div>
                      <label className="block text-xs text-black/70 font-medium mb-1">KPI</label>
                      <input
                        type="text"
                        className="w-full p-1.5 border border-black/30 text-xs bg-gray-100 text-gray-700 cursor-not-allowed"
                        value={form.kpi}
                        readOnly
                        disabled
                      />
                    </div>

                    {/* Sub KPI - Read Only */}
                    <div>
                      <label className="block text-xs text-black/70 font-medium mb-1">
                        Sub KPI
                      </label>
                      <input
                        type="text"
                        className="w-full p-1.5 text-xs border border-black/30 bg-gray-100 text-gray-700 cursor-not-allowed"
                        value={form.subKpi}
                        readOnly
                        disabled
                      />
                    </div>

                    {/* Comments - Editable */}
                    <div className="col-span-2">
                      <label className="block text-xs text-black/70 font-medium mb-1">
                        Comments <span className="text-red-600">*</span>
                      </label>
                      <textarea
                        className={`w-full p-2 border text-xs resize-none focus:outline-none focus:ring-1 focus:ring-darkblue1 ${errors.comments ? "border-red-500" : "border-black/30"}`}
                        rows={3}
                        placeholder="Enter comments..."
                        value={form.comments}
                        onChange={(e) => handleChange("comments", e.target.value)}
                      ></textarea>
                      {errors.comments && <p className="text-red-500 text-xs mt-1">{errors.comments}</p>}
                    </div>
                  </div>
                </form>

                <div className="flex justify-center gap-4 mt-4">
                  <button
                    type="button"
                    className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium hover:bg-mildBlue1"
                    onClick={() => {
                      // Only clear comments, keep the score view data
                      setForm(prev => ({ ...prev, comments: "" }));
                      setErrors({});
                      setPopupView("ACTION_TABLE");
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveAction}
                    disabled={actionLoading}
                    className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 transition hover:bg-blue-700 disabled:opacity-50"
                  >
                    {actionLoading ? "Saving..." : "Save"}
                  </button>
                </div>
              </>
            )}

            {/* ASSIGN VIEW */}
            {popupView === "ADD_ASIGN" && (
              <div>
                <div className="flex items-center gap-2">
                  <ArrowLeft
                    onClick={() => {
                      setAssignForm({ assignTo: "", dealerUser: "", email: "", endDate: "" });
                      setAssignErrors({});
                      setPopupView("ACTION_TABLE");
                    }}
                    size={20}
                    className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
                  />
                  <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                    {(selectedActionItemForAssign?.assignedTo || selectedActionItemForAssign?.assignedToName)
                      ? "Reassign Action Item"
                      : "Assign Action Item"}
                  </h2>
                </div>
                <div className="hidden lg:block h-1 bg-darkblue1 w-[12%] ml-7"></div>

                {/* Current Assignment Info - Show if already assigned */}
                {(selectedActionItemForAssign?.assignedTo || selectedActionItemForAssign?.assignedToName) && (
                  <div className="bg-blue-50 border border-blue-200 p-3 mt-3 mb-2">
                    <h4 className="text-xs font-semibold text-blue-800 mb-2">Current Assignment:</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                      <div>
                        <span className="text-gray-500">Assigned To:</span>
                        <p className="font-medium text-black">{selectedActionItemForAssign?.assignedTo || selectedActionItemForAssign?.assignedToName || "—"}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Status:</span>
                        <p className="font-medium text-black">{selectedActionItemForAssign?.status || "—"}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Target Date:</span>
                        <p className="font-medium text-black">{selectedActionItemForAssign?.endDate ? formatDateDisplay(selectedActionItemForAssign.endDate) : "—"}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Sub KPI:</span>
                        <p className="font-medium text-black">{selectedActionItemForAssign?.subKpi || "—"}</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Sub KPI Info Bar - Show only if NOT already assigned */}
                {!(selectedActionItemForAssign?.assignedTo || selectedActionItemForAssign?.assignedToName) && (
                  <div className="bg-gray-100 p-2 mt-3 flex flex-wrap gap-4 text-xs">
                    <div>
                      <span className="text-gray-500">Sub KPI: </span>
                      <span className="font-medium text-black">{selectedActionItemForAssign?.subKpi || "—"}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Status: </span>
                      <span className="font-medium text-black">{selectedActionItemForAssign?.status || "Created"}</span>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <StyledSelectField
                    label="Assign To"
                    placeholder="Select User Type"
                    value={assignform.assignTo}
                    setValue={(val) => handleChangeAssign("assignTo", val)}
                    options={assignToOptions}
                    dropdownOpen={assigndropdowns.assignTo}
                    setDropdownOpen={(val) => setAssignDropdowns((prev) => ({ ...prev, assignTo: val }))}
                    dropdownRef={assignrefs.assignTo}
                    error={assignErrors.assignTo}
                  />

                  <div className="mb-2">
                    <label className="block text-xs font-medium text-black/60 mb-2">End Date <span className="text-red-500">*</span></label>
                    <div
                      className={`relative flex items-center px-3 py-1.5 cursor-pointer border ${assignErrors.endDate ? "border-red-500" : "border-black/30"}`}
                      onClick={() => document.getElementById('endDateInput')?.showPicker?.() || document.getElementById('endDateInput')?.focus()}
                    >
                      <input
                        id="endDateInput"
                        type="date"
                        name="endDate"
                        value={assignform.endDate}
                        onChange={(e) => handleChangeAssign(e)}
                        className="w-full text-xs bg-transparent outline-none cursor-pointer [&::-webkit-calendar-picker-indicator]:opacity-0 [&::-webkit-calendar-picker-indicator]:absolute [&::-webkit-calendar-picker-indicator]:right-0 [&::-webkit-calendar-picker-indicator]:w-full [&::-webkit-calendar-picker-indicator]:h-full [&::-webkit-calendar-picker-indicator]:cursor-pointer"
                      />
                      <FaRegCalendar className="absolute right-3 text-xs pointer-events-none text-black" />
                    </div>
                    {assignErrors.endDate && <p className="text-xs text-red-500 mt-1">{assignErrors.endDate}</p>}
                  </div>

                  {assignform.assignTo === "Internal User" && (
                    <div className="md:col-span-2">
                      <StyledSelectField
                        label="Select Dealer User"
                        placeholder={usersLoading ? "Loading users..." : "Select User"}
                        value={assignform.dealerUser}
                        setValue={(val) => {
                          // Find the selected user to get their ID
                          const selectedUser = dealerUsers.find(user => {
                            const userName = user.label || user.value || `${user.firstName || ""} ${user.lastName || ""}`.trim();
                            return userName === val;
                          });

                          console.log("📋 Selected user object:", selectedUser);
                          console.log("📋 All keys:", selectedUser ? Object.keys(selectedUser) : []);

                          // Try multiple possible field names for user ID
                          const userId = selectedUser?.id ||
                            selectedUser?.userId ||
                            selectedUser?.user_id ||
                            selectedUser?.auditorId ||
                            selectedUser?.auditor_id ||
                            selectedUser?.userID ||
                            selectedUser?.ID ||
                            null;

                          console.log("📋 User ID found:", userId);

                          setAssignForm(prev => ({
                            ...prev,
                            dealerUser: val,
                            dealerUserId: userId
                          }));
                          if (assignErrors.dealerUser) {
                            setAssignErrors(prev => ({ ...prev, dealerUser: "" }));
                          }
                        }}
                        options={dealerUsers.map(user => ({
                          label: user.label || user.value || `${user.firstName || ""} ${user.lastName || ""}`.trim(),
                          value: user.label || user.value || `${user.firstName || ""} ${user.lastName || ""}`.trim(),
                        }))}
                        dropdownOpen={assigndropdowns.dealerUser}
                        setDropdownOpen={(val) => setAssignDropdowns((prev) => ({ ...prev, dealerUser: val }))}
                        dropdownRef={assignrefs.dealerUser}
                        error={assignErrors.dealerUser}
                        disabled={usersLoading}
                      />
                      {/* Debug: Show selected user ID */}
                      {assignform.dealerUserId && (
                        <p className="text-[10px] text-green-600 mt-1">✓ User ID: {assignform.dealerUserId}</p>
                      )}
                      {assignform.dealerUser && !assignform.dealerUserId && (
                        <p className="text-[10px] text-red-500 mt-1">⚠ No User ID found - check console</p>
                      )}
                    </div>
                  )}

                  {assignform.assignTo === "External User" && (
                    <div className="md:col-span-2">
                      <label className="block text-xs font-medium text-black mb-2">External Email</label>
                      <input
                        type="email"
                        name="email"
                        value={assignform.email}
                        onChange={(e) => handleChangeAssign(e)}
                        placeholder="Enter external user email"
                        className={`w-full px-3 py-2 border text-xs bg-white ${assignErrors.email ? "border-red-500" : "border-black/30"}`}
                      />
                      {assignErrors.email && <p className="text-xs text-red-500 mt-1">{assignErrors.email}</p>}
                    </div>
                  )}
                </div>

                <div className="flex justify-end mt-4 mb-4">
                  <button
                    onClick={handleAssign}
                    disabled={actionLoading}
                    className="px-8 py-1.5 bg-darkblue1 text-white text-xs font-medium hover:bg-opacity-90 transition disabled:opacity-50"
                  >
                    {actionLoading ? "Assigning..." : "Assign"}
                  </button>
                </div>

                {/* List of Messages Table */}
                <div className="border border-gray-300 bg-white">
                  <div className="bg-gray-600 text-white text-sm font-medium px-3 py-2">
                    List of Messages
                  </div>
                  <table className="w-full text-xs">
                    <thead className="bg-gray-100 text-gray-700 text-left font-medium">
                      <tr>
                        <th className="p-2 border-b border-gray-300">Comments By</th>
                        <th className="p-2 border-b border-gray-300">ActionItem ▲</th>
                        <th className="p-2 border-b border-gray-300">Comments</th>
                        <th className="p-2 border-b border-gray-300">Created Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {assignmentHistory.length === 0 ? (
                        <tr>
                          <td colSpan="4" className="text-center py-4 text-gray-500 italic">No data found</td>
                        </tr>
                      ) : (
                        assignmentHistory.map((log, index) => (
                          <tr key={log.id || index} className="font-normal text-xs border-b border-gray-200 hover:bg-gray-50">
                            <td className="p-2">{log.commentedByName ? "User" : "System"}</td>
                            <td className="p-2">{selectedActionItemForAssign?.subKpi || selectedActionItemForAssign?.subKPI || "Action Item"}</td>
                            <td className="p-2">{log.comments || ""}</td>
                            <td className="p-2">{log.createdDate || ""}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* RESPONSE TABLE VIEW */}
            {popupView === "RESPONSE_TABLE" && (
              <>
                <div className="flex flex-col w-full mb-4">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <ArrowLeft
                        onClick={() => setPopupView("ACTION_TABLE")}
                        size={20}
                        className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
                      />
                      <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                        {selectedActionItem?.subKpi || selectedScoreView?.subKpi || "Action Item Responses"}
                      </h2>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 rounded text-sm font-medium ${selectedActionItem?.status === "Completed" || selectedActionItem?.status === "Closed"
                          ? "bg-green-100 text-green-600"
                          : selectedActionItem?.status === "In Progress"
                            ? "bg-blue-100 text-blue-600"
                            : selectedActionItem?.assignedTo || selectedActionItem?.assignedToName
                              ? "bg-green-100 text-green-600"
                              : "bg-gray-100 text-gray-600"
                        }`}>
                        {selectedActionItem?.assignedTo || selectedActionItem?.assignedToName
                          ? "Assigned"
                          : selectedActionItem?.status || "Created"}
                      </span>
                    </div>
                  </div>
                  <div className="h-[2px] bg-darkblue1 w-[10%] ml-7 -mt-2"></div>
                </div>

                <div className="flex justify-between items-center mb-2">
                  <Searchinput
                    value={ressearchQuery}
                    onChange={(e) => setResSearchQuery(e.target.value)}
                    placeholder="Search"
                    iconColor="text-black"
                    bgColor="bg-FrostWhite"
                    borderColor="border-black/60"
                    textColor="text-black"
                    shadow="shadow-none"
                    inputPadding="pl-6 pr-3 py-1.5"
                    iconSize="w-3 h-3"
                    iconLeft="left-3 top-4"
                    inputWidth="w-full"
                    focusRing="focus:ring-black/60"
                    hoverInputClasses="hover:bg-white hover:border-black/60"
                  />
                  <div className="flex items-center gap-2">
                    {/* Show Add Response button only when assigned (In Progress) */}
                    {selectedActionItem?.status === "In Progress" && (
                      <button
                        onClick={() => setPopupView("ADD_RESPONSE")}
                        className="bg-darkblue1 text-white text-xs px-4 py-1 hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1"
                      >
                        + Add Response
                      </button>
                    )}

                    {/* Close Item Button - Only visible when assigned person has replied */}
                    {selectedActionItem?.status === "In Progress" &&
                      responses.some(r =>
                        r.comments &&
                        r.commentedBy &&  // Must be a user response (has commentedBy)
                        !r.comments.startsWith("Action item assigned to") &&
                        !r.comments.startsWith("Action item closed") &&
                        r.commentedBy !== selectedActionItem?.createdBy  // Response from someone other than creator
                      ) && (
                        <button
                          onClick={handleCloseItem}
                          disabled={isClosingItem}
                          className="px-4 py-1.5 bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition text-xs font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {isClosingItem ? (
                            <>
                              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                              Closing...
                            </>
                          ) : (
                            <>
                              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                              Close Item
                            </>
                          )}
                        </button>
                      )}

                    {/* Show Closed badge when item is closed */}
                    {selectedActionItem?.status === "Closed" && (
                      <div className="px-4 py-1 bg-gray-100 border border-gray-300 text-gray-600 text-xs font-medium flex items-center gap-2">
                        <svg className="w-3 h-3 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Item Closed
                      </div>
                    )}
                  </div>
                </div>

                {/* Show message if not assigned yet (status is Created) */}
                {selectedActionItem?.status === "Created" && (
                  <div className="bg-yellow-50 border border-yellow-300 text-yellow-800 px-4 py-2 mb-3 text-xs">
                    <span className="font-medium">Note:</span> Please assign the action item first to add responses.
                  </div>
                )}

                <div className="bg-white shadow-md border border-Dustyblue max-h-[50vh] overflow-auto">
                  <table className="w-full text-xs border-collapse">
                    <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                      <tr className="text-left">
                        <th className="p-1.5 border border-grey2 border-t-0 border-l-0">System / User</th>
                        <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Comments By</th>
                        <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Comments</th>
                        <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Created Date</th>
                        <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Supporting Document</th>
                        <th className="p-1.5 text-center border border-grey2 border-t-0 border-l-0 border-r-0">Action Details</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredResponses.length === 0 ? (
                        <tr>
                          <td colSpan="6" className="p-3 text-center text-gray-500 italic">No data found</td>
                        </tr>
                      ) : (
                        filteredResponses.map((item, index) => (
                          <tr key={item.id || index}>
                            <td className="p-1 border border-grey2 border-t-0 border-l-0">{item.commentedBy ? "User" : "System"}</td>
                            <td className="p-1 border border-grey2 border-t-0 border-l-0">{item.commentedByName || "—"}</td>
                            <td className="p-1 border border-grey2 border-t-0 border-l-0">{item.comments}</td>
                            <td className="p-1 border border-grey2 border-t-0 border-l-0">{formatDateDisplay(item.createdAt)}</td>
                            <td className="p-1 border border-grey2 border-t-0 border-l-0">
                              {item.supportingDocUrl ? (
                                <a href={item.supportingDocUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">
                                  View
                                </a>
                              ) : "—"}
                            </td>
                            <td className="p-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-center">
                              {formatDateDisplay(item.createdAt)} By {item.commentedByName || "System"}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </>
            )}

            {/* ADD RESPONSE VIEW */}
            {popupView === "ADD_RESPONSE" && (
              <>
                <h2 className="text-base font-semibold mb-4 text-darkblue1">Add Message</h2>
                <div className="h-[2px] bg-darkblue1 w-[10%] -mt-4 mb-4"></div>

                <form className="w-full">
                  <div className="grid grid-cols-2 gap-4">
                    {/* Year - Read Only */}
                    <div className="mt-1">
                      <label className="block text-xs font-medium mb-1 text-black/70">Year</label>
                      <input
                        type="text"
                        className="w-full p-1.5 border border-black/30 text-xs bg-gray-100 text-gray-700 cursor-not-allowed"
                        value={responseForm.year}
                        readOnly
                        disabled
                      />
                    </div>

                    {/* Quarter - Read Only */}
                    <div className="mt-1">
                      <label className="block text-xs font-medium mb-1 text-black/70">Quarter</label>
                      <input
                        type="text"
                        className="w-full p-1.5 border border-black/30 text-xs bg-gray-100 text-gray-700 cursor-not-allowed"
                        value={responseForm.quarter}
                        readOnly
                        disabled
                      />
                    </div>

                    {/* Strategic Objective - Read Only */}
                    <div>
                      <label className="block text-xs text-black/70 font-medium mb-1">Strategic Objective</label>
                      <input
                        type="text"
                        className="w-full p-1.5 border border-black/30 text-xs bg-gray-100 text-gray-700 cursor-not-allowed"
                        value={responseForm.strategicObjective}
                        readOnly
                        disabled
                      />
                    </div>

                    {/* KPI - Read Only */}
                    <div>
                      <label className="block text-xs text-black/70 font-medium mb-1">KPI</label>
                      <input
                        type="text"
                        className="w-full p-1.5 border border-black/30 text-xs bg-gray-100 text-gray-700 cursor-not-allowed"
                        value={responseForm.kpi}
                        readOnly
                        disabled
                      />
                    </div>

                    {/* Sub KPI - Read Only */}
                    <div>
                      <label className="block text-xs text-black/70 font-medium mb-1">Sub KPI</label>
                      <input
                        type="text"
                        className="w-full p-1.5 border border-black/30 text-xs bg-gray-100 text-gray-700 cursor-not-allowed"
                        value={responseForm.subKpi}
                        readOnly
                        disabled
                      />
                    </div>

                    {/* Supporting Document - File Upload */}
                    <div>
                      <label className="block text-xs text-black/70 font-medium mb-1">Supporting Document</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          readOnly
                          value={responseForm.file ? responseForm.file.name : ""}
                          placeholder="Choose file..."
                          className="flex-1 px-2 py-1.5 border border-black/30 text-xs bg-gray-50"
                        />
                        <button
                          type="button"
                          onClick={() => document.getElementById('responseFileInput').click()}
                          className="px-3 py-1.5 bg-darkblue1 text-white text-xs hover:bg-darkblue1/80"
                        >
                          Browse
                        </button>
                      </div>
                      <input
                        type="file"
                        id="responseFileInput"
                        style={{ display: "none" }}
                        accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xlsx,.xls"
                        onChange={(e) => {
                          const file = e.target.files[0];
                          if (file) {
                            setResponseForm(prev => ({ ...prev, file: file }));
                          }
                        }}
                      />
                      <p className="text-[10px] text-gray-500 mt-1">Optional: PDF, JPG, PNG, DOC, XLSX</p>
                    </div>

                    {/* Comments - Editable */}
                    <div className="col-span-2">
                      <label className="block text-xs text-black/70 font-medium mb-1">
                        Comments <span className="text-red-600">*</span>
                      </label>
                      <textarea
                        className={`w-full p-2 border text-xs resize-none focus:outline-none focus:ring-1 focus:ring-darkblue1 ${responseErrors.comments ? "border-red-500" : "border-black/30"}`}
                        rows={3}
                        placeholder="Enter comments..."
                        value={responseForm.comments}
                        onChange={(e) => handleResponseChange("comments", e.target.value)}
                      ></textarea>
                      {responseErrors.comments && <p className="text-xs text-red-500 mt-1">{responseErrors.comments}</p>}
                    </div>
                  </div>
                </form>

                <div className="flex justify-center gap-4 mt-4">
                  <button
                    type="button"
                    className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium hover:bg-mildBlue1"
                    onClick={() => {
                      // Only clear comments and file, keep other data
                      setResponseForm(prev => ({ ...prev, comments: "", file: null }));
                      setResponseErrors({});
                      setPopupView("RESPONSE_TABLE");
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveResponse}
                    disabled={actionLoading}
                    className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 transition hover:bg-blue-700 disabled:opacity-50"
                  >
                    {actionLoading ? "Saving..." : "Save"}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Delete Modal */}
      <DeleteModal
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
        loading={deleteLoading}
      />

      {/* Close Item Confirmation Modal */}
      {closeConfirmVisible && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60]">
          <div className="bg-white p-6 shadow-lg max-w-md w-full mx-4">
            <div className="flex items-start gap-3 mb-4">
              <div className="flex-shrink-0">
                <svg className="w-8 h-8 text-orange-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-gray-800 mb-1">
                  Are you sure you want to close this action item?
                </h3>
                <p className="text-xs text-red-600">
                  <span className="font-medium">*Note:</span> Once closed, you cannot assign or add messages.
                </p>
              </div>
            </div>

            <div className="flex justify-center gap-3 mt-6">
              <button
                onClick={() => {
                  if (!isClosingItem) {
                    setCloseConfirmVisible(false);
                  }
                }}
                disabled={isClosingItem}
                className="border-2 border-red2 text-red px-4  py-1.5 text-xs font-bold  hover:bg-red2 hover:shadow-md hover:scale-105 transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                No
              </button>
              <button
                onClick={confirmCloseItem}
                disabled={isClosingItem}
                className="bg-green4 text-green5 text-xs border-2 border-transparent font-bold font-VolvoNovum px-5  py-1.5  transition duration-200 "
              >
                {isClosingItem ? (
                  <>
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                    Closing...
                  </>
                ) : (
                  "Yes"
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserViewDetails;