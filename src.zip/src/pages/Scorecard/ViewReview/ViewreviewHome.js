import React from "react";
import Header from "../../../Components/Header";
import { useState } from "react";
import SubNavbar3 from "../../../Components/SubNavbar3";
import ViewReview from "./ViewReview";

const ViewreviewHome = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="bg-Frostwhite h-screen overflow-hidden flex flex-col">
      {/* Navigation Bar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      
      {/* Main Content - Moves Right when Sidebar Opens */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex flex-col
          overflow-visible
        `}
      >
        {/* Content Container with proper spacing */}
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] px-2 lg:px-4">
          <ViewReview />
        </div>
      </div>
    </div>
  );
};

export default ViewreviewHome;