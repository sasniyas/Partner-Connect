import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, X } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import Filter from "../../../Components/Filter";
import Searchinput from "../../../Components/Searchinput";
import { ChevronDown,ChevronUp,ChevronsUpDown} from "lucide-react";
// ═══════════════════════════════════════════════════════════════
// 📡 API SERVICE IMPORT
// ═══════════════════════════════════════════════════════════════
import {
  getScorecardScoreViewsByScorecardId,
  getScorecardScoreViewDocsByScorecardId,
  getScorecardActionItemsByScoreViewId,
} from "../../../services/scorecard/scorecardScoreView.service";

// ⭐ Import scoring service for quarter scores lookup
import { getAllScorecardScoreViews } from "../../../services/scorecard/scoringScoreView.service";

const ScorecardAnnualView = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const rowData = location.state?.item;
  const scorecardId = rowData?.id;

  // Debug: Log rowData to see what fields are available
  useEffect(() => {
    console.log("📋 ScorecardAnnualView - rowData received:", rowData);
  }, [rowData]);

  // ═══════════════════════════════════════════════════════════════
  // 📊 API DATA STATE
  // ═══════════════════════════════════════════════════════════════
  const [scoreViewsData, setScoreViewsData] = useState([]);
  const [allQuarterData, setAllQuarterData] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 SEARCH & FILTER STATE
  // ═══════════════════════════════════════════════════════════════
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    kpiNo: [],
    strategicObjective: [],
  });

  // ═══════════════════════════════════════════════════════════════
  // 🎯 POPUP STATE
  // ═══════════════════════════════════════════════════════════════
  const [showCriteriaModal, setShowCriteriaModal] = useState(false);
  const [selectedCriteria, setSelectedCriteria] = useState(null);
  const [showActionItemsModal, setShowActionItemsModal] = useState(false);
  const [selectedActionItems, setSelectedActionItems] = useState([]);
  const [actionItemsLoading, setActionItemsLoading] = useState(false);
  const [selectedSubKpi, setSelectedSubKpi] = useState("");

  // ═══════════════════════════════════════════════════════════════
  // 📱 UI STATE
  // ═══════════════════════════════════════════════════════════════
  const [menuOpen, setMenuOpen] = useState(false);
  const [isMobileView, setIsMobileView] = useState(false);

  // ═══════════════════════════════════════════════════════════════
  // ♾️ INFINITE SCROLL STATE
  // ═══════════════════════════════════════════════════════════════
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [batchSize, setBatchSize] = useState(10);
  const [rowsToShow, setRowsToShow] = useState(10);

  const tableContainerRef = useRef(null);
  const observerTarget = useRef(null);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return displayedItems;

  return [...displayedItems].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [displayedItems, sortKey, sortOrder]);


  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH DATA FROM API
  // ═══════════════════════════════════════════════════════════════
  const fetchData = useCallback(async () => {
    if (!scorecardId) {
      console.warn("No scorecard ID provided");
      setIsLoading(false);
      setError("No scorecard ID provided");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log("📡 Fetching data for scorecard:", scorecardId);

      // Fetch score views, documents, and all quarter data in parallel
      const [scoreViewsResponse, docsResponse, allDataResponse] = await Promise.all([
        getScorecardScoreViewsByScorecardId(scorecardId),
        getScorecardScoreViewDocsByScorecardId(scorecardId).catch((err) => {
          console.warn("Failed to fetch documents:", err);
          return [];
        }),
        getAllScorecardScoreViews().catch((err) => {
          console.warn("Failed to fetch all quarter data:", err);
          return [];
        }),
      ]);

      console.log("✅ Score views fetched:", scoreViewsResponse.length, "records");
      console.log("✅ Documents fetched:", docsResponse.length, "records");
      console.log("✅ All quarter data fetched:", allDataResponse.length, "records");

      setScoreViewsData(scoreViewsResponse);
      setDocuments(docsResponse);
      setAllQuarterData(allDataResponse);
    } catch (err) {
      console.error("❌ Error fetching data:", err);
      setError(err.message || "Failed to load data");

      if (err.message?.includes("Session expired")) {
        navigate("/login");
      }
    } finally {
      setIsLoading(false);
    }
  }, [scorecardId, navigate]);

  // Fetch data on mount
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // ═══════════════════════════════════════════════════════════════
  // 🔧 GET QUARTER SCORES FOR A SUB KPI
  // ═══════════════════════════════════════════════════════════════
  const getQuarterScores = useCallback((item) => {
    const year = item.scorecardYear || rowData?.year;
    const dealer = item.scorecardBranch || item.dealer || rowData?.dealer;
    const subKpiId = item.subKpiId;
    const subKpiName = item.subKpi || item.subKpiName;

    const findQuarterScore = (quarter) => {
      const record = allQuarterData.find(row =>
        (row.year === year || row.scorecardYear === year) &&
        (row.branch === dealer || row.dealer === dealer || row.scorecardBranch === dealer) &&
        (row.subKpiId === subKpiId || row.subKpi === subKpiName || row.subKpiName === subKpiName) &&
        (row.quarter === quarter || row.scorecardQuarter === quarter)
      );
      return record?.finalScore || "";
    };

    return {
      q1: findQuarterScore("Q1"),
      q2: findQuarterScore("Q2"),
      q3: findQuarterScore("Q3"),
      q4: findQuarterScore("Q4"),
    };
  }, [allQuarterData, rowData]);

  // ═══════════════════════════════════════════════════════════════
  // 🔧 HELPER FUNCTIONS
  // ═══════════════════════════════════════════════════════════════
  const formatDateDisplay = (dateString) => {
    if (!dateString) return "—";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return dateString;

      const day = date.getDate();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();
      let hours = date.getHours();
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12;

      return `${day}/${month}/${year}, ${String(hours).padStart(2, '0')}:${minutes}${ampm}`;
    } catch {
      return dateString;
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🎯 DYNAMIC FILTER OPTIONS
  // ═══════════════════════════════════════════════════════════════
  const filterOptions = useMemo(() => {
    const kpiNoSet = new Set();
    const strategicObjectiveSet = new Set();

    scoreViewsData.forEach(item => {
      if (item.kpiNo) kpiNoSet.add(item.kpiNo);
      if (item.strategicObjective) strategicObjectiveSet.add(item.strategicObjective);
    });

    return {
      kpiNo: Array.from(kpiNoSet).sort(),
      strategicObjective: Array.from(strategicObjectiveSet).sort(),
    };
  }, [scoreViewsData]);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 FILTERED DATA
  // ═══════════════════════════════════════════════════════════════
  const filteredData = useMemo(() => {
    const search = (searchTerm || "").trim().toLowerCase();

    return scoreViewsData.filter((item) => {
      const matchesSearch =
        search === "" ||
        (item.kpiNo + "").toLowerCase().includes(search) ||
        (item.strategicObjective + "").toLowerCase().includes(search) ||
        (item.kpi + "").toLowerCase().includes(search) ||
        (item.subKpi + "").toLowerCase().includes(search) ||
        (item.subKpiName + "").toLowerCase().includes(search);

      const matchesKpiNo =
        filters.kpiNo.length === 0 ||
        filters.kpiNo.includes(item.kpiNo);

      const matchesStrategicObjective =
        filters.strategicObjective.length === 0 ||
        filters.strategicObjective.includes(item.strategicObjective);

      return matchesSearch && matchesKpiNo && matchesStrategicObjective;
    });
  }, [scoreViewsData, filters, searchTerm]);

  // ═══════════════════════════════════════════════════════════════
  // 📊 STATISTICS CALCULATION
  // ═══════════════════════════════════════════════════════════════
  const stats = useMemo(() => {
    const totalMaxScore = scoreViewsData.reduce(
      (sum, item) => sum + (parseFloat(item.maxScore) || 0),
      0
    );
    const totalFinalScore = scoreViewsData.reduce(
      (sum, item) => sum + (parseFloat(item.finalScore) || 0),
      0
    );
    const achievementPercent = totalMaxScore > 0 
      ? ((totalFinalScore / totalMaxScore) * 100).toFixed(0) 
      : 0;

    return { totalMaxScore, totalFinalScore, achievementPercent };
  }, [scoreViewsData]);

  // ═══════════════════════════════════════════════════════════════
  // ♾️ INFINITE SCROLL LOGIC
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const calculateRowsToShow = () => {
      setRowsToShow(10);
      setBatchSize(10);
    };

    calculateRowsToShow();
    window.addEventListener("resize", calculateRowsToShow);
    return () => window.removeEventListener("resize", calculateRowsToShow);
  }, []);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 1024);
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  useEffect(() => {
    setDisplayedItems(filteredData.slice(0, rowsToShow));
    setHasMore(filteredData.length > rowsToShow);
  }, [filteredData, rowsToShow]);

  const loadMoreItems = useCallback(() => {
    if (isLoadingMore || !hasMore) return;

    setIsLoadingMore(true);

    setTimeout(() => {
      setDisplayedItems((prevDisplayed) => {
        const currentLength = prevDisplayed.length;
        const nextBatch = filteredData.slice(
          currentLength,
          currentLength + batchSize
        );

        if (nextBatch.length > 0) {
          setHasMore(currentLength + nextBatch.length < filteredData.length);
          return [...prevDisplayed, ...nextBatch];
        } else {
          setHasMore(false);
          return prevDisplayed;
        }
      });

      setIsLoadingMore(false);
    }, 300);
  }, [filteredData, batchSize, hasMore, isLoadingMore]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore) {
          loadMoreItems();
        }
      },
      { threshold: 0.1 }
    );

    const currentTarget = observerTarget.current;
    if (currentTarget) {
      observer.observe(currentTarget);
    }

    return () => {
      if (currentTarget) {
        observer.unobserve(currentTarget);
      }
    };
  }, [loadMoreItems, hasMore, isLoadingMore]);

  // ═══════════════════════════════════════════════════════════════
  // 🎯 EVENT HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleBack = () => navigate("/scorecard/viewreview");

  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const handleViewCriteria = (item) => {
    setSelectedCriteria({
      scoring: item.scoringCriteria || "No scoring criteria available",
      definition: item.criteriaDefinition || "No criteria definition available",
    });
    setShowCriteriaModal(true);
  };

  const handleViewActionItems = async (item) => {
    setSelectedSubKpi(item.subKpi || item.subKpiName || "");
    setActionItemsLoading(true);
    setShowActionItemsModal(true);

    try {
      const actionItems = await getScorecardActionItemsByScoreViewId(item.id);
      setSelectedActionItems(actionItems || []);
    } catch (err) {
      console.error("Error fetching action items:", err);
      setSelectedActionItems([]);
    } finally {
      setActionItemsLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 📱 MOBILE CARD COMPONENT
  // ═══════════════════════════════════════════════════════════════
  const MobileResultCard = ({ item, index }) => {
    const quarterScores = getQuarterScores(item);

    return (
      <div className="bg-white border border-gray-200 rounded-lg p-3 mb-3 shadow-sm">
        <div className="flex justify-between items-start mb-2">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold text-darkblue1">
                KPI {item.kpiNo}
              </span>
            </div>
            <p className="text-xs font-medium text-black">
              {item.strategicObjective}
            </p>
            <p className="text-xs text-gray-600">{item.kpi}</p>
          </div>
        </div>

        <div className="space-y-1.5 border-t pt-2">
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Sub KPI:</span>
            <span className="text-xs text-black text-right line-clamp-2 flex-1 ml-2">
              {item.subKpi || item.subKpiName}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Max Score:</span>
            <span className="text-xs text-black font-medium">{item.maxScore}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Threshold:</span>
            <span className="text-xs text-black">{item.minScore || "—"}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Assessment Period:</span>
            <span className="text-xs text-black">{item.assessmentPeriod || item.frequency || "—"}</span>
          </div>
          <div className="grid grid-cols-4 gap-2 py-2 border-t border-b">
            <div className="text-center">
              <span className="text-[10px] text-gray-500 block">Q1</span>
              <span className="text-xs font-semibold">{quarterScores.q1 || "—"}</span>
            </div>
            <div className="text-center">
              <span className="text-[10px] text-gray-500 block">Q2</span>
              <span className="text-xs font-semibold">{quarterScores.q2 || "—"}</span>
            </div>
            <div className="text-center">
              <span className="text-[10px] text-gray-500 block">Q3</span>
              <span className="text-xs font-semibold">{quarterScores.q3 || "—"}</span>
            </div>
            <div className="text-center">
              <span className="text-[10px] text-gray-500 block">Q4</span>
              <span className="text-xs font-semibold">{quarterScores.q4 || "—"}</span>
            </div>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Final Score:</span>
            <span className="text-xs text-darkblue1 font-semibold">
              {item.finalScore || "—"}
            </span>
          </div>
        </div>

        <div className="flex gap-2 mt-3 pt-2 border-t">
          <button
            onClick={() => handleViewCriteria(item)}
            className="flex-1 text-xs bg-gray-100 hover:bg-gray-200 py-1.5 rounded transition"
          >
            View Criteria
          </button>
          <button
            onClick={() => handleViewActionItems(item)}
            className="flex-1 text-xs bg-darkblue1 text-white hover:bg-blue-700 py-1.5 rounded transition"
          >
            Action Items
          </button>
        </div>
      </div>
    );
  };

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "lg:ml-60" : ""
        } flex justify-center flex-1`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header Section */}
          <div className="flex flex-col w-full mb-3">
            <div className="flex items-center gap-2">
              <ArrowLeft
                onClick={handleBack}
                size={20}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
              />
              <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                Annual Results: {rowData?.dealer || rowData?.dealerName || "—"}
              </h2>
            </div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-[150px] sm:w-[200px] mt-1 ml-7"></div>
          </div>

          {/* Info Grid - ViewAudit Style */}
          <div className="w-full bg-white shadow-[0_4px_10px_#0000001A] p-1.5 mb-3 overflow-x-auto">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 text-center gap-2 lg:gap-0 min-w-max lg:min-w-0">
              {[
                { 
                  title: "Year / Quarter", 
                  value: `${rowData?.year || scoreViewsData[0]?.scorecardYear || "—"} / ${rowData?.quarter || rowData?.quarterFrequency || "Annual"}`, 
                },
                { 
                  title: "Frequency", 
                  value: rowData?.frequency || scoreViewsData[0]?.scorecardFrequency || "—", 
                },
                { 
                  title: "Audit Location", 
                  value: rowData?.auditLocation || scoreViewsData[0]?.scorecardAuditLocation || "—", 
                },
                { 
                  title: "Branch", 
                  value: rowData?.branch || scoreViewsData[0]?.scorecardBranch || "—", 
                },
                { 
                  title: "Auditor", 
                  value: rowData?.leadAuditor || "—", 
                },
                { 
                  title: "Created Date", 
                  value: formatDateDisplay(rowData?.createdAt || scoreViewsData[0]?.createdAt), 
                },
                {
                  title: "Status",
                  value: rowData?.reviewStatus || rowData?.status || "Completed",
                  color: (rowData?.reviewStatus || rowData?.status) === "Completed" ? "text-green-600" : 
                         (rowData?.reviewStatus || rowData?.status) === "Pending" ? "text-orange-600" :
                         (rowData?.reviewStatus || rowData?.status) === "Created" ? "text-blue-600" : "text-gray-600",
                },
              ].map((item, i) => (
                <div
                  key={i}
                  className={`relative py-2 px-2 lg:px-3 ${i < 6 ? "lg:border-r border-gray-300" : ""} flex flex-col items-center justify-center bg-white rounded lg:rounded-none`}
                >
                  <div className="text-xs font-medium text-black text-center">{item.title}</div>
                  <div className={`text-xs font-semibold mt-1 text-center ${item.color || "text-SteelBlue1"}`}>
                    {item.value || "—"}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Loading State */}
          {isLoading && (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
              <span className="ml-3 text-gray-600">Loading results...</span>
            </div>
          )}

          {/* Error State */}
          {error && !isLoading && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-red-600 font-medium">Error:</span>
                  <span className="text-red-700">{error}</span>
                </div>
                <button
                  onClick={fetchData}
                  className="bg-red-600 text-white px-3 py-1 rounded text-xs hover:bg-red-700 transition"
                >
                  Retry
                </button>
              </div>
            </div>
          )}

          {/* Main Content */}
          {!isLoading && !error && (
            <>
              {/* Filters and Stats Row - ViewAudit Style */}
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-3 w-full">
                {/* Filters */}
                <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
                  <Searchinput 
                    value={searchTerm} 
                    onChange={(e) => setSearchTerm(e.target.value)} 
                    placeholder="Search" 
                    className="w-[1/2]" 
                    iconColor="text-black" 
                    bgColor="bg-FrostWhite" 
                    borderColor="border-black" 
                    textColor="text-black" 
                    shadow="shadow-none" 
                    inputPadding="pl-7 pr-3 py-1.5" 
                    iconSize="w-3.5 h-3.5" 
                    iconLeft="left-3" 
                    inputWidth="w-full" 
                    focusRing="focus:ring-1 focus:ring-black/60" 
                    hoverInputClasses="hover:bg-white hover:border-black/60" 
                  />

                  <Filter
                    name="kpiNo"
                    value={filters.kpiNo}
                    options={filterOptions.kpiNo}
                    onChange={handleFilterChange}
                    placeholder="KPI No"
                    customWidth="w-[130px] sm:w-[140px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-gray-300"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />

                  <Filter
                    name="strategicObjective"
                    value={filters.strategicObjective}
                    options={filterOptions.strategicObjective}
                    onChange={handleFilterChange}
                    placeholder="Strategic Objective"
                    customWidth="w-[170px] sm:w-[200px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-gray-300"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />
                </div>

                {/* Stats */}
                <div className="flex flex-wrap items-center gap-4 lg:gap-6 text-xs font-medium whitespace-nowrap">
                  <span className="text-black">
                    Max Score: <span className="font-semibold">{stats.totalMaxScore}</span>
                  </span>
                  <span className="text-black">
                    Final Score: <span className="font-semibold text-blue-600">{stats.totalFinalScore}</span>
                  </span>
                  <span className="text-black">
                    Achievement %: <span className="font-semibold">{stats.achievementPercent}%</span>
                  </span>
                </div>
              </div>

              {/* Data Display - Responsive */}
              {isMobileView ? (
                /* Mobile Card View */
                <div className="space-y-3">
                  {sortedData.length > 0 ? (
                    <>
                      {sortedData.map((item, index) => (
                        <MobileResultCard
                          key={`${item.id}-${index}`}
                          item={item}
                          index={index}
                        />
                      ))}
                      {isLoadingMore && (
                        <div className="flex justify-center py-3">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        </div>
                      )}
                      <div ref={observerTarget} className="h-2" />
                    </>
                  ) : (
                    <div className="bg-white border border-gray-200 rounded-lg p-6 text-center text-gray-500">
                      No records found
                    </div>
                  )}
                </div>
              ) : (
                /* Desktop Table View - ViewAudit Style */
                <div className="flex-shrink overflow-hidden bg-white shadow-md border border-Dustyblue w-full relative z-10 lg:max-h-[calc(100vh-12rem)] max-h-[calc(100vh-14rem)]">
                  <div className="hidden lg:block h-full">
                    <div
                      ref={tableContainerRef}
                      className="overflow-y-auto overflow-x-auto max-h-full"
                      style={{
                        scrollbarWidth: "none",
                        msOverflowStyle: "none",
                      }}
                    >
                      <style jsx>{`
                        div::-webkit-scrollbar { display: none; }
                      `}</style>
                      <table className="w-full text-xs border-collapse">
                        <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                        
                          <tr>
  {/* KPI No */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[4%] cursor-pointer select-none"
    onClick={() => handleSort("kpiNo")}
  >
    <div className="flex items-center gap-1">
      KPI No
      {sortKey !== "kpiNo" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

      {sortKey === "kpiNo" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "kpiNo" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Strategic Objective */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
    onClick={() => handleSort("strategicObjective")}
  >
    <div className="flex items-center gap-1">
      Strategic Objective
      {sortKey === "strategicObjective" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "strategicObjective" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* KPI */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
    onClick={() => handleSort("kpi")}
  >
    <div className="flex items-center gap-1">
      KPI
      {sortKey === "kpi" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "kpi" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Sub KPI */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[15%] cursor-pointer select-none"
    onClick={() => handleSort("subKpi")}
  >
    <div className="flex items-center gap-1">
      Sub KPI
      {sortKey === "subKpi" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "subKpi" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Criteria */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("criteria")}
  >
    <div className="flex items-center justify-center gap-1">
      Criteria
      {sortKey === "criteria" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "criteria" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Max Score */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("maxScore")}
  >
    <div className="flex items-center justify-center gap-1">
      Max Score
      {sortKey === "maxScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "maxScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Threshold */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("threshold")}
  >
    <div className="flex items-center justify-center gap-1">
      Threshold
      {sortKey === "threshold" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "threshold" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Assessment Period */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[7%] cursor-pointer select-none"
    onClick={() => handleSort("assessmentPeriod")}
  >
    <div className="flex items-center justify-center gap-1">
      Assessment Period
      {sortKey === "assessmentPeriod" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "assessmentPeriod" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Q1 */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("q1Score")}
  >
    <div className="flex items-center justify-center gap-1">
      Q1 Score
      {sortKey === "q1Score" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "q1Score" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Q2 */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("q2Score")}
  >
    <div className="flex items-center justify-center gap-1">
      Q2 Score
      {sortKey === "q2Score" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "q2Score" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Q3 */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("q3Score")}
  >
    <div className="flex items-center justify-center gap-1">
      Q3 Score
      {sortKey === "q3Score" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "q3Score" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Q4 */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("q4Score")}
  >
    <div className="flex items-center justify-center gap-1">
      Q4 Score
      {sortKey === "q4Score" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "q4Score" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Final Score */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%] cursor-pointer select-none"
    onClick={() => handleSort("finalScore")}
  >
    <div className="flex items-center justify-center gap-1">
      Final Score
      {sortKey === "finalScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "finalScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

                            <th className="px-2 py-1.5 text-center font-medium border-t-0 border-l-0 border-r-0 w-[5%]">
                              Action Items
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                          {sortedData.length > 0 ? (
                            <>
                              {sortedData.map((item, index) => {
                                const quarterScores = getQuarterScores(item);
                                
                                return (
                                  <tr
                                    key={`${item.id}-${index}`}
                                    className={`text-xs transition hover:bg-lightBlue/30`}
                                  >
                                    <td className="px-4 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                      {item.kpiNo}
                                    </td>
                                   <td className="px-4 py-1 text-xs border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.strategicObjective?.length > 18)
          setHoveredCell(item.id + "-strategicObjective");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.strategicObjective || "—"}
    </p>

    {hoveredCell === item.id + "-strategicObjective" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {item.strategicObjective}
      </span>
    )}
  </div>
</td>
                                  {/* KPI */}
<td className="px-4 py-1 text-xs border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.kpi?.length > 18)
          setHoveredCell(item.id + "-kpi");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.kpi || "—"}
    </p>

    {hoveredCell === item.id + "-kpi" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {item.kpi}
      </span>
    )}
  </div>
</td>

{/* Sub KPI */}
<td className="px-4 py-1 text-xs border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if ((item.subKpi || item.subKpiName)?.length > 18)
          setHoveredCell(item.id + "-subKpi");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.subKpi || item.subKpiName || "—"}
    </p>

    {hoveredCell === item.id + "-subKpi" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {item.subKpi || item.subKpiName}
      </span>
    )}
  </div>
</td>
                                    <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                      <button
                                        onClick={() => handleViewCriteria(item)}
                                        className="inline-flex items-center justify-center w-full hover:bg-gray-200 rounded transition p-1"
                                        title="View Criteria"
                                      >
                                        <svg className="w-4 h-4 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
                                          <path d="M9 2a2 2 0 00-2 2v8a2 2 0 002 2h6a2 2 0 002-2V6.414A2 2 0 0016.414 5L14 2.586A2 2 0 0012.586 2H9z" />
                                          <path d="M3 8a2 2 0 012-2v10h8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z" />
                                        </svg>
                                      </button>
                                    </td>
                                    <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0 font-medium">
                                      {item.maxScore}
                                    </td>
                                    <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                      {item.minScore || "—"}
                                    </td>
                                    <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                      {item.assessmentPeriod || item.frequency || "—"}
                                    </td>
                                    <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0 font-medium">
                                      {quarterScores.q1 || "—"}
                                    </td>
                                    <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0 font-medium">
                                      {quarterScores.q2 || "—"}
                                    </td>
                                    <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0 font-medium">
                                      {quarterScores.q3 || "—"}
                                    </td>
                                    <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0 font-medium">
                                      {quarterScores.q4 || "—"}
                                    </td>
                                    <td className="px-4 py-1 text-center border border-grey2 border-t-0 border-l-0 font-semibold text-darkblue1">
                                      {item.finalScore || "—"}
                                    </td>
                                    <td className="py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0">
                                      <button
                                        onClick={() => handleViewActionItems(item)}
                                        className="w-6 h-6 border border-grey flex items-center justify-center mx-auto hover:bg-lightBlue/50"
                                      >
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"  className="w-3 h-2">
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="#212121"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
</svg>
                                      </button>
                                    </td>
                                  </tr>
                                );
                              })}

                              {isLoadingMore && (
                                <tr>
                                  <td
                                    colSpan={14}
                                    className="py-3 text-center text-gray-500"
                                  >
                                    <div className="flex items-center justify-center gap-2">
                                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                                      Loading more...
                                    </div>
                                  </td>
                                </tr>
                              )}

                              <tr ref={observerTarget}>
                                <td colSpan={14} className="h-0 p-0"></td>
                              </tr>
                            </>
                          ) : (
                            <tr className="hover:bg-gray-50">
                              <td
                                colSpan={14}
                                className="px-2 py-4  text-center text-gray-500 italic"
                              >
                                No records found
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Criteria Display Modal */}
      {showCriteriaModal && selectedCriteria && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-3xl w-full shadow-2xl">
            <div className="bg-Dustyblue text-white px-4 py-3 rounded-t-lg flex items-center justify-between">
              <h3 className="text-sm font-semibold">Criteria Display</h3>
              <button
                onClick={() => setShowCriteriaModal(false)}
                className="bg-red-600 hover:bg-red-700 text-white rounded-full p-1 transition"
              >
                <X size={16} />
              </button>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-semibold text-black mb-3">
                    Scoring Criteria:
                  </h4>
                  <div
                    className="bg-gray-100 p-4 rounded text-xs text-black"
                    dangerouslySetInnerHTML={{ __html: selectedCriteria.scoring }}
                  />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-black mb-3">
                    Criteria Definition:
                  </h4>
                  <div
                    className="bg-gray-100 p-4 rounded text-xs text-black"
                    dangerouslySetInnerHTML={{
                      __html: selectedCriteria.definition,
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Action Items Modal */}
      {showActionItemsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full shadow-2xl">
            <div className="bg-Dustyblue text-white px-4 py-3 rounded-t-lg flex items-center justify-between">
              <h3 className="text-sm font-semibold">
                Action Items - {selectedSubKpi}
              </h3>
              <button
                onClick={() => {
                  setShowActionItemsModal(false);
                  setSelectedActionItems([]);
                }}
                className="bg-red-600 hover:bg-red-700 text-white rounded-full p-1 transition"
              >
                <X size={16} />
              </button>
            </div>

            <div className="p-4">
              {actionItemsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-darkblue1"></div>
                  <span className="ml-2 text-gray-600 text-sm">Loading...</span>
                </div>
              ) : selectedActionItems.length > 0 ? (
                <div className="max-h-[400px] overflow-y-auto">
                  <table className="w-full text-xs">
                    <thead className="bg-gray-100 sticky top-0">
                      <tr>
                        <th className="px-2 py-2 text-left font-medium">Created By</th>
                        <th className="px-2 py-2 text-left font-medium">Status</th>
                        <th className="px-2 py-2 text-left font-medium">Assigned To</th>
                        <th className="px-2 py-2 text-left font-medium">Created Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedActionItems.map((item, index) => (
                        <tr
                          key={item.id || index}
                          className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}
                        >
                          <td className="px-2 py-2 border-b">
                            {item.createdByName || item.createdBy || "—"}
                          </td>
                          <td className="px-2 py-2 border-b">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-medium ${
                                item.status === "Completed" || item.status === "Closed"
                                  ? "bg-green-100 text-green-700"
                                  : item.status === "In Progress"
                                  ? "bg-blue-100 text-blue-700"
                                  : "bg-gray-100 text-gray-700"
                              }`}
                            >
                              {item.status || "Created"}
                            </span>
                          </td>
                          <td className="px-2 py-2 border-b">
                            {item.assignedToName || item.assignedTo || "—"}
                          </td>
                          <td className="px-2 py-2 border-b">
                            {item.createdAt ? formatDateDisplay(item.createdAt) : item.createdDate || "—"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <svg
                    className="w-12 h-12 mx-auto mb-2 text-gray-300"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                    />
                  </svg>
                  <p className="text-sm">No action items to display</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ScorecardAnnualView;