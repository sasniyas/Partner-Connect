import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, X } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import Filter from "../../../Components/Filter";
import Searchinput from "../../../Components/Searchinput";

// ═══════════════════════════════════════════════════════════════
// 📡 API SERVICE IMPORT
// ═══════════════════════════════════════════════════════════════
import {
  getScorecardScoreViewsByScorecardId,
  getScorecardScoreViewDocsByScorecardId,
  getAllScorecardActionItems,
} from "../../../services/scorecard/scorecardScoreView.service";

const UserView = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const rowData = location.state?.item;
  const scorecardId = rowData?.id;

  // ═══════════════════════════════════════════════════════════════
  // 📊 API DATA STATE
  // ═══════════════════════════════════════════════════════════════
  const [scoreViewsData, setScoreViewsData] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [actionItems, setActionItems] = useState([]);
  const [groupedData, setGroupedData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 SEARCH & FILTER STATE
  // ═══════════════════════════════════════════════════════════════
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    strategicObjective: [],
  });

  // ═══════════════════════════════════════════════════════════════
  // 📱 UI STATE
  // ═══════════════════════════════════════════════════════════════
  const [menuOpen, setMenuOpen] = useState(false);
  const [showCriteriaModal, setShowCriteriaModal] = useState(false);
  const [selectedCriteria, setSelectedCriteria] = useState(null);
  const [isMobileView, setIsMobileView] = useState(false);

  // ═══════════════════════════════════════════════════════════════
  // ♾️ INFINITE SCROLL STATE
  // ═══════════════════════════════════════════════════════════════
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [batchSize, setBatchSize] = useState(10);
  const [rowsToShow, setRowsToShow] = useState(10);

  const tableContainerRef = useRef(null);
  const observerTarget = useRef(null);

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH DATA FROM API
  // ═══════════════════════════════════════════════════════════════
  const fetchData = useCallback(async () => {
    if (!scorecardId) {
      console.warn("No scorecard ID provided");
      setIsLoading(false);
      setError("No scorecard ID provided");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log("📡 Fetching data for scorecard:", scorecardId);

      // Fetch score views, documents, and action items in parallel
      const [scoreViewsResponse, docsResponse, actionItemsResponse] = await Promise.all([
        getScorecardScoreViewsByScorecardId(scorecardId),
        getScorecardScoreViewDocsByScorecardId(scorecardId).catch((err) => {
          console.warn("Failed to fetch documents:", err);
          return [];
        }),
        getAllScorecardActionItems(scorecardId).catch((err) => {
          console.warn("Failed to fetch action items:", err);
          return [];
        }),
      ]);

      console.log("✅ Score views fetched:", scoreViewsResponse.length, "records");
      console.log("✅ Documents fetched:", docsResponse.length, "records");
      console.log("✅ Action items fetched:", actionItemsResponse.length, "records");

      setScoreViewsData(scoreViewsResponse);
      setDocuments(docsResponse);
      setActionItems(actionItemsResponse);

      // Group data by Strategic Objective with action item counts
      const grouped = groupByStrategicObjective(scoreViewsResponse, docsResponse, actionItemsResponse);
      setGroupedData(grouped);
    } catch (err) {
      console.error("❌ Error fetching data:", err);
      setError(err.message || "Failed to load data");

      if (err.message?.includes("Session expired")) {
        navigate("/login");
      }
    } finally {
      setIsLoading(false);
    }
  }, [scorecardId, navigate]);

  // ═══════════════════════════════════════════════════════════════
  // 🔧 GROUP DATA BY STRATEGIC OBJECTIVE
  // ═══════════════════════════════════════════════════════════════
  const groupByStrategicObjective = (scoreViews, docs, actionItemsList) => {
    const grouped = {};

    // First, create groups from score views
    scoreViews.forEach((item) => {
      const objective = item.strategicObjective || "Other";

      if (!grouped[objective]) {
        grouped[objective] = {
          id: item.subKpiObjectiveId || objective,
          strategicObjective: objective,
          maxScore: 0,
          finalScore: 0,
          items: [],
          scoreViewIds: [], // Track score view IDs for this objective
          actionCounts: {
            created: 0,      // Status = "Created"
            inProgress: 0,   // Status = "In Progress"
            assigned: 0,     // assigned_to is NOT null (has assignee)
            closed: 0,       // Status = "Closed" or "Completed"
          },
          docCounts: {
            needToUpload: 0,
            uploaded: 0,
          },
        };
      }

      grouped[objective].items.push(item);
      grouped[objective].scoreViewIds.push(item.id);
      grouped[objective].maxScore += parseFloat(item.maxScore) || 0;
      grouped[objective].finalScore += parseFloat(item.finalScore) || 0;

      // Count documents - if item has no supporting doc, it needs upload
      if (!item.supportingDoc) {
        grouped[objective].docCounts.needToUpload += 1;
      }
    });

    // Now count action items by strategic objective
    actionItemsList.forEach((actionItem) => {
      const objective = actionItem.strategicObjective || "Other";
      const status = actionItem.status || "Created";
      
      // Check if action item has someone assigned
      // assignedTo or assignedToId comes from the API transformation
      const hasAssignee = actionItem.assignedTo || actionItem.assignedToId || actionItem.assigned_to;

      // Find the matching group
      if (grouped[objective]) {
        // Count by status
        switch (status) {
          case "Created":
            grouped[objective].actionCounts.created += 1;
            break;
          case "In Progress":
            grouped[objective].actionCounts.inProgress += 1;
            break;
          case "Closed":
          case "Completed":
            grouped[objective].actionCounts.closed += 1;
            break;
          default:
            grouped[objective].actionCounts.created += 1;
        }

        // Count assigned (if has assignee, regardless of status)
        if (hasAssignee) {
          grouped[objective].actionCounts.assigned += 1;
        }
      }
    });

    // Count uploaded documents from docs array
    // Group docs by strategic objective if possible, or count total
    docs.forEach((doc) => {
      // Try to find which objective this doc belongs to based on scoreViewId
      const docScoreViewId = doc.scoreViewId;
      
      // Find which objective this score view belongs to
      Object.keys(grouped).forEach((key) => {
        if (grouped[key].scoreViewIds.includes(docScoreViewId)) {
          grouped[key].docCounts.uploaded += 1;
        }
      });
    });

    // If docs don't have scoreViewId association, distribute evenly or show total
    const totalUploaded = docs.length;
    const hasDistributedDocs = Object.values(grouped).some(g => g.docCounts.uploaded > 0);
    
    if (!hasDistributedDocs && totalUploaded > 0) {
      // Show total uploaded in each objective if we can't distribute
      Object.keys(grouped).forEach((key) => {
        grouped[key].docCounts.uploaded = totalUploaded;
      });
    }

    // Convert to array
    return Object.values(grouped);
  };

  // Fetch data on mount
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // ═══════════════════════════════════════════════════════════════
  // 🎯 DYNAMIC FILTER OPTIONS
  // ═══════════════════════════════════════════════════════════════
  const strategicObjectiveOptions = useMemo(() => {
    const objectives = new Set();
    groupedData.forEach((item) => {
      if (item.strategicObjective) objectives.add(item.strategicObjective);
    });
    return Array.from(objectives).sort();
  }, [groupedData]);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 FILTERED DATA
  // ═══════════════════════════════════════════════════════════════
  const filteredData = useMemo(() => {
    const search = (searchTerm || "").trim().toLowerCase();

    return groupedData.filter((item) => {
      const matchesSearch =
        search === "" ||
        (item.strategicObjective || "").toLowerCase().includes(search);

      const matchesStrategicObjective =
        filters.strategicObjective.length === 0 ||
        filters.strategicObjective.includes(item.strategicObjective);

      return matchesSearch && matchesStrategicObjective;
    });
  }, [groupedData, filters, searchTerm]);

  // ═══════════════════════════════════════════════════════════════
  // 📊 STATISTICS CALCULATION
  // ═══════════════════════════════════════════════════════════════
  const stats = useMemo(() => {
    const totalMaxScore = scoreViewsData.reduce(
      (sum, item) => sum + (parseFloat(item.maxScore) || 0),
      0
    );
    const totalFinalScore = scoreViewsData.reduce(
      (sum, item) => sum + (parseFloat(item.finalScore) || 0),
      0
    );

    // Calculate total action item counts
    const totalActionCounts = {
      created: 0,
      inProgress: 0,
      assigned: 0,
      closed: 0,
    };

    actionItems.forEach((item) => {
      const status = item.status || "Created";
      const hasAssignee = item.assignedTo || item.assignedToId || item.assigned_to;

      switch (status) {
        case "Created":
          totalActionCounts.created += 1;
          break;
        case "In Progress":
          totalActionCounts.inProgress += 1;
          break;
        case "Closed":
        case "Completed":
          totalActionCounts.closed += 1;
          break;
        default:
          totalActionCounts.created += 1;
      }

      if (hasAssignee) {
        totalActionCounts.assigned += 1;
      }
    });

    return { totalMaxScore, totalFinalScore, totalActionCounts };
  }, [scoreViewsData, actionItems]);

  // ═══════════════════════════════════════════════════════════════
  // ♾️ INFINITE SCROLL LOGIC
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const calculateRowsToShow = () => {
      const targetRows = 10;
      setRowsToShow(targetRows);
      setBatchSize(targetRows);
    };

    calculateRowsToShow();
    window.addEventListener("resize", calculateRowsToShow);
    return () => window.removeEventListener("resize", calculateRowsToShow);
  }, []);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 1024);
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  useEffect(() => {
    setDisplayedItems(filteredData.slice(0, rowsToShow));
    setHasMore(filteredData.length > rowsToShow);
  }, [filteredData, rowsToShow]);

  const loadMoreItems = useCallback(() => {
    if (isLoadingMore || !hasMore) return;

    setIsLoadingMore(true);

    setTimeout(() => {
      setDisplayedItems((prevDisplayed) => {
        const currentLength = prevDisplayed.length;
        const nextBatch = filteredData.slice(
          currentLength,
          currentLength + batchSize
        );

        if (nextBatch.length > 0) {
          setHasMore(currentLength + nextBatch.length < filteredData.length);
          return [...prevDisplayed, ...nextBatch];
        } else {
          setHasMore(false);
          return prevDisplayed;
        }
      });

      setIsLoadingMore(false);
    }, 300);
  }, [filteredData, batchSize, hasMore, isLoadingMore]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore) {
          loadMoreItems();
        }
      },
      { threshold: 0.1 }
    );

    const currentTarget = observerTarget.current;
    if (currentTarget) {
      observer.observe(currentTarget);
    }

    return () => {
      if (currentTarget) {
        observer.unobserve(currentTarget);
      }
    };
  }, [loadMoreItems, hasMore, isLoadingMore]);

  // ═══════════════════════════════════════════════════════════════
  // 🎯 EVENT HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleBack = () => navigate("/scorecard/viewreview");

  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const handleDownloadDocument = (fileName) => {
    if (fileName) {
      window.open(fileName, "_blank");
    } else {
      alert("No document available");
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 📱 MOBILE CARD COMPONENT
  // ═══════════════════════════════════════════════════════════════
  const MobileAuditCard = ({ item, index }) => (
    <div className="bg-white border border-gray-200 p-3 mb-3 shadow-sm">
      <div className="flex justify-between items-start mb-2">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span
              className={`text-xs font-medium px-2 py-0.5 ${
                item.finalScore > 0
                  ? "bg-green-100 text-green-700"
                  : "bg-red-100 text-red-700"
              }`}
            >
              {item.finalScore > 0 ? "Scored" : "Not Scored"}
            </span>
          </div>
          <p className="text-xs font-medium text-black">
            {item.strategicObjective}
          </p>
        </div>
      </div>

      <div className="space-y-1.5 border-t pt-2">
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Max Score:</span>
          <span className="text-xs text-black font-medium">{item.maxScore}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Final Score:</span>
          <span className="text-xs text-darkblue1 font-semibold">
            {item.finalScore}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Action Items:</span>
          <span className="text-xs text-black">
            Created: {item.actionCounts.created}, In Progress:{" "}
            {item.actionCounts.inProgress}, Assigned: {item.actionCounts.assigned}, Closed: {item.actionCounts.closed}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Documents:</span>
          <span className="text-xs text-black">
            Need: {item.docCounts.needToUpload}, Uploaded:{" "}
            {item.docCounts.uploaded}
          </span>
        </div>
      </div>

      <div className="flex gap-2 mt-3 pt-2 border-t">
        <button
          onClick={() =>
            navigate("/scorecard/userview/view", {
              state: { rowData: item, scorecardId, scoreViewsData: item.items, parentRowData: rowData },
            })
          }
          className="flex-1 text-xs bg-darkblue1 text-white hover:bg-blue-700 py-1.5 rounded transition"
        >
          View Details
        </button>
      </div>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "lg:ml-60" : ""
        } flex justify-center flex-1`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header Section */}
          <div className="flex flex-col w-full mb-3">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-2 w-full">
              {/* Back + Heading */}
              <div className="flex items-center gap-2 flex-shrink-0">
                <ArrowLeft
                  onClick={handleBack}
                  size={20}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
                />
                <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                  Scorecard / View Reviews / User View
                </h2>
              </div>

              {/* Info Grid */}
              <div className="flex-1 bg-white shadow-[0_4px_10px_#0000001A] p-2 mx-2">
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-5 text-center gap-1 lg:gap-2">
                  {[
                    {
                      title: "Dealer Name",
                      value: rowData?.dealer || "—",
                    },
                    {
                      title: "Region",
                      value: rowData?.marketArea || "—",
                    },
                    {
                      title: "Year / Quarter",
                      value: `${rowData?.year || "—"} / ${
                        rowData?.quarter || "—"
                      }`,
                    },
                    {
                      title: "Assigned Auditor",
                      value: rowData?.leadAuditor || "—",
                    },
                    {
                      title: "Lead Auditor",
                      value: rowData?.leadAuditor || "—",
                    },
                  ].map((item, i) => (
                    <div
                      key={i}
                      className={`relative py-1 px-2 lg:px-3 ${
                        i < 4 ? "lg:border-r border-gray-300" : ""
                      } flex flex-col items-center justify-center`}
                    >
                      <div className="text-[10px] sm:text-xs font-medium text-black">
                        {item.title}
                      </div>
                      <div className="text-[10px] sm:text-xs font-semibold mt-1 text-SteelBlue1 truncate max-w-full">
                        {item.value || "—"}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Underline bar */}
            <div className="hidden lg:block h-1 bg-darkblue1 w-[6%] -mt-5 ml-7 mb-4"></div>
          </div>

          {/* Loading State */}
          {isLoading && (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
              <span className="ml-3 text-gray-600">Loading data...</span>
            </div>
          )}

          {/* Error State */}
          {error && !isLoading && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-red-600 font-medium">Error:</span>
                  <span className="text-red-700">{error}</span>
                </div>
                <button
                  onClick={fetchData}
                  className="bg-red-600 text-white px-3 py-1 rounded text-xs hover:bg-red-700 transition"
                >
                  Retry
                </button>
              </div>
            </div>
          )}

          {/* Main Content */}
          {!isLoading && !error && (
            <>
              {/* Filters Row */}
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-2 w-full">
                {/* Left side - Search and Filters */}
                <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
                  <Searchinput
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search"
                    className="w-[1/2]"
                    iconColor="text-black"
                    bgColor="bg-FrostWhite"
                    borderColor="border-black"
                    textColor="text-black"
                    shadow="shadow-none"
                    inputPadding="pl-7 pr-3 py-1.5"
                    iconSize="w-3.5 h-3.5"
                    iconLeft="left-3"
                    inputWidth="w-full"
                    focusRing="focus:ring-1 focus:ring-black/60"
                    hoverInputClasses="hover:bg-white hover:border-black/60"
                  />

                  <Filter
                    name="strategicObjective"
                    value={filters.strategicObjective}
                    options={strategicObjectiveOptions}
                    onChange={handleFilterChange}
                    placeholder="Strategic Objective"
                    customWidth="w-[170px] sm:w-[200px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-gray-300"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />
                </div>

                {/* Right side - Score Summary */}
                <div className="flex flex-shrink-0 items-center gap-4 text-xs font-medium whitespace-nowrap">
                  <span className="text-black">
                    Max Score:{" "}
                    <span className="font-semibold">{stats.totalMaxScore}</span>
                  </span>
                  <span className="text-black">
                    Final Score:{" "}
                    <span className="font-semibold text-blue-600">
                      {stats.totalFinalScore}
                    </span>
                  </span>
                </div>
              </div>

              {/* Data Display - Responsive */}
              {isMobileView ? (
                /* Mobile Card View */
                <div className="space-y-3">
                  {displayedItems.length > 0 ? (
                    <>
                      {displayedItems.map((item, index) => (
                        <MobileAuditCard
                          key={`${item.id}-${index}`}
                          item={item}
                          index={index}
                        />
                      ))}
                      {isLoadingMore && (
                        <div className="flex justify-center py-3">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        </div>
                      )}
                      <div ref={observerTarget} className="h-2" />
                    </>
                  ) : (
                    <div className="bg-white border border-gray-200 p-6 text-center text-gray-500">
                      No records found
                    </div>
                  )}
                </div>
              ) : (
                /* Desktop Table View */
                <div className="flex-shrink overflow-hidden bg-white shadow-md border border-Dustyblue w-full relative z-10 max-h-[calc(100vh-14rem)] lg:max-h-[calc(100vh-12rem)]">
                  <div className="hidden lg:block h-full">
                    <div
                      ref={tableContainerRef}
                      className="overflow-y-auto overflow-x-auto max-h-full"
                      style={{
                        scrollbarWidth: "none",
                        msOverflowStyle: "none",
                      }}
                    >
                      <table className="w-full text-xs border-collapse">
                        <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                          <tr>
                            <th className="px-2 py-1.5 text-left font-medium border border-white/20 border-t-0 border-l-0 w-[20%]">
                              Strategic Objective
                            </th>
                            <th className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[8%]">
                              Max Score
                            </th>
                            <th className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[8%]">
                              Final Score
                            </th>
                            <th className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[30%]">
                              Action Item Counts
                            </th>
                            <th className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[25%]">
                              Support Document Uploads Counts
                            </th>
                            <th className="px-2 py-1.5 text-center font-medium border-t-0 border-l-0 border-r-0 w-[6%]">
                              Action
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                          {displayedItems.length > 0 ? (
                            <>
                              {displayedItems.map((item, index) => (
                                <tr
                                  key={`${item.id}-${index}`}
                                  className={`text-xs transition ${
                                    index % 2 === 0 ? "bg-white" : "bg-gray-50"
                                  } hover:bg-lightBlue/30`}
                                >
                                  <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                    {item.strategicObjective}
                                  </td>
                                  <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0 font-medium">
                                    {item.maxScore}
                                  </td>
                                  <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0 font-semibold text-blue-600">
                                    {item.finalScore}
                                  </td>
                                  <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0">
                                    <div className="flex gap-4 items-center justify-center">
                                      <span>
                                        Created:{" "}
                                        <span className="font-semibold">
                                          {item.actionCounts.created}
                                        </span>
                                      </span>
                                      <span>
                                        In Progress:{" "}
                                        <span className="font-semibold">
                                          {item.actionCounts.inProgress}
                                        </span>
                                      </span>
                                      <span>
                                        Assigned:{" "}
                                        <span className="font-semibold">
                                          {item.actionCounts.assigned}
                                        </span>
                                      </span>
                                      <span>
                                        Closed:{" "}
                                        <span className="font-semibold">
                                          {item.actionCounts.closed}
                                        </span>
                                      </span>
                                    </div>
                                  </td>
                                  <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0">
                                    <div className="flex gap-4 items-center justify-center">
                                      <span>
                                        Need to Upload:{" "}
                                        <span className="font-semibold">
                                          {item.docCounts.needToUpload}
                                        </span>
                                      </span>
                                      <span>
                                        Uploaded:{" "}
                                        <span className="font-semibold">
                                          {item.docCounts.uploaded}
                                        </span>
                                      </span>
                                    </div>
                                  </td>
                                  <td className="py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0">
                                    <button
                                      onClick={() =>
                                        navigate("/scorecard/userview/view", {
                                          state: {
                                            rowData: item,
                                            scorecardId,
                                            scoreViewsData: item.items,
                                            parentRowData: rowData,
                                          },
                                        })
                                      }
                                      className="w-6 h-6 border border-grey hover:bg-lightBlue/50 text-center flex items-center justify-center mx-auto transition"
                                    >
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"  className="w-4 h-3">
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="#212121"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
</svg>
                                    </button>
                                  </td>
                                </tr>
                              ))}

                              {isLoadingMore && (
                                <tr>
                                  <td
                                    colSpan={6}
                                    className="py-3 text-center text-gray-500"
                                  >
                                    <div className="flex items-center justify-center gap-2">
                                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                                      Loading more...
                                    </div>
                                  </td>
                                </tr>
                              )}

                              <tr ref={observerTarget}>
                                <td colSpan={6} className="h-0 p-0"></td>
                              </tr>
                            </>
                          ) : (
                            <tr className="hover:bg-gray-50">
                              <td
                                colSpan={6}
                                className="px-2 py-4 border border-grey2 text-center text-gray-500 italic"
                              >
                                No records found
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Criteria Display Modal */}
      {showCriteriaModal && selectedCriteria && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white max-w-3xl w-full shadow-2xl">
            <div className="bg-Dustyblue text-white px-4 py-3 flex items-center justify-between">
              <h3 className="text-sm font-semibold">Criteria Display</h3>
              <button
                onClick={() => setShowCriteriaModal(false)}
                className="bg-red-600 hover:bg-red-700 text-white rounded-full p-1 transition"
              >
                <X size={16} />
              </button>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-semibold text-black mb-3">
                    Scoring Criteria:
                  </h4>
                  <div className="bg-gray-100 p-4 text-xs text-black whitespace-pre-line">
                    {selectedCriteria.scoring}
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-black mb-3">
                    Criteria Definition:
                  </h4>
                  <div className="bg-gray-100 p-4 text-xs text-black">
                    {selectedCriteria.definition}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserView;