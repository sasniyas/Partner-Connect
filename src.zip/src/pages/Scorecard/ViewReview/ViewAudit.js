import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, X, ChevronDown, ChevronUp,ChevronsUpDown } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import Filter from "../../../Components/Filter";
import DeleteModal from "../../../Components/DeleteModal";
import StyledSelectField from "../../../Components/StyledSelectField";
import Searchinput from "../../../Components/Searchinput";
import { FaRegCalendar } from "react-icons/fa";

// ═══════════════════════════════════════════════════════════════
// 📡 API SERVICE IMPORT
// ═══════════════════════════════════════════════════════════════
import {
  getScorecardScoreViewsByScorecardId,
  getScorecardScoreViewDocsByScorecardId,
  getScorecardActionItemsByScoreViewId,
  getScorecardActionLogsByActionItemId,
  deleteScorecardActionItem,
  deleteScorecardActionLog,
} from "../../../services/scorecard/scorecardScoreView.service";

const ViewAudit = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const rowData = location.state?.item;

  // Debug: Log rowData to see what fields are available
  useEffect(() => {
    console.log("📋 ViewAudit - rowData received:", rowData);
  }, [rowData]);

  // ═══════════════════════════════════════════════════════════════
  // 📊 API DATA STATE
  // ═══════════════════════════════════════════════════════════════
  const [scoreViewsData, setScoreViewsData] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 SEARCH & FILTER STATE
  // ═══════════════════════════════════════════════════════════════
  const [ressearchQuery, setResSearchQuery] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  const [filters, setFilters] = useState({
    kpiNo: [],
    strategicObjective: [],
    scored: [],
  });

  // ═══════════════════════════════════════════════════════════════
  // 🎯 POPUP STATE
  // ═══════════════════════════════════════════════════════════════
  const [showResponsePopup, setShowResponsePopup] = useState(false);
  const [showActionPopup, setShowActionPopup] = useState(false);
  const [showCriteriaModal, setShowCriteriaModal] = useState(false);
  const [selectedCriteria, setSelectedCriteria] = useState(null);
  const [selectedScoreView, setSelectedScoreView] = useState(null);

  // ═══════════════════════════════════════════════════════════════
  // 📱 UI STATE
  // ═══════════════════════════════════════════════════════════════
  const [menuOpen, setMenuOpen] = useState(false);
  const [isMobileView, setIsMobileView] = useState(false);
  const [expandedRow, setExpandedRow] = useState(null);

  // ═══════════════════════════════════════════════════════════════
  // ♾️ INFINITE SCROLL STATE
  // ═══════════════════════════════════════════════════════════════
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [batchSize, setBatchSize] = useState(10);
  const [rowsToShow, setRowsToShow] = useState(10);

  const tableContainerRef = useRef(null);
  const observerTarget = useRef(null);

  // ═══════════════════════════════════════════════════════════════
  // 🎬 ACTION ITEM STATE
  // ═══════════════════════════════════════════════════════════════
  const [popupView, setPopupView] = useState("ACTION_TABLE");
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteRowId, setDeleteRowId] = useState(null);
  const [deleteType, setDeleteType] = useState(null); // "action" or "comment"
  const [loading, setLoading] = useState(false);
  const [dropdownId, setDropdownId] = useState(null);
  const wrapperRefs = useRef({});
  const popupRef = useRef(null);

  // Action Items Data (from API)
  const [actionItemsData, setActionItemsData] = useState([]);
  const [actionItemsLoading, setActionItemsLoading] = useState(false);
  const [selectedActionItem, setSelectedActionItem] = useState(null);

  // Response/Comments Data (from API)
  const [responseData, setResponseData] = useState([]);
  const [responseLoading, setResponseLoading] = useState(false);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return displayedItems;

  return [...displayedItems].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [displayedItems, sortKey, sortOrder]);


  // Form states
  const [form, setForm] = useState({
    year: "",
    quarter: "",
    strategicObjective: "Customer Excellence",
    kpi: "Service Response Time",
    subKpi: "MTTR (Mean Time to Repair)",
    comments: "",
  });

  const [dropdowns, setDropdowns] = useState({
    year: false,
    quarter: false,
    assignTo: false,
  });

  const refs = {
    year: useRef(null),
    quarter: useRef(null),
  };

  const [errors, setErrors] = useState({
    year: "",
    quarter: "",
  });

  const [responseForm, setResponseForm] = useState({
    year: "",
    quarter: "",
    strategicObjective: "Customer Excellence",
    kpi: "Service Response Time",
    subKpi: "MTTR (Mean Time to Repair)",
    comments: "",
  });

  const [responseDropdowns, setResponseDropdowns] = useState({
    quarter: false,
  });

  const responseRefs = {
    quarter: useRef(null),
  };

  const [responseErrors, setResponseErrors] = useState({
    year: "",
    quarter: "",
    strategicObjective: "",
    kpi: "",
    subKpi: "",
    comments: "",
  });

  const assignToOptions = ["External User", "Internal User"];
  const [selectedRowId, setSelectedRowId] = useState(null);
  const [assignedData, setAssignedData] = useState({});
  const [assignmentHistory, setAssignmentHistory] = useState([]);
  const [isAssigned, setIsAssigned] = useState(false);
  const [assigerrors, setAssignErrors] = useState({
    assignTo: "",
    dealerUser: "",
    email: "",
    endDate: "",
  });

  const [assignform, setAssignForm] = useState({
    assignTo: "",
    email: "",
    dealerUser: "",
    endDate: ""
  });

  const [assigndropdowns, setAssignDropdowns] = useState({
    assignTo: false,
    dealerUser: false
  });

  const assignrefs = {
    assignTo: useRef(null),
    dealerUser: useRef(null)
  };

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH SCORE VIEWS DATA
  // ═══════════════════════════════════════════════════════════════
  const fetchScoreViews = useCallback(async () => {
    // Get scorecard ID from route state
    const scorecardId = rowData?.id || rowData?.scorecardId;
    
    if (!scorecardId) {
      console.warn("No scorecard ID provided, using dummy data");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log("📡 Fetching score views for scorecard:", scorecardId);
      
      // Fetch score views and documents in parallel
      const [scoreViewsResponse, docsResponse] = await Promise.all([
        getScorecardScoreViewsByScorecardId(scorecardId),
        getScorecardScoreViewDocsByScorecardId(scorecardId).catch(err => {
          console.warn("Failed to fetch documents:", err);
          return [];
        })
      ]);
      
      console.log("✅ Score views fetched:", scoreViewsResponse.length, "records");
      console.log("✅ Documents fetched:", docsResponse.length, "records");
      
      setScoreViewsData(scoreViewsResponse);
      setDocuments(docsResponse);
    } catch (err) {
      console.error("❌ Error fetching score views:", err);
      setError(err.message || "Failed to load score views");
      
      // Check for session expiry
      if (err.message?.includes("Session expired")) {
        navigate("/login");
      }
    } finally {
      setIsLoading(false);
    }
  }, [rowData, navigate]);

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH ACTION ITEMS FOR SCORE VIEW
  // ═══════════════════════════════════════════════════════════════
  const fetchActionItems = useCallback(async (scoreViewId) => {
    if (!scoreViewId) return;

    setActionItemsLoading(true);
    try {
      console.log("📡 Fetching action items for score view:", scoreViewId);
      const response = await getScorecardActionItemsByScoreViewId(scoreViewId);
      console.log("✅ Action items fetched:", response.length, "records");
      setActionItemsData(response);
    } catch (err) {
      console.error("❌ Error fetching action items:", err);
      setActionItemsData([]);
    } finally {
      setActionItemsLoading(false);
    }
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH RESPONSE/COMMENTS FOR ACTION ITEM
  // ═══════════════════════════════════════════════════════════════
  const fetchResponseData = useCallback(async (actionItemId) => {
    if (!actionItemId) return;

    setResponseLoading(true);
    try {
      console.log("📡 Fetching comments for action item:", actionItemId);
      const response = await getScorecardActionLogsByActionItemId(actionItemId);
      console.log("✅ Comments fetched:", response.length, "records");
      
      // Transform API response to match table format
      const transformedData = response.map(log => ({
        id: log.id,
        systemUser: log.commentedBy ? "User" : "System",
        commentsby: log.commentedByName || "System",
        Comments: log.comments || "-",
        createdDate: log.createdAt ? new Date(log.createdAt).toLocaleDateString() : "-",
        supportingDocument: log.supportingDocUrl || "",
        status: log.status || "-",
        details: `${log.createdAt ? new Date(log.createdAt).toLocaleString() : ""} By ${log.commentedByName || "System"}`,
      }));
      
      setResponseData(transformedData);
    } catch (err) {
      console.error("❌ Error fetching comments:", err);
      setResponseData([]);
    } finally {
      setResponseLoading(false);
    }
  }, []);

  // Fetch data on component mount
  useEffect(() => {
    fetchScoreViews();
  }, [fetchScoreViews]);

  // ═══════════════════════════════════════════════════════════════
  // 🔧 HELPER FUNCTIONS
  // ═══════════════════════════════════════════════════════════════
  const formatDateDisplay = (dateString) => {
    if (!dateString) return "—";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return dateString;

      const day = date.getDate();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();
      let hours = date.getHours();
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12;

      return `${day}/${month}/${year}, ${String(hours).padStart(2, '0')}:${minutes}${ampm}`;
    } catch {
      return dateString;
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🎯 DYNAMIC FILTER OPTIONS (from API data)
  // ═══════════════════════════════════════════════════════════════
  const filterOptions = useMemo(() => {
    const kpiNoSet = new Set();
    const strategicObjectiveSet = new Set();

    scoreViewsData.forEach(item => {
      if (item.kpiNo) kpiNoSet.add(item.kpiNo);
      if (item.strategicObjective) strategicObjectiveSet.add(item.strategicObjective);
    });

    return {
      kpiNo: Array.from(kpiNoSet).sort(),
      strategicObjective: Array.from(strategicObjectiveSet).sort(),
      scored: ["Yes", "No"],
    };
  }, [scoreViewsData]);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 FILTERED DATA
  // ═══════════════════════════════════════════════════════════════
  const filteredData = useMemo(() => {
    const search = (searchTerm || "").trim().toLowerCase();

    return scoreViewsData.filter((item) => {
      // 🔍 Global Search
      const matchesSearch =
        search === "" ||
        (item.kpiNo + "").toLowerCase().includes(search) ||
        (item.strategicObjective + "").toLowerCase().includes(search) ||
        (item.kpi + "").toLowerCase().includes(search) ||
        (item.subKpi + "").toLowerCase().includes(search) ||
        (item.subKpiName + "").toLowerCase().includes(search) ||
        (item.maxScore + "").toLowerCase().includes(search) ||
        (item.reviewerScore + "").toLowerCase().includes(search) ||
        (item.finalScore + "").toLowerCase().includes(search) ||
        (item.minScore + "").toLowerCase().includes(search) ||
        (item.reviewerName + "").toLowerCase().includes(search);

      // 🎯 KPI No
      const matchesKpiNo =
        filters.kpiNo.length === 0 ||
        filters.kpiNo.includes(item.kpiNo);

      // 🎯 Strategic Objective
      const matchesStrategicObjective =
        filters.strategicObjective.length === 0 ||
        filters.strategicObjective.includes(item.strategicObjective);

      // 🎯 Scored (Yes/No)
      const matchesScored =
        filters.scored.length === 0 ||
        filters.scored.includes(item.isScored ? "Yes" : "No");

      return (
        matchesSearch &&
        matchesKpiNo &&
        matchesStrategicObjective &&
        matchesScored
      );
    });
  }, [scoreViewsData, filters, searchTerm]);

  // ═══════════════════════════════════════════════════════════════
  // 📊 STATISTICS CALCULATION
  // ═══════════════════════════════════════════════════════════════
  const stats = useMemo(() => {
    const totalMaxScore = scoreViewsData.reduce((sum, item) => sum + (parseFloat(item.maxScore) || 0), 0);
    const totalFinalScore = scoreViewsData.reduce((sum, item) => sum + (parseFloat(item.finalScore) || 0), 0);
    const achievementPercent = totalMaxScore > 0 ? ((totalFinalScore / totalMaxScore) * 100).toFixed(0) : 0;

    return {
      totalMaxScore,
      totalFinalScore,
      achievementPercent,
    };
  }, [scoreViewsData]);

  // ═══════════════════════════════════════════════════════════════
  // ♾️ INFINITE SCROLL LOGIC
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const calculateRowsToShow = () => {
      const viewportHeight = window.innerHeight;
      const headerHeight = 280;
      const rowHeight = 48;
      const availableHeight = viewportHeight - headerHeight;
      const visibleRows = Math.floor(availableHeight / rowHeight);
      
      const targetRows = 10;
      setRowsToShow(targetRows);
      setBatchSize(targetRows);
    };

    calculateRowsToShow();
    window.addEventListener("resize", calculateRowsToShow);
    return () => window.removeEventListener("resize", calculateRowsToShow);
  }, []);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 1024);
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  useEffect(() => {
    setDisplayedItems(filteredData.slice(0, rowsToShow));
    setHasMore(filteredData.length > rowsToShow);
  }, [filteredData, rowsToShow]);

  const loadMoreItems = useCallback(() => {
    if (isLoadingMore || !hasMore) return;

    setIsLoadingMore(true);

    setTimeout(() => {
      setDisplayedItems((prevDisplayed) => {
        const currentLength = prevDisplayed.length;
        const nextBatch = filteredData.slice(currentLength, currentLength + batchSize);

        if (nextBatch.length > 0) {
          setHasMore(currentLength + nextBatch.length < filteredData.length);
          return [...prevDisplayed, ...nextBatch];
        } else {
          setHasMore(false);
          return prevDisplayed;
        }
      });

      setIsLoadingMore(false);
    }, 300);
  }, [filteredData, batchSize, hasMore, isLoadingMore]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore) {
          loadMoreItems();
        }
      },
      { threshold: 0.1 }
    );

    const currentTarget = observerTarget.current;
    if (currentTarget) {
      observer.observe(currentTarget);
    }

    return () => {
      if (currentTarget) {
        observer.unobserve(currentTarget);
      }
    };
  }, [loadMoreItems, hasMore, isLoadingMore]);

  // ═══════════════════════════════════════════════════════════════
  // 🎯 EVENT HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleBack = () => navigate("/scorecard/viewreview");

  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const handleViewCriteria = (item) => {
    setSelectedCriteria({
      scoring: item.scoringCriteria || "No scoring criteria available",
      definition: item.criteriaDefinition || "No criteria definition available",
    });
    setShowCriteriaModal(true);
  };

  const handleDownloadDocument = (docUrl) => {
    if (docUrl) {
      window.open(docUrl, "_blank");
    } else {
      alert("No document available");
    }
  };

  const handleViewActionItems = async (item) => {
    setSelectedScoreView(item);
    setShowActionPopup(true);
    setPopupView("ACTION_TABLE");
    
    // Fetch action items from API
    await fetchActionItems(item.id);
  };

  const handleViewResponse = async (actionItem) => {
    setSelectedActionItem(actionItem);
    setPopupView("RESPONSE_TABLE");
    
    // Pre-fill response form with action item data
    setResponseForm({
      year: rowData?.year || "",
      quarter: rowData?.quarter || "",
      strategicObjective: selectedScoreView?.strategicObjective || "Customer Excellence",
      kpi: selectedScoreView?.kpi || "Service Response Time",
      subKpi: selectedScoreView?.subKpiName || actionItem?.subKpi || "MTTR (Mean Time to Repair)",
      comments: "",
    });
    
    // Fetch response data from API
    await fetchResponseData(actionItem.id);
  };

  const toggleExpand = (id) => {
    setExpandedRow(expandedRow === id ? null : id);
  };

  const toggleDropdown = (id, e) => {
    e.stopPropagation();
    setDropdownId(prev => (prev === id ? null : id));
  };

  const handleConfirmDelete = async () => {
    setLoading(true);
    try {
      if (deleteType === "action") {
        console.log("📡 Deleting action item:", deleteRowId);
        await deleteScorecardActionItem(deleteRowId);
        console.log("✅ Action item deleted successfully");
        // Refresh action items
        await fetchActionItems(selectedScoreView?.id);
      } else if (deleteType === "comment") {
        console.log("📡 Deleting comment:", deleteRowId);
        await deleteScorecardActionLog(deleteRowId);
        console.log("✅ Comment deleted successfully");
        // Refresh comments
        await fetchResponseData(selectedActionItem?.id);
      }
    } catch (err) {
      console.error("❌ Delete failed:", err);
      alert("Failed to delete: " + err.message);
    } finally {
      setLoading(false);
      setDeleteModalOpen(false);
      setDeleteRowId(null);
      setDeleteType(null);
    }
  };

  // Delete handlers
  const handleDeleteActionItem = (id) => {
    setDeleteRowId(id);
    setDeleteType("action");
    setDeleteModalOpen(true);
  };

  const handleDeleteComment = (id) => {
    setDeleteRowId(id);
    setDeleteType("comment");
    setDeleteModalOpen(true);
  };

  // Form handlers
  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleResponseChange = (field, value) => {
    setResponseForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleChangeassign = (eOrField, val) => {
    if (typeof eOrField === "string") {
      setAssignForm((prev) => ({ ...prev, [eOrField]: val }));
      return;
    }
    const { name, value } = eOrField.target;
    setAssignForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSaveAction = () => {
    const newErrors = {};
    if (!form.year) newErrors.year = "Please enter Year";
    else if (form.year.length !== 4) newErrors.year = "Year must be 4 digits";
    if (!form.quarter) newErrors.quarter = "Please select Quarter";
    if (!form.subKpi) newErrors.subKpi = "Please enter Sub KPI";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});

    const newRow = {
      id: Date.now(),
      createdBy: "User",
      subKpi: form.subKpi,
      createdDate: new Date().toLocaleString(),
      maxScore: 0,
      finalScore: 0,
      remarks: form.comments || "-",
      status: "Created",
      assignedTo: form.assignedTo || "-",
    };

    setActionItemsData((prev) => [newRow, ...prev]);

    setForm({
      year: "",
      quarter: "",
      strategicObjective: "Customer Excellence",
      kpi: "Service Response Time",
      subKpi: "",
      comments: "",
      assignedTo: "",
    });

    setPopupView("ACTION_TABLE");
  };

  // ═══════════════════════════════════════════════════════════════
  // 💾 SAVE RESPONSE (API INTEGRATED)
  // ═══════════════════════════════════════════════════════════════
  const handleAssign = () => {
    let tempErrors = {};

    if (!assignform.assignTo) tempErrors.assignTo = "Please select Assign To";
    if (!assignform.endDate) tempErrors.endDate = "Please select End Date";
    if (assignform.assignTo === "Internal User" && !assignform.dealerUser)
      tempErrors.dealerUser = "Please select Dealer User";
    if (assignform.assignTo === "External User" && !assignform.email)
      tempErrors.email = "Please enter External Email";

    if (Object.keys(tempErrors).length > 0) {
      setErrors(tempErrors);
      return;
    }

    const assignedValue =
      assignform.assignTo === "External User"
        ? assignform.email
        : assignform.dealerUser;

    setActionItemsData((prev) =>
      prev.map((row) =>
        row.id === selectedRowId
          ? { ...row, assignedTo: assignedValue, status: "In Progress" }
          : row
      )
    );

    setAssignmentHistory((prev) => [
      ...prev,
      {
        rowId: selectedRowId,
        commentsBy: "System",
        actionItem: "Assignment Updated",
        comment: `Assigned to ${assignedValue}`,
        createdDate: new Date().toLocaleDateString("en-GB"),
      },
    ]);

    setAssignForm({ assignTo: "", dealerUser: "", email: "", endDate: "" });
    setErrors({ assignTo: "", dealerUser: "", email: "", endDate: "" });
    setPopupView("ACTION_TABLE");
  };

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!dropdownId) return;

      const dropdownWrapper = wrapperRefs.current[dropdownId];
      const popupBox = popupRef.current;

      if (dropdownWrapper && !dropdownWrapper.contains(event.target) && popupBox?.contains(event.target)) {
        setDropdownId(null);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [dropdownId]);

  // Response filter
  const filteredResponse = useMemo(() => {
    if (!ressearchQuery) return responseData;

    return responseData.filter((item) => {
      return (
        (item.systemUser?.toLowerCase() || "").includes(ressearchQuery.toLowerCase()) ||
        (item.commentsby?.toLowerCase() || "").includes(ressearchQuery.toLowerCase()) ||
        (item.Comments?.toLowerCase() || "").includes(ressearchQuery.toLowerCase()) ||
        (item.createdDate?.toLowerCase() || "").includes(ressearchQuery.toLowerCase()) ||
        (item.supportingDocument?.toLowerCase() || "").includes(ressearchQuery.toLowerCase()) ||
        (item.status?.toLowerCase() || "").includes(ressearchQuery.toLowerCase())
      );
    });
  }, [ressearchQuery, responseData]);

  // ═══════════════════════════════════════════════════════════════
  // 📱 MOBILE CARD COMPONENT
  // ═══════════════════════════════════════════════════════════════
  const MobileAuditCard = ({ item, index }) => (
    <div className="bg-white border border-gray-200 rounded-lg p-3 mb-3 shadow-sm">
      <div className="flex justify-between items-start mb-2">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold text-darkblue1">KPI {item.kpiNo}</span>
            <span className={`text-xs font-medium px-2 py-0.5 rounded ${
              item.isScored ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
            }`}>
              {item.isScored ? "Scored" : "Not Scored"}
            </span>
            {item.isExcluded && (
              <span className="text-xs font-medium px-2 py-0.5 rounded bg-yellow-100 text-yellow-700">
                Excluded
              </span>
            )}
          </div>
          <p className="text-xs font-medium text-black">{item.strategicObjective}</p>
          <p className="text-xs text-gray-600">{item.kpi}</p>
        </div>
      </div>

      <div className="space-y-1.5 border-t pt-2">
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Sub KPI:</span>
          <span className="text-xs text-black text-right line-clamp-2 flex-1 ml-2">{item.subKpiName || item.subKpi}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Max Score:</span>
          <span className="text-xs text-black font-medium">{item.maxScore}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Reviewer Score:</span>
          <span className="text-xs text-black font-medium">{item.reviewerScore || "—"}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Final Score:</span>
          <span className="text-xs text-darkblue1 font-semibold">{item.finalScore || "—"}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Threshold:</span>
          <span className="text-xs text-black">{item.minScore}</span>
        </div>
        {item.reviewerName && (
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Scored By:</span>
            <span className="text-xs text-black">{item.reviewerName}</span>
          </div>
        )}
      </div>

      <div className="flex gap-2 mt-3 pt-2 border-t">
        <button
          onClick={() => handleViewCriteria(item)}
          className="flex-1 text-xs bg-gray-100 hover:bg-gray-200 py-1.5 rounded transition"
        >
          View Criteria
        </button>
        <button
          onClick={() => handleViewActionItems(item)}
          className="flex-1 text-xs bg-darkblue1 text-white hover:bg-blue-700 py-1.5 rounded transition"
        >
          Action Items
        </button>
      </div>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header Section */}
          <div className="flex flex-col w-full mb-3">
            <div className="flex items-center gap-2">
              <ArrowLeft
                onClick={handleBack}
                size={20}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
              />
              <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                Dealer Details: {rowData?.dealer || rowData?.dealerName || "—"}
              </h2>
            </div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-[150px] sm:w-[200px] mt-1 ml-7"></div>
          </div>

          {/* Info Grid */}
          <div className="w-full bg-white shadow-[0_4px_10px_#0000001A] p-1.5 mb-3 overflow-x-auto">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 text-center gap-2 lg:gap-0 min-w-max lg:min-w-0">
              {[
                { 
                  title: "Year / Quarter", 
                  value: `${rowData?.year || rowData?.scorecard_year || scoreViewsData[0]?.scorecardYear || "—"} / ${rowData?.quarter || rowData?.quarter_frequency || scoreViewsData[0]?.scorecardQuarter || "—"}`, 
                },
                { 
                  title: "Frequency", 
                  value: rowData?.frequency || rowData?.scorecard_frequency || scoreViewsData[0]?.scorecardFrequency || "—", 
                },
                { 
                  title: "Audit Location", 
                  value: rowData?.auditLocation || rowData?.audit_location || scoreViewsData[0]?.scorecardAuditLocation || "—", 
                },
                { 
                  title: "Branch", 
                  value: rowData?.branch || rowData?.branch_name || scoreViewsData[0]?.scorecardBranch || "—", 
                },
                { 
                  title: "Auditor", 
                  value: rowData?.leadAuditor || rowData?.auditor_name || rowData?.auditor || "—", 
                },
                { 
                  title: "Created Date", 
                  value: formatDateDisplay(rowData?.created_at || rowData?.createdAt || scoreViewsData[0]?.createdAt), 
                },
                {
                  title: "Status",
                  value: rowData?.reviewStatus || rowData?.review_status || rowData?.status || "—",
                  color: (rowData?.reviewStatus || rowData?.review_status || rowData?.status) === "Completed" ? "text-green-600" : 
                         (rowData?.reviewStatus || rowData?.review_status || rowData?.status) === "Pending" ? "text-orange-600" :
                         (rowData?.reviewStatus || rowData?.review_status || rowData?.status) === "Created" ? "text-blue-600" : "text-gray-600",
                },
              ].map((item, i) => (
                <div
                  key={i}
                  className={`relative py-2 px-2 lg:px-3 ${i < 6 ? "lg:border-r border-gray-300" : ""} flex flex-col items-center justify-center bg-white rounded lg:rounded-none`}
                >
                  <div className="text-xs font-medium text-black text-center">{item.title}</div>
                  <div className={`text-xs font-semibold mt-1 text-center ${item.color || "text-SteelBlue1"}`}>
                    {item.value || "—"}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Loading State */}
          {isLoading && (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
              <span className="ml-3 text-gray-600">Loading score views...</span>
            </div>
          )}

          {/* Error State */}
          {error && !isLoading && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-red-600 font-medium">Error:</span>
                  <span className="text-red-700">{error}</span>
                </div>
                <button
                  onClick={fetchScoreViews}
                  className="bg-red-600 text-white px-3 py-1 rounded text-xs hover:bg-red-700 transition"
                >
                  Retry
                </button>
              </div>
            </div>
          )}

          {/* Main Content */}
          {!isLoading && !error && (
            <>
              {/* Filters and Stats Row */}
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-3 w-full">
                {/* Filters */}
                <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
                  <Searchinput 
                    value={searchTerm} 
                    onChange={(e) => setSearchTerm(e.target.value)} 
                    placeholder="Search" 
                    className="w-[1/2]" 
                    iconColor="text-black" 
                    bgColor="bg-FrostWhite" 
                    borderColor="border-black" 
                    textColor="text-black" 
                    shadow="shadow-none" 
                    inputPadding="pl-7 pr-3 py-1.5" 
                    iconSize="w-3.5 h-3.5" 
                    iconLeft="left-3" 
                    inputWidth="w-full" 
                    focusRing="focus:ring-1 focus:ring-black/60" 
                    hoverInputClasses="hover:bg-white hover:border-black/60" 
                  />

                  <Filter
                    name="kpiNo"
                    value={filters.kpiNo}
                    options={filterOptions.kpiNo}
                    onChange={handleFilterChange}
                    placeholder="KPI No"
                    customWidth="w-[130px] sm:w-[140px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-gray-300"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />

                  <Filter
                    name="strategicObjective"
                    value={filters.strategicObjective}
                    options={filterOptions.strategicObjective}
                    onChange={handleFilterChange}
                    placeholder="Strategic Objective"
                    customWidth="w-[170px] sm:w-[200px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-gray-300"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />

                  <Filter
                    name="scored"
                    value={filters.scored}
                    options={filterOptions.scored}
                    onChange={handleFilterChange}
                    placeholder="Scored"
                    customWidth="w-[110px] sm:w-[120px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    closedBgColor="bg-white"
                    hoverRingColor="ring-gray-300"
                    openBgColor="bg-white"
                    textColor="text-black"
                  />
                </div>

                {/* Stats */}
                <div className="flex flex-wrap items-center gap-4 lg:gap-6 text-xs font-medium whitespace-nowrap">
                  <span className="text-black">
                    Max Score: <span className="font-semibold">{stats.totalMaxScore}</span>
                  </span>
                  <span className="text-black">
                    Final Score: <span className="font-semibold text-blue-600">{stats.totalFinalScore}</span>
                  </span>
                  <span className="text-black">
                    Achievement %: <span className="font-semibold">{stats.achievementPercent}%</span>
                  </span>
                </div>
              </div>

              {/* Data Display - Responsive */}
              {isMobileView ? (
                /* Mobile Card View */
                <div className="space-y-3">
                  {sortedData.length > 0 ? (
                    <>
                      {sortedData.map((item, index) => (
                        <MobileAuditCard key={`${item.id}-${index}`} item={item} index={index} />
                      ))}
                      {isLoadingMore && (
                        <div className="flex justify-center py-3">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        </div>
                      )}
                      <div ref={observerTarget} className="h-2" />
                    </>
                  ) : (
                    <div className="bg-white  rounded-lg p-6 text-center text-gray-500">
                      No records found
                    </div>
                  )}
                </div>
              ) : (
                /* Desktop Table View */
                <div className={`flex-shrink overflow-hidden bg-white shadow-md border border-Dustyblue w-full relative z-10 lg:max-h-[calc(100vh-12rem)] ${showMobileFilters ? 'max-h-[calc(100vh-26rem)]' : 'max-h-[calc(100vh-14rem)]'}`}>
                  <div className="hidden lg:block h-full">
                    <div
                      ref={tableContainerRef}
                      className="overflow-y-auto overflow-x-auto max-h-full"
                      style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                    >
                      <table className="w-full text-xs border-collapse">
                        <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                          <tr>
                       
  {/* KPI No */}
  <th onClick={() => handleSort("kpiNo")}
    className="px-2 py-1.5 text-left font-medium border border-white/20 border-t-0 border-l-0 w-[5%] cursor-pointer select-none">
    <div className="flex items-center gap-1">
      KPI No
      {sortKey !== "kpiNo" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

      {sortKey === "kpiNo" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "kpiNo" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Strategic Objective */}
  <th onClick={() => handleSort("strategicObjective")}
    className="px-2 py-1.5 text-left font-medium border border-white/20 border-t-0 border-l-0 w-[10%] cursor-pointer select-none">
    <div className="flex items-center gap-1">
      Strategic Objective
      {sortKey === "strategicObjective" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "strategicObjective" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* KPI */}
  <th onClick={() => handleSort("kpi")}
    className="px-2 py-1.5 text-left font-medium border border-white/20 border-t-0 border-l-0 w-[10%] cursor-pointer select-none">
    <div className="flex items-center gap-1">
      KPI
      {sortKey === "kpi" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "kpi" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Sub KPI */}
  <th onClick={() => handleSort("subKpi")}
    className="px-2 py-1.5 text-left font-medium border border-white/20 border-t-0 border-l-0 w-[15%] cursor-pointer select-none">
    <div className="flex items-center gap-1">
      Sub KPI
      {sortKey === "subKpi" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "subKpi" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Criteria */}
  <th onClick={() => handleSort("criteria")}
    className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[5%] cursor-pointer select-none">
    <div className="flex items-center justify-center gap-1">
      Criteria
      {sortKey === "criteria" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "criteria" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Max Score */}
  <th onClick={() => handleSort("maxScore")}
    className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[5%] cursor-pointer select-none">
    <div className="flex items-center justify-center gap-1">
      Max Score
      {sortKey === "maxScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "maxScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Reviewer Score */}
  <th onClick={() => handleSort("reviewerScore")}
    className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[6%] cursor-pointer select-none">
    <div className="flex items-center justify-center gap-1">
      Reviewer Score
      {sortKey === "reviewerScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "reviewerScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Final Score */}
  <th onClick={() => handleSort("finalScore")}
    className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[5%] cursor-pointer select-none">
    <div className="flex items-center justify-center gap-1">
      Final Score
      {sortKey === "finalScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "finalScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Threshold */}
  <th onClick={() => handleSort("threshold")}
    className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[6%] cursor-pointer select-none">
    <div className="flex items-center justify-center gap-1">
      Threshold
      {sortKey === "threshold" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "threshold" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Excluded */}
  <th onClick={() => handleSort("excluded")}
    className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[6%] cursor-pointer select-none">
    <div className="flex items-center justify-center gap-1">
      Excluded
      {sortKey === "excluded" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "excluded" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Scored */}
  <th onClick={() => handleSort("scored")}
    className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 w-[5%] cursor-pointer select-none">
    <div className="flex items-center justify-center gap-1">
      Scored
      {sortKey === "scored" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "scored" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Supporting Document */}
  <th onClick={() => handleSort("supportingDocument")}
    className="px-2 py-1.5 text-left font-medium border border-white/20 border-t-0 border-l-0 w-[10%] cursor-pointer select-none">
    <div className="flex items-center gap-1">
      Supporting Document
      {sortKey === "supportingDocument" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "supportingDocument" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Uploaded By */}
  <th onClick={() => handleSort("uploadedBy")}
    className="px-2 py-1.5 text-left font-medium border border-white/20 border-t-0 border-l-0 w-[8%] cursor-pointer select-none">
    <div className="flex items-center gap-1">
      Uploaded By
      {sortKey === "uploadedBy" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "uploadedBy" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Scored By */}
  <th onClick={() => handleSort("scoredBy")}
    className="px-2 py-1.5 text-left font-medium border border-white/20 border-t-0 border-l-0 w-[8%] cursor-pointer select-none">
    <div className="flex items-center gap-1">
      Scored By
      {sortKey === "scoredBy" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "scoredBy" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

                            <th className="px-2 py-1.5 text-center font-medium border-t-0 border-l-0 border-r-0 w-[5%]">Action Items</th>
                          </tr>
                        </thead>

                        <tbody>
                          {displayedItems.length > 0 ? (
                            <>
                              {displayedItems.map((item, index) => (
                                <tr
                                  key={`${item.id}-${index}`}
                                  className={`text-xs transition ${
                                    index % 2 === 0 ? 'bg-white' : 'bg-gray-50'
                                  } hover:bg-lightBlue/30`}
                                >
                                  <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                    {item.kpiNo}
                                  </td>
                                  <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                    {item.strategicObjective}
                                  </td>
                                  <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                    {item.kpi}
                                  </td>
                                  <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                    {item.subKpiName || item.subKpi}
                                  </td>
                                  <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                    <button
                                      onClick={() => handleViewCriteria(item)}
                                      className="inline-flex items-center justify-center w-full hover:bg-gray-200 rounded transition p-1"
                                      title="View Criteria"
                                    >
                                      <svg className="w-4 h-4 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M9 2a2 2 0 00-2 2v8a2 2 0 002 2h6a2 2 0 002-2V6.414A2 2 0 0016.414 5L14 2.586A2 2 0 0012.586 2H9z" />
                                        <path d="M3 8a2 2 0 012-2v10h8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z" />
                                      </svg>
                                    </button>
                                  </td>
                                  <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0 font-medium">
                                    {item.maxScore}
                                  </td>
                                  <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0 font-medium">
                                    {item.reviewerScore || "—"}
                                  </td>
                                  <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0 font-semibold">
                                    {item.finalScore || "—"}
                                  </td>
                                  <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                    {item.minScore}
                                  </td>
                                  <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${
                                      item.isExcluded 
                                        ? "bg-yellow-100 text-yellow-700" 
                                        : "bg-gray-100 text-gray-600"
                                    }`}>
                                      {item.isExcluded ? "Yes" : "No"}
                                    </span>
                                  </td>
                                  <td className="px-2 py-1 text-center border border-grey2 border-t-0 border-l-0">
                                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${
                                      item.isScored 
                                        ? "bg-green-100 text-green-700" 
                                        : "bg-red-100 text-red-700"
                                    }`}>
                                      {item.isScored ? "Yes" : "No"}
                                    </span>
                                  </td>
                                  <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                    {item.supportingDoc ? (
                                      <button
                                        onClick={() => handleDownloadDocument(item.supportingDoc)}
                                        className="text-blue-600 hover:text-blue-800 underline decoration-2 underline-offset-2 font-medium text-left transition text-xs"
                                        title="Click to download"
                                      >
                                        {item.supportingDoc.split('/').pop() || "Document"}
                                      </button>
                                    ) : documents.length > 0 ? (
                                      <div className="flex flex-col gap-0.5">
                                        {documents.map((doc, docIdx) => (
                                          <button
                                            key={doc.id || docIdx}
                                            onClick={() => handleDownloadDocument(doc.docUrl)}
                                            className="text-blue-600 hover:text-blue-800 underline decoration-1 underline-offset-2 font-medium text-left transition text-xs truncate max-w-[150px]"
                                            title={doc.name || "Click to download"}
                                          >
                                            {doc.name || `Document ${docIdx + 1}`}
                                          </button>
                                        ))}
                                      </div>
                                    ) : (
                                      "—"
                                    )}
                                  </td>
                                  <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                    {item.uploadedByName ? (
                                      <>
                                        <div className="font-medium text-black text-xs">{item.uploadedByName}</div>
                                        {item.uploadedOn && (
                                          <div className="text-gray-600 text-[10px]">{formatDateDisplay(item.uploadedOn)}</div>
                                        )}
                                      </>
                                    ) : documents.length > 0 ? (
                                      <div className="flex flex-col gap-0.5">
                                        {documents.map((doc, docIdx) => (
                                          <div key={doc.id || docIdx}>
                                            <div className="font-medium text-black text-xs">{doc.uploadedByName || "—"}</div>
                                            <div className="text-gray-600 text-[10px]">{doc.date || ""}</div>
                                          </div>
                                        ))}
                                      </div>
                                    ) : (
                                      "—"
                                    )}
                                  </td>
                                  <td className="px-2 py-1 text-left border border-grey2 border-t-0 border-l-0">
                                    {item.reviewerName ? (
                                      <>
                                        <div className="font-medium text-black text-xs">{item.reviewerName}</div>
                                        {item.updatedAt && (
                                          <div className="text-gray-600 text-[10px]">{formatDateDisplay(item.updatedAt)}</div>
                                        )}
                                      </>
                                    ) : (
                                      "—"
                                    )}
                                  </td>
                                  <td className="py-1 text-center border border-grey2">
                                    <button
                                      onClick={() => handleViewActionItems(item)}
                                      className="w-6 h-6 border border-grey flex items-center justify-center mx-auto hover:bg-lightBlue/50"
                                    >
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" className="w-3 h-2">
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="#212121"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
</svg>
                                    </button>
                                  </td>
                                </tr>
                              ))}

                              {isLoadingMore && (
                                <tr>
                                  <td colSpan={15} className="py-3 text-center text-gray-500">
                                    <div className="flex items-center justify-center gap-2">
                                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                                      Loading more...
                                    </div>
                                  </td>
                                </tr>
                              )}

                              <tr ref={observerTarget}>
                                <td colSpan={15} className="h-0 p-0"></td>
                              </tr>
                            </>
                          ) : (
                            <tr className="hover:bg-gray-50">
                              <td
                                colSpan={15}
                                className="px-2 py-4 text-center text-gray-500 italic"
                              >
                                No records found
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Criteria Display Modal */}
      {showCriteriaModal && selectedCriteria && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-3xl w-full shadow-2xl">
            <div className="bg-Dustyblue text-white px-4 py-3 rounded-t-lg flex items-center justify-between">
              <h3 className="text-sm font-semibold">Criteria Display</h3>
              <button
                onClick={() => setShowCriteriaModal(false)}
                className="bg-red-600 hover:bg-red-700 text-white rounded-full p-1 transition"
              >
                <X size={16} />
              </button>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-semibold text-black mb-3">Scoring Criteria:</h4>
                  <div 
                    className="bg-gray-100 p-4 rounded text-xs text-black"
                    dangerouslySetInnerHTML={{ __html: selectedCriteria.scoring }}
                  />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-black mb-3">Criteria Definition:</h4>
                  <div 
                    className="bg-gray-100 p-4 rounded text-xs text-black"
                    dangerouslySetInnerHTML={{ __html: selectedCriteria.definition }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Action Items Popup */}
      {showActionPopup && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div
            ref={popupRef}
            onClick={(e) => e.stopPropagation()}
            className={`
              bg-white p-6 shadow-lg relative
              ${
                popupView === "ACTION_TABLE"
                  ? "lg:w-[90%]"
                : popupView === "RESPONSE_TABLE"
                  ? "w-[80%]"
                : popupView === "ADD_ACTION"
                  ? "w-[50%]"
                : popupView === "ADD_ASIGN"
                  ? "w-[50%]"
                : "w-[70%]"
              }
            `}
          >
            {/* ACTION TABLE SCREEN */}
            {popupView === "ACTION_TABLE" && (
              <>
                <div className="flex flex-col w-full mb-2">
                  <div className="flex items-center gap-2">
                    <ArrowLeft
                      onClick={() => setShowActionPopup(false)}
                      size={20}
                      className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
                    />
                    <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                      Action Items - {selectedScoreView?.subKpiName || selectedScoreView?.subKpi || ""}
                    </h2>
                  </div>
                  <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-7"></div>
                </div>

                <div className="flex justify-end mb-2">
                  {/* Add Action button can be enabled if needed */}
                </div>

                {/* Loading State */}
                {actionItemsLoading && (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-darkblue1"></div>
                    <span className="ml-2 text-gray-600 text-sm">Loading action items...</span>
                  </div>
                )}

                {!actionItemsLoading && (
                  <div className="bg-white border shadow max-h-[70vh] overflow-visible">
                    <table className="w-full text-xs">
                      <thead className="bg-Dustyblue text-white sticky top-0 text-left">
                        <tr>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Created By</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Review Sub KPI</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Created Date</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0 text-center">Max Score</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0 text-center">Final Score</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Remarks</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Status</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Assigned To</th>
                          <th className="p-1.5 border border-grey2 border-t-0 border-l-0 border-r-0 text-center">Action</th>
                        </tr>
                      </thead>

                      <tbody>
                        {actionItemsData.length === 0 ? (
                          <tr>
                            <td colSpan={9} className="text-center p-3 italic text-gray-500">
                              No data found
                            </td>
                          </tr>
                        ) : (
                          actionItemsData.map((item, i) => (
                            <tr key={item.id || i}>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1">{item.createdByName || item.createdBy || "User"}</td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1">{item.subKpi || selectedScoreView?.subKpiName || "-"}</td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1">{item.createdAt ? formatDateDisplay(item.createdAt) : item.createdDate || "-"}</td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1 text-center">{item.maxScore || selectedScoreView?.maxScore || 0}</td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1 text-center">{item.finalScore || 0}</td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1">{item.remarks || "-"}</td>
                              <td className={`border border-grey2 border-t-0 border-l-0 p-1 text-xs font-medium ${
                                item.status === "Completed" || item.status === "Closed" ? "text-green-600" :
                                item.status === "In Progress" ? "text-blue-600" : "text-black"
                              }`}>
                                {item.status || "Created"}
                              </td>
                              <td className="border border-grey2 border-t-0 border-l-0 p-1">{item.assignedToName || item.assignedTo || "-"}</td>
                              <td className="border p-1 text-center">
                                <div className="flex items-center justify-center gap-2">
                                  <div className="relative group">
                                    <button
                                      onClick={() => handleViewResponse(item)}
                                      className="w-6 h-6 border border-black flex items-center justify-center hover:bg-lightBlue/50"
                                    >
                                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" className="w-3 h-2">
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="#212121"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9ZM12 17C10.6739 17 9.40215 16.4732 8.46447 15.5355C7.52678 14.5979 7 13.3261 7 12C7 10.6739 7.52678 9.40215 8.46447 8.46447C9.40215 7.52678 10.6739 7 12 7C13.3261 7 14.5979 7.52678 15.5355 8.46447C16.4732 9.40215 17 10.6739 17 12C17 13.3261 16.4732 14.5979 15.5355 15.5355C14.5979 16.4732 13.3261 17 12 17ZM12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5Z" fill="black" fill-opacity="0.2"/>
</svg>
                                    </button>
                                    <span className="absolute left-1/2 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                                      View
                                    </span>
                                  </div>

                                  {/* Delete Button */}
                                  <div className="relative group">
                                    <button
                                      onClick={() => handleDeleteActionItem(item.id)}
                                      className="w-6 h-6 border border-black flex items-center justify-center hover:bg-red-100"
                                    >
                                   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>

                                    </button>
                                    <span className="absolute left-1/2 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-red-500 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                                      Delete
                                    </span>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}

            {/* ADD ACTION SCREEN */}
            {popupView === "ADD_ACTION" && (
              <>
                <h2 className="text-base font-semibold text-MediumGrey">
                  Manual Action Item Form
                </h2>
                <div className="hidden lg:block h-1 bg-MediumGrey w-[10%] mb-4"></div>

                <form className="w-full items-center justify-center">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="mt-1">
                      <label className="block text-xs font-medium mb-1 text-black/70">
                        Year <span className="text-red-600">*</span>
                      </label>
                      <input
                        type="text"
                        className={`w-full p-1.5 text-xs focus:outline-none border ${errors.year ? "border-red1" : "border-black/30"}`}
                        placeholder="Enter Year"
                        maxLength={4}
                        inputMode="numeric"
                        pattern="\d{4}"
                        value={form.year}
                        onChange={(e) => handleChange("year", e.target.value.replace(/\D/g, ""))}
                      />
                      {errors.year && <p className="text-red1 text-xs mt-1">{errors.year}</p>}
                    </div>

                    <div>
                      <StyledSelectField
                        label="Quarter"
                        placeholder="Select Quarter"
                        value={form.quarter}
                        setValue={(val) => handleChange("quarter", val)}
                        options={["Q1", "Q2", "Q3", "Q4"]}
                        dropdownOpen={dropdowns.quarter}
                        setDropdownOpen={(val) => setDropdowns((prev) => ({ ...prev, quarter: val }))}
                        dropdownRef={refs.quarter}
                        error={errors.quarter}
                      />
                    </div>

                    <div>
                      <label className="block text-xs text-black/70 font-medium mb-1">Strategic Objective</label>
                      <input
                        type="text"
                        className="w-full p-1.5 border border-black/30 text-xs focus:outline-none"
                        placeholder="Enter Strategic Objective"
                        value={form.strategicObjective}
                        onChange={(e) => handleChange("strategicObjective", e.target.value)}
                      />
                    </div>

                    <div>
                      <label className="block text-xs text-black/70 font-medium mb-1">KPI</label>
                      <input
                        type="text"
                        className="w-full p-1.5 border border-black/30 text-xs focus:outline-none"
                        placeholder="Enter KPI"
                        value={form.kpi}
                        onChange={(e) => handleChange("kpi", e.target.value)}
                      />
                    </div>

                    <div>
                      <label className="block text-xs text-black/70 font-medium mb-1">
                        Sub KPI <span className="text-red-600">*</span>
                      </label>
                      <input
                        type="text"
                        className={`w-full p-1.5 text-xs focus:outline-none border ${errors.subKpi ? "border-red-600" : "border-black/30"}`}
                        placeholder="Enter Sub KPI"
                        value={form.subKpi}
                        onChange={(e) => handleChange("subKpi", e.target.value)}
                      />
                      {errors.subKpi && <p className="text-red-600 text-xs mt-1">{errors.subKpi}</p>}
                    </div>

                    <div className="col-span-2">
                      <label className="block text-xs text-black/70 font-medium mb-1">Comments</label>
                      <textarea
                        className="w-full p-2 border border-black/30 text-xs resize-none focus:outline-none"
                        rows={3}
                        placeholder="Enter comments..."
                        value={form.comments}
                        onChange={(e) => handleChange("comments", e.target.value)}
                      ></textarea>
                    </div>
                  </div>
                </form>

                <div className="flex justify-center gap-4 mt-4">
                  <button
                    type="button"
                    className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium hover:bg-mildBlue1 hover:scale-105"
                    onClick={() => {
                      setForm({
                        year: "",
                        quarter: "",
                        strategicObjective: "",
                        kpi: "",
                        subKpi: "",
                        comments: "",
                      });
                      setErrors({
                        year: "",
                        quarter: "",
                        subKpi: "",
                        strategicObjective: "",
                        kpi: "",
                        comments: "",
                      });
                      setPopupView("ACTION_TABLE");
                    }}
                  >
                   
               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 18 20" fill="none"className="w-3 h-3">
<path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
                    Cancel
                  </button>

                  <button
                    onClick={handleSaveAction}
                    className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 transition hover:bg-blue-700 focus:outline-none hover:text-darkblue1 hover:border hover:border-darkblue1 hover:bg-white"
                  >
                    Save
                  </button>
                </div>
              </>
            )}

            {/* RESPONSE TABLE SCREEN */}
            {popupView === "RESPONSE_TABLE" && (
              <>
                <div className="flex flex-col w-full mb-4">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <ArrowLeft
                        onClick={() => setPopupView("ACTION_TABLE")}
                        size={20}
                        className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
                      />
                      <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
                        {selectedScoreView?.subKpiName || "MTTR (Mean Time to Repair)"}
                      </h2>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`px-3 py-1 rounded text-sm font-medium ${
                          selectedActionItem?.status === "Completed" || selectedActionItem?.status === "Closed"
                            ? "bg-green-100 text-green-600"
                            : selectedActionItem?.status === "In Progress"
                            ? "bg-blue-100 text-blue-600"
                            : selectedActionItem?.assignedTo || selectedActionItem?.assignedToName
                            ? "bg-green-100 text-green-600"
                            : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {selectedActionItem?.assignedTo || selectedActionItem?.assignedToName
                          ? "Assigned"
                          : selectedActionItem?.status || "Created"}
                      </span>
                    </div>
                  </div>

                  <div className="h-[2px] bg-darkblue1 w-[10%] ml-7 -mt-2"></div>
                </div>

                <div className="flex justify-between items-center mb-2">
                  <div className="flex gap-2">
                    <Searchinput
                      value={ressearchQuery}
                      onChange={(e) => setResSearchQuery(e.target.value)}
                      placeholder="Search"
                      className=""
                      iconColor="text-black"
                      bgColor="bg-FrostWhite"
                      borderColor="border-black/60"
                      textColor="text-black"
                      shadow="shadow-none"
                      inputPadding="pl-6 pr-3 py-1.5"
                      iconSize="w-3 h-3"
                      iconLeft="left-3 top-4"
                      inputWidth="w-full"
                      focusRing="focus:ring-black/60"
                      hoverInputClasses="hover:bg-white hover:border-black/60"
                    />
                  </div>


                </div>

                {/* Loading State */}
                {responseLoading && (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-darkblue1"></div>
                    <span className="ml-2 text-gray-600 text-sm">Loading responses...</span>
                  </div>
                )}

                {!responseLoading && (
                  <div className="bg-white shadow-md border border-Dustyblue">
                    <div
                      ref={tableContainerRef}
                      className="hide-scrollbar overflow-y-auto overflow-x-auto max-h-[calc(100vh-280px)] sm:max-h-[calc(100vh-260px)] md:max-h-[calc(100vh-240px)] lg:max-h-[calc(100vh-220px)] xl:max-h-[calc(100vh-200px)]"
                    >
                      <table className="w-full text-xs border-collapse">
                        <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                          <tr className="text-left">
                            <th className="p-1.5 border border-grey2 border-t-0 border-l-0">System / User</th>
                            <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Comments By</th>
                            <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Comments</th>
                            <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Created Date</th>
                            <th className="p-1.5 border border-grey2 border-t-0 border-l-0">Supporting Document</th>
                            <th className="p-1.5 border border-grey2 border-t-0 border-l-0">
                              Action Details
                            </th>
                            <th className="p-1.5 text-center border border-grey2 border-t-0 border-l-0 border-r-0">
                              Action
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                          {filteredResponse.length === 0 ? (
                            <tr>
                              <td colSpan="8" className="p-3 text-center text-gray-500 italic">
                                No data found
                              </td>
                            </tr>
                          ) : (
                            filteredResponse.map((item, index) => (
                              <tr key={item.id || index}>
                                <td className="p-1 border border-grey2 border-t-0 border-l-0">{item.systemUser}</td>
                                <td className="p-1 border border-grey2 border-t-0 border-l-0">{item.commentsby}</td>
                                <td className="p-1 border border-grey2 border-t-0 border-l-0">{item.Comments}</td>
                                <td className="p-1 border border-grey2 border-t-0 border-l-0">{item.createdDate}</td>
                                <td className="p-1 border border-grey2 border-t-0 border-l-0">
                                  {item.supportingDocument ? (
                                    <button
                                      onClick={() => handleDownloadDocument(item.supportingDocument)}
                                      className="text-blue-600 hover:text-blue-800 underline"
                                    >
                                      View
                                    </button>
                                  ) : (
                                    "-"
                                  )}
                                </td>
                                <td className="p-1 border border-grey2 border-t-0 border-l-0">
                                  {item.details}
                                </td>
                                <td className="p-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-center">
                                  <div className="flex items-center justify-center">
                                    <div className="relative group">
                                      <button
                                        onClick={() => handleDeleteComment(item.id)}
                                        className="w-6 h-6 border border-black flex items-center justify-center hover:bg-red-100"
                                      >
                                     <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>

                                      </button>
                                      <span className="absolute left-1/2 top-full mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-red-500 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                                        Delete
                                      </span>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      <DeleteModal
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
        loading={loading}
      />
    </div>
  );
};

export default ViewAudit;