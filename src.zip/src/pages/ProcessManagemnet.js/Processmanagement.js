

import React, { useState, useEffect } from "react";

import { useLocation } from "react-router-dom";
import Templates from "./Templates/Templates";
import Process from "./Templates/Process/Process";
import Schem from "./Schems/Schem";
import Datacollection from "./DataCollection/Datacollection";

const Processmanagement = () => {
  const location = useLocation();

  // Default tab
  const [activeTab, setActiveTab] = useState("templates");

  // Update tab if coming from Add/Edit page
  useEffect(() => {
    if (location.state?.activeTab) {
      setActiveTab(location.state.activeTab);
    }
  }, [location.state]);

  const handleTabClick = (tab, route) => {
    setActiveTab(tab);
    console.log("Navigate to:", route);
  };

  return (
    <div className="w-full flex justify-center">
      <div className="w-full">
        <h2 className="text-xl font-semibold text-darkblue1 text-center mb-2">
         Process Management System
        </h2>

        {/* Tabs */}
        <div className="w-full grid grid-cols-4 divide-x divide-black/30 border border-black/30 overflow-hidden mb-2">
          <button
            onClick={() => handleTabClick("templates", "")}
            className={`py-2 font-medium text-xs transition ${
              activeTab === "templates"
                ? "bg-DustyBlue1 text-white"
                : "bg-white text-black"
            }`}
          >
Templates
          </button>

          <button
            onClick={() => handleTabClick("process", "")}
            className={`py-2 font-medium text-xs transition ${
              activeTab === "process"
                ? "bg-DustyBlue1 text-white"
                : "bg-white text-black"
            }`}
          >
         Process
          </button>

          

          <button
            onClick={() => handleTabClick("schems", "")}
            className={`py-2 font-medium text-xs transition ${
              activeTab === "schems"
                ? "bg-DustyBlue1 text-white"
                : "bg-white text-black"
            }`}
          >
           Schems/Policies
          </button>

          <button
            onClick={() => handleTabClick("dataCollection", "")}
            className={`py-2 font-medium text-xs transition ${
              activeTab === "dataCollection"
                ? "bg-DustyBlue1 text-white"
                : "bg-white text-black"
            }`}
          >
           Data Collection
          </button>
        </div>

        {/* Tab Content */}
        <div className="">
          {activeTab === "templates" && <Templates />}
          {activeTab === "process" && <Process />} 
          {activeTab === "schems" && <Schem/>}
          {activeTab === "dataCollection" && <Datacollection />}
        </div>
      </div>
    </div>
  );
};

export default Processmanagement;
