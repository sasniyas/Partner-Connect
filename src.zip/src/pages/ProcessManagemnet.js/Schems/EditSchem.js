import React, { useState, useRef, useEffect } from "react";
import { Upload } from "lucide-react";
import { toast } from "react-toastify";
import StyledSelectField from "../../../Components/StyledSelectField";
import StyledDateField from "../../../Components/StyledDatefield";
import {
  updateProcessManagementPolicy,
  extractFileName,
} from "../../../services/processManagement/processManagementPolicy.service";
import { getAllDepartments } from "../../../services/masterOthers/department.service";

const EditSchem = ({ onClose, onSave, policy, departments: propDepartments }) => {
  const [formData, setFormData] = useState({
    id: "",
    policyNo: "",
    schemePolicy: "",
    department: "",
    departmentId: "",
    description: "",
    effectiveDate: "",
    validTill: "",
    templateFile: null,
    existingFile: "",
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [departments, setDepartments] = useState([]);
  const [isDepartmentsLoading, setIsDepartmentsLoading] = useState(false);

  const [dropdowns, setDropdowns] = useState({ department: false });
  const refs = { department: useRef(null) };

  useEffect(() => {
    if (propDepartments && propDepartments.length > 0) {
      setDepartments(propDepartments);
    } else {
      fetchDepartments();
    }
  }, [propDepartments]);

  const fetchDepartments = async () => {
    setIsDepartmentsLoading(true);
    try {
      const data = await getAllDepartments();
      const activeDepartments = data.filter((dept) => dept.isActive === 1);
      setDepartments(activeDepartments);
    } catch (error) {
      console.error("Error fetching departments:", error);
      toast.error("Failed to load departments");
    } finally {
      setIsDepartmentsLoading(false);
    }
  };

  const departmentOptions = departments.map((dept) => ({
    label: dept.name || dept.department_name,
    value: String(dept.id),
  }));

  useEffect(() => {
    if (policy) {
      const dept = departmentOptions.find(
        (opt) => opt.value === String(policy.departmentId)
      );

      setFormData({
        id: policy.id,
        policyNo: policy.policyNo || "",
        schemePolicy: policy.schemeName || "",
        department: dept?.label || policy.department || "",
        departmentId: String(policy.departmentId) || "",
        description: policy.description || "",
        effectiveDate: policy.effectiveDate || "",
        validTill: policy.validTill || "",
        templateFile: null,
        existingFile: policy.templateFile || "",
      });
    }
  }, [policy, departments]);

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const handleDepartmentChange = (label) => {
    const selected = departmentOptions.find((opt) => opt.label === label);
    setFormData({
      ...formData,
      department: selected?.label || "",
      departmentId: selected?.value || "",
    });
    setErrors((prev) => ({ ...prev, department: "" }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const validTypes = [
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ];

    if (!validTypes.includes(file.type)) {
      toast.error("Only PDF, DOCX, or XLSX files are allowed.");
      return;
    }

    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      toast.error("File size must be less than 10MB.");
      return;
    }

    handleChange("templateFile", file);
  };

  const handleSave = async () => {
    const newErrors = {};

    if (!formData.policyNo.trim()) newErrors.policyNo = "Policy No. is required";
    if (!formData.schemePolicy.trim()) newErrors.schemePolicy = "Schemes/Policy is required";
    if (!formData.departmentId) newErrors.department = "Department is required";
    if (!formData.description.trim()) newErrors.description = "Description is required";
    if (!formData.effectiveDate) newErrors.effectiveDate = "Effective Date is required";
    if (!formData.validTill) newErrors.validTill = "Valid Till date is required";

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      return;
    }

    setIsLoading(true);

    try {
      const policyData = {
        id: formData.id,
        process_no: formData.policyNo.trim(),
        policy: formData.schemePolicy.trim(),
        department_id: parseInt(formData.departmentId),
        effective_date: formData.effectiveDate,
        description: formData.description.trim(),
        valid_till: formData.validTill,
      };

      await updateProcessManagementPolicy(policyData, formData.templateFile);
      toast.success("Policy updated successfully!");
      onSave();
      onClose();
    } catch (error) {
      console.error("Error updating policy:", error);
      toast.error(error.message || "Failed to update policy");
    } finally {
      setIsLoading(false);
    }
  };

  const openExistingFile = () => {
    if (formData.existingFile) {
      window.open(formData.existingFile, "_blank");
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
      <div className="bg-white p-6 shadow-md w-full max-w-3xl relative">
        <button
          onClick={onClose}
          disabled={isLoading}
          className="absolute top-3 right-3 p-1 text-gray-500 hover:text-black disabled:opacity-50"
        >
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
            alt="close"
            className="w-4 h-4"
          />
        </button>

        <h2 className="text-base text-MediumGrey font-semibold mb-4 text-center">
          Edit Policy
        </h2>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Policy No. <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              placeholder="Enter Policy Number"
              value={formData.policyNo}
              onChange={(e) => handleChange("policyNo", e.target.value)}
              disabled={isLoading}
              className={`border text-xs px-4 py-1.5 w-full ${
                errors.policyNo ? "border-red1" : "border-black/30"
              } disabled:bg-gray-100`}
            />
            {errors.policyNo && <span className="text-red1 text-xs">{errors.policyNo}</span>}
          </div>

          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Schemes/Policy <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              placeholder="Enter Schemes/Policy"
              value={formData.schemePolicy}
              onChange={(e) => handleChange("schemePolicy", e.target.value)}
              disabled={isLoading}
              className={`border text-xs px-4 py-1.5 w-full ${
                errors.schemePolicy ? "border-red1" : "border-black/30"
              } disabled:bg-gray-100`}
            />
            {errors.schemePolicy && (
              <span className="text-red1 text-xs">{errors.schemePolicy}</span>
            )}
          </div>

          <StyledSelectField
            label="Department"
            placeholder={isDepartmentsLoading ? "Loading..." : "Select Department"}
            value={formData.department}
            setValue={handleDepartmentChange}
            options={departmentOptions.map((opt) => opt.label)}
            dropdownOpen={dropdowns.department}
            setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, department: val }))}
            dropdownRef={refs.department}
            error={errors.department}
            required
            disabled={isLoading || isDepartmentsLoading}
          />

          <div className="mt-1">
            <StyledDateField
              label="Effective Date"
              value={formData.effectiveDate}
              setValue={(val) => handleChange("effectiveDate", val)}
              error={errors.effectiveDate}
              required
              disabled={isLoading}
            />
          </div>

          <div className="col-span-2">
            <label className="text-xs font-medium text-black mb-2 block">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              placeholder="Enter Description"
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              disabled={isLoading}
              className={`border text-xs px-4 py-2 resize-none h-28 w-full ${
                errors.description ? "border-red1" : "border-black/30"
              } disabled:bg-gray-100`}
            />
            {errors.description && (
              <span className="text-red1 text-xs">{errors.description}</span>
            )}
          </div>

          <div className="mt-1">
            <StyledDateField
              label="Valid Till"
              value={formData.validTill}
              setValue={(val) => handleChange("validTill", val)}
              error={errors.validTill}
              required
              disabled={isLoading}
            />
          </div>

          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Template File
            </label>
            <label
              htmlFor="template-upload-edit"
              className={`relative cursor-pointer border border-black/30 flex items-center gap-3 px-3 py-1.5 text-black text-xs hover:bg-gray-50 ${
                isLoading ? "opacity-50 cursor-not-allowed" : ""
              }`}
            >
              {formData.templateFile ? (
                <span className="truncate text-green-600">
                  {formData.templateFile.name} (New)
                </span>
              ) : formData.existingFile ? (
                <span className="truncate text-blue-600">
                  {extractFileName(formData.existingFile)}
                </span>
              ) : (
                <span className="truncate text-gray-400">
                  Choose a file (pdf, docx, xlsx - max 10MB)
                </span>
              )}
              <Upload size={16} className="ml-auto text-gray-400" />
              <input
                type="file"
                id="template-upload-edit"
                accept=".pdf,.docx,.xlsx"
                className="absolute inset-0 opacity-0 cursor-pointer"
                disabled={isLoading}
                onChange={handleFileChange}
              />
            </label>
            {formData.existingFile && !formData.templateFile && (
              <button
                type="button"
                onClick={openExistingFile}
                className="text-blue-600 text-xs hover:underline mt-1 inline-block"
              >
                View current file
              </button>
            )}
          </div>
        </div>

        <div className="flex justify-center mt-6">
          <button
            onClick={handleSave}
            disabled={isLoading}
            className="bg-darkblue1 text-white px-8 py-1 text-xs hover:bg-white hover:text-darkblue1 border border-darkblue1 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {isLoading && (
              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
            )}
            {isLoading ? "Updating..." : "Update"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditSchem;