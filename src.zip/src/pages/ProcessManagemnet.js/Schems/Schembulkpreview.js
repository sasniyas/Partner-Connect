"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import {
  bulkAddProcessManagementPolicies,
  getAllProcessManagementPolicies,
} from "../../../services/processManagement/processManagementPolicy.service";
import { getAllDepartments } from "../../../services/masterOthers/department.service";

function Schembulkpreview() {
  const location = useLocation();
  const navigate = useNavigate();

  const [rows, setRows] = useState(location.state?.rows || []);
  const [fileName, setFileName] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [duplicateInfo, setDuplicateInfo] = useState(null);

  // Departments from API
  const [departments, setDepartments] = useState([]);
  const [isDepartmentsLoading, setIsDepartmentsLoading] = useState(false);

  // Dropdown states
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0, width: 0 });
  const [dropdownSearch, setDropdownSearch] = useState("");

  // Refs
  const dropdownButtonRefs = useRef({});
  const dropdownMenuRef = useRef(null);
  const tableContainerRef = useRef(null);

  // =============================== FETCH DEPARTMENTS ===============================
  useEffect(() => {
    fetchDepartments();
  }, []);

  const fetchDepartments = async () => {
    setIsDepartmentsLoading(true);
    try {
      const data = await getAllDepartments();
      const activeDepartments = data.filter((dept) => dept.isActive === 1);
      const formattedDepartments = activeDepartments.map((dept) => ({
        id: dept.id,
        label: dept.name || dept.department_name,
        value: String(dept.id),
      }));
      setDepartments(formattedDepartments);
    } catch (error) {
      console.error("Error fetching departments:", error);
      toast.error("Failed to load departments");
    } finally {
      setIsDepartmentsLoading(false);
    }
  };

  // =============================== BACK ===============================
  const handleBack = () => {
    navigate("/processmangement", { state: { activeTab: "schems" } });
  };

  // =============================== VALIDATE ROW ===============================
  const validateRow = (row) => {
    const errors = [];
    if (!row.process_no || !row.process_no.trim()) errors.push("Policy No. required");
    if (!row.policy || !row.policy.trim()) errors.push("Schemes/Policy required");
    if (!row.department_id) errors.push("Department required");
    if (!row.effective_date) errors.push("Effective Date required");
    if (!row.description || !row.description.trim()) errors.push("Description required");
    if (!row.valid_till) errors.push("Valid Till required");
    return {
      hasError: errors.length > 0,
      errors,
    };
  };

  // =============================== CHECK DUPLICATES ===============================
  const checkDuplicates = async () => {
    if (rows.length === 0) {
      toast.error("No data to check. Please upload a file first.");
      return;
    }

    setIsChecking(true);
    setDuplicateInfo(null);

    try {
      const existingData = await getAllProcessManagementPolicies();

      // Create Set of existing policy numbers (case-insensitive)
      const existingPolicyNos = new Set();
      if (Array.isArray(existingData)) {
        existingData.forEach((item) => {
          existingPolicyNos.add(String(item.process_no || "").toLowerCase().trim());
        });
      }

      // Also check for duplicates within the uploaded file itself
      const seenInFile = new Set();

      const updatedRows = rows.map((row) => {
        const policyNoKey = (row.process_no || "").toLowerCase().trim();

        let isDuplicate = false;
        let duplicateReason = "";

        if (row.hasError) {
          return row;
        }

        // Check if exists in database
        if (existingPolicyNos.has(policyNoKey)) {
          isDuplicate = true;
          duplicateReason = "Policy No. already exists in database";
        }

        // Check if duplicate within file
        if (seenInFile.has(policyNoKey) && !isDuplicate) {
          isDuplicate = true;
          duplicateReason = "Duplicate Policy No. within file";
        }

        seenInFile.add(policyNoKey);

        return {
          ...row,
          isDuplicate,
          duplicateReason,
        };
      });

      setRows(updatedRows);

      const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

      if (duplicateCount > 0) {
        setDuplicateInfo({
          count: duplicateCount,
          message: `${duplicateCount} duplicate(s) found! These will be skipped during save.`,
          type: "warning",
        });
        toast.warning(`${duplicateCount} duplicate record(s) found!`);
      } else {
        setDuplicateInfo({
          count: 0,
          message: "No duplicates found. All records are unique.",
          type: "success",
        });
        toast.success("No duplicates found!");
      }
    } catch (error) {
      console.error("Error checking duplicates:", error);
      toast.error("Failed to check duplicates");
    } finally {
      setIsChecking(false);
    }
  };

  // =============================== FILE UPLOAD ===============================
  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];

      let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });

      json = json.filter((row) => Object.values(row).some((cell) => cell !== ""));

      const finalRows = json.map((row) => {
        const policyNo = String(row["Policy No."] || row["process_no"] || "").trim();
        const schemeName = String(row["Schemes/Policy"] || row["policy"] || "").trim();
        const departmentId = String(row["Department ID"] || row["department_id"] || "").trim();
        const departmentName = String(row["Department"] || row["department"] || "").trim();
        const effectiveDate = String(
          row["Effective Date (YYYY-MM-DD)"] || row["Effective Date"] || row["effective_date"] || ""
        ).trim();
        const description = String(row["Description"] || row["description"] || "").trim();
        const validTill = String(
          row["Valid Till (YYYY-MM-DD)"] || row["Valid Till"] || row["valid_till"] || ""
        ).trim();

        // Find department ID from name if not provided
        let deptId = departmentId;
        let deptName = departmentName;

        if (!deptId && departmentName) {
          const dept = departments.find(
            (d) => d.label.toLowerCase() === departmentName.toLowerCase()
          );
          deptId = dept?.value || "";
          deptName = dept?.label || departmentName;
        } else if (deptId) {
          const dept = departments.find((d) => d.value === deptId);
          deptName = dept?.label || "";
        }

        const rowData = {
          process_no: policyNo,
          policy: schemeName,
          department_id: deptId,
          department_name: deptName,
          effective_date: effectiveDate,
          description: description,
          valid_till: validTill,
          isDuplicate: false,
          duplicateReason: "",
        };

        const validation = validateRow(rowData);
        return {
          ...rowData,
          hasError: validation.hasError,
          errors: validation.errors,
        };
      });

      setRows(finalRows);
      toast.success(`${finalRows.length} row(s) loaded successfully`);
    };

    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  // =============================== EDIT CELL ===============================
  const handleCellChange = (rowIdx, key, value) => {
    const updated = [...rows];
    updated[rowIdx][key] = value;

    const validation = validateRow(updated[rowIdx]);
    updated[rowIdx].hasError = validation.hasError;
    updated[rowIdx].errors = validation.errors;

    updated[rowIdx].isDuplicate = false;
    updated[rowIdx].duplicateReason = "";

    setRows(updated);
    setDuplicateInfo(null);
  };

  // =============================== DELETE ROW ===============================
  const handleDeleteRow = (rowIdx) => {
    const updated = rows.filter((_, idx) => idx !== rowIdx);
    setRows(updated);
    setDuplicateInfo(null);
    closeDropdown();
  };

  // =============================== DROPDOWN HANDLERS ===============================
  const closeDropdown = useCallback(() => {
    setActiveDropdown(null);
    setDropdownSearch("");
  }, []);

  const handleOpenDropdown = (rowIndex, column) => {
    if (activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column) {
      closeDropdown();
      return;
    }

    const refKey = `${rowIndex}-${column}`;
    const buttonEl = dropdownButtonRefs.current[refKey];
    if (buttonEl) {
      const rect = buttonEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const dropdownHeight = 200;

      const spaceBelow = viewportHeight - rect.bottom;
      const openUpward = spaceBelow < dropdownHeight && rect.top > dropdownHeight;

      setDropdownPosition({
        top: openUpward ? rect.top - dropdownHeight : rect.bottom + 2,
        left: rect.left,
        width: Math.max(rect.width, 180),
      });
    }
    setActiveDropdown({ rowIndex, column });
    setDropdownSearch("");
  };

  const handleSelectOption = (rowIdx, column, value, label) => {
    const updated = [...rows];
    updated[rowIdx].department_id = value;
    updated[rowIdx].department_name = label;

    const validation = validateRow(updated[rowIdx]);
    updated[rowIdx].hasError = validation.hasError;
    updated[rowIdx].errors = validation.errors;
    updated[rowIdx].isDuplicate = false;
    updated[rowIdx].duplicateReason = "";

    setRows(updated);
    setDuplicateInfo(null);
    closeDropdown();
  };

  // =============================== SAVE ===============================
  const handleSave = async () => {
    const hasError = rows.some((r) => r.hasError);

    if (hasError) {
      toast.error("Please fix all errors before saving. All fields are mandatory.");
      return;
    }

    if (rows.length === 0) {
      toast.error("No data to save. Please upload a file first.");
      return;
    }

    const rowsToSave = rows.filter((r) => !r.isDuplicate);

    if (rowsToSave.length === 0) {
      toast.error("All records are duplicates. Nothing to save.");
      return;
    }

    setIsSaving(true);

    try {
      const payload = rowsToSave.map((r) => ({
        process_no: r.process_no.trim(),
        policy: r.policy.trim(),
        department_id: parseInt(r.department_id),
        effective_date: r.effective_date,
        description: r.description.trim(),
        valid_till: r.valid_till,
      }));

      console.log("Sending bulk upload payload:", payload);

      const response = await bulkAddProcessManagementPolicies(payload);

      if (response.status) {
        const insertedCount = response.data?.inserted || payload.length;
        const invalidCount = response.data?.invalid || 0;

        if (invalidCount > 0) {
          toast.success(
            `${insertedCount} record(s) added successfully! ${invalidCount} were skipped.`,
            { autoClose: 5000 }
          );
        } else {
          toast.success(`${insertedCount} record(s) added successfully!`);
        }

        setTimeout(() => {
          navigate("/processmangement", { state: { activeTab: "schems" } });
        }, 1500);
      } else {
        toast.error(response.message || "Failed to upload policies");
      }
    } catch (error) {
      console.error("Bulk upload error:", error);
      toast.error(error.message || "Failed to upload policies");
    } finally {
      setIsSaving(false);
    }
  };

  // =============================== CLEAR ALL ===============================
  const handleClearAll = () => {
    setRows([]);
    setFileName("");
    setDuplicateInfo(null);
    closeDropdown();
  };

  // =============================== CLOSE DROPDOWN ON OUTSIDE CLICK ===============================
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return;
      }

      const clickedOnButton = Object.values(dropdownButtonRefs.current).some(
        (ref) => ref?.contains(e.target)
      );

      if (!clickedOnButton) {
        closeDropdown();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [closeDropdown]);

  // =============================== CLOSE DROPDOWN ON SCROLL ===============================
  useEffect(() => {
    const handleTableScroll = () => {
      if (activeDropdown !== null) {
        closeDropdown();
      }
    };

    const tableContainer = tableContainerRef.current;
    if (tableContainer) {
      tableContainer.addEventListener("scroll", handleTableScroll);
    }

    return () => {
      if (tableContainer) {
        tableContainer.removeEventListener("scroll", handleTableScroll);
      }
    };
  }, [activeDropdown, closeDropdown]);

  // =============================== GET DROPDOWN OPTIONS ===============================
  const getDropdownOptions = () => {
    if (!activeDropdown) return [];

    let options = departments.map((dept) => ({ id: dept.value, label: dept.label }));

    if (dropdownSearch) {
      options = options.filter((opt) =>
        opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
      );
    }

    return options;
  };

  // =============================== RENDER DROPDOWN BUTTON ===============================
  const renderDropdownButton = (row, rowIndex) => {
    const isInvalid = !row.department_id;
    const displayValue = row.department_name || "";
    const placeholder = isDepartmentsLoading ? "Loading..." : "Select Department";
    const isOpen = activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === "department";
    const refKey = `${rowIndex}-department`;

    return (
      <div
        ref={(el) => (dropdownButtonRefs.current[refKey] = el)}
        className={`flex justify-between items-center px-2 py-1 border text-xs min-h-[26px] cursor-pointer ${
          isInvalid
            ? "border-red-500 bg-red-50"
            : row.isDuplicate
            ? "border-yellow-500 bg-yellow-50"
            : "border-gray-300 bg-white hover:border-gray-400"
        }`}
        onClick={() => !isDepartmentsLoading && handleOpenDropdown(rowIndex, "department")}
      >
        <span className={`flex-1 truncate ${displayValue ? "text-gray-800" : "text-gray-400"}`}>
          {displayValue || placeholder}
        </span>
        {isOpen ? (
          <ChevronUp className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1" />
        ) : (
          <ChevronDown className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1" />
        )}
      </div>
    );
  };

  // =============================== UI ===============================
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex-1 flex justify-center`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Back */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer hover:scale-110 text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">
              Policies Bulk Upload
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[8%] ml-7 mb-2"></div>

          {/* Upload Section */}
          <div className="mb-4 flex flex-wrap items-center gap-2 w-full">
            <div className="flex-1 min-w-[200px] max-w-md flex items-center border border-black/30 px-3 py-1.5 bg-white text-xs">
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/bulkupload.png"
                className="w-4 h-4 mr-2"
                alt="bulk"
              />
              <span className="text-xs text-gray-700 truncate">
                {fileName || "No file selected"}
              </span>
              <input
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleBulkUpload}
                id="bulk-upload-input"
              />
            </div>

            <label
              htmlFor="bulk-upload-input"
              className="px-3 py-1.5 bg-darkblue1 text-white text-xs cursor-pointer hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition"
            >
              Browse
            </label>

            {rows.length > 0 && (
              <>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 bg-gray-500 text-white text-xs hover:bg-gray-600 transition"
                >
                  Clear
                </button>

                <button
                  onClick={checkDuplicates}
                  disabled={isChecking || rows.length === 0 || rows.some((r) => r.hasError)}
                  className="px-3 py-1.5 bg-yellow-600 text-white text-xs hover:bg-yellow-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  {isChecking && (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  )}
                  {isChecking ? "Checking..." : "Check Duplicates"}
                </button>
              </>
            )}

            <button
              onClick={handleSave}
              disabled={isSaving || rows.length === 0 || rows.some((r) => r.hasError)}
              className="px-4 py-1.5 bg-darkblue1 text-white text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              {isSaving && (
                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
              )}
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>

          {/* Duplicate Info Banner */}
          {duplicateInfo && (
            <div
              className={`mb-2 p-2 border text-xs flex items-center justify-between ${
                duplicateInfo.type === "warning"
                  ? "bg-yellow-50 border-yellow-300 text-yellow-700"
                  : "bg-green-50 border-green-300 text-green-700"
              }`}
            >
              <span>
                <span className="font-medium">
                  {duplicateInfo.type === "warning" ? "⚠️ " : "✅ "}
                </span>
                {duplicateInfo.message}
              </span>
              <button
                onClick={() => setDuplicateInfo(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
          )}

          {/* Error Summary */}
          {rows.length > 0 && rows.some((r) => r.hasError) && (
            <div className="mb-2 p-2 bg-red-50 border border-red-200 text-red-600 text-xs">
              <span className="font-medium">
                ⚠ {rows.filter((r) => r.hasError).length} row(s) have validation errors.
              </span>
              <span className="ml-2">Please fix all mandatory fields (highlighted in red).</span>
            </div>
          )}

          {/* Preview Table */}
          {rows.length > 0 ? (
            <div className="overflow-auto border border-Dustyblue mb-2 bg-white shadow-md">
              <div
                ref={tableContainerRef}
                className="overflow-y-auto max-h-[400px] relative"
              >
                <table className="w-full text-sm bg-white border-collapse">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                    <tr>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[5%]">
                        #
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[12%]">
                        Policy No. <span className="text-red-300">*</span>
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[15%]">
                        Schemes/Policy <span className="text-red-300">*</span>
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[15%]">
                        Department <span className="text-red-300">*</span>
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[12%]">
                        Effective Date <span className="text-red-300">*</span>
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[18%]">
                        Description <span className="text-red-300">*</span>
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[10%]">
                        Valid Till <span className="text-red-300">*</span>
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-center w-[8%]">
                        Status
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium text-center w-[5%]">
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((row, i) => (
                      <tr
                        key={i}
                        className={`text-xs hover:bg-lightBlue/50 ${
                          row.hasError ? "bg-red-50" : row.isDuplicate ? "bg-yellow-50" : ""
                        }`}
                      >
                        {/* Row Number */}
                        <td className="px-3 py-2 border border-grey2 border-l-0 text-center text-gray-500">
                          {i + 1}
                        </td>

                        {/* Policy No. */}
                        <td className="px-3 py-2 border border-grey2">
                          <input
                            type="text"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.process_no
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.process_no}
                            placeholder="Enter Policy No."
                            onChange={(e) => handleCellChange(i, "process_no", e.target.value)}
                          />
                        </td>

                        {/* Schemes/Policy */}
                        <td className="px-3 py-2 border border-grey2">
                          <input
                            type="text"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.policy
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.policy}
                            placeholder="Enter Schemes/Policy"
                            onChange={(e) => handleCellChange(i, "policy", e.target.value)}
                          />
                        </td>

                        {/* Department - Custom Dropdown */}
                        <td className="px-3 py-2 border border-grey2">
                          {renderDropdownButton(row, i)}
                        </td>

                        {/* Effective Date */}
                        <td className="px-3 py-2 border border-grey2">
                          <input
                            type="date"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.effective_date
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.effective_date}
                            onChange={(e) => handleCellChange(i, "effective_date", e.target.value)}
                          />
                        </td>

                        {/* Description */}
                        <td className="px-3 py-2 border border-grey2">
                          <input
                            type="text"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.description
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.description}
                            placeholder="Enter Description"
                            onChange={(e) => handleCellChange(i, "description", e.target.value)}
                          />
                        </td>

                        {/* Valid Till */}
                        <td className="px-3 py-2 border border-grey2">
                          <input
                            type="date"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.valid_till
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.valid_till}
                            onChange={(e) => handleCellChange(i, "valid_till", e.target.value)}
                          />
                        </td>

                        {/* Status */}
                        <td className="px-3 py-2 border border-grey2 text-center">
                          {row.hasError ? (
                            <span
                              className="px-2 py-0.5 bg-red-100 text-red-600 text-[10px] rounded-full cursor-help"
                              title={row.errors?.join(", ")}
                            >
                              Invalid
                            </span>
                          ) : row.isDuplicate ? (
                            <span
                              className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full cursor-help"
                              title={row.duplicateReason}
                            >
                              Duplicate
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-green-100 text-green-600 text-[10px] rounded-full">
                              Valid
                            </span>
                          )}
                        </td>

                        {/* Delete Action */}
                        <td className="px-3 py-2 border border-grey2 border-r-0 text-center">
                          <button
                            onClick={() => handleDeleteRow(i)}
                            className="text-red-500 hover:text-red-700 transition"
                            title="Delete Row"
                          >
                            <img
                              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                              className="w-4 h-4 mx-auto"
                              alt="Delete"
                            />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Footer */}
              <div className="px-4 py-2 bg-gray-50 border-t border-grey2 flex flex-wrap justify-between items-center gap-2">
                <span className="text-xs text-gray-600">
                  Total: {rows.length} row(s) |
                  <span className="text-green-600 ml-1">
                    Valid: {rows.filter((r) => !r.hasError && !r.isDuplicate).length}
                  </span>{" "}
                  |
                  <span className="text-yellow-600 ml-1">
                    Duplicates: {rows.filter((r) => r.isDuplicate).length}
                  </span>{" "}
                  |
                  <span className="text-red-600 ml-1">
                    Errors: {rows.filter((r) => r.hasError).length}
                  </span>
                </span>
                <span className="text-xs text-gray-500 italic">
                  💡 Click "Check Duplicates" before saving to identify existing records
                </span>
              </div>
            </div>
          ) : (
            <div className="bg-white shadow-md border border-Dustyblue p-8 text-center">
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/bulkupload.png"
                className="w-12 h-12 mx-auto mb-3 opacity-50"
                alt="upload"
              />
              <p className="text-gray-500 text-sm">
                No data loaded. Please upload an Excel file to preview.
              </p>
              <p className="text-gray-400 text-xs mt-1">Supported formats: .xlsx, .xls</p>
              <p className="text-gray-400 text-xs mt-1">
                Required columns: Policy No., Schemes/Policy, Department ID, Effective Date, Description, Valid Till
              </p>
            </div>
          )}
        </div>
      </div>

      {/* ========== UNIVERSAL CUSTOM DROPDOWN ========== */}
      {activeDropdown !== null && rows[activeDropdown.rowIndex] && (
        <div
          ref={dropdownMenuRef}
          className="fixed border border-gray-300 bg-white z-[9999] shadow-xl rounded overflow-hidden"
          style={{
            top: `${dropdownPosition.top}px`,
            left: `${dropdownPosition.left}px`,
            width: `${dropdownPosition.width}px`,
            minWidth: "180px",
          }}
        >
          {/* Search Input */}
          <div className="p-2 border-b border-gray-200 bg-gray-50">
            <input
              type="text"
              placeholder="Search department..."
              value={dropdownSearch}
              onChange={(e) => setDropdownSearch(e.target.value)}
              className="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:outline-none focus:border-darkblue1"
              autoFocus
            />
          </div>

          {/* Options List */}
          <div className="max-h-[150px] overflow-y-auto">
            {isDepartmentsLoading ? (
              <div className="px-3 py-3 text-xs text-gray-400 text-center">
                Loading departments...
              </div>
            ) : getDropdownOptions().length > 0 ? (
              getDropdownOptions().map((option) => {
                const isSelected = rows[activeDropdown.rowIndex]?.department_id === option.id;

                return (
                  <div
                    key={option.id}
                    className={`flex items-center gap-2 px-3 py-1.5 cursor-pointer text-xs border-b border-gray-100 last:border-b-0 ${
                      isSelected ? "bg-blue-50" : "hover:bg-gray-50"
                    }`}
                    onClick={() =>
                      handleSelectOption(activeDropdown.rowIndex, "department", option.id, option.label)
                    }
                  >
                    <span className={isSelected ? "text-blue-700 font-medium" : ""}>
                      {option.label}
                    </span>
                    {isSelected && <span className="ml-auto text-blue-500">✓</span>}
                  </div>
                );
              })
            ) : (
              <div className="px-3 py-3 text-xs text-gray-400 text-center">No departments found</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default Schembulkpreview;