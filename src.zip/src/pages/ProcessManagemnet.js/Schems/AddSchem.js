import React, { useState, useRef, useEffect } from "react";
import { Upload } from "lucide-react";
import { toast } from "react-toastify";
import StyledSelectField from "../../../Components/StyledSelectField";
import StyledDateField from "../../../Components/StyledDatefield";
import { addProcessManagementPolicy } from "../../../services/processManagement/processManagementPolicy.service";
import { getAllDepartments } from "../../../services/masterOthers/department.service";

const AddSchem = ({ onClose, onSave, departments: propDepartments }) => {
  const [formData, setFormData] = useState({
    policyNo: "",
    schemePolicy: "",
    department: "",
    departmentId: "",
    description: "",
    effectiveDate: "",
    validTill: "",
    templateFile: null,
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [departments, setDepartments] = useState([]);
  const [isDepartmentsLoading, setIsDepartmentsLoading] = useState(false);

  const [dropdowns, setDropdowns] = useState({ department: false });
  const refs = { department: useRef(null) };

  // Fetch departments
  useEffect(() => {
    if (propDepartments && propDepartments.length > 0) {
      setDepartments(propDepartments);
    } else {
      fetchDepartments();
    }
  }, [propDepartments]);

  const fetchDepartments = async () => {
    setIsDepartmentsLoading(true);
    try {
      const data = await getAllDepartments();
      const activeDepartments = data.filter((dept) => dept.isActive === 1);
      setDepartments(activeDepartments);
    } catch (error) {
      console.error("Error fetching departments:", error);
      toast.error("Failed to load departments");
    } finally {
      setIsDepartmentsLoading(false);
    }
  };

  const departmentOptions = departments.map((dept) => ({
    label: dept.name || dept.department_name,
    value: String(dept.id),
  }));

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const handleDepartmentChange = (label) => {
    const selected = departmentOptions.find((opt) => opt.label === label);
    setFormData({
      ...formData,
      department: selected?.label || "",
      departmentId: selected?.value || "",
    });
    setErrors((prev) => ({ ...prev, department: "" }));
  };

  const handleSave = async () => {
    const newErrors = {};

    if (!formData.policyNo.trim()) newErrors.policyNo = "Policy No. is required";
    if (!formData.schemePolicy.trim()) newErrors.schemePolicy = "Schemes/Policy is required";
    if (!formData.departmentId) newErrors.department = "Department is required";
    if (!formData.description.trim()) newErrors.description = "Description is required";
    if (!formData.effectiveDate) newErrors.effectiveDate = "Effective Date is required";
    if (!formData.validTill) newErrors.validTill = "Valid Till date is required";
    if (!formData.templateFile) newErrors.templateFile = "Template File is required";

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      return;
    }

    setIsLoading(true);

    try {
      const policyData = {
        process_no: formData.policyNo.trim(),
        policy: formData.schemePolicy.trim(),
        department_id: parseInt(formData.departmentId),
        effective_date: formData.effectiveDate,
        description: formData.description.trim(),
        valid_till: formData.validTill,
      };

      await addProcessManagementPolicy(policyData, formData.templateFile);
      toast.success("Policy added successfully!");
      onSave();
      onClose();
    } catch (error) {
      console.error("Error adding policy:", error);
      toast.error(error.message || "Failed to add policy");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
      <div className="bg-white p-6 shadow-md w-full max-w-3xl relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          disabled={isLoading}
          className="absolute top-3 right-3 p-1 text-gray-500 hover:text-black disabled:opacity-50"
        >
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
            alt="close"
            className="w-4 h-4"
          />
        </button>

        <h2 className="text-base text-MediumGrey font-semibold mb-4 text-center">
          Add New Policy
        </h2>

        <div className="grid grid-cols-2 gap-4">
          {/* Policy No. */}
          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Policy No. <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              placeholder="Enter Policy Number"
              value={formData.policyNo}
              onChange={(e) => handleChange("policyNo", e.target.value)}
              className={`border text-xs px-4 py-1.5 w-full ${
                errors.policyNo ? "border-red1" : "border-black/30"
              }`}
            />
            {errors.policyNo && <span className="text-red1 text-xs">{errors.policyNo}</span>}
          </div>

          {/* Schemes/Policy */}
          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Schemes/Policy <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              placeholder="Enter Schemes/Policy"
              value={formData.schemePolicy}
              onChange={(e) => handleChange("schemePolicy", e.target.value)}
              className={`border text-xs px-4 py-1.5 w-full ${
                errors.schemePolicy ? "border-red1" : "border-black/30"
              }`}
            />
            {errors.schemePolicy && (
              <span className="text-red1 text-xs">{errors.schemePolicy}</span>
            )}
          </div>

          {/* Department */}
          <StyledSelectField
            label="Department"
            placeholder={isDepartmentsLoading ? "Loading..." : "Select Department"}
            value={formData.department}
            setValue={handleDepartmentChange}
            options={departmentOptions.map((opt) => opt.label)}
            dropdownOpen={dropdowns.department}
            setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, department: val }))}
            dropdownRef={refs.department}
            error={errors.department}
            required
          />

          {/* Effective Date */}
          <div className="mt-1">
            <StyledDateField
              label="Effective Date"
              value={formData.effectiveDate}
              setValue={(val) => handleChange("effectiveDate", val)}
              error={errors.effectiveDate}
              required
            />
          </div>

          {/* Description */}
          <div className="col-span-2">
            <label className="text-xs font-medium text-black mb-2 block">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              placeholder="Enter Description"
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              className={`border text-xs px-4 py-2 resize-none h-28 w-full ${
                errors.description ? "border-red1" : "border-black/30"
              }`}
            />
            {errors.description && (
              <span className="text-red1 text-xs">{errors.description}</span>
            )}
          </div>

          {/* Valid Till */}
          <div className="mt-1">
            <StyledDateField
              label="Valid Till"
              value={formData.validTill}
              setValue={(val) => handleChange("validTill", val)}
              error={errors.validTill}
              required
            />
          </div>

          {/* Template File */}
          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Template File <span className="text-red-500">*</span>
            </label>
            <label
              htmlFor="template-upload"
              className={`relative cursor-pointer border border-black/30 flex items-center gap-3 px-3 py-1.5 text-black text-xs hover:bg-gray-50 ${
                errors.templateFile ? "border-red1" : ""
              }`}
            >
              {formData.templateFile ? (
                <span className="truncate">{formData.templateFile.name}</span>
              ) : (
                <span className="truncate">Choose a file (pdf, docx, xlsx - max 10MB)</span>
              )}
              <Upload size={16} className="ml-auto text-gray-400" />
              <input
                type="file"
                id="template-upload"
                accept=".pdf, .docx, .xlsx"
                className="absolute inset-0 opacity-0 cursor-pointer"
                onChange={(e) => {
                  const file = e.target.files[0];
                  if (!file) return;

                  const validTypes = [
                    "application/pdf",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                  ];
                  if (!validTypes.includes(file.type)) {
                    toast.error("Only PDF, DOCX, or XLSX files are allowed.");
                    return;
                  }

                  const maxSize = 10 * 1024 * 1024;
                  if (file.size > maxSize) {
                    toast.error("File size must be less than 10MB.");
                    return;
                  }

                  handleChange("templateFile", file);
                }}
              />
            </label>
            {errors.templateFile && (
              <span className="text-red1 text-xs mt-1">{errors.templateFile}</span>
            )}
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-center mt-6">
          <button
            onClick={handleSave}
            disabled={isLoading}
            className="bg-darkblue1 text-white px-8 py-1 text-xs hover:bg-white hover:text-darkblue1 border border-darkblue1 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {isLoading && (
              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
            )}
            {isLoading ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddSchem;