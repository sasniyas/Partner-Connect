"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";

const SchemDownload= () => {
  const [tableData, setTableData] = useState([]);
  const [menuOpen, setMenuOpen] = useState(false);

  // ✅ Receive data from parent window
  useEffect(() => {
    window.opener?.postMessage({ type: "READY_FOR_DATA" }, "*");

    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // ✅ Excel download
 const handleDownloadExcel = () => {
  if (!tableData.length) return;

  // Map tableData to Excel-friendly format
  const excelData = tableData.map((row, index) => ({
  "Sl. No": index + 1,
  "Policy No.": row.policyNo,
  "Schemes/Policy": row.schemeName, // <-- use schemeName instead of templateName
  "Department": row.department,
  "Description": row.description,
  "Uploaded By": row.uploadedBy,
  "Uploaded Date": row.uploadedDate,
  "Effective Date": row.effectiveDate,
  "Valid Till": row.validTill,
  "Active": row.active,
}));


  // Convert JSON to worksheet
  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // Create workbook and append worksheet
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Schems_Policies");

  // Save Excel file
  XLSX.writeFile(workbook, "Schems_Policies.xlsx");
};


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">
          Schems/Policies
          </h2>

          <button
            onClick={handleDownloadExcel}
            className="bg-darkblue1 text-white text-sm font-medium px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          >
            Download
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-Dustyblue text-white text-left text-xs sticky top-0 z-10">
  <tr>
    {[
      { name: "Policy No.", width: "w-[10%]" },
      { name: "Schemes/Policy", width: "w-[15%]" },
      { name: "Department", width: "w-[10%]" },
      { name: "Description", width: "w-[25%]" },
      { name: "Uploaded By", width: "w-[10%]" },
      { name: "Uploaded Date", width: "w-[10%]" },
      { name: "Effective Date", width: "w-[10%]" },
      { name: "Valid Till", width: "w-[10%]" },
     
    ].map((col, idx, arr) => (
      <th
        key={col.name}
        className={`px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 ${idx === arr.length - 1 ? "border-r-0" : ""} ${col.width}`}
      >
        {col.name}
      </th>
    ))}
  </tr>
</thead>

            <tbody>
              {tableData.length ? (
                tableData.map((item, index) => (
                  <tr key={index} className="hover:bg-lightBlue/50 text-xs">
                    <td className="px-4 py-1 border border-grey2">{item.policyNo}</td>
                      <td className="px-4 py-1 border border-grey2">{item.schemeName}</td>
                      <td className="px-4 py-1 border border-grey2">{item.department}</td>
                      <td className="px-4 py-1 border border-grey2">{item.description}</td>
                      <td className="px-4 py-1 border border-grey2">{item.uploadedBy}</td>
                      <td className="px-4 py-1 border border-grey2">{item.uploadedDate}</td>
                      <td className="px-4 py-1 border border-grey2">{item.effectiveDate}</td>
                      <td className="px-4 py-1 border border-grey2">{item.validTill}</td>  
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SchemDownload;
