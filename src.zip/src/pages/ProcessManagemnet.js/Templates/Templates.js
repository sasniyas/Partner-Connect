"use client"

import { useState, useRef, useEffect } from "react"
import Searchinput from "../../../Components/Searchinput"
import Filter from "../../../Components/Filter"
import { MoreVertical } from "lucide-react"
import { useNavigate, useLocation } from "react-router-dom"
import { toast } from "react-toastify"
import DeleteModal from "../../../Components/DeleteModal"
import ActivateStatus from "../../../Components/ActivateStatus"
import DeactivateStatus from "../../../Components/DeactivateStatus"
import ExcelJS from "exceljs"
import { saveAs } from "file-saver"
import * as XLSX from "xlsx"
import AddTemplatePopup from "./AddTemplate"
import EditTemplate from "./EditTemplate"

// Import service functions
import {
  getAllProcessManagementTemplates,
  deleteProcessManagementTemplate,
  toggleProcessManagementTemplateStatus,
  transformTemplateData,
} from "../../../services/processManagement/processManagementTemplate.service"

const Templates = () => {
  const location = useLocation()
  const navigate = useNavigate()

  // Loading states
  const [isLoading, setIsLoading] = useState(false)
  const [statusLoading, setStatusLoading] = useState(false)
  const [deleteLoading, setDeleteLoading] = useState(false)

  // Filters
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTemplate, setSelectedTemplate] = useState("")
  const [selectedDepartment, setSelectedDepartment] = useState("")
  const [selectedUploadedBy, setSelectedUploadedBy] = useState("")

  // Table data
  const [tableData, setTableData] = useState([])

  // Selected row for modals
  const [selectedRow, setSelectedRow] = useState(null)
  const [deleteItem, setDeleteItem] = useState(null)

  // Modals
  const [showActivateModal, setShowActivateModal] = useState(false)
  const [showDeactivateModal, setShowDeactivateModal] = useState(false)
  const [isAddPopupOpen, setIsAddPopupOpen] = useState(false)
  const [editingTemplate, setEditingTemplate] = useState(null)

  // Dropdowns
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const [dropdownId, setDropdownId] = useState(null)

  // Refs
  const addUserButtonRef = useRef(null)
  const addUserDropdownRef = useRef(null)
  const dropdownRefs = useRef({})
  const tableContainerRef = useRef(null)
  const fileInputRef = useRef(null)
  const [addUserButtonWidth, setAddUserButtonWidth] = useState(0)

  // Dynamic filter options from data
  const templateOptions = [...new Set(tableData.map(item => item.templateName))].filter(Boolean).sort()
  const departmentOptions = [...new Set(tableData.map(item => item.department))].filter(Boolean).sort()
  const uploadedByOptions = [...new Set(tableData.map(item => item.uploadedBy))].filter(Boolean).sort()

  // ============================================
  // FETCH DATA
  // ============================================
  useEffect(() => {
    fetchTemplates()
  }, [])

  const fetchTemplates = async () => {
    setIsLoading(true)
    try {
      const response = await getAllProcessManagementTemplates()
      const transformedData = transformTemplateData(response)
      setTableData(transformedData)
    } catch (error) {
      console.error("Error fetching templates:", error)
      toast.error(error.message || "Failed to fetch templates")
    } finally {
      setIsLoading(false)
    }
  }

  // ============================================
  // FILTER DATA
  // ============================================
  const filteredItems = tableData.filter((item) => {
    const searchLower = searchTerm.toLowerCase()

    const matchesSearch =
      item.templateName?.toLowerCase().includes(searchLower) ||
      item.description?.toLowerCase().includes(searchLower) ||
      item.uploadedBy?.toLowerCase().includes(searchLower) ||
      item.department?.toLowerCase().includes(searchLower)

    const matchesTemplate =
      selectedTemplate?.length > 0
        ? selectedTemplate.includes(item.templateName)
        : true

    const matchesDepartment =
      selectedDepartment?.length > 0
        ? selectedDepartment.includes(item.department)
        : true

    const matchesUploadedBy =
      selectedUploadedBy?.length > 0
        ? selectedUploadedBy.includes(item.uploadedBy)
        : true

    return matchesSearch && matchesTemplate && matchesDepartment && matchesUploadedBy
  })

  // ============================================
  // EFFECTS
  // ============================================
  useEffect(() => {
    if (addUserButtonRef.current) {
      setAddUserButtonWidth(addUserButtonRef.current.offsetWidth)
    }
  }, [])

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        addUserDropdownRef.current &&
        !addUserDropdownRef.current.contains(e.target) &&
        addUserButtonRef.current &&
        !addUserButtonRef.current.contains(e.target)
      ) {
        setIsAddUserOpen(false)
      }

      const isClickInsideRowDropdown = Object.values(dropdownRefs.current).some(
        (ref) => ref && ref.contains(e.target)
      )
      if (!isClickInsideRowDropdown) {
        setDropdownId(null)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // ============================================
  // HANDLERS
  // ============================================
  const handleSaveTemplate = async () => {
    await fetchTemplates() // Refresh data after save
    setIsAddPopupOpen(false)
    toast.success("Template added successfully!")
  }

  const handleEdit = (item) => {
    setEditingTemplate(item)
    setDropdownId(null)
  }

  const handleUpdateTemplate = async () => {
    await fetchTemplates() // Refresh data after update
    setEditingTemplate(null)
    toast.success("Template updated successfully!")
  }

  const handleDeleteClick = (item) => {
    setDeleteItem(item)
    setSelectedRow(item.id)
    setDropdownId(null)
  }

  const handleConfirmDelete = async () => {
    if (!selectedRow) return

    setDeleteLoading(true)
    try {
      await deleteProcessManagementTemplate(selectedRow)
      setTableData((prev) => prev.filter((row) => row.id !== selectedRow))
      toast.success("Template deleted successfully!")
    } catch (error) {
      console.error("Error deleting template:", error)
      toast.error(error.message || "Failed to delete template")
    } finally {
      setDeleteItem(null)
      setSelectedRow(null)
      setDeleteLoading(false)
    }
  }

  const handleToggleStatus = async () => {
    if (!selectedRow) return

    setStatusLoading(true)
    try {
      await toggleProcessManagementTemplateStatus(selectedRow)
      setTableData((prev) =>
        prev.map((item) =>
          item.id === selectedRow
            ? {
                ...item,
                status: item.status === "Active" ? "Inactive" : "Active",
                isActive: item.isActive === 1 ? 0 : 1,
              }
            : item
        )
      )
      toast.success("Status updated successfully!")
    } catch (error) {
      console.error("Error toggling status:", error)
      toast.error(error.message || "Failed to update status")
    } finally {
      setShowDeactivateModal(false)
      setShowActivateModal(false)
      setSelectedRow(null)
      setStatusLoading(false)
    }
  }

  const handleStatusClick = (item) => {
    setSelectedRow(item.id)
    if (item.status === "Active") {
      setShowDeactivateModal(true)
    } else {
      setShowActivateModal(true)
    }
    setDropdownId(null)
  }

  // ============================================
  // DOWNLOAD HANDLERS
  // ============================================
  const handlePreviewAndDownload = () => {
    const data = filteredItems
    const newWindow = window.open("proceemangemnet/downlaod", "_blank")

    const handleReady = (event) => {
      if (event.source === newWindow && event.data?.type === "READY_FOR_DATA") {
        newWindow.postMessage({ type: "INIT_DATA", payload: data }, "*")
        window.removeEventListener("message", handleReady)
      }
    }

    window.addEventListener("message", handleReady)
  }

  const handleDownloadTemplate = async () => {
    try {
      const workbook = new ExcelJS.Workbook()
      const sheet = workbook.addWorksheet("Template")

      sheet.columns = [
        { header: "Template Name", key: "templateName", width: 25 },
        { header: "Department ID", key: "departmentId", width: 15 },
        { header: "Description", key: "description", width: 40 },
        { header: "Valid Till (YYYY-MM-DD)", key: "validTill", width: 20 },
      ]

      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: true, color: { argb: "FFFFFFFF" } }
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        }
        cell.alignment = { vertical: "middle", horizontal: "left" }
      })

      const sampleRow = sheet.addRow({
        templateName: "Sample Template",
        departmentId: 1,
        description: "Sample description",
        validTill: "2025-12-31",
      })

      sampleRow.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" }
      })

      sheet.views = [{ state: "frozen", ySplit: 1 }]

      const buffer = await workbook.xlsx.writeBuffer()
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      })
      saveAs(blob, "Process_Management_Template.xlsx")
      setIsAddUserOpen(false)
    } catch (err) {
      console.error("Error downloading template:", err)
      toast.error("Failed to download template")
    }
  }

  const handleBulkUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result)
      const workbook = XLSX.read(data, { type: "array" })
      const sheetName = workbook.SheetNames[0]

      let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" })

      json = json.filter((row) => Object.values(row).some((cell) => cell !== ""))

      const finalRows = json.map((row, index) => ({
        slNo: index + 1,
        template_name: row["Template Name"] || "",
        department_id: row["Department ID"] || "",
        description: row["Description"] || "",
        valid_till: row["Valid Till (YYYY-MM-DD)"] || row["Valid Till"] || "",
        hasError:
          !row["Template Name"] ||
          !row["Department ID"] ||
          !row["Description"] ||
          !row["Valid Till (YYYY-MM-DD)"],
      }))

      navigate("/templates/bulkupload", { state: { rows: finalRows } })
    }

    reader.readAsArrayBuffer(file)
    e.target.value = ""
  }

  // ============================================
  // RENDER
  // ============================================
  return (
    <div className="">
      {/* Top Bar */}
      <div className="flex justify-between items-center mt-4">
        <div className="flex gap-2">
          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search"
            className="w-[1/2]"
            iconColor="text-black"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            inputWidth="w-full"
            focusRing="focus:ring-1 focus:ring-black/60"
            hoverInputClasses="hover:bg-white hover:border-black/60"
          />

          <Filter
            name="Template"
            value={selectedTemplate}
            options={templateOptions}
            onChange={(n, v) => setSelectedTemplate(v)}
            placeholder="Template"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />

          <Filter
            name="Department"
            value={selectedDepartment}
            options={departmentOptions}
            onChange={(n, v) => setSelectedDepartment(v)}
            placeholder="Department"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />

          <Filter
            name="Uploaded By"
            value={selectedUploadedBy}
            options={uploadedByOptions}
            onChange={(n, v) => setSelectedUploadedBy(v)}
            placeholder="Uploaded By"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <div className="relative inline-block">
            <button
              ref={addUserButtonRef}
              onClick={() => setIsAddUserOpen(!isAddUserOpen)}
              className="py-2 px-3 w-[150px] text-xs font-medium bg-darkblue1 text-white flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <img
                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/add user.png"
                  className="w-4 h-4"
                  alt="add"
                />
                Actions
              </span>
            </button>

            {isAddUserOpen && (
              <div
                ref={addUserDropdownRef}
                className="absolute top-full left-0 mt-1 bg-white border border-darkblue1 shadow-lg z-50"
                style={{ width: addUserButtonWidth }}
              >
                <button
                  onClick={() => {
                    setIsAddPopupOpen(true)
                    setIsAddUserOpen(false)
                  }}
                  className="w-full px-3 py-1 text-xs hover:bg-lightBlue/50 flex gap-2"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/addnew.png"
                    alt="add"
                    className="w-4 h-3"
                  />
                  Add New
                </button>

                <button
                  onClick={() => {
                    navigate("/templates/bulkupload")
                    setIsAddUserOpen(false)
                  }}
                  className="w-full text-left px-3 py-1 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/bulkupload.png"
                    className="w-3 h-3"
                    alt="bulk"
                  />
                  Bulk Upload
                </button>

                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept=".xlsx,.xls"
                  onChange={handleBulkUpload}
                />

                <button
                  onClick={handleDownloadTemplate}
                  className="w-full px-3 py-1 text-xs hover:bg-lightBlue/50 flex gap-2"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/download.png"
                    alt="download"
                    className="w-3 h-3"
                  />
                  Template
                </button>
              </div>
            )}
          </div>

          <button
            onClick={handlePreviewAndDownload}
            className="py-2 px-6 text-xs border border-black/30 hover:bg-lightBlue/50 flex items-center gap-2"
          >
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Scorecard/template.png"
              alt="bulk"
              className="w-4 h-4"
            />
            Download
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white shadow-md border border-Dustyblue mt-3">
        <div
          ref={tableContainerRef}
          className="overflow-y-auto overflow-x-auto max-h-[400px]"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          <table className="text-sm w-full">
            <thead className="bg-Dustyblue text-white text-left text-xs sticky top-0 z-10">
              <tr>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[15%]">
                  Template Name
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[12%]">
                  Department
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%]">
                  Description
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[12%]">
                  Uploaded By
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%]">
                  Uploaded Date
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%]">
                  Valid Till
                </th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[8%]">
                  Status
                </th>
                <th className="px-4 py-1.5 text-center border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 w-[5%]">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan="8" className="text-center py-8">
                    <div className="flex items-center justify-center gap-2">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                      <span className="text-xs text-gray-500">Loading...</span>
                    </div>
                  </td>
                </tr>
              ) : filteredItems.length > 0 ? (
                filteredItems.map((item) => {
                  const rowId = `row-${item.id}`
                  const isActive = item.status === "Active"

                  return (
                    <tr
                      key={rowId}
                      className={`hover:bg-lightBlue/50 cursor-pointer text-xs ${
                        isActive ? "text-black" : "text-gray-400"
                      }`}
                    >
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        {item.templateName}
                      </td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        {item.department}
                      </td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 truncate max-w-[200px]">
                        {item.description}
                      </td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        {item.uploadedBy}
                      </td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        {item.uploadedDate}
                      </td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        {item.validTill}
                      </td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        <span
                          className={`px-2 py-0.5 text-[10px] rounded-full ${
                            isActive
                              ? "bg-green-100 text-green-600"
                              : "bg-red-100 text-red-600"
                          }`}
                        >
                          {item.status}
                        </span>
                      </td>
                      <td className="py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0">
                        <div className="relative flex items-center justify-center">
                          <button
                            onClick={() => setDropdownId(dropdownId === rowId ? null : rowId)}
                            className="w-6 h-6 flex items-center justify-center border border-gray-300 hover:bg-gray-100"
                          >
                            <MoreVertical size={16} className="text-black" />
                          </button>

                          {dropdownId === rowId && (
                            <div
                              ref={(el) => (dropdownRefs.current[rowId] = el)}
                              className="absolute right-0 mt-1 bg-white w-40 border border-gray-200 shadow-lg z-50"
                              style={{ top: "100%" }}
                            >
                              <div className="py-1 flex flex-col">
                                <button
                                  onClick={() => handleEdit(item)}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <img
                                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
                                    alt="Edit"
                                    className="w-4 h-4"
                                  />
                                  Edit
                                </button>

                                <button
                                  onClick={() => handleStatusClick(item)}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <img
                                    src={
                                      isActive
                                        ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/deactive.png"
                                        : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/active.png"
                                    }
                                    alt="Toggle Status"
                                    className="w-4 h-4"
                                  />
                                  <span>{isActive ? "Deactivate" : "Activate"}</span>
                                </button>

                                {item.templateFile && (
                                  <button
                                    onClick={() => {
                                      window.open(item.templateFile, "_blank")
                                      setDropdownId(null)
                                    }}
                                    className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                  >
                                    <img
                                      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/download.png"
                                      alt="Download"
                                      className="w-4 h-4"
                                    />
                                    Download File
                                  </button>
                                )}

                                <button
                                  onClick={() => handleDeleteClick(item)}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <img
                                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                                    alt="Delete"
                                    className="w-4 h-4"
                                  />
                                  Delete
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  )
                })
              ) : (
                <tr>
                  <td colSpan="8" className="text-center py-8 text-xs text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      {deleteItem && (
        <DeleteModal
          isOpen={true}
          onClose={() => {
            setDeleteItem(null)
            setSelectedRow(null)
          }}
          onConfirm={handleConfirmDelete}
          loading={deleteLoading}
          extraMessage="This template will be permanently deleted."
        />
      )}

      <ActivateStatus
        isOpen={showActivateModal}
        onClose={() => {
          setShowActivateModal(false)
          setSelectedRow(null)
        }}
        onConfirm={handleToggleStatus}
        loading={statusLoading}
      />

      <DeactivateStatus
        isOpen={showDeactivateModal}
        onClose={() => {
          setShowDeactivateModal(false)
          setSelectedRow(null)
        }}
        onConfirm={handleToggleStatus}
        loading={statusLoading}
      />

      {isAddPopupOpen && (
        <AddTemplatePopup
          onClose={() => setIsAddPopupOpen(false)}
          onSave={handleSaveTemplate}
        />
      )}

      {editingTemplate && (
        <EditTemplate
          template={editingTemplate}
          onClose={() => setEditingTemplate(null)}
          onSave={handleUpdateTemplate}
        />
      )}
    </div>
  )
}

export default Templates