import React, { useState, useRef, useEffect } from "react";
import { Upload } from "lucide-react";
import { toast } from "react-toastify";
import StyledSelectField from "../../../Components/StyledSelectField";
import StyledDateField from "../../../Components/StyledDatefield";
import {
  updateProcessManagementTemplate,
  extractFileName,
} from "../../../services/processManagement/processManagementTemplate.service";
import { getAllDepartments } from "../../../services/masterOthers/department.service"; // Use existing service

const EditTemplate = ({ onClose, onSave, template }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [isDepartmentsLoading, setIsDepartmentsLoading] = useState(false);
  const [departments, setDepartments] = useState([]);

  const [formData, setFormData] = useState({
    templateName: "",
    departmentId: "",
    departmentLabel: "",
    description: "",
    templateFile: null,
    existingFileUrl: "",
    existingFileName: "",
    validTill: "",
  });

  const [errors, setErrors] = useState({});
  const [dropdowns, setDropdowns] = useState({ department: false });
  const refs = { department: useRef(null) };

  // Fetch departments on mount
  useEffect(() => {
    fetchDepartments();
  }, []);

  const fetchDepartments = async () => {
    setIsDepartmentsLoading(true);
    try {
      const data = await getAllDepartments();
      // Filter only active departments
      const activeDepartments = data.filter((dept) => dept.isActive === 1);
      const formattedDepartments = activeDepartments.map((dept) => ({
        id: dept.id,
        label: dept.name || dept.department_name,
        value: String(dept.id),
      }));
      setDepartments(formattedDepartments);
    } catch (error) {
      console.error("Error fetching departments:", error);
      toast.error("Failed to load departments");
    } finally {
      setIsDepartmentsLoading(false);
    }
  };

  // Populate form with existing template data
  useEffect(() => {
    if (template && departments.length > 0) {
      const dept = departments.find(
        (d) => d.value === String(template.departmentId) || d.label === template.department
      );

      setFormData({
        templateName: template.templateName || "",
        departmentId: template.departmentId ? String(template.departmentId) : dept?.value || "",
        departmentLabel: template.department || dept?.label || "",
        description: template.description || "",
        templateFile: null,
        existingFileUrl: template.templateFile || "",
        existingFileName: extractFileName(template.templateFile),
        validTill: template.validTill || "",
      });
    }
  }, [template, departments]);

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const validTypes = [
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
      "application/msword",
      "application/vnd.ms-excel",
    ];

    if (!validTypes.includes(file.type)) {
      toast.error("Only PDF, DOCX, XLSX, or PPTX files are allowed.");
      return;
    }

    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      toast.error("File size must be less than 10MB.");
      return;
    }

    handleChange("templateFile", file);
  };

  const handleSave = async () => {
    const newErrors = {};
    if (!formData.templateName.trim()) newErrors.templateName = "Template Name is required";
    if (!formData.departmentId) newErrors.department = "Department is required";
    if (!formData.description.trim()) newErrors.description = "Description is required";
    if (!formData.templateFile && !formData.existingFileUrl) {
      newErrors.templateFile = "Template File is required";
    }
    if (!formData.validTill) newErrors.validTill = "Valid Till date is required";

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) return;

    setIsLoading(true);
    try {
      const payload = {
        id: template.id,
        template_name: formData.templateName.trim(),
        department_id: parseInt(formData.departmentId),
        description: formData.description.trim(),
        valid_till: formData.validTill,
      };

      await updateProcessManagementTemplate(payload, formData.templateFile);
      onSave();
    } catch (error) {
      console.error("Error updating template:", error);
      toast.error(error.message || "Failed to update template");
    } finally {
      setIsLoading(false);
    }
  };

  const openExistingFile = () => {
    if (formData.existingFileUrl) {
      window.open(formData.existingFileUrl, "_blank");
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
      <div className="bg-white p-6 shadow-md w-full max-w-3xl relative">
        <button
          onClick={onClose}
          disabled={isLoading}
          className="absolute top-3 right-3 p-1 text-gray-500 hover:text-black disabled:opacity-50"
        >
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
            alt="close"
            className="w-4 h-4"
          />
        </button>

        <h2 className="text-base text-MediumGrey font-semibold mb-4 text-center">
          Edit Template
        </h2>

        <div className="grid grid-cols-2 gap-4">
          {/* Template Name */}
          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Template Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              placeholder="Enter Template Name"
              value={formData.templateName}
              onChange={(e) => handleChange("templateName", e.target.value)}
              disabled={isLoading}
              className={`border text-xs px-4 py-1.5 w-full ${
                errors.templateName ? "border-red1" : "border-black/30"
              } disabled:bg-gray-100`}
            />
            {errors.templateName && (
              <span className="text-red1 text-xs">{errors.templateName}</span>
            )}
          </div>

          {/* Department */}
          <StyledSelectField
            label="Department"
            required
            placeholder={isDepartmentsLoading ? "Loading..." : "Select Department"}
            value={formData.departmentLabel}
            setValue={(label) => {
              const selected = departments.find((opt) => opt.label === label);
              setFormData({
                ...formData,
                departmentId: selected?.value || "",
                departmentLabel: label,
              });
              setErrors((prev) => ({ ...prev, department: "" }));
            }}
            options={departments.map((opt) => opt.label)}
            dropdownOpen={dropdowns.department}
            setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, department: val }))}
            dropdownRef={refs.department}
            error={errors.department}
            disabled={isLoading || isDepartmentsLoading}
          />

          {/* Description */}
          <div className="col-span-2">
            <label className="text-xs font-medium text-black mb-2 block">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              placeholder="Enter Description"
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              disabled={isLoading}
              className={`border text-xs px-4 py-2 resize-none h-28 w-full ${
                errors.description ? "border-red1" : "border-black/30"
              } disabled:bg-gray-100`}
            />
            {errors.description && (
              <span className="text-red1 text-xs">{errors.description}</span>
            )}
          </div>

          {/* Template File */}
          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Template File <span className="text-red-500">*</span>
            </label>
            <label
              htmlFor="template-upload-edit"
              className={`relative cursor-pointer border flex items-center gap-3 px-3 py-1.5 text-black text-xs hover:bg-gray-50 ${
                errors.templateFile ? "border-red1" : "border-black/30"
              } ${isLoading ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              {formData.templateFile ? (
                <span className="truncate text-green-600">
                  {formData.templateFile.name} (New)
                </span>
              ) : formData.existingFileName ? (
                <span className="truncate">{formData.existingFileName}</span>
              ) : (
                <span className="truncate text-gray-400">
                  Choose a file (pdf, docx, xlsx - max 10MB)
                </span>
              )}
              <Upload size={16} className="ml-auto text-gray-400" />
              <input
                type="file"
                id="template-upload-edit"
                accept=".pdf,.docx,.xlsx,.pptx,.xls,.doc"
                className="absolute inset-0 opacity-0 cursor-pointer"
                disabled={isLoading}
                onChange={handleFileChange}
              />
            </label>
            {errors.templateFile && (
              <span className="text-red1 text-xs mt-1 block">{errors.templateFile}</span>
            )}
            {formData.existingFileUrl && !formData.templateFile && (
              <button
                type="button"
                onClick={openExistingFile}
                className="text-xs text-blue-600 hover:underline mt-1 inline-block"
              >
                View current file
              </button>
            )}
          </div>

          {/* Valid Till */}
          <div className="mt-1">
            <StyledDateField
              label="Valid Till"
              required
              value={formData.validTill}
              setValue={(val) => handleChange("validTill", val)}
              error={errors.validTill}
              disabled={isLoading}
            />
          </div>
        </div>

        {/* Update Button */}
        <div className="flex justify-center mt-6">
          <button
            onClick={handleSave}
            disabled={isLoading}
            className="bg-darkblue1 text-white px-8 py-1 text-xs hover:bg-white hover:text-darkblue1 border border-darkblue1 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {isLoading && (
              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
            )}
            {isLoading ? "Updating..." : "Update"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditTemplate;