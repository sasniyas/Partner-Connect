"use client";

import { useState, useRef, useEffect } from "react";
import Searchinput from "../../../../Components/Searchinput";
import Filter from "../../../../Components/Filter";
import { MoreVertical } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import DeleteModal from "../../../../Components/DeleteModal";
import ActivateStatus from "../../../../Components/ActivateStatus";
import DeactivateStatus from "../../../../Components/DeactivateStatus";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import AddProcess from "./AddProcess";
import EditProcess from "./EditProcess";
import {
  getAllProcessManagementProcesses,
  deleteProcessManagementProcess,
  toggleProcessManagementProcessStatus,
  transformProcessData,
} from "../../../../services/processManagement/processManagementProcess.service";
import { getAllDepartments } from "../../../../services/masterOthers/department.service";

const Process = () => {
  const navigate = useNavigate();

  // Data States
  const [tableData, setTableData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [departments, setDepartments] = useState([]);

  // Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedProcess, setSelectedProcess] = useState("");
  const [selectedDepartment, setSelectedDepartment] = useState("");
  const [selectedUploadedBy, setSelectedUploadedBy] = useState("");

  // Modal States
  const [deleteItem, setDeleteItem] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [isAddProcessOpen, setIsAddProcessOpen] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [editingProcess, setEditingProcess] = useState(null);
  const [statusLoading, setStatusLoading] = useState(false);

  // Refs
  const fileInputRef = useRef(null);
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const addUserButtonRef = useRef(null);
  const addUserDropdownRef = useRef(null);
  const [addUserButtonWidth, setAddUserButtonWidth] = useState(0);
  const [dropdownId, setDropdownId] = useState(null);
  const dropdownRefs = useRef({});
  const tableContainerRef = useRef(null);

  // =============================== FETCH DATA ===============================
  useEffect(() => {
    fetchProcesses();
    fetchDepartments();
  }, []);

  const fetchProcesses = async () => {
    setIsLoading(true);
    try {
      const data = await getAllProcessManagementProcesses();
      const transformed = transformProcessData(data);
      setTableData(transformed);
    } catch (error) {
      console.error("Error fetching processes:", error);
      toast.error(error.message || "Failed to fetch processes");
    } finally {
      setIsLoading(false);
    }
  };

  const fetchDepartments = async () => {
    try {
      const data = await getAllDepartments();
      const activeDepartments = data.filter((dept) => dept.isActive === 1);
      const formattedDepartments = activeDepartments.map((dept) => ({
        id: dept.id,
        label: dept.name || dept.department_name,
        value: String(dept.id),
      }));
      setDepartments(formattedDepartments);
    } catch (error) {
      console.error("Error fetching departments:", error);
    }
  };

  // =============================== DYNAMIC FILTER OPTIONS ===============================
  const processOptions = [...new Set(tableData.map((item) => item.processName))].filter(Boolean).sort();
  const departmentOptions = [...new Set(tableData.map((item) => item.department))].filter(Boolean).sort();
  const uploadedByOptions = [...new Set(tableData.map((item) => item.uploadedBy))].filter(Boolean).sort();

  // =============================== FILTERED DATA ===============================
  const filteredItems = tableData.filter((item) => {
    const searchLower = searchTerm.toLowerCase();

    const matchesSearch =
      item.processName?.toLowerCase().includes(searchLower) ||
      item.description?.toLowerCase().includes(searchLower) ||
      item.uploadedBy?.toLowerCase().includes(searchLower) ||
      item.processNo?.toLowerCase().includes(searchLower);

    const matchesProcess =
      selectedProcess?.length > 0
        ? selectedProcess.includes(item.processName)
        : true;

    const matchesDepartment =
      selectedDepartment?.length > 0
        ? selectedDepartment.includes(item.department)
        : true;

    const matchesUploadedBy =
      selectedUploadedBy?.length > 0
        ? selectedUploadedBy.includes(item.uploadedBy)
        : true;

    return matchesSearch && matchesProcess && matchesDepartment && matchesUploadedBy;
  });

  // =============================== DROPDOWN HANDLERS ===============================
  useEffect(() => {
    if (addUserButtonRef.current) {
      setAddUserButtonWidth(addUserButtonRef.current.offsetWidth);
    }
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        addUserDropdownRef.current &&
        !addUserDropdownRef.current.contains(e.target) &&
        addUserButtonRef.current &&
        !addUserButtonRef.current.contains(e.target)
      ) {
        setIsAddUserOpen(false);
      }

      const isClickInsideRowDropdown = Object.values(dropdownRefs.current).some(
        (ref) => ref && ref.contains(e.target)
      );
      if (!isClickInsideRowDropdown) {
        setDropdownId(null);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // =============================== SAVE HANDLER ===============================
  const handleSaveProcess = () => {
    fetchProcesses();
    setIsAddProcessOpen(false);
    toast.success("Process added successfully");
  };

  const handleUpdateProcess = () => {
    fetchProcesses();
    setEditingProcess(null);
    toast.success("Process updated successfully");
  };

  // =============================== EDIT HANDLER ===============================
  const handleEdit = (item) => {
    setEditingProcess(item);
    setDropdownId(null);
  };

  // =============================== DELETE HANDLERS ===============================
  const handleDeleteClick = (item) => {
    setDeleteItem(item);
    setSelectedRow(item.id);
    setDropdownId(null);
  };

  const handleConfirmDelete = async () => {
    setDeleteLoading(true);
    try {
      await deleteProcessManagementProcess(selectedRow);
      setTableData((prev) => prev.filter((row) => row.id !== selectedRow));
      toast.success("Process deleted successfully");
    } catch (error) {
      console.error("Error deleting process:", error);
      toast.error(error.message || "Failed to delete process");
    } finally {
      setDeleteItem(null);
      setSelectedRow(null);
      setDeleteLoading(false);
    }
  };

  // =============================== STATUS TOGGLE HANDLERS ===============================
  const handleToggleStatus = (item, idx) => {
    setSelectedRow(item.id);
    if (item.active === "Yes") {
      setShowDeactivateModal(true);
    } else {
      setShowActivateModal(true);
    }
    setDropdownId(null);
  };

  const handleConfirmDeactivate = async () => {
    setStatusLoading(true);
    try {
      await toggleProcessManagementProcessStatus(selectedRow);
      setTableData((prev) =>
        prev.map((item) =>
          item.id === selectedRow
            ? { ...item, active: "No", status: "Inactive", isActive: 0 }
            : item
        )
      );
      toast.success("Process deactivated successfully");
    } catch (error) {
      console.error("Error deactivating process:", error);
      toast.error(error.message || "Failed to deactivate process");
    } finally {
      setShowDeactivateModal(false);
      setStatusLoading(false);
      setSelectedRow(null);
    }
  };

  const handleConfirmActivate = async () => {
    setStatusLoading(true);
    try {
      await toggleProcessManagementProcessStatus(selectedRow);
      setTableData((prev) =>
        prev.map((item) =>
          item.id === selectedRow
            ? { ...item, active: "Yes", status: "Active", isActive: 1 }
            : item
        )
      );
      toast.success("Process activated successfully");
    } catch (error) {
      console.error("Error activating process:", error);
      toast.error(error.message || "Failed to activate process");
    } finally {
      setShowActivateModal(false);
      setStatusLoading(false);
      setSelectedRow(null);
    }
  };

  // =============================== DOWNLOAD HANDLERS ===============================
  const handlePreviewAndDownload = () => {
    const data = filteredItems;
    const newWindow = window.open("proceemangemnet/process/download", "_blank");

    const handleReady = (event) => {
      if (event.source === newWindow && event.data?.type === "READY_FOR_DATA") {
        newWindow.postMessage({ type: "INIT_DATA", payload: data }, "*");
        window.removeEventListener("message", handleReady);
      }
    };

    window.addEventListener("message", handleReady);
  };

  const handleDownloadTemplate = async () => {
  try {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Process Template");

    // Columns - Process No. included as number input
    sheet.columns = [
      { header: "Process No.", key: "processNo", width: 15 },
      { header: "Process Name", key: "processName", width: 25 },
      { header: "Department ID", key: "departmentId", width: 15 },
      { header: "Process Owner", key: "processOwner", width: 20 },
      { header: "Description", key: "description", width: 40 },
    ];

    // Header style
    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });

    // Sample row
    const sampleRow = sheet.addRow({
      processNo: 1001,
      processName: "Sample Process",
      departmentId: 1,
      processOwner: "John Doe",
      description: "Sample process description",
    });

    sampleRow.eachCell((cell) => {
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });

    sheet.views = [{ state: "frozen", ySplit: 1 }];

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(blob, "Process_Template.xlsx");
    setIsAddUserOpen(false);
  } catch (err) {
    console.error("Error downloading template:", err);
    toast.error("Failed to download template");
  }
};

  // =============================== BULK UPLOAD HANDLER ===============================
  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];
      let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });
      json = json.filter((row) => Object.values(row).some((cell) => cell !== ""));

      const finalRows = json.map((row) => ({
        process_name: String(row["Process Name"] || "").trim(),
        department_id: String(row["Department ID"] || "").trim(),
        process_owner: String(row["Process Owner"] || "").trim(),
        description: String(row["Description"] || "").trim(),
        hasError:
          !row["Process Name"] ||
          !row["Department ID"] ||
          !row["Process Owner"] ||
          !row["Description"],
      }));

      navigate("/process/bulkupload", { state: { rows: finalRows } });
    };

    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  // =============================== DOWNLOAD FILE ===============================
  const handleDownloadFile = (item) => {
    if (item.processFile) {
      window.open(item.processFile, "_blank");
    } else {
      toast.error("No file available");
    }
    setDropdownId(null);
  };

  // =============================== UI ===============================
  return (
    <div className="">
      {/* Top Bar */}
      <div className="flex justify-between items-center mt-4">
        <div className="flex gap-2">
          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search"
            className="w-[1/2]"
            iconColor="text-black"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            inputWidth="w-full"
            focusRing="focus:ring-1 focus:ring-black/60"
            hoverInputClasses="hover:bg-white hover:border-black/60"
          />
          <Filter
            name="Process"
            value={selectedProcess}
            options={processOptions}
            onChange={(n, v) => setSelectedProcess(v)}
            placeholder="Process"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />
          <Filter
            name="Department"
            value={selectedDepartment}
            options={departmentOptions}
            onChange={(n, v) => setSelectedDepartment(v)}
            placeholder="Department"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />
          <Filter
            name="Uploaded By"
            value={selectedUploadedBy}
            options={uploadedByOptions}
            onChange={(n, v) => setSelectedUploadedBy(v)}
            placeholder="Uploaded By"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
            customWidth="w-[150px]"
          />
        </div>

        {/* Add User Dropdown */}
        <div className="flex gap-2">
          <div className="relative inline-block">
            <button
              ref={addUserButtonRef}
              onClick={() => setIsAddUserOpen(!isAddUserOpen)}
              className="py-2 px-3 w-[150px] text-xs font-medium bg-darkblue1 text-white flex items-center justify-between"
            >
              <span className="flex items-center gap-2">
                <img
                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/add user.png"
                  className="w-4 h-4"
                  alt="add"
                />
                Add Process
              </span>
            </button>

            {isAddUserOpen && (
              <div
                ref={addUserDropdownRef}
                className="absolute top-full left-0 mt-1 bg-white border border-darkblue1 shadow-lg z-50"
                style={{ width: addUserButtonWidth }}
              >
                <button
                  onClick={() => {
                    setIsAddProcessOpen(true);
                    setIsAddUserOpen(false);
                  }}
                  className="w-full px-3 py-1 text-xs hover:bg-lightBlue/50 flex gap-2"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/addnew.png"
                    alt="add"
                    className="w-4 h-3"
                  />
                  Add New
                </button>

                <button
                  onClick={() => {
                    navigate("/process/bulkupload");
                    setIsAddUserOpen(false);
                  }}
                  className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/bulkupload.png"
                    className="w-3 h-3"
                    alt="bulk"
                  />
                  Bulk Upload
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept=".xlsx,.xls"
                  onChange={handleBulkUpload}
                />

                <button
                  onClick={handleDownloadTemplate}
                  className="w-full px-3 py-1 text-xs hover:bg-lightBlue/50 flex gap-2"
                >
                  <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/download.png"
                    alt="download"
                    className="w-3 h-3"
                  />
                  Template
                </button>
              </div>
            )}
          </div>

          {/* Download Button */}
          <button
            onClick={handlePreviewAndDownload}
            className="py-2 px-6 text-xs border border-black/30 hover:bg-lightBlue/50 flex items-center gap-2"
          >
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Scorecard/template.png"
              alt="bulk"
              className="w-4 h-4"
            />
            Download
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white shadow-md border border-Dustyblue mt-3">
        <div
          ref={tableContainerRef}
          className="overflow-y-auto overflow-x-auto max-h-full"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          <table className="text-sm w-full">
            <thead className="bg-Dustyblue text-white text-left text-xs sticky top-0 z-10">
              <tr>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Process No.</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Process Name</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Department</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Process Owner</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Description</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Uploaded By</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Uploaded Date</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Last Modified By</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Last Modified Date</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Status</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan="11" className="text-center py-8">
                    <div className="flex justify-center items-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-darkblue1"></div>
                      <span className="ml-2 text-xs text-gray-500">Loading...</span>
                    </div>
                  </td>
                </tr>
              ) : filteredItems.length > 0 ? (
                filteredItems.map((item, idx) => {
                  const rowId = `${item.id}-${idx}`;
                  const isActive = item.active === "Yes";

                  return (
                    <tr
                      key={rowId}
                      className={`hover:bg-lightBlue/50 cursor-pointer text-xs ${
                        isActive ? "text-black" : "text-gray-400"
                      }`}
                    >
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.processNo}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.processName}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.department}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.processOwner}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 max-w-[200px] truncate" title={item.description}>
                        {item.description}
                      </td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.uploadedBy}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.uploadedDate}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.lastModifiedBy}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.lastModifiedDate}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] ${
                            isActive ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"
                          }`}
                        >
                          {item.status}
                        </span>
                      </td>
                      <td className="py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0 text-xs">
                        <div className="relative flex items-center justify-center">
                          <button
                            onClick={() => setDropdownId(dropdownId === rowId ? null : rowId)}
                            className="w-6 h-6 flex items-center justify-center border border-gray-300 hover:bg-gray-100"
                          >
                            <MoreVertical size={16} className="text-black" />
                          </button>

                          {dropdownId === rowId && (
                            <div
                              ref={(el) => (dropdownRefs.current[rowId] = el)}
                              className="absolute right-0 mt-1 bg-white w-40 border border-gray-200 shadow-lg z-50"
                            >
                              <div className="py-1 flex flex-col">
                                <button
                                  onClick={() => handleEdit(item)}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <img
                                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
                                    alt="Edit"
                                    className="w-4 h-4"
                                  />
                                  Edit
                                </button>

                                <button
                                  onClick={() => handleToggleStatus(item, idx)}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <img
                                    src={
                                      item.active === "Yes"
                                        ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/deactive.png"
                                        : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/active.png"
                                    }
                                    alt="Toggle Status"
                                    className="w-4 h-4"
                                  />
                                  <span>{item.active === "Yes" ? "Deactivate" : "Activate"}</span>
                                </button>

                                <button
                                  onClick={() => handleDownloadFile(item)}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <img
                                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/download.png"
                                    alt="Download"
                                    className="w-4 h-4"
                                  />
                                  Download File
                                </button>

                                <button
                                  onClick={() => handleDeleteClick(item)}
                                  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                >
                                  <img
                                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                                    alt="Delete"
                                    className="w-4 h-4"
                                  />
                                  Delete
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan="11" className="text-center py-8 text-xs text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      {deleteItem && (
        <DeleteModal
          isOpen={true}
          onClose={() => setDeleteItem(null)}
          onConfirm={handleConfirmDelete}
          loading={deleteLoading}
        />
      )}

      {showActivateModal && (
        <ActivateStatus
          isOpen={true}
          onClose={() => setShowActivateModal(false)}
          onConfirm={handleConfirmActivate}
          loading={statusLoading}
        />
      )}

      {showDeactivateModal && (
        <DeactivateStatus
          isOpen={true}
          onClose={() => setShowDeactivateModal(false)}
          onConfirm={handleConfirmDeactivate}
          loading={statusLoading}
        />
      )}

      {isAddProcessOpen && (
        <AddProcess
          onClose={() => setIsAddProcessOpen(false)}
          onSave={handleSaveProcess}
          departments={departments}
        />
      )}

      {editingProcess && (
        <EditProcess
          isOpen={!!editingProcess}
          onClose={() => setEditingProcess(null)}
          processData={editingProcess}
          onSave={handleUpdateProcess}
          departments={departments}
        />
      )}
    </div>
  );
};

export default Process;