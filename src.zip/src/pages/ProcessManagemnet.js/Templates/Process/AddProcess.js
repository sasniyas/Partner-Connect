import React, { useState, useRef, useEffect } from "react";
import { Upload } from "lucide-react";
import { toast } from "react-toastify";
import StyledSelectField from "../../../../Components/StyledSelectField";
import { addProcessManagementProcess } from "../../../../services/processManagement/processManagementProcess.service";
import { getAllDepartments } from "../../../../services/masterOthers/department.service";

const AddProcess = ({ onClose, onSave }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [isDepartmentsLoading, setIsDepartmentsLoading] = useState(false);
  const [departments, setDepartments] = useState([]);

  const [formData, setFormData] = useState({
    processName: "",
    processNo: "",
    departmentId: "",
    departmentLabel: "",
    processOwner: "",
    description: "",
    processFile: null,
  });

  const [errors, setErrors] = useState({});
  const [dropdowns, setDropdowns] = useState({ department: false });
  const refs = { department: useRef(null) };

  // Fetch departments on mount
  useEffect(() => {
    fetchDepartments();
  }, []);

  const fetchDepartments = async () => {
    setIsDepartmentsLoading(true);
    try {
      const data = await getAllDepartments();
      const activeDepartments = data.filter((dept) => dept.isActive === 1);
      const formattedDepartments = activeDepartments.map((dept) => ({
        id: dept.id,
        label: dept.name || dept.department_name,
        value: String(dept.id),
      }));
      setDepartments(formattedDepartments);
    } catch (error) {
      console.error("Error fetching departments:", error);
      toast.error("Failed to load departments");
    } finally {
      setIsDepartmentsLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const handleProcessNoChange = (e) => {
    const value = e.target.value;
    // Only allow numbers
    if (value === "" || /^\d+$/.test(value)) {
      handleChange("processNo", value);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const validTypes = [
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ];

    if (!validTypes.includes(file.type)) {
      toast.error("Only PDF, DOCX, or XLSX files are allowed.");
      return;
    }

    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      toast.error("File size must be less than 10MB.");
      return;
    }

    handleChange("processFile", file);
  };

  const handleSave = async () => {
    const newErrors = {};

    if (!formData.processNo.trim()) newErrors.processNo = "Process No. is required";
    if (!formData.processName.trim()) newErrors.processName = "Process Name is required";
    if (!formData.departmentId) newErrors.department = "Department is required";
    if (!formData.processOwner.trim()) newErrors.processOwner = "Process Owner is required";
    if (!formData.description.trim()) newErrors.description = "Description is required";
    if (!formData.processFile) newErrors.processFile = "Process file is required";

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) return;

    setIsLoading(true);
    try {
      const payload = {
        process_id: formData.processNo.trim(),
        process_name: formData.processName.trim(),
        department_id: parseInt(formData.departmentId),
        process_owner: formData.processOwner.trim(),
        description: formData.description.trim(),
      };

      await addProcessManagementProcess(payload, formData.processFile);
      onSave();
    } catch (error) {
      console.error("Error adding process:", error);
      toast.error(error.message || "Failed to add process");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
      <div className="bg-white p-6 shadow-md w-full max-w-3xl relative">
        {/* Close */}
        <button
          onClick={onClose}
          disabled={isLoading}
          className="absolute top-3 right-3 disabled:opacity-50"
        >
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
            alt="close"
            className="w-4 h-4"
          />
        </button>

        <h2 className="text-base font-semibold text-center mb-4">Add New Process</h2>

        <div className="grid grid-cols-2 gap-4">
          {/* Process No. (Number Input) */}
          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Process No. <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              inputMode="numeric"
              placeholder="Enter Process No."
              value={formData.processNo}
              onChange={handleProcessNoChange}
              disabled={isLoading}
              className={`border text-xs px-4 py-1.5 w-full ${
                errors.processNo ? "border-red1" : "border-black/30"
              } disabled:bg-gray-100`}
            />
            {errors.processNo && (
              <span className="text-red1 text-xs">{errors.processNo}</span>
            )}
          </div>

          {/* Process Name */}
          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Process Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              placeholder="Enter Process Name"
              value={formData.processName}
              onChange={(e) => handleChange("processName", e.target.value)}
              disabled={isLoading}
              className={`border text-xs px-4 py-1.5 w-full ${
                errors.processName ? "border-red1" : "border-black/30"
              } disabled:bg-gray-100`}
            />
            {errors.processName && (
              <span className="text-red1 text-xs">{errors.processName}</span>
            )}
          </div>

          {/* Department */}
          <StyledSelectField
            label="Department"
            required
            placeholder={isDepartmentsLoading ? "Loading..." : "Select Department"}
            value={formData.departmentLabel}
            setValue={(label) => {
              const selected = departments.find((opt) => opt.label === label);
              setFormData({
                ...formData,
                departmentId: selected?.value || "",
                departmentLabel: label,
              });
              setErrors((prev) => ({ ...prev, department: "" }));
            }}
            options={departments.map((opt) => opt.label)}
            dropdownOpen={dropdowns.department}
            setDropdownOpen={(v) => setDropdowns((p) => ({ ...p, department: v }))}
            dropdownRef={refs.department}
            error={errors.department}
            disabled={isLoading || isDepartmentsLoading}
          />

          {/* Process Owner */}
          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Process Owner <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              placeholder="Enter Process Owner"
              value={formData.processOwner}
              onChange={(e) => handleChange("processOwner", e.target.value)}
              disabled={isLoading}
              className={`border text-xs px-4 py-1.5 w-full ${
                errors.processOwner ? "border-red1" : "border-black/30"
              } disabled:bg-gray-100`}
            />
            {errors.processOwner && (
              <span className="text-red1 text-xs">{errors.processOwner}</span>
            )}
          </div>

          {/* Description */}
          <div className="col-span-2">
            <label className="text-xs font-medium text-black mb-2 block">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              placeholder="Enter Description"
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              disabled={isLoading}
              className={`border text-xs px-4 py-2 h-28 w-full resize-none ${
                errors.description ? "border-red1" : "border-black/30"
              } disabled:bg-gray-100`}
            />
            {errors.description && (
              <span className="text-red1 text-xs">{errors.description}</span>
            )}
          </div>

          {/* Upload Process File */}
          <div>
            <label className="text-xs font-medium text-black/70 mb-2 block">
              Upload Process File <span className="text-red-500">*</span>
            </label>
            <label
              htmlFor="process-upload-add"
              className={`cursor-pointer border flex items-center gap-3 px-3 py-1.5 text-xs ${
                errors.processFile ? "border-red1" : "border-black/30"
              } ${isLoading ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              {formData.processFile ? (
                <span className="truncate">{formData.processFile.name}</span>
              ) : (
                <span className="text-gray-400">Choose file (pdf, docx, xlsx – max 10MB)</span>
              )}
              <Upload size={16} className="ml-auto text-gray-400" />
              <input
                type="file"
                id="process-upload-add"
                className="hidden"
                accept=".pdf,.docx,.xlsx"
                disabled={isLoading}
                onChange={handleFileChange}
              />
            </label>
            {errors.processFile && (
              <span className="text-red1 text-xs">{errors.processFile}</span>
            )}
          </div>
        </div>

        {/* Save */}
        <div className="flex justify-center mt-6">
          <button
            onClick={handleSave}
            disabled={isLoading}
            className="bg-darkblue1 text-white px-8 py-1 text-xs border border-darkblue1 hover:bg-white hover:text-darkblue1 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {isLoading && (
              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
            )}
            {isLoading ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddProcess;