"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../Components/Header";

const ProcessDownlaod = () => {
  const [tableData, setTableData] = useState([]);
  const [menuOpen, setMenuOpen] = useState(false);

  // ✅ Receive data from parent window
  useEffect(() => {
    window.opener?.postMessage({ type: "READY_FOR_DATA" }, "*");

    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // ✅ Excel download
const handleDownloadExcel = () => {
  if (!tableData.length) return;

  // Map tableData to Excel-friendly format
  const excelData = tableData.map((row, index) => ({
    "Sl. No": index + 1,
    "Process No.": row.processNo,
    "Process Name": row.processName,
    "Department": row.department,
    "Process Owner": row.processOwner,
    "Description": row.description,
    "Uploaded By": row.uploadedBy,
    "Uploaded Date": row.uploadedDate,
    "Last Modified By": row.lastModifiedBy,
    "Last Modified Date": row.lastModifiedDate,
    "Valid Till": row.validTill || "",   // optional field
    "Active": row.active || "",          // optional field
  }));

  // Convert JSON to worksheet
  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // Create workbook and append worksheet
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Processes");

  // Save Excel file
  XLSX.writeFile(workbook, "Processes.xlsx");
};

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">
            Dealer Address Book
          </h2>

          <button
            onClick={handleDownloadExcel}
            className="bg-darkblue1 text-white text-sm font-medium px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          >
            Download
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Process No.</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 ">Process Name</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Department</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Process Owner</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Description</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Uploaded By</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Uploaded Date</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Last Modified By</th>
                <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">Last Modified Date</th>
              </tr>
            </thead>

            <tbody>
              {tableData.length ? (
                tableData.map((item, index) => (
                  <tr key={index} className="hover:bg-lightBlue/50 text-xs">
                     <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.processNo}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.processName}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.department}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.processOwner}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.description}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.uploadedBy}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.uploadedDate}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.lastModifiedBy}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.lastModifiedDate}</td>
   
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProcessDownlaod;
