"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";

const DownloadTemplate = () => {
  const [tableData, setTableData] = useState([]);
  const [menuOpen, setMenuOpen] = useState(false);

  // ✅ Receive data from parent window
  useEffect(() => {
    window.opener?.postMessage({ type: "READY_FOR_DATA" }, "*");

    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // ✅ Excel download
 const handleDownloadExcel = () => {
  if (!tableData.length) return;

  // Map tableData to Excel-friendly format
  const excelData = tableData.map((row, index) => ({
    "Sl. No": index + 1,
    "Template Name": row.templateName,
    "Department": row.department,
    "Description": row.description,
    "Uploaded By": row.uploadedBy,
    "Uploaded Date": row.uploadedDate,
    "Valid Till": row.validTill,
    "Active": row.active,
  }));

  // Convert JSON to worksheet
  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // Create workbook and append worksheet
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Templates");

  // Save Excel file
  XLSX.writeFile(workbook, "Templates.xlsx");
};


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">
            Dealer Address Book
          </h2>

          <button
            onClick={handleDownloadExcel}
            className="bg-darkblue1 text-white text-sm font-medium px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          >
            Download
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2">Template Name</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Department</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Description</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Uploaded By</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Uploaded Date</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 bprder-r-0">Valid Till</th>
              </tr>
            </thead>

            <tbody>
              {tableData.length ? (
                tableData.map((item, index) => (
                  <tr key={index} className="hover:bg-lightBlue/50 text-xs">
                    <td className="px-4 py-1 border border-grey2">{item.templateName}</td>
                    <td className="px-4 py-1 border border-grey2">{item.department}</td>
                    <td className="px-4 py-1 border border-grey2">{item.description}</td>
                    <td className="px-4 py-1 border border-grey2">
                        {item.uploadedBy}
                    </td>
                    <td className="px-4 py-1 border border-grey2">{item.uploadedDate}</td>
                                        <td className="px-4 py-1 border border-grey2">{item.validTill}</td>

                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DownloadTemplate;
