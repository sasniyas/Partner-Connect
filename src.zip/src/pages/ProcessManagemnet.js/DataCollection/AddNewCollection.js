

"use client";

import { useState, useRef, createRef, useEffect } from "react";
import { Plus, X } from "lucide-react";
import StyledSelectField from "../../../Components/StyledSelectField";

const AddNewCollection = ({ onClose, onSave }) => {
  const [year, setYear] = useState("");
  const [name, setName] = useState("");
  const [isOpen,setIsOpen] =useState(true)
  const [headers, setHeaders] = useState([
    { name: "", type: "", options: ["Option 1"], preview: "" },
  ]);

  /* ---------------- Dropdown State ---------------- */
  const [dropdowns, setDropdowns] = useState({
    year: false,
  });

  /* ---------------- Dynamic Refs ---------------- */
  const refs = useRef({});

  /* ---------------- Year Options ---------------- */
  const currentYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 10 }, (_, i) => {
    const y = currentYear - i;
    return { label: y.toString(), value: y };
  });

  /* ---------------- Header Type Options ---------------- */
  const headerTypeOptions = [
    { label: "Text", value: "text" },
    { label: "File", value: "file" },
    { label: "Drop Down", value: "dropdown" },
  ];

  /* ---------------- Header Logic ---------------- */
  const addHeader = () => {
    setHeaders([
      ...headers,
      { name: "", type: "", options: ["Option 1"], preview: "" },
    ]);
  };

  const removeHeader = (index) => {
    if (headers.length === 1) return;
    setHeaders(headers.filter((_, i) => i !== index));
  };

  const updateHeader = (index, key, value) => {
    const updated = [...headers];
    updated[index][key] = value;
    setHeaders(updated);
  };

  const addOption = (headerIndex) => {
    const updated = [...headers];
    updated[headerIndex].options.push(
      `Option ${updated[headerIndex].options.length + 1}`
    );
    setHeaders(updated);
  };

  const removeOption = (headerIndex, optionIndex) => {
    const updated = [...headers];
    updated[headerIndex].options.splice(optionIndex, 1);
    setHeaders(updated);
  };

  /* ---------------- Close dropdowns on outside click ---------------- */
useEffect(() => {
  const handleClickOutside = (event) => {
    setDropdowns((prevDropdowns) => {
      const updated = { ...prevDropdowns };
      Object.keys(prevDropdowns).forEach((key) => {
        if (
          prevDropdowns[key] &&
          refs.current[key] &&
          refs.current[key].current &&
          !refs.current[key].current.contains(event.target)
        ) {
          updated[key] = false;
        }
      });
      return updated;
    });
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []); // <-- empty dependency

   const handleSave = () => {
    const collectionData = {
      year,
     name,
      headers,
    };
    onSave(collectionData); // Pass data to parent
    onClose(); // Close popup
  };

if (!isOpen) return null;
  return (
<div className="p-6 bg-white w-[50%] mx-auto shadow max-h-screen overflow-y-auto">

      {/* Top Header */}
      <div className="relative mb-4 pb-3">
        <h2 className="text-center text-base text-MediumGrey font-semibold">
          Add New Collection
        </h2>

        <button 
      onClick={onClose}
        className="absolute right-0 top-0">
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
            alt="close"
            className="w-4 h-4"
          />
        </button>
      </div>

      {/* Year & Collection Name */}
      <div className="grid grid-cols-2 gap-4 mb-2">
        <StyledSelectField
          label="Year"
          placeholder="Select Year"
          value={
            yearOptions.find((opt) => opt.value === year)?.label || ""
          }
          setValue={(label) => {
            const selected = yearOptions.find((opt) => opt.label === label);
            setYear(selected?.value || "");
          }}
          options={yearOptions.map((opt) => opt.label)}
          dropdownOpen={dropdowns.year}
          setDropdownOpen={(val) =>
            setDropdowns((prev) => ({ ...prev, year: val }))
          }
          dropdownRef={
            refs.current.year || (refs.current.year = createRef())
          }
          error={null}
        />

        <div className="flex flex-col gap-1 ">
          <label className="text-xs font-medium text-gray-600 mb-1">
            Collection Name
          </label>
          <input
            type="text"
            placeholder="Enter Collection Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="border border-black/30 px-3 py-1.5 text-xs"
          />
        </div>
      </div>

      {/* Dynamic Headers */}
      {headers.map((header, index) => (
        <div key={index} className="mb-2 mt-1">

          <div className="grid grid-cols-[1fr_1fr_auto] gap-4 mb-3 items-center">
            <input
              type="text"
              placeholder={`Header ${index + 1}`}
              value={header.name}
              onChange={(e) =>
                updateHeader(index, "name", e.target.value)
              }
              className="border border-black/30 px-3 py-1.5 text-xs"
            />

            <div className="flex items-center gap-2 -mt-1">
              <StyledSelectField
                placeholder="Select Type"
                value={
                  headerTypeOptions.find(
                    (opt) => opt.value === header.type
                  )?.label || ""
                }
                setValue={(label) => {
                  const selected = headerTypeOptions.find(
                    (opt) => opt.label === label
                  );
                  updateHeader(index, "type", selected?.value || "");
                }}
                options={headerTypeOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns[`type_${index}`] || false}
                setDropdownOpen={(val) =>
                  setDropdowns((prev) => ({
                    ...prev,
                    [`type_${index}`]: val,
                  }))
                }
                dropdownRef={
                  refs.current[`type_${index}`] ||
                  (refs.current[`type_${index}`] = createRef())
                }
                error={null}
              />

              <button
                onClick={() => removeHeader(index)}
                className="text-red-500"
              >
                <img
                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                  alt="Delete"
                  className="w-4 h-4"
                />
              </button>
            </div>
          </div>

          {/* Dropdown Options */}
          {header.type === "dropdown" && (
            <div className="border p-3 flex gap-4">
              <div className="flex-1">
                <div className="flex justify-between mb-2">
                  <p className="text-xs font-medium">Dropdown Options</p>
                  <button
                    onClick={() => addOption(index)}
                    className="text-xs bg-darkblue1 text-white px-2 py-1"
                  >
                    + Add Option
                  </button>
                </div>

                {header.options.map((opt, optIndex) => (
                  <div
                    key={optIndex}
                    className="flex items-center bg-gray-100 px-2 py-1.5 mb-2"
                  >
                    <input
                      type="text"
                      value={opt}
                      onChange={(e) => {
                        const updated = [...headers];
                        updated[index].options[optIndex] = e.target.value;
                        setHeaders(updated);
                      }}
                      className="bg-transparent border-none text-xs w-full outline-none"
                    />
                    <img
                      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
                      alt="close"
                      className="w-4 h-4 cursor-pointer"
                      onClick={() => removeOption(index, optIndex)}
                    />
                  </div>
                ))}
              </div>

              {/* Styled Preview Dropdown */}
             <div className="flex-1">
  <StyledSelectField
    label="Preview"
    placeholder="Select Option"
    value={header.preview || ""}
    setValue={(val) => {
      const updated = [...headers];
      updated[index].preview = val;
      setHeaders(updated);
    }}
    options={header.options}
    dropdownOpen={dropdowns[`preview_${index}`] || false}
    setDropdownOpen={(val) =>
      setDropdowns((prev) => ({
        ...prev,
        [`preview_${index}`]: val,
      }))
    }
    dropdownRef={
      refs.current[`preview_${index}`] ||
      (refs.current[`preview_${index}`] = createRef())
    }
    error={null}
  />
</div>

            </div>
          )}
        </div>
      ))}

      {/* Add Header */}
      <button
        onClick={addHeader}
        className="flex items-center gap-1 text-xs bg-darkblue1 text-white mb-6 px-4 py-1"
      >
        <Plus size={14} /> Add Header
      </button>

      {/* Footer */}
      <div className="flex justify-end gap-3">
        <button
        onClick={handleSave} 
        className="bg-darkblue1 text-white px-8 py-1.5 text-xs">
          Save
        </button>
      </div>
    </div>
  );
};

export default AddNewCollection;
