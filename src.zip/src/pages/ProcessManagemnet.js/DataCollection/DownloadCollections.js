"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";

const DownloadCollections = () => {
  const [tableData, setTableData] = useState([]);
  const [menuOpen, setMenuOpen] = useState(false);

  // ✅ Receive data from parent window
  useEffect(() => {
    window.opener?.postMessage({ type: "READY_FOR_DATA" }, "*");

    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // ✅ Excel download
  const handleDownloadExcel = () => {
    if (!tableData.length) return;

    const excelData = tableData.map((row, index) => ({
      "Sl. No": index + 1,
      Year: row.year,
      "Collection Name": row.name,
      "Created By": row.createdBy,
      "Created Date": row.createdDate,
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Collections");
    XLSX.writeFile(workbook, "Collections.xlsx");
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">
            Collections Preview
          </h2>

          <button
            onClick={handleDownloadExcel}
            className="bg-darkblue1 text-white text-sm font-medium px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          >
            Download
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2">Year</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Collection Name</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Created By</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Created Date</th>
              </tr>
            </thead>

            <tbody>
              {tableData.length ? (
                tableData.map((item, index) => (
                  <tr key={index} className="hover:bg-lightBlue/50 text-xs">
                    <td className="px-4 py-1 border border-grey2">{item.year}</td>
                    <td className="px-4 py-1 border border-grey2">{item.name}</td>
                    <td className="px-4 py-1 border border-grey2">{item.createdBy}</td>
                    <td className="px-4 py-1 border border-grey2">{item.createdDate}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DownloadCollections;
