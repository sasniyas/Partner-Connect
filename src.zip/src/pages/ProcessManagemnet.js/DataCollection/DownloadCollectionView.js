"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";

const DownloadCollectionView = () => {
  const [tableData, setTableData] = useState([]);
  const [menuOpen, setMenuOpen] = useState(false);

  // Receive data from parent window
  useEffect(() => {
  const timer = setTimeout(() => {
    window.opener?.postMessage({ type: "READY_FOR_DATA" }, "*");
  }, 100); // 100ms delay

  const handler = (event) => {
    if (event.data?.type === "INIT_DATA") {
      setTableData(event.data.payload || []);
    }
  };

  window.addEventListener("message", handler);
  return () => {
    clearTimeout(timer);
    window.removeEventListener("message", handler);
  };
}, []);


  // Excel download
  const handleDownloadExcel = () => {
    if (!tableData.length) return;

    const excelData = tableData.map((row, index) => ({
      "Sl. No": index + 1,
      "Created By": row.createdBy,
      "Created Date": row.createdDate,
      Size: row.size,
      Color: row.color,
      Print: row.print,
      Count: row.count,
      "Uploaded File": row.uploadedFile,
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "CollectionView");
    XLSX.writeFile(workbook, "CollectionView.xlsx");
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">
            View Event
          </h2>

          <button
            onClick={handleDownloadExcel}
            className="bg-darkblue1 text-white text-sm font-medium px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          >
            Download
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2">Created By</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Created Date</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Size</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Color</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Print</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Count</th>
                <th className="px-4 py-1.5 text-xs border border-grey2">Uploaded File</th>
              </tr>
            </thead>

            <tbody>
              {tableData.length ? (
                tableData.map((row, index) => (
                  <tr key={index} className="hover:bg-lightBlue/50 text-xs">
                    <td className="px-4 py-1 border border-grey2">{row.createdBy}</td>
                    <td className="px-4 py-1 border border-grey2">{row.createdDate}</td>
                    <td className="px-4 py-1 border border-grey2">{row.size}</td>
                    <td className="px-4 py-1 border border-grey2">{row.color}</td>
                    <td className="px-4 py-1 border border-grey2">{row.print}</td>
                    <td className="px-4 py-1 border border-grey2">{row.count}</td>
                    <td className="px-4 py-1 border border-grey2">{row.uploadedFile}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DownloadCollectionView;
