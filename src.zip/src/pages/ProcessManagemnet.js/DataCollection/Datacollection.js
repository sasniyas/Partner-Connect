"use client"

import { useState, useRef, useEffect } from "react";
import Searchinput from "../../../Components/Searchinput";
import Filter from "../../../Components/Filter";
import { Eye, MoreVertical } from "lucide-react";
import { useNavigate } from "react-router-dom";
import DeleteModal from "../../../Components/DeleteModal";
// import AddCollectionPopup from "./AddCollection";
// import EditCollectionPopup from "./EditCollection";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import AddNewCollection from "./AddNewCollection";
import EditDataCollection from "./EditDataCollection";
import CollectionView from "./Collectionview";

const Datacollection = () => {
  const navigate = useNavigate();
  const [popupOpen, setPopupOpen] = useState(false);
const [currentView, setCurrentView] = useState("table"); // "table" or "view"
const [viewData, setViewData] = useState(null); // store the selected collection

  // Filters and search
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedYear, setSelectedYear] = useState("");
  const [selectedCreatedBy, setSelectedCreatedBy] = useState("");
    const tableContainerRef = useRef(null);
     const [editData, setEditData] = useState(null); // Data to edit
  const [showEditPopup, setShowEditPopup] = useState(false);
  // Table & modals
  const [tableData, setTableData] = useState([
    {
      id: 1,
      year: 2024,
      name: "Summer Collection",
      createdBy: "Admin",
      createdDate: "2024-06-01",
    },
    {
      id: 2,
      year: 2025,
      name: "Winter Collection",
      createdBy: "Manager",
      createdDate: "2025-01-15",
    },
  ]);

  const [dropdownId, setDropdownId] = useState(null);
  const dropdownRefs = useRef({});
  const [deleteItem, setDeleteItem] = useState(null);
  const [selectedRow, setSelectedRow] = useState(null);
  const [isAddPopupOpen, setIsAddPopupOpen] = useState(false);
  const [editingCollection, setEditingCollection] = useState(null);
  const fileInputRef = useRef(null);

  const yearsOptions = [2023, 2024, 2025];
  const createdByOptions = ["Admin", "Manager", "HR Team"];

const filteredItems = tableData.filter((item) => {
  const searchLower = searchTerm.toLowerCase();
  const name = item.name || "";        // fallback if undefined
  const createdBy = item.createdBy || ""; // fallback if undefined

  return (
    (name.toLowerCase().includes(searchLower) ||
     createdBy.toLowerCase().includes(searchLower)) &&
    (selectedYear ? item.year === selectedYear : true) &&
    (selectedCreatedBy ? createdBy === selectedCreatedBy : true)
  );
});



  // Close dropdowns on click outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      const isClickInsideRowDropdown = Object.values(dropdownRefs.current).some(
        (ref) => ref && ref.contains(e.target)
      );
      if (!isClickInsideRowDropdown) setDropdownId(null);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Add / Edit / Delete handlers
  

  const handleDeleteClick = (item) => {
    setDeleteItem(item);
    setSelectedRow(item.id);
  };

  const handleConfirmDelete = () => {
    setTableData((prev) => prev.filter((row) => row.id !== selectedRow));
    setDeleteItem(null);
    setSelectedRow(null);
  };

  const handleDownload = async () => {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Collections");
    sheet.columns = [
      { header: "Year", key: "year", width: 10 },
      { header: "Collection Name", key: "name", width: 25 },
      { header: "Created By", key: "createdBy", width: 20 },
      { header: "Created Date", key: "createdDate", width: 15 },
    ];
    tableData.forEach((row) => sheet.addRow(row));
    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer]), "Collections.xlsx");
  };

  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];
      const json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });
      const finalRows = json.map((row, i) => ({
        id: Date.now() + i,
        year: row["Year"] || "",
        name: row["Collection Name"] || "",
        createdBy: row["Created By"] || "",
        createdDate: row["Created Date"] || "",
      }));
      setTableData((prev) => [...finalRows, ...prev]);
    };
    reader.readAsArrayBuffer(file);
  };
const handleSaveCollection = (data) => {
  const newRow = {
    id: Date.now(),
    year: data.year,
    name: data.name,
    createdBy: "Admin", // you can make this dynamic
    createdDate: new Date().toISOString().split("T")[0],
    headers: data.headers,
  };
  setTableData((prev) => [newRow, ...prev]);
  setPopupOpen(false);
};
 const handleEditClick = (item) => {
    setEditData(item);
    setShowEditPopup(true);
  };


  const handleUpdate = (updatedData) => {
     setTableData((prev) =>
      prev.map((col) => (col.id === editData.id ? { ...col, ...updatedData } : col))
    );
  };
  const handlePreviewAndDownload = () => {
  const data = filteredItems; // filtered collections
  const newWindow = window.open("/collectiondwonload", "_blank"); // open blank window

  // Wait for the window to be ready
  const handleReady = (event) => {
    if (event.source === newWindow && event.data?.type === "READY_FOR_DATA") {
      newWindow.postMessage({ type: "INIT_DATA", payload: data }, "*");
      window.removeEventListener("message", handleReady);
    }
  };

  window.addEventListener("message", handleReady);
};

  return (

    <div >
      {currentView === "table" && (
      <div>
      {/* Top bar */}
      <div className="flex justify-between items-center mb-2">
        <div className="flex gap-2">
          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search"
            className="w-[1/2]"
            iconColor="text-black"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            inputWidth="w-full"
            focusRing="focus:ring-1 focus:ring-black/60"
            hoverInputClasses="hover:bg-white hover:border-black/60"
          />
        
        </div>
        <div className="flex gap-2">
          <button
        onClick={() => setPopupOpen(true)}
            className="bg-darkblue1 text-white px-4 py-1 text-xs flex items-center gap-2"
          >
            + Add Collection
          </button>
         <button 
           onClick={handlePreviewAndDownload}
          className="py-1 px-6 bg-white  text-black text-xs border border-black/30 hover:bg-lightBlue/50 flex items-center gap-2">
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Scorecard/template.png"
              alt="bulk"
              className="w-4 h-4"
            />
            Download
          </button>

        </div>
      </div>
<div className="bg-white shadow-md border border-Dustyblue mt-3">
  <div
    ref={tableContainerRef}
    className="overflow-y-auto overflow-x-auto max-h-[500px]" // adjust height as needed
    style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
  >
    <table className="text-sm w-full">
      <thead className="bg-Dustyblue text-white text-left text-xs sticky top-0 z-10">
        <tr>
          <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%]">Year</th>
          <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[25%]">Collection Name</th>
          <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%]">Created By</th>
          <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%]">Created Date</th>
          <th className="px-4 py-1.5 text-center border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 w-[10%]">Actions</th>
        </tr>
      </thead>
      <tbody>
        {filteredItems.length > 0 ? (
          filteredItems.map((item, idx) => {
            const rowId = `collection-${item.id}`;
            return (
              <tr
                key={rowId}
                className="hover:bg-lightBlue/50 cursor-pointer text-black text-xs"
              >
                <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.year}</td>
                <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.name}</td>
                <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.createdBy}</td>
                <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.createdDate}</td>
<td className="py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0 text-xs">
  <div className="relative flex items-center justify-center">
    <button
      onClick={() => setDropdownId(dropdownId === rowId ? null : rowId)}
      className="w-6 h-6 flex items-center justify-center border border-gray-300 hover:bg-gray-100"
    >
      <MoreVertical size={16} className="text-black" />
    </button>

    {dropdownId === rowId && (
      <div
        ref={(el) => (dropdownRefs.current[rowId] = el)}
        className="absolute right-0 mt-1 bg-white w-40 border border-gray-200 shadow-lg z-50"
      >
        <div className="py-1 flex flex-col">
          
          {/* View */}
         {/* View */}
<button
  onClick={() => {
    setViewData(item);        // store selected collection
    setCurrentView("view");   // switch to view mode
    setDropdownId(null);      // close dropdown
  }}
  className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
>
  <Eye size={16} />
  View
</button>


          {/* Edit */}
          <button
            onClick={() => {
            setEditData(item);
    setShowEditPopup(true);
              setDropdownId(null);
            }}
            className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
          >
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
              alt="Edit"
              className="w-4 h-4"
            />
            Edit
          </button>

          {/* Delete */}
          <button
            onClick={() => {
              handleDeleteClick(item);
              setDropdownId(null);
            }}
            className="w-full px-3 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
          >
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
              alt="Delete"
              className="w-4 h-4"
            />
            Delete
          </button>

        </div>
      </div>
    )}
  </div>
</td>

              </tr>
            );
          })
        ) : (
          <tr>
            <td colSpan={5} className="text-center py-8 text-xs text-gray-500 italic">
              No data found
            </td>
          </tr>
        )}
      </tbody>
    </table>
  </div>
</div>
 </div>
      )}
      {currentView === "view" && viewData && (<CollectionView viewData={viewData}
      onBack={()=>{
        setCurrentView ("table")
        setViewData(null)
      }} />)}
      {deleteItem && (
        <DeleteModal
          isOpen={true}
          onClose={() => setDeleteItem(null)}
          onConfirm={handleConfirmDelete}
          extraMessage="This collection will be permanently deleted."
        />
      )}

     

      {/* Hidden file input for bulk upload */}
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        accept=".xlsx,.xls"
        onChange={handleBulkUpload}
      />
       {popupOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <AddNewCollection onClose={() => setPopupOpen(false)} 
             onSave={handleSaveCollection} />
        </div>
      )}
     {showEditPopup && editData && (
  <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
    <EditDataCollection
      initialData={editData}
      onClose={() => setShowEditPopup(false)}
      onSave={(updatedRow) => {
        handleUpdate(updatedRow);
        setShowEditPopup(false);
      }}
    />
  </div>
)}

   
    </div>
  );
};

export default Datacollection;
