"use client";
import React, { useState, useRef, createRef, useEffect } from "react";
import { ArrowLeft } from "lucide-react";
import StyledSelectField from "../../../Components/StyledSelectField";
import DeleteModal from "../../../Components/DeleteModal";

const CollectionView = ({ onBack }) => {
  const [tableData, setTableData] = useState([
    {
      id: 1,
      createdBy: "Admin",
      createdDate: "2024-06-01",
      size: "M",
      color: "Red",
      print: "Floral",
      count: 50,
      uploadedFile: "summer_collection.xlsx",
    },
    {
      id: 2,
      createdBy: "Manager",
      createdDate: "2025-01-15",
      size: "L",
      color: "Blue",
      print: "Striped",
      count: 30,
      uploadedFile: "winter_collection.xlsx",
    },
  ]);

  const [isEditing, setIsEditing] = useState(false);
  const [editRow, setEditRow] = useState(null);
const [deleteRow, setDeleteRow] = useState(null); // the row selected to delete
const [isDeleteOpen, setIsDeleteOpen] = useState(false); // modal open state

  const [dropdowns, setDropdowns] = useState({});
  const refs = useRef({});

  const sizeOptions = ["S", "M", "L", "XL"];

  const handleDelete = (id) => {
    setTableData((prev) => prev.filter((row) => row.id !== id));
  };

  const handleEdit = (row) => {
    setEditRow(row);
    setIsEditing(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditRow((prev) => ({
      ...prev,
      [name]: name === "count" ? Number(value) : value,
    }));
  };

  const handleSave = () => {
    setTableData((prevData) =>
      prevData.map((row) => (row.id === editRow.id ? editRow : row))
    );
    setIsEditing(false);
    setEditRow(null);
  };

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      setDropdowns((prev) => {
        const updated = { ...prev };
        Object.keys(prev).forEach((key) => {
          if (refs.current[key]?.current && !refs.current[key].current.contains(event.target)) {
            updated[key] = false;
          }
        });
        return updated;
      });
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
const handlePreviewAndDownload = (data) => {
  if (!data || !data.length) return alert("No data to preview/download");

  const newWindow = window.open("/DownloadCollectionView", "_blank");
  if (!newWindow) return alert("Popup blocked. Please allow popups.");

  // Listen for READY message from new window
  const handleReady = (event) => {
    if (event.source === newWindow && event.data?.type === "READY_FOR_DATA") {
      newWindow.postMessage({ type: "INIT_DATA", payload: data }, "*");
      window.removeEventListener("message", handleReady);
    }
  };

  window.addEventListener("message", handleReady);
};




  return (
    <div>
      {/* Header */}
     <div className="flex items-center justify-between w-full ">
  <div className="flex items-center gap-2">
    <ArrowLeft
      onClick={onBack}
      size={20}
      className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
    />
    <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">
      View Event
    </h2>
  </div>

  
  <button 
             onClick={() => handlePreviewAndDownload(tableData)}

          className="py-1 px-6 bg-white  text-black text-xs border border-black/30 hover:bg-lightBlue/50 flex items-center gap-2">
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Scorecard/template.png"
              alt="bulk"
              className="w-4 h-4"
            />
            Download
          </button>
</div>
            <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-7 "></div>


      {/* Table */}
      <div className="bg-white shadow-md border border-Dustyblue mt-3">
        <table className="text-sm w-full border-collapse">
          <thead className="bg-Dustyblue text-white text-left text-xs sticky top-0 z-10">
            <tr>
              <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                Created By
              </th>
              <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                Created Date
              </th>
              <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                Size
              </th>
              <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                Color
              </th>
              <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                Print
              </th>
              <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                Count
              </th>
              <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-b-0">
                Uploaded File
              </th>
              <th className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 border-r-0 text-center">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {tableData.length > 0 ? (
              tableData.map((row) => (
                <tr
                  key={row.id}
                  className="hover:bg-lightBlue/50 text-black text-xs"
                >
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                    {row.createdBy}
                  </td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                    {row.createdDate}
                  </td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                    {row.size}
                  </td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                    {row.color}
                  </td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                    {row.print}
                  </td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                    {row.count}
                  </td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                    {row.uploadedFile}
                  </td>
                  <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-center flex justify-center gap-2">
                    <button
                      onClick={() => handleEdit(row)}
                      className="text-blue-600"
                    >
                      <img
                        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
                        alt="Edit"
                        className="w-4 h-4"
                      />
                    </button>
                    <button
  onClick={() => {
    setDeleteRow(row);   // set the row to delete
    setIsDeleteOpen(true); // open modal
  }}
  className="text-red-600"
>
  <img
    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
    alt="Delete"
    className="w-4 h-4"
  />
</button>

                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={8}
                  className="text-center py-8 text-xs text-gray-500 italic"
                >
                  No data found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Edit Modal */}
      {isEditing && editRow && (
        <>
          {/* Overlay */}
          <div
            className="fixed inset-0 bg-black bg-opacity-30 z-40"
            onClick={() => setIsEditing(false)}
          />

          {/* Modal */}
          <div
            className="fixed top-1/4 left-1/2 transform -translate-x-1/2 bg-white p-6 shadow-lg w-[70%] max-w-md z-50"
            onClick={(e) => e.stopPropagation()}
          >
           <div className="relative mb-4">
  <h3 className="font-semibold text-center text-MediumGrey text-base">
    Edit Details
  </h3>
  <button
    onClick={() => setIsEditing(false)}
    className="absolute right-0 top-0 text-gray-400 hover:text-gray-600"
    aria-label="Close modal"
  >
    <img
      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
      alt="close"
      className="w-4 h-4"
    />
  </button>
</div>


            <div className="grid grid-cols-2 gap-4 mb-2">
              {/* StyledSelectField for Size */}
              <div className="flex-1">
                <StyledSelectField
                  label="Size"
                  placeholder="Select Size"
                  value={editRow.size || ""}
                  setValue={(val) =>
                    setEditRow((prev) => ({ ...prev, size: val }))
                  }
                  options={sizeOptions}
                  dropdownOpen={dropdowns.size || false}
                  setDropdownOpen={(val) =>
                    setDropdowns((prev) => ({ ...prev, size: val }))
                  }
                  dropdownRef={refs.current.size || (refs.current.size = createRef())}
                />
              </div>

              {/* Color */}
              <div className="flex-1 flex flex-col gap-1">
                <label className="text-xs font-medium text-gray-600 mb-1">
                  Color
                </label>
                <input
                  type="text"
                  value={editRow.color || ""}
                  onChange={handleChange}
                  name="color"
                  className="border border-black/30 px-3 py-1.5 text-xs w-full"
                />
              </div>

              {/* Print */}
              <div className="flex-1 flex flex-col gap-1">
                <label className="text-xs font-medium text-gray-600 mb-1">
                  Print
                </label>
                <input
                  type="text"
                  value={editRow.print || ""}
                  onChange={handleChange}
                  name="print"
                  className="border border-black/30 px-3 py-1.5 text-xs w-full"
                />
              </div>

              {/* Count */}
              <div className="flex-1 flex flex-col gap-1">
                <label className="text-xs font-medium text-gray-600 mb-1">
                  Count
                </label>
                <input
                  type="number"
                  value={editRow.count || ""}
                  min="1"
                  onChange={handleChange}
                  name="count"
                  className="border border-black/30 px-3 py-1.5 text-xs w-full"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={handleSave}
                className="bg-darkblue1 text-white px-8 text-xs py-1 hover:bg-darkblue1/90"
              >
                Save
              </button>
            </div>
          </div>
        </>
      )}
      <DeleteModal
  isOpen={isDeleteOpen}
  onClose={() => setIsDeleteOpen(false)}
  onConfirm={() => {
    if (deleteRow) {
      setTableData((prev) =>
        prev.filter((row) => row.id !== deleteRow.id)
      );
    }
    setIsDeleteOpen(false);
    setDeleteRow(null);
  }}
  extraMessage={`This will delete the record created by "${deleteRow?.createdBy}".`}
/>

    </div>
  );
};

export default CollectionView;
