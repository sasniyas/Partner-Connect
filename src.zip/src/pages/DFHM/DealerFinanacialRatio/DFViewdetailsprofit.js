import React, { useState } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft,ArrowDown,ArrowUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useMemo } from "react";
const DFViewdetailsprofit = () => {
  const { state } = useLocation();
const mode = state?.mode;
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
const [activeTab, setActiveTab] = useState("profit");
const [activeQuarter, setActiveQuarter] = useState("Q1");
const [activeMetric, setActiveMetric] = useState("revenue");
const tableContainerRef = React.useRef(null);
  const handleback = () => {
    navigate("/dfhm/dealerfinacialratio");
  };
 

  const handleTabClick = (tab, path) => {
    setActiveTab(tab); // sets the active tab for styling
    navigate(path);    // navigates to the route
  };


const quarterMonths = {
  Q1: ["Jan", "Feb", "Mar"],
  Q2: ["Apr", "May", "Jun"],
  Q3: ["Jul", "Aug", "Sep"],
  Q4: ["Oct", "Nov", "Dec"],
};
const monthsForQuarter = quarterMonths[activeQuarter];
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


const financeDataByMetric = {
  revenue: {
    Q1: [
      {
        category: "Revenue Machine",
        rows: [
      { 
        subCategory: "Machine", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,28900"
        } 
      },
      
 { 
        subCategory: "Rental", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Used Equipments", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Machines Commissions", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Revenue Machine", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Revenue services",
        rows: [
      { 
        subCategory: "Retail services", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "CSA services", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Warrenty services", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Warranty Commission", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Revenue Services", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Others",
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Revenue- UPP",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Revenue",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]}
    ],
     Q2: [
    {
      category: "Revenue Machine",
      rows: [
        { subCategory: "Machine", values: { Jan: "3,00,00,000", Feb: "4,50,00,000", Mar: "5,00,00,000", Q1: "12,50,00,000", YTD: "90,00,000", BP: "90,00,000", VSBP: "90,00,000", VBPM: "90,00,000", runRate: "91,00,000" } },
        { subCategory: "Rental", values: { Jan: "1,00,00,000", Feb: "1,50,00,000", Mar: "1,75,00,000", Q1: "4,25,00,000", YTD: "88,00,000", BP: "88,00,000", VSBP: "88,00,000", VBPM: "88,00,000", runRate: "89,00,000" } },
        { subCategory: "Used Equipments", values: { Jan: "2,50,00,000", Feb: "3,00,00,000", Mar: "2,75,00,000", Q1: "8,25,00,000", YTD: "85,00,000", BP: "85,00,000", VSBP: "85,00,000", VBPM: "85,00,000", runRate: "86,00,000" } },
        { subCategory:"Machines Commissions", values: { Jan: "50,00,000", Feb: "60,00,000", Mar: "70,00,000", Q1: "1,80,00,000", YTD: "82,00,000", BP: "82,00,000", VSBP: "82,00,000", VBPM: "82,00,000", runRate: "83,00,000" } },
        { subCategory:"Total Revenue Machine", isTotal:true, values: { Jan: "7,00,00,000", Feb: "9,60,00,000", Mar: "10,20,00,000", Q1: "26,80,00,000", YTD: "87,00,000", BP: "87,00,000", VSBP: "87,00,000", VBPM: "87,00,000", runRate: "88,00,000" } }
      ]
    },
    {
      category: "Revenue services",
      rows: [
        { subCategory: "Retail services", values: { Jan: "1,50,00,000", Feb: "2,00,00,000", Mar: "2,50,00,000", Q1: "6,00,00,000", YTD: "70,00,000", BP: "70,00,000", VSBP: "70,00,000", VBPM: "70,00,000", runRate: "71,00,000" } },
        { subCategory: "CSA services", values: { Jan: "80,00,000", Feb: "90,00,000", Mar: "1,00,00,000", Q1: "2,70,00,000", YTD: "68,00,000", BP: "68,00,000", VSBP: "68,00,000", VBPM: "68,00,000", runRate: "69,00,000" } },
        { subCategory: "Warrenty services", values: { Jan: "60,00,000", Feb: "70,00,000", Mar: "80,00,000", Q1: "2,10,00,000", YTD: "65,00,000", BP: "65,00,000", VSBP: "65,00,000", VBPM: "65,00,000", runRate: "66,00,000" } },
        { subCategory:"Warranty Commission", values: { Jan: "30,00,000", Feb: "35,00,000", Mar: "40,00,000", Q1: "1,05,00,000", YTD: "62,00,000", BP: "62,00,000", VSBP: "62,00,000", VBPM: "62,00,000", runRate: "63,00,000" } },
        { subCategory:"Total Revenue Services", isTotal:true, values: { Jan: "3,20,00,000", Feb: "3,95,00,000", Mar: "4,70,00,000", Q1: "11,85,00,000", YTD: "67,00,000", BP: "67,00,000", VSBP: "67,00,000", VBPM: "67,00,000", runRate: "68,00,000" } }
      ]
    },
    {
      category: "Others",
      rows: [
        { subCategory: "", values: { Jan: "50,00,000", Feb: "60,00,000", Mar: "70,00,000", Q1: "1,80,00,000", YTD: "60,00,000", BP: "60,00,000", VSBP: "60,00,000", VBPM: "60,00,000", runRate: "61,00,000" } }
      ]
    },
    {
      category: "Total Revenue- UPP",
      isTotalRow:true,
      rows: [
        { subCategory: "", values: { Jan: "10,00,00,000", Feb: "13,00,00,000", Mar: "15,00,00,000", Q1: "38,00,00,000", YTD: "90,00,000", BP: "90,00,000", VSBP: "90,00,000", VBPM: "90,00,000", runRate: "91,00,000" } }
      ]
    },
    {
      category: "Total Revenue",
      isTotalRow:true,
      rows: [
        { subCategory: "", values: { Jan: "10,50,00,000", Feb: "13,60,00,000", Mar: "15,70,00,000", Q1: "39,80,00,000", YTD: "91,00,000", BP: "91,00,000", VSBP: "91,00,000", VBPM: "91,00,000", runRate: "92,00,000" } }
      ]
    }
  ],
  Q3: [
    // same structure, different dummy values
    {
      category: "Revenue Machine",
      rows: [
        { subCategory: "Machine", values: { Jan: "4,00,00,000", Feb: "4,50,00,000", Mar: "5,50,00,000", Q1: "14,00,00,000", YTD: "95,00,000", BP: "95,00,000", VSBP: "95,00,000", VBPM: "95,00,000", runRate: "96,00,000" } },
        { subCategory: "Rental", values: { Jan: "1,20,00,000", Feb: "1,70,00,000", Mar: "1,90,00,000", Q1: "4,80,00,000", YTD: "92,00,000", BP: "92,00,000", VSBP: "92,00,000", VBPM: "92,00,000", runRate: "93,00,000" } },
        { subCategory: "Used Equipments", values: { Jan: "2,80,00,000", Feb: "3,20,00,000", Mar: "3,00,00,000", Q1: "9,00,00,000", YTD: "90,00,000", BP: "90,00,000", VSBP: "90,00,000", VBPM: "90,00,000", runRate: "91,00,000" } },
        { subCategory:"Machines Commissions", values: { Jan: "60,00,000", Feb: "70,00,000", Mar: "80,00,000", Q1: "2,10,00,000", YTD: "88,00,000", BP: "88,00,000", VSBP: "88,00,000", VBPM: "88,00,000", runRate: "89,00,000" } },
        { subCategory:"Total Revenue Machine", isTotal:true, values: { Jan: "8,60,00,000", Feb: "9,90,00,000", Mar: "10,80,00,000", Q1: "29,30,00,000", YTD: "89,00,000", BP: "89,00,000", VSBP: "89,00,000", VBPM: "89,00,000", runRate: "90,00,000" } }
      ]
    },
    {
      category: "Revenue services",
      rows: [
        { subCategory: "Retail services", values: { Jan: "1,70,00,000", Feb: "2,10,00,000", Mar: "2,80,00,000", Q1: "6,60,00,000", YTD: "72,00,000", BP: "72,00,000", VSBP: "72,00,000", VBPM: "72,00,000", runRate: "73,00,000" } },
        { subCategory: "CSA services", values: { Jan: "90,00,000", Feb: "1,00,00,000", Mar: "1,10,00,000", Q1: "3,00,00,000", YTD: "70,00,000", BP: "70,00,000", VSBP: "70,00,000", VBPM: "70,00,000", runRate: "71,00,000" } },
        { subCategory: "Warrenty services", values: { Jan: "70,00,000", Feb: "80,00,000", Mar: "90,00,000", Q1: "2,40,00,000", YTD: "68,00,000", BP: "68,00,000", VSBP: "68,00,000", VBPM: "68,00,000", runRate: "69,00,000" } },
        { subCategory:"Warranty Commission", values: { Jan: "35,00,000", Feb: "40,00,000", Mar: "45,00,000", Q1: "1,20,00,000", YTD: "66,00,000", BP: "66,00,000", VSBP: "66,00,000", VBPM: "66,00,000", runRate: "67,00,000" } },
        { subCategory:"Total Revenue Services", isTotal:true, values: { Jan: "3,05,00,000", Feb: "3,60,00,000", Mar: "4,35,00,000", Q1: "11,25,00,000", YTD: "67,00,000", BP: "67,00,000", VSBP: "67,00,000", VBPM: "67,00,000", runRate: "68,00,000" } }
      ]
    },
    {
      category: "Others",
      rows: [
        { subCategory: "", values: { Jan: "55,00,000", Feb: "65,00,000", Mar: "75,00,000", Q1: "1,95,00,000", YTD: "63,00,000", BP: "63,00,000", VSBP: "63,00,000", VBPM: "63,00,000", runRate: "64,00,000" } }
      ]
    },
    {
      category: "Total Revenue- UPP",
      isTotalRow:true,
      rows: [
        { subCategory: "", values: { Jan: "10,85,00,000", Feb: "13,95,00,000", Mar: "15,85,00,000", Q1: "40,65,00,000", YTD: "91,00,000", BP: "91,00,000", VSBP: "91,00,000", VBPM: "91,00,000", runRate: "92,00,000" } }
      ]
    },
    {
      category: "Total Revenue",
      isTotalRow:true,
      rows: [
        { subCategory: "", values: { Jan: "11,40,00,000", Feb: "14,55,00,000", Mar: "16,65,00,000", Q1: "42,60,00,000", YTD: "92,00,000", BP: "92,00,000", VSBP: "92,00,000", VBPM: "92,00,000", runRate: "93,00,000" } }
      ]
    }
  ],
  Q4: [
    // same structure, different dummy values
    {
      category: "Revenue Machine",
      rows: [
        { subCategory: "Machine", values: { Jan: "5,00,00,000", Feb: "5,50,00,000", Mar: "6,00,00,000", Q1: "16,50,00,000", YTD: "100,00,000", BP: "100,00,000", VSBP: "100,00,000", VBPM: "100,00,000", runRate: "101,00,000" } },
        { subCategory: "Rental", values: { Jan: "1,50,00,000", Feb: "1,80,00,000", Mar: "2,00,00,000", Q1: "5,30,00,000", YTD: "97,00,000", BP: "97,00,000", VSBP: "97,00,000", VBPM: "97,00,000", runRate: "98,00,000" } },
        { subCategory: "Used Equipments", values: { Jan: "3,00,00,000", Feb: "3,30,00,000", Mar: "3,50,00,000", Q1: "9,80,00,000", YTD: "95,00,000", BP: "95,00,000", VSBP: "95,00,000", VBPM: "95,00,000", runRate: "96,00,000" } },
        { subCategory:"Machines Commissions", values: { Jan: "70,00,000", Feb: "80,00,000", Mar: "90,00,000", Q1: "2,40,00,000", YTD: "93,00,000", BP: "93,00,000", VSBP: "93,00,000", VBPM: "93,00,000", runRate: "94,00,000" } },
        { subCategory:"Total Revenue Machine", isTotal:true, values: { Jan: "9,20,00,000", Feb: "10,40,00,000", Mar: "10,90,00,000", Q1: "30,50,00,000", YTD: "95,00,000", BP: "95,00,000", VSBP: "95,00,000", VBPM: "95,00,000", runRate: "96,00,000" } }
      ]
    },
    {
      category: "Revenue services",
      rows: [
        { subCategory: "Retail services", values: { Jan: "1,90,00,000", Feb: "2,30,00,000", Mar: "2,90,00,000", Q1: "7,10,00,000", YTD: "75,00,000", BP: "75,00,000", VSBP: "75,00,000", VBPM: "75,00,000", runRate: "76,00,000" } },
        { subCategory: "CSA services", values: { Jan: "1,00,00,000", Feb: "1,10,00,000", Mar: "1,20,00,000", Q1: "3,30,00,000", YTD: "72,00,000", BP: "72,00,000", VSBP: "72,00,000", VBPM: "72,00,000", runRate: "73,00,000" } },
        { subCategory: "Warrenty services", values: { Jan: "80,00,000", Feb: "90,00,000", Mar: "1,00,00,000", Q1: "2,70,00,000", YTD: "70,00,000", BP: "70,00,000", VSBP: "70,00,000", VBPM: "70,00,000", runRate: "71,00,000" } },
        { subCategory:"Warranty Commission", values: { Jan: "40,00,000", Feb: "45,00,000", Mar: "50,00,000", Q1: "1,35,00,000", YTD: "68,00,000", BP: "68,00,000", VSBP: "68,00,000", VBPM: "68,00,000", runRate: "69,00,000" } },
        { subCategory:"Total Revenue Services", isTotal:true, values: { Jan: "3,10,00,000", Feb: "3,75,00,000", Mar: "4,60,00,000", Q1: "11,45,00,000", YTD: "68,00,000", BP: "68,00,000", VSBP: "68,00,000", VBPM: "68,00,000", runRate: "69,00,000" } }
      ]
    },
    {
      category: "Others",
      rows: [
        { subCategory: "", values: { Jan: "60,00,000", Feb: "70,00,000", Mar: "80,00,000", Q1: "2,10,00,000", YTD: "65,00,000", BP: "65,00,000", VSBP: "65,00,000", VBPM: "65,00,000", runRate: "66,00,000" } }
      ]
    },
    {
      category: "Total Revenue- UPP",
      isTotalRow:true,
      rows: [
        { subCategory: "", values: { Jan: "11,10,00,000", Feb: "14,10,00,000", Mar: "16,40,00,000", Q1: "41,60,00,000", YTD: "92,00,000", BP: "92,00,000", VSBP: "92,00,000", VBPM: "92,00,000", runRate: "93,00,000" } }
      ]
    },
    {
      category: "Total Revenue",
      isTotalRow:true,
      rows: [
        { subCategory: "", values: { Jan: "11,70,00,000", Feb: "14,80,00,000", Mar: "16,90,00,000", Q1: "43,40,00,000", YTD: "93,00,000", BP: "93,00,000", VSBP: "93,00,000", VBPM: "93,00,000", runRate: "94,00,000" } }
      ]
    }
  ]
  },
  expense: {
 Q1: [
      {
        category: "Salary Expenses",
        rows: [
      { 
        subCategory: "Sales", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Administration", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Administration", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Salary Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Sales, General & Admin Expenses",
        rows: [
      { 
        subCategory: "Selling Expenses (travel, ent)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Administrative Expenses", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Depreciation & Amortization", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Expenses", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Sales, General & Admin Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       

        {
        category: "Total Salary& SGA Expenses",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "SG&A% of Revenue",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
         {
        category: "Other Income/Expenses",
        rows: [
      { 
        subCategory: "Other Income (scrap, credits)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Other Expenses(in Negative)", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
      
      { 
        subCategory:"Total Other Income/Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       

        {
        category: "Operating Margin",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Operating Margin %",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
         {
        category: "Total Finance Costs",
        rows: [
      { 
        subCategory: "Selling Expenses (travel, ent)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Total Finance Costs", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Interest Expenses", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Total Finance Costs", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"OPEX (incl.finance cost) % of Revenue", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } ,
      { 
        subCategory:"Total Salary Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      
      ]
      },
      ],
        Q2: [
      {
        category: "Salary Expenses",
        rows: [
      { 
        subCategory: "Sales", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Administration", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Administration", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Salary Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Sales, General & Admin Expenses",
        rows: [
      { 
        subCategory: "Selling Expenses (travel, ent)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Administrative Expenses", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Depreciation & Amortization", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Expenses", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Sales, General & Admin Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       

        {
        category: "Total Salary& SGA Expenses",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "SG&A% of Revenue",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
         {
        category: "Other Income/Expenses",
        rows: [
      { 
        subCategory: "Other Income (scrap, credits)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Other Expenses(in Negative)", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
      
      { 
        subCategory:"Total Other Income/Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       

        {
        category: "Operating Margin",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Operating Margin %",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
         {
        category: "Total Finance Costs",
        rows: [
      { 
        subCategory: "Selling Expenses (travel, ent)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Total Finance Costs", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Interest Expenses", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Total Finance Costs", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"OPEX (incl.finance cost) % of Revenue", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } ,
      { 
        subCategory:"Total Salary Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      
      ]
      },
      ],
    Q3: [
      {
        category: "Salary Expenses",
        rows: [
      { 
        subCategory: "Sales", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Administration", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Administration", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Salary Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Sales, General & Admin Expenses",
        rows: [
      { 
        subCategory: "Selling Expenses (travel, ent)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Administrative Expenses", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Depreciation & Amortization", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Expenses", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Sales, General & Admin Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       

        {
        category: "Total Salary& SGA Expenses",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "SG&A% of Revenue",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
         {
        category: "Other Income/Expenses",
        rows: [
      { 
        subCategory: "Other Income (scrap, credits)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Other Expenses(in Negative)", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
      
      { 
        subCategory:"Total Other Income/Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       

        {
        category: "Operating Margin",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Operating Margin %",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
         {
        category: "Total Finance Costs",
        rows: [
      { 
        subCategory: "Selling Expenses (travel, ent)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Total Finance Costs", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Interest Expenses", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Total Finance Costs", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"OPEX (incl.finance cost) % of Revenue", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } ,
      { 
        subCategory:"Total Salary Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      
      ]
      },
      ],
    Q4: [
      {
        category: "Salary Expenses",
        rows: [
      { 
        subCategory: "Sales", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Administration", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Administration", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Salary Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Sales, General & Admin Expenses",
        rows: [
      { 
        subCategory: "Selling Expenses (travel, ent)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Administrative Expenses", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Depreciation & Amortization", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Expenses", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Sales, General & Admin Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       

        {
        category: "Total Salary& SGA Expenses",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "SG&A% of Revenue",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
         {
        category: "Other Income/Expenses",
        rows: [
      { 
        subCategory: "Other Income (scrap, credits)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Other Expenses(in Negative)", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
      
      { 
        subCategory:"Total Other Income/Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       

        {
        category: "Operating Margin",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Operating Margin %",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
         {
        category: "Total Finance Costs",
        rows: [
      { 
        subCategory: "Selling Expenses (travel, ent)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Total Finance Costs", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Interest Expenses", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Total Finance Costs", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"OPEX (incl.finance cost) % of Revenue", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } ,
      { 
        subCategory:"Total Salary Expenses", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      
      ]
      },
      ]
  },
  profit: {
    Q1:  [
      {
        category: "Gross-Profit Machine",
        rows: [
      { 
        subCategory: "Machine", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Rental", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Used Equipments", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Machines Commissions", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Gross Profit - Machine", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Gross-Profit Parts",
        rows: [
      { 
        subCategory: "Spare Parts", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Warranty Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Gross Profit - Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Others",
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross-Profit- UPP",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross-Profit",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross Profit %",
        rows: [
      { 
        subCategory: "Gross-Profit%- Machines", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Gross Profit %- Machine Commission", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Gross-Profit %- Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }, 
       { 
        subCategory:"Gross-Profit %- Services", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ],
    Q2:  [
      {
        category: "Gross-Profit Machine",
        rows: [
      { 
        subCategory: "Machine", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Rental", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Used Equipments", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Machines Commissions", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Gross Profit - Machine", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Gross-Profit Parts",
        rows: [
      { 
        subCategory: "Spare Parts", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Warranty Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Gross Profit - Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Others",
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross-Profit- UPP",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross-Profit",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross Profit %",
        rows: [
      { 
        subCategory: "Gross-Profit%- Machines", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Gross Profit %- Machine Commission", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Gross-Profit %- Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }, 
       { 
        subCategory:"Gross-Profit %- Services", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ],
    Q3:  [
      {
        category: "Gross-Profit Machine",
        rows: [
      { 
        subCategory: "Machine", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Rental", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Used Equipments", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Machines Commissions", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Gross Profit - Machine", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Gross-Profit Parts",
        rows: [
      { 
        subCategory: "Spare Parts", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Warranty Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Gross Profit - Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Others",
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross-Profit- UPP",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross-Profit",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross Profit %",
        rows: [
      { 
        subCategory: "Gross-Profit%- Machines", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Gross Profit %- Machine Commission", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Gross-Profit %- Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }, 
       { 
        subCategory:"Gross-Profit %- Services", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ],
    Q4:  [
      {
        category: "Gross-Profit Machine",
        rows: [
      { 
        subCategory: "Machine", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Rental", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Used Equipments", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Machines Commissions", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Gross Profit - Machine", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Gross-Profit Parts",
        rows: [
      { 
        subCategory: "Spare Parts", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Warranty Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Gross Profit - Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289,"
        } 
      } 
      ]
      },
       {
        category: "Others",
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross-Profit- UPP",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross-Profit",
        isTotalRow:true,  
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
        {
        category: "Total Gross Profit %",
        rows: [
      { 
        subCategory: "Gross-Profit%- Machines", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Gross Profit %- Machine Commission", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Gross-Profit %- Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }, 
       { 
        subCategory:"Gross-Profit %- Services", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ]
  }
};
// Helper function to get data based on tab, quarter, metric
const getFinanceData = (tab, quarter, metric) => {
  // Currently we only have revenue, profit, expense
  if (metric === "viewall") {
    // Merge all metrics for viewall
    const allMetrics = ["revenue", "profit", "expense",];
    const merged = [];
    allMetrics.forEach((m) => {
      const data = financeDataByMetric[m]?.[quarter] || [];
      data.forEach((section) => {
        // Check if already exists to avoid duplicates
        const existing = merged.find((s) => s.category === section.category);
        if (!existing) {
          merged.push(section);
        }
      });
    });
    return merged;
  }

  return financeDataByMetric[metric]?.[quarter] || [];
};
const [tableDataDynamic, setTableDataDynamic] = useState(
  getFinanceData(activeTab, activeQuarter, activeMetric)
);

// Update table whenever tab, quarter, or metric changes
React.useEffect(() => {
  const data = getFinanceData(activeTab, activeQuarter, activeMetric);
  setTableDataDynamic(data);
}, [activeTab, activeQuarter, activeMetric]);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return tableDataDynamic;

  return [...tableDataDynamic].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [tableDataDynamic, sortKey, sortOrder]);



  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      {/* Header */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      {/* SubNavbar */}
      <SubNavbar3 />

      {/* MAIN CONTENT */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">

          {/* -------- TOP ROW -------- */}
          <div className="w-full relative flex items-center justify-between">

            {/* LEFT : Arrow + Heading */}
            {/* LEFT : Arrow + Heading */}
            <div className="flex items-center gap-2">
              <ArrowLeft
                size={24}
                onClick={handleback}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              />
              <h1 className="text-base font-semibold text-darkblue1">
                DFHM/ Financial Ratio
              </h1>
            </div>

            {/* CENTER : Disclaimer */}
            <div className="absolute left-1/2 -translate-x-1/2">
              <p className="text-[10px] text-red1 font-medium whitespace-nowrap">
                Disclaimer : This data is for internal review to determine
                improvement areas within dealerships
              </p>
            </div>

            {/* RIGHT : Amount + Download */}
           <div className="flex items-center gap-4">


  {/* Button 1 */}
 <button  onClick={() => navigate("/dfhm/dealerfinacialratio/ratiochart")} className="px-3 py-1 text-xs font-medium bg-darkblue1 text-white hover:text-darkblue1 hover:bg-white hover:border hover:border-darkblue1 flex items-center gap-1">

  {/* Search Icon */}
  <svg
    className="w-4 h-4 stroke-current"   // << this makes icon match text color
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth="2"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M21 21l-4.35-4.35M10 18a8 8 0 100-16 8 8 0 000 16z"
    />
  </svg>

  Ratio chart
</button>

  {/* Button 2 */}
  <button 
      onClick={() => navigate("/dfhm/dealerfinacialratio/healthindex")}
  className="px-3 py-1 text-xs font-medium bg-darkblue1 text-white hover:text-darkblue1 hover:bg-white hover:border hover:border-darkblue1 ">
  Health Index
  </button>
</div>

         



            {/* CENTER : Disclaimer */}
          

            {/* RIGHT : Amount + Download */}
          
          </div>

          {/* Blue underline */}
          <hr className="hidden lg:block w-[7%] border-t-4 border-darkblue1 ml-[34px] mb-2" />

          {/* -------- FOUR BUTTON ROW -------- */}
     <div
      className="w-full grid grid-cols-5 divide-x divide-black/30 border border-black/30 overflow-hidden mb-2"
    >
      {/* Profit & Loss */}
      <button
        // onClick={() => handleTabClick("profit", "/profit")}
        className={`py-1.5 font-medium transition text-xs
          ${activeTab === "profit"
            ? "bg-DustyBlue1 text-white"
            : "bg-white text-black"
          }`}
      >
        Profit & Loss
      </button>

      {/* Balance Sheet */}
     <button
  onClick={() =>
  handleTabClick("balance","/dfhm/dealerfinacialratio/dfbalancesheet")
  }
  className={`py-1 font-medium transition text-xs
    ${activeTab === "balance"
      ? "bg-DustyBlue1 text-white"
      : "bg-white text-black"
    }`}
>
  Balance Sheet
</button>


      {/* Headcount */}
      <button
        onClick={() => handleTabClick("headcount", "/dfhm/dealerfinacialratio/dfheadcount")}
        className={`py-1 font-medium transition text-xs
          ${activeTab === "headcount"
            ? "bg-DustyBlue1 text-white"
            : "bg-white text-black"
          }`}
      >
        Headcount
      </button>

      {/* AR Aging */}
      <button
        onClick={() => handleTabClick("ar", "/dfhm/dealerfinacialratio/dfaraging" )}
        className={`py-1 font-medium transition text-xs
          ${activeTab === "ar"
            ? "bg-DustyBlue1 text-white"
            : "bg-white text-black"
          }`}
      >
        AR Aging
      </button>
       <button
        onClick={() => handleTabClick("ratioanalysis", "/dfhm/dealerfinacialratio/rationanalysis" )}
        className={`py-1 font-medium transition text-xs
          ${activeTab === "ratioanalysis"
            ? "bg-DustyBlue1 text-white"
            : "bg-white text-black"
          }`}
      >
       Ratio Analysis
      </button>
    </div>
<div className=" w-full flex items-center justify-between mb-2">

  {/* LEFT — QUARTER BUTTONS */}
  <div className="grid grid-cols-4 divide-x divide-darkblue1 border border-darkblue1 overflow-hidden">
    {["Q1", "Q2", "Q3", "Q4"].map((q) => (
      <button
        key={q}
        onClick={() => setActiveQuarter(q)}
        className={`py-1 px-10 font-medium transition text-xs text-medium
          ${activeQuarter === q
            ? "bg-darkblue1 text-white"
            : "bg-white text-darkblue1 hover:bg-darkblue1 hover:text-white"
          }`}
      >
        {q}
      </button>
    ))}
  </div>

  {/* RIGHT — METRIC BUTTONS */}
  <div className="grid grid-cols-4 divide-x divide-darkblue1 border border-darkblue1 overflow-hidden ">
    {[
      { id: "revenue", label: "Revenue" },
      { id: "profit", label: "Gross Profit" },
      { id: "expense", label: "Expense" },
            { id: "viewall", label: "View All" },

    ].map((m) => (
      <button
        key={m.id}
        onClick={() => setActiveMetric(m.id)}
        className={`py-1 px-10 font-medium transition text-xs text-medium
          ${activeMetric === m.id
            ? "bg-darkblue1 text-white"
            : "bg-white text-darkblue1 hover:bg-darkblue1 hover:text-white"
          }`}
      >
        {m.label}
      </button>
    ))}
  </div>

</div>


<div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
<div
              ref={tableContainerRef}
              className="
    w-full 
    overflow-y-auto 
    overflow-x-hidden

 
      lg:max-h-[60vh] 
      xl:max-h-[58vh] 
      2xl:max-h-[65vh]
  "
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                  onScroll={handleTableScroll}
            > 
<table className="w-full table-fixed text-xs cursor-pointer">           
       <thead className="bg-Dustyblue text-white font-normal text-left sticky top-0 z-10">
    {/* First row: main headers */}
    <tr>
      <th className="py-2 px-2 border border-grey2  border-t-0 border-l-0 font-normal w-[10%]" rowSpan={2}>Category</th>
      <th className="py-2 px-2 border border-grey2 border-t-0 font-normal w-[10%]" rowSpan={2}>Sub Category</th>

      {/* Monthly group */}
      <th className="py-2 px-2 border border-grey2 text-center border-t-0 font-normal w-[40%]" colSpan={4}>Monthly Breakdown</th>

      {/* Business Plan Comparison group */}
      <th className="py-2 px-2 border border-grey2 text-center border-t-0 border-r-0 font-normal w-[50%]" colSpan={5}>Business Plan Comparison</th>
    </tr>

    {/* Second row: sub-columns */} 
    <tr>
    {monthsForQuarter.map((m) => (
      <th key={m} className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">{m}</th>
    ))}
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">Q{activeQuarter[1]}</th> 
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">YTD</th>
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">Business Plan</th>
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">Vs. BP (YTD-BP)</th>
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">VBPM</th>
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center border-r-0">Run-Rate% (YTD/BP)</th>
  </tr>
  </thead>

 <tbody>
{tableDataDynamic.map((section, idx) => (
    
       section.rows.map((row, rIdx) => {
        const isGrandTotal = section.isTotalRow;
        const isSingleRowCategory = 
          section.category === "Other" || isGrandTotal;

        // Collect all cells
        const cells = [];

        // Category + Sub Category merged for Other / Totals
        if (isSingleRowCategory && rIdx === 0) {
          cells.push(
            <td
              key="category"
              colSpan={2}
              className="py-2 px-2 border border-grey2 font-semibold"
            >
              {section.category}
            </td>
          );
        }

        // Normal category
        if (!isSingleRowCategory && rIdx === 0) {
          cells.push(
            <td
              key="category"
              rowSpan={section.rows.length}
              className="py-1 px-2 border border-grey2 font-normal"
            >
              {section.category}
            </td>
          );
        }

        // Sub Category for normal rows
        if (!isSingleRowCategory) {
          cells.push(
            <td key="subcat" className="py-1 px-2 border border-grey2">
              {row.subCategory}
            </td>
          );
        }

        // All value cells
        Object.values(row.values).forEach((val, i) => {
          cells.push(
            <td key={i} className="py-1 px-2 border border-grey2 text-center text-xs">
              {val}
            </td>
          );
        });

        // Apply border-l-0 to first cell and border-r-0 to last cell
        if (cells.length > 0) {
          cells[0] = React.cloneElement(cells[0], {
            className: `${cells[0].props.className} border-l-0`,
          });
          cells[cells.length - 1] = React.cloneElement(cells[cells.length - 1], {
            className: `${cells[cells.length - 1].props.className} border-r-0`,
          });
        }

        return (
          <tr
            key={rIdx}
            className={row.isTotal || isGrandTotal ? "bg-gery1 font-bold" : "bg-white hover:bg-lightBlue/50"}
          >
            {cells}
          </tr>
        );
      })
    
  ))}
</tbody>
</table></div>
 {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}


        </div>
      </div>
    </div>
    </div>
  );
};

export default DFViewdetailsprofit;
