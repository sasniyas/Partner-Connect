import React, { useState, useRef, useEffect, useMemo } from "react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { ArrowLeft, Menu, X, ChevronDown, Maximize2, Printer, Download, FileSpreadsheet, Table2, Check, BarChart3 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import * as XLSX from "xlsx";

const DFRatioChart = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("efficiency");
  const [viewAll, setViewAll] = useState(false);

  const [dropdown1Open, setDropdown1Open] = useState(false);
  const [dropdown2Open, setDropdown2Open] = useState(false);
  const dropdown1Ref = useRef(null);
  const dropdown2Ref = useRef(null);

  const [year1, setYear1] = useState("");
  const [year2, setYear2] = useState("");
  const [quarters1, setQuarters1] = useState({ Q1: false, Q2: false, Q3: false, Q4: false, YTD: false });
  const [quarters2, setQuarters2] = useState({ Q1: false, Q2: false, Q3: false, Q4: false, YTD: false });

  const [chartFilters, setChartFilters] = useState({
    absorptionRate: "totalOperatingExpenses",
    gpByEmployee: "totalDirectEmployees",
    cashConversionCycle: "daysInventory",
    operatingMargin: "operatingMargin",
    operatingCashFlow: "netProfitBeforeTax",
    dupontRoe: "returnOnAssets",
    gearingRatio: "totalEquity",
    interestCoverage: "interestExpenses",
    quickRatio: "currentLiabilities",
  });

  const [openMenuId, setOpenMenuId] = useState(null);
  const [fullScreenChart, setFullScreenChart] = useState(null);
  const [showDataTable, setShowDataTable] = useState(null);
  const chartRefs = useRef({});

  const isFilterSelected = useMemo(() => {
    const hasYear1 = year1 !== "";
    const hasYear2 = year2 !== "";
    const hasQuarter1 = Object.values(quarters1).some((v) => v);
    const hasQuarter2 = Object.values(quarters2).some((v) => v);
    return hasYear1 && hasYear2 && hasQuarter1 && hasQuarter2;
  }, [year1, year2, quarters1, quarters2]);

  const getSelectedQuarters = (quartersObj) => {
    return Object.entries(quartersObj).filter(([_, selected]) => selected).map(([quarter]) => quarter);
  };

  const handleback = () => navigate("/dfhm/dealerfinacialratio");

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest(".dropdown-wrapper")) setOpenMenuId(null);
      if (dropdown1Ref.current && !dropdown1Ref.current.contains(event.target)) setDropdown1Open(false);
      if (dropdown2Ref.current && !dropdown2Ref.current.contains(event.target)) setDropdown2Open(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const yearOptions = ["2020", "2021", "2022", "2023", "2024", "2025"];

  const YearDropdown = ({ value, onChange, isOpen, setIsOpen, dropdownRef }) => (
    <div className="relative" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center justify-between gap-2 px-3 py-2 min-w-[130px] bg-white border rounded-md text-xs transition-all duration-200 ease-in-out ${isOpen ? "border-[#1e3a5f] ring-2 ring-[#1e3a5f]/20 shadow-sm" : "border-gray-300 hover:border-gray-400"} ${value ? "text-gray-800" : "text-gray-500"}`}
      >
        <span>{value || "Select Year"}</span>
        <ChevronDown size={14} className={`text-gray-400 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} />
      </button>
      {isOpen && (
        <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-200 rounded-md shadow-lg z-50 overflow-hidden">
          <div className="max-h-[200px] overflow-y-auto">
            <div onClick={() => { onChange(""); setIsOpen(false); }} className={`px-3 py-2 text-xs cursor-pointer transition-colors ${!value ? "bg-[#1e3a5f]/10 text-[#1e3a5f] font-medium" : "text-gray-500 hover:bg-gray-50"}`}>
              Select Year
            </div>
            {yearOptions.map((year) => (
              <div key={year} onClick={() => { onChange(year); setIsOpen(false); }} className={`px-3 py-2 text-xs cursor-pointer transition-colors ${value === year ? "bg-[#1e3a5f] text-white font-medium" : "text-gray-700 hover:bg-[#1e3a5f]/10 hover:text-[#1e3a5f]"}`}>
                {year}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const handleQuarterChange = (quarter, filterSet) => {
    if (filterSet === 1) setQuarters1((prev) => ({ ...prev, [quarter]: !prev[quarter] }));
    else setQuarters2((prev) => ({ ...prev, [quarter]: !prev[quarter] }));
  };

  const handleChartFilterChange = (chartId, value) => setChartFilters((prev) => ({ ...prev, [chartId]: value }));
  const handleViewAllToggle = () => setViewAll(!viewAll);

  const allChartData = {
    absorptionRate: [
      { period: "Q1-2023", totalOperatingExpenses: 50000, totalGrossProfit: 65000, absorptionRate: 78, targetAbsorptionRate: 85 },
      { period: "Q2-2023", totalOperatingExpenses: 150000, totalGrossProfit: 180000, absorptionRate: 83, targetAbsorptionRate: 85 },
      { period: "Q3-2023", totalOperatingExpenses: 95000, totalGrossProfit: 110000, absorptionRate: 86, targetAbsorptionRate: 85 },
      { period: "Q4-2023", totalOperatingExpenses: 185000, totalGrossProfit: 210000, absorptionRate: 88, targetAbsorptionRate: 85 },
      { period: "YTD-2023", totalOperatingExpenses: 480000, totalGrossProfit: 565000, absorptionRate: 85, targetAbsorptionRate: 85 },
      { period: "Q1-2024", totalOperatingExpenses: 140000, totalGrossProfit: 165000, absorptionRate: 85, targetAbsorptionRate: 85 },
      { period: "Q2-2024", totalOperatingExpenses: 210000, totalGrossProfit: 245000, absorptionRate: 86, targetAbsorptionRate: 85 },
      { period: "Q3-2024", totalOperatingExpenses: 155000, totalGrossProfit: 180000, absorptionRate: 86, targetAbsorptionRate: 85 },
      { period: "Q4-2024", totalOperatingExpenses: 165000, totalGrossProfit: 195000, absorptionRate: 85, targetAbsorptionRate: 85 },
      { period: "YTD-2024", totalOperatingExpenses: 670000, totalGrossProfit: 785000, absorptionRate: 85, targetAbsorptionRate: 85 },
      { period: "Q1-2025", totalOperatingExpenses: 175000, totalGrossProfit: 205000, absorptionRate: 85, targetAbsorptionRate: 85 },
      { period: "Q2-2025", totalOperatingExpenses: 225000, totalGrossProfit: 265000, absorptionRate: 85, targetAbsorptionRate: 85 },
      { period: "Q3-2025", totalOperatingExpenses: 168000, totalGrossProfit: 198000, absorptionRate: 85, targetAbsorptionRate: 85 },
      { period: "Q4-2025", totalOperatingExpenses: 182000, totalGrossProfit: 215000, absorptionRate: 85, targetAbsorptionRate: 85 },
      { period: "YTD-2025", totalOperatingExpenses: 750000, totalGrossProfit: 883000, absorptionRate: 85, targetAbsorptionRate: 85 },
    ],
    gpByEmployee: [
      { period: "Q1-2023", totalDirectEmployees: 55, totalGrossProfit: 65000, gpByEmployee: 1182 },
      { period: "Q2-2023", totalDirectEmployees: 60, totalGrossProfit: 180000, gpByEmployee: 3000 },
      { period: "Q3-2023", totalDirectEmployees: 58, totalGrossProfit: 110000, gpByEmployee: 1897 },
      { period: "Q4-2023", totalDirectEmployees: 65, totalGrossProfit: 210000, gpByEmployee: 3231 },
      { period: "YTD-2023", totalDirectEmployees: 60, totalGrossProfit: 565000, gpByEmployee: 9417 },
      { period: "Q1-2024", totalDirectEmployees: 68, totalGrossProfit: 165000, gpByEmployee: 2426 },
      { period: "Q2-2024", totalDirectEmployees: 72, totalGrossProfit: 245000, gpByEmployee: 3403 },
      { period: "Q3-2024", totalDirectEmployees: 70, totalGrossProfit: 180000, gpByEmployee: 2571 },
      { period: "Q4-2024", totalDirectEmployees: 75, totalGrossProfit: 195000, gpByEmployee: 2600 },
      { period: "YTD-2024", totalDirectEmployees: 71, totalGrossProfit: 785000, gpByEmployee: 11056 },
      { period: "Q1-2025", totalDirectEmployees: 78, totalGrossProfit: 205000, gpByEmployee: 2628 },
      { period: "Q2-2025", totalDirectEmployees: 82, totalGrossProfit: 265000, gpByEmployee: 3232 },
      { period: "Q3-2025", totalDirectEmployees: 80, totalGrossProfit: 198000, gpByEmployee: 2475 },
      { period: "Q4-2025", totalDirectEmployees: 85, totalGrossProfit: 215000, gpByEmployee: 2529 },
      { period: "YTD-2025", totalDirectEmployees: 81, totalGrossProfit: 883000, gpByEmployee: 10901 },
    ],
    cashConversionCycle: [
      { period: "Q1-2023", daysInventory: 28, daysPayables: 35, daysSales: 42, targetSales: 40, cashCycle: 35 },
      { period: "Q2-2023", daysInventory: 65, daysPayables: 55, daysSales: 70, targetSales: 40, cashCycle: 80 },
      { period: "Q3-2023", daysInventory: 45, daysPayables: 40, daysSales: 55, targetSales: 40, cashCycle: 60 },
      { period: "Q4-2023", daysInventory: 85, daysPayables: 70, daysSales: 90, targetSales: 40, cashCycle: 105 },
      { period: "YTD-2023", daysInventory: 56, daysPayables: 50, daysSales: 64, targetSales: 40, cashCycle: 70 },
      { period: "Q1-2024", daysInventory: 55, daysPayables: 48, daysSales: 62, targetSales: 40, cashCycle: 69 },
      { period: "Q2-2024", daysInventory: 78, daysPayables: 65, daysSales: 85, targetSales: 40, cashCycle: 98 },
      { period: "Q3-2024", daysInventory: 62, daysPayables: 55, daysSales: 70, targetSales: 40, cashCycle: 77 },
      { period: "Q4-2024", daysInventory: 68, daysPayables: 58, daysSales: 75, targetSales: 40, cashCycle: 85 },
      { period: "YTD-2024", daysInventory: 66, daysPayables: 57, daysSales: 73, targetSales: 40, cashCycle: 82 },
      { period: "Q1-2025", daysInventory: 52, daysPayables: 45, daysSales: 58, targetSales: 40, cashCycle: 65 },
      { period: "Q2-2025", daysInventory: 72, daysPayables: 62, daysSales: 78, targetSales: 40, cashCycle: 88 },
      { period: "Q3-2025", daysInventory: 58, daysPayables: 52, daysSales: 65, targetSales: 40, cashCycle: 71 },
      { period: "Q4-2025", daysInventory: 65, daysPayables: 55, daysSales: 72, targetSales: 40, cashCycle: 82 },
      { period: "YTD-2025", daysInventory: 62, daysPayables: 54, daysSales: 68, targetSales: 40, cashCycle: 77 },
    ],
    operatingMargin: [
      { period: "Q1-2023", operatingMargin: 50000, revenue: 200000, targetMargin: 48000, marginPercent: 25 },
      { period: "Q2-2023", operatingMargin: 165000, revenue: 650000, targetMargin: 155000, marginPercent: 25.4 },
      { period: "Q3-2023", operatingMargin: 95000, revenue: 380000, targetMargin: 90000, marginPercent: 25 },
      { period: "Q4-2023", operatingMargin: 185000, revenue: 720000, targetMargin: 175000, marginPercent: 25.7 },
      { period: "YTD-2023", operatingMargin: 495000, revenue: 1950000, targetMargin: 468000, marginPercent: 25.4 },
      { period: "Q1-2024", operatingMargin: 140000, revenue: 560000, targetMargin: 135000, marginPercent: 25 },
      { period: "Q2-2024", operatingMargin: 215000, revenue: 850000, targetMargin: 200000, marginPercent: 25.3 },
      { period: "Q3-2024", operatingMargin: 155000, revenue: 620000, targetMargin: 148000, marginPercent: 25 },
      { period: "Q4-2024", operatingMargin: 165000, revenue: 660000, targetMargin: 158000, marginPercent: 25 },
      { period: "YTD-2024", operatingMargin: 675000, revenue: 2690000, targetMargin: 641000, marginPercent: 25.1 },
      { period: "Q1-2025", operatingMargin: 155000, revenue: 620000, targetMargin: 150000, marginPercent: 25 },
      { period: "Q2-2025", operatingMargin: 235000, revenue: 940000, targetMargin: 225000, marginPercent: 25 },
      { period: "Q3-2025", operatingMargin: 172000, revenue: 688000, targetMargin: 165000, marginPercent: 25 },
      { period: "Q4-2025", operatingMargin: 188000, revenue: 752000, targetMargin: 180000, marginPercent: 25 },
      { period: "YTD-2025", operatingMargin: 750000, revenue: 3000000, targetMargin: 720000, marginPercent: 25 },
    ],
    operatingCashFlow: [
      { period: "Q1-2023", netProfitBeforeTax: 45000, operatingCashFlow: 52000, targetCashFlow: 50000 },
      { period: "Q2-2023", netProfitBeforeTax: 155000, operatingCashFlow: 172000, targetCashFlow: 160000 },
      { period: "Q3-2023", netProfitBeforeTax: 85000, operatingCashFlow: 95000, targetCashFlow: 90000 },
      { period: "Q4-2023", netProfitBeforeTax: 175000, operatingCashFlow: 195000, targetCashFlow: 180000 },
      { period: "YTD-2023", netProfitBeforeTax: 460000, operatingCashFlow: 514000, targetCashFlow: 480000 },
      { period: "Q1-2024", netProfitBeforeTax: 130000, operatingCashFlow: 148000, targetCashFlow: 140000 },
      { period: "Q2-2024", netProfitBeforeTax: 185000, operatingCashFlow: 205000, targetCashFlow: 195000 },
      { period: "Q3-2024", netProfitBeforeTax: 145000, operatingCashFlow: 162000, targetCashFlow: 155000 },
      { period: "Q4-2024", netProfitBeforeTax: 155000, operatingCashFlow: 175000, targetCashFlow: 165000 },
      { period: "YTD-2024", netProfitBeforeTax: 615000, operatingCashFlow: 690000, targetCashFlow: 655000 },
      { period: "Q1-2025", netProfitBeforeTax: 145000, operatingCashFlow: 165000, targetCashFlow: 155000 },
      { period: "Q2-2025", netProfitBeforeTax: 205000, operatingCashFlow: 230000, targetCashFlow: 215000 },
      { period: "Q3-2025", netProfitBeforeTax: 162000, operatingCashFlow: 182000, targetCashFlow: 172000 },
      { period: "Q4-2025", netProfitBeforeTax: 178000, operatingCashFlow: 200000, targetCashFlow: 188000 },
      { period: "YTD-2025", netProfitBeforeTax: 690000, operatingCashFlow: 777000, targetCashFlow: 730000 },
    ],
    dupontRoe: [
      { period: "Q1-2023", returnOnAssets: 48000, leverageFactor: 55000, profitMargin: 42000, targetRoe: 45000, dupontRoe: 50000 },
      { period: "Q2-2023", returnOnAssets: 165000, leverageFactor: 180000, profitMargin: 155000, targetRoe: 160000, dupontRoe: 175000 },
      { period: "Q3-2023", returnOnAssets: 72000, leverageFactor: 85000, profitMargin: 68000, targetRoe: 70000, dupontRoe: 80000 },
      { period: "Q4-2023", returnOnAssets: 178000, leverageFactor: 195000, profitMargin: 170000, targetRoe: 175000, dupontRoe: 190000 },
      { period: "YTD-2023", returnOnAssets: 463000, leverageFactor: 515000, profitMargin: 435000, targetRoe: 450000, dupontRoe: 495000 },
      { period: "Q1-2024", returnOnAssets: 138000, leverageFactor: 155000, profitMargin: 130000, targetRoe: 135000, dupontRoe: 150000 },
      { period: "Q2-2024", returnOnAssets: 195000, leverageFactor: 215000, profitMargin: 185000, targetRoe: 190000, dupontRoe: 210000 },
      { period: "Q3-2024", returnOnAssets: 152000, leverageFactor: 170000, profitMargin: 145000, targetRoe: 150000, dupontRoe: 165000 },
      { period: "Q4-2024", returnOnAssets: 162000, leverageFactor: 180000, profitMargin: 155000, targetRoe: 160000, dupontRoe: 175000 },
      { period: "YTD-2024", returnOnAssets: 647000, leverageFactor: 720000, profitMargin: 615000, targetRoe: 635000, dupontRoe: 700000 },
      { period: "Q1-2025", returnOnAssets: 152000, leverageFactor: 170000, profitMargin: 145000, targetRoe: 150000, dupontRoe: 165000 },
      { period: "Q2-2025", returnOnAssets: 215000, leverageFactor: 238000, profitMargin: 205000, targetRoe: 210000, dupontRoe: 232000 },
      { period: "Q3-2025", returnOnAssets: 168000, leverageFactor: 188000, profitMargin: 160000, targetRoe: 165000, dupontRoe: 182000 },
      { period: "Q4-2025", returnOnAssets: 180000, leverageFactor: 200000, profitMargin: 172000, targetRoe: 177000, dupontRoe: 195000 },
      { period: "YTD-2025", returnOnAssets: 715000, leverageFactor: 796000, profitMargin: 682000, targetRoe: 702000, dupontRoe: 774000 },
    ],
    gearingRatio: [
      { period: "Q1-2023", totalEquity: 250000, totalBorrowings: 180000, gearingRatio: 220000, targetGearing: 200000 },
      { period: "Q2-2023", totalEquity: 780000, totalBorrowings: 520000, gearingRatio: 680000, targetGearing: 600000 },
      { period: "Q3-2023", totalEquity: 420000, totalBorrowings: 295000, gearingRatio: 380000, targetGearing: 350000 },
      { period: "Q4-2023", totalEquity: 920000, totalBorrowings: 610000, gearingRatio: 820000, targetGearing: 750000 },
      { period: "YTD-2023", totalEquity: 2370000, totalBorrowings: 1605000, gearingRatio: 2100000, targetGearing: 1900000 },
      { period: "Q1-2024", totalEquity: 680000, totalBorrowings: 445000, gearingRatio: 600000, targetGearing: 550000 },
      { period: "Q2-2024", totalEquity: 1050000, totalBorrowings: 680000, gearingRatio: 920000, targetGearing: 850000 },
      { period: "Q3-2024", totalEquity: 620000, totalBorrowings: 405000, gearingRatio: 550000, targetGearing: 500000 },
      { period: "Q4-2024", totalEquity: 750000, totalBorrowings: 490000, gearingRatio: 660000, targetGearing: 600000 },
      { period: "YTD-2024", totalEquity: 3100000, totalBorrowings: 2020000, gearingRatio: 2730000, targetGearing: 2500000 },
      { period: "Q1-2025", totalEquity: 720000, totalBorrowings: 475000, gearingRatio: 640000, targetGearing: 585000 },
      { period: "Q2-2025", totalEquity: 1120000, totalBorrowings: 725000, gearingRatio: 980000, targetGearing: 905000 },
      { period: "Q3-2025", totalEquity: 665000, totalBorrowings: 435000, gearingRatio: 590000, targetGearing: 535000 },
      { period: "Q4-2025", totalEquity: 805000, totalBorrowings: 525000, gearingRatio: 710000, targetGearing: 645000 },
      { period: "YTD-2025", totalEquity: 3310000, totalBorrowings: 2160000, gearingRatio: 2920000, targetGearing: 2670000 },
    ],
    interestCoverage: [
      { period: "Q1-2023", interestExpenses: 52000, netProfitBeforeTax: 75000, targetRatio: 48000, interestCoverage: 70000 },
      { period: "Q2-2023", interestExpenses: 135000, netProfitBeforeTax: 185000, targetRatio: 125000, interestCoverage: 175000 },
      { period: "Q3-2023", interestExpenses: 82000, netProfitBeforeTax: 115000, targetRatio: 78000, interestCoverage: 108000 },
      { period: "Q4-2023", interestExpenses: 162000, netProfitBeforeTax: 205000, targetRatio: 150000, interestCoverage: 195000 },
      { period: "YTD-2023", interestExpenses: 431000, netProfitBeforeTax: 580000, targetRatio: 401000, interestCoverage: 548000 },
      { period: "Q1-2024", interestExpenses: 120000, netProfitBeforeTax: 160000, targetRatio: 115000, interestCoverage: 152000 },
      { period: "Q2-2024", interestExpenses: 175000, netProfitBeforeTax: 225000, targetRatio: 165000, interestCoverage: 215000 },
      { period: "Q3-2024", interestExpenses: 135000, netProfitBeforeTax: 175000, targetRatio: 128000, interestCoverage: 168000 },
      { period: "Q4-2024", interestExpenses: 148000, netProfitBeforeTax: 195000, targetRatio: 140000, interestCoverage: 185000 },
      { period: "YTD-2024", interestExpenses: 578000, netProfitBeforeTax: 755000, targetRatio: 548000, interestCoverage: 720000 },
      { period: "Q1-2025", interestExpenses: 128000, netProfitBeforeTax: 172000, targetRatio: 122000, interestCoverage: 162000 },
      { period: "Q2-2025", interestExpenses: 188000, netProfitBeforeTax: 242000, targetRatio: 178000, interestCoverage: 230000 },
      { period: "Q3-2025", interestExpenses: 145000, netProfitBeforeTax: 188000, targetRatio: 138000, interestCoverage: 180000 },
      { period: "Q4-2025", interestExpenses: 160000, netProfitBeforeTax: 210000, targetRatio: 152000, interestCoverage: 200000 },
      { period: "YTD-2025", interestExpenses: 621000, netProfitBeforeTax: 812000, targetRatio: 590000, interestCoverage: 772000 },
    ],
    quickRatio: [
      { period: "Q1-2023", currentLiabilities: 150000, tradeReceivables: 185000, cashEquivalents: 165000, targetQuick: 145000, quickRatio: 180000 },
      { period: "Q2-2023", currentLiabilities: 320000, tradeReceivables: 425000, cashEquivalents: 375000, targetQuick: 310000, quickRatio: 410000 },
      { period: "Q3-2023", currentLiabilities: 225000, tradeReceivables: 295000, cashEquivalents: 265000, targetQuick: 218000, quickRatio: 285000 },
      { period: "Q4-2023", currentLiabilities: 380000, tradeReceivables: 495000, cashEquivalents: 445000, targetQuick: 370000, quickRatio: 480000 },
      { period: "YTD-2023", currentLiabilities: 1075000, tradeReceivables: 1400000, cashEquivalents: 1250000, targetQuick: 1043000, quickRatio: 1355000 },
      { period: "Q1-2024", currentLiabilities: 285000, tradeReceivables: 365000, cashEquivalents: 325000, targetQuick: 275000, quickRatio: 355000 },
      { period: "Q2-2024", currentLiabilities: 420000, tradeReceivables: 555000, cashEquivalents: 495000, targetQuick: 410000, quickRatio: 540000 },
      { period: "Q3-2024", currentLiabilities: 315000, tradeReceivables: 415000, cashEquivalents: 375000, targetQuick: 305000, quickRatio: 402000 },
      { period: "Q4-2024", currentLiabilities: 360000, tradeReceivables: 478000, cashEquivalents: 428000, targetQuick: 350000, quickRatio: 465000 },
      { period: "YTD-2024", currentLiabilities: 1380000, tradeReceivables: 1813000, cashEquivalents: 1623000, targetQuick: 1340000, quickRatio: 1762000 },
      { period: "Q1-2025", currentLiabilities: 305000, tradeReceivables: 392000, cashEquivalents: 348000, targetQuick: 295000, quickRatio: 380000 },
      { period: "Q2-2025", currentLiabilities: 450000, tradeReceivables: 595000, cashEquivalents: 530000, targetQuick: 438000, quickRatio: 580000 },
      { period: "Q3-2025", currentLiabilities: 338000, tradeReceivables: 445000, cashEquivalents: 402000, targetQuick: 328000, quickRatio: 432000 },
      { period: "Q4-2025", currentLiabilities: 388000, tradeReceivables: 512000, cashEquivalents: 460000, targetQuick: 378000, quickRatio: 498000 },
      { period: "YTD-2025", currentLiabilities: 1481000, tradeReceivables: 1944000, cashEquivalents: 1740000, targetQuick: 1439000, quickRatio: 1890000 },
    ],
  };

  const filterChartData = (dataKey) => {
    if (!isFilterSelected) return [];
    const selectedQ1 = getSelectedQuarters(quarters1);
    const selectedQ2 = getSelectedQuarters(quarters2);
    const periods1 = selectedQ1.map((q) => `${q}-${year1}`);
    const periods2 = selectedQ2.map((q) => `${q}-${year2}`);
    const allPeriods = [...periods1, ...periods2];
    return allChartData[dataKey]?.filter((item) => allPeriods.includes(item.period)) || [];
  };

  const getChartConfigs = () => ({
    efficiency: [
      { id: "absorptionRate", title: "Absorption Rate (%)", data: filterChartData("absorptionRate"), status: "G", radioOptions: [{ value: "totalOperatingExpenses", label: "Total Operating Expenses" }, { value: "totalGrossProfit", label: "Total Gross Profit" }, { value: "absorptionRate", label: "Absorption Rate" }, { value: "targetAbsorptionRate", label: "Target Absorption Rate" }] },
      { id: "gpByEmployee", title: "GP By Employee(INR)", data: filterChartData("gpByEmployee"), status: "G", radioOptions: [{ value: "totalDirectEmployees", label: "Total Direct Employees" }, { value: "totalGrossProfit", label: "Total Gross Profit" }, { value: "gpByEmployee", label: "Gross Profit by Employee" }] },
      { id: "cashConversionCycle", title: "Cash Conversion Cycle (Days)", data: filterChartData("cashConversionCycle"), status: "G", radioOptions: [{ value: "daysInventory", label: "Days Inventory Outstanding" }, { value: "daysPayables", label: "Days Payables Outstanding" }, { value: "daysSales", label: "Days Sales Outstanding" }, { value: "targetSales", label: "Target Sales Outstanding" }, { value: "cashCycle", label: "Cash Conversion Cycle (Days)" }] },
    ],
    profitability: [
      { id: "operatingMargin", title: "Operating Margin (%)", data: filterChartData("operatingMargin"), status: "Y", radioOptions: [{ value: "operatingMargin", label: "Operating Margin" }, { value: "revenue", label: "Revenue" }, { value: "targetMargin", label: "Target Operating Margin" }, { value: "marginPercent", label: "Operating Margin (%)" }] },
      { id: "operatingCashFlow", title: "Operating Cash Flows (INR)", data: filterChartData("operatingCashFlow"), status: "G", radioOptions: [{ value: "netProfitBeforeTax", label: "Net Profit Before Tax" }, { value: "operatingCashFlow", label: "Operating Cash Flow" }, { value: "targetCashFlow", label: "Target Operating Cash Flow" }] },
      { id: "dupontRoe", title: "Dupont's RoE(%)", data: filterChartData("dupontRoe"), status: "G", radioOptions: [{ value: "returnOnAssets", label: "Return On Assets(RoA)" }, { value: "leverageFactor", label: "Leverage Factor" }, { value: "profitMargin", label: "Profit Margin" }, { value: "targetRoe", label: "Target RoE" }, { value: "dupontRoe", label: "Dupont's RoE" }] },
    ],
    leverage: [
      { id: "gearingRatio", title: "Gearing Ratio (%)", data: filterChartData("gearingRatio"), status: "G", radioOptions: [{ value: "totalEquity", label: "Total Equity" }, { value: "totalBorrowings", label: "Total Borrowings" }, { value: "gearingRatio", label: "Gearing Ratio" }, { value: "targetGearing", label: "Target Gearing Ratio" }] },
      { id: "interestCoverage", title: "Interest Coverage Ratio (No.)", data: filterChartData("interestCoverage"), status: "G", radioOptions: [{ value: "interestExpenses", label: "Interest Expenses" }, { value: "netProfitBeforeTax", label: "Net Profit Before Tax" }, { value: "targetRatio", label: "Target Interest Coverage Ratio" }, { value: "interestCoverage", label: "Interest Coverage Ratio" }] },
      { id: "quickRatio", title: "Quick Ratio (No.)", data: filterChartData("quickRatio"), status: "G", radioOptions: [{ value: "currentLiabilities", label: "Current Liabilities" }, { value: "tradeReceivables", label: "Trade Receivables" }, { value: "cashEquivalents", label: "Cash & Cash Equivalents" }, { value: "targetQuick", label: "Target Quick Ratio" }, { value: "quickRatio", label: "Quick Ratio" }] },
    ],
  });

  const chartConfigs = getChartConfigs();

  const getStatusColor = (status) => {
    switch (status) {
      case "G": return "bg-green";
      case "Y": return "bg-yellow";
      case "R": return "bg-red";
      default: return "bg-gray";
    }
  };

  const handleViewFullScreen = (chartId) => { setFullScreenChart(chartId); setOpenMenuId(null); };

  const exportChartAsImage = (chartId, callback) => {
    const chartElement = chartRefs.current[chartId];
    if (!chartElement) { alert("Chart not found."); return; }
    setTimeout(() => {
      html2canvas(chartElement, { backgroundColor: '#ffffff', scale: 2, useCORS: true, allowTaint: true, logging: false, ignoreElements: (element) => element.classList.contains('dropdown-wrapper') || element.closest('.dropdown-wrapper') }).then((canvas) => callback(canvas)).catch((error) => { console.error("Error:", error); alert("Error exporting chart."); });
    }, 100);
  };

  const handlePrintChart = (chartId) => {
    setOpenMenuId(null);
    setTimeout(() => {
      exportChartAsImage(chartId, (canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const printWindow = window.open("", "_blank");
        if (printWindow) {
          // Style the body
          printWindow.document.body.style.margin = "0";
          printWindow.document.body.style.padding = "20px";
          printWindow.document.body.style.display = "flex";
          printWindow.document.body.style.justifyContent = "center";
          printWindow.document.body.style.alignItems = "center";
          printWindow.document.body.style.minHeight = "100vh";
          printWindow.document.body.style.background = "white";
          printWindow.document.body.style.boxSizing = "border-box";
          
          // Create and style the image
          const img = printWindow.document.createElement("img");
          img.src = imgData;
          img.style.maxWidth = "100%";
          img.style.height = "auto";
          img.style.display = "block";
          
          img.onload = () => {
            setTimeout(() => {
              printWindow.print();
              printWindow.close();
            }, 300);
          };
          printWindow.document.body.appendChild(img);
        }
      });
    }, 50);
  };

  const handleDownloadJPEG = (chartId) => {
    setOpenMenuId(null);
    setTimeout(() => {
      exportChartAsImage(chartId, (canvas) => {
        const link = document.createElement("a");
        link.download = `${chartId}_chart.jpeg`;
        link.href = canvas.toDataURL("image/jpeg", 0.95);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      });
    }, 50);
  };

  const handleDownloadPNG = (chartId) => {
    setOpenMenuId(null);
    setTimeout(() => {
      exportChartAsImage(chartId, (canvas) => {
        const link = document.createElement("a");
        link.download = `${chartId}_chart.png`;
        link.href = canvas.toDataURL("image/png");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      });
    }, 50);
  };

  const handleDownloadPDF = (chartId) => {
    setOpenMenuId(null);
    setTimeout(() => {
      exportChartAsImage(chartId, (canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF("landscape");
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const imgWidth = pdfWidth - 20;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        const yPos = (pdfHeight - imgHeight) / 2;
        pdf.addImage(imgData, "PNG", 10, yPos > 10 ? yPos : 10, imgWidth, imgHeight);
        pdf.save(`${chartId}_chart.pdf`);
      });
    }, 50);
  };

  const handleDownloadXLS = (chartId, data, title) => {
    try {
      const worksheet = XLSX.utils.json_to_sheet(data);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, title.substring(0, 31));
      XLSX.writeFile(workbook, `${chartId}_data.xlsx`);
    } catch (error) {
      console.error("Error:", error);
      alert("Error downloading XLS.");
    }
    setOpenMenuId(null);
  };

  const handleViewDataTable = (chartId) => { setShowDataTable(showDataTable === chartId ? null : chartId); setOpenMenuId(null); };

  const handleExportAll = () => {
    const workbook = XLSX.utils.book_new();
    if (viewAll) {
      Object.keys(chartConfigs).forEach((tabKey) => {
        chartConfigs[tabKey].forEach((chart) => {
          if (chart.data.length > 0) {
            const worksheet = XLSX.utils.json_to_sheet(chart.data);
            XLSX.utils.book_append_sheet(workbook, worksheet, chart.title.substring(0, 31));
          }
        });
      });
      XLSX.writeFile(workbook, "all_ratios_export.xlsx");
    } else {
      chartConfigs[activeTab].forEach((chart) => {
        if (chart.data.length > 0) {
          const worksheet = XLSX.utils.json_to_sheet(chart.data);
          XLSX.utils.book_append_sheet(workbook, worksheet, chart.title.substring(0, 31));
        }
      });
      XLSX.writeFile(workbook, `${activeTab}_ratios_export.xlsx`);
    }
  };

  const RadioButton = ({ checked, onChange, label }) => (
    <label className="flex items-center gap-2 cursor-pointer select-none">
      <div onClick={onChange} className={`w-[18px] h-[18px] rounded-full border-2 flex items-center justify-center transition-all duration-200 ${checked ? "border-[#1e3a5f]" : "border-gray-400 hover:border-gray-500"}`}>
        {checked && <div className="w-[10px] h-[10px] rounded-full bg-[#1e3a5f]"></div>}
      </div>
      <span className={`text-sm ${checked ? "text-[#1e3a5f] font-medium" : "text-gray-600"}`}>{label}</span>
    </label>
  );

  const lineChartFields = ["targetAbsorptionRate"];
  const isLineChart = (dataKey) => lineChartFields.includes(dataKey);

  const renderChart = (config) => {
    const selectedFilter = chartFilters[config.id];
    const useLineChart = isLineChart(selectedFilter);
    const selectedIndex = config.radioOptions.findIndex((opt) => opt.value === selectedFilter);
    const barConfig = { dataKey: selectedFilter, fill: "#1e3a5f", secondaryKey: config.radioOptions[selectedIndex === 0 ? 1 : 0]?.value, secondaryFill: "#4a9b8c" };

    return (
      <div key={config.id} ref={(el) => (chartRefs.current[config.id] = el)} className="bg-white border border-gray-200 rounded mb-4">
        <div className="flex items-center justify-between px-4 pt-4">
          <div className="flex items-center gap-2">
            <span className={`w-6 h-6 rounded-full ${getStatusColor(config.status)} text-white text-xs flex items-center justify-center font-bold`}>{config.status}</span>
          </div>
          <div className="relative dropdown-wrapper">
            <button onClick={() => setOpenMenuId(openMenuId === config.id ? null : config.id)} className="p-1.5 hover:bg-gray-100 rounded">
              <Menu size={18} className="text-gray-500" />
            </button>
            {openMenuId === config.id && (
              <div className="absolute right-0 top-9 bg-white border border-gray-200 rounded-md shadow-lg z-50 w-56">
                <button onClick={() => handleViewFullScreen(config.id)} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"><Maximize2 size={16} />View in full screen</button>
                <button onClick={() => handlePrintChart(config.id)} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"><Printer size={16} />Print chart</button>
                <div className="border-t border-gray-200 my-1"></div>
                <button onClick={() => handleDownloadPNG(config.id)} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"><Download size={16} />Download PNG image</button>
                <button onClick={() => handleDownloadJPEG(config.id)} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"><Download size={16} />Download JPEG image</button>
                <button onClick={() => handleDownloadPDF(config.id)} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"><Download size={16} />Download PDF</button>
                <div className="border-t border-gray-200 my-1"></div>
                <button onClick={() => handleDownloadXLS(config.id, config.data, config.title)} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"><FileSpreadsheet size={16} />Download XLS</button>
                <button onClick={() => handleViewDataTable(config.id)} className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"><Table2 size={16} />View data table</button>
              </div>
            )}
          </div>
        </div>
        <h3 className="text-center text-base font-semibold text-gray-800 mb-2">{config.title}</h3>
        <div className="flex flex-wrap items-center justify-center gap-8 px-4 pb-3">
          {config.radioOptions.map((option) => (
            <RadioButton key={option.value} checked={selectedFilter === option.value} onChange={() => handleChartFilterChange(config.id, option.value)} label={option.label} />
          ))}
        </div>
        <div className="px-4 pb-4">
          {config.data.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              {useLineChart ? (
                <LineChart data={config.data} margin={{ top: 10, right: 30, left: 10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                  <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={{ stroke: "#d1d5db" }} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={{ stroke: "#d1d5db" }} tickLine={false} domain={['auto', 'auto']} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6, border: "1px solid #e5e7eb", boxShadow: "0 2px 8px rgba(0,0,0,0.1)" }} formatter={(value) => typeof value === 'number' ? value.toLocaleString("en-IN") : value} />
                  <Line type="monotone" dataKey={selectedFilter} stroke="#1e3a5f" strokeWidth={2} dot={{ r: 4, fill: "#1e3a5f", strokeWidth: 2 }} activeDot={{ r: 6, fill: "#1e3a5f" }} />
                </LineChart>
              ) : (
                <BarChart data={config.data} margin={{ top: 10, right: 30, left: 10, bottom: 5 }} barGap={2} barCategoryGap="15%">
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                  <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={{ stroke: "#d1d5db" }} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "#6b7280" }} tickFormatter={(value) => (value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value)} axisLine={{ stroke: "#d1d5db" }} tickLine={false} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6, border: "1px solid #e5e7eb", boxShadow: "0 2px 8px rgba(0,0,0,0.1)" }} formatter={(value) => value.toLocaleString("en-IN")} />
                  <Bar dataKey={barConfig.dataKey} fill={barConfig.fill} radius={[2, 2, 0, 0]} maxBarSize={35} />
                  {barConfig.secondaryKey && !isLineChart(barConfig.secondaryKey) && <Bar dataKey={barConfig.secondaryKey} fill={barConfig.secondaryFill} radius={[2, 2, 0, 0]} maxBarSize={35} />}
                </BarChart>
              )}
            </ResponsiveContainer>
          ) : (
            <div className="h-[240px] flex items-center justify-center text-gray-400 text-sm">No data available for selected filters</div>
          )}
        </div>
        {showDataTable === config.id && config.data.length > 0 && (
          <div className="mx-4 mb-4 overflow-x-auto border border-gray-200 rounded">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-gray-50">
                  {Object.keys(config.data[0]).map((key) => (<th key={key} className="border-b px-3 py-2 text-left font-medium text-gray-700">{key}</th>))}
                </tr>
              </thead>
              <tbody>
                {config.data.map((row, idx) => (
                  <tr key={idx} className="hover:bg-gray-50 border-b last:border-b-0">
                    {Object.values(row).map((val, vIdx) => (<td key={vIdx} className="px-3 py-2 text-gray-600">{typeof val === "number" ? val.toLocaleString("en-IN") : val}</td>))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    );
  };

  const renderAllCharts = () => {
    const tabs = ["efficiency", "profitability", "leverage"];
    const tabLabels = { efficiency: "Efficiency", profitability: "Profitability", leverage: "Leverage" };
    return tabs.map((tabKey) => (
      <div key={tabKey} className="mb-6">
        <div className="bg-[#1e3a5f] text-white px-4 py-3 mb-4 rounded"><h2 className="text-lg font-semibold">{tabLabels[tabKey]}</h2></div>
        {chartConfigs[tabKey].map((config) => renderChart(config))}
      </div>
    ));
  };

  const renderFullScreenModal = () => {
    if (!fullScreenChart) return null;
    let config = null;
    for (const tabKey of Object.keys(chartConfigs)) {
      config = chartConfigs[tabKey].find((c) => c.id === fullScreenChart);
      if (config) break;
    }
    if (!config) return null;
    const selectedFilter = chartFilters[config.id];
    const useLineChart = isLineChart(selectedFilter);
    const selectedIndex = config.radioOptions.findIndex((opt) => opt.value === selectedFilter);
    const barConfig = { dataKey: selectedFilter, fill: "#1e3a5f", secondaryKey: config.radioOptions[selectedIndex === 0 ? 1 : 0]?.value, secondaryFill: "#4a9b8c" };

    return (
      <div className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center p-4">
        <div className="bg-white rounded-lg w-full max-w-6xl max-h-[90vh] overflow-auto">
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="text-lg font-semibold">{config.title}</h2>
            <button onClick={() => setFullScreenChart(null)} className="p-2 hover:bg-gray-100 rounded"><X size={20} /></button>
          </div>
          <div className="p-6">
            {config.data.length > 0 ? (
              <ResponsiveContainer width="100%" height={500}>
                {useLineChart ? (
                  <LineChart data={config.data}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="period" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} domain={['auto', 'auto']} />
                    <Tooltip formatter={(value) => typeof value === 'number' ? value.toLocaleString("en-IN") : value} />
                    <Legend />
                    <Line type="monotone" dataKey={selectedFilter} stroke="#1e3a5f" strokeWidth={2} dot={{ r: 5, fill: "#1e3a5f", strokeWidth: 2 }} activeDot={{ r: 7, fill: "#1e3a5f" }} name={config.radioOptions.find(o => o.value === selectedFilter)?.label} />
                  </LineChart>
                ) : (
                  <BarChart data={config.data}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="period" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} tickFormatter={(value) => (value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value)} />
                    <Tooltip formatter={(value) => value.toLocaleString("en-IN")} />
                    <Legend />
                    <Bar dataKey={barConfig.dataKey} fill={barConfig.fill} radius={[4, 4, 0, 0]} />
                    {barConfig.secondaryKey && !isLineChart(barConfig.secondaryKey) && <Bar dataKey={barConfig.secondaryKey} fill={barConfig.secondaryFill} radius={[4, 4, 0, 0]} />}
                  </BarChart>
                )}
              </ResponsiveContainer>
            ) : (
              <div className="h-[500px] flex items-center justify-center text-gray-400">No data available for selected filters</div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderEmptyState = () => (
    <div className="flex-1 flex items-center justify-center">
      <div className="text-center">
        <div className="w-20 h-20 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
          <BarChart3 size={40} className="text-gray-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-700 mb-2">No Data to Display</h3>
        <p className="text-sm text-gray-500 max-w-md">Please select <span className="font-medium">Year</span> and <span className="font-medium">Quarter(s)</span> for both comparison periods to view the financial ratio charts.</p>
        <div className="mt-4 flex items-center justify-center gap-2 text-xs text-gray-400">
          <span className="px-2 py-1 bg-gray-100 rounded">Year 1 + Quarters</span>
          <span>→</span>
          <span className="px-2 py-1 bg-gray-100 rounded">Year 2 + Quarters</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-[#f8f9fa] min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex-1 flex flex-col`}>
        <div className="mt-[4.5rem] lg:mt-[6rem] flex flex-col flex-1">
          <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button onClick={handleback} className="w-7 h-7 flex items-center justify-center bg-[#1e3a5f] text-white"><ArrowLeft size={18} /></button>
              <h1 className="text-base font-semibold text-[#1e3a5f]">DFHM/ Financial Ratio</h1>
            </div>
            <p className="text-[11px] text-red font-medium">Disclaimer : This data is not for the legal entity, this is for internal review to determine improvement areas within dealerships</p>
            <div className="flex items-center gap-2">
              <button onClick={handleExportAll} disabled={!isFilterSelected} className={`px-6 py-2 text-xs font-medium transition ${isFilterSelected ? "bg-[#1e3a5f] text-white hover:bg-[#1e3a5f]/90" : "bg-gray-300 text-gray-500 cursor-not-allowed"}`}>Export</button>
              <button onClick={() => navigate("/dfhm/dealerfinacialratio/healthindex")} className="px-6 py-2 text-xs font-medium bg-[#1e3a5f] text-white hover:bg-[#1e3a5f]/90">Health Index</button>
            </div>
          </div>
          <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500 font-medium">Year</span>
                <YearDropdown value={year1} onChange={setYear1} isOpen={dropdown1Open} setIsOpen={setDropdown1Open} dropdownRef={dropdown1Ref} />
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-500 font-medium">Quarter</span>
                {["Q1", "Q2", "Q3", "Q4", "YTD"].map((q) => (
                  <label key={q} className="flex items-center gap-1.5 cursor-pointer select-none group">
                    <div className="relative">
                      <input type="checkbox" checked={quarters1[q]} onChange={() => handleQuarterChange(q, 1)} className="peer sr-only" />
                      <div className={`w-4 h-4 border-2 rounded transition-all duration-200 flex items-center justify-center ${quarters1[q] ? "bg-[#1e3a5f] border-[#1e3a5f]" : "bg-white border-gray-300 group-hover:border-gray-400"}`}>
                        {quarters1[q] && <Check size={12} className="text-white" strokeWidth={3} />}
                      </div>
                    </div>
                    <span className={`text-xs transition-colors ${quarters1[q] ? "text-[#1e3a5f] font-medium" : "text-gray-600"}`}>{q}</span>
                  </label>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500 font-medium">Year</span>
                <YearDropdown value={year2} onChange={setYear2} isOpen={dropdown2Open} setIsOpen={setDropdown2Open} dropdownRef={dropdown2Ref} />
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-500 font-medium">Quarter</span>
                {["Q1", "Q2", "Q3", "Q4", "YTD"].map((q) => (
                  <label key={q} className="flex items-center gap-1.5 cursor-pointer select-none group">
                    <div className="relative">
                      <input type="checkbox" checked={quarters2[q]} onChange={() => handleQuarterChange(q, 2)} className="peer sr-only" />
                      <div className={`w-4 h-4 border-2 rounded transition-all duration-200 flex items-center justify-center ${quarters2[q] ? "bg-[#1e3a5f] border-[#1e3a5f]" : "bg-white border-gray-300 group-hover:border-gray-400"}`}>
                        {quarters2[q] && <Check size={12} className="text-white" strokeWidth={3} />}
                      </div>
                    </div>
                    <span className={`text-xs transition-colors ${quarters2[q] ? "text-[#1e3a5f] font-medium" : "text-gray-600"}`}>{q}</span>
                  </label>
                ))}
              </div>
            </div>
            <div className="flex items-center">
              <button onClick={handleViewAllToggle} disabled={!isFilterSelected} className={`px-5 py-2 text-xs font-medium rounded transition-all duration-200 ${viewAll ? "bg-[#1e3a5f] text-white shadow-md" : isFilterSelected ? "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 hover:border-gray-400" : "bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed"}`}>View All</button>
            </div>
          </div>
          {!viewAll && isFilterSelected && (
            <div className="bg-white">
              <div className="flex border-b border-gray-300">
                {[{ id: "efficiency", label: "Efficiency" }, { id: "profitability", label: "Profitability" }, { id: "leverage", label: "Leverage" }].map((tab) => (
                  <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex-1 py-2.5 text-sm font-medium transition-colors border-r border-gray-300 last:border-r-0 ${activeTab === tab.id ? "bg-[#1e3a5f] text-white" : "bg-white text-gray-600 hover:bg-gray-50"}`}>{tab.label}</button>
                ))}
              </div>
            </div>
          )}
          {!isFilterSelected ? renderEmptyState() : (
            <div className="flex-1 overflow-y-auto p-4">
              {viewAll ? renderAllCharts() : chartConfigs[activeTab].map((config) => renderChart(config))}
            </div>
          )}
        </div>
      </div>
      {renderFullScreenModal()}
    </div>
  );
};

export default DFRatioChart;