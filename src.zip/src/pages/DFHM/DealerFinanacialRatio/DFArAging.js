import React, { useState, useEffect, useRef ,useMemo} from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft,ChevronDown,ChevronUp,ChevronsUpDown } from "lucide-react";
import { useNavigate } from "react-router-dom";

const DFArAging = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("ar");
  const [activeQuarter, setActiveQuarter] = useState("Q1");
  const [activeMetric, setActiveMetric] = useState("assets");
  const tableContainerRef = useRef(null);
  const [tableDataDynamic, setTableDataDynamic] = useState([]);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return tableDataDynamic;

  return [...tableDataDynamic].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [tableDataDynamic, sortKey, sortOrder]);


  const handleback = () => {
    navigate("/dfhm/dealerfinacialratio");
  };

  const handleTabClick = (tab, path) => {
    setActiveTab(tab);
    navigate(path);
  };

  const quarterMonths = {
    Q1: ["Jan", "Feb", "Mar"],
    Q2: ["Apr", "May", "Jun"],
    Q3: ["Jul", "Aug", "Sep"],
    Q4: ["Oct", "Nov", "Dec"],
  };

  const monthsForQuarter = quarterMonths[activeQuarter];

  const quarterData = {
    Q1: [
      {
        category: "Equipment Customer",
        rows: [
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "ADVO",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Total",
            isTotal: true,
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
        ],
      },
      {
        category: "Parts Customer",
        rows: [
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "ADVO",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Total",
            isTotal: true,
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
        ],
      },
    ],
    Q2: [
      {
        category: "Equipment Customer",
        rows: [
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "ADVO",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Total",
            isTotal: true,
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
        ],
      },
      {
        category: "Parts Customer",
        rows: [
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "ADVO",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Advitiix",
            isTotal: true,
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
        ],
      },
    ],
    Q3: [
      {
        category: "Equipment Customer",
        rows: [
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "ADVO",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Total",
            isTotal: true,
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
        ],
      },
      {
        category: "Parts Customer",
        rows: [
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "ADVO",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Advitiix",
            isTotal: true,
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
        ],
      },
    ],
    Q4: [
      {
        category: "Equipment Customer",
        rows: [
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "ADVO",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Total",
            isTotal: true,
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
        ],
      },
      {
        category: "Parts Customer",
        rows: [
          {
            subCategory: "Others",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "ADVO",
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
          {
            subCategory: "Advitiix",
            isTotal: true,
            values: {
              Current: "12",
              less30Days: "06",
              "30to60 days": "03",
              "60-90 Days": "11",
              ">90 Days": "22",
              "Total Overdue": "33",
              Total: "44",
            },
          },
        ],
      },
    ],
  };

  const getFinanceData = (tab, quarter, metric) => {
    return quarterData[quarter] || [];
  };

  useEffect(() => {
    const data = getFinanceData(activeTab, activeQuarter, activeMetric);
    setTableDataDynamic(data);
  }, [activeTab, activeQuarter, activeMetric]);

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* TOP ROW */}
          <div className="w-full relative flex items-center justify-between">
            {/* LEFT: Arrow + Heading */}
            <div className="flex items-center gap-2">
              <ArrowLeft
                size={24}
                onClick={handleback}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              />
              <h1 className="text-base font-semibold text-darkblue1">DFHM/ Financial Ratio</h1>
            </div>

            {/* CENTER: Disclaimer */}
            <div className="absolute left-1/2 -translate-x-1/2">
              <p className="text-[10px] text-red1 font-medium whitespace-nowrap">
                Disclaimer : This data is for internal review to determine improvement areas within dealerships
              </p>
            </div>

            {/* RIGHT: Buttons */}
            <div className="flex items-center gap-4">
              {/* Ratio Chart Button */}
              <button
                onClick={() => navigate("/dfhm/dealerfinacialratio/ratiochart")}
                className="px-3 py-1 text-xs font-medium bg-darkblue1 text-white hover:text-darkblue1 hover:bg-white hover:border hover:border-darkblue1 flex items-center gap-1"
              >
                <svg className="w-4 h-4 stroke-current" fill="none" viewBox="0 0 24 24" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35M10 18a8 8 0 100-16 8 8 0 000 16z" />
                </svg>
                Ratio chart
              </button>

              {/* Health Index Button - NOW WITH NAVIGATION */}
              <button
                onClick={() => navigate("/dfhm/dealerfinacialratio/healthindex")}
                className="px-3 py-1 text-xs font-medium bg-darkblue1 text-white hover:text-darkblue1 hover:bg-white hover:border hover:border-darkblue1"
              >
                Health Index
              </button>
            </div>
          </div>

          {/* Blue underline */}
          <hr className="hidden lg:block w-[7%] border-t-4 border-darkblue1 ml-[34px] mb-2" />

          {/* FIVE TAB BUTTONS */}
          <div className="w-full grid grid-cols-5 divide-x divide-black/30 border border-black/30 overflow-hidden mb-2">
            <button
              onClick={() => handleTabClick("profit", "/dfhm/viewdfhm/fillentries")}
              className={`py-1.5 font-medium transition text-xs ${activeTab === "profit" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              Profit & Loss
            </button>
            <button
              onClick={() => handleTabClick("balance", "/dfhm/dealerfinacialratio/viewdetails")}
              className={`py-1 font-medium transition text-xs ${activeTab === "balance" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              Balance Sheet
            </button>
            <button
              onClick={() => handleTabClick("headcount", "/dfhm/dealerfinacialratio/dfheadcount")}
              className={`py-1 font-medium transition text-xs ${activeTab === "headcount" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              Headcount
            </button>
            <button
              className={`py-1 font-medium transition text-xs ${activeTab === "ar" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              AR Aging
            </button>
            <button
              onClick={() => handleTabClick("ratioanalysis", "/dfhm/dealerfinacialratio/rationanalysis")}
              className={`py-1 font-medium transition text-xs ${activeTab === "ratioanalysis" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              Ratio Analysis
            </button>
          </div>

          {/* QUARTER BUTTONS */}
          <div className="w-full flex items-center justify-between mb-2">
            <div className="grid grid-cols-4 divide-x divide-darkblue1 border border-darkblue1 overflow-hidden">
              {["Q1", "Q2", "Q3", "Q4"].map((q) => (
                <button
                  key={q}
                  onClick={() => setActiveQuarter(q)}
                  className={`py-1 px-10 font-medium transition text-xs ${activeQuarter === q ? "bg-darkblue1 text-white" : "bg-white text-darkblue1 hover:bg-darkblue1 hover:text-white"}`}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* TABLE */}
          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
            <div
              ref={tableContainerRef}
              className="w-full overflow-y-auto overflow-x-auto lg:max-h-[60vh] xl:max-h-[58vh] 2xl:max-h-[65vh]"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
            >
<table className="w-full table-fixed text-xs cursor-pointer">
                  <thead className="bg-Dustyblue text-white font-normal text-left sticky top-0 z-10">
                  <tr>
<th
  onClick={() => handleSort("category")}
  className="py-2 px-2 border border-grey2 border-l-0 border-t-0 w-[12%] font-normal cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Category
    {sortKey !== "category" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

    {sortKey === "category" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3 text-white" />
    )}
    {sortKey === "category" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3 text-white" />
    )}
  </div>
</th>                    <th className="py-2 px-2 border border-grey2 border-t-0 font-normal w-[12%]">Sub Category</th>
                    <th className="py-2 px-2 border border-grey2 border-t-0 font-normal text-center">Current (AR)</th>
                    <th className="py-2 px-2 border border-grey2 border-t-0 font-normal text-center">&lt;30 Days</th>
                    <th className="py-2 px-2 border border-grey2 border-t-0 font-normal text-center">30-60 Days</th>
                    <th className="py-2 px-2 border border-grey2 border-t-0 font-normal text-center">60-90 Days</th>
                    <th className="py-2 px-2 border border-grey2 border-t-0 font-normal text-center">&gt;90 Days</th>
                    <th className="py-2 px-2 border border-grey2 border-t-0 font-normal text-center">Total Overdue</th>
                    <th className="py-2 px-2 border border-grey2 border-t-0 border-r-0 font-normal text-center">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedData.map((section, idx) =>
                    section.rows.map((row, rIdx) => {
                      const isSingleRowCategory = section.category === "Other" || section.isTotalRow;
                      const cells = [];

                      if (isSingleRowCategory && rIdx === 0) {
                        cells.push(
                          <td key="cat" colSpan={2} className="py-2 px-2 border border-grey2 font-semibold border-l-0">
                            {section.category}
                          </td>
                        );
                      }

                      if (!isSingleRowCategory && rIdx === 0) {
                        cells.push(
                          <td key="cat" rowSpan={section.rows.length} className="py-2 px-2 border border-grey2 border-l-0">
                            {section.category}
                          </td>
                        );
                      }

                      if (!isSingleRowCategory) {
                        cells.push(
                          <td key="subcat" className="py-2 px-2 border border-grey2">
                            {row.subCategory}
                          </td>
                        );
                      }

                      Object.values(row.values).forEach((val, index) => {
                        cells.push(
                          <td key={index} className="py-2 px-2 border border-grey2 text-center">
                            {val}
                          </td>
                        );
                      });

                      cells[cells.length - 1] = React.cloneElement(cells[cells.length - 1], {
                        className: cells[cells.length - 1].props.className + " border-r-0",
                      });

                      return (
                        <tr
                          key={`${idx}-${rIdx}`}
                          className={row.isTotal || section.isTotalRow ? "bg-gery1 font-bold" : "bg-white hover:bg-lightBlue/50"}
                        >
                          {cells}
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DFArAging;