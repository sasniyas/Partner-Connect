import React, { useState, useRef } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, ArrowRight, Eye, MoreVertical,ChevronUp,ChevronDown,ChevronsUpDown,ArrowUp,ArrowDown } from "lucide-react";
import Searchinput from "../../../Components/Searchinput";
import Filter from "../../../Components/Filter";
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import DeleteModal from "../../../Components/DeleteModal";
import { useMemo } from "react";
const DFRatio = () => {
    const location = useLocation();
    const navigate = useNavigate();
const newDfhm = location.state?.newDfhm || [];
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedYear, setSelectedYear] = useState("");
  const [selectedQuarter, setSelectedQuarter] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const [selectedDealer, setSelectedDealer] = useState("");
  const [selectedMarketArea, setSelectedMarketArea] = useState("");
  const [selectedRow, setSelectedRow] = useState(null);
  const tableContainerRef = useRef(null);
const [dropdownId, setDropdownId] = useState(null);
// const dropdownRef = useRef(null);
const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
const toggleDropdown = (id) => {
  setDropdownId(dropdownId === id ? null : id);
};
// useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setDropdownId(null);
//       }
//     };

//     document.addEventListener("mousedown", handleClickOutside);

//     return () => {
//       document.removeEventListener("mousedown", handleClickOutside);
//     };
//   }, []);
useEffect(() => {
  const handleClickOutside = (event) => {
    // If click is outside any open dropdown button/menu, close it
    if (!event.target.closest(".dropdown-wrapper")) {
      setDropdownId(null);
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);

  const lastItemRef = useRef(null);

  const displayedItemsOriginal = [
    {
      id: 1,
      year: 2025,
      quarter: "Q1",
      marketArea: "DRS Earthwork Pvt Ltd",
      dealer: "DRS Earthwork Pvt Ltd",
      status: "Created",
      dealerPrincipal: "Validate",
      validateVolvoUser: "Validated",
      validate: false,
    },
    {
      id: 2,
      year: 2025,
      quarter: "Q2",
      marketArea: "North",
      dealer: "Alpha Teknisk Pvt. Ltd. (UP)",
      status: "Validate By Volvo",
      dealerPrincipal: "Validate By Volvo",
      validateVolvoUser:"Validated",
    },
    
    {
      id: 3,
      year: 2024,
      quarter: "Q4",
      marketArea: "West 1",
      dealer: "Advanced Construction Technologies Pvt. Ltd",
      status: "Validate By Volvo",
     dealerPrincipal: "Validate By Volvo",
      validateVolvoUser:"Validated",
    },
  ];
  const [displayedItems, setDisplayedItems] = useState(displayedItemsOriginal);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

useEffect(() => {
  if (newDfhm.length > 0) {
    setDisplayedItems(prev => [...newDfhm, ...prev]);
  }
}, [newDfhm]);

  const quarterOptions = ["Q1", "Q2", "Q3", "Q4"];
  const startYear = 2016;
const endYear = new Date().getFullYear() + 10;

const yearOptions = Array.from(
  { length: endYear - startYear + 1 },
  (_, i) => (startYear + i).toString()
);

  const marketAreaOptions = ["North", "South", "East", "West", "Central"];
  const dealerOptions = ["Dealer 1", "Dealer 2", "Dealer 3", "Dealer 4", "Dealer 5"];
  const statusOptions = ["Created", "Submitted", "DP Validated","Volvo Validated"];

  // 🔹 Filtered Data
  const filteredItems = useMemo(() => {
    return displayedItems.filter((item) => {
      const searchLower = searchTerm.toLowerCase().trim();
  
      const matchesSearch =
        searchLower === "" ||
        item.marketArea?.toLowerCase().includes(searchLower) ||
        item.dealer?.toLowerCase().includes(searchLower);
  
       const matchesYear = selectedYear.length
    ? selectedYear.some(year =>
        item.year.toString().toLowerCase().includes(year.toLowerCase())
      )
    : true;
  
      const matchesQuarter = selectedQuarter.length
    ? selectedQuarter.some(quarter =>
        item.quarter.toString().includes(quarter.toString())
      )
    : true;
  
     const matchesMarketArea = selectedMarketArea.length
    ? selectedMarketArea.some(area =>
        item.marketArea.toLowerCase().includes(area.toLowerCase())
      )
    : true;
  
      // const matchesDealer =
      //   selectedDealer === "" || item.dealer?.toLowerCase() === selectedDealer.toLowerCase();
      const matchesDealer = selectedDealer.length
    ? selectedDealer.some(dealer=>
        item.dealer.toString().includes(dealer.toString())
      )
    : true;
  
      // const matchesStatus =
      //   selectedStatus === "" || item.status === selectedStatus;
  const matchesStatus = selectedStatus.length
    ? selectedStatus.some(status =>
        item.status.toString().includes(status.toString())
      )
    : true;
  
      return (
        matchesSearch &&
        matchesYear &&
        matchesQuarter &&
        matchesMarketArea &&
        matchesDealer &&
        matchesStatus
      );
    });
  }, [
    displayedItems,
    searchTerm,
    selectedYear,
    selectedQuarter,
    selectedMarketArea,
    selectedDealer,
    selectedStatus,
  ]);
  const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredItems;

  return [...filteredItems].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [filteredItems, sortKey, sortOrder]);

// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

const handleViewDetails = (item) => {
  navigate("/dfhm/viewdfhm/viewdetails", { state: { rowData: item } });
};
  // const handleFillEntries = (item) => alert("Fill Entries: " + JSON.stringify(item));
  const handleFillEntries = (item) => {
  navigate("/dfhm/viewdfhm/fillentries", { state: { rowData: item } });
};
  const handleConfirmDelete = () => {
    if (itemToDelete) {
      setDisplayedItems(prev => prev.filter(i => i.id !== itemToDelete.id));
      setDeleteModalOpen(false);
      setItemToDelete(null);
    }
  };
const handleback = () => {
  navigate("/dfhm/createdfhm");
}
  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* 🔵 HEADER ROW */}
         {/* <div className="w-full flex justify-center">
  <h1 className="text-lg font-semibold text-darkblue1 text-center">
    Dealer Financial Ratio
  </h1>
</div> */}
<div className="w-full relative flex items-center justify-between">
            <div className="flex items-center gap-2">
              {/* <ArrowLeft
                size={24}
                onClick={() => handleback()}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 "
              /> */}
              <h1 className="x">Dealer Financial Ratio</h1>
            </div>

            <div className="absolute left-1/2 -translate-x-1/2">
              <p className="text-[10px] text-red1 font-medium whitespace-nowrap">
                Disclaimer : This data is for internal review to determine improvement areas within dealerships
              </p>
            </div>

           
          </div>

          <hr className="hidden lg:block w-[7%] border-t-4 border-darkblue1 mt-0  mb-3" />


          {/* 🔵 SEARCH + FILTER ROW */}
           <div className="flex flex-col sm:flex-row items-center justify-start gap-2 mb-2">

            {/* SEARCH INPUT */}
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="w-[1/2]"
              iconColor="text-black"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-1.5"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              inputWidth="w-full"
              focusRing="focus:ring-1 focus:ring-black/60"
              hoverInputClasses="hover:bg-white hover:border-black/60"
            />

            {/* YEAR FILTER */}
            <Filter
              name="Year"
              value={selectedYear}
              options={yearOptions}
              onChange={(name, value) => setSelectedYear(value)}
              placeholder="Year"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
              customWidth="w-[120px]"
            />
            <Filter
  name="Quarter"
  value={selectedQuarter}
  options={quarterOptions}   // ["Q1", "Q2", "Q3", "Q4"]
  onChange={(name, value) => setSelectedQuarter(value)}
  placeholder="Quarter"
  placeholderColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black/60"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
  customWidth="w-[120px]"
/>
<Filter
  name="Market Area"
  value={selectedMarketArea}
  options={marketAreaOptions}   // your market areas array
  onChange={(name, value) => setSelectedMarketArea(value)}
  placeholder=" Market Area"
  placeholderColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black/60"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
  customWidth="w-[150px]"
/>
<Filter
  name="Dealer"
  value={selectedDealer}
  options={dealerOptions}   // your dealer list
  onChange={(name, value) => setSelectedDealer(value)}
  placeholder="Dealer"
  placeholderColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black/60"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
  customWidth="w-[150px]"
/>
<Filter
  name="Status"
  value={selectedStatus}
  options={statusOptions}   // status list
  onChange={(name, value) => setSelectedStatus(value)}
  placeholder=" Status"
  placeholderColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black/60"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
  customWidth="w-[150px]"
/>        </div>
      

          {/* 🔵 TABLE */}
          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
 <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
              maxHeight: sortedData.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >             <table className="w-full text-xs">
                <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                  <tr>
                   <th
  onClick={() => handleSort("year")}
  className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[5%] cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Year
    {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

    {sortKey === "year" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3" />
    )}
    {sortKey === "year" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3" />
    )}
  </div>
</th>

<th
  onClick={() => handleSort("quarter")}
  className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[10%] cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Quarter
    {sortKey === "quarter" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3" />
    )}
    {sortKey === "quarter" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3" />
    )}
  </div>
</th>

<th
  onClick={() => handleSort("marketArea")}
  className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[15%] cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Market Area
    {sortKey === "marketArea" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3" />
    )}
    {sortKey === "marketArea" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3" />
    )}
  </div>
</th>

<th
  onClick={() => handleSort("dealer")}
  className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[15%] cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Dealer
    {sortKey === "dealer" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3" />
    )}
    {sortKey === "dealer" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3" />
    )}
  </div>
</th>

<th
  onClick={() => handleSort("status")}
  className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[10%] cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Status
    {sortKey === "status" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3" />
    )}
    {sortKey === "status" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3" />
    )}
  </div>
</th>
                    <th className="text-center py-1.5 border border-grey2 border-t-0 border-l-0 border-r-0 font-medium w-[8%]">View Details</th>
                  </tr>
                </thead>

                <tbody>
                  {sortedData.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="text-center py-8 text-gray-500 italic">No data found</td>
                    </tr>
                  ) : (
                    sortedData.map((item, index) => (
                      <tr key={index} className={`hover:bg-lightBlue/50 text-xs t`}>
                        <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.year}</td>
                        <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.quarter}</td>
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.marketArea && item.marketArea.length > 70)
          setHoveredCell(item.id + "-marketArea");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.marketArea}
    </p>

    {hoveredCell === item.id + "-marketArea" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {item.marketArea}
      </span>
    )}
  </div>
</td>                      
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[20rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.dealer && item.dealer.length > 70)
          setHoveredCell(item.id + "-dealer");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.dealer}
    </p>

    {hoveredCell === item.id + "-dealer" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {item.dealer}
      </span>
    )}
  </div>
</td>                        <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.status}</td>
<td className=" py-1 text-center border border-grey2 border-t-0 border-l-0 border-r-0 text-center">
                            <button
                              onClick={() => navigate("/dfhm/dealerfinacialratio/viewdetails" , { state: { rowData: item } })}
                              className="w-6 h-6 text-center flex items-center justify-center mx-auto transition"
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className="w-5 h-5">
<rect x="0.416667" y="0.416667" width="19.1667" height="19.1667" rx="4.58333" stroke="#878787" stroke-width="0.833333"/>
<g clip-path="url(#clip0_556_10062)">
<path d="M9.99957 8.54166C9.61279 8.54166 9.24186 8.6953 8.96837 8.96879C8.69488 9.24228 8.54123 9.61322 8.54123 9.99999C8.54123 10.3868 8.69488 10.7577 8.96837 11.0312C9.24186 11.3047 9.61279 11.4583 9.99957 11.4583C10.3863 11.4583 10.7573 11.3047 11.0308 11.0312C11.3043 10.7577 11.4579 10.3868 11.4579 9.99999C11.4579 9.61322 11.3043 9.24228 11.0308 8.96879C10.7573 8.6953 10.3863 8.54166 9.99957 8.54166ZM9.99957 12.4305C9.35494 12.4305 8.73672 12.1745 8.2809 11.7187C7.82509 11.2628 7.56901 10.6446 7.56901 9.99999C7.56901 9.35537 7.82509 8.73715 8.2809 8.28133C8.73672 7.82551 9.35494 7.56943 9.99957 7.56943C10.6442 7.56943 11.2624 7.82551 11.7182 8.28133C12.174 8.73715 12.4301 9.35537 12.4301 9.99999C12.4301 10.6446 12.174 11.2628 11.7182 11.7187C11.2624 12.1745 10.6442 12.4305 9.99957 12.4305ZM9.99957 6.35416C7.56901 6.35416 5.49332 7.86596 4.65234 9.99999C5.49332 12.134 7.56901 13.6458 9.99957 13.6458C12.4301 13.6458 14.5058 12.134 15.3468 9.99999C14.5058 7.86596 12.4301 6.35416 9.99957 6.35416Z" fill="#878787"/>
</g>
<defs>
<clipPath id="clip0_556_10062">
<rect width="11.6667" height="11.6667" fill="white" transform="translate(4.16602 4.16666)"/>
</clipPath>
</defs>
</svg>
                            </button>
                          </td>

                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
              {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}


          </div>

        </div>
      </div>
        <DeleteModal
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
        extraMessage="This action cannot be undone."
      />
    </div>
  );
};

export default DFRatio;
