import React, { useState, useRef, useEffect, useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Menu, ChevronDown, Download, Printer, FileSpreadsheet, BarChart3 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import * as XLSX from "xlsx";

const DFHMDashboard = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  // Filter states - Initially empty/unchecked
  const [searchTerm, setSearchTerm] = useState("");
  const [marketArea, setMarketArea] = useState("");
  const [dealerName, setDealerName] = useState("");
  const [year1, setYear1] = useState("");
  const [year2, setYear2] = useState("");
  const [quarters1, setQuarters1] = useState({ Q1: false, Q2: false, Q3: false, Q4: false, YTD: false });
  const [quarters2, setQuarters2] = useState({ Q1: false, Q2: false, Q3: false, Q4: false, YTD: false });

  // Selected metric for chart (radio button selection)
  const [selectedMetric, setSelectedMetric] = useState("absorptionRate");

  // Dropdown states
  const [marketDropdownOpen, setMarketDropdownOpen] = useState(false);
  const [dealerDropdownOpen, setDealerDropdownOpen] = useState(false);
  const [year1DropdownOpen, setYear1DropdownOpen] = useState(false);
  const [year2DropdownOpen, setYear2DropdownOpen] = useState(false);
  const [openMenuId, setOpenMenuId] = useState(null);

  const marketDropdownRef = useRef(null);
  const dealerDropdownRef = useRef(null);
  const year1DropdownRef = useRef(null);
  const year2DropdownRef = useRef(null);
  const chartRef = useRef(null);

  const handleback = () => navigate("/dfhm");

  // Check if any filter is selected (like DFRatioChart)
  const isFilterSelected = useMemo(() => {
    const hasYear1 = year1 !== "";
    const hasYear2 = year2 !== "";
    const hasQuarter1 = Object.values(quarters1).some((v) => v);
    const hasQuarter2 = Object.values(quarters2).some((v) => v);
    return (hasYear1 && hasQuarter1) || (hasYear2 && hasQuarter2);
  }, [year1, year2, quarters1, quarters2]);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest(".dropdown-wrapper")) setOpenMenuId(null);
      if (marketDropdownRef.current && !marketDropdownRef.current.contains(event.target)) setMarketDropdownOpen(false);
      if (dealerDropdownRef.current && !dealerDropdownRef.current.contains(event.target)) setDealerDropdownOpen(false);
      if (year1DropdownRef.current && !year1DropdownRef.current.contains(event.target)) setYear1DropdownOpen(false);
      if (year2DropdownRef.current && !year2DropdownRef.current.contains(event.target)) setYear2DropdownOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Options
  const yearOptions = ["2020", "2021", "2022", "2023", "2024", "2025"];
  const marketOptions = ["North", "South", "East", "West", "Central"];
  const dealerOptions = ["Navin Infrasolution Pvt Ltd", "ABC Motors", "XYZ Dealers", "Metro Auto"];

  // 9 Ratios with their health values (can vary by quarter)
  const ratiosList = [
    { name: "Absorption Rate", key: "absorptionRate" },
    { name: "Cash Conversion Cycle (days)", key: "cashConversionCycle" },
    { name: "Dupont's RoE", key: "dupontRoe" },
    { name: "Gearing Ratio", key: "gearingRatio" },
    { name: "Gross Profit by Employee", key: "grossProfitByEmployee" },
    { name: "Interest Coverage Ratio", key: "interestCoverageRatio" },
    { name: "Operating Cash Flow", key: "operatingCashFlow" },
    { name: "Operating Margin", key: "operatingMargin" },
    { name: "Quick Ratio", key: "quickRatio" },
  ];

  // Health values data per year-quarter (sample data)
  const healthValuesData = {
    "2022-Q1": { absorptionRate: 0, cashConversionCycle: 1, dupontRoe: 0, gearingRatio: 1, grossProfitByEmployee: 0.5, interestCoverageRatio: 1, operatingCashFlow: 0.5, operatingMargin: 0.5, quickRatio: 0 },
    "2022-Q2": { absorptionRate: 0, cashConversionCycle: 1, dupontRoe: 0, gearingRatio: 1, grossProfitByEmployee: 0.5, interestCoverageRatio: 1, operatingCashFlow: 0.5, operatingMargin: 0.5, quickRatio: 0 },
    "2022-Q3": { absorptionRate: 0, cashConversionCycle: 1, dupontRoe: 0, gearingRatio: 1, grossProfitByEmployee: 0.5, interestCoverageRatio: 1, operatingCashFlow: 0.5, operatingMargin: 0.5, quickRatio: 0 },
    "2022-Q4": { absorptionRate: 0, cashConversionCycle: 1, dupontRoe: 0, gearingRatio: 1, grossProfitByEmployee: 0.5, interestCoverageRatio: 1, operatingCashFlow: 0.5, operatingMargin: 0.5, quickRatio: 0 },
    "2022-YTD": { absorptionRate: 0, cashConversionCycle: 1, dupontRoe: 0, gearingRatio: 1, grossProfitByEmployee: 0.5, interestCoverageRatio: 1, operatingCashFlow: 0.5, operatingMargin: 0.5, quickRatio: 0 },
    "2023-Q1": { absorptionRate: 1, cashConversionCycle: 1, dupontRoe: 1, gearingRatio: 1, grossProfitByEmployee: 1, interestCoverageRatio: 1, operatingCashFlow: 1, operatingMargin: 0.5, quickRatio: 0.5 },
    "2023-Q2": { absorptionRate: 1, cashConversionCycle: 1, dupontRoe: 1, gearingRatio: 1, grossProfitByEmployee: 1, interestCoverageRatio: 1, operatingCashFlow: 1, operatingMargin: 0.5, quickRatio: 0.5 },
    "2023-Q3": { absorptionRate: 1, cashConversionCycle: 1, dupontRoe: 1, gearingRatio: 1, grossProfitByEmployee: 1, interestCoverageRatio: 1, operatingCashFlow: 1, operatingMargin: 0.5, quickRatio: 0.5 },
    "2023-Q4": { absorptionRate: 1, cashConversionCycle: 1, dupontRoe: 1, gearingRatio: 1, grossProfitByEmployee: 1, interestCoverageRatio: 1, operatingCashFlow: 1, operatingMargin: 0.5, quickRatio: 0.5 },
    "2023-YTD": { absorptionRate: 1, cashConversionCycle: 1, dupontRoe: 1, gearingRatio: 1, grossProfitByEmployee: 1, interestCoverageRatio: 1, operatingCashFlow: 1, operatingMargin: 0.5, quickRatio: 0.5 },
    "2024-Q1": { absorptionRate: 1, cashConversionCycle: 1, dupontRoe: 1, gearingRatio: 1, grossProfitByEmployee: 1, interestCoverageRatio: 1, operatingCashFlow: 1, operatingMargin: 1, quickRatio: 1 },
    "2024-Q2": { absorptionRate: 1, cashConversionCycle: 1, dupontRoe: 1, gearingRatio: 1, grossProfitByEmployee: 1, interestCoverageRatio: 1, operatingCashFlow: 1, operatingMargin: 1, quickRatio: 1 },
    "2024-Q3": { absorptionRate: 1, cashConversionCycle: 1, dupontRoe: 1, gearingRatio: 1, grossProfitByEmployee: 1, interestCoverageRatio: 1, operatingCashFlow: 1, operatingMargin: 1, quickRatio: 1 },
    "2024-Q4": { absorptionRate: 1, cashConversionCycle: 1, dupontRoe: 1, gearingRatio: 1, grossProfitByEmployee: 1, interestCoverageRatio: 1, operatingCashFlow: 1, operatingMargin: 1, quickRatio: 1 },
    "2024-YTD": { absorptionRate: 1, cashConversionCycle: 1, dupontRoe: 1, gearingRatio: 1, grossProfitByEmployee: 1, interestCoverageRatio: 1, operatingCashFlow: 1, operatingMargin: 1, quickRatio: 1 },
  };

  // Custom Dropdown Component
  const CustomDropdown = ({ value, onChange, options, placeholder, isOpen, setIsOpen, dropdownRef, minWidth = "150px" }) => (
    <div className="relative" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center justify-between gap-2 px-3 py-2 bg-white border rounded text-xs transition-all duration-200 ${isOpen ? "border-[#1e3a5f] ring-1 ring-[#1e3a5f]/20" : "border-gray-300 hover:border-gray-400"} ${value ? "text-gray-800" : "text-gray-500"}`}
        style={{ minWidth }}
      >
        <span className="truncate">{value || placeholder}</span>
        <ChevronDown size={14} className={`text-gray-400 transition-transform duration-200 flex-shrink-0 ${isOpen ? "rotate-180" : ""}`} />
      </button>
      {isOpen && (
        <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-200 rounded shadow-lg z-50 overflow-hidden">
          <div className="max-h-[200px] overflow-y-auto">
            <div onClick={() => { onChange(""); setIsOpen(false); }} className={`px-3 py-2 text-xs cursor-pointer transition-colors ${!value ? "bg-[#1e3a5f]/10 text-[#1e3a5f] font-medium" : "text-gray-500 hover:bg-gray-50"}`}>
              {placeholder}
            </div>
            {options.map((opt) => (
              <div key={opt} onClick={() => { onChange(opt); setIsOpen(false); }} className={`px-3 py-2 text-xs cursor-pointer transition-colors ${value === opt ? "bg-[#1e3a5f] text-white font-medium" : "text-gray-700 hover:bg-[#1e3a5f]/10 hover:text-[#1e3a5f]"}`}>
                {opt}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  // Quarter checkbox handler
  const handleQuarterChange = (quarter, set) => {
    if (set === 1) setQuarters1((prev) => ({ ...prev, [quarter]: !prev[quarter] }));
    else setQuarters2((prev) => ({ ...prev, [quarter]: !prev[quarter] }));
  };

  // Get selected quarters
  const getSelectedQuarters = (quartersObj) => Object.entries(quartersObj).filter(([_, selected]) => selected).map(([quarter]) => quarter);

  // Metric config for radio buttons
  const metricConfig = [
    { key: "absorptionRate", label: "Absorption Rate" },
    { key: "cashConversionCycle", label: "Cash Conversion Cycle (Days)" },
    { key: "dupontRoe", label: "Dupont's RoE" },
    { key: "gearingRatio", label: "Gearing Ratio" },
    { key: "grossProfitByEmployee", label: "Gross- Profit by Employee" },
    { key: "interestCoverageRatio", label: "Interest Coverage Ratio" },
    { key: "operatingCashFlow", label: "Operating Cash Flow" },
    { key: "operatingMargin", label: "Operating Margin" },
    { key: "quickRatio", label: "Quick Ratio" },
  ];

  // Chart Data
  const allChartData = [
    { period: "Q1-2022", absorptionRate: 120, cashConversionCycle: 85, dupontRoe: 95, gearingRatio: 78, grossProfitByEmployee: 110, interestCoverageRatio: 92, operatingCashFlow: 88, operatingMargin: 75, quickRatio: 82 },
    { period: "Q2-2022", absorptionRate: 45, cashConversionCycle: 52, dupontRoe: 48, gearingRatio: 55, grossProfitByEmployee: 60, interestCoverageRatio: 58, operatingCashFlow: 50, operatingMargin: 45, quickRatio: 48 },
    { period: "Q3-2022", absorptionRate: 65, cashConversionCycle: 70, dupontRoe: 62, gearingRatio: 68, grossProfitByEmployee: 72, interestCoverageRatio: 65, operatingCashFlow: 60, operatingMargin: 58, quickRatio: 55 },
    { period: "Q4-2022", absorptionRate: 38, cashConversionCycle: 42, dupontRoe: 35, gearingRatio: 40, grossProfitByEmployee: 45, interestCoverageRatio: 38, operatingCashFlow: 35, operatingMargin: 32, quickRatio: 30 },
    { period: "YTD-2022", absorptionRate: 95, cashConversionCycle: 88, dupontRoe: 82, gearingRatio: 85, grossProfitByEmployee: 90, interestCoverageRatio: 85, operatingCashFlow: 78, operatingMargin: 72, quickRatio: 70 },
    { period: "Q1-2023", absorptionRate: 130, cashConversionCycle: 125, dupontRoe: 118, gearingRatio: 122, grossProfitByEmployee: 128, interestCoverageRatio: 120, operatingCashFlow: 115, operatingMargin: 110, quickRatio: 105 },
    { period: "Q2-2023", absorptionRate: 58, cashConversionCycle: 62, dupontRoe: 55, gearingRatio: 60, grossProfitByEmployee: 65, interestCoverageRatio: 58, operatingCashFlow: 52, operatingMargin: 48, quickRatio: 45 },
    { period: "Q3-2023", absorptionRate: 85, cashConversionCycle: 90, dupontRoe: 82, gearingRatio: 88, grossProfitByEmployee: 92, interestCoverageRatio: 85, operatingCashFlow: 80, operatingMargin: 75, quickRatio: 72 },
    { period: "Q4-2023", absorptionRate: 72, cashConversionCycle: 78, dupontRoe: 70, gearingRatio: 75, grossProfitByEmployee: 80, interestCoverageRatio: 72, operatingCashFlow: 68, operatingMargin: 62, quickRatio: 58 },
    { period: "YTD-2023", absorptionRate: 115, cashConversionCycle: 108, dupontRoe: 102, gearingRatio: 105, grossProfitByEmployee: 112, interestCoverageRatio: 105, operatingCashFlow: 98, operatingMargin: 92, quickRatio: 88 },
    { period: "Q1-2024", absorptionRate: 140, cashConversionCycle: 135, dupontRoe: 128, gearingRatio: 132, grossProfitByEmployee: 138, interestCoverageRatio: 130, operatingCashFlow: 125, operatingMargin: 120, quickRatio: 115 },
    { period: "Q2-2024", absorptionRate: 68, cashConversionCycle: 72, dupontRoe: 65, gearingRatio: 70, grossProfitByEmployee: 75, interestCoverageRatio: 68, operatingCashFlow: 62, operatingMargin: 58, quickRatio: 55 },
    { period: "Q3-2024", absorptionRate: 95, cashConversionCycle: 100, dupontRoe: 92, gearingRatio: 98, grossProfitByEmployee: 102, interestCoverageRatio: 95, operatingCashFlow: 90, operatingMargin: 85, quickRatio: 82 },
    { period: "Q4-2024", absorptionRate: 82, cashConversionCycle: 88, dupontRoe: 80, gearingRatio: 85, grossProfitByEmployee: 90, interestCoverageRatio: 82, operatingCashFlow: 78, operatingMargin: 72, quickRatio: 68 },
    { period: "YTD-2024", absorptionRate: 125, cashConversionCycle: 118, dupontRoe: 112, gearingRatio: 115, grossProfitByEmployee: 122, interestCoverageRatio: 115, operatingCashFlow: 108, operatingMargin: 102, quickRatio: 98 },
  ];

  // Filter chart data based on selections (like DFRatioChart)
  const filteredChartData = useMemo(() => {
    if (!isFilterSelected) return [];
    
    const selectedQ1 = getSelectedQuarters(quarters1);
    const selectedQ2 = getSelectedQuarters(quarters2);
    const periods1 = year1 ? selectedQ1.map((q) => `${q}-${year1}`) : [];
    const periods2 = year2 ? selectedQ2.map((q) => `${q}-${year2}`) : [];
    const allPeriods = [...periods1, ...periods2];
    
    return allChartData.filter((item) => allPeriods.includes(item.period));
  }, [year1, year2, quarters1, quarters2, isFilterSelected]);

  // Generate filtered table data based on selected filters
  const filteredTableData = useMemo(() => {
    if (!isFilterSelected) return [];
    
    const selectedQ1 = getSelectedQuarters(quarters1);
    const selectedQ2 = getSelectedQuarters(quarters2);
    
    const result = [];
    const selectedDealer = dealerName || "Navin Infrasolution Pvt Ltd";
    
    // Add data for Year 1 quarters
    if (year1) {
      selectedQ1.forEach((quarter) => {
        const key = `${year1}-${quarter}`;
        const healthValues = healthValuesData[key] || {};
        const healthIndex = Object.values(healthValues).reduce((sum, val) => sum + val, 0);
        
        ratiosList.forEach((ratio, idx) => {
          result.push({
            year: year1,
            quarter: quarter,
            dealer: selectedDealer,
            ratio: ratio.name,
            healthValue: healthValues[ratio.key] || 0,
            healthIndex: healthIndex,
            isFirstInQuarter: idx === 0,
            quarterRowCount: ratiosList.length,
          });
        });
      });
    }
    
    // Add data for Year 2 quarters
    if (year2) {
      selectedQ2.forEach((quarter) => {
        const key = `${year2}-${quarter}`;
        const healthValues = healthValuesData[key] || {};
        const healthIndex = Object.values(healthValues).reduce((sum, val) => sum + val, 0);
        
        ratiosList.forEach((ratio, idx) => {
          result.push({
            year: year2,
            quarter: quarter,
            dealer: selectedDealer,
            ratio: ratio.name,
            healthValue: healthValues[ratio.key] || 0,
            healthIndex: healthIndex,
            isFirstInQuarter: idx === 0,
            quarterRowCount: ratiosList.length,
          });
        });
      });
    }
    
    return result;
  }, [year1, year2, quarters1, quarters2, dealerName, isFilterSelected]);

  // Group table data by year for proper row spanning
  const groupedTableData = useMemo(() => {
    const grouped = {};
    filteredTableData.forEach((row) => {
      const yearKey = row.year;
      if (!grouped[yearKey]) {
        grouped[yearKey] = { year: yearKey, quarters: {} };
      }
      const quarterKey = row.quarter;
      if (!grouped[yearKey].quarters[quarterKey]) {
        grouped[yearKey].quarters[quarterKey] = [];
      }
      grouped[yearKey].quarters[quarterKey].push(row);
    });
    return grouped;
  }, [filteredTableData]);

  // Export functions
  const exportChartAsImage = (callback) => {
    if (!chartRef.current) { alert("Chart not found."); return; }
    setTimeout(() => {
      html2canvas(chartRef.current, { 
        backgroundColor: '#ffffff', 
        scale: 2, 
        useCORS: true, 
        allowTaint: true, 
        logging: false, 
        ignoreElements: (element) => element.classList.contains('dropdown-wrapper') || element.closest('.dropdown-wrapper') 
      }).then((canvas) => callback(canvas)).catch((error) => { 
        console.error("Error:", error); 
        alert("Error exporting chart."); 
      });
    }, 100);
  };

  const handlePrintChart = () => {
    setOpenMenuId(null);
    setTimeout(() => {
      exportChartAsImage((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const printWindow = window.open("", "_blank");
        if (printWindow) {
          printWindow.document.body.style.margin = "0";
          printWindow.document.body.style.padding = "20px";
          printWindow.document.body.style.display = "flex";
          printWindow.document.body.style.justifyContent = "center";
          printWindow.document.body.style.alignItems = "center";
          printWindow.document.body.style.minHeight = "100vh";
          printWindow.document.body.style.background = "white";
          printWindow.document.body.style.boxSizing = "border-box";
          const img = printWindow.document.createElement("img");
          img.src = imgData;
          img.style.maxWidth = "100%";
          img.style.height = "auto";
          img.style.display = "block";
          img.onload = () => { setTimeout(() => { printWindow.print(); printWindow.close(); }, 300); };
          printWindow.document.body.appendChild(img);
        }
      });
    }, 50);
  };

  const handleDownloadPNG = () => {
    setOpenMenuId(null);
    setTimeout(() => {
      exportChartAsImage((canvas) => {
        const link = document.createElement("a");
        link.download = "dfhm_dashboard_chart.png";
        link.href = canvas.toDataURL("image/png");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      });
    }, 50);
  };

  const handleDownloadPDF = () => {
    setOpenMenuId(null);
    setTimeout(() => {
      exportChartAsImage((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF("landscape");
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const imgWidth = pdfWidth - 20;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        const yPos = (pdfHeight - imgHeight) / 2;
        pdf.addImage(imgData, "PNG", 10, yPos > 10 ? yPos : 10, imgWidth, imgHeight);
        pdf.save("dfhm_dashboard_chart.pdf");
      });
    }, 50);
  };

  const handleDownloadXLS = () => {
    try {
      const exportData = filteredTableData.map(row => ({
        Year: row.year,
        Quarter: row.quarter,
        Dealer: row.dealer,
        Ratio: row.ratio,
        "Health Value": row.healthValue,
        "Health Index": row.isFirstInQuarter ? row.healthIndex : ""
      }));
      const worksheet = XLSX.utils.json_to_sheet(exportData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "DFHM Dashboard");
      XLSX.writeFile(workbook, "dfhm_dashboard_data.xlsx");
    } catch (error) {
      console.error("Error:", error);
      alert("Error downloading XLS.");
    }
    setOpenMenuId(null);
  };

  // Radio Button Component
  const RadioButton = ({ checked, onChange, label }) => (
    <label className="flex items-center gap-1.5 cursor-pointer select-none">
      <div 
        onClick={onChange} 
        className={`w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${checked ? "border-[#1e3a5f]" : "border-gray-400 hover:border-gray-500"}`}
      >
        {checked && <div className="w-2 h-2 rounded-full bg-[#1e3a5f]"></div>}
      </div>
      <span className={`text-xs ${checked ? "text-[#1e3a5f] font-medium" : "text-gray-600"}`}>{label}</span>
    </label>
  );

  // Checkbox Component
  const Checkbox = ({ checked, onChange, label }) => (
    <label className="flex items-center gap-1 cursor-pointer select-none">
      <div className="relative">
        <input 
          type="checkbox" 
          checked={checked} 
          onChange={onChange} 
          className="sr-only peer" 
        />
        <div className={`w-4 h-4 border rounded transition-all duration-200 flex items-center justify-center ${checked ? "bg-white border-gray-400" : "bg-white border-gray-300"}`}>
          {checked && (
            <svg className="w-3 h-3 text-[#1e3a5f]" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={3}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          )}
        </div>
      </div>
      <span className="text-xs text-gray-700">{label}</span>
    </label>
  );

  // Empty State Component (like DFRatioChart)
  const renderEmptyState = () => (
    <div className="flex-1 flex items-center justify-center py-16">
      <div className="text-center">
        <div className="w-20 h-20 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
          <BarChart3 size={40} className="text-gray-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-700 mb-2">No Data to Display</h3>
        <p className="text-sm text-gray-500 max-w-md">
          Please select <span className="font-medium">Year</span> and <span className="font-medium">Quarter(s)</span> to view the financial health chart and data.
        </p>
        <div className="mt-4 flex items-center justify-center gap-2 text-xs text-gray-400">
          <span className="px-2 py-1 bg-gray-100 rounded">Year + Quarters</span>
          <span>→</span>
          <span className="px-2 py-1 bg-gray-100 rounded">View Chart & Table</span>
        </div>
      </div>
    </div>
  );

  // Render table with proper row spanning
  const renderTable = () => {
    const years = Object.keys(groupedTableData);
    if (years.length === 0) return null;

    const rows = [];
    
    years.forEach((yearKey) => {
      const yearData = groupedTableData[yearKey];
      const quarters = Object.keys(yearData.quarters);
      let yearRowCount = 0;
      quarters.forEach((q) => { yearRowCount += yearData.quarters[q].length; });
      
      let isFirstRowOfYear = true;
      
      quarters.forEach((quarterKey) => {
        const quarterRows = yearData.quarters[quarterKey];
        let isFirstRowOfQuarter = true;
        
        quarterRows.forEach((row, rowIdx) => {
          rows.push(
            <tr key={`${yearKey}-${quarterKey}-${rowIdx}`} className="border-b border-gray-200 hover:bg-blue-50/30">
              {isFirstRowOfYear && (
                <td rowSpan={yearRowCount} className="py-2 px-3 border-r border-gray-200 align-middle font-medium bg-gray-50/50 text-center">
                  {yearKey}
                </td>
              )}
              {isFirstRowOfQuarter && (
                <td rowSpan={quarterRows.length} className="py-2 px-3 border-r border-gray-200 align-middle font-medium bg-gray-50/50 text-center">
                  {quarterKey}
                </td>
              )}
              <td className="py-2 px-3 border-r border-gray-200">{row.dealer}</td>
              <td className="py-2 px-3 border-r border-gray-200">{row.ratio}</td>
              <td className="py-2 px-3 text-center border-r border-gray-200">{row.healthValue}</td>
              {isFirstRowOfQuarter && (
                <td rowSpan={quarterRows.length} className="py-2 px-3 text-center align-middle font-bold text-lg text-[#1e3a5f] bg-gray-50/50">
                  {row.healthIndex}
                </td>
              )}
            </tr>
          );
          
          isFirstRowOfYear = false;
          isFirstRowOfQuarter = false;
        });
      });
    });

    return (
      <div className="bg-white border border-gray-200 rounded overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-[#1e3a5f] text-white">
              <tr>
                <th className="py-2.5 px-3 text-center font-medium border-r border-[#2a4a6f] w-16">Year</th>
                <th className="py-2.5 px-3 text-center font-medium border-r border-[#2a4a6f] w-20">Quarter</th>
                <th className="py-2.5 px-3 text-left font-medium border-r border-[#2a4a6f]">Dealer</th>
                <th className="py-2.5 px-3 text-left font-medium border-r border-[#2a4a6f]">Ratio</th>
                <th className="py-2.5 px-3 text-center font-medium border-r border-[#2a4a6f] w-28">Health Value</th>
                <th className="py-2.5 px-3 text-center font-medium w-28">Health Index</th>
              </tr>
            </thead>
            <tbody>
              {rows}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-[#f8f9fa] min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex-1 flex flex-col`}>
        <div className="mt-[4.5rem] lg:mt-[6rem] flex flex-col flex-1">
          
          {/* HEADER */}
          <div className="bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-center">
            <h1 className="text-xl font-bold text-[#1e3a5f]">DFHM Dashboard</h1>
          </div>

          {/* FILTER ROW */}
          <div className="bg-white border-b border-gray-200 px-4 py-3 flex flex-wrap items-center gap-4">
            {/* Search */}
            <div className="flex items-center border border-gray-300 rounded overflow-hidden bg-white">
              <span className="px-2 text-gray-400">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </span>
              <input 
                type="text" 
                placeholder="Search" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="px-2 py-2 text-xs w-20 focus:outline-none" 
              />
            </div>

            {/* Market Area */}
            <CustomDropdown 
              value={marketArea} 
              onChange={setMarketArea} 
              options={marketOptions} 
              placeholder="Market Area" 
              isOpen={marketDropdownOpen} 
              setIsOpen={setMarketDropdownOpen} 
              dropdownRef={marketDropdownRef} 
              minWidth="120px" 
            />

            {/* Dealer Name */}
            <CustomDropdown 
              value={dealerName} 
              onChange={setDealerName} 
              options={dealerOptions} 
              placeholder="Dealer" 
              isOpen={dealerDropdownOpen} 
              setIsOpen={setDealerDropdownOpen} 
              dropdownRef={dealerDropdownRef} 
              minWidth="200px" 
            />

            {/* Year 1 */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500 font-medium">Year</span>
              <CustomDropdown 
                value={year1} 
                onChange={setYear1} 
                options={yearOptions} 
                placeholder="Select Year" 
                isOpen={year1DropdownOpen} 
                setIsOpen={setYear1DropdownOpen} 
                dropdownRef={year1DropdownRef} 
                minWidth="100px" 
              />
            </div>

            {/* Quarter 1 - Checkboxes */}
            <div className="flex items-center gap-3">
              <span className="text-xs text-gray-500 font-medium">Quarter</span>
              {["Q1", "Q2", "Q3", "Q4", "YTD"].map((q) => (
                <Checkbox 
                  key={q} 
                  checked={quarters1[q]} 
                  onChange={() => handleQuarterChange(q, 1)} 
                  label={q} 
                />
              ))}
            </div>

            {/* Year 2 */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500 font-medium">Year</span>
              <CustomDropdown 
                value={year2} 
                onChange={setYear2} 
                options={yearOptions} 
                placeholder="Select Year" 
                isOpen={year2DropdownOpen} 
                setIsOpen={setYear2DropdownOpen} 
                dropdownRef={year2DropdownRef} 
                minWidth="100px" 
              />
            </div>

            {/* Quarter 2 - Checkboxes */}
            <div className="flex items-center gap-3">
              <span className="text-xs text-gray-500 font-medium">Quarter</span>
              {["Q1", "Q2", "Q3", "Q4", "YTD"].map((q) => (
                <Checkbox 
                  key={q} 
                  checked={quarters2[q]} 
                  onChange={() => handleQuarterChange(q, 2)} 
                  label={q} 
                />
              ))}
            </div>
          </div>

          {/* CONTENT */}
          <div className="flex-1 overflow-y-auto p-4">
            
            {/* Show Empty State if no filters selected */}
            {!isFilterSelected ? (
              renderEmptyState()
            ) : (
              <>
                {/* CHART SECTION */}
                <div ref={chartRef} className="bg-white border border-gray-200 rounded mb-4">
                  {/* Chart Header */}
                  <div className="flex items-center justify-between px-4 pt-4">
                    <div></div>
                    <h2 className="text-sm font-semibold text-gray-800">Dealer Finance Health Chart</h2>
                    
                    {/* Menu Dropdown */}
                    <div className="relative dropdown-wrapper">
                      <button onClick={() => setOpenMenuId(openMenuId === "chart" ? null : "chart")} className="p-1.5 hover:bg-gray-100 rounded">
                        <Menu size={18} className="text-gray-500" />
                      </button>
                      {openMenuId === "chart" && (
                        <div className="absolute right-0 top-8 bg-white border border-gray-200 rounded-md shadow-lg z-50 w-48">
                          <button onClick={handlePrintChart} className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                            <Printer size={14} />Print chart
                          </button>
                          <div className="border-t border-gray-200"></div>
                          <button onClick={handleDownloadPNG} className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                            <Download size={14} />Download PNG
                          </button>
                          <button onClick={handleDownloadPDF} className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                            <Download size={14} />Download PDF
                          </button>
                          <div className="border-t border-gray-200"></div>
                          <button onClick={handleDownloadXLS} className="w-full px-3 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                            <FileSpreadsheet size={14} />Download XLS
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Radio Buttons for Metrics */}
                  <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 px-4 py-3">
                    {metricConfig.map((metric) => (
                      <RadioButton
                        key={metric.key}
                        checked={selectedMetric === metric.key}
                        onChange={() => setSelectedMetric(metric.key)}
                        label={metric.label}
                      />
                    ))}
                  </div>

                  {/* Chart */}
                  <div className="px-4 pb-4">
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={filteredChartData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }} barCategoryGap="15%">
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                        <XAxis 
                          dataKey="period" 
                          tick={{ fontSize: 11, fill: "#6b7280" }} 
                          axisLine={{ stroke: "#d1d5db" }} 
                          tickLine={false} 
                        />
                        <YAxis 
                          tick={{ fontSize: 11, fill: "#6b7280" }} 
                          axisLine={{ stroke: "#d1d5db" }} 
                          tickLine={false}
                        />
                        <Tooltip 
                          contentStyle={{ fontSize: 11, borderRadius: 4, border: "1px solid #e5e7eb", boxShadow: "0 2px 4px rgba(0,0,0,0.1)" }} 
                          formatter={(value) => value.toLocaleString("en-IN")} 
                        />
                        <Bar 
                          dataKey={selectedMetric}
                          radius={[2, 2, 0, 0]} 
                          maxBarSize={50}
                          fill="#1e3a5f"
                          shape={(props) => {
                            const { x, y, width, height, payload } = props;
                            const year = payload.period.split("-")[1];
                            let fill = "#1e3a5f";
                            if (year === "2024") fill = "#4db6ac";
                            return <rect x={x} y={y} width={width} height={height} fill={fill} rx={2} ry={2} />;
                          }}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* TABLE SECTION */}
                {renderTable()}
              </>
            )}

          </div>
        </div>
      </div>
    </div>
  );
};

export default DFHMDashboard;