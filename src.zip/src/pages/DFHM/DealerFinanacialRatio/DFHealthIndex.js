import React, { useState, useRef, useEffect } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  LabelList,
} from "recharts";
import { ArrowLeft, Menu, Link2, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import * as XLSX from "xlsx";

const DFHealthIndex = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [remarks, setRemarks] = useState("");
  const [openMenuId, setOpenMenuId] = useState(null);
  const [attachedFile, setAttachedFile] = useState(null);
  const chartRefs = useRef({});
  const fileInputRef = useRef(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest(".dropdown-wrapper")) {
        setOpenMenuId(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleBack = () => {
    navigate("/dfhm/dealerfinacialratio/ratiochart");
  };

  // File attachment handler
  const handleAttachClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAttachedFile(file);
      alert(`File attached: ${file.name}`);
    }
  };

  // Delete handler - clears both remarks and attached file
  const handleDelete = () => {
    setRemarks("");
    setAttachedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Health Index Score
  const healthScore = 7.5;

  // Chart Data - Colors matching the design
  const absorptionRatioData = [
    { name: "Lowest", value: 54.73, color: "#4db6ac" },
    { name: "highest", value: 746.3, color: "#4db6ac" },
    { name: "Mean", value: 400.51, color: "#4db6ac" },
    { name: "Navin", value: 65.01, color: "#4db6ac" },
  ];

  const operatingMarginData = [
    { name: "Lowest", value: -2.61, color: "#1e3a5f" },
    { name: "highest", value: 45.66, color: "#1e3a5f" },
    { name: "Mean", value: 93.94, color: "#1e3a5f" },
    { name: "Navin", value: 2.37, color: "#1e3a5f" },
  ];

  const gearingRatioData = [
    { name: "Lowest", value: 12.5, color: "#4db6ac" },
    { name: "highest", value: 85.2, color: "#4db6ac" },
    { name: "Mean", value: 45.8, color: "#4db6ac" },
    { name: "Navin", value: 32.1, color: "#4db6ac" },
  ];

  const interestCoverageData = [
    { name: "Lowest", value: 1.2, color: "#1e3a5f" },
    { name: "highest", value: 15.8, color: "#1e3a5f" },
    { name: "Mean", value: 8.5, color: "#1e3a5f" },
    { name: "Navin", value: 5.2, color: "#1e3a5f" },
  ];

  // Save remarks handler
  const handleSaveRemarks = () => {
    console.log("Saving remarks:", remarks);
    console.log("Attached file:", attachedFile);
    alert(`Remarks saved successfully!${attachedFile ? `\nAttached: ${attachedFile.name}` : ""}`);
  };

  // Export handler
  const handleExport = () => {
    const workbook = XLSX.utils.book_new();
    
    const ws1 = XLSX.utils.json_to_sheet(absorptionRatioData);
    XLSX.utils.book_append_sheet(workbook, ws1, "Absorption Ratio");
    
    const ws2 = XLSX.utils.json_to_sheet(operatingMarginData);
    XLSX.utils.book_append_sheet(workbook, ws2, "Operating Margin");
    
    const ws3 = XLSX.utils.json_to_sheet(gearingRatioData);
    XLSX.utils.book_append_sheet(workbook, ws3, "Gearing Ratio");
    
    const ws4 = XLSX.utils.json_to_sheet(interestCoverageData);
    XLSX.utils.book_append_sheet(workbook, ws4, "Interest Coverage");
    
    XLSX.writeFile(workbook, "health_index_export.xlsx");
  };

  // Download handlers
  const exportChartAsImage = (chartId, callback) => {
    const chartElement = chartRefs.current[chartId];
    if (!chartElement) {
      alert("Chart not found. Please try again.");
      return;
    }

    setTimeout(() => {
      html2canvas(chartElement, {
        backgroundColor: '#ffffff',
        scale: 2,
        useCORS: true,
        allowTaint: true,
        logging: false,
        ignoreElements: (element) => {
          return element.classList.contains('dropdown-wrapper') || 
                 element.closest('.dropdown-wrapper');
        }
      }).then((canvas) => {
        callback(canvas);
      }).catch((error) => {
        console.error("Error capturing chart:", error);
        alert("Error exporting chart. Please try again.");
      });
    }, 100);
  };

  const handleDownloadPNG = (chartId) => {
    setOpenMenuId(null);
    setTimeout(() => {
      exportChartAsImage(chartId, (canvas) => {
        const link = document.createElement("a");
        link.download = `${chartId}_chart.png`;
        link.href = canvas.toDataURL("image/png");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      });
    }, 50);
  };

  const handleDownloadPDF = (chartId) => {
    setOpenMenuId(null);
    setTimeout(() => {
      exportChartAsImage(chartId, (canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF("landscape");
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        
        const imgWidth = pdfWidth - 20;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        const yPos = (pdfHeight - imgHeight) / 2;
        pdf.addImage(imgData, "PNG", 10, yPos > 10 ? yPos : 10, imgWidth, imgHeight);
        pdf.save(`${chartId}_chart.pdf`);
      });
    }, 50);
  };

  const handlePrintChart = (chartId) => {
    setOpenMenuId(null);
    setTimeout(() => {
      exportChartAsImage(chartId, (canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const printWindow = window.open("", "_blank");
        if (printWindow) {
          // Style the body
          printWindow.document.body.style.margin = "0";
          printWindow.document.body.style.padding = "20px";
          printWindow.document.body.style.display = "flex";
          printWindow.document.body.style.justifyContent = "center";
          printWindow.document.body.style.alignItems = "center";
          printWindow.document.body.style.minHeight = "100vh";
          printWindow.document.body.style.background = "white";
          printWindow.document.body.style.boxSizing = "border-box";
          
          // Create and style the image
          const img = printWindow.document.createElement("img");
          img.src = imgData;
          img.style.maxWidth = "100%";
          img.style.height = "auto";
          img.style.display = "block";
          
          img.onload = () => {
            setTimeout(() => {
              printWindow.print();
              printWindow.close();
            }, 300);
          };
          printWindow.document.body.appendChild(img);
        }
      });
    }, 50);
  };

  // Professional Gauge Component matching the image exactly
  const GaugeChart = ({ score, maxScore = 10 }) => {
    const percentage = (score / maxScore) * 100;
    const needleAngle = -90 + (percentage / 100) * 180;

    return (
      <div className="flex flex-col items-center justify-center py-4">
        <svg viewBox="0 0 300 200" className="w-full max-w-[320px]">
          <defs>
            <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.15"/>
            </filter>
          </defs>

          {/* Outer circle border */}
          <circle
            cx="150"
            cy="150"
            r="125"
            fill="none"
            stroke="#e5e5e5"
            strokeWidth="2"
          />

          {/* Inner white background */}
          <circle
            cx="150"
            cy="150"
            r="122"
            fill="white"
          />

          {/* Colored arc segments - matching the image colors */}
          {/* Red segment (0-20%) */}
          <path
            d="M 45 150 A 105 105 0 0 1 66 85"
            fill="none"
            stroke="#dc2626"
            strokeWidth="22"
            strokeLinecap="butt"
          />
          {/* Orange segment (20-40%) */}
          <path
            d="M 66 85 A 105 105 0 0 1 115 50"
            fill="none"
            stroke="#f97316"
            strokeWidth="22"
            strokeLinecap="butt"
          />
          {/* Yellow segment (40-60%) */}
          <path
            d="M 115 50 A 105 105 0 0 1 185 50"
            fill="none"
            stroke="#facc15"
            strokeWidth="22"
            strokeLinecap="butt"
          />
          {/* Light Green segment (60-80%) */}
          <path
            d="M 185 50 A 105 105 0 0 1 234 85"
            fill="none"
            stroke="#84cc16"
            strokeWidth="22"
            strokeLinecap="butt"
          />
          {/* Green segment (80-100%) */}
          <path
            d="M 234 85 A 105 105 0 0 1 255 150"
            fill="none"
            stroke="#22c55e"
            strokeWidth="22"
            strokeLinecap="butt"
          />

          {/* Tick marks and labels */}
          {[0, 2, 4, 6, 8, 10].map((tick, i) => {
            const angle = -180 + (tick / 10) * 180;
            const radian = (angle * Math.PI) / 180;
            const x1 = 150 + 78 * Math.cos(radian);
            const y1 = 150 + 78 * Math.sin(radian);
            const x2 = 150 + 90 * Math.cos(radian);
            const y2 = 150 + 90 * Math.sin(radian);
            const labelX = 150 + 65 * Math.cos(radian);
            const labelY = 150 + 65 * Math.sin(radian);
            
            return (
              <g key={i}>
                <line
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke="#999"
                  strokeWidth="2"
                />
                <text
                  x={labelX}
                  y={labelY + 4}
                  textAnchor="middle"
                  fontSize="13"
                  fill="#666"
                  fontWeight="500"
                >
                  {tick}
                </text>
              </g>
            );
          })}

          {/* Score label */}
          <text
            x="150"
            y="115"
            textAnchor="middle"
            fontSize="14"
            fill="#666"
            fontWeight="500"
          >
            Score
          </text>

          {/* Needle */}
          <g transform={`rotate(${needleAngle}, 150, 150)`}>
            <polygon
              points="150,55 146,150 154,150"
              fill="#1f2937"
              filter="url(#shadow)"
            />
          </g>

          {/* Center circle */}
          <circle cx="150" cy="150" r="12" fill="#1f2937" />
          <circle cx="150" cy="150" r="6" fill="#4b5563" />
        </svg>
        
        {/* Score display */}
        <div className="text-4xl font-bold text-gray-800 mt-2">{score}</div>
      </div>
    );
  };

  // Custom Label Component for bars
  const CustomBarLabel = (props) => {
    const { x, y, width, value } = props;
    const displayValue = typeof value === 'number' ? 
      (Math.abs(value) >= 100 ? value.toFixed(1) : value.toFixed(2)) : value;
    
    return (
      <g>
        <rect
          x={x + width / 2 - 30}
          y={y - 25}
          width={60}
          height={21}
          rx={4}
          fill="#4db6ac"
        />
        <text
          x={x + width / 2}
          y={y - 10}
          textAnchor="middle"
          fill="white"
          fontSize={12}
          fontWeight={500}
        >
          {displayValue}
        </text>
      </g>
    );
  };

  // Render Bar Chart
  const renderBarChart = (chartId, title, data, yAxisLabel) => {
    return (
      <div
        ref={(el) => (chartRefs.current[chartId] = el)}
        className="bg-white border border-gray rounded-lg mb-4"
      >
        {/* Chart Header */}
        <div className="flex items-center justify-between px-4 pt-4">
          <div className="flex-1"></div>
          <h3 className="text-base font-semibold text-gray flex-1 text-center">{title}</h3>
          
          {/* Menu */}
          <div className="relative dropdown-wrapper flex-1 flex justify-end">
            <button
              onClick={() => setOpenMenuId(openMenuId === chartId ? null : chartId)}
              className="p-1.5 hover:bg-gray rounded"
            >
              <Menu size={18} className="text-gray" />
            </button>

            {openMenuId === chartId && (
              <div className="absolute right-0 top-9 bg-white border border-gray rounded-md shadow-lg z-50 w-48">
                <button
                  onClick={() => handlePrintChart(chartId)}
                  className="w-full px-4 py-2 text-left text-sm text-gray hover:bg-gray-50"
                >
                  Print chart
                </button>
                <div className="border-t border-gray"></div>
                <button
                  onClick={() => handleDownloadPNG(chartId)}
                  className="w-full px-4 py-2 text-left text-sm text-gray hover:bg-gray"
                >
                  Download PNG
                </button>
                <button
                  onClick={() => handleDownloadPDF(chartId)}
                  className="w-full px-4 py-2 text-left text-sm text-gray hover:bg-gray"
                >
                  Download PDF
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Chart */}
        <div className="px-4 pb-4">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={data} margin={{ top: 35, right: 30, left: 20, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
              <XAxis
                dataKey="name"
                tick={{ fontSize: 12, fill: "#6b7280" }}
                axisLine={{ stroke: "#d1d5db" }}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 11, fill: "#6b7280" }}
                axisLine={{ stroke: "#d1d5db" }}
                tickLine={false}
                label={{
                  value: yAxisLabel,
                  angle: -90,
                  position: "insideLeft",
                  style: { textAnchor: "middle", fill: "#9ca3af", fontSize: 11 },
                  dx: -10,
                }}
              />
              <Tooltip
                contentStyle={{
                  fontSize: 12,
                  borderRadius: 6,
                  border: "1px solid #e5e7eb",
                  boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
                }}
                formatter={(value) => [value.toLocaleString("en-IN"), "Value"]}
              />
              <Bar dataKey="value" radius={[4, 4, 0, 0]} maxBarSize={70}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
                <LabelList dataKey="value" content={<CustomBarLabel />} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-[#f8f9fa] min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration ${menuOpen ? "lg:ml-60" : ""} flex-1 flex flex-col`}>
        <div className="mt-[4.5rem] lg:mt-[6rem] flex flex-col flex-1">
          
          {/* ======== HEADER ROW ======== */}
          <div className="bg-white border-b border-gray px-4 py-3 flex items-center justify-between">
            {/* Left: Back + Title */}
            <div className="flex items-center gap-3">
              <button
                onClick={handleBack}
                className="w-7 h-7 flex items-center justify-center bg-[#1e3a5f] text-white"
              >
                <ArrowLeft size={18} />
              </button>
              <h1 className="text-base font-semibold text-[#1e3a5f]">Dealer Performance Health Index</h1>
            </div>

            {/* Center: Disclaimer */}
            <p className="text-[11px] text-red font-medium">
              Disclaimer : This data is not for the legal entity, this is for internal review to determine improvement
              areas within dealerships
            </p>

            {/* Right: Export Button */}
            <button
              onClick={handleExport}
              className="px-6 py-2 text-xs font-medium bg-[#1e3a5f] text-white hover:bg-[#1e3a5f]/90"
            >
              Export
            </button>
          </div>

          {/* ======== MAIN CONTENT ======== */}
          <div className="flex-1 overflow-y-auto p-4">
            
            {/* Top Section: Gauge + Remarks */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6 items-stretch">
              
              {/* Final Performance Health Index - Gauge */}
              <div className="bg-white border-2 border-red rounded-lg overflow-hidden flex flex-col">
                {/* Header */}
                <div className="flex items-center justify-between px-4 py-3 border-b border-gray">
                  <h3 className="text-base font-semibold text-gray-800">Final Performance Health Index</h3>
                  <div className="relative dropdown-wrapper">
                    <button 
                      onClick={() => setOpenMenuId(openMenuId === "gauge" ? null : "gauge")}
                      className="p-1 hover:bg-gray rounded"
                    >
                      <Menu size={18} className="text-gray" />
                    </button>

                    {openMenuId === "gauge" && (
                      <div className="absolute right-0 top-9 bg-white border border-gray rounded-md shadow-lg z-50 w-48">
                        <button
                          onClick={() => handlePrintChart("gauge")}
                          className="w-full px-4 py-2 text-left text-sm text-gray hover:bg-gray"
                        >
                          Print chart
                        </button>
                        <div className="border-t border-gray"></div>
                        <button
                          onClick={() => handleDownloadPNG("gauge")}
                          className="w-full px-4 py-2 text-left text-sm text-gray hover:bg-gray"
                        >
                          Download PNG
                        </button>
                        <button
                          onClick={() => handleDownloadPDF("gauge")}
                          className="w-full px-4 py-2 text-left text-sm text-gray hover:bg-gray"
                        >
                          Download PDF
                        </button>
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Gauge */}
                <div 
                  ref={(el) => (chartRefs.current["gauge"] = el)}
                  className="px-4 py-2 flex-1 bg-white"
                >
                  <GaugeChart score={healthScore} maxScore={10} />
                </div>
                
                {/* Error/Warning message */}
                <div className="bg-red text-white p-3 text-xs">
                  <p className="text-[10px] mb-0.5">Highcharts error #33:</p>
                  <p className="font-bold text-sm mb-1">Invalid attribute or tagName</p>
                  <p className="text-[10px] leading-relaxed">
                    This error occurs if HTML in the chart configuration contains unknown tag names or attributes. Unknown tag names or attributes are those not present in the _allow lists_.
                  </p>
                  <p className="text-[10px] mt-1">To fix the error, consider:</p>
                  <p className="text-[10px] leading-relaxed">
                    Is your tag name or attribute spelled correctly? For example, linearGradient would be blocked as it is a misspelling for linearGradient.
                  </p>
                  <p className="text-[10px] leading-relaxed">
                    Is it allowed in Highcharts? For example, onclick attributes are blocked as they pose a real security threat.
                  </p>
                  <p className="text-[10px] leading-relaxed">
                    This error occurs because attributes and tag names are sanitized of potentially harmful content from the chart configuration before being added to the DOM.
                  </p>
                  <p className="text-[10px] leading-relaxed">
                    Consult the security documentation for more information.
                  </p>
                </div>
              </div>

              {/* Remarks Section */}
              <div className="bg-white border border-gray rounded-lg flex flex-col">
                {/* Header */}
                <div className="px-4 py-3 border-b border-gray">
                  <h3 className="text-sm font-semibold text-gray">Remarks</h3>
                </div>
                
                {/* Textarea - takes remaining space */}
                <div className="p-4 pb-3 flex-1 flex flex-col">
                  <textarea
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="Enter your text"
                    className="w-full flex-1 min-h-[180px] border border-gray rounded p-3 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-[#1e3a5f]/30 focus:border-[#1e3a5f]/50 placeholder-gray-400"
                  />
                </div>
                
                {/* Footer */}
                <div className="flex items-center justify-between px-4 py-3 border-t border-gray">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-blue">24 Nov 2024, 04:00PM</span>
                    {attachedFile && (
                      <span className="text-xs text-green bg-green-50 px-2 py-0.5 rounded">
                        📎 {attachedFile.name}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    {/* Hidden file input */}
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      className="hidden"
                      accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg"
                    />
                    {/* Attachment/Link Icon */}
                    <button 
                      onClick={handleAttachClick}
                      className="text-[#1e3a5f] hover:text-[#1e3a5f]/80 transition-colors"
                      title="Attach file"
                    >
                      <Link2 size={20} />
                    </button>
                    {/* Delete Icon with border */}
                    <button 
                      className="w-9 h-9 flex items-center justify-center text-gray hover:text-red hover:bg-gray rounded border border-gray transition-colors"
                      title="Delete"
                      onClick={handleDelete}
                    >
                      <Trash2 size={18} />
                    </button>
                    {/* Save Button */}
                    <button
                      onClick={handleSaveRemarks}
                      className="px-6 py-2 text-sm font-medium bg-[#1e3a5f] text-white rounded hover:bg-[#1e3a5f]/90 transition-colors"
                    >
                      Save
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Performance Tab */}
            <div className="bg-[#1e3a5f] text-white text-center py-2 rounded-t-lg">
              <span className="text-sm font-medium">Performance</span>
            </div>

            {/* Charts Container */}
            <div className="bg-white border border-gray border-t-0 rounded-b-lg p-4">
              {renderBarChart("absorptionRatio", "Absorption Ratio (%)", absorptionRatioData, "Absorption Ratio")}
              {renderBarChart("operatingMargin", "Operating Margin (%)", operatingMarginData, "Margin")}
              {renderBarChart("gearingRatio", "Gearing Ratio (%)", gearingRatioData, "Gearing Ratio")}
              {renderBarChart("interestCoverage", "Interest Coverage Ratio", interestCoverageData, "Coverage")}
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default DFHealthIndex;