import React, { useState } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft,ArrowUp,ArrowDown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
const  DFBalanceSheet = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
const [activeTab, setActiveTab] = useState("balance");
const [activeQuarter, setActiveQuarter] = useState("Q1");
const [activeMetric, setActiveMetric] = useState("assets");
const tableContainerRef = React.useRef(null);
  const handleback = () => {
    navigate("/dfhm/dealerfinacialratio");
  };
  const handleTabClick = (tab, path) => {
    setActiveTab(tab); // sets the active tab for styling
    navigate(path);    // navigates to the route
  };


const quarterMonths = {
  Q1: ["Jan", "Feb", "Mar"],
  Q2: ["Apr", "May", "Jun"],
  Q3: ["Jul", "Aug", "Sep"],
  Q4: ["Oct", "Nov", "Dec"],
};
const monthsForQuarter = quarterMonths[activeQuarter];

const financeDataByMetric = {
 assets: {
    Q1: [
      {
        category: "Current Assets",
        rows: [
      { 
        subCategory: "Cash & Cash Equivalents", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Deferred Taxes", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Other Current Assets", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Total Current Assets", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Assets", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Non- Current Assets",
        rows: [
      { 
        subCategory: "Property, Plan & Equipment (PPE)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Accumulated Depreciation", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Net Property, Plant & Equipment (PPE)", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Intangibles", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Other Non-Current Receivables", 
        
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } ,
      { 
        subCategory:"Total Non- Current Asset", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      ]
      },
     
        
    ],
     Q2:[
      {
        category: "Current Assets",
        rows: [
      { 
        subCategory: "Cash & Cash Equivalents", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Deferred Taxes", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Other Current Assets", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Total Current Assets", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Assets", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Non- Current Assets",
        rows: [
      { 
        subCategory: "Property, Plan & Equipment (PPE)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Accumulated Depreciation", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Net Property, Plant & Equipment (PPE)", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Intangibles", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Other Non-Current Receivables", 
        
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } ,
      { 
        subCategory:"Total Non- Current Asset", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      ]
      },
     
        
    ],
  Q3: [
      {
        category: "Current Assets",
        rows: [
      { 
        subCategory: "Cash & Cash Equivalents", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Deferred Taxes", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Other Current Assets", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Total Current Assets", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Assets", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Non- Current Assets",
        rows: [
      { 
        subCategory: "Property, Plan & Equipment (PPE)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Accumulated Depreciation", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Net Property, Plant & Equipment (PPE)", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Intangibles", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Other Non-Current Receivables", 
        
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } ,
      { 
        subCategory:"Total Non- Current Asset", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      ]
      },
     
        
    ],
  Q4: [
      {
        category: "Current Assets",
        rows: [
      { 
        subCategory: "Cash & Cash Equivalents", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Deferred Taxes", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Other Current Assets", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Total Current Assets", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Assets", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Non- Current Assets",
        rows: [
      { 
        subCategory: "Property, Plan & Equipment (PPE)", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Accumulated Depreciation", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Net Property, Plant & Equipment (PPE)", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Intangibles", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Other Non-Current Receivables", 
        
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } ,
      { 
        subCategory:"Total Non- Current Asset", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      ]
      },
     
        
    ]
  },
  liability: {
 Q1:[
      {
        category: "Current Liabilities",
        rows: [
      { 
        subCategory: "Trade Payables", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Sundry Payables", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Borrowings - 3rd parties", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      }, 
      { 
        subCategory: "Borrowings - Related parties", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      }, 
      { 
        subCategory:"Total Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Non-Current Liabilities",
        rows: [
      { 
        subCategory: "Borrowings - Banks", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Borrowings - 3rd parties", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Borrowings - Related parties", 
      
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Non-Current Liabilities", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      
      { 
        subCategory:"Total Non-Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      ]
      },     
    ],
        Q2: [
      {
        category: "Current Liabilities",
        rows: [
      { 
        subCategory: "Trade Payables", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Sundry Payables", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Borrowings - 3rd parties", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      }, 
      { 
        subCategory: "Borrowings - Related parties", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      }, 
      { 
        subCategory:"Total Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Non-Current Liabilities",
        rows: [
      { 
        subCategory: "Borrowings - Banks", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Borrowings - 3rd parties", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Borrowings - Related parties", 
      
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Non-Current Liabilities", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      
      { 
        subCategory:"Total Non-Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      ]
      },     
    ],
    Q3: [
      {
        category: "Current Liabilities",
        rows: [
      { 
        subCategory: "Trade Payables", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Sundry Payables", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Borrowings - 3rd parties", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      }, 
      { 
        subCategory: "Borrowings - Related parties", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      }, 
      { 
        subCategory:"Total Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Non-Current Liabilities",
        rows: [
      { 
        subCategory: "Borrowings - Banks", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Borrowings - 3rd parties", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Borrowings - Related parties", 
      
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Non-Current Liabilities", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      
      { 
        subCategory:"Total Non-Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      ]
      },     
    ],
    Q4: [
      {
        category: "Current Liabilities",
        rows: [
      { 
        subCategory: "Trade Payables", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Sundry Payables", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Borrowings - 3rd parties", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      }, 
      { 
        subCategory: "Borrowings - Related parties", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      }, 
      { 
        subCategory:"Total Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      { 
        subCategory:"Total Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
       {
        category: "Non-Current Liabilities",
        rows: [
      { 
        subCategory: "Borrowings - Banks", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Borrowings - 3rd parties", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Borrowings - Related parties", 
      
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      { 
        subCategory:"Other Non-Current Liabilities", 
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }    ,
      
      { 
        subCategory:"Total Non-Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      }
      ]
      },     
    ]
  },
  inventories: {
    Q1:  [
      {
        category: "Machines Inventories",
        rows: [
      { 
        subCategory: "Inventories - Machines", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Obsolescence Prov. - Machines", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Total Net Inventories - Machines", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    
      
     
      ]
      },
       {
        category: "Parts Inventories",
        rows: [
      { 
        subCategory: "Inventories - Parts", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Obsolescence Prov. - Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Net Inventories - Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ],
    Q2: [
      {
        category: "Machines Inventories",
        rows: [
      { 
        subCategory: "Inventories - Machines", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Obsolescence Prov. - Machines", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Total Net Inventories - Machines", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    
      
     
      ]
      },
       {
        category: "Parts Inventories",
        rows: [
      { 
        subCategory: "Inventories - Parts", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Obsolescence Prov. - Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Net Inventories - Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ],
    Q3: [
      {
        category: "Machines Inventories",
        rows: [
      { 
        subCategory: "Inventories - Machines", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Obsolescence Prov. - Machines", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Total Net Inventories - Machines", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    
      
     
      ]
      },
       {
        category: "Parts Inventories",
        rows: [
      { 
        subCategory: "Inventories - Parts", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Obsolescence Prov. - Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Net Inventories - Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ],
    Q4:[
      {
        category: "Machines Inventories",
        rows: [
      { 
        subCategory: "Inventories - Machines", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Obsolescence Prov. - Machines", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Total Net Inventories - Machines", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    
      
     
      ]
      },
       {
        category: "Parts Inventories",
        rows: [
      { 
        subCategory: "Inventories - Parts", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Obsolescence Prov. - Parts", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Net Inventories - Parts", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ]
  },
  trade:{
    Q1: [
      {
        category: "Machines Receivables",
        rows: [
      { 
        subCategory: "Trade Receivables - Machines", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Doubtful Debts Prov - Machines (enter - )", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Bank Account", 
       
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    { 
        subCategory: "Total Net Trade Receivables - Machines", 
       isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      
     
      ]
      },
       {
        category: "Aftermarket Receivables",
        rows: [
      { 
        subCategory: "Trade Receivables - Aftermarket", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Doubtful Debts Prov. - Aftermarket", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Non-Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ],
    Q2:[
      {
        category: "Machines Receivables",
        rows: [
      { 
        subCategory: "Trade Receivables - Machines", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Doubtful Debts Prov - Machines (enter - )", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Bank Account", 
       
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    { 
        subCategory: "Total Net Trade Receivables - Machines", 
       isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      
     
      ]
      },
       {
        category: "Aftermarket Receivables",
        rows: [
      { 
        subCategory: "Trade Receivables - Aftermarket", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Doubtful Debts Prov. - Aftermarket", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Non-Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ],
    Q3: [
      {
        category: "Machines Receivables",
        rows: [
      { 
        subCategory: "Trade Receivables - Machines", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Doubtful Debts Prov - Machines (enter - )", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Bank Account", 
       
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    { 
        subCategory: "Total Net Trade Receivables - Machines", 
       isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      
     
      ]
      },
       {
        category: "Aftermarket Receivables",
        rows: [
      { 
        subCategory: "Trade Receivables - Aftermarket", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Doubtful Debts Prov. - Aftermarket", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Non-Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ],
    Q4: [
      {
        category: "Machines Receivables",
        rows: [
      { 
        subCategory: "Trade Receivables - Machines", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Doubtful Debts Prov - Machines (enter - )", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Bank Account", 
       
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    { 
        subCategory: "Total Net Trade Receivables - Machines", 
       isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      
     
      ]
      },
       {
        category: "Aftermarket Receivables",
        rows: [
      { 
        subCategory: "Trade Receivables - Aftermarket", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Less: Doubtful Debts Prov. - Aftermarket", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 
       
      { 
        subCategory:"Total Non-Current Liabilities", 
        isTotal:true,
        values: { 
          Jan: "2,34,46,167", Feb: "4,99,91,428", Mar: "1,87,95,479", Q1: "81,22,33,169",
          YTD: "67,90,286", BP: "67,90,2858", VSBP: "88,50,29", VBPM: "83,96,289", runRate: "86,98,289"
        } 
      } 
      ]
      },
    ]  
  },
  equity:{
    Q1: [
      {
        category: "Total Equity",
        rows: [
      { 
        subCategory: "Share Capital", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Reserves & Surplus", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Retained Earnings", 
       
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    { 
        subCategory: "Total Equity", 
       isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      
     
      ]
      },
      {
        category: "Check",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
          
      
    ],
    Q2:  [
      {
        category: "Total Equity",
        rows: [
      { 
        subCategory: "Share Capital", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Reserves & Surplus", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Retained Earnings", 
       
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    { 
        subCategory: "Total Equity", 
       isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      
     
      ]
      },
      {
        category: "Check",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
          
      
    ],
    Q3:  [
      {
        category: "Total Equity",
        rows: [
      { 
        subCategory: "Share Capital", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Reserves & Surplus", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Retained Earnings", 
       
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    { 
        subCategory: "Total Equity", 
       isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      
     
      ]
      },
      {
        category: "Check",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
          
      
    ],
    Q4:  [
      {
        category: "Total Equity",
        rows: [
      { 
        subCategory: "Share Capital", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
      
 { 
        subCategory: "Reserves & Surplus", 
        values: { 
          Jan: "2,34,46,17", Feb: "4,99,91,", Mar: "3,87,95,679", Q1: "11,2,13,169",
          YTD: "847,940,289", BP: "87,890,289", VSBP: "80,90,289", VBPM:"87,90,28", runRate: "87,96,289"
        } 
      },        
 { 
        subCategory: "Retained Earnings", 
       
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
    { 
        subCategory: "Total Equity", 
       isTotal:true,
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "1,87,95,579", Q1: "51,22,33,169",
          YTD: "87,90,280", BP: "87,90,2858", VSBP: "87,50,29", VBPM: "87,96,289", runRate: "87,98,289"
        } 
      },  
      
     
      ]
      },
      {
        category: "Check",
        isTotalRow:true,
        rows: [
      { 
        subCategory: "", 
        values: { 
          Jan: "2,34,46,166", Feb: "4,99,91,424", Mar: "3,87,95,579", Q1: "11,22,33,169",
          YTD: "87,90,289", BP: "87,90,289", VSBP: "87,90,289", VBPM: "87,90,289", runRate: "87,90,289"
        } 
      },
        ]},
          
      
    ]  
  }
};
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


// Helper function to get data based on tab, quarter, metric
const getFinanceData = (tab, quarter, metric) => {
  // Currently we only have revenue, profit, expense
  if (metric === "viewall") {
    // Merge all metrics for viewall
    const allMetrics = ["assets", "liability", "inventories","trade", "equity"];
    const merged = [];
    allMetrics.forEach((m) => {
      const data = financeDataByMetric[m]?.[quarter] || [];
      data.forEach((section) => {
        // Check if already exists to avoid duplicates
        const existing = merged.find((s) => s.category === section.category);
        if (!existing) {
          merged.push(section);
        }
      });
    });
    return merged;
  }

  return financeDataByMetric[metric]?.[quarter] || [];
};
const [tableDataDynamic, setTableDataDynamic] = useState(
  getFinanceData(activeTab, activeQuarter, activeMetric)
);

// Update table whenever tab, quarter, or metric changes
React.useEffect(() => {
  const data = getFinanceData(activeTab, activeQuarter, activeMetric);
  setTableDataDynamic(data);
}, [activeTab, activeQuarter, activeMetric]);

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      {/* Header */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      {/* SubNavbar */}
      <SubNavbar3 />

      {/* MAIN CONTENT */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">

          {/* -------- TOP ROW -------- */}
          <div className="w-full relative flex items-center justify-between">

            {/* LEFT : Arrow + Heading */}
           <div className="flex items-center gap-2">
                       <ArrowLeft
                         size={24}
                         onClick={handleback}
                         className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
                       />
                       <h1 className="text-base font-semibold text-darkblue1">
                         DFHM/ Financial Ratio
                       </h1>
                     </div>
         
                     {/* CENTER : Disclaimer */}
                     <div className="absolute left-1/2 -translate-x-1/2">
                       <p className="text-[10px] text-red1 font-medium whitespace-nowrap">
                         Disclaimer : This data is for internal review to determine
                         improvement areas within dealerships
                       </p>
                     </div>
         
                     {/* RIGHT : Amount + Download */}
                    <div className="flex items-center gap-4">
         
         
           {/* Button 1 */}
          <button  onClick={() => navigate("/dfhm/dealerfinacialratio/ratiochart")} className="px-3 py-1 text-xs font-medium bg-darkblue1 text-white hover:text-darkblue1 hover:bg-white hover:border hover:border-darkblue1 flex items-center gap-1">
         
           {/* Search Icon */}
           <svg
             className="w-4 h-4 stroke-current"   // << this makes icon match text color
             fill="none"
             viewBox="0 0 24 24"
             strokeWidth="2"
           >
             <path
               strokeLinecap="round"
               strokeLinejoin="round"
               d="M21 21l-4.35-4.35M10 18a8 8 0 100-16 8 8 0 000 16z"
             />
           </svg>
         
           Ratio chart
         </button>
         
           {/* Button 2 */}
           <button  onClick={() => navigate("/dfhm/dealerfinacialratio/healthindex")} className="px-3 py-1 text-xs font-medium bg-darkblue1 text-white hover:text-darkblue1 hover:bg-white hover:border hover:border-darkblue1 ">
           Health Index
           </button>
         </div>
         </div>

          {/* Blue underline */}
          <hr className="hidden lg:block w-[7%] border-t-4 border-darkblue1 ml-[34px] mb-2" />

          {/* -------- FOUR BUTTON ROW -------- */}
     <div
      className="w-full grid grid-cols-5 divide-x divide-black/30 border border-black/30 overflow-hidden mb-2"
    >
      {/* Profit & Loss */}
      <button
        onClick={() => handleTabClick("profit","/dfhm/dealerfinacialratio/viewdetails" )}
        className={`py-1.5 font-medium transition text-xs
          ${activeTab === "profit"
            ? "bg-DustyBlue1 text-white"
            : "bg-white text-black"
          }`}
      >
        Profit & Loss
      </button>

      {/* Balance Sheet */}
      <button
        // onClick={() => handleTabClick("balance", "/balance")}
        className={`py-1 font-medium transition text-xs
          ${activeTab === "balance"
            ? "bg-DustyBlue1 text-white"
            : "bg-white text-black"
          }`}
      >
        Balance Sheet
      </button>

      {/* Headcount */}
      <button
        onClick={() => handleTabClick("headcount", "/dfhm/dealerfinacialratio/dfheadcount")}
        className={`py-1 font-medium transition text-xs
          ${activeTab === "headcount"
            ? "bg-DustyBlue1 text-white"
            : "bg-white text-black"
          }`}
      >
        Headcount
      </button>

      {/* AR Aging */}
      <button
        onClick={() => handleTabClick("ar","/dfhm/dealerfinacialratio/dfaraging" )}
        className={`py-1 font-medium transition text-xs
          ${activeTab === "ar"
            ? "bg-DustyBlue1 text-white"
            : "bg-white text-black"
          }`}
      >
        AR Aging
      </button>
      <button
        onClick={() => handleTabClick("ratioanalysis", "/dfhm/dealerfinacialratio/rationanalysis" )}
        className={`py-1 font-medium transition text-xs
          ${activeTab === "ratioanalysis"
            ? "bg-DustyBlue1 text-white"
            : "bg-white text-black"
          }`}
      >
       Ratio Analysis
      </button>
    </div>
<div className=" w-full flex items-center justify-between mb-2">

  {/* LEFT — QUARTER BUTTONS */}
  <div className="grid grid-cols-4 divide-x divide-darkblue1 border border-darkblue1 overflow-hidden">
    {["Q1", "Q2", "Q3", "Q4"].map((q) => (
      <button
        key={q}
        onClick={() => setActiveQuarter(q)}
        className={`py-1 px-10 font-medium transition text-xs text-medium
          ${activeQuarter === q
            ? "bg-darkblue1 text-white"
            : "bg-white text-darkblue1 hover:bg-darkblue1 hover:text-white"
          }`}
      >
        {q}
      </button>
    ))}
  </div>

  {/* RIGHT — METRIC BUTTONS */}
  <div className="grid grid-cols-6 divide-x divide-darkblue1 border border-darkblue1 overflow-hidden ">
    {[
      { id: "assets", label: "Assets" },
      { id: "liability", label: "Liabilities" },
      { id: "inventories", label: "Inventories" },
            { id: "trade", label: "Trade Receivables" },
      { id: "equity", label: "Equity" },

            { id: "viewall", label: "View All" },

    ].map((m) => (
      <button
        key={m.id}
        onClick={() => setActiveMetric(m.id)}
        className={`py-1 px-5 font-medium transition text-xs text-medium
          ${activeMetric === m.id
            ? "bg-darkblue1 text-white"
            : "bg-white text-darkblue1 hover:bg-darkblue1 hover:text-white"
          }`}
      >
        {m.label}
      </button>
    ))}
  </div>

</div>


<div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
<div
              ref={tableContainerRef}
              className="
    w-full 
    overflow-y-auto 
    overflow-x-hidden

 
      lg:max-h-[60vh] 
      xl:max-h-[58vh] 
      2xl:max-h-[65vh]
  "
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                onScroll={handleTableScroll}

            > 
<table className="w-full table-fixed text-xs cursor-pointer">   
               <thead className="bg-Dustyblue text-white font-normal text-left sticky top-0 z-10">
    {/* First row: main headers */}
    <tr>
      <th className="py-2 px-2 border border-grey2 border-t-0 border-l-0 font-normal w-[10%]" rowSpan={2}>Category</th>
      <th className="py-2 px-2 border border-grey2 border-t-0 font-normal w-[10%]" rowSpan={2}>Sub Category</th>

      {/* Monthly group */}
      <th className="py-2 px-2 border border-grey2 text-center border-t-0 font-normal w-[40%]" colSpan={4}>Monthly Breakdown</th>

      {/* Business Plan Comparison group */}
      <th className="py-2 px-2 border border-grey2 text-center border-t-0 border-r-0 font-normal w-[50%]" colSpan={5}>Business Plan Comparison</th>
    </tr>

    {/* Second row: sub-columns */} 
    <tr>
    {monthsForQuarter.map((m) => (
      <th key={m} className="py-2 px-2 border border-grey2 font-normal text-center">{m}</th>
    ))}
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">Q{activeQuarter[1]}</th> 
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">YTD</th>
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">Business Plan</th>
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">Vs. BP (YTD-BP)</th>
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center">VBPM</th>
    <th className="py-2 px-2 border border-grey2 font-normal w-[10%] text-center border-r-0">Run-Rate% (YTD/BP)</th>
  </tr>
  </thead>

 <tbody>
{tableDataDynamic.map((section, idx) => (
    
       section.rows.map((row, rIdx) => {
        const isGrandTotal = section.isTotalRow;
        const isSingleRowCategory = 
          section.category === "Other" || isGrandTotal;

        // Collect all cells
        const cells = [];

        // Category + Sub Category merged for Other / Totals
        if (isSingleRowCategory && rIdx === 0) {
          cells.push(
            <td
              key="category"
              colSpan={2}
              className="py-2 px-2 border border-grey2 font-semibold"
            >
              {section.category}
            </td>
          );
        }

        // Normal category
        if (!isSingleRowCategory && rIdx === 0) {
          cells.push(
            <td
              key="category"
              rowSpan={section.rows.length}
              className="py-1 px-2 border border-grey2 font-normal"
            >
              {section.category}
            </td>
          );
        }

        // Sub Category for normal rows
        if (!isSingleRowCategory) {
          cells.push(
            <td key="subcat" className="py-1 px-2 border border-grey2">
              {row.subCategory}
            </td>
          );
        }

        // All value cells
        Object.values(row.values).forEach((val, i) => {
          cells.push(
            <td key={i} className="py-1 px-2 border border-grey2 text-center text-xs">
              {val}
            </td>
          );
        });

        // Apply border-l-0 to first cell and border-r-0 to last cell
        if (cells.length > 0) {
          cells[0] = React.cloneElement(cells[0], {
            className: `${cells[0].props.className} border-l-0`,
          });
          cells[cells.length - 1] = React.cloneElement(cells[cells.length - 1], {
            className: `${cells[cells.length - 1].props.className} border-r-0`,
          });
        }

        return (
          <tr
            key={rIdx}
            className={row.isTotal || isGrandTotal ? "bg-gery1 font-bold" : "bg-white hover:bg-lightBlue/50"}
          >
            {cells}
          </tr>
        );
      })
    
  ))}
</tbody>
</table></div>
 {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}


        </div>
      </div>
    </div>
    </div>
  );
};

export default DFBalanceSheet;
