import React, { useState, useEffect, useRef } from "react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import { ArrowLeft,ChevronDown ,ChevronUp,ChevronsUpDown,ArrowUp,ArrowDown  } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import { useMemo } from "react";

// Import service functions
import {
  quarterMonthsMap,
  parseNumericValue,
  formatIndianNumber,
  calculateDerivedValues,
  getDfhmHcByDfhmId,
  getDfhmHcByFilters,
  updateMultipleDfhmHc,
  transformHcDataForTable,
  transformHcDataForApi,
} from "../../../../services/dfhm/dfhmFillEntries.service";

const FillEntryHeadCount = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { rowData, mode } = location.state || {};

  // Mode flags
  const isViewMode = mode === "view";
  const isFillMode = mode === "fill";
  const [fillTableMode, setFillTableMode] = useState("edit"); // "edit" = editable, "view" = read-only
  const showInputs = isFillMode && fillTableMode === "edit";

  // UI state
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("headcount");
  const [activeQuarter, setActiveQuarter] = useState(rowData?.quarter || "Q1");
  const tableContainerRef = useRef(null);

  // Data state
  const [tableDataDynamic, setTableDataDynamic] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);

  // Extract DFHM ID and other params
  const dfhmId = rowData?.id || null;
  const year = rowData?.year || null;
  const dealerId = rowData?.dealerId || null;
  const dealerName = rowData?.dealer || rowData?.dealerName || "";

  // Get months for current quarter
  const monthsForQuarter = quarterMonthsMap[activeQuarter] || ["Jan", "Feb", "Mar"];
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return tableDataDynamic;

  return [...tableDataDynamic].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [tableDataDynamic, sortKey, sortOrder]);
 // ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  // ============================================
  // NAVIGATION
  // ============================================
  const handleback = () => {
    navigate("/dfhm/viewdfhm");
  };

  const handleTabClick = (tab, path) => {
    setActiveTab(tab);
    navigate(path, {
      state: {
        ...location.state,
      },
    });
  };

  // ============================================
  // FETCH DATA
  // ============================================
  const fetchHcData = async () => {
    setLoading(true);
    setError(null);

    try {
      let response;

      // Try filter-based fetch first if we have year and dealerId
      if (year && dealerId) {
        response = await getDfhmHcByFilters({
          quarter: activeQuarter,
          year: year,
          dealerId: dealerId,
        });
      } else if (dfhmId) {
        // Fallback to dfhmId-based fetch
        response = await getDfhmHcByDfhmId(dfhmId);
      } else {
        throw new Error("No DFHM ID or filter parameters available");
      }

      if (response?.status && response?.data) {
        // Filter data for current quarter if using dfhmId fetch
        let filteredData = response.data;
        if (!year && dfhmId) {
          filteredData = response.data.filter(
            (item) => item.quarter === activeQuarter
          );
        }

        // Transform API data to table format
        const transformedData = transformHcDataForTable(filteredData, activeQuarter);
        setTableDataDynamic(transformedData);
      } else {
        setTableDataDynamic([]);
      }
    } catch (err) {
      console.error("Error fetching Head Count data:", err);
      setError(err.message || "Failed to fetch Head Count data");
      setTableDataDynamic([]);
    } finally {
      setLoading(false);
    }
  };

  // Fetch data on mount and when quarter changes
  useEffect(() => {
    fetchHcData();
  }, [dfhmId, activeQuarter, year, dealerId]);

  // ============================================
  // CALCULATE TOTALS
  // ============================================
  const calculateAllTotals = (data) => {
    const updatedData = JSON.parse(JSON.stringify(data));

    // 1. Recalculate category totals
    updatedData.forEach((section) => {
      const totalRow = section.rows.find((r) => r.isTotal || r.isCalculatedTotal);
      if (totalRow) {
        const dataRows = section.rows.filter((r) => !r.isTotal && !r.isCalculatedTotal);

        Object.keys(totalRow.values).forEach((key) => {
          if (!["VSBP", "VBPM", "runRate"].includes(key)) {
            totalRow.values[key] = dataRows.reduce((sum, r) => {
              return sum + parseNumericValue(r.values[key]);
            }, 0);
          }
        });

        // Recalculate derived values for total row
        const derived = calculateDerivedValues(
          totalRow.values[monthsForQuarter[0]],
          totalRow.values[monthsForQuarter[1]],
          totalRow.values[monthsForQuarter[2]],
          totalRow.values.YTD,
          totalRow.values.BP
        );
        totalRow.values.Q1 = derived.quarterTotal;
        totalRow.values.VSBP = derived.vsBP;
        totalRow.values.VBPM = derived.vbpm;
        totalRow.values.runRate = derived.runRate;
      }
    });

    // 2. Calculate Grand Total (sections with isTotalRow: true)
    const grandSections = updatedData.filter((sec) => sec.isTotalRow === true);
    grandSections.forEach((grandSection) => {
      const grandRow = grandSection.rows[0];
      if (grandRow) {
        Object.keys(grandRow.values).forEach((key) => {
          if (!["VSBP", "VBPM", "runRate"].includes(key)) {
            let total = 0;
            updatedData.forEach((section) => {
              if (!section.isTotalRow) {
                const catTotalRow = section.rows.find((r) => r.isTotal || r.isCalculatedTotal);
                if (catTotalRow) {
                  total += parseNumericValue(catTotalRow.values[key]);
                }
              }
            });
            grandRow.values[key] = total;
          }
        });

        // Recalculate derived values for grand total
        const derived = calculateDerivedValues(
          grandRow.values[monthsForQuarter[0]],
          grandRow.values[monthsForQuarter[1]],
          grandRow.values[monthsForQuarter[2]],
          grandRow.values.YTD,
          grandRow.values.BP
        );
        grandRow.values.Q1 = derived.quarterTotal;
        grandRow.values.VSBP = derived.vsBP;
        grandRow.values.VBPM = derived.vbpm;
        grandRow.values.runRate = derived.runRate;
      }
    });

    return updatedData;
  };

  // ============================================
  // HANDLE VALUE CHANGE
  // ============================================
  const handleValueChange = (sectionIndex, rowIndex, field, newValue) => {
    setTableDataDynamic((prev) => {
      const updated = JSON.parse(JSON.stringify(prev));
      const row = updated[sectionIndex].rows[rowIndex];

      // Update the changed field
      row.values[field] = parseNumericValue(newValue);

      // Recalculate Q1 (sum of 3 months) if a month was changed
      if (monthsForQuarter.includes(field)) {
        const m1 = parseNumericValue(row.values[monthsForQuarter[0]]);
        const m2 = parseNumericValue(row.values[monthsForQuarter[1]]);
        const m3 = parseNumericValue(row.values[monthsForQuarter[2]]);
        row.values.Q1 = m1 + m2 + m3;
      }

      // Recalculate derived values for this row
      const derived = calculateDerivedValues(
        row.values[monthsForQuarter[0]],
        row.values[monthsForQuarter[1]],
        row.values[monthsForQuarter[2]],
        row.values.YTD,
        row.values.BP
      );
      row.values.VSBP = derived.vsBP;
      row.values.VBPM = derived.vbpm;
      row.values.runRate = derived.runRate;

      // Recalculate all totals
      return calculateAllTotals(updated);
    });
  };

  // ============================================
  // SAVE DATA
  // ============================================
  const handleSave = async () => {
    setSaving(true);
    try {
      const apiData = transformHcDataForApi(tableDataDynamic, activeQuarter);

      if (apiData.length === 0) {
        toast.warning("No data to save");
        setSaving(false);
        return;
      }

      const response = await updateMultipleDfhmHc(apiData);

      if (response?.status) {
        toast.success("Head Count data saved successfully!");
        setFillTableMode("view");
      } else {
        toast.error(response?.message || "Failed to save data");
      }
    } catch (err) {
      console.error("Error saving Head Count data:", err);
      toast.error("Failed to save Head Count data");
    } finally {
      setSaving(false);
    }
  };

  // ============================================
  // FORMAT DISPLAY VALUE
  // ============================================
  const formatDisplayValue = (value, key) => {
    if (value === null || value === undefined || value === "") return "0";

    const numVal = parseNumericValue(value);

    // For percentage fields
    if (key === "VBPM" || key === "runRate") {
      return `${numVal}%`;
    }

    // For Head Count, just show numbers (no Indian formatting needed)
    return numVal;
  };

  // ============================================
  // RENDER
  // ============================================

  // Loading state
  if (loading) {
    return (
      <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        <SubNavbar3 />
        <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center items-center flex-1`}>
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-darkblue1 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading Head Count data...</p>
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        <SubNavbar3 />
        <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center items-center flex-1`}>
          <div className="text-center">
            <p className="text-red-600 mb-4">{error}</p>
            <button
              onClick={fetchHcData}
              className="px-4 py-2 bg-darkblue1 text-white rounded hover:bg-blue-700"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      {/* Header */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      {/* SubNavbar */}
      <SubNavbar3 />

      {/* MAIN CONTENT */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* -------- TOP ROW -------- */}
          <div className="w-full relative flex items-center justify-between">
            {/* LEFT : Arrow + Heading */}
            <div className="flex items-center gap-2">
              <ArrowLeft
                size={24}
                onClick={handleback}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              />
              <h1 className="text-base font-semibold text-darkblue1">
                DFHM / {isViewMode ? "View DFHM" : "Fill Entries"} - Head Count - {dealerName}
              </h1>
            </div>

            {/* CENTER : Disclaimer */}
            <div className="absolute left-1/2 -translate-x-1/2">
              <p className="text-[10px] text-red1 font-medium whitespace-nowrap">
                Disclaimer : This data is for internal review to determine
                improvement areas within dealerships
              </p>
            </div>

            {/* RIGHT : Year & Quarter info */}
            <div className="flex items-center gap-4">
              <p className="text-xs text-black font-semibold whitespace-nowrap">
                Year: <span className="font-normal text-SteelBlue1">{year}</span>
                {" | "}
                Quarter: <span className="font-normal text-SteelBlue1">{activeQuarter}</span>
              </p>
            </div>
          </div>

          {/* Blue underline */}
          <hr className="hidden lg:block w-[7%] border-t-4 border-darkblue1 ml-[34px] mb-2" />

          {/* -------- FOUR BUTTON ROW -------- */}
          <div className="w-full grid grid-cols-4 divide-x divide-black/30 border border-black/30 overflow-hidden mb-2">
            <button
              onClick={() => handleTabClick("profit", "/dfhm/viewdfhm/fillentries")}
              className={`py-1.5 font-medium transition text-xs
                ${activeTab === "profit" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              Profit & Loss
            </button>
            <button
              onClick={() => handleTabClick("balance", "/dfhm/viewdfhm/fillentries/balance")}
              className={`py-1 font-medium transition text-xs
                ${activeTab === "balance" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              Balance Sheet
            </button>
            <button
              className={`py-1 font-medium transition text-xs
                ${activeTab === "headcount" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              Headcount
            </button>
            <button
              onClick={() => handleTabClick("ar", "/dfhm/viewdfhm/fillentries/Araging")}
              className={`py-1 font-medium transition text-xs
                ${activeTab === "ar" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              AR Aging
            </button>
          </div>

          {/* -------- QUARTER BUTTONS -------- */}
          <div className="w-full flex items-center justify-between mb-2">
            {/* LEFT — QUARTER BUTTONS */}
            <div className="grid grid-cols-4 divide-x divide-darkblue1 border border-darkblue1 overflow-hidden">
              {["Q1", "Q2", "Q3", "Q4"].map((q) => (
                <button
                  key={q}
                  onClick={() => setActiveQuarter(q)}
                  className={`py-1 px-10 font-medium transition text-xs
                    ${activeQuarter === q
                      ? "bg-darkblue1 text-white"
                      : "bg-white text-darkblue1 hover:bg-darkblue1 hover:text-white"
                    }`}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* -------- TABLE -------- */}
          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
            <div
              ref={tableContainerRef}
              className="w-full overflow-y-auto overflow-x-hidden lg:max-h-[55vh] xl:max-h-[58vh] 2xl:max-h-[65vh]"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                onScroll={handleTableScroll}

            >
<table className="w-full table-fixed text-xs cursor-pointer">                <thead className="bg-Dustyblue text-white font-normal text-left sticky top-0 z-10">
                  <tr>
                      <th
      rowSpan={2}
      onClick={() => handleSort("category")}
      className="py-2 px-2 border border-grey2 border-t-0 border-l-0 font-normal w-[7%] cursor-pointer select-none"
    >
      <div className="flex items-center gap-1">
        Category
        {sortKey !== "category" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
        {sortKey === "category" && sortOrder === "asc" && (
          <ChevronUp className="w-3 h-3 text-white" />
        )}
        {sortKey === "category" && sortOrder === "desc" && (
          <ChevronDown className="w-3 h-3 text-white" />
        )}
      </div>
    </th>
                    <th className="py-2 px-2 border border-grey2 border-t-0 font-normal w-[10%]" rowSpan={2}>
                      Sub Category
                    </th>
                    <th className="py-2 px-2 border border-grey2 text-center font-normal border-t-0 w-[40%]" colSpan={4}>
                      Monthly Breakdown
                    </th>
                    <th className="py-2 px-2 border border-grey2 text-center font-normal border-t-0 border-r-0 w-[50%]" colSpan={5}>
                      Business Plan Comparison
                    </th>
                  </tr>
                  <tr>
                    {monthsForQuarter.map((m) => (
                      <th key={m} className="py-2 px-2 border border-grey2 font-normal text-center">
                        {m}
                      </th>
                    ))}
                    <th className="py-2 px-2 border border-grey2 text-center w-[10%] font-normal">Q{activeQuarter[1]}</th>
                    <th className="py-2 px-2 border border-grey2 text-center w-[10%]  font-normal">YTD</th>
                    <th className="py-2 px-2 border border-grey2 text-center w-[10%] font-normal">Business Plan</th>
                    <th className="py-2 px-2 border border-grey2 text-center w-[10%] font-normal">Vs. BP (YTD-BP)</th>
                    <th className="py-2 px-2 border border-grey2 text-center w-[10%] font-normal">VBPM</th>
                    <th className="py-2 px-2 border border-grey2 text-center w-[10%] font-normal border-r-0">Run-Rate% (YTD/BP)</th>
                  </tr>
                </thead>

                <tbody>
                  {sortedData.length === 0 ? (
                    <tr>
                      <td colSpan={11} className="py-8 text-center text-gray-500">
                        No Head Count data available for this quarter
                      </td>
                    </tr>
                  ) : (
                    sortedData.map((section, sectionIdx) => (
                      <React.Fragment key={sectionIdx}>
                        {section.rows.map((row, rowIdx) => {
                          const isGrandTotalSection = section.isTotalRow;
                          const isTotalRow = row.isTotal || row.isCalculatedTotal;

                          const isSingleRowCategory =
                            (section.category === "Others" && section.rows.length === 1) ||
                            isGrandTotalSection;

                          const totalRowSpan = section.rows.length;

                          const cells = [];

                          // Category cell
                          if (isSingleRowCategory && rowIdx === 0) {
                            cells.push(
                              <td
                                key="category"
                                colSpan={2}
                                className={`py-2 px-2 border border-grey2 border-l-0 font-semibold ${
                                  isGrandTotalSection ? "bg-gray-200" : ""
                                }`}
                              >
                                {section.category}
                              </td>
                            );
                          } else if (!isSingleRowCategory && rowIdx === 0) {
                            cells.push(
                              <td
                                key="category"
                                rowSpan={totalRowSpan}
                                className="py-1 px-2 border border-grey2 border-l-0 font-medium align-top"
                              >
                                {section.category}
                              </td>
                            );
                          }

                          // SubCategory cell
                          if (!isSingleRowCategory) {
                            cells.push(
                              <td
                                key="subcat"
                                className={`py-1 px-2 border border-grey2  ${
                                  isTotalRow ? "font-semibold bg-gray-100" : ""
                                }`}
                              >
                                {row.subCategory}
                              </td>
                            );
                          }

                          // Value cells
                          const valueKeys = [
                            monthsForQuarter[0],
                            monthsForQuarter[1],
                            monthsForQuarter[2],
                            "Q1",
                            "YTD",
                            "BP",
                            "VSBP",
                            "VBPM",
                            "runRate",
                          ];

                          valueKeys.forEach((key, i) => {
                            const val = row.values[key];
                            const isEditable =
                              showInputs &&
                              !isTotalRow &&
                              !isGrandTotalSection &&
                              !["Q1", "VSBP", "VBPM", "runRate"].includes(key);
                            const isNegative = key === "VSBP" && parseNumericValue(val) < 0;

                            cells.push(
                              <td
                                key={i}
                                className={`py-1 px-2 border border-grey2 text-center text-xs ${
                                  isNegative ? "text-red-600" : ""
                                } ${isTotalRow || isGrandTotalSection ? "bg-gray-100 font-semibold" : ""}`}
                              >
                                {isEditable ? (
                                  <input
                                    type="number"
                                    value={val || ""}
                                    onChange={(e) => {
                                      handleValueChange(sectionIdx, rowIdx, key, e.target.value);
                                    }}
                                    className="w-full bg-white text-center border border-grey2 px-1 py-0.5 text-xs focus:outline-none focus:border-darkblue1"
                                    disabled={saving}
                                  />
                                ) : (
                                  formatDisplayValue(val, key)
                                )}
                              </td>
                            );
                          });

                          return (
                            <tr
                              key={rowIdx}
                              className={
                                isTotalRow || isGrandTotalSection
                                  ? "bg-gray-100"
                                  : "bg-white hover:bg-lightBlue/50"
                              }
                            >
                              {cells}
                            </tr>
                          );
                        })}
                      </React.Fragment>
                    ))
                  )}
                </tbody>
              </table>
            </div>
              {showScrollButtons && (
            <div className="fixed bottom-16 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}


          </div>

          {/* -------- ACTION BUTTONS -------- */}
          {isFillMode && (
            <div className="flex justify-end mt-4 gap-2">
              {fillTableMode === "edit" && (
                <button
                  className="px-4 py-1 font-medium bg-darkblue1 text-xs text-white hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50"
                  onClick={handleSave}
                  disabled={saving}
                >
                  {saving ? "Saving..." : "Save & View"}
                </button>
              )}

              {fillTableMode === "view" && (
                <>
                  <button
                    className="px-4 py-1 font-medium bg-darkblue1 text-xs text-white hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition"
                    onClick={() => setFillTableMode("edit")}
                  >
                    Edit
                  </button>
                  <button
                    className="px-4 py-1 font-medium bg-darkblue1 text-xs text-white hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition"
                    onClick={() => navigate("/dfhm/viewdfhm")}
                  >
                    Submit
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FillEntryHeadCount;