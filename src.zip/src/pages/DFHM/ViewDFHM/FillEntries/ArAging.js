import React, { useState, useEffect, useRef } from "react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import { ArrowLeft } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import StyledSelectField from "../../../../Components/StyledSelectField";

// Import service functions
import {
  getDfhmAgingByFilters,
  getDfhmAgingByDfhmId,
  addDfhmAging,
  updateMultipleDfhmAging,
  deleteDfhmAging,
  transformAgingDataForTableGrouped,
  transformAgingGroupedDataForApi,
  parseNumericValue,
} from "../../../../services/dfhm/dfhmFillEntries.service";

const ArAging = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { rowData, mode } = location.state || {};

  const isViewMode = mode === "view";
  const isFillMode = mode === "fill";
  const [fillTableMode, setFillTableMode] = useState("edit");
  const showInputs = isFillMode && fillTableMode === "edit";

  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("ar");
  const [activeQuarter, setActiveQuarter] = useState("Q1");

  const tableContainerRef = useRef(null);
  const [tableDataDynamic, setTableDataDynamic] = useState([]);
  
  // Loading and error states
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  
  // Store dfhm_id separately (persists across quarter switches)
  const [dfhmId, setDfhmId] = useState(rowData?.dfhmId || rowData?.id || null);

  // Dealer name for header (prefer short name)
  const dealerName = rowData?.dealer || rowData?.dealerName || rowData?.dealer_short_name || rowData?.dealerShortName || "";

  // Add Customer Modal
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [addingCustomer, setAddingCustomer] = useState(false);

  const typeOptions = [
    { label: "Equipment Customer", value: "Equipment" },
    { label: "Parts Customer", value: "Parts" },
  ];

  const [form, setForm] = useState({
    type: "",
    customerName: "",
  });

  const [errors, setErrors] = useState({
    type: "",
    customerName: "",
  });

  const [dropdowns, setDropdowns] = useState({
    type: false,
  });

  const refs = {
    type: useRef(null),
  };

  // Import Modal
  const [showimportPopup, setShowimportPopup] = useState(false);
  const [formData, setFormData] = useState({ file: "", fileObject: null });
  const fileInputRef = useRef(null);

  // Delete confirmation
  const [deleteConfirm, setDeleteConfirm] = useState({ show: false, row: null, sectionIdx: null, rowIdx: null });
  const [deleting, setDeleting] = useState(false);

  // ============================================
  // FETCH DATA FROM API
  // ============================================
  const fetchData = async (quarterOverride = null) => {
    const quarterToFetch = quarterOverride || activeQuarter;
    
    setLoading(true);
    setError(null);

    console.log("Fetching AR Aging data for quarter:", quarterToFetch);

    try {
      let response;

      // Use filters if year and dealerId are available
      // NOTE: Do NOT pass quarter to API - backend filters by dfhm.quarter (parent)
      // We fetch ALL data and filter by AR Aging record's own quarter in frontend
      if (rowData?.year && rowData?.dealerId) {
        response = await getDfhmAgingByFilters({
          // quarter: NOT passed - we filter in frontend
          year: rowData.year,
          dealerId: rowData.dealerId,
        });
      } else if (rowData?.dfhmId || rowData?.id) {
        // Fallback to dfhmId
        response = await getDfhmAgingByDfhmId(rowData.dfhmId || rowData.id);
      } else {
        setError("Missing required parameters (year, dealerId or dfhmId)");
        setLoading(false);
        return;
      }

      if (response?.status && response?.data) {
        // Store dfhm_id BEFORE filtering (for adding customers when current quarter is empty)
        if (response.data.length > 0 && response.data[0].dfhm_id) {
          setDfhmId(response.data[0].dfhm_id);
        }
        
        // Filter data by the active quarter (each AR Aging record has its own quarter field)
        const filteredData = response.data.filter(item => item.quarter === quarterToFetch);
        
        console.log("Total records:", response.data.length, "Filtered for", quarterToFetch + ":", filteredData.length);
        
        const transformed = transformAgingDataForTableGrouped(filteredData);
        setTableDataDynamic(transformed);
      } else {
        setTableDataDynamic([]);
      }
    } catch (err) {
      console.error("Error fetching AR Aging data:", err);
      setError("Failed to load AR Aging data. Please try again.");
      setTableDataDynamic([]);
    } finally {
      setLoading(false);
    }
  };

  // Fetch on mount and quarter change
  useEffect(() => {
    if (rowData) {
      fetchData();
    }
  }, [activeQuarter, rowData?.year, rowData?.dealerId]);

  // ============================================
  // CALCULATE TOTALS
  // ============================================
  const calculateAllTotals = (data) => {
    const updated = JSON.parse(JSON.stringify(data));

    updated.forEach((section) => {
      const totalRow = section.rows.find((r) => r.isCalculatedTotal);
      if (totalRow) {
        const otherRows = section.rows.filter((r) => !r.isCalculatedTotal);

        // Reset totals
        Object.keys(totalRow.values).forEach((key) => {
          totalRow.values[key] = 0;
        });

        // Sum all non-total rows
        otherRows.forEach((row) => {
          Object.keys(totalRow.values).forEach((key) => {
            totalRow.values[key] += parseNumericValue(row.values[key]);
          });
        });
      }
    });

    return updated;
  };

  // ============================================
  // HANDLE VALUE CHANGE
  // ============================================
  const handleValueChange = (sectionIndex, rowIndex, field, newValue) => {
    setTableDataDynamic((prev) => {
      const updated = JSON.parse(JSON.stringify(prev));
      const row = updated[sectionIndex].rows[rowIndex];

      // Update the field
      row.values[field] = parseNumericValue(newValue);

      // Recalculate derived fields for this row
      const current = parseNumericValue(row.values["Current"]);
      const l30 = parseNumericValue(row.values["<30 Days"]);
      const l60 = parseNumericValue(row.values["30-60 Days"]);
      const l90 = parseNumericValue(row.values["60-90 Days"]);
      const m90 = parseNumericValue(row.values[">90 Days"]);

      row.values["Total Overdue"] = l30 + l60 + l90 + m90;
      row.values["Total"] = current + row.values["Total Overdue"];

      return calculateAllTotals(updated);
    });
  };

  // ============================================
  // SAVE DATA
  // ============================================
  const handleSave = async () => {
    setSaving(true);

    try {
      const apiData = transformAgingGroupedDataForApi(tableDataDynamic);

      if (apiData.length === 0) {
        toast.warning("No data to save");
        setSaving(false);
        return;
      }

      const response = await updateMultipleDfhmAging(apiData);

      if (response?.status) {
        toast.success("AR Aging data saved successfully!");
        setFillTableMode("view");
      } else {
        toast.error(response?.message || "Failed to save data");
      }
    } catch (err) {
      console.error("Error saving AR Aging data:", err);
      toast.error("Failed to save AR Aging data. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  // ============================================
  // ADD CUSTOMER
  // ============================================
  const handleChange = (field, value) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSaveCustomer = async () => {
    let hasError = false;
    const newErrors = { type: "", customerName: "" };

    if (!form.type) {
      newErrors.type = "Please select customer type";
      hasError = true;
    }

    if (!form.customerName.trim()) {
      newErrors.customerName = "Please enter customer name";
      hasError = true;
    }

    setErrors(newErrors);
    if (hasError) return;

    setAddingCustomer(true);

    try {
      // Get dfhm_id - prefer stored dfhmId state, then try tableData, then rowData
      const currentDfhmId = dfhmId || tableDataDynamic[0]?.rows[0]?.dfhm_id || rowData?.dfhmId || rowData?.id;

      console.log("Adding customer with:", {
        dfhmId: currentDfhmId,
        quarter: activeQuarter,
        category: form.type,
        customerName: form.customerName.trim()
      });

      if (!currentDfhmId) {
        toast.error("Unable to add customer - DFHM ID not found. Please try switching quarters first.");
        setAddingCustomer(false);
        return;
      }

      const payload = {
        dfhm_id: currentDfhmId,
        quarter: activeQuarter,
        category: form.type, // "Equipment" or "Parts"
        customer_name: form.customerName.trim(),
        current_ar: null,
        L30: null,
        L60: null,
        L90: null,
        M90: null,
      };

      console.log("API payload:", payload);

      const response = await addDfhmAging(payload);

      if (response?.status) {
        toast.success("Customer added successfully!");
        handleClosePopup();
        // Refresh data for the CURRENT quarter to show new customer
        console.log("Refreshing data for quarter:", activeQuarter);
        fetchData(activeQuarter);
      } else {
        toast.error(response?.message || "Failed to add customer");
      }
    } catch (err) {
      console.error("Error adding customer:", err);
      toast.error("Failed to add customer. Please try again.");
    } finally {
      setAddingCustomer(false);
    }
  };

  const handleClosePopup = () => {
    setForm({ type: "", customerName: "" });
    setErrors({ type: "", customerName: "" });
    setDropdowns({ type: false });
    setShowAddCustomer(false);
  };

  // ============================================
  // DELETE ROW
  // ============================================
  const handleDeleteClick = (sectionIdx, rowIdx, row) => {
    if (row.isCalculatedTotal) return; // Can't delete total rows
    setDeleteConfirm({ show: true, row, sectionIdx, rowIdx });
  };

  const handleConfirmDelete = async () => {
    const { row, sectionIdx, rowIdx } = deleteConfirm;

    if (!row.id) {
      toast.error("Cannot delete - row ID not found");
      setDeleteConfirm({ show: false, row: null, sectionIdx: null, rowIdx: null });
      return;
    }

    setDeleting(true);

    try {
      const response = await deleteDfhmAging(row.id);

      if (response?.status) {
        toast.success("Customer deleted successfully!");
        // Remove from local state
        setTableDataDynamic((prev) => {
          const updated = JSON.parse(JSON.stringify(prev));
          updated[sectionIdx].rows.splice(rowIdx, 1);
          return calculateAllTotals(updated);
        });
      } else {
        toast.error(response?.message || "Failed to delete customer");
      }
    } catch (err) {
      console.error("Error deleting customer:", err);
      toast.error("Failed to delete customer. Please try again.");
    } finally {
      setDeleting(false);
      setDeleteConfirm({ show: false, row: null, sectionIdx: null, rowIdx: null });
    }
  };

  // ============================================
  // IMPORT FILE
  // ============================================
  const handleImportClick = () => {
    setShowimportPopup(true);
  };

  const handleImportFile = () => {
    if (!formData.file) {
      toast.warning("Please select a file first!");
      return;
    }
    // TODO: Implement file upload to backend
    console.log("File imported:", formData.file);
    toast.info("Import functionality coming soon!");
    setShowimportPopup(false);
    setFormData({ file: "", fileObject: null });
  };

  // ============================================
  // NAVIGATION
  // ============================================
  const handleback = () => {
    navigate("/dfhm/viewdfhm");
  };

  const handleTabClick = (tab, path) => {
    setActiveTab(tab);
    navigate(path, {
      state: {
        ...location.state,
      },
    });
  };

  // ============================================
  // FORMAT DISPLAY VALUE
  // ============================================
  const formatDisplayValue = (val) => {
    if (val === null || val === undefined || val === "") return "";
    const num = parseNumericValue(val);
    return num.toLocaleString("en-IN");
  };

  // ============================================
  // RENDER
  // ============================================
  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* TOP ROW */}
          <div className="w-full relative flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ArrowLeft
                size={24}
                onClick={handleback}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              />
              <h1 className="text-base font-semibold text-darkblue1">
                DFHM / {isViewMode ? "View DFHM" : "Fill Entries"} - AR Aging - {dealerName}
              </h1>
            </div>

            <div className="absolute left-1/2 -translate-x-1/2">
              <p className="text-[10px] text-red1 font-medium whitespace-nowrap">
                Disclaimer : This data is for internal review to determine
                improvement areas within dealerships
              </p>
            </div>

            <div className="flex items-center gap-4">
              <p className="text-xs text-black font-semibold whitespace-nowrap">
                All Values in INR
              </p>
            </div>
          </div>

          <hr className="hidden lg:block w-[7%] border-t-4 border-darkblue1 ml-[34px] mb-2" />

          {/* TAB BUTTONS */}
          <div className="w-full grid grid-cols-4 divide-x divide-black/30 border border-black/30 overflow-hidden mb-2">
            <button
              onClick={() => handleTabClick("profit", "/dfhm/viewdfhm/fillentries")}
              className={`py-1.5 font-medium transition text-xs
                ${activeTab === "profit" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              Profit & Loss
            </button>
            <button
              onClick={() => handleTabClick("balance", "/dfhm/viewdfhm/fillentries/balance")}
              className={`py-1 font-medium transition text-xs
                ${activeTab === "balance" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              Balance Sheet
            </button>
            <button
              onClick={() => handleTabClick("headcount", "/dfhm/viewdfhm/fillentries/headcount")}
              className={`py-1 font-medium transition text-xs
                ${activeTab === "headcount" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              Headcount
            </button>
            <button
              className={`py-1 font-medium transition text-xs
                ${activeTab === "ar" ? "bg-DustyBlue1 text-white" : "bg-white text-black"}`}
            >
              AR Aging
            </button>
          </div>

          {/* QUARTER & ACTION BUTTONS */}
          <div className="w-full flex items-center justify-between mb-2">
            {/* Quarter Buttons */}
            <div className="grid grid-cols-4 divide-x divide-darkblue1 border border-darkblue1 overflow-hidden">
              {["Q1", "Q2", "Q3", "Q4"].map((q) => (
                <button
                  key={q}
                  onClick={() => setActiveQuarter(q)}
                  className={`py-1 px-10 font-medium transition text-xs
                    ${activeQuarter === q
                      ? "bg-darkblue1 text-white"
                      : "bg-white text-darkblue1 hover:bg-darkblue1 hover:text-white"
                    }`}
                >
                  {q}
                </button>
              ))}
            </div>

            {/* Action Buttons - Only show if data exists for this quarter */}
            {isFillMode && dfhmId && tableDataDynamic.length > 0 && (
              <div className="flex border border-darkblue1 overflow-hidden">
                <button
                  onClick={handleImportClick}
                  className="py-1 px-10 font-medium text-xs bg-darkblue1 text-white border-r border-r-grey2 hover:bg-blue-700 transition"
                >
                  Import
                </button>
                <button className="py-1 px-10 font-medium text-xs bg-darkblue1 text-white border-r border-r-grey2 hover:bg-blue-700 transition">
                  Sample File
                </button>
                <button
                  onClick={() => setShowAddCustomer(true)}
                  className="py-1 px-10 font-medium text-xs bg-darkblue1 text-white hover:bg-blue-700 transition"
                >
                  Add Customer
                </button>
              </div>
            )}
          </div>

          {/* TABLE */}
          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden mb-2">
            <div
              ref={tableContainerRef}
              className="w-full overflow-y-auto overflow-x-auto lg:max-h-[60vh] xl:max-h-[58vh] 2xl:max-h-[65vh]"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
            >
              {loading ? (
                <div className="flex items-center justify-center py-20">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
                  <span className="ml-3 text-sm text-gray-600">Loading AR Aging data...</span>
                </div>
              ) : error ? (
                <div className="flex flex-col items-center justify-center py-20">
                  <p className="text-red-500 text-sm mb-4">{error}</p>
                  <button
                    onClick={fetchData}
                    className="px-4 py-2 bg-darkblue1 text-white text-xs hover:bg-blue-700 transition"
                  >
                    Retry
                  </button>
                </div>
              ) : tableDataDynamic.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20">
                  <p className="text-gray-500 text-sm">
                    {dfhmId 
                      ? `No AR Aging data available for ${activeQuarter}` 
                      : `DFHM not created for this dealer/year. Please create DFHM first.`
                    }
                  </p>
                </div>
              ) : (
                <table className="w-full text-xs cursor-pointer border-collapse">
                  <thead className="bg-Dustyblue text-white font-medium text-left sticky top-0 z-10">
                    <tr>
                      <th className="py-2 px-2 border border-grey2 border-l-0 border-t-0 w-[12%]">Customer Type</th>
                      <th className="py-2 px-2 border border-grey2 border-t-0 w-[12%]">Customer Name</th>
                      <th className="py-2 px-2 border border-grey2 border-t-0 text-center">Current (AR)</th>
                      <th className="py-2 px-2 border border-grey2 border-t-0 text-center">&lt;30 Days</th>
                      <th className="py-2 px-2 border border-grey2 border-t-0 text-center">30-60 Days</th>
                      <th className="py-2 px-2 border border-grey2 border-t-0 text-center">60-90 Days</th>
                      <th className="py-2 px-2 border border-grey2 border-t-0 text-center">&gt;90 Days</th>
                      <th className="py-2 px-2 border border-grey2 border-t-0 text-center">Total Overdue</th>
                      <th className="py-2 px-2 border border-grey2 border-t-0 border-r-0 text-center">Total</th>
                      {isFillMode && fillTableMode === "edit" && (
                        <th className="py-2 px-2 border border-grey2 border-t-0 border-r-0 text-center w-[60px]">Action</th>
                      )}
                    </tr>
                  </thead>

                  <tbody>
                    {tableDataDynamic.map((section, sectionIdx) => (
                      <React.Fragment key={sectionIdx}>
                        {section.rows.map((row, rowIdx) => {
                          const isTotal = row.isCalculatedTotal;
                          const isFirstRow = rowIdx === 0;
                          const nonTotalRowCount = section.rows.filter((r) => !r.isCalculatedTotal).length;

                          return (
                            <tr
                              key={rowIdx}
                              className={isTotal ? "bg-gray-100 font-semibold" : "bg-white hover:bg-lightBlue/50"}
                            >
                              {/* Category Column - rowSpan for first row */}
                              {isFirstRow && (
                                <td
                                  rowSpan={section.rows.length}
                                  className="py-1 px-2 border border-grey2 font-medium align-top"
                                >
                                  {section.category}
                                </td>
                              )}

                              {/* Customer Name / SubCategory */}
                              <td className="py-1 px-2 border border-grey2">
                                {row.subCategory}
                              </td>

                              {/* Current (AR) */}
                              <td className="py-1 px-2 border border-grey2 text-center">
                                {showInputs && !isTotal ? (
                                  <input
                                    type="number"
                                    value={row.values["Current"] || ""}
                                    onChange={(e) =>
                                      handleValueChange(sectionIdx, rowIdx, "Current", e.target.value)
                                    }
                                    className="w-full bg-white text-center border border-grey2 px-1 py-0.5 text-xs focus:outline-none"
                                  />
                                ) : (
                                  formatDisplayValue(row.values["Current"])
                                )}
                              </td>

                              {/* <30 Days */}
                              <td className="py-1 px-2 border border-grey2 text-center">
                                {showInputs && !isTotal ? (
                                  <input
                                    type="number"
                                    value={row.values["<30 Days"] || ""}
                                    onChange={(e) =>
                                      handleValueChange(sectionIdx, rowIdx, "<30 Days", e.target.value)
                                    }
                                    className="w-full bg-white text-center border border-grey2 px-1 py-0.5 text-xs focus:outline-none"
                                  />
                                ) : (
                                  formatDisplayValue(row.values["<30 Days"])
                                )}
                              </td>

                              {/* 30-60 Days */}
                              <td className="py-1 px-2 border border-grey2 text-center">
                                {showInputs && !isTotal ? (
                                  <input
                                    type="number"
                                    value={row.values["30-60 Days"] || ""}
                                    onChange={(e) =>
                                      handleValueChange(sectionIdx, rowIdx, "30-60 Days", e.target.value)
                                    }
                                    className="w-full bg-white text-center border border-grey2 px-1 py-0.5 text-xs focus:outline-none"
                                  />
                                ) : (
                                  formatDisplayValue(row.values["30-60 Days"])
                                )}
                              </td>

                              {/* 60-90 Days */}
                              <td className="py-1 px-2 border border-grey2 text-center">
                                {showInputs && !isTotal ? (
                                  <input
                                    type="number"
                                    value={row.values["60-90 Days"] || ""}
                                    onChange={(e) =>
                                      handleValueChange(sectionIdx, rowIdx, "60-90 Days", e.target.value)
                                    }
                                    className="w-full bg-white text-center border border-grey2 px-1 py-0.5 text-xs focus:outline-none"
                                  />
                                ) : (
                                  formatDisplayValue(row.values["60-90 Days"])
                                )}
                              </td>

                              {/* >90 Days */}
                              <td className="py-1 px-2 border border-grey2 text-center">
                                {showInputs && !isTotal ? (
                                  <input
                                    type="number"
                                    value={row.values[">90 Days"] || ""}
                                    onChange={(e) =>
                                      handleValueChange(sectionIdx, rowIdx, ">90 Days", e.target.value)
                                    }
                                    className="w-full bg-white text-center border border-grey2 px-1 py-0.5 text-xs focus:outline-none"
                                  />
                                ) : (
                                  formatDisplayValue(row.values[">90 Days"])
                                )}
                              </td>

                              {/* Total Overdue - Calculated */}
                              <td className="py-1 px-2 border border-grey2 text-center bg-gray-50">
                                {formatDisplayValue(row.values["Total Overdue"])}
                              </td>

                              {/* Total - Calculated */}
                              <td className="py-1 px-2 border border-grey2 text-center bg-gray-50">
                                {formatDisplayValue(row.values["Total"])}
                              </td>

                              {/* Delete Action */}
                              {isFillMode && fillTableMode === "edit" && (
                                <td className="py-1 px-2 border border-grey2 text-center">
                                  {!isTotal && (
                                    <button
                                      onClick={() => handleDeleteClick(sectionIdx, rowIdx, row)}
                                      className="text-red-500 hover:text-red-700 text-xs"
                                      title="Delete Customer"
                                    >
                                      🗑️
                                    </button>
                                  )}
                                </td>
                              )}
                            </tr>
                          );
                        })}
                      </React.Fragment>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          {/* SAVE / EDIT / SUBMIT BUTTONS */}
          {isFillMode && !loading && !error && tableDataDynamic.length > 0 && (
            <div className="flex justify-end mt-4 gap-2">
              {fillTableMode === "edit" && (
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="px-4 py-1 font-medium bg-darkblue1 text-xs text-white hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50"
                >
                  {saving ? "Saving..." : "Save & View"}
                </button>
              )}

              {fillTableMode === "view" && (
                <>
                  <button
                    onClick={() => setFillTableMode("edit")}
                    className="px-4 py-1 font-medium bg-darkblue1 text-xs text-white hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition"
                  >
                    Edit
                  </button>
                  <button className="px-4 py-1 font-medium bg-darkblue1 text-xs text-white hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition">
                    Submit
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ADD CUSTOMER MODAL */}
      {showAddCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40 p-4">
          <div className="bg-white p-6 rounded shadow-lg w-full max-w-sm relative">
            <button
              onClick={handleClosePopup}
              className="absolute top-2 right-2 text-gray-500 hover:text-black text-lg"
            >
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
                alt="close"
                className="w-4 h-4"
              />
            </button>

            <h2 className="text-base text-center text-MediumGrey font-semibold mb-4">Add New Customer</h2>

            <div className="mb-2">
              <StyledSelectField
                label="Customer Type"
                placeholder="Select Type"
                value={typeOptions.find((opt) => opt.value === form.type)?.label || ""}
                setValue={(label) => {
                  const selected = typeOptions.find((opt) => opt.label === label);
                  handleChange("type", selected?.value || "");
                  setErrors((p) => ({ ...p, type: "" }));
                }}
                options={typeOptions.map((opt) => opt.label)}
                dropdownOpen={dropdowns.type}
                setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, type: val }))}
                dropdownRef={refs.type}
                error={errors.type}
              />
            </div>

            <div className="mb-4">
              <label className="text-xs text-black/70 font-medium">Customer Name</label>
              <input
                type="text"
                value={form.customerName}
                onChange={(e) => {
                  handleChange("customerName", e.target.value);
                  setErrors((p) => ({ ...p, customerName: "" }));
                }}
                placeholder="Enter customer name"
                className={`w-full text-xs border px-2 py-1.5 text-sm focus:outline-none ${
                  errors.customerName ? "border-red1" : "border-black/30"
                }`}
              />
              {errors.customerName && (
                <p className="text-red1 text-xs mt-1">{errors.customerName}</p>
              )}
            </div>

            <div className="flex justify-center">
              <button
                onClick={handleSaveCustomer}
                disabled={addingCustomer}
                className="px-4 py-1 text-xs font-medium bg-darkblue1 text-white hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 disabled:opacity-50"
              >
                {addingCustomer ? "Saving..." : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deleteConfirm.show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40 p-4">
          <div className="bg-white p-6 rounded shadow-lg w-full max-w-sm relative">
            <h2 className="text-base text-center text-MediumGrey font-semibold mb-4">Confirm Delete</h2>
            <p className="text-sm text-center text-gray-600 mb-4">
              Are you sure you want to delete customer "{deleteConfirm.row?.customer_name}"?
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={() => setDeleteConfirm({ show: false, row: null, sectionIdx: null, rowIdx: null })}
                className="px-4 py-1 text-xs font-medium border border-darkblue1 text-darkblue1 hover:bg-darkblue1 hover:text-white transition"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                disabled={deleting}
                className="px-4 py-1 text-xs font-medium bg-red-500 text-white hover:bg-red-600 transition disabled:opacity-50"
              >
                {deleting ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* IMPORT MODAL */}
      {showimportPopup && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white w-[40%] h-[30%] shadow-lg p-6 relative rounded-lg">
            <button
              onClick={() => setShowimportPopup(false)}
              className="absolute top-2 right-2 text-gray-500 hover:text-black text-lg"
            >
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
                alt="close"
                className="w-4 h-4"
              />
            </button>

            <h2 className="text-base font-semibold text-center text-MediumGrey mb-4">Import Customers</h2>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={formData.file || ""}
                readOnly
                placeholder="No file chosen"
                className="flex-1 px-2 py-1 border border-black/30 text-xs cursor-pointer hover:bg-gray-100"
              />
              <button
                onClick={() => fileInputRef.current.click()}
                className="px-3 py-1 bg-darkblue1 text-white text-xs hover:bg-darkblue1/80"
              >
                Upload
              </button>
            </div>

            <input
              type="file"
              ref={fileInputRef}
              accept=".xls,.xlsx,.csv"
              style={{ display: "none" }}
              onChange={(e) => {
                const file = e.target.files[0];
                if (file) {
                  setFormData({ file: file.name, fileObject: file });
                }
              }}
            />

            <button
              onClick={handleImportFile}
              className="mt-6 text-xs font-medium px-8 py-1.5 bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto"
            >
              Import
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ArAging;