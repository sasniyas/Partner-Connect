import React, { useState, useRef, useEffect, useMemo } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, ArrowRight, Eye, MoreVertical,ChevronDown,ChevronUp,ChevronsUpDown,ArrowUp,ArrowDown  } from "lucide-react";
import Searchinput from "../../../Components/Searchinput";
import Filter from "../../../Components/Filter";
import { useLocation, useNavigate } from "react-router-dom";
import DeleteModal from "../../../Components/DeleteModal";
import {
  getAllDfhm,
  deleteDfhm,
  getUniqueFilterOptions,
  formatDate,
} from "../../../services/dfhm/dfhm.service";

const ViewDfhm = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [menuOpen, setMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedYear, setSelectedYear] = useState([]);
  const [selectedQuarter, setSelectedQuarter] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState([]);
  const [selectedDealer, setSelectedDealer] = useState([]);
  const [selectedMarketArea, setSelectedMarketArea] = useState([]);
  const tableContainerRef = useRef(null);
  const [dropdownId, setDropdownId] = useState(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // API Data States
  const [displayedItems, setDisplayedItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  // Filter Options (dynamic from API data)
  const [filterOptions, setFilterOptions] = useState({
    year: [],
    quarter: [],
    marketArea: [],
    dealer: [],
    status: [],
  });
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  // Fetch data on component mount
  useEffect(() => {
    fetchDfhmData();
  }, []);

  // Refresh data if coming from create page
  useEffect(() => {
    if (location.state?.refresh) {
      fetchDfhmData();
      // Clear the state to prevent re-fetching on subsequent renders
      navigate(location.pathname, { replace: true, state: {} });
    }
    if (location.state?.successMessage) {
      // You could show a toast notification here
      console.log("✅", location.state.successMessage);
    }
  }, [location.state]);

  // Fetch DFHM data from API
  const fetchDfhmData = async () => {
    try {
      setLoading(true);
      setError(null);

      const data = await getAllDfhm();
      console.log("✅ DFHM data loaded:", data.length, "records");

      setDisplayedItems(data);

      // Extract unique filter options
      setFilterOptions({
        year: getUniqueFilterOptions(data, "year").map(String),
        quarter: getUniqueFilterOptions(data, "quarter"),
        marketArea: getUniqueFilterOptions(data, "marketArea").filter((ma) => ma !== "—"),
        dealer: getUniqueFilterOptions(data, "dealer").filter((d) => d !== "—"),
        status: getUniqueFilterOptions(data, "status"),
      });
    } catch (err) {
      console.error("❌ Error fetching DFHM data:", err);
      setError(err.message || "Failed to load DFHM data");
    } finally {
      setLoading(false);
    }
  };

  const toggleDropdown = (id) => {
    setDropdownId(dropdownId === id ? null : id);
  };

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest(".dropdown-wrapper")) {
        setDropdownId(null);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Static options for filters
  const quarterOptions = ["Q1", "Q2", "Q3", "Q4"];
  const startYear = 2016;
  const endYear = new Date().getFullYear() + 10;
  const yearOptions = Array.from(
    { length: endYear - startYear + 1 },
    (_, i) => (startYear + i).toString()
  );
  const statusOptions = ["Created", "All Data Review", "Review by Volvo"];

  // 🔹 Filtered Data
  const filteredItems = useMemo(() => {
    return displayedItems.filter((item) => {
      const searchLower = searchTerm.toLowerCase().trim();

      const matchesSearch =
        searchLower === "" ||
        item.marketArea?.toLowerCase().includes(searchLower) ||
        item.dealer?.toLowerCase().includes(searchLower) ||
        item.dealerName?.toLowerCase().includes(searchLower);

      const matchesYear =
        selectedYear.length === 0 ||
        selectedYear.some((year) =>
          item.year?.toString().toLowerCase().includes(year.toLowerCase())
        );

      const matchesQuarter =
        selectedQuarter.length === 0 ||
        selectedQuarter.some((quarter) =>
          item.quarter?.toString().includes(quarter.toString())
        );

      const matchesMarketArea =
        selectedMarketArea.length === 0 ||
        selectedMarketArea.some((area) =>
          item.marketArea?.toLowerCase().includes(area.toLowerCase())
        );

      const matchesDealer =
        selectedDealer.length === 0 ||
        selectedDealer.some((dealer) =>
          item.dealer?.toString().includes(dealer.toString())
        );

      const matchesStatus =
        selectedStatus.length === 0 ||
        selectedStatus.some((status) =>
          item.status?.toString().includes(status.toString())
        );

      return (
        matchesSearch &&
        matchesYear &&
        matchesQuarter &&
        matchesMarketArea &&
        matchesDealer &&
        matchesStatus
      );
    });
  }, [
    displayedItems,
    searchTerm,
    selectedYear,
    selectedQuarter,
    selectedMarketArea,
    selectedDealer,
    selectedStatus,
  ]);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredItems;

  return [...filteredItems].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [filteredItems, sortKey, sortOrder]);

  const handleViewDetails = (item) => {
    navigate("/dfhm/viewdfhm/fillentries", { state: { rowData: item, mode: "view" } });
  };

  const handleFillEntries = (item) => {
    navigate("/dfhm/viewdfhm/fillentries", { state: { rowData: item, mode: "fill" } });
  };

  // Handle delete with API
  const handleConfirmDelete = async () => {
    if (!itemToDelete) return;

    setDeleteLoading(true);
    try {
      await deleteDfhm(itemToDelete.id);

      // Remove from local state
      setDisplayedItems((prev) => prev.filter((i) => i.id !== itemToDelete.id));

      console.log("✅ DFHM deleted successfully");
    } catch (err) {
      console.error("❌ Error deleting DFHM:", err);
      alert(err.message || "Failed to delete DFHM");
    } finally {
      setDeleteLoading(false);
      setDeleteModalOpen(false);
      setItemToDelete(null);
    }
  };

  const handleback = () => {
    navigate("/dfhm/createdfhm");
  };

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "lg:ml-60" : ""
        } flex justify-center flex-1`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* 🔵 HEADER ROW */}
          <div className="w-full relative flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ArrowLeft
                size={24}
                onClick={() => handleback()}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              />
              <h1 className="text-base font-semibold text-darkblue1">
                Dealer Finance Health
              </h1>
            </div>

            <div className="absolute left-1/2 -translate-x-1/2">
              <p className="text-[10px] text-red1 font-medium whitespace-nowrap">
                Disclaimer : This data is for internal review to determine improvement
                areas within dealerships
              </p>
            </div>

            <div>
              <p className="text-xs text-black font-semibold">
                All Values in INR:{" "}
                <span className="font-normal text-SteelBlue1">34,890</span>
              </p>
            </div>
          </div>

          <hr className="hidden lg:block w-[7%] border-t-4 border-darkblue1 mt-0 ml-[34px] mb-3" />

          {/* 🔵 SEARCH + FILTER ROW */}
          <div className="flex flex-col sm:flex-row items-center justify-start gap-2 mb-2">
            {/* SEARCH INPUT */}
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="w-[1/2]"
              iconColor="text-black"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-1.5"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              inputWidth="w-full"
              focusRing="focus:ring-1 focus:ring-black/60"
              hoverInputClasses="hover:bg-white hover:border-black/60"
            />

            {/* YEAR FILTER */}
            <Filter
              name="Year"
              value={selectedYear}
              options={filterOptions.year.length > 0 ? filterOptions.year : yearOptions}
              onChange={(name, value) => setSelectedYear(value)}
              placeholder="Year"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
              customWidth="w-[120px]"
            />

            {/* QUARTER FILTER */}
            <Filter
              name="Quarter"
              value={selectedQuarter}
              options={quarterOptions}
              onChange={(name, value) => setSelectedQuarter(value)}
              placeholder="Quarter"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
              customWidth="w-[120px]"
            />

            {/* MARKET AREA FILTER */}
            <Filter
              name="Market Area"
              value={selectedMarketArea}
              options={filterOptions.marketArea}
              onChange={(name, value) => setSelectedMarketArea(value)}
              placeholder="Market Area"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
              customWidth="w-[150px]"
            />

            {/* DEALER FILTER */}
            <Filter
              name="Dealer"
              value={selectedDealer}
              options={filterOptions.dealer}
              onChange={(name, value) => setSelectedDealer(value)}
              placeholder="Dealership"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
              customWidth="w-[150px]"
            />

            {/* STATUS FILTER */}
            <Filter
              name="Status"
              value={selectedStatus}
              options={statusOptions}
              onChange={(name, value) => setSelectedStatus(value)}
              placeholder="Status"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
              customWidth="w-[150px]"
            />
          </div>

          {/* Loading State */}
          {loading && (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
              <span className="ml-3 text-gray-600">Loading DFHM data...</span>
            </div>
          )}

          {/* Error State */}
          {error && !loading && (
            <div className="bg-red-50 border border-red-200 p-4 mb-4">
              <p className="text-red-600 text-sm">{error}</p>
              <button
                onClick={fetchDfhmData}
                className="mt-2 text-xs text-blue-600 hover:underline"
              >
                Try Again
              </button>
            </div>
          )}

          {/* 🔵 TABLE */}
          {!loading && !error && (
            <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
             <div
              ref={tableContainerRef}
              className="overflow-y-auto overflow-x-auto lg:overflow-x-hidden lg:max-h-[calc(100vh-14rem)] max-h-[calc(100vh-16rem)] hide-scrollbar"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
              onScroll={handleTableScroll}
            >
                <table className="w-full text-xs">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                   <tr>
  {/* Year */}
  <th
    onClick={() => handleSort("year")}
    className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[5%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Year
      {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

      {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Quarter */}
  <th
    onClick={() => handleSort("quarter")}
    className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[10%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Quarter
      {sortKey === "quarter" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "quarter" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Market Area */}
  <th
    onClick={() => handleSort("marketArea")}
    className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[15%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Market Area
      {sortKey === "marketArea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "marketArea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Dealership */}
  <th
    onClick={() => handleSort("dealer")}
    className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[15%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Dealership
      {sortKey === "dealer" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "dealer" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Status */}
  <th
    onClick={() => handleSort("status")}
    className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[10%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Status
      {sortKey === "status" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "status" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Dealer Principal Validate */}
  <th
    onClick={() => handleSort("dealerPrincipalValidate")}
    className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[15%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Dealer Principal Validate
      {sortKey === "dealerPrincipalValidate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "dealerPrincipalValidate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Volvo User Validate */}
  <th
    onClick={() => handleSort("volvoUserValidate")}
    className="px-4 py-1.5 border border-grey2 border-t-0 border-l-0 font-medium w-[15%] cursor-pointer select-none"
  >
    <div className="flex items-center gap-1">
      Volvo User validate
      {sortKey === "volvoUserValidate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
      {sortKey === "volvoUserValidate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
    </div>
  </th>

  {/* Actions (No Sort) */}
  <th className="text-center py-1.5 border border-grey2 border-t-0 border-l-0 border-r-0 font-medium w-[8%]">
    Actions
  </th>
</tr>
                  </thead>

                  <tbody>
                    {sortedData.length === 0 ? (
                      <tr>
                        <td
                          colSpan={8}
                          className="text-center py-8 text-gray-500 italic"
                        >
                          No data found
                        </td>
                      </tr>
                    ) : (
                      sortedData.map((item, index) => (
                        <tr
                          key={item.rowId || item.id}
                          className="hover:bg-lightBlue/50 text-xs"
                        >
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                            {item.year}
                          </td>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                            {item.quarter}
                          </td>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                            {item.marketArea}
                          </td>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                            {item.dealer}
                          </td>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                            {item.status}
                          </td>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                            {item.dealerPrincipalValidate}
                          </td>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                            {item.volvoUserValidate}
                          </td>
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-center relative">
                            <div className="flex items-center justify-center dropdown-wrapper">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleDropdown(index);
                                }}
                                className="w-6 h-6 flex items-center justify-center border border-gray-300 hover:bg-gray-100 transition-colors"
                              >
                                <MoreVertical size={16} className="text-gray-600" />
                              </button>

                              {dropdownId === index && (
                                <div
                                  className={`absolute right-0 w-40 bg-white border border-gray-200 shadow-lg z-50
                                  ${
                                    sortedData.length > 3 &&
                                    index >= sortedData.length - 3
                                      ? "bottom-full mb-1"
                                      : "top-full -mt-4"
                                  }`}
                                >
                                  <div className="py-1 flex flex-col">
                                    <button
                                      onClick={() => {
                                        handleViewDetails(item);
                                        setDropdownId(null);
                                      }}
                                      className="w-full px-3 py-1 text-left text-xs text-black hover:bg-lightBlue/50 flex items-center gap-2"
                                    >
                                      <span className="p-1 border border-2 border-black/60 rounded flex items-center justify-center">
                                        <Eye className="w-3 h-3 text-black/60" />
                                      </span>
                                      View Details
                                    </button>

                                    <button
                                      onClick={() => {
                                        handleFillEntries(item);
                                        setDropdownId(null);
                                      }}
                                      className="w-full px-3 py-1 text-left text-xs text-black hover:bg-lightBlue/50 flex items-center gap-2"
                                    >
                                      <span className="p-1 rounded flex items-center justify-center">
<svg xmlns="http://www.w3.org/2000/svg" width="17" height="20" viewBox="0 0 17 20" fill="none" className="w-4 h-4" >
<path d="M12.75 2.25H16.5V19.5H0V2.25H3.75V3.75H12.75V2.25ZM3 9.75H13.5V8.25H3V9.75ZM3 15.75H13.5V14.25H3V15.75ZM5.25 2.25V0H11.25V2.25H5.25Z" fill="#E06900"/>
</svg>                                      </span>
                                      Fill Entries
                                    </button>

                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setItemToDelete(item);
                                        setDeleteModalOpen(true);
                                        setDropdownId(null);
                                      }}
                                      className="w-full px-3 py-1 text-left text-xs text-black hover:bg-lightBlue/50 flex items-center gap-3"
                                    >
                                     <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>



                                      Delete
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
               {showScrollButtons && (
            <div className="fixed bottom-10 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

            </div>
          )}
        </div>
      </div>

      {/* Delete Modal */}
      <DeleteModal
        isOpen={deleteModalOpen}
        onClose={() => {
          if (!deleteLoading) {
            setDeleteModalOpen(false);
            setItemToDelete(null);
          }
        }}
        onConfirm={handleConfirmDelete}
        loading={deleteLoading}
        extraMessage="This action cannot be undone."
      />
    </div>
  );
};

export default ViewDfhm;