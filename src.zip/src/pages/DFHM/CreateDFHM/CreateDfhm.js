import React, { useState, useRef, useEffect } from "react";
import StyledSelectField from "../../../Components/StyledSelectField";
import StyledDateField from "../../../Components/StyledDatefield";
import { useNavigate } from "react-router-dom";
import { getMarketAreas } from "../../../services/pdpMaster/marketArea.service";
import { getActiveDealers } from "../../../services/PDP/CrudPdp/crudPdp.service";
import { addDfhm } from "../../../services/dfhm/dfhm.service";

// Helper function to format date for API (YYYY-MM-DD)
const formatDateForApi = (date) => {
  if (!date) return null;
  try {
    const d = new Date(date);
    return d.toISOString().split('T')[0];
  } catch {
    return null;
  }
};

const CreateDfhm = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [marketAreaOptions, setMarketAreaOptions] = useState([]);
  const [marketAreasList, setMarketAreasList] = useState([]); // holds {id, marketarea}
  const [dealerOptions, setDealerOptions] = useState([]);
  const [allDealers, setAllDealers] = useState([]);
  const [saveLoading, setSaveLoading] = useState(false);

  // 🔹 Form Data
  const [formData, setFormData] = useState({
    year: "",
    quarter: "",
    marketArea: "",
    chooseDealer: "",
    dealerType: "",
    startDate: "",
    endDate: "",
  });

  // 🔹 Dropdown State
  const [dropdowns, setDropdowns] = useState({
    year: false,
    quarter: false,
    marketArea: false,
    chooseDealer: false,
    dealerType: false,
  });

  // 🔹 Options
  const startYear = 2016;
  const endYear = new Date().getFullYear() + 10;

  const yearOptions = Array.from(
    { length: endYear - startYear + 1 },
    (_, i) => (startYear + i).toString()
  );

  const quarterOptions = [
    { label: "Q1", value: "Q1" },
    { label: "Q2", value: "Q2" },
    { label: "Q3", value: "Q3" },
    { label: "Q4", value: "Q4" },
  ];

  // Fetch Market Areas
  useEffect(() => {
    const fetchMarketAreas = async () => {
      try {
        const areas = await getMarketAreas(); // [{id, marketarea}]
        setMarketAreasList(areas);
        setMarketAreaOptions(areas.map(a => a.marketarea));
      } catch (error) {
        console.error("Failed to load market areas:", error.message);
      }
    };
    fetchMarketAreas();
  }, []);

  const choosedealeroptions = ["All Dealers", "Dealers in MA", "Individual Dealer"].map(
    (name) => ({ label: name, value: name })
  );

  // Fetch Dealers
  useEffect(() => {
    const fetchDealers = async () => {
      try {
        const activeDealers = await getActiveDealers();
        setAllDealers(activeDealers);
      } catch (error) {
        console.error(error.message);
      }
    };
    fetchDealers();
  }, []);

  // Update dealer options based on selection
  useEffect(() => {
    const { chooseDealer, marketArea } = formData;
    if (!allDealers.length) return;

    let options = [];

    if (chooseDealer === "All Dealers") {
      options = allDealers.map((d) => ({
        label: d.dealerShortName,
        value: d.id, // Store dealer ID
        dealerId: d.id,
      }));
      setFormData((prev) => ({ ...prev, dealerType: "All Dealers Selected" }));
    } else if (
      (chooseDealer === "Dealers in MA" || chooseDealer === "Individual Dealer") &&
      marketArea
    ) {
      const filtered = allDealers.filter((d) => d.marketName === marketArea);

      options = filtered.map((d) => ({
        label: d.dealerShortName,
        value: d.id, // Store dealer ID
        dealerId: d.id,
      }));

      if (chooseDealer === "Dealers in MA") {
        setFormData((prev) => ({
          ...prev,
          dealerType: `All Dealers in ${marketArea} Selected`,
        }));
      } else {
        setFormData((prev) => ({ ...prev, dealerType: "" }));
      }
    } else {
      options = [];
      setFormData((prev) => ({ ...prev, dealerType: "" }));
    }

    setDealerOptions(options);
  }, [formData.chooseDealer, formData.marketArea, allDealers]);

  const openSingleDropdown = (key) => {
    setDropdowns({
      year: false,
      quarter: false,
      marketArea: false,
      chooseDealer: false,
      dealerType: false,
      [key]: true,
    });
  };

  // 🔹 Refs
  const yearRef = useRef(null);
  const quarterRef = useRef(null);
  const marketAreaRef = useRef(null);
  const chooseDealerRef = useRef(null);
  const dealerTypeRef = useRef(null);

  // 🔹 Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      const refs = [
        yearRef,
        quarterRef,
        marketAreaRef,
        chooseDealerRef,
        dealerTypeRef,
      ];

      const clickedInside = refs.some(
        (ref) => ref.current && ref.current.contains(e.target)
      );

      if (!clickedInside) {
        setDropdowns({
          year: false,
          quarter: false,
          marketArea: false,
          chooseDealer: false,
          dealerType: false,
        });
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // 🔹 Errors
  const [errors, setErrors] = useState({
    year: "",
    quarter: "",
    marketArea: "",
    chooseDealer: "",
    dealerType: "",
    startDate: "",
    endDate: "",
  });

  // 🔹 Handle Save with API Integration
  const handleSave = async () => {
    const newErrors = {};

    // Required fields validation
    if (!formData.year) newErrors.year = "Please fill out this field";
    if (!formData.quarter) newErrors.quarter = "Please fill out this field";
    if (!formData.marketArea) newErrors.marketArea = "Please fill out this field";
    if (!formData.chooseDealer) newErrors.chooseDealer = "Please fill out this field";

    // Dealer validation
    if (formData.chooseDealer === "Individual Dealer") {
      if (!formData.dealerType) {
        newErrors.dealerType = "Please select a dealer";
      }
    }

    if (formData.chooseDealer === "Dealers in MA") {
      if (dealerOptions.length === 0) {
        newErrors.dealerType = "No dealers available in this Market Area";
      }
    }

    if (!formData.dealerType) newErrors.dealerType = "Please fill out this field";
    if (!formData.startDate) newErrors.startDate = "Start date is required";
    if (!formData.endDate) newErrors.endDate = "End date is required";

    // Set all errors if any exist
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Clear errors
    setErrors({});
    setSaveLoading(true);

    try {
      // Get market area ID from name
      const selectedMarketArea = marketAreasList.find(
        (ma) => ma.marketarea === formData.marketArea
      );

      if (!selectedMarketArea) {
        throw new Error("Invalid market area selected");
      }

      // Prepare dealer IDs based on selection
      let dealerIds = [];

      if (formData.chooseDealer === "All Dealers") {
        // All dealers
        dealerIds = allDealers.map((d) => d.id);
      } else if (formData.chooseDealer === "Dealers in MA") {
        // All dealers in selected market area
        const filtered = allDealers.filter((d) => d.marketName === formData.marketArea);
        dealerIds = filtered.map((d) => d.id);
      } else if (formData.chooseDealer === "Individual Dealer") {
        // Single dealer - formData.dealerType contains the dealer ID or name
        const selectedDealer = dealerOptions.find(
          (d) => d.label === formData.dealerType || d.value === formData.dealerType
        );
        if (selectedDealer) {
          dealerIds = [selectedDealer.dealerId || selectedDealer.value];
        } else {
          // Try to find by name in allDealers
          const dealer = allDealers.find((d) => d.dealerShortName === formData.dealerType);
          if (dealer) {
            dealerIds = [dealer.id];
          }
        }
      }

      if (dealerIds.length === 0) {
        throw new Error("No dealers selected");
      }

      // Prepare API payload
      const payload = {
        year: parseInt(formData.year),
        quarter: formData.quarter,
        market_area_id: selectedMarketArea.id,
        start_date: formatDateForApi(formData.startDate),
        end_date: formatDateForApi(formData.endDate),
        dealerIds: dealerIds,
        status: "Created",
      };

      console.log("📤 Creating DFHM:", payload);

      // Call API
      const response = await addDfhm(payload);

      console.log("✅ DFHM created successfully:", response);

      // Navigate to view page with success message
      navigate("/dfhm/viewdfhm", {
        state: {
          successMessage: `DFHM created successfully! ${response.count} entries created.`,
          refresh: true,
        },
      });
    } catch (error) {
      console.error("❌ Error creating DFHM:", error);
      alert(error.message || "Failed to create DFHM");
    } finally {
      setSaveLoading(false);
    }
  };

  const handleCancel = () => {
    navigate("/dfhm/viewdfhm");
  };

  return (
    <div className="w-full max-w-7xl mx-auto">
      {/* Title */}
      <h2 className="text-center text-xl font-semibold text-darkblue1 font-VolvoNovum mb-2">
        Create DFHM
      </h2>

      {/* Row 1 */}
      <div className="grid grid-cols-4 gap-4">
        {/* Year */}
        <div>
          <StyledSelectField
            label="Year"
            placeholder="Select Year"
            value={formData.year}
            setValue={(v) => setFormData({ ...formData, year: v })}
            options={yearOptions}
            dropdownOpen={dropdowns.year}
            setDropdownOpen={(val) => {
              if (val === true) openSingleDropdown("year");
              else setDropdowns({ ...dropdowns, year: val });
            }}
            dropdownRef={yearRef}
            error={errors.year}
          />
        </div>

        {/* Quarter */}
        <div>
          <StyledSelectField
            label="Quarter"
            placeholder="Select Quarter"
            value={formData.quarter}
            setValue={(v) => setFormData({ ...formData, quarter: v })}
            options={quarterOptions}
            dropdownOpen={dropdowns.quarter}
            setDropdownOpen={(val) => {
              if (val === true) openSingleDropdown("quarter");
              else setDropdowns({ ...dropdowns, quarter: val });
            }}
            dropdownRef={quarterRef}
            error={errors.quarter}
          />
        </div>

        {/* Market Area */}
        <div>
          <StyledSelectField
            label="Market Area"
            placeholder="Select Market Area"
            value={formData.marketArea}
            setValue={(v) => setFormData({ ...formData, marketArea: v })}
            options={marketAreaOptions}
            dropdownOpen={dropdowns.marketArea}
            setDropdownOpen={(val) => {
              if (val === true) openSingleDropdown("marketArea");
              else setDropdowns({ ...dropdowns, marketArea: val });
            }}
            dropdownRef={marketAreaRef}
            error={errors.marketArea}
          />
        </div>

        {/* Start Date */}
        <div className="mt-1.5">
          <StyledDateField
            label="Start Date"
            value={formData.startDate}
            setValue={(v) => setFormData({ ...formData, startDate: v })}
            error={errors.startDate}
          />
        </div>
      </div>

      {/* Row 2 */}
      <div className="grid grid-cols-4 gap-4 mt-4">
        {/* End Date */}
        <div className="mt-1.5">
          <StyledDateField
            label="End Date"
            value={formData.endDate}
            setValue={(v) => setFormData({ ...formData, endDate: v })}
            error={errors.endDate}
          />
        </div>

        {/* Choose Dealer */}
        <div>
          <StyledSelectField
            label="Choose Dealer"
            value={formData.chooseDealer}
            setValue={(val) => setFormData({ ...formData, chooseDealer: val })}
            options={choosedealeroptions}
            dropdownOpen={dropdowns.chooseDealer}
            setDropdownOpen={(val) => {
              if (val === true) openSingleDropdown("chooseDealer");
              else setDropdowns({ ...dropdowns, chooseDealer: val });
            }}
            dropdownRef={chooseDealerRef}
            error={errors.chooseDealer}
          />
        </div>

        {/* Dealer */}
        <div>
          <StyledSelectField
            label="Dealer"
            value={formData.dealerType}
            setValue={(val) => {
              if (formData.chooseDealer === "Individual Dealer") {
                setFormData({ ...formData, dealerType: val });
                setErrors((prev) => ({ ...prev, dealerType: "" }));
              }
            }}
            options={dealerOptions}
            disabled={
              formData.chooseDealer === "All Dealers" ||
              formData.chooseDealer === "Dealers in MA"
            }
            dropdownOpen={dropdowns.dealerType}
            setDropdownOpen={(val) => {
              if (val === true) openSingleDropdown("dealerType");
              else setDropdowns({ ...dropdowns, dealerType: val });
            }}
            dropdownRef={dealerTypeRef}
            error={errors.dealerType}
          />
        </div>
      </div>

      {/* Buttons */}
      <div className="flex justify-end mt-6 gap-4">
        <button
          type="button"
          className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium hover:bg-mildBlue1 hover:scale-105"
          onClick={handleCancel}
        >
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/cancel.png"
            alt=""
            className="w-3 h-3"
          />
          Cancel
        </button>

        <button
          className="bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition disabled:opacity-50"
          onClick={handleSave}
          disabled={saveLoading}
        >
          {saveLoading ? "Saving..." : "Save"}
        </button>
      </div>
    </div>
  );
};

export default CreateDfhm;