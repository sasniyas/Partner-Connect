import React from "react"
import Header from "../../../Components/Header"
import { useState } from "react"
import SubNavbar3 from "../../../Components/SubNavbar3"
import CreateDfhm from "./CreateDfhm"

const  CreateDfhmhome = () => {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col  ">
      {/* Header - Fixed at top */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      
      {/* SubNavbar - Fixed below header */}
      <SubNavbar3 />

      {/* Main Content */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        {/* ✅ Fixed margin-top calculation:
            - Mobile: Header (4rem = 64px) + small gap
            - Desktop: Header (5rem = 80px) + SubNavbar (4rem = 64px) + small gap
        */}
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
        <CreateDfhm/>
        </div>
      </div>
    </div>
  )
}

export default CreateDfhmhome