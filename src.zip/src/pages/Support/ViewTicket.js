import React, { useRef, useState, useMemo, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Header from "../../Components/Header";
import SubNavbar3 from "../../Components/SubNavbar3";
import { ArrowLeft } from "lucide-react";
import { ChevronDown } from "lucide-react";
import { ChevronsUpDown } from "lucide-react";
import { ChevronUp } from "lucide-react";
import { ArrowUp } from "lucide-react";
import { ArrowDown } from "lucide-react";
import { getCommentsByTicketId } from "../../services/ticketService";

const ViewTicket = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const ticket = location.state?.ticket;

  const [hoveredCell, setHoveredCell] = useState({ row: null, col: null });
  const [comments, setComments] = useState([]);
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState("asc");
  const [menuOpen, setMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const tableContainerRef = useRef(null);

  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null);
  const [lastScrollTop, setLastScrollTop] = useState(0);

  const formatDisplayDate = (dateStr) => {
    if (!dateStr || dateStr === "NA" || String(dateStr).trim() === "") return "NA";
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return "NA";
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  };

  useEffect(() => {
    const fetchComments = async () => {
      try {
        setLoading(true);
        setError(null);
        if (ticket?.id) {
          const data = await getCommentsByTicketId(ticket.id);
          setComments(data);
        }
      } catch (err) {
        console.error("Error fetching comments:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchComments();
  }, [ticket?.id]);

  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;
    if (scrollTop > lastScrollTop) { setScrollDirection('down'); }
    else if (scrollTop < lastScrollTop) { setScrollDirection('up'); }
    setLastScrollTop(scrollTop);
    setScrollPosition(scrollTop);
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: tableContainerRef.current.scrollHeight, behavior: "smooth" });
    }
  };

  const handleBack = () => navigate(-1);

  const handleAttachmentClick = (e) => {
    const attachment = e.target.closest("[data-file-url]");
    if (!attachment) return;
    const fileUrl = attachment.dataset.fileUrl;
    window.open(fileUrl, "_blank");
  };

  const getPlainText = (html) => {
    if (!html) return "";
    const div = document.createElement("div");
    div.innerHTML = html;
    div.querySelectorAll("[data-file-url]").forEach((el) => el.remove());
    return div.textContent.trim();
  };

  const getAttachments = (html) => {
    if (!html) return [];
    const div = document.createElement("div");
    div.innerHTML = html;
    const attachments = [];
    div.querySelectorAll("[data-file-url]").forEach((el) => {
      attachments.push({ name: el.dataset.fileName, url: el.dataset.fileUrl });
    });
    return attachments;
  };

  const getFileNameFromUrl = (url) => {
    if (!url) return "Attachment";
    try {
      const pathname = new URL(url).pathname;
      return decodeURIComponent(pathname.split("/").pop()) || "Attachment";
    } catch { return "Attachment"; }
  };

  // Merge attachments from description HTML + DB ticket.attachments array (deduplicated by URL)
  const getAllTicketAttachments = () => {
    const htmlAttachments = getAttachments(ticket?.description);
    const dbAttachments = (ticket?.attachments || []).map((att) => ({
      name: getFileNameFromUrl(att.attachment_url),
      url: att.attachment_url,
    }));
    const allAttachments = [...htmlAttachments];
    dbAttachments.forEach((dbAtt) => {
      if (!allAttachments.some((a) => a.url === dbAtt.url)) {
        allAttachments.push(dbAtt);
      }
    });
    return allAttachments;
  };

  const handleSortComments = (key) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortOrder("asc");
    }
  };

  const sortedComments = useMemo(() => {
    if (!sortKey) return comments;
    return [...comments].sort((a, b) => {
      let valA, valB;
      switch (sortKey) {
        case "comment":
          valA = getPlainText(a.comment);
          valB = getPlainText(b.comment);
          break;
        case "createdby":
          valA = `${a.created_by_first_name} ${a.created_by_last_name}`.trim() || a.created_by || "";
          valB = `${b.created_by_first_name} ${b.created_by_last_name}`.trim() || b.created_by || "";
          break;
        case "createdon":
          valA = new Date(a.created_at);
          valB = new Date(b.created_at);
          break;
        case "attachments":
          valA = getAttachments(a.comment).length;
          valB = getAttachments(b.comment).length;
          break;
        default:
          valA = "";
          valB = "";
      }
      if (valA < valB) return sortOrder === "asc" ? -1 : 1;
      if (valA > valB) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [comments, sortKey, sortOrder]);

  if (!ticket) {
    navigate("/support");
    return null;
  }

  const ticketAttachments = getAllTicketAttachments();

  return (
    <div className="bg-Frostwhite h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="flex items-center gap-2 mb-4">
            <ArrowLeft onClick={handleBack} size={24} className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 " />
            <h1 className="text-lg font-semibold text-darkblue1">View Ticket</h1>
          </div>
          <hr className="hidden lg:block w-[7%] border-t-4 ml-8 border-darkblue1 -mt-5 mb-4" />

          <div className="grid grid-cols-4 gap-4 text-xs mb-4">
            <Detail label="Ticket #" value={ticket.ticketNumber} />
            <Detail label="Ticket Subject" value={ticket.subject} />
            <Detail label="Issue Related To" value={ticket.issueRelated} />
            <Detail label="Created By" value={ticket.createdBy} />
            <Detail label="Created On" value={formatDisplayDate(ticket.createdOn)} />
            <Detail label="Expected Resolution Date" value={formatDisplayDate(ticket.resolutionDate)} />
            <Detail label="Priority" value={ticket.priority} />
            <Detail label="Status" value={ticket.status} />

            <div className="col-span-2">
              <label className="font-medium text-black/70">Description</label>
              <div className="border border-black/30 p-2 mt-1 min-h-[96px] text-xs bg-gray-50" onClick={handleAttachmentClick}>
                <p>{getPlainText(ticket.description)}</p>

                {ticketAttachments.length > 0 && (
                  <div className="mt-2 flex flex-col gap-1">
                    {ticketAttachments.map((att, i) => (
                      <a key={i} href={att.url} target="_blank" rel="noopener noreferrer" className="underline text-blue-600 text-xs">
                        {att.name}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="mt-4">
            <h3 className="font-semibold text-darkblue1 mb-2 text-sm">Comments & Updates</h3>
            <hr className="hidden lg:block w-[7%] border-t-4 ml-0 border-darkblue1 -mt-2 mb-4" />

            <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
              <div ref={tableContainerRef} className="overflow-y-auto overflow-x-auto scrollbar-hide"
                style={{ maxHeight: comments.length > 8 ? "calc(100vh - 240px)" : "auto" }} onScroll={handleTableScroll}>
                <table className="w-full text-xs table-fixed">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                    <tr>
                      <th className="text-left px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%] cursor-pointer" onClick={() => handleSortComments("comment")}>
                        <div className="flex items-center gap-1">
                          Comment
                          {sortKey !== "comment" && <ChevronsUpDown className="w-3 h-3 text-white" />}
                          {sortKey === "comment" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "comment" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>
                      <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">Created By</th>
                      <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">Created On</th>
                      <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[20%]">Attachments</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      <tr>
                        <td colSpan={4} className="text-center py-4">
                          <div className="flex items-center justify-center gap-2">
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                            Loading comments...
                          </div>
                        </td>
                      </tr>
                    ) : error ? (
                      <tr>
                        <td colSpan={4} className="text-center py-4 text-red-500 text-xs">
                          Error loading comments: {error}
                        </td>
                      </tr>
                    ) : comments.length > 0 ? (
                      sortedComments.map((cmt, idx) => {
                        const text = getPlainText(cmt.comment);
                        const htmlAttachments = getAttachments(cmt.comment);
                        const serverAttachment = cmt.attachment_url ? [{ name: getFileNameFromUrl(cmt.attachment_url), url: cmt.attachment_url }] : [];
                        const allAttachments = [...htmlAttachments];
                        serverAttachment.forEach((sa) => { if (!allAttachments.some((a) => a.url === sa.url)) allAttachments.push(sa); });
                        const createdByName = `${cmt.created_by_first_name || ""} ${cmt.created_by_last_name || ""}`.trim() || cmt.created_by || "-";

                        return (
                          <tr key={idx} className="border-t hover:bg-lightBlue/50">
                            <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                              <div className="relative">
                                <p className="truncate max-w-[15rem] cursor-pointer"
                                  onMouseEnter={() => { if (text && text.length > 20) setHoveredCell({ row: idx, col: 'comment' }); }}
                                  onMouseLeave={() => setHoveredCell({ row: null, col: null })}>
                                  {text || "-"}
                                </p>
                                {hoveredCell.row === idx && hoveredCell.col === 'comment' && (
                                  <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-20">{text}</span>
                                )}
                              </div>
                            </td>

                            <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                              <div className="relative">
                                <p className="truncate max-w-[10rem] cursor-pointer"
                                  onMouseEnter={() => { if (createdByName.length > 15) setHoveredCell({ row: idx, col: 'createdBy' }); }}
                                  onMouseLeave={() => setHoveredCell({ row: null, col: null })}>
                                  {createdByName}
                                </p>
                                {hoveredCell.row === idx && hoveredCell.col === 'createdBy' && (
                                  <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-20">{createdByName}</span>
                                )}
                              </div>
                            </td>

                            <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                              <div className="relative">
                                <p className="truncate max-w-[10rem] cursor-pointer"
                                  onMouseEnter={() => { if (formatDisplayDate(cmt.created_at).length > 15) setHoveredCell({ row: idx, col: 'createdOn' }); }}
                                  onMouseLeave={() => setHoveredCell({ row: null, col: null })}>
                                  {formatDisplayDate(cmt.created_at)}
                                </p>
                                {hoveredCell.row === idx && hoveredCell.col === 'createdOn' && (
                                  <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-20">{formatDisplayDate(cmt.created_at)}</span>
                                )}
                              </div>
                            </td>

                            <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                              <div className="relative">
                                {allAttachments.length ? (
                                  allAttachments.map((att, i) => (
                                    <div key={i} className="truncate max-w-[10rem] cursor-pointer">
                                      <a href={att.url} target="_blank" rel="noopener noreferrer" className="underline text-blue-600 text-xs"
                                        onMouseEnter={() => { if (att.name.length > 15) setHoveredCell({ row: idx, col: `attachment-${i}` }); }}
                                        onMouseLeave={() => setHoveredCell({ row: null, col: null })}>
                                        {att.name}
                                      </a>
                                      {hoveredCell.row === idx && hoveredCell.col === `attachment-${i}` && (
                                        <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-20">{att.name}</span>
                                      )}
                                    </div>
                                  ))
                                ) : (
                                  "-"
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan={4} className="text-center text-gray-500 px-3 py-2 italic text-xs">No comments yet</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {showScrollButtons && (
                <div className="fixed bottom-8 right-6 z-40 pointer-events-auto animate-fade-in">
                  {scrollDirection === 'down' && (
                    <button onClick={scrollToTop} className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm" aria-label="Scroll to top">
                      <ArrowUp className="w-2 h-2" />
                    </button>
                  )}
                  {scrollDirection === 'up' && (
                    <button onClick={scrollToBottom} className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm" aria-label="Scroll to bottom">
                      <ArrowDown className="w-2 h-2" />
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Detail = ({ label, value }) => (
  <div>
    <label className="font-medium text-black/70">{label}</label>
    <div className="border border-black/30 px-2 py-1 mt-1 text-xs">{value || "-"}</div>
  </div>
);

export default ViewTicket;