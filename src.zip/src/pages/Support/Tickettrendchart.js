import React, { useState, useRef, useEffect, useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import Header from "../../Components/Header";
import SubNavbar3 from "../../Components/SubNavbar3";
import { Menu, ArrowLeft, PlusIcon } from "lucide-react";
import Filter from "../../Components/Filter";
import Searchinput from "../../Components/Searchinput";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { getTicketByUserId, getAllTickets } from "../../services/ticketService";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const STATUS_COLORS = {
  Open: "#BF2012",
  "In Progress": "#D4A017",
  Closed: "#2E7D32",
};

const TicketTrendChart = () => {
  const navigate = useNavigate();
  const { data: userData } = useSelector((state) => state.user);
  const effectiveRole = userData ? userData.persona : "";
  const isAdmin = effectiveRole === "Administrator";

  const [menuOpen, setMenuOpen] = useState(false);
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showChartMenu, setShowChartMenu] = useState(false);

  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    year: [],
    issueRelated: [],
    priority: [],
    status: [],
  });

  const chartWrapperRef = useRef(null);
  const chartContainerRef = useRef(null);
  const menuRef = useRef(null);

  // ═══════════════════════════════════════════════════════
  // FETCH TICKETS
  // ═══════════════════════════════════════════════════════
  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = isAdmin ? await getAllTickets() : await getTicketByUserId();
      const transformedData = data.map((ticket) => ({
        id: ticket.id,
        ticketNumber: ticket.ticket_no,
        subject: ticket.ticket_subject,
        issueRelated: ticket.issue,
        description: ticket.description,
        createdOn: ticket.created_at,
        resolutionDate: ticket.expected_resolution_date || "NA",
        createdBy: `${ticket.submitted_by_first_name || ""} ${ticket.submitted_by_last_name || ""}`.trim(),
        priority: ticket.priority,
        status: ticket.ticket_status,
      }));
      setTickets(transformedData);
    } catch (err) {
      console.error("Error fetching tickets:", err);
      setError(err.message);
      setTickets([]);
    } finally {
      setLoading(false);
    }
  };

  // Stat cards (from ALL tickets, unfiltered)
  const totalTickets = tickets?.length || 0;
  const closedTickets = tickets?.filter((t) => t.status === "Closed" || t.status === "Resolved").length || 0;
  const openTickets = tickets?.filter((t) => t.status === "Open").length || 0;
  const newTickets = tickets?.filter((t) => t.status === "New").length || 0;
  const assignedTickets = tickets?.filter((t) => t.status === "Assigned").length || 0;

  // ═══════════════════════════════════════════════════════
  // FILTER OPTIONS (dynamic from ticket data)
  // ═══════════════════════════════════════════════════════
  const filterOptions = useMemo(() => {
    const years = [...new Set(
      tickets.map((t) => {
        const d = new Date(t.createdOn);
        return isNaN(d.getTime()) ? null : String(d.getFullYear());
      }).filter(Boolean)
    )].sort((a, b) => b - a);

    const issueOptions = [...new Set(tickets.map((t) => t.issueRelated).filter(Boolean))].sort();
    const priorityOptions = [...new Set(tickets.map((t) => t.priority).filter(Boolean))].sort();
    const statusOptions = [...new Set(tickets.map((t) => t.status).filter(Boolean))].sort();

    return { years, issueOptions, priorityOptions, statusOptions };
  }, [tickets]);

  // ═══════════════════════════════════════════════════════
  // FILTERED TICKETS (filters affect chart only)
  // ═══════════════════════════════════════════════════════
  const filteredTickets = useMemo(() => {
    return tickets.filter((t) => {
      const ticketDate = new Date(t.createdOn);
      const ticketYear = isNaN(ticketDate.getTime()) ? null : String(ticketDate.getFullYear());

      const matchYear = !filters.year?.length || filters.year.includes(ticketYear);
      const matchIssue = !filters.issueRelated?.length || filters.issueRelated.includes(t.issueRelated);
      const matchPriority = !filters.priority?.length || filters.priority.includes(t.priority);
      const matchStatus = !filters.status?.length || filters.status.includes(t.status);
      const matchSearch =
        !searchTerm ||
        t.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.ticketNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.createdBy?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.issueRelated?.toLowerCase().includes(searchTerm.toLowerCase());

      return matchYear && matchIssue && matchPriority && matchStatus && matchSearch;
    });
  }, [tickets, filters, searchTerm]);

  // ═══════════════════════════════════════════════════════
  // CHART DATA
  // ═══════════════════════════════════════════════════════
  const chartData = useMemo(() => {
    const monthMap = {};
    MONTHS.forEach((m, i) => {
      monthMap[i] = { month: m, Open: 0, "In Progress": 0, Closed: 0 };
    });

    filteredTickets.forEach((t) => {
      const d = new Date(t.createdOn);
      if (isNaN(d.getTime())) return;
      const monthIdx = d.getMonth();
      const status = t.status;

      if (status === "Open" || status === "New") {
        monthMap[monthIdx].Open += 1;
      } else if (status === "In Progress") {
        monthMap[monthIdx]["In Progress"] += 1;
      } else if (status === "Closed" || status === "Resolved") {
        monthMap[monthIdx].Closed += 1;
      }
    });

    return Object.values(monthMap);
  }, [filteredTickets]);

  // ═══════════════════════════════════════════════════════
  // CUSTOM TOOLTIP
  // ═══════════════════════════════════════════════════════
  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload || payload.length === 0) return null;

    const selectedYear =
      filters.year?.length === 1
        ? filters.year[0]
        : filters.year?.length > 1
        ? filters.year.join("/")
        : new Date().getFullYear();

    return (
      <div className="bg-white p-3 border border-gray-300 shadow-lg min-w-[160px]">
        <p className="font-semibold text-gray-800 mb-2 text-sm">{selectedYear} - {label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-xs mb-0.5" style={{ color: entry.fill }}>
            {entry.name}: <span className="font-semibold">{entry.value}</span>
          </p>
        ))}
      </div>
    );
  };

  // ═══════════════════════════════════════════════════════
  // CLOSE MENU ON OUTSIDE CLICK
  // ═══════════════════════════════════════════════════════
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowChartMenu(false);
      }
    };
    if (showChartMenu) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showChartMenu]);

  // ═══════════════════════════════════════════════════════
  // EXPORT HANDLERS
  // ═══════════════════════════════════════════════════════
  const exportChartAsImage = (format = "png") => {
    if (!chartContainerRef.current) return;
    try {
      const svg = chartContainerRef.current.querySelector("svg");
      if (!svg) return;
      const clonedSvg = svg.cloneNode(true);
      const svgRect = svg.getBoundingClientRect();
      const canvas = document.createElement("canvas");
      const scale = 2;
      canvas.width = svgRect.width * scale;
      canvas.height = svgRect.height * scale;
      const ctx = canvas.getContext("2d");
      ctx.scale(scale, scale);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, svgRect.width, svgRect.height);
      const svgString = new XMLSerializer().serializeToString(clonedSvg);
      const svgBlob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
      const svgUrl = URL.createObjectURL(svgBlob);
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, svgRect.width, svgRect.height);
        canvas.toBlob(
          (blob) => {
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.download = `ticket-trend-chart.${format}`;
            link.href = url;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            URL.revokeObjectURL(svgUrl);
          },
          format === "jpeg" ? "image/jpeg" : "image/png",
          format === "jpeg" ? 0.95 : undefined
        );
      };
      img.onerror = () => { alert("Error exporting chart."); URL.revokeObjectURL(svgUrl); };
      img.src = svgUrl;
    } catch (err) {
      console.error("Error exporting chart:", err);
      alert("Error exporting chart. Please try again.");
    }
    setShowChartMenu(false);
  };

  const handleExportPNG = () => exportChartAsImage("png");
  const handleExportJPEG = () => exportChartAsImage("jpeg");

  const handleExportSVG = () => {
    if (!chartContainerRef.current) return;
    try {
      const svg = chartContainerRef.current.querySelector("svg");
      if (svg) {
        const svgData = new XMLSerializer().serializeToString(svg);
        const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.download = "ticket-trend-chart.svg";
        link.href = url;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }
    } catch (err) {
      console.error("Error exporting SVG:", err);
    }
    setShowChartMenu(false);
  };

  const handleExportPDF = () => {
    alert("PDF export functionality will be implemented with a PDF library.");
    setShowChartMenu(false);
  };

  const handlePrint = () => {
    if (!chartContainerRef.current) { setShowChartMenu(false); return; }
    try {
      const svg = chartContainerRef.current.querySelector("svg");
      if (!svg) { setShowChartMenu(false); return; }
      const svgClone = svg.cloneNode(true);
      const printWindow = window.open("", "", "width=900,height=600");
      printWindow.document.write(`
        <html>
          <head>
            <title>Ticket Trends</title>
            <style>
              body { margin: 20px; font-family: Arial, sans-serif; text-align: center; }
              h2 { margin-bottom: 20px; }
              svg { max-width: 100%; height: auto; }
              @media print { body { margin: 0; } }
            </style>
          </head>
          <body>
            <h2>Ticket Trends</h2>
            ${new XMLSerializer().serializeToString(svgClone)}
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => printWindow.print(), 300);
    } catch (err) {
      console.error("Error printing chart:", err);
    }
    setShowChartMenu(false);
  };

  const handleFullScreen = () => {
    if (chartWrapperRef.current) {
      if (chartWrapperRef.current.requestFullscreen) chartWrapperRef.current.requestFullscreen();
      else if (chartWrapperRef.current.webkitRequestFullscreen) chartWrapperRef.current.webkitRequestFullscreen();
      else if (chartWrapperRef.current.mozRequestFullScreen) chartWrapperRef.current.mozRequestFullScreen();
      else if (chartWrapperRef.current.msRequestFullscreen) chartWrapperRef.current.msRequestFullscreen();
    }
    setShowChartMenu(false);
  };

  const handleDownloadCSV = () => {
    try {
      if (chartData.length === 0) { alert("No chart data to download"); return; }
      const headers = ["Month", "Open", "In Progress", "Closed"];
      const csvContent = [
        headers.join(","),
        ...chartData.map((row) => [row.month, row.Open, row["In Progress"], row.Closed].join(",")),
      ].join("\n");
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.download = "ticket-trend-data.csv";
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Error downloading CSV:", err);
    }
    setShowChartMenu(false);
  };

  const handleViewDataTable = () => {
    if (chartData.length === 0) { alert("No chart data to display"); setShowChartMenu(false); return; }
    const tableWindow = window.open("", "", "width=800,height=600");
    tableWindow.document.write(`
      <html>
        <head>
          <title>Ticket Trends - Data Table</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #6B8CA8; color: white; }
            tr:nth-child(even) { background-color: #f2f2f2; }
          </style>
        </head>
        <body>
          <h2>Ticket Trends - Data Table</h2>
          <table>
            <thead><tr><th>Month</th><th>Open</th><th>In Progress</th><th>Closed</th></tr></thead>
            <tbody>
              ${chartData.map((row) => `<tr><td>${row.month}</td><td>${row.Open}</td><td>${row["In Progress"]}</td><td>${row.Closed}</td></tr>`).join("")}
            </tbody>
          </table>
        </body>
      </html>
    `);
    tableWindow.document.close();
    setShowChartMenu(false);
  };

  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  // ═══════════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════════
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">

          {/* ═══════════ TOP BAR ═══════════ */}
          <div className="flex items-center justify-between w-full">
            {/* LEFT: Back Arrow + Heading */}
            <div className="flex items-center gap-2">
              <ArrowLeft
                onClick={() => navigate("/support")}
                size={24}
                className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
              />
              <h2 className="text-lg font-semibold text-darkblue1 font-VolvoNovum">
                My Support
              </h2>
            </div>

            {/* MIDDLE: Stat Cards */}
            <div className="px-6">
              <div className="bg-white shadow-[0_4px_10px_#0000001A] py-1">
                <div className="grid grid-cols-5 text-center gap-2">
                  {[
                    { title: "Total Tickets", value: totalTickets },
                    { title: "Closed Ticket", value: closedTickets },
                    { title: "Open Tickets", value: openTickets },
                    { title: "New Tickets", value: newTickets },
                    { title: "Assigned Tickets", value: assignedTickets },
                  ].map((item, i) => (
                    <div
                      key={i}
                      className={`py-0 px-3 ${i < 4 ? "border-r border-darkblue1" : ""} flex flex-col items-center justify-center`}
                    >
                      <div className="text-xs font-medium text-black">{item.title}</div>
                      <div className="text-sm font-semibold text-SteelBlue1 mt-1">{item.value ?? 0}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* RIGHT: Buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate("/support")}
                className="h-8 px-4 bg-white text-darkblue1 border border-darkblue1 font-VlovoNovum text-xs font-medium flex items-center justify-center gap-2 transition duration-200 hover:bg-darkblue1 hover:text-white group flex-1"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="12" viewBox="0 0 16 12" fill="none" className="w-3 h-3 transition duration-200">
                  <path d="M15.5 10H2V0.5C2 0.22375 1.77625 0 1.5 0H0.5C0.22375 0 0 0.22375 0 0.5V11C0 11.5522 0.447812 12 1 12H15.5C15.7762 12 16 11.7762 16 11.5V10.5C16 10.2238 15.7762 10 15.5 10ZM14.5 1H10.8106C10.1425 1 9.80781 1.80781 10.2803 2.28031L11.2928 3.29281L9 5.58594L6.70719 3.29313C6.31656 2.9025 5.68344 2.9025 5.29313 3.29313L3.14656 5.43969C2.95125 5.635 2.95125 5.95156 3.14656 6.14688L3.85344 6.85375C4.04875 7.04906 4.36531 7.04906 4.56063 6.85375L6 5.41406L8.29281 7.70687C8.68344 8.0975 9.31656 8.0975 9.70687 7.70687L12.7069 4.70687L13.7194 5.71938C14.1919 6.19187 14.9997 5.85719 14.9997 5.18906V1.5C15 1.22375 14.7762 1 14.5 1Z" fill="currentColor"/>
                </svg>
                <span className="whitespace-nowrap">Trend Chart</span>
              </button>

              <button
                onClick={() => navigate("/support")}
                className="h-8 px-4 bg-darkblue1 text-white font-VlovoNovum text-xs font-semibold flex items-center justify-center gap-2 border border-transparent transition duration-200 hover:bg-white hover:text-darkblue1 hover:border-darkblue1 group whitespace-nowrap"
              >
                <PlusIcon className="w-3 h-3 transition duration-200 font-bold group-hover:filter group-hover:brightness-0 group-hover:saturate-100" />
                <span>Create New Tickets</span>
              </button>
            </div>
          </div>

          <hr className="hidden lg:block w-[7%] border-t-4 -mt-4 border-darkblue1 mb-4" />

          {/* ═══════════ FILTERS ═══════════ */}
          <div className="hidden lg:flex w-full items-center gap-2 mb-3">
            <div className="w-[100px]">
              <Searchinput
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
                className="w-full"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                focusRing="focus:ring-black/60"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-2 sm:py-3"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                iconColor="text-black"
              />
            </div>

            <Filter
              name="year"
              value={filters.year}
              options={filterOptions.years}
              onChange={handleFilterChange}
              placeholder="Year"
              placeholderColor="text-black"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-[120px]"
            />

            <Filter
              name="issueRelated"
              value={filters.issueRelated}
              options={filterOptions.issueOptions}
              onChange={handleFilterChange}
              placeholder="Issue Related To"
              placeholderColor="text-black"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-[200px]"
            />

            <Filter
              name="priority"
              value={filters.priority}
              options={filterOptions.priorityOptions}
              onChange={handleFilterChange}
              placeholder="Priority"
              placeholderColor="text-black"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-[120px]"
            />

            <Filter
              name="status"
              value={filters.status}
              options={filterOptions.statusOptions}
              onChange={handleFilterChange}
              placeholder="Ticket Status"
              placeholderColor="text-black"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-[150px]"
            />
          </div>

          {/* ═══════════ CHART SECTION ═══════════ */}
          <div
            className="bg-white shadow-md border border-gray-200 p-4 sm:p-6 relative"
            ref={chartWrapperRef}
          >
            {/* Title + Menu */}
            <div className="flex items-center justify-between mb-2">
              <div className="flex-1" />
              <h2 className="text-base sm:text-lg font-semibold text-gray-800 font-VolvoNovum text-center flex-1">
                Ticket Trends
              </h2>
              <div className="flex-1 flex justify-end">
                <div className="relative" ref={menuRef}>
                  <button
                    onClick={() => setShowChartMenu(!showChartMenu)}
                    className="p-1 hover:bg-gray-100 transition"
                    aria-label="Chart options"
                  >
                    <Menu size={18} className="text-gray-600" />
                  </button>

                  {showChartMenu && (
                    <div className="absolute right-0 top-full mt-2 w-56 bg-white border border-gray-200 rounded shadow-lg z-50">
                      <button onClick={handleFullScreen} className="w-full px-4 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                        </svg>
                        View in full screen
                      </button>
                      <button onClick={handlePrint} className="w-full px-4 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                        </svg>
                        Print chart
                      </button>
                      <div className="border-t border-gray-200 my-1" />
                      <button onClick={handleExportPNG} className="w-full px-4 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50">
                        Download PNG image
                      </button>
                      <button onClick={handleExportJPEG} className="w-full px-4 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50">
                        Download JPEG image
                      </button>
                      <button onClick={handleExportSVG} className="w-full px-4 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50">
                        Download SVG vector image
                      </button>
                      <button onClick={handleExportPDF} className="w-full px-4 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50">
                        Download PDF document
                      </button>
                      <div className="border-t border-gray-200 my-1" />
                      <button onClick={handleDownloadCSV} className="w-full px-4 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50">
                        Download CSV
                      </button>
                      <button onClick={handleViewDataTable} className="w-full px-4 py-1.5 text-left text-xs text-gray-700 hover:bg-gray-50">
                        View data table
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Chart - Always shows all 3 status bars */}
            {loading ? (
              <div className="flex flex-col items-center justify-center h-[350px] text-gray-400">
                <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-gray-500 mb-4" />
                <p className="text-sm font-medium">Loading chart data...</p>
              </div>
            ) : (
              <div ref={chartContainerRef}>
                <ResponsiveContainer width="100%" height={350}>
                  <BarChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={{ stroke: "#e5e7eb" }} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={{ stroke: "#333" }} tickLine={false} allowDecimals={false} />
                    <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(0, 0, 0, 0.05)" }} />
                    <Bar dataKey="Open" fill={STATUS_COLORS.Open} maxBarSize={30} radius={[2, 2, 0, 0]} />
                    <Bar dataKey="In Progress" fill={STATUS_COLORS["In Progress"]} maxBarSize={30} radius={[2, 2, 0, 0]} />
                    <Bar dataKey="Closed" fill={STATUS_COLORS.Closed} maxBarSize={30} radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TicketTrendChart;