import React, { useState, useRef } from "react";
import Header from "../../Components/Header";
import SubNavbar3 from "../../Components/SubNavbar3";
import { useNavigate, useLocation } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import StyledSelectField from "../../Components/StyledSelectField";
import StyledDateField from "../../Components/StyledDatefield";
import { formatDateInput } from "../../services/PDP/CrudPdp/crudPdp.service";
import { useEffect } from "react";
import { ChevronUp } from "lucide-react";
import { ChevronDown } from "lucide-react";
import { ChevronsUpDown } from "lucide-react";
import { ArrowUp } from "lucide-react";
import { ArrowDown } from "lucide-react";
import {
  Bold,
  Italic,
  Underline,
  List,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Copy,
  RotateCcw,
} from "lucide-react";
import { formatDateOnly } from "../../util/timeFormat";
import { addTicketComment, getCommentsByTicketId, updateTicket } from "../../services/ticketService";

const CriteriaDefinitionEditor = ({ value, onChange, className = "", onPendingFilesChange }) => {
  const [fontSize, setFontSize] = useState("12");
  const [fontFamily, setFontFamily] = useState("Segoe UI");
  const [activeFormats, setActiveFormats] = useState({
    bold: false,
    italic: false,
    underline: false,
    unorderedList: false,
    orderedList: false,
  });

  const editorRef = useRef(null);
  const [attachments, setAttachments] = useState([]);
  const [dropdowns, setDropdowns] = useState({
    fontFamily: false,
    fontSize: false,
  });
  const dropdownRefs = { fontFamily: useRef(null), fontSize: useRef(null) };

  const fontFamilyOptions = [
    { value: "Segoe UI", label: "Segoe UI" },
    { value: "Arial", label: "Arial" },
    { value: "Roboto", label: "Roboto" },
    { value: "Times New Roman", label: "Times New Roman" },
  ];

  const fontSizeOptions = ["12", "14", "16", "18", "20", "24", "28", "32"];

  const executeCommand = (command, val = null) => {
    document.execCommand(command, false, val);
    editorRef.current?.focus();
  };

  const handleContentChange = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const handleFileAttach = (files) => {
    if (!editorRef.current) return;

    const filesArray = Array.from(files).map((file) => ({
      id: Date.now() + Math.random(),
      name: file.name,
      file,
    }));

    const updatedAttachments = [...attachments, ...filesArray];
    setAttachments(updatedAttachments);

    // Notify parent about pending files (actual File objects for later upload)
    if (onPendingFilesChange) {
      onPendingFilesChange(updatedAttachments.map((a) => a.file));
    }

    filesArray.forEach((att) => {
      const span = document.createElement("span");
      span.contentEditable = "false";
      span.dataset.pendingFile = "true";
      span.dataset.fileName = att.name;
      span.dataset.fileId = String(att.id);
      span.className =
        "inline-flex items-center gap-2 px-2 py-1 bg-gray-200 text-xs mr-1 mt-2 rounded cursor-pointer hover:bg-gray-300";

      span.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none">
          <path d="M4.177 5.50694V11.139C4.177 12.2468 4.61708 13.3092 5.40042 14.0926C6.18377 14.8759 7.24621 15.316 8.35402 15.316C9.46183 15.316 10.5243 14.8759 11.3076 14.0926C12.091 13.3092 12.531 12.2468 12.531 11.139V4.17726C12.531 3.43871 12.2377 2.73042 11.7154 2.20819C11.1932 1.68596 10.4849 1.39258 9.74636 1.39258C9.00782 1.39258 8.29952 1.68596 7.77729 2.20819C7.25507 2.73042 6.96168 3.43871 6.96168 4.17726V10.5695C6.96168 10.7523 6.99769 10.9334 7.06767 11.1023C7.13764 11.2712 7.2402 11.4247 7.36949 11.554C7.49878 11.6833 7.65227 11.7859 7.8212 11.8558C7.99012 11.9258 8.17118 11.9618 8.35402 11.9618C8.72329 11.9618 9.07744 11.8151 9.33855 11.554C9.59967 11.2929 9.74636 10.9388 9.74636 10.5695V5.5696" stroke="black" stroke-width="0.835404" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        ${att.name}
        <button data-id="${att.id}" class="remove-btn text-red-500 font-bold text-xs ml-1 flex-shrink-0">
          <svg width="14" height="14" viewBox="0 0 20 20">
            <circle cx="10" cy="10" r="8" fill="#BF2012" />
            <path d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5" stroke="white" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </button>
      `;

      span.querySelector(".remove-btn")?.addEventListener("click", (e) => {
        e.stopPropagation();
        setAttachments((prev) => {
          const updated = prev.filter((a) => a.id !== att.id);
          if (onPendingFilesChange) {
            onPendingFilesChange(updated.map((a) => a.file));
          }
          return updated;
        });
        span.remove();
        const sel = window.getSelection();
        const range = document.createRange();
        range.setStart(editorRef.current, editorRef.current.childNodes.length);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
        editorRef.current.focus();
        handleContentChange();
      });

      editorRef.current.appendChild(span);
      const space = document.createTextNode("\u00A0");
      editorRef.current.appendChild(space);

      const sel = window.getSelection();
      const range = document.createRange();
      range.setStartAfter(space);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
      editorRef.current.focus();
    });

    handleContentChange();
  };

  // Reset attachments (called by parent after successful comment submit)
  useEffect(() => {
    if (value === "") {
      setAttachments([]);
    }
  }, [value]);

  const updateActiveFormats = () => {
    if (!editorRef.current) return;
    setActiveFormats({
      bold: document.queryCommandState("bold"),
      italic: document.queryCommandState("italic"),
      underline: document.queryCommandState("underline"),
      unorderedList: document.queryCommandState("insertUnorderedList"),
      orderedList: document.queryCommandState("insertOrderedList"),
    });
  };

  useEffect(() => {
    if (editorRef.current && value !== editorRef.current.innerHTML) {
      editorRef.current.innerHTML = value || "";
    }
  }, [value]);

  return (
    <div className="border border-gray-300 overflow-hidden bg-white">
      <div className="border-b border-gray-200 py-0 px-2 bg-gray-50">
        <div className="flex flex-wrap gap-4 mb-2">
          <div className="w-40">
            <StyledSelectField value={fontFamily} setValue={setFontFamily} options={fontFamilyOptions}
              dropdownOpen={dropdowns.fontFamily} setDropdownOpen={(val) => setDropdowns((prev) => ({ ...prev, fontFamily: val }))}
              dropdownRef={dropdownRefs.fontFamily} />
          </div>
          <div className="w-20">
            <StyledSelectField value={fontSize} setValue={setFontSize}
              options={fontSizeOptions.map((size) => ({ label: size, value: size }))}
              dropdownOpen={dropdowns.fontSize} setDropdownOpen={(val) => setDropdowns((prev) => ({ ...prev, fontSize: val }))}
              dropdownRef={dropdownRefs.fontSize} />
          </div>
          <div className="flex flex-wrap gap-0 items-center">
            <ToolbarButton icon={<Bold size={16} />} label="Bold" isActive={activeFormats.bold}
              onClick={() => { executeCommand("bold"); handleContentChange(); updateActiveFormats(); }} />
            <ToolbarButton icon={<Italic size={16} />} label="Italic" isActive={activeFormats.italic}
              onClick={() => { executeCommand("italic"); handleContentChange(); updateActiveFormats(); }} />
            <ToolbarButton icon={<Underline size={16} />} label="Underline" isActive={activeFormats.underline}
              onClick={() => { executeCommand("underline"); handleContentChange(); updateActiveFormats(); }} />
            <ToolbarButton icon={<List size={16} />} label="Bullet List" isActive={activeFormats.unorderedList}
              onClick={() => {
                if (editorRef.current?.innerHTML.trim() === "") { editorRef.current.innerHTML = "<ul><li><br></li></ul>"; }
                else { executeCommand("insertUnorderedList"); }
                handleContentChange(); updateActiveFormats();
              }} />
            <ToolbarButton icon={<span className="text-sm font-bold">1.</span>} label="Numbered List" isActive={activeFormats.orderedList}
              onClick={() => {
                if (editorRef.current?.innerHTML.trim() === "") { editorRef.current.innerHTML = "<ol><li><br></li></ol>"; }
                else { executeCommand("insertOrderedList"); }
                handleContentChange(); updateActiveFormats();
              }} />
            <ToolbarButton icon={<AlignLeft size={16} />} label="Align Left" onClick={() => { executeCommand("justifyLeft"); handleContentChange(); }} />
            <ToolbarButton icon={<AlignCenter size={16} />} label="Align Center" onClick={() => { executeCommand("justifyCenter"); handleContentChange(); }} />
            <ToolbarButton icon={<AlignRight size={16} />} label="Align Right" onClick={() => { executeCommand("justifyRight"); handleContentChange(); }} />
            <ToolbarButton
              icon={<span className="text-lg"><svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none">
                <path d="M4.177 5.50694V11.139C4.177 12.2468 4.61708 13.3092 5.40042 14.0926C6.18377 14.8759 7.24621 15.316 8.35402 15.316C9.46183 15.316 10.5243 14.8759 11.3076 14.0926C12.091 13.3092 12.531 12.2468 12.531 11.139V4.17726C12.531 3.43871 12.2377 2.73042 11.7154 2.20819C11.1932 1.68596 10.4849 1.39258 9.74636 1.39258C9.00782 1.39258 8.29952 1.68596 7.77729 2.20819C7.25507 2.73042 6.96168 3.43871 6.96168 4.17726V10.5695C6.96168 10.7523 6.99769 10.9334 7.06767 11.1023C7.13764 11.2712 7.2402 11.4247 7.36949 11.554C7.49878 11.6833 7.65227 11.7859 7.8212 11.8558C7.99012 11.9258 8.17118 11.9618 8.35402 11.9618C8.72329 11.9618 9.07744 11.8151 9.33855 11.554C9.59967 11.2929 9.74636 10.9388 9.74636 10.5695V5.5696" stroke="black" strokeWidth="0.835404" strokeLinecap="round" strokeLinejoin="round"/></svg></span>}
              label="Attach File"
              onClick={() => document.getElementById("editFileInput")?.click()} />
            <input id="editFileInput" type="file" multiple className="hidden"
              onChange={(e) => { if (e.target.files) handleFileAttach(e.target.files); e.target.value = ""; }} />
            <ToolbarButton icon={<Copy size={16} />} label="Copy" onClick={() => executeCommand("copy")} />
            <ToolbarButton icon={<RotateCcw size={16} />} label="Undo" onClick={() => { executeCommand("undo"); handleContentChange(); updateActiveFormats(); }} />
          </div>
        </div>
      </div>
      <div ref={editorRef} contentEditable className={`min-h-[100px] p-4 focus:outline-none border ${className}`}
        style={{ fontSize: fontSize + "px", fontFamily: fontFamily }}
        onInput={handleContentChange} onBlur={handleContentChange} onKeyUp={updateActiveFormats}
        onMouseUp={updateActiveFormats} onFocus={updateActiveFormats} suppressContentEditableWarning={true} />
    </div>
  );
};

const ToolbarButton = ({ icon, label, isActive = false, onClick }) => (
  <div className="relative group">
    <button type="button" className={"p-1.5 focus:outline-none hover:bg-gray-200 " + (isActive ? "border border-black" : "")}
      onMouseDown={(e) => e.preventDefault()} onClick={onClick}>{icon}</button>
    <span className="absolute top-full left-1/2 -translate-x-1/2 mt-0 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 z-0 whitespace-nowrap">{label}</span>
  </div>
);

const statusOptions = [
  { label: "New", value: "New" },
  { label: "Open", value: "Open" },
  { label: "In Progress", value: "In Progress" },
  { label: "Closed", value: "Closed" },
];

const EditTicket = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const ticket = location.state?.ticket;

  const [newCommentText, setNewCommentText] = useState("");
  const [pendingFiles, setPendingFiles] = useState([]);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const handleBack = () => navigate(-1);
  const tableContainerRef = useRef(null);

  const [form, setForm] = useState({ status: ticket?.status || "", resolutionDate: ticket?.resolutionDate || "" });
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState("asc");
  const [hoveredCell, setHoveredCell] = useState({ row: null, col: null });
  const [errors, setErrors] = useState({});
  const [dropdowns, setDropdowns] = useState({ status: false });
  const refs = { status: useRef(null) };
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null);
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    const fetchComments = async () => {
      try {
        setLoading(true); setError(null);
        if (ticket?.id) { const data = await getCommentsByTicketId(ticket.id); setComments(data); }
      } catch (err) { console.error("Error fetching comments:", err); setError(err.message); }
      finally { setLoading(false); }
    };
    fetchComments();
  }, [ticket?.id]);

  const handleTableScroll = (e) => {
    const container = e.target; const scrollTop = container.scrollTop;
    if (scrollTop > lastScrollTop) { setScrollDirection("down"); } else if (scrollTop < lastScrollTop) { setScrollDirection("up"); }
    setLastScrollTop(scrollTop); setScrollPosition(scrollTop);
    const isScrollable = container.scrollHeight > container.clientHeight;
    setShowScrollButtons(isScrollable && scrollTop > 100);
  };

  const scrollToTop = () => { tableContainerRef.current?.scrollTo({ top: 0, behavior: "smooth" }); };
  const scrollToBottom = () => { tableContainerRef.current?.scrollTo({ top: tableContainerRef.current.scrollHeight, behavior: "smooth" }); };
  const handleChange = (field, value) => { setForm((prev) => ({ ...prev, [field]: value })); };

  // Helper: strip pending file spans from comment HTML
  const getCleanComment = (html) => {
    if (!html) return "";
    const div = document.createElement("div");
    div.innerHTML = html;
    div.querySelectorAll("[data-pending-file]").forEach((el) => el.remove());
    return div.innerHTML.trim();
  };

  const handleAddComment = async () => {
    const cleanComment = getCleanComment(newCommentText);
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = cleanComment;
    const hasText = tempDiv.textContent.trim().length > 0;
    const hasFiles = pendingFiles.length > 0;

    if (!hasText && !hasFiles) return;

    try {
      setUpdating(true);
      // Pass clean comment (no pending spans) + pending files
      const commentData = { comment: cleanComment };
      const result = await addTicketComment(ticket.id, commentData, pendingFiles);

      const newComment = {
        id: result.id, ticket_id: result.ticket_id, created_by: result.created_by,
        comment: result.comment, attachment_url: result.attachment_url || null,
        created_at: result.created_at, created_by_first_name: "", created_by_last_name: "",
      };
      setComments((prev) => [...prev, newComment]);
      setNewCommentText("");
      setPendingFiles([]);
    } catch (err) { console.error("Error adding comment:", err); alert("Error adding comment: " + err.message); }
    finally { setUpdating(false); }
  };

  const handleSortComments = (key) => {
    if (sortKey === key) { setSortOrder(sortOrder === "asc" ? "desc" : "asc"); }
    else { setSortKey(key); setSortOrder("asc"); }
  };

  const formatDateToYMD = (dateStr) => {
    if (!dateStr || dateStr === "NA" || dateStr.trim() === "") return null;
    const d = new Date(dateStr); if (isNaN(d.getTime())) return null;
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };

  const formatDisplayDate = (dateStr) => {
    if (!dateStr || dateStr === "NA" || String(dateStr).trim() === "") return "NA";
    const d = new Date(dateStr); if (isNaN(d.getTime())) return "NA";
    return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${d.getFullYear()}`;
  };

  const handleUpdateTicket = async () => {
    if (!form.status) { alert("Please select a status"); return; }
    try {
      setUpdating(true);
      await updateTicket({ id: ticket.id, ticket_status: form.status, expected_resolution_date: formatDateToYMD(form.resolutionDate) });
      navigate("/support");
    } catch (err) { console.error("Error updating ticket:", err); alert("Error updating ticket: " + err.message); }
    finally { setUpdating(false); }
  };

  const getPlainText = (html) => {
    if (!html) return "";
    const div = document.createElement("div"); div.innerHTML = html;
    div.querySelectorAll("[data-file-url]").forEach((el) => el.remove());
    div.querySelectorAll("[data-pending-file]").forEach((el) => el.remove());
    return div.textContent.trim();
  };

  const getAttachments = (html) => {
    if (!html) return [];
    const div = document.createElement("div"); div.innerHTML = html;
    return Array.from(div.querySelectorAll("[data-file-url]")).map((el) => ({ name: el.dataset.fileName, url: el.dataset.fileUrl }));
  };

  const getFileNameFromUrl = (url) => {
    if (!url) return "Attachment";
    try { const pathname = new URL(url).pathname; return decodeURIComponent(pathname.split("/").pop()) || "Attachment"; }
    catch { return "Attachment"; }
  };

  // Merge attachments from description HTML + DB ticket.attachments array (deduplicated by URL)
  const getAllTicketAttachments = () => {
    const htmlAttachments = getAttachments(ticket?.description);
    const dbAttachments = (ticket?.attachments || []).map((att) => ({
      name: getFileNameFromUrl(att.attachment_url),
      url: att.attachment_url,
    }));
    const allAttachments = [...htmlAttachments];
    dbAttachments.forEach((dbAtt) => {
      if (!allAttachments.some((a) => a.url === dbAtt.url)) {
        allAttachments.push(dbAtt);
      }
    });
    return allAttachments;
  };

  const sortedComments = React.useMemo(() => {
    if (!sortKey) return comments;
    return [...comments].sort((a, b) => {
      let valA, valB;
      switch (sortKey) {
        case "comment": valA = getPlainText(a.comment); valB = getPlainText(b.comment); break;
        case "createdby":
          valA = `${a.created_by_first_name} ${a.created_by_last_name}`.trim() || a.created_by || "";
          valB = `${b.created_by_first_name} ${b.created_by_last_name}`.trim() || b.created_by || "";
          break;
        case "createdon": valA = new Date(a.created_at); valB = new Date(b.created_at); break;
        default: valA = ""; valB = "";
      }
      if (valA < valB) return sortOrder === "asc" ? -1 : 1;
      if (valA > valB) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [comments, sortKey, sortOrder]);

  if (!ticket) {
    return (
      <div className="bg-Frostwhite min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 mb-4">No ticket found</p>
          <button onClick={() => navigate("/support")} className="bg-darkblue1 text-white px-4 py-2 rounded hover:bg-darkblue1/80">Back to Support</button>
        </div>
      </div>
    );
  }

  const ticketAttachments = getAllTicketAttachments();

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header />
      <SubNavbar3 />
      <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
        <div className="flex items-center gap-2 mb-4">
          <ArrowLeft onClick={handleBack} size={24} className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1" />
          <h1 className="text-lg font-semibold text-darkblue1">Edit Ticket</h1>
        </div>
        <hr className="hidden lg:block w-[7%] border-t-4 ml-8 border-darkblue1 -mt-3 mb-4" />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6 p-4 bg-white border border-black/30 shadow">
          <Info label="Ticket Number" value={ticket?.ticketNumber || "N/A"} />
          <Info label="Ticket Subject" value={ticket?.subject || "N/A"} />
          <Info label="Issue Related To" value={ticket?.issueRelated || "N/A"} />
          <Info label="Created By" value={ticket?.createdBy || "N/A"} />
          <Info label="Created On" value={formatDisplayDate(ticket?.createdOn) || "N/A"} />
          <Info label="Priority" value={ticket?.priority || "N/A"} valueClass="text-red-600 font-semibold" />
          <Info label="Ticket Status" value={ticket?.status || "N/A"} />

          <div className="col-span-2">
            <p className="text-sm text-darkblue1 font-bold mb-1">Description</p>
            <p className="text-gray-800 text-xs whitespace-pre-wrap">{getPlainText(ticket?.description) || "N/A"}</p>
          </div>

          <div className="col-span-2 mt-2">
            <p className="text-sm text-darkblue1 font-bold mb-1">Attachments</p>
            <div className="flex flex-wrap gap-2">
              {ticketAttachments.length > 0 ? (
                ticketAttachments.map((att, idx) => (
                  <a key={idx} href={att.url} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1 bg-gray-200 text-gray-800 text-xs px-2 py-1 rounded hover:bg-gray-300 transition">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none">
                      <path d="M4.177 5.50694V11.139C4.177 12.2468 4.61708 13.3092 5.40042 14.0926C6.18377 14.8759 7.24621 15.316 8.35402 15.316C9.46183 15.316 10.5243 14.8759 11.3076 14.0926C12.091 13.3092 12.531 12.2468 12.531 11.139V4.17726C12.531 3.43871 12.2377 2.73042 11.7154 2.20819C11.1932 1.68596 10.4849 1.39258 9.74636 1.39258C9.00782 1.39258 8.29952 1.68596 7.77729 2.20819C7.25507 2.73042 6.96168 3.43871 6.96168 4.17726V10.5695C6.96168 10.7523 6.99769 10.9334 7.06767 11.1023C7.13764 11.2712 7.2402 11.4247 7.36949 11.554C7.49878 11.6833 7.65227 11.7859 7.8212 11.8558C7.99012 11.9258 8.17118 11.9618 8.35402 11.9618C8.72329 11.9618 9.07744 11.8151 9.33855 11.554C9.59967 11.2929 9.74636 10.9388 9.74636 10.5695V5.5696" stroke="black" strokeWidth="0.835404" strokeLinecap="round" strokeLinejoin="round"/></svg></span>
                    <span>{att.name}</span>
                  </a>
                ))
              ) : (
                <p className="text-xs text-gray-500">No attachments</p>
              )}
            </div>
          </div>
        </div>

        <div className="bg-white p-4 border border-black/30 shadow mb-2">
          <h3 className="font-bold mb-4 text-base text-darkblue1">Comments & Updates</h3>
          <hr className="hidden lg:block w-[7%] border-t-4 ml-0 border-darkblue1 -mt-4 mb-4" />

          <div className="grid grid-cols-4 gap-4 mb-4">
            <div className="col-span-1">
              <StyledSelectField label="Change Status" placeholder="Select status" value={form.status}
                setValue={(val) => handleChange("status", val)} options={statusOptions}
                dropdownOpen={dropdowns.status} setDropdownOpen={(val) => setDropdowns((prev) => ({ ...prev, status: val }))}
                dropdownRef={refs.status} error={errors.status} />
            </div>
            <div className="col-span-1 mt-1.5">
              <StyledDateField label="Expected Resolution Date" value={form.resolutionDate}
                setValue={(val) => handleChange("resolutionDate", val)} error={errors.resolutionDate} />
            </div>
          </div>

          <div className="relative w-full mb-2">
            <label className="block text-xs font-medium text-black/70 mb-1">Comment</label>
            <CriteriaDefinitionEditor value={newCommentText} onChange={setNewCommentText}
              className="w-full min-h-[80px] p-2 border rounded resize-none"
              onPendingFilesChange={(files) => setPendingFiles(files)} />
            <button type="button" onClick={handleAddComment} disabled={updating}
              className="absolute bottom-2 right-2 flex items-center gap-1 bg-darkblue1 text-white px-3 py-1 text-xs border border-transparent hover:bg-white hover:text-darkblue1 hover:border-darkblue1 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" /></svg>
              <span>{updating ? "Sending..." : "Send"}</span>
            </button>
          </div>

          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
            <div ref={tableContainerRef} className="overflow-y-auto overflow-x-auto scrollbar-hide"
              style={{ maxHeight: comments.length > 8 ? "calc(100vh - 240px)" : "auto" }} onScroll={handleTableScroll}>
              <table className="w-full text-xs whitespace-nowrap table-fixed">
                <thead className="bg-Dustyblue text-white font-semibold text-left sticky top-0 z-10">
                  <tr>
                    <th className="text-left px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%] cursor-pointer" onClick={() => handleSortComments("comment")}>
                      <div className="flex items-center gap-1">Comment
                        {sortKey !== "comment" && <ChevronsUpDown className="w-3 h-3 text-white" />}
                        {sortKey === "comment" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                        {sortKey === "comment" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                      </div>
                    </th>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">Created By</th>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">Created On</th>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[20%]">Attachments</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={4} className="text-center py-4">
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>Loading comments...</div>
                    </td></tr>
                  ) : sortedComments.length > 0 ? (
                    sortedComments.map((cmt, idx) => {
                      const text = getPlainText(cmt.comment);
                      const htmlAttachments = getAttachments(cmt.comment);
                      const serverAttachment = cmt.attachment_url ? [{ name: getFileNameFromUrl(cmt.attachment_url), url: cmt.attachment_url }] : [];
                      const allAttachments = [...htmlAttachments];
                      serverAttachment.forEach((sa) => { if (!allAttachments.some((a) => a.url === sa.url)) allAttachments.push(sa); });

                      return (
                        <tr key={idx} className="border-t hover:bg-lightBlue/50">
                          <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p className="truncate max-w-[15rem] cursor-pointer"
                                onMouseEnter={() => { if (text && text.length > 20) setHoveredCell({ row: idx, col: "comment" }); }}
                                onMouseLeave={() => setHoveredCell({ row: null, col: null })}>{text || "-"}</p>
                              {hoveredCell.row === idx && hoveredCell.col === "comment" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-20">{text}</span>
                              )}
                            </div>
                          </td>
                          <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p className="truncate max-w-[10rem] cursor-pointer"
                                onMouseEnter={() => { const name = `${cmt.created_by_first_name} ${cmt.created_by_last_name}`.trim() || cmt.created_by || "-"; if (name.length > 15) setHoveredCell({ row: idx, col: "createdBy" }); }}
                                onMouseLeave={() => setHoveredCell({ row: null, col: null })}>
                                {`${cmt.created_by_first_name} ${cmt.created_by_last_name}`.trim() || cmt.created_by || "-"}
                              </p>
                              {hoveredCell.row === idx && hoveredCell.col === "createdBy" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-20">
                                  {`${cmt.created_by_first_name} ${cmt.created_by_last_name}`.trim() || cmt.created_by}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p className="truncate max-w-[10rem] cursor-pointer"
                                onMouseEnter={() => { if (formatDisplayDate(cmt.created_at).length > 15) setHoveredCell({ row: idx, col: "createdOn" }); }}
                                onMouseLeave={() => setHoveredCell({ row: null, col: null })}>{formatDisplayDate(cmt.created_at)}</p>
                              {hoveredCell.row === idx && hoveredCell.col === "createdOn" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-20">{formatDisplayDate(cmt.created_at)}</span>
                              )}
                            </div>
                          </td>
                          <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              {allAttachments.length ? (
                                allAttachments.map((att, i) => (
                                  <div key={i} className="truncate max-w-[10rem] cursor-pointer">
                                    <a href={att.url} target="_blank" rel="noopener noreferrer" className="underline text-blue-600 text-xs"
                                      onMouseEnter={() => { if (att.name.length > 15) setHoveredCell({ row: idx, col: `attachment-${i}` }); }}
                                      onMouseLeave={() => setHoveredCell({ row: null, col: null })}>{att.name}</a>
                                    {hoveredCell.row === idx && hoveredCell.col === `attachment-${i}` && (
                                      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-20">{att.name}</span>
                                    )}
                                  </div>
                                ))
                              ) : ("-")}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr><td colSpan={4} className="text-center text-gray-500 px-3 py-2 italic">No comments yet</td></tr>
                  )}
                </tbody>
              </table>
            </div>

            {showScrollButtons && (
              <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
                {scrollDirection === "down" && (
                  <button onClick={scrollToTop} className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm" aria-label="Scroll to top"><ArrowUp className="w-2 h-2" /></button>
                )}
                {scrollDirection === "up" && (
                  <button onClick={scrollToBottom} className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm" aria-label="Scroll to bottom"><ArrowDown className="w-2 h-2" /></button>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-3 mb-2 w-full">
          <button onClick={handleUpdateTicket} disabled={updating}
            className="bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed">
            {updating ? "Updating..." : "Update"}
          </button>
        </div>
      </div>
    </div>
  );
};

const Info = ({ label, value, span, valueClass = "" }) => (
  <div className={span ? "col-span-2" : ""}>
    <p className="text-sm text-darkblue1 font-bold mb-1">{label}</p>
    <p className={`text-gray-800 text-xs ${valueClass}`}>{value}</p>
  </div>
);

export default EditTicket;