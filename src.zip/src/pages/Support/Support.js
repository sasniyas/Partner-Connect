import React from "react"
import Header from "../../Components/Header"
import { useState } from "react"
import SubNavbar3 from "../../Components/SubNavbar3"
import { Eye, PlusIcon } from "lucide-react"
import Searchinput from "../../Components/Searchinput"
import Filter from "../../Components/Filter"
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { useRef } from "react"
import CreateTicketPopup from "./CreateTicketPopup"
import EditTicket from "./EditTicket"
import DeleteModal from "../../Components/DeleteModal"
import {useNavigate } from "react-router-dom"
import { useSelector } from "react-redux"
import ViewModal from "./ViewTicket"
import { formatDateOnly } from "../../util/timeFormat"
import { useLocation } from "react-router-dom";
import { useEffect } from "react"
import { useMemo } from "react"
import { ChevronDown } from "lucide-react"
import { ChevronUp } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
import { getTicketByUserId, deleteTicket, addTicket, getAllTickets } from "../../services/ticketService"
import useCRUDWithReset from "../../util/useCRUDWithReset"

const Support = () => {
    const navigate = useNavigate("")
    const location = useLocation();
    const { data: userData } = useSelector((state) => state.user);
    const effectiveRole = userData ? userData.persona : "";
    const isAdmin = effectiveRole === "Administrator";

    const [tickets, setTickets] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)

    const [menuOpen, setMenuOpen] = useState(false)
    const totalTickets = tickets?.length || 0;
    const openTickets = tickets?.filter(t => t.status === "Open").length || 0;
    const closedTickets = tickets?.filter(t => t.status === "Closed").length || 0;
    const newTickets = tickets?.filter(t => t.status === "New").length || 0;
    const [searchTerm, setSearchTerm] = useState("");
    const [showRealToInput, setShowRealToInput] = useState(false);
    const [showRealFromInput, setShowRealFromInput] = useState(false);
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const [isOpen, setIsOpen] = useState(false);
    const [sortKey, setSortKey] = useState(null);
    const [sortOrder, setSortOrder] = useState(null);
    const [hoveredName ,setHoveredName] = useState(null)
    const [isLoadingTickets,setIsLoadingTickets] =useState("")
    const toDateRef = useRef(null);
    const dropdownRef = useRef(null);
    const fromDateRef = useRef(null);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedId, setSelectedId] = useState(null);
    const [deleteLoading, setDeleteLoading] = useState(false);

    const [filters, setFilters] = useState({
      fromDate: "",
      endDate: "",
      issueRelated: "",
      priority: "",
      status: "",
    });

    const getPlainDescription = (html) => {
      if (!html) return "";
      const div = document.createElement("div");
      div.innerHTML = html;
      div.querySelectorAll("[data-file-url]").forEach(el => el.remove());
      div.querySelectorAll("[data-pending-file]").forEach(el => el.remove());
      return div.textContent.trim();
    };

    const formatDisplayDate = (dateStr) => {
      if (!dateStr || dateStr === "NA" || String(dateStr).trim() === "") return "NA";
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return "NA";
      const day = String(d.getDate()).padStart(2, "0");
      const month = String(d.getMonth() + 1).padStart(2, "0");
      const year = d.getFullYear();
      return `${day}-${month}-${year}`;
    };

    const yearOptions = ["2024", "2025", "2026"];
    const issueOptions = [...new Set(tickets.map(t => t.issueRelated).filter(Boolean))];
    const priorityOptions = ["Low", "Medium", "High"];
    const statusOptions = ["New", "Open", "In Progress", "Closed"];
    
    const [showScrollButtons, setShowScrollButtons] = useState(false);
    const [scrollPosition, setScrollPosition] = useState(0);
    const [scrollDirection, setScrollDirection] = useState(null);
    const [lastScrollTop, setLastScrollTop] = useState(0);
    const tableContainerRef = useRef(null);

    useEffect(() => {
      fetchTickets()
    }, [])

    const fetchTickets = async () => {
      try {
        setLoading(true)
        setError(null)
        const data = await getTicketByUserId()
        const transformedData = data.map(ticket => ({
          id: ticket.id,
          ticketNumber: ticket.ticket_no,
          subject: ticket.ticket_subject,
          issueRelated: ticket.issue,
          description: ticket.description,
          createdOn: ticket.created_at,
          resolutionDate: ticket.expected_resolution_date || "NA",
          createdBy: `${ticket.submitted_by_first_name || ""} ${ticket.submitted_by_last_name || ""}`.trim(),
          priority: ticket.priority,
          status: ticket.ticket_status,
          attachments: ticket.attachments || [],
        }))
        setTickets(transformedData)
      } catch (err) {
        console.error("Error fetching tickets:", err)
        setError(err.message)
        setTickets([])
      } finally {
        setLoading(false)
      }
    }

    const handleTableScroll = (e) => {
      const container = e.target;
      const scrollTop = container.scrollTop;
      const scrollHeight = container.scrollHeight;
      const clientHeight = container.clientHeight;

      if (scrollTop > lastScrollTop) {
        setScrollDirection('down');
      } else if (scrollTop < lastScrollTop) {
        setScrollDirection('up');
      }
      setLastScrollTop(scrollTop);
      setScrollPosition(scrollTop);

      const isScrollable = scrollHeight > clientHeight;
      const hasScrolledDown = scrollTop > 100;
      
      setShowScrollButtons(isScrollable && hasScrolledDown);
    };

    const scrollToTop = () => {
      if (tableContainerRef.current) {
        tableContainerRef.current.scrollTo({
          top: 0,
          behavior: "smooth"
        });
      }
    };

    const scrollToBottom = () => {
      if (tableContainerRef.current) {
        tableContainerRef.current.scrollTo({
          top: tableContainerRef.current.scrollHeight,
          behavior: "smooth"
        });
      }
    };

    const handleFilterChange = (name, value) => {
      setFilters(prev => ({ ...prev, [name]: value }));
    };

    const normalizeDate = (date, isEnd = false) => {
      if (!date) return null;
      const d = new Date(date);
      if (isNaN(d.getTime())) return null;
      if (isEnd) {
        d.setHours(23, 59, 59, 999);
      } else {
        d.setHours(0, 0, 0, 0);
      }
      return d;
    };

    const filteredTickets = tickets.filter((ticket) => {
      const searchLower = searchTerm.toLowerCase();

      const matchesSearch =
        (ticket.ticketNumber || "").toLowerCase().includes(searchLower) ||
        (ticket.subject || "").toLowerCase().includes(searchLower) ||
        (getPlainDescription(ticket.description) || "").toLowerCase().includes(searchLower);

      const matchesIssueRelated =
        !filters.issueRelated?.length ||
        filters.issueRelated.includes(ticket.issueRelated);

      const matchesPriority =
        !filters.priority?.length ||
        filters.priority.includes(ticket.priority);

      const matchesStatus =
        !filters.status?.length ||
        filters.status.includes(ticket.status);

      if (!ticket.createdOn) return false;

      const ticketDate = new Date(ticket.createdOn);
      if (isNaN(ticketDate.getTime())) return false;

      const from = normalizeDate(fromDate);
      const to = normalizeDate(toDate, true);

      let matchesDate = true;

      if (from && to) {
        matchesDate = ticketDate >= from && ticketDate <= to;
      } else if (from) {
        matchesDate = ticketDate >= from;
      } else if (to) {
        matchesDate = ticketDate <= to;
      }

      return (
        matchesSearch &&
        matchesIssueRelated &&
        matchesPriority &&
        matchesStatus &&
        matchesDate
      );
    });

    const handleSort = (key) => {
      if (sortKey === key) {
        if (sortOrder === "asc") {
          setSortOrder("desc");
          return;
        } else if (sortOrder === "desc") {
          setSortKey(null);
          setSortOrder(null);
          return;
        }
      }
      setSortKey(key);
      setSortOrder("asc");
    };

    const sortedData = useMemo(() => {
      if (!sortKey || !sortOrder) return filteredTickets;

      return [...filteredTickets].sort((a, b) => {
        let valA = a[sortKey] || "";
        let valB = b[sortKey] || "";

        if (sortKey === "description") {
          valA = (getPlainDescription(valA) || "").toString().toLowerCase();
          valB = (getPlainDescription(valB) || "").toString().toLowerCase();
        } else {
          valA = valA.toString().toLowerCase();
          valB = valB.toString().toLowerCase();
        }

        return sortOrder === "asc"
          ? valA.localeCompare(valB)
          : valB.localeCompare(valA);
      });
    }, [filteredTickets, sortKey, sortOrder]);

const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    setSearchTerm,
    setFilters,
    setFromDate,
    setToDate,
    setShowRealFromInput,
    setShowRealToInput,
  }
);

    const handleEditClick = (ticket) => {
      navigate("/ticket/edit", { state: { ticket } });
    };

    const handleAddTicket = async (ticketData) => {
      try {
        const payload = {
          ticket_subject: ticketData.ticketSubject,
          issue: ticketData.issueRelatedTo,
          priority: ticketData.priority,
          description: ticketData.description,
          expected_resolution_date: ticketData.resolutionDate || null,
        }

        // Pass pending files directly - addTicket handles multipart/form-data
        const pendingFiles = ticketData.pendingFiles || [];
        await addTicket(payload, pendingFiles)

        resetSortAndFilter()
        await fetchTickets()
        setIsOpen(false)
      } catch (err) {
        console.error("Error adding ticket:", err)
        alert("Error adding ticket: " + err.message)
      }
    };

    const handleDeleteTicket = async (ticket) => {
      setSelectedId(ticket.id);
      setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = async () => {
      if (!selectedId) return;
      try {
        setDeleteLoading(true);
        await deleteTicket(selectedId);
        setTickets(prev => prev.filter(t => t.id !== selectedId));
        setIsDeleteModalOpen(false);
        setSelectedId(null);
      } catch (err) {
        console.error("Error deleting ticket:", err);
        alert("Error deleting ticket: " + err.message);
      } finally {
        setDeleteLoading(false);
      }
    };

    const handleViewClick = (ticket) => {
      navigate("/ticket/view", { state: { ticket } });
    };

    return (
      <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col  ">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        
        <SubNavbar3 />

        <div
          className={`
            transition-all duration-300
            ${menuOpen ? "lg:ml-60" : ""}
            flex justify-center
            flex-1
          `}
        >
          <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
  <div className="flex items-center justify-between w-full ">
    
    {/* LEFT: Heading */}
           <h2 className="text-lg font-semibold text-darkblue1 font-VolvoNovum text-center ">
             My Support
           </h2>

    {/* MIDDLE: Card */}
    <div className=" px-6 ">
  <div className="bg-white shadow-[0_4px_10px_#0000001A] py-1">
    <div className="grid grid-cols-5 text-center gap-2">

      {[
        { title: "Total Tickets", value: totalTickets },
        { title: "Open Tickets", value: openTickets },
        { title: "Closed Tickets", value: closedTickets },
        { title: "New Tickets", value: newTickets },
        { title: "Assigned Tickets", value: 0 },
      ].map((item, i) => (
        <div
          key={i}
          className={`py-0 px-3 ${
            i < 4 ? "border-r border-darkblue1" : ""
          } flex flex-col items-center justify-center`}
        >
          <div className="text-xs font-medium text-black">
            {item.title}
          </div>
          <div className="text-sm font-semibold text-SteelBlue1 mt-1">
            {item.value ?? 0}
          </div>
        </div>
      ))}

    </div>
  </div>
    </div>

    {/* RIGHT: Buttons */}
    <div className="flex items-center gap-2">
       <button
                      onClick={() => navigate("/support/trend-chart")}
                      className="h-8 px-4 bg-darkblue1 text-white font-VlovoNovum text-xs font-medium flex items-center justify-center gap-2 border border-transparent transition duration-200 hover:bg-white hover:text-darkblue1 hover:border-darkblue1 group flex-1"
                    >
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="12" viewBox="0 0 16 12" fill="none"                       className="w-3 h-3 transition duration-200 group-hover:filter group-hover:brightness-0 group-hover:saturate-100"
  >
  <path d="M15.5 10H2V0.5C2 0.22375 1.77625 0 1.5 0H0.5C0.22375 0 0 0.22375 0 0.5V11C0 11.5522 0.447812 12 1 12H15.5C15.7762 12 16 11.7762 16 11.5V10.5C16 10.2238 15.7762 10 15.5 10ZM14.5 1H10.8106C10.1425 1 9.80781 1.80781 10.2803 2.28031L11.2928 3.29281L9 5.58594L6.70719 3.29313C6.31656 2.9025 5.68344 2.9025 5.29313 3.29313L3.14656 5.43969C2.95125 5.635 2.95125 5.95156 3.14656 6.14688L3.85344 6.85375C4.04875 7.04906 4.36531 7.04906 4.56063 6.85375L6 5.41406L8.29281 7.70687C8.68344 8.0975 9.31656 8.0975 9.70687 7.70687L12.7069 4.70687L13.7194 5.71938C14.1919 6.19187 14.9997 5.85719 14.9997 5.18906V1.5C15 1.22375 14.7762 1 14.5 1Z" fill="white"/>
  </svg>
                      <span className="whitespace-nowrap">Trend Chart</span>
                    </button>
    <button
      onClick={() => setIsOpen(true)} 
    className="h-8 px-4 bg-darkblue1 text-white 
    font-VlovoNovum text-xs font-semibold 
    flex items-center justify-center gap-2 
    border border-transparent transition duration-200 
    hover:bg-white hover:text-darkblue1 hover:border-darkblue1 
    group whitespace-nowrap"
  >
    <PlusIcon
      className="w-3 h-3 transition duration-200 font-bold 
      group-hover:filter group-hover:brightness-0 group-hover:saturate-100"
    />
    <span>Create New Tickets</span>
  </button>

    {isAdmin && (
    <button
    className="h-8 px-4 bg-darkblue1 text-white font-VlovoNovum text-xs font-semibold flex items-center justify-center gap-2 border border-transparent transition duration-200 whitespace-nowrap hover:bg-white hover:text-darkblue1 hover:border-darkblue1"
    onClick={() => navigate("/support/all-tickets")}
  >
    View All Tickets
  </button>
    )}

    </div>
  </div>
                <hr className="hidden lg:block w-[7%] border-t-4 -mt-4 border-darkblue1 mb-6" />
   <div className="hidden lg:flex w-full items-center justify-between gap-2 mb-2">
    {/* Left: Search + Filters */}
    <div className="flex flex-wrap gap-2 flex-1 ">

      {/* Search Input */}
      <div className="w-[100px]">
      <Searchinput
        value={searchTerm}
        onChange={(e) => {
          setSearchTerm(e.target.value)
        }}
        placeholder="Search..."
        className="w-full"
        bgColor="bg-FrostWhite"
        borderColor="border-black/60"
        textColor="text-black"
        focusRing="focus:ring-black/60"
        shadow="shadow-none"
        inputPadding="pl-6 pr-3 py-2 sm:py-3"
        iconSize="w-3 h-3"
        iconLeft="left-3"
        iconColor="text-black"
      />
    </div>

        <div className="relative w-[150px]">
    {!showRealFromInput && (
      <input
        type="text"
        placeholder="From Date"
        readOnly
        className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-gray-400 cursor-pointer"
        onFocus={() => {
          setShowRealFromInput(true);
          setTimeout(() => fromDateRef.current?.showPicker(), 0);
        }}
      />
    )}
    {showRealFromInput && (
      <input
        type="date"
        ref={fromDateRef}
        value={fromDate}
        onChange={(e) => setFromDate(e.target.value)}
        className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-black"
      />
    )}
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
      fill="none"
      onClick={() => {
        setShowRealFromInput(true);
        setTimeout(() => fromDateRef.current?.showPicker(), 0);
      }}
    >
      <path
        d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
        stroke="black"
        strokeOpacity="0.7"
        strokeWidth="1.5"
      />
      <path
        d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
        stroke="black"
        strokeOpacity="0.7"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  </div>

  <div className="relative w-[150px]">
    {!showRealToInput && (
      <input
        type="text"
        placeholder="To Date"
        readOnly
        className="w-full py-1.5 px-3 text-xs border border-black/50 pr-10 text-gray-400 cursor-pointer"
        onFocus={() => {
          setShowRealToInput(true);
          setTimeout(() => toDateRef.current?.showPicker(), 0);
        }}
      />
    )}
    {showRealToInput && (
      <input
        type="date"
        ref={toDateRef}
        value={toDate}
        onChange={(e) => setToDate(e.target.value)}
        className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-black"
      />
    )}
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
      fill="none"
      onClick={() => {
        setShowRealToInput(true);
        setTimeout(() => toDateRef.current?.showPicker(), 0);
      }}
    >
      <path
        d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
        stroke="black"
        strokeOpacity="0.7"
        strokeWidth="1.5"
      />
      <path
        d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
        stroke="black"
        strokeOpacity="0.7"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  </div>

   <Filter
    name="issueRelated"
    value={filters.issueRelated}
    options={issueOptions}
    onChange={(name, val) =>
      setFilters((prev) => ({
        ...prev,
        issueRelated: val,
      }))
    }
    placeholder="Issue Related To"
    placeholderColor="text-black"
    textColor="text-black"
    buttonBorderColor="border-black/60"
    dropdownBorderColor="border-black/60"
    dropdownHoverColor="hover:bg-lightBlue/50"
    customWidth="w-[200px]"
  />

    <Filter
      name="priority"
      value={filters.priority}
      options={priorityOptions}
      onChange={handleFilterChange}
      placeholder="Priority"
      placeholderColor="text-black"
      textColor="text-black"
      buttonBorderColor="border-black/60"
      dropdownBorderColor="border-black/60"
      dropdownHoverColor="hover:bg-lightBlue/50"
      customWidth=" w-[50px]"
    />

    <Filter
      name="status"
      value={filters.status}
      options={statusOptions}
      onChange={handleFilterChange}
      placeholder="Ticket Status"
      placeholderColor="text-black"
      textColor="text-black"
      buttonBorderColor="border-black/60"
      dropdownBorderColor="border-black/60"
      dropdownHoverColor="hover:bg-lightBlue/50"
      customWidth="w-[50px]"
    />
  </div>

  </div>

  {error && (
    <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4 text-red-700 text-xs">
      {error}
    </div>
  )}

  <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
    <div
      ref={tableContainerRef}
      className="overflow-y-auto overflow-x-auto scrollbar-hide"
      style={{
        maxHeight: filteredTickets.length > 8 ? "calc(100vh - 240px)" : "auto",
        
      }}
      onScroll={handleTableScroll}
    >
      <table className="w-full text-xs whitespace-nowrap table-fixed min-w-[700px] lg:min-w-full">
        <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
         <tr>
    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%] cursor-pointer text-left"
      onClick={() => handleSort("ticketNumber")}
    >
      <div className="flex items-center gap-1">
        Ticket #
        {sortKey !== "ticketNumber" && <ChevronsUpDown className="w-3 h-3 text-white" />}
        {sortKey === "ticketNumber" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "ticketNumber" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%] cursor-pointer"
      onClick={() => handleSort("subject")}
    >
      <div className="flex items-center gap-1">
        Ticket Subject
        {sortKey === "subject" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "subject" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[15%] cursor-pointer"
      onClick={() => handleSort("issueRelated")}
    >
      <div className="flex items-center gap-1">
        Issue Related To
        {sortKey === "issueRelated" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "issueRelated" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[25%] cursor-pointer"
      onClick={() => handleSort("description")}
    >
      <div className="flex items-center gap-1">
        Description
        {sortKey === "description" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "description" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[12%] cursor-pointer"
      onClick={() => handleSort("createdOn")}
    >
      <div className="flex items-center gap-1">
        Created On
        {sortKey === "createdOn" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "createdOn" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[15%] cursor-pointer whitespace-normal"
      onClick={() => handleSort("resolutionDate")}
    >
      <div className="flex items-center gap-1">
        Exp. Resolution Date
        {sortKey === "resolutionDate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "resolutionDate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%] cursor-pointer"
      onClick={() => handleSort("priority")}
    >
      <div className="flex items-center gap-1">
        Priority
        {sortKey === "priority" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "priority" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[13%] cursor-pointer"
      onClick={() => handleSort("status")}
    >
      <div className="flex items-center gap-1">
        Ticket Status
        {sortKey === "status" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "status" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 w-[12%] text-center cursor-pointer"
    >
      <div className="flex items-center justify-center gap-1">
        Action
      </div>
    </th>
  </tr>

        </thead>

        <tbody>
          {loading && (
            <tr>
              <td colSpan={10} className="px-6 py-8 text-center text-gray-500">
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                  Loading...
                </div>
              </td>
            </tr>
          )}

          {!loading && sortedData.length > 0 ? (
            sortedData.map((ticket) => (
              <tr key={ticket.id} className="hover:bg-lightBlue/50">
                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  <div className="relative">
                    <p
                      className="truncate max-w-[20rem] cursor-pointer"
                      onMouseEnter={() => {
                        if (ticket.ticketNumber && ticket.ticketNumber.length > 20) {
                          setHoveredName(ticket.id + "-ticketNumber");
                        }
                      }}
                      onMouseLeave={() => setHoveredName(null)}
                    >
                      {ticket.ticketNumber}
                    </p>
                    {hoveredName === ticket.id + "-ticketNumber" && (
                      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                        {ticket.ticketNumber}
                      </span>
                    )}
                  </div>
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  <div className="relative">
                    <p
                      className="truncate max-w-[10rem] cursor-pointer"
                      onMouseEnter={() => {
                        if (ticket.subject && ticket.subject.length > 20) {
                         setHoveredName(ticket.id + "-subject");
                        }
                      }}
                      onMouseLeave={() => setHoveredName(null)}
                    >
                      {ticket.subject}
                    </p>
                    {hoveredName === ticket.id + "-subject" && (
                      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                        {ticket.subject}
                      </span>
                    )}
                  </div>
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  <div className="relative">
                    <p
                      className="truncate max-w-[15rem] cursor-pointer"
                      onMouseEnter={() => {
                        if (ticket.issueRelated && ticket.issueRelated.length > 20) {
                          setHoveredName(ticket.id + "-issueRelated");
                        }
                      }}
                      onMouseLeave={() => setHoveredName(null)}
                    >
                      {ticket.issueRelated}
                    </p>
                    {hoveredName === ticket.id + "-issueRelated" && (
                      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                        {ticket.issueRelated}
                      </span>
                    )}
                  </div>
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  <div className="relative">
                    <p
                      className="truncate max-w-[15rem] cursor-pointer"
                      onMouseEnter={() => {
                        const plainText = getPlainDescription(ticket.description);
                        if (plainText && plainText.length > 20) {
                          setHoveredName(ticket.id + "-description");
                        }
                      }}
                      onMouseLeave={() => setHoveredName(null)}
                    >
                      {getPlainDescription(ticket.description) || "No description"}
                    </p>
                    {hoveredName === ticket.id + "-description" && (
                      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                        {getPlainDescription(ticket.description)}
                      </span>
                    )}
                  </div>
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  {formatDisplayDate(ticket.createdOn)}
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  {ticket.resolutionDate !== "NA"
                    ? formatDisplayDate(ticket.resolutionDate) 
                    : "NA"}
                </td>

                <td
                  className={`px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs font-medium
                    ${
                      ticket.priority === "High"
                        ? "text-green2"
                        : ticket.priority === "Medium"
                        ? "text-SteelBlue1"
                        : ticket.priority === "Low"
                        ? "text-red1"
                        : "text-gray-400"
                    }
                  `}
                >
                  {ticket.priority}
                </td>

                <td
                  className={`px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs font-medium
                    ${
                      ticket.status === "Open"
                        ? "text-SteelBlue1"
                        : ticket.status === "In Progress"
                        ? "text-burntorange"
                        : ticket.status === "Closed"
                        ? "text-green3"
                        : "text-gray-400"
                    }
                  `}
                >
                  {ticket.status}
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center">
                  <div className="flex items-center justify-center gap-2">
                    <div className="relative group inline-block">
                      <button
                        onClick={() => handleViewClick(ticket)}
                        className="w-5 h-5  hover:bg-lightBlue/50 flex items-center justify-center transition"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M9.59922 7.19961H20.3992V9.59961H9.59922V7.19961ZM9.59922 3.59961H22.7992V5.99961H9.59922V3.59961ZM1.19922 3.59961H8.39922V10.7996H1.19922V3.59961ZM9.59922 16.7996H20.3992V19.1996H9.59922V16.7996ZM9.59922 13.1996H22.7992V15.5996H9.59922V13.1996ZM1.19922 13.1996H8.39922V20.3996H1.19922V13.1996Z" fill="#2C4730"/>
                        </svg>
                      </button>
                      <span className="
                        absolute left-1/2 top-full -mt-1
                        bg-SteelBlue1 text-white text-[9px]
                        px-2 py-0 whitespace-nowrap
                        transform -translate-x-1/2
                        opacity-0 group-hover:opacity-100
                        pointer-events-none
                        z-0
                      ">
                        View 
                      </span>
                    </div>

                    <div className="relative group inline-block">
                      <button 
                        onClick={() => handleEditClick(ticket)}
                        className="group relative">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                          <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                        </svg>
                      </button>
                      <span className="
                        absolute left-1/2 top-full -mt-1
                        bg-SteelBlue1 text-white text-[9px]
                        px-2 py-0 whitespace-nowrap
                        transform -translate-x-1/2
                        opacity-0 group-hover:opacity-100
                        pointer-events-none
                        z-0
                      ">
                        Edit
                      </span>
                    </div>

                    <div className="relative group inline-block">
                      <button
                        onClick={() => handleDeleteTicket(ticket)}
                        className="group relative">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                          <g clipPath="url(#clip0_6398_313)">
                            <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                          </g>
                          <defs>
                            <clipPath id="clip0_6398_313">
                              <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                            </clipPath>
                          </defs>
                        </svg>
                      </button>
                      <span className="
                        absolute left-1/2 top-full -mt-1
                        bg-SteelBlue1 text-white text-[9px]
                        px-2 py-0 whitespace-nowrap
                        transform -translate-x-1/2
                        opacity-0 group-hover:opacity-100
                        pointer-events-none
                        z-0
                      ">
                        Delete
                      </span>
                    </div>
                  </div>
                </td>
              </tr>
            ))
          ) : (
            !loading && (
              <tr>
                <td colSpan={10} className="text-center py-8 text-gray-500 italic">
                  No tickets found
                </td>
              </tr>
            )
          )}
        </tbody>
      </table>
    </div>

    {showScrollButtons && (
      <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
        {scrollDirection === 'down' && (
          <button
            onClick={scrollToTop}
            className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-2 h-2" />
          </button>
        )}

        {scrollDirection === 'up' && (
          <button
            onClick={scrollToBottom}
            className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
            aria-label="Scroll to bottom"
          >
            <ArrowDown className="w-2 h-2" />
          </button>
        )}
      </div>
    )}
  </div>
        </div>
      </div>

      {isOpen && (
        <CreateTicketPopup
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          onSave={handleAddTicket}
        />
      )}

      {isDeleteModalOpen && selectedId && (
        <DeleteModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            if (!deleteLoading) {
              setIsDeleteModalOpen(false);
              setSelectedId(null);
            }
          }}
          onConfirm={handleConfirmDelete}
          loading={deleteLoading}
          extraMessage="This will permanently delete the ticket and all related data."
        />
      )}
    </div>
  )
}

export default Support