import React, { useState, useRef } from "react";
import StyledDateField from "../../Components/StyledDatefield";
import { useEffect } from "react";
import StyledSelectField from "../../Components/StyledSelectField";
import {useKeyboardNavigation} from  "../../util/useKeyboardNavigation"
import {
  Bold,
  Italic,
  Underline,
  List,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Copy,
  RotateCcw,
} from "lucide-react";

const CriteriaDefinitionEditor = ({ value, onChange, className = "", onPendingFilesChange }) => {
  const [fontSize, setFontSize] = useState("12");
  const [fontFamily, setFontFamily] = useState("Segoe UI");
  const [activeFormats, setActiveFormats] = useState({
    bold: false,
    italic: false,
    underline: false,
    unorderedList: false,
    orderedList: false,
  });

  const editorRef = useRef(null);
  const [attachments, setAttachments] = useState([]);
  const [dropdowns, setDropdowns] = useState({
    fontFamily: false,
    fontSize: false,
  });
  const dropdownRefs = { fontFamily: useRef(null), fontSize: useRef(null) };

  const fontFamilyOptions = [
    { value: "Segoe UI", label: "Segoe UI" },
    { value: "Arial", label: "Arial" },
    { value: "Roboto", label: "Roboto" },
    { value: "Times New Roman", label: "Times New Roman" },
  ];

  const fontSizeOptions = ["12", "14", "16", "18", "20", "24", "28", "32"];

  const executeCommand = (command, val = null) => {
    document.execCommand(command, false, val);
    editorRef.current?.focus();
  };

  const handleContentChange = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const handleFileAttach = (files) => {
    if (!editorRef.current) return;

    const filesArray = Array.from(files).map((file) => ({
      id: Date.now() + Math.random(),
      name: file.name,
      file,
    }));

    const updatedAttachments = [...attachments, ...filesArray];
    setAttachments(updatedAttachments);

    // Notify parent about pending files (actual File objects for later upload)
    if (onPendingFilesChange) {
      onPendingFilesChange(updatedAttachments.map((a) => a.file));
    }

    filesArray.forEach((att) => {
      const span = document.createElement("span");
      span.contentEditable = "false";
      span.dataset.pendingFile = "true";
      span.dataset.fileName = att.name;
      span.dataset.fileId = String(att.id);
      span.className =
        "inline-flex items-center gap-2 px-2 py-1 bg-gray-200 text-xs mr-1 mt-2 rounded cursor-pointer hover:bg-gray-300";

      span.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none">
          <path d="M4.177 5.50694V11.139C4.177 12.2468 4.61708 13.3092 5.40042 14.0926C6.18377 14.8759 7.24621 15.316 8.35402 15.316C9.46183 15.316 10.5243 14.8759 11.3076 14.0926C12.091 13.3092 12.531 12.2468 12.531 11.139V4.17726C12.531 3.43871 12.2377 2.73042 11.7154 2.20819C11.1932 1.68596 10.4849 1.39258 9.74636 1.39258C9.00782 1.39258 8.29952 1.68596 7.77729 2.20819C7.25507 2.73042 6.96168 3.43871 6.96168 4.17726V10.5695C6.96168 10.7523 6.99769 10.9334 7.06767 11.1023C7.13764 11.2712 7.2402 11.4247 7.36949 11.554C7.49878 11.6833 7.65227 11.7859 7.8212 11.8558C7.99012 11.9258 8.17118 11.9618 8.35402 11.9618C8.72329 11.9618 9.07744 11.8151 9.33855 11.554C9.59967 11.2929 9.74636 10.9388 9.74636 10.5695V5.5696" stroke="black" stroke-width="0.835404" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        ${att.name}
        <button data-id="${att.id}" class="remove-btn text-red-500 font-bold text-xs ml-1 flex-shrink-0">
          <svg width="14" height="14" viewBox="0 0 20 20">
            <circle cx="10" cy="10" r="8" fill="#BF2012" />
            <path d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5" stroke="white" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </button>
      `;

      span.querySelector(".remove-btn")?.addEventListener("click", (e) => {
        e.stopPropagation();
        setAttachments((prev) => {
          const updated = prev.filter((a) => a.id !== att.id);
          if (onPendingFilesChange) {
            onPendingFilesChange(updated.map((a) => a.file));
          }
          return updated;
        });
        span.remove();

        const sel = window.getSelection();
        const range = document.createRange();
        range.setStart(editorRef.current, editorRef.current.childNodes.length);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
        editorRef.current.focus();
        handleContentChange();
      });

      editorRef.current.appendChild(span);

      const space = document.createTextNode("\u00A0");
      editorRef.current.appendChild(space);

      const sel = window.getSelection();
      const range = document.createRange();
      range.setStartAfter(space);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
      editorRef.current.focus();
    });

    handleContentChange();
  };

  const updateActiveFormats = () => {
    if (!editorRef.current) return;
    setActiveFormats({
      bold: document.queryCommandState("bold"),
      italic: document.queryCommandState("italic"),
      underline: document.queryCommandState("underline"),
      unorderedList: document.queryCommandState("insertUnorderedList"),
      orderedList: document.queryCommandState("insertOrderedList"),
    });
  };

  useEffect(() => {
    if (editorRef.current && value !== editorRef.current.innerHTML) {
      editorRef.current.innerHTML = value || "";
    }
  }, [value]);

  return (
    <div className="border border-gray-300 overflow-hidden bg-white">
      <div className="border-b border-gray-200 py-0 px-2 bg-gray-50">
        <div className="flex flex-wrap gap-4 mb-2">
          <div className="w-40">
            <StyledSelectField
              value={fontFamily}
              setValue={setFontFamily}
              options={fontFamilyOptions}
              dropdownOpen={dropdowns.fontFamily}
              setDropdownOpen={(val) =>
                setDropdowns((prev) => ({ ...prev, fontFamily: val }))
              }
              dropdownRef={dropdownRefs.fontFamily}
            />
          </div>
          <div className="w-20">
            <StyledSelectField
              value={fontSize}
              setValue={setFontSize}
              options={fontSizeOptions.map((size) => ({
                label: size,
                value: size,
              }))}
              dropdownOpen={dropdowns.fontSize}
              setDropdownOpen={(val) =>
                setDropdowns((prev) => ({ ...prev, fontSize: val }))
              }
              dropdownRef={dropdownRefs.fontSize}
            />
          </div>

          <div className="flex flex-wrap gap-0 items-center">
            <ToolbarButton
              icon={<Bold size={16} />}
              label="Bold"
              isActive={activeFormats.bold}
              onClick={() => {
                executeCommand("bold");
                handleContentChange();
                updateActiveFormats();
              }}
            />
            <ToolbarButton
              icon={<Italic size={16} />}
              label="Italic"
              isActive={activeFormats.italic}
              onClick={() => {
                executeCommand("italic");
                handleContentChange();
                updateActiveFormats();
              }}
            />
            <ToolbarButton
              icon={<Underline size={16} />}
              label="Underline"
              isActive={activeFormats.underline}
              onClick={() => {
                executeCommand("underline");
                handleContentChange();
                updateActiveFormats();
              }}
            />
            <ToolbarButton
              icon={<List size={16} />}
              label="Bullet List"
              isActive={activeFormats.unorderedList}
              onClick={() => {
                if (editorRef.current?.innerHTML.trim() === "") {
                  editorRef.current.innerHTML = "<ul><li><br></li></ul>";
                } else {
                  executeCommand("insertUnorderedList");
                }
                handleContentChange();
                updateActiveFormats();
              }}
            />
            <ToolbarButton
              icon={<span className="text-sm font-bold">1.</span>}
              label="Numbered List"
              isActive={activeFormats.orderedList}
              onClick={() => {
                if (editorRef.current?.innerHTML.trim() === "") {
                  editorRef.current.innerHTML = "<ol><li><br></li></ol>";
                } else {
                  executeCommand("insertOrderedList");
                }
                handleContentChange();
                updateActiveFormats();
              }}
            />
            <ToolbarButton
              icon={<AlignLeft size={16} />}
              label="Align Left"
              onClick={() => {
                executeCommand("justifyLeft");
                handleContentChange();
              }}
            />
            <ToolbarButton
              icon={<AlignCenter size={16} />}
              label="Align Center"
              onClick={() => {
                executeCommand("justifyCenter");
                handleContentChange();
              }}
            />
            <ToolbarButton
              icon={<AlignRight size={16} />}
              label="Align Right"
              onClick={() => {
                executeCommand("justifyRight");
                handleContentChange();
              }}
            />
            <ToolbarButton
              icon={
                <span className="text-lg">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="17"
                    height="17"
                    viewBox="0 0 17 17"
                    fill="none"
                  >
                    <path
                      d="M4.177 5.50694V11.139C4.177 12.2468 4.61708 13.3092 5.40042 14.0926C6.18377 14.8759 7.24621 15.316 8.35402 15.316C9.46183 15.316 10.5243 14.8759 11.3076 14.0926C12.091 13.3092 12.531 12.2468 12.531 11.139V4.17726C12.531 3.43871 12.2377 2.73042 11.7154 2.20819C11.1932 1.68596 10.4849 1.39258 9.74636 1.39258C9.00782 1.39258 8.29952 1.68596 7.77729 2.20819C7.25507 2.73042 6.96168 3.43871 6.96168 4.17726V10.5695C6.96168 10.7523 6.99769 10.9334 7.06767 11.1023C7.13764 11.2712 7.2402 11.4247 7.36949 11.554C7.49878 11.6833 7.65227 11.7859 7.8212 11.8558C7.99012 11.9258 8.17118 11.9618 8.35402 11.9618C8.72329 11.9618 9.07744 11.8151 9.33855 11.554C9.59967 11.2929 9.74636 10.9388 9.74636 10.5695V5.5696"
                      stroke="black"
                      strokeWidth="0.835404"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </span>
              }
              label="Attach File"
              onClick={() => document.getElementById("fileInput")?.click()}
            />
            <input
              id="fileInput"
              type="file"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files) handleFileAttach(e.target.files);
                e.target.value = "";
              }}
            />

            <ToolbarButton
              icon={<Copy size={16} />}
              label="Copy"
              onClick={() => executeCommand("copy")}
            />

            <ToolbarButton
              icon={<RotateCcw size={16} />}
              label="Undo"
              onClick={() => {
                executeCommand("undo");
                handleContentChange();
                updateActiveFormats();
              }}
            />
          </div>
        </div>
      </div>
      <div
        ref={editorRef}
        contentEditable
        className={`min-h-[100px] p-4 focus:outline-none border ${className}`}
        style={{ fontSize: fontSize + "px", fontFamily: fontFamily }}
        onInput={handleContentChange}
        onBlur={handleContentChange}
        onKeyUp={updateActiveFormats}
        onMouseUp={updateActiveFormats}
        onFocus={updateActiveFormats}
        suppressContentEditableWarning={true}
      />
    </div>
  );
};

const ToolbarButton = ({ icon, label, isActive = false, onClick }) => (
  <div className="relative group">
    <button
      type="button"
      className={
        "p-1.5 focus:outline-none hover:bg-gray-200 " +
        (isActive ? "border border-black" : "")
      }
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
    >
      {icon}
    </button>
    <span className="absolute top-full left-1/2 -translate-x-1/2 mt-0 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 z-0 whitespace-nowrap">
      {label}
    </span>
  </div>
);

const CreateTicketPopup = ({ isOpen, onClose, onSave }) => {
  const [form, setForm] = useState({
    ticketSubject: "",
    issueRelatedTo: "",
    priority: "",
    resolutionDate: "",
    description: "",
  });
  const [pendingFiles, setPendingFiles] = useState([]);
  const popupRef = useRef(null);
  const [dropdowns, setDropdowns] = useState({
    issue: false,
    priority: false,
  });

  const refs = {
    issue: useRef(null),
    priority: useRef(null),
  };

  const issueOptions = [
    { label: "Login Problem", value: "login" },
    { label: "Payment Issue", value: "payment" },
    { label: "Bug Report", value: "bug" },
  ];

  const priorityOptions = [
    { label: "Low", value: "Low" },
    { label: "Medium", value: "Medium" },
    { label: "High", value: "High" },
  ];

  const [errors, setErrors] = useState({});

  const handleChange = (field, val) => {
    setForm((prev) => ({ ...prev, [field]: val }));
    setErrors((prev) => ({ ...prev, [field]: null }));
  };

  useEffect(() => {
    function handleClickOutside(event) {
      const issueContains = refs.issue.current?.contains(event.target);
      const priorityContains = refs.priority.current?.contains(event.target);

      if (!issueContains && !priorityContains) {
        setDropdowns({ issue: false, priority: false });
      }
    }

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Helper: strip pending file spans from description HTML (plain text + formatting only)
  const getCleanDescription = (html) => {
    if (!html) return "";
    const div = document.createElement("div");
    div.innerHTML = html;
    div.querySelectorAll("[data-pending-file]").forEach((el) => el.remove());
    return div.innerHTML.trim();
  };

  const submitForm = () => {
    let newErrors = {};

    if (!form.ticketSubject.trim())
      newErrors.ticketSubject = "Please fill out this field";
    if (!form.issueRelatedTo)
      newErrors.issueRelatedTo = "Please fill out this field";
    if (!form.priority)
      newErrors.priority = "Please fill out this field";

    // Check description has actual text content (not just attachment spans)
    const cleanDesc = getCleanDescription(form.description);
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = cleanDesc;
    const hasText = tempDiv.textContent.trim().length > 0;
    const hasFiles = pendingFiles.length > 0;

    if (!hasText && !hasFiles)
      newErrors.description = "Please fill out this field";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Pass clean description (no pending spans) + pending files to parent
    onSave?.({
      ...form,
      description: getCleanDescription(form.description),
      pendingFiles: pendingFiles,
    });
    onClose();
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    submitForm();
  };

  useKeyboardNavigation({
    containerRef: popupRef,
    onSubmit: submitForm,
    onCancel: onClose,
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center z-50 p-4">
      <div className="bg-white w-full max-w-2xl p-6 shadow-lg flex flex-col max-h-full overflow-auto">
        <div className="relative flex items-center">
          <h2 className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 text-lg font-semibold text-MediumGrey">
            Create New Ticket
          </h2>

          <button
            onClick={onClose}
            className="ml-auto text-white bg-red-600 rounded-full w-8 h-8 flex items-center justify-center hover:bg-red-700"
            aria-label="Close modal"
            type="button"
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg"
              role="img"
              aria-label="Close icon"
            >
              <circle cx="10" cy="10" r="8" fill="#BF2012" />
              <path
                d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
          </button>
        </div>

        <form ref={popupRef} className="flex flex-col gap-2" onSubmit={handleSubmit} noValidate>
          <div className="flex flex-col">
            <label className="mb-1 text-xs text-black/70 font-medium">
              Ticket Subject
            </label>
            <input
              type="text"
              placeholder="Enter ticket subject"
              className={`border px-3 py-1.5 text-xs focus:outline-none focus:ring-1 ${
                errors.ticketSubject
                  ? "border-red1 focus:border-red1 focus:ring-red1"
                  : "border-black/30 focus:border-black/30 focus:ring-black/30"
              }`}
              value={form.ticketSubject}
              onChange={(e) => handleChange("ticketSubject", e.target.value)}
            />

            {errors.ticketSubject && (
              <p className="text-red1 text-xs mt-1">{errors.ticketSubject}</p>
            )}
          </div>

          <div className="flex gap-4">
            <div className="flex-1">
              <StyledSelectField
                label="Issue Related to"
                placeholder="Select issue"
                value={form.issueRelatedTo}
                setValue={(val) => handleChange("issueRelatedTo", val)}
                options={issueOptions}
                dropdownOpen={dropdowns.issue}
                setDropdownOpen={(val) =>
                  setDropdowns((prev) => ({ ...prev, issue: val }))
                }
                dropdownRef={refs.issue}
                error={errors.issueRelatedTo}
              />
            </div>

            <div className="flex-1">
              <StyledSelectField
                label="Priority"
                placeholder="Select priority"
                value={form.priority}
                setValue={(val) => handleChange("priority", val)}
                options={priorityOptions}
                dropdownOpen={dropdowns.priority}
                setDropdownOpen={(val) =>
                  setDropdowns((prev) => ({ ...prev, priority: val }))
                }
                dropdownRef={refs.priority}
                error={errors.priority}
              />
            </div>
          </div>

          <div className="flex flex-col -mt-1">
            <label className="mb-1 text-xs text-black/70 font-medium">
              Description
            </label>

            <CriteriaDefinitionEditor
              value={form.description}
              onChange={(val) => handleChange("description", val)}
              className={errors.description ? "border border-red1 focus:ring-red1 " : "border-black/30 bg-white hover:ring-1 hover:ring-black/30"}
              onPendingFilesChange={(files) => setPendingFiles(files)}
            />

            {errors.description && (
              <p className="text-red1 text-xs mt-1">{errors.description}</p>
            )}
          </div>

          <div className="flex justify-end gap-3 mt-2">
            <button
              type="submit"
              className=" bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateTicketPopup;