import React from "react"
import Header from "../../Components/Header"
import { useState } from "react"
import SubNavbar3 from "../../Components/SubNavbar3"
import { Eye } from "lucide-react"
import Searchinput from "../../Components/Searchinput"
import Filter from "../../Components/Filter"
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { ArrowLeft } from "lucide-react"
import { useRef } from "react"
import { useNavigate } from "react-router-dom"
import { useSelector } from "react-redux"
import { useEffect } from "react"
import { useMemo } from "react"
import { ChevronDown } from "lucide-react"
import { ChevronUp } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
import { getAllTickets } from "../../services/ticketService"

const AllTickets = () => {
    const navigate = useNavigate()
    const { data: userData } = useSelector((state) => state.user);
    const effectiveRole = userData ? userData.persona : "";
    const isAdmin = effectiveRole === "Administrator";

    const [tickets, setTickets] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)

    const [menuOpen, setMenuOpen] = useState(false)
    const totalTickets = tickets?.length || 0;
    const openTickets = tickets?.filter(t => t.status === "Open").length || 0;
    const closedTickets = tickets?.filter(t => t.status === "Closed").length || 0;
    const newTickets = tickets?.filter(t => t.status === "New").length || 0;
    const [searchTerm, setSearchTerm] = useState("");
    const [showRealToInput, setShowRealToInput] = useState(false);
    const [showRealFromInput, setShowRealFromInput] = useState(false);
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const [sortKey, setSortKey] = useState(null);
    const [sortOrder, setSortOrder] = useState(null);
    const [hoveredName, setHoveredName] = useState(null)
    const toDateRef = useRef(null);
    const dropdownRef = useRef(null);
    const fromDateRef = useRef(null);

    const [filters, setFilters] = useState({
      issueRelated: [],
      priority: [],
      status: [],
    });

    const issueOptions = [...new Set(tickets.map(t => t.issueRelated).filter(Boolean))];
    const priorityOptions = [...new Set(tickets.map(t => t.priority).filter(Boolean))];
    const statusOptions = [...new Set(tickets.map(t => t.status).filter(Boolean))];

    const [showScrollButtons, setShowScrollButtons] = useState(false);
    const [scrollPosition, setScrollPosition] = useState(0);
    const [scrollDirection, setScrollDirection] = useState(null);
    const [lastScrollTop, setLastScrollTop] = useState(0);
    const tableContainerRef = useRef(null);

    // Redirect non-admin users
    useEffect(() => {
      if (!isAdmin) {
        navigate("/support");
      }
    }, [isAdmin]);

    useEffect(() => {
      fetchAllTickets()
    }, [])

    const fetchAllTickets = async () => {
      try {
        setLoading(true)
        setError(null)
        const data = await getAllTickets()
        const transformedData = data.map(ticket => ({
          id: ticket.id,
          ticketNumber: ticket.ticket_no,
          subject: ticket.ticket_subject,
          issueRelated: ticket.issue,
          description: ticket.description,
          createdOn: ticket.created_at,
          resolutionDate: ticket.expected_resolution_date || "NA",
          createdBy: `${ticket.submitted_by_first_name || ""} ${ticket.submitted_by_last_name || ""}`.trim(),
          priority: ticket.priority,
          status: ticket.ticket_status,
        }))
        setTickets(transformedData)
      } catch (err) {
        console.error("Error fetching all tickets:", err)
        setError(err.message)
        setTickets([])
      } finally {
        setLoading(false)
      }
    }

    const getPlainDescription = (html) => {
      if (!html) return "";
      const div = document.createElement("div");
      div.innerHTML = html;
      div.querySelectorAll("[data-file-url]").forEach(el => el.remove());
      return div.textContent.trim();
    };

    const formatDisplayDate = (dateStr) => {
      if (!dateStr || dateStr === "NA" || String(dateStr).trim() === "") return "NA";
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return "NA";
      const day = String(d.getDate()).padStart(2, "0");
      const month = String(d.getMonth() + 1).padStart(2, "0");
      const year = d.getFullYear();
      return `${day}-${month}-${year}`;
    };

    const handleTableScroll = (e) => {
      const container = e.target;
      const scrollTop = container.scrollTop;
      const scrollHeight = container.scrollHeight;
      const clientHeight = container.clientHeight;

      if (scrollTop > lastScrollTop) {
        setScrollDirection('down');
      } else if (scrollTop < lastScrollTop) {
        setScrollDirection('up');
      }
      setLastScrollTop(scrollTop);
      setScrollPosition(scrollTop);

      const isScrollable = scrollHeight > clientHeight;
      const hasScrolledDown = scrollTop > 100;
      
      setShowScrollButtons(isScrollable && hasScrolledDown);
    };

    const scrollToTop = () => {
      if (tableContainerRef.current) {
        tableContainerRef.current.scrollTo({ top: 0, behavior: "smooth" });
      }
    };

    const scrollToBottom = () => {
      if (tableContainerRef.current) {
        tableContainerRef.current.scrollTo({ top: tableContainerRef.current.scrollHeight, behavior: "smooth" });
      }
    };

    const handleSort = (key) => {
      if (sortKey === key) {
        setSortOrder((prev) => (prev === "asc" ? "desc" : "asc"));
      } else {
        setSortKey(key);
        setSortOrder("asc");
      }
    };

    const handleViewClick = (ticket) => {
      navigate("/ticket/view", { state: { ticket } });
    };

    const handleEditClick = (ticket) => {
      navigate("/ticket/edit", { state: { ticket } });
    };

    const filteredTickets = useMemo(() => {
      return tickets.filter((ticket) => {
        const matchesSearch =
          !searchTerm ||
          Object.values(ticket).some((val) =>
            String(val).toLowerCase().includes(searchTerm.toLowerCase())
          );

        const matchesIssue =
          !filters.issueRelated?.length ||
          filters.issueRelated.includes(ticket.issueRelated);

        const matchesPriority =
          !filters.priority?.length ||
          filters.priority.includes(ticket.priority);

        const matchesStatus =
          !filters.status?.length ||
          filters.status.includes(ticket.status);

        const ticketDate = new Date(ticket.createdOn);
        const from = fromDate ? new Date(fromDate) : null;
        const to = toDate ? new Date(toDate) : null;
        const matchesDateRange =
          (!from || ticketDate >= from) && (!to || ticketDate <= to);

        return (
          matchesSearch &&
          matchesIssue &&
          matchesPriority &&
          matchesStatus &&
          matchesDateRange
        );
      });
    }, [tickets, searchTerm, filters, fromDate, toDate]);

    const sortedData = useMemo(() => {
      if (!sortKey || !sortOrder) return filteredTickets;

      return [...filteredTickets].sort((a, b) => {
        let valA = a[sortKey];
        let valB = b[sortKey];

        if (sortKey === "createdOn" || sortKey === "resolutionDate") {
          valA = new Date(valA);
          valB = new Date(valB);
        }

        if (typeof valA === "string") valA = valA.toLowerCase();
        if (typeof valB === "string") valB = valB.toLowerCase();

        if (valA < valB) return sortOrder === "asc" ? -1 : 1;
        if (valA > valB) return sortOrder === "asc" ? 1 : -1;
        return 0;
      });
    }, [filteredTickets, sortKey, sortOrder]);

    return (
      <div className="bg-Frostwhite min-h-screen flex flex-col">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
        <SubNavbar3 />

        <div
          className={`
            transition-all duration-300
            ${menuOpen ? "lg:ml-60" : ""}
            flex justify-center
            flex-1
          `}
        >
          <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
   <div className="flex items-center w-full">
  {/* LEFT */}
  <div className="flex items-center gap-2 flex-1">
      <ArrowLeft
        onClick={() => navigate("/support")}
        size={24}
        className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
      />
      <h2 className="text-lg font-semibold text-darkblue1 font-VolvoNovum text-center">
        View All Tickets
      </h2>
    </div>

    {/* MIDDLE: Card */}
    <div className="px-2">
  <div className="bg-white shadow-[0_4px_10px_#0000001A] py-1">
    <div className="grid grid-cols-5 text-center gap-2">
      {[
        { title: "Total Tickets", value: totalTickets },
        { title: "Open Tickets", value: openTickets },
        { title: "Closed Tickets", value: closedTickets },
        { title: "New Tickets", value: newTickets },
        { title: "Assigned Tickets", value: 0 },
      ].map((item, i) => (
        <div
          key={i}
          className={`py-0 px-3 ${
            i < 4 ? "border-r border-darkblue1" : ""
          } flex flex-col items-center justify-center`}
        >
          <div className="text-xs font-medium text-black">
            {item.title}
          </div>
          <div className="text-sm font-semibold text-SteelBlue1 mt-1">
            {item.value ?? 0}
          </div>
        </div>
      ))}
    </div>
  </div>
    </div>

    {/* RIGHT: Empty space for alignment */}
  <div className="flex items-center gap-2 flex-1 justify-end">
    </div>
  </div>
                <hr className="hidden lg:block w-[7%] border-t-4 -mt-4 border-darkblue1 mb-6 ml-8" />
   <div className="hidden lg:flex w-full items-center justify-between gap-2 mb-2">
    {/* Left: Search + Filters */}
    <div className="flex flex-wrap gap-2 flex-1">

      {/* Search Input */}
      <div className="w-36">
        <Searchinput
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value)
          }}
          placeholder="Search..."
        className="w-full"
        bgColor="bg-FrostWhite"
        borderColor="border-black/60"
        textColor="text-black"
        focusRing="focus:ring-black/60"
        shadow="shadow-none"
        inputPadding="pl-6 pr-3 py-2 sm:py-3"
        iconSize="w-3 h-3"
        iconLeft="left-3"
        iconColor="text-black"
        />
      </div>

      {/* Issue Related To Filter */}
      <Filter
        name="issueRelated"
        value={filters.issueRelated}
        options={issueOptions}
        onChange={(name, val) =>
          setFilters((prev) => ({
            ...prev,
            issueRelated: val,
          }))
        }
        placeholder="Issue Related To"
        placeholderColor="text-black"
        textColor="text-black"
        buttonBorderColor="border-black/60"
        dropdownBorderColor="border-black/60"
        dropdownHoverColor="hover:bg-lightBlue/50"
      />

      {/* Priority Filter */}
      <Filter
        name="priority"
        value={filters.priority}
        options={priorityOptions}
        onChange={(name, val) =>
          setFilters((prev) => ({
            ...prev,
            priority: val,
          }))
        }
        placeholder="Priority"
        placeholderColor="text-black"
        textColor="text-black"
        buttonBorderColor="border-black/60"
        dropdownBorderColor="border-black/60"
        dropdownHoverColor="hover:bg-lightBlue/50"
      />

      {/* Ticket Status Filter */}
      <Filter
        name="status"
        value={filters.status}
        options={statusOptions}
        onChange={(name, val) =>
          setFilters((prev) => ({
            ...prev,
            status: val,
          }))
        }
        placeholder="Ticket Status"
        placeholderColor="text-black"
        textColor="text-black"
        buttonBorderColor="border-black/60"
        dropdownBorderColor="border-black/60"
        dropdownHoverColor="hover:bg-lightBlue/50"
      />
    </div>
   </div>

        <div className="w-full flex-1 flex flex-col min-h-0 ">
  <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
    <div
      ref={tableContainerRef}
      className="overflow-y-auto overflow-x-auto scrollbar-hide"
      style={{
        maxHeight: filteredTickets.length > 8 ? "calc(100vh - 240px)" : "auto",
      }}
      onScroll={handleTableScroll}
    >
      <table className="w-full text-xs whitespace-nowrap table-fixed min-w-[700px] lg:min-w-full">
        <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
         <tr>
    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[8%] cursor-pointer text-left"
      onClick={() => handleSort("ticketNumber")}
    >
      <div className="flex items-center gap-1">
        Ticket #
        {sortKey !== "ticketNumber" && <ChevronsUpDown className="w-3 h-3 text-white" />}
        {sortKey === "ticketNumber" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "ticketNumber" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[12%] cursor-pointer"
      onClick={() => handleSort("subject")}
    >
      <div className="flex items-center gap-1">
        Ticket Subject
        {sortKey === "subject" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "subject" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[12%] cursor-pointer"
      onClick={() => handleSort("issueRelated")}
    >
      <div className="flex items-center gap-1">
        Issue Related To
        {sortKey === "issueRelated" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "issueRelated" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[12%] cursor-pointer"
      onClick={() => handleSort("description")}
    >
      <div className="flex items-center gap-1">
        Description
        {sortKey === "description" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "description" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[12%] cursor-pointer"
      onClick={() => handleSort("createdBy")}
    >
      <div className="flex items-center gap-1">
        Created By
        {sortKey === "createdBy" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "createdBy" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[9%] cursor-pointer"
      onClick={() => handleSort("createdOn")}
    >
      <div className="flex items-center gap-1">
        Created On
        {sortKey === "createdOn" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "createdOn" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%] cursor-pointer whitespace-normal"
      onClick={() => handleSort("resolutionDate")}
    >
      <div className="flex items-center gap-1">
        Exp. Resolution Date
        {sortKey === "resolutionDate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "resolutionDate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[8%] cursor-pointer"
      onClick={() => handleSort("priority")}
    >
      <div className="flex items-center gap-1">
        Priority
        {sortKey === "priority" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "priority" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 w-[10%] cursor-pointer"
      onClick={() => handleSort("status")}
    >
      <div className="flex items-center gap-1">
        Ticket Status
        {sortKey === "status" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "status" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 text-xs font-medium border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 w-[7%] text-center cursor-pointer"
    >
      <div className="flex items-center justify-center gap-1">
        Action
      </div>
    </th>
  </tr>

        </thead>

        <tbody>
          {loading && (
            <tr>
              <td colSpan={10} className="px-6 py-8 text-center text-gray-500">
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                  Loading...
                </div>
              </td>
            </tr>
          )}

          {!loading && sortedData.length > 0 ? (
            sortedData.map((ticket) => (
              <tr key={ticket.id} className="hover:bg-lightBlue/50">
                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  <div className="relative">
                    <p
                      className="truncate max-w-[8rem] cursor-pointer"
                      onMouseEnter={() => {
                        if (ticket.ticketNumber && ticket.ticketNumber.length > 10) {
                          setHoveredName(ticket.id + "-ticketNumber");
                        }
                      }}
                      onMouseLeave={() => setHoveredName(null)}
                    >
                      {ticket.ticketNumber}
                    </p>
                    {hoveredName === ticket.id + "-ticketNumber" && (
                      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                        {ticket.ticketNumber}
                      </span>
                    )}
                  </div>
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  <div className="relative">
                    <p
                      className="truncate max-w-[10rem] cursor-pointer"
                      onMouseEnter={() => {
                        if (ticket.subject && ticket.subject.length > 20) {
                         setHoveredName(ticket.id + "-subject");
                        }
                      }}
                      onMouseLeave={() => setHoveredName(null)}
                    >
                      {ticket.subject}
                    </p>
                    {hoveredName === ticket.id + "-subject" && (
                      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                        {ticket.subject}
                      </span>
                    )}
                  </div>
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  <div className="relative">
                    <p
                      className="truncate max-w-[10rem] cursor-pointer"
                      onMouseEnter={() => {
                        if (ticket.issueRelated && ticket.issueRelated.length > 20) {
                          setHoveredName(ticket.id + "-issueRelated");
                        }
                      }}
                      onMouseLeave={() => setHoveredName(null)}
                    >
                      {ticket.issueRelated}
                    </p>
                    {hoveredName === ticket.id + "-issueRelated" && (
                      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                        {ticket.issueRelated}
                      </span>
                    )}
                  </div>
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  <div className="relative">
                    <p
                      className="truncate max-w-[10rem] cursor-pointer"
                      onMouseEnter={() => {
                        if (getPlainDescription(ticket.description) && getPlainDescription(ticket.description).length > 20) {
                          setHoveredName(ticket.id + "-description");
                        }
                      }}
                      onMouseLeave={() => setHoveredName(null)}
                    >
                      {getPlainDescription(ticket.description) || "-"}
                    </p>
                    {hoveredName === ticket.id + "-description" && (
                      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                        {getPlainDescription(ticket.description)}
                      </span>
                    )}
                  </div>
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  <div className="relative">
                    <p
                      className="truncate max-w-[10rem] cursor-pointer"
                      onMouseEnter={() => {
                        if (ticket.createdBy && ticket.createdBy.length > 15) {
                          setHoveredName(ticket.id + "-createdBy");
                        }
                      }}
                      onMouseLeave={() => setHoveredName(null)}
                    >
                      {ticket.createdBy || "-"}
                    </p>
                    {hoveredName === ticket.id + "-createdBy" && (
                      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                        {ticket.createdBy}
                      </span>
                    )}
                  </div>
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  {formatDisplayDate(ticket.createdOn)}
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                  {ticket.resolutionDate !== "NA"
                    ? formatDisplayDate(ticket.resolutionDate) 
                    : "NA"}
                </td>

                <td
                  className={`px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs font-medium
                    ${
                      ticket.priority === "High"
                        ? "text-green2"
                        : ticket.priority === "Medium"
                        ? "text-SteelBlue1"
                        : ticket.priority === "Low"
                        ? "text-red1"
                        : "text-gray-400"
                    }
                  `}
                >
                  {ticket.priority}
                </td>

                <td
                  className={`px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs font-medium
                    ${
                      ticket.status === "Open"
                        ? "text-SteelBlue1"
                        : ticket.status === "In Progress"
                        ? "text-burntorange"
                        : ticket.status === "Closed"
                        ? "text-green3"
                        : "text-gray-400"
                    }
                  `}
                >
                  {ticket.status}
                </td>

                <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center">
                  <div className="flex items-center justify-center gap-2">
                    <div className="relative group inline-block">
                      <button
                        onClick={() => handleViewClick(ticket)}
                        className="w-5 h-5 hover:bg-lightBlue/50 flex items-center justify-center transition"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M9.59922 7.19961H20.3992V9.59961H9.59922V7.19961ZM9.59922 3.59961H22.7992V5.99961H9.59922V3.59961ZM1.19922 3.59961H8.39922V10.7996H1.19922V3.59961ZM9.59922 16.7996H20.3992V19.1996H9.59922V16.7996ZM9.59922 13.1996H22.7992V15.5996H9.59922V13.1996ZM1.19922 13.1996H8.39922V20.3996H1.19922V13.1996Z" fill="#2C4730"/>
                        </svg>
                      </button>
                      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[9px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none z-0">
                        View 
                      </span>
                    </div>

                    <div className="relative group inline-block">
                      <button 
                        onClick={() => handleEditClick(ticket)}
                        className="group relative">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                          <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                        </svg>
                      </button>
                      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[9px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none z-0">
                        Edit
                      </span>
                    </div>
                  </div>
                </td>
              </tr>
            ))
          ) : (
            !loading && (
              <tr>
                <td colSpan={10} className="text-center py-8 text-gray-500 italic">
                  No tickets found
                </td>
              </tr>
            )
          )}
        </tbody>
      </table>
    </div>

    {showScrollButtons && (
      <div className="fixed bottom-8 right-6 z-40 pointer-events-auto animate-fade-in">
        {scrollDirection === 'down' && (
          <button
            onClick={scrollToTop}
            className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-2 h-2" />
          </button>
        )}

        {scrollDirection === 'up' && (
          <button
            onClick={scrollToBottom}
            className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
            aria-label="Scroll to bottom"
          >
            <ArrowDown className="w-2 h-2" />
          </button>
        )}
      </div>
    )}
  </div>
        </div>
      </div>

      </div>
    </div>
  );
};

export default AllTickets;