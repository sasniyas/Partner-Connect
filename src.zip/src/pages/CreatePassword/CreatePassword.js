import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { API } from '../../api';

const CreatePassword = () => {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [isValidUrl, setIsValidUrl] = useState(true); // ✅ Track URL validation
  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();

  // ✅ Get query parameter from URL
  const urlParams = new URLSearchParams(window.location.search);
  const code = urlParams.get("code");

  // ✅ Check if code exists and validate on mount
  useEffect(() => {
    if (!code) {
      setIsValidUrl(false);
      setLoading(false);
      return;
    }

    const checkUrl = async () => {
      try {
        const link = `${API.domain}${API.userManagement.urlValidation}`
        const headers = { Authorization: `Bearer ${code}` };

        await axios.get(link, { headers });
        setIsValidUrl(true);
      } catch (err) {
        if (err.response?.status === 400 || err.response?.status === 404) {
          setIsValidUrl(false);
        }
        console.error("Error validating URL:", err.response || err.message);
      } finally {
        setLoading(false);
      }
    };

    checkUrl();
  }, [code]);

  const strongPasswordRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,20}$/;

  const handleSubmit = async (e) => {
    e.preventDefault();
    let newErrors = {};

    if (!newPassword) {
      newErrors.newPassword = "Please fill in this field.";
    } else if (!strongPasswordRegex.test(newPassword)) {
      newErrors.newPassword =
        "Password must be 8–20 chars, include uppercase, lowercase, number & special char.";
    }

    if (!confirmPassword) {
      newErrors.confirmPassword = "Please fill in this field.";
    } else if (newPassword !== confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) return;

    try {
      const payload = { token: code, newPassword };

      const res = await fetch(
        `${API.domain}${API.userManagement.setPassword}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );

      const json = await res.json();
      console.log("Response:", json);

      if (json.status) {
        navigate("/"); // ✅ Redirect after success
      }
    } catch (err) {
      console.error("Error setting password:", err);
    }
  };

  const EyeIcon = ({ show }) => (
    <svg
      className="w-5 h-5"
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
      />
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        d="M2.458 12C3.732 7.943 7.523 5 12 5s8.268 2.943 9.542 7c-1.274 4.057-5.065 7-9.542 7S3.732 16.057 2.458 12z"
      />
      {!show && (
        <line
          x1="4"
          y1="4"
          x2="20"
          y2="20"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
        />
      )}
    </svg>
  );

  // ✅ Loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-lg">Validating link...</p>
      </div>
    );
  }

  // ✅ Invalid URL state
  if (!isValidUrl) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-6  shadow-md text-center">
          <h1 className="text-xl font-bold text-red-600 mb-2">Invalid URL</h1>
          <p className="text-gray-700">
            The link you used is not valid or has expired.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row overflow-hidden">
      {/* Left Image */}
      <div className="hidden lg:block lg:w-1/2">
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvologin3.png"
          alt="Background"
          className="w-full h-screen object-cover"
        />
      </div>

      {/* Right Form */}
      <div className="w-full lg:w-1/2 h-screen flex flex-col justify-center px-6 bg-white">
        <div className="flex justify-center mb-10 mt-[-50px]">
          <img
            src="/volvo-spread-word-mark1214[1].jpg"
            alt="Volvo"
            className="w-40 h-auto"
          />
        </div>

        <div className="max-w-sm w-full px-6 mx-auto">
          <h2 className="text-3xl font-bold mb-2 font-VolvoNovum whitespace-nowrap">
            Create Password & Activate User
          </h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* New Password */}
            <div className="relative">
              <input
                type={showNewPassword ? "text" : "password"}
                placeholder="New password"
                value={newPassword}
                maxLength={20}
                onChange={(e) => setNewPassword(e.target.value)}
                className={`w-full border-0 border-b-2 py-1.5 text-sm pr-8 text-black placeholder:text-black/70 font-VolvoNovum focus:outline-none ${errors.newPassword
                  ? "border-red-500 focus:border-red-500"
                  : "border-black/60 focus:border-black"
                  }`}
              />
              <button
                type="button"
                onClick={() => setShowNewPassword(!showNewPassword)}
                className="absolute right-0 top-2.5 text-gray-600"
              >
                <EyeIcon show={showNewPassword} />
              </button>
              {errors.newPassword && (
                <p className="text-xs text-red1 mt-1">{errors.newPassword}</p>
              )}
            </div>

            {/* Confirm Password */}
            <div className="relative">
              <input
                type={showConfirmPassword ? "text" : "password"}
                placeholder="Confirm password"
                value={confirmPassword}
                maxLength={20}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className={`w-full border-0 border-b-2 py-1.5 text-sm pr-8 text-black placeholder:text-black/70 font-VolvoNovum focus:outline-none ${errors.confirmPassword
                  ? "border-red-500 focus:border-red-500"
                  : "border-black/60 focus:border-black"
                  }`}
              />
              <button
                type="button"
                onClick={() =>
                  setShowConfirmPassword(!showConfirmPassword)
                }
                className="absolute right-0 top-2.5 text-gray-600"
              >
                <EyeIcon show={showConfirmPassword} />
              </button>
              {errors.confirmPassword && (
                <p className="text-xs text-red1 mt-1">
                  {errors.confirmPassword}
                </p>
              )}
            </div>

            {/* Confirm Button */}
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-darkblue1 text-white  py-1.5 text-sm font-medium hover:bg-opacity-90 transition"
            >
              Confirm
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreatePassword;
