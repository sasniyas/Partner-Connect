import React from "react";
import { useNavigate } from "react-router-dom";
import Header from "../../Components/Header";
import SubNavbar3 from "../../Components/SubNavbar3";

const NotFound = ({ errorCode = 404, errorMessage = "", onRetry }) => {
  const navigate = useNavigate();

  const getErrorDetails = () => {
    switch (errorCode) {
      case 400:
        return "The server could not understand your request. Please check and try again.";
      case 401:
        return "You are not authorized to access this page. Please login and try again.";
      case 403:
        return "You don't have permission to access this resource.";
      case 404:
        return "Oops! The page you are looking for does not exist.";
      case 500:
        return "Something went wrong on our end. Please try again later.";
      case 502:
        return "The server received an invalid response. Please try again later.";
      case 503:
        return "The service is temporarily unavailable. Please try again later.";
      default:
        return "An unexpected error occurred. Please try again.";
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Header */}
      <Header />

      {/* Sub Navigation */}
      <SubNavbar3 />

      {/* Error Content */}
      <div className="flex-1 flex flex-col items-center justify-center text-center px-6">
        <h1 className="text-6xl font-bold text-darkblue1 font-VolvoNovum">
          {errorCode}
        </h1>
        <p className="mt-2 text-lg text-gray-600 font-VolvoNovum">
          {errorMessage || getErrorDetails()}
        </p>

        <div className="flex items-center gap-3 mt-6">
          {onRetry && (
            <button
              onClick={onRetry}
              className="bg-darkblue1 text-white px-6 py-2 rounded-lg font-medium hover:bg-opacity-90 transition"
            >
              Try Again
            </button>
          )}

          {errorCode !== 404 && (
            <button
              onClick={() => navigate(-1)}
              className="bg-white text-darkblue1 px-6 py-2 rounded-lg font-medium border border-darkblue1 hover:bg-darkblue1 hover:text-white transition"
            >
              Go Back
            </button>
          )}

          <button
            onClick={() => navigate("/")}
            className="bg-darkblue1 text-white px-6 py-2 rounded-lg font-medium hover:bg-opacity-90 transition"
          >
            Back to Login
          </button>
        </div>

        {errorCode !== 404 && (
          <p className="text-xs text-gray-400 mt-4">
            If the problem persists, please contact support.
          </p>
        )}
      </div>
    </div>
  );
};

// ErrorBoundary - catches React crashes and shows 500 error page
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught an error:", error, errorInfo);
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      return (
        <NotFound
          errorCode={500}
          errorMessage="Something went wrong while loading this page. Please try again."
          onRetry={this.handleRetry}
        />
      );
    }

    return this.props.children;
  }
}

export { ErrorBoundary };
export default NotFound;