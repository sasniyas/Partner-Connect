import React from "react";
import { useNavigate } from "react-router-dom";
import DeptTable from "./DeptTable";

const DepartmentScorecard = () => {
  const navigate = useNavigate();

 const buttons = [
   
             { label: "Department Master", path: "/others" },    
             { label: "Designation Master", path:"/others/designation"},  ];
  const currentPath =  "/others" ; // ✅ Update currentPath

  return (
    <div className="w-full flex flex-col items-center justify-center px-2">
      {/* Heading */}
      <h2 className="text-center text-xl font-semibold text-darkblue1 font-VolvoNovum mb-2">
      Contact Management
      </h2>

      {/* Button Row */}
      <div className="w-full overflow-x-auto">
       {/* Tab Navigation */}
<div className="flex w-full mb-2 overflow-hidden ">
  {buttons.map(({ label, path }) => (
    <button
      key={label}
      onClick={() => {
        if (path !== currentPath && path !== "#") navigate(path);
      }}
      className={`flex-1 py-2 text-xs font-medium font-VolvoNovum transition
        ${
          path === currentPath
            ? "bg-Dustyblue text-white"
            : "bg-gray-200 text-gray-700 hover:bg-gray-300"
        }
      `}
    >
      {label}
    </button>
  ))}
</div>

      </div>

      {/* ✅ State Master Table */}
    <div className="w-full flex justify-center">
  <div className="w-full ">

        <DeptTable />
      </div>
      </div>
    </div>
  );
};

export default DepartmentScorecard;
