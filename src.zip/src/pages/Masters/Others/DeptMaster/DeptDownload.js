"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../Components/Header";

function DeptDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]);

  useEffect(() => {
  window.opener?.postMessage({ type: "CHILD_READY" }, "*");

  const handler = (event) => {
    if (event.data?.type === "INIT_DATA") {
      const payloadArray = Array.isArray(event.data.payload) ? event.data.payload : [];
      setTableData(payloadArray);

      if (payloadArray.length > 0) {
        downloadExcel(payloadArray); // auto-download with actual data
      }
    }
  };

  window.addEventListener("message", handler);
  return () => window.removeEventListener("message", handler);
}, []);

// ✅ Always download data passed to it
const downloadExcel = (data) => {
  if (!Array.isArray(data) || data.length === 0) {
    alert("No data available to download");
    return;
  }

  const excelData = data.map((item, index) => ({
    "Sl. No": index + 1,
    Category: item.category || "",
    "Department Name": item.departmentName || "",
    Status: item.status || "Active",
  }));

  const worksheet = XLSX.utils.json_to_sheet(excelData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Department Master");
  XLSX.writeFile(workbook, "Department_Master.xlsx");
};

// Button click
const handleDownloadClick = () => downloadExcel(tableData);


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">Department Master</h2>
          <button
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-sm hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadClick}
          >
            Download
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full text-sm text-left whitespace-nowrap">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 w-[10%]">Sl. No</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 w-[30%]">Category</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 w-[40%]">Department Name</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 w-[20%]">Status</th>
              </tr>
            </thead>
            <tbody>
              {tableData.length > 0 ? (
                tableData.map((item, index) => (
                  <tr key={index} className="hover:bg-lightBlue/50 text-xs font-normal">
                    <td className="px-4 py-1 border border-grey2">{index + 1}</td>
                    <td className="px-6 py-1 border border-grey2">{item.category}</td>
                    <td className="px-6 py-1 border border-grey2">{item.departmentName}</td>
                    <td className="px-6 py-1 border border-grey2">{item.status || "Active"}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="text-center py-4 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default DeptDownload;
