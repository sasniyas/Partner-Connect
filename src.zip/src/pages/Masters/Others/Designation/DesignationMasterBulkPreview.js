"use client";
import React, { useState, useRef, useEffect, useCallback } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import {
  bulkAddDesignations,
  getAllDesignations,
} from "../../../../services/masterOthers/designation.service";
import { getAllDepartments } from "../../../../services/masterOthers/department.service";

const categoryOptions = ["Volvo", "Dealer"];

function DesignationMasterBulkPreview() {
  const [rows, setRows] = useState([]);
  const [fileName, setFileName] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [duplicateInfo, setDuplicateInfo] = useState(null);
  const [isDragActive, setIsDragActive] = useState(false);
  const [departmentsList, setDepartmentsList] = useState([]);

  const [activeDropdown, setActiveDropdown] = useState(null);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0, width: 0 });
  const [dropdownSearch, setDropdownSearch] = useState("");

  const dropdownButtonRefs = useRef({});
  const dropdownMenuRef = useRef(null);
  const tableContainerRef = useRef(null);

  const navigate = useNavigate();

  // Fetch departments on mount
  useEffect(() => {
    fetchDepartments();
  }, []);

  const fetchDepartments = async () => {
    try {
      const response = await getAllDepartments();
      setDepartmentsList(response.filter((d) => d.isActive === 1));
    } catch (err) {
      console.error("Error fetching departments:", err);
      toast.error("Failed to load departments");
    }
  };

  const handleBack = () => navigate("/others/designation");

  // Get department ID by name and category
  const getDepartmentId = (departmentName, category) => {
    const dept = departmentsList.find(
      (d) => d.name === departmentName && d.category === category
    );
    return dept?.id || null;
  };

  // Get filtered departments by category
  const getFilteredDepartments = (category) => {
    return category
      ? departmentsList.filter((d) => d.category === category)
      : departmentsList;
  };

  // ================= PARSE EXCEL FILE =================
  const parseExcelFile = (arrayBuffer) => {
    const data = new Uint8Array(arrayBuffer);
    const workbook = XLSX.read(data, { type: "array" });
    const sheetName = workbook.SheetNames[0];

    let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });

    json = json.filter((row) =>
      Object.values(row).some((cell) => String(cell).trim() !== "")
    );

    const finalRows = json.map((row) => {
      const category = String(row["Category"] || row["CATEGORY"] || "").trim();
      const departmentName = String(row["Department Name"] || row["DEPARTMENT NAME"] || "").trim();
      const name = String(row["Designation"] || row["DESIGNATION"] || "").trim();
      const departmentId = getDepartmentId(departmentName, category);

      const rowData = {
        category,
        departmentName,
        departmentId,
        name,
        isDuplicate: false,
        duplicateReason: "",
      };

      const validation = validateRow(rowData);
      return {
        ...rowData,
        hasError: validation.hasError,
        errors: validation.errors,
      };
    });

    return finalRows;
  };

  // ================= FILE UPLOAD =================
  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully`);
      } catch (error) {
        console.error("Error parsing file:", error);
        toast.error("Failed to parse Excel file");
      }
    };

    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  // ================= DRAG AND DROP HANDLERS =================
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    const file = e.dataTransfer.files[0];
    if (!file) return;

    // Validate file type
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error("Please drop an Excel file (.xlsx or .xls)");
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully`);
      } catch (error) {
        console.error("Error parsing file:", error);
        toast.error("Failed to parse Excel file");
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // ================= VALIDATE ROW =================
  const validateRow = (row) => {
    const errors = [];
    if (!row.category || !categoryOptions.includes(row.category)) errors.push("Invalid Category");
    if (!row.departmentId) errors.push("Invalid Department");
    if (!row.name || !row.name.trim()) errors.push("Designation required");
    return {
      hasError: errors.length > 0,
      errors,
    };
  };

  // ================= CHECK DUPLICATES =================
  const checkDuplicates = async () => {
    if (rows.length === 0) {
      toast.error("No data to check. Please upload a file first.");
      return;
    }

    setIsChecking(true);
    setDuplicateInfo(null);

    try {
      const existingData = await getAllDesignations();

      const existingCombinations = new Set();
      if (Array.isArray(existingData)) {
        existingData.forEach((item) => {
          const key = `${(item.category || "").toLowerCase()}|${item.departmentId}|${(item.name || "").toLowerCase()}`;
          existingCombinations.add(key);
        });
      }

      const seenInFile = new Set();

      const updatedRows = rows.map((row) => {
        const key = `${row.category.toLowerCase()}|${row.departmentId}|${row.name.toLowerCase()}`;

        let isDuplicate = false;
        let duplicateReason = "";

        if (existingCombinations.has(key)) {
          isDuplicate = true;
          duplicateReason = "Already exists in database";
        }

        if (seenInFile.has(key) && !isDuplicate) {
          isDuplicate = true;
          duplicateReason = "Duplicate within file";
        }

        seenInFile.add(key);

        return { ...row, isDuplicate, duplicateReason };
      });

      setRows(updatedRows);

      const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

      if (duplicateCount > 0) {
        setDuplicateInfo({
          count: duplicateCount,
          message: `${duplicateCount} duplicate(s) found! These will be skipped during save.`,
          type: "warning",
        });
        toast.warning(`${duplicateCount} duplicate record(s) found!`);
      } else {
        setDuplicateInfo({
          count: 0,
          message: "No duplicates found. All records are unique.",
          type: "success",
        });
        toast.success("No duplicates found!");
      }
    } catch (error) {
      console.error("Error checking duplicates:", error);
      toast.error("Failed to check duplicates");
    } finally {
      setIsChecking(false);
    }
  };

  // ================= EDIT CELL =================
  const handleCellChange = (rowIdx, key, value) => {
    const updated = [...rows];
    updated[rowIdx][key] = value;

    // If category changes, reset department
    if (key === "category") {
      updated[rowIdx].departmentName = "";
      updated[rowIdx].departmentId = null;
    }

    // If department changes, update departmentId
    if (key === "departmentName") {
      const deptId = getDepartmentId(value, updated[rowIdx].category);
      updated[rowIdx].departmentId = deptId;
    }

    const validation = validateRow(updated[rowIdx]);
    updated[rowIdx].hasError = validation.hasError;
    updated[rowIdx].errors = validation.errors;

    updated[rowIdx].isDuplicate = false;
    updated[rowIdx].duplicateReason = "";

    setRows(updated);
    setDuplicateInfo(null);
  };

  // ================= DELETE ROW =================
  const handleDeleteRow = (rowIdx) => {
    const updated = rows.filter((_, idx) => idx !== rowIdx);
    setRows(updated);
    setDuplicateInfo(null);
    closeDropdown();
  };

  // ================= DROPDOWN HANDLERS =================
  const closeDropdown = useCallback(() => {
    setActiveDropdown(null);
    setDropdownSearch("");
  }, []);

  const handleOpenDropdown = (rowIndex, column) => {
    if (activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column) {
      closeDropdown();
      return;
    }

    const refKey = `${rowIndex}-${column}`;
    const buttonEl = dropdownButtonRefs.current[refKey];
    if (buttonEl) {
      const rect = buttonEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const dropdownHeight = 200;

      const spaceBelow = viewportHeight - rect.bottom;
      const openUpward = spaceBelow < dropdownHeight && rect.top > dropdownHeight;

      setDropdownPosition({
        top: openUpward ? rect.top - dropdownHeight : rect.bottom + 2,
        left: rect.left,
        width: Math.max(rect.width, 180),
      });
    }
    setActiveDropdown({ rowIndex, column });
    setDropdownSearch("");
  };

  const handleSelectOption = (rowIdx, column, value) => {
    handleCellChange(rowIdx, column, value);
    closeDropdown();
  };

  // ================= SAVE =================
  const handleSave = async () => {
    const hasError = rows.some((r) => r.hasError);

    if (hasError) {
      toast.error("Please fix all errors before saving.");
      return;
    }

    if (rows.length === 0) {
      toast.error("No data to save. Please upload a file first.");
      return;
    }

    const rowsToSave = rows.filter((r) => !r.isDuplicate);

    if (rowsToSave.length === 0) {
      toast.error("All records are duplicates. Nothing to save.");
      return;
    }

    setIsSaving(true);

    try {
      const payload = rowsToSave.map((r) => ({
        name: r.name.trim(),
        departmentId: r.departmentId,
        category: r.category.trim(),
      }));

      const response = await bulkAddDesignations(payload);

      if (response.status) {
        const insertedCount = response.data?.inserted || payload.length;
        const invalidCount = response.data?.invalid || 0;

        if (invalidCount > 0) {
          toast.success(
            `${insertedCount} record(s) added successfully! ${invalidCount} duplicate(s) were skipped.`,
            { autoClose: 5000 }
          );
        } else {
          toast.success(`${insertedCount} record(s) added successfully!`);
        }

        setTimeout(() => {
          navigate("/others");
        }, 1500);
      } else {
        toast.error(response.message || "Failed to upload Designation data");
      }
    } catch (error) {
      console.error("Bulk upload error:", error);
      toast.error(error.message || "Failed to upload Designation data");
    } finally {
      setIsSaving(false);
    }
  };

  // ================= CLEAR ALL =================
  const handleClearAll = () => {
    setRows([]);
    setFileName("");
    setDuplicateInfo(null);
    closeDropdown();
  };

  // ================= CLICK OUTSIDE =================
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) return;

      const clickedOnButton = Object.values(dropdownButtonRefs.current).some(
        (ref) => ref?.contains(e.target)
      );

      if (!clickedOnButton) closeDropdown();
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [closeDropdown]);

  // ================= CLOSE ON SCROLL =================
  useEffect(() => {
    const handleTableScroll = () => {
      if (activeDropdown !== null) closeDropdown();
    };

    const tableContainer = tableContainerRef.current;
    if (tableContainer) {
      tableContainer.addEventListener("scroll", handleTableScroll);
    }

    return () => {
      if (tableContainer) {
        tableContainer.removeEventListener("scroll", handleTableScroll);
      }
    };
  }, [activeDropdown, closeDropdown]);

  // ================= DROPDOWN OPTIONS =================
  const getDropdownOptions = () => {
    if (!activeDropdown) return [];

    const { rowIndex, column } = activeDropdown;
    let options = [];

    if (column === "category") {
      options = categoryOptions.map((opt) => ({ id: opt, label: opt }));
    } else if (column === "departmentName") {
      const category = rows[rowIndex]?.category;
      const filteredDepts = getFilteredDepartments(category);
      options = filteredDepts.map((d) => ({ id: d.name, label: d.name }));
    }

    if (dropdownSearch) {
      options = options.filter((opt) =>
        opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
      );
    }

    return options;
  };

  const renderDropdownButton = (row, rowIndex, column) => {
    let isInvalid = false;
    let displayValue = "";
    let placeholder = "";
    let isDisabled = false;

    if (column === "category") {
      isInvalid = !row.category || !categoryOptions.includes(row.category);
      displayValue = row.category || "";
      placeholder = "Select Category";
    } else if (column === "departmentName") {
      isInvalid = !row.departmentId;
      displayValue = row.departmentName || "";
      placeholder = row.category ? "Select Department" : "Select Category First";
      isDisabled = !row.category;
    }

    const isOpen = activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column;
    const refKey = `${rowIndex}-${column}`;

    return (
      <div
        ref={(el) => (dropdownButtonRefs.current[refKey] = el)}
        className={`flex justify-between items-center px-2 py-1 border text-xs min-h-[26px] cursor-pointer ${
          isDisabled
            ? "bg-gray-100 cursor-not-allowed"
            : isInvalid
            ? "border-red-500 bg-red-50"
            : row.isDuplicate
            ? "border-yellow-500 bg-yellow-50"
            : "border-gray-300 bg-white hover:border-gray-400"
        }`}
        onClick={() => !isDisabled && handleOpenDropdown(rowIndex, column)}
      >
        <span className={`flex-1 truncate ${displayValue ? "text-gray-800" : "text-gray-400"}`}>
          {displayValue || placeholder}
        </span>
        {isOpen ? (
          <ChevronUp className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1" />
        ) : (
          <ChevronDown className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1" />
        )}
      </div>
    );
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex-1 flex justify-center`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Back */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer hover:scale-110 text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">Designation Master Bulk Upload</h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[8%] ml-7 mb-2"></div>

          {/* Upload Section */}
          <div className="mb-4 flex flex-wrap items-center gap-2 w-full">
            {/* Drag & Drop Area */}
            <div
              className={`flex-1 min-w-[200px] max-w-md flex items-center border-2 border-dashed px-3 py-1.5 text-xs transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-black/30 bg-white hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="mr-2 flex-shrink-0"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>
              <span className="text-xs text-gray-700 truncate">
                {isDragActive
                  ? "Drop file here..."
                  : fileName || "Drag & drop or click Browse"}
              </span>
              <input
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleBulkUpload}
                id="bulk-upload-input"
              />
            </div>

            <label
              htmlFor="bulk-upload-input"
              className="px-3 py-1.5 bg-darkblue1 text-white text-xs cursor-pointer hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition"
            >
              Browse
            </label>

            {rows.length > 0 && (
              <>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 bg-gray-500 text-white text-xs hover:bg-gray-600 transition"
                >
                  Clear
                </button>

                <button
                  onClick={checkDuplicates}
                  disabled={isChecking || rows.length === 0}
                  className="px-3 py-1.5 bg-yellow-600 text-white text-xs hover:bg-yellow-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  {isChecking && (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  )}
                  {isChecking ? "Checking..." : "Check Duplicates"}
                </button>
              </>
            )}

            <button
              onClick={handleSave}
              disabled={isSaving || rows.length === 0 || rows.some((r) => r.hasError)}
              className="px-4 py-1.5 bg-darkblue1 text-white text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              {isSaving && (
                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
              )}
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>

          {/* Duplicate Info Banner */}
          {duplicateInfo && (
            <div
              className={`mb-2 p-2 border text-xs flex items-center justify-between ${
                duplicateInfo.type === "warning"
                  ? "bg-yellow-50 border-yellow-300 text-yellow-700"
                  : "bg-green-50 border-green-300 text-green-700"
              }`}
            >
              <span>
                <span className="font-medium">{duplicateInfo.type === "warning" ? "⚠️ " : "✅ "}</span>
                {duplicateInfo.message}
              </span>
              <button onClick={() => setDuplicateInfo(null)} className="text-gray-500 hover:text-gray-700">
                ✕
              </button>
            </div>
          )}

          {/* Error Summary */}
          {rows.length > 0 && rows.some((r) => r.hasError) && (
            <div className="mb-2 p-2 bg-red-50 border border-red-200 text-red-600 text-xs">
              <span className="font-medium">⚠️ {rows.filter((r) => r.hasError).length} row(s) have validation errors.</span>
              <span className="ml-2">Please fix all mandatory fields (highlighted in red).</span>
            </div>
          )}

          {/* Table */}
          {rows.length > 0 ? (
            <div className="overflow-auto border border-Dustyblue mb-2 bg-white shadow-md">
              <div ref={tableContainerRef} className="overflow-y-auto max-h-[400px] relative">
                <table className="w-full text-sm bg-white border-collapse">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                    <tr>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[5%]">#</th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[18%]">
                        Category <span className="text-red-300">*</span>
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[25%]">
                        Department Name <span className="text-red-300">*</span>
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[25%]">
                        Designation <span className="text-red-300">*</span>
                      </th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-center w-[12%]">Status</th>
                      <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium text-center w-[8%]">Action</th>
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((row, i) => (
                      <tr
                        key={i}
                        className={`text-xs hover:bg-lightBlue/50 ${
                          row.hasError ? "bg-red-50" : row.isDuplicate ? "bg-yellow-50" : ""
                        }`}
                      >
                        <td className="px-3 py-2 border border-grey2 border-l-0 text-center text-gray-500">{i + 1}</td>

                        <td className="px-3 py-2 border border-grey2">{renderDropdownButton(row, i, "category")}</td>

                        <td className="px-3 py-2 border border-grey2">{renderDropdownButton(row, i, "departmentName")}</td>

                        <td className="px-3 py-2 border border-grey2">
                          <input
                            type="text"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.name
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.name}
                            placeholder="Enter Designation"
                            onChange={(e) => handleCellChange(i, "name", e.target.value)}
                          />
                        </td>

                        <td className="px-3 py-2 border border-grey2 text-center">
                          {row.hasError ? (
                            <span
                              className="px-2 py-0.5 bg-red-100 text-red-600 text-[10px] rounded-full cursor-help"
                              title={row.errors?.join(", ")}
                            >
                              Invalid
                            </span>
                          ) : row.isDuplicate ? (
                            <span
                              className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full cursor-help"
                              title={row.duplicateReason}
                            >
                              Duplicate
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-green-100 text-green-600 text-[10px] rounded-full">Valid</span>
                          )}
                        </td>

                        <td className="px-3 py-2 border border-grey2 border-r-0 text-center">
                          <button onClick={() => handleDeleteRow(i)} className="text-red-500 hover:text-red-700 transition" title="Delete Row">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                              <g clipPath="url(#clip0_6398_313)">
                                <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                              </g>
                              <defs>
                                <clipPath id="clip0_6398_313">
                                  <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                                </clipPath>
                              </defs>
                            </svg>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Footer */}
              <div className="px-4 py-2 bg-gray-50 border-t border-grey2 flex flex-wrap justify-between items-center gap-2">
                <span className="text-xs text-gray-600">
                  Total: {rows.length} row(s) |
                  <span className="text-green-600 ml-1">Valid: {rows.filter((r) => !r.hasError && !r.isDuplicate).length}</span> |
                  <span className="text-yellow-600 ml-1">Duplicates: {rows.filter((r) => r.isDuplicate).length}</span> |
                  <span className="text-red-600 ml-1">Errors: {rows.filter((r) => r.hasError).length}</span>
                </span>
                <span className="text-xs text-gray-500 italic">💡 Click "Check Duplicates" before saving to identify existing records</span>
              </div>
            </div>
          ) : (
            /* Empty State - WITH DRAG AND DROP */
            <div
              className={`bg-white shadow-md border-2 border-dashed p-8 text-center transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-Dustyblue hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="w-12 h-12 mx-auto mb-3 opacity-50"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>

              <p className="text-gray-500 text-sm">
                {isDragActive
                  ? "Drop your Excel file here!"
                  : "No data loaded. Please upload an Excel file to preview."}
              </p>
              <p className="text-gray-400 text-xs mt-1">
                {isDragActive
                  ? "Release to upload"
                  : "Supported formats: .xlsx, .xls (Drag & drop or click Browse)"}
              </p>
              <p className="text-gray-400 text-xs mt-1">Required columns: Category, Department Name, Designation</p>
            </div>
          )}
        </div>
      </div>

      {/* UNIVERSAL CUSTOM DROPDOWN */}
      {activeDropdown !== null && rows[activeDropdown.rowIndex] && (
        <div
          ref={dropdownMenuRef}
          className="fixed border border-gray-300 bg-white z-[9999] shadow-xl rounded overflow-hidden"
          style={{
            top: `${dropdownPosition.top}px`,
            left: `${dropdownPosition.left}px`,
            width: `${dropdownPosition.width}px`,
            minWidth: "180px",
          }}
        >
          <div className="p-2 border-b border-gray-200 bg-gray-50">
            <input
              type="text"
              placeholder={`Search ${activeDropdown.column === "category" ? "category" : "department"}...`}
              value={dropdownSearch}
              onChange={(e) => setDropdownSearch(e.target.value)}
              className="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:outline-none focus:border-darkblue1"
              autoFocus
            />
          </div>

          <div className="max-h-[150px] overflow-y-auto">
            {getDropdownOptions().length > 0 ? (
              getDropdownOptions().map((option) => {
                let isSelected = false;
                if (activeDropdown.column === "category") {
                  isSelected = rows[activeDropdown.rowIndex].category === option.id;
                } else if (activeDropdown.column === "departmentName") {
                  isSelected = rows[activeDropdown.rowIndex].departmentName === option.id;
                }

                return (
                  <div
                    key={option.id}
                    className={`flex items-center gap-2 px-3 py-1.5 cursor-pointer text-xs border-b border-gray-100 last:border-b-0 ${
                      isSelected ? "bg-blue-50" : "hover:bg-gray-50"
                    }`}
                    onClick={() => handleSelectOption(activeDropdown.rowIndex, activeDropdown.column, option.id)}
                  >
                    <span className={isSelected ? "text-blue-700 font-medium" : ""}>{option.label}</span>
                    {isSelected && <span className="ml-auto text-blue-500">✓</span>}
                  </div>
                );
              })
            ) : (
              <div className="px-3 py-3 text-xs text-gray-400 text-center">
                {activeDropdown.column === "departmentName" && !rows[activeDropdown.rowIndex]?.category
                  ? "Select category first"
                  : "No options found"}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default DesignationMasterBulkPreview;