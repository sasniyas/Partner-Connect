import React, { useState,useEffect } from "react";
import Header from "../../../../Components/Header";
// import Dashboard from "../Homepage/Dashboard";
import SubNavbar3 from "../../../../Components/SubNavbar3";

import DesignationScorecard from "./DesignationScorecard";


function Designation() {
  const [menuOpen, setMenuOpen] = useState(false);
  


  return (
<div className="bg-Frostwhite h-screen flex flex-col">
      {/* Navigation Bar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
<SubNavbar3/>
      {/* Main Content - Moves Right when Sidebar Opens */}
      {/* <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : "ml-0"} mt-[-10px] p-4`}> */}
      <div
        className={`transition-all duration-300 ${
          menuOpen ? "ml-60" : ""
        }`}
      >
           {/* <div className="w-full mt-[-10px] md:mt-[-40px] lg:mt-[-10px] p-2 xl:mt-[-20px] lg:w-[100%] xl:w-[100%] 2xl:w-[100%] 2xl:mt-[-420px] "> */}

        {/* <img src="/homepageimage.png" alt="home page"/> */}
                <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:p-2">

        <DesignationScorecard/>
        {/* </div> */}
       </div>

      </div>
    </div>
  );
}

export default Designation;
