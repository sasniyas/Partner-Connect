"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../Components/Header";

function DesignationMasterDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]);

  // ✅ Listen for postMessage from parent window
  useEffect(() => {
  // Tell parent we are ready
  window.opener?.postMessage({ type: "CHILD_READY" }, "*");

  const handler = (event) => {
    if (event.data?.type === "INIT_DATA") {
      setTableData(event.data.payload || []);
    }
  };

  window.addEventListener("message", handler);
  return () => window.removeEventListener("message", handler);
}, []);


  const handleDownloadExcel = () => {
  if (!tableData || tableData.length === 0) return;

  const excelData = tableData.map((item, index) => ({
    "Sl. No": index + 1,
    "Category": item.category,
    "Department Name": item.departmentName,
    "Designation": item.designation,
    "Status": item.status || "Active",
  }));

  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // Only apply alignment to actual cells, skip metadata
  Object.keys(worksheet).forEach((cell) => {
    if (cell[0] !== "!") {
      worksheet[cell].s = { alignment: { horizontal: "left" } };
    }
  });

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Designation Master");
  XLSX.writeFile(workbook, "Designation_Master.xlsx");
};


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">Designation Master</h2>
          <button
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-sm  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadExcel}
          >
            Download
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full text-sm text-left whitespace-nowrap">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 w-[10%]">Sl. No</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 w-[25%]">Category</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 w-[25%]">Department Name</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 w-[25%]">Designation</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 w-[15%]">Status</th>
              </tr>
            </thead>
            <tbody>
              {tableData.length > 0 ? (
                tableData.map((item, index) => (
                  <tr key={index} className="hover:bg-lightBlue/50 text-xs font-normal">
                    <td className="px-4 py-1 border border-grey2">{index + 1}</td>
                    <td className="px-6 py-1 border border-grey2">{item.category}</td>
                    <td className="px-6 py-1 border border-grey2">{item.departmentName}</td>
                    <td className="px-6 py-1 border border-grey2">{item.designation}</td>
                    <td className="px-6 py-1 border border-grey2">{item.status || "Active"}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="text-center py-4 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default DesignationMasterDownload;
