import React, { useRef, useState, useEffect } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import Searchinput from "../../../Components/Searchinput";
import Filter from "../../../Components/Filter";
import { getAllSubKPIs, updateFormulaSubKpi } from "../../../services/Masters/SubKpi/subKpi.service";
import { toast } from "react-toastify"; // Assuming toast is used based on other files, but I'll check if it's available. If not, I'll use simple alert or console.

const Subkpiformulae = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [data, setData] = useState([]);
  const tableContainerRef = useRef();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedYear, setSelectedYear] = useState("");
  const [selectedObjective, setSelectedObjective] = useState("");
  const [selectedKpi, setSelectedKpi] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("");
  const [error, setError] = useState("");

  const [editRow, setEditRow] = useState(null);
  const [editedFormula, setEditedFormula] = useState("");

  // Options for filters (can be made dynamic from data)
  const [yearoptions, setYearOptions] = useState([]);
  const [objectiveoptions, setObjectiveOptions] = useState([]);
  const [kpioptions, setKpiOptions] = useState([]);

  // 🔹 Fetch Data
  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await getAllSubKPIs();
      const mappedData = res.map((item) => ({
        id: item.id,
        year: String(item.createdYear),
        objective: item.objectiveName || "",
        kpiNo: item.kpiNumber || "",
        kpi: item.kpiName || "",
        subkpi: item.subKpiName || "",
        formulae: item.formula || "",
        active: item.isActive === 1,
      }));
      setData(mappedData);

      // Extract unique options for filters
      const years = [...new Set(mappedData.map(item => item.year))].sort().reverse();
      const objectives = [...new Set(mappedData.map(item => item.objective))].filter(Boolean).sort();
      const kpis = [...new Set(mappedData.map(item => item.kpi))].filter(Boolean).sort();

      setYearOptions(years);
      setObjectiveOptions(objectives);
      setKpiOptions(kpis);
    } catch (err) {
      console.error("Error fetching Sub KPIs:", err);
      // alert("Failed to fetch data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // 🔹 Filter + Search logic
  const filteredData = data.filter((row) => {
    // Year filter
    const yearMatch = !selectedYear || row.year === selectedYear;

    // Objective filter
    const objectiveMatch =
      !selectedObjective || row.objective === selectedObjective;

    // KPI filter
    const kpiMatch = !selectedKpi || row.kpi === selectedKpi;

    // Status filter
    let statusMatch = true;
    if (selectedStatus) {
      if (selectedStatus === "Active") statusMatch = row.active === true;
      else if (selectedStatus === "Inactive") statusMatch = row.active === false;
    }

    // Search filter
    const searchMatch = Object.values(row)
      .join(" ")
      .toLowerCase()
      .includes(searchTerm.toLowerCase());

    return yearMatch && objectiveMatch && kpiMatch && statusMatch && searchMatch;
  });

  // 🔹 Open Edit Modal
  const handleEdit = (row) => {
    setEditRow(row);
    setEditedFormula(row.formulae);
  };



  // 🔹 Save Formula
  const handleSave = async () => {
    setLoading(true);
    try {
      await updateFormulaSubKpi({
        id: editRow.id,
        formula: editedFormula,
      });

      // Update local state
      setData((prev) =>
        prev.map((item) =>
          item.id === editRow.id
            ? { ...item, formulae: editedFormula }
            : item
        )
      );
      setEditRow(null);
      toast.success("Formula updated successfully!");
    } catch (err) {
      console.error("Error updating formula:", err);
      setError(err.message || "Failed to update formula");
      toast.error(err.message || "Failed to update formula");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-Frostwhite h-screen overflow-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 flex-1 ${menuOpen ? "lg:ml-60" : ""
          }`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] px-4">
          {/* 🔹 Heading */}
          <h2 className="text-center text-lg font-semibold text-darkblue1 font-VolvoNovum mb-3">
            Sub KPI Formulae
          </h2>

          {/* 🔹 Search + Filters */}
          <div className="mb-3 flex flex-wrap gap-2 items-center">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="min-w-[120px] max-w-[180px]"
              iconColor="text-black"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-1.5"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              inputWidth="w-full"
              focusRing="focus:ring-1 focus:ring-black/60"
              hoverInputClasses="hover:bg-white hover:border-black/60"
            />

            <Filter
              name="year"
              value={selectedYear ? [selectedYear] : []}
              options={yearoptions}
              onChange={(name, value) => setSelectedYear(value[0] || "")}
              placeholder="Year"
              customWidth="w-[120px]"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />

            <Filter
              name="objective"
              value={selectedObjective ? [selectedObjective] : []}
              options={objectiveoptions}
              onChange={(name, value) => setSelectedObjective(value[0] || "")}
              placeholder="Strategic Objective"
              customWidth="w-[220px]"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />

            <Filter
              name="kpi"
              value={selectedKpi ? [selectedKpi] : []}
              options={kpioptions}
              onChange={(name, value) => setSelectedKpi(value[0] || "")}
              placeholder="KPI"
              customWidth="w-[180px]"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />
            <Filter
              name="status"
              value={selectedStatus ? [selectedStatus] : []}
              options={["Active", "Inactive"]}
              onChange={(name, value) => setSelectedStatus(value[0] || "")}
              placeholder="Status"
              customWidth="w-[120px]"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />
          </div>

          {/* 🔹 Table */}
          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
            <div
              ref={tableContainerRef}
              className="overflow-y-auto overflow-x-auto scrollbar-hide"
              style={{
                maxHeight: filteredData.length > 10 ? "calc(100vh - 200px)" : "auto",
              }}
            >
              <table className="w-full text-xs whitespace-nowrap table-fixed">
                <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                  <tr>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[5%]">Year</th>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[20%]">Strategic Objective</th>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[5%]">KPI No</th>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[20%]">KPI</th>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[20%]">Sub KPI</th>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[20%]">Formulae</th>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[10%]">Status</th>
                    <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium w-[5%]"></th>
                  </tr>
                </thead>
                <tbody>
                  {loading && data.length === 0 ? (
                    <tr>
                      <td colSpan="8" className="p-4 text-center">Loading...</td>
                    </tr>
                  ) : (
                    filteredData.map((row) => (
                      <tr
                        key={row.id}
                        className={row.active ? "text-black" : "text-gray-400"}
                      >
                        <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0">{row.year}</td>
                        <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 break-words whitespace-normal">{row.objective}</td>
                        <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0">{row.kpiNo}</td>
                        <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 break-words whitespace-normal">{row.kpi}</td>
                        <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 break-words whitespace-normal">{row.subkpi}</td>
                        <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 break-words whitespace-normal">{row.formulae}</td>
                        <td
                          className={`px-3 py-1 border border-grey2 border-t-0 border-l-0 font-medium ${row.active ? "text-green-600" : "text-red-600"}`}
                        >
                          {row.active ? "Active" : "Inactive"}
                        </td>
                        {/* 🔹 Actions Column */}
                        <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <div className="relative inline-block group">
                              <button onClick={() => handleEdit(row)}>
                                <img
                                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png"
                                  className="w-[14px] h-[14px] object-contain"
                                  alt="Edit"
                                />
                              </button>
                              <span className="absolute top-[110%] left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-[1px] z-50 whitespace-nowrap pointer-events-none">
                                Edit Formula
                              </span>
                            </div>

                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                  {!loading && filteredData.length === 0 && (
                    <tr>
                      <td colSpan="8" className="p-4 text-center text-gray-500">
                        No data found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* 🔹 Edit Modal */}
      {editRow && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white w-full max-w-md shadow-lg p-4">
            <div className="relative mb-3 flex items-center justify-center">
              {/* Centered Title */}
              <h2 className="text-base text-darkblue1 font-semibold">
                Edit Sub KPI Formulae
              </h2>

              {/* Close Button */}
              <button
                className="absolute right-0 text-gray-500 hover:text-black"
                onClick={() => {
                  setEditRow(null);
                  setError(""); // reset error on close
                }}
              >
                <img
                  src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
                  alt="Close"
                  className="w-4 h-4"
                />
              </button>
            </div>

            <label className="block text-sm mb-1">Formulae</label>
            <textarea
              className={`w-full border px-3 py-1.5 text-sm mb-1 
    ${error ? "border-red1 focus:border-red1" : "border-black/30 focus:border-black/30"} 
    focus:outline-none`}
              value={editedFormula}
              onChange={(e) => {
                setEditedFormula(e.target.value);
                if (error && e.target.value.trim() !== "") setError(""); // remove error when typing
              }}
              rows={3}
            />

            {/* Error Message */}
            {error && <p className="text-red1 text-xs mb-2">{error}</p>}

            <div className="flex items-center justify-center gap-4 mt-2">
              <button
                onClick={() => {
                  if (!editedFormula.trim()) {
                    setError("Please fill this field");
                    return;
                  }
                  handleSave();
                }}
                disabled={loading}
                className={`bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 
            transition ${loading
                    ? "opacity-50 cursor-not-allowed"
                    : "hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                  }`}
              >
                {loading ? "Saving..." : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Subkpiformulae;
