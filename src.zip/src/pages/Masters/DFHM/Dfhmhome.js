import React, { useState } from "react";
import Header from "../../../Components/Header";
import PLTab from "./PLTab";
import BalanceSheetTab from "./BalanceSheetTab";
import HeadCountTab from "./HeadCountTab";
import RatioAnalysisTab from "./RatioAnalysisTab";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { useLocation } from "react-router-dom";
function DfhmMasterData() {
  const [menuOpen, setMenuOpen] = useState(false);
const location = useLocation();

const [activeTab, setActiveTab] = useState(
  location.state?.activeTab || "pl"
);

  return (
<div className="bg-Frostwhite h-screen  flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3/>
      
      {/* Removed the fixed left margin and padding adjustments */}
      <div className="transition-all duration-300  flex-1">
        
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
      <h2 className="text-center text-xl  font-semibold text-darkblue1 font-VolvoNovum mb-2">
              DFHM Master Data
            </h2>

            {/* Tab Buttons Container */}
            <div className="flex justify-center gap-4 mb-2 flex-wrap">
              {/* P&L Tab */}
              <button
                onClick={() => setActiveTab("pl")}
                className={`px-6 py-1 text-sm  font-medium transition-all duration-200 flex items-center justify-center gap-2 min-w-[120px] shadow-sm
                ${
                  activeTab === "pl"
                    ? "bg-[#7F96B3] text-white"
                    : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
                }`}
              >
                P&L
              </button>

              {/* Balance Sheet Tab */}
              <button
                onClick={() => setActiveTab("balanceSheet")}
                className={`px-6 py-1 text-sm  font-medium transition-all duration-200 flex items-center justify-center gap-2 min-w-[150px] shadow-sm
                ${
                  activeTab === "balanceSheet"
                    ? "bg-[#7F96B3] text-white"
                    : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
                }`}
              >
                Balance Sheet
              </button>

              {/* Head Count Tab */}
              <button
                onClick={() => setActiveTab("headCount")}
                className={`px-6 py-1 text-sm  font-medium transition-all duration-200 flex items-center justify-center gap-2 min-w-[130px] shadow-sm
                ${
                  activeTab === "headCount"
                    ? "bg-[#7F96B3] text-white"
                    : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
                }`}
              >
                Head Count
              </button>

              {/* Ratio Analysis Tab */}
              <button
                onClick={() => setActiveTab("ratioAnalysis")}
                className={`px-6 py-1 text-sm  font-medium transition-all duration-200 flex items-center justify-center gap-2 min-w-[150px] shadow-sm
                ${
                  activeTab === "ratioAnalysis"
                    ? "bg-[#7F96B3] text-white"
                    : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
                }`}
              >
                Ratio Analysis
              </button>
            </div>

            {/* Tab content rendering */}
             <div className="w-full flex justify-center">
  <div className="w-full ">
              {activeTab === "pl" && <PLTab />}
              {activeTab === "balanceSheet" && <BalanceSheetTab />}
              {activeTab === "headCount" && <HeadCountTab />}
              {activeTab === "ratioAnalysis" && <RatioAnalysisTab />}
            </div>
          </div>
        </div>
      </div>
      </div>
   
  );
}

export default DfhmMasterData;