import React from "react";
import { useNavigate } from "react-router-dom";
import MarketAreaTable from "./MarketAreaTable"; // or replace with correct table per view

const  Marketareascorecard = () => {
  const navigate = useNavigate();

  const buttons = [
    { label: "Market Area", path: "/masters/scorecard" },
    { label: "Country Master", path: "/masters/countrymaster" }, // Current page
    { label: "State Master", path: "/masters/statemaster" },
    { label: "City Master", path:  "/masters/citymaster" },
        { label: "Dealer Master", path: "/masters/dealermaster" },
              { label: "Role Master", path: "/masters/roles"  },

      { label: "Strategic Objective", path: "/masters/strategicobjective"  },

    { label: "KPI Master", path:"/masters/kpimaster" },
    { label: "Sub KPI Master", path:"/masters/subkpimaster" },
    // { label: "Updates", path: "/masters/updates" },
  ];

  return (
    <div className="w-full flex flex-col items-center justify-center px-2  ">
      <h2 className="text-center text-xl   font-semibold text-darkblue1 font-VolvoNovum mb-2">
        Scorecard Master Data
      </h2>

      <div className="w-full overflow-x-auto">
        <div className="flex justify-center gap-1 w-full">
                  {/* <div className="flex justify-center gap-5 min-w-[1100px]"> */}

          {buttons.map(({ label, path }, index) => (
            <button
              key={label}
              onClick={() => navigate(path)}
              className={`w-full py-2  whitespace-nowrap  text-xs font-medium font-VolvoNovum transition duration-200 
                ${
                  index === 0
                    ? "bg-Dustyblue text-white border border-Dustyblue"
                    : "bg-white text-black border border-darkblue1 hover:bg-Dustyblue hover:text-white"
                }
              `}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* You can remove this if it's specific to "Market Area" only */}
    <div className="w-full flex justify-center">
  <div className="w-full">
    <MarketAreaTable />
  </div>
</div>


    </div>
  );
};

export default Marketareascorecard;
