"use client";

import React, { useState, useRef } from "react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

// ⭐ Import service functions
import {
  bulkAddMarketAreas,
  checkDuplicatesInUpload,
  parseMarketAreaExcel,
} from "../../../../services/Masters/MarketArea/marketArea.service";

function MABulkUpload() {
  const navigate = useNavigate();

  // ═══════════════════════════════════════════════════════════════
  // 📊 STATE MANAGEMENT
  // ═══════════════════════════════════════════════════════════════
  const [rows, setRows] = useState([]);
  const [fileName, setFileName] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [duplicateInfo, setDuplicateInfo] = useState(null);
  const [isDragActive, setIsDragActive] = useState(false);

  const tableContainerRef = useRef(null);

  // ═══════════════════════════════════════════════════════════════
  // 🔙 NAVIGATION
  // ═══════════════════════════════════════════════════════════════
  const handleBack = () => {
    navigate("/masters/scorecard", {
      state: { activeTab: "marketArea" },
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 📁 FILE UPLOAD - Using Service with rowId
  // ═══════════════════════════════════════════════════════════════
  const handleBulkUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setFileName(file.name);
    setDuplicateInfo(null);

    try {
      const parsedRows = await parseMarketAreaExcel(file);

      // ⭐ Add unique rowId to each row
      const rowsWithIds = parsedRows.map((row, index) => ({
        ...row,
        rowId: `row-${Date.now()}-${index}`,
      }));

      setRows(rowsWithIds);
      toast.success(`${rowsWithIds.length} row(s) loaded successfully!`);
    } catch (error) {
      console.error("Error parsing file:", error);
      toast.error(error.message || "Failed to parse Excel file");
    }

    e.target.value = "";
  };

  // ═══════════════════════════════════════════════════════════════
  // 🎯 DRAG AND DROP HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    const file = e.dataTransfer.files[0];
    if (!file) return;

    // Validate file type
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error("Please drop an Excel file (.xlsx or .xls)");
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    try {
      const parsedRows = await parseMarketAreaExcel(file);

      // ⭐ Add unique rowId to each row
      const rowsWithIds = parsedRows.map((row, index) => ({
        ...row,
        rowId: `row-${Date.now()}-${index}`,
      }));

      setRows(rowsWithIds);
      toast.success(`${rowsWithIds.length} row(s) loaded successfully!`);
    } catch (error) {
      console.error("Error parsing file:", error);
      toast.error(error.message || "Failed to parse Excel file");
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔍 CHECK DUPLICATES - Using Service
  // ═══════════════════════════════════════════════════════════════
  const checkDuplicates = async () => {
    if (rows.length === 0) {
      toast.error("No data to check. Please upload a file first.");
      return;
    }

    setIsChecking(true);
    setDuplicateInfo(null);

    try {
      const { updatedRows, duplicateCount } = await checkDuplicatesInUpload(rows);

      // ⭐ Preserve rowId when updating rows
      const rowsWithIds = updatedRows.map((row, index) => ({
        ...row,
        rowId: rows[index]?.rowId || `row-${Date.now()}-${index}`,
      }));

      setRows(rowsWithIds);

      if (duplicateCount > 0) {
        setDuplicateInfo({
          count: duplicateCount,
          message: `${duplicateCount} duplicate(s) found! These will be skipped during save.`,
          type: "warning",
        });
        toast.warning(`${duplicateCount} duplicate record(s) found!`);
      } else {
        setDuplicateInfo({
          count: 0,
          message: "No duplicates found. All records are unique.",
          type: "success",
        });
        toast.success("No duplicates found!");
      }
    } catch (error) {
      console.error("Error checking duplicates:", error);
      toast.error(error.message || "Failed to check duplicates");
    } finally {
      setIsChecking(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // ✏️ EDIT CELL - Using rowId for tracking
  // ═══════════════════════════════════════════════════════════════
  const handleCellChange = (rowIdx, value) => {
    const updated = [...rows];
    updated[rowIdx].marketArea = value;
    updated[rowIdx].hasError = !value.trim();
    updated[rowIdx].isDuplicate = false;
    updated[rowIdx].duplicateReason = "";

    setRows(updated);
    setDuplicateInfo(null);
  };

  // ═══════════════════════════════════════════════════════════════
  // 🗑️ DELETE ROW - Using rowId
  // ═══════════════════════════════════════════════════════════════
  const handleDeleteRow = (rowId) => {
    const updated = rows.filter((row) => row.rowId !== rowId);
    setRows(updated);
    setDuplicateInfo(null);
  };

  // ═══════════════════════════════════════════════════════════════
  // 💾 SAVE - Using Service
  // ═══════════════════════════════════════════════════════════════
  const handleSave = async () => {
    const hasError = rows.some((r) => !r.marketArea?.trim());

    if (hasError) {
      toast.error("Please fix all errors before saving. Market Area is mandatory.");
      return;
    }

    if (rows.length === 0) {
      toast.error("No data to save. Please upload a file first.");
      return;
    }

    // Filter out duplicates
    const rowsToSave = rows.filter((r) => !r.isDuplicate);

    if (rowsToSave.length === 0) {
      toast.error("All records are duplicates. Nothing to save.");
      return;
    }

    setIsSaving(true);

    try {
      const payload = rowsToSave.map((r) => ({
        marketarea: r.marketArea.trim(),
      }));

      console.log("💾 Saving:", payload.length, "records");

      const response = await bulkAddMarketAreas(payload);

      if (response.status) {
        const insertedCount = response.data?.inserted || payload.length;
        const invalidCount = response.data?.invalid || 0;

        if (invalidCount > 0) {
          toast.success(
            `${insertedCount} Market Area(s) added! ${invalidCount} duplicate(s) skipped.`,
            { autoClose: 5000 }
          );
        } else {
          toast.success(`${insertedCount} Market Area(s) added successfully!`);
        }

        setTimeout(() => {
          navigate("/masters/scorecard", { state: { activeTab: "marketArea" } });
        }, 1500);
      } else {
        toast.error(response.message || "Failed to upload Market Areas");
      }
    } catch (error) {
      console.error("Error saving:", error);
      toast.error(error.message || "Failed to upload Market Areas");
    } finally {
      setIsSaving(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🧹 CLEAR ALL
  // ═══════════════════════════════════════════════════════════════
  const handleClearAll = () => {
    setRows([]);
    setFileName("");
    setDuplicateInfo(null);
  };

  // ═══════════════════════════════════════════════════════════════
  // 📊 COMPUTED VALUES
  // ═══════════════════════════════════════════════════════════════
  const validCount = rows.filter((r) => !r.hasError && !r.isDuplicate).length;
  const duplicateCount = rows.filter((r) => r.isDuplicate).length;
  const errorCount = rows.filter((r) => r.hasError).length;

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "lg:ml-60" : ""
        } flex-1 flex justify-center`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Back Button & Title */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer hover:scale-110 text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">
              Market Area Bulk Upload
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[10%] ml-7 mb-2"></div>

          {/* Upload Section */}
          <div className="mb-4 flex flex-wrap items-center gap-2 w-full">
            {/* Drag & Drop Area */}
            <div
              className={`flex-1 min-w-[200px] max-w-md flex items-center border-2 border-dashed px-3 py-1.5 text-xs transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-black/30 bg-white hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="mr-2 flex-shrink-0"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>

              <span className="text-xs text-gray-700 truncate">
                {isDragActive
                  ? "Drop file here..."
                  : fileName || "Drag & drop or click Browse"}
              </span>

              <input
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleBulkUpload}
                id="bulk-upload-input"
              />
            </div>

            {/* Browse Button */}
            <label
              htmlFor="bulk-upload-input"
              className="px-3 py-1.5 bg-darkblue1 text-white text-xs cursor-pointer hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition"
            >
              Browse
            </label>

            {/* Action Buttons */}
            {rows.length > 0 && (
              <>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 bg-gray-500 text-white text-xs hover:bg-gray-600 transition"
                >
                  Clear
                </button>

                <button
                  onClick={checkDuplicates}
                  disabled={isChecking}
                  className="px-3 py-1.5 bg-yellow-600 text-white text-xs hover:bg-yellow-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  {isChecking && (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  )}
                  {isChecking ? "Checking..." : "Check Duplicates"}
                </button>
              </>
            )}

            <button
              onClick={handleSave}
              disabled={isSaving || rows.length === 0}
              className="px-4 py-1.5 bg-darkblue1 text-white text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              {isSaving && (
                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
              )}
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>

          {/* Duplicate Info Banner */}
          {duplicateInfo && (
            <div
              className={`mb-2 p-2 border text-xs flex items-center justify-between ${
                duplicateInfo.type === "warning"
                  ? "bg-yellow-50 border-yellow-300 text-yellow-700"
                  : "bg-green-50 border-green-300 text-green-700"
              }`}
            >
              <span>
                <span className="font-medium">
                  {duplicateInfo.type === "warning" ? "⚠️ " : "✅ "}
                </span>
                {duplicateInfo.message}
              </span>
              <button
                onClick={() => setDuplicateInfo(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
          )}

          {/* Error Summary */}
          {rows.length > 0 && errorCount > 0 && (
            <div className="mb-2 p-2 bg-red-50 border border-red-200 text-red-600 text-xs">
              <span className="font-medium">⚠ {errorCount} row(s) have validation errors.</span>
              <span className="ml-2">Please fill in all Market Area fields.</span>
            </div>
          )}

          {/* ⭐ RESPONSIVE TABLE */}
          {rows.length > 0 ? (
            <div className="shadow-md border border-Dustyblue overflow-hidden w-full">
              <div
                ref={tableContainerRef}
                className="overflow-y-auto overflow-x-auto scrollbar-hide"
                style={{
                  maxHeight: rows.length > 10 ? "calc(100vh - 280px)" : "auto",
                }}
              >
                <table className="w-full text-xs text-left table-fixed min-w-[400px] lg:min-w-full">
                  <thead className="bg-Dustyblue text-white text-xs font-medium sticky top-0 z-20">
                    <tr>
                      <th className="px-3 py-1.5 font-medium text-xs border border-grey2 border-t-0 border-l-0 text-left w-[8%]">
                        #
                      </th>
                      <th className="px-3 py-1.5 font-medium text-xs border border-grey2 border-t-0 border-l-0 text-left w-[60%]">
                        Market Area <span className="text-red-300">*</span>
                      </th>
                      <th className="px-3 py-1.5 font-medium text-xs border border-grey2 border-t-0 border-l-0 text-center w-[20%]">
                        Status
                      </th>
                      <th className="px-3 py-1.5 font-medium text-xs border border-grey2 border-t-0 border-l-0 border-r-0 text-center w-[12%]">
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((row, i) => (
                      <tr
                        key={row.rowId}
                        className={`text-xs hover:bg-lightBlue/50 ${
                          row.hasError
                            ? "bg-red-50"
                            : row.isDuplicate
                            ? "bg-yellow-50"
                            : ""
                        }`}
                      >
                        {/* Row Number */}
                        <td className="px-3 py-1 border border-grey2 border-l-0 text-center text-gray-500">
                          {i + 1}
                        </td>

                        {/* Market Area Input */}
                        <td className="px-3 py-1 border border-grey2">
                          <input
                            type="text"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.marketArea
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.marketArea || ""}
                            placeholder="Enter Market Area"
                            onChange={(e) => handleCellChange(i, e.target.value)}
                          />
                        </td>

                        {/* Status Badge */}
                        <td className="px-3 py-1 border border-grey2 text-center">
                          {row.hasError ? (
                            <span className="px-2 py-0.5 bg-red-100 text-red-600 text-[10px] rounded-full">
                              Invalid
                            </span>
                          ) : row.isDuplicate ? (
                            <span
                              className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full cursor-help"
                              title={row.duplicateReason}
                            >
                              Duplicate
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-green-100 text-green-600 text-[10px] rounded-full">
                              Valid
                            </span>
                          )}
                        </td>

                        {/* Delete Button - Using rowId */}
                        <td className="px-3 py-1 border border-grey2 border-r-0 text-center">
                          <button
                            onClick={() => handleDeleteRow(row.rowId)}
                            className="text-red-500 hover:text-red-700 transition"
                            title="Delete Row"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="20"
                              height="20"
                              viewBox="0 0 32 32"
                              fill="none"
                            >
                              <g clipPath="url(#clip0_6398_313)">
                                <path
                                  d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z"
                                  fill="#BF2012"
                                />
                              </g>
                              <defs>
                                <clipPath id="clip0_6398_313">
                                  <rect
                                    width="24"
                                    height="24"
                                    fill="white"
                                    transform="translate(4 4)"
                                  />
                                </clipPath>
                              </defs>
                            </svg>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Footer Stats */}
              <div className="px-4 py-2 bg-gray-50 border-t border-grey2 flex flex-wrap justify-between items-center gap-2">
                <span className="text-xs text-gray-600">
                  Total: {rows.length} row(s) |
                  <span className="text-green-600 ml-1">Valid: {validCount}</span> |
                  <span className="text-yellow-600 ml-1">Duplicates: {duplicateCount}</span> |
                  <span className="text-red-600 ml-1">Errors: {errorCount}</span>
                </span>
                <span className="text-xs text-gray-500 italic">
                  💡 Click "Check Duplicates" before saving
                </span>
              </div>
            </div>
          ) : (
            /* Empty State - WITH DRAG AND DROP */
            <div
              className={`bg-white shadow-md border-2 border-dashed p-8 text-center transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-Dustyblue hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="w-12 h-12 mx-auto mb-3 opacity-50"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>

              <p className="text-gray-500 text-sm">
                {isDragActive
                  ? "Drop your Excel file here!"
                  : "No data loaded. Please upload an Excel file to preview."}
              </p>
              <p className="text-gray-400 text-xs mt-1">
                {isDragActive
                  ? "Release to upload"
                  : "Supported formats: .xlsx, .xls (Drag & drop or click Browse)"}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default MABulkUpload;