// // import React from "react";
// // // import { useState } from "react";
// // import Header from "../../Components/Header";

// // function HomePage() {
// //     // const [openDropdown, setOpenDropdown] = useState(null);

// //   return (
// //     <div className="bg-gray-100 min-h-screen flex flex-col">
// //       {/* Navigation Bar */}
// //             {/* Main Content */}
// //             <Header/>
// //             <h1 className="text-xl font-bold">Your Page Content</h1>
// //             <p>Content moves to the right when menu opens.</p>
      
// //     </div>
// //   );
// // }

// // export default HomePage;


// import React, { useState,useEffect } from "react";
// import Header from "../../../Components/Header";
// // import Dashboard from "../Homepage/Dashboard";
// import Scorecard from "./Scorecard";
// import SubNavbar3 from "../../../Components/SubNavbar3";

// function ScorecardHome() {
//   const [menuOpen, setMenuOpen] = useState(false);
//    const [showScrollTop, setShowScrollTop] = useState(false);
  
// useEffect(() => {
//   const handleScroll = () => {
//     setShowScrollTop(window.scrollY > 100);
//   };

//   window.addEventListener("scroll", handleScroll);
//   return () => window.removeEventListener("scroll", handleScroll);
// }, []);

//   return (
//     <div className="bg-Frostwhite min-h-screen flex flex-col">
//       {/* Navigation Bar */}
//       <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
// <SubNavbar3/>
//       {/* Main Content - Moves Right when Sidebar Opens */}
//       {/* <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : "ml-0"} mt-[-10px] p-4`}> */}
//       <div
//         className={`transition-all duration-300 ${
//           menuOpen ? "ml-60" : ""
//         }`}
//       >
//            {/* <div className="w-full mt-[-10px] md:mt-[-40px] lg:mt-[-10px] p-2 xl:mt-[-20px] lg:w-[100%] xl:w-[100%] 2xl:w-[100%] 2xl:mt-[-420px] "> */}

//         {/* <img src="/homepageimage.png" alt="home page"/> */}
        
//         <Scorecard/>
//         {/* </div> */}
//         {showScrollTop && (
//    <div className="mt-12 mb-2 flex justify-end pr-4 ">
//     <button
//       onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
//     className="bg-Silvergrey text-black font-bold px-4 py-2 rounded-lg shadow-lg hover:scale-110 transition duration-200"
//     >
//       ^
//     </button>
//   </div>
// )}

//       </div>
//     </div>
//   );
// }

// export default ScorecardHome;
