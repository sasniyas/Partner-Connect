import React from "react";
import { useNavigate } from "react-router-dom";
import CityMasterTable from "./CityMasterTable";
const  CityMasterScorecard = () => {
  const navigate = useNavigate();

 const buttons = [
    { label: "Market Area", path: "/masters/scorecard" },
    { label: "Country Master", path: "/masters/countrymaster" }, // Current page
    { label: "State Master", path: "/masters/statemaster" },
    { label: "City Master", path:  "/masters/citymaster" },
    { label: "Dealer Master", path: "/masters/dealermaster"},
                  { label: "Role Master", path: "/masters/roles"  },

          { label: "Strategic Objective", path: "/masters/strategicobjective"  },
    { label: "KPI Master", path:"/masters/kpimaster" },
    { label: "Sub KPI Master", path:"/masters/subkpimaster" },
  ];

  const currentPath = "/masters/citymaster";

  return (
    <div className="w-full flex flex-col items-center justify-center px-2">
      {/* Heading */}
      <h2 className="text-center text-xl font-semibold text-darkblue1 font-VolvoNovum mb-2">
        Scorecard Master Data
      </h2>

      {/* Button Row */}
      <div className="w-full overflow-x-auto">
        <div className="flex justify-center gap-1">
          {buttons.map(({ label, path }) => (
            <button
              key={label}
              onClick={() => {
                if (path !== currentPath && path !== "#") navigate(path);
              }}
            //   className={`w-[150px] h-[44px] whitespace-nowrap rounded-md text-base font-medium font-VolvoNovum transition duration-200
                className={`w-full py-2 whitespace-nowrap  text-xs font-medium font-VolvoNovum transition duration-200

                ${
                  path === currentPath
                    ? "bg-Dustyblue text-white border border-Dustyblue"
                    : "bg-white text-black border border-darkblue1 hover:bg-Dustyblue hover:text-white"
                }
              `}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* ✅ Country Master Component */}
     
 <div className="w-full flex justify-center">
  <div className="w-full ">

       <CityMasterTable/>
      </div>
      </div>
    </div>
  );
};

export default CityMasterScorecard;
