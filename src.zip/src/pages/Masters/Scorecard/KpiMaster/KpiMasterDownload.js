"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../Components/Header";

function KpimasterDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]); // ⬅️ now controlled by postMessage

  // ✅ Listen for postMessage from parent window
  useEffect(() => {
    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const handleDownloadExcel = () => {
  if (!tableData || tableData.length === 0) return;

  const excelData = tableData.map((record, index) => ({
    "Sl. No": String(index + 1),
    "Strategic Objective": record.objectives,
    "KPI": record.kpis,
    "Max Score": String(record.maxScore), // make it text so alignment works
    "Status": record.status,
  }));

  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // 👇 Apply left alignment to Sl. No (A) and Max Score (D)
  Object.keys(worksheet).forEach((cell) => {
    if (cell.startsWith("A") || cell.startsWith("D")) {
      if (!worksheet[cell].s) worksheet[cell].s = {};
      worksheet[cell].s.alignment = { horizontal: "left" };
    }
  });

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "KPI Master");
  XLSX.writeFile(workbook, "KPI_Master.xlsx");
};


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-1 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">KPI Master</h2>
          <button
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-sm  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadExcel}
          >
            Download 
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue  overflow-x-auto">
          <table className="w-full  text-xs text-left whitespace-nowrap">
            <thead className="bg-Dustyblue text-white">
              <tr>
                             <th className="px-4  py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%]">Sl. No</th>

          <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[30%]">Strategic Objective</th>
        <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[30%]">KPI</th>
        <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">Max Score</th>
        <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[10%]">Status</th>

              </tr>
            </thead>
            <tbody>
              {tableData.length > 0 ? (
                tableData.map((record, index) => (
                  <tr key={index} className="  hover:bg-lightBlue/50 text-xs font-normal">
            <td className="px-4  py-1 border border-grey2 border-t-0 border-l-0 ">{index+1}</td>
   <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{record.objectives}</td>
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border border-grey2 border-t-0 border-l-0  whitespace-normal break-words max-w-[200px] md:max-w-[300px]">
                {record.kpis}
              </td>
                                    <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{record.maxScore}</td>

                                        <td className="px-12 border border-grey2 border-t-0 border-l-0  py-1">{record.status}</td>

                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default KpimasterDownload;
