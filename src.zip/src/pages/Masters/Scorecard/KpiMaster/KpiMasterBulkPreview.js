"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

// ⭐ Import service functions
import {
  getAllKPIs,
  bulkAddKPIs,
  getActiveStrategicObjectives,
  checkDuplicatesInUpload,
  getObjectiveIdByName,
} from "../../../../services/Masters/Kpi/kpi.service";

function BulkUploadKPIMaster() {
  const navigate = useNavigate();

  // ═══════════════════════════════════════════════════════════════
  // 📊 STATE MANAGEMENT
  // ═══════════════════════════════════════════════════════════════
  const [rows, setRows] = useState([]);
  const [fileName, setFileName] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [duplicateInfo, setDuplicateInfo] = useState(null);
  const [strategicObjectives, setStrategicObjectives] = useState([]);
  const [existingKpis, setExistingKpis] = useState([]);
  const [isDataLoading, setIsDataLoading] = useState(true);
  const [isDragActive, setIsDragActive] = useState(false);

  // Dropdown states
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0, width: 0 });
  const [dropdownSearch, setDropdownSearch] = useState("");

  // Refs
  const dropdownButtonRefs = useRef({});
  const dropdownMenuRef = useRef(null);
  const tableContainerRef = useRef(null);

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH DATA - Using Service
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const fetchData = async () => {
      setIsDataLoading(true);

      try {
        const objectives = await getActiveStrategicObjectives();
        setStrategicObjectives(objectives);
      } catch (err) {
        console.error("Failed to fetch objectives:", err);
      }

      try {
        const kpis = await getAllKPIs();
        setExistingKpis(kpis);
      } catch (err) {
        console.error("Failed to fetch existing KPIs:", err);
      }

      setIsDataLoading(false);
    };

    fetchData();
  }, [navigate]);

  // ═══════════════════════════════════════════════════════════════
  // 🔙 NAVIGATION
  // ═══════════════════════════════════════════════════════════════
  const handleBack = () => {
    navigate("/masters/kpimaster");
  };

  // ═══════════════════════════════════════════════════════════════
  // 📥 DROPDOWN HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const closeDropdown = useCallback(() => {
    setActiveDropdown(null);
    setDropdownSearch("");
  }, []);

  const handleOpenDropdown = (rowIndex, column) => {
    if (activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column) {
      closeDropdown();
      return;
    }

    const refKey = `${rowIndex}-${column}`;
    const buttonEl = dropdownButtonRefs.current[refKey];
    if (buttonEl) {
      const rect = buttonEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const dropdownHeight = 220;

      const spaceBelow = viewportHeight - rect.bottom;
      const openUpward = spaceBelow < dropdownHeight && rect.top > dropdownHeight;

      setDropdownPosition({
        top: openUpward ? rect.top - dropdownHeight : rect.bottom + 2,
        left: rect.left,
        width: Math.max(rect.width, 200),
      });
    }
    setActiveDropdown({ rowIndex, column });
    setDropdownSearch("");
  };

  const handleSelectOption = (rowIdx, column, value) => {
    handleCellChange(rowIdx, column, value);
    closeDropdown();
  };

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) return;
      const clickedOnButton = Object.values(dropdownButtonRefs.current).some(
        (ref) => ref?.contains(e.target)
      );
      if (!clickedOnButton) closeDropdown();
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [closeDropdown]);

  // Close on scroll
  useEffect(() => {
    const handleTableScroll = () => {
      if (activeDropdown !== null) closeDropdown();
    };

    const tableContainer = tableContainerRef.current;
    if (tableContainer) {
      tableContainer.addEventListener("scroll", handleTableScroll);
    }

    const handleWindowScroll = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) return;
      if (activeDropdown !== null) closeDropdown();
    };

    window.addEventListener("scroll", handleWindowScroll, true);

    return () => {
      if (tableContainer) {
        tableContainer.removeEventListener("scroll", handleTableScroll);
      }
      window.removeEventListener("scroll", handleWindowScroll, true);
    };
  }, [activeDropdown, closeDropdown]);

  // ═══════════════════════════════════════════════════════════════
  // 📁 FILE UPLOAD
  // ═══════════════════════════════════════════════════════════════
  const parseExcelFile = (arrayBuffer) => {
    const data = new Uint8Array(arrayBuffer);
    const workbook = XLSX.read(data, { type: "array" });
    const sheetName = workbook.SheetNames[0];

    let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });

    json = json.filter((row) =>
      Object.values(row).some((cell) => String(cell).trim() !== "")
    );

    const finalRows = json.map((row, index) => {
      const objectiveName = String(
        row["Strategic Objective"] || row["StrategicObjective"] || ""
      ).trim();
      const kpiName = String(row["KPI"] || row["kpi"] || "").trim();
      const maxScore = String(row["Max Score"] || row["MaxScore"] || "").trim();

      const objectiveId = getObjectiveIdByName(strategicObjectives, objectiveName);

      const isValidObjective = !!objectiveId;
      const isValidKPI = !!kpiName;
      const isValidMaxScore = !!maxScore && !isNaN(Number(maxScore));

      const hasError = !isValidObjective || !isValidKPI || !isValidMaxScore;

      return {
        // ⭐ Use unique row ID for tracking
        rowId: `row-${Date.now()}-${index}`,
        objectiveName,
        objectiveId,
        kpiName,
        maxScore,
        hasError,
        isDuplicate: false,
        duplicateReason: "",
      };
    });

    return finalRows;
  };

  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (isDataLoading) {
      toast.warning("Please wait, loading data...");
      e.target.value = "";
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully!`);
      } catch (error) {
        console.error("Error parsing file:", error);
        toast.error("Failed to parse Excel file");
      }
    };

    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  // ═══════════════════════════════════════════════════════════════
  // 🎯 DRAG AND DROP HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    const file = e.dataTransfer.files[0];
    if (!file) return;

    // Validate file type
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error("Please drop an Excel file (.xlsx or .xls)");
      return;
    }

    if (isDataLoading) {
      toast.warning("Please wait, loading data...");
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully!`);
      } catch (error) {
        console.error("Error parsing file:", error);
        toast.error("Failed to parse Excel file");
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔍 CHECK DUPLICATES - Using Service
  // ═══════════════════════════════════════════════════════════════
  const checkDuplicates = async () => {
    if (rows.length === 0) {
      toast.error("No data to check. Please upload a file first.");
      return;
    }

    setIsChecking(true);
    setDuplicateInfo(null);

    try {
      const { updatedRows, duplicateCount } = checkDuplicatesInUpload(rows, existingKpis);

      setRows(updatedRows);

      if (duplicateCount > 0) {
        setDuplicateInfo({
          count: duplicateCount,
          message: `${duplicateCount} duplicate(s) found! These will be skipped during save.`,
          type: "warning",
        });
        toast.warning(`${duplicateCount} duplicate record(s) found!`);
      } else {
        setDuplicateInfo({
          count: 0,
          message: "No duplicates found. All records are unique.",
          type: "success",
        });
        toast.success("No duplicates found!");
      }
    } catch (error) {
      console.error("Error checking duplicates:", error);
      toast.error("Failed to check duplicates");
    } finally {
      setIsChecking(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // ✏️ EDIT CELL - Using rowId
  // ═══════════════════════════════════════════════════════════════
  const handleCellChange = (rowIdx, key, value) => {
    const updated = [...rows];
    updated[rowIdx][key] = value;

    if (key === "objectiveName") {
      updated[rowIdx].objectiveId = getObjectiveIdByName(strategicObjectives, value);
    }

    const row = updated[rowIdx];
    const isValidObjective = !!row.objectiveId;
    const isValidKPI = !!row.kpiName;
    const isValidMaxScore = !!row.maxScore && !isNaN(Number(row.maxScore));

    updated[rowIdx].hasError = !isValidObjective || !isValidKPI || !isValidMaxScore;
    updated[rowIdx].isDuplicate = false;
    updated[rowIdx].duplicateReason = "";

    setRows(updated);
    setDuplicateInfo(null);
  };

  // ═══════════════════════════════════════════════════════════════
  // 🗑️ DELETE ROW - Using rowId
  // ═══════════════════════════════════════════════════════════════
  const handleDeleteRow = (rowId) => {
    const updated = rows.filter((row) => row.rowId !== rowId);
    setRows(updated);
    setDuplicateInfo(null);
    closeDropdown();
  };

  // ═══════════════════════════════════════════════════════════════
  // 💾 SAVE - Using Service
  // ═══════════════════════════════════════════════════════════════
  const handleSave = async () => {
    const hasError = rows.some((r) => r.hasError);

    if (hasError) {
      toast.error("Please fix all errors before saving.");
      return;
    }

    if (rows.length === 0) {
      toast.error("No data to save. Please upload a file first.");
      return;
    }

    const rowsToSave = rows.filter((r) => !r.isDuplicate);

    if (rowsToSave.length === 0) {
      toast.error("All records are duplicates. Nothing to save.");
      return;
    }

    setIsSaving(true);

    try {
      const payload = rowsToSave.map((r) => ({
        objectiveId: r.objectiveId,
        kpiName: r.kpiName.trim(),
        maxScore: Number(r.maxScore),
      }));

      console.log("💾 Saving:", payload.length, "records");

      const response = await bulkAddKPIs(payload);

      if (response.status) {
        const insertedCount = response.data?.inserted || payload.length;
        const invalidCount = response.data?.invalid || 0;

        if (invalidCount > 0) {
          toast.success(
            `${insertedCount} KPI(s) added! ${invalidCount} duplicate(s) skipped.`,
            { autoClose: 5000 }
          );
        } else {
          toast.success(`${insertedCount} KPI(s) added successfully!`);
        }

        setTimeout(() => {
          navigate("/masters/kpimaster");
        }, 1500);
      } else {
        toast.error(response.message || "Failed to upload KPIs");
      }
    } catch (error) {
      console.error("Error saving:", error);
      toast.error(error.message || "Failed to upload KPIs");
    } finally {
      setIsSaving(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🧹 CLEAR ALL
  // ═══════════════════════════════════════════════════════════════
  const handleClearAll = () => {
    setRows([]);
    setFileName("");
    setDuplicateInfo(null);
    closeDropdown();
  };

  // ═══════════════════════════════════════════════════════════════
  // 📊 DROPDOWN HELPERS
  // ═══════════════════════════════════════════════════════════════
  const getDropdownOptions = () => {
    if (!activeDropdown) return [];

    let options = strategicObjectives.map((obj) => ({
      id: obj.name,
      label: obj.name,
    }));

    if (dropdownSearch) {
      options = options.filter((opt) =>
        opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
      );
    }

    return options;
  };

  const renderDropdownButton = (row, rowIndex, column) => {
    const isInvalid = !row.objectiveId;
    const displayValue = row.objectiveName || "";
    const isOpen = activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column;
    const refKey = `${rowIndex}-${column}`;

    return (
      <div
        ref={(el) => (dropdownButtonRefs.current[refKey] = el)}
        className={`w-full flex justify-between items-center px-2 py-1 border text-xs min-h-[26px] cursor-pointer ${
          isInvalid
            ? "border-red-500 bg-red-50"
            : row.isDuplicate
            ? "border-yellow-500 bg-yellow-50"
            : "border-gray-300 bg-white hover:border-gray-400"
        }`}
        onClick={() => handleOpenDropdown(rowIndex, column)}
      >
        <span className={`flex-1 truncate ${displayValue ? "text-gray-800" : "text-gray-400"}`}>
          {displayValue || "Select Objective"}
        </span>
        {isOpen ? (
          <ChevronUp className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1" />
        ) : (
          <ChevronDown className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1" />
        )}
      </div>
    );
  };

  // ═══════════════════════════════════════════════════════════════
  // 📊 COMPUTED VALUES
  // ═══════════════════════════════════════════════════════════════
  const validCount = rows.filter((r) => !r.hasError && !r.isDuplicate).length;
  const duplicateCount = rows.filter((r) => r.isDuplicate).length;
  const errorCount = rows.filter((r) => r.hasError).length;

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "lg:ml-60" : ""
        } flex-1 flex justify-center`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Back Button & Title */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer hover:scale-110 text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">
              KPI Master Bulk Upload
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[8%] ml-7 mb-2"></div>

          {/* Loading Indicator */}
          {isDataLoading && (
            <div className="mb-2 p-2 bg-blue-50 border border-blue-200 text-blue-600 text-xs flex items-center gap-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              <span>Loading dropdown data... Please wait before uploading.</span>
            </div>
          )}

          {/* Upload Section */}
          <div className="mb-4 flex flex-wrap items-center gap-2 w-full">
            {/* Drag & Drop Area */}
            <div
              className={`flex-1 min-w-[200px] max-w-md flex items-center border-2 border-dashed px-3 py-1.5 text-xs transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-black/30 bg-white hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="mr-2 flex-shrink-0"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>

              <span className="text-xs text-gray-700 truncate">
                {isDragActive
                  ? "Drop file here..."
                  : fileName || "Drag & drop or click Browse"}
              </span>

              <input
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleBulkUpload}
                id="bulk-upload-input"
                disabled={isDataLoading}
              />
            </div>

            <label
              htmlFor="bulk-upload-input"
              className={`px-3 py-1.5 text-xs cursor-pointer transition ${
                isDataLoading
                  ? "bg-gray-400 text-white cursor-not-allowed"
                  : "bg-darkblue1 text-white hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1"
              }`}
            >
              {isDataLoading ? "Loading..." : "Browse"}
            </label>

            {rows.length > 0 && (
              <>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 bg-gray-500 text-white text-xs hover:bg-gray-600 transition"
                >
                  Clear
                </button>

                <button
                  onClick={checkDuplicates}
                  disabled={isChecking}
                  className="px-3 py-1.5 bg-yellow-600 text-white text-xs hover:bg-yellow-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  {isChecking && (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  )}
                  {isChecking ? "Checking..." : "Check Duplicates"}
                </button>
              </>
            )}

            <button
              onClick={handleSave}
              disabled={isSaving || rows.length === 0 || isDataLoading}
              className="px-4 py-1.5 bg-darkblue1 text-white text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              {isSaving && (
                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
              )}
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>

          {/* Duplicate Info Banner */}
          {duplicateInfo && (
            <div
              className={`mb-2 p-2 border text-xs flex items-center justify-between ${
                duplicateInfo.type === "warning"
                  ? "bg-yellow-50 border-yellow-300 text-yellow-700"
                  : "bg-green-50 border-green-300 text-green-700"
              }`}
            >
              <span>
                <span className="font-medium">
                  {duplicateInfo.type === "warning" ? "⚠️ " : "✅ "}
                </span>
                {duplicateInfo.message}
              </span>
              <button
                onClick={() => setDuplicateInfo(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
          )}

          {/* Error Summary */}
          {rows.length > 0 && errorCount > 0 && (
            <div className="mb-2 p-2 bg-red-50 border border-red-200 text-red-600 text-xs">
              <span className="font-medium">⚠ {errorCount} row(s) have validation errors.</span>
              <span className="ml-2">
                Please select valid Strategic Objective and enter KPI name and Max Score.
              </span>
            </div>
          )}

          {/* ⭐ RESPONSIVE TABLE - Fits 1024px, shrinks/scrolls based on content */}
          {rows.length > 0 ? (
            <div className="overflow-hidden border border-Dustyblue mb-2 bg-white shadow-md">
              <div
                ref={tableContainerRef}
                className="overflow-y-auto overflow-x-auto scrollbar-hide"
                style={{
                  maxHeight: rows.length > 10 ? "calc(100vh - 280px)" : "auto",
                }}
              >
                <table className="w-full text-sm bg-white border-collapse table-fixed min-w-[700px] lg:min-w-full">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-20">
                    <tr>
                      <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[5%]">
                        #
                      </th>
                      <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[35%]">
                        Strategic Objective <span className="text-red-300">*</span>
                      </th>
                      <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[30%]">
                        KPI <span className="text-red-300">*</span>
                      </th>
                      <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[10%]">
                        Max Score <span className="text-red-300">*</span>
                      </th>
                      <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-center w-[12%]">
                        Status
                      </th>
                      <th className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium text-center w-[8%]">
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((row, i) => (
                      <tr
                        key={row.rowId}
                        className={`text-xs hover:bg-lightBlue/50 ${
                          row.hasError
                            ? "bg-red-50"
                            : row.isDuplicate
                            ? "bg-yellow-50"
                            : ""
                        }`}
                      >
                        {/* Row Number */}
                        <td className="px-3 py-1 border border-grey2 border-l-0 text-center text-gray-500">
                          {i + 1}
                        </td>

                        {/* Strategic Objective - Custom Dropdown */}
                        <td className="px-3 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "objectiveName")}
                        </td>

                        {/* KPI Input */}
                        <td className="px-3 py-1 border border-grey2">
                          <input
                            type="text"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.kpiName
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.kpiName}
                            onChange={(e) => handleCellChange(i, "kpiName", e.target.value)}
                            placeholder="Enter KPI"
                          />
                        </td>

                        {/* Max Score Input */}
                        <td className="px-3 py-1 border border-grey2">
                          <input
                            type="number"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.maxScore || isNaN(Number(row.maxScore))
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.maxScore}
                            onChange={(e) => handleCellChange(i, "maxScore", e.target.value)}
                            placeholder="Score"
                          />
                        </td>

                        {/* Status Badge */}
                        <td className="px-3 py-1 border border-grey2 text-center">
                          {row.hasError ? (
                            <span className="px-2 py-0.5 bg-red-100 text-red-600 text-[10px] rounded-full">
                              {!row.objectiveId
                                ? "Invalid Objective"
                                : !row.kpiName
                                ? "KPI Required"
                                : "Invalid Score"}
                            </span>
                          ) : row.isDuplicate ? (
                            <span
                              className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full cursor-help"
                              title={row.duplicateReason}
                            >
                              Duplicate
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-green-100 text-green-600 text-[10px] rounded-full">
                              Valid
                            </span>
                          )}
                        </td>

                        {/* Delete Button - Using rowId */}
                        <td className="px-3 py-1 border border-grey2 border-r-0 text-center">
                          <button
                            onClick={() => handleDeleteRow(row.rowId)}
                            className="text-red-500 hover:text-red-700 transition"
                            title="Delete Row"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="20"
                              height="20"
                              viewBox="0 0 32 32"
                              fill="none"
                            >
                              <g clipPath="url(#clip0_6398_313)">
                                <path
                                  d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z"
                                  fill="#BF2012"
                                />
                              </g>
                              <defs>
                                <clipPath id="clip0_6398_313">
                                  <rect
                                    width="24"
                                    height="24"
                                    fill="white"
                                    transform="translate(4 4)"
                                  />
                                </clipPath>
                              </defs>
                            </svg>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Footer Stats */}
              <div className="px-4 py-2 bg-gray-50 border-t border-grey2 flex flex-wrap justify-between items-center gap-2">
                <span className="text-xs text-gray-600">
                  Total: {rows.length} row(s) |
                  <span className="text-green-600 ml-1">Valid: {validCount}</span> |
                  <span className="text-yellow-600 ml-1">Duplicates: {duplicateCount}</span> |
                  <span className="text-red-600 ml-1">Errors: {errorCount}</span>
                </span>
                <span className="text-xs text-gray-500 italic">
                  💡 Click "Check Duplicates" before saving
                </span>
              </div>
            </div>
          ) : (
            /* Empty State - WITH DRAG AND DROP */
            <div
              className={`bg-white shadow-md border-2 border-dashed p-8 text-center transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-Dustyblue hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="w-12 h-12 mx-auto mb-3 opacity-50"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>

              <p className="text-gray-500 text-sm">
                {isDragActive
                  ? "Drop your Excel file here!"
                  : "No data loaded. Please upload an Excel file to preview."}
              </p>
              <p className="text-gray-400 text-xs mt-1">
                {isDragActive
                  ? "Release to upload"
                  : "Supported formats: .xlsx, .xls (Drag & drop or click Browse)"}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Universal Custom Dropdown */}
      {activeDropdown !== null && rows[activeDropdown.rowIndex] && (
        <div
          ref={dropdownMenuRef}
          className="fixed border border-gray-300 bg-white z-[9999] shadow-xl rounded overflow-hidden"
          style={{
            top: `${dropdownPosition.top}px`,
            left: `${dropdownPosition.left}px`,
            width: `${dropdownPosition.width}px`,
            minWidth: "200px",
          }}
        >
          {/* Search Input */}
          <div className="p-2 border-b border-gray-200 bg-gray-50">
            <input
              type="text"
              placeholder="Search objective..."
              value={dropdownSearch}
              onChange={(e) => setDropdownSearch(e.target.value)}
              className="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:outline-none focus:border-darkblue1"
              autoFocus
            />
          </div>

          {/* Options List */}
          <div className="max-h-[150px] overflow-y-auto">
            {getDropdownOptions().length > 0 ? (
              getDropdownOptions().map((option) => {
                const isSelected =
                  rows[activeDropdown.rowIndex]?.objectiveName === option.id;

                return (
                  <div
                    key={option.id}
                    className={`flex items-center justify-between px-3 py-1.5 cursor-pointer text-xs border-b border-gray-100 last:border-b-0 ${
                      isSelected ? "bg-blue-50" : "hover:bg-gray-50"
                    }`}
                    onClick={() =>
                      handleSelectOption(activeDropdown.rowIndex, "objectiveName", option.id)
                    }
                  >
                    <span className={isSelected ? "text-blue-700 font-medium" : ""}>
                      {option.label}
                    </span>
                    {isSelected && <span className="text-blue-500">✓</span>}
                  </div>
                );
              })
            ) : (
              <div className="px-3 py-3 text-xs text-gray-400 text-center">No options found</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default BulkUploadKPIMaster;