"use client";

import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import Searchinput from "../../../../Components/Searchinput";
import * as XLSX from "xlsx";
import DeleteModal from "../../../../Components/DeleteModal";
import Filter from "../../../../Components/Filter";
import ActivateStatus from "../../../../Components/ActivateStatus";
import DeactivateStatus from "../../../../Components/DeactivateStatus";
import { useNavigate } from "react-router-dom";
import { saveAs } from "file-saver";
import ExcelJS from "exceljs";
import {uploadTempFile} from "../../../../services/download/bluckDownload.service"
import { ChevronDown } from "lucide-react";
import { ChevronUp } from "lucide-react";
import { ArrowUp } from "lucide-react";
import { ArrowDown } from "lucide-react";
import { ChevronsUpDown } from "lucide-react";
import { useCRUDWithReset } from "../../../../util/useCRUDWithReset";
import {useKeyboardNavigation} from "../../../../util/useKeyboardNavigation"
// ⭐ Import service functions
import {
  getAllStatesFormatted,
  getAllStatesList,
  addState,
  updateState,
  deleteState,
  toggleStateStatus,
  checkStateExists,
  getAllMarketAreas,
  getActiveMarketAreas,
  getMarketAreaIdByName,
} from "../../../../services/Masters/State/state.service";

const StateMasterTable = () => {
  const navigate = useNavigate();

  // ═══════════════════════════════════════════════════════════════
  // 📊 STATE MANAGEMENT
  // ═══════════════════════════════════════════════════════════════
  const [tableData, setTableData] = useState([]);
  const [isLoadingdata, setIsLoadingdata] = useState(false);
const [selectedStatus, setSelectedStatus] = useState([]);
const statusOptions = ["Active", "Inactive"];
const [areaSearch, setAreaSearch] = useState("");
const [stateSearch, setStateSearch] = useState("");
const popupRef =useRef("")
  // Master data for dropdowns
  const [allMarketAreas, setAllMarketAreas] = useState([]);
  const [activeMarketAreas, setActiveMarketAreas] = useState([]);
  const [allStatesList, setAllStatesList] = useState([]);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"

  // Form state
  const [formData, setFormData] = useState({
    selectedArea: "",
    selectedAreaId: null,
    selectState: "",
    errors: { area: false, state: false },
  });
  const [errorMessage, setErrorMessage] = useState("");
  const [hoveredCell,setHoveredCell] = useState (null)
  // ⭐ ID-based selection instead of index
  const [selectedId, setSelectedId] = useState(null);
  const [selectedRowData, setSelectedRowData] = useState(null);

  // Filter state
  const [selectedMarketArea, setSelectedMarketArea] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

   const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    setSelectedMarketArea,
    setSearchTerm,
    setSelectedStatus
  }
);

  // Modal states
  const [showPopup, setShowPopup] = useState(false);
  const [editPopup, setEditPopup] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);

  // Loading states
  const [loading, setLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [loadingToggle, setLoadingToggle] = useState(false);

  // UI states
  const [isOpen, setIsOpen] = useState(false);
  const [stateOpen, setStateOpen] = useState(false);

  // Dropdown states for screen sizes
  const [dropdownOpenLg, setDropdownOpenLg] = useState(false);
  const [dropdownOpenMd, setDropdownOpenMd] = useState(false);
  const [dropdownOpenSm, setDropdownOpenSm] = useState(false);

  // Refs
  const actionsRefLg = useRef(null);
  const actionsRefMd = useRef(null);
  const actionsRefSm = useRef(null);
  const marketAreaRef = useRef(null);
  const stateDropdownRef = useRef(null);
  const tableContainerRef = useRef(null);
  const fileInputRef = useRef(null);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH DATA - Using Service
  // ═══════════════════════════════════════════════════════════════
  const fetchStates = async () => {
    try {
      setIsLoadingdata(true);
      const data = await getAllStatesFormatted();
      setTableData(data);
    } catch (err) {
      // console.error("Error fetching States:", err.message);
      setTableData([]);
    } finally {
      setIsLoadingdata(false);
    }
  };

  const fetchMasterData = async () => {
    try {
      const [marketAreas, statesList] = await Promise.all([
        getAllMarketAreas(),
        getAllStatesList(),
      ]);
      setAllMarketAreas(marketAreas);
      setActiveMarketAreas(marketAreas.filter((a) => a.isActive === 1));
      setAllStatesList(statesList);
    } catch (err) {
      // console.error("Error fetching master data:", err.message);
    }
  };

  useEffect(() => {
    fetchStates();
    fetchMasterData();
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 FILTER DATA
  // ═══════════════════════════════════════════════════════════════
const filteredData = useMemo(() => {
  return tableData
    // 🔹 search by area/state
    .filter((item) => {
      const searchLower = searchTerm.toLowerCase();
      return (
        item.area.toLowerCase().includes(searchLower) ||
        item.state.toLowerCase().includes(searchLower)
      );
    })
    // 🔹 market area filter
    .filter((item) =>
      selectedMarketArea.length > 0
        ? selectedMarketArea.includes(item.area)
        : true
    )
    // 🔹 status filter
    .filter((item) =>
      selectedStatus.length > 0
        ? selectedStatus.includes(item.status) // match status
        : true
    );
}, [tableData, searchTerm, selectedMarketArea, selectedStatus]);

  // ═══════════════════════════════════════════════════════════════
  // 🖱️ CLICK OUTSIDE HANDLER
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (actionsRefLg.current && !actionsRefLg.current.contains(event.target)) {
        setDropdownOpenLg(false);
      }
      if (actionsRefMd.current && !actionsRefMd.current.contains(event.target)) {
        setDropdownOpenMd(false);
      }
      if (actionsRefSm.current && !actionsRefSm.current.contains(event.target)) {
        setDropdownOpenSm(false);
      }
      if (marketAreaRef.current && !marketAreaRef.current.contains(event.target)) {
        setIsOpen(false);
        setAreaSearch("");
      }
      if (stateDropdownRef.current && !stateDropdownRef.current.contains(event.target)) {
        setStateOpen(false);
        setStateSearch("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // ✅ VALIDATION
  // ═══════════════════════════════════════════════════════════════
  const validateForm = () => {
    const errors = {
      area: !formData.selectedArea.trim(),
      state: !formData.selectState.trim(),
    };
    setFormData((prev) => ({ ...prev, errors }));
    return !errors.area && !errors.state;
  };

  // ═══════════════════════════════════════════════════════════════
  // ➕ ADD STATE - Using Service
  // ═══════════════════════════════════════════════════════════════
  // ═══════════════════════════════════════════════════════════════
// ➕ ADD STATE - Using Service
// ═══════════════════════════════════════════════════════════════
const handleSubmit = async () => {
  if (!validateForm()) return;

  setErrorMessage("");

  // Check for duplicates - State name should be unique across all Market Areas
  const isDuplicate = tableData.some(
    (item) =>
      item.state.toLowerCase() === formData.selectState.trim().toLowerCase()
  );

  if (isDuplicate) {
    setErrorMessage("This state already exists. State names must be unique.");
    return;
  }

  const marketAreaId = getMarketAreaIdByName(activeMarketAreas, formData.selectedArea);
  if (!marketAreaId) {
    setErrorMessage("Invalid Market Area selected");
    return;
  }

  setLoading(true);
  setErrorMessage("");

  try {
    const payload = {
      marketarea_id: marketAreaId,
      stateName: formData.selectState.trim(),
    };

    await addState(payload);
    await fetchStates();
    resetSortAndFilter();
    resetForm();
  } catch (error) {
    // console.error("Error adding State:", error.message);
    setErrorMessage(error.message || "Failed to add state");
  } finally {
    setLoading(false);
  }
};

  // ═══════════════════════════════════════════════════════════════
  // ✏️ UPDATE STATE - Using Service with ID
  // ═══════════════════════════════════════════════════════════════
  const handleEditSubmit = async () => {
    if (!validateForm()) return;

    if (!selectedId) {
      // alert("Unable to update: Missing ID");
      return;
    }

    // No changes check
    if (
      selectedRowData?.area === formData.selectedArea &&
      selectedRowData?.state === formData.selectState
    ) {
      resetForm();
      return;
    }

    // ⭐ Check duplicates excluding current ID
    if (checkStateExists(tableData, formData.selectedArea, formData.selectState, selectedId)) {
      setErrorMessage("This state already exists for the selected Market Area");
      return;
    }

    const marketAreaId = formData.selectedAreaId || getMarketAreaIdByName(activeMarketAreas, formData.selectedArea);
    if (!marketAreaId) {
      setErrorMessage("Invalid Market Area selected");
      return;
    }

    setLoading(true);
    setErrorMessage("");

    try {
      const payload = {
        id: selectedId,
        marketarea_id: marketAreaId.toString(),
        stateName: formData.selectState.trim(),
      };

      await updateState(payload);
      await fetchStates();
      resetForm();
      // console.log("State updated successfully");
    } catch (error) {
      // console.error("Failed to update State:", error.message);
      setErrorMessage(error.message || "Failed to update state");
    } finally {
      setLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🗑️ DELETE STATE - Using ID
  // ═══════════════════════════════════════════════════════════════
  const handleDelete = async () => {
    if (!selectedId) {
      // console.error("No ID selected for deletion");
      return;
    }

    setDeleteLoading(true);

    try {
      await deleteState(selectedId);
      await fetchStates();
      setIsDeleteModalOpen(false);
      setSelectedId(null);
      setSelectedRowData(null);
    } catch (error) {
      // console.error("Error deleting State:", error.message);
    } finally {
      setDeleteLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔄 TOGGLE STATUS - Using ID
  // ═══════════════════════════════════════════════════════════════
  const handleToggleStatus = async () => {
    if (!selectedId) {
      // console.error("No ID selected for toggle");
      return;
    }

    setLoadingToggle(true);

    try {
      await toggleStateStatus(selectedId);
      await fetchStates();
      setShowActivateModal(false);
      setShowDeactivateModal(false);
      setSelectedId(null);
      setSelectedRowData(null);
    } catch (error) {
      // console.error("Error toggling State status:", error.message);
    } finally {
      setLoadingToggle(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // ✏️ EDIT HANDLER - Using ID
  // ═══════════════════════════════════════════════════════════════
  const handleEditClick = (rowData) => {
    setSelectedId(rowData.id);
    setSelectedRowData(rowData);
    setFormData({
      selectedArea: rowData.area,
      selectedAreaId: rowData.marketarea_id,
      selectState: rowData.state,
      errors: { area: false, state: false },
    });
    setEditPopup(true);
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔄 RESET FORM
  // ═══════════════════════════════════════════════════════════════
  const resetForm = () => {
    setFormData({
      selectedArea: "",
      selectedAreaId: null,
      selectState: "",
      errors: { area: false, state: false },
    });
    setSelectedId(null);
    setSelectedRowData(null);
    setShowPopup(false);
    setEditPopup(false);
    setIsOpen(false);
    setStateOpen(false);
    setErrorMessage("");
  };

  // ═══════════════════════════════════════════════════════════════
  // 📥 DOWNLOAD HANDLERS
  // ═══════════════════════════════════════════════════════════════
 const handlePreviewAndDownload = async () => {
  if (!filteredData || filteredData.length === 0) {
    // alert("No data available to generate preview");
    return;
  }

  try {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("State Master");

    // ===== HEADERS =====
    sheet.columns = [
      { header: "Sl. No", key: "slNo", width: 10 },
      { header: "Market Area", key: "area", width: 30 },
      { header: "State", key: "state", width: 40 },
      { header: "Status", key: "status", width: 15 },
    ];

    // ===== HEADER STYLE =====
    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });

    // ===== DATA ROWS =====
    filteredData.forEach((item, index) => {
      const row = sheet.addRow({
        slNo: index + 1,
        area: item.area || "",
        state: item.state || "",
        status: item.isActive === 1 ? "Active" : "Inactive",
      });

      row.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
    });

    // ===== CREATE FILE =====
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const file = new File([blob], "State_Master.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    // ===== UPLOAD TEMP FILE (FOR OFFICE PREVIEW) =====
    // uploadTempFile must return a public file URL
    const response = await uploadTempFile(file);

    const fileUrl = response
      ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
      : null;

    if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    } else {
      // console.warn("Upload succeeded but no preview URL returned");
      // alert("Upload succeeded but preview is not available.");
    }
  } catch (error) {
    // console.error("State preview generation failed:", error);
    // alert("Failed to generate preview. Check console for details.");
  }
};
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const valA = (a[sortKey] || "").toString().toLowerCase();
    const valB = (b[sortKey] || "").toString().toLowerCase();

    return sortOrder === "asc"
      ? valA.localeCompare(valB)
      : valB.localeCompare(valA);
  });
}, [filteredData, sortKey, sortOrder]);


  const handleDownloadTemplate = async () => {
    if (!activeMarketAreas || activeMarketAreas.length === 0) {
      // alert("Market Areas not loaded yet!");
      return;
    }

    if (!allStatesList || allStatesList.length === 0) {
      // alert("States not loaded yet!");
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("State Master");

    const header = sheet.addRow(["Market Area", "State"]);
    header.eachCell((cell) => {
      cell.protection = { locked: true };
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
    });

    const sample = sheet.addRow(["East", "Karnataka"]);
    sample.eachCell((cell) => (cell.protection = { locked: false }));

    for (let i = 0; i < 99; i++) {
      const row = sheet.addRow(["", ""]);
      row.eachCell((cell) => (cell.protection = { locked: false }));
    }

    const hidden = workbook.addWorksheet("Lists");
    hidden.state = "hidden";

    activeMarketAreas.forEach((area, i) => {
      hidden.getCell(`A${i + 1}`).value = area.marketarea;
    });

    const stateNames = allStatesList.map((s) => s.state_name);
    stateNames.forEach((state, i) => {
      hidden.getCell(`B${i + 1}`).value = state;
    });

    const totalAreas = activeMarketAreas.length;
    const totalStates = stateNames.length;

    sheet.dataValidations.add("A2:A102", {
      type: "list",
      allowBlank: false,
      formulae: [`Lists!$A$1:$A$${totalAreas}`],
    });

    sheet.dataValidations.add("B2:B102", {
      type: "list",
      allowBlank: false,
      formulae: [`Lists!$B$1:$B$${totalStates}`],
    });

    sheet.protect("12345", {
      selectLockedCells: true,
      selectUnlockedCells: true,
      formatColumns: true,
      formatRows: true,
      insertRows: true,
      deleteRows: true,
    });

    sheet.getColumn(1).width = 25;
    sheet.getColumn(2).width = 30;

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer]), "State_Master_Bulk_Upload_Template.xlsx");
  };
useKeyboardNavigation({
  containerRef: popupRef, // your popup div ref

  onSubmit: () => {
    if (editPopup) {
      handleEditSubmit();
    } else {
      handleSubmit();
    }
  },

  onCancel: () => {
    resetForm(); // closes popup and resets state
  },
});

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="w-full mt-2 flex justify-center">
      <div className="w-full">
        {/* Search and Filters Section */}
        <div className="w-full mb-2">
          {/* LARGE SCREEN */}
          <div className="hidden lg:flex w-full items-center justify-between gap-2">
            <div className="flex flex-wrap gap-2 flex-1 items-center">
              <Searchinput
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
                className="min-w-[120px] max-w-[180px]"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />

              <Filter
                name="market Area"
                value={selectedMarketArea}
                options={allMarketAreas.map((a) => a.marketarea)}
                onChange={(name, value) => setSelectedMarketArea(value)}
                placeholder="Market Area"
                customWidth="w-[150px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />
              <Filter
  name="status"
  value={selectedStatus}
  options={statusOptions}
  onChange={(name, val) => setSelectedStatus(val)}
  placeholder="Status"
  placeholderColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black/60"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
  customWidth="w-[160px]"
/>

            </div>

            {/* Actions Dropdown - LG */}
            <div className="relative flex-shrink-0" ref={actionsRefLg}>
              <button
                onClick={() => setDropdownOpenLg(!dropdownOpenLg)}
                className={`flex items-center justify-center px-3 py-1 text-white text-xs font-medium bg-darkblue1 shadow-md transition duration-200 ${
                  dropdownOpenLg ? "" : "hover:scale-105"
                }`}
              >
                Actions
                
                 <svg
  
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
     className={`w-5 h-5 ml-1 transition-transform duration-300 ${
                    dropdownOpenLg ? "rotate-180" : ""
                  }`}
    fill="none"
    
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
              </button>

              {dropdownOpenLg && (
                <div className="absolute right-0 top-full mt-1 w-32 bg-white border border-darkblue1 shadow-lg z-[9999]">
                  <ul className="p-0 w-full">
                    <li
                      onClick={() => {
                        setDropdownOpenLg(false);
                        setShowPopup(true);
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15" fill="none">
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="#212121"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
</svg>
                      <span>Add New</span>
                    </li>
                    <li>
                      <button
                        onClick={() => navigate("/masters/statemaster/bulkupload")}
                        className="w-full text-left px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1.5 cursor-pointer"
                      >
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>
                        Bulk Upload
                      </button>
                    </li>
                    <li
                      onClick={() => {
                        setDropdownOpenLg(false);
                        handlePreviewAndDownload();
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>


                      <span>Download</span>
                    </li>
                    <li
                      onClick={() => {
                        handleDownloadTemplate();
                        setDropdownOpenLg(false);
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 22 22" fill="none">
<path d="M10.9994 10.0834C11.2425 10.0834 11.4756 10.18 11.6475 10.3519C11.8195 10.5238 11.916 10.7569 11.916 11V17.0354L13.1013 15.851C13.2734 15.6792 13.5068 15.5827 13.75 15.5829C13.9933 15.583 14.2265 15.6798 14.3984 15.852C14.5702 16.0241 14.6667 16.2574 14.6665 16.5007C14.6664 16.7439 14.5696 16.9772 14.3974 17.149L11.8088 19.7331C11.5769 19.9641 11.3504 20.1667 10.9994 20.1667C10.6914 20.1667 10.4805 20.0118 10.277 19.8184L7.60128 17.149C7.42915 16.9772 7.33236 16.7439 7.33218 16.5007C7.33201 16.2574 7.42848 16.0241 7.60036 15.852C7.77224 15.6798 8.00546 15.583 8.24871 15.5829C8.49196 15.5827 8.72532 15.6792 8.89744 15.851L10.0827 17.0354V11C10.0827 10.7569 10.1793 10.5238 10.3512 10.3519C10.5231 10.18 10.7562 10.0834 10.9994 10.0834ZM10.541 1.83337C13.093 1.83337 15.271 3.43754 16.1199 5.69437C17.2507 6.00528 18.2525 6.66933 18.9794 7.58967C19.7063 8.51001 20.1201 9.6385 20.1605 10.8106C20.2009 11.9826 19.8658 13.1369 19.2041 14.1052C18.5424 15.0734 17.5886 15.8049 16.4819 16.193C16.4126 15.5742 16.1353 14.9974 15.6954 14.5567C15.2264 14.0869 14.6032 13.8027 13.9409 13.7565L13.7494 13.75V11C13.7501 10.2842 13.4716 9.59632 12.9732 9.08254C12.4747 8.56876 11.7956 8.26958 11.0801 8.24857C10.3645 8.22757 9.66903 8.48639 9.1413 8.97005C8.61358 9.4537 8.29525 10.1241 8.25394 10.8387L8.24936 11V13.75C7.88788 13.75 7.52994 13.8212 7.19601 13.9596C6.86209 14.0981 6.55872 14.3009 6.30328 14.5567C5.81094 15.05 5.52426 15.7118 5.50119 16.4084C4.54688 16.2134 3.67945 15.7195 3.02465 14.9984C2.36986 14.2773 1.96171 13.3664 1.85937 12.3978C1.75703 11.4291 1.96582 10.4531 2.45547 9.61105C2.94512 8.76904 3.6902 8.10483 4.58269 7.71471C4.60295 6.14784 5.23962 4.65202 6.35484 3.55122C7.47006 2.45041 8.97403 1.83324 10.541 1.83337Z" fill="black"/>
</svg>

                      <span>Template</span>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* MEDIUM SCREEN */}
          <div className="hidden md:flex lg:hidden w-full items-center justify-between gap-2">
            <div className="flex flex-wrap gap-2 flex-1 items-center">
              <Searchinput
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
                className="min-w-[120px] max-w-[160px]"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />

              <Filter
                name="market Area"
                value={selectedMarketArea}
                options={allMarketAreas.map((a) => a.marketarea)}
                onChange={(name, value) => setSelectedMarketArea(value)}
                placeholder="Market Area"
                customWidth="w-[130px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />
            </div>

            <div className="relative flex-shrink-0" ref={actionsRefMd}>
              <button
                onClick={() => setDropdownOpenMd(!dropdownOpenMd)}
                className={`flex items-center justify-center px-3 py-1 text-white text-xs font-medium bg-darkblue1 shadow-md transition duration-200 ${
                  dropdownOpenMd ? "" : "hover:scale-105"
                }`}
              >
                Actions
                
                 <svg
  
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
     className={`w-5 h-5 ml-1 transition-transform duration-300 ${
                    dropdownOpenMd ? "rotate-180" : ""
                  }`}
    fill="none"
    
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
              </button>

              {dropdownOpenMd && (
                <div className="absolute right-0 top-full mt-1 w-32 bg-white border border-darkblue1 shadow-lg z-[9999]">
                  <ul className="p-0 w-full">
                    <li
                      onClick={() => {
                        setDropdownOpenMd(false);
                        setShowPopup(true);
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15" fill="none">
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="#212121"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
</svg>


                      <span>Add New</span>
                    </li>
                    <li>
                      <button
                        onClick={() => navigate("/masters/statemaster/bulkupload")}
                        className="w-full text-left px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1.5 cursor-pointer"
                      >
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>


                        Bulk Upload
                      </button>
                    </li>
                    <li
                      onClick={() => {
                        setDropdownOpenMd(false);
                        handlePreviewAndDownload();
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                     <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

                      <span>Download</span>
                    </li>
                    <li
                      onClick={() => {
                        handleDownloadTemplate();
                        setDropdownOpenMd(false);
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 22 22" fill="none">
<path d="M10.9994 10.0834C11.2425 10.0834 11.4756 10.18 11.6475 10.3519C11.8195 10.5238 11.916 10.7569 11.916 11V17.0354L13.1013 15.851C13.2734 15.6792 13.5068 15.5827 13.75 15.5829C13.9933 15.583 14.2265 15.6798 14.3984 15.852C14.5702 16.0241 14.6667 16.2574 14.6665 16.5007C14.6664 16.7439 14.5696 16.9772 14.3974 17.149L11.8088 19.7331C11.5769 19.9641 11.3504 20.1667 10.9994 20.1667C10.6914 20.1667 10.4805 20.0118 10.277 19.8184L7.60128 17.149C7.42915 16.9772 7.33236 16.7439 7.33218 16.5007C7.33201 16.2574 7.42848 16.0241 7.60036 15.852C7.77224 15.6798 8.00546 15.583 8.24871 15.5829C8.49196 15.5827 8.72532 15.6792 8.89744 15.851L10.0827 17.0354V11C10.0827 10.7569 10.1793 10.5238 10.3512 10.3519C10.5231 10.18 10.7562 10.0834 10.9994 10.0834ZM10.541 1.83337C13.093 1.83337 15.271 3.43754 16.1199 5.69437C17.2507 6.00528 18.2525 6.66933 18.9794 7.58967C19.7063 8.51001 20.1201 9.6385 20.1605 10.8106C20.2009 11.9826 19.8658 13.1369 19.2041 14.1052C18.5424 15.0734 17.5886 15.8049 16.4819 16.193C16.4126 15.5742 16.1353 14.9974 15.6954 14.5567C15.2264 14.0869 14.6032 13.8027 13.9409 13.7565L13.7494 13.75V11C13.7501 10.2842 13.4716 9.59632 12.9732 9.08254C12.4747 8.56876 11.7956 8.26958 11.0801 8.24857C10.3645 8.22757 9.66903 8.48639 9.1413 8.97005C8.61358 9.4537 8.29525 10.1241 8.25394 10.8387L8.24936 11V13.75C7.88788 13.75 7.52994 13.8212 7.19601 13.9596C6.86209 14.0981 6.55872 14.3009 6.30328 14.5567C5.81094 15.05 5.52426 15.7118 5.50119 16.4084C4.54688 16.2134 3.67945 15.7195 3.02465 14.9984C2.36986 14.2773 1.96171 13.3664 1.85937 12.3978C1.75703 11.4291 1.96582 10.4531 2.45547 9.61105C2.94512 8.76904 3.6902 8.10483 4.58269 7.71471C4.60295 6.14784 5.23962 4.65202 6.35484 3.55122C7.47006 2.45041 8.97403 1.83324 10.541 1.83337Z" fill="black"/>
</svg>

                      <span>Template</span>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* SMALL SCREEN */}
          <div className="flex md:hidden w-full flex-col gap-2">
            <div className="flex items-center justify-between gap-2">
              <Searchinput
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
                className="flex-1"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />

              <div className="relative flex-shrink-0" ref={actionsRefSm}>
                <button
                  onClick={() => setDropdownOpenSm(!dropdownOpenSm)}
                  className={`flex items-center justify-center px-3 py-1 text-white text-xs font-medium bg-darkblue1 shadow-md transition duration-200 ${
                    dropdownOpenSm ? "" : "hover:scale-105"
                  }`}
                >
                  Actions
                  <svg
  
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
     className={`w-5 h-5 ml-1 transition-transform duration-300 ${
                    dropdownOpenSm ? "rotate-180" : ""
                  }`}
    fill="none"
    
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
                </button>

                {dropdownOpenSm && (
                  <div className="absolute right-0 top-full mt-1 w-32 bg-white border border-darkblue1 shadow-lg z-[9999]">
                    <ul className="p-0 w-full">
                      <li
                        onClick={() => {
                          setDropdownOpenSm(false);
                          setShowPopup(true);
                        }}
                        className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15" fill="none">
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="#212121"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
</svg>


                        <span>Add New</span>
                      </li>
                      <li>
                        <button
                          onClick={() => navigate("/masters/statemaster/bulkupload")}
                          className="w-full text-left px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>


                          Bulk Upload
                        </button>
                      </li>
                      <li
                        onClick={() => {
                          setDropdownOpenSm(false);
                          handlePreviewAndDownload();
                        }}
                        className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1.5 cursor-pointer"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

                        <span>Download</span>
                      </li>
                      <li
                        onClick={() => {
                          handleDownloadTemplate();
                          setDropdownOpenSm(false);
                        }}
                        className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 22 22" fill="none">
<path d="M10.9994 10.0834C11.2425 10.0834 11.4756 10.18 11.6475 10.3519C11.8195 10.5238 11.916 10.7569 11.916 11V17.0354L13.1013 15.851C13.2734 15.6792 13.5068 15.5827 13.75 15.5829C13.9933 15.583 14.2265 15.6798 14.3984 15.852C14.5702 16.0241 14.6667 16.2574 14.6665 16.5007C14.6664 16.7439 14.5696 16.9772 14.3974 17.149L11.8088 19.7331C11.5769 19.9641 11.3504 20.1667 10.9994 20.1667C10.6914 20.1667 10.4805 20.0118 10.277 19.8184L7.60128 17.149C7.42915 16.9772 7.33236 16.7439 7.33218 16.5007C7.33201 16.2574 7.42848 16.0241 7.60036 15.852C7.77224 15.6798 8.00546 15.583 8.24871 15.5829C8.49196 15.5827 8.72532 15.6792 8.89744 15.851L10.0827 17.0354V11C10.0827 10.7569 10.1793 10.5238 10.3512 10.3519C10.5231 10.18 10.7562 10.0834 10.9994 10.0834ZM10.541 1.83337C13.093 1.83337 15.271 3.43754 16.1199 5.69437C17.2507 6.00528 18.2525 6.66933 18.9794 7.58967C19.7063 8.51001 20.1201 9.6385 20.1605 10.8106C20.2009 11.9826 19.8658 13.1369 19.2041 14.1052C18.5424 15.0734 17.5886 15.8049 16.4819 16.193C16.4126 15.5742 16.1353 14.9974 15.6954 14.5567C15.2264 14.0869 14.6032 13.8027 13.9409 13.7565L13.7494 13.75V11C13.7501 10.2842 13.4716 9.59632 12.9732 9.08254C12.4747 8.56876 11.7956 8.26958 11.0801 8.24857C10.3645 8.22757 9.66903 8.48639 9.1413 8.97005C8.61358 9.4537 8.29525 10.1241 8.25394 10.8387L8.24936 11V13.75C7.88788 13.75 7.52994 13.8212 7.19601 13.9596C6.86209 14.0981 6.55872 14.3009 6.30328 14.5567C5.81094 15.05 5.52426 15.7118 5.50119 16.4084C4.54688 16.2134 3.67945 15.7195 3.02465 14.9984C2.36986 14.2773 1.96171 13.3664 1.85937 12.3978C1.75703 11.4291 1.96582 10.4531 2.45547 9.61105C2.94512 8.76904 3.6902 8.10483 4.58269 7.71471C4.60295 6.14784 5.23962 4.65202 6.35484 3.55122C7.47006 2.45041 8.97403 1.83324 10.541 1.83337Z" fill="black"/>
</svg>

                        <span>Template</span>
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            </div>

            {/* Filter for small screen */}
            <Filter
              name="market Area"
              value={selectedMarketArea}
              options={allMarketAreas.map((a) => a.marketarea)}
              onChange={(name, value) => setSelectedMarketArea(value)}
              placeholder="Market Area"
              customWidth="w-full"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
            />
          </div>
        </div>

        {/* ⭐ RESPONSIVE TABLE */}
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
          <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
              maxHeight: filteredData.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >
            <table className="w-full text-xs whitespace-nowrap table-fixed min-w-[500px] lg:min-w-full">
             <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
  <tr>
    {/* Market Area */}
    <th
      className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[40%] cursor-pointer select-none"
      onClick={() => handleSort("area")}
    >
      <div className="flex items-center gap-1">
        Market Area
        {sortKey !== "area" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}


        {sortKey === "area" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "area" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* State */}
    <th
      className="px-3 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[45%] cursor-pointer select-none"
      onClick={() => handleSort("state")}
    >
      <div className="flex items-center gap-1">
        State
        {sortKey === "state" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "state" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Actions */}
    <th className="text-center py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium w-[15%]">
      Actions
    </th>
  </tr>
</thead>

              <tbody>
                {/* Loading State */}
                {isLoadingdata && (
                  <tr>
                    <td colSpan={3} className="px-6 py-8 text-center text-gray-500">
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        Loading...
                      </div>
                    </td>
                  </tr>
                )}

                {/* Data Rows */}
                {!isLoadingdata &&sortedData.length > 0 ? (
                  sortedData.map((item) => (
                    <tr
                      key={item.id}
                      className={`hover:bg-lightBlue/50 ${
                        item.status === "Active" ? "text-black" : "text-gray-400"
                      }`}
                    >
                     <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.area && item.area.length > 60) setHoveredCell(item.id + "-area");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.area}
    </p>

    {hoveredCell === item.id + "-area" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {item.area}
      </span>
    )}
  </div>
</td>

                     <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[40rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.state && item.state.length > 60) setHoveredCell(item.id + "-state");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.state}
    </p>

    {hoveredCell === item.id + "-state" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {item.state}
      </span>
    )}
  </div>
</td>


                      {/* Actions - Using ID */}
                      <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                        <div className="flex items-center justify-center gap-3">
                          {/* Edit */}
                          <div className="relative group">
                            <button onClick={() => handleEditClick(item)}>
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>


                            </button>
                            <span className="absolute top-[110%] left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 z-0 whitespace-nowrap pointer-events-none">
                              Edit
                            </span>
                          </div>

                          {/* Status Toggle - Using ID */}
                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedId(item.id);
                                setSelectedRowData(item);
                                item.status === "Active"
                                  ? setShowDeactivateModal(true)
                                  : setShowActivateModal(true);
                              }}
                            >
                              {item.status === "Active" ? (<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
<path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" stroke-width="2.66667" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

) :(<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<g clip-path="url(#clip0_5669_3080)">
<path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" stroke-width="2.66667" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
<clipPath id="clip0_5669_3080">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>
</svg>
)}
                            </button>
                            <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              {item.status === "Active" ? "Deactivate" : "Activate"}
                            </span>
                          </div>

                          {/* Delete - Using ID */}
                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedId(item.id);
                                setSelectedRowData(item);
                                setIsDeleteModalOpen(true);
                              }}
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>


                            </button>
                            <span className="absolute top-[110%] left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 z-0 whitespace-nowrap pointer-events-none">
                              Delete
                            </span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  !isLoadingdata && (
                    <tr>
                      <td colSpan={3} className="text-center py-8 text-gray-500 italic">
                        No data found
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>
           {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

        </div>

        {/* Add/Edit Popup */}
        {(showPopup || editPopup) && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
            <div 
            ref={popupRef}
            className="bg-white shadow-lg p-6 w-full max-w-md relative">
              <button
                onClick={resetForm}
                className="absolute top-4 right-4 text-gray-700 transition p-1 hover:scale-105 duration-200"
              >
                 <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>

              </button>

              <div className="text-center">
                <h3 className="text-base font-semibold text-MediumGrey">
                  {editPopup ? "Edit State Master" : "Add New State"}
                </h3>
              </div>

              {/* Market Area Dropdown */}
              <div className="relative mb-2" ref={marketAreaRef}>
                <label className="block text-xs font-medium text-MediumGrey mb-2">
                  Market Area <span className=" text-red1">*</span>
                </label>
                <div
                  className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none text-black placeholder:text-grey focus:ring-1 flex justify-between items-center  ${
                    isOpen
                      ? "border-black/30 border-b-white"
                      : formData.errors.area
                      ? "border-red1 focus:ring-red1"
                      : "border-black/30 focus:ring-black/30"
                  }`}
                  tabIndex={0}
                  onClick={() => setIsOpen(!isOpen)}
                    onKeyDown={(e) => {
    if (e.key === "Enter") {
      e.preventDefault();      // ❗ stop form submit
      e.stopPropagation();     // ❗ stop Save handler
      setIsOpen((prev) => !prev); // ⭐ open dropdown
    }
     if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsOpen(false);
      return;
    }
  }}
                >
                  <span className="text-black flex items-center">
                    
                    {formData.selectedArea || "- Select Market Area -"}
                  </span>

                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"className={`w-3 h-3 transform transition-transform duration-200 ${
                      isOpen ? "rotate-180" : ""
                    }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>

                </div>

               {isOpen && (
  <ul className="absolute z-10 text-xs w-full bg-white border border-black/30 border-t-white max-h-48 overflow-y-auto shadow-md">

    {/* 🔍 Search – only if more than 5 market areas */}
    {activeMarketAreas.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1.5 z-10">
       <input
  type="text"
  placeholder="Search market area..."
  value={areaSearch}
  onChange={(e) => setAreaSearch(e.target.value)}

  onKeyDown={(e) => {
    // prevent form submit
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
    }

    // ESC → close dropdown only
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation(); // 🔥 important

      setIsOpen(null); // or setIsAreaOpen(false)
      setAreaSearch("");       // optional
    }

    // Arrow ↓ → focus first option
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation();

      const first = e.currentTarget
        .closest("ul")
        ?.querySelector("li[tabindex]");
      first?.focus();
    }
  }}

  className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
  autoFocus
/>
      </li>
    )}

    {/* Filter + Sort + List */}
    {activeMarketAreas
      .filter((area) => area?.marketarea)
      .filter((area) =>
        !areaSearch
          ? true
          : area.marketarea.toLowerCase().includes(areaSearch.toLowerCase())
      )
      .sort((a, b) => a.marketarea.localeCompare(b.marketarea))
      .length > 0 ? (
        activeMarketAreas
          .filter((area) => area?.marketarea)
          .filter((area) =>
            !areaSearch
              ? true
              : area.marketarea.toLowerCase().includes(areaSearch.toLowerCase())
          )
          .sort((a, b) => a.marketarea.localeCompare(b.marketarea))
          .map((area, index) => (
           <li
  tabIndex={0}
  key={area.id ?? index}
  className={`px-4 py-1.5 cursor-pointer text-xs ${
    area.marketarea === formData.selectedArea
      ? "bg-lightBlue/30 font-medium"
      : "hover:bg-black/30 hover:text-white"
  }`}
  onKeyDown={(e) => {
    e.stopPropagation(); // ⭐ prevents Save

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
     setIsOpen(false);
      return;
    }
    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData((prev) => ({
        ...prev,
        selectedArea: area.marketarea,
        selectedAreaId: area.id,
        errors: { ...prev.errors, area: false },
      }));
      setIsOpen(false);
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setFormData((prev) => ({
      ...prev,
      selectedArea: area.marketarea,
      selectedAreaId: area.id,
      errors: { ...prev.errors, area: false },
    }));
    setIsOpen(false);
  }}
>
  {area.marketarea}
</li>
          ))
      ) : (
        <li className="px-4 py-2 text-sm text-gray-400 italic">
          No areas found.
        </li>
      )}
  </ul>
)}


                {formData.errors.area && (
                  <p className="text-red1 text-xs mt-1">Please fill out this field</p>
                )}
              </div>

              {/* State Dropdown */}
              <div className="relative mb-2" ref={stateDropdownRef}>
                <label className="block text-xs font-medium text-MediumGrey mb-2">
                  Select State <span className=" text-red1">*</span>
                </label>
                <div className="relative">
             <input
  placeholder="- Select or type state -"
  className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none text-black placeholder:text-grey focus:ring-1 flex justify-between items-center 
    ${
      stateOpen
        ? "border-black/30 border-b-white"
        : formData.errors.state
        ? "border-red1 focus:ring-red1"
        : "border-black/30 focus:ring-black/30"
    }`}
  tabIndex={0}
  value={formData.selectState}
  autoComplete="off"

  onChange={(e) => {
    setFormData((prev) => ({
      ...prev,
      selectState: e.target.value,
      errors: { ...prev.errors, state: false },
    }));
    setStateOpen(true);
  }}


  onKeyDown={(e) => {
    if (e.key === "Enter") {
      e.preventDefault();      // ❗ stop form submit
      e.stopPropagation();     // ❗ stop popup Save
      setStateOpen(true);      // ⭐ only open dropdown
    }
  }}
/>
                  {/* <img
                    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/dropdown.png"
                    alt="Dropdown"
                    onClick={() => setStateOpen(!stateOpen)}
                    className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-3 h-3 cursor-pointer transition-transform duration-200 ${
                      stateOpen ? "rotate-180" : "rotate-0"
                    }`}
                  /> */}
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-3 h-3 cursor-pointer transition-transform duration-200 ${
                      stateOpen ? "rotate-180" : "rotate-0"
                    }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>

               {stateOpen && (
  <ul className="absolute z-10 text-xs w-full bg-white border border-black/30 border-t-white max-h-48 overflow-y-auto shadow-md">

    {/* 🔍 Search – only if more than 5 states */}
    {allStatesList.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1.5 z-10">
       <input
  type="text"
  placeholder="Search state..."
  value={stateSearch}
  onChange={(e) => setStateSearch(e.target.value)}

  onKeyDown={(e) => {
    // prevent form submit
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
    }

    // ESC → close dropdown only
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation(); // 🔥 important

     setStateOpen(null); // or setIsStateOpen(false)
      setStateSearch("");      // optional
    }

    // Arrow ↓ → focus first option
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation();

      const first = e.currentTarget
        .closest("ul")
        ?.querySelector("li[tabindex]");
      first?.focus();
    }
  }}

  className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
  autoFocus
/>
      </li>
    )}

    {/* Filter + Sort + List */}
    {allStatesList
      .filter((s) => s?.state_name)
      .filter((s) =>
        !stateSearch
          ? true
          : s.state_name.toLowerCase().includes(stateSearch.toLowerCase())
      )
      .sort((a, b) => a.state_name.localeCompare(b.state_name))
      .length > 0 ? (
        allStatesList
          .filter((s) => s?.state_name)
          .filter((s) =>
            !stateSearch
              ? true
              : s.state_name.toLowerCase().includes(stateSearch.toLowerCase())
          )
          .sort((a, b) => a.state_name.localeCompare(b.state_name))
          .map((stateObj) => (
         <li
  tabIndex={0}
  key={stateObj.id}
  className={`px-4 py-1.5 text-xs cursor-pointer transition
    ${
      stateObj.state_name === formData.selectState
        ? "bg-lightBlue/30 font-medium"
        : "hover:bg-black/30 hover:text-white"
    }
  `}
  onKeyDown={(e) => {

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setStateOpen(false);

      // move focus back to dropdown trigger
      stateDropdownRef.current?.querySelector('[tabindex="0"]')?.focus();

      return;
    }

    e.stopPropagation(); // prevent Save

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }
    

    if (e.key === "Enter") {
      e.preventDefault();
e.stopPropagation()
      setFormData((prev) => ({
        ...prev,
        selectState: stateObj.state_name,
        errors: { ...prev.errors, state: false },
      }));

      setStateOpen(false);
    }
  }}

  onMouseDown={(e) => {
    e.preventDefault();

    setFormData((prev) => ({
      ...prev,
      selectState: stateObj.state_name,
      errors: { ...prev.errors, state: false },
    }));

    setStateOpen(false);
  }}
>
  {stateObj.state_name}
</li>
          ))
      ) : (
        <li className="px-4 py-2 text-sm text-gray-400 italic">
          No states found.
        </li>
      )}
  </ul>
)}

                </div>

                {formData.errors.state && (
                  <p className="text-red1 text-xs mt-1">Please fill out this field</p>
                )}
              </div>

              {errorMessage && (
                <p className="text-red1 text-xs mt-1">{errorMessage}</p>
              )}

              <div className="flex items-center justify-center gap-4 mt-2">
                <button
                  onClick={editPopup ? handleEditSubmit : handleSubmit}
                  disabled={loading}
                  className={`bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 
                    transition ${
                      loading
                        ? "opacity-50 cursor-not-allowed"
                        : "hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                    }`}
                >
                  {loading ? "Saving..." : "Save"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Delete Modal - Using ID */}
        {isDeleteModalOpen && selectedId && (
          <DeleteModal
            isOpen={isDeleteModalOpen}
            loading={deleteLoading}
            onClose={() => {
              if (!deleteLoading) {
                setIsDeleteModalOpen(false);
                setSelectedId(null);
                setSelectedRowData(null);
              }
            }}
            onConfirm={handleDelete}
            extraMessage="This will delete all the records related this State."
          />
        )}

        {/* Deactivate Modal - Using ID */}
        {showDeactivateModal && selectedId && (
          <DeactivateStatus
            isOpen={showDeactivateModal}
            loading={loadingToggle}
            onClose={() => {
              if (!loadingToggle) {
                setShowDeactivateModal(false);
                setSelectedId(null);
                setSelectedRowData(null);
              }
            }}
            onConfirm={handleToggleStatus}
          />
        )}

        {/* Activate Modal - Using ID */}
        {showActivateModal && selectedId && (
          <ActivateStatus
            isOpen={showActivateModal}
            loading={loadingToggle}
            onClose={() => {
              if (!loadingToggle) {
                setShowActivateModal(false);
                setSelectedId(null);
                setSelectedRowData(null);
              }
            }}
            onConfirm={handleToggleStatus}
          />
        )}

        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          multiple
          accept=".csv,.xlsx,.xls"
        />
      </div>
    </div>
  );
};

export default StateMasterTable;