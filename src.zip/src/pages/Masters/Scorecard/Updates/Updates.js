import React, { useState, useEffect } from "react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import UpdatesScorecard from "./UpdatesScorecard";

function Updates() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      {/* Header and SubNavbar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      {/* Content Wrapper */}
      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        {/* Main Component */}
        <UpdatesScorecard /> 

        {/* Scroll to Top Button */}
        {showScrollTop && (
          <div className="mt-12 mb-2 flex justify-end pr-4">
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="bg-Silvergrey text-black font-bold px-4 py-2 rounded-lg shadow-lg hover:scale-110 transition duration-200"
            >
              ^
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default Updates;
