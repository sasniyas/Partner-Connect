// // import React, { useState,useRef,useEffect } from "react";
// // // import Searchinput from "../../../../Components/Searchinput";
// // import { ArrowLeft, ArrowRight } from "lucide-react";
// // // import * as XLSX from "xlsx";
// // import DeleteModal from "../../../../Components/DeleteModal";
// // import Searchinput from "../../../../Components/Searchinput";

// // const UpdatesTable = () => {
// //   const userRoles = [
// //     "Administrator",
// //     "Auditor",
// //     "Volvo User",
// //     "Dealer Coordinator",
// //     "Dealer Sales Head",
// //     "Dealer CST Head",
// //     "Uptime & Parts Manager",
// //     "Market Area Head",
// //     "Volvo Functional Manager",
// //     "IMT",
// //     "Retail Sales Manager",
// //     "Dealer Finance Head",
// //     "Dealer HR Head",
// //     "Dealer Principal",
// //     "Financial Analyst",
// //     "Key Account Manager (Uptime & Parts)",
// //     "Head of Channel Development (Region India)",
// //     "Dealer CEO",
// //     "Dealer Parts Manager",
// //     "Key Account Manager (Sales)"
// //   ];

// //   const [tableData, setTableData] = useState([]);
// //   const [currentPage, setCurrentPage] = useState(1);
// //   const [showPopup, setShowPopup] = useState(false);
// //   const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
// //   const [selectedRow, setSelectedRow] = useState(null);
// //   const [userRoleDropdownOpen, setUserRoleDropdownOpen] = useState(false);
// //   const [userRole, setUserRole] = useState('');
// //   const [triggerAfter, setTriggerAfter] = useState('');
// // const [searchTerm, setSearchTerm] = useState("");
// // const userRoleRef = useRef(null);

// //   const rowsPerPage = 7;
// //   const startIndex = (currentPage - 1) * rowsPerPage;
// //   // const paginatedRecords = tableData.slice(startIndex, startIndex + rowsPerPage);
// //   const totalPages = Math.ceil(tableData.length / rowsPerPage);
// // const filteredData = tableData.filter(
// //   (item) =>
// //     item.userRole.toLowerCase().includes(searchTerm.toLowerCase()) ||
// //     item.triggerAfter.toLowerCase().includes(searchTerm.toLowerCase())
// // );

// // const paginatedRecords = filteredData.slice(startIndex, startIndex + rowsPerPage);
// // // const totalPages = Math.ceil(filteredData.length / rowsPerPage);

// //   const handleAdd = () => {
// //     if (userRole && triggerAfter) {
// //       setTableData([...tableData, { userRole, triggerAfter }]);
// //       setUserRole("");
// //       setTriggerAfter("");
// //       setShowPopup(false);
// //     } else {
// //       alert("Please fill all fields");
// //     }
// //   };

// //   const handleDelete = (rowIndex) => {
// //     const updated = [...tableData];
// //     updated.splice(rowIndex, 1);
// //     setTableData(updated);
// //     setIsDeleteModalOpen(false);
// //     setSelectedRow(null);
// //   };
// // useEffect(() => {
// //   const handleClickOutside = (event) => {
// //     if (userRoleRef.current && !userRoleRef.current.contains(event.target)) {
// //       setUserRoleDropdownOpen(false);
// //     }
// //   };

// //   document.addEventListener("mousedown", handleClickOutside);
// //   return () => {
// //     document.removeEventListener("mousedown", handleClickOutside);
// //   };
// // }, []);

// //   return (
// //     // <div className="w-full mt-6 px-4 flex justify-center">
// //     //   {/* <div className="w-full w-[105%] xl:w-[98%] 2xl:w-[85%] ml-[-75px] md:ml-[-80px] md:w-[105%] lg:ml-[-60px]">
// //     //     <div className="w-full flex justify-end mb-4"> */}
// //     //       <div className="w-full w-[105%]  xl:w-[101.35%] 2xl:w-[85%] ml-[-75px] md:ml-[-45px] md:w-[105%] lg:ml-[-56px]"> {/* Constrain max width if needed */}
// // <div className="w-full mt-6  flex justify-center">
// //   <div className="w-full w-[105%] lg:w-[99%] xl:w-[95.5%] 2xl:w-[89%] ml-[-65px] md:ml-[-60px] md:w-[105%] lg:ml-[-68px] xl:ml-[-70px]"> {/* Constrain max width if needed */}
// //         {/* <div className="w-full w-[105%]  xl:w-[98%] 2xl:w-[85%] ml-[-75px] md:ml-[-80px] md:w-[105%] lg:ml-[-60px]"> Constrain max width if needed */}
// //     <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 md:gap-12 lg:gap-18 mb-6">
// //     <Searchinput
// //       value={searchTerm}
// //    onChange={(e) => {
// //      setSearchTerm(e.target.value);
// //     setCurrentPage(1); // Reset to first page when searching
// //    }}
// //         placeholder="Search"
// //         className="w-full md:w-1/2 lg:w-1/3 xl:w-80"
// //         iconColor="text-black"
// //         bgColor="bg-FrostWhite"
// //         borderColor="border-black/60"
// //         textColor="text-black"
// //         shadow="shadow-none"
// //         inputPadding="pl-8 pr-3 py-2"
// //         iconSize="w-4 h-4"
// //         iconLeft="left-3"
// //         inputWidth="w-full"
// //         focusRing="focus:ring-1 focus:ring-black/60"
// //         hoverInputClasses="hover:bg-white hover:border-black/60"
// //       />
// //           <button
// //             onClick={() => setShowPopup(true)}
// //             className="flex items-center gap-2 px-6 py-2 bg-darkblue1 text-white text-base font-semibold rounded-lg shadow-sm hover:border hover:border-darkblue1 hover:text-darkblue1 hover:bg-white transition duration-200 whitespace-nowrap"
// //           >
// //             <span className="text-lg font-bold">+</span>
// //             Add New
// //           </button>
// //         </div>

// //         {/* Table */}
// //         <div className="bg-white shadow-md rounded-lg border border-Dustyblue pb-10 overflow-y-hidden overflow-x-auto md:overflow-x-hidden">
// //           <table className="w-full min-w-[600px] text-sm whitespace-nowrap">
// //             <thead className="bg-Dustyblue text-white text-left">
// //               <tr>
// //                 <th className="text-left px-6 py-4 text-base font-medium">User Role</th>
// //             <th className="text-right px-8 py-4 text-base font-medium">Trigger After</th>
// //               </tr>
// //             </thead>
// //             <tbody>
// //               {paginatedRecords.map((row, index) => (
// //                 <tr key={index} className="odd:bg-white even:bg-gery1 hover:bg-lightBlue/50">
// //                   <td className="px-6 py-4">{row.userRole}</td>
// //                   <td className="px-24 py-4 text-right">{row.triggerAfter}</td>
// //                 </tr>
// //               ))}
// //             </tbody>
// //           </table>
// //         </div>

// //         {/* Pagination */}
// //         {totalPages > 1 && (
// //           <div className="flex justify-end mt-4 gap-2">
// //             <button
// //               onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
// //               disabled={currentPage === 1}
// //               className="w-9 h-9 flex items-center justify-center rounded-lg bg-darkblue1 text-white text-lg font-bold hover:scale-110 transition disabled:opacity-50 disabled:cursor-not-allowed"
// //             >
// //               <ArrowLeft size={20} />
// //             </button>
// //             <button
// //               onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
// //               disabled={currentPage === totalPages}
// //               className="w-9 h-9 flex items-center justify-center rounded-lg bg-darkblue1 text-white text-lg font-bold hover:scale-110 transition disabled:opacity-50 disabled:cursor-not-allowed"
// //             >
// //               <ArrowRight size={20} />
// //             </button>
// //           </div>
// //         )}

// //         {/* Popup Modal */}
// //         {showPopup && (
// //           <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
// //             <div className="bg-white rounded-lg shadow-lg p-6 w-96 relative">
// //               <button
// //                 onClick={() => setShowPopup(false)}
// //                 className="absolute top-4 right-4 text-gray-700 transition p-1 hover:scale-105 duration-200"
// //               >
// //                 <img src="/icons/MarketAreaatble/cancel.png" alt="Close" className="w-5 h-5" />
// //               </button>
// //               <div className="mb-4 text-center">
// //                 <h3 className="text-MediumGrey text-lg font-semibold">Add Record</h3>
// //               </div>
// //               <div className="relative mb-4 w-[98%] mx-auto"ref={userRoleRef}>
// //                 <label className="block text-sm font-medium text-black/70 mb-2">User Role</label>
// //                 <div
// //                   className={`relative w-full text-sm border rounded-lg px-4 py-2 cursor-pointer flex justify-between items-center transition-all duration-200 ${userRoleDropdownOpen ? "border-black/30 border-b-white rounded-b-none" : "border-black/30 bg-white hover:ring-1 hover:ring-black/30"}`}
// //                   onClick={() => setUserRoleDropdownOpen(!userRoleDropdownOpen)}
// //                 >
// //                   <span>{userRole || "Select User Role"}</span>
// //                   <img
// //                     src="/icons/MarketAreaatble/dropdown.png"
// //                     alt="Dropdown"
// //                     className={`w-4 h-4 transform transition-transform duration-200 ${userRoleDropdownOpen ? "rotate-180" : "rotate-0"}`}
// //                   />
// //                 </div>
// //                 {userRoleDropdownOpen && (
// //                   <ul className="absolute left-7.5 mt-0 w-full  text-sm bg-white border border-black/30 border-t-white rounded-t-none rounded-lg shadow-lg z-10 max-h-40 overflow-auto">
// //                     {userRoles.map((role, idx) => (
// //                       <li
// //                         key={idx}
// //                         onClick={() => {
// //                           setUserRole(role);
// //                           setUserRoleDropdownOpen(false);
// //                         }}
// //                         className="px-4 py-2 hover:bg-black/30 hover:text-white transition duration-200 cursor-pointer"
// //                       >
// //                         {role}
// //                       </li>
// //                     ))}
// //                   </ul>
// //                 )}
// //               </div>
// //               <div className="mb-4">
// //                 <label className="block text-sm font-medium text-black/70 mb-2">Trigger After</label>
// //                 <input
// //                   type="text"
// //                   value={triggerAfter}
// //                   onChange={(e) => setTriggerAfter(e.target.value)}
// //                   className="w-full px-4 py-2 border border-black/30 text-sm rounded-lg focus:outline-none"
// //                   placeholder="Enter trigger description"
// //                 />
// //               </div>
// //               <div className="text-center">
// //                 <button
// //                   onClick={handleAdd}
// //                   // className="bg-ab text-mildBlue font-bold px-6 py-2 rounded-md hover:shadow-md hover:scale-105"
// //                             className="bg-darkblue1 text-white text-sm font-medium px-10 py-1.5 rounded-md hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"

// //                 >
// //                   Save
// //                 </button>
// //               </div>
// //             </div>
// //           </div>
// //         )}

// //         {isDeleteModalOpen && selectedRow !== null && (
// //           <DeleteModal
// //             isOpen={isDeleteModalOpen}
// //             onClose={() => setIsDeleteModalOpen(false)}
// //             onConfirm={() => handleDelete(selectedRow)}
// //           />
// //         )}
// //       </div>
// //     </div>
// //   );
// // };

// // export default UpdatesTable;


// import React, { useState, useRef, useEffect } from "react";
// import { ArrowLeft, ArrowRight } from "lucide-react";
// import DeleteModal from "../../../../Components/DeleteModal";
// import Filter from "../../../../Components/Filter";

// const types = [
//   { value: "dealer-user", label: "Dealer User" },
//   { value: "volvo-user", label: "Volvo User" },
// ];

// const roleOptions = {
//   "Dealer User": [
//     { value: "dealer-1", label: "Dealer 1" },
//     { value: "dealer-ceo", label: "Dealer CEO" },
//     { value: "dealer-coordinator", label: "Dealer Coordinator" },
//     { value: "dealer-cst-head", label: "Dealer CST Head" },
//     { value: "dealer-finance-head", label: "Dealer Finance Head" },
//     { value: "dealer-hr", label: "Dealer HR" },
//     { value: "dealer-hr-head", label: "Dealer HR Head" },
//     { value: "dealer-parts-manager", label: "Dealer Parts Manager" },
//     { value: "dealer-principal", label: "Dealer Principal" },
//     { value: "dealer-sales-head", label: "Dealer Sales Head" },
//   ],
//   "Volvo User": [
//     { value: "admin", label: "Administrator" },
//     { value: "auditor", label: "Auditor" },
//     { value: "financial-analyst", label: "Financial Analyst" },
//     { value: "head-channel-dev", label: "Head of Channel Development (Region India)" },
//     { value: "imt", label: "IMT" },
//     { value: "kam-sales", label: "Key Account Manager (Sales)" },
//     { value: "kam-uptime", label: "Key Account Manager (Uptime & Parts)" },
//     { value: "market-area-head", label: "Market Area Head" },
//     { value: "retail-sales-manager", label: "Retail Sales Manager" },
//     { value: "uptime-parts-manager", label: "Uptime & Parts Manager" },
//     { value: "volvo-engineer", label: "Volvo Engineer" },
//     { value: "volvo-functional-manager", label: "Volvo Functional Manager" },
//     { value: "volvo-manager", label: "Volvo Manager" },
//     { value: "volvo-user", label: "Volvo User" },
//   ],
// };

// const UpdatesTable = () => {
//   const [tableData, setTableData] = useState([]);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [showPopup, setShowPopup] = useState(false);
//   const [selectedRow, setSelectedRow] = useState(null);
//   const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
//   const [selectedType, setSelectedType] = useState("");
//   const [selectedRole, setSelectedRole] = useState("");
//   const [triggerAfter, setTriggerAfter] = useState("");
//   const [searchType, setSearchType] = useState("");
//   const [searchRole, setSearchRole] = useState("");

//   const rowsPerPage = 7;
//   const startIndex = (currentPage - 1) * rowsPerPage;

//   const formatDate = (str) => {
//     if (!str) return "";
//     const date = new Date(str);
//     return date.toLocaleDateString("en-IN", {
//       day: "2-digit",
//       month: "short",
//       year: "numeric",
//     });
//   };

//   const filteredData = tableData.filter((item) => {
//     const typeMatch = searchType ? item.type === searchType : true;
//     const roleMatch = searchRole ? item.role === searchRole : true;
//     return typeMatch && roleMatch;
//   });

//   const paginatedRecords = filteredData.slice(startIndex, startIndex + rowsPerPage);
//   const totalPages = Math.ceil(filteredData.length / rowsPerPage);

//   const handleAdd = () => {
//     if (!selectedType || !selectedRole || !triggerAfter) {
//       alert("Please fill all fields");
//       return;
//     }
//     const typeLabel = types.find((t) => t.value === selectedType)?.label;
//     const roleLabel = roleOptions[typeLabel]?.find((r) => r.value === selectedRole)?.label;
//     setTableData([
//       ...tableData,
//       { type: selectedType, role: selectedRole, typeLabel, roleLabel, triggerAfter },
//     ]);
//     setSelectedType("");
//     setSelectedRole("");
//     setTriggerAfter("");
//     setShowPopup(false);
//   };

//   const handleDelete = (rowIndex) => {
//     const updated = [...tableData];
//     updated.splice(rowIndex, 1);
//     setTableData(updated);
//     setIsDeleteModalOpen(false);
//     setSelectedRow(null);
//   };

//   return (
//     <div className="w-full mt-6 flex justify-center">
//       <div className="w-full w-[105%] lg:w-[99%] xl:w-[95.5%] 2xl:w-[89%] ml-[-65px] md:ml-[-60px]">
//         <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
//           <div className="flex flex-wrap items-center gap-4 w-full md:w-[80%]">
//             <input
//               type="text"
//               placeholder="Search User Role"
//               className="px-4 py-2 w-full sm:w-48 md:w-56 border border-gray-300 rounded-lg text-sm"
//               onChange={(e) => {
//                 const value = e.target.value.toLowerCase();
//                 const match = tableData.find((item) =>
//                   item.roleLabel.toLowerCase().includes(value)
//                 );
//                 if (match) {
//                   setSearchRole(match.role);
//                   setSearchType(match.type);
//                 } else {
//                   setSearchRole("");
//                   setSearchType("");
//                 }
//               }}
//             />
//             <Filter
//               name="type"
//               value={searchType ? types.find((t) => t.value === searchType)?.label : ""}
//               options={types.map((t) => t.label)}
//               onChange={(key, label) => {
//                 const selected = types.find((t) => t.label === label)?.value;
//                 setSearchType(selected);
//                 setSearchRole("");
//               }}
//               placeholder="User Type"
//             />
//             <Filter
//               name="role"
//               value={
//                 searchRole && searchType
//                   ? roleOptions[types.find((t) => t.value === searchType)?.label].find(
//                       (r) => r.value === searchRole
//                     )?.label
//                   : ""
//               }
//               options={
//                 searchType
//                   ? roleOptions[types.find((t) => t.value === searchType)?.label].map((r) => r.label)
//                   : []
//               }
//               onChange={(key, label) => {
//                 const selected = roleOptions[
//                   types.find((t) => t.value === searchType)?.label
//                 ]?.find((r) => r.label === label)?.value;
//                 setSearchRole(selected);
//               }}
//               placeholder="User Role"
//             />
//           </div>
//           <button
//             onClick={() => setShowPopup(true)}
//             className="flex items-center gap-2 px-6 py-2 bg-darkblue1 text-white font-semibold rounded-lg shadow-sm hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
//           >
//             <span className="text-lg font-bold">+</span>Add New
//           </button>
//         </div>

//         <div className="bg-white shadow-md rounded-lg border border-Dustyblue pb-10 overflow-x-auto">
//           <table className="w-full min-w-[600px] text-sm">
//             <thead className="bg-Dustyblue text-white">
//               <tr>
//                 <th className="text-left px-6 py-4 text-base font-medium">User Role</th>
//                 <th className="text-right px-6 py-4 text-base font-medium">Trigger After</th>
//               </tr>
//             </thead>
//             <tbody>
//               {paginatedRecords.map((row, index) => (
//                 <tr key={index} className="odd:bg-white even:bg-gery1 hover:bg-lightBlue/50">
//                   <td className="px-6 py-4">{row.roleLabel}</td>
//                   <td className="px-6 py-4 text-right">{formatDate(row.triggerAfter)}</td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>

//         {totalPages > 1 && (
//           <div className="flex justify-end mt-4 gap-2">
//             <button
//               onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
//               disabled={currentPage === 1}
//               className="w-9 h-9 rounded-lg bg-darkblue1 text-white flex items-center justify-center hover:scale-110 disabled:opacity-50"
//             >
//               <ArrowLeft size={20} />
//             </button>
//             <button
//               onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
//               disabled={currentPage === totalPages}
//               className="w-9 h-9 rounded-lg bg-darkblue1 text-white flex items-center justify-center hover:scale-110 disabled:opacity-50"
//             >
//               <ArrowRight size={20} />
//             </button>
//           </div>
//         )}

//         {showPopup && (
//           <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
//             <div className="bg-white rounded-lg shadow-lg p-6 w-96 relative">
//               <button
//                 onClick={() => setShowPopup(false)}
//                 className="absolute top-4 right-4 text-gray-700"
//               >
//                 <img src="/icons/MarketAreaatble/cancel.png" alt="Close" className="w-5 h-5" />
//               </button>
//               <h3 className="text-center mb-4 text-lg font-semibold text-gray-700">Add Record</h3>

//               <div className="mb-4">
//                 <label className="text-sm font-medium text-black/70 mb-1 block">User Type</label>
//                 <select
//                   value={selectedType}
//                   onChange={(e) => {
//                     setSelectedType(e.target.value);
//                     setSelectedRole("");
//                   }}
//                   className="w-full px-4 py-2 border border-black/30 text-sm rounded-lg"
//                 >
//                   <option value="">Select Type</option>
//                   {types.map((type) => (
//                     <option key={type.value} value={type.value}>
//                       {type.label}
//                     </option>
//                   ))}
//                 </select>
//               </div>

//               <div className="mb-4">
//                 <label className="text-sm font-medium text-black/70 mb-1 block">User Role</label>
//                 <select
//                   value={selectedRole}
//                   onChange={(e) => setSelectedRole(e.target.value)}
//                   className="w-full px-4 py-2 border border-black/30 text-sm rounded-lg"
//                 >
//                   <option value="">Select Role</option>
//                   {(selectedType
//                     ? roleOptions[types.find((t) => t.value === selectedType)?.label]
//                     : []
//                   ).map((role) => (
//                     <option key={role.value} value={role.value}>
//                       {role.label}
//                     </option>
//                   ))}
//                 </select>
//               </div>

//               <div className="mb-4">
//                 <label className="text-sm font-medium text-black/70 mb-1 block">Trigger After</label>
//                 <input
//                   type="date"
//                   value={triggerAfter}
//                   onChange={(e) => setTriggerAfter(e.target.value)}
//                   className="w-full px-4 py-2 border border-black/30 text-sm rounded-lg"
//                 />
//               </div>

//               <div className="text-center">
//                 <button
//                   onClick={handleAdd}
//                   className="bg-darkblue1 text-white px-8 py-2 rounded-md hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
//                 >
//                   Save
//                 </button>
//               </div>
//             </div>
//           </div>
//         )}

//         {isDeleteModalOpen && selectedRow !== null && (
//           <DeleteModal
//             isOpen={isDeleteModalOpen}
//             onClose={() => setIsDeleteModalOpen(false)}
//             onConfirm={() => handleDelete(selectedRow)}
//           />
//         )}
//       </div>
//     </div>
//   );
// };

// export default UpdatesTable;


import React, { useState } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import DeleteModal from "../../../../Components/DeleteModal";
import Filter from "../../../../Components/Filter";
import Searchinput from "../../../../Components/Searchinput";

const types = [
  { value: "dealer-user", label: "Dealer User" },
  { value: "volvo-user", label: "Volvo User" },
];

const roleOptions = {
  "Dealer User": [
    { value: "dealer-1", label: "Dealer 1" },
    { value: "dealer-ceo", label: "Dealer CEO" },
    { value: "dealer-coordinator", label: "Dealer Coordinator" },
    { value: "dealer-cst-head", label: "Dealer CST Head" },
    { value: "dealer-finance-head", label: "Dealer Finance Head" },
    { value: "dealer-hr", label: "Dealer HR" },
    { value: "dealer-hr-head", label: "Dealer HR Head" },
    { value: "dealer-parts-manager", label: "Dealer Parts Manager" },
    { value: "dealer-principal", label: "Dealer Principal" },
    { value: "dealer-sales-head", label: "Dealer Sales Head" },
  ],
  "Volvo User": [
    { value: "admin", label: "Administrator" },
    { value: "auditor", label: "Auditor" },
    { value: "financial-analyst", label: "Financial Analyst" },
    { value: "head-channel-dev", label: "Head of Channel Development (Region India)" },
    { value: "imt", label: "IMT" },
    { value: "kam-sales", label: "Key Account Manager (Sales)" },
    { value: "kam-uptime", label: "Key Account Manager (Uptime & Parts)" },
    { value: "market-area-head", label: "Market Area Head" },
    { value: "retail-sales-manager", label: "Retail Sales Manager" },
    { value: "uptime-parts-manager", label: "Uptime & Parts Manager" },
    { value: "volvo-engineer", label: "Volvo Engineer" },
    { value: "volvo-functional-manager", label: "Volvo Functional Manager" },
    { value: "volvo-manager", label: "Volvo Manager" },
    { value: "volvo-user", label: "Volvo User" },
  ],
};

const UpdatesTable = () => {
  const [tableData, setTableData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [showPopup, setShowPopup] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  // In your state
const [selectedRoles, setSelectedRoles] = useState([]);
const [selectedRoleLabels, setSelectedRoleLabels] = useState([]);

  const [searchType, setSearchType] = useState("");
  const [searchRole, setSearchRole] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
const [selectedType, setSelectedType] = useState("");
const [selectedTypeLabel, setSelectedTypeLabel] = useState("");
const [userTypeDropdownOpen, setUserTypeDropdownOpen] = useState(false);

const [selectedRole, setSelectedRole] = useState("");
const [selectedRoleLabel, setSelectedRoleLabel] = useState("");
const [userRoleDropdownOpen, setUserRoleDropdownOpen] = useState(false);
const [message, setMessage] = useState("");

const [triggerAfter, setTriggerAfter] = useState("");

  const rowsPerPage = 7;
  const startIndex = (currentPage - 1) * rowsPerPage;

  

  const filteredData = tableData.filter((item) => {
    const typeMatch = searchType ? item.type === searchType : true;
    const roleMatch = searchRole ? item.role === searchRole : true;
    return typeMatch && roleMatch;
  });

  const paginatedRecords = filteredData.slice(startIndex, startIndex + rowsPerPage);
  const totalPages = Math.ceil(filteredData.length / rowsPerPage);

  const handleAdd = () => {
  if (!selectedType || selectedRoles.length === 0 || !triggerAfter || !message.trim()) {
    alert("Please fill all fields");
    return;
  }

  const typeLabel = types.find((t) => t.value === selectedType)?.label;

  const newEntries = selectedRoles.map((roleLabel) => {
    const roleObj = roleOptions[typeLabel]?.find((r) => r.label === roleLabel);
    return {
      type: selectedType,
      role: roleObj?.value || "",
      typeLabel,
      roleLabel,
      triggerAfter,
      message: message.trim(),
    };
  });

  setTableData([...tableData, ...newEntries]);

  // ✅ Reset all fields
  setSelectedType("");
  setSelectedTypeLabel("");
  setSelectedRoles([]);
  setTriggerAfter("");
  setMessage("");
  setShowPopup(false);
  setUserTypeDropdownOpen(false);
  setUserRoleDropdownOpen(false);
};

  const handleDelete = (rowIndex) => {
    const updated = [...tableData];
    updated.splice(rowIndex, 1);
    setTableData(updated);
    setIsDeleteModalOpen(false);
    setSelectedRow(null);
  };

  return (
   <div className="w-full mt-6 flex justify-center">
  <div className="w-full max-w-[1290px]">


        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div className="flex flex-wrap items-center gap-4 w-full md:w-[80%]">
            <Searchinput
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
                const value = e.target.value.toLowerCase();
                const match = tableData.find((item) =>
                  item.roleLabel.toLowerCase().includes(value)
                );
                if (match) {
                  setSearchRole(match.role);
                  setSearchType(match.type);
                } else {
                  setSearchRole("");
                  setSearchType("");
                }
              }}
              placeholder="Search"
              className="w-full md:w-1/2 lg:w-1/3 xl:w-80"
              iconColor="text-black"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              shadow="shadow-none"
              inputPadding="pl-8 pr-3 py-2"
              iconSize="w-4 h-4"
              iconLeft="left-3"
              inputWidth="w-full"
              focusRing="focus:ring-1 focus:ring-black/60"
              hoverInputClasses="hover:bg-white hover:border-black/60"
            />
            <Filter
              name="type"
              value={searchType ? types.find((t) => t.value === searchType)?.label : ""}
              options={types.map((t) => t.label)}
              onChange={(key, label) => {
                const selected = types.find((t) => t.label === label)?.value;
                setSearchType(selected);
                setSearchRole("");
              }}
             className="h-10 w-full md:w-80"
  placeholder="Select User Type"           // 👈 Updated here
  placeholderColor="text-black"
  buttonBorderColor="border-black"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
            />
            <Filter
              name="role"
              value={
                searchRole && searchType
                  ? roleOptions[types.find((t) => t.value === searchType)?.label].find(
                      (r) => r.value === searchRole
                    )?.label
                  : ""
              }
              options={
                searchType
                  ? roleOptions[types.find((t) => t.value === searchType)?.label].map((r) => r.label)
                  : []
              }
              onChange={(key, label) => {
                const selected = roleOptions[
                  types.find((t) => t.value === searchType)?.label
                ]?.find((r) => r.label === label)?.value;
                setSearchRole(selected);
              }}
              placeholder="User Role"
              className="h-10 w-full md:w-80"
  // placeholder="Select Market Area"           // 👈 Updated here
  placeholderColor="text-black"
  buttonBorderColor="border-black"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
            />
          </div>
          <button
            onClick={() => setShowPopup(true)}
            className="flex items-center gap-2 px-6 py-1 bg-darkblue1 text-white font-semibold rounded-lg shadow-sm hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
          >
            <span className="text-lg font-bold">+</span>Add New
          </button>
        </div>

        <div className="bg-white shadow-md rounded-lg border border-Dustyblue pb-10 overflow-x-auto">
          <table className="w-full min-w-[600px] text-sm">
            <thead className="bg-Dustyblue text-white">
  <tr>
    <th className="text-left px-6 py-4 text-base font-medium w-[20%]">User Role</th>
    <th className="text-center px-12  py-4 text-base font-medium w-[20%] ">Trigger After</th>
    <th className="text-left px-6  pl-40 py-4 text-base font-medium w-[60%]">Message</th>
  </tr>
</thead>

            <tbody>
  {paginatedRecords.map((row, index) => (
    <tr key={index} className="odd:bg-white even:bg-gery1 hover:bg-lightBlue/50">
      <td className="px-6 py-4">{row.roleLabel}</td>
      <td className="px-20  py-4 text-left">{row.triggerAfter} Days</td>
      <td className="px-6  pl-40  py-4 text-left">{row.message}</td>
    </tr>
  ))}
</tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div className="flex justify-end mt-4 gap-2">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="w-9 h-9 rounded-lg bg-darkblue1 text-white flex items-center justify-center hover:scale-110 disabled:opacity-50"
            >
              <ArrowLeft size={20} />
            </button>
            <button
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="w-9 h-9 rounded-lg bg-darkblue1 text-white flex items-center justify-center hover:scale-110 disabled:opacity-50"
            >
              <ArrowRight size={20} />
            </button>
          </div>
        )}

        {showPopup && (
  <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
    <div className="bg-white rounded-lg shadow-lg p-6 w-96 relative">
      <button
        onClick={() => setShowPopup(false)}
        className="absolute top-4 right-4 text-gray-700 transition p-1 hover:scale-105 duration-200"
      >
        <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" alt="Close" className="w-5 h-5" />
      </button>

      <h3 className="text-center mb-4 text-lg font-semibold text-MediumGrey">Updates </h3>

      {/* User Type */}
      <div className="mb-4 relative">
        <label className="text-sm font-medium text-black/70 mb-2 block">User Type</label>
        <div
          className={`relative w-full text-sm border rounded-lg px-4 py-2 cursor-pointer flex justify-between items-center transition-all duration-200 ${
            userTypeDropdownOpen
              ? "border-black/30 border-b-white rounded-b-none"
              : "border-black/30 bg-white hover:ring-1 hover:ring-black/30"
          }`}
          onClick={() => setUserTypeDropdownOpen(!userTypeDropdownOpen)}
        >
          <span>{selectedTypeLabel || "Select User Type"}</span>
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/dropdown.png"
            alt="Dropdown"
            className={`w-4 h-4 transform transition-transform duration-200 ${
              userTypeDropdownOpen ? "rotate-180" : "rotate-0"
            }`}
          />
        </div>
        {userTypeDropdownOpen && (
          <ul className="absolute z-10 left-0 mt-0 w-full text-sm bg-white border border-black/30 border-t-white rounded-t-none rounded-lg shadow-lg max-h-40 overflow-auto">
            {types.map((type) => (
              <li
                key={type.value}
                onClick={() => {
                  setSelectedType(type.value);
                  setSelectedTypeLabel(type.label);
                  setUserTypeDropdownOpen(false);
                  setSelectedRole("");
                  setSelectedRoleLabel("");
                }}
                className="px-4 py-2 hover:bg-black/30 hover:text-white transition duration-200 cursor-pointer"
              >
                {type.label}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* User Role */}
     <div className="mb-4 relative">
  <label className="text-sm font-medium text-black/70 mb-2 block">User Role</label>

  {/* Clickable Dropdown Box */}
  <div
    className={`relative w-full text-sm border rounded-lg px-4 py-2 cursor-pointer flex justify-between items-center transition-all duration-200 ${
      userRoleDropdownOpen
        ? "border-black/30 border-b-white rounded-b-none"
        : "border-black/30 bg-white hover:ring-1 hover:ring-black/30"
    }`}
    onClick={() =>
      selectedType && setUserRoleDropdownOpen((prev) => !prev)
    }
  >
    <div className="flex flex-wrap gap-2 max-w-[85%]">
      {selectedRoles.length > 0 ? (
        selectedRoles.map((role, i) => (
          <span
            key={i}
            className="bg-grey2 text-black text-xs px-2 py-[2px] rounded-md flex items-center gap-1"
          >
            {role}
            <button
              onClick={(e) => {
                e.stopPropagation();
                const updated = selectedRoles.filter((r) => r !== role);
                setSelectedRoles(updated);
              }}
            >
              <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
                alt="remove"
                className="w-3 h-3"
              />
            </button>
          </span>
        ))
      ) : (
        <span className="text-gray-400">Select User Role</span>
      )}
    </div>

    <img
      src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/dropdown.png"
      alt="Dropdown"
      className={`w-4 h-4 transform transition-transform duration-200 ${
        userRoleDropdownOpen ? "rotate-180" : "rotate-0"
      }`}
    />
  </div>

  {/* Dropdown List */}
  {userRoleDropdownOpen && selectedType && (
    <ul className="absolute z-10 left-0 mt-0 w-full text-sm bg-white border border-black/30 border-t-white rounded-t-none rounded-lg shadow-lg max-h-40 overflow-auto">
      {roleOptions[types.find((t) => t.value === selectedType)?.label]?.map(
        (role, idx) => {
          const alreadySelected = selectedRoles.includes(role.label);
          return (
            <li
              key={idx}
              onClick={(e) => {
                e.stopPropagation();
                if (!alreadySelected) {
                  setSelectedRoles([...selectedRoles, role.label]);
                }
              }}
              className={`px-4 py-2 flex justify-between items-center cursor-pointer transition duration-200 ${
                alreadySelected ? "" : "hover:bg-black/10"
              }`}
            >
              <span>{role.label}</span>
              {alreadySelected && (
                <span className="text-xs text-green-600 font-medium"></span>
              )}
            </li>
          );
        }
      )}
    </ul>
  )}
</div>


      {/* Trigger After */}
      <div className="mb-4">
        <label className="text-sm font-medium text-black/70 mb-1 block">Trigger After</label>
        <div className="flex items-center border border-black/30 rounded-lg overflow-hidden h-10 focus-within:ring-1 focus-within:ring-black/60">
          <input
            type="number"
            value={triggerAfter}
            onChange={(e) => setTriggerAfter(e.target.value)}
            placeholder="Enter number"
            className="w-full px-4 py-2 text-sm text-black bg-white focus:outline-none"
          />
          <span className="px-4 py-2 text-sm text-black/70 bg-gray-100">Days</span>
        </div>
      </div>
 <div className="mb-4">
        <label className="text-sm font-medium text-black/70 mb-1 block">Message</label>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Enter message"
          rows={3}
          className="w-full px-4 py-2 text-sm border border-black/30 rounded-lg resize-none focus:outline-none focus:ring-1 focus:ring-black/60"
        />
      </div>
      {/* Save Button */}
      <div className="text-center">
        <button
          onClick={handleAdd}
          className="bg-darkblue1 text-white px-8 py-2 rounded-md hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
        >
          Save
        </button>
      </div>
    </div>
  </div>
)}


        {isDeleteModalOpen && selectedRow !== null && (
          <DeleteModal
            isOpen={isDeleteModalOpen}
            onClose={() => setIsDeleteModalOpen(false)}
            onConfirm={() => handleDelete(selectedRow)}
          />
        )}
      </div>
    </div>
  );
};

export default UpdatesTable;
