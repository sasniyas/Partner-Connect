import React from "react";
import { useNavigate } from "react-router-dom";
import UpdatesTable from "./UpdatesTable";

const UpdatesScorecard = () => {
  const navigate = useNavigate();

 const buttons = [
    { label: "Market Area", path: "/masters/scorecard" },
    { label: "Country Master", path: "/masters/countrymaster" }, // Current page
    { label: "State Master", path: "/masters/statemaster" },
    { label: "City Master", path:  "/masters/citymaster" },
    { label: "Dealer Master", path: "/masters/dealermaster" },
          { label: "Strategic Obj", path: "/masters/strategicobjective"  },

    { label: "KPIs Master", path:"/masters/kpimaster" },
    { label: "Sub KPIs Master", path:"/masters/subkpimaster" },
    { label: "Updates", path: "/masters/updates" },
  ];

  const currentPath = "/masters/updates"; // ✅ Update currentPath

  return (
    <div className="w-full flex flex-col items-center justify-center px-4 pt-[160px]">
      {/* Heading */}
      <h2 className="text-center text-2xl sm:text-3xl font-semibold text-darkblue1 font-VolvoNovum mb-8">
        Scorecard Master Data
      </h2>

      {/* Button Row */}
      <div className="w-full overflow-x-auto">
        <div className="flex justify-center gap-5 min-w-[1100px]">
          {buttons.map(({ label, path }) => (
            <button
              key={label}
              onClick={() => {
                if (path !== currentPath && path !== "#") navigate(path);
              }}
              className={`w-[125px] py-2 whitespace-nowrap rounded-md text-sm font-medium font-VolvoNovum transition duration-200
                ${
                  path === currentPath
                    ? "bg-Dustyblue text-white border border-Dustyblue"
                    : "bg-white text-black border border-darkblue1 hover:bg-Dustyblue hover:text-white"
                }
              `}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* ✅ State Master Table */}
  <div className="w-full flex justify-center">
  <div className="w-full max-w-[1285px]">
  <UpdatesTable />
  </div> 
      </div>
    </div>
  );
};

export default UpdatesScorecard;
