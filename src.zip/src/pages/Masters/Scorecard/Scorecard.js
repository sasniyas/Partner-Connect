// // 

// import React from "react";
// import { useNavigate } from "react-router-dom";
// import MarketAreaTable from "./MarketArea/MarketAreaTable"; // or replace with correct table per view

// const ScorecardButtons = () => {
//   const navigate = useNavigate();

//   const buttons = [
//     { label: "Market Area", path: "/masters/scorecard" },
//     { label: "Country Master", path: "/masters/countrymaster" },
//     { label: "State Master", path: "/masters/statemaster" }, // ✅ This is current
//     { label: "City Master", path: "/masters/citymaster" },
//     { label: "Dealer Master", path: "/masters/dealer-master" },
//     { label: "KPIs Master", path: "/masters/kpi-master" },
//     { label: "Sub KPIs Master", path: "/masters/subkpi-master" },
//     { label: "Updates", path: "/masters/updates" },
//   ];

//   return (
//     <div className="w-full flex flex-col items-center justify-center px-4 pt-[160px]">
//       <h2 className="text-center text-2xl sm:text-3xl font-semibold text-darkblue1 font-VolvoNovum mb-8">
//         Scorecard Master Data
//       </h2>

//       <div className="w-full overflow-x-auto">
//         <div className="flex justify-center gap-7 min-w-[1200px]">
//           {buttons.map(({ label, path }, index) => (
//             <button
//               key={label}
//               onClick={() => navigate(path)}
//               className={`w-[125px] py-2 whitespace-nowrap rounded-md text-base font-medium font-VolvoNovum transition duration-200
//                 ${
//                   index === 0
//                     ? "bg-Dustyblue text-white border border-Dustyblue"
//                     : "bg-white text-black border border-darkblue1 hover:bg-Dustyblue hover:text-white"
//                 }
//               `}
//             >
//               {label}
//             </button>
//           ))}
//         </div>
//       </div>

//       {/* You can remove this if it's specific to "Market Area" only */}
//       <div className="mt-0 w-full max-w-[1200px]">
//         <MarketAreaTable />
//       </div>
//     </div>
//   );
// };

// export default ScorecardButtons;
