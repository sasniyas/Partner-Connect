import React, { useState,useEffect } from "react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
// import CountrymasterScorecard from "./CountrymasterScorecard";
import CountrymasterScorecard from "./CountrymasterScorecard";
function CountryMaster() {
  const [menuOpen, setMenuOpen] = useState(false);
   
  return (
<div className="bg-Frostwhite h-screen overflow-y-hidden  flex-col">
      {/* Navigation Bar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
<SubNavbar3/>
      {/* Main Content - Moves Right when Sidebar Opens */}
      {/* <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : "ml-0"} mt-[-10px] p-4`}> */}
      <div
        className={`transition-all duration-300 ${
          menuOpen ? "ml-60" : ""
        }`}
      >
                       <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:p-2">
   
      <CountrymasterScorecard/>
      </div>
      

      </div>
    </div>
  );
}

export default CountryMaster;

