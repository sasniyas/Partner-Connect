import React from "react";
import Header from "../../../../Components/Header";
import { useState } from "react";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import SubkpiAdd from "./SubkpiAdd";

const SubkpiHome = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="bg-Frostwhite min-h-screen  flex-col">
      {/* Navigation Bar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      {/* Main Content - Moves Right when Sidebar Opens */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
          overflow-hidden
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:p-2 overflow-hidden">
          <SubkpiAdd />
        </div>
      </div>
    </div>
  );
};

export default SubkpiHome;