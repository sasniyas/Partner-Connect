"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../Components/Header";
import { ChevronDown, ChevronUp } from "lucide-react";

function SubkpiDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

 const prepareExcelData = () => {
  return tableData.map((record, index) => {
    const users = Array.isArray(record.users)
      ? record.users.map(u => [u.firstName, u.middleName, u.lastName].filter(Boolean).join(" ")).join(", ")
      : "-";

    return {
      "Sl. No": index + 1,
      "Created Year": record.createdYear || "-",
      "Strategic Objective": record.objectiveName || "-",
      "KPI No.": record.kpiNumber || "-",
      "KPI": record.kpiName || "-",
      "Sub KPI": record.subKpiName || "-",
      "Assessment Period": record.assessmentPeriod || "-",
      "Max Score": record.maxScore || "-",
      "Min Score": record.minScore || "-",
      "Measurement": record.measurement || "-",
      "Annual Score": record.annualScore || "-",
      "User Name": users,
      "Status": record.isActive === 1 ? "Active" : "Inactive",
    };
  });
};


  const handleDownloadExcel = () => {
    if (!tableData || tableData.length === 0) return;
    const excelData = prepareExcelData();
    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sub KPI");
    XLSX.writeFile(workbook, "Sub_KPI.xlsx");
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">Sub KPI</h2>
          <button
            className="bg-darkblue1 text-white font-medium px-4 py-1.5 text-sm hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadExcel}
          >
            Download
          </button>
        </div>

        {/* Expand/Collapse */}
        <div className="flex items-center mb-1">
          <button
            onClick={() => setIsExpanded((prev) => !prev)}
            className="h-5 w-5 rounded-md bg-Dustyblue text-white flex items-center justify-center hover:bg-blue-800 transition"
          >
            {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
          <span className="ml-2 text-sm">{isExpanded ? "Collapse Table" : "Expand Table"}</span>
        </div>

        {/* Table */}
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
          <table className="w-full text-xs text-left table-auto border-collapse">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Sl. No</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Created Year</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Strategic Objective</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">KPI No.</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">KPI</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Sub KPI</th>
                {isExpanded && (
                  <>
                    <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Assessment Period</th>
                    <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Max Score</th>
                    <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Min Score</th>
                    <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Measurement</th>
                    <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Annual Score</th>
                    <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">User Name</th>
                  </>
                )}
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0">Status</th>
              </tr>
            </thead>

            <tbody>
              {tableData.length > 0 ? (
                tableData.map((record, index) => {
                  const users = Array.isArray(record.users)
                    ? record.users.map(u => [u.firstName, u.middleName, u.lastName].filter(Boolean).join(" ")).slice(0, 3).join(", ")
                    : "-";

                  return (
                    <tr key={index} className="hover:bg-lightBlue/50 text-xs font-normal">
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{index + 1}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{record.createdYear || "-"}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0  truncate max-w-[120px]" title={record.objectiveName}>{record.objectiveName || "-"}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{record.kpiNumber || "-"}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0  truncate max-w-[120px]" title={record.kpiName}>{record.kpiName || "-"}</td>
                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0  truncate max-w-[120px]" title={record.subKpiName}>{record.subKpiName || "-"}</td>

                      {isExpanded && (
                        <>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{record.assessmentPeriod || "-"}</td>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{record.maxScore || "-"}</td>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">{record.minScore || "-"}</td>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0  truncate max-w-[120px]" title={record.measurement}>{record.measurement || "-"}</td>
                          <td className="px-4 py-1 border border border-grey2 border-t-0 border-l-0 border border-grey2 border-t-0 border-l-0 ">{record.annualScore || "-"}</td>
                          <td className="px-4 py-1 border border border-grey2 border-t-0 border-l-0  truncate max-w-[150px]" title={users}>{users}</td>
                        </>
                      )}

                      <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">{record.isActive === 1 ? "Active" : "Inactive"}</td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={isExpanded ? 13 : 7} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default SubkpiDownload;
