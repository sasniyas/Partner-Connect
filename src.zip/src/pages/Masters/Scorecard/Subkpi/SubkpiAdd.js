import { useState, useRef, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import StyledSelectField from "../../../../Components/StyledSelectField";
import Clone from "../../../../Components/Clone";
import { ArrowLeft } from "lucide-react";
import {
  Bold,
  Italic,
  Underline,
  List,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Copy,
  RotateCcw,
} from "lucide-react";

import {
  getAllSubKPIs,
  getAllKPIs,
  getAllStrategicObjectives,
  getAllRoles,
  getAllUsers,
  addSubKPI,
  updateSubKPI,
  buildSubKPIFormData,
  checkSubKPIExists,
  getFilteredRoles,
  getFilteredUsers,
  getYearsArray,
  ASSESSMENT_PERIODS,
  MEASUREMENTS,
  ANNUAL_SCORE_OPTIONS,
  DEALER_CONTENT_OPTIONS,
} from "../../../../services/Masters/SubKpi/subKpi.service";
import { useKeyboardNavigation } from "../../../../util/useKeyboardNavigation";

const SubkpiAdd = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const locationState = location.state || {};
  const [isEditing, setIsEditing] = useState(locationState.isEditing || false);
  const editData = locationState.editData || null;

  const [form, setForm] = useState({
    id: "",
    year: new Date().getFullYear(),
    kpiNumber: "",
    maxScore: "",
    minScore: "",
    subKpi: "",
    strategicObjective: "",
    userType: "",
    userRole: [],
    userName: [],
    dealerContent: "",
    annualScore: "",
    kpi: "",
    assessmentPeriod: "",
    status: "",
    measurement: "",
    scoringCriteria: "",
    supportingDocument: null,
    existingFileUrl: null,
    annualScoringCriteria: "",
    criteriaDefinition: "",
    dataSource: "",
  });

  const [subKPIs, setSubKPIs] = useState([]);
  const [apiData, setApiData] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [kpiOptions, setKpiOptions] = useState([]);
  const [objectives, setObjectives] = useState([]);
  const [errors, setErrors] = useState({});
  const [submitError, setSubmitError] = useState("");
  const [loading, setLoading] = useState(false);
  const [isCloning, setIsCloning] = useState(false);
  const [showCloneModal, setShowCloneModal] = useState(false);
  const [dropdowns, setDropdowns] = useState({});
  const [originalEditData, setOriginalEditData] = useState(null);
  const [roleSearch, setRoleSearch] = useState("");
  const formRef = useRef(null);

  function getDropdownYears() {
    const currentYear = new Date().getFullYear();
    const yearsBefore = 10;
    const yearsAfter = 10;
    const years = [];
    for (let i = yearsBefore; i > 0; i--) {
      years.push(String(currentYear - i));
    }
    years.push(String(currentYear));
    for (let i = 1; i <= yearsAfter; i++) {
      years.push(String(currentYear + i));
    }
    return years;
  }

  const dropdownYears = getDropdownYears();
  const assessmentPeriods = ASSESSMENT_PERIODS;
  const measurementOptions = MEASUREMENTS;
  const dealerOptions = DEALER_CONTENT_OPTIONS;

  const types = [
    { value: "dealer-user", label: "Dealer User" },
    { value: "volvo-user", label: "Volvo User" },
  ];

  const refs = {
    year: useRef(),
    role: useRef(),
    name: useRef(),
    score: useRef(),
    objective: useRef(),
    dealerContent: useRef(),
    kpi: useRef(),
    status: useRef(),
    period: useRef(),
    measurement: useRef(),
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAllSubKPIs();
        setSubKPIs(data);
      } catch (err) {}
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAllRoles();
        setApiData(data);
      } catch (err) {}
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAllUsers();
        setAllUsers(data);
      } catch (err) {}
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAllKPIs();
        // Ensure each kpi item has objectiveId for dependent filtering
        setKpiOptions(data);
      } catch (err) {}
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAllStrategicObjectives();
        setObjectives(data);
      } catch (err) {}
    };
    fetchData();
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // ⭐ DEPENDENT DROPDOWN: Filter KPIs based on selected Strategic Objective
  // ═══════════════════════════════════════════════════════════════
  const filteredKpiOptions = useMemo(() => {
    if (!form.strategicObjective) return [];
    // ⭐ API returns no objectiveId — match by strategicObjective name string
    const selectedObj = objectives.find((obj) => obj.id === form.strategicObjective);
    if (!selectedObj) return [];
    return kpiOptions.filter((opt) => opt.objectiveName === selectedObj.name);
  }, [form.strategicObjective, kpiOptions, objectives]);

  const filteredRoles = useMemo(() => {
    return getFilteredRoles(apiData, form.userType);
  }, [form.userType, apiData]);

  const filteredUsers = useMemo(() => {
    return getFilteredUsers(allUsers, apiData, form.userRole);
  }, [form.userRole, allUsers, apiData]);

  const fillForm = (data) => {
    const docStatusValue = data.docStaus ?? data.docStatus ?? 0;
    const isDealerContentYes = docStatusValue === 1 || data.isActive === true;

    setForm({
      id: data.id || "",
      year: data.createdYear || new Date().getFullYear(),
      kpiNumber: data.kpiNumber || "",
      maxScore: data.maxScore || "",
      minScore: data.minScore || "",
      subKpi: data.subKpiName || "",
      strategicObjective: data.objectiveId || "",
      userType: data.userType || "",
      userRole: Array.isArray(data.userRoles) ? data.userRoles.map((r) => r.id) : [],
      userName: Array.isArray(data.users) ? data.users.map((u) => u.id) : [],
      dealerContent: isDealerContentYes ? "Yes" : "No",
      annualScore: data.annualScore || "",
      kpi: data.kpiId || "",
      assessmentPeriod: data.assessmentPeriod || "",
      status: data.status || "",
      measurement: data.measurement || "",
      scoringCriteria: data.scoringCriteria || "",
      supportingDocument: null,
      existingFileUrl: data.doc || null,
      annualScoringCriteria: data.annualScoringCriteria || "",
      criteriaDefinition: data.criteriaDefinition || "",
      dataSource: data.dataSource || "",
    });
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      handleChange("supportingDocument", file);
      handleChange("existingFileUrl", null);
      setErrors((prev) => ({ ...prev, supportingDocument: "" }));
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const resetForm = () => {
    setForm({
      id: "",
      year: new Date().getFullYear(),
      kpiNumber: "",
      maxScore: "",
      minScore: "",
      subKpi: "",
      strategicObjective: "",
      userType: "",
      userRole: [],
      userName: [],
      dealerContent: "",
      annualScore: "",
      kpi: "",
      assessmentPeriod: "",
      status: "",
      measurement: "",
      scoringCriteria: "",
      supportingDocument: null,
      existingFileUrl: null,
      annualScoringCriteria: "",
      criteriaDefinition: "",
      dataSource: "",
    });
    setErrors({});
    setSubmitError("");
  };

  useEffect(() => {
    if (locationState.isEditing && editData) {
      setOriginalEditData(editData);
      fillForm(editData);
      setIsCloning(false);
      setIsEditing(true);
    }
  }, []);

  useEffect(() => {
    const closeDropdown = (e) => {
      Object.keys(refs).forEach((key) => {
        if (refs[key]?.current && !refs[key].current.contains(e.target)) {
          setDropdowns((prev) => ({ ...prev, [key]: false }));
        }
      });
    };
    document.addEventListener("mousedown", closeDropdown);
    return () => document.removeEventListener("mousedown", closeDropdown);
  }, []);

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }));
    }
  };

  const handleSubmit = async () => {
    const newErrors = {};
    const requiredFields = {
      year: "year",
      kpi: "KPI",
      subKpi: "Sub KPI",
      strategicObjective: "Strategic Objective",
      kpiNumber: "KPI Number",
      maxScore: "Max Score",
      minScore: "Min Score",
      scoringCriteria: "Scoring Criteria",
      annualScore: "Annual Score",
      annualScoringCriteria: "Annual Scoring Criteria",
      assessmentPeriod: "Assessment Period",
      measurement: "Measurement",
      userRole: "User Type & Roles",
      dealerContent: "Dealer Needs to Provide Content",
    };

    for (const [key] of Object.entries(requiredFields)) {
      const value = form[key];
      if (
        value === undefined ||
        value === null ||
        value === "" ||
        (Array.isArray(value) && value.length === 0)
      ) {
        newErrors[key] = "Please fill out this field";
      }
    }

    if (
      form.dealerContent === "Yes" &&
      !form.supportingDocument &&
      !form.existingFileUrl
    ) {
      newErrors.supportingDocument =
        "Please upload a supporting document when Yes is selected";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    setErrors({});

    const duplicate = checkSubKPIExists(
      subKPIs,
      form.subKpi,
      form.kpi,
      form.strategicObjective,
      form.year,
      form.id || null
    );

    if (duplicate) {
      setSubmitError(
        "A Sub KPI with the same name, KPI, Strategic Objective, and Year already exists."
      );
      return;
    }

    setLoading(true);
    setSubmitError("");

    try {
      const formData = buildSubKPIFormData(form, isEditing);
      if (isEditing) {
        await updateSubKPI(formData);
      } else {
        await addSubKPI(formData);
      }
      navigate("/masters/subkpimaster");
    } catch (err) {
      setSubmitError(err.message || "Failed to save Sub KPI");
    } finally {
      setLoading(false);
    }
  };

  const handleClone = async () => {
    try {
      const allData = await getAllSubKPIs();
      if (!allData || allData.length === 0) return;

      const latestData = allData.reduce((prev, curr) =>
        curr.id > prev.id ? curr : prev
      );

      fillForm(latestData);
      setForm((prev) => ({ ...prev, id: "" }));
      setIsEditing(false);
      setIsCloning(true);
    } catch (error) {}
  };

  const handleCancel = () => {
    if (originalEditData && isCloning) {
      fillForm(originalEditData);
      setIsEditing(true);
      setIsCloning(false);
    } else if (originalEditData && isEditing) {
      fillForm(originalEditData);
      setIsEditing(true);
      setIsCloning(false);
    } else {
      resetForm();
      setIsEditing(false);
      setIsCloning(false);
    }
    setSubmitError("");
    setErrors({});
  };

  useKeyboardNavigation({
    containerRef: formRef,
    onSubmit: () => {
      handleSubmit();
    },
    onCancel: () => {
      resetForm();
    },
  });

  return (
    <div ref={formRef} className="w-full">
      <div className="flex items-center justify-center mb-6">
        <button
          onClick={() => navigate("/masters/subkpimaster")}
          className="cursor-pointer p-2 bg-darkblue1 text-white flex items-center justify-center relative z-10"
        >
          <ArrowLeft size={18} className="pointer-events-auto" />
        </button>

        <h2 className="text-lg font-semibold text-center w-full -ml-6 text-darkblue1">
          {isEditing ? "Edit Sub KPI" : isCloning ? "Cloned Sub KPI" : "Add New Sub KPI"}
        </h2>

        <button
          onClick={handleClone}
          className="flex items-center justify-center gap-2 text-xs font-medium px-6 py-1.5 bg-lightBlue text-mildBlue hover:bg-white hover:border hover:border-mildBlue transition whitespace-nowrap"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <rect x="0.5" y="0.5" width="10.0003" height="13.6086" stroke="#204D80" />
            <path d="M3 5L6 5" stroke="#204D80" strokeLinecap="round" />
            <path d="M3 7L7 7" stroke="#204D80" strokeLinecap="round" />
            <path d="M3 9H8" stroke="#204D80" strokeLinecap="round" />
            <rect x="13.5" y="9.89136" width="10.0003" height="13.6086" stroke="#204D80" />
            <path d="M16 14.3914L19 14.3914" stroke="#204D80" strokeLinecap="round" />
            <path d="M16 16.3914L20 16.3914" stroke="#204D80" strokeLinecap="round" />
            <path d="M16 18.3914H21" stroke="#204D80" strokeLinecap="round" />
            <path d="M5.5 15.6523V19.8262H10.5002" stroke="#204D80" strokeLinecap="round" />
            <path d="M11.7558 19.4864C11.8298 19.5242 11.8915 19.5798 11.9345 19.6472C11.9775 19.7147 12.0001 19.7917 12.0001 19.8701C12.0001 19.9486 11.9775 20.0255 11.9345 20.093C11.8915 20.1605 11.8298 20.2161 11.7558 20.2539L8.6125 21.8591C8.5407 21.8957 8.45987 21.9143 8.37796 21.9131C8.29606 21.9118 8.21591 21.8908 8.14542 21.8521C8.07493 21.8133 8.01652 21.7582 7.97595 21.6921C7.93538 21.626 7.91405 21.5513 7.91406 21.4752V18.2648C7.91408 18.1887 7.93544 18.114 7.97605 18.0479C8.01666 17.9818 8.07511 17.9267 8.14564 17.888C8.21617 17.8492 8.29635 17.8283 8.37827 17.8271C8.46019 17.8259 8.54103 17.8446 8.61281 17.8812L11.7558 19.4864Z" fill="#204D80" />
            <path d="M12.2441 3.74641C12.1701 3.78419 12.1084 3.83972 12.0654 3.90722C12.0224 3.97472 11.9998 4.0517 11.9998 4.13011C11.9998 4.20853 12.0224 4.28551 12.0654 4.35301C12.1084 4.42051 12.1701 4.47604 12.2441 4.51382L15.3875 6.11897C15.4593 6.15559 15.5401 6.1742 15.622 6.17298C15.7039 6.17175 15.7841 6.15073 15.8546 6.11199C15.9251 6.07325 15.9835 6.01812 16.024 5.95204C16.0646 5.88595 16.0859 5.81119 16.0859 5.73513V2.52481C16.0859 2.44873 16.0646 2.37396 16.024 2.30787C15.9833 2.24179 15.9249 2.18668 15.8544 2.14796C15.7838 2.10924 15.7036 2.08826 15.6217 2.08709C15.5398 2.08591 15.459 2.10458 15.3872 2.14125L12.2441 3.74641Z" fill="#204D80" />
            <path d="M13.9863 4.17401H18.9865V8.3479" stroke="#204D80" strokeLinecap="round" />
          </svg>
          Clone Latest Sub KPI
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6 mb-6">
        {/* ── CARD 1: KPI Details ── */}
        <div className="bg-white shadow p-6 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 32 32" fill="none">
              <path fillRule="evenodd" clipRule="evenodd" d="M29.3327 5.33331V26.6666H2.66602V5.33331H29.3327ZM26.666 8H5.3327V24H26.666V8ZM23.9993 18.6666V20.6666H17.3327V18.6666H23.9993ZM23.9993 14.6666V16.6666H17.3327V14.6666H23.9993ZM14.666 10.6666V16H7.99933V10.6666H14.666ZM23.9993 10.6666V12.6666H17.3327V10.6666H23.9993Z" fill="#1B365D" />
            </svg>
            <h3 className="font-semibold text-sm">KPI Details</h3>
          </div>

          {/* Year */}
          <div className="mb-4">
            <StyledSelectField
              label="Created Year"
              required={true}
              placeholder="Created Year"
              value={String(form.year)}
              setValue={(val) => handleChange("year", val)}
              options={dropdownYears}
              dropdownOpen={dropdowns.year}
              setDropdownOpen={(val) => setDropdowns((prev) => ({ ...prev, year: val }))}
              dropdownRef={refs.year}
              error={errors.year}
            />
          </div>

          {/* ⭐ Strategic Objective — resets KPI on change */}
          <div className="mb-4">
            <StyledSelectField
              required={true}
              label="Strategic Objective"
              placeholder="Strategic Objective"
              value={objectives.find((obj) => obj.id === form.strategicObjective)?.name || ""}
              setValue={(val) => {
                const selected = objectives.find((obj) => obj.name === val);
                handleChange("strategicObjective", selected?.id || "");
                // ⭐ Reset KPI whenever Strategic Objective changes
                handleChange("kpi", "");
              }}
              options={objectives.map((obj) => obj.name)}
              dropdownOpen={dropdowns.objective}
              setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, objective: val }))}
              dropdownRef={refs.objective}
              error={errors.strategicObjective}
            />
          </div>

          {/* KPI Number */}
          <InputField
            label="KPI Number"
            required={true}
            value={form.kpiNumber}
            onChange={(e) => handleChange("kpiNumber", e.target.value)}
            placeholder="Enter Number"
            error={errors.kpiNumber}
          />

          {/* ⭐ KPI — dependent on Strategic Objective */}
          <div className="mb-4">
            {/* Hint shown when no objective is selected */}
            {!form.strategicObjective && (
              <p className="text-xs text-amber-600 mb-1 flex items-center gap-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
                Select a Strategic Objective first
              </p>
            )}

            {/* Hint shown when objective selected but no KPIs available */}
            {form.strategicObjective && filteredKpiOptions.length === 0 && (
              <p className="text-xs text-gray-500 mb-1 flex items-center gap-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
                No KPIs found for selected objective
              </p>
            )}

            <StyledSelectField
              label="KPI"
              required={true}
              placeholder={
                !form.strategicObjective
                  ? "Select Strategic Objective first"
                  : filteredKpiOptions.length === 0
                  ? "No KPIs available"
                  : "Select KPI"
              }
              value={kpiOptions.find((opt) => opt.value === form.kpi)?.label || ""}
              setValue={(val) => {
                const selected = filteredKpiOptions.find((opt) => opt.label === val);
                handleChange("kpi", selected?.value || "");
              }}
              // ⭐ Only show KPIs that belong to the selected Strategic Objective
              options={filteredKpiOptions.map((opt) => opt.label)}
              dropdownOpen={dropdowns.kpi}
              setDropdownOpen={(val) => {
                // Only open if an objective is selected
                if (!form.strategicObjective) return;
                setDropdowns((p) => ({ ...p, kpi: val }));
              }}
              dropdownRef={refs.kpi}
              error={errors.kpi}
            />
          </div>

          {/* Sub KPI */}
          <div className="mb-2">
            <label className="block text-xs font-medium text-black/70 mb-1">
              Sub KPI <span className="text-red1">*</span>
            </label>
            <textarea
              rows={3}
              value={form.subKpi}
              onChange={(e) => handleChange("subKpi", e.target.value)}
              placeholder="Enter Sub KPI"
              className={
                "w-full px-4 py-1.5 text-xs resize-none focus:outline-none border " +
                (errors.subKpi ? "border-red1" : "border-black/30")
              }
            />
            {errors.subKpi && <p className="text-red1 text-xs mt-1">{errors.subKpi}</p>}
          </div>

          {/* Assessment Period */}
          <div className="mb-4">
            <StyledSelectField
              required={true}
              label="Assessment Period"
              placeholder="Assessment Period"
              value={form.assessmentPeriod}
              setValue={(val) => handleChange("assessmentPeriod", val)}
              options={assessmentPeriods}
              dropdownOpen={dropdowns.period}
              setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, period: val }))}
              dropdownRef={refs.period}
              error={errors.assessmentPeriod}
            />
          </div>
        </div>

        {/* ── CARD 2: Scoring Details ── */}
        <div className="bg-white shadow p-6 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 32 32" fill="none">
              <path d="M4 25.3333H28V28H4V25.3333ZM8 21.3333C9.46667 21.3333 10.6667 20.1333 10.6667 18.6667C10.6667 18 10.4 17.3333 10 16.9333L11.7333 13.3333H12C12.6667 13.3333 13.3333 13.0667 13.7333 12.6667L17.3333 14.5333V14.6667C17.3333 16.1333 18.5333 17.3333 20 17.3333C21.4667 17.3333 22.6667 16.1333 22.6667 14.6667C22.6667 14 22.4 13.4667 22 12.9333L23.7333 9.33333H24C25.4667 9.33333 26.6667 8.13333 26.6667 6.66667C26.6667 5.2 25.4667 4 24 4C22.5333 4 21.3333 5.2 21.3333 6.66667C21.3333 7.33333 21.6 8 22 8.4L20.2667 12H20C19.3333 12 18.6667 12.2667 18.2667 12.6667L14.6667 10.9333V10.6667C14.6667 9.2 13.4667 8 12 8C10.5333 8 9.33333 9.2 9.33333 10.6667C9.33333 11.3333 9.6 12 10 12.4L8.26667 16H8C6.53333 16 5.33333 17.2 5.33333 18.6667C5.33333 20.1333 6.53333 21.3333 8 21.3333Z" fill="#1B365D" />
            </svg>
            <h3 className="font-semibold text-sm">Scoring Details</h3>
          </div>

          <InputField
            label="Min Score"
            required={true}
            value={form.minScore}
            onChange={(e) => handleChange("minScore", e.target.value)}
            type="number"
            error={errors.minScore}
          />

          <InputField
            label="Max Score"
            required={true}
            value={form.maxScore}
            onChange={(e) => handleChange("maxScore", e.target.value)}
            type="number"
            error={errors.maxScore}
          />

          <div className="mb-2">
            <label className="block text-xs font-medium text-MediumGrey mb-1">
              Scoring Criteria <span className="text-red1">*</span>
            </label>
            <textarea
              value={form.scoringCriteria}
              onChange={(e) => handleChange("scoringCriteria", e.target.value)}
              placeholder="Enter scoring criteria"
              rows={4}
              className={
                "w-full text-xs border px-3 py-2 outline-none resize-none " +
                (errors.scoringCriteria ? "border-red1" : "border-black/30")
              }
            />
            {errors.scoringCriteria && (
              <p className="text-red1 text-xs mt-1">{errors.scoringCriteria}</p>
            )}
          </div>

          <div className="mb-4">
            <StyledSelectField
              required={true}
              label="Measurement"
              placeholder="Measurement"
              value={form.measurement}
              setValue={(val) => handleChange("measurement", val)}
              options={measurementOptions}
              dropdownOpen={dropdowns.measurement}
              setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, measurement: val }))}
              dropdownRef={refs.measurement}
              error={errors.measurement}
            />
          </div>

          <div className="mb-4">
            <StyledSelectField
              required={true}
              label="Annual Score"
              placeholder="Annual Score"
              value={form.annualScore}
              setValue={(val) => handleChange("annualScore", val)}
              options={ANNUAL_SCORE_OPTIONS}
              dropdownOpen={dropdowns.score}
              setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, score: val }))}
              dropdownRef={refs.score}
              error={errors.annualScore}
            />
          </div>

          <label className="block text-xs font-medium text-black/70 mb-2">
            Annual Scoring Criteria <span className="text-red1">*</span>
          </label>
          <textarea
            rows={3}
            value={form.annualScoringCriteria}
            onChange={(e) => handleChange("annualScoringCriteria", e.target.value)}
            className={
              "w-full text-xs border px-3 py-2 outline-none resize-none " +
              (errors.annualScoringCriteria ? "border-red1" : "border-black/30")
            }
            placeholder="Enter annual scoring criteria"
          />
          {errors.annualScoringCriteria && (
            <p className="text-red1 text-xs mt-1">{errors.annualScoringCriteria}</p>
          )}
        </div>

        {/* ── CARD 3: Evaluation ── */}
        <div className="bg-white shadow p-6 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 32 32" fill="none">
              <path d="M9.33333 22.6666H12.1333L20.1333 14.7333L17.2667 11.8666L9.33333 19.8V22.6666ZM21.0667 13.8L22.4667 12.3333C22.6 12.2 22.6667 12.0444 22.6667 11.8666C22.6667 11.6889 22.6 11.5333 22.4667 11.4L20.6 9.53331C20.4667 9.39998 20.3111 9.33331 20.1333 9.33331C19.9556 9.33331 19.8 9.39998 19.6667 9.53331L18.2 10.9333L21.0667 13.8ZM6.66667 28C5.93333 28 5.30578 27.7391 4.784 27.2173C4.26222 26.6955 4.00089 26.0675 4 25.3333V6.66665C4 5.93331 4.26133 5.30576 4.784 4.78398C5.30667 4.2622 5.93422 4.00087 6.66667 3.99998H12.2667C12.5556 3.19998 13.0391 2.55554 13.7173 2.06665C14.3956 1.57776 15.1564 1.33331 16 1.33331C16.8436 1.33331 17.6049 1.57776 18.284 2.06665C18.9631 2.55554 19.4462 3.19998 19.7333 3.99998H25.3333C26.0667 3.99998 26.6947 4.26131 27.2173 4.78398C27.74 5.30665 28.0009 5.9342 28 6.66665V25.3333C28 26.0666 27.7391 26.6946 27.2173 27.2173C26.6956 27.74 26.0676 28.0009 25.3333 28H6.66667ZM6.66667 25.3333H25.3333V6.66665H6.66667V25.3333ZM16 5.66665C16.2889 5.66665 16.528 5.57198 16.7173 5.38265C16.9067 5.19331 17.0009 4.95465 17 4.66665C16.9991 4.37865 16.9044 4.13998 16.716 3.95065C16.5276 3.76131 16.2889 3.66665 16 3.66665C15.7111 3.66665 15.4724 3.76131 15.284 3.95065C15.0956 4.13998 15.0009 4.37865 15 4.66665C14.9991 4.95465 15.0938 5.19376 15.284 5.38398C15.4742 5.5742 15.7129 5.66842 16 5.66665Z" fill="#1B365D" />
            </svg>
            <h3 className="font-semibold text-sm">Evaluation</h3>
          </div>

          {/* User Type & Roles */}
          <div className="relative w-full" ref={refs.role}>
            <label className="block text-xs font-medium text-black/70 mb-2">
              User Type & Roles <span className="text-red1">*</span>
            </label>

            <div
              onClick={() => setDropdowns((p) => ({ ...p, role: !dropdowns.role }))}
              className={
                "w-full text-xs border px-4 py-1.5 cursor-pointer flex justify-between items-center transition-all duration-200 " +
                (dropdowns.role ? "border-black/30 border-b-white" : "border-black/30 bg-white") +
                (errors.userRole && !dropdowns.role ? " border-red1" : "")
              }
              tabIndex={0}
            >
              <div className="flex flex-wrap gap-2 max-w-[85%]">
                {form.userRole.length > 0 ? (
                  form.userRole.map((roleId, i) => {
                    const roleObj = apiData.find((r) => r.id === roleId);
                    return (
                      <span key={i} className="bg-grey2 text-black text-xs px-2 py-0 flex items-center gap-1">
                        {roleObj?.userRole || roleId}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleChange("userRole", form.userRole.filter((r) => r !== roleId));
                          }}
                        >
                          <svg width="14" height="14" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="10" cy="10" r="8" fill="#BF2012" />
                            <path d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5" stroke="white" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                        </button>
                      </span>
                    );
                  })
                ) : (
                  <span className="text-gray-400">Select User Roles</span>
                )}
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"
                className={"w-3 h-3 transform transition-transform duration-200 " + (dropdowns.role ? "rotate-180" : "rotate-0")}>
                <path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121" />
              </svg>
            </div>

            {dropdowns.role && (
              <div className="absolute top-full left-0 mt-0 w-full bg-white border border-black/30 border-t-white shadow-lg z-10 max-h-40 overflow-hidden grid grid-cols-2">
                <div className="border-r border-black/20 overflow-y-auto max-h-40">
                  {types.map((type) => (
                    <div
                      key={type.value}
                      className={
                        "px-4 py-1.5 text-xs cursor-pointer hover:bg-black/10 " +
                        (form.userType === type.label ? "bg-darkblue1 text-white" : "")
                      }
                      onClick={(e) => {
                        e.stopPropagation();
                        handleChange("userType", type.label);
                        handleChange("userRole", []);
                      }}
                    >
                      {type.label}
                    </div>
                  ))}
                </div>

                <div className="overflow-y-auto overflow-x-hidden scrollbar-thin scrollbar-thumb-gray-300 max-h-40">
                  {filteredRoles.length > 5 && (
                    <div className="sticky top-0 bg-white px-3 py-1 z-10">
                      <input
                        type="text"
                        placeholder="Search roles..."
                        value={roleSearch}
                        onChange={(e) => setRoleSearch(e.target.value)}
                        className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
                        autoFocus
                      />
                    </div>
                  )}
                  {filteredRoles
                    .filter((r) => !roleSearch ? true : r.label.toLowerCase().includes(roleSearch.toLowerCase()))
                    .sort((a, b) => a.label.localeCompare(b.label))
                    .map((role) => {
                      const isSelected = form.userRole.includes(role.value);
                      return (
                        <li
                          key={role.value}
                          className={"px-4 py-1.5 text-xs cursor-pointer hover:bg-lightBlue " + (isSelected ? "bg-lightBlue font-semibold" : "")}
                          onClick={(e) => {
                            e.stopPropagation();
                            if (isSelected) {
                              handleChange("userRole", form.userRole.filter((r) => r !== role.value));
                            } else {
                              handleChange("userRole", [...form.userRole, role.value]);
                            }
                          }}
                        >
                          {role.label}
                        </li>
                      );
                    })}
                  {filteredRoles.filter((r) => !roleSearch ? true : r.label.toLowerCase().includes(roleSearch.toLowerCase())).length === 0 && (
                    <li className="px-4 py-2 text-xs text-gray-500 cursor-default">No roles found</li>
                  )}
                </div>
              </div>
            )}

            {errors.userRole && <p className="text-red1 text-xs mt-1">{errors.userRole}</p>}
          </div>

          {/* User Name */}
          <div className="relative w-full" ref={refs.name}>
            <label className="block text-xs font-medium text-black/70 mb-2">User Name</label>
            <div
              onClick={() => setDropdowns((p) => ({ ...p, name: !dropdowns.name }))}
              className={
                "w-full text-xs border px-4 py-1.5 cursor-pointer flex justify-between items-center transition-all duration-200 " +
                (dropdowns.name ? "border-black/30 border-b-white" : "border-black/30 bg-white") +
                (errors.userName && !dropdowns.name ? " border-red1" : "")
              }
              tabIndex={0}
            >
              <div className="flex flex-wrap gap-2 max-w-[85%]">
                {form.userName.length > 0 ? (
                  form.userName.map((id) => {
                    const user = allUsers.find((u) => u.id === id);
                    const fullName = user ? (user.firstName + " " + user.middleName + " " + user.lastName).trim() : id;
                    return (
                      <span key={id} className="bg-grey2 text-black text-xs px-2 py-0 flex items-center gap-1">
                        {fullName}
                        <button onClick={(e) => { e.stopPropagation(); handleChange("userName", form.userName.filter((n) => n !== id)); }}>
                          <svg width="14" height="14" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="10" cy="10" r="8" fill="#BF2012" />
                            <path d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5" stroke="white" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                        </button>
                      </span>
                    );
                  })
                ) : (
                  <span className="text-gray-400">Select User Names</span>
                )}
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"
                className={"w-3 h-3 transform transition-transform duration-200 " + (dropdowns.name ? "rotate-180" : "rotate-0")}>
                <path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121" />
              </svg>
            </div>

            {dropdowns.name && (
              <div className="absolute top-full left-0 mt-0 w-full bg-white border border-black/30 border-t-white shadow-lg z-10 max-h-40 overflow-auto">
                {filteredUsers.length > 0 ? (
                  filteredUsers.map((user) => {
                    const fullName = (user.firstName + " " + user.middleName + " " + user.lastName).trim();
                    const isSelected = form.userName.includes(user.id);
                    return (
                      <li
                        key={user.id}
                        className={"px-4 py-1.5 text-xs cursor-pointer hover:bg-lightBlue " + (isSelected ? "bg-lightBlue font-semibold" : "")}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (isSelected) {
                            handleChange("userName", form.userName.filter((n) => n !== user.id));
                          } else {
                            handleChange("userName", [...form.userName, user.id]);
                          }
                        }}
                      >
                        {fullName}
                      </li>
                    );
                  })
                ) : (
                  <li className="px-4 py-2 text-xs text-gray-500 cursor-default">No users found</li>
                )}
              </div>
            )}
          </div>
          {errors.userName && <p className="text-red1 text-xs mt-1">{errors.userName}</p>}

          {/* Dealer Content */}
          <div className="mb-4">
            <StyledSelectField
              required={true}
              label="Dealer Needs to Provide Content"
              placeholder="Dealer Needs to Provide Content"
              value={form.dealerContent}
              setValue={(val) => handleChange("dealerContent", val)}
              options={dealerOptions}
              dropdownOpen={dropdowns.dealerContent}
              setDropdownOpen={(val) => setDropdowns((p) => ({ ...p, dealerContent: val }))}
              dropdownRef={refs.dealerContent}
              error={errors.dealerContent}
            />
          </div>

          {form.dealerContent === "Yes" && (
            <FileUploadField
              form={form}
              errors={errors}
              handleChange={handleChange}
              setErrors={setErrors}
            />
          )}

          <label className="block text-xs font-medium text-gray-700 mb-2">Criteria Definition</label>
          <CriteriaDefinitionEditor
            value={form.criteriaDefinition}
            onChange={(val) => handleChange("criteriaDefinition", val)}
          />

          <label className="block text-xs font-medium text-black/70 mb-1">Data Source</label>
          <textarea
            rows={3}
            value={form.dataSource}
            onChange={(e) => handleChange("dataSource", e.target.value)}
            className="w-full px-4 py-1.5 text-xs border border-black/30 focus:outline-none resize-none"
            placeholder="Enter data source"
          />
        </div>
      </div>

      <div className="mb-4">
        {submitError && <p className="text-red1 text-xs mb-2">{submitError}</p>}
      </div>

      <div className="flex justify-end gap-2">
        {isCloning && (
          <button
            type="button"
            onClick={handleCancel}
            className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium hover:bg-mildBlue1"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 18 20" fill="none">
              <path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" />
              <path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Cancel
          </button>
        )}

        <button
          onClick={handleSubmit}
          disabled={loading}
          className={"bg-darkblue1 text-white text-xs font-medium px-8 py-2 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 " + (loading ? "opacity-50 cursor-not-allowed" : "")}
        >
          {loading ? "Saving..." : "Save"}
        </button>
      </div>

      <Clone
        isOpen={showCloneModal}
        message="You are about to clone this Sub KPI. Click Yes to add it as a new record."
        onCancel={() => setShowCloneModal(false)}
        onConfirm={() => {
          setIsCloning(true);
          setShowCloneModal(false);
        }}
      />
    </div>
  );
};

export default SubkpiAdd;

// ─────────────────────────────────────────────
// File Upload Field
// ─────────────────────────────────────────────
const FileUploadField = ({ form, errors, handleChange, setErrors }) => {
  const onFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      handleChange("supportingDocument", file);
      handleChange("existingFileUrl", null);
      setErrors((prev) => ({ ...prev, supportingDocument: "" }));
    }
  };

  const handleDragOver = (e) => e.preventDefault();

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      handleChange("supportingDocument", file);
      handleChange("existingFileUrl", null);
      setErrors((prev) => ({ ...prev, supportingDocument: "" }));
    }
  };

  const getDisplayName = () => {
    if (form.supportingDocument?.name) return form.supportingDocument.name;
    if (form.existingFileUrl) {
      const parts = form.existingFileUrl.split("/");
      return "Existing: " + (parts[parts.length - 1] || "file uploaded");
    }
    return "Choose file or drag & drop";
  };

  const hasFile = form.supportingDocument || form.existingFileUrl;
  const showExistingLink = form.existingFileUrl && !form.supportingDocument;

  return (
    <div>
      <label className="block text-xs font-medium text-black/70 mb-2">
        Supporting Document (Template) <span className="text-red1">*</span>
      </label>
      <div className="relative w-full" onDragOver={handleDragOver} onDrop={handleDrop}>
        <input id="supportingDocInput" type="file" className="hidden" onChange={onFileChange} />
        <label
          htmlFor="supportingDocInput"
          className={"w-full flex items-center justify-between border px-4 py-1.5 text-xs cursor-pointer " + (errors.supportingDocument ? "border-red1" : "border-black/30")}
        >
          <span className={hasFile ? "text-gray-700" : "text-gray-500"}>{getDisplayName()}</span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
            <g clipPath="url(#clip0_5669_3782)">
              <path fillRule="evenodd" clipRule="evenodd" d="M9.73176 2.40514C7.75032 2.87587 5.9629 3.94776 4.6144 5.47395C3.26591 7.00013 2.42231 8.90596 2.19919 10.9303H6.80376C7.11748 7.896 8.12205 4.98171 9.73176 2.40514ZM14.2678 2.40514C15.8834 4.98528 16.8852 7.90191 17.1958 10.9303H21.8003C21.5772 8.90596 20.7336 7.00013 19.3851 5.47395C18.0366 3.94776 16.2492 2.87587 14.2678 2.40514ZM15.0392 10.9303C14.7023 8.03061 13.6587 5.25801 11.9998 2.856C10.3409 5.25801 9.29717 8.03061 8.96033 10.9303H15.0392ZM8.96033 13.0731H15.0392C14.7023 15.9728 13.6587 18.7454 11.9998 21.1474C10.3409 18.7454 9.29717 15.9728 8.96033 13.0731ZM6.80376 13.0731H2.19919C2.42231 15.0975 3.26591 17.0033 4.6144 18.5295C5.9629 20.0557 7.75032 21.1276 9.73176 21.5983C8.11608 19.0182 7.11435 16.1015 6.80376 13.0731ZM14.2678 21.5983C15.8834 19.0182 16.8852 16.1015 17.1958 13.0731H21.8003C21.5772 15.0975 20.7336 17.0033 19.3851 18.5295C18.0366 20.0557 16.2492 21.1276 14.2678 21.5983ZM11.9998 24.0034C13.5758 24.0034 15.1365 23.693 16.5926 23.0899C18.0487 22.4867 19.3718 21.6027 20.4863 20.4882C21.6007 19.3737 22.4848 18.0507 23.0879 16.5946C23.691 15.1385 24.0015 13.5778 24.0015 12.0017C24.0015 10.4256 23.691 8.86497 23.0879 7.40886C22.4848 5.95274 21.6007 4.62968 20.4863 3.51522C19.3718 2.40076 18.0487 1.51672 16.5926 0.913576C15.1365 0.310433 13.5758 -2.34855e-08 11.9998 0C8.81671 4.74312e-08 5.76403 1.26446 3.51327 3.51522C1.26251 5.76598 -0.00195312 8.81866 -0.00195312 12.0017C-0.00195313 15.1848 1.26251 18.2375 3.51327 20.4882C5.76403 22.739 8.81671 24.0034 11.9998 24.0034Z" fill="black" />
            </g>
            <defs><clipPath id="clip0_5669_3782"><rect width="24" height="24" fill="white" /></clipPath></defs>
          </svg>
        </label>
      </div>
      {showExistingLink && <ExistingFileLinkComponent url={form.existingFileUrl} />}
      {errors.supportingDocument && <p className="text-red1 text-xs mt-1">{errors.supportingDocument}</p>}
    </div>
  );
};

const ExistingFileLinkComponent = ({ url }) => (
  <div className="mt-1 flex items-center gap-2">
    <a href={url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 text-xs underline">
      View existing file
    </a>
    <span className="text-gray-400 text-xs">|</span>
    <span className="text-gray-500 text-xs italic">Upload new file to replace</span>
  </div>
);

const InputField = ({ label, value, onChange, placeholder = "", type = "text", error = "", required = false }) => (
  <div className="mb-2">
    <label className="block text-xs font-medium text-black/70 mb-1">
      {label}
      {required && <span className="text-red1 ml-1">*</span>}
    </label>
    <input
      type={type}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className={"w-full px-4 py-1.5 text-xs focus:outline-none border " + (error ? "border-red1" : "border-black/30")}
    />
    {error && <p className="text-red1 text-xs mt-1">{error}</p>}
  </div>
);

const CriteriaDefinitionEditor = ({ value, onChange }) => {
  const [fontSize, setFontSize] = useState("12");
  const [fontFamily, setFontFamily] = useState("Segoe UI");
  const [activeFormats, setActiveFormats] = useState({
    bold: false, italic: false, underline: false, unorderedList: false, orderedList: false,
  });
  const editorRef = useRef(null);
  const [dropdowns, setDropdowns] = useState({ fontFamily: false, fontSize: false });
  const dropdownRefs = { fontFamily: useRef(null), fontSize: useRef(null) };

  const fontFamilyOptions = [
    { value: "Segoe UI", label: "Segoe UI" },
    { value: "Arial", label: "Arial" },
    { value: "Roboto", label: "Roboto" },
    { value: "Times New Roman", label: "Times New Roman" },
  ];
  const fontSizeOptions = ["12", "14", "16", "18", "20", "24", "28", "32"];

  const executeCommand = (command, val = null) => {
    document.execCommand(command, false, val);
    editorRef.current?.focus();
  };

  const handleContentChange = () => {
    if (editorRef.current) onChange(editorRef.current.innerHTML);
  };

  const updateActiveFormats = () => {
    if (!editorRef.current) return;
    setActiveFormats({
      bold: document.queryCommandState("bold"),
      italic: document.queryCommandState("italic"),
      underline: document.queryCommandState("underline"),
      unorderedList: document.queryCommandState("insertUnorderedList"),
      orderedList: document.queryCommandState("insertOrderedList"),
    });
  };

  useEffect(() => {
    if (editorRef.current && value !== editorRef.current.innerHTML) {
      editorRef.current.innerHTML = value || "";
    }
  }, [value]);

  return (
    <div className="border border-gray-300 overflow-hidden bg-white">
      <div className="border-b border-gray-200 p-3 bg-gray-50">
        <div className="flex flex-wrap gap-4 mb-2">
          <div className="w-40">
            <StyledSelectField
              value={fontFamily}
              setValue={setFontFamily}
              options={fontFamilyOptions}
              dropdownOpen={dropdowns.fontFamily}
              setDropdownOpen={(val) => setDropdowns((prev) => ({ ...prev, fontFamily: val }))}
              dropdownRef={dropdownRefs.fontFamily}
            />
          </div>
          <div className="w-20">
            <StyledSelectField
              value={fontSize}
              setValue={setFontSize}
              options={fontSizeOptions.map((size) => ({ label: size, value: size }))}
              dropdownOpen={dropdowns.fontSize}
              setDropdownOpen={(val) => setDropdowns((prev) => ({ ...prev, fontSize: val }))}
              dropdownRef={dropdownRefs.fontSize}
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-0 items-center">
          <ToolbarButton icon={<Bold size={16} />} label="Bold" isActive={activeFormats.bold} onClick={() => { executeCommand("bold"); handleContentChange(); updateActiveFormats(); }} />
          <ToolbarButton icon={<Italic size={16} />} label="Italic" isActive={activeFormats.italic} onClick={() => { executeCommand("italic"); handleContentChange(); updateActiveFormats(); }} />
          <ToolbarButton icon={<Underline size={16} />} label="Underline" isActive={activeFormats.underline} onClick={() => { executeCommand("underline"); handleContentChange(); updateActiveFormats(); }} />
          <ToolbarButton icon={<List size={16} />} label="Bullet List" isActive={activeFormats.unorderedList} onClick={() => { if (editorRef.current?.innerHTML.trim() === "") { editorRef.current.innerHTML = "<ul><li><br></li></ul>"; } else { executeCommand("insertUnorderedList"); } handleContentChange(); updateActiveFormats(); }} />
          <ToolbarButton icon={<span className="text-sm font-bold">1.</span>} label="Numbered List" isActive={activeFormats.orderedList} onClick={() => { if (editorRef.current?.innerHTML.trim() === "") { editorRef.current.innerHTML = "<ol><li><br></li></ol>"; } else { executeCommand("insertOrderedList"); } handleContentChange(); updateActiveFormats(); }} />
          <ToolbarButton icon={<AlignLeft size={16} />} label="Align Left" onClick={() => { executeCommand("justifyLeft"); handleContentChange(); }} />
          <ToolbarButton icon={<AlignCenter size={16} />} label="Align Center" onClick={() => { executeCommand("justifyCenter"); handleContentChange(); }} />
          <ToolbarButton icon={<AlignRight size={16} />} label="Align Right" onClick={() => { executeCommand("justifyRight"); handleContentChange(); }} />
          <ToolbarButton icon={<Copy size={16} />} label="Copy" onClick={() => executeCommand("copy")} />
          <ToolbarButton icon={<RotateCcw size={16} />} label="Undo" onClick={() => { executeCommand("undo"); handleContentChange(); updateActiveFormats(); }} />
        </div>
      </div>
      <div
        ref={editorRef}
        contentEditable
        className="min-h-[150px] p-4 focus:outline-none"
        style={{ fontSize: (fontSize || 12) + "px", fontFamily }}
        onInput={handleContentChange}
        onBlur={handleContentChange}
        onKeyUp={updateActiveFormats}
        onMouseUp={updateActiveFormats}
        onFocus={updateActiveFormats}
        suppressContentEditableWarning={true}
      />
    </div>
  );
};

const ToolbarButton = ({ icon, label, isActive = false, onClick }) => (
  <div className="relative group">
    <button
      type="button"
      className={"p-1.5 focus:outline-none hover:bg-gray-200 " + (isActive ? "border border-black" : "")}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
    >
      {icon}
    </button>
    <span className="absolute top-full left-1/2 -translate-x-1/2 mt-1 opacity-0 group-hover:opacity-100 bg-black text-white text-xs px-2 py-1 z-50 whitespace-nowrap">
      {label}
    </span>
  </div>
);