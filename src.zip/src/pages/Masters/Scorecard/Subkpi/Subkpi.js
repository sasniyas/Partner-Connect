import React, { useState, useEffect } from "react";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import SubkpiMasterScorecard from "./SubKpiMasterScorecard";

function Subkpi() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex-col ">
      {/* Header and SubNavbar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      {/* Content Wrapper */}
      <div className={`transition-all duration-300  ${menuOpen ? "ml-60" : ""}`}>
        {/* Main Component */}
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:p-2">
          <SubkpiMasterScorecard />
        </div>
      </div>
    </div>
  );
}

export default Subkpi;