"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

// ⭐ Import service functions
import {
  getAllSubKPIs,
  getAllStrategicObjectives,
  getAllRoles,
  getAllUsers,
  bulkAddSubKPIs,
  checkDuplicatesInUpload,
  getYearsArray,
  ASSESSMENT_PERIODS,
  MEASUREMENTS,
  ANNUAL_SCORE_OPTIONS,
  DEALER_CONTENT_OPTIONS,
} from "../../../../services/Masters/SubKpi/subKpi.service";

// ⭐ Import KPI service
import { getAllKPIs } from "../../../../services/Masters/SubKpi/subKpi.service";

function BulkUploadSubKPIMaster() {
  const navigate = useNavigate();

  // ═══════════════════════════════════════════════════════════════
  // 📊 STATE MANAGEMENT
  // ═══════════════════════════════════════════════════════════════
  const [rows, setRows] = useState([]);
  const [fileName, setFileName] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [duplicateInfo, setDuplicateInfo] = useState(null);
  const [isDataLoading, setIsDataLoading] = useState(true);
  const [isDragActive, setIsDragActive] = useState(false);

  // API Data for dropdowns and ID mapping
  const [strategicObjectives, setStrategicObjectives] = useState([]);
  const [kpis, setKpis] = useState([]);
  const [rolesData, setRolesData] = useState([]);
  const [usersData, setUsersData] = useState([]);
  const [existingSubKpis, setExistingSubKpis] = useState([]);

  // Dropdown states
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0, width: 0 });
  const [dropdownSearch, setDropdownSearch] = useState("");

  // Refs
  const dropdownButtonRefs = useRef({});
  const dropdownMenuRef = useRef(null);
  const tableContainerRef = useRef(null);

  // Static dropdown options
  const userTypes = ["Dealer User", "Volvo User"];
  const periods = ASSESSMENT_PERIODS;
  const measurements = MEASUREMENTS;
  const dealerContentOptions = DEALER_CONTENT_OPTIONS;
  const annualScoreOptions = ANNUAL_SCORE_OPTIONS;
  const years = getYearsArray();

  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH ALL DROPDOWN DATA - Using Service
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const fetchAllData = async () => {
      setIsDataLoading(true);

      try {
        const objectives = await getAllStrategicObjectives();
        setStrategicObjectives(objectives);
      } catch (err) {
        console.error("Failed to fetch objectives:", err);
      }

      try {
        const kpiList = await getAllKPIs();
        // Transform to have name property
        const transformedKpis = kpiList.map((k) => ({
          id: k.value,
          name: k.label,
        }));
        setKpis(transformedKpis);
      } catch (err) {
        console.error("Failed to fetch KPIs:", err);
      }

      try {
        const roles = await getAllRoles();
        setRolesData(roles);
      } catch (err) {
        console.error("Failed to fetch roles:", err);
      }

      try {
        const users = await getAllUsers();
        setUsersData(users);
      } catch (err) {
        console.error("Failed to fetch users:", err);
      }

      try {
        const subKpis = await getAllSubKPIs();
        setExistingSubKpis(subKpis);
      } catch (err) {
        console.error("Failed to fetch existing sub KPIs:", err);
      }

      setIsDataLoading(false);
    };

    fetchAllData();
  }, [navigate]);

  // ═══════════════════════════════════════════════════════════════
  // 🔧 HELPER FUNCTIONS
  // ═══════════════════════════════════════════════════════════════
  const getObjectiveIdByName = (name) => {
    if (!name) return null;
    const obj = strategicObjectives.find(
      (o) => o.name.toLowerCase().trim() === name.toLowerCase().trim()
    );
    return obj?.id || null;
  };

  const getKpiIdByName = (name) => {
    if (!name) return null;
    const kpi = kpis.find(
      (k) => k.name.toLowerCase().trim() === name.toLowerCase().trim()
    );
    return kpi?.id || null;
  };

  const getRoleIdByName = (roleName, userType) => {
    if (!roleName || !userType) return null;
    const role = rolesData.find(
      (r) =>
        r.userRole?.toLowerCase().trim() === roleName.toLowerCase().trim() &&
        r.userType?.toLowerCase().trim() === userType.toLowerCase().trim() &&
        r.isActive === 1
    );
    return role?.id || null;
  };

  const getUserIdByName = (userName) => {
    if (!userName) return null;
    const normalizedInput = userName.replace(/\s+/g, " ").trim().toLowerCase();
    const user = usersData.find((u) => {
      const fullName = `${u.firstName || ""} ${u.middleName || ""} ${u.lastName || ""}`
        .replace(/\s+/g, " ")
        .trim()
        .toLowerCase();
      return fullName === normalizedInput && u.status === "ACTIVE";
    });
    return user?.id || null;
  };

  const groupedRoles = {
    "Dealer User": rolesData
      .filter((r) => r.userType === "Dealer User" && r.isActive === 1)
      .map((r) => r.userRole),
    "Volvo User": rolesData
      .filter((r) => r.userType === "Volvo User" && r.isActive === 1)
      .map((r) => r.userRole),
  };

  const groupedUsers = {};
  rolesData.forEach((role) => {
    groupedUsers[role.userRole] = usersData
      .filter((u) => u.status === "ACTIVE" && u.persona === role.userRole)
      .map((u) => ({
        id: u.id,
        name: `${u.firstName || ""} ${u.middleName || ""} ${u.lastName || ""}`
          .replace(/\s+/g, " ")
          .trim(),
      }));
  });

  // ═══════════════════════════════════════════════════════════════
  // 📥 DROPDOWN HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const closeDropdown = useCallback(() => {
    setActiveDropdown(null);
    setDropdownSearch("");
  }, []);

  const handleOpenDropdown = (rowIndex, column) => {
    if (activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column) {
      closeDropdown();
      return;
    }

    const row = rows[rowIndex];

    // Cascading checks
    if (column === "userRoleName" && !row.userType) {
      toast.warning("Please select User Type first");
      return;
    }
    if (column === "userName" && !row.userRoleName) {
      toast.warning("Please select User Role first");
      return;
    }

    const refKey = `${rowIndex}-${column}`;
    const buttonEl = dropdownButtonRefs.current[refKey];
    if (buttonEl) {
      const rect = buttonEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const dropdownHeight = 220;

      const spaceBelow = viewportHeight - rect.bottom;
      const openUpward = spaceBelow < dropdownHeight && rect.top > dropdownHeight;

      setDropdownPosition({
        top: openUpward ? rect.top - dropdownHeight : rect.bottom + 2,
        left: rect.left,
        width: Math.max(rect.width, 160),
      });
    }
    setActiveDropdown({ rowIndex, column });
    setDropdownSearch("");
  };

  const handleSelectOption = (rowIdx, column, value) => {
    handleCellChange(rowIdx, column, value);
    closeDropdown();
  };

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) return;
      const clickedOnButton = Object.values(dropdownButtonRefs.current).some(
        (ref) => ref?.contains(e.target)
      );
      if (!clickedOnButton) closeDropdown();
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [closeDropdown]);

  // Close on scroll
  useEffect(() => {
    const handleTableScroll = () => {
      if (activeDropdown !== null) closeDropdown();
    };

    const tableContainer = tableContainerRef.current;
    if (tableContainer) {
      tableContainer.addEventListener("scroll", handleTableScroll);
    }

    const handleWindowScroll = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) return;
      if (activeDropdown !== null) closeDropdown();
    };

    window.addEventListener("scroll", handleWindowScroll, true);

    return () => {
      if (tableContainer) {
        tableContainer.removeEventListener("scroll", handleTableScroll);
      }
      window.removeEventListener("scroll", handleWindowScroll, true);
    };
  }, [activeDropdown, closeDropdown]);

  // ═══════════════════════════════════════════════════════════════
  // 📊 GET DROPDOWN OPTIONS
  // ═══════════════════════════════════════════════════════════════
  const getDropdownOptions = () => {
    if (!activeDropdown) return [];

    const { rowIndex, column } = activeDropdown;
    const row = rows[rowIndex];
    let options = [];

    switch (column) {
      case "createdYear":
        options = years.map((y) => ({ id: y, label: y }));
        break;
      case "objectiveName":
        options = strategicObjectives.map((o) => ({ id: o.name, label: o.name }));
        break;
      case "kpiName":
        options = kpis.map((k) => ({ id: k.name, label: k.name }));
        break;
      case "assessmentPeriod":
        options = periods.map((p) => ({ id: p, label: p }));
        break;
      case "measurement":
        options = measurements.map((m) => ({ id: m, label: m }));
        break;
      case "annualScore":
        options = annualScoreOptions.map((a) => ({ id: a, label: a }));
        break;
      case "userType":
        options = userTypes.map((ut) => ({ id: ut, label: ut }));
        break;
      case "userRoleName":
        const roleOptions = groupedRoles[row?.userType] || [];
        options = roleOptions.map((r) => ({ id: r, label: r }));
        break;
      case "userName":
        const userOptions = groupedUsers[row?.userRoleName] || [];
        options = userOptions.map((u) => ({ id: u.name, label: u.name }));
        break;
      case "dealerContent":
        options = dealerContentOptions.map((d) => ({ id: d, label: d }));
        break;
      default:
        options = [];
    }

    if (dropdownSearch) {
      options = options.filter((opt) =>
        opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
      );
    }

    return options;
  };

  const getDisplayValue = (row, column) => {
    switch (column) {
      case "createdYear":
        return row.createdYear || "";
      case "objectiveName":
        return row.objectiveName || "";
      case "kpiName":
        return row.kpiName || "";
      case "assessmentPeriod":
        return row.assessmentPeriod || "";
      case "measurement":
        return row.measurement || "";
      case "annualScore":
        return row.annualScore || "";
      case "userType":
        return row.userType || "";
      case "userRoleName":
        return row.userRoleName || "";
      case "userName":
        return row.userName || "";
      case "dealerContent":
        return row.dealerContent || "";
      default:
        return "";
    }
  };

  const isValueSelected = (row, column, optionId) => {
    return getDisplayValue(row, column) === optionId;
  };

  const getPlaceholder = (column, row) => {
    switch (column) {
      case "userRoleName":
        return row && !row.userType ? "Select User Type first" : "Select";
      case "userName":
        return row && !row.userRoleName ? "Select Role first" : "Select";
      default:
        return "Select";
    }
  };

  const getSearchPlaceholder = (column) => {
    const placeholders = {
      createdYear: "Search year...",
      objectiveName: "Search objective...",
      kpiName: "Search KPI...",
      assessmentPeriod: "Search period...",
      measurement: "Search...",
      annualScore: "Search...",
      userType: "Search...",
      userRoleName: "Search role...",
      userName: "Search user...",
      dealerContent: "Search...",
    };
    return placeholders[column] || "Search...";
  };

  const isFieldInvalid = (row, column) => {
    switch (column) {
      case "createdYear":
        return !years.includes(row.createdYear);
      case "objectiveName":
        return !row.objectiveId;
      case "kpiName":
        return !row.kpiId;
      default:
        return false;
    }
  };

  const isDropdownDisabled = (row, column) => {
    if (column === "userRoleName") return !row.userType;
    if (column === "userName") return !row.userRoleName;
    return false;
  };

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER DROPDOWN BUTTON
  // ═══════════════════════════════════════════════════════════════
  const renderDropdownButton = (row, rowIndex, column) => {
    const isInvalid = isFieldInvalid(row, column);
    const displayValue = getDisplayValue(row, column);
    const placeholder = getPlaceholder(column, row);
    const isOpen = activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column;
    const refKey = `${rowIndex}-${column}`;
    const isDisabled = isDropdownDisabled(row, column);

    return (
      <div
        ref={(el) => (dropdownButtonRefs.current[refKey] = el)}
        className={`w-full flex justify-between items-center px-1 py-0.5 border text-xs min-h-[22px] ${
          isDisabled
            ? "border-gray-200 bg-gray-100 cursor-not-allowed"
            : isInvalid
            ? "border-red-500 bg-red-50 cursor-pointer"
            : row.isDuplicate
            ? "border-yellow-500 bg-yellow-50 cursor-pointer"
            : "border-gray-300 bg-white hover:border-gray-400 cursor-pointer"
        }`}
        onClick={() => !isDisabled && handleOpenDropdown(rowIndex, column)}
      >
        <span
          className={`flex-1 truncate ${
            displayValue
              ? "text-gray-800"
              : isDisabled
              ? "text-gray-400 italic"
              : "text-gray-400"
          }`}
        >
          {displayValue || placeholder}
        </span>
        {!isDisabled &&
          (isOpen ? (
            <ChevronUp className="w-3 h-3 text-gray-400 flex-shrink-0 ml-0.5" />
          ) : (
            <ChevronDown className="w-3 h-3 text-gray-400 flex-shrink-0 ml-0.5" />
          ))}
      </div>
    );
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔙 NAVIGATION
  // ═══════════════════════════════════════════════════════════════
  const handleBack = () => {
    navigate("/masters/subkpimaster");
  };

  // ═══════════════════════════════════════════════════════════════
  // 📁 FILE UPLOAD WITH PARSING
  // ═══════════════════════════════════════════════════════════════
  const parseExcelFile = (arrayBuffer) => {
    const data = new Uint8Array(arrayBuffer);
    const workbook = XLSX.read(data, { type: "array" });

    const sheetName =
      workbook.SheetNames.find((name) => name === "Sub KPI Template") ||
      workbook.SheetNames.find((name) => !name.toLowerCase().includes("dropdown")) ||
      workbook.SheetNames[0];

    let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });

    json = json.filter((row) =>
      Object.values(row).some((cell) => String(cell).trim() !== "")
    );

    const finalRows = json.map((row) => {
      const createdYear = String(row["Created Year"] || "").trim();
      const objectiveName = String(row["Strategic Objective"] || "").trim();
      const kpiNumber = String(row["KPI Number"] || "").trim();
      const kpiName = String(row["KPI"] || "").trim();
      const subKpiName = String(row["Sub KPI"] || "").trim();
      const assessmentPeriod = String(row["Assessment Period"] || "").trim();
      const minScore = String(row["Min Score"] || "0").trim();
      const maxScore = String(row["Max Score"] || "0").trim();
      const scoringCriteria = String(row["Scoring Criteria"] || "").trim();
      const measurement = String(row["Measurement"] || "").trim();
      const annualScore = String(row["Annual Score"] || "").trim();
      const annualScoringCriteria = String(row["Annual Scoring Criteria"] || "").trim();
      const userType = String(row["User Type"] || "").trim();
      const userRoleName = String(row["User Roles"] || "").trim();
      const userName = String(row["User Names"] || "").trim();
      const criteriaDefinition = String(row["Criteria Definition"] || "").trim();
      const dataSource = String(row["Data Source"] || "").trim();
      const dealerContent = String(row["Dealer Needs to Provide Content"] || "").trim();

      const objectiveId = getObjectiveIdByName(objectiveName);
      const kpiId = getKpiIdByName(kpiName);
      const roleId = getRoleIdByName(userRoleName, userType);
      const userId = getUserIdByName(userName);

      const isValidYear = years.includes(createdYear);
      const isValidObjective = !!objectiveId;
      const isValidKpi = !!kpiId;
      const isValidSubKpi = !!subKpiName;

      const hasError = !isValidYear || !isValidObjective || !isValidKpi || !isValidSubKpi;

      return {
        createdYear,
        objectiveName,
        objectiveId,
        kpiNumber,
        kpiName,
        kpiId,
        subKpiName,
        assessmentPeriod,
        minScore,
        maxScore,
        scoringCriteria,
        measurement,
        annualScore,
        annualScoringCriteria,
        userType,
        userRoleName,
        roleId,
        userName,
        userId,
        criteriaDefinition,
        dataSource,
        dealerContent,
        hasError,
        isDuplicate: false,
        duplicateReason: "",
      };
    });

    return finalRows;
  };

  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (isDataLoading) {
      toast.warning("Please wait, loading data...");
      e.target.value = "";
      return;
    }

    if (strategicObjectives.length === 0 || kpis.length === 0) {
      toast.error("Failed to load dropdown data. Please refresh the page.");
      e.target.value = "";
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully!`);
      } catch (error) {
        console.error("Error parsing file:", error);
        toast.error("Failed to parse Excel file");
      }
    };

    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  // ═══════════════════════════════════════════════════════════════
  // 🎯 DRAG AND DROP HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    const file = e.dataTransfer.files[0];
    if (!file) return;

    // Validate file type
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error("Please drop an Excel file (.xlsx or .xls)");
      return;
    }

    if (isDataLoading) {
      toast.warning("Please wait, loading data...");
      return;
    }

    if (strategicObjectives.length === 0 || kpis.length === 0) {
      toast.error("Failed to load dropdown data. Please refresh the page.");
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully!`);
      } catch (error) {
        console.error("Error parsing file:", error);
        toast.error("Failed to parse Excel file");
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔍 CHECK DUPLICATES - Using Service
  // ═══════════════════════════════════════════════════════════════
  const checkDuplicates = async () => {
    if (rows.length === 0) {
      toast.error("No data to check. Please upload a file first.");
      return;
    }

    setIsChecking(true);
    setDuplicateInfo(null);

    try {
      const { updatedRows, duplicateCount } = checkDuplicatesInUpload(
        rows,
        existingSubKpis
      );

      setRows(updatedRows);

      if (duplicateCount > 0) {
        setDuplicateInfo({
          count: duplicateCount,
          message: `${duplicateCount} duplicate(s) found! These will be skipped during save.`,
          type: "warning",
        });
        toast.warning(`${duplicateCount} duplicate record(s) found!`);
      } else {
        setDuplicateInfo({
          count: 0,
          message: "No duplicates found. All records are unique.",
          type: "success",
        });
        toast.success("No duplicates found!");
      }
    } catch (error) {
      console.error("Error checking duplicates:", error);
      toast.error("Failed to check duplicates");
    } finally {
      setIsChecking(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // ✏️ EDIT CELL
  // ═══════════════════════════════════════════════════════════════
  const handleCellChange = (rowIdx, key, value) => {
    const updated = [...rows];
    updated[rowIdx][key] = value;

    if (key === "objectiveName") {
      updated[rowIdx].objectiveId = getObjectiveIdByName(value);
    }

    if (key === "kpiName") {
      updated[rowIdx].kpiId = getKpiIdByName(value);
    }

    if (key === "userType") {
      updated[rowIdx].userRoleName = "";
      updated[rowIdx].roleId = null;
      updated[rowIdx].userName = "";
      updated[rowIdx].userId = null;
    }

    if (key === "userRoleName") {
      updated[rowIdx].roleId = getRoleIdByName(value, updated[rowIdx].userType);
      updated[rowIdx].userName = "";
      updated[rowIdx].userId = null;
    }

    if (key === "userName") {
      updated[rowIdx].userId = getUserIdByName(value);
    }

    const row = updated[rowIdx];
    const isValidYear = years.includes(row.createdYear);
    const isValidObjective = !!row.objectiveId;
    const isValidKpi = !!row.kpiId;
    const isValidSubKpi = !!row.subKpiName;

    updated[rowIdx].hasError = !isValidYear || !isValidObjective || !isValidKpi || !isValidSubKpi;
    updated[rowIdx].isDuplicate = false;
    updated[rowIdx].duplicateReason = "";

    setRows(updated);
    setDuplicateInfo(null);
  };

  // ═══════════════════════════════════════════════════════════════
  // 🗑️ DELETE ROW
  // ═══════════════════════════════════════════════════════════════
  const handleDeleteRow = (rowIdx) => {
    const updated = rows.filter((_, idx) => idx !== rowIdx);
    setRows(updated);
    setDuplicateInfo(null);
    closeDropdown();
  };

  // ═══════════════════════════════════════════════════════════════
  // 💾 SAVE - Using Service
  // ═══════════════════════════════════════════════════════════════
  const handleSave = async () => {
    const hasError = rows.some((r) => r.hasError);

    if (hasError) {
      toast.error(
        "Please fix all errors before saving. Year, Objective, KPI, and Sub KPI are mandatory."
      );
      return;
    }

    if (rows.length === 0) {
      toast.error("No data to save. Please upload a file first.");
      return;
    }

    const rowsToSave = rows.filter((r) => !r.isDuplicate);

    if (rowsToSave.length === 0) {
      toast.error("All records are duplicates. Nothing to save.");
      return;
    }

    setIsSaving(true);

    try {
      const payload = rowsToSave.map((r) => ({
        createdYear: r.createdYear,
        strategicObjective: r.objectiveId,
        kpiId: r.kpiId,
        kpiNumber: r.kpiNumber || "",
        subKpiName: r.subKpiName.trim(),
        assessmentPeriod: r.assessmentPeriod || "",
        minScore: Number(r.minScore) || 0,
        maxScore: Number(r.maxScore) || 0,
        scoringCriteria: r.scoringCriteria || "",
        measurement: r.measurement || "",
        annualScore: r.annualScore || "",
        annualScoringCriteria: r.annualScoringCriteria || "",
        userType: r.userType || "",
        userRoles: r.roleId ? [r.roleId] : [],
        userIds: r.userId ? [r.userId] : [],
        criteriaDefinition: r.criteriaDefinition || "",
        dataSource: r.dataSource || "",
        docStaus: r.dealerContent?.toLowerCase().trim() === "yes" ? 1 : 0,
      }));

      console.log("💾 Saving:", payload.length, "records");

      const response = await bulkAddSubKPIs(payload);

      if (response.status) {
        const insertedCount = response.data?.inserted || payload.length;
        const invalidCount = response.data?.invalid || 0;

        if (invalidCount > 0) {
          toast.success(
            `${insertedCount} Sub KPI(s) added! ${invalidCount} duplicate(s) skipped.`,
            { autoClose: 5000 }
          );
        } else {
          toast.success(`${insertedCount} Sub KPI(s) added successfully!`);
        }

        setTimeout(() => {
          navigate("/masters/subkpimaster");
        }, 1500);
      } else {
        toast.error(response.message || "Failed to upload Sub KPIs");
      }
    } catch (error) {
      console.error("Error saving:", error);
      toast.error(error.message || "Failed to upload Sub KPIs");
    } finally {
      setIsSaving(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🧹 CLEAR ALL
  // ═══════════════════════════════════════════════════════════════
  const handleClearAll = () => {
    setRows([]);
    setFileName("");
    setDuplicateInfo(null);
    closeDropdown();
  };

  // ═══════════════════════════════════════════════════════════════
  // 📊 COMPUTED VALUES
  // ═══════════════════════════════════════════════════════════════
  const validCount = rows.filter((r) => !r.hasError && !r.isDuplicate).length;
  const duplicateCount = rows.filter((r) => r.isDuplicate).length;
  const errorCount = rows.filter((r) => r.hasError).length;

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "lg:ml-60" : ""
        } flex-1 flex justify-center`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Back Button & Title */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer hover:scale-110 text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">
              Sub KPI Master Bulk Upload
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[10%] ml-7 mb-2"></div>

          {/* Loading Indicator */}
          {isDataLoading && (
            <div className="mb-2 p-2 bg-blue-50 border border-blue-200 text-blue-600 text-xs flex items-center gap-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              <span>Loading dropdown data... Please wait before uploading.</span>
            </div>
          )}

          {/* Upload Section */}
          <div className="mb-4 flex flex-wrap items-center gap-2 w-full">
            {/* Drag & Drop Area */}
            <div
              className={`flex-1 min-w-[200px] max-w-md flex items-center border-2 border-dashed px-3 py-1.5 text-xs transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-black/30 bg-white hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="mr-2 flex-shrink-0"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>

              <span className="text-xs text-gray-700 truncate">
                {isDragActive
                  ? "Drop file here..."
                  : fileName || "Drag & drop or click Browse"}
              </span>

              <input
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleBulkUpload}
                id="bulk-upload-input"
                disabled={isDataLoading}
              />
            </div>

            <label
              htmlFor="bulk-upload-input"
              className={`px-3 py-1.5 text-xs cursor-pointer transition ${
                isDataLoading
                  ? "bg-gray-400 text-white cursor-not-allowed"
                  : "bg-darkblue1 text-white hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1"
              }`}
            >
              {isDataLoading ? "Loading..." : "Browse"}
            </label>

            {rows.length > 0 && (
              <>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 bg-gray-500 text-white text-xs hover:bg-gray-600 transition"
                >
                  Clear
                </button>

                <button
                  onClick={checkDuplicates}
                  disabled={isChecking}
                  className="px-3 py-1.5 bg-yellow-600 text-white text-xs hover:bg-yellow-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  {isChecking && (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  )}
                  {isChecking ? "Checking..." : "Check Duplicates"}
                </button>
              </>
            )}

            <button
              onClick={handleSave}
              disabled={isSaving || rows.length === 0 || isDataLoading}
              className="px-4 py-1.5 bg-darkblue1 text-white text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              {isSaving && (
                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
              )}
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>

          {/* Duplicate Info Banner */}
          {duplicateInfo && (
            <div
              className={`mb-2 p-2 border text-xs flex items-center justify-between ${
                duplicateInfo.type === "warning"
                  ? "bg-yellow-50 border-yellow-300 text-yellow-700"
                  : "bg-green-50 border-green-300 text-green-700"
              }`}
            >
              <span>
                <span className="font-medium">
                  {duplicateInfo.type === "warning" ? "⚠️ " : "✅ "}
                </span>
                {duplicateInfo.message}
              </span>
              <button
                onClick={() => setDuplicateInfo(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
          )}

          {/* Error Summary */}
          {rows.length > 0 && errorCount > 0 && (
            <div className="mb-2 p-2 bg-red-50 border border-red-200 text-red-600 text-xs">
              <span className="font-medium">⚠ {errorCount} row(s) have validation errors.</span>
              <span className="ml-2">
                Please select valid Year, Objective, KPI, and enter Sub KPI name.
              </span>
            </div>
          )}

          {/* Table */}
          {rows.length > 0 ? (
            <div className="overflow-auto border border-Dustyblue mb-2 bg-white shadow-md">
              <div
                ref={tableContainerRef}
                className="overflow-y-auto max-h-[400px] overflow-x-auto"
              >
                <table className="text-sm bg-white border-collapse min-w-[2400px]">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-20">
                    <tr>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[40px]">
                        #
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[90px]">
                        Created Year <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[160px]">
                        Strategic Objective <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[80px]">
                        KPI Number
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[160px]">
                        KPI <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[160px]">
                        Sub KPI <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[110px]">
                        Assessment Period
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[70px]">
                        Min Score
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[70px]">
                        Max Score
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[130px]">
                        Scoring Criteria
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[110px]">
                        Measurement
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[90px]">
                        Annual Score
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[150px]">
                        Annual Scoring Criteria
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[100px]">
                        User Type
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[110px]">
                        User Roles
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[130px]">
                        User Names
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[150px]">
                        Criteria Definition
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[130px]">
                        Data Source
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[120px]">
                        Dealer Content
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-center w-[80px]">
                        Status
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium text-center w-[60px]">
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((row, i) => (
                      <tr
                        key={i}
                        className={`text-xs hover:bg-lightBlue/50 ${
                          row.hasError
                            ? "bg-red-50"
                            : row.isDuplicate
                            ? "bg-yellow-50"
                            : ""
                        }`}
                      >
                        <td className="px-2 py-1 border border-grey2 border-l-0 text-center text-gray-500">
                          {i + 1}
                        </td>

                        {/* Dropdown columns */}
                        <td className="px-2 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "createdYear")}
                        </td>
                        <td className="px-2 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "objectiveName")}
                        </td>

                        {/* Input columns */}
                        <td className="px-2 py-1 border border-grey2">
                          <input
                            type="text"
                            className="w-full text-xs border px-1 py-0.5 border-gray-300"
                            value={row.kpiNumber}
                            onChange={(e) => handleCellChange(i, "kpiNumber", e.target.value)}
                          />
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "kpiName")}
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          <input
                            type="text"
                            className={`w-full text-xs border px-1 py-0.5 ${
                              !row.subKpiName
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.subKpiName}
                            onChange={(e) => handleCellChange(i, "subKpiName", e.target.value)}
                            placeholder="Enter Sub KPI"
                          />
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "assessmentPeriod")}
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          <input
                            type="number"
                            className="w-full text-xs border px-1 py-0.5 border-gray-300"
                            value={row.minScore}
                            onChange={(e) => handleCellChange(i, "minScore", e.target.value)}
                          />
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          <input
                            type="number"
                            className="w-full text-xs border px-1 py-0.5 border-gray-300"
                            value={row.maxScore}
                            onChange={(e) => handleCellChange(i, "maxScore", e.target.value)}
                          />
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          <input
                            type="text"
                            className="w-full text-xs border px-1 py-0.5 border-gray-300"
                            value={row.scoringCriteria}
                            onChange={(e) =>
                              handleCellChange(i, "scoringCriteria", e.target.value)
                            }
                          />
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "measurement")}
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "annualScore")}
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          <input
                            type="text"
                            className="w-full text-xs border px-1 py-0.5 border-gray-300"
                            value={row.annualScoringCriteria}
                            onChange={(e) =>
                              handleCellChange(i, "annualScoringCriteria", e.target.value)
                            }
                          />
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "userType")}
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "userRoleName")}
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "userName")}
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          <input
                            type="text"
                            className="w-full text-xs border px-1 py-0.5 border-gray-300"
                            value={row.criteriaDefinition}
                            onChange={(e) =>
                              handleCellChange(i, "criteriaDefinition", e.target.value)
                            }
                          />
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          <input
                            type="text"
                            className="w-full text-xs border px-1 py-0.5 border-gray-300"
                            value={row.dataSource}
                            onChange={(e) => handleCellChange(i, "dataSource", e.target.value)}
                          />
                        </td>

                        <td className="px-2 py-1 border border-grey2">
                          {renderDropdownButton(row, i, "dealerContent")}
                        </td>

                        {/* Status Badge */}
                        <td className="px-2 py-1 border border-grey2 text-center">
                          {row.hasError ? (
                            <span className="px-1 py-0.5 bg-red-100 text-red-600 text-[10px] rounded-full">
                              Invalid
                            </span>
                          ) : row.isDuplicate ? (
                            <span
                              className="px-1 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full cursor-help"
                              title={row.duplicateReason}
                            >
                              Duplicate
                            </span>
                          ) : (
                            <span className="px-1 py-0.5 bg-green-100 text-green-600 text-[10px] rounded-full">
                              Valid
                            </span>
                          )}
                        </td>

                        {/* Delete Button */}
                        <td className="px-2 py-1 border border-grey2 border-r-0 text-center">
                          <button
                            onClick={() => handleDeleteRow(i)}
                            className="text-red-500 hover:text-red-700 transition"
                            title="Delete Row"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="20"
                              height="20"
                              viewBox="0 0 32 32"
                              fill="none"
                            >
                              <g clipPath="url(#clip0_6398_313)">
                                <path
                                  d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z"
                                  fill="#BF2012"
                                />
                              </g>
                              <defs>
                                <clipPath id="clip0_6398_313">
                                  <rect
                                    width="24"
                                    height="24"
                                    fill="white"
                                    transform="translate(4 4)"
                                  />
                                </clipPath>
                              </defs>
                            </svg>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Footer Stats */}
              <div className="px-4 py-2 bg-gray-50 border-t border-grey2 flex flex-wrap justify-between items-center gap-2">
                <span className="text-xs text-gray-600">
                  Total: {rows.length} row(s) |
                  <span className="text-green-600 ml-1">Valid: {validCount}</span> |
                  <span className="text-yellow-600 ml-1">Duplicates: {duplicateCount}</span> |
                  <span className="text-red-600 ml-1">Errors: {errorCount}</span>
                </span>
                <span className="text-xs text-gray-500 italic">
                  💡 Click "Check Duplicates" before saving
                </span>
              </div>
            </div>
          ) : (
            /* Empty State - WITH DRAG AND DROP */
            <div
              className={`bg-white shadow-md border-2 border-dashed p-8 text-center transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-Dustyblue hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="w-12 h-12 mx-auto mb-3 opacity-50"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>

              <p className="text-gray-500 text-sm">
                {isDragActive
                  ? "Drop your Excel file here!"
                  : "No data loaded. Please upload an Excel file to preview."}
              </p>
              <p className="text-gray-400 text-xs mt-1">
                {isDragActive
                  ? "Release to upload"
                  : "Supported formats: .xlsx, .xls (Drag & drop or click Browse)"}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Universal Custom Dropdown */}
      {activeDropdown !== null && rows[activeDropdown.rowIndex] && (
        <div
          ref={dropdownMenuRef}
          className="fixed border border-gray-300 bg-white z-[9999] shadow-xl rounded overflow-hidden"
          style={{
            top: `${dropdownPosition.top}px`,
            left: `${dropdownPosition.left}px`,
            width: `${dropdownPosition.width}px`,
            minWidth: "160px",
          }}
        >
          {/* Search Input */}
          <div className="p-2 border-b border-gray-200 bg-gray-50">
            <input
              type="text"
              placeholder={getSearchPlaceholder(activeDropdown.column)}
              value={dropdownSearch}
              onChange={(e) => setDropdownSearch(e.target.value)}
              className="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:outline-none focus:border-darkblue1"
              autoFocus
            />
          </div>

          {/* Options List */}
          <div className="max-h-[150px] overflow-y-auto">
            {getDropdownOptions().length > 0 ? (
              getDropdownOptions().map((option) => {
                const isSelected = isValueSelected(
                  rows[activeDropdown.rowIndex],
                  activeDropdown.column,
                  option.id
                );

                return (
                  <div
                    key={option.id}
                    className={`flex items-center justify-between px-3 py-1.5 cursor-pointer text-xs border-b border-gray-100 last:border-b-0 ${
                      isSelected ? "bg-blue-50" : "hover:bg-gray-50"
                    }`}
                    onClick={() =>
                      handleSelectOption(activeDropdown.rowIndex, activeDropdown.column, option.id)
                    }
                  >
                    <span className={isSelected ? "text-blue-700 font-medium" : ""}>
                      {option.label}
                    </span>
                    {isSelected && <span className="text-blue-500">✓</span>}
                  </div>
                );
              })
            ) : (
              <div className="px-3 py-3 text-xs text-gray-400 text-center">No options found</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default BulkUploadSubKPIMaster;