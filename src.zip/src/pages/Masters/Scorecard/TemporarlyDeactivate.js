import React from "react";

const TemporarlyDeactivate = ({ isOpen, onConfirm, onCancel }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center px-4">
      <div className="bg-white p-5 sm:p-6 rounded-lg shadow-xl w-full max-w-sm sm:max-w-md border-l-8 border-green relative">
        <p className="text-sm sm:text-base font-medium text-black font-VolvoNovum mb-6 text-center leading-snug">
          Are you sure you want to temporarily deactivate?
        </p>

        <div className="flex justify-center gap-4">
          <button
            onClick={onCancel}
            className="border-2 border-red2 text-red px-4 sm:px-5 py-1.5 text-sm font-bold rounded-md hover:bg-red2 hover:shadow-md hover:scale-105 transition duration-200"
          >
            No
          </button>
          <button
            onClick={onConfirm}
            className="px-6 py-2 bg-green4 text-green5 text-sm font-bold border-2 border-transparent font-VolvoNovum rounded-md hover:bg-white hover:border-green4 hover:shadow-md hover:scale-105 transition duration-200"
          >
            Yes
          </button>
        </div>
      </div>
    </div>
  );
};

export default TemporarlyDeactivate;
