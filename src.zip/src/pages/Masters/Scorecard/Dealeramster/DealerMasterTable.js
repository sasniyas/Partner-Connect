import { useState, useRef, useEffect, useMemo } from "react";
import Searchinput from "../../../../Components/Searchinput";
import DeleteModal from "../../../../Components/DeleteModal";
import Filter from "../../../../Components/Filter";
import ActivateStatus from "../../../../Components/ActivateStatus";
import DeactivateStatus from "../../../../Components/DeactivateStatus";
import { useNavigate } from "react-router-dom";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { ChevronDown } from "lucide-react";
import { ChevronUp } from "lucide-react";
import { ArrowUp } from "lucide-react";
import { ArrowDown } from "lucide-react";
import { ChevronsUpDown } from "lucide-react";
import { useCRUDWithReset } from "../../../../util/useCRUDWithReset";
// ⭐ Import service functions
import {
  getAllDealersFormatted,
  addDealer,
  updateDealer,
  deleteDealer,
  toggleDealerStatus,
  checkDealerExists,
  getAllMarketAreas,
  getActiveMarketAreas,
  getAllStates,
  getStatesByMarketAreaName,
  getMarketAreaIdByName,
  getStateIdByName,
} from "../../../../services/Masters/Dealer/dealer.service";
import { uploadTempFile } from "../../../../services/download/bluckDownload.service";
import { useKeyboardNavigation } from "../../../../util/useKeyboardNavigation";
import { LOGO_BASE_URL } from "../../../../util/filePath";
const DealerMasterTable = () => {
  const navigate = useNavigate();

  // ═══════════════════════════════════════════════════════════════
  // 📊 STATE MANAGEMENT
  // ═══════════════════════════════════════════════════════════════
  const [tableData, setTableData] = useState([]);
  const [isLoadingdata, setIsLoadingdata] = useState(false);
const [marketAreaSearch, setMarketAreaSearch] = useState("");
const [stateSearch, setStateSearch] = useState("");
const popupRef = useRef("")
  // Master data for dropdowns
  const [allMarketAreasData, setAllMarketAreasData] = useState([]);
  const [allStatesData, setAllStatesData] = useState([]);
  const [activeMarketAreas, setActiveMarketAreas] = useState([]);
  const [filteredStatesForPopup, setFilteredStatesForPopup] = useState([]);
  const [sortKey, setSortKey] = useState(null);    // "marketArea", "states", "dealerName", etc.
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc"
const [hoveredCell, setHoveredCell] = useState(null);

  // Form states
  const [selectedArea, setSelectedArea] = useState("");
  const [selectState, setSelectState] = useState("");
  const [dealerName, setDealerName] = useState("");
  const [dealerShortName, setDealerShortName] = useState("");
  const [errors, setErrors] = useState({
    marketArea: "",
    state: "",
    dealerName: "",
    dealerShortName: "",
  });

  // ⭐ ID-based selection instead of index
  const [selectedId, setSelectedId] = useState(null);
  const [selectedRowData, setSelectedRowData] = useState(null);

  // Filter states
  const [selectedAllMarketArea, setSelectedAllMarketArea] = useState([]);
  const [selectedStates, setSelectedStates] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState([]);
const statusOptions = ["Active", "Inactive"];

 
  // Modal states
  const [showPopup, setShowPopup] = useState(false);
  const [editPopup, setEditPopup] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);

  // Loading states
  const [loading, setLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [loadingToggle, setLoadingToggle] = useState(false);

// UI states
  const [searchTerm, setSearchTerm] = useState("");

  
  const { resetSortAndFilter } = useCRUDWithReset(
    setSortKey,
    setSortOrder,
    {
      setSelectedAllMarketArea,
      setSelectedStates,
      setSelectedStatus,
      setSearchTerm 
    }
  );


  // Dropdown states
  const [dropdownOpenLg, setDropdownOpenLg] = useState(false);
  const [dropdownOpenMd, setDropdownOpenMd] = useState(false);
  const [dropdownOpenSm, setDropdownOpenSm] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [stateOpen, setStateOpen] = useState(false);

  // Refs
  const actionsRefLg = useRef(null);
  const actionsRefMd = useRef(null);
  const actionsRefSm = useRef(null);
  const marketAreaRef = useRef(null);
  const stateRef = useRef(null);
  const tableContainerRef = useRef(null);
  const fileInputRef = useRef(null);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); 
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  // ═══════════════════════════════════════════════════════════════
  // 📡 FETCH DATA - Using Service
  // ═══════════════════════════════════════════════════════════════
  const fetchDealers = async () => {
    try {
      setIsLoadingdata(true);
      const data = await getAllDealersFormatted();
      setTableData(data);
    } catch (err) {
      // console.error("Error fetching Dealers:", err.message);
      setTableData([]);
    } finally {
      setIsLoadingdata(false);
    }
  };

  const fetchMasterData = async () => {
    try {
      const [marketAreas, states] = await Promise.all([
        getAllMarketAreas(),
        getAllStates(),
      ]);
      setAllMarketAreasData(marketAreas);
      setAllStatesData(states);
      setActiveMarketAreas(marketAreas.filter((ma) => ma.isActive === 1));
    } catch (err) {
      // console.error("Error fetching master data:", err.message);
    }
  };

  useEffect(() => {
    fetchDealers();
    fetchMasterData();
  }, []);

  // Update filtered states when market area changes in popup
  useEffect(() => {
    if (selectedArea) {
      const states = getStatesByMarketAreaName(allStatesData, allMarketAreasData, selectedArea);
      setFilteredStatesForPopup(states);
    } else {
      setFilteredStatesForPopup([]);
    }
  }, [selectedArea, allStatesData, allMarketAreasData]);

  // ═══════════════════════════════════════════════════════════════
  // 🔍 FILTER DATA
  // ═══════════════════════════════════════════════════════════════
  const filteredStateOptions = useMemo(() => {
    if (!selectedAllMarketArea || selectedAllMarketArea.length === 0) {
      return allStatesData.map((s) => s.stateName);
    }

    const selectedIds = allMarketAreasData
      .filter((ma) => selectedAllMarketArea.includes(ma.marketarea))
      .map((ma) => ma.id);

    const filtered = allStatesData
      .filter((state) => selectedIds.includes(state.marketarea_id))
      .map((s) => s.stateName);

    return filtered.length > 0 ? filtered : ["No states found"];
  }, [selectedAllMarketArea, allMarketAreasData, allStatesData]);

  const filteredData = tableData.filter((item) => {
    const searchLower = searchTerm.toLowerCase();

    const matchesSearch =
      (item.marketArea?.toLowerCase() || "").includes(searchLower) ||
      (item.dealerName?.toLowerCase() || "").includes(searchLower) ||
      (item.dealerShortName?.toLowerCase() || "").includes(searchLower) ||
      (item.states?.toLowerCase() || "").includes(searchLower);
const matchesStatus = selectedStatus.length > 0
  ? selectedStatus.includes(
      item.isActive === 1 ? "Active" : "Inactive"
    )
  : true;

    const matchesMarket =
      selectedAllMarketArea.length === 0 ||
      selectedAllMarketArea.includes(item.marketArea);

    const matchesStates =
      selectedStates.length === 0 || selectedStates.includes(item.states);

    return matchesSearch && matchesMarket && matchesStates && matchesStatus;
  });
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const valA = (a[sortKey] || "").toString().trim();
    const valB = (b[sortKey] || "").toString().trim();

    return sortOrder === "asc"
      ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: "base" })
      : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: "base" });
  });
}, [filteredData, sortKey, sortOrder]);


  // ═══════════════════════════════════════════════════════════════
  // 🖱️ CLICK OUTSIDE HANDLER
  // ═══════════════════════════════════════════════════════════════
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (actionsRefLg.current && !actionsRefLg.current.contains(event.target)) {
        setDropdownOpenLg(false);
      }
      if (actionsRefMd.current && !actionsRefMd.current.contains(event.target)) {
        setDropdownOpenMd(false);
      }
      if (actionsRefSm.current && !actionsRefSm.current.contains(event.target)) {
        setDropdownOpenSm(false);
      }
      if (marketAreaRef.current && !marketAreaRef.current.contains(event.target)) {
        setIsOpen(false);
        setMarketAreaSearch("");
      }
      if (stateRef.current && !stateRef.current.contains(event.target)) {
        setStateOpen(false);
        setStateSearch("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // ✅ VALIDATION
  // ═══════════════════════════════════════════════════════════════
  const validateForm = () => {
    const newErrors = {};
    if (!selectedArea) newErrors.marketArea = "Please fill out this field";
    if (!selectState) newErrors.state = "Please fill out this field";
    if (!dealerName.trim()) newErrors.dealerName = "Please fill out this field";
    if (!dealerShortName.trim()) newErrors.dealerShortName = "Please fill out this field";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // ═══════════════════════════════════════════════════════════════
  // ➕ ADD DEALER - Using Service
  // ═══════════════════════════════════════════════════════════════
  const handleSubmit = async () => {
    if (!validateForm()) return;

    const marketId = getMarketAreaIdByName(allMarketAreasData, selectedArea);
    const stateId = getStateIdByName(allStatesData, selectState);

    if (!marketId || !stateId) {
      setErrors({ ...errors, marketArea: "Invalid Market Area or State" });
      return;
    }

    // Check for duplicates
    if (checkDealerExists(tableData, selectedArea, dealerName)) {
      setErrors({ ...errors, dealerName: "This Market Area & Dealer Name combination already exists" });
      return;
    }

    setLoading(true);

    try {
      const payload = {
        market_id: marketId,
        state_id: stateId,
        dealerName: dealerName.trim(),
        dealerShortName: dealerShortName.trim(),
      };

      await addDealer(payload);
      await fetchDealers();
      resetSortAndFilter(); 
      resetForm();
    } catch (error) {
      // console.error("Error adding Dealer:", error.message);
    } finally {
      setLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // ✏️ UPDATE DEALER - Using Service with ID
  // ═══════════════════════════════════════════════════════════════
  const handleEditSubmit = async () => {
    if (!validateForm()) return;

    if (!selectedId) {
      // alert("Unable to update: Missing ID");
      return;
    }

    const marketId = getMarketAreaIdByName(allMarketAreasData, selectedArea);
    const stateId = getStateIdByName(allStatesData, selectState);

    if (!marketId || !stateId) {
      setErrors({ ...errors, marketArea: "Invalid Market Area or State" });
      return;
    }

    // ⭐ Check duplicates excluding current ID
    if (checkDealerExists(tableData, selectedArea, dealerName, selectedId)) {
      setErrors({ ...errors, dealerName: "This Market Area & Dealer Name combination already exists" });
      return;
    }

    setLoading(true);

    try {
      const payload = {
        id: selectedId,
        market_id: marketId,
        state_id: stateId,
        dealerName: dealerName.trim(),
        dealerShortName: dealerShortName.trim(),
      };

      await updateDealer(payload);
      await fetchDealers()
      resetForm();
      // console.log("Dealer updated successfully");
    } catch (error) {
      // console.error("Failed to update Dealer:", error.message);
      // alert("Failed to update. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🗑️ DELETE DEALER - Using ID
  // ═══════════════════════════════════════════════════════════════
  const handleDelete = async () => {
    if (!selectedId) {
      // console.error("No ID selected for deletion");
      return;
    }

    setDeleteLoading(true);

    try {
      await deleteDealer(selectedId);
      await fetchDealers();
      setIsDeleteModalOpen(false);
      setSelectedId(null);
      setSelectedRowData(null);
    } catch (error) {
      // console.error("Error deleting Dealer:", error.message);
    } finally {
      setDeleteLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔄 TOGGLE STATUS - Using ID
  // ═══════════════════════════════════════════════════════════════
  const handleActivate = async () => {
    if (!selectedId) {
      // console.error("No ID selected for toggle");
      return;
    }

    setLoadingToggle(true);

    try {
      await toggleDealerStatus(selectedId, 1);
      await fetchDealers(); 
      setShowActivateModal(false);
      setSelectedId(null);
      setSelectedRowData(null);
    } catch (error) {
      // console.error("Error activating Dealer:", error.message);
    } finally {
      setLoadingToggle(false);
    }
  };

  const handleDeactivate = async () => {
    if (!selectedId) {
      // console.error("No ID selected for toggle");
      return;
    }

    setLoadingToggle(true);

    try {
      await toggleDealerStatus(selectedId, 0);
      await fetchDealers(); 
      setShowDeactivateModal(false);
      setSelectedId(null);
      setSelectedRowData(null);
    } catch (error) {
      // console.error("Error deactivating Dealer:", error.message);
    } finally {
      setLoadingToggle(false);
    }
  };

  // ═══════════════════════════════════════════════════════════════
  // ✏️ EDIT HANDLER - Using ID
  // ═══════════════════════════════════════════════════════════════
  const handleEditClick = (rowData) => {
    setSelectedId(rowData.id);
    setSelectedRowData(rowData);
    setSelectedArea(rowData.marketArea);
    setSelectState(rowData.states);
    setDealerName(rowData.dealerName);
    setDealerShortName(rowData.dealerShortName);
    setEditPopup(true);
  };

  // ═══════════════════════════════════════════════════════════════
  // 🔄 RESET FORM
  // ═══════════════════════════════════════════════════════════════
  const resetForm = () => {
    setSelectedArea("");
    setSelectState("");
    setDealerName("");
    setDealerShortName("");
    setSelectedId(null);
    setSelectedRowData(null);
    setShowPopup(false);
    setEditPopup(false);
    setIsOpen(false);
    setStateOpen(false);
    setErrors({
      marketArea: "",
      state: "",
      dealerName: "",
      dealerShortName: "",
    });
  };

  // ═══════════════════════════════════════════════════════════════
  // 📥 DOWNLOAD HANDLERS
  // ═══════════════════════════════════════════════════════════════
  const handlePreviewAndDownload = async () => {
  if (!filteredData || filteredData.length === 0) {
    // alert("No data available to generate preview");
    return;
  }

  try {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Dealer Master");

    // ===== HEADERS =====
    sheet.columns = [
      { header: "Sl. No", key: "slNo", width: 10 },
      { header: "Market Area", key: "marketArea", width: 25 },
      { header: "State", key: "state", width: 25 },
      { header: "Dealer Name", key: "dealerName", width: 30 },
      { header: "Dealer Short Name", key: "dealerShortName", width: 20 },
      { header: "Status", key: "status", width: 15 },
    ];

    // ===== HEADER STYLE =====
    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });

    // ===== DATA ROWS =====
    filteredData.forEach((item, index) => {
      const row = sheet.addRow({
        slNo: index + 1,
        marketArea: item.marketArea || "",
        state: item.states || "",
        dealerName: item.dealerName || "",
        dealerShortName: item.dealerShortName || "",
        status: item.isActive === 1 ? "Active" : "Inactive",
      });

      row.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
    });

    // ===== CREATE FILE =====
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const file = new File([blob], "Dealer_Master.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    // ===== UPLOAD TEMP FILE FOR PREVIEW =====
    // uploadTempFile(file) must return a public URL
    const response = await uploadTempFile(file);

    const fileUrl = response
      ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
      : null;

    if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    } else {
      // console.warn("Upload succeeded but no preview URL returned");
      // alert("Upload succeeded but preview is not available.");
    }
  } catch (error) {
    // console.error("Dealer preview generation failed:", error);
    // alert("Failed to generate preview. Check console for details.");
  }
};


  const handleDownloadTemplate = async () => {
    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("Dealer Master");

      sheet.columns = [
        { header: "Market Area", key: "marketArea", width: 25 },
        { header: "State", key: "state", width: 25 },
        { header: "Dealer Name", key: "dealerName", width: 30 },
        { header: "Dealer Short Name", key: "dealerShortName", width: 20 },
      ];

      const headerRow = sheet.getRow(1);
      headerRow.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        };
        cell.alignment = { vertical: "middle", horizontal: "left" };
        cell.protection = { locked: true };
      });

      const dummyRow = sheet.addRow({
        marketArea: "East",
        state: "Karnataka",
        dealerName: "Alps Tech LTD",
        dealerShortName: "ATL",
      });

      dummyRow.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" };
        cell.protection = { locked: false };
      });

      const hidden = workbook.addWorksheet("DropdownData");
      hidden.state = "hidden";

      allMarketAreasData.forEach((m, i) => {
        hidden.getCell(`A${i + 1}`).value = m.marketarea;
      });

      allStatesData.forEach((s, i) => {
        hidden.getCell(`B${i + 1}`).value = s.stateName;
      });

      const maCount = allMarketAreasData.length;
      const stateCount = allStatesData.length;

      sheet.dataValidations.add("A2:A5000", {
        type: "list",
        allowBlank: true,
        formulae: [`DropdownData!$A$1:$A$${maCount}`],
        showErrorMessage: true,
        errorTitle: "Invalid Market Area",
        error: "Please select a Market Area from the dropdown list.",
      });

      sheet.dataValidations.add("B2:B5000", {
        type: "list",
        allowBlank: true,
        formulae: [`DropdownData!$B$1:$B$${stateCount}`],
        showErrorMessage: true,
        errorTitle: "Invalid State",
        error: "Please select a State from the dropdown list.",
      });

      for (let row = 2; row <= 5000; row++) {
        sheet.getCell(`A${row}`).protection = { locked: false };
        sheet.getCell(`B${row}`).protection = { locked: false };
        sheet.getCell(`C${row}`).protection = { locked: false };
        sheet.getCell(`D${row}`).protection = { locked: false };
      }

      sheet.protect("12345", {
        selectLockedCells: true,
        selectUnlockedCells: true,
        formatColumns: true,
        formatRows: true,
        insertRows: true,
        deleteRows: true,
      });

      const buffer = await workbook.xlsx.writeBuffer();
      saveAs(
        new Blob([buffer], { type: "application/octet-stream" }),
        "Dealer_Master_Bulk_Upload_Template.xlsx"
      );
    } catch (err) {
      // console.error("Template download error:", err);
    }
  };
useKeyboardNavigation({
  containerRef: popupRef, // your popup div ref

  onSubmit: () => { 
    if (editPopup) {
      handleEditSubmit();
    } else {
      handleSubmit();
    }
  },

  onCancel: () => {
    resetForm(); // closes popup and resets state
  },
});

  // ═══════════════════════════════════════════════════════════════
  // 🎨 RENDER
  // ═══════════════════════════════════════════════════════════════
  return (
    <div className="w-full mt-2 flex justify-center">
      <div className="w-full">
        {/* Search and Filters Section */}
        <div className="w-full mb-2">
          {/* LARGE SCREEN */}
          <div className="hidden lg:flex w-full items-center justify-between gap-2">
            <div className="flex flex-wrap gap-2 flex-1 items-center">
              <Searchinput
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
                className="min-w-[120px] max-w-[180px]"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />

              <Filter
                name="All Market Areas"
                value={selectedAllMarketArea}
                options={allMarketAreasData.map((a) => a.marketarea)}
                isMulti
                onChange={(name, values) => {
                  setSelectedAllMarketArea(values);
                  setSelectedStates([]);
                }}
                placeholder="Market Area"
                customWidth="w-[150px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />

              <Filter
                name="states"
                value={selectedStates}
                options={filteredStateOptions}
                isMulti
                onChange={(name, values) => {
                  if (filteredStateOptions[0] === "No states found") return;
                  setSelectedStates(values);
                }}
                placeholder="State"
                customWidth="w-[150px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />
              <Filter
  name="status"
  value={selectedStatus}
  options={statusOptions}
  onChange={(name, val) => setSelectedStatus(val)}
  placeholder="Status"
  placeholderColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black/60"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
  customWidth="w-[160px]"
/>

            </div>

            {/* Actions Dropdown */}
            <div className="relative flex-shrink-0" ref={actionsRefLg}>
              <button
                onClick={() => setDropdownOpenLg(!dropdownOpenLg)}
                className={`flex items-center justify-center px-3 py-1 text-white text-xs font-medium bg-darkblue1 shadow-md transition duration-200 ${
                  dropdownOpenLg ? "" : "hover:scale-105"
                }`}
              >
                Actions
                
        <svg
  
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className={`w-5 h-5 cursor-pointer transition-transform duration-300 ${
      dropdownOpenLg ? "rotate-180" : "rotate-0"
    }`}
    fill="none"
    
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
    
              </button>

              {dropdownOpenLg && (
                <div className="absolute right-0 top-full mt-1 w-32 bg-white border border-darkblue1 shadow-lg z-[9999]">
                  <ul className="p-0 w-full">
                    <li
                      onClick={() => {
                        setDropdownOpenLg(false);
                        setShowPopup(true);
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15" fill="none">
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="#212121"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
</svg>
                      <span>Add New</span>
                    </li>
                    <li>
                      <button
                        onClick={() => navigate("/bulkupload/dealermaster")}
                        className="w-full text-left px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1.5 cursor-pointer"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>
                        Bulk Upload
                      </button>
                    </li>
                    <li
                      onClick={() => {
                        setDropdownOpenLg(false);
                        handlePreviewAndDownload();
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                     <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>


                      <span>Download</span>
                    </li>
                    <li
                      onClick={() => {
                        handleDownloadTemplate();
                        setDropdownOpenLg(false);
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 22 22" fill="none">
<path d="M10.9994 10.0834C11.2425 10.0834 11.4756 10.18 11.6475 10.3519C11.8195 10.5238 11.916 10.7569 11.916 11V17.0354L13.1013 15.851C13.2734 15.6792 13.5068 15.5827 13.75 15.5829C13.9933 15.583 14.2265 15.6798 14.3984 15.852C14.5702 16.0241 14.6667 16.2574 14.6665 16.5007C14.6664 16.7439 14.5696 16.9772 14.3974 17.149L11.8088 19.7331C11.5769 19.9641 11.3504 20.1667 10.9994 20.1667C10.6914 20.1667 10.4805 20.0118 10.277 19.8184L7.60128 17.149C7.42915 16.9772 7.33236 16.7439 7.33218 16.5007C7.33201 16.2574 7.42848 16.0241 7.60036 15.852C7.77224 15.6798 8.00546 15.583 8.24871 15.5829C8.49196 15.5827 8.72532 15.6792 8.89744 15.851L10.0827 17.0354V11C10.0827 10.7569 10.1793 10.5238 10.3512 10.3519C10.5231 10.18 10.7562 10.0834 10.9994 10.0834ZM10.541 1.83337C13.093 1.83337 15.271 3.43754 16.1199 5.69437C17.2507 6.00528 18.2525 6.66933 18.9794 7.58967C19.7063 8.51001 20.1201 9.6385 20.1605 10.8106C20.2009 11.9826 19.8658 13.1369 19.2041 14.1052C18.5424 15.0734 17.5886 15.8049 16.4819 16.193C16.4126 15.5742 16.1353 14.9974 15.6954 14.5567C15.2264 14.0869 14.6032 13.8027 13.9409 13.7565L13.7494 13.75V11C13.7501 10.2842 13.4716 9.59632 12.9732 9.08254C12.4747 8.56876 11.7956 8.26958 11.0801 8.24857C10.3645 8.22757 9.66903 8.48639 9.1413 8.97005C8.61358 9.4537 8.29525 10.1241 8.25394 10.8387L8.24936 11V13.75C7.88788 13.75 7.52994 13.8212 7.19601 13.9596C6.86209 14.0981 6.55872 14.3009 6.30328 14.5567C5.81094 15.05 5.52426 15.7118 5.50119 16.4084C4.54688 16.2134 3.67945 15.7195 3.02465 14.9984C2.36986 14.2773 1.96171 13.3664 1.85937 12.3978C1.75703 11.4291 1.96582 10.4531 2.45547 9.61105C2.94512 8.76904 3.6902 8.10483 4.58269 7.71471C4.60295 6.14784 5.23962 4.65202 6.35484 3.55122C7.47006 2.45041 8.97403 1.83324 10.541 1.83337Z" fill="black"/>
</svg>

                      <span>Template</span>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* MEDIUM SCREEN */}
          <div className="hidden md:flex lg:hidden w-full items-center justify-between gap-2">
            <div className="flex flex-wrap gap-2 flex-1 items-center">
              <Searchinput
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
                className="min-w-[120px] max-w-[160px]"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />

              <Filter
                name="All Market Areas"
                value={selectedAllMarketArea}
                options={allMarketAreasData.map((a) => a.marketarea)}
                isMulti
                onChange={(name, values) => {
                  setSelectedAllMarketArea(values);
                  setSelectedStates([]);
                }}
                placeholder="Market Area"
                customWidth="w-[130px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />
            </div>

            <div className="relative flex-shrink-0" ref={actionsRefMd}>
              <button
                onClick={() => setDropdownOpenMd(!dropdownOpenMd)}
                className={`flex items-center justify-center px-3 py-1 text-white text-xs font-medium bg-darkblue1 shadow-md transition duration-200 ${
                  dropdownOpenMd ? "" : "hover:scale-105"
                }`}
              >
                Actions
               
        <svg
  
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className={`w-5 h-5 cursor-pointer transition-transform duration-300 ${
      dropdownOpenMd ? "rotate-180" : "rotate-0"
    }`}
    fill="none"
    
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
    
              </button>

              {dropdownOpenMd && (
                <div className="absolute right-0 top-full mt-1 w-32 bg-white border border-darkblue1 shadow-lg z-[9999]">
                  <ul className="p-0 w-full">
                    <li
                      onClick={() => {
                        setDropdownOpenMd(false);
                        setShowPopup(true);
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15" fill="none">
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="#212121"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
</svg>
                      <span>Add New</span>
                    </li>
                    <li>
                      <button
                        onClick={() => navigate("/bulkupload/dealermaster")}
                        className="w-full text-left px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>
                        Bulk Upload
                      </button>
                    </li>
                    <li
                      onClick={() => {
                        setDropdownOpenMd(false);
                        handlePreviewAndDownload();
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1.5 cursor-pointer"
                    >
                     <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>


                      <span>Download</span>
                    </li>
                    <li
                      onClick={() => {
                        handleDownloadTemplate();
                        setDropdownOpenMd(false);
                      }}
                      className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                    >
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 22 22" fill="none">
<path d="M10.9994 10.0834C11.2425 10.0834 11.4756 10.18 11.6475 10.3519C11.8195 10.5238 11.916 10.7569 11.916 11V17.0354L13.1013 15.851C13.2734 15.6792 13.5068 15.5827 13.75 15.5829C13.9933 15.583 14.2265 15.6798 14.3984 15.852C14.5702 16.0241 14.6667 16.2574 14.6665 16.5007C14.6664 16.7439 14.5696 16.9772 14.3974 17.149L11.8088 19.7331C11.5769 19.9641 11.3504 20.1667 10.9994 20.1667C10.6914 20.1667 10.4805 20.0118 10.277 19.8184L7.60128 17.149C7.42915 16.9772 7.33236 16.7439 7.33218 16.5007C7.33201 16.2574 7.42848 16.0241 7.60036 15.852C7.77224 15.6798 8.00546 15.583 8.24871 15.5829C8.49196 15.5827 8.72532 15.6792 8.89744 15.851L10.0827 17.0354V11C10.0827 10.7569 10.1793 10.5238 10.3512 10.3519C10.5231 10.18 10.7562 10.0834 10.9994 10.0834ZM10.541 1.83337C13.093 1.83337 15.271 3.43754 16.1199 5.69437C17.2507 6.00528 18.2525 6.66933 18.9794 7.58967C19.7063 8.51001 20.1201 9.6385 20.1605 10.8106C20.2009 11.9826 19.8658 13.1369 19.2041 14.1052C18.5424 15.0734 17.5886 15.8049 16.4819 16.193C16.4126 15.5742 16.1353 14.9974 15.6954 14.5567C15.2264 14.0869 14.6032 13.8027 13.9409 13.7565L13.7494 13.75V11C13.7501 10.2842 13.4716 9.59632 12.9732 9.08254C12.4747 8.56876 11.7956 8.26958 11.0801 8.24857C10.3645 8.22757 9.66903 8.48639 9.1413 8.97005C8.61358 9.4537 8.29525 10.1241 8.25394 10.8387L8.24936 11V13.75C7.88788 13.75 7.52994 13.8212 7.19601 13.9596C6.86209 14.0981 6.55872 14.3009 6.30328 14.5567C5.81094 15.05 5.52426 15.7118 5.50119 16.4084C4.54688 16.2134 3.67945 15.7195 3.02465 14.9984C2.36986 14.2773 1.96171 13.3664 1.85937 12.3978C1.75703 11.4291 1.96582 10.4531 2.45547 9.61105C2.94512 8.76904 3.6902 8.10483 4.58269 7.71471C4.60295 6.14784 5.23962 4.65202 6.35484 3.55122C7.47006 2.45041 8.97403 1.83324 10.541 1.83337Z" fill="black"/>
</svg>

                      <span>Template</span>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* SMALL SCREEN */}
          <div className="flex md:hidden w-full flex-col gap-2">
            <div className="flex items-center justify-between gap-2">
              <Searchinput
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
                className="flex-1"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />

              <div className="relative flex-shrink-0" ref={actionsRefSm}>
                <button
                  onClick={() => setDropdownOpenSm(!dropdownOpenSm)}
                  className={`flex items-center justify-center px-3 py-1 text-white text-xs font-medium bg-darkblue1 shadow-md transition duration-200 ${
                    dropdownOpenSm ? "" : "hover:scale-105"
                  }`}
                >
                  Actions
                 
        <svg
  
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className={`w-5 h-5 cursor-pointer transition-transform duration-300 ${
      dropdownOpenSm ? "rotate-180" : "rotate-0"
    }`}
    fill="none"
    
  >
    <path
      d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
      fill="currentColor"
    />
  </svg>
    
                </button>

                {dropdownOpenSm && (
                  <div className="absolute right-0 top-full mt-1 w-32 bg-white border border-darkblue1 shadow-lg z-[9999]">
                    <ul className="p-0 w-full">
                      <li
                        onClick={() => {
                          setDropdownOpenSm(false);
                          setShowPopup(true);
                        }}
                        className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15" fill="none">
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="#212121"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
<path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="black" fill-opacity="0.2"/>
</svg>
                        <span>Add New</span>
                      </li>
                      <li>
                        <button
                          onClick={() => navigate("/bulkupload/dealermaster")}
                          className="w-full text-left px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>
                          Bulk Upload
                        </button>
                      </li>
                      <li
                        onClick={() => {
                          setDropdownOpenSm(false);
                          handlePreviewAndDownload();
                        }}
                        className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1.5 cursor-pointer"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>


                        <span>Download</span>
                      </li>
                      <li
                        onClick={() => {
                          handleDownloadTemplate();
                          setDropdownOpenSm(false);
                        }}
                        className="w-full px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 cursor-pointer"
                      >
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 22 22" fill="none">
<path d="M10.9994 10.0834C11.2425 10.0834 11.4756 10.18 11.6475 10.3519C11.8195 10.5238 11.916 10.7569 11.916 11V17.0354L13.1013 15.851C13.2734 15.6792 13.5068 15.5827 13.75 15.5829C13.9933 15.583 14.2265 15.6798 14.3984 15.852C14.5702 16.0241 14.6667 16.2574 14.6665 16.5007C14.6664 16.7439 14.5696 16.9772 14.3974 17.149L11.8088 19.7331C11.5769 19.9641 11.3504 20.1667 10.9994 20.1667C10.6914 20.1667 10.4805 20.0118 10.277 19.8184L7.60128 17.149C7.42915 16.9772 7.33236 16.7439 7.33218 16.5007C7.33201 16.2574 7.42848 16.0241 7.60036 15.852C7.77224 15.6798 8.00546 15.583 8.24871 15.5829C8.49196 15.5827 8.72532 15.6792 8.89744 15.851L10.0827 17.0354V11C10.0827 10.7569 10.1793 10.5238 10.3512 10.3519C10.5231 10.18 10.7562 10.0834 10.9994 10.0834ZM10.541 1.83337C13.093 1.83337 15.271 3.43754 16.1199 5.69437C17.2507 6.00528 18.2525 6.66933 18.9794 7.58967C19.7063 8.51001 20.1201 9.6385 20.1605 10.8106C20.2009 11.9826 19.8658 13.1369 19.2041 14.1052C18.5424 15.0734 17.5886 15.8049 16.4819 16.193C16.4126 15.5742 16.1353 14.9974 15.6954 14.5567C15.2264 14.0869 14.6032 13.8027 13.9409 13.7565L13.7494 13.75V11C13.7501 10.2842 13.4716 9.59632 12.9732 9.08254C12.4747 8.56876 11.7956 8.26958 11.0801 8.24857C10.3645 8.22757 9.66903 8.48639 9.1413 8.97005C8.61358 9.4537 8.29525 10.1241 8.25394 10.8387L8.24936 11V13.75C7.88788 13.75 7.52994 13.8212 7.19601 13.9596C6.86209 14.0981 6.55872 14.3009 6.30328 14.5567C5.81094 15.05 5.52426 15.7118 5.50119 16.4084C4.54688 16.2134 3.67945 15.7195 3.02465 14.9984C2.36986 14.2773 1.96171 13.3664 1.85937 12.3978C1.75703 11.4291 1.96582 10.4531 2.45547 9.61105C2.94512 8.76904 3.6902 8.10483 4.58269 7.71471C4.60295 6.14784 5.23962 4.65202 6.35484 3.55122C7.47006 2.45041 8.97403 1.83324 10.541 1.83337Z" fill="black"/>
</svg>

                        <span>Template</span>
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            </div>

            {/* Filters for small screen */}
            <div className="flex gap-2">
              <Filter
                name="All Market Areas"
                value={selectedAllMarketArea}
                options={allMarketAreasData.map((a) => a.marketarea)}
                isMulti
                onChange={(name, values) => {
                  setSelectedAllMarketArea(values);
                  setSelectedStates([]);
                }}
                placeholder="Market Area"
                customWidth="flex-1"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />

              <Filter
                name="states"
                value={selectedStates}
                options={filteredStateOptions}
                isMulti
                onChange={(name, values) => {
                  if (filteredStateOptions[0] === "No states found") return;
                  setSelectedStates(values);
                }}
                placeholder="State"
                customWidth="flex-1"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
              />
            </div>
          </div>
        </div>

        {/* ⭐ RESPONSIVE TABLE - Fits 1024px, shrinks/scrolls based on content */}
        <div className="shadow-md border border-Dustyblue overflow-hidden cursor-pointer w-full">
          <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-auto scrollbar-hide"
            style={{
               maxHeight: filteredData.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >
            <table className="w-full text-xs text-left table-fixed min-w-[700px] lg:min-w-full">
             <thead className="bg-Dustyblue text-white text-xs font-medium sticky top-0 z-10">
  <tr>
    <th
      className="px-3 py-1.5 font-medium text-xs border border-grey2 border-t-0 border-l-0 w-[20%] cursor-pointer"
      onClick={() => handleSort("marketArea")}
    >
      <div className="flex items-center gap-1">
        Market Area
        {sortKey !== "marketArea" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}


        {sortKey === "marketArea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "marketArea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 font-medium text-xs border border-grey2 border-t-0 border-l-0 w-[20%] cursor-pointer"
      onClick={() => handleSort("states")}
    >
      <div className="flex items-center gap-1">
        State
        {sortKey === "states" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "states" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 font-medium text-xs border border-grey2 border-t-0 border-l-0 w-[25%] cursor-pointer"
      onClick={() => handleSort("dealerName")}
    >
      <div className="flex items-center gap-1">
        Dealer Name
        {sortKey === "dealerName" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "dealerName" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="px-3 py-1.5 font-medium text-xs border border-grey2 border-t-0 border-l-0 w-[20%] cursor-pointer"
      onClick={() => handleSort("dealerShortName")}
    >
      <div className="flex items-center gap-1">
        Dealer Short Name
        {sortKey === "dealerShortName" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "dealerShortName" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th className="text-center py-1.5 font-medium text-xs border border-grey2 border-t-0 border-l-0 border-r-0 w-[15%]">
      Actions
    </th>
  </tr>
</thead>


              <tbody>
                {/* Loading State */}
                {isLoadingdata && (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        Loading...
                      </div>
                    </td>
                  </tr>
                )}

                {/* Data Rows */}
                {!isLoadingdata && sortedData.length > 0 ? (
                  sortedData.map((record) => (
                    <tr
                      key={record.id}
                      className={`hover:bg-lightBlue/50 text-xs ${
                        record.status === "Active" ? "text-black" : "text-gray-400"
                      }`}
                    >
                      <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[10rem] cursor-pointer"
      onMouseEnter={() => {
        if (record.marketArea && record.marketArea.length > 20)
          setHoveredCell(record.id + "-ma");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {record.marketArea}
    </p>

    {hoveredCell === record.id + "-ma" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {record.marketArea}
      </span>
    )}
  </div>
</td>

                     <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[10rem] cursor-pointer"
      onMouseEnter={() => {
        if (record.states && record.states.length > 40)
          setHoveredCell(record.id + "-st");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {record.states}
    </p>

    {hoveredCell === record.id + "-st" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {record.states}
      </span>
    )}
  </div>
</td>

                     <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[25rem] cursor-pointer"
      onMouseEnter={() => {
        if (record.dealerName && record.dealerName.length > 70)
          setHoveredCell(record.id + "-dn");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {record.dealerName}
    </p>

    {hoveredCell === record.id + "-dn" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {record.dealerName}
      </span>
    )}
  </div>
</td>

                     <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[10rem] cursor-pointer"
      onMouseEnter={() => {
        if (record.dealerShortName && record.dealerShortName.length > 12)
          setHoveredCell(record.id + "-ds");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {record.dealerShortName}
    </p>

    {hoveredCell === record.id + "-ds" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {record.dealerShortName}
      </span>
    )}
  </div>
</td>


                      {/* Actions - Using ID */}
                      <td className="border border-grey2 border-t-0 border-l-0 border-r-0">
                        <div className="flex items-center justify-center gap-3">
                          {/* Edit */}
                          <div className="relative group">
                            <button onClick={() => handleEditClick(record)}>
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>


                            </button>
                            <span className="absolute top-4 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 z-0   whitespace-nowrap pointer-events-none">
                              Edit
                            </span>
                          </div>

                          {/* Status Toggle - Using ID */}
                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedId(record.id);
                                setSelectedRowData(record);
                                record.status === "Active"
                                  ? setShowDeactivateModal(true)
                                  : setShowActivateModal(true);
                              }}
                            >
                              {record.status === "Active" ? (<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
<path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" stroke-width="2.66667" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

):(<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<g clip-path="url(#clip0_5669_3080)">
<path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" stroke-width="2.66667" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
<clipPath id="clip0_5669_3080">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>
</svg>)}
                            </button>
                            <span className="absolute top-3 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 z-0   whitespace-nowrap pointer-events-none">
                              {record.status === "Active" ? "Deactivate" : "Activate"}
                            </span>
                          </div>

                          {/* Delete - Using ID */}
                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedId(record.id);
                                setSelectedRowData(record);
                                setIsDeleteModalOpen(true);
                              }}
                            >
                             <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>

                            </button>
                            <span className="absolute top-4 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-SteelBlue1 text-white text-[10px] px-2 py-0 z-0 whitespace-nowrap pointer-events-none">
                              Delete
                            </span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  !isLoadingdata && (
                    <tr>
                      <td colSpan={5} className="px-6 py-8 text-center text-gray-500 italic">
                        No data available
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>
           {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

        </div>

        {/* Add/Edit Modal */}
        {(showPopup || editPopup) && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div 
            ref={popupRef}
            className="bg-white shadow-lg p-6 w-[500px] relative">
              {/* Close Button */}
              <button
                onClick={resetForm}
                className="absolute top-4 right-4 text-gray-700 transition p-1 hover:scale-105 duration-200"
              >
               <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>

              </button>

              {/* Header */}
              <div className="mb-2 text-center">
                <h3 className="text-MediumGrey text-base font-semibold">
                  {editPopup ? "Edit Dealer" : "Add Dealer"}
                </h3>
              </div>

              {/* Market Area & State Dropdowns */}
              <div className="flex gap-4 mb-2">
                {/* Market Area Dropdown */}
                <div className="relative flex-1" ref={marketAreaRef}>
                  <label className="block text-xs font-medium text-black/70 mb-2">
                    Market Area <span className=" text-red1">*</span>
                  </label>
                  <div
                    className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none text-black placeholder:text-grey focus:ring-1 flex justify-between items-center 
                      ${
                        isOpen
                          ? "border-black/30 border-b-white"
                          : errors.marketArea
                          ? "border-red1 focus:ring-red1"
                          : "border-black/30 focus:ring-black/30"
                      }`}
                      tabIndex={0}
                    onClick={() => {
                      setIsOpen(!isOpen);
                      setErrors({ ...errors, marketArea: "" });
                    }}
                    onKeyDown={(e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    e.stopPropagation();
    setIsOpen((prev) => !prev);
  }
}}
                  >
                    <span className="text-black flex items-center">
                      <img
                        src={`${LOGO_BASE_URL}/public/icons/statemastertable/location.png`}
                        alt="location"
                        className="w-3 h-3 mr-2"
                      />
                      {selectedArea || "- Select Market Area -"}
                    </span>
                  
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"className={`w-3 h-3 transform transition-transform duration-200 ${
                        isOpen ? "rotate-180" : "rotate-0"
                      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>
                  </div>

                 {isOpen && (
  <ul className="absolute left-0 mt-0 w-full bg-white border border-black/30 shadow-lg z-10 max-h-40 overflow-auto border-t-white">

    {/* 🔍 Search input (only if more than 5 options) */}
    {activeMarketAreas.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1.5 z-10">
       <input
  type="text"
  placeholder="Search market area..."
  value={marketAreaSearch}
  onChange={(e) => setMarketAreaSearch(e.target.value)}

  onKeyDown={(e) => {
    // ENTER → prevent form submit
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
    }

    // ESC → close only dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation(); // 🔥 must

      setIsOpen(null);     // or setIsMarketAreaOpen(false)
      setMarketAreaSearch("");     // optional
    }

    // Arrow ↓ → focus first option
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation();

      const first = e.currentTarget
        .closest("ul")
        ?.querySelector("li[tabindex]");
      first?.focus();
    }
  }}

  className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
  autoFocus
/>
      </li>
    )}

    {/* Filter + Sort + Render */}
    {activeMarketAreas
      .map((a) => a.marketarea)
      .filter(Boolean) // ✅ prevent undefined
      .filter((area) =>
        !marketAreaSearch
          ? true
          : area.toLowerCase().includes(marketAreaSearch.toLowerCase())
      )
      .sort((a, b) => a.localeCompare(b))
      .filter((area) => area !== selectedArea)
      .map((area, index) => (
       <li
  tabIndex={0}
  key={index}
  className={`px-4 py-1.5 text-xs cursor-pointer transition
    ${
      area === selectedArea
        ? "bg-lightBlue/30 font-medium"
        : "hover:bg-black/30 hover:text-white"
    }
  `}
  onKeyDown={(e) => {

    // ⭐ ESCAPE → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
       e.stopPropagation();
      setIsOpen(false);
      marketAreaRef.current?.querySelector('[tabindex="0"]')?.focus();
      return;
    }

    e.stopPropagation(); // prevent Save

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );

    const currentIndex = items.indexOf(e.currentTarget);

    // ⭐ Arrow Down
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex + 1) % items.length]?.focus();
    }

    // ⭐ Arrow Up
    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex - 1 + items.length) % items.length]?.focus();
    }

    // ⭐ Enter select
    if (e.key === "Enter") {
      e.preventDefault();
e.stopPropagation()
      setSelectedArea(area);
      setIsOpen(false);
      setSelectState("");
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();

    setSelectedArea(area);
    setIsOpen(false);
    setSelectState("");
  }}
>
  {area}
</li>
      ))}

    {/* No results */}
    {activeMarketAreas
      .map((a) => a.marketarea)
      .filter(Boolean)
      .filter((area) =>
        !marketAreaSearch
          ? true
          : area.toLowerCase().includes(marketAreaSearch.toLowerCase())
      ).length === 0 && (
      <li className="px-4 py-2 text-sm text-gray-400 italic">
        No market areas found.
      </li>
    )}
  </ul>
)}

                  {errors.marketArea && (
                    <p className="text-red1 text-xs mt-1">{errors.marketArea}</p>
                  )}
                </div>

                {/* State Dropdown */}
                <div className="relative flex-1" ref={stateRef}>
                  <label className="block text-xs font-medium text-black/70 mb-2">
                    Select State <span className=" text-red1">*</span>
                  </label>
                  <div
                    className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none text-black placeholder:text-grey focus:ring-1 focus:ring-black/30 flex justify-between items-center 
                      ${
                        stateOpen
                          ? "border-black/30 border-b-white"
                          : errors.state
                          ? "border-red1 focus:ring-red1"
                          : "border-black/30 focus:ring-black/30"
                      }`}
                      tabIndex={0}
                    onClick={() => {
                      setStateOpen(!stateOpen);
                      setErrors({ ...errors, state: "" });
                    }}
                     onKeyDown={(e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setStateOpen((prev) => !prev);
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setStateOpen(false);
    }
  }}
                  >
                    <span className="text-black flex items-center">
                     <img
  src={`${LOGO_BASE_URL}/public/icons/statemastertable/location.png`}
  alt="location"
  className="w-3 h-3 mr-2"
/>

                      {selectState || "- Select State -"}
                    </span>
                    
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"className={`w-3 h-3 transform transition-transform duration-200 ${
                        stateOpen ? "rotate-180" : "rotate-0"
                      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>
                  </div>

                 {stateOpen && (
  <ul className="absolute left-0 mt-0 w-full bg-white border border-black/30 shadow-lg z-10 max-h-40 overflow-auto border-t-white">

    {/* 🔍 Search (only if more than 5 states) */}
    {filteredStatesForPopup.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1.5 z-10">
        <input
  type="text"
  placeholder="Search state..."
  value={stateSearch}
  onChange={(e) => setStateSearch(e.target.value)}

  onKeyDown={(e) => {
    // ENTER → prevent form submit
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
    }

    // ESC → close only dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation(); // 🔥 important

    setStateOpen(null); // or setIsStateOpen(false)
      setStateSearch("");      // optional
    }

    // Arrow ↓ → focus first option
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation();

      const first = e.currentTarget
        .closest("ul")
        ?.querySelector("li[tabindex]");
      first?.focus();
    }
  }}

  className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
  autoFocus
/>
      </li>
    )}

    {/* Filter + Sort + Render */}
    {filteredStatesForPopup
      .map((s) => s.stateName)
      .filter(Boolean) // ✅ avoid undefined
      .filter((state) =>
        !stateSearch
          ? true
          : state.toLowerCase().includes(stateSearch.toLowerCase())
      )
      .sort((a, b) => a.localeCompare(b))
      .filter((state) => state !== selectState)
      .map((state, index) => (
       <li
  tabIndex={0}
  key={index}
  className={`px-4 py-1.5 text-xs cursor-pointer transition
    ${
      state === selectState
        ? "bg-lightBlue/30 font-medium"
        : "hover:bg-black/30 hover:text-white"
    }
  `}
  onKeyDown={(e) => {

    // ESCAPE → close
    if (e.key === "Escape") {
      e.preventDefault();
       e.stopPropagation();
      setStateOpen(false);
      stateRef.current?.querySelector('[tabindex="0"]')?.focus();
      return;
    }

    e.stopPropagation(); // prevent Save button

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );

    const currentIndex = items.indexOf(e.currentTarget);

    // Arrow Down
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex + 1) % items.length]?.focus();
    }

    // Arrow Up
    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(currentIndex - 1 + items.length) % items.length]?.focus();
    }

    // Enter select
    if (e.key === "Enter") {
      e.preventDefault();
      setSelectState(state);
      e.stopPropagation()
      setStateOpen(false);
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setSelectState(state);
    setStateOpen(false);
  }}
>
  {state}
</li>
      ))}

    {/* No results */}
    {filteredStatesForPopup
      .map((s) => s.stateName)
      .filter(Boolean)
      .filter((state) =>
        !stateSearch
          ? true
          : state.toLowerCase().includes(stateSearch.toLowerCase())
      ).length === 0 && (
      <li className="px-4 py-2 text-sm text-black cursor-default">
        No states found
      </li>
    )}
  </ul>
)}

                  {errors.state && (
                    <p className="text-red1 text-xs mt-1">{errors.state}</p>
                  )}
                </div>
              </div>

              {/* Dealer Name Input */}
              <div className="mb-4 relative">
                <label className="block text-xs font-medium text-black/70 mb-2">
                  Dealer Name <span className=" text-red1">*</span>
                </label>

                {dealerName === "" && (
                  <div className="absolute left-4 top-11 transform -translate-y-1/2 flex items-center text-gray-400 pointer-events-none">
                    <img
                      src={`${LOGO_BASE_URL}/public/icons/Scorecard/tdesign_city-11.png`}
                      alt="icon"
                      className="w-4 h-4 mr-2"
                    />
                    <span className="text-xs">Enter Dealer Name</span>
                  </div>
                )}

                <input
                  type="text"
                  value={dealerName}
                  onChange={(e) => {
                    setDealerName(e.target.value);
                    setErrors({ ...errors, dealerName: "" });
                  }}
                  maxLength={100}
                  className={`border  px-3 py-1.5 w-full text-xs outline-none text-black placeholder:text-grey focus:ring-1
                    ${errors.dealerName ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                />

                {errors.dealerName && (
                  <p className="text-red1 text-xs mt-1">{errors.dealerName}</p>
                )}
              </div>

              {/* Dealer Short Name Input */}
              <div className="mb-4">
                <label className="block text-xs font-medium text-black/70 mb-2">
                  Dealer Short Name <span className=" text-red1">*</span>
                </label>
                <input
                  type="text"
                  value={dealerShortName}
                  onChange={(e) => {
                    setDealerShortName(e.target.value);
                    setErrors({ ...errors, dealerShortName: "" });
                  }}
                  maxLength={50}
                  className={`border  px-3 py-1.5 w-full  text-xs outline-none text-black placeholder:text-grey focus:ring-1
                    ${errors.dealerShortName ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                  placeholder="Enter Dealer Short Name"
                />
                {errors.dealerShortName && (
                  <p className="text-red1 text-xs mt-1">{errors.dealerShortName}</p>
                )}
              </div>

              {/* Save Button */}
              <div className="flex items-center justify-center gap-4 mt-2">
                <button
                type="button"
                  onClick={editPopup ? handleEditSubmit : handleSubmit}
                  disabled={loading}
                  className={`bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 
                    transition ${
                      loading
                        ? "opacity-50 cursor-not-allowed"
                        : "hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                    }`}
                >
                  {loading ? "Saving..." : "Save"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Delete Modal - Using ID */}
        {isDeleteModalOpen && selectedId && (
          <DeleteModal
            isOpen={isDeleteModalOpen}
            loading={deleteLoading}
            onClose={() => {
              if (!deleteLoading) {
                setIsDeleteModalOpen(false);
                setSelectedId(null);
                setSelectedRowData(null);
              }
            }}
            onConfirm={handleDelete}
          />
        )}

        {/* Activate Modal - Using ID */}
        {showActivateModal && selectedId && (
          <ActivateStatus
            isOpen={showActivateModal}
            loading={loadingToggle}
            onClose={() => {
              if (!loadingToggle) {
                setShowActivateModal(false);
                setSelectedId(null);
                setSelectedRowData(null);
              }
            }}
            onConfirm={handleActivate}
          />
        )}

        {/* Deactivate Modal - Using ID */}
        {showDeactivateModal && selectedId && (
          <DeactivateStatus
            isOpen={showDeactivateModal}
            loading={loadingToggle}
            onClose={() => {
              if (!loadingToggle) {
                setShowDeactivateModal(false);
                setSelectedId(null);
                setSelectedRowData(null);
              }
            }}
            onConfirm={handleDeactivate}
          />
        )}
      </div>
    </div>
  );
};

export default DealerMasterTable;