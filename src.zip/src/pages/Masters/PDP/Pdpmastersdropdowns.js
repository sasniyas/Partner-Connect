
import React, { useState } from "react";
const Pdpmastersdropdown = ({
  activeTab,
  setActiveTab,
 
}
) => {
  // PDP Master
  const [ismasterOpen, setIsMasterOpen] = useState(false);
  const [selected, setSelected] = useState({
    label: "PDP Master",
    defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/mynaui_file.png",
    hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/mynaui_file.png",
    activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/padpmastetrclick.png",
  });
  const [hoveredIndex, setHoveredIndex] = useState(null);

  const optionspdp = [
    {
      label: "Presentation Template",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/presentaiontemplate.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/presntaiontemplateactive.png",
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/presntaiontemplateactive.png",
    },
    {
      label: "Finance Template",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/financetemplate.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/financetemplateactive.png",
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/financetemplateactive.png",
    },
  ];

  const isCustomSelected = selected.label !== "PDP Master";

  // PDP Management
  const [ispdpmanagemnetOpen, setIsPdpmanagementOpen] = useState(false);
  const [selectedpdpmanagement, setSelectedpdpmangement] = useState({
    label: "PDP Data Management",
    defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/pdpdata mangement.png",
    hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/pdpmanagemnetactivation.png",
    activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/pdpmanagemnetactivation.png",
  });
  const [hoveredPdpIndex, setHoveredPdpIndex] = useState(null);

  const optionspdpmanagement = [
    {
      label:"Equipment Type",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/mynaui_file.png",
    hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/padpmastetrclick.png",
    activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/padpmastetrclick.png",
    },
    {
      label: "Equipment Master",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/equipmentmasterdefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/equipmemtmasteractive.png",
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/equipmemtmasteractive.png",
    },
    {
      label: "Uptime & Parts",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/uptimedefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/uptimeactive.png",
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/uptimeactive.png",
    },
    {
      label: "Infrastructure",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/infreastructuredefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/infrastructureactive.png",
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/infrastructureactive.png",
    },
    {
      label: "Competence Type",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/competencedefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/competenceactive.png",
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/competenceactive.png",
    },
    {
      label: "Competence Master",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/competencemasterdefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/competencemasteractive.png",
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/competencemasteractive.png",
    },
    {
      label: "Marcom Type",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/macrontypedefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/macrotypeactive.png",
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/macrotypeactive.png",
    },
    {
      label: "Marcom Master",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/macrontypedefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/macrotypeactive.png",
      activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/macrotypeactive.png",
    },
    {
      label: "Key Account Customer Type",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/keyaccounttypedefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/keyaccounttypeactive.png",
      activeIcon:"https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/keyaccounttypeactive.png" ,
    },
    {
      label: "Key Account Customer Master",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/keyaccounttypedefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/keyaccounttypeactive.png",
      activeIcon:"https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/keyaccounttypeactive.png" ,
    },
    {
      label: "National Key Accounts",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/nationalkeydefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/nationalkeyactive.png",
      activeIcon:"https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/nationalkeyactive.png" ,
    },
    {
      label: "Segment Priority",
      defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/prioritydefault.png",
      hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/priorityactive.png",
      activeIcon:"https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/priorityactive.png" ,
    }

  ];

  const isCustompdpmanagementSelected =
    selectedpdpmanagement.label !== "PDP Data Management";
//explorer
const [isexplorerOpen, setIsExplorerOpen] = useState(false);
const [selectedexplorer, setSelectedexplorer] = useState({
  label: "Explorer",
  defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/explorer.png",
  hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/exploreractive.png",
  activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/exploreractive.png",
});
const [hoveredexplorerIndex, setHoveredexplorerIndex] = useState(null);
const optionsexplorer = [
  {
    label:"PDP Data Explorer",
    defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/dataexplorerdefault.png",
  hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/exploreractive.png",
  activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/exploreractive.png"
  },
  {
    label: "PDP Fill Templates Explorer",
    defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/explorer.png",
    hoverIcon:"https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/exploreractive.png",
    activeIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/exploreractive.png",
  }]
  const isCustomexplorerSelected =
  selectedexplorer.label !== "Explorer";
// trendchart
const [istrendchartOpen, setIsTrendchartOpen] = useState(false);
const [selectedtrendchart, setSelectedtrendchart] = useState({
  label: "Trend Charts",
  defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/trendchart.png",
  hoverIcon: " https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/xaxismonthactive.png",
  activeIcon:  "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/xaxismonthactive.png"
});
const [hoveredtrendchartIndex, setHoveredtrendchartIndex] = useState(null);
const optionstrendchart = [
  {
    label:"X-axis Months",
    defaultIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/x-axismonthdefault.png",
  hoverIcon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/xaxismonthactive.png",
  activeIcon:  "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/xaxismonthactive.png"
  },]
  const isCustomtrendchartSelected =
  selectedtrendchart.label !== "Trend Charts";

  return (
    <div className="flex justify-center">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-10 gap-y-2">
        {/* PDP Master */}
        <div className="relative w-[270px] ">
          <img
            src={
              ismasterOpen
                ? selected.activeIcon || selected.defaultIcon
                : selected.defaultIcon
            }
            alt="icon"
            className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 transition-all ${
              selectedpdpmanagement.label !== "PDP Master"
                ? "contrast-150 drop-shadow-[0_0_1px_#000]"
                : ""
            }`}          />
          <div
            onClick={() => setIsMasterOpen(!ismasterOpen)}
            className={`pl-10 pr-8 py-2 cursor-pointer text-sm font-VolvoNovum relative rounded-lg shadow-lg transition-all
              ${
                ismasterOpen || isCustomSelected
                  ? "bg-ab/50 border border-mildBlue text-mildBlue border-none"
                  : "border border-black  text-black/70 hover:ring-1 hover:ring-gray-400"
              }
              ${ismasterOpen ? "rounded-b-none" : ""}
            `}
          >
<span className={`${isCustomSelected ? "font-semibold" : "font-normal"}`}>
  {selected.label}
</span>            <img
              src={
                ismasterOpen || selected.label !== "PDP Master"
                  ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/dropdownup.png"
                  : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/material-symbols-light_arrow-drop-down-rounded.png"
              }
              alt="dropdown-icon"
              className={`absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none ${
                ismasterOpen || selected.label !== "PDP Master"
                  ? "w-1.5 h-1"
                  : "w-5 h-5"
              }`}
            />
          </div>

          {ismasterOpen && (
            <ul className="absolute z-10 mt-0 bg-white border border-none rounded-t-none rounded-lg w-full shadow-md flex flex-col items-center py-2">
              {optionspdp.map((option, idx) => {
                const isSelected = activeTab === option.label;
                const isHovered = hoveredIndex === idx;
                const iconSrc = isSelected
                  ? option.activeIcon
                  : isHovered
                  ? option.hoverIcon
                  : option.defaultIcon;

                return (
                  <li
                    key={idx}
                    onClick={() => {
                      setSelected(option);
                      setActiveTab(option.label);
                      setIsMasterOpen(false);
                    }}
                    onMouseEnter={() => setHoveredIndex(idx)}
                    onMouseLeave={() => setHoveredIndex(null)}
                    className={`w-[90%] flex items-center gap-2 px-4 py-2 my-1 rounded-md cursor-pointer text-sm
                      border ${
                        isSelected
                          ? "border-mildBlue bg-ab/50 text-mildBlue"
                          : "border-black text-black bg-white"
                      }
                      ${
                        !isSelected &&
                        "hover:border-mildBlue hover:bg-ab/50 hover:text-mildBlue"
                      }`}
                  >
 <img
    src={iconSrc}
    alt="icon"
    className={`w-4 h-4 transition-all ${
      isSelected || isHovered ? "contrast-150 drop-shadow-[0_0_1px_#000]" : ""
    }`}
  />                    <span className={`${isSelected || isHovered ? "font-semibold" : "font-normal"}`}>
    {option.label}
  </span>                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {/* PDP Management */}
        <div className="relative w-[270px]">
          <img
            src={
              ispdpmanagemnetOpen
                ? selectedpdpmanagement.activeIcon ||
                  selectedpdpmanagement.defaultIcon
                : selectedpdpmanagement.defaultIcon
            }
            alt="icon"
            className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 transition-all ${
              selectedpdpmanagement.label !== "PDP Data Management"
                ? "contrast-150 drop-shadow-[0_0_1px_#000]"
                : ""
            }`}
          />
          <div
            onClick={() => setIsPdpmanagementOpen(!ispdpmanagemnetOpen)}
            className={`pl-10 pr-8 py-2 cursor-pointer text-sm font-VolvoNovum relative rounded-lg transition-all
              ${
                ispdpmanagemnetOpen || isCustompdpmanagementSelected
                  ? "bg-ab/50 border border-mildBlue text-mildBlue border-none"
                  : "border border-black text-black/70 hover:ring-1 hover:ring-gray-400"
              }
              ${ispdpmanagemnetOpen ? "rounded-b-none" : ""}
            `}
          >
            <span className={`${isCustompdpmanagementSelected ? "font-semibold" : "font-normal"}`}>
            {selectedpdpmanagement.label}
</span>
            {/* {selectedpdpmanagement.label} */}
            <img
              src={
                ispdpmanagemnetOpen ||
                selectedpdpmanagement.label !== "PDP Data Management"
                  ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/dropdownup.png"
                  : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/material-symbols-light_arrow-drop-down-rounded.png"
              }
              alt="dropdown-icon"
              className={`absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none ${
                ispdpmanagemnetOpen ||
                selectedpdpmanagement.label !== "PDP Data Management"
                  ? "w-1.5 h-1"
                  : "w-5 h-5"
              }`}
            />
          </div>

          {ispdpmanagemnetOpen && (
            // <ul className="absolute z-10 mt-0 bg-white border border-none rounded-t-none rounded-lg w-full shadow-md flex flex-col items-center py-2">
            <ul className="absolute z-10 mt-0 bg-white border border-none rounded-t-none rounded-lg w-full shadow-md flex flex-col items-center py-2 max-h-60 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100">

              {optionspdpmanagement.map((option, idx) => {
                const isSelected = activeTab.label === option.label;
                const isHovered = hoveredPdpIndex === idx;
                const iconSrc = isSelected
                  ? option.activeIcon
                  : isHovered
                  ? option.hoverIcon
                  : option.defaultIcon;

                return (
                  <li
                    key={idx}
                    onClick={() => {
                      setSelectedpdpmangement(option);
                      setActiveTab(option.label);
                      setIsPdpmanagementOpen(false);
                    }}
                    onMouseEnter={() => setHoveredPdpIndex(idx)}
                    onMouseLeave={() => setHoveredPdpIndex(null)}
                    className={`w-[90%] flex items-center gap-2 px-4 py-2 my-1 rounded-md cursor-pointer text-sm
                      border ${
                        isSelected
                          ? "border-mildBlue bg-ab/50 text-mildBlue"
                          : "border-black text-black bg-white"
                      }
                      ${
                        !isSelected &&
                        "hover:border-mildBlue hover:bg-ab/50 hover:text-mildBlue"
                      }`}
                  >
                    <img
    src={iconSrc}
    alt="icon"
    className={`w-4 h-4 transition-all ${
      isSelected || isHovered ? "contrast-150 drop-shadow-[0_0_1px_#000]" : ""
    }`}
  />
                    <span className={`${isSelected || isHovered ? "font-semibold" : "font-normal"}`}>

                    {option.label}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

               {/* explorer */}
        <div className="relative w-[270px]">
          <img
            src={
              isexplorerOpen
                ? selectedexplorer.activeIcon ||
                  selectedexplorer.defaultIcon
                : selectedexplorer.defaultIcon
            }
            alt="icon"
            className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 transition-all ${
              selectedexplorer.label !== "Explorer"
                ? "contrast-150 drop-shadow-[0_0_1px_#000]"
                : ""
            }`}
          />
          <div
          onClick={() => setIsExplorerOpen(!isexplorerOpen)}
            className={`pl-10 pr-8 py-2 cursor-pointer text-sm font-VolvoNovum relative rounded-lg transition-all
              ${
                isexplorerOpen || isCustomexplorerSelected
                  ? "bg-ab/50 border border-mildBlue text-mildBlue border-none"
                  : "border border-black text-black/70 hover:ring-1 hover:ring-gray-400"
              }
              ${isexplorerOpen ? "rounded-b-none" : ""}
            `}
          >
            <span className={`${isCustomexplorerSelected ? "font-semibold" : "font-normal"}`}>
            {selectedexplorer.label}
</span>
            {/* {selectedpdpmanagement.label} */}
            <img
              src={
              isexplorerOpen ||
                selectedexplorer.label !== "Explorer"
                  ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/dropdownup.png"
                  : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/material-symbols-light_arrow-drop-down-rounded.png"
              }
              alt="dropdown-icon"
              className={`absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none ${
                isexplorerOpen ||
               selectedexplorer.label !== "Explorer"
                  ? "w-1.5 h-1"
                  : "w-5 h-5"
              }`}
            />
          </div>

          {isexplorerOpen && (
            <ul className="absolute z-10 mt-0 bg-white border border-none rounded-t-none rounded-lg w-full shadow-md flex flex-col items-center py-2">
              {optionsexplorer.map((option, idx) => {
                const isSelected = activeTab.label === option.label;
                const isHovered = hoveredexplorerIndex === idx;
                const iconSrc = isSelected
                  ? option.activeIcon
                  : isHovered
                  ? option.hoverIcon
                  : option.defaultIcon;

                return (
                  <li
                    key={idx}
                    onClick={() => {
                     setSelectedexplorer(option);
                     setActiveTab(option.label);
                      setIsExplorerOpen(false);
                    }}
                    onMouseEnter={() => setHoveredexplorerIndex(idx)}
                    onMouseLeave={() => setHoveredexplorerIndex(null)}
                    className={`w-[90%] flex items-center gap-2 px-4 py-2 my-1 rounded-md cursor-pointer text-sm
                      border ${
                        isSelected
                          ? "border-mildBlue bg-ab/50 text-mildBlue"
                          : "border-black text-black bg-white"
                      }
                      ${
                        !isSelected &&
                        "hover:border-mildBlue hover:bg-ab/50 hover:text-mildBlue"
                      }`}
                  >
                    <img
    src={iconSrc}
    alt="icon"
    className={`w-4 h-4 transition-all ${
      isSelected || isHovered ? "contrast-150 drop-shadow-[0_0_1px_#000]" : ""
    }`}
  />
                    <span className={`${isSelected || isHovered ? "font-semibold" : "font-normal"}`}>

                    {option.label}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {/* trendchart */}
        <div className="relative w-[270px]">
          <img
            src={
              istrendchartOpen
                ?selectedtrendchart.activeIcon ||
                selectedtrendchart.defaultIcon
                : selectedtrendchart.defaultIcon
            }
            alt="icon"
            className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 transition-all ${
             selectedtrendchart.label !== "Trend Charts"
                ? "contrast-150 drop-shadow-[0_0_1px_#000]"
                : ""
            }`}
          />
          <div
          onClick={() => setIsTrendchartOpen(!istrendchartOpen)}
            className={`pl-10 pr-8 py-2 cursor-pointer text-sm font-VolvoNovum relative rounded-lg transition-all
              ${
                istrendchartOpen || isCustomtrendchartSelected
                  ? "bg-ab/50 border border-mildBlue text-mildBlue border-none"
                  : "border border-black text-black/70 hover:ring-1 hover:ring-gray-400"
              }
              ${istrendchartOpen ? "rounded-b-none" : ""}
            `}
          >
            <span className={`${isCustomtrendchartSelected ? "font-semibold" : "font-normal"}`}>
            {selectedtrendchart.label}
</span>
            {/* {selectedpdpmanagement.label} */}
            <img
              src={
              istrendchartOpen ||
                selectedtrendchart.label !== "Trend Charts"
                  ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpHomepage/dropdownup.png"
                  : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/material-symbols-light_arrow-drop-down-rounded.png"
              }
              alt="dropdown-icon"
              className={`absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none ${
                istrendchartOpen ||
               selectedtrendchart.label !== "Trend Charts"
                  ? "w-1.5 h-1"
                  : "w-5 h-5"
              }`}
            />
          </div>

          {istrendchartOpen&& (
            <ul className="absolute z-10 mt-0 bg-white border border-none rounded-t-none rounded-lg w-full shadow-md flex flex-col items-center py-2">
              {optionstrendchart.map((option, idx) => {
                const isSelected = activeTab.label === option.label;
                const isHovered = hoveredtrendchartIndex === idx;
                const iconSrc = isSelected
                  ? option.activeIcon
                  : isHovered
                  ? option.hoverIcon
                  : option.defaultIcon;

                return (
                  <li
                    key={idx}
                    onClick={() => {
                     setSelectedtrendchart(option);
                     setActiveTab(option.label);
                      setIsTrendchartOpen(false);
                    }}
                    onMouseEnter={() => setHoveredtrendchartIndex(idx)}
                    onMouseLeave={() => setHoveredtrendchartIndex(null)}
                    className={`w-[90%] flex items-center gap-2 px-4 py-2 my-1 rounded-md cursor-pointer text-sm
                      border ${
                        isSelected
                          ? "border-mildBlue bg-ab/50 text-mildBlue"
                          : "border-black text-black bg-white"
                      }
                      ${
                        !isSelected &&
                        "hover:border-mildBlue hover:bg-ab/50 hover:text-mildBlue"
                      }`}
                  >
                    <img
    src={iconSrc}
    alt="icon"
    className={`w-4 h-4 transition-all ${
      isSelected || isHovered ? "contrast-150 drop-shadow-[0_0_1px_#000]" : ""
    }`}
  />
                    <span className={`${isSelected || isHovered ? "font-semibold" : "font-normal"}`}>

                    {option.label}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
      
    </div>
  );
};

export default Pdpmastersdropdown;
