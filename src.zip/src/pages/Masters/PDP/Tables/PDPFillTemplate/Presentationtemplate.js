import { useState, useEffect, useRef, useCallback } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus, ArrowRight } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import Filter from "../../../../../Components/Filter"
import DeleteModal from "../../../../../Components/DeleteModal"
import { Folder } from "lucide-react"
 import ExcelJS from "exceljs";
 import * as XLSX from "xlsx"
import { useMemo } from "react"
import { saveAs } from "file-saver";
import { ChevronDown } from "lucide-react"
import { ChevronUp } from "lucide-react"
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
import {
  addDeafultPreTemplate,
  getDeafultPreTemplate,
  addPresentationTemplate,
  getPresentationTemplates,
  updatePresentationTemplate,
  deletePresentationTemplate
} from "../../../../../services/pdpMaster/presentationTemplate.service";
import {
  addPresentationTemplateCategory,
  getCategoriesByPresentationTemplateId,
  updatePresentationTemplateCategory,
  deletePresentationTemplateCategory
} from "../../../../../services/pdpMaster/presentationTemplateCategory.service";
 import {uploadTempFile} from "../../../../../services/download/bluckDownload.service"
import useCRUDWithReset from "../../../../../util/useCRUDWithReset"
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation"
function PresentationTemplate() {
  const [selectedYears, setSelectedYears] = useState([]) // store multiple years
const categoryRef = useRef(null);

  const [menuOpen, setMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const [catagorySuggestions, setCatagorySuggestions] = useState("")
  const dropdownRef = useRef(null)
  const [tableData, setTableData] = useState([])
  const [formData, setFormData] = useState({ year: "", category: "", file: "", page: "" })
  const [isEditing, setIsEditing] = useState(false)
  const [editIndex, setEditIndex] = useState(null)
  const [errors, setErrors] = useState({})
  const [yearOptions, setYearOptions] = useState([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedYear, setSelectedYear] = useState("")
  const [showViewPopup, setShowViewPopup] = useState(false);
  const [showModal, setShowModal] = useState(false)
  const [categoryName, setCategoryName] = useState("")
  const [pageNumber, setPageNumber] = useState("")
  const [selectedRowIndex, setSelectedRowIndex] = useState(null)
  const [deleteIndex, setDeleteIndex] = useState(null); // to track which row to delete
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [selectedCategoryOption, setSelectedCategoryOption] = useState("");
  const [showViewTemplatesModal, setShowViewTemplatesModal] = useState(false)
  const [editingIndex, setEditingIndex] = useState(null);
  const [editedCategory, setEditedCategory] = useState("");
  const [editedPage, setEditedPage] = useState("");
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const fileInputRef = useRef(null)
  const [fileError, setFileError] = useState("");
  const [categorySearch, setCategorySearch] = useState("");
const [hoveredCell, setHoveredCell] = useState(null);
const [modalSortKey, setModalSortKey] = useState(null);
const [modalSortOrder, setModalSortOrder] = useState(null);
const [hoveredcategoryCell, setHoveredcategoryCell] = useState(null);
const popupRef = useRef (null)


  // API integration states
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [apiError, setApiError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [showUploadPopup, setShowUploadPopup] = useState(false);

  // Main table lazy loading states
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const observerRef = useRef();

  // Modal table lazy loading states
  const [displayedTemplates, setDisplayedTemplates] = useState([]);
  const [hasMoreTemplates, setHasMoreTemplates] = useState(true);
  const [isLoadingTemplates, setIsLoadingTemplates] = useState(false);
  const templateObserverRef = useRef();
  // ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };
  const handleDragOverTemplate = (e) => {
  e.preventDefault();
  e.stopPropagation();
};

const handleDropTemplate = (e) => {
  e.preventDefault();
  e.stopPropagation();

  const file = e.dataTransfer.files?.[0];
  if (file) {
    setDefFormData((prev) => ({
      ...prev,
      serverFileUrl: file.name,
      fileObject: file,
    }));
  }
};
const handleDragOverSample = (e) => {
  e.preventDefault();
  e.stopPropagation();
};

const handleDropSample = (e) => {
  e.preventDefault();
  e.stopPropagation();

  const file = e.dataTransfer.files?.[0];
  if (file) {
    setFormData({ ...formData, file: file }); // store full file object
  }
};
  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
const handleModalSort = (key) => {
  if (modalSortKey === key) {
    if (modalSortOrder === "asc") {
      setModalSortOrder("desc");
      return;
    } else if (modalSortOrder === "desc") {
      setModalSortKey(null);
      setModalSortOrder(null);
      return;
    }
  }
  setModalSortKey(key);
  setModalSortOrder("asc");
};

    const [defformData, setDefFormData] = useState({
      url: "",
      fileObject: null,
      serverFileUrl: ""
    });
  
  
    // Load existing file when popup opens
    useEffect(() => {
      if (showUploadPopup) {
        getDeafultPreTemplate()
          .then((data) => {
            setDefFormData({
              url: data?.url || "",
              serverFileUrl: data?.url || "",
              fileObject: null
            });
          })
          .catch(() => {
            setDefFormData({
              url: "",
              serverFileUrl: "",
              fileObject: null
            });
          });
      }
    }, [showUploadPopup]);
useEffect(() => {
  const handleClickOutside = (e) => {
    if (categoryRef.current && !categoryRef.current.contains(e.target)) {
      setCatagorySuggestions(false);
      setCategorySearch("");  
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);

  const itemsPerLoad = 10;
  const templatesPerLoad = 5;

  // Data transformation function to map backend data to frontend format
  const transformBackendData = (backendData) => {
    if (!Array.isArray(backendData)) {
      // console.error("Backend data is not an array:", backendData);
      return [];
    }

    return backendData.map((item) => ({
      id: item.id,
      year: item.year ? item.year.toString() : '',
      category: item.presentation_template || '',
      file: item.sample_file || '',
      isActive: item.isActive,
      createdOn: item.createdOn,
      templates: [] // Initialize empty templates array
    }));
  };

  // Transform category data from backend to frontend format
  const transformCategoryData = (categoryData) => {
    if (!categoryData || !Array.isArray(categoryData)) {
      return [];
    }

    return categoryData.map(category => ({
      id: category.id,
      categoryName: category.category_name,
      pageNumber: category.page_number,
      presentationTemplateId: category.presentation_template_id,
      createdOn: category.createdOn
    }));
  };

  // Fetch data from API
  const fetchPresentationTemplates = async () => {
    try {
      setIsLoadingData(true);
      setApiError("");
      const data = await getPresentationTemplates();
      const transformedData = transformBackendData(data);

      // Fetch categories for each template
      const templatesWithCategories = await Promise.all(
        transformedData.map(async (template) => {
          try {
            // Check if template.id exists and is valid
            if (!template.id || template.id === undefined || template.id === null || template.id === 'undefined') {
              return {
                ...template,
                templates: []
              };
            }

            // Additional validation for numeric IDs
            if (isNaN(template.id) || template.id <= 0) {
              return {
                ...template,
                templates: []
              };
            }

            const categories = await getCategoriesByPresentationTemplateId(template.id);
            const transformedCategories = transformCategoryData(categories);

            return {
              ...template,
              templates: transformedCategories
            };
          } catch (error) {
            // console.error(`Error fetching categories for template ${template.id}:`, error);
            return {
              ...template,
              templates: []
            };
          }
        })
      );

      setTableData(templatesWithCategories);
    } catch (error) {
      // console.error("Error fetching presentation templates:", error);
      setApiError(error.message || "Failed to fetch presentation templates");
    } finally {
      setIsLoadingData(false);
    }
  };

  const filteredData = tableData.filter((item) => {
    const search = searchQuery.toLowerCase();

    const matchesSearch =
      item.year?.toString().toLowerCase().includes(search) ||
      item.category?.toLowerCase().includes(search) ||
      item.file?.toLowerCase().includes(search);

    const matchesYear =
      selectedYears.length > 0
        ? selectedYears.includes(String(item.year))
        : true;

    return matchesSearch && matchesYear;
  });
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};

const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const valA = (a[sortKey] || "").toString().toLowerCase();
    const valB = (b[sortKey] || "").toString().toLowerCase();

    return sortOrder === "asc"
      ? valA.localeCompare(valB)
      : valB.localeCompare(valA);
  });
}, [filteredData, sortKey, sortOrder]);
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchQuery: { setter: setSearchQuery, resetValue: "" },
    selectedYears: { setter: setSelectedYears, resetValue: [] }
  }
);


 const loadMoreItems = useCallback(() => {
  if (isLoading || !hasMore) return;

  setIsLoading(true);

  setTimeout(() => {
    const currentLength = displayedItems.length;
    const nextItems = sortedData.slice(
      currentLength,
      currentLength + itemsPerLoad
    );

    if (nextItems.length === 0) {
      setHasMore(false);
    } else {
      setDisplayedItems(prev => [...prev, ...nextItems]);
    }

    setIsLoading(false);
  }, 300);
}, [displayedItems.length, sortedData, isLoading, hasMore]);

  // Main table intersection Observer callback
  const lastItemRef = useCallback(node => {
    if (isLoading) return;
    if (observerRef.current) observerRef.current.disconnect();

    observerRef.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        loadMoreItems();
      }
    });

    if (node) observerRef.current.observe(node);
  }, [isLoading, hasMore, loadMoreItems]);

  // Modal template lazy loading function
  const loadMoreTemplates = useCallback(() => {
    if (isLoadingTemplates || !hasMoreTemplates || selectedRowIndex === null) return;

    setIsLoadingTemplates(true);

    setTimeout(() => {
      const templates = tableData[selectedRowIndex]?.templates || [];
      const currentLength = displayedTemplates.length;
      const nextTemplates = templates.slice(currentLength, currentLength + templatesPerLoad);

      if (nextTemplates.length === 0) {
        setHasMoreTemplates(false);
      } else {
        setDisplayedTemplates(prev => [...prev, ...nextTemplates]);
      }

      setIsLoadingTemplates(false);
    }, 200); // Small delay to simulate loading
  }, [displayedTemplates.length, tableData, selectedRowIndex, isLoadingTemplates, hasMoreTemplates]);
const sortedTemplates = useMemo(() => {
  if (!modalSortKey || !modalSortOrder) return displayedTemplates;

  return [...displayedTemplates].sort((a, b) => {
    if (modalSortKey === "pageNumber") {
      return modalSortOrder === "asc"
        ? Number(a.pageNumber) - Number(b.pageNumber)
        : Number(b.pageNumber) - Number(a.pageNumber);
    }

    const valA = (a[modalSortKey] || "").toString().toLowerCase();
    const valB = (b[modalSortKey] || "").toString().toLowerCase();

    return modalSortOrder === "asc"
      ? valA.localeCompare(valB)
      : valB.localeCompare(valA);
  });
}, [displayedTemplates, modalSortKey, modalSortOrder]);

  // Modal template intersection observer callback
  const lastTemplateRef = useCallback(node => {
    if (isLoadingTemplates) return;
    if (templateObserverRef.current) templateObserverRef.current.disconnect();

    templateObserverRef.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMoreTemplates) {
        loadMoreTemplates();
      }
    });

    if (node) templateObserverRef.current.observe(node);
  }, [isLoadingTemplates, hasMoreTemplates, loadMoreTemplates]);

  // Reset displayed items when search or filters change
  useEffect(() => {
    setDisplayedItems(filteredData.slice(0, itemsPerLoad));
    setHasMore(filteredData.length > itemsPerLoad);
  }, [searchQuery, tableData, selectedYears]);

  // Reset displayed templates when modal opens or selectedRowIndex changes
  useEffect(() => {
    if (selectedRowIndex !== null && showViewTemplatesModal) {
      const templates = tableData[selectedRowIndex]?.templates || [];
      setDisplayedTemplates(templates.slice(0, templatesPerLoad));
      setHasMoreTemplates(templates.length > templatesPerLoad);
    }
  }, [selectedRowIndex, showViewTemplatesModal, tableData]);

  // Initial load
  useEffect(() => {
    setDisplayedItems(filteredData.slice(0, itemsPerLoad));
    setHasMore(filteredData.length > itemsPerLoad);
  }, []);

  // Fetch data on component mount
  useEffect(() => {
    fetchPresentationTemplates();
  }, []);

  // Auto-dismiss success messages
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => {
        setSuccessMessage("");
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);


  const handleBulkUploadClick = () => {
    fileInputRef.current.click()
  }

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  useEffect(() => {
    const years = [...new Set(tableData.map((item) => item.year))].sort((a, b) => Number(a) - Number(b))
    setYearOptions(years)
  }, [tableData])



const handleDownloadTemplate = async () => {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Presentation Template");

  // ================= COLUMNS =================
  sheet.columns = [
    { header: "Year", key: "year", width: 20 },
    { header: "Presentation Template", key: "template", width: 30 },
  ];

  // ================= COLUMN ALIGNMENT (ALWAYS LEFT) =================
  sheet.columns.forEach((column) => {
    column.alignment = {
      vertical: "middle",
      horizontal: "left",
      wrapText: true,
    };
  });

  // ================= SAMPLE ROW =================
  sheet.addRow({
    year: "2025",
    template: "Sample Template",
  });

  // ================= UNLOCK ALL COLUMNS =================
  sheet.columns.forEach((column) => {
    column.protection = { locked: false };
  });

  // ================= LOCK HEADER ROW =================
  const headerRow = sheet.getRow(1);
  headerRow.eachCell((cell) => {
    cell.protection = { locked: true };
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FF476896" },
    };
  });

  // ================= DATA VALIDATIONS =================
  sheet.dataValidations.add("A2:A5000", {
    type: "custom",
    allowBlank: false,
    formulae: ['LEN(TRIM(A2))>0'],
    showErrorMessage: true,
    errorTitle: "Year is required",
    error: "Please enter Year",
  });

  sheet.dataValidations.add("B2:B5000", {
    type: "custom",
    allowBlank: false,
    formulae: ['LEN(TRIM(B2))>0'],
    showErrorMessage: true,
    errorTitle: "Presentation Template is required",
    error: "Please enter Presentation Template",
  });

  // ================= PROTECT SHEET =================
  await sheet.protect("12345", {
    selectLockedCells: true,
    selectUnlockedCells: true,
    insertRows: true,
    deleteRows: true,
    formatColumns: true,
    formatRows: true,
  });

  // ================= EXPORT =================
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  saveAs(blob, "Presentation_Template_Bulk_Upload_Template.xlsx");
};


const handleBulkUpload = (e) => {
  const file = e.target.files[0];
  if (!file) return;

  // Open preview tab first (popup-safe)
  const previewTab = window.open(
   "/bulkupload/presentaiontemplate",
    "_blank"
  );

  if (!previewTab) {
    // alert("Popup blocked! Please allow popups.");
    return;
  }

  const reader = new FileReader();

  reader.onload = (event) => {
    const data = new Uint8Array(event.target.result);
    const workbook = XLSX.read(data, { type: "array" });
    const sheetName = workbook.SheetNames[0];

    let rows = XLSX.utils.sheet_to_json(
      workbook.Sheets[sheetName],
      { defval: "" }
    );

    // Remove empty rows
    rows = rows.filter((row) =>
      Object.values(row).some((v) => v !== "")
    );

    // Validate required fields
    const finalRows = rows.map((row, index) => ({
      slNo: index + 1,
      year: row["Year"] || "",
      template: row["Presentation Template"] || "",
      hasError: !row["Year"] || !row["Presentation Template"],
    }));

    // Send to preview page
    previewTab.postMessage(
      {
        type: "PRESENTATION_TEMPLATE_PREVIEW",
        payload: { rows: finalRows },
      },
      "*"
    );
  };

  reader.readAsArrayBuffer(file);
};


 const handlePreviewAndDownload = async () => {
  if (!displayedItems || displayedItems.length === 0) {
    // alert("No data available to upload");
    return;
  }

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Presentation Templates");

  // ================= HEADERS =================
  sheet.columns = [
    { header: "Sl. No", key: "slNo", width: 10 },
    { header: "Year", key: "year", width: 15 },
    { header: "Category", key: "category", width: 50 },
    { header: "File", key: "file", width: 100 },
    { header: "Status", key: "status", width: 15 },
  ];

  // ================= HEADER STYLE =================
  sheet.getRow(1).eachCell((cell) => {
    cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
    cell.alignment = { vertical: "middle", horizontal: "left" };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FF476896" },
    };
  });

  // ================= DATA ROWS =================
  displayedItems.forEach((item, index) => {
    const row = sheet.addRow({
      slNo: index + 1,
      year: item.year,
      category: item.category,
      file: item.file,
      status: item.isActive ? "Active" : "Inactive",
    });

    row.eachCell((cell) => {
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });
  });

  // ================= CREATE FILE (NO DOWNLOAD) =================
  const buffer = await workbook.xlsx.writeBuffer();

  const blob = new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  const file = new File(
    [blob],
    "Presentation_Template_List.xlsx",
    {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }
  );

  // ================= UPLOAD FILE =================
  try {
    const response = await  uploadTempFile (file);
const fileUrl = response ? `https://view.officeapps.live.com/op/view.aspx?src=${response} `:null;  
  if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    } else {
      // console.warn("Upload succeeded but no file URL returned");
    }
  } catch (error) {
    // console.error("Upload failed:", error);
  }
};


  // 1. This handles the selected Excel file
  const handleExcelUpload = (file) => {
    // console.log("Valid Excel file:", file);
    // your upload/parse logic here
  };

  // 2. This runs when clicking "Bulk Upload"
  const openExcelPicker = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".xlsx, .xls";

    input.onchange = (e) => {
      const file = e.target.files?.[0];
      if (
        file &&
        (file.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
          file.type === "application/vnd.ms-excel" ||
          file.name.endsWith(".xlsx") ||
          file.name.endsWith(".xls"))
      ) {
        handleExcelUpload(file); // ✅ Only handle upload here
      } else {
        // console.warn("Please upload a valid Excel file");
      }
    };

    input.click(); // ✅ only here
    setOpen(false);
  };
useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
    // trigger the SAME logic as Save button
    document.getElementById("saveTemplateBtn")?.click();
  },

  onCancel: () => {
    setIsAddUserOpen(false);
    setIsEditing(false);
    setFormData({ year: "", category: "", file: "", page: "" });
    setErrors({});
  },
});

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full   transition-all duration-300 ease-in-out ">
            {/* 🔹 Heading */}
            <div className="flex items-center justify-between mb-2 flex-wrap gap-4">
              <h2 className="text-base font-medium font-VolvoNovum text-center text-darkblue1 flex items-center justify-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1  p-1"
                />
                PDP Fill Templates / Presentation Template
              </h2>
              {/* Upload PPT Master Template Button */}
             <div className="flex gap-3">
  {/* Upload Button */}
  <button
    onClick={() => setShowUploadPopup(true)}
    className="bg-darkblue1 text-white font-medium text-xs px-4 py-1.5 transition hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1"
  >
    Upload Presentation Template
  </button>

  {/* View Button */}
  <button
    onClick={() => setShowViewPopup(true)}
    className="bg-darkblue1 text-white font-medium text-xs px-4 py-1.5 transition hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1"
  >
    View Presentation Template
  </button>
</div>

    {showUploadPopup && (

<div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">

<div
ref={popupRef}
onDragOver={handleDragOverTemplate}
onDrop={handleDropTemplate}
className="bg-white w-[35%] shadow-lg p-6 relative"
>

{/* Close */}

<button
onClick={()=>{
setShowUploadPopup(false)
setFileError("")
}}
className="absolute top-2 right-2"
>

<svg width="14" height="14" viewBox="0 0 20 20">
<circle cx="10" cy="10" r="8" fill="#BF2012"/>
<path d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5" stroke="white" strokeWidth="2"/>
</svg>

</button>

<h2 className="text-base font-semibold text-center mb-5 text-MediumGrey">
Upload Presentation Template
</h2>

{/* File Row */}

<div className="flex gap-2">

<input
type="text"
readOnly
value={defformData.fileObject ? defformData.fileObject.name : ""}
placeholder="Drag & Drop or Upload File"
className={`flex-1 border px-2 py-1 text-xs outline-none ${
fileError ? "border-red1" : "border-black/30"
}`}
/>

<button
type="button"
onClick={()=>fileInputRef.current.click()}
className="bg-darkblue1 text-white px-3 py-1 text-xs"
>
Upload
</button>

</div>

{/* Error */}

{fileError && (
<p className="text-red1 text-xs mt-1 ml-1">
{fileError}
</p>
)}

{/* Hidden File Input */}

<input
type="file"
ref={fileInputRef}
accept=".ppt,.pptx,.xlsx,.csv"
hidden
onChange={(e)=>{

const file = e.target.files[0]

if(file){

setDefFormData(prev=>({
...prev,
fileObject:file,
serverFileUrl:file.name
}))

setFileError("")

}

}}
/>

{/* Save Button */}

<button
id="saveTemplateBtn"
type="button"
onClick={async ()=>{

if(!defformData.fileObject){
setFileError("Please upload a file")
return
}

try{

setIsLoadingData(true)

const res = await addDeafultPreTemplate(
{financeTemplate: defformData.url},
defformData.fileObject
)

setDefFormData(prev=>({
...prev,
serverFileUrl: res
}))

setShowUploadPopup(false)

}
finally{
setIsLoadingData(false)
}

}}

className={`mt-6 text-xs px-8 py-1.5 block mx-auto ${
isLoadingData
? "bg-gray-400 text-white cursor-not-allowed"
: "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
}`}
>

{isLoadingData ? "Saving..." : "Save"}

</button>

</div>
</div>

)}
{showViewPopup && (

<div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">

<div className="bg-white w-[35%] shadow-lg p-6 relative">

{/* Close */}
<button
onClick={()=>setShowViewPopup(false)}
className="absolute top-2 right-2"
>

<svg width="14" height="14" viewBox="0 0 20 20">
<circle cx="10" cy="10" r="8" fill="#BF2012"/>
<path d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5" stroke="white" strokeWidth="2"/>
</svg>

</button>

<h2 className="text-base font-semibold text-center mb-5 text-MediumGrey">
View Presentation Template
</h2>

{/* File Row */}
<div className="flex gap-2">

<input
type="text"
readOnly
value={defformData.serverFileUrl || ""}
placeholder="No template uploaded"
className="flex-1 border border-black/30 px-2 py-1 text-xs"
/>

<button
onClick={()=>{
if(defformData.serverFileUrl){
window.open(defformData.serverFileUrl,"_blank")
}
}}
className="bg-darkblue1 text-white font-medium text-xs px-4 py-1.5"
>

View

</button>

</div>

</div>
</div>

)}
            </div>
            {/* 🔹 Error and Success Messages */}
            {apiError && (
              <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 ">
                {apiError}
              </div>
            )}
            {successMessage && (
              <div className="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 ">
                {successMessage}
              </div>
            )}


            {/* 🔹 Controls: Search + Filters + Actions */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 md:gap-12 lg:gap-18 mb-2">
              <div className="flex flex-col sm:flex-row items-center gap-2 w-full sm:w-auto">              {/* Left: Search + Filter */}

                <Searchinput
                  onChange={(e) => {
                    setSearchQuery(e.target.value)
                  }}
                  value={searchQuery}
                  placeholder="Search"
                  className="w-[1/2]"
                  iconColor="text-black"
                  bgColor="bg-FrostWhite"
                  borderColor="border-black/60"
                  textColor="text-black"
                  shadow="shadow-none"
                  inputPadding="pl-6 pr-3 py-1.5"
                  iconSize="w-3 h-3"
                  iconLeft="left-3"
                  inputWidth="w-full"
                  focusRing="focus:ring-1 focus:ring-black/60"
                  hoverInputClasses="hover:bg-white hover:border-black/60"
                />

                <Filter
                  name="year"
                  className="" // reduce button width inside container
                  placeholder="Year"
                  options={yearOptions} // dynamic options
                  placeholderColor="text-black"
                  customWidth="w-[120px]"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black"
                  openBgColor="bg-white"
                  textColor="text-black"
                  value={selectedYears} // match prop name inside Filter
                  onChange={(name, newSelectedYears) => {
                    setSelectedYears(newSelectedYears) // update the array
                  }}
                />


              </div>
              {/* Right: Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                {/* Add Dropdown */}
                <div className="relative w-full sm:w-[190px]" ref={dropdownRef}>
                  <button
                    onClick={() => setOpen(!open)}
                    className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-1.5 text-xs  flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
                  >
                    <Plus className="w-3 h-3 stroke-[3]" />
                    Add New
                  </button>
                  {open && (
                    <div className="absolute top-full left-1/2 mt-1 w-max min-w-full -translate-x-1/2 bg-white border border-darkblue1  shadow-lg z-50">
                      <button
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                        onClick={() => {
                          setIsAddUserOpen(true)
                          setOpen(false)
                        }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
<g clip-path="url(#clip0_1415_1571)">
<path d="M13.0888 12.4253H2.91051M11.9814 12.4253V15.2024M4.01794 15.2024V12.4253M12.5277 9.90871C13.5322 9.81499 14.3219 9.14985 14.4305 8.30871C14.4305 8.30871 14.6785 7.34871 14.6785 5.47785C14.6785 3.60699 14.4305 2.64471 14.4305 2.64471C14.3208 1.80471 13.5322 1.13957 12.5277 1.04471C11.0694 0.907566 9.46823 0.797852 8.0008 0.797852C6.53223 0.797852 4.93109 0.906423 3.47051 1.04471C2.46594 1.13957 1.67737 1.80471 1.56766 2.64471C1.56766 2.64471 1.3208 3.60471 1.3208 5.47671C1.3208 7.34871 1.56766 8.30985 1.56766 8.30985C1.67737 9.14985 2.46594 9.81499 3.47051 9.90985" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M4.96094 12.4248C4.96094 11.6625 5.03751 10.8625 5.51979 10.2705C5.81894 9.90068 6.19675 9.60222 6.62576 9.39681C7.05476 9.1914 7.52415 9.08421 7.99979 9.08304C8.99751 9.08304 9.88894 9.5459 10.4798 10.2716C10.9621 10.8625 11.0387 11.6625 11.0387 12.4248M7.99979 7.19733C9.16894 7.19733 9.82608 6.54018 9.82608 5.37104C9.82608 4.2019 9.16894 3.5459 7.99979 3.5459C6.83065 3.5459 6.17351 4.20304 6.17351 5.37104C6.17351 6.53904 6.83065 7.19733 7.99979 7.19733Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
<clipPath id="clip0_1415_1571">
<rect width="16" height="16" fill="white"/>
</clipPath>
</defs>
</svg>
                        Add Presentation
                      </button>
                   <button
        onClick={() => navigate("/bulkupload/presentaiontemplate")}
        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1.5"
      >
       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>

        Bulk Upload
      </button>

  <input
    type="file"
    ref={fileInputRef}
    className="hidden"
    accept=".xlsx,.xls"
    onChange={handleBulkUpload}
  />

          
                      <button
                        onClick={handleDownloadTemplate}

                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2  whitespace-nowrap"
                      >
<svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

                        Bulk upload Template
                      </button>
                    </div>
                  )}
                </div>
                {/* Download Button */}
                <button
                  onClick={handlePreviewAndDownload}
                  className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1 flex items-center gap-2 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
<path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D"/>
</svg>
           
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"className="w-3 h-3 hidden group-hover:block">
<path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white"/>
</svg>

                  <span className="font-semibold">Download</span>
                </button>
              </div>
            </div>

            {/* 🔹 Table Section with Lazy Loading - RESPONSIVE (SIZES UNCHANGED) */}
<div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
  <div
  ref={tableContainerRef}
    className="
      overflow-y-auto overflow-x-auto
    "
    style={{
      scrollbarWidth: "none",
      msOverflowStyle: "none",
      maxHeight: sortedData.length > 8 ? "calc(100vh - 240px)" : "auto"
    }}
    onScroll={handleTableScroll}
  >
    <style jsx>{`
      div::-webkit-scrollbar {
        display: none;
      }
    `}</style>

    <table className="w-full text-sm whitespace-nowrap cursor-pointer border-collapse">
      <thead className="bg-Dustyblue text-white sticky top-0 z-10">
        <tr>
          {/* Year - w-[10%] */}
          <th
            className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
            onClick={() => handleSort("year")}
          >
            <div className="flex items-center gap-1">
              Year
              {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}


              {sortKey === "year" && sortOrder === "asc" && (
                <ChevronUp className="w-3 h-3" />
              )}
              {sortKey === "year" && sortOrder === "desc" && (
                <ChevronDown className="w-3 h-3" />
              )}
            </div>
          </th>

          {/* Presentation Template - w-[10%] */}
          <th
            onClick={() => handleSort("category")}
            className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
          >
            <div className="flex items-center gap-1">
              Presentation Template
              {sortKey === "category" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
              {sortKey === "category" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
            </div>
          </th>

          {/* File - w-[40%] */}
          <th
            className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%] cursor-pointer select-none"
            onClick={() => handleSort("file")}
          >
            <div className="flex items-center gap-1">
              File
              {sortKey === "file" && sortOrder === "asc" && (
                <ChevronUp className="w-3 h-3" />
              )}
              {sortKey === "file" && sortOrder === "desc" && (
                <ChevronDown className="w-3 h-3" />
              )}
            </div>
          </th>

          {/* Actions - w-[10%] */}
          <th className="text-center py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 w-[10%]">
            Actions
          </th>
        </tr>
      </thead>

      <tbody className="text-black">
        {isLoadingData ? (
          <tr>
            <td colSpan={4} className="px-4 py-6 text-center">
              <div className="flex items-center justify-center gap-2">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-darkblue1"></div>
                <span className="text-gray-600">Loading presentation templates...</span>
              </div>
            </td>
          </tr>
        ) : sortedData.length > 0 ? (
          sortedData.map((item, index) => (
            <tr key={index} ref={index === sortedData.length - 1 ? lastItemRef : null} className="hover:bg-lightBlue/50 text-xs">
              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">{item.year}</td>

              <td
                className="py-1 px-4 text-black font-medium border border-grey2 border-t-0 border-l-0 cursor-pointer"
                onClick={() => {
                  const actualIndex = tableData.findIndex(tableItem =>
                    tableItem.year === item.year &&
                    tableItem.category === item.category &&
                    tableItem.file === item.file
                  );
                  setSelectedRowIndex(actualIndex);
                  setShowViewTemplatesModal(true);
                }}
              >
                <div className="flex items-center gap-2 group relative w-max">
                  <Folder className="w-4 h-4 text-darkblue1" stroke="none" fill="currentColor" />
                  <span>{item.category}</span>

                  {/* Tooltip */}
                  <span className="absolute left-1/2 top-full mt-0 font-normal transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                    View Presentation
                  </span>
                </div>
              </td>

              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                <div className="relative">
                  <p
                    className="underline text-SteelBlue1 truncate max-w-[120rem] cursor-pointer"
                    onClick={() => {
                      if (item.file) window.open(item.file, "_blank");
                    }}
                    onMouseEnter={() => {
                      const fileName = item.file?.substring(item.file.lastIndexOf("/") + 1);
                      if (fileName && fileName.length > 50) {
                        setHoveredCell(item.id + "-file");
                      }
                    }}
                    onMouseLeave={() => setHoveredCell(null)}
                  >
                    {item.file
                      ? (() => {
                          const fileName = item.file.substring(item.file.lastIndexOf("/") + 1);
                          return fileName.length > 50
                            ? `${fileName.substring(0, 50)}...`
                            : fileName;
                        })()
                      : "No file"}
                  </p>

                  {hoveredCell === item.id + "-file" && item.file && (
                    <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                      {item.file.substring(item.file.lastIndexOf("/") + 1)}
                    </span>
                  )}
                </div>
              </td>

              <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                <div className="flex items-center justify-center gap-2">
                  {/* Edit Button */}
                  <div className="relative group inline-block">
                    <button
                      onClick={() => {
                        const editData = {
                          year: item.year,
                          category: item.category,
                          file: item.file,
                        }
                        setFormData(editData)
                        setIsAddUserOpen(true)
                        setIsEditing(true)
                        const actualIndex = tableData.findIndex(tableItem =>
                          tableItem.year === item.year &&
                          tableItem.category === item.category &&
                          tableItem.file === item.file
                        );
                        setEditIndex(actualIndex)
                      }}
                      className="text-blue-600 hover:underline"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                        <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                      </svg>
                    </button>
                    <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                      Edit
                    </span>
                  </div>

                  {/* Add Presentation Button */}
                  <div className="relative group inline-block">
                    <button
                      onClick={() => {
                        const actualIndex = tableData.findIndex(tableItem =>
                          tableItem.year === item.year &&
                          tableItem.category === item.category &&
                          tableItem.file === item.file
                        );
                        setSelectedRowIndex(actualIndex)
                        setShowModal(true)
                      }}
                      className="text-blue-600 hover:underline"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M18 17H16C15.7167 17 15.4793 16.904 15.288 16.712C15.0967 16.52 15.0007 16.2827 15 16C14.9993 15.7173 15.0953 15.48 15.288 15.288C15.4807 15.096 15.718 15 16 15H18V13C18 12.7167 18.096 12.4793 18.288 12.288C18.48 12.0967 18.7173 12.0007 19 12C19.2827 11.9993 19.5203 12.0953 19.713 12.288C19.9057 12.4807 20.0013 12.718 20 13V15H22C22.2833 15 22.521 15.096 22.713 15.288C22.905 15.48 23.0007 15.7173 23 16C22.9993 16.2827 22.9033 16.5203 22.712 16.713C22.5207 16.9057 22.2833 17.0013 22 17H20V19C20 19.2833 19.904 19.521 19.712 19.713C19.52 19.905 19.2827 20.0007 19 20C18.7173 19.9993 18.48 19.9033 18.288 19.712C18.096 19.5207 18 19.2833 18 19V17ZM3 21C2.45 21 1.97933 20.8043 1.588 20.413C1.19667 20.0217 1.00067 19.5507 1 19V5C1 4.45 1.196 3.97933 1.588 3.588C1.98 3.19667 2.45067 3.00067 3 3H17C17.55 3 18.021 3.196 18.413 3.588C18.805 3.98 19.0007 4.45067 19 5V9C19 9.28333 18.904 9.521 18.712 9.713C18.52 9.905 18.2827 10.0007 18 10C17.7173 9.99933 17.48 9.90333 17.288 9.712C17.096 9.52067 17 9.28333 17 9V8H3V19H15C15.2833 19 15.521 19.096 15.713 19.288C15.905 19.48 16.0007 19.7173 16 20C15.9993 20.2827 15.9033 20.5203 15.712 20.713C15.5207 20.9057 15.2833 21.0013 15 21H3Z" fill="#E06900"/>
                      </svg>
                    </button>
                    <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                      Presentation
                    </span>
                  </div>

                  {/* Delete Button */}
                  <div className="relative group inline-block">
                    <button
                      onClick={() => {
                        const actualIndex = tableData.findIndex(tableItem =>
                          tableItem.year === item.year &&
                          tableItem.category === item.category &&
                          tableItem.file === item.file
                        );
                        setDeleteIndex(actualIndex);
                        setIsDeleteModalOpen(true);
                      }}
                      className="text-blue-600 hover:underline"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                        <g clipPath="url(#clip0_6398_313)">
                          <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                        </g>
                        <defs>
                          <clipPath id="clip0_6398_313">
                            <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                          </clipPath>
                        </defs>
                      </svg>
                    </button>
                    <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                      Delete
                    </span>
                  </div>
                </div>
              </td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan={4} className="px-4 py-6 text-center italic text-gray-500">
              No data found
            </td>
          </tr>
        )}
        {isLoading && (
          <tr>
            <td colSpan={4} className="px-6 py-4 text-center text-gray-500">
              <div className="flex items-center justify-center gap-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                Loading more...
              </div>
            </td>
          </tr>
        )}
        
      </tbody>
    </table>
    
  </div>
    {showScrollButtons && (
            <div className="fixed bottom-16 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

</div>
          </div>
        </div>
       
      </div>

      {/* 🔹 Scroll to Top Button */}


      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
          <div 
          ref={popupRef}
          className="bg-white  p-6 w-full max-w-xl relative">
            <h2 className="text-base font-semibold text-center mb-4 text-MediumGrey">
              {isEditing ? "Presentation Template" : "Add Presentation Template"}
            </h2>
            <button
              onClick={() => {
                setIsAddUserOpen(false)
                setIsEditing(false)
                setFormData({ year: "", category: "", file: "", page: "" })
                setErrors({})
              }}
              className="absolute top-3 right-4 text-red-600 font-bold text-xl"
            >
<svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>

            </button>
            {/* 🔹 Grid Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {/* Year */}
              <div className="col-span-1">
                <label className="text-xs font-medium text-black/70">Year <span className=" text-red1">*</span></label>
                <input
                  type="number"
                  value={formData.year}
                  onChange={(e) => {
        setFormData({ ...formData, year: e.target.value });

        // remove error when user types
        if (errors.year) {
          setErrors({ ...errors, year: "" });
        }
      }}
                  className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none text-black placeholder:text-grey focus:ring-1 ${errors.year ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                  placeholder="Enter Year"
                  tabIndex={0}
                />
                {errors.year && <p className="text-red1 text-xs mt-1">{errors.year}</p>}
              </div>
              {/* Category Name */}

           <div className="relative col-span-2">
  <label className="text-xs font-medium text-black/70">
    Presentation Template <span className=" text-red1">*</span>
  </label>

  {isEditing && tableData.length > 1 ? (
    <div ref={categoryRef} className="relative w-full">
      {/* INPUT */}
      <input
  type="text"
  value={formData.category}
  maxLength={50}
  onChange={(e) => {
    const value = e.target.value;

    setFormData((prev) => ({
      ...prev,
      category: value,
    }));

    // clear error when typing
    setErrors((prev) => ({
      ...prev,
      category: "",
    }));

    setCatagorySuggestions(true);
  }}
  onClick={() => setCatagorySuggestions(true)}
  onKeyDown={(e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setCatagorySuggestions(true);
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      setCatagorySuggestions(false);
    }
  }}
  placeholder="Enter Presentation Template"
  className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none transition-all
    ${catagorySuggestions ? "border-b-white" : ""}
    ${errors.category ? "border-red1" : "border-black/30"}
  `}
/>
      {/* DROPDOWN ICON */}
     <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transition-transform
          ${catagorySuggestions ? "rotate-180" : "rotate-0"}
        `}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>

      {/* DROPDOWN */}
      {catagorySuggestions && (
        <div className="absolute z-20 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto">
          
          {/* SEARCH (only if many items) */}
          {Array.from(
            new Set(tableData.map((i) => i.category).filter(Boolean))
          ).length > 5 && (
            <div className="sticky top-0 bg-white px-3 py-1.5 ">
              <input
                type="text"
                placeholder="Search category..."
                value={categorySearch}
                onChange={(e) => setCategorySearch(e.target.value)}
                className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
              />
            </div>
          )}

          {/* LIST */}
          {Array.from(
            new Set(tableData.map((i) => i.category).filter(Boolean))
          )
            .filter((c) => c !== formData.category)
            .filter((c) =>
              !categorySearch
                ? true
                : c.toLowerCase().includes(categorySearch.toLowerCase())
            )
            .sort((a, b) => a.localeCompare(b))
            .map((category, idx) => (
             <div
  tabIndex={0}
  data-option
  key={idx}
  className="px-3 py-1.5 text-xs cursor-pointer hover:bg-gray-100"
  onKeyDown={(e) => {

    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setCatagorySuggestions(false);
      categoryRef.current?.querySelector("input")?.focus();
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      setFormData({ ...formData, category });
      e.stopPropagation()
      setCatagorySuggestions(false);
      setCategorySearch("");
    }

  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setFormData({ ...formData, category });
    setCatagorySuggestions(false);
    setCategorySearch("");
  }}
>
  {category}
</div>
            ))}

          {/* NO RESULTS */}
          {Array.from(
            new Set(tableData.map((i) => i.category).filter(Boolean))
          ).filter((c) =>
            !categorySearch
              ? true
              : c.toLowerCase().includes(categorySearch.toLowerCase())
          ).length === 0 && (
            <div className="px-3 py-2 text-xs text-gray-400 italic">
              No categories found
            </div>
          )}
        </div>
      )}
    </div>
  ) : (
    /* SIMPLE INPUT */
    <input
      type="text"
      value={formData.category}
      onChange={(e) => {
    const value = e.target.value;

    setFormData({ ...formData, category: value });

    if (errors.category) {
      setErrors({ ...errors, category: "" });
    }

    setCatagorySuggestions(true);
  }}
      placeholder="Enter Presentation Template"
      className={`border w-full mt-1 px-3 py-1.5 text-xs outline-none
        ${errors.category ? "border-red1" : "border-black/30"}
      `}
    />
  )}

  {errors.category && (
    <p className="text-red1 text-xs mt-1">{errors.category}</p>
  )}
</div>

              {/* File */}
<div
  className="col-span-3 relative"
  onDragOver={handleDragOverSample}
  onDrop={handleDropSample}
>                <label className="text-xs font-medium text-black/70">Sample File <span className=" text-red1">*</span></label>
                {/* Label wrapping text and icon */}
                <label
                  htmlFor="hiddenFileInput"
                  className={`flex items-center border  px-3 py-1.5 w-full mt-1 text-xs pr-2 cursor-pointer outline-none ${errors.file ? "border-red1 focus-within:ring-1 focus-within:ring-red1" : "border-black/30 focus-within:ring-1 focus-within:ring-black/30"}`}
                >
                  <span
                    className={`flex-grow text-left truncate ${formData.file ? "text-black underline" : "text-grey"
                      }`}
                      tabIndex={0}
                  >
{formData.file?.name || "Upload Sample File"}                  </span>

<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
<path d="M21 12C21 10.22 20.4722 8.47991 19.4832 6.99987C18.4943 5.51983 17.0887 4.36628 15.4442 3.68509C13.7996 3.0039 11.99 2.82567 10.2442 3.17294C8.49836 3.5202 6.89472 4.37737 5.63604 5.63604C4.37737 6.89472 3.5202 8.49836 3.17294 10.2442C2.82567 11.99 3.0039 13.7996 3.68509 15.4442C4.36628 17.0887 5.51983 18.4943 6.99987 19.4832C8.47991 20.4722 10.22 21 12 21M3.6 9H20.4M3.6 15H12" stroke="#1B365D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M11.5778 3C9.89314 5.69961 9 8.81787 9 12C9 15.1821 9.89314 18.3004 11.5778 21M12.4998 3C14.2188 5.755 14.9998 8.876 14.9998 12M17.9998 21V14M17.9998 14L20.9998 17M17.9998 14L14.9998 17" stroke="#1B365D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>                </label>
                {/* Hidden file input */}
                <input
                  type="file"
                  id="hiddenFileInput"
                  className="hidden"

                  onChange={(e) => {
                     if (errors.file) {
          setErrors({ ...errors, file: "" });
        }
                    const file = e.target.files[0]
                    if (file) {
setFormData({ ...formData, file: file })                    }
                  }}
                />
                {errors.file && <p className="text-red1 text-xs mt-1">{errors.file}</p>}
              </div>
            </div>
            {/* Save Button */}
            <button
            id="saveTemplateBtn"
              onClick={async () => {
                const newErrors = {}
                const yearTrimmed = formData.year.toString().trim()

                // ✅ Validate Year
                if (!yearTrimmed) {
                  newErrors.year = "Please enter this field"
                } else if (!/^\d{4}$/.test(yearTrimmed)) {
                  newErrors.year = "Please enter a valid 4-digit year"
                }

                // ✅ Validate Category
                if (!formData.category.trim()) {
                  newErrors.category = "Please enter this field"
                }

                // ✅ Validate File
                if (!formData.file) {
                  newErrors.file = "Please upload a file"
                }

                // ✅ If errors, stop here
                if (Object.keys(newErrors).length > 0) {
                  setErrors(newErrors)
                  return
                }

                try {
                  setIsLoadingData(true);
                  setApiError("");
                  setSuccessMessage("");

                  // Prepare data for API
                  const presentationTemplateData = {
                    year: yearTrimmed,
                    presentationTemplate: formData.category.trim()
                  };

                  // Get the file from the file input
                  const fileInput = document.getElementById('hiddenFileInput');
                  const file = fileInput?.files?.[0];

                  if (isEditing) {
                    // Update existing template
                    const existingItem = tableData[editIndex];
                    const updateData = {
                      id: existingItem.id,
                      year: yearTrimmed,
                      presentationTemplate: formData.category.trim(),
                      sampleFileUrl: existingItem.file // Keep existing file URL if no new file
                    };

                    await updatePresentationTemplate(updateData, file);
                    // setSuccessMessage("Presentation template updated successfully!");
                  } else {
                    // Add new template
                    await addPresentationTemplate(presentationTemplateData, file);
                    // setSuccessMessage("Presentation template added successfully!");
                  }
 resetSortAndFilter()

                  // Refresh data from API
                  await fetchPresentationTemplates();
                  // Reset form
                  setFormData({ year: "", category: "", file: "", page: "" })
                  setErrors({})
                  setIsEditing(false)
                  setEditIndex(null)
                  setIsAddUserOpen(false)

                } catch (error) {
                  // console.error("Error saving presentation template:", error);
                  setApiError(error.message || "Failed to save presentation template");
                } finally {
                  setIsLoadingData(false);
                }
              }}

              className={`mt-6 text-xs font-medium px-8 py-1.5  transition block mx-auto ${isLoadingData
                ? "bg-gray-400 text-white cursor-not-allowed"
                : "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                }`}
              disabled={isLoadingData}
            >
              {isLoadingData ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  {isEditing ? "Updating..." : "Saving..."}
                </div>
              ) : (
                "Save"
              )}
            </button>
          </div>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center z-50">
          <div className="bg-white p-6  w-[400px]">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-base font-semibold text-center mb-2 text-MediumGrey w-full">
                Add Category
              </h2>
              <button
                onClick={() => {
                  setShowModal(false)
                  setCategoryName("")
                  setPageNumber("")
                  setSelectedRowIndex(null)
                  setErrors({})
                }}
                className="text-red-600 font-bold text-lg"
              >
 <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>
              </button>
            </div>

            {/* Category Name */}
            <label className="text-xs font-medium text-black/70">
              Category Name <span className="text-red1">*</span>
            </label>
            <input
              type="text"
              placeholder="Category Name"
              value={categoryName}
              onChange={(e) => setCategoryName(e.target.value)}
              className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${errors.categoryName ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                } mb-1`}
            />
            {errors.categoryName && <p className="text-red1 text-xs mb-2">Please fill this field</p>}

            {/* Page Number */}
            <label className="text-xs font-medium text-black/70">
              Page Number <span className="text-red1">*</span>
            </label>
            <input
              type="text"
              placeholder="Page Number"
              value={pageNumber}
              onChange={(e) => {
                const onlyNums = e.target.value.replace(/[^0-9]/g, "");
                setPageNumber(onlyNums);
              }}
              className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${errors.pageNumber ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                }`}
            />
            {errors.pageNumber && <p className="text-red1 text-xs mb-2">{errors.pageNumber}</p>}

            {/* Save Button */}
            <button
              onClick={async () => {
                const newErrors = {}
                if (!categoryName.trim()) newErrors.categoryName = true
                if (!pageNumber.trim()) {
                  newErrors.pageNumber = "Please fill this field"
                } else if (!/^\d+$/.test(pageNumber.trim())) {
                  newErrors.pageNumber = "Only numbers are allowed"
                }

                if (Object.keys(newErrors).length > 0) {
                  setErrors(newErrors)
                  return
                }

                if (selectedRowIndex !== null) {
                  try {
                    setIsLoadingData(true);
                    setApiError("");
                    setSuccessMessage("");

                    const templateId = tableData[selectedRowIndex].id;
                    const categoryData = {
                      category_name: categoryName.trim(),
                      page_number: pageNumber.toString().trim(),
                      presentation_template_id: templateId
                    };

                    await addPresentationTemplateCategory(categoryData);
                    // setSuccessMessage("Category added successfully!");

                    // Refresh data from API to get updated categories
                    await fetchPresentationTemplates();

                    // Clear Add form
                    setCategoryName("")
                    setPageNumber("")
                    setSelectedRowIndex(selectedRowIndex) // retain index
                    setShowModal(false)
                    setErrors({})

                  } catch (error) {
                    // console.error("Error adding category:", error);
                    setApiError(error.message || "Failed to add category");
                  } finally {
                    setIsLoadingData(false);
                  }
                }
              }}

              className={`mt-6 text-xs font-medium px-8 py-1.5  transition block mx-auto ${isLoadingData
                ? "bg-gray-400 text-white cursor-not-allowed"
                : "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                }`}
              disabled={isLoadingData}
            >
              {isLoadingData ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Adding...
                </div>
              ) : (
                "Save"
              )}
            </button>
          </div>
        </div>
      )}

      {/* Modal with Lazy Loading Table */}
      {showViewTemplatesModal && selectedRowIndex !== null && (
        <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
          <div className="bg-white p-6  w-[600px]">
            {/* Modal Header */}
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-base font-semibold w-full text-center text-MediumGrey">
                Presentations in {tableData[selectedRowIndex]?.category}
              </h2>
              <button
                onClick={() => {
                  setShowViewTemplatesModal(false);
                  setSelectedRowIndex(null);
                  setEditingIndex(null);
                  // Reset lazy loading states
                  setDisplayedTemplates([]);
                  setHasMoreTemplates(true);
                  setIsLoadingTemplates(false);
                }}
              >
 <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>
              </button>
            </div>

            {/* Table with Lazy Loading */}
            <div className="bg-white shadow-md  border border-Dustyblue overflow-hidden">
              <div
                className="
    overflow-y-auto relative
    max-h-[300px]        /* default (mobile / sm) */
    md:max-h-[350px]     /* medium screens */
    lg:max-h-[400px]     /* large screens */
    xl:max-h-[450px]     /* extra-large screens */
    2xl:max-h-[500px]    /* 2xl screens */
  "
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
              >
                <style jsx>{`
    div::-webkit-scrollbar {
      display: none;
    }
  `}</style>
                <table className="w-full text-sm whitespace-nowrap cursor-pointer">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-10">
  <tr>
    <th
      onClick={() => handleModalSort("categoryName")}
      className="py-1.5 px-3 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%] cursor-pointer select-none"
    >
      <div className="flex items-center gap-1">
        Category
        {modalSortKey === "categoryName" && modalSortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {modalSortKey === "categoryName" && modalSortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    <th
      onClick={() => handleModalSort("pageNumber")}
      className="py-1.5 px-3 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%] cursor-pointer select-none"
    >
      <div className="flex items-center gap-1">
        Page Number
        {modalSortKey === "pageNumber" && modalSortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
        {modalSortKey === "pageNumber" && modalSortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
      </div>
    </th>

    {editingIndex === null && (
      <th className="py-1.5 px-3 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 w-[20%]">
        Actions
      </th>
    )}
  </tr>
</thead>

                  <tbody>
                    {sortedTemplates.length > 0 ? (
                      sortedTemplates.map((tpl, idx) => (
                        <tr
                          key={idx}
                          ref={idx === sortedTemplates.length - 1 ? lastTemplateRef : null}
                          className="border-t  text-xs"
                        >
                          {editingIndex === idx ? (
                            <>
                            <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <input
      type="text"
      value={editedCategory}
      onChange={(e) => setEditedCategory(e.target.value)}
      onMouseEnter={() => {
        if (editedCategory?.length > 18) {
          setHoveredCell("edit-category");
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
      className="border px-2 py-1 w-full truncate"
    />

    {hoveredCell === "edit-category" && editedCategory && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {editedCategory}
      </span>
    )}
  </div>
</td>

                            <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <input
      type="text"
      value={editedPage}
      onChange={(e) => {
        const onlyNums = e.target.value.replace(/[^0-9]/g, "");
        setEditedPage(onlyNums);
      }}
      onMouseEnter={() => {
        if (editedPage?.length > 5) {
          setHoveredCell("edit-page");
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
      className="border px-2 py-1 w-full truncate"
    />

    {hoveredCell === "edit-page" && editedPage && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {editedPage}
      </span>
    )}
  </div>
</td>

                              {/* no Actions column here */}
                            </>
                          ) : (
                            <>
                              <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0">{tpl.categoryName}</td>
                              <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0">Page {tpl.pageNumber}</td>
                              {editingIndex === null && (
                                <td className="px-3 py-1  flex   gap-4">
                                 
                                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="20" viewBox="0 0 24 24" fill="none" onClick={() => {
                                      setEditingIndex(idx);
                                      setEditedCategory(tpl.categoryName);
                                      setEditedPage(tpl.pageNumber);
                                    }}>
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

                                  
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none"onClick={() => {
                                      setDeleteIndex(idx);
                                      setShowDeleteModal(true);
                                    }}>
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>

                                </td>
                              )}
                            </>
                          )}
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={editingIndex === null ? 3 : 2} className="text-center italic text-sm text-black py-4">
                          No Presentations found
                        </td>
                      </tr>
                    )}
                    {isLoadingTemplates && (
                      <tr>
                        <td colSpan={editingIndex === null ? 3 : 2} className="px-3 py-4 text-center text-gray-500">
                          <div className="flex items-center justify-center gap-2">
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                            Loading more...
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Global Save button */}
            {editingIndex !== null && (
              <div className="mt-4 flex justify-center gap-4">
                {/* Cancel Button */}
                <button
                  onClick={() => setEditingIndex(null)}
                  className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium  hover:bg-mildBlue1 hover:scale-105"
                >
 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 18 20" fill="none">
<path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>                  Cancel
                </button>

                {/* Save Button */}
                <button 
                  onClick={async () => {
                    try {
                      setIsLoadingData(true);
                      setApiError("");
                      setSuccessMessage("");

                      const categoryToUpdate = displayedTemplates[editingIndex];
                      const updateData = {
                        category_name: editedCategory.trim(),
                        page_number: editedPage.toString().trim(),
                        presentation_template_id: tableData[selectedRowIndex].id
                      };

                      await updatePresentationTemplateCategory(categoryToUpdate.id, updateData);
                      // setSuccessMessage("Category updated successfully!");

                      // Refresh data from API
                      await fetchPresentationTemplates();
                      setEditingIndex(null);

                    } catch (error) {
                      // console.error("Error updating category:", error);
                      setApiError(error.message || "Failed to update category");
                    } finally {
                      setIsLoadingData(false);
                    }
                  }}
                  className={`text-xs font-medium px-8 py-1.5  ${isLoadingData
                    ? "bg-gray-400 text-white cursor-not-allowed"
                    : "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                    }`}
                  disabled={isLoadingData}
                >
                  {isLoadingData ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      Updating...
                    </div>
                  ) : (
                    "Save"
                  )}
                </button>
              </div>
            )}

            <DeleteModal
              isOpen={showDeleteModal}
              onClose={() => {
                setShowDeleteModal(false);
                setDeleteIndex(null);
              }}
              onConfirm={async () => {
                try {
                  setIsLoadingData(true);
                  setApiError("");
                  setSuccessMessage("");

                  const categoryToDelete = displayedTemplates[deleteIndex];
                  await deletePresentationTemplateCategory(categoryToDelete.id);

                  // setSuccessMessage("Category deleted successfully!");

                  // Refresh data from API
                  await fetchPresentationTemplates();

                  setShowDeleteModal(false);
                  setDeleteIndex(null);

                } catch (error) {
                  // console.error("Error deleting category:", error);
                  setApiError(error.message || "Failed to delete category");
                } finally {
                  setIsLoadingData(false);
                }
              }}
            />
          </div>
        </div>
      )}

      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={async () => {
          if (deleteIndex !== null) {
            try {
              setIsLoadingData(true);
              setApiError("");
              setSuccessMessage("");

              const itemToDelete = tableData[deleteIndex];
              await deletePresentationTemplate(itemToDelete.id);

              // setSuccessMessage("Presentation template deleted successfully!");

              // Refresh data from API
              await fetchPresentationTemplates();

              setDeleteIndex(null);
            } catch (error) {
              // console.error("Error deleting presentation template:", error);
              setApiError(error.message || "Failed to delete presentation template");
            } finally {
              setIsLoadingData(false);
            }
          }
          setIsDeleteModalOpen(false);
        }}
      />

    </div>
  )
}

export default PresentationTemplate