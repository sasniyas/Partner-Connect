"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../../Components/Header";

function NationalKeyDownload () {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]); // ⬅️ now controlled by postMessage

  // ✅ Listen for postMessage from parent window
  useEffect(() => {
    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const handleDownloadExcel = () => {
  if (!tableData || tableData.length === 0) return;

  const excelData = tableData.map((item, index) => ({
  "Sl. No": String(index + 1),
  "Market Area": item.marketarea,
   "Dealership":item.dealer_name,
   "Key Account Customer":item.key_account_customer,
"Status": item.isActive  === 1 ? "Active" : "Inactive"
}));


  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // 👇 Apply left alignment style explicitly
  Object.keys(worksheet).forEach((cell) => {
    if (cell.startsWith("A")) {
      worksheet[cell].s = { alignment: { horizontal: "left" } };
    }
  });

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "National Key Accounts");
  XLSX.writeFile(workbook, "National_Key _Accounts.xlsx");
};


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2  flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1"> National Key Accounts


</h2>
          <button
            className="bg-darkblue1 text-white text-sm font-medium px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadExcel}
          >
            Download 
          </button>
        </div>

        <div className="bg-white shadow-md  border border-Dustyblue  overflow-x-auto">
          <table className="w-full  text-left whitespace-nowrap">
            <thead className="bg-Dustyblue text-white">
              <tr>
                             <th className="px-4  py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0font-medium w-[10%]">Sl. No</th>

          <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">Market Area</th>
        <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%] ">Dealership</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">Key Account Customer</th>
  
    <th className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[10%] ">Status</th>

              </tr>
            </thead>
            <tbody>
              {tableData.length > 0 ? (
                tableData.map((item, index) => (
                  <tr key={index} className=" hover:bg-lightBlue/50 text-xs">
                                        <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0">{index+1}</td>

                       <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0 align-top">
                {item.marketarea || "-"}     
          </td>
 <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0 align-top">
                {item.dealer_name || "-"}     
          </td>
          {/* Competence Name */}
          <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0 align-top">
            
                {item.key_account_customer || "-"}
              
          </td>

    
      <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0 border-r-0">{ item.isActive  === 1 ? "Active" : "Inactive"}</td>


                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default NationalKeyDownload;
