


"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../../Components/Header";
import { formatedTime } from "../../../../../util/timeFormat";

function OthersDataDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]);

  // Listen for postMessage from parent window
  useEffect(() => {
    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        // Add createdTime if not present
        const dataWithTime = (event.data.payload || []).map(item => ({
          ...item,
          createdTime: item.createdTime || new Date().toISOString()
        }));
        setTableData(dataWithTime);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const handleDownloadExcel = () => {
    if (!tableData || tableData.length === 0) return;

    const excelData = tableData.map((item, index) => {
      const dateObj = new Date(item.createdTime);
      return {
        "Sl. No": index + 1,
        "File Name": item.fileName || "-",
        
      "Created On":formatedTime(item.createdOn) ,
        "Status": item.status || "-"
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Others Data");
    XLSX.writeFile(workbook, "Others_Data.xlsx");
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-2 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">Others Data</h2>
          <button
            className="bg-darkblue1 text-white text-sm font-medium px-4 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadExcel}
          >
            Download
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full text-left whitespace-nowrap">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%]">Sl. No</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%]">File Name</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%]">Created On</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[10%]">Status</th>
              </tr>
            </thead>
            <tbody>
              {tableData.length > 0 ? (
                tableData.map((item, index) => {
                  const dateObj = new Date(item.createdTime);
                  return (
                    <tr key={index} className=" hover:bg-lightBlue/50 text-xs">
                      <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0">{index + 1}</td>
                      <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0">{item.file_name || "-"}</td>
                      <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0">{formatedTime(item.createdOn)}</td>
                      <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0 border-r-0">{item.status}</td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={5} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default OthersDataDownload;
