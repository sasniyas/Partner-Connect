// import { useState, useEffect, useRef } from "react"
// import Header from "../../../../../Components/Header"
// import { useNavigate } from "react-router-dom"
// import SubNavbar3 from "../../../../../Components/SubNavbar3"
// import { ArrowLeft, Plus, ArrowRight } from "lucide-react"
// import Searchinput from "../../../../../Components/Searchinput"
// import DeleteModal from "../../../../../Components/DeleteModal"
// import * as XLSX from "xlsx";

// // Mock components - replace with your actual components

// function  PDPFillTemplatesExplorer() {
//   const [menuOpen, setMenuOpen] = useState(false)
//   const [showScrollTop, setShowScrollTop] = useState(false)
//   const navigate = useNavigate()
// //   const [open, setOpen] = useState(false)
//   const [isAddUserOpen, setIsAddUserOpen] = useState(false)
//   const dropdownRef = useRef(null)
//   const [tableData, setTableData] = useState([])
// const [formData, setFormData] = useState({
//   segmnetname: "",
//   label: "",
//   isroot: "",
//   haschild: "",
//   parentid: "",
//   image: "", // ← new image name
// });
//   const [isEditing, setIsEditing] = useState(false)
//   const [editIndex, setEditIndex] = useState(null)
//   const [errors, setErrors] = useState({})
//   const [searchQuery, setSearchQuery] = useState("")
//   const [open,setOpen]=useState("")
//   const [currentPage, setCurrentPage] = useState(1)
//   const rowsPerPage = 7
// //   const [competenceOptions,setCompetencename]=useState("")
// const [deleteIndex, setDeleteIndex] = useState(null); // to track which row to delete
// const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
// const [showmarcomnamesuggestion, setShowMarcomnamesuggestion] = useState(false);
// const [marcomtype, setMarcomtype] = useState("");
// const [marcomname, setMarcomname] = useState("");
// const [label,setLabel]=useState("")
// const [showlabeluggestions,setShowLabelSuggestions] =useState(false);
// const imageInputRef = useRef(null);
// const generateUniqueId = () => Date.now().toString();
// const fileInputRef = useRef(null)
// const handleBulkUploadClick = () => {
//     fileInputRef.current.click()
//   }
// const [showMarcomTypeSuggestions,setShowMarcomTypeSuggestions] =useState(false);
// const [showsegmentSuggestions,setShowSegmentSuggestions] =useState(false);
// const [showParentIdSuggestions, setShowParentIdSuggestions] = useState(false);
// const [parentIdOptions, setParentIdOptions] = useState(["a", "b", "c"]);


//   const filteredData = tableData.filter((item) => {
//   const matchesSearch = Object.values(item).some((val) =>
//     val?.toString().toLowerCase().includes(searchQuery.toLowerCase())
//   );
//   const matcheslabel = label ? item.label === label : true;
// const matchesmarcomname = marcomname ? item.marcomname === marcomname : true;

//   return matchesSearch && matcheslabel &&matchesmarcomname;
// });




//   const totalPages = Math.ceil(filteredData.length / rowsPerPage)
//   const paginatedData = filteredData.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage)

//   useEffect(() => {
//     const handleScroll = () => {
//       setShowScrollTop(window.scrollY > 100)
//     }
//     window.addEventListener("scroll", handleScroll)
//     return () => window.removeEventListener("scroll", handleScroll)
//   }, [])
//  useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setOpen(false)
//       }
//     }
//     document.addEventListener("mousedown", handleClickOutside)
//     return () => document.removeEventListener("mousedown", handleClickOutside)
//   }, [])

  
// const handlePreviewAndDownload = () => {
//   const tableHeaders = ["ID","Image", "Parent ID", "Label", "Is Root","Has Children"];

//   // ✅ Use full filtered data instead of just the current page
//   const tableRows = filteredData.map((item, index) => `
//     <tr class="${index % 2 === 0 ? 'bg-white' : 'bg-gray-100'}">
//       <td class="border px-4 py-2 text-sm">${index + 1}</td>
//       <td class="border px-4 py-2 text-sm">${item.image}</td>
//       <td class="border px-4 py-2 text-sm">${item.parentid}</td>
//             <td class="border px-4 py-2 text-sm">${item.label}</td>

//             <td class="border px-4 py-2 text-sm">${item.isroot}</td>
//             <td class="border px-4 py-2 text-sm">${item.haschild}</td>


//     </tr>
//   `).join("");

//   const htmlContent = `
//     <!DOCTYPE html>
//     <html lang="en">
//     <head>
//       <meta charset="UTF-8" />
//       <meta name="viewport" content="width=device-width, initial-scale=1.0" />
//       <script src="https://cdn.tailwindcss.com"></script>
//       <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
//       <title>PDP Data Explorer Preview</title>
//     </head>
//     <body class="bg-gray-50 text-gray-900 p-8 font-sans">
//       <h1 class="text-2xl font-bold mb-4">PDP Data Explorer Table </h1>
//       <div class="overflow-x-auto">
//         <table id="exportTable" class="min-w-full bg-white border border-gray-300 rounded-md text-left text-sm">
//           <thead class="bg-blue-100">
//             <tr>
//               ${tableHeaders.map(header => `<th class="px-4 py-2 border text-sm font-medium">${header}</th>`).join("")}
//             </tr>
//           </thead>
//           <tbody>
//             ${tableRows}
//           </tbody>
//         </table>
//       </div>
//       <button
//         onclick="downloadAsExcel()"
//         class="mt-6 px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition"
//       >
//         Download as Excel
//       </button>

//       <script>
//         function downloadAsExcel() {
//           const wb = XLSX.utils.book_new();
//           const ws = XLSX.utils.table_to_sheet(document.getElementById('exportTable'));
//           XLSX.utils.book_append_sheet(wb, ws, 'Templates');
//           XLSX.writeFile(wb, 'PDP_Data_Explorer_Table.xlsx');
//         }
//       </script>
//     </body>
//     </html>
//   `;

//   const newWindow = window.open("", "_blank");
//   newWindow.document.write(htmlContent);
//   newWindow.document.close();
// };

// const handleDownloadTemplate = () => {
//   const headers = [["ID","Image", "Parent ID", "Label", "Is Root","Has Children"]];

//   const worksheet = XLSX.utils.aoa_to_sheet(headers);

//   worksheet["!cols"] = [
//     { wch: 20 },
//     { wch: 30 },
//     { wch: 20 },
//     { wch: 20 },
//     { wch: 25 },
//   ];

//   const data = [
//     {
//       ID:"1",
//       Image: "abc.png",
//       "Parent ID": "Excel Machine Sales",
//       "Label": "Excel Machine Sales",
//       "Is Root": "yes",
//       "Has Children":"No"
//     }
//   ];

//   XLSX.utils.sheet_add_json(worksheet, data, {
//     origin: "A2", // Avoid overwriting the header
//     skipHeader: true
//   });

//   const workbook = XLSX.utils.book_new();
//   XLSX.utils.book_append_sheet(workbook, worksheet, "Users");

//   XLSX.writeFile(workbook, "PDP_Data_Explorer_Bulk_Upload_Template.xlsx");
// };

 
// // useEffect(() => {
// //   const marcomtypeFromData = tableData
// //     .map(item => item.marcomtype?.trim())
// //     .filter(val => val && val.length > 0);

// //   const baseMarcomType = [  "Branding","Marketing"];

// //   setMarcomOptions(Array.from(new Set([...baseMarcomType, ...marcomtypeFromData])));
// // }, [tableData]);




//   return (
//     <div className="bg-Frostwhite min-h-screen flex flex-col">
//       <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
//       <SubNavbar3 />
//       <div className={`transition-all duration-300 mt-20 lg:mt-[170px] ${menuOpen ? "ml-60" : ""}`}>
//         <div className="w-full flex justify-center">
//           <div className="w-full max-w-[1280px] transition-all duration-300 ease-in-out px-4 lg:px-2 xl:px-0">
//             {/* 🔹 Heading */}
//             <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
//               <h2 className="text-base font-medium font-VolvoNovum text-center text-darkblue1 flex items-center justify-center gap-2">
//                 <ArrowLeft
//                   onClick={() => navigate("/masterpdphomepage")}
//                   size={28}
//                   className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 rounded-md p-1"
//                 />
//       Explorer / PDP Fill Templates Explorer
//   </h2>
             
//             </div>
//           {/* 🔹 Controls: Search + Filters + Actions */}
// <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8 w-full">

//   {/* 🔸 Left Side: Search + Filters */}
//   <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-2 w-full ">
    
//     {/* 🔍 Search Input */}
//     <div className="w-full sm:w-64 md:w-36 lg:w-80">
//       <Searchinput
//         onChange={(e) => {
//           setSearchQuery(e.target.value);
//           setCurrentPage(1);
//         }}
//         value={searchQuery}
//         placeholder="Search"
//         className="w-full"
//         iconColor="text-black"
//         bgColor="bg-FrostWhite"
//         borderColor="border-black/60"
//         textColor="text-black"
//         shadow="shadow-none"
//         inputPadding="pl-8 pr-3 py-2"
//         iconSize="w-4 h-4"
//         iconLeft="left-3"
//         inputWidth="w-full"
//         focusRing="focus:ring-1 focus:ring-black/60"
//         hoverInputClasses="hover:bg-white hover:border-black/60"
//       />
//     </div>

//     {/* 📆 Year Filter */}
   
//     {/* 🏷️ Category Filter */}
     
 
 
//   </div>

//   {/* 🔸 Right Side: Action Buttons */}
//  <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
    
//     {/* ➕ Add Dropdown */}
//     <div className="relative w-full sm:w-[180px]" ref={dropdownRef}>
//       <button
//         onClick={() => setOpen(!open)}
//         className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-2 text-sm rounded-lg flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
//       >
//         <Plus className="w-4 h-4 stroke-[3]" />
//         Add New
//       </button>

//       {open && (
//         <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1 rounded-lg shadow-lg z-50">
//           <button
//             className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-2"
//             onClick={() => {
//               setIsAddUserOpen(true);
//               setOpen(false);
//             }}
//           >
//             <img src="/icons/PdpmasterHomepage/filltemplateexplorer.png"alt="add new" className="w-4 h-4" />
//             Add Data Explorer
//           </button>
//          <button
//   onClick={() => {
//     const input = document.createElement("input")
//     input.type = "file"
//     input.accept = ".xlsx, .xls" // Accept only Excel files
//     input.onchange = (e) => {
//       const file = e.target.files[0]
//       if (file && (file.name.endsWith(".xlsx") || file.name.endsWith(".xls"))) {
//         handleBulkUploadClick(file) // your upload logic
//       }
//       // If not valid, do nothing (no alert)
//     }
//     input.click()
//     setOpen(false)
//   }}
//   className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-1 hover:rounded-b-lg whitespace-nowrap"
// >
//   <img
//     src="/icons/Usermanagement/bulkupload.png"
//     alt="bulk upload"
//     className="w-5 h-5"
//   />
//   Bulk Upload
// </button>


//   <button
//                       // onClick={() => {
//                       //   handleBulkUploadClick()
//                       //   setOpen(false)
//                       // }}
//                               onClick={handleDownloadTemplate}

//                       className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-1 hover:rounded-b-lg whitespace-nowrap"
//                     >
//  <img src="/icons/MarketAreaatble/download.png" alt="Download" className="w-4 h-4" />                     
//  Bulk upload Template
//                     </button>

//         </div>
//       )}
//     </div>

//     {/* ⬇️ Download Button */}
//    <button
//       onClick={handlePreviewAndDownload}
//       className="group relative text-sm bg-white text-darkblue1 px-4 py-2 border border-darkblue1 rounded-md flex items-center gap-1 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
//     >
//       <img
//         src="/icons/PdpmasterHomepage/download.png"
//         alt="download"
//         className="w-3 h-3 group-hover:hidden"
//       />
//       <img
//         src="/icons/PdpmasterHomepage/download1.png"
//         alt="download-white"
//         className="w-3 h-3 hidden group-hover:block"
//       />
//       <span className="font-semibold">Download</span>
//     </button>

//   </div>
//   </div>
//     {/* ➕ Add Dropdown */}
//     {/* <div className="relative w-full sm:w-[180px]" ref={dropdownRef}>
//       <button
//         onClick={() => setOpen(!open)}
//         className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-2 text-sm rounded-lg flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
//       >
//         <Plus className="w-4 h-4 stroke-[3]" />
//         Add New
//       </button>

//       {open && (
//         <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1 rounded-lg shadow-lg z-50">
//           <button
//             className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-2"
//             onClick={() => {
//               setIsAddUserOpen(true);
//               setOpen(false);
//             }}
//           >
//             <img src="/icons/PdpmasterHomepage/presentationtemplate.png" alt="add new" className="w-4 h-4" />
//             Add Marcom
//           </button>
//           <button
//             onClick={() => setOpen(false)}
//             className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-2 hover:rounded-b-lg"
//           >
//             <img src="/icons/Usermanagement/bulkupload.png" alt="bulk upload" className="w-5 h-5" />
//             Bulk Upload
//           </button>
//         </div>
//       )}
//     </div> */}

//     {/* ⬇️ Download Button */}
//     {/* <button className="group relative text-sm bg-white text-darkblue1 px-4 py-2 border border-darkblue1 rounded-md flex items-center gap-2 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto">
//       <img src="/icons/PdpmasterHomepage/download.png" alt="download" className="w-3 h-3 group-hover:hidden" />
//       <img src="/icons/PdpmasterHomepage/download1.png" alt="download-white" className="w-3 h-3 hidden group-hover:block" />
//       <span className="font-semibold">Download</span>
//     </button> */}
 


//             {/* 🔹 Table Section */}
//           <div className="bg-white shadow-md rounded-lg border border-Dustyblue overflow-hidden">
//   <table className="w-full table-auto text-sm cursor-pointer">
//     <thead className="bg-Dustyblue text-white text-left">
//       <tr>
//         <th className="px-4 py-4 text-base font-medium w-[2%] ">ID</th>
//               <th className="px-4 py-4 text-base font-medium w-[20%] ">Image</th>
//         <th className="px-4 py-4 text-base font-medium  w-[15%]">Parent ID</th>
//         <th className="px-4 py-4 text-base font-medium  w-[15%]">Label</th>
//         <th className="px-4 py-4 text-base font-medium w-[7%] ">Is Root</th>
//         <th className="px-4 py-4 text-base font-medium w-[7%] whitespace-nowrap">Has Children</th>

//         <th className="px-4 py-4 text-base font-medium w-[5%]  ">Actions</th>
//       </tr>
//     </thead>

//     <tbody className="text-black">
//      {paginatedData.length > 0 ? (
//     paginatedData.map((item, index) => (   
//         <tr key={index} className="odd:bg-white even:bg-gery1 hover:bg-lightBlue/50">
//           {/* Competence Type */}
//           <td className="px-4 py-6 ">
//                 {item.id || "-"}     
//           </td>
//  <td className="px-4 py-6 ">
//                 {item.image|| "-"}     
//           </td>
//            <td className="px-4 py-6 ">
//                 {item.parentid || "-"}     
//           </td>
//            <td className="px-4 py-6 ">
//                 {item.label|| "-"}     
//           </td>
//            <td className="px-4 py-6 ">
//                 {item.isroot|| "-"}     
//           </td>
//            <td className="px-4 py-6 ">
//                 {item.haschild || "-"}     
//           </td>
//           {/* Competence Name */}
        
//           {/* Actions */}
//           <td className="px-4 py-4">
//             <div className="flex items-center gap-2">
//               {/* Edit */}
//               <div className="relative group inline-block">
//                 <button
//                  onClick={() => {
//   setFormData({
//     segmnetname: item.segmnetname || "",
//     label: item.label || "",
//     isroot: item.isroot || "",
//     haschild: item.haschild || "",
//     parentid: item.parentid || "",
//     image: item.image || "",
//   });
//   setIsAddUserOpen(true);
//   setIsEditing(true);
//   setEditIndex(index);
// }}

//                 >
//                   <img src="/icons/MarketAreaatble/edit.png" alt="edit" className="w-4 h-4" />
//                 </button>
//                 <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-0 transition-opacity duration-200 z-50">
//                   Edit
//                 </span>
//               </div>

//               {/* Activate / Deactivate */}
//               <div className="relative group inline-block">
//                 <button
//                   onClick={() => {
//                     const updated = [...tableData];
//                     updated[index].isActive = !updated[index].isActive;
//                     setTableData(updated);
//                   }}
//                 >
//                   <img
//                     src={
//                       item.isActive
//                         ? "/icons/MarketAreaatble/active.png"
//                         : "/icons/MarketAreaatble/deactive.png"
//                     }
//                     alt={item.isActive ? "Active" : "Deactive"}
//                     className="w-4 h-4"
//                   />
//                 </button>
//                 <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-0 transition-opacity duration-200 z-50">
//                   {item.isActive ? "Deactivate" : "Activate"}
//                 </span>
//               </div>

//               {/* Delete */}
//               <div className="relative group inline-block">
//                 <button
//                   onClick={() => {
//                     setDeleteIndex(index);
//                     setIsDeleteModalOpen(true);
//                   }}
//                 >
//                   <img src="/icons/PdpmasterHomepage/delete.png" alt="delete" className="w-4 h-4" />
//                 </button>
//                 <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-0 transition-opacity duration-200 z-50">
//                   Delete
//                 </span>
//               </div>
//             </div>
//           </td>
//         </tr>
//       ))
//       ) : (
//         <tr>
//           <td colSpan="7" className="px-4 py-6 text-center text-gray-500 italic ">
//             No data found
//           </td>
//         </tr>
//       )}
//     </tbody>
//   </table>
// </div>

//                   {totalPages > 1 && (
//         <div className="flex justify-end mt-4 gap-2">
//           <button
//             onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
//             disabled={currentPage === 1}
//             className="w-9 h-9 flex items-center justify-center rounded-lg bg-darkblue1 text-white text-lg font-bold hover:scale-110 transition disabled:opacity-50 disabled:cursor-not-allowed"
//           >
//             <ArrowLeft size={20} />
//           </button>
//           <button
//             onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
//             disabled={currentPage === totalPages}
//             className="w-9 h-9 flex items-center justify-center rounded-lg bg-darkblue1 text-white text-lg font-bold hover:scale-110 transition disabled:opacity-50 disabled:cursor-not-allowed"
//           >
//             <ArrowRight size={20} />
//           </button>
//         </div>
//       )}

//           </div>
//         </div>
//       </div>


//       {/* 🔹 Scroll to Top Button */}
//       {showScrollTop && (
//    <div className="mt-12 mb-2 flex justify-end pr-4 ">
//     <button
//       onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
//     className="bg-Silvergrey text-black font-bold px-4 py-2 rounded-lg shadow-lg hover:scale-110 transition duration-200"
//     >
//       ^
//     </button>
//   </div>
// )}

//       {isAddUserOpen && (
//         <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
//           <div className="bg-white rounded-lg p-6 w-full max-w-xl relative">
//             <h2 className="text-base font-semibold text-center mb-4 text-MediumGrey">
//               {isEditing ? "PDP Fill Templates Tree Widget" : "Add PDP Fill Templates Tree Widget"}
//             </h2>
//             <button
//               onClick={() => {
//                 setIsAddUserOpen(false)
//                 setIsEditing(false)
//                 setFormData({ segmnetname: "", })
//                 setErrors({})
//               }}
//               className="absolute top-3 right-4 text-red-600 font-bold text-xl"
//             >
//               <img src="/icons/MarketAreaatble/cancel.png" alt="close" className="w-5 h-5" />
//             </button>
//             {/* 🔹 Grid Inputs */}
//             <div className="grid grid-cols-1  gap-2">
             



  
// <label className="text-sm font-medium text-black/70">Label</label>

//   {/* More than 1 row → dropdown with suggestions */}
//   {isEditing && tableData.length > 1 ? (
//     <>
//      <div className="relative w-full">
//   <input
//     type="text"
//     value={formData.label}
//     onChange={(e) => {
//       setFormData({ ...formData, label: e.target.value });
//    setShowLabelSuggestions(true);
//     }}
//     onFocus={() =>  setShowLabelSuggestions(true)}
//     onBlur={() => setTimeout(() =>  setShowLabelSuggestions(false), 100)}
//     placeholder="Select or type Category"
//     className={`border w-full mt-1 text-sm px-3 py-2 outline-none focus:ring-1 transition-all
//       ${showlabeluggestions? "rounded-t-md border-b-white" : "rounded-md"}
//       ${errors.showlabeluggestions? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
//     `}
//   />

//   {/* Dropdown Icon */}
//   <img
//     src="/icons/MarketAreaatble/dropdown.png"
//     alt="Dropdown"
//     onClick={() => setShowSegmentSuggestions((prev) => !prev)}
//     className={`w-4 h-4 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
//       showlabeluggestions? "rotate-180" : "rotate-0"
//     }`}
//   />

//   {/* Suggestions */}
//   {showlabeluggestions && (
//     <div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 rounded-b-md shadow-md max-h-40 overflow-y-auto">
//       {Array.from(new Set(tableData.map((item) => item.label))).map((label, idx) => (
//         <div
//           key={idx}
//           onMouseDown={() => {
//             setFormData({ ...formData, label});
//          setShowLabelSuggestions(false);
//           }}
//           className={`w-full px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 ${
//             marcomname === formData.label? "bg-gray-100" : ""
//           }`}
//         >
//           {label}
//         </div>
//       ))}
//     </div>
//   )}
// </div>

//     </>
//   ) : (
//     // Only 1 row OR not editing → plain input
//     <input
//   type="text"
//   value={formData.label}
//   onChange={(e) => {
//     const value = e.target.value;
//     setFormData({ ...formData, label: value });
//   }}
//   placeholder="Enter Label"
//   className={`border rounded-md px-3 py-2 w-full mt-1 text-sm outline-none focus:ring-1 ${
//     errors.label ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
//   }`}
// />

//   )}

//   {errors.label && (
//     <p className="text-red1 text-xs mt-1">{errors.label}</p>
//   )}


//   <div className=" w-full relative">
//   <label className="text-sm font-medium text-black/70">Upload Image</label>

//   <div className="relative w-full mt-1">
//     {/* Clickable Container */}
//     <div
//       className={`border text-sm px-3 py-2 rounded-md w-full flex items-center justify-between cursor-pointer outline-none focus:ring-1 ${
//         errors.image ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
//       }`}
//       onClick={() => imageInputRef.current.click()}
//     >
//       {/* File name / Placeholder */}
//       <span className={`${formData.image ? "text-black" : "text-gray-400"}`}>
//         {formData.image || "Select image"}
//       </span>

//       {/* Image Icon */}
//       <img
//         src="/icons/PdpmasterHomepage/image uplaod.png"
//         alt="Select"
//         className="w-5 h-5 pointer-events-none"
//       />
//     </div>

//     {/* Hidden File Input */}
//     <input
//       type="file"
//       accept="image/*"
//       ref={imageInputRef}
//       className="hidden"
//       onChange={(e) => {
//         const file = e.target.files[0];
//         if (file) {
//           setFormData({ ...formData, image: file.name });
//           setErrors(prev => ({ ...prev, image: "" }));
//         }
//       }}
//     />
//   </div>

//   {/* Error message */}
//   {errors.image && (
//     <p className="text-red1 text-xs mt-1">{errors.image}</p>
//   )}
// </div>


//   <div className=" w-full relative">

//   <label className="text-sm font-medium text-black/70">Parent ID</label>
 
//     <input
//       type="text"
//       value={formData.parentid}
//       onChange={(e) => {
//         const value = e.target.value;
//         setFormData({ ...formData, parentid: value });
//         setShowParentIdSuggestions(true);
//       }}
//       onFocus={() => setShowParentIdSuggestions(true)}
//       onBlur={() => setTimeout(() => setShowParentIdSuggestions(false), 100)}
//       placeholder="Type or select Parent ID"
//       className={`border w-full  text-sm px-3 py-2 outline-none focus:ring-1 transition-all
//         ${showParentIdSuggestions ? "rounded-t-md border-b-white" : "rounded-md"}
//         ${errors.parentid ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
//       `}
//     />

//     {/* Dropdown Icon */}
//     <img
//       src="/icons/MarketAreaatble/dropdown.png"
//       alt="Dropdown"
//       onClick={() => setShowParentIdSuggestions(prev => !prev)}
//       className={`w-4 h-4 absolute right-3 top-9 cursor-pointer transform transition-transform duration-200 ${
//         showParentIdSuggestions ? "rotate-180" : "rotate-0"
//       }`}
//     />

//     {/* Suggestions */}
//     {showParentIdSuggestions && (
//       <div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 rounded-b-md shadow-md max-h-40 overflow-y-auto">
//         {Array.from(
//   new Set([
//     "a", "b", "c", // static options
//     ...tableData.map((item) => item.parentid).filter(Boolean) // dynamic from data
//   ])
// )
//   .sort()
//   .map((id, idx) => (

//             <div
//               key={idx}
//               onMouseDown={() => {
//                 setFormData({ ...formData, parentid: id });
//                 setShowParentIdSuggestions(false);
//               }}
//               className={`w-full px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 ${
//                 formData.parentid === id ? "bg-gray-100" : ""
//               }`}
//             >
//               {id}
//             </div>
//           ))}
//       </div>
//     )}
//   </div>

//   {errors.parentid && (
//     <p className="text-red1 text-xs mt-0">{errors.parentid}</p>
//   )}
// </div>
//            {/* Is Root? */}
//                        <div className="grid grid-cols-2  gap-2">

// <div className="mb-4">
//   <label className="text-sm font-medium text-black/70">Is Root?</label>

//   <div
//     className={`flex items-center gap-4 mt-1 px-3 py-2 rounded-md w-full border focus:ring-1 cursor-pointer
//       ${errors.isroot ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
//     `}
//   >
//     {["Yes", "No"].map((val) => (
//       <label key={val} className="flex items-center gap-1 text-sm">
//         <input
//           type="radio"
//           name="isroot"
//           value={val}
//           checked={formData.isroot === val}
//           onChange={(e) => setFormData({ ...formData, isroot: e.target.value })}
//           className="accent-darkblue1 cursor-pointer"
//         />
//         {val}
//       </label>
//     ))}
//   </div>

//   {/* Error message below */}
//   {errors.isroot && (
//     <p className="text-red1 text-xs mt-1">{errors.isroot}</p>
//   )}
// </div>

// {/* Has Children? */}
// <div className="mb-4">
//   <label className="text-sm font-medium text-black/70">Has Children?</label>

//   <div
//     className={`flex items-center gap-4 mt-1 px-3 py-2 rounded-md w-full border focus:ring-1 cursor-pointer 
//       ${errors.haschild ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
//     `}
//   >
//     {["Yes", "No"].map((val) => (
//       <label key={val} className="flex items-center gap-1 text-sm">
//         <input
//           type="radio"
//           name="haschild"
//           value={val}
//           checked={formData.haschild === val}
//           onChange={(e) => setFormData({ ...formData, haschild: e.target.value })}
//           className="accent-darkblue1 cursor-pointer"
//         />
//         {val}
//       </label>
//     ))}
//   </div>

//   {/* Show error message */}
//   {errors.haschild && (
//     <p className="text-red1 text-xs mt-1">{errors.haschild}</p>
//   )}


//   {/* Parent ID Input/Dropdown Combo */}
// {/* Parent ID Input + Dropdown */}

  

// {/* Image upload input */}



// </div>
// </div>
//             {/* Save Button */}
//             <button
//              onClick={() => {
//   const newErrors = {};
//   // if (!formData.segmnetname) newErrors.segmnetname = "Please enter this field";
//   if (!formData.label) newErrors.label = "Please enter this field";
//     if (!formData.image) newErrors.image = "Please Select image";

//   if (!formData.isroot) newErrors.isroot = "Please select root status";
//   if (!formData.haschild) newErrors.haschild = "Please select child status";
// if (!formData.parentid) newErrors.parentid = "Please select or type parent ID";

//   if (Object.keys(newErrors).length > 0) {
//     setErrors(newErrors);
//     return;
//   }

//   const updatedData = [...tableData];
//  if (isEditing) {
//   updatedData[editIndex] = {
//     ...formData,
//     templates: updatedData[editIndex].templates || [],
//   };
// } else {
//   updatedData.push({
//     ...formData,
// id: tableData.length > 0 ? Math.max(...tableData.map(item => Number(item.id))) + 1 : 1,
//     templates: [],
//   });
// }


//   setTableData(updatedData);

//   // Update Parent ID options – include new ID if not already present
//   const newId = isEditing
//     ? updatedData[editIndex]?.id
//     : updatedData[updatedData.length - 1]?.id;

//   if (newId && !parentIdOptions.includes(newId.toString())) {
//     setParentIdOptions(prev => [...prev, newId.toString()]);
//   }
//   setFormData({
//     segmnetname: "",
//     label: "",
//     isroot: "",
//     haschild: "",
//     parentid:"",
//     image:""
//   });
//   setErrors({});
//   setIsEditing(false);
//   setEditIndex(null);
//   setIsAddUserOpen(false);
// }}

//               className="mt-6 bg-darkblue1 text-sm font-medium text-white px-10 py-1.5 rounded-md hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto"
//             >
//               Save
//             </button>
//          </div>
//        </div>
//       )}

   
// <DeleteModal
//   isOpen={isDeleteModalOpen}
//   onClose={() => setIsDeleteModalOpen(false)}
//   onConfirm={() => {
//     if (deleteIndex !== null) {
//       const updated = tableData.filter((_, i) => i !== deleteIndex);
//       setTableData(updated);
//       setDeleteIndex(null); // reset
//     }
//     setIsDeleteModalOpen(false);
//   }}
// />

//     </div>
//   )
// }

// export default  PDPFillTemplatesExplorer;
