import { useState, useEffect, useRef } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus, ArrowRight } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import Filter from "../../../../../Components/Filter"
import DeleteModal from "../../../../../Components/DeleteModal"
import * as XLSX from "xlsx";

// Mock components - replace with your actual components

function   Xaxismonth() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const dropdownRef = useRef(null)
  const [tableData, setTableData] = useState([])
const [formData, setFormData] = useState({
 
  date: "",
  month: "",
  year: "",
});
  const [isEditing, setIsEditing] = useState(false)
  const [editIndex, setEditIndex] = useState(null)
  const [errors, setErrors] = useState({})
  const [searchQuery, setSearchQuery] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const rowsPerPage = 7
//   const [competenceOptions,setCompetencename]=useState("")
const [deleteIndex, setDeleteIndex] = useState(null); // to track which row to delete
const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
const [showmarcomnamesuggestion, setShowMarcomnamesuggestion] = useState(false);
const [marcomtype, setMarcomtype] = useState("");
const [marcomname, setMarcomname] = useState("");

const [showMarcomTypeSuggestions,setShowMarcomTypeSuggestions] =useState(false);
const [showsegmentSuggestions,setShowSegmentSuggestions] =useState(false);

const [marcomOptions,setMarcomOptions]= useState([
 "Branding","Marketing"
]);

 const filteredData = tableData.filter((item) => {
  const lowerSearch = searchQuery.toLowerCase();

  const matchesSearch =
    item.year?.toString().toLowerCase().includes(lowerSearch) ||
    item.month?.toLowerCase().includes(lowerSearch) ||
    item.date?.toString().toLowerCase().includes(lowerSearch);

  const matchesMarcomType = marcomtype
    ? item.marcomtype?.toLowerCase() === marcomtype.toLowerCase()
    : true;

  const matchesMarcomName = marcomname
    ? item.marcomname?.toLowerCase() === marcomname.toLowerCase()
    : true;

  return matchesSearch && matchesMarcomType && matchesMarcomName;
});
 const fileInputRef = useRef(null)
const handleBulkUploadClick = () => {
    fileInputRef.current.click()
  }





  const totalPages = Math.ceil(filteredData.length / rowsPerPage)
  const paginatedData = filteredData.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage)

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

 
// useEffect(() => {
//   const marcomtypeFromData = tableData
//     .map(item => item.marcomtype?.trim())
//     .filter(val => val && val.length > 0);

//   const baseMarcomType = [  "Branding","Marketing"];

//   setMarcomOptions(Array.from(new Set([...baseMarcomType, ...marcomtypeFromData])));
// }, [tableData]);
const handleDownloadTemplate = () => {
  const headers = [["Sl.NO","Year", "Month ", "Date", ]];

  const worksheet = XLSX.utils.aoa_to_sheet(headers);

  worksheet["!cols"] = [
    { wch: 20 },
    { wch: 30 },
    { wch: 20 },
    { wch: 20 },
    { wch: 25 },
  ];

  const data = [
    {
      "Sl.NO":"1",
      Year: "2025",
      Month: "January",
      Date: "07-08-2025",
      
    }
  ];

  XLSX.utils.sheet_add_json(worksheet, data, {
    origin: "A2", // Avoid overwriting the header
    skipHeader: true
  });

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Users");

  XLSX.writeFile(workbook, "X-axis_Category_Month.xlsx");
};
const handlePreviewAndDownload = () => {
  const tableHeaders = ["Sl.NO", "Year", "Month", "Date"];

  const tableRows = filteredData.map((item, index) => `
    <tr class="${index % 2 === 0 ? 'bg-white' : 'bg-gray-100'} hover:bg-blue-50">
      <td class="px-4 py-6 text-left text-sm">${index + 1}</td>
      <td class="px-4 py-6 text-left text-sm">${item.year || "-"}</td>
      <td class="px-4 py-6 text-left text-sm">${item.month || "-"}</td>
      <td class="px-4 py-6 text-left text-sm">${item.date || "-"}</td>
    </tr>
  `).join("");

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <script src="https://cdn.tailwindcss.com"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
      <title>X-axis Category Month Preview</title>
      <style>
        body { font-family: 'VolvoNovum', sans-serif; margin: 0; background-color: #F8FAFC; }
        .header {
          display: flex;
          justify-content: flex-start;
          align-items: center;
          padding: 10px 32px;
          background: white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          position: sticky;
          top: 0;
          z-index: 10;
        }
        .header img.volvo-logo { height: 70px; width: auto; }
        .table-container { padding: 32px; }
        .table-container table {
          border-collapse: separate;
          border-spacing: 0;
          width: 100%;
          border: 2px solid #5B7C99;
          border-radius: 0.375rem;
          overflow: hidden;
        }
        .table-container th {
          background-color: #5B7C99;
          color: white;
          padding: 16px 8px;
          text-align: left;
          font-size: 1rem;
        }
        .table-container td {
          padding: 24px 8px;
          text-align: left;
          font-size: 0.875rem;
        }
        .download-btn {
          background-color: #1D2B50;
          color: white;
          padding: 10px 24px;
          border-radius: 0.375rem;
          font-weight: 500;
          cursor: pointer;
          border: 2px solid #1D2B50;
          margin-top: 20px;
        }
        .download-btn:hover {
          background-color: white;
          color: #1D2B50;
          border-color: #1D2B50;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Volvo Logo" class="volvo-logo"/>
      </div>

      <div class="table-container">
        <h1 class="text-2xl font-bold mb-4">X-axis Category Month Table</h1>
        <div class="overflow-x-auto">
          <table id="exportTable">
            <thead>
              <tr>${tableHeaders.map(header => `<th>${header}</th>`).join("")}</tr>
            </thead>
            <tbody>${tableRows}</tbody>
          </table>
        </div>
        <button class="download-btn" onclick="downloadAsExcel()">Download</button>
      </div>

      <script>
        function downloadAsExcel() {
          const wb = XLSX.utils.book_new();
          const ws = XLSX.utils.table_to_sheet(document.getElementById('exportTable'));
          XLSX.utils.book_append_sheet(wb, ws, 'XaxisCategoryMonth');
          XLSX.writeFile(wb, 'Xaxis_Category_Month_Table.xlsx');
        }
      </script>
    </body>
    </html>
  `;

  const newWindow = window.open("", "_blank");
  newWindow.document.write(htmlContent);
  newWindow.document.close();
};


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300 mt-20 lg:mt-[170px] ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full flex justify-center">
          <div className="w-full max-w-[1280px] transition-all duration-300 ease-in-out px-4 lg:px-2 xl:px-0">
            {/* 🔹 Heading */}
            <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
              <h2 className="text-base font-medium font-VolvoNovum text-center text-darkblue1 flex items-center justify-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={28}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 rounded-md p-1"
                />
       Trend Chart / X-axis Categories Months
  </h2>
             
            </div>
          {/* 🔹 Controls: Search + Filters + Actions */}
<div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8 w-full">

  {/* 🔸 Left Side: Search + Filters */}
  <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-2 w-full ">
    
    {/* 🔍 Search Input */}
    <div className="w-full sm:w-64 md:w-36 lg:w-80">
      <Searchinput
        onChange={(e) => {
          setSearchQuery(e.target.value);
          setCurrentPage(1);
        }}
        value={searchQuery}
        placeholder="Search"
        className="w-full"
        iconColor="text-black"
        bgColor="bg-FrostWhite"
        borderColor="border-black/60"
        textColor="text-black"
        shadow="shadow-none"
        inputPadding="pl-8 pr-3 py-2"
        iconSize="w-4 h-4"
        iconLeft="left-3"
        inputWidth="w-full"
        focusRing="focus:ring-1 focus:ring-black/60"
        hoverInputClasses="hover:bg-white hover:border-black/60"
      />
    </div>

    {/* 📆 Year Filter */}
   
    {/* 🏷️ Category Filter */}
     
 
 
  </div>

<div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
    
    {/* ➕ Add Dropdown */}
    <div className="relative w-full sm:w-[180px]" ref={dropdownRef}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-2 text-sm rounded-lg flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
      >
        <Plus className="w-4 h-4 stroke-[3]" />
        Add New
      </button>

      {open && (
        <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1 rounded-lg shadow-lg z-50">
          <button
            className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-2"
            onClick={() => {
              setIsAddUserOpen(true);
              setOpen(false);
            }}
          >
            <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpmasterHomepage/xaxismonth.png"alt="add new" className="w-4 h-4" />
            Add X-axis Category
          </button>
         <button
  onClick={() => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = ".xlsx, .xls" // Accept only Excel files
    input.onchange = (e) => {
      const file = e.target.files[0]
      if (file && (file.name.endsWith(".xlsx") || file.name.endsWith(".xls"))) {
        handleBulkUploadClick(file) // your upload logic
      }
      // If not valid, do nothing (no alert)
    }
    input.click()
    setOpen(false)
  }}
  className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-1 hover:rounded-b-lg whitespace-nowrap"
>
  <img
    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/bulkupload.png"
    alt="bulk upload"
    className="w-5 h-5"
  />
  Bulk Upload
</button>


  <button
                      // onClick={() => {
                      //   handleBulkUploadClick()
                      //   setOpen(false)
                      // }}
                              onClick={handleDownloadTemplate}

                      className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-1 hover:rounded-b-lg whitespace-nowrap"
                    >
 <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/download.png" alt="Download" className="w-4 h-4" />                     
 Bulk upload Template
                    </button>

        </div>
      )}
    </div>
     <button
      onClick={handlePreviewAndDownload}
      className="group relative text-sm bg-white text-darkblue1 px-4 py-2 border border-darkblue1 rounded-md flex items-center gap-1 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
    >
      <img
        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpmasterHomepage/download.png"
        alt="download"
        className="w-3 h-3 group-hover:hidden"
      />
      <img
        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpmasterHomepage/download1.png"
        alt="download-white"
        className="w-3 h-3 hidden group-hover:block"
      />
      <span className="font-semibold">Download</span>
    </button>        
    </div>
   </div>
    {/* 🔹 Table Section */}
          <div className="bg-white shadow-md rounded-lg border border-Dustyblue overflow-hidden">
  <table className="w-full table-auto text-sm cursor-pointer">
    <thead className="bg-Dustyblue text-white text-left">
      <tr>
        <th className="px-4 py-4 text-base font-medium w-[20%]">Year</th>
              <th className="px-4 py-4 text-base font-medium w-[20%]">Month </th>
        <th className="px-4 py-4 text-base font-medium w-[20%]">Date</th>

        <th className="px-4 py-4 text-base font-medium w-[5%] ">Actions</th>
      </tr>
    </thead>

    <tbody className="text-black">
      {paginatedData.length > 0 ? (
    paginatedData.map((item, index) => (   
        <tr key={index} className="odd:bg-white even:bg-gery1 hover:bg-lightBlue/50">
          {/* Competence Type */}
          <td className="px-4 py-6 ">
                {item.year || "-"}     
          </td>
<td className="px-4 py-6 ">
                {item.month || "-"}     
          </td>
          <td className="px-4 py-6 ">
                {item.date || "-"}     
          </td>
          {/* Competence Name */}
        
          {/* Actions */}
          <td className="px-4 py-4">
            <div className="flex items-center gap-2">
              {/* Edit */}
              <div className="relative group inline-block">
               <button
 onClick={() => {
  let formattedDate = "";
  if (item.date && item.date.includes("-")) {
    const parts = item.date.split("-");
    if (parts.length === 3) {
      const [dd, mm, yyyy] = parts;
      formattedDate = `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
    }
  }

  setFormData({
    date: formattedDate,
    month: item.month || "",
    year: item.year || "",
  });

  setIsAddUserOpen(true);
  setIsEditing(true);
  setEditIndex(index);
}}


>
  <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png" alt="edit" className="w-4 h-4" />
</button>

                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-0 transition-opacity duration-200 z-50">
                  Edit
                </span>
              </div>

              {/* Activate / Deactivate */}
              <div className="relative group inline-block">
                <button
                  onClick={() => {
                    const updated = [...tableData];
                    updated[index].isActive = !updated[index].isActive;
                    setTableData(updated);
                  }}
                >
                  <img
                    src={
                      item.isActive
                        ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/active.png"
                        : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/deactive.png"
                    }
                    alt={item.isActive ? "Active" : "Deactive"}
                    className="w-4 h-4"
                  />
                </button>
                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-0 transition-opacity duration-200 z-50">
                  {item.isActive ? "Deactivate" : "Activate"}
                </span>
              </div>

              {/* Delete */}
              <div className="relative group inline-block">
                <button
                  onClick={() => {
                    setDeleteIndex(index);
                    setIsDeleteModalOpen(true);
                  }}
                >
                  <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpmasterHomepage/delete.png" alt="delete" className="w-4 h-4" />
                </button>
                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-0 transition-opacity duration-200 z-50">
                  Delete
                </span>
              </div>
            </div>
          </td>
        </tr>
      ))
      ) : (
        <tr>
          <td colSpan="4" className="px-4 py-6 text-center italic text-gray-500 italic">
            No data found
          </td>
        </tr>
      )}
    </tbody>
  </table>
</div>

                  {totalPages > 1 && (
        <div className="flex justify-end mt-4 gap-2">
          <button
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="w-9 h-9 flex items-center justify-center rounded-lg bg-darkblue1 text-white text-lg font-bold hover:scale-110 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ArrowLeft size={20} />
          </button>
          <button
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="w-9 h-9 flex items-center justify-center rounded-lg bg-darkblue1 text-white text-lg font-bold hover:scale-110 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ArrowRight size={20} />
          </button>
        </div>
      )}

          </div>
        </div>
      </div>


      {/* 🔹 Scroll to Top Button */}
      {showScrollTop && (
   <div className="mt-12 mb-2 flex justify-end pr-4 ">
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
    className="bg-Silvergrey text-black font-bold px-4 py-2 rounded-lg shadow-lg hover:scale-110 transition duration-200"
    >
      ^
    </button>
  </div>
)}

    {isAddUserOpen && (
  <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
    <div className="bg-white rounded-lg p-6 w-full max-w-xl relative">
      <h2 className="text-base font-semibold text-center mb-4 text-darkblue1">
        {isEditing ? "Edit X-axis Categories Months" : "Add X-axis Categories Months"}
      </h2>

      <button
        onClick={() => {
          setIsAddUserOpen(false)
          setIsEditing(false)
          setFormData({ date: "", month: "", year: "" })
          setErrors({})
        }}
        className="absolute top-3 right-4 text-red-600 font-bold text-xl"
      >
        <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" alt="close" className="w-5 h-5" />
      </button>

      <div className="grid grid-cols-1 gap-4">
        {/* Date */}
        <div className="relative w-full">
          <label className="text-sm font-medium text-black/70">Date</label>
          <input
            type="date"
            value={formData.date}
            onChange={(e) => {
              const dateVal = e.target.value;
              const dateObj = new Date(dateVal);
              const extractedMonth = dateObj.toLocaleString("default", { month: "long" });
              const extractedYear = dateObj.getFullYear().toString();

              setFormData({
                ...formData,
                date: dateVal,
                month: extractedMonth,
                year: extractedYear
              });
              setErrors((prev) => ({ ...prev, date: "" }));
            }}
            placeholder="DD-MM-YY"
            className={`mt-1 px-3 py-2 text-sm rounded-md border w-full outline-none focus:ring-1
              ${errors.date ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
            `}
          />
          {errors.date && <p className="text-red1 text-xs mt-1">{errors.date}</p>}
        </div>

        {/* Month */}
        <div className="w-full">
          <label className="text-sm font-medium text-black/70">Month</label>
          <input
            type="text"
            value={formData.month}
            onChange={(e) =>
              setFormData({ ...formData, month: e.target.value })
            }
            placeholder="Enter Month Name"
            className={`mt-1 px-3 py-2 text-sm rounded-md border w-full outline-none focus:ring-1
              ${errors.month ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
            `}
          />
          {errors.month && <p className="text-red1 text-xs mt-1">{errors.month}</p>}
        </div>
      </div>

      {/* Save Button */}
      <button
        onClick={() => {
          const newErrors = {};
          if (!formData.date) newErrors.date = "Please select a date";
          if (!formData.month) newErrors.month = "Please enter month name";

          if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
            return;
          }

          const updatedData = [...tableData];
          const [yyyy, mm, dd] = formData.date.split("-");
const formattedDate = `${dd}-${mm}-${yyyy}`;

const newItem = {
  date: formattedDate, // ✅ Store in display-friendly format
  month: formData.month,
  year: formData.year,
  isActive: true,
};


          if (isEditing) {
            updatedData[editIndex] = newItem;
          } else {
            updatedData.push(newItem);
          }

          setTableData(updatedData);
          setFormData({ date: "", month: "", year: "" });
          setErrors({});
          setIsEditing(false);
          setEditIndex(null);
          setIsAddUserOpen(false);
        }}
        className="mt-6 bg-darkblue1 text-sm font-medium text-white px-10 py-1.5 rounded-md hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto"
      >
        Save
      </button>
    </div>
  </div>
)}

   
<DeleteModal
  isOpen={isDeleteModalOpen}
  onClose={() => setIsDeleteModalOpen(false)}
  onConfirm={() => {
    if (deleteIndex !== null) {
      const updated = tableData.filter((_, i) => i !== deleteIndex);
      setTableData(updated);
      setDeleteIndex(null); // reset
    }
    setIsDeleteModalOpen(false);
  }}
/>

    </div>
  )
}

export default  Xaxismonth;
