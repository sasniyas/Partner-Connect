import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import Filter from "../../../../../Components/Filter"
import DeleteModal from "../../../../../Components/DeleteModal"
import * as XLSX from "xlsx";
import DeactivateStatus from "../../../../../Components/DeactivateStatus"
import ActivateStatus from "../../../../../Components/ActivateStatus"
import { getMarketAreas } from "../../../../../services/pdpMaster/marketArea.service.js";
import { getDealers } from "../../../../../services/pdpMaster/dealership.service.js";
import { saveAs } from "file-saver"
import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../../../services/download/bluckDownload.service.js"
import useCRUDWithReset from "../../../../../util/useCRUDWithReset"
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation.js"
import { 
  getNationalKeyAccounts, 
  addNationalKeyAccount, 
  updateNationalKeyAccount, 
  toggleNationalKeyAccount, 
  deleteNationalKeyAccount 
} from "../../../../../services/pdpMaster/nationalKeyAccount.service.js";
import { ChevronDown } from "lucide-react"
import { ChevronUp } from "lucide-react"
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
function KeyAccount() {
  // API Data States
  const [marketAreas, setMarketAreas] = useState([]);
  const [dealers, setDealers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedYears, setSelectedYears] = useState([]);
  const [tableData, setTableData] = useState([]);
  // ✅ DYNAMIC YEAR OPTIONS FROM DATA
  const yearOptions = useMemo(() => {
    const years = new Set(tableData.map(item => item.year).filter(Boolean));
    return Array.from(years).sort((a, b) => parseInt(b) - parseInt(a));
  }, [tableData]);

  const [menuOpen, setMenuOpen] = useState(false)
  const navigate = useNavigate()
  const [selectedStatus, setSelectedStatus] = useState([]);
  const statusOptions = ["Active", "Inactive"];

  const [selectedRow, setSelectedRow] = useState(null);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null);
  const [hoveredCell, setHoveredCell] = useState(null);
  const popupRef = useRef(null)
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const dropdownRef = useRef(null)
  const [formData, setFormData] = useState({
    year: "",
    market_area_id: "",
    dealer_id: "",
    key_account_customer: ""
  })
  const [isEditing, setIsEditing] = useState(false)
  const [editIndex, setEditIndex] = useState(null)
  const [errors, setErrors] = useState({})
  const [searchQuery, setSearchQuery] = useState("")
  const marketRef = useRef(null);
  const dealerRef = useRef(null);

  const [deleteIndex, setDeleteIndex] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [keyaccount, setKeyaccount] = useState("")
  const [marketarea, setMarketarea] = useState([])
  const [dealership, setDealership] = useState("")
  const [dealershipOptions, setDealershipOptions] = useState([])

  const [marketareaOptionssuggestions, setMarketareaoptionsSuggestions] = useState(false);
  const [dealershipOptionsSuggestions, setDealershipoptionsSuggestions] = useState(false);

  // ✅ NEW: Search states for dropdowns
  const [marketAreaSearch, setMarketAreaSearch] = useState("");
  const [dealershipSearch, setDealershipSearch] = useState("");

  const fileInputRef = useRef(null)
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  // ✅ Filtered market areas based on search (for popup form)
  const filteredMarketAreas = useMemo(() => {
    if (!marketAreaSearch.trim()) return marketAreas;
    return marketAreas.filter(area =>
      area.marketarea.toLowerCase().includes(marketAreaSearch.toLowerCase())
    );
  }, [marketAreas, marketAreaSearch]);

  // ✅ Filtered dealers based on search (for popup form)
  const filteredDealers = useMemo(() => {
    if (!dealershipSearch.trim()) return dealers;
    return dealers.filter(dealer =>
      dealer.dealerName.toLowerCase().includes(dealershipSearch.toLowerCase())
    );
  }, [dealers, dealershipSearch]);

  // ═══════════════════════════════════════════════════════
  // 🔗 DEPENDENT TABLE FILTER OPTIONS (Market Area → Dealership)
  // ═══════════════════════════════════════════════════════

  // Market Area filter options - all unique market areas from tableData (no dependency)
  const filterMarketAreaOptions = useMemo(() => {
    return [...new Set(tableData.map((i) => i.marketarea).filter(Boolean))].sort();
  }, [tableData]);

  // Dealership filter options - depends on selected market areas
  const filterDealershipOptions = useMemo(() => {
    let filtered = tableData;
    if (marketarea.length > 0) {
      filtered = filtered.filter((item) => marketarea.includes(item.marketarea));
    }
    return [...new Set(filtered.map((i) => i.dealer_name).filter(Boolean))].sort();
  }, [tableData, marketarea]);

  // ═══════════════════════════════════════════════════════
  // 🔄 CASCADING FILTER CHANGE HANDLERS
  // ═══════════════════════════════════════════════════════

  // When Market Area changes → reset Dealership
  const handleMarketAreaFilterChange = (name, value) => {
    setMarketarea(value);
    setDealership([]);
  };

  // Dealership change - no child to reset
  const handleDealershipFilterChange = (name, value) => {
    setDealership(value);
  };

  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc");
        return;
      }
      if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
        return;
      }
    }
    setSortKey(key);
    setSortOrder("asc");
  };

  // API Loading Functions
  const loadMarketAreas = async () => {
    try {
      setLoading(true);
      const data = await getMarketAreas();
      setMarketAreas(data || []);
    } catch (error) {
      // console.error("Error loading market areas:", error);
      setError("Failed to load market areas");
    } finally {
      setLoading(false);
    }
  };

  const loadDealers = async () => {
    try {
      setLoading(true);
      const data = await getDealers();
      setDealers(data || []);
    } catch (error) {
      // console.error("Error loading dealers:", error);
      setError("Failed to load dealers");
    } finally {
      setLoading(false);
    }
  };

  const loadNationalKeyAccounts = async () => {
    try {
      setLoading(true);
      const data = await getNationalKeyAccounts();
      const reversedData = (data || []).reverse();
      
      // ✅ CRITICAL FIX: Transform year to string for ALL records
      const transformedData = reversedData.map(item => ({
        ...item,
        year: item.year ? String(item.year) : ""
      }));
      
      setTableData(transformedData);             
    } catch (error) {
      // console.error("Error loading national key accounts:", error);
      setError("Failed to load national key accounts");
    } finally {
      setLoading(false);
    }
  };

  // ✅ FILTERED DATA - NO LAZY LOADING
  const filteredData = useMemo(() => {
    return tableData?.filter(item => {
      const matchesSearch = Object.values(item).some(val =>
        val?.toString().toLowerCase().includes(searchQuery.toLowerCase())
      );
      const matchesYear = selectedYears.length
        ? selectedYears.some((year) => String(year) === String(item.year))
        : true;
      const matchMarketarea = marketarea.length > 0 ? marketarea.includes(item.marketarea) : true;
      const matchDealership = dealership.length > 0 ? dealership.includes(item.dealer_name) : true;
      const matchKeyaccount = keyaccount.length > 0 ? keyaccount.includes(item.key_account_customer) : true;
      const matchesStatus =
        selectedStatus.length > 0
          ? selectedStatus.some(status =>
              (status === "Active" && item.isActive === 1) ||
              (status === "Inactive" && item.isActive === 0)
            )
          : true;

      return matchesSearch && matchMarketarea && matchDealership && matchKeyaccount && matchesStatus && matchesYear;
    }) || [];
  }, [tableData, searchQuery, marketarea, dealership, keyaccount, selectedStatus, selectedYears]);

  // ✅ SORTED DATA - USE FILTERED DATA DIRECTLY (NO LAZY LOADING)
  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredData;

    return [...filteredData].sort((a, b) => {
      let valA = a[sortKey] ?? "";
      let valB = b[sortKey] ?? "";

      // Numeric sort for year
      if (sortKey === "year") {
        valA = parseInt(valA) || 0;
        valB = parseInt(valB) || 0;
        return sortOrder === "asc" ? valA - valB : valB - valA;
      }

      // String sort for other columns
      return sortOrder === "asc"
        ? valA.toString().localeCompare(valB.toString(), undefined, { numeric: true, sensitivity: "base" })
        : valB.toString().localeCompare(valA.toString(), undefined, { numeric: true, sensitivity: "base" });
    });
  }, [filteredData, sortKey, sortOrder]);
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchQuery: { setter: setSearchQuery, resetValue: "" },
    selectedYears: { setter: setSelectedYears, resetValue: [] },
    marketarea:{setter :setMarketarea,resetValue :[]},
    dealership:{setter :setDealership,resetValue:[]},
    selectedStatus:{setter:setSelectedStatus,resetValue:[]}
  }
);

  // Load all data on component mount
  useEffect(() => {
    const loadAllData = async () => {
      await Promise.all([
        loadMarketAreas(),
        loadDealers(),
        loadNationalKeyAccounts()
      ]);
    };
    loadAllData();
  }, []);

  useEffect(() => {
    const handleFocus = () => {
      loadNationalKeyAccounts();
    };

    window.addEventListener("focus", handleFocus);
    return () => window.removeEventListener("focus", handleFocus);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (marketRef.current && !marketRef.current.contains(event.target)) {
        setMarketareaoptionsSuggestions(false);
        setMarketAreaSearch("");
      }
      if (dealerRef.current && !dealerRef.current.contains(event.target)) {
        setDealershipoptionsSuggestions(false);
        setDealershipSearch("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const allDealers = dealers.map(d => d.dealerName);
    setDealershipOptions(allDealers);
  }, [dealers]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleDownloadTemplate = async () => {
    if (!marketAreas.length || !dealers.length) {
      // alert("Please load Market Areas and Dealers first.")
      return
    }

    const workbook = new ExcelJS.Workbook()
    const sheet = workbook.addWorksheet("National Key Accounts")

    sheet.columns = [
      { header: "Year", key: "year", width: 15 },
      { header: "Market Area", key: "market_area", width: 30 },
      { header: "Dealership", key: "dealer_name", width: 50 },
      { header: "Key Account Customer", key: "key_account_customer", width: 30 },
    ]

    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } }
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      }
      cell.alignment = { vertical: "middle", horizontal: "left" }
      cell.protection = { locked: true }
    })

    const sampleRow = sheet.addRow({
      year: "2024",
      market_area: marketAreas[0]?.marketarea || "",
      dealer_name: dealers[0]?.dealerName || "",
      key_account_customer: "Sample Customer",
    })

    sampleRow.eachCell((cell) => {
      cell.protection = { locked: false }
      cell.alignment = { vertical: "middle", horizontal: "left" }
    })

    for (let i = 3; i <= 1000; i++) {
      const row = sheet.getRow(i)
      for (let col = 1; col <= 4; col++) {
        const cell = row.getCell(col)
        cell.protection = { locked: false }
        cell.alignment = { vertical: "middle", horizontal: "left" }
      }
    }

    const marketAreaList = marketAreas.map((ma) => ma.marketarea).join(",")
    const dealerList = dealers.map((d) => d.dealerName).join(",")

   

    sheet.dataValidations.add("B2:B1000", {
      type: "list",
      allowBlank: false,
      formulae: [`"${marketAreaList}"`],
      showErrorMessage: true,
      errorTitle: "Invalid Market Area",
      error: "Please select Market Area from dropdown only",
    })

    sheet.dataValidations.add("C2:C1000", {
      type: "list",
      allowBlank: false,
      formulae: [`"${dealerList}"`],
      showErrorMessage: true,
      errorTitle: "Invalid Dealer",
      error: "Please select Dealer from dropdown only",
    })

    await sheet.protect("password123", {
      selectLockedCells: true,
      selectUnlockedCells: true,
      formatCells: false,
      formatColumns: true,
      formatRows: true,
      insertRows: true,
      deleteRows: true,
      insertColumns: false,
      deleteColumns: false,
    })

    const buffer = await workbook.xlsx.writeBuffer()
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })

    saveAs(blob, "National_Key_Accounts_Template.xlsx")
  }

  const handleBulkUploadNavigate = () => {
    navigate("/master/pdp/nationalkeyaccount/preview");
    setOpen(false);
  };

  const handlePreviewAndDownload = async () => {
  if (!sortedData || sortedData.length === 0) return;
  try {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("National Key Accounts");

    sheet.columns = [
      { header: "Sl. No", key: "slNo", width: 10 },
      { header: "Year", key: "year", width: 15 },
      { header: "Market Area", key: "market_area", width: 20 },
      { header: "Dealership", key: "dealer_name", width: 40 },
      { header: "Key Account Customer", key: "key_account_customer", width: 75 },
      { header: "Status", key: "status", width: 15 },
    ];

    // Header styling: all left-aligned
    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" }; // ✅ all left
    });

    // Add data rows
    sortedData.forEach((item, index) => {
      sheet.addRow({
        slNo: index + 1,
        year: item.year || "",
        market_area: item.market_area || item.marketarea || "",
        dealer_name: item.dealer_name || item.dealerName || "",
        key_account_customer: item.key_account_customer || "",
        status: item.isActive ? "Active" : "Inactive",
      });
    });

    // Make all columns left-aligned
    sheet.columns.forEach((col) => {
      col.alignment = { horizontal: "left" };
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const file = new File([blob], "National_Key_Accounts.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const response = await uploadTempFile(file); 
    const fileUrl = response
      ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
      : null;

    if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    }
  } catch (error) {
    // console.error("Preview generation failed:", error);
  }
};
useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
    document.getElementById("submitkeyaccountBtn")?.click();
  },

  onCancel: () => {
    setIsAddUserOpen(false);
    setIsEditing(false);
    setFormData({ year: "", market_area_id: "", dealer_id: "", key_account_customer: "" });
                  setErrors({});
  },
});


  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300  ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full  transition-all duration-300 ease-in-out ">
            {/* 🔹 Heading */}
            <div className="flex items-center justify-between mb-2 flex-wrap gap-4">
              <h2 className="text-base font-medium font-VolvoNovum text-darkblue1 flex items-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1  p-1"
                />
                PDP Data / National Key Accounts
              </h2>
            </div>

            {/* ═══════════════════════════════════════════════════════
                🔗 TABLE FILTERS - DEPENDENT/CASCADING
                Market Area → Dealership
            ═══════════════════════════════════════════════════════ */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 md:gap-12 lg:gap-18 mb-2">
              <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">      
                {/* 🔍 Search Input */}
                <Searchinput
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                  }}
                  value={searchQuery}
                  placeholder="Search"
                  className="w-[1/2]"
                  iconColor="text-black"
                  bgColor="bg-FrostWhite"
                  borderColor="border-black/60"
                  textColor="text-black"
                  shadow="shadow-none"
                  inputPadding="pl-6 pr-3 py-1.5"
                  iconSize="w-3 h-3"
                  iconLeft="left-3"
                  inputWidth="w-full"
                  focusRing="focus:ring-1 focus:ring-black/60"
                  hoverInputClasses="hover:bg-white hover:border-black/60"
                />

                {/* Year Filter (independent) */}
                <Filter
                  name="year"
                  placeholder="Year"
                  options={yearOptions}
                  customWidth="w-[10px]"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black"
                  openBgColor="bg-white"
                  textColor="text-black"
                  value={selectedYears}
                  onChange={(name, value) => {
                    setSelectedYears(value);
                  }}
                />

                {/* Market Area Filter (parent - resets Dealership) */}
                <Filter
                  name="marketarea"
                  placeholder="Market Area"
                  options={filterMarketAreaOptions}
                  customWidth="w-[120px]"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"    
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  textColor="text-black"
                  value={marketarea}
                  onChange={handleMarketAreaFilterChange}
                />

                {/* Dealership Filter (depends on Market Area) */}
                <Filter
                  name="dealer"
                  placeholder="Dealership"
                  customWidth="w-[150px]"
                  options={filterDealershipOptions}
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"    
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black"
                  openBgColor="bg-white"
                  textColor="text-black"
                  value={dealership}
                  onChange={handleDealershipFilterChange}
                />

                {/* Status Filter (independent) */}
                <Filter
                  name="status"
                  placeholder="Status"
                  options={statusOptions}
                  value={selectedStatus}
                  customWidth="w-[80px]"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black"
                  openBgColor="bg-white"
                  textColor="text-black"
                  onChange={(name, value) => {
                    setSelectedStatus(value);
                  }}
                />
              </div>

              {/* 🔸 Right Side: Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                {/* ➕ Add Dropdown */}
                <div className="relative w-full sm:w-[180px]" ref={dropdownRef}>
                  <button
                    onClick={() => setOpen(!open)}
                    className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-1.5 text-xs  flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
                  >
                    <Plus className="w-3 h-3 stroke-[3]" />
                    Add New
                  </button>

                  {open && (
                    <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1  shadow-lg z-50">
                      <button
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 "
                        onClick={() => {
                          setIsAddUserOpen(true);
                          setOpen(false);
                        }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                          <g clipPath="url(#clip0_1415_1601)">
                            <path d="M15.02 6.15333L13.1066 2.82L12.7733 3.01333C12.4828 3.18028 12.1536 3.26802 11.8185 3.26776C11.4834 3.2675 11.1543 3.17925 10.8641 3.01185C10.5738 2.84445 10.3326 2.60377 10.1646 2.31388C9.99657 2.02399 9.90762 1.69506 9.90665 1.36V1H6.09331V1.38667C6.09234 1.72173 6.00339 2.05066 5.83537 2.34055C5.66735 2.63044 5.42615 2.87112 5.1359 3.03852C4.84565 3.20592 4.51653 3.29416 4.18147 3.29442C3.84641 3.29468 3.51715 3.20695 3.22665 3.04L2.89331 2.84667L0.97998 6.18L1.33331 6.34667C1.63052 6.51181 1.87816 6.75342 2.05058 7.04646C2.22299 7.33951 2.31391 7.67333 2.31391 8.01333C2.31391 8.35334 2.22299 8.68716 2.05058 8.9802C1.87816 9.27325 1.63052 9.51486 1.33331 9.68L0.993314 9.87333L2.90665 13.2067L3.23998 13.0133C3.53049 12.8464 3.85974 12.7587 4.19481 12.7589C4.52987 12.7592 4.85899 12.8474 5.14923 13.0148C5.43948 13.1822 5.68068 13.4229 5.8487 13.7128C6.01672 14.0027 6.10567 14.3316 6.10665 14.6667V15.0533H9.91998V14.6667C9.92096 14.3316 10.0099 14.0027 10.1779 13.7128C10.3459 13.4229 10.5871 13.1822 10.8774 13.0148C11.1676 12.8474 11.4968 12.7592 11.8318 12.7589C12.1669 12.7587 12.4961 12.8464 12.7866 13.0133L13.12 13.2067L15.0333 9.87333L14.6666 9.65333C14.3694 9.48819 14.1218 9.24658 13.9494 8.95354C13.777 8.66049 13.686 8.32667 13.686 7.98667C13.686 7.64666 13.777 7.31284 13.9494 7.0198C14.1218 6.72675 14.3694 6.48514 14.6666 6.32L15.02 6.15333Z" stroke="black" strokeMiterlimit="10"/>
                            <path d="M7.99993 8.63316C9.05295 8.63316 9.90659 7.77951 9.90659 6.72649C9.90659 5.67347 9.05295 4.81982 7.99993 4.81982C6.94691 4.81982 6.09326 5.67347 6.09326 6.72649C6.09326 7.77951 6.94691 8.63316 7.99993 8.63316Z" stroke="black" strokeMiterlimit="10"/>
                            <path d="M4.81982 12.8201V11.8201C4.81982 10.9767 5.15486 10.1679 5.75122 9.57154C6.34759 8.97517 7.15644 8.64014 7.99982 8.64014C8.84321 8.64014 9.65206 8.97517 10.2484 9.57154C10.8448 10.1679 11.1798 10.9767 11.1798 11.8201V12.8201" stroke="black" strokeMiterlimit="10"/>
                          </g>
                          <defs>
                            <clipPath id="clip0_1415_1601">
                              <rect width="16" height="16" fill="white"/>
                            </clipPath>
                          </defs>
                        </svg>
                        Add National key Accounts
                      </button>
                      
                      <button
                        onClick={handleBulkUploadNavigate}
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
                        </svg>
                        Bulk Upload
                      </button>

                      <button
                        onClick={handleDownloadTemplate}
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2  whitespace-nowrap"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
                          <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
                          <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                          <path d="M1 14.75H12" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        Bulk upload Template
                      </button>
                    </div>
                  )}
                </div>

                {/* ⬇️ Download Button */}
                <button
                  onClick={handlePreviewAndDownload}
                  className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1  flex items-center gap-1 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
                    <path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D"/>
                  </svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" className="w-3 h-3 hidden group-hover:block">
                    <path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white"/>
                  </svg>
                  <span className="font-semibold">Download</span>
                </button>
              </div>
            </div>

            {/* ✅ RESPONSIVE TABLE */}
            <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
              <div
              ref={tableContainerRef}
                className="overflow-y-auto relative"
                style={{
                  scrollbarWidth: "none",
                  msOverflowStyle: "none",
                  maxHeight: sortedData.length > 8 ? "calc(100vh - 220px)" : "auto",
                }}
                onScroll={handleTableScroll}
              >
                <style jsx>{`
                  div::-webkit-scrollbar {
                    display: none;
                  }
                `}</style>
                
                <table className="w-full text-xs whitespace-nowrap border-collapse">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                    <tr>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none hover:bg-Dustyblue/80 transition"
                        onClick={() => handleSort("year")}
                      >
                        <div className="flex items-center gap-1">
                          <span className="whitespace-nowrap">Year</span>
                          {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

                          {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white flex-shrink-0" />}
                          {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white flex-shrink-0" />}
                        </div>
                      </th>

                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[15%] cursor-pointer select-none hover:bg-Dustyblue/80 transition"
                        onClick={() => handleSort("marketarea")}
                      >
                        <div className="flex items-center gap-1">
                          <span className="whitespace-nowrap">Market Area</span>
                          {sortKey === "marketarea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white flex-shrink-0" />}
                          {sortKey === "marketarea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white flex-shrink-0" />}
                        </div>
                      </th>

                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[25%] cursor-pointer select-none hover:bg-Dustyblue/80 transition"
                        onClick={() => handleSort("dealer_name")}
                      >
                        <div className="flex items-center gap-1">
                          <span className="whitespace-nowrap">Dealership</span>
                          {sortKey === "dealer_name" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white flex-shrink-0" />}
                          {sortKey === "dealer_name" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white flex-shrink-0" />}
                        </div>
                      </th>

                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%] cursor-pointer select-none hover:bg-Dustyblue/80 transition"
                        onClick={() => handleSort("key_account_customer")}
                      >
                        <div className="flex items-center gap-1">
                          <span className="whitespace-nowrap">Key Account Customer</span>
                          {sortKey === "key_account_customer" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white flex-shrink-0" />}
                          {sortKey === "key_account_customer" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white flex-shrink-0" />}
                        </div>
                      </th>

                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 text-center font-medium w-[10%]">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-black">
                    {loading && tableData.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-2 py-8 text-center text-gray-500">
                          <div className="flex items-center justify-center gap-2">
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                            <span>Loading...</span>
                          </div>
                        </td>
                      </tr>
                    ) : sortedData.length > 0 ? (
                      sortedData.map((item, index) => (
                        <tr
                          key={item.id || index}
                          className={`hover:bg-lightBlue/50 text-xs ${item.isActive === 1 ? "text-black" : "text-gray-400"}`}
                        >
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[4rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.year?.toString().length > 4)
                                    setHoveredCell(item.id + "-year");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.year || "-"}
                              </p>
                              {hoveredCell === item.id + "-year" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                  {item.year}
                                </span>
                              )}
                            </div>
                          </td>

                         <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs w-[20rem]">
  <div className="relative">
    <p
      className="block max-w-[20rem] truncate cursor-pointer"
      onMouseEnter={() => {
        if (item.marketarea && item.marketarea.length > 15) {
          setHoveredCell(item.id + "-marketarea");
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.marketarea || "-"}
    </p>

    {hoveredCell === item.id + "-marketarea" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-nowrap transform -translate-x-1/2 z-50">
        {item.marketarea}
      </span>
    )}
  </div>
</td>
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs w-[20rem]">
  <div className="relative">
    <p
      className="block max-w-[20rem] truncate cursor-pointer"
      onMouseEnter={() => {
        if (item.dealer_name && item.dealer_name.length > 30) {
          setHoveredCell(item.id + "-dealer");
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.dealer_name || "-"}
    </p>

    {hoveredCell === item.id + "-dealer" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-nowrap  transform -translate-x-1/2 z-50">
        {item.dealer_name}
      </span>
    )}
  </div>
</td>
<td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs w-[20rem]">
  <div className="relative">
    <p
      className="block max-w-[20rem] truncate cursor-pointer"
      onMouseEnter={() => {
        if (
          item.key_account_customer &&
          item.key_account_customer.length > 50
        ) {
          setHoveredCell(item.id + "-keyAccount");
        }
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.key_account_customer || "-"}
    </p>

    {hoveredCell === item.id + "-keyAccount" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-nowrap  transform -translate-x-1/2 z-50">
        {item.key_account_customer}
      </span>
    )}
  </div>
</td>

                          <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                            <div className="flex items-center justify-center gap-2">
                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    const marketArea = marketAreas.find(area => area.marketarea === item.marketarea);
                                    const dealer = dealers.find(d => d.dealerName === item.dealer_name);
                                    
                                    setFormData({
                                      year: item.year || "",
                                      market_area_id: marketArea ? marketArea.id : "",
                                      dealer_id: dealer ? dealer.id : "",
                                      key_account_customer: item.key_account_customer || "",
                                    });
                                    setIsAddUserOpen(true);
                                    setIsEditing(true);
                                    setEditIndex(item.id);
                                  }}
                                  className="p-1 hover:scale-110 transition"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                    <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                                    <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 z-0 whitespace-nowrap">
                                  Edit
                                </span>
                              </div>

                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setSelectedRow(item.id);
                                    if (item.isActive === 1) {
                                      setShowDeactivateModal(true);
                                    } else {
                                      setShowActivateModal(true);
                                    }
                                  }}
                                  className="p-1 hover:scale-110 transition"
                                >
                                  {item.isActive === 1 ? (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 21 23" fill="none">
                                      <path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                    </svg>
                                  ) : (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                      <path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                    </svg>
                                  )}
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                  {item.isActive === 1 ? "Deactivate" : "Activate"}
                                </span>
                              </div>

                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setDeleteIndex(item.id);
                                    setIsDeleteModalOpen(true);
                                  }}
                                  className="p-1 hover:scale-110 transition"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                                    <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 z-0 whitespace-nowrap">
                                  Delete
                                </span>
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="px-2 py-8 text-center italic text-gray-500">
                          No data found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
               {showScrollButtons && (
            <div className="fixed bottom-16 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

            </div>
          </div>
        </div>
      </div>

      {/* Add/Edit Modal - Popup form dropdowns remain INDEPENDENT (not cascading) */}
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center p-4">
          <div 
          ref={popupRef}
          className="bg-white p-6 w-full max-w-md relative rounded">
            <h2 className="text-base font-semibold text-center mb-4 text-MediumGrey">
              {isEditing ? "Edit National Key Account" : "Add National Key Accounts"}
            </h2>

            <button
              onClick={() => {
                setIsAddUserOpen(false);
                setIsEditing(false);
                setFormData({ year: "", market_area_id: "", dealer_id: "", key_account_customer: "" });
                setErrors({});
                setError(null);
                setMarketAreaSearch("");
                setDealershipSearch("");
              }}
              className="absolute top-3 right-4 text-red-600 font-bold"
            >
              <svg width="14" height="14" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <circle cx="10" cy="10" r="8" fill="#BF2012" />
                <path d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5" stroke="white" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </button>

            <div className="space-y-4">
              {/* Year */}
              <div>
                <label className="text-xs font-medium text-black/70">Year <span className=" text-red1">*</span></label>
                <input
                  type="text"
                  value={formData.year}
                  tabIndex={0}
                  onChange={(e) => {
                     if (errors.year) {
          setErrors({ ...errors, year: "" });
        }
                    const value = e.target.value;
                    if (/^\d{0,4}$/.test(value)) {
                      setFormData({ ...formData, year: value });
                    }
                  }}
                  maxLength={4}
                  className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                    errors.year ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                  placeholder="Enter Year"
                />
                {errors.year && <p className="text-red1 text-xs mt-1">{errors.year}</p>}
              </div>

              {/* ✅ MARKET AREA - SEARCH INSIDE BOX */}
              <div className="w-full relative" ref={marketRef}>
                <label className="text-xs font-medium text-black/70">Market Area <span className=" text-red1">*</span></label>
                
                 <div
                  className={`
                   border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all flex justify-between items-center 
                    ${marketareaOptionssuggestions
                      ? " border-black/30 border-b-white bg-white"
                      : " border-black/30 bg-white hover:ring-1 hover:ring-black/30"}
                    ${errors.marketarea ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                  `}
                  tabIndex={0}
                  onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setMarketareaoptionsSuggestions(true);
    }

    // ESC → close
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setMarketareaoptionsSuggestions(false);
    }

  }}
                  onClick={() => {
                    setMarketareaoptionsSuggestions(prev => !prev);
                    setDealershipoptionsSuggestions(false);
                  }}
                >    
                  <span className={`${formData.market_area_id ? "text-black" : "text-gray-400"}`}>
                    {(() => {
                      const foundArea = marketAreas.find(area => area.id === formData.market_area_id);
                      return foundArea?.marketarea || "Select Market Area";
                    })()}
                  </span>

                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"className={`w-3 h-3 transform transition-transform duration-200 ${
                      marketareaOptionssuggestions ? "rotate-180" : "rotate-0"
                    }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>

                </div>


                {/* ✅ DROPDOWN LIST BELOW THE BOX */}
      {marketareaOptionssuggestions && (
  <div className="absolute z-50 w-full bg-white border border-black/30 border-t-0 shadow-lg max-h-48 overflow-y-auto">

    {/* 🔍 Search input — based on TOTAL marketAreas count */}
    {marketAreas.length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5 z-10">
        <input
          type="text"
          placeholder="Search market area..."
          value={marketAreaSearch}
          onChange={(e) => setMarketAreaSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
        />
      </div>
    )}

    {/* Options list */}
    {Array.from(new Set(marketAreas.map((area) => area.marketarea)))
      .filter(Boolean)
      .filter((areaName) =>
        marketAreaSearch
          ? areaName.toLowerCase().includes(marketAreaSearch.toLowerCase())
          : true
      )
      .filter((areaName) => {
        const areaObj = marketAreas.find(a => a.marketarea === areaName);
        return areaObj?.id !== formData.market_area_id;
      })
      .sort((a, b) => a.localeCompare(b))
      .map((areaName) => {
        const areaObj = marketAreas.find((a) => a.marketarea === areaName);

        return (
         <div
  key={areaObj.id}
  tabIndex={0}
  data-market-option
  className="px-3 py-2 text-xs cursor-pointer hover:bg-gray-100 transition"

  onKeyDown={(e) => {

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-market-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setMarketareaoptionsSuggestions(false);
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData({
        ...formData,
        market_area_id: areaObj.id,
        dealer_id: ""
      });
      setMarketareaoptionsSuggestions(false);
      setMarketAreaSearch("");
    }

  }}

  onMouseDown={() => {
    setFormData({
      ...formData,
      market_area_id: areaObj.id,
      dealer_id: ""
    });
     setErrors((prev) => ({
    ...prev,
    marketarea: ""
  }));

    setMarketareaoptionsSuggestions(false);
    setMarketAreaSearch("");
  }}
>
  {areaName}
</div>
        );
      })}

    {/* No results */}
    {Array.from(new Set(marketAreas.map((area) => area.marketarea)))
      .filter(Boolean)
      .filter((areaName) =>
        marketAreaSearch
          ? areaName.toLowerCase().includes(marketAreaSearch.toLowerCase())
          : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic text-center">
        No results found
      </div>
    )}
  </div>
)}
                {errors.marketarea && <p className="text-red1 text-xs mt-1">{errors.marketarea}</p>}
              </div>

            <div className="w-full relative" ref={dealerRef}>
                <label className="text-xs font-medium text-black/70">Dealership<span className=" text-red1">*</span></label>

                <div
                  className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all flex justify-between items-center 
                    ${dealershipOptionsSuggestions
                      ? " border-black/30 border-b-white bg-white"
                      : "border-black/30 bg-white hover:ring-1 hover:ring-black/30"}
                    ${errors.dealer ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                    tabIndex={0}
                     onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setDealershipoptionsSuggestions(true);
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setDealershipoptionsSuggestions(false);
    }

  }}

                  onClick={() => setDealershipoptionsSuggestions(prev => !prev)}
                >
                  <span className = {`${formData.dealer_id ? "text-black" : "text-gray-400"}`}>
                    {(() => {
                      const foundDealer = dealers.find(dealer => dealer.id === formData.dealer_id);
                      return foundDealer?.dealerName || "Select Dealership";
                    })()}
                  </span>

                  
                  <svg xmlns = "http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"className={`w-3 h-3 transform transition-transform duration-200 ${
                      dealershipOptionsSuggestions ? "rotate-180" : "rotate-0"
                    }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>

                </div>

                {dealershipOptionsSuggestions && (
  <div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto">
    {/* Search input if more than 5 dealers */}
    {dealers.length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5  border-black/10 z-10">
        <input
          type = "text"
          placeholder = "Search dealer..."
          value = {dealershipSearch}
          onChange = {(e) => setDealershipSearch(e.target.value)}
          className = "w-full px-2 py-1 text-xs border border-black/30 outline-none"
        />
      </div>
    )}

    {/* Options list */}
    {Array.from(new Set(dealers.map(d => d.dealerName)))
      .filter(Boolean)
      .filter(name => dealershipSearch ? name.toLowerCase().includes(dealershipSearch.toLowerCase()) : true)
      .filter(name => {
        const dealerObj = dealers.find(d => d.dealerName === name);
        return dealerObj?.id !== formData.dealer_id;
      })
      .sort((a, b) => a.localeCompare(b))
      .map((name, idx) => {
        const dealerObj = dealers.find(d => d.dealerName === name);
        return (
          <div
  key={dealerObj.id}
  tabIndex={0}
  data-dealer-option
  className="px-3 py-1.5 text-xs cursor-pointer hover:bg-gray-100 transition"

  onKeyDown={(e) => {

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-dealer-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      e.stopPropagation()
      setDealershipoptionsSuggestions(false);
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData({ ...formData, dealer_id: dealerObj.id });
      setDealershipoptionsSuggestions(false);
      setDealershipSearch("");
    }

  }}

  onMouseDown={() => {
    setFormData({ ...formData, dealer_id: dealerObj.id });
     setErrors((prev) => ({
    ...prev,
    dealer: ""
  }));

    setDealershipoptionsSuggestions(false);
    setDealershipSearch("");
  }}
>
  {name}
</div>
        );
      })}

    {/* No results */}
    {Array.from(new Set(dealers.map(d => d.dealerName)))
      .filter(Boolean)
      .filter(name => dealershipSearch ? name.toLowerCase().includes(dealershipSearch.toLowerCase()) : true)
      .length === 0 && (
        <div className="px-3 py-2 text-xs text-gray-400 italic text-center">
          No dealers found
        </div>
      )}
  </div>
)}

                {errors.dealer && <p className="text-red1 text-xs mt-1">{errors.dealer}</p>}
              </div>


              {/* Key Account */}
              <div>
                <label className="text-xs font-medium text-black/70">Key Account Customer <span className=" text-red1">*</span></label>
                <input
                  type="text"
                  tabIndex={0}
                  value={formData.key_account_customer}
                  onChange={(e) =>{ 
                     if (errors.key_account_customer) {
          setErrors({ ...errors, key_account_customer: "" });
        }
                    setFormData({ ...formData, key_account_customer: e.target.value })}}
                  placeholder="Enter Key Account Customer"
                  className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                    errors.key_account_customer ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                />
                {errors.key_account_customer && <p className="text-red1 text-xs mt-1">{errors.key_account_customer}</p>}
              </div>
            </div>

            {error && (
              <div className="text-red1 text-xs font-normal mb-3 text-left mt-2">
                {error}
              </div>
            )}

            <button
            id="submitkeyaccountBtn"
              onClick={async () => {
                const newErrors = {};
                
                // ✅ DEFENSIVE: Convert to string first before operations
                const yearStr = String(formData.year || "").trim();
                const keyAccountStr = String(formData.key_account_customer || "").trim();
                
                if (!yearStr) {
                  newErrors.year = "Please fill this field";
                } else if (!/^\d{4}$/.test(yearStr)) {
                  newErrors.year = "Enter a valid 4-digit year";
                }
                if (!formData.market_area_id) newErrors.marketarea = "Please select Market Area";
                if (!formData.dealer_id) newErrors.dealer = "Please select Dealer";
                if (!keyAccountStr) newErrors.key_account_customer = "Please enter Key Account Customer";

                if (Object.keys(newErrors).length > 0) {
                  setErrors(newErrors);
                  return;
                }

                // ✅ Check for duplicates with proper string comparison
                const isDuplicate = tableData.some((item) => {
                  if (isEditing && item.id === editIndex) return false;

                  const itemYear = String(item.year || "").trim();
                  const itemKeyAccount = String(item.key_account_customer || "").trim().toLowerCase();
                  
                  return (
                    itemYear === yearStr &&
                    item.market_area_id === formData.market_area_id &&
                    item.dealer_id === formData.dealer_id &&
                    itemKeyAccount === keyAccountStr.toLowerCase()
                  );
                });

                if (isDuplicate) {
                  setError("This combination already exists.");
                  return;
                }

                try {
                  setLoading(true);
                  setError(null);

                  const dataToSend = {
                    year: yearStr,
                    market_area_id: formData.market_area_id,
                    dealer_id: formData.dealer_id,
                    key_account_customer: keyAccountStr
                  };

                  if (isEditing) {
                    await updateNationalKeyAccount(editIndex, dataToSend);
                  } else {
                    await addNationalKeyAccount(dataToSend);
                  }
resetSortAndFilter()
                  await loadNationalKeyAccounts();

                  setFormData({ year: "", market_area_id: "", dealer_id: "", key_account_customer: "" });
                  setErrors({});
                  setIsAddUserOpen(false);
                  setIsEditing(false);
                  setEditIndex(null);
                  setMarketAreaSearch("");
                  setDealershipSearch("");
                } catch (error) {
                  // console.error("Error saving national key account:", error);
                  setError("Failed to save. This combination might already exist.");
                } finally {
                  setLoading(false);
                }
              }}
              disabled={loading}
              className="mt-6 bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "Saving..." : "Save"}
            </button>
          </div>
        </div>
      )}

      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={async () => {
          if (deleteIndex !== null) {
            try {
              setLoading(true);
              await deleteNationalKeyAccount(deleteIndex);
              resetSortAndFilter()
              await loadNationalKeyAccounts();
              setDeleteIndex(null);
            } catch (error) {
              // console.error("Error deleting national key account:", error);
              setError(error.message || "Failed to delete national key account");
            } finally {
              setLoading(false);
            }
          }
          setIsDeleteModalOpen(false);
        }}
      />

      {showActivateModal && selectedRow !== null && (
        <ActivateStatus
          isOpen={showActivateModal}
          onClose={() => setShowActivateModal(false)}
          onConfirm={async () => {
            try {
              setLoading(true);
              await toggleNationalKeyAccount(selectedRow);
              await loadNationalKeyAccounts();
              setShowActivateModal(false);
              setSelectedRow(null);
            } catch (error) {
              // console.error("Error activating national key account:", error);
              setError(error.message || "Failed to activate national key account");
            } finally {
              setLoading(false);
            }
          }}
        />
      )}

      {showDeactivateModal && selectedRow !== null && (
        <DeactivateStatus
          isOpen={showDeactivateModal}
          onClose={() => setShowDeactivateModal(false)}
          onConfirm={async () => {
            try {
              setLoading(true);
              await toggleNationalKeyAccount(selectedRow);
              await loadNationalKeyAccounts();
              setShowDeactivateModal(false);
              setSelectedRow(null);
            } catch (error) {
              // console.error("Error deactivating national key account:", error);
              setError(error.message || "Failed to deactivate national key account");
            } finally {
              setLoading(false);
            }
          }}
        />
      )}
    </div>
  )
}

export default KeyAccount;