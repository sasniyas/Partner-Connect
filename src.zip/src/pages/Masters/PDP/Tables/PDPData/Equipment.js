import { useState, useEffect, useRef, useCallback,useMemo } from "react";
import Header from "../../../../../Components/Header";
import { useNavigate } from "react-router-dom";
import SubNavbar3 from "../../../../../Components/SubNavbar3";
import { ArrowLeft, Plus, ArrowRight } from "lucide-react";
import Searchinput from "../../../../../Components/Searchinput";
import Filter from "../../../../../Components/Filter";
import DeleteModal from "../../../../../Components/DeleteModal";
import FilterSearch from "../../../../../Components/FilterSearch";
import * as XLSX from "xlsx";
import DeactivateStatus from "../../../../../Components/DeactivateStatus";
import ActivateStatus from "../../../../../Components/ActivateStatus";
import { uploadTempFile } from "../../../../../services/download/bluckDownload.service";
 import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { ChevronDown } from "lucide-react";
import { ChevronUp } from "lucide-react";
import { ChevronsUpDown } from "lucide-react";
import { ArrowUp } from "lucide-react";
import { ArrowDown } from "lucide-react";
import useCRUDWithReset from "../../../../../util/useCRUDWithReset"
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation";
import {
  addEquipment,
  getEquipments,
  updateEquipment,
  deleteEquipment,
  toggleEquipment,
} from "../../../../../services/pdpMaster/equipment.service";

function Equipment() {
  const [selectedYears, setSelectedYears] = useState([]);
  const [selectedTypes, setSelectedTypes] = useState([]);
  const [selectedLines, setSelectedLines] = useState([]);
  const [selectedModels, setSelectedModels] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [startIndex, setStartIndex] = useState(0);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [selectedMakes, setSelectedMakes] = useState([]);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);
const [modelSearch, setModelSearch] = useState("");
const dropdownref = useRef(null);
const [lineSearch, setLineSearch] = useState("");
const [typeSearch, setTypeSearch] = useState("");
const typeRef = useRef(null);
const popupRef= useRef(null)
const lineRef = useRef(null);
  // Loading and error states
  const [isLoading, setIsLoading] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  // Add this with your other useState hooks
  const [makeOptions, setMakeOptions] = useState(["Volvo", "SDLG"]);
  const [showMakeSuggestions, setShowMakeSuggestions] = useState(false);

  const [typeOptions, setTypeOptions] = useState([]);
  const [lineOptions, setLineOptions] = useState(["Artic Haulers"]);
  const [modelOptions, setModelOptions] = useState([]);

  const [menuOpen, setMenuOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const dropdownRef = useRef(null);
  const [tableData, setTableData] = useState([]);
  const [formData, setFormData] = useState({
    year: "",
    equipment_type: "",
    equipment_line: "",
    equipment_model: "",
    equipment_make: "",
  });
  const [isEditing, setIsEditing] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  const [errors, setErrors] = useState({});
  const [yearOptions, setYearOptions] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedYear, setSelectedYear] = useState("");
const [selectedStatus, setSelectedStatus] = useState([]);
const [makeSearch, setMakeSearch] = useState("");
const makeRef = useRef(null);

  const [deleteIndex, setDeleteIndex] = useState(null); // to track which row to delete
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showLineSuggestions, setShowLineSuggestions] = useState(false);
  const [showModelSuggestions, setShowModelSuggestions] = useState(false);
  const [selectedType, setSelectedType] = useState("");
  const [selectedLine, setSelectedLine] = useState("");
  const [selectedModel, setSelectedModel] = useState("");
  const fileInputRef = useRef(null);

  // Lazy loading states
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLazyLoading, setIsLazyLoading] = useState(false);
  const observerRef = useRef();

  const itemsPerLoad = 10;
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  // Fetch equipment data from backend
  const fetchEquipmentData = async () => {
    try {
      setIsInitialLoading(true);
      setError(null);
      const data = await getEquipments();

      // Map backend data to frontend format
      const mappedData = data.map((item) => ({
        id: item.id,
        year: item.year,
        type: item.equipment_type,
        make: item.equipment_make,
        line: item.equipment_line,
        model: item.equipment_model,
        status: item.isActive ? "Active" : "Inactive",
        createdOn: item.createdOn,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
      }));

      setTableData(mappedData);
    } catch (err) {
      // console.error("Error fetching equipment data:", err);
      setError(err.message || "Failed to fetch equipment data");
    } finally {
      setIsInitialLoading(false);
    }
  };
const statusOptions = [
    "Active", "Inactive"
];

  const handleBulkUploadClick = () => {
    fileInputRef.current.click();
  };

  // ═══════════════════════════════════════════════════════
  // 🔗 DEPENDENT FILTER OPTIONS (Make → Type → Line → Model)
  // ═══════════════════════════════════════════════════════

  // Make options - always show ALL unique makes from data (no dependency)
  const filterMakeOptions = useMemo(() => {
    return [...new Set(tableData.map((i) => i.make).filter(Boolean))].sort();
  }, [tableData]);

  // Type options - depends on selectedMakes
  const filterTypeOptions = useMemo(() => {
    let filtered = tableData;
    if (selectedMakes.length > 0) {
      filtered = filtered.filter((item) => selectedMakes.includes(item.make));
    }
    return [...new Set(filtered.map((i) => i.type).filter(Boolean))].sort();
  }, [tableData, selectedMakes]);

  // Line options - depends on selectedMakes + selectedTypes
  const filterLineOptions = useMemo(() => {
    let filtered = tableData;
    if (selectedMakes.length > 0) {
      filtered = filtered.filter((item) => selectedMakes.includes(item.make));
    }
    if (selectedTypes.length > 0) {
      filtered = filtered.filter((item) => selectedTypes.includes(item.type));
    }
    return [...new Set(filtered.map((i) => i.line).filter(Boolean))].sort();
  }, [tableData, selectedMakes, selectedTypes]);

  // Model options - depends on selectedMakes + selectedTypes + selectedLines
  const filterModelOptions = useMemo(() => {
    let filtered = tableData;
    if (selectedMakes.length > 0) {
      filtered = filtered.filter((item) => selectedMakes.includes(item.make));
    }
    if (selectedTypes.length > 0) {
      filtered = filtered.filter((item) => selectedTypes.includes(item.type));
    }
    if (selectedLines.length > 0) {
      filtered = filtered.filter((item) => selectedLines.includes(item.line));
    }
    return [...new Set(filtered.map((i) => i.model).filter(Boolean))].sort();
  }, [tableData, selectedMakes, selectedTypes, selectedLines]);

  // ═══════════════════════════════════════════════════════
  // 🔄 CASCADING FILTER CHANGE HANDLERS
  // ═══════════════════════════════════════════════════════

  // When Make changes → reset Type, Line, Model
  const handleMakeFilterChange = (name, value) => {
    setSelectedMakes(value);
    setSelectedTypes([]);
    setSelectedLines([]);
    setSelectedModels([]);
  };

  // When Type changes → reset Line, Model
  const handleTypeFilterChange = (name, value) => {
    setSelectedTypes(value);
    setSelectedLines([]);
    setSelectedModels([]);
  };

  // When Line changes → reset Model
  const handleLineFilterChange = (name, value) => {
    setSelectedLines(value);
    setSelectedModels([]);
  };

  // Model change - no child to reset
  const handleModelFilterChange = (name, value) => {
    setSelectedModels(value);
  };

const filteredData = useMemo(() => {
  const query = searchQuery.trim().toLowerCase();

  return tableData.filter((item) => {
    const searchableFields = [
      String(item.year || ""),
      String(item.type || ""),
      String(item.make || ""),
      String(item.line || ""),
      String(item.model || ""),
    ];

    const matchesSearch = query
      ? searchableFields.some((val) => val.toLowerCase().includes(query))
      : true;

    const matchesYear = selectedYears.length
      ? selectedYears.some((year) => String(year) === String(item.year))
      : true;

    const matchesType = selectedTypes.length
      ? selectedTypes.includes(item.type)
      : true;

    const matchesLine = selectedLines.length
      ? selectedLines.includes(item.line)
      : true;

    const matchesModel = selectedModels.length
      ? selectedModels.includes(item.model)
      : true;

    const matchesMake = selectedMakes.length
      ? selectedMakes.includes(item.make)
      : true;
      const matchesStatus = selectedStatus.length
      ? selectedStatus.includes(item.status)
      : true;


    return (
      matchesSearch &&
      matchesYear &&
      matchesType &&
      matchesLine &&
      matchesModel &&
      matchesMake  &&
      matchesStatus
    );
  });
}, [
  tableData,
  searchQuery,
  selectedYears,
  selectedTypes,
  selectedLines,
  selectedModels,
  selectedMakes,
  selectedStatus,
]);
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    }

    if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }

  setSortKey(key);
  setSortOrder("asc");
};
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const valA = a[sortKey] ?? "";
    const valB = b[sortKey] ?? "";

    return sortOrder === "asc"
      ? valA.toString().localeCompare(valB.toString(), undefined, {
          numeric: true,
          sensitivity: "base",
        })
      : valB.toString().localeCompare(valA.toString(), undefined, {
          numeric: true,
          sensitivity: "base",
        });
  });
}, [filteredData, sortKey, sortOrder]);
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchQuery: { setter: setSearchQuery, resetValue: "" },
    selectedYears: { setter: setSelectedYears, resetValue: [] },
    selectedMakes:{setter : setSelectedMakes ,resetValue: []},
    selectedTypes:{setter : setSelectedTypes ,resetValue :[]},
    selectedLines :{setter: setSelectedLines , resetValue :[]},
    selectedModels :{setter: setSelectedModels , resetValue :[]},
    selectedStatus :{setter :setSelectedStatus ,resetValue :[]}
  } 
);

useEffect(() => {
  const handleClickOutside = (e) => {
    if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
      setShowModelSuggestions(false);
      setModelSearch("");
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);
useEffect(() => {
  const handleClickOutside = (e) => {
    if (lineRef.current && !lineRef.current.contains(e.target)) {
      setShowLineSuggestions(false);
      setLineSearch("");
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);
useEffect(() => {
  const handleClickOutside = (e) => {
    if (typeRef.current && !typeRef.current.contains(e.target)) {
      setShowSuggestions(false);
      setTypeSearch("");
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);
useEffect(() => {
  const handleClickOutside = (e) => {
    if (makeRef.current && !makeRef.current.contains(e.target)) {
      setShowMakeSuggestions(false);
      setMakeSearch("");
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);
useEffect(() => {
  if (isEditing && selectedRow) {
    setFormData({
      ...selectedRow,
      equipment_type: selectedRow.equipment_type || "",
    });
  }
}, [isEditing, selectedRow]);

  // Load more items function
  const loadMoreItems = useCallback(() => {
    if (isLazyLoading || !hasMore) return;

    setIsLazyLoading(true);

    setTimeout(() => {
      const currentLength = displayedItems.length;
      const nextItems = filteredData.slice(
        currentLength,
        currentLength + itemsPerLoad
      );

      if (nextItems.length === 0) {
        setHasMore(false);
      } else {
        setDisplayedItems((prev) => [...prev, ...nextItems]);
      }

      setIsLazyLoading(false);
    }, 300);
  }, [displayedItems.length, filteredData, isLazyLoading, hasMore]);

  // Intersection Observer callback
  const lastItemRef = useCallback(
    (node) => {
      if (isLazyLoading) return;
      if (observerRef.current) observerRef.current.disconnect();

      observerRef.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore) {
          loadMoreItems();
        }
      });

      if (node) observerRef.current.observe(node);
    },
    [isLazyLoading, hasMore, loadMoreItems]
  );

  // Initial load
  useEffect(() => {
    fetchEquipmentData();
  }, []);

useEffect(() => {
  const initialItems = filteredData.slice(0, itemsPerLoad);
  setDisplayedItems(initialItems);
  setHasMore(filteredData.length > itemsPerLoad);
}, [filteredData, itemsPerLoad]);


  // Auto-dismiss success messages
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => {
        setSuccessMessage(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  // Scroll handler (one-time)
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close dropdown when clicking outside (one-time)
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Year options derived from tableData
  useEffect(() => {
    const years = [...new Set(tableData.map((item) => item.year))].sort((a, b) =>
      Number(a) - Number(b)
    );
    setYearOptions(years);
  }, [tableData]);

  // ✅ Stable generation of popup dropdown options (for Add/Edit form - independent, NOT cascading)
  useEffect(() => {
    const unique = (arr) => Array.from(new Set(arr.filter(Boolean)));
    const arraysEqual = (a, b) =>
      a.length === b.length && a.every((v, i) => v === b[i]);

    const newTypes = unique(tableData.map((i) => i.type));
    const newLines = unique(tableData.map((i) => i.line));
    const newModels = unique(tableData.map((i) => i.model));
    const newMakes = unique(tableData.map((i) => i.make));

    setTypeOptions((prev) => (arraysEqual(prev, newTypes) ? prev : newTypes));
    setLineOptions((prev) => (arraysEqual(prev, newLines) ? prev : newLines));
    setModelOptions((prev) =>
      arraysEqual(prev, newModels) ? prev : newModels
    );
    setMakeOptions((prev) => (arraysEqual(prev, newMakes) ? prev : newMakes));
  }, [tableData]);


const handleDownloadTemplate = async () => {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Equipment");

  sheet.columns = [
    { header: "Sl. No", key: "slNo", width: 10 },
      { header: "Year", key: "year", width: 15 },
     { header: "Equipment Make", key: "make", width: 25 },
      { header: "Equipment Type", key: "type", width: 35 },
      { header: "Equipment Line", key: "line", width: 30 },
      { header: "Equipment Model", key: "model", width: 30 },
      { header: "Status", key: "status", width: 15 },
  ];

  sheet.columns.forEach((column) => {
    column.alignment = {
      vertical: "middle",
      horizontal: "left",
      wrapText: true,
    };
    column.numFmt = "@";
  });

  sheet.addRow({
    year: "2025",
    type: "GPE (General Production Equipment)",
    make: "VOLVO",
    line: "Excavators",
    model: "EC200",
  });

  sheet.columns.forEach((column) => {
    column.protection = { locked: false };
  });

  const headerRow = sheet.getRow(1);
  headerRow.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FF476896" },
    };
    cell.alignment = { vertical: "middle", horizontal: "left" };
    cell.protection = { locked: true };
  });

  sheet.dataValidations.add("C2:C5000", {
    type: "list",
    allowBlank: false,
    formulae: ['"VOLVO,SDLG"'],
    showErrorMessage: true,
    errorTitle: "Invalid Make",
    error: "Please select a valid Equipment Make from the list.",
  });

  await sheet.protect("12345", {
    selectLockedCells: true,
    selectUnlockedCells: true,
    insertRows: true,
    deleteRows: true,
    formatColumns: true,
    formatRows: true,
  });

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  saveAs(blob, "Equipment_Bulk_Upload_Template.xlsx");
};


const handlePreviewAndDownload = async () => {
  if (!displayedItems || displayedItems.length === 0) {
    // alert("No data available to upload");
    return;
  }

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Equipment");

    sheet.columns = [
      { header: "Sl. No", key: "slNo", width: 10 },
      { header: "Year", key: "year", width: 15 },
     { header: "Equipment Make", key: "make", width: 25 },
      { header: "Equipment Type", key: "type", width: 35 },
      { header: "Equipment Line", key: "line", width: 30 },
      { header: "Equipment Model", key: "model", width: 30 },
      { header: "Status", key: "status", width: 15 },
    ];

    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.alignment = { vertical: "middle", horizontal: "left" };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
    });

    displayedItems.forEach((item, index) => {
      const row = sheet.addRow({
        slNo: index + 1,
        year: item.year || "",
        type: item.type || "",
        make: item.make || "",
        line: item.line || "",
        model: item.model || "",
        status: item.isActive ? "Active" : "Inactive",
      });

      row.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
    });

    const buffer = await workbook.xlsx.writeBuffer();

    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const file = new File(
      [blob],
      "Equipment.xlsx",
      {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }
    );
  try {
    const response = await  uploadTempFile (file);
const fileUrl = response ? `https://view.officeapps.live.com/op/view.aspx?src=${response} `:null;  
  if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    } else {
      // console.warn("Upload succeeded but no file URL returned");
    }
  } catch (error) {
    // console.error("Upload failed:", error);
  }
};


const handleBulkUpload = (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const previewTab = window.open(
    "/bulkupload/equipment",
    "_blank"
  );

  if (!previewTab) {
    // alert("Popup blocked! Please allow popups.");
    return;
  }

  const reader = new FileReader();

  reader.onload = (event) => {
    const data = new Uint8Array(event.target.result);
    const workbook = XLSX.read(data, { type: "array" });
    const sheetName = workbook.SheetNames[0];

    let rows = XLSX.utils.sheet_to_json(
      workbook.Sheets[sheetName],
      { defval: "" }
    );

    rows = rows.filter((row) =>
      Object.values(row).some((v) => v !== "")
    );

    const finalRows = rows.map((row, index) => ({
      slNo: index + 1,
      year: row["Year"] || "",
      equipmentType: row["Equipment Type"] || "",
      equipmentMake: row["Equipment Make"] || "",
      equipmentLine: row["Equipment Line"] || "",
      equipmentModel: row["Equipment Model"] || "",
      hasError: !row["Year"] || !row["Equipment Type"] || !row["Equipment Make"],
    }));

    previewTab.postMessage(
      {
        type: "EQUIPMENT_PREVIEW",
        payload: { rows: finalRows },
      },
      "*"
    );
  };

  reader.readAsArrayBuffer(file);
};

useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
    document.getElementById("saveEquipmentBtn")?.click();
  },

  onCancel: () => {
    setIsAddUserOpen(false);
    setIsEditing(false);
    setFormData({
      year: "",
      equipment_type: "",
      equipment_line: "",
      equipment_model: "",
      equipment_make: "",
    });
    setErrors({});
  },
});

  return (
<div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full transition-all duration-300 ease-in-out">
            {/* 🔹 Heading */}
           <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-2">
              <div className="w-full sm:w-auto flex justify-center sm:justify-start">
                <h2 className="text-base font-medium font-VolvoNovum text-center text-darkblue1 flex items-center justify-center gap-2">
                  <ArrowLeft
                    onClick={() => navigate("/masterpdphomepage")}
                    size={24}
                    className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1  p-1"
                  />
                  PDP Data / Equipment
                </h2>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto justify-end">
              </div>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                {error}
              </div>
            )}
            {successMessage && (
              <div className="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded">
                {successMessage}
              </div>
            )}

            {isInitialLoading && (
              <div className="mb-4 p-4 text-center">
                <div className="inline-flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-darkblue1"></div>
                  Loading equipment data...
                </div>
              </div>
            )}

            {/* ═══════════════════════════════════════════════════════
                🔗 TABLE FILTERS - DEPENDENT/CASCADING
                Make → Type → Line → Model
            ═══════════════════════════════════════════════════════ */}
            <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto mb-2">             
                  <Searchinput
                  onChange={(e) => {
                    setSearchQuery(e.target.value)
                  }}
                  value={searchQuery}
                  placeholder="Search"
                  className="w-[1/2]"
                  iconColor="text-black"
                  bgColor="bg-FrostWhite"
              borderColor="border-black/60"
                  textColor="text-black"
                  shadow="shadow-none"
                  inputPadding="pl-6 pr-3 py-1.5"
                  iconSize="w-3 h-3"
                  iconLeft="left-3"
                  inputWidth="w-full"
                  focusRing="focus:ring-1 focus:ring-black/60"
                  hoverInputClasses="hover:bg-white hover:border-black/60"
                />
                
            {/* Year Filter (independent) */}
            <Filter
              name="year"
              placeholder="Year"
              options={yearOptions}
              customWidth="w-[10px]"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
              value={selectedYears}
              onChange={(name, value) => {
                setSelectedYears(value);
              }}
            />

            {/* Equipment Make Filter (parent - resets Type, Line, Model) */}
            <Filter
              name="equipmentMake"
              placeholder="Equipment Make"
              options={filterMakeOptions}
              customWidth="w-[80px]"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
              value={selectedMakes}
              onChange={handleMakeFilterChange}
            />

            {/* Equipment Type Filter (depends on Make → resets Line, Model) */}
             <Filter
              name="equipmentType"
              placeholder="Equipment Type"
              options={filterTypeOptions}
              customWidth="w-[80px]"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
              value={selectedTypes}
              isSearchable={true}
              searchPlaceholder="Search equipment..."
              onChange={handleTypeFilterChange}
            /> 

            {/* Equipment Line Filter (depends on Make + Type → resets Model) */}
            <Filter
              name="equipmentLine"
              placeholder="Equipment Line"
              options={filterLineOptions}
              value={selectedLines}
              customWidth="w-[80px]"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              openBgColor="bg-white"
              textColor="text-black"
              onChange={handleLineFilterChange}
            />

            {/* Equipment Model Filter (depends on Make + Type + Line) - REMOVED, replaced below */}

            {/* Status Filter (independent) */}
            <Filter
  name="status"
  placeholder="Status"
  options={statusOptions}
  value={selectedStatus}
  customWidth="w-[80px]"
  placeholderColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black/60"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
  onChange={(name, value) => {
    setSelectedStatus(value);
  }}
/>


           <div className="relative w-full sm:w-[190px]" ref={dropdownRef}>
                  <button
                    onClick={() => setOpen(!open)}
                    className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-1.5 text-xs  flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
                  >
                    <Plus className="w-3 h-3 stroke-[3]" />
                    Add New
                  </button>
                  {open && (
                    <div className="absolute top-full left-0 mt-1  w-full bg-white border border-darkblue1 shadow-lg z-50">
                      <button
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1"
                        onClick={() => {
                          setIsAddUserOpen(true)
                          setOpen(false)
                        }}
                      >
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
<g clipPath="url(#clip0_1415_1580)">
<path d="M11.5745 0C11.0146 0 10.5532 0.516369 10.5532 1.14286C10.5532 1.32738 10.5997 1.5 10.6702 1.65476L8.18085 3.78571L8.59574 4.39286L11.1702 2.19048C11.2952 2.25149 11.4309 2.28571 11.5745 2.28571C11.6556 2.28571 11.7327 2.27083 11.8085 2.25L14.1915 6.89286C14.0452 7.09077 13.9574 7.34524 13.9574 7.61905C13.9574 7.79762 13.9973 7.96726 14.0638 8.11905L11.9787 11.2024L11.5745 11.8095H14.6383C15.1981 11.8095 15.6596 11.2932 15.6596 10.6667V8.46429C15.867 8.25446 16 7.95387 16 7.61905C16 6.99256 15.5386 6.47619 14.9787 6.47619C14.9082 6.47619 14.8431 6.48512 14.7766 6.5L12.383 1.84524C12.5173 1.65179 12.5957 1.40476 12.5957 1.14286C12.5957 0.516369 12.1343 0 11.5745 0ZM11.5745 0.761905C11.766 0.761905 11.9149 0.928571 11.9149 1.14286C11.9149 1.35714 11.766 1.52381 11.5745 1.52381C11.383 1.52381 11.234 1.35714 11.234 1.14286C11.234 0.928571 11.383 0.761905 11.5745 0.761905ZM4.76596 3.42857C4.39362 3.42857 4.08511 3.77381 4.08511 4.19048V6.47619H2.04255C1.48271 6.47619 1.02128 6.99256 1.02128 7.61905V9.52381C1.02128 10.1503 1.48271 10.6667 2.04255 10.6667H3.06383V11.4286H2.04255C0.918883 11.4286 0 12.4568 0 13.7143C0 14.9717 0.918883 16 2.04255 16H8.85106C9.97473 16 10.8936 14.9717 10.8936 13.7143C10.8936 12.4568 9.97473 11.4286 8.85106 11.4286H7.82979V10.6667H8.85106C9.4109 10.6667 9.87234 10.1503 9.87234 9.52381V7.63095C9.87234 7.29167 9.77128 6.95833 9.58511 6.69048L7.61702 3.86905C7.4242 3.59077 7.13431 3.42857 6.81915 3.42857H4.76596Z" fill="black"/>
</g>
<defs>
<clipPath id="clip0_1415_1580">
<rect width="16" height="16" fill="white"/>
</clipPath>
</defs>
</svg>
                        Add Equipment
                      </button>
                        <button
        onClick={() => navigate("/bulkupload/equipment")}
        className="w-full text-left px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>
        Bulk Upload
      </button>

  <input
    type="file"
    ref={fileInputRef}
    className="hidden"
    accept=".xlsx,.xls"
    onChange={handleBulkUpload}
  />
                                       <button
                                              onClick={handleDownloadTemplate}
                                      className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2  whitespace-nowrap"
                                    >
<svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
</svg>

                         Bulk upload Template
                                    </button>
                    </div>
                  )}
                </div>
 <button
                  onClick={handlePreviewAndDownload}
                  className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1 flex items-center gap-2 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
                >
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
<path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D"/>
</svg>
           
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" className="w-3 h-3 hidden group-hover:block">
<path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white"/>
</svg>

                  <span className="font-semibold">Download</span>
                </button>
          
          </div>
       


{/* 🔹 RESPONSIVE TABLE */}
<div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
  <div
  ref={tableContainerRef}
    className="overflow-y-auto relative"
    style={{
      scrollbarWidth: "none",
      msOverflowStyle: "none",
      maxHeight: sortedData.length > 8 ? "calc(100vh - 240px)" : "auto",
    }}
    onScroll={handleTableScroll}
  >
    <style jsx>{`
      div::-webkit-scrollbar {
        display: none;
      }
    `}</style>

    <table className="w-full text-xs whitespace-nowrap cursor-pointer border-collapse">
      <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
        <tr>
          <th
            className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
            onClick={() => handleSort("year")}
          >
            <div className="flex items-center gap-1">
              Year
              {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
              {sortKey === "year" && sortOrder === "asc" && (
                <ChevronUp className="w-3 h-3 text-white" />
              )}
              {sortKey === "year" && sortOrder === "desc" && (
                <ChevronDown className="w-3 h-3 text-white" />
              )}
            </div>
          </th>

          <th
            className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
            onClick={() => handleSort("make")}
          >
            <div className="flex items-center gap-1">
              Equipment Make
              {sortKey === "make" && sortOrder === "asc" && (
                <ChevronUp className="w-3 h-3 text-white" />
              )}
              {sortKey === "make" && sortOrder === "desc" && (
                <ChevronDown className="w-3 h-3 text-white" />
              )}
            </div>
          </th>

          <th
            className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[30%] cursor-pointer select-none"
            onClick={() => handleSort("type")}
          >
            <div className="flex items-center gap-1">
              Equipment Type
              {sortKey === "type" && sortOrder === "asc" && (
                <ChevronUp className="w-3 h-3 text-white" />
              )}
              {sortKey === "type" && sortOrder === "desc" && (
                <ChevronDown className="w-3 h-3 text-white" />
              )}
            </div>
          </th>

          <th
            className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%] cursor-pointer select-none"
            onClick={() => handleSort("line")}
          >
            <div className="flex items-center gap-1">
              Equipment Line
              {sortKey === "line" && sortOrder === "asc" && (
                <ChevronUp className="w-3 h-3 text-white" />
              )}
              {sortKey === "line" && sortOrder === "desc" && (
                <ChevronDown className="w-3 h-3 text-white" />
              )}
            </div>
          </th>

          <th
            className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
            onClick={() => handleSort("model")}
          >
            <div className="flex items-center gap-1">
              Equipment Model
              {sortKey === "model" && sortOrder === "asc" && (
                <ChevronUp className="w-3 h-3 text-white" />
              )}
              {sortKey === "model" && sortOrder === "desc" && (
                <ChevronDown className="w-3 h-3 text-white" />
              )}
            </div>
          </th>

          <th className="text-center py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[10%]">
            Actions
          </th>
        </tr>
      </thead>

      <tbody className="text-black">
        {sortedData.length > 0 ? (
          sortedData.map((item, index) => (
            <tr
              key={index}
              className={`hover:bg-lightBlue/50 text-xs ${
                item.status === "Active" ? "text-black" : "text-gray-400"
              }`}
            >
              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                {item.year}
              </td>

              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                <div className="relative">
                  <p
                    className="truncate max-w-[10rem] cursor-pointer"
                    onMouseEnter={() => {
                      if (item.make && item.make.length > 15)
                        setHoveredCell(item.id + "-make");
                    }}
                    onMouseLeave={() => setHoveredCell(null)}
                  >
                    {item.make}
                  </p>
                  {hoveredCell === item.id + "-make" && (
                    <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                      {item.make}
                    </span>
                  )}
                </div>
              </td>

              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                <div className="relative">
                  <p
                    className="truncate max-w-[30rem] cursor-pointer"
                    onMouseEnter={() => {
                      if (item.type && item.type.length > 40)
                        setHoveredCell(item.id + "-type");
                    }}
                    onMouseLeave={() => setHoveredCell(null)}
                  >
                    {item.type}
                  </p>
                  {hoveredCell === item.id + "-type" && (
                    <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                      {item.type}
                    </span>
                  )}
                </div>
              </td>

              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                <div className="relative">
                  <p
                    className="truncate max-w-[12rem] cursor-pointer"
                    onMouseEnter={() => {
                      if (item.line && item.line.length > 20)
                        setHoveredCell(item.id + "-line");
                    }}
                    onMouseLeave={() => setHoveredCell(null)}
                  >
                    {item.line}
                  </p>
                  {hoveredCell === item.id + "-line" && (
                    <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                      {item.line}
                    </span>
                  )}
                </div>
              </td>

              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                <div className="relative">
                  <p
                    className="truncate max-w-[14rem] cursor-pointer"
                    onMouseEnter={() => {
                      if (item.model && item.model.length > 40)
                        setHoveredCell(item.id + "-model");
                    }}
                    onMouseLeave={() => setHoveredCell(null)}
                  >
                    {item.model}
                  </p>
                  {hoveredCell === item.id + "-model" && (
                    <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                      {item.model}
                    </span>
                  )}
                </div>
              </td>

              <td className="text-center py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                <div className="flex items-center justify-center gap-4">
                  <div className="relative group">
                    <button onClick={() => {
                      setFormData({
                        year: item.year,
                        equipment_type: item.type,
                        equipment_line: item.line,
                        equipment_model: item.model || "",
                        equipment_make: item.make || "",
                      });
                      setIsAddUserOpen(true);
                      setIsEditing(true);
                      setEditIndex(item.id);
                    }}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                        <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                      </svg>
                    </button>
                    <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">Edit</span>
                  </div>

                  <div className="relative group">
                    <button onClick={() => {
                      setSelectedRow(item.id);
                      item.status === "Active" ? setShowDeactivateModal(true) : setShowActivateModal(true);
                    }}>
                      {item.status === "Active" ? (
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
                          <path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      )}
                    </button>
                    <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                      {item.status === "Active" ? "Deactivate" : "Activate"}
                    </span>
                  </div>

                  <div className="relative group">
                    <button onClick={() => {
                      setDeleteIndex(item.id);
                      setIsDeleteModalOpen(true);
                    }}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                        <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                      </svg>
                    </button>
                    <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">Delete</span>
                  </div>
                </div>
              </td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan={6} className="px-4 py-6 text-center italic text-gray-500">No data found</td>
          </tr>
        )}
      </tbody>
    </table>
  </div>
  {showScrollButtons && (
            <div className="fixed bottom-16 right-6 z-40 pointer-events-auto animate-fade-in">
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

</div>
          </div>
        </div>
      </div>

      {/* Add/Edit Modal - Popup form dropdowns remain INDEPENDENT (not cascading) */}
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
          <div 
          ref={popupRef}
          className="bg-white p-6 w-full max-w-xl relative">
            <h2 className="text-base font-semibold text-center mb-4 text-MediumGrey">
              {isEditing ? "Equipment " : "Add Equipment"}
            </h2>
            <button
              onClick={() => {
                setIsAddUserOpen(false)
                setIsEditing(false)
                setFormData({ year: "", type: "", line: "", model: "", make: "" })
                setErrors({})
              }}
              className="absolute top-3 right-4 text-red-600 font-bold text-xl"
            >
<svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>

            </button>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {/* Year */}
              <div className="col-span-1">
                <label className="text-xs font-medium text-black/70">Year <span className=" text-red1">*</span> </label>
               <input
                  type="text"
                  tabIndex={0}
                  value={formData.year}
                  onChange={(e) => {
                    const value = e.target.value;
                     if (errors.year) {
          setErrors({ ...errors, year: "" });
        }
                    if (/^\d{0,4}$/.test(value)) {
                      setFormData({ ...formData, year: value });
                    }
                  }}
                  maxLength={4}
                  className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                    errors.year ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                  placeholder="Enter Year"
                />

                {errors.year && <p className="text-red1 text-xs mt-1">{errors.year}</p>}
              </div>
              {/* Equipment Make */}
              <div className="col-span-2 relative">
                 <label className="text-xs font-medium text-black/70">Equipment Make <span className=" text-red1">*</span></label>

                <div className="relative">
                  <input
                    type="text"
                    tabIndex={0}
                    value={formData.equipment_make || ""}
                    onChange={(e) => {
                       if (errors.equipment_make) {
          setErrors({ ...errors, equipment_make: "" });
        }
                      setFormData({ ...formData, equipment_make: e.target.value });
                      setShowMakeSuggestions(true);
                    }}
                     onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setShowMakeSuggestions(true);
    }

    

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowMakeSuggestions(false);
    }

  }}
                    placeholder="Select or type Equipment Make"
                    className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
                      ${showMakeSuggestions ? " border-b-white" : ""}
                      ${errors.equipment_make ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                    `}
                    tableIndex={0}
                  />
                  
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowMakeSuggestions((prev) => !prev)}
                    className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
                      showMakeSuggestions ? "rotate-180" : "rotate-0"
                    }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>

                </div>

                {showMakeSuggestions && (
  <div
    ref={makeRef}
    className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {[...new Set([...makeOptions, ...tableData.map(i => i.make)].filter(Boolean))].length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5  z-10">
        <input
          type="text"
          placeholder="Search make..."
          value={makeSearch}
          onChange={(e) => setMakeSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </div>
    )}

    {[...new Set([...makeOptions, ...tableData.map((item) => item.make)])]
      .filter(Boolean)
      .filter((option) => option !== formData.equipment_make)
      .filter((option) =>
        makeSearch
          ? option.toLowerCase().includes(makeSearch.toLowerCase())
          : true
      )
      .sort((a, b) => a.localeCompare(b))
      .map((option, idx) => (
       <div
  tabIndex={0}
  data-option
  key={idx}
  className={`px-3 py-1.5 text-xs cursor-pointer transition
  ${formData.equipment_make === option ? "bg-lightBlue/30 font-medium" : "hover:bg-gray-100"}`}

  onKeyDown={(e) => {

    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowMakeSuggestions(false);
      makeRef.current?.querySelector("input")?.focus();
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      setFormData((prev) => ({
        ...prev,
        equipment_make: option,
      }));
      e.stopPropagation()
      setShowMakeSuggestions(false);
      setMakeSearch("");
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault();
    setFormData((prev) => ({
      ...prev,
      equipment_make: option,
    }));
    setShowMakeSuggestions(false);
    setMakeSearch("");
  }}
>
  {option}
</div>
      ))}

    {[...new Set([...makeOptions, ...tableData.map(i => i.make)].filter(Boolean))]
      .filter((option) =>
        makeSearch
          ? option.toLowerCase().includes(makeSearch.toLowerCase())
          : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic">
        No makes found
      </div>
    )}
  </div>
)}
{errors.equipment_make && <p className="text-red1 text-xs mt-1">{errors.equipment_make}</p>}
  
</div>

              <div className="col-span-3 relative">
              </div>
              <div className="col-span-3 relative">
                 <label className="text-xs font-medium text-black/70">Equipment Type <span className=" text-red1">*</span></label>

              {isEditing && tableData.length > 1 ? (    
                <>
                    <div className="relative">
                     <input
  type="text"
  value={formData.equipment_type}
  maxLength={15}
  onChange={(e) => {
     if (errors.equipment_type) {
          setErrors({ ...errors, equipment_type: "" });
        }
    setFormData({ ...formData, equipment_type: e.target.value });
    setShowSuggestions(true);
  }}
  onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setShowSuggestions(true);
    }
    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowSuggestions(false);
    }

  }}

  onClick={() => setShowSuggestions(true)}
  placeholder="Select or type Equipment Type"
  className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
    ${showSuggestions ? "border-b-white" : ""}
    ${errors.equipment_type ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
  `}
  tabIndex={0}
/>

                     
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowSuggestions((prev) => !prev)}
                        className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
                          showSuggestions ? "rotate-180" : "rotate-0"
                        }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>

                    </div>

                 {showSuggestions && (
  <div
    ref={typeRef}
    className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {[...new Set([...typeOptions, ...tableData.map((i) => i.type)].filter(Boolean))].length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5 z-10">
        <input
          type="text"
          placeholder="Search type..."
          value={typeSearch}
          onChange={(e) => setTypeSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
        />
      </div>
    )}

    {[...new Set([...typeOptions, ...tableData.map((item) => item.type)])]
      .filter(Boolean)
      .filter((option) => option !== formData.equipment_type)
      .filter((option) =>
        typeSearch
          ? option.toLowerCase().includes(typeSearch.toLowerCase())
          : true
      )
      .sort((a, b) => a.localeCompare(b))
      .map((option, idx) => (
      <div
  tabIndex={0}
  data-option
  key={idx}
  className={`px-3 py-1.5 text-xs cursor-pointer transition
    ${
      formData.equipment_type === option
        ? "bg-lightBlue/30 font-medium"
        : "hover:bg-gray-100"
    }`}

  onKeyDown={(e) => {

    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowSuggestions(false);
      typeRef.current?.querySelector("input")?.focus();
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData((prev) => ({
        ...prev,
        equipment_type: option,
      }));
      setShowSuggestions(false);
      setTypeSearch("");
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault();
    setFormData((prev) => ({
      ...prev,
      equipment_type: option,
    }));
    setShowSuggestions(false);
    setTypeSearch("");
  }}
>
  {option}
</div>
      ))}

    {[...new Set([...typeOptions, ...tableData.map((i) => i.type)].filter(Boolean))]
      .filter((option) =>
        typeSearch
          ? option.toLowerCase().includes(typeSearch.toLowerCase())
          : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic">
        No types found
      </div>
    )}
  </div>
)}

                  </>
                ) : (
                  <input
                    type="text"
                    value={formData.equipment_type}
                    onChange={(e) => {
                        const value = e.target.value;
                         if (errors.equipment_type) {
          setErrors({ ...errors, equipment_type: "" });
        }
                      setFormData({ ...formData, equipment_type: e.target.value })}}
                    placeholder="Enter Equipment Type"
                    className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                      errors.equipment_type ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                    }`}
                  />
                )}

                {errors.equipment_type && <p className="text-red1 text-xs mt-1">{errors.equipment_type}</p>}

                <label className="text-xs font-medium text-black/70">Equipment Line <span className=" text-red1">*</span></label>

              {isEditing && tableData.length > 1 ? (   
                <>
                    <div className="relative">
                      <input
                        type="text"
                        maxLength={20}
                        value={formData.equipment_line}
                        onChange={(e) => {
                           if (errors.equipment_line) {
          setErrors({ ...errors, equipment_line: "" });
        }
                          setFormData({ ...formData, equipment_line: e.target.value });
                          setShowLineSuggestions(true);
                        }}
 onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setShowLineSuggestions(true);
    }
 
    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowLineSuggestions(false);
    }

  }}                        placeholder="Select or type Equipment Line"
                        className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
                          ${showLineSuggestions ? " border-b-white" : ""}
                          ${errors.equipment_line ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                        `}
                        tabIndex={0}
                      />
                      
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowLineSuggestions((prev) => !prev)}
                        className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
                          showLineSuggestions ? "rotate-180" : "rotate-0"
                        }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>

                    </div>

                  {showLineSuggestions && (
  <div
    ref={lineRef}
    className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {[...new Set([...lineOptions, ...tableData.map((i) => i.line)].filter(Boolean))].length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5 ">
        <input
          type="text"
          placeholder="Search line..."
          value={lineSearch}
          onChange={(e) => setLineSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
        />
      </div>
    )}

    {[...new Set([...lineOptions, ...tableData.map((item) => item.line)])]
      .filter(Boolean)
      .filter((option) => option !== formData.equipment_line)
      .filter((option) =>
        lineSearch
          ? option.toLowerCase().includes(lineSearch.toLowerCase())
          : true
      )
      .sort((a, b) => a.localeCompare(b))
      .map((option, idx) => (
       <div
  tabIndex={0}
  data-option
  key={idx}
  className={`px-3 py-1.5 text-xs cursor-pointer transition
    ${
      formData.equipment_line === option
        ? "bg-lightBlue/30 font-medium"
        : "hover:bg-gray-100"
    }`}

  onKeyDown={(e) => {

    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowLineSuggestions(false);
      lineRef.current?.querySelector("input")?.focus();
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData((prev) => ({
        ...prev,
        equipment_line: option,
      }));
      setShowLineSuggestions(false);
      setLineSearch("");
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault();
    setFormData((prev) => ({
      ...prev,
      equipment_line: option,
    }));
    setShowLineSuggestions(false);
    setLineSearch("");
  }}
>
  {option}
</div>
      ))}

    {[...new Set([...lineOptions, ...tableData.map((i) => i.line)].filter(Boolean))]
      .filter((option) =>
        lineSearch
          ? option.toLowerCase().includes(lineSearch.toLowerCase())
          : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic">
        No lines found
      </div>
    )}
  </div>
)}

                  </>
                ) : (
                  <input
                    type="text"
                    value={formData.equipment_line}
                    onChange={(e) => {
                        const value = e.target.value;
                         if (errors.equipment_line) {
          setErrors({ ...errors, equipment_line: "" });
        }
                      setFormData({ ...formData, equipment_line: e.target.value })}}
                    placeholder="Enter Equipment Line"
                    className={`border  px-3 py-2 w-full mt-1 text-xs outline-none focus:ring-1 ${
                      errors.equipment_line ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                    }`}
                  />
                )}

                {errors.equipment_line && <p className="text-red1 text-xs mt-1">{errors.equipment_line}</p>}
              </div>

              {/* Equipment Model */}
              <div className="col-span-3 relative">
                <label className="text-xs font-medium text-black/70">Equipment Model <span className=" text-red1">*</span></label>

                {isEditing && tableData.length > 1 ? (
                  <>
                    <div className="relative">
                      <input
                        type="text"
                        maxLength={50}
                        value={formData.equipment_model}
                        onChange={(e) => {
                           if (errors.equipment_model) {
          setErrors({ ...errors, equipment_model: "" });
        }
                          setFormData({ ...formData, equipment_model: e.target.value });
                          setShowModelSuggestions(true);
                        }}
onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setShowModelSuggestions(true);
    }

    // ArrowDown → go to first option
    if (e.key === "ArrowDown" && showModelSuggestions) {
      e.preventDefault();
      e.stopPropagation()
      const first = dropdownRef.current?.querySelector("[data-option]");
      first?.focus();
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowModelSuggestions(false);
    }

  }}
                        placeholder="Select or type Equipment Model"
                        className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
                          ${showModelSuggestions ? "border-b-white" : ""}
                          ${errors.equipment_model ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                        `}
                        tabIndex={0}
                      />
                    
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowModelSuggestions((prev) => !prev)}
                        className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
                          showModelSuggestions ? "rotate-180" : "rotate-0"
                        }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>

                    </div>

                  {showModelSuggestions && (
  <div
    ref={dropdownRef}
    className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {[...new Set([...modelOptions, ...tableData.map((i) => i.model)].filter(Boolean))].length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5 border-black/10">
        <input
          type="text"
          placeholder="Search model..."
          value={modelSearch}
          onChange={(e) => setModelSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
        />
      </div>
    )}

    {[...new Set([...modelOptions, ...tableData.map((item) => item.model)])]
      .filter(Boolean)
      .filter((option) => option !== formData.equipment_model)
      .filter((option) =>
        modelSearch
          ? option.toLowerCase().includes(modelSearch.toLowerCase())
          : true
      )
      .sort((a, b) => a.localeCompare(b))
      .map((option, idx) => (
        <div
  tabIndex={0}
  data-option
  key={idx}
  className={`px-3 py-1.5 text-xs cursor-pointer transition
    ${
      formData.equipment_model === option
        ? "bg-lightBlue/30 font-medium"
        : "hover:bg-gray-100"
    }`}

  onKeyDown={(e) => {

    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowModelSuggestions(false);
      dropdownRef.current?.querySelector("input")?.focus();
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData((prev) => ({
        ...prev,
        equipment_model: option,
      }));
      setShowModelSuggestions(false);
      setModelSearch("");
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault();
    setFormData((prev) => ({
      ...prev,
      equipment_model: option,
    }));
    setShowModelSuggestions(false);
    setModelSearch("");
  }}
>
  {option}
</div>
      ))}

    {[...new Set([...modelOptions, ...tableData.map((i) => i.model)].filter(Boolean))]
      .filter((option) =>
        modelSearch
          ? option.toLowerCase().includes(modelSearch.toLowerCase())
          : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic">
        No models found
      </div>
    )}
  </div>
)}

                  </>
                ) : (
                  <input
                    type="text"
                    value={formData.equipment_model}
                    onChange={(e) => {
                        const value = e.target.value;
                         if (errors.equipment_model) {
          setErrors({ ...errors, equipment_model: "" });
        }
                      setFormData({ ...formData, equipment_model: e.target.value })}}
                    placeholder="Enter Equipment Model"
                    className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                      errors.equipment_model ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                    }`}
                  />
                )}

                {errors.equipment_model && <p className="text-red1 text-xs mt-1">{errors.equipment_model}</p>}
              </div>

            </div>
            {/* Save Button */}
            <button
              id="saveEquipmentBtn"
              onClick={async () => {
                const newErrors = {}
                if (!formData.year) {
                  newErrors.year = "Please enter this field";
                } else if (!/^\d{4}$/.test(formData.year)) {
                  newErrors.year = "Enter a valid 4-digit year";
                }
                else if (isNaN(formData.year)) newErrors.year = "Please enter a valid year"
                if (!formData.equipment_type) newErrors.equipment_type = "Please enter this field"
                if (!formData.equipment_model) newErrors.equipment_model = "Please enter this field"
                if (!formData.equipment_line) newErrors.equipment_line = "Please enter this field";
                if (!formData.equipment_make) newErrors.equipment_make = "Please enter this field";
                if (Object.keys(newErrors).length > 0) {
                  setErrors(newErrors)
                  return
                }

                try {
                  setIsLoading(true);
                  setError(null);
                  setSuccessMessage(null);

                  if (isEditing) {
                    await updateEquipment(editIndex, {
                      year: parseInt(formData.year),
                      equipment_type: formData.equipment_type,
                      equipment_make: formData.equipment_make,
                      equipment_line: formData.equipment_line,
                      equipment_model: formData.equipment_model
                    });
                    // setSuccessMessage("Equipment updated successfully!");
                  } else {
                    await addEquipment({
                      year: parseInt(formData.year),
                      equipment_type: formData.equipment_type,
                      equipment_make: formData.equipment_make,
                      equipment_line: formData.equipment_line,
                      equipment_model: formData.equipment_model
                    });
                    // setSuccessMessage("Equipment added successfully!");
                  }
                   resetSortAndFilter()
                  await fetchEquipmentData();

                  setFormData({ year: "", equipment_type: "", equipment_line: "", equipment_model: "", equipment_make: "" });
                  setErrors({});
                  setIsEditing(false);
                  setEditIndex(null);
                  setIsAddUserOpen(false);

                } catch (err) {
                  // console.error("Error saving equipment:", err);
                  setError(err.message || "Failed to save equipment");
                } finally {
                  setIsLoading(false);
                }
              }}
              className="mt-6 bg-darkblue1 text-xs font-medium text-white px-8 py-1.5  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  {isEditing ? "Updating..." : "Adding..."}
                </div>
              ) : (
                "Save"
              )}
            </button>
          </div>
        </div>
      )}

      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={async () => {
          if (deleteIndex !== null) {
            try {
              setIsLoading(true);
              setError(null);
              await deleteEquipment(deleteIndex);
              // setSuccessMessage("Equipment deleted successfully!");
              resetSortAndFilter()
              await fetchEquipmentData();
              setDeleteIndex(null);
            } catch (err) {
              // console.error("Error deleting equipment:", err);
              setError(err.message || "Failed to delete equipment");
            } finally {
              setIsLoading(false);
            }
          }
          setIsDeleteModalOpen(false);
        }}
      />
      {showActivateModal && selectedRow !== null && (
        <ActivateStatus
          isOpen={showActivateModal}
          onClose={() => setShowActivateModal(false)}
          onConfirm={async () => {
            try {
              setIsLoading(true);
              setError(null);
              await toggleEquipment(selectedRow);
              // setSuccessMessage("Equipment activated successfully!");
              await fetchEquipmentData();
              setShowActivateModal(false);
              setSelectedRow(null);
            } catch (err) {
              // console.error("Error activating equipment:", err);
              setError(err.message || "Failed to activate equipment");
            } finally {
              setIsLoading(false);
            }
          }}
        />
      )}

      {showDeactivateModal && selectedRow !== null && (
        <DeactivateStatus
          isOpen={showDeactivateModal}
          onClose={() => setShowDeactivateModal(false)}
          onConfirm={async () => {
            try {
              setIsLoading(true);
              setError(null);
              await toggleEquipment(selectedRow);
              // setSuccessMessage("Equipment deactivated successfully!");
              await fetchEquipmentData();
              setShowDeactivateModal(false);
              setSelectedRow(null);
            } catch (err) {
              // console.error("Error deactivating equipment:", err);
              setError(err.message || "Failed to deactivate equipment");
            } finally {
              setIsLoading(false);
            }
          }}
        />
      )}

    </div>
  )
}

export default Equipment;