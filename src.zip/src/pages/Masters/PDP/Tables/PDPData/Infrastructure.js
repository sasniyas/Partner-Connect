import { useState, useEffect, useRef, useCallback,useMemo } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus, ArrowRight } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import Filter from "../../../../../Components/Filter"
import DeleteModal from "../../../../../Components/DeleteModal"
import * as XLSX from "xlsx";
import ActivateStatus from "../../../../../Components/ActivateStatus"
import DeactivateStatus from "../../../../../Components/DeactivateStatus"
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { uploadTempFile } from "../../../../../services/download/bluckDownload.service"
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
import useCRUDWithReset from "../../../../../util/useCRUDWithReset"
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation"
import { 
  addInfrastructure, 
  getInfrastructures, 
  updateInfrastructure, 
  deleteInfrastructure, 
  toggleInfrastructure 
} from "../../../../../services/pdpMaster/infrastructure.service"
import { ChevronUp, ChevronDown } from "lucide-react";
function Infrastructure() {
  const [selectedYears, setSelectedYears] = useState([]); // array for multi-select
  const [selectedRow, setSelectedRow] = useState(null);
  const [startIndex, setStartIndex] = useState(0);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
const [selectedStatus, setSelectedStatus] = useState([]);
const statusOptions = [
    "Active", "Inactive"
];

  const [menuOpen, setMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const dropdownRef = useRef(null)
  const [tableData, setTableData] = useState([])
  const [facilitySearch, setFacilitySearch] = useState("");
const facilityRef = useRef(null);

  const [formData, setFormData] = useState({ 
    year: "", 
    facility_type: "", 
    facility_definition: "" 
  })
  const [isEditing, setIsEditing] = useState(false)
  const [editIndex, setEditIndex] = useState(null)
  const [errors, setErrors] = useState({})
  const [yearOptions, setYearOptions] = useState([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedYear, setSelectedYear] = useState("")
  const [selectedFacilityTypes, setSelectedFacilityTypes] = useState([]);
  const [facilityTypeOptions, setFacilityTypeOptions] = useState([]);
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null); // "asc", "desc", or null
const [hoveredCell, setHoveredCell] = useState(null);

  // Loading and error states
  const [isLoading, setIsLoading] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  const [deleteIndex, setDeleteIndex] = useState(null); // to track which row to delete
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const fileInputRef = useRef(null)

  // Lazy loading states
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLazyLoading, setIsLazyLoading] = useState(false);
  const observerRef = useRef();

  const itemsPerLoad = 10;
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);
  const popupRef= useRef(null)

  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  // Fetch infrastructure data from backend
  const fetchInfrastructureData = async () => {
    try {
      setIsInitialLoading(true);
      setError(null);
      const data = await getInfrastructures();
      
      // Map backend data to frontend format
      const mappedData = data.map(item => ({
        id: item.id,
        year: item.year,
        facilitytype: item.facility_type,
        facilitydef: item.facility_definition,
        status: item.isActive ? "Active" : "Inactive",
        createdOn: item.createdOn,
        isActive: item.isActive,
        isDeleted: item.isDeleted
      }));
      
      setTableData(mappedData);
    } catch (err) {
      // console.error("Error fetching infrastructure data:", err);
      setError(err.message || "Failed to fetch infrastructure data");
    } finally {
      setIsInitialLoading(false);
    }
  };

  const handleBulkUploadClick = () => {
    fileInputRef.current.click()
  }

const filteredData = useMemo(() => {
  const query = searchQuery.trim().toLowerCase();

  return tableData.filter((item) => {
    // Only include relevant columns in search
    const searchableFields = [
      item.year,
      item.facilitytype,
      item.facilitydef,
    ]
      .filter(Boolean) // removes null/undefined
      .map((v) => v.toString().toLowerCase());

    const matchesSearch = query
      ? searchableFields.some((val) => val.includes(query))
      : true;

    const matchesYear =
      selectedYears.length > 0 ? selectedYears.includes(item.year) : true;

    const matchesFacilityType =
      selectedFacilityTypes.length > 0
        ? selectedFacilityTypes.includes(item.facilitytype)
        : true;
 const matchesStatus = selectedStatus.length
      ? selectedStatus.includes(item.status)
      : true;
    return matchesSearch && matchesYear && matchesFacilityType && matchesStatus ;
  });
}, [tableData, searchQuery, selectedYears, selectedFacilityTypes, selectedStatus]);

const handleSort = (key) => {
  if (sortKey === key) {
    // cycle: asc → desc → default
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    }
    if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const valA = a[sortKey] ?? "";
    const valB = b[sortKey] ?? "";

    return sortOrder === "asc"
      ? valA.toString().localeCompare(valB.toString(), undefined, {
          numeric: true,
          sensitivity: "base",
        })
      : valB.toString().localeCompare(valA.toString(), undefined, {
          numeric: true,
          sensitivity: "base",
        });
  });
}, [filteredData, sortKey, sortOrder]);
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchQuery: { setter: setSearchQuery, resetValue: "" },
    selectedYears: { setter: setSelectedYears, resetValue: [] },
    selectedFacilityTypes:{setter:setSelectedFacilityTypes,resetValue:[]},
    selectedStatus:{setter:setSelectedStatus,resetValue:[]}
  }
);

  // Load more items function
  const loadMoreItems = useCallback(() => {
    if (isLazyLoading || !hasMore) return;

    setIsLazyLoading(true);
    
    setTimeout(() => {
      const currentLength = displayedItems.length;
      const nextItems = filteredData.slice(currentLength, currentLength + itemsPerLoad);
      
      if (nextItems.length === 0) {
        setHasMore(false);
      } else {
        setDisplayedItems(prev => [...prev, ...nextItems]);
      }
      
      setIsLazyLoading(false);
    }, 300); // Small delay to simulate loading
  }, [displayedItems.length, filteredData, isLazyLoading, hasMore]);

  // Intersection Observer callback
  const lastItemRef = useCallback(node => {
    if (isLazyLoading) return;
    if (observerRef.current) observerRef.current.disconnect();
    
    observerRef.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        loadMoreItems();
      }
    });
    
    if (node) observerRef.current.observe(node);
  }, [isLazyLoading, hasMore, loadMoreItems]);

  // Reset displayed items when search or filters change
  useEffect(() => {
  setDisplayedItems(filteredData.slice(0, itemsPerLoad));
  setHasMore(filteredData.length > itemsPerLoad);
}, [filteredData]);


  // Initial load
  useEffect(() => {
    fetchInfrastructureData();
  }, []);

  // Update displayed items when data changes
  useEffect(() => {
    setDisplayedItems(filteredData.slice(0, itemsPerLoad));
    setHasMore(filteredData.length > itemsPerLoad);
  }, [filteredData]);

  // Auto-dismiss success messages
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => {
        setSuccessMessage(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  useEffect(() => {
    const facilityTypes = [...new Set(tableData.map(item => item.facilitytype))].sort();
    setFacilityTypeOptions(facilityTypes);
  }, [tableData]);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])
useEffect(() => {
  const handleClickOutside = (e) => {
    if (facilityRef.current && !facilityRef.current.contains(e.target)) {
      setShowSuggestions(false);
      setFacilitySearch("");
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

 useEffect(() => {
    const years = [...new Set(tableData.map((item) => item.year))].sort((a, b) => Number(a) - Number(b));
    setYearOptions(years);
  }, [tableData]);
useEffect(() => {
  if (isEditing && selectedRow) {
    setFormData({
      ...selectedRow,
      equipment_type: selectedRow.equipment_type || "",
    });
  }
}, [isEditing, selectedRow]); // ❌ NOT formData

 

const handleDownloadTemplate = async () => {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Infrastructure");

  // ================= COLUMNS =================
  sheet.columns = [
    { header: "Year", key: "year", width: 15 },
    { header: "Facility Type", key: "type", width: 40 },
    { header: "Facility Definition", key: "definition", width: 90 },
  ];

  // ================= FORCE LEFT ALIGNMENT (ALL ROWS + NEW ROWS) =================
  sheet.columns.forEach((column) => {
    column.alignment = {
      vertical: "middle",
      horizontal: "left",
      wrapText: true,
    };

    // 🔥 Prevent Excel auto right-alignment
    column.numFmt = "@";
  });

  // ================= SAMPLE ROW =================
  sheet.addRow({
    year: "2025",
    type: "Touch Point (Service)",
    definition:
      "Equipment Sales Office, Parts Warehouse, Parts Sale Counter, Workshop for Repair and Components",
  });

  // ================= UNLOCK ALL COLUMNS =================
  sheet.columns.forEach((column) => {
    column.protection = { locked: false };
  });

  // ================= HEADER STYLE (LOCKED) =================
  const headerRow = sheet.getRow(1);
  headerRow.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FF476896" },
    };
    cell.alignment = { vertical: "middle", horizontal: "left" };
    cell.protection = { locked: true }; // 🔒 header only
  });

  // ================= PROTECT SHEET =================
  await sheet.protect("12345", {
    selectLockedCells: true,
    selectUnlockedCells: true,
    insertRows: true,     // ✅ new rows allowed
    deleteRows: true,
    formatColumns: true,
    formatRows: true,
  });

  // ================= DOWNLOAD =================
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  saveAs(blob, "Infrastructure_Bulk_Upload_Template.xlsx");
};


const handleBulkUpload = (e) => {
  const file = e.target.files[0];
  if (!file) return;

  // Open preview tab first
  const previewTab = window.open(
    "/bulkupload/infrastructure", // Change this to your preview route
    "_blank"
  );

  if (!previewTab) {
    // alert("Popup blocked! Please allow popups.");
    return;
  }

  const reader = new FileReader();

  reader.onload = (event) => {
    const data = new Uint8Array(event.target.result);
    const workbook = XLSX.read(data, { type: "array" });
    const sheetName = workbook.SheetNames[0];

    let rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });

    // Remove completely empty rows
    rows = rows.filter((row) =>
      Object.values(row).some((v) => v !== "")
    );

    // Map and validate rows
    const finalRows = rows.map((row, index) => ({
      slNo: index + 1,
      year: row["Year"] || "",
      facilityType: row["Facility Type"] || "",
      facilityDefinition: row["Facility Definition"] || "",
      hasError: !row["Year"] || !row["Facility Type"] || !row["Facility Definition"], // all fields required
    }));

    // Send data to preview page
    previewTab.postMessage(
      {
        type: "INFRASTRUCTURE_PREVIEW",
        payload: { rows: finalRows },
      },
      "*"
    );
  };

  reader.readAsArrayBuffer(file);
};

 const handlePreviewAndDownload = async () => {
  if (!displayedItems || displayedItems.length === 0) {
    // alert("No data available to upload");
    return;
  }

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Infrastructure");

  // ================= HEADERS =================
  sheet.columns = [
    { header: "Sl. No", key: "slNo", width: 10 },
    { header: "Year", key: "year", width: 15 },
    { header: "Facility Type", key: "facilityType", width: 40 },
    { header: "Facility Definition", key: "facilityDefinition", width: 100 },
    { header: "Status", key: "status", width: 15 },
  ];

  // ================= HEADER STYLE =================
  sheet.getRow(1).eachCell((cell) => {
    cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
    cell.alignment = { vertical: "middle", horizontal: "left" };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FF476896" },
    };
  });

  // ================= DATA ROWS =================
  displayedItems.forEach((item, index) => {
    const row = sheet.addRow({
      slNo: index + 1,
      year: item.year || "",
      facilityType: item.facilitytype || "",
      facilityDefinition: item.facilitydef || "",
      status: item.isActive ? "Active" : "Inactive",
    });

    row.eachCell((cell) => {
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });
  });

  // ================= CREATE FILE =================
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  const file = new File([blob], "Infrastructure.xlsx", {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  try {
    const response = await uploadTempFile(file);
    const fileUrl = response
      ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
      : null;

    if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    } else {
      // console.warn("Upload succeeded but no file URL returned");
    }
  } catch (error) {
    // console.error("Upload failed:", error);
    // alert("Failed to upload file. Check console for details.");
  }
};

useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
    document.getElementById("saveinfrastructureBtn")?.click();
  },

  onCancel: () => {
    setIsAddUserOpen(false);
    setIsEditing(false);
   setFormData({ year: "", facility_type: "", facility_definition: "" });
                  setErrors({});
  },
});

  return (
<div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300  ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full  transition-all duration-300 ease-in-out ">
            {/* 🔹 Heading */}
            <div className="flex items-center justify-between mb-2 flex-wrap gap-4">
              <h2 className="text-base font-medium font-VolvoNovum text-center text-darkblue1 flex items-center justify-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1  p-1"
                />
                PDP Data / Infrastructure         
              </h2>
            </div>

            {/* Error and Success Messages */}
            {error && (
              <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 ">
                {error}
              </div>
            )}
            {successMessage && (
              <div className="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 ">
                {successMessage}
              </div>
            )}

            {/* Loading State */}
            {isInitialLoading && (
              <div className="mb-4 p-4 text-center">
                <div className="inline-flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-darkblue1"></div>
                  Loading infrastructure data...
                </div>
              </div>
            )}
           <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 md:gap-12 lg:gap-18 mb-2">
            <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">      
                
                {/* 🔍 Search Input */}
                <div className="">
                  <Searchinput
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                    }}
                    value={searchQuery}
                    placeholder="Search"
                    className="w-[1/2]"
                    iconColor="text-black"
                    bgColor="bg-FrostWhite"
              borderColor="border-black/60"
                    textColor="text-black"
                    shadow="shadow-none"
                    inputPadding="pl-6 pr-3 py-1.5"
                    iconSize="w-3 h-3"
                    iconLeft="left-3"
                    inputWidth="w-full"
                    focusRing="focus:ring-1 focus:ring-black/60"
                    hoverInputClasses="hover:bg-white hover:border-black/60"
                  />
                </div>

                {/* 📆 Year Filter */}
                <Filter
                  name="year"
                  placeholder="Year"
                  options={yearOptions}
                  customWidth="w-[120px]"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black"
                  openBgColor="bg-white"
                  textColor="text-black"
                  value={selectedYears}
                  onChange={(name, value) => {
                    setSelectedYears(value);
                  }}
                />

                {/* 🏥 Facility Type Filter */}
                <Filter
                  name="facilitytype"
                  placeholder="Facility Type"
                  options={facilityTypeOptions}
                  customWidth="w-[220px]"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  textColor="text-black"
                  value={selectedFacilityTypes}
                  onChange={(name, value) => {
                    setSelectedFacilityTypes(value);
                  }}
                />
  <Filter
  name="status"
  placeholder="Status"
  options={statusOptions}
  value={selectedStatus} // ✅ array
  customWidth="w-[80px]"
  placeholderColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black/60"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
  onChange={(name, value) => {
    setSelectedStatus(value);
  }}
/>
              </div>

             
              {/* 🔸 Right Side: Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                
                {/* ➕ Add Dropdown */}
                <div className="relative w-full sm:w-[190px]" ref={dropdownRef}>
                  <button
                    onClick={() => setOpen(!open)}
                    className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-1.5 text-xs  flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
                  >
                    <Plus className="w-4 h-4 stroke-[3]" />
                    Add New
                  </button>

                  {open && (
                    <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1  shadow-lg z-50">
                      <button
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1"
                        onClick={() => {
                          setIsAddUserOpen(true);
                          setOpen(false);
                        }}
                      >
                        <div className="">
   <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
<path d="M4.57767 6.49C4.61833 6.88 4.86767 7.20367 5.22333 7.36733C5.96233 7.707 7.26 8.25 8 8.25C8.74 8.25 10.0377 7.70667 10.7767 7.36733C11.1323 7.204 11.3817 6.87967 11.4223 6.49C11.462 6.10767 11.5 5.536 11.5 4.75C11.5 3.964 11.462 3.39233 11.4223 3.01C11.3817 2.62 11.1323 2.29633 10.7763 2.13267C10.0377 1.793 8.74033 1.25 8 1.25C7.26 1.25 5.96233 1.79333 5.22333 2.13267C4.86767 2.296 4.61833 2.62033 4.57767 3.01C4.538 3.39233 4.5 3.964 4.5 4.75C4.5 5.536 4.538 6.10767 4.57767 6.49Z" stroke="black" stroke-width="0.8" stroke-linejoin="round"/>
<path d="M4.5 2.6499C4.5 2.6499 7.29333 4.0499 8 4.0499C8.70667 4.0499 11.5 2.6499 11.5 2.6499" stroke="black" stroke-width="0.8" stroke-linejoin="round"/>
<path d="M8 4.0498V8.2498" stroke="black" stroke-width="0.8" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1.07767 12.5735C1.11833 12.9635 1.36767 13.2872 1.72367 13.4508C2.46233 13.7905 3.76 14.3335 4.5 14.3335C5.24 14.3335 6.53767 13.7902 7.27667 13.4508C7.63233 13.2875 7.88167 12.9632 7.92233 12.5735C7.962 12.1912 8 11.6195 8 10.8335C8 10.0475 7.962 9.47583 7.92233 9.0935C7.88167 8.7035 7.63233 8.37983 7.27667 8.21616C6.53767 7.8765 5.24 7.3335 4.5 7.3335C3.76 7.3335 2.46233 7.87683 1.72333 8.21616C1.36767 8.3795 1.11833 8.70383 1.07767 9.0935C1.038 9.47583 1 10.0475 1 10.8335C1 11.6195 1.038 12.1912 1.07767 12.5735Z" stroke="black" stroke-width="0.8" stroke-linejoin="round"/>
<path d="M1 8.7334C1 8.7334 3.79333 10.1334 4.5 10.1334C5.20667 10.1334 8 8.7334 8 8.7334" stroke="black" stroke-width="0.8" stroke-linejoin="round"/>
<path d="M4.5 10.1333V14.3333" stroke="black" stroke-width="0.8" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8.07767 12.5735C8.11833 12.9635 8.36767 13.2872 8.72333 13.4508C9.46267 13.7905 10.76 14.3335 11.5 14.3335C12.24 14.3335 13.5377 13.7902 14.2767 13.4508C14.6323 13.2875 14.8817 12.9632 14.9223 12.5735C14.962 12.1912 15 11.6195 15 10.8335C15 10.0475 14.962 9.47583 14.9223 9.0935C14.8817 8.7035 14.6323 8.37983 14.2763 8.21616C13.5377 7.8765 12.2407 7.3335 11.5 7.3335C10.76 7.3335 9.46233 7.87683 8.72333 8.21616C8.36767 8.3795 8.11833 8.70383 8.07767 9.0935C8.038 9.47583 8 10.0475 8 10.8335C8 11.6195 8.038 12.1912 8.07767 12.5735Z" stroke="black" stroke-width="0.8" stroke-linejoin="round"/>
<path d="M8 8.7334C8 8.7334 10.7933 10.1334 11.5 10.1334C12.2067 10.1334 15 8.7334 15 8.7334" stroke="black" stroke-width="0.8" stroke-linejoin="round"/>
<path d="M11.5 10.1333V14.3333" stroke="black" stroke-width="0.8" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

  </div>

                        Add Infrastructure
                      </button>
                      <button
        onClick={() => navigate("/bulkupload/infrastructure")}
        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1"
      >
       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>

        Bulk Upload
      </button>

  <input
    type="file"
    ref={fileInputRef}
    className="hidden"
    accept=".xlsx,.xls"
    onChange={handleBulkUpload}
  />
          
                      <button
                        onClick={handleDownloadTemplate}
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1  whitespace-nowrap"
                      >
<svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
                       Bulk upload Template
                      </button>
                    </div>
                  )}
                </div>

                {/* ⬇️ Download Button */}
                <button
                  onClick={handlePreviewAndDownload}
                  className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1  flex items-center gap-2 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
                >
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
<path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D"/>
</svg>
           
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"className="w-3 h-3 hidden group-hover:block">
<path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white"/>
</svg>

                  <span className="font-semibold">Download</span>
                </button>
              </div>
            </div>

          

{/* 🔹 RESPONSIVE TABLE - FINAL (NO LAZY LOADING) */}
<div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
  <div
  ref={tableContainerRef}
    className="overflow-y-auto relative"
    style={{
      scrollbarWidth: "none",
      msOverflowStyle: "none",
      maxHeight: sortedData.length > 8 ? "calc(100vh - 220px)" : "auto",
    }}
    onScroll={handleTableScroll}
  >
    <style jsx>{`
      div::-webkit-scrollbar {
        display: none;
      }
    `}</style>

    <table className="w-full text-xs whitespace-nowrap cursor-pointer border-collapse">
      <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
        <tr>
          {/* Year - w-[10%] */}
          <th
            className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
            onClick={() => handleSort("year")}
          >
            <div className="flex items-center gap-1">
              Year
              {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}


              {sortKey === "year" && sortOrder === "asc" && (
                <ChevronUp className="w-3 h-3 text-white" />
              )}
              {sortKey === "year" && sortOrder === "desc" && (
                <ChevronDown className="w-3 h-3 text-white" />
              )}
            </div>
          </th>

          {/* Facility Type - w-[30%] */}
          <th
            className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[30%] cursor-pointer select-none"
            onClick={() => handleSort("facilitytype")}
          >
            <div className="flex items-center gap-1">
              Facility Type
              {sortKey === "facilitytype" && sortOrder === "asc" && (
                <ChevronUp className="w-3 h-3 text-white" />
              )}
              {sortKey === "facilitytype" && sortOrder === "desc" && (
                <ChevronDown className="w-3 h-3 text-white" />
              )}
            </div>
          </th>

          {/* Facility Definition - w-[40%] */}
          <th
            className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%] cursor-pointer select-none"
            onClick={() => handleSort("facilitydef")}
          >
            <div className="flex items-center gap-1">
              Facility Definition
              {sortKey === "facilitydef" && sortOrder === "asc" && (
                <ChevronUp className="w-3 h-3 text-white" />
              )}
              {sortKey === "facilitydef" && sortOrder === "desc" && (
                <ChevronDown className="w-3 h-3 text-white" />
              )}
            </div>
          </th>

          {/* Actions - w-[20%] */}
          <th className="text-center px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">
            Actions
          </th>
        </tr>
      </thead>

      <tbody className="text-black">
        {sortedData.length > 0 ? (
          sortedData.map((item, index) => (
            <tr
              key={index}
              className={`hover:bg-lightBlue/50 text-xs ${
                item.status === "Active" ? "text-black" : "text-gray-400"
              }`}
            >
              {/* Year */}
              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                {item.year}
              </td>

              {/* Facility Type */}
              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                <div className="relative">
                  <p
                    className="truncate max-w-[20rem] cursor-pointer"
                    onMouseEnter={() => {
                      if (item.facilitytype && item.facilitytype.length > 40)
                        setHoveredCell(item.id + "-facilitytype");
                    }}
                    onMouseLeave={() => setHoveredCell(null)}
                  >
                    {item.facilitytype}
                  </p>
                  {hoveredCell === item.id + "-facilitytype" && (
                    <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                      {item.facilitytype}
                    </span>
                  )}
                </div>
              </td>

              {/* Facility Definition */}
              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                <div className="relative">
                  <p
                    className="truncate max-w-[35rem] cursor-pointer"
                    onMouseEnter={() => {
                      if (item.facilitydef && item.facilitydef.length > 40)
                        setHoveredCell(item.id + "-facilitydef");
                    }}
                    onMouseLeave={() => setHoveredCell(null)}
                  >
                    {item.facilitydef}
                  </p>
                  {hoveredCell === item.id + "-facilitydef" && (
                    <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                      {item.facilitydef}
                    </span>
                  )}
                </div>
              </td>

              {/* Actions */}
              <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                <div className="flex items-center justify-center gap-4">
                  {/* Edit */}
                  <div className="relative group">
                    <button onClick={() => {
                      setFormData({
                        year: item.year,
                        facility_type: item.facilitytype || "",
                        facility_definition: item.facilitydef || "",
                      });
                      setIsAddUserOpen(true);
                      setIsEditing(true);
                      setEditIndex(item.id);
                    }}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                        <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                      </svg>
                    </button>
                    <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">Edit</span>
                  </div>

                  {/* Toggle */}
                  <div className="relative group">
                    <button onClick={() => {
                      setSelectedRow(item.id);
                      item.status === "Active" ? setShowDeactivateModal(true) : setShowActivateModal(true);
                    }}>
                      {item.status === "Active" ? (
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
                          <path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      )}
                    </button>
                    <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                      {item.status === "Active" ? "Deactivate" : "Activate"}
                    </span>
                  </div>

                  {/* Delete */}
                  <div className="relative group">
                    <button onClick={() => {
                      setDeleteIndex(item.id);
                      setIsDeleteModalOpen(true);
                    }}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                        <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                      </svg>
                    </button>
                    <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">Delete</span>
                  </div>
                </div>
              </td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan={4} className="px-4 py-6 text-center italic text-gray-500">No data found</td>
          </tr>
        )}
      </tbody>
    </table>
  </div>
  {showScrollButtons && (
            <div className="fixed bottom-14 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}
</div>
          </div>
        </div>
      </div>

      {/* 🔹 Scroll to Top Button */}
     
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
          <div className="bg-white  p-6 w-full max-w-xl relative">
            <h2 className="text-base font-semibold text-center mb-2 text-MediumGrey">
              {isEditing ? "Infrastructure" : "Add Infrastructure"}
            </h2>
            <button
              onClick={() => {
                setIsAddUserOpen(false)
                setIsEditing(false)
                setFormData({ year: "", facilitytype: "", facilitydef: "" })
                setErrors({})
              }}
              className="absolute top-3 right-4 text-red-600 font-bold text-xl"
            >
 <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>

            </button>
            {/* 🔹 Grid Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {/* Year */}
              <div className="md:col-span-1">
                <label className="text-xs font-medium text-black/70">Year <span className=" text-red1">*</span></label>
               <input
                  type="text"
                  value={formData.year}
                  tabIndex={0}
                  onChange={(e) => {
                    const value = e.target.value;
                     if (errors.year) {
          setErrors({ ...errors, year: "" });
        }
                    if (/^\d{0,4}$/.test(value)) {
                      setFormData({ ...formData, year: value });
                    }
                  }}
                  maxLength={4}
                  className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                    errors.year ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                  placeholder="Enter Year"
                />

                {errors.year && <p className="text-red1 text-xs mt-1">{errors.year}</p>}
              </div>
              {/* Category Name */}
              <div className="col-span-1 md:col-span-2">
                <label className="text-xs font-medium text-black/70">Facility Type <span className=" text-red1">*</span></label>

                {/* More than 1 row → dropdown with suggestions */}
                {isEditing && tableData.length > 1 ? (
                  <>
                    <div className="relative w-full">
                      <input
                        type="text"
                        value={formData.facility_type}
                        maxLength={75}
                        tabIndex={0}
                        onChange={(e) => {
                           if (errors.facility_type) {
          setErrors({ ...errors,facility_type: "" });
        }
                          setFormData({ ...formData, facility_type: e.target.value });
                          setShowSuggestions(true);
                        }}
 onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setShowSuggestions(true);
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowSuggestions(false);
    }

  }}                        onClick={() => setShowSuggestions(true)}
                        placeholder="Enter Facility Type"
                        className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
                          ${showSuggestions ? " border-b-white" : ""}
                          ${errors.facility_type ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                        `}
                      />

                     
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowSuggestions((prev) => !prev)}
                        className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
                          showSuggestions ? "rotate-180" : "rotate-0"
                        }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>

                      {/* Suggestions */}
                    {showSuggestions && (
  <div
    ref={facilityRef}
    className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {/* Search input */}
    {Array.from(new Set(tableData.map(item => item.facilitytype))).length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5  border-black/10 z-10">
        <input
          type="text"
          placeholder="Search facility..."
          value={facilitySearch}
          onChange={(e) => setFacilitySearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
        />
      </div>
    )}

    {/* Options list */}
    {Array.from(new Set(tableData.map(item => item.facilitytype)))
      .filter(Boolean)
      .filter(option =>
        facilitySearch
          ? option.toLowerCase().includes(facilitySearch.toLowerCase())
          : true
      )
      .filter(option => option !== formData.facility_type)
      .sort((a, b) => a.localeCompare(b))
      .map((option, idx) => (
       <div
  tabIndex={0}
  data-option
  key={idx}
  className={`px-3 py-1.5 text-xs cursor-pointer transition
  ${
    option === formData.facility_type
      ? "bg-lightBlue/30 font-medium"
      : "hover:bg-gray-100"
  }`}

  onKeyDown={(e) => {

    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowSuggestions(false);
      facilityRef.current?.querySelector("input")?.focus();
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData({ ...formData, facility_type: option });
      setShowSuggestions(false);
      setFacilitySearch("");
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault();
    setFormData({ ...formData, facility_type: option });
    setShowSuggestions(false);
    setFacilitySearch("");
  }}
>
  {option}
</div>
      ))}

    {/* No results */}
    {Array.from(new Set(tableData.map(item => item.facilitytype)))
      .filter(Boolean)
      .filter(option =>
        facilitySearch
          ? option.toLowerCase().includes(facilitySearch.toLowerCase())
          : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic">
        No facilities found
      </div>
    )}
  </div>
)}

                    </div>
                  </>
                ) : (
                  // Only 1 row OR not editing → plain input
                  <input
                    type="text"
                    value={formData.facility_type}
                    onChange={(e) => {
                       if (errors.facility_type) {
          setErrors({ ...errors, facility_type: "" });
        }
                      setFormData({ ...formData, facility_type: e.target.value });
                    }}
                    placeholder="Enter Facility Type"
                    className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                      errors.facility_type ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                    }`}
                  />
                )}

                {errors.facility_type && (
                  <p className="text-red1 text-xs mt-1">{errors.facility_type}</p>
                )}
              </div>
              
              {/* Facility Definition */}
              <div className="col-span-1 md:col-span-3">
                <label className="text-xs font-medium text-black/70">Facility Definition <span className=" text-red1">*</span></label>
                <input
                  type="text"
                  maxLength={150}
                  tabIndex={0}
                  value={formData.facility_definition || ""}
                  onChange={(e) => {
                     if (errors.facility_definition) {
          setErrors({ ...errors, facility_definition: "" });
        }
                    setFormData({ ...formData, facility_definition: e.target.value })}}
                  placeholder="Enter definition"
                  className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                    errors.facility_definition ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                />
                {errors.facility_definition && <p className="text-red1 text-xs mt-1">{errors.facility_definition}</p>}
              </div>
            </div>
            
            {/* Save Button */}
            <button
            id="saveinfrastructureBtn"
              onClick={async () => {
                const newErrors = {}
                if (!formData.year) {
                  newErrors.year = "Please enter this field";
                } else if (!/^\d{4}$/.test(formData.year)) {
                  newErrors.year = "Enter a valid 4-digit year";
                }
                else if (isNaN(formData.year)) newErrors.year = "Please enter a valid year"
                if (!formData.facility_type) newErrors.facility_type = "Please enter this field"
                if (!formData.facility_definition) newErrors.facility_definition = "Please enter this field"
                if (Object.keys(newErrors).length > 0) {
                  setErrors(newErrors)
                  return
                }

                try {
                  setIsLoading(true);
                  setError(null);
                  setSuccessMessage(null);

                  if (isEditing) {
                    // Update existing infrastructure
                    await updateInfrastructure(editIndex, {
                      year: parseInt(formData.year),
                      facility_type: formData.facility_type,
                      facility_definition: formData.facility_definition
                    });
                    // setSuccessMessage("Infrastructure updated successfully!");
                  } else {
                    // Add new infrastructure
                    await addInfrastructure({
                      year: parseInt(formData.year),
                      facility_type: formData.facility_type,
                      facility_definition: formData.facility_definition
                    });
                    // setSuccessMessage("Infrastructure added successfully!");
                  }
resetSortAndFilter()
                  // Refresh data from backend
                  await fetchInfrastructureData();

                  // Reset form
                  setFormData({ year: "", facility_type: "", facility_definition: "" });
                  setErrors({});
                  setIsEditing(false);
                  setEditIndex(null);
                  setIsAddUserOpen(false);

                } catch (err) {
                  // console.error("Error saving infrastructure:", err);
                  setError(err.message || "Failed to save infrastructure");
                } finally {
                  setIsLoading(false);
                }
              }}
              className="mt-6 bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  {isEditing ? "Updating..." : "Adding..."}
                </div>
              ) : (
                "Save"
              )}
            </button>
          </div>
        </div>
      )}

      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={async () => {
          if (deleteIndex !== null) {
            try {
              setIsLoading(true);
              setError(null);
              await deleteInfrastructure(deleteIndex);
              // setSuccessMessage("Infrastructure deleted successfully!");
              resetSortAndFilter()
              await fetchInfrastructureData();
              setDeleteIndex(null);
            } catch (err) {
              // console.error("Error deleting infrastructure:", err);
              setError(err.message || "Failed to delete infrastructure");
            } finally {
              setIsLoading(false);
            }
          }
          setIsDeleteModalOpen(false);
        }}
      />
      {showActivateModal && selectedRow !== null && (
        <ActivateStatus
          isOpen={showActivateModal}
          onClose={() => setShowActivateModal(false)}
          onConfirm={async () => {
            try {
              setIsLoading(true);
              setError(null);
              await toggleInfrastructure(selectedRow);
              // setSuccessMessage("Infrastructure activated successfully!");
              await fetchInfrastructureData();
              setShowActivateModal(false);
              setSelectedRow(null);
            } catch (err) {
              // console.error("Error activating infrastructure:", err);
              setError(err.message || "Failed to activate infrastructure");
            } finally {
              setIsLoading(false);
            }
          }}
        />
      )}

      {showDeactivateModal && selectedRow !== null && (
        <DeactivateStatus
          isOpen={showDeactivateModal}
          onClose={() => setShowDeactivateModal(false)}
          onConfirm={async () => {
            try {
              setIsLoading(true);
              setError(null);
              await toggleInfrastructure(selectedRow);
              // setSuccessMessage("Infrastructure deactivated successfully!");
              await fetchInfrastructureData();
              setShowDeactivateModal(false);
              setSelectedRow(null);
            } catch (err) {
              // console.error("Error deactivating infrastructure:", err);
              setError(err.message || "Failed to deactivate infrastructure");
            } finally {
              setIsLoading(false);
            }
          }}
        />
      )}
    </div>
  )
}

export default Infrastructure;