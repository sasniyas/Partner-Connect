import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus, ArrowRight, ChevronUp, ChevronDown } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import Filter from "../../../../../Components/Filter"
import DeleteModal from "../../../../../Components/DeleteModal"
import * as XLSX from "xlsx"
import DeactivateStatus from "../../../../../Components/DeactivateStatus"
import ActivateStatus from "../../../../../Components/ActivateStatus"
import { addCompetence, updateCompetence, getCompetences, toggleCompetence, deleteCompetence } from "../../../../../services/pdpMaster/competence.service"
import ExcelJS from "exceljs"
import { saveAs } from "file-saver"
import { uploadTempFile } from "../../../../../services/download/bluckDownload.service"
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
import useCRUDWithReset from "../../../../../util/useCRUDWithReset"
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation"
function Competence() {
  const [selectedCompetenceTypes, setSelectedCompetenceTypes] = useState([])
  const [selectedRow, setSelectedRow] = useState(null)
  const [showDeactivateModal, setShowDeactivateModal] = useState(false)
  const [showActivateModal, setShowActivateModal] = useState(false)
  const [showDIRequiredDropdown, setShowDIRequiredDropdown] = useState()
  const [menuOpen, setMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const dropdownRef = useRef(null)
  const [tableData, setTableData] = useState([])
  const [formData, setFormData] = useState({ competencetype: "", competencename: "", di_required: "" })
  const [isEditing, setIsEditing] = useState(false)
  const [editIndex, setEditIndex] = useState(null)
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [apiError, setApiError] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [hoveredCell, setHoveredCell] = useState(null)
  const [selectedDIRequired, setSelectedDIRequired] = useState("")
  const [deleteIndex, setDeleteIndex] = useState(null)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [showcompetencenamesuggestion, setShowcompetencenamesuggestion] = useState(false)
  const [showCompetenceTypeSuggestions, setShowCompetenceTypeSuggestions] = useState(false)
  const [competenceOptions, setCompetenceOptions] = useState([])
  const [selectedStatus, setSelectedStatus] = useState([])
  const [sortKey, setSortKey] = useState(null)
  const [sortOrder, setSortOrder] = useState(null)
  const fileInputRef = useRef(null)
  const [competenceSearch, setCompetenceSearch] = useState("");
const competenceRef = useRef(null);
const [competenceNameSearch, setCompetenceNameSearch] = useState("");
const competenceNameRef = useRef(null);
const popupRef=useRef(null)

  const statusOptions = ["Active", "Inactive"]
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") setSortOrder("desc")
      else if (sortOrder === "desc") {
        setSortKey(null)
        setSortOrder(null)
      } else setSortOrder("asc")
    } else {
      setSortKey(key)
      setSortOrder("asc")
    }
  }

  // Load competences from API on component mount
  useEffect(() => {
    const loadCompetences = async () => {
      try {
        setLoading(true)
        setApiError(null)

        const data = await getCompetences()

        if (!Array.isArray(data)) {
          // console.error("API response is not an array:", data)
          throw new Error("Invalid data format received from API")
        }

        if (data.length === 0) {
          setTableData([])
          return
        }

        const transformedData = data.map(item => ({
          id: item.id,
          year: item.year,
          competencetype: item.competence_type,
          competencename: item.competence_name,
          di_required: item.di_required === 1 ? "Yes" : "No",
          status: item.isActive === 1 ? "Active" : "Inactive",
          createdOn: item.createdOn,
          isActive: item.isActive === 1,
          isDeleted: item.isDeleted || false
        }))

        setTableData(transformedData)
      } catch (error) {
        // console.error("Error loading competences:", error)
        // console.error("Error details:", {
        //   message: error.message,
        //   response: error.response?.data,
        //   status: error.response?.status,
        //   statusText: error.response?.statusText
        // })

        setTableData([])
        setApiError(`API Error: ${error.message || "Failed to load competences"}`)
      } finally {
        setLoading(false)
      }
    }

    loadCompetences()
  }, [])

  const handleBulkUploadClick = () => {
    fileInputRef.current.click()
  }

  const filteredData = useMemo(() => {
  const safeSearch = String(searchQuery || "").toLowerCase()

  return tableData.filter(item => {
    const matchesSearch = safeSearch
      ? Object.values(item).some(val =>
          String(val ?? "").toLowerCase().includes(safeSearch)
        )
      : true

    const matchesCompetenceType =
      selectedCompetenceTypes.length
        ? selectedCompetenceTypes
            .map(v => v.toLowerCase())
            .includes(String(item.competencetype).toLowerCase())
        : true

    const matchesDIRequired =
      selectedDIRequired && selectedDIRequired !== "All"
        ? String(item.di_required).toLowerCase() ===
          String(selectedDIRequired).toLowerCase()
        : true

    const matchesStatus =
      selectedStatus.length
        ? selectedStatus
            .map(v => v.toLowerCase())
            .includes(String(item.status).toLowerCase())
        : true

    return (
      matchesSearch &&
      matchesCompetenceType &&
      matchesDIRequired &&
      matchesStatus
    )
  })
}, [
  tableData,
  searchQuery,
  selectedCompetenceTypes,
  selectedDIRequired,
  selectedStatus
])

const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData

  return [...filteredData].sort((a, b) => {
    const valA = String(a?.[sortKey] ?? "")
    const valB = String(b?.[sortKey] ?? "")

    return sortOrder === "asc"
      ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: "base" })
      : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: "base" })
  })
}, [filteredData, sortKey, sortOrder])
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchQuery: { setter: setSearchQuery, resetValue: "" },
    selectedCompetenceTypes :{setter :setSelectedCompetenceTypes,resetValue :[]},
    selectedDIRequired :{setter :setSelectedDIRequired,resetValue :""},
    selectedStatus:{setter :setSelectedStatus,resetValue :[]}
  }
);

  // Scroll to top button visibility
  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 100)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Dropdown close when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])
useEffect(() => {
  const handleClickOutside = (e) => {
    if (competenceRef.current && !competenceRef.current.contains(e.target)) {
      setShowCompetenceTypeSuggestions(false);
      setCompetenceSearch("");
    }
  };
  
  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);
useEffect(() => {
  const handleClickOutside = (e) => {
    if (competenceNameRef.current && !competenceNameRef.current.contains(e.target)) {
      setShowcompetencenamesuggestion(false);
      setCompetenceNameSearch("");
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);

  // Load competence options from tableData
  useEffect(() => {
    const competenceTypesFromData = tableData
      .map(item => item.competencetype?.trim())
      .filter(val => val && val.length > 0)

    setCompetenceOptions([...new Set(competenceTypesFromData)])
  }, [tableData])
useEffect(() => {
  if (isEditing && selectedRow) {
    setFormData({
      ...selectedRow,
      equipment_type: selectedRow.equipment_type || "",
    });
  }
}, [isEditing, selectedRow]); // ❌ NOT formData

  const handleDownloadTemplate = async () => {
    const workbook = new ExcelJS.Workbook()
    const sheet = workbook.addWorksheet("Competence")

    sheet.columns = [
      { header: "Competence Type", key: "type", width: 30 },
      { header: "Competence Name", key: "name", width: 30 },
      { header: "Required for DI", key: "di_required", width: 20 },
    ]

    sheet.columns.forEach((column) => {
      column.alignment = {
        vertical: "middle",
        horizontal: "left",
        wrapText: true,
      }
      column.numFmt = "@"
    })

    sheet.addRow({
      type: "GPE (General Production Equipment)",
      name: "Excavators",
      di_required: "Yes",
    })

    sheet.columns.forEach((column) => {
      column.protection = { locked: false }
    })

    const headerRow = sheet.getRow(1)
    headerRow.eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } }
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      }
      cell.alignment = { vertical: "middle", horizontal: "left" }
      cell.protection = { locked: true }
    })

    sheet.dataValidations.add("C2:C5000", {
      type: "list",
      allowBlank: false,
      formulae: ['"Yes,No"'],
      showErrorMessage: true,
    })

    await sheet.protect("12345", {
      selectLockedCells: true,
      selectUnlockedCells: true,
      insertRows: true,
      deleteRows: true,
      formatColumns: true,
      formatRows: true,
    })

    const buffer = await workbook.xlsx.writeBuffer()
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })

    saveAs(blob, "Competence_Bulk_Upload_Template.xlsx")
  }

  const handleBulkUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return

    const previewTab = window.open("/bulkupload/competence", "_blank")
    if (!previewTab) {
      // alert("Popup blocked! Please allow popups.")
      return
    }

    const reader = new FileReader()
    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result)
      const workbook = XLSX.read(data, { type: "array" })
      const sheetName = workbook.SheetNames[0]

      let rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" })

      rows = rows.filter((row) =>
        Object.values(row).some((v) => v !== "")
      )

      const finalRows = rows.map((row, index) => ({
        slNo: index + 1,
        type: row["Competence Type"] || "",
        name: row["Competence Name"] || "",
        di_required: row["Required for DI"] || "",
        hasError: !row["Competence Type"] || !row["Competence Name"] || !row["Required for DI"],
      }))

      previewTab.postMessage(
        {
          type: "COMPETENCE_PREVIEW",
          payload: { rows: finalRows },
        },
        "*"
      )
    }

    reader.readAsArrayBuffer(file)
  }

  // ✅ FIXED: Download now uses sortedData instead of displayedItems
  const handlePreviewAndDownload = async () => {
    if (!sortedData || sortedData.length === 0) {
      // alert("No data available to upload")
      return
    }

    const workbook = new ExcelJS.Workbook()
    const sheet = workbook.addWorksheet("Competence")

    sheet.columns = [
      { header: "Sl. No", key: "slNo", width: 10 },
      { header: "Competence Type", key: "type", width: 90 },
      { header: "Competence Name", key: "name", width: 60 },
      { header: "Required for DI", key: "di_required", width: 20 },
      { header: "Status", key: "status", width: 15 },
    ]

    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } }
      cell.alignment = { vertical: "middle", horizontal: "left" }
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      }
    })

    // ✅ FIXED: Use sortedData here
    sortedData.forEach((item, index) => {
      const row = sheet.addRow({
        slNo: index + 1,
        type: item.competencetype || "",
        name: item.competencename || "",
        di_required: item.di_required || "",
        status: item.status || (item.isActive ? "Active" : "Inactive"),
      })

      row.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" }
      })
    })

    const buffer = await workbook.xlsx.writeBuffer()
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })

    const file = new File([blob], "Competence.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })

    try {
      const response = await uploadTempFile(file)
      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer")
      } else {
        // console.warn("Upload succeeded but no file URL returned")
        // alert("Upload succeeded but no preview available.")
      }
    } catch (error) {
      // console.error("Upload failed:", error)
      // alert("Failed to upload file. Check console for details.")
    }
  }
useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
    // trigger the SAME logic as Save button
    document.getElementById("saveCompetenceBtn")?.click();
  },

  onCancel: () => {
    setIsAddUserOpen(false);
    setIsEditing(false);
   setFormData({ competencetype: "", competencename: "", di_required: "" })
                  setErrors({})
  },
});

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full transition-all duration-300 ease-in-out">
            {/* Heading */}
            <div className="flex items-center justify-between mb-2 flex-wrap gap-4">
              <h2 className="text-base font-medium font-VolvoNovum text-center text-darkblue1 flex items-center justify-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
                />
                PDP Data / Competence
              </h2>
            </div>

            {/* Controls: Search + Filters + Actions */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 md:gap-12 lg:gap-18 mb-2">
              <div className="flex flex-col sm:flex-row items-center gap-2 w-full sm:w-auto">
                {/* Search Input */}
                <div className="">
                  <Searchinput
                    onChange={(e) => {
                      setSearchQuery(e.target.value)
                    }}
                    value={searchQuery}
                    placeholder="Search"
                    className="w-[1/2]"
                    iconColor="text-black"
                    bgColor="bg-FrostWhite"
                    borderColor="border-black/60"
                    textColor="text-black"
                    shadow="shadow-none"
                    inputPadding="pl-6 pr-3 py-1.5"
                    iconSize="w-3 h-3"
                    iconLeft="left-3"
                    inputWidth="w-full"
                    focusRing="focus:ring-1 focus:ring-black/60"
                    hoverInputClasses="hover:bg-white hover:border-black/60"
                  />
                </div>

                <div className="ml-0 md:ml-5 lg:ml-0 xl:ml-0">
                  <Filter
                    name="competence type"
                    placeholder="Competence Type"
                    options={competenceOptions}
                    customWidth="w-[200px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    dropdownBorderColor="border-black/60"
                    textColor="text-black"
                    onChange={(name, value) => {
                      setSelectedCompetenceTypes(value)
                    }}
                    value={selectedCompetenceTypes}
                  />
                </div>

                <Filter
                  name="Required for DI"
                  placeholder="Required for DI"
                  options={["Yes", "No"]}
                  customWidth="w-[150px]"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  textColor="text-black"
                  onChange={(name, value) => {
                    setSelectedDIRequired(value)
                  }}
                  value={selectedDIRequired}
                />

                <Filter
                  name="status"
                  placeholder="Status"
                  options={statusOptions}
                  value={selectedStatus}
                  customWidth="w-[80px]"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black"
                  openBgColor="bg-white"
                  textColor="text-black"
                  onChange={(name, value) => {
                    setSelectedStatus(value)
                  }}
                />
              </div>

              {/* Right Side: Action Buttons */}
              <div className="flex justify-end items-center gap-2 w-full md:w-auto">
                {/* Add Dropdown */}
                <div className="relative w-full sm:w-[190px]" ref={dropdownRef}>
                  <button
                    onClick={() => setOpen(!open)}
                    className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-1.5 text-xs flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
                  >
                    <Plus className="w-3 h-3 stroke-[3]" />
                    Add New
                  </button>

                  {open && (
                    <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1 shadow-lg z-50">
                      <button
                        className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                        onClick={() => {
                          setIsAddUserOpen(true)
                          setOpen(false)
                        }}
                      ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
<g clip-path="url(#clip0_1415_1614)">
<path d="M9.67215 4.3242C9.90856 4.51669 10.1091 4.71886 10.2493 4.99172C10.3131 5.09261 10.347 5.14593 10.4601 5.18714C10.5644 5.19803 10.6637 5.19816 10.7685 5.19445C10.8063 5.19449 10.844 5.19458 10.883 5.19462C11.0036 5.19449 11.1239 5.19207 11.2444 5.18943C11.3646 5.18831 11.4847 5.18766 11.6049 5.18727C11.6795 5.18684 11.7541 5.18593 11.8287 5.18446C12.2772 5.17806 12.6354 5.27306 12.9678 5.58666C13.2781 5.92552 13.328 6.31185 13.3186 6.75583C13.3182 6.79453 13.3178 6.83323 13.3174 6.87311C13.3163 6.96751 13.3147 7.06186 13.3128 7.15622C13.3426 7.15847 13.3426 7.15847 13.3731 7.16072C14.0012 7.21438 14.5699 7.52863 14.9869 7.99631C15.4661 8.60552 15.5886 9.24387 15.5315 9.99998C15.4752 10.457 15.2438 10.8815 14.9378 11.2187C14.9144 11.2451 14.8909 11.2714 14.8667 11.2986C14.4514 11.7408 13.8686 12.0103 13.2621 12.0402C12.5606 12.0599 11.9035 11.8424 11.3848 11.3583C11.0164 10.9969 10.7881 10.5343 10.6878 10.0312C10.6772 9.97901 10.6772 9.97901 10.6663 9.92578C10.6072 9.23972 10.7581 8.56872 11.2037 8.02683C11.6247 7.53858 12.1533 7.26545 12.7816 7.15622C12.8228 7.15622 12.864 7.15622 12.9065 7.15622C12.904 7.0325 12.9005 6.90882 12.8968 6.78515C12.8961 6.75051 12.8954 6.71587 12.8946 6.68015C12.8838 6.34571 12.8383 6.08772 12.6021 5.84106C12.4211 5.68759 12.2018 5.62273 11.9677 5.61858C11.9364 5.61793 11.9051 5.61732 11.8729 5.61667C11.8394 5.61615 11.8058 5.61564 11.7713 5.61512C11.7368 5.61447 11.7023 5.61382 11.6667 5.61313C11.5566 5.61109 11.4464 5.60923 11.3362 5.60742C11.2615 5.60603 11.1868 5.60469 11.1121 5.60331C10.929 5.59998 10.7459 5.59678 10.5628 5.59375C10.5693 5.61723 10.5758 5.64076 10.5826 5.66498C10.5953 5.71133 10.5953 5.71133 10.6084 5.7586C10.621 5.80448 10.621 5.80448 10.634 5.85131C10.6862 6.05062 10.6943 6.24647 10.6956 6.45114C10.6966 6.48902 10.6966 6.48902 10.6975 6.52763C10.6989 6.73122 10.6646 6.90126 10.5447 7.06895C10.5275 7.08552 10.5102 7.10208 10.4925 7.11912C10.4756 7.13607 10.4587 7.15306 10.4412 7.17053C10.2097 7.33987 9.98182 7.32495 9.7045 7.32162C9.66601 7.32154 9.62757 7.32145 9.58791 7.32136C9.44478 7.32085 9.30164 7.31955 9.15851 7.31834C8.67799 7.31544 8.67799 7.31544 8.18778 7.3125C8.19812 8.41594 8.20841 9.51938 8.21905 10.6562C8.38402 10.6872 8.54904 10.7181 8.71903 10.75C8.8517 10.7977 8.96932 10.844 9.09403 10.9062C9.12443 10.9213 9.15487 10.9363 9.18618 10.9518C9.77931 11.2704 10.1774 11.8031 10.3741 12.4411C10.5476 13.1176 10.4359 13.7827 10.0951 14.3839C10.0222 14.5048 9.93624 14.6123 9.84404 14.7187C9.82424 14.7445 9.80439 14.7702 9.78398 14.7967C9.45049 15.1986 8.91384 15.4438 8.40655 15.5312C7.6469 15.5807 6.99881 15.4739 6.40655 14.9687C6.38169 14.95 6.35682 14.9314 6.33122 14.9121C5.88681 14.5367 5.60716 13.9338 5.55583 13.3595C5.53343 12.9825 5.56897 12.6393 5.6878 12.2812C5.70367 12.2324 5.70367 12.2324 5.71989 12.1825C5.94186 11.5829 6.42026 11.1373 6.98661 10.8632C7.24599 10.75 7.50225 10.6962 7.78156 10.6562C7.79185 9.5528 7.80218 8.44936 7.81278 7.3125C7.17611 7.31743 7.17611 7.31743 6.53948 7.32374C6.45935 7.32409 6.37922 7.32443 6.29913 7.32469C6.23725 7.32565 6.23725 7.32565 6.17416 7.32664C5.90817 7.32673 5.73087 7.30524 5.52396 7.1272C5.50713 7.10714 5.49031 7.08707 5.47293 7.0664C5.45563 7.04651 5.43829 7.02658 5.42047 7.00608C5.3086 6.83618 5.30173 6.66744 5.30303 6.47068C5.30307 6.44478 5.30316 6.41888 5.3032 6.3922C5.30761 6.11834 5.35098 5.85412 5.43777 5.59375C5.22156 5.59505 5.00534 5.5973 4.78908 5.60024C4.71565 5.60111 4.64223 5.60175 4.5688 5.60219C4.46272 5.60288 4.35669 5.60435 4.25065 5.60595C4.21825 5.60599 4.18585 5.60603 4.15246 5.60608C3.83917 5.61222 3.56386 5.68824 3.3333 5.90843C3.16725 6.10191 3.12436 6.31146 3.1154 6.56115C3.11409 6.59587 3.11278 6.63064 3.11143 6.66645C3.1102 6.70238 3.10898 6.73832 3.10771 6.77538C3.10569 6.83021 3.10569 6.83021 3.10362 6.88616C3.10031 6.9762 3.09712 7.06619 3.09404 7.15622C3.12359 7.15847 3.12359 7.15847 3.15375 7.16072C3.8122 7.21732 4.37542 7.53922 4.80754 8.03635C5.22994 8.58891 5.4078 9.24374 5.33048 9.93334C5.26674 10.3723 5.09265 10.7799 4.81278 11.125C4.79232 11.1509 4.77187 11.1768 4.75077 11.2035C4.36417 11.6641 3.78348 11.9616 3.18779 12.0312C2.49581 12.0725 1.8434 11.927 1.31084 11.4609C0.833914 11.0139 0.483298 10.4828 0.458541 9.81127C0.448911 9.11384 0.56697 8.54199 1.03154 7.99998C1.04548 7.98156 1.05941 7.96318 1.07378 7.9442C1.43192 7.48448 2.00736 7.26009 2.56279 7.15622C2.60404 7.15622 2.64529 7.15622 2.68779 7.15622C2.68681 7.1211 2.68681 7.1211 2.68581 7.08521C2.65941 5.99838 2.65941 5.99838 3.06169 5.55773C3.34143 5.28608 3.67415 5.18363 4.0568 5.18701C4.12809 5.18826 4.19938 5.18952 4.27068 5.19077C4.38904 5.19155 4.50739 5.19194 4.62575 5.19237C4.70744 5.19302 4.78908 5.19427 4.87077 5.19618C5.29113 5.22727 5.29113 5.22727 5.68521 5.1205C5.78424 5.02459 5.82917 4.90848 5.87531 4.78121C6.21667 4.27941 6.86134 3.92226 7.4472 3.80186C8.23751 3.67209 9.03643 3.82826 9.67215 4.3242ZM6.28153 4.93749C5.87267 5.41957 5.71016 5.95708 5.69939 6.57849C5.72525 6.72188 5.77343 6.77248 5.87531 6.87496C5.955 6.91483 6.01139 6.91051 6.10065 6.91103C6.15241 6.91146 6.15241 6.91146 6.20525 6.91185C6.24331 6.91198 6.28136 6.91211 6.32058 6.91224C6.3605 6.9125 6.40045 6.91276 6.44162 6.91302C6.57429 6.91384 6.70696 6.91432 6.83963 6.91479C6.88534 6.91496 6.931 6.91509 6.97667 6.91527C7.16668 6.91596 7.35669 6.91656 7.5467 6.91691C7.819 6.91739 8.09126 6.91842 8.36357 6.92024C8.55501 6.92145 8.74649 6.92206 8.93792 6.92219C9.05226 6.92232 9.16659 6.92271 9.28093 6.9237C9.40858 6.92482 9.53619 6.92469 9.66385 6.92448C9.70164 6.925 9.73944 6.92547 9.77836 6.92603C9.99405 6.92772 9.99405 6.92772 10.1795 6.83086C10.325 6.66463 10.296 6.46921 10.2869 6.25866C10.2395 5.62545 9.90726 5.07241 9.43228 4.66147C8.44893 3.90661 7.11769 4.05029 6.28153 4.93749ZM1.36869 8.22826C0.958879 8.70718 0.838714 9.24002 0.868682 9.85633C0.909153 10.3534 1.18757 10.8179 1.55949 11.1411C2.07189 11.5384 2.62508 11.692 3.26506 11.6113C3.82319 11.5028 4.28343 11.1643 4.61442 10.7104C4.90791 10.2594 5.00335 9.71246 4.90069 9.18748C4.77282 8.64945 4.48785 8.1944 4.02373 7.88474C3.13877 7.34792 2.09047 7.47587 1.36869 8.22826ZM11.4893 8.33533C11.175 8.74325 11.0143 9.26623 11.0628 9.78121C11.1515 10.3582 11.3985 10.8751 11.877 11.2263C12.3434 11.5493 12.872 11.6984 13.4396 11.6156C14.0144 11.5035 14.4785 11.196 14.8158 10.719C14.9048 10.5783 14.9734 10.437 15.0315 10.2812C15.0415 10.2569 15.0514 10.2326 15.0617 10.2075C15.2244 9.73654 15.1577 9.1685 14.9601 8.72167C14.6875 8.18091 14.2482 7.83384 13.6911 7.62182C12.8653 7.37464 12.0353 7.7013 11.4893 8.33533ZM6.45598 11.7523C6.05931 12.2351 5.9288 12.7653 5.96906 13.375C6.03198 13.8968 6.31353 14.3567 6.70925 14.6953C7.16564 15.0404 7.69537 15.1981 8.26398 15.1367C8.80573 15.0531 9.29671 14.7759 9.62921 14.3379C9.9755 13.8392 10.1183 13.2893 10.0121 12.6877C9.88383 12.1391 9.55877 11.7039 9.10367 11.3763C8.23414 10.8394 7.15336 11.0142 6.45598 11.7523Z" fill="black"/>
<path d="M13.0918 7.76352C13.1337 7.7624 13.1337 7.7624 13.1765 7.76123C13.3164 7.76158 13.3862 7.76685 13.5027 7.84971C13.5678 7.9451 13.5793 7.99362 13.584 8.10726C13.5995 8.21944 13.6101 8.26674 13.6926 8.34614C13.8447 8.44534 13.8447 8.44534 14.0201 8.45957C14.0972 8.43734 14.0972 8.43734 14.1836 8.40218C14.3097 8.36685 14.375 8.3637 14.5 8.40607C14.5768 8.492 14.6312 8.58722 14.6875 8.68733C14.707 8.71738 14.707 8.71738 14.7269 8.748C14.8042 8.86921 14.8297 8.9512 14.8125 9.0936C14.7532 9.17343 14.7532 9.17342 14.6758 9.24594C14.6504 9.27033 14.625 9.29477 14.5989 9.31989C14.5312 9.37485 14.5312 9.37485 14.4687 9.37485C14.4559 9.6347 14.4559 9.6347 14.5636 9.86151C14.634 9.92188 14.7065 9.97632 14.7813 10.0311C14.8266 10.1217 14.8225 10.1798 14.8125 10.2811C14.7756 10.367 14.7277 10.4444 14.6777 10.5233C14.6651 10.5443 14.6525 10.5653 14.6395 10.5869C14.579 10.685 14.5346 10.7476 14.4375 10.8123C14.3385 10.8044 14.247 10.7909 14.1529 10.7582C14.0037 10.7105 13.912 10.7133 13.7695 10.783C13.6675 10.8507 13.6308 10.8894 13.59 11.0059C13.567 11.1141 13.567 11.1141 13.556 11.2209C13.5312 11.3123 13.5312 11.3123 13.4684 11.3707C13.3413 11.4188 13.2285 11.4209 13.0937 11.4197C13.0689 11.4204 13.0441 11.421 13.0185 11.4216C12.8981 11.4216 12.8267 11.4138 12.7193 11.3553C12.6406 11.2626 12.6321 11.1996 12.6172 11.0799C12.5884 10.9319 12.5884 10.9319 12.5042 10.8113C12.378 10.7328 12.2828 10.7064 12.1367 10.7381C12.0909 10.7518 12.0453 10.7661 12 10.7811C11.8828 10.8104 11.8828 10.8104 11.7813 10.8123C11.5775 10.6747 11.4395 10.3963 11.373 10.1659C11.4136 10.0394 11.4611 10.0139 11.5644 9.93342C11.6637 9.8507 11.7122 9.80845 11.7424 9.68158C11.7392 9.52724 11.7265 9.41857 11.6216 9.30099C11.5466 9.2373 11.5466 9.2373 11.4667 9.18661C11.4063 9.12482 11.4063 9.12482 11.3901 9.02255C11.4086 8.88871 11.4556 8.7925 11.5254 8.67954C11.5365 8.66043 11.5477 8.64132 11.5591 8.62164C11.6724 8.43133 11.6724 8.43133 11.75 8.37485C11.8633 8.38069 11.9619 8.39422 12.0701 8.42795C12.212 8.4718 12.212 8.4718 12.3524 8.43781C12.4198 8.39561 12.4198 8.39561 12.4803 8.34873C12.5312 8.31232 12.5312 8.31232 12.5938 8.31232C12.5983 8.27051 12.5983 8.27051 12.603 8.22787C12.6077 8.19128 12.6124 8.1547 12.6172 8.11704C12.6215 8.08075 12.6259 8.04452 12.6304 8.00715C12.6959 7.7512 12.8616 7.76071 13.0918 7.76352ZM13.0313 8.18735C13.0238 8.22631 13.0238 8.22631 13.0162 8.26605C13.0089 8.30004 13.0016 8.33399 12.9941 8.36897C12.9838 8.41957 12.9838 8.41957 12.9733 8.47115C12.9287 8.58475 12.8895 8.60395 12.7813 8.65611C12.7279 8.68798 12.6745 8.71989 12.6211 8.7518C12.5946 8.76763 12.5681 8.78346 12.5408 8.79976C12.4847 8.83388 12.4296 8.86968 12.375 8.90609C12.3109 8.90644 12.3109 8.90644 12.2402 8.89632C12.2156 8.89295 12.1909 8.88953 12.1655 8.88607C11.9893 8.85848 11.9893 8.85848 11.9062 8.84357C11.8797 8.9 11.8797 8.9 11.875 8.96858C11.9262 9.02553 11.9262 9.02553 11.9961 9.07786C12.1063 9.18168 12.1446 9.24806 12.1582 9.39937C12.1589 9.46475 12.1582 9.53018 12.1563 9.59552C12.1572 9.62834 12.1582 9.66117 12.1592 9.69498C12.1578 9.83345 12.1558 9.93018 12.0671 10.0406C12.0054 10.0948 11.9439 10.1427 11.875 10.1873C11.8853 10.2389 11.8956 10.2904 11.9062 10.3436C11.9329 10.3368 11.9329 10.3368 11.9601 10.3299C12.2548 10.259 12.2548 10.259 12.4063 10.2811C12.4729 10.3226 12.5316 10.369 12.5919 10.4191C12.6569 10.4691 12.7182 10.5002 12.793 10.533C12.8747 10.5721 12.9008 10.5847 12.9492 10.6639C12.9557 10.6923 12.9621 10.7206 12.9688 10.7498C12.9804 10.7947 12.9922 10.8397 13.0039 10.8846C13.0129 10.9226 13.022 10.9607 13.0313 10.9998C13.0828 10.9998 13.1344 10.9998 13.1875 10.9998C13.1896 10.973 13.1916 10.9463 13.1937 10.9187C13.2344 10.6304 13.2344 10.6304 13.3735 10.5212C13.4766 10.4677 13.5811 10.4213 13.6875 10.3749C13.7103 10.3577 13.733 10.3406 13.7565 10.323C13.8463 10.2558 13.9219 10.272 14.0313 10.2811C14.1161 10.2984 14.1978 10.3201 14.2812 10.3436C14.3122 10.2817 14.3122 10.2817 14.3437 10.2186C14.3287 10.2072 14.3136 10.1959 14.2981 10.1841C14.2783 10.1685 14.2586 10.1528 14.2383 10.1365C14.2187 10.1213 14.1991 10.1061 14.179 10.0904C14.0432 9.94117 14.052 9.75068 14.0527 9.56037C14.0522 9.53572 14.0517 9.51103 14.0512 9.4856C14.0511 9.33909 14.0619 9.24378 14.1563 9.12482C14.2153 9.06666 14.2781 9.01965 14.3437 8.96858C14.3128 8.9067 14.3128 8.9067 14.2812 8.84357C14.2631 8.84811 14.245 8.8526 14.2263 8.85727C13.9339 8.92677 13.9339 8.92677 13.8125 8.90609C13.7481 8.86251 13.6894 8.81485 13.6299 8.76486C13.5551 8.71349 13.5006 8.70298 13.4121 8.68733C13.3413 8.66817 13.3413 8.66817 13.2812 8.62484C13.2276 8.48171 13.2049 8.33879 13.1875 8.18735C13.1359 8.18735 13.0844 8.18735 13.0313 8.18735Z" fill="black"/>
<path d="M3.55292 8.12016C3.81584 8.33573 3.97028 8.61218 4.00873 8.95C4.02187 9.27787 3.89322 9.55108 3.75812 9.84245C3.53608 10.2958 3.53608 10.2958 3.47284 10.7884C3.46694 10.9191 3.41612 11.0175 3.32831 11.1138C3.12462 11.2724 2.93926 11.2715 2.68769 11.2499C2.51886 11.1991 2.42785 11.0891 2.34394 10.9374C2.3099 10.8353 2.31045 10.7583 2.30866 10.6509C2.29018 10.3708 2.1841 10.1471 2.06464 9.89642C1.85937 9.45763 1.69146 9.07454 1.86151 8.58779C1.99891 8.2821 2.22858 8.10035 2.53143 7.96868C2.86466 7.8562 3.26892 7.92492 3.55292 8.12016ZM2.36542 8.56829C2.2399 8.72911 2.18786 8.88366 2.18744 9.08695C2.21794 9.32275 2.3395 9.53888 2.43964 9.75186C2.46061 9.79726 2.48155 9.84262 2.50244 9.88803C2.55329 9.99847 2.60487 10.1085 2.65644 10.2187C2.81112 10.2187 2.96581 10.2187 3.12519 10.2187C3.24122 9.9724 3.35583 9.72587 3.46503 9.47648C3.47434 9.45529 3.48365 9.43406 3.49324 9.41222C3.59226 9.18485 3.63884 9.00012 3.54706 8.76357C3.46041 8.58537 3.32129 8.45551 3.14325 8.36967C2.84925 8.2748 2.57499 8.3474 2.36542 8.56829ZM2.71894 10.6249C2.72754 10.7442 2.72754 10.7442 2.78144 10.8437C2.88951 10.8515 2.88951 10.8515 3.00019 10.8437C3.02081 10.823 3.04144 10.8024 3.06269 10.7812C3.06269 10.7296 3.06269 10.678 3.06269 10.6249C2.94925 10.6249 2.83581 10.6249 2.71894 10.6249Z" fill="black"/>
<path d="M8.79899 0.676074C9.11713 0.909406 9.3148 1.20826 9.40591 1.59343C9.45469 2.04673 9.38451 2.432 9.09953 2.79741C8.88072 3.04388 8.58014 3.23324 8.24967 3.28093C7.77832 3.30726 7.39968 3.23646 7.02507 2.92937C6.76288 2.68697 6.60621 2.37796 6.58148 2.02007C6.56332 1.55581 6.67428 1.19153 6.99372 0.844528C7.47908 0.383353 8.23744 0.317858 8.79899 0.676074ZM7.17547 1.26836C6.99908 1.52912 6.96492 1.7817 6.99968 2.09343C7.06498 2.37387 7.23117 2.58888 7.47039 2.74577C7.72522 2.89987 8.01992 2.92009 8.30753 2.8543C8.59216 2.75165 8.80604 2.5529 8.9372 2.28093C9.03536 2.03096 9.0428 1.74438 8.95281 1.48992C8.82485 1.21936 8.62866 1.03011 8.35614 0.907274C7.90637 0.769557 7.47078 0.898625 7.17547 1.26836Z" fill="black"/>
<path d="M9.34373 12.0939C9.41578 12.1566 9.43381 12.1968 9.44942 12.2904C9.43242 12.4111 9.36336 12.4714 9.27982 12.5535C9.26304 12.5706 9.24631 12.5877 9.22901 12.6053C9.17348 12.6617 9.1174 12.7174 9.06127 12.7732C9.02248 12.8122 8.98369 12.8512 8.9449 12.8902C8.86356 12.9719 8.78196 13.0534 8.7001 13.1346C8.59528 13.2387 8.49124 13.3436 8.38741 13.4487C8.30745 13.5294 8.22711 13.6097 8.14659 13.6899C8.10806 13.7284 8.06966 13.767 8.03143 13.8058C7.97785 13.86 7.92371 13.9136 7.86944 13.967C7.85374 13.9831 7.83805 13.9992 7.82187 14.0158C7.74239 14.0928 7.69742 14.1239 7.5862 14.1373C7.48808 14.1235 7.45508 14.1043 7.38464 14.0363C7.36349 14.0163 7.34235 13.9962 7.32055 13.9756C7.29725 13.9527 7.27398 13.9299 7.24998 13.9064C7.2233 13.8813 7.19658 13.8562 7.16907 13.8303C7.08112 13.7473 6.99459 13.6629 6.90819 13.5782C6.89318 13.564 6.87822 13.5497 6.86274 13.535C6.81859 13.4929 6.77504 13.4501 6.73154 13.4074C6.70581 13.3824 6.68008 13.3574 6.65357 13.3317C6.57906 13.2301 6.56739 13.1563 6.5625 13.0314C6.60938 12.9533 6.60938 12.9533 6.68747 12.9064C6.86745 12.9125 6.94749 12.956 7.07117 13.0842C7.0854 13.0988 7.09967 13.1133 7.11437 13.1283C7.15939 13.1743 7.20371 13.221 7.24804 13.2677C7.27861 13.2992 7.30922 13.3307 7.33988 13.3621C7.41452 13.439 7.48868 13.5162 7.5625 13.5939C7.67541 13.5463 7.74538 13.4799 7.83018 13.3923C7.85824 13.3635 7.88631 13.3348 7.91519 13.3051C7.93007 13.2898 7.94494 13.2744 7.96025 13.2586C8.00695 13.2103 8.05396 13.1623 8.10105 13.1144C8.23485 12.9782 8.36842 12.8418 8.50118 12.7046C8.58252 12.6206 8.66438 12.5371 8.74659 12.454C8.77776 12.4222 8.80873 12.3903 8.83947 12.3582C8.88254 12.3133 8.92635 12.269 8.9702 12.2249C8.99485 12.1995 9.01954 12.1741 9.04496 12.148C9.15022 12.0768 9.21919 12.08 9.34373 12.0939Z" fill="black"/>
<path d="M13.5241 8.95133C13.6815 9.0613 13.7851 9.19181 13.8438 9.37503C13.8691 9.62074 13.8776 9.86156 13.7188 10.0626C13.5476 10.252 13.3519 10.3443 13.0977 10.3594C12.8697 10.3513 12.6736 10.2511 12.5176 10.086C12.3637 9.88309 12.3224 9.67708 12.3553 9.42631C12.4096 9.19963 12.5609 9.03553 12.75 8.90627C13.0028 8.77991 13.2845 8.81689 13.5241 8.95133ZM12.8438 9.34381C12.7709 9.45062 12.75 9.51289 12.75 9.64262C12.7885 9.77486 12.826 9.82558 12.9376 9.90627C13.0231 9.93641 13.0972 9.94692 13.1875 9.93754C13.3062 9.87604 13.3635 9.82995 13.4375 9.71881C13.458 9.55851 13.458 9.55851 13.4047 9.41191C13.3492 9.34411 13.2977 9.28949 13.2188 9.25006C13.0638 9.23834 12.9653 9.24257 12.8438 9.34381Z" fill="black"/>
</g>
<defs>
<clipPath id="clip0_1415_1614">
<rect width="16" height="16" fill="white"/>
</clipPath>
</defs>
</svg>

                        Add Competence
                      </button>

                      <button
                        onClick={() => navigate("/bulkupload/competence")}
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1.5"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black" />
                        </svg>
                        Bulk Upload
                      </button>

                      <input
                        type="file"
                        ref={fileInputRef}
                        className="hidden"
                        accept=".xlsx,.xls"
                        onChange={handleBulkUpload}
                      />

                      <button
                        onClick={handleDownloadTemplate}
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 whitespace-nowrap"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

                        Bulk upload Template
                      </button>
                    </div>
                  )}
                </div>

                {/* Download Button */}
                <button
                  onClick={handlePreviewAndDownload}
                  className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1 flex items-center gap-2 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
                    <path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D" />
                  </svg>

                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" className="w-3 h-3 hidden group-hover:block">
                    <path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white" />
                  </svg>

                  <span className="font-semibold">Download</span>
                </button>
              </div>
            </div>

            {/* Error Display */}
            {apiError && (
              <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700">
                {apiError}
              </div>
            )}

            {/* TABLE */}
            <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
              <div
              ref={tableContainerRef}
                className="overflow-y-auto relative"
                style={{
                  scrollbarWidth: "none",
                  msOverflowStyle: "none",
                  maxHeight: sortedData.length > 8 ? "calc(100vh - 220px)" : "auto",
                }}
                onScroll={handleTableScroll}
              >
                <style jsx>{`
                  div::-webkit-scrollbar {
                    display: none;
                  }
                `}</style>

                <table className="w-full text-xs whitespace-nowrap cursor-pointer border-collapse">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                    <tr>
                      {/* Competence Type - w-[30%] */}
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[30%] cursor-pointer select-none"
                        onClick={() => handleSort("competencetype")}
                      >
                        <div className="flex items-center gap-1">
                          Competence Type
                          {sortKey !== "competencetype" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}


                          {sortKey === "competencetype" && sortOrder === "asc" && (
                            <ChevronUp className="w-3 h-3 text-white" />
                          )}
                          {sortKey === "competencetype" && sortOrder === "desc" && (
                            <ChevronDown className="w-3 h-3 text-white" />
                          )}
                        </div>
                      </th>

                      {/* Competence Name - w-[40%] - CHANGED FROM 45% */}
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%] cursor-pointer select-none"
                        onClick={() => handleSort("competencename")}
                      >
                        <div className="flex items-center gap-1">
                          Competence Name
                          {sortKey === "competencename" && sortOrder === "asc" && (
                            <ChevronUp className="w-3 h-3 text-white" />
                          )}
                          {sortKey === "competencename" && sortOrder === "desc" && (
                            <ChevronDown className="w-3 h-3 text-white" />
                          )}
                        </div>
                      </th>

                      {/* Required For DI - w-[12%] - CHANGED FROM 15% */}
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[12%] cursor-pointer select-none"
                        onClick={() => handleSort("di_required")}
                      >
                        <div className="flex items-center gap-1">
                          Required For DI
                          {sortKey === "di_required" && sortOrder === "asc" && (
                            <ChevronUp className="w-3 h-3 text-white" />
                          )}
                          {sortKey === "di_required" && sortOrder === "desc" && (
                            <ChevronDown className="w-3 h-3 text-white" />
                          )}
                        </div>
                      </th>

                      {/* Status - w-[8%] - NEW COLUMN */}
                      {/* <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%] cursor-pointer select-none"
                        onClick={() => handleSort("status")}
                      >
                        <div className="flex items-center gap-1">
                          Status
                          {sortKey === "status" && sortOrder === "asc" && (
                            <ChevronUp className="w-3 h-3 text-white" />
                          )}
                          {sortKey === "status" && sortOrder === "desc" && (
                            <ChevronDown className="w-3 h-3 text-white" />
                          )}
                        </div>
                      </th> */}

                      {/* Actions - w-[10%] */}
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 text-center font-medium w-[10%]">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-black">
                    {loading && tableData.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-2 py-8 text-center text-gray-500">
                          <div className="flex items-center justify-center gap-2">
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                            Loading competences...
                          </div>
                        </td>
                      </tr>
                    ) : sortedData.length > 0 ? (
                      sortedData.map((item, index) => (
                        <tr
                          key={item.id || index}
                          className={`hover:bg-lightBlue/50 text-xs ${
                            item.status === "Active" ? "text-black" : "text-gray-400"
                          }`}
                        >
                          {/* Competence Type */}
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[30rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.competencetype && item.competencetype.length > 40)
                                    setHoveredCell(item.id + "-competencetype")
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.competencetype || "-"}
                              </p>

                              {hoveredCell === item.id + "-competencetype" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-nowrap transform -translate-x-1/4 z-0">
                                  {item.competencetype}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Competence Name */}
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[40rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.competencename && item.competencename.length > 50)
                                    setHoveredCell(item.id + "-competencename")
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.competencename || "-"}
                              </p>

                              {hoveredCell === item.id + "-competencename" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-nowrap transform -translate-x-1/2 z-0">
                                  {item.competencename}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Required For DI */}
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs align-top text-center">
                            {item.di_required}
                          </td>

                          {/* Status - NEW CELL */}
                          {/* <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs align-top text-center">
                            <span
                              className={`inline-block px-2 py-0.5 rounded text-[10px] font-medium ${
                                item.status === "Active"
                                  ? "bg-green-100 text-green-700"
                                  : "bg-red-100 text-red-700"
                              }`}
                            >
                              {item.status}
                            </span>
                          </td> */}

                          {/* Actions */}
                          <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                            <div className="flex items-center justify-center gap-2">
                              {/* Edit */}
                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setFormData({
                                      competencetype: item.competencetype || "",
                                      competencename: item.competencename || "",
                                      di_required: item.di_required || "Yes",
                                    })
                                    setIsAddUserOpen(true)
                                    setIsEditing(true)
                                    const actualIndex = tableData.findIndex(
                                      (tableItem) => tableItem.id === item.id
                                    )
                                    setEditIndex(actualIndex)
                                  }}
                                >
                                  <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    width="16"
                                    height="16"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                  >
                                    <path
                                      d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z"
                                      fill="#66B3A6"
                                    />
                                    <path
                                      d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z"
                                      fill="#66B3A6"
                                    />
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 z-0">
                                  Edit
                                </span>
                              </div>

                              {/* Toggle Active/Deactivate */}
                              <div className="relative group">
                                <button
                                  onClick={() => {
                                    const actualIndex = tableData.findIndex(
                                      (tableItem) => tableItem.id === item.id
                                    )
                                    setSelectedRow(actualIndex)
                                    if (item.status === "Active") {
                                      setShowDeactivateModal(true)
                                    } else {
                                      setShowActivateModal(true)
                                    }
                                  }}
                                >
                                  {item.status === "Active" ? (
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      width="14"
                                      height="14"
                                      viewBox="0 0 21 23"
                                      fill="none"
                                    >
                                      <path
                                        d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337"
                                        stroke="#50A294"
                                        strokeWidth="2.66667"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                      />
                                    </svg>
                                  ) : (
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      width="16"
                                      height="16"
                                      viewBox="0 0 24 24"
                                      fill="none"
                                    >
                                      <g clipPath="url(#clip0_5669_3080)">
                                        <path
                                          d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22"
                                          stroke="#BF2012"
                                          strokeWidth="2.66667"
                                          strokeLinecap="round"
                                          strokeLinejoin="round"
                                        />
                                      </g>
                                      <defs>
                                        <clipPath id="clip0_5669_3080">
                                          <rect width="24" height="24" fill="white" />
                                        </clipPath>
                                      </defs>
                                    </svg>
                                  )}
                                </button>

                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                  {item.status === "Active" ? "Deactivate" : "Activate"}
                                </span>
                              </div>

                              {/* Delete */}
                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    const actualIndex = tableData.findIndex(
                                      (tableItem) => tableItem.id === item.id
                                    )
                                    setDeleteIndex(actualIndex)
                                    setIsDeleteModalOpen(true)
                                  }}
                                >
                                  <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    width="20"
                                    height="20"
                                    viewBox="0 0 32 32"
                                    fill="none"
                                  >
                                    <g clipPath="url(#clip0_6398_313)">
                                      <path
                                        d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z"
                                        fill="#BF2012"
                                      />
                                    </g>
                                    <defs>
                                      <clipPath id="clip0_6398_313">
                                        <rect
                                          width="24"
                                          height="24"
                                          fill="white"
                                          transform="translate(4 4)"
                                        />
                                      </clipPath>
                                    </defs>
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 z-0">
                                  Delete
                                </span>
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="px-2 py-6 text-center italic text-gray-500">
                          No data found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
                 {showScrollButtons && (
            <div className="fixed bottom-14 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ADD/EDIT MODAL */}
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
          <div className="bg-white p-6 w-full max-w-xl relative">
            <h2 className="text-base font-semibold text-center mb-4 text-MediumGrey">
              {isEditing ? "Competence" : "Add Competence"}
            </h2>
            <button
              onClick={() => {
                setIsAddUserOpen(false)
                setIsEditing(false)
                setFormData({ competencetype: "", competencename: "", di_required: "" })
                setErrors({})
                setApiError(null)
              }}
              className="absolute top-3 right-4 text-red-600 font-bold text-xl"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
                role="img"
                aria-label="Error icon"
              >
                <circle cx="10" cy="10" r="8" fill="#BF2012" />
                <path
                  d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>
            </button>

            {apiError && (
              <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700">
                {apiError}
              </div>
            )}

            <div className="grid grid-cols-1 gap-2">
              {/* Competence Type */}
              <div className="w-full relative">
                <label className="text-xs font-medium text-black/70">Competence Type <span className=" text-red1">*</span></label>

                {isEditing && tableData.length > 1 ? (
                  <>
                    <div className="relative w-full">
                      <input
                        type="text"
                        tabIndex={0}
                        maxLength={150}
                        value={formData.competencetype}
                        onChange={(e) => {
                           if (errors.competencetype) {
          setErrors({ ...errors, competencetype: "" });
        }
                          setFormData({ ...formData, competencetype: e.target.value })
                          setShowCompetenceTypeSuggestions(true)
                        }}
  onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setShowCompetenceTypeSuggestions(true)
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setShowCompetenceTypeSuggestions(false)
    }

  }}                        onClick={() =>setShowCompetenceTypeSuggestions(true)}
                        placeholder="Select or type Equipment Type"
                        className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all whitespace-normal
                          ${showCompetenceTypeSuggestions ? "d border-b-white" : ""}
                          ${errors.competencetype ? "border-red-600 focus:ring-red-600" : "border-black/30 focus:ring-black/30"}
                        `}
                        
                      />

                       <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowCompetenceTypeSuggestions((prev) => !prev)}
                        className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
                          showCompetenceTypeSuggestions  ? "rotate-180" : "rotate-0"
                        }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>

                    </div>

                   {showCompetenceTypeSuggestions && (
  <div
    ref={competenceRef}
    className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {/* Search input */}
    {Array.from(new Set([...competenceOptions, ...tableData.map(item => item.competencetype)])).length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5  z-10">
        <input
          type="text"
          placeholder="Search competence type..."
          value={competenceSearch}
          onChange={(e) => setCompetenceSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"

        />
      </div>
    )}

    {/* Options list */}
    {[...new Set([...competenceOptions, ...tableData.map(item => item.competencetype)])]
      .filter(Boolean)
      .filter(option =>
        competenceSearch ? option.toLowerCase().includes(competenceSearch.toLowerCase()) : true
      )
      .filter(option => option !== formData.competencetype)
      .sort((a, b) => a.localeCompare(b))
      .map((option, idx) => (
        <div
  tabIndex={0}
  data-option
  key={idx}
  className={`px-3 py-1.5 text-xs cursor-pointer transition
  ${
    option === formData.competencetype
      ? "bg-lightBlue/30 font-medium"
      : "hover:bg-gray-100"
  }`}

  onKeyDown={(e) => {

    e.stopPropagation()

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    )

    const index = items.indexOf(e.currentTarget)

    if (e.key === "ArrowDown") {
      e.preventDefault()
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus()
    }

    if (e.key === "ArrowUp") {
      e.preventDefault()
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus()
    }

    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setShowCompetenceTypeSuggestions(false)
      competenceRef.current?.querySelector("input")?.focus()
      return
    }

    if (e.key === "Enter") {
      e.preventDefault()
      saveAs.stopPropagation()
      setFormData({ ...formData, competencetype: option })
      setShowCompetenceTypeSuggestions(false)
      setCompetenceSearch("")
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault()
    setFormData({ ...formData, competencetype: option })
    setShowCompetenceTypeSuggestions(false)
    setCompetenceSearch("")
  }}
>
  {option}
</div>
      ))}

    {/* No results */}
    {[...new Set([...competenceOptions, ...tableData.map(item => item.competencetype)])]
      .filter(Boolean)
      .filter(option =>
        competenceSearch ? option.toLowerCase().includes(competenceSearch.toLowerCase()) : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic">
        No competence types found
      </div>
    )}
  </div>
)}

                  </>
                ) : (
                  <input
                    type="text"
                    value={formData.competencetype}
                    onChange={(e) =>{
                       if (errors.competencetype) {
          setErrors({ ...errors,competencetype: "" });
        }
                      setFormData({ ...formData, competencetype: e.target.value })}}
                    placeholder="Enter Competence Type"
                    className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                      errors.competencetype ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                    }`}
                  />
                )}

                {errors.competencetype && <p className="text-red1 text-xs mt-1">{errors.competencetype}</p>}
              </div>

              {/* Competence Name */}
 <div className="relative w-full">                <label className="text-xs font-medium text-black/70">Competence Name <span className=" text-red1">*</span></label>

                {isEditing && tableData.length > 1 ? (
                  <>
                    <div >
                      <input
                        type="text"
                        value={formData.competencename}
                        maxLength={100}
                        tabIndex={0}
                        onChange={(e) => {
                           if (errors.competencename) {
          setErrors({ ...errors, competencename: "" });
        }
                          setFormData({ ...formData, competencename: e.target.value })
                          setShowcompetencenamesuggestion(true)
                        }}
 onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setShowcompetencenamesuggestion(true)
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setShowcompetencenamesuggestion(false)
    }

  }}                        onClick={() =>setShowcompetencenamesuggestion(true)}
                        placeholder="Select or type Category"
                        className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
                          ${showcompetencenamesuggestion ? " border-b-white" : ""}
                          ${errors.competencename ? "border-red-600 focus:ring-red-600" : "border-black/30 focus:ring-black/30"}
                        `}
                      />

                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowcompetencenamesuggestion((prev) => !prev)}
                      className={`w-3 h-3 absolute right-3 top-10 cursor-pointer transform transition-transform duration-200 ${
                        showcompetencenamesuggestion ? "rotate-180" : "rotate-0"
                      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>
                    </div>

                   {showcompetencenamesuggestion && (
  <div
    ref={competenceNameRef}
    className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {/* Search input */}
    {Array.from(new Set(tableData.map(item => item.competencename))).length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5  z-10">
        <input
          type="text"
          placeholder="Search competence name..."
          value={competenceNameSearch}
          onChange={(e) => setCompetenceNameSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
       
        />
      </div>
    )}

    {/* Options list */}
    {Array.from(new Set(tableData.map(item => item.competencename)))
      .filter(Boolean)
      .filter(option =>
        competenceNameSearch
          ? option.toLowerCase().includes(competenceNameSearch.toLowerCase())
          : true
      )
      .filter(option => option !== formData.competencename)
      .sort((a, b) => a.localeCompare(b))
      .map((competencename, idx) => (
       <div
  key={idx}
  tabIndex={0}
  data-option
  className={`w-full px-3 py-1.5 text-xs cursor-pointer transition
  ${
    competencename === formData.competencename
      ? "bg-lightBlue/30 font-medium"
      : "hover:bg-gray-100"
  }`}

  onKeyDown={(e) => {

    e.stopPropagation()

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    )

    const index = items.indexOf(e.currentTarget)

    if (e.key === "ArrowDown") {
      e.preventDefault()
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus()
    }

    if (e.key === "ArrowUp") {
      e.preventDefault()
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus()
    }

    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setShowcompetencenamesuggestion(false)
      return
    }

    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setFormData({ ...formData, competencename })
      setShowcompetencenamesuggestion(false)
      setCompetenceNameSearch("")
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault()
    setFormData({ ...formData, competencename })
    setShowcompetencenamesuggestion(false)
    setCompetenceNameSearch("")
  }}
>
  {competencename}
</div>
      ))}

    {/* No results */}
    {Array.from(new Set(tableData.map(item => item.competencename)))
      .filter(option =>
        competenceNameSearch
          ? option.toLowerCase().includes(competenceNameSearch.toLowerCase())
          : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic">
        No competence names found
      </div>
    )}
  </div>
)}

                  </>
                ) : (
                  <input
                    type="text"
                    value={formData.competencename}
                    onChange={(e) => {
                      const value = e.target.value
                       if (errors.competencename) {
          setErrors({ ...errors,competencename: "" });
        }
                      setFormData({ ...formData, competencename: value })
                    }}
                    placeholder="Enter Competence Name"
                    className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                      errors.competencename ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                    }`}
                  />
                )}

                {errors.competencename && <p className="text-red1 text-xs mt-1">{errors.competencename}</p>}
              </div>

              {/* Is DI Required? */}
              <div className="w-full relative">
                <label className="text-xs font-medium text-black/70">Is DI Required? <span className=" text-red1">*</span></label>

                <div className="relative w-full">
                  <input
                    type="text"
                    value={formData.di_required || ""}
                    tabIndex={0}
                    onChange={(e) => {
                       if (errors.di_required) {
          setErrors({ ...errors, di_required: "" });
        }
                      setFormData({ ...formData, di_required: e.target.value })}}
  onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setShowDIRequiredDropdown(true)
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setShowDIRequiredDropdown(false)
    }

  }}                    onBlur={() => setTimeout(() => setShowDIRequiredDropdown(false), 100)}
                    placeholder="Select or type"
                    className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
                      ${showDIRequiredDropdown ? "border-b-white" : ""}
                      ${errors.di_required ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                    `}
                  />

                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowDIRequiredDropdown((prev) => !prev)}
      className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
        showDIRequiredDropdown ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>

                  {showDIRequiredDropdown && (
                    <div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto">
                      {["Yes", "No"]
                        .filter((option) => option !== formData.di_required)
                        .map((option, idx) => (
                         <div
  key={idx}
  tabIndex={0}
  data-di-option
  className={`px-3 py-1.5 text-xs cursor-pointer transition
  ${
    option === formData.di_required
      ? "bg-lightBlue/30 font-medium"
      : "hover:bg-gray-100"
  }`}

  onKeyDown={(e) => {

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-di-option]")
    )

    const index = items.indexOf(e.currentTarget)

    if (e.key === "ArrowDown") {
      e.preventDefault()
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus()
    }

    if (e.key === "ArrowUp") {
      e.preventDefault()
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus()
    }

    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setShowDIRequiredDropdown(false)
    }

    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setFormData({ ...formData, di_required: option })
      setShowDIRequiredDropdown(false)
    }

  }}

  onMouseDown={() => {
    setFormData({ ...formData, di_required: option })
    setShowDIRequiredDropdown(false)
  }}
>
  {option}
</div>
                        ))}
                    </div>
                  )}
                </div>

                {errors.di_required && <p className="text-red1 text-xs mt-1">{errors.di_required}</p>}
              </div>
            </div>

            {/* Save Button */}
            <button
            id="saveCompetenceBtn"
              onClick={async () => {
                const newErrors = {}

                if (!formData.competencetype) newErrors.competencetype = "Please enter this field"
                if (!formData.competencename) newErrors.competencename = "Please enter this field"
                if (!formData.di_required) newErrors.di_required = "Please enter this field"

                if (Object.keys(newErrors).length > 0) {
                  setErrors(newErrors)
                  return
                }

                try {
                  setLoading(true)
                  setApiError(null)

                  if (isEditing) {
                    const itemToUpdate = tableData[editIndex]
                    await updateCompetence(itemToUpdate.id, {
                      competence_type: formData.competencetype,
                      competence_name: formData.competencename,
                      di_required: formData.di_required === "Yes" ? true : false
                    })
                  } else {
                    await addCompetence({
                      competence_type: formData.competencetype,
                      competence_name: formData.competencename,
                      di_required: formData.di_required === "Yes" ? true : false
                    })
                    
                  }
                  resetSortAndFilter()

                  const data = await getCompetences()
                  const transformedData = data.map(item => ({
                    id: item.id,
                    year: item.year,
                    competencetype: item.competence_type,
                    competencename: item.competence_name,
                    di_required: item.di_required === 1 ? "Yes" : "No",
                    status: item.isActive === 1 ? "Active" : "Inactive",
                    createdOn: item.createdOn,
                    isActive: item.isActive === 1,
                    isDeleted: item.isDeleted || false
                  }))
                     
                  setTableData(transformedData)

                  setCompetenceOptions(prev => {
                    const newOptions = [...prev]
                    if (!newOptions.includes(formData.competencetype)) {
                      newOptions.push(formData.competencetype)
                      newOptions.sort()
                    }
                    return newOptions
                  })

                  setFormData({ competencetype: "", competencename: "", di_required: "" })
                  setErrors({})
                  setIsEditing(false)
                  setEditIndex(null)
                  setIsAddUserOpen(false)
                } catch (error) {
                  // console.error("Error saving competence:", error)
                  setApiError(error.message || "Failed to save competence")
                } finally {
                  setLoading(false)
                }
              }}
              disabled={loading}
              className="mt-6 bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "Saving..." : "Save"}
            </button>
          </div>
        </div>
      )}

      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={async () => {
          if (deleteIndex !== null) {
            try {
              setLoading(true)
              setApiError(null)

              const itemToDelete = tableData[deleteIndex]
              
              await deleteCompetence(itemToDelete.id)
  resetSortAndFilter()
              const data = await getCompetences()
              const transformedData = data.map(item => ({
                id: item.id,
                year: item.year,
                competencetype: item.competence_type,
                competencename: item.competence_name,
                di_required: item.di_required === 1 ? "Yes" : "No",
                status: item.isActive === 1 ? "Active" : "Inactive",
                createdOn: item.createdOn,
                isActive: item.isActive === 1,
                isDeleted: item.isDeleted || false
              }))

              setTableData(transformedData)
              setDeleteIndex(null)
              setIsDeleteModalOpen(false)
            } catch (error) {
              // console.error("Error deleting competence:", error)
              setApiError(error.message || "Failed to delete competence")
            } finally {
              setLoading(false)
            }
          }
        }}
      />

      {showActivateModal && selectedRow !== null && (
        <ActivateStatus
          isOpen={showActivateModal}
          onClose={() => setShowActivateModal(false)}
          onConfirm={async () => {
            try {
              setLoading(true)
              setApiError(null)

              const itemToToggle = tableData[selectedRow]
              await toggleCompetence(itemToToggle.id)

              const data = await getCompetences()
              const transformedData = data.map(item => ({
                id: item.id,
                year: item.year,
                competencetype: item.competence_type,
                competencename: item.competence_name,
                di_required: item.di_required === 1 ? "Yes" : "No",
                status: item.isActive === 1 ? "Active" : "Inactive",
                createdOn: item.createdOn,
                isActive: item.isActive === 1,
                isDeleted: item.isDeleted || false
              }))

              setTableData(transformedData)
              setShowActivateModal(false)
              setSelectedRow(null)
            } catch (error) {
              // console.error("Error toggling competence:", error)
              setApiError(error.message || "Failed to toggle competence")
            } finally {
              setLoading(false)
            }
          }}
        />
      )}

      {showDeactivateModal && selectedRow !== null && (
        <DeactivateStatus
          isOpen={showDeactivateModal}
          onClose={() => setShowDeactivateModal(false)}
          onConfirm={async () => {
            try {
              setLoading(true)
              setApiError(null)

              const itemToToggle = tableData[selectedRow]
              await toggleCompetence(itemToToggle.id)

              const data = await getCompetences()
              const transformedData = data.map(item => ({
                id: item.id,
                year: item.year,
                competencetype: item.competence_type,
                competencename: item.competence_name,
                di_required: item.di_required === 1 ? "Yes" : "No",
                status: item.isActive === 1 ? "Active" : "Inactive",
                createdOn: item.createdOn,
                isActive: item.isActive === 1,
                isDeleted: item.isDeleted || false
              }))

              setTableData(transformedData)
              setShowDeactivateModal(false)
              setSelectedRow(null)
            } catch (error) {
              // console.error("Error toggling competence:", error)
              setApiError(error.message || "Failed to toggle competence")
            } finally {
              setLoading(false)
            }
          }}
        />
      )}
    </div>
  )
}

export default Competence