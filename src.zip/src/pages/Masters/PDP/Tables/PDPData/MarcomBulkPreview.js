"use client"
import React, { useState, useEffect, useRef, useCallback } from "react"
import * as XLSX from "xlsx"
import Header from "../../../../../Components/Header"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react"
import { useNavigate } from "react-router-dom"
import { toast } from "react-toastify"

import {
  getAllMarcoms,
  bulkAddMarcom,
} from "../../../../../services/pdpMaster/marcom.service"

function BulkUploadMarcom() {
  const navigate = useNavigate()

  const [rows, setRows] = useState([])
  const [fileName, setFileName] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [isChecking, setIsChecking] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [duplicateInfo, setDuplicateInfo] = useState(null)
  const [isDataLoading, setIsDataLoading] = useState(true)
  const [isDragActive, setIsDragActive] = useState(false)

  // Master data states
  const [yearOptions, setYearOptions] = useState([])
  const [marcomTypeOptions, setMarcomTypeOptions] = useState([])
  const [existingMarcoms, setExistingMarcoms] = useState([])

  // Dropdown states
  const [activeDropdown, setActiveDropdown] = useState(null)
  const [dropdownPosition, setDropdownPosition] = useState({
    top: 0,
    left: 0,
    width: 0,
  })
  const [dropdownSearch, setDropdownSearch] = useState("")

  // Refs
  const dropdownButtonRefs = useRef({})
  const dropdownMenuRef = useRef(null)
  const tableContainerRef = useRef(null)

  // =============================== BACK ===============================
  const handleBack = () => {
    navigate("/master/pdp/marcom")
  }

  // =============================== LOAD MASTER DATA ===============================
  useEffect(() => {
    const loadMasterData = async () => {
      try {
        setIsDataLoading(true)
        const data = await getAllMarcoms()
        setExistingMarcoms(data || [])

        // Extract unique years for dropdown
        const years = Array.from(
          new Set((data || []).map((i) => i.year?.toString()).filter(Boolean))
        ).sort((a, b) => Number(b) - Number(a))
        setYearOptions(years)

        // Extract unique marcom types for dropdown
        const types = Array.from(
          new Set((data || []).map((i) => i.marcom_type).filter(Boolean))
        )
        setMarcomTypeOptions(types)
      } catch (err) {
        console.error("Error loading master data:", err)
        toast.error("Failed to load master data")
      } finally {
        setIsDataLoading(false)
      }
    }

    loadMasterData()
  }, [])

  // =============================== HELPER FUNCTIONS ===============================
  const normalize = (str) => (str || "").toString().trim().toLowerCase()

  // =============================== VALIDATE ROW ===============================
  const validateRow = (row) => {
    const errors = []

    // ✅ Year validation
    if (!row.year || !row.year.toString().trim()) {
      errors.push("Year required")
    } else if (!/^\d{4}$/.test(row.year.toString().trim())) {
      errors.push("Year must be 4 digits")
    }

    // ✅ Marcom Type validation
    if (!row.marcom_type || !row.marcom_type.trim()) {
      errors.push("Marcom Branding Type required")
    } else if (row.marcom_type.length > 100) {
      errors.push(`Type exceeds 100 characters (${row.marcom_type.length})`)
    }

    // ✅ Marcom Name validation
    if (!row.marcom_name || !row.marcom_name.trim()) {
      errors.push("Marcom Branding Element required")
    } else if (row.marcom_name.length > 100) {
      errors.push(`Name exceeds 100 characters (${row.marcom_name.length})`)
    }

    return {
      hasError: errors.length > 0,
      errors,
    }
  }

  // =============================== PARSE EXCEL FILE ===============================
  const parseExcelFile = (arrayBuffer) => {
    const data = new Uint8Array(arrayBuffer)
    const workbook = XLSX.read(data, { type: "array" })
    const sheetName = workbook.SheetNames[0]

    let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
      defval: "",
    })

    // ✅ Remove empty rows
    json = json.filter((row) =>
      Object.values(row).some((cell) => String(cell).trim() !== "")
    )

    // ✅ CHECK IF FILE IS EMPTY
    if (json.length === 0) {
      throw new Error("No valid data found in file")
    }

    // Clean column names
    const cleanedJson = json.map((row) => {
      const newRow = {}
      Object.keys(row).forEach((key) => {
        newRow[key.trim()] = row[key]
      })
      return newRow
    })

    console.log("Parsed Excel data:", cleanedJson)

    // ✅ ENHANCED VALIDATION WITH ALL CHECKS
    const finalRows = cleanedJson.map((row, index) => {
      const year = String(row["Year"] || "").trim()
      const marcom_type = String(
        row["Marcom Branding Type"] || row["Marcom Type"] || ""
      ).trim()
      const marcom_name = String(
        row["Marcom Branding Element"] || row["Marcom Name"] || ""
      ).trim()

      const rowData = {
        id: index + 1,
        year,
        marcom_type,
        marcom_name,
        isDuplicate: false,
        duplicateReason: "",
      }

      const validation = validateRow(rowData)
      return {
        ...rowData,
        hasError: validation.hasError,
        errors: validation.errors,
      }
    })

    return finalRows
  }

  // =============================== FILE UPLOAD WITH ENHANCED VALIDATION ===============================
  const handleBulkUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return

    // ✅ FILE TYPE VALIDATION
    const validExtensions = ['.xlsx', '.xls']
    const fileExtension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase()
    
    if (!validExtensions.includes(fileExtension)) {
      toast.error('❌ Invalid file format. Please upload .xlsx or .xls file only.')
      return
    }

    // ✅ FILE SIZE VALIDATION - Max 5MB
    if (file.size > 5 * 1024 * 1024) {
      toast.error('❌ File size exceeds 5MB limit.')
      return
    }

    if (marcomTypeOptions.length === 0) {
      toast.error("Master data not yet loaded. Please wait a moment and retry.")
      return
    }

    setFileName(file.name)
    setDuplicateInfo(null)

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result)
        setRows(finalRows)
        toast.success(`${finalRows.length} row(s) loaded successfully`)
      } catch (error) {
        console.error("Error parsing file:", error)
        toast.error('❌ Error reading file: ' + error.message)
      }
    }

    reader.onerror = () => {
      toast.error('❌ Error reading file. Please try again.')
    }

    reader.readAsArrayBuffer(file)
    e.target.value = ""
  }

  // =============================== DRAG AND DROP HANDLERS ===============================
  const handleDragOver = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragActive(true)
  }

  const handleDragLeave = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragActive(false)
  }

  const handleDrop = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragActive(false)

    const file = e.dataTransfer.files[0]
    if (!file) return

    // Validate file type
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error("Please drop an Excel file (.xlsx or .xls)")
      return
    }

    // Validate file size
    if (file.size > 5 * 1024 * 1024) {
      toast.error('❌ File size exceeds 5MB limit.')
      return
    }

    if (marcomTypeOptions.length === 0) {
      toast.error("Master data not yet loaded. Please wait a moment and retry.")
      return
    }

    setFileName(file.name)
    setDuplicateInfo(null)

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result)
        setRows(finalRows)
        toast.success(`${finalRows.length} row(s) loaded successfully`)
      } catch (error) {
        console.error("Error parsing file:", error)
        toast.error('❌ Error reading file: ' + error.message)
      }
    }

    reader.onerror = () => {
      toast.error('❌ Error reading file. Please try again.')
    }

    reader.readAsArrayBuffer(file)
  }

  // =============================== CHECK DUPLICATES ===============================
  const checkDuplicates = async () => {
    if (rows.length === 0) {
      toast.error("No data to check. Please upload a file first.")
      return
    }

    setIsChecking(true)
    setDuplicateInfo(null)

    try {
      // Create set of existing combinations
      const existingCombos = new Set()
      
      if (Array.isArray(existingMarcoms)) {
        existingMarcoms.forEach((item) => {
          // Check year + type + name combination
          if (item.year && item.marcom_type && item.marcom_name) {
            const combo = `${item.year}|${normalize(item.marcom_type)}|${normalize(item.marcom_name)}`
            existingCombos.add(combo)
          }
        })
      }

      const seenCombosInFile = new Set()

      const updatedRows = rows.map((row) => {
        const comboKey = `${row.year}|${normalize(row.marcom_type)}|${normalize(row.marcom_name)}`

        let isDuplicate = false
        let duplicateReason = ""

        if (row.year && row.marcom_name && row.marcom_type) {
          // Check against database (combination)
          if (existingCombos.has(comboKey)) {
            isDuplicate = true
            duplicateReason = "This combination already exists in database"
          }

          // Check for duplicates within the file (combination)
          if (seenCombosInFile.has(comboKey) && !isDuplicate) {
            isDuplicate = true
            duplicateReason = "Duplicate combination in uploaded file"
          }

          seenCombosInFile.add(comboKey)
        }

        return {
          ...row,
          isDuplicate,
          duplicateReason,
        }
      })

      setRows(updatedRows)

      const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length

      if (duplicateCount > 0) {
        setDuplicateInfo({
          count: duplicateCount,
          message: `${duplicateCount} duplicate(s) found! These will be skipped during save.`,
          type: "warning",
        })
        toast.warning(`${duplicateCount} duplicate record(s) found!`)
      } else {
        setDuplicateInfo({
          count: 0,
          message: "No duplicates found. All records are unique.",
          type: "success",
        })
        toast.success("No duplicates found!")
      }
    } catch (error) {
      console.error("Error checking duplicates:", error)
      toast.error("Failed to check duplicates")
    } finally {
      setIsChecking(false)
    }
  }

  // =============================== EDIT CELL ===============================
  const handleCellChange = (rowIdx, key, value) => {
    const updated = [...rows]
    updated[rowIdx][key] = value

    // Re-validate row
    const validation = validateRow(updated[rowIdx])
    updated[rowIdx].hasError = validation.hasError
    updated[rowIdx].errors = validation.errors

    // Reset duplicate flag
    updated[rowIdx].isDuplicate = false
    updated[rowIdx].duplicateReason = ""

    setRows(updated)
    setDuplicateInfo(null)
  }

  // =============================== CLOSE DROPDOWN ===============================
  const closeDropdown = useCallback(() => {
    setActiveDropdown(null)
    setDropdownSearch("")
  }, [])

  // =============================== OPEN DROPDOWN ===============================
  const handleOpenDropdown = (rowIndex, column) => {
    const dropdownKey = `${rowIndex}-${column}`

    if (activeDropdown === dropdownKey) {
      closeDropdown()
      return
    }

    const refKey = `${rowIndex}-${column}`
    const buttonEl = dropdownButtonRefs.current[refKey]
    if (buttonEl) {
      const rect = buttonEl.getBoundingClientRect()
      const viewportHeight = window.innerHeight
      const dropdownHeight = 220

      const spaceBelow = viewportHeight - rect.bottom
      const openUpward = spaceBelow < dropdownHeight && rect.top > dropdownHeight

      setDropdownPosition({
        top: openUpward ? rect.top - dropdownHeight : rect.bottom + 2,
        left: rect.left,
        width: Math.max(rect.width, 150),
      })
    }
    setActiveDropdown(dropdownKey)
    setDropdownSearch("")
  }

  // =============================== SELECT OPTION ===============================
  const handleSelectOption = (rowIdx, column, value) => {
    handleCellChange(rowIdx, column, value)
    closeDropdown()
  }

  // =============================== DELETE ROW ===============================
  const handleDeleteRow = (rowIdx) => {
    const updated = rows.filter((_, idx) => idx !== rowIdx)
    const reIndexed = updated.map((row, index) => ({ ...row, id: index + 1 }))
    setRows(reIndexed)
    setDuplicateInfo(null)
    closeDropdown()
  }

  // =============================== SAVE ===============================
  const handleSave = async () => {
    const hasError = rows.some((r) => r.hasError)

    if (hasError) {
      toast.error("Please fix all errors before saving. Check highlighted rows.")
      return
    }

    if (rows.length === 0) {
      toast.error("No data to save. Please upload a file first.")
      return
    }

    const rowsToSave = rows.filter((r) => !r.isDuplicate)

    if (rowsToSave.length === 0) {
      toast.error("All records are duplicates. Nothing to save.")
      return
    }

    setIsSaving(true)

    try {
      const payload = rowsToSave.map((r) => ({
        year: parseInt(r.year),
        marcom_type: r.marcom_type.trim(),
        marcom_name: r.marcom_name.trim(),
      }))

      console.log("Sending bulk upload payload:", payload)

      const response = await bulkAddMarcom(payload)

      if (response?.status) {
        const insertedCount = response.data?.inserted || payload.length
        const invalidCount = response.data?.invalid || 0

        if (invalidCount > 0) {
          toast.success(
            `${insertedCount} record(s) added successfully! ${invalidCount} invalid/duplicate(s) were skipped.`,
            { autoClose: 5000 }
          )
        } else {
          toast.success(`${insertedCount} record(s) added successfully!`)
        }

        setTimeout(() => {
          navigate("/master/pdp/marcom")
        }, 1500)
      } else {
        toast.error(response?.message || "Failed to upload data")
      }
    } catch (error) {
      console.error("Bulk upload error:", error)
      toast.error(error.message || "Failed to upload data")
    } finally {
      setIsSaving(false)
    }
  }

  // =============================== CLEAR ALL ===============================
  const handleClearAll = () => {
    setRows([])
    setFileName("")
    setDuplicateInfo(null)
    closeDropdown()
  }

  // =============================== CLOSE DROPDOWN ON OUTSIDE CLICK ===============================
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return
      }

      const clickedOnButton = Object.values(dropdownButtonRefs.current).some(
        (ref) => ref?.contains(e.target)
      )

      if (!clickedOnButton) {
        closeDropdown()
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [closeDropdown])

  // =============================== CLOSE DROPDOWN ON SCROLL ===============================
  useEffect(() => {
    const handleTableScroll = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return
      }
      if (activeDropdown !== null) {
        closeDropdown()
      }
    }

    const handleWindowScroll = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return
      }
      if (activeDropdown !== null) {
        closeDropdown()
      }
    }

    const tableContainer = tableContainerRef.current
    if (tableContainer) {
      tableContainer.addEventListener("scroll", handleTableScroll)
    }

    window.addEventListener("scroll", handleWindowScroll, true)

    return () => {
      if (tableContainer) {
        tableContainer.removeEventListener("scroll", handleTableScroll)
      }
      window.removeEventListener("scroll", handleWindowScroll, true)
    }
  }, [activeDropdown, closeDropdown])

  // =============================== GET DROPDOWN OPTIONS ===============================
  const getDropdownOptions = (column) => {
    if (column === "year") {
      // Generate years from 2015 to current year + 5
      const currentYear = new Date().getFullYear()
      const generatedYears = []
      for (let y = currentYear + 5; y >= 2015; y--) {
        generatedYears.push(y.toString())
      }

      // Merge with existing years from data
      const allYears = Array.from(new Set([...generatedYears, ...yearOptions])).sort(
        (a, b) => Number(b) - Number(a)
      )

      let options = allYears.map((year) => ({ id: year, label: year }))

      if (dropdownSearch) {
        options = options.filter((opt) =>
          opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
        )
      }

      return options
    }

    if (column === "marcom_type") {
      let options = marcomTypeOptions.map((type) => ({ id: type, label: type }))

      if (dropdownSearch) {
        options = options.filter((opt) =>
          opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
        )
      }

      return options
    }

    return []
  }

  // =============================== GET ACTIVE COLUMN ===============================
  const getActiveColumn = () => {
    if (!activeDropdown) return null
    return activeDropdown.split("-").slice(1).join("-")
  }

  const getActiveRowIndex = () => {
    if (!activeDropdown) return null
    return parseInt(activeDropdown.split("-")[0])
  }

  // =============================== RENDER DROPDOWN BUTTON ===============================
  const renderDropdownButton = (row, rowIndex, column) => {
    let isInvalid = false

    if (column === "year") {
      isInvalid = !row.year || !row.year.toString().trim() || !/^\d{4}$/.test(row.year.toString().trim())
    } else if (column === "marcom_type") {
      isInvalid = !row.marcom_type || !row.marcom_type.trim()
    }

    const dropdownKey = `${rowIndex}-${column}`
    const isOpen = activeDropdown === dropdownKey
    const refKey = `${rowIndex}-${column}`

    return (
      <div
        ref={(el) => (dropdownButtonRefs.current[refKey] = el)}
        className={`flex justify-between items-center px-2 py-1 border text-xs min-h-[26px] cursor-pointer ${
          isInvalid
            ? "border-red-500 bg-red-50"
            : row.isDuplicate
            ? "border-yellow-500 bg-yellow-50"
            : "border-gray-300 bg-white hover:border-gray-400"
        }`}
        onClick={() => handleOpenDropdown(rowIndex, column)}
      >
        <span
          className={`flex-1 truncate ${
            row[column] ? "text-gray-800" : "text-gray-400"
          }`}
        >
          {row[column] || (column === "year" ? "Select Year" : "Select Type")}
        </span>
        {isOpen ? (
          <ChevronUp className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1" />
        ) : (
          <ChevronDown className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1" />
        )}
      </div>
    )
  }

  // =============================== UI ===============================
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "lg:ml-60" : ""
        } flex-1 flex justify-center`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Back */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer hover:scale-110 text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">
              Marcom / Branding Bulk Upload
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[12%] ml-7 mb-2"></div>

          {/* Loading Indicator */}
          {isDataLoading && (
            <div className="mb-2 p-2 bg-blue-50 border border-blue-200 text-blue-600 text-xs flex items-center gap-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              Loading master data for validation...
            </div>
          )}

          {/* Upload Section */}
          <div className="mb-4 flex flex-wrap items-center gap-2 w-full">
            {/* Drag & Drop Area */}
            <div
              className={`flex-1 min-w-[200px] max-w-md flex items-center border-2 border-dashed px-3 py-1.5 text-xs transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-black/30 bg-white hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="mr-2 flex-shrink-0"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>
              <span className="text-xs text-gray-700 truncate">
                {isDragActive
                  ? "Drop file here..."
                  : fileName || "Drag & drop or click Browse"}
              </span>
              <input
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleBulkUpload}
                id="bulk-upload-input"
                disabled={isDataLoading}
              />
            </div>

            <label
              htmlFor="bulk-upload-input"
              className={`px-3 py-1.5 bg-darkblue1 text-white text-xs cursor-pointer hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition ${
                isDataLoading ? "opacity-50 cursor-not-allowed" : ""
              }`}
            >
              Browse
            </label>

            {rows.length > 0 && (
              <>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 bg-gray-500 text-white text-xs hover:bg-gray-600 transition"
                >
                  Clear
                </button>

                <button
                  onClick={checkDuplicates}
                  disabled={isChecking || rows.length === 0}
                  className="px-3 py-1.5 bg-yellow-600 text-white text-xs hover:bg-yellow-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  {isChecking && (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  )}
                  {isChecking ? "Checking..." : "Check Duplicates"}
                </button>
              </>
            )}

            <button
              onClick={handleSave}
              disabled={
                isSaving ||
                rows.length === 0 ||
                isDataLoading ||
                rows.some((r) => r.hasError)
              }
              className="px-4 py-1.5 bg-darkblue1 text-white text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              {isSaving && (
                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
              )}
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>

          {/* Duplicate Info Banner */}
          {duplicateInfo && (
            <div
              className={`mb-2 p-2 border text-xs flex items-center justify-between ${
                duplicateInfo.type === "warning"
                  ? "bg-yellow-50 border-yellow-300 text-yellow-700"
                  : "bg-green-50 border-green-300 text-green-700"
              }`}
            >
              <span>
                <span className="font-medium">
                  {duplicateInfo.type === "warning" ? "⚠️ " : "✅ "}
                </span>
                {duplicateInfo.message}
              </span>
              <button
                onClick={() => setDuplicateInfo(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
          )}

          {/* Error Summary */}
          {rows.length > 0 && rows.some((r) => r.hasError) && (
            <div className="mb-2 p-2 bg-red-50 border border-red-200 text-red-600 text-xs">
              <span className="font-medium">
                ⚠️ {rows.filter((r) => r.hasError).length} row(s) have validation errors.
              </span>
              <span className="ml-2">
                Please fix all mandatory fields (highlighted in red).
              </span>
            </div>
          )}

          {/* Table */}
          {rows.length > 0 ? (
            <div className="overflow-auto border border-Dustyblue mb-2 bg-white shadow-md">
              <div
                ref={tableContainerRef}
                className="overflow-y-auto max-h-[400px]"
              >
                <table className="w-full text-sm bg-white border-collapse">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-20">
                    <tr>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[5%]">
                        #
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[10%]">
                        Year <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[30%]">
                        Marcom Branding Type <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[30%]">
                        Marcom Branding Element <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-center w-[15%]">
                        Status
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium text-center w-[10%]">
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((row, i) => (
                      <tr
                        key={i}
                        className={`text-xs hover:bg-lightBlue/50 ${
                          row.hasError
                            ? "bg-red-50"
                            : row.isDuplicate
                            ? "bg-yellow-50"
                            : ""
                        }`}
                      >
                        {/* Row Number */}
                        <td className="px-2 py-1.5 border border-grey2 border-l-0 text-center text-gray-500">
                          {i + 1}
                        </td>

                        {/* Year - Custom Dropdown */}
                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "year")}
                        </td>

                        {/* Marcom Type - Custom Dropdown */}
                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "marcom_type")}
                        </td>

                        {/* Marcom Name - Text Input */}
                        <td className="px-2 py-1.5 border border-grey2">
                          <input
                            type="text"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.marcom_name || !row.marcom_name.trim()
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.marcom_name || ""}
                            placeholder="Enter Marcom Branding Element"
                            onChange={(e) =>
                              handleCellChange(i, "marcom_name", e.target.value)
                            }
                          />
                        </td>

                        {/* Status */}
                        <td className="px-2 py-1.5 border border-grey2 text-center">
                          {row.hasError ? (
                            <span
                              className="px-2 py-0.5 bg-red-100 text-red-600 text-[10px] rounded-full cursor-help"
                              title={row.errors?.join(", ")}
                            >
                              Invalid
                            </span>
                          ) : row.isDuplicate ? (
                            <span
                              className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full cursor-help"
                              title={row.duplicateReason}
                            >
                              Duplicate
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-green-100 text-green-600 text-[10px] rounded-full">
                              Valid
                            </span>
                          )}
                        </td>

                        {/* Delete Action */}
                        <td className="px-2 py-1.5 border border-grey2 border-r-0 text-center">
                          <button
                            onClick={() => handleDeleteRow(i)}
                            className="text-red-500 hover:text-red-700 transition"
                            title="Delete Row"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                              <g clipPath="url(#clip0_6398_313)">
                                <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                              </g>
                              <defs>
                                <clipPath id="clip0_6398_313">
                                  <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                                </clipPath>
                              </defs>
                            </svg>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Footer */}
              <div className="px-4 py-2 bg-gray-50 border-t border-grey2 flex flex-wrap justify-between items-center gap-2">
                <span className="text-xs text-gray-600">
                  Total: {rows.length} row(s) |
                  <span className="text-green-600 ml-1">
                    Valid:{" "}
                    {rows.filter((r) => !r.hasError && !r.isDuplicate).length}
                  </span>{" "}
                  |
                  <span className="text-yellow-600 ml-1">
                    Duplicates: {rows.filter((r) => r.isDuplicate).length}
                  </span>{" "}
                  |
                  <span className="text-red-600 ml-1">
                    Errors: {rows.filter((r) => r.hasError).length}
                  </span>
                </span>
                <span className="text-xs text-gray-500 italic">
                  💡 Click "Check Duplicates" before saving to identify existing records
                </span>
              </div>
            </div>
          ) : (
            /* Empty State - WITH DRAG AND DROP */
            <div
              className={`bg-white shadow-md border-2 border-dashed p-8 text-center transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-Dustyblue hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" className="w-12 h-12 mx-auto mb-3 opacity-50">
                <path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
              </svg>

              <p className="text-gray-500 text-sm">
                {isDragActive
                  ? "Drop your Excel file here!"
                  : "No data loaded. Please upload an Excel file to preview."}
              </p>
              <p className="text-gray-400 text-xs mt-1">
                {isDragActive
                  ? "Release to upload"
                  : "Supported formats: .xlsx, .xls (Drag & drop or click Browse)"}
              </p>
              <p className="text-gray-400 text-xs mt-1">
                Required columns: Year, Marcom Branding Type, Marcom Branding Element
              </p>
            </div>
          )}
        </div>
      </div>

      {/* ========== UNIVERSAL CUSTOM DROPDOWN ========== */}
      {activeDropdown !== null && rows[getActiveRowIndex()] && (
        <div
          ref={dropdownMenuRef}
          className="fixed border border-gray-300 bg-white z-[9999] shadow-xl rounded overflow-hidden"
          style={{
            top: `${dropdownPosition.top}px`,
            left: `${dropdownPosition.left}px`,
            width: `${dropdownPosition.width}px`,
            minWidth: "150px",
          }}
        >
          {/* Search Input */}
          <div className="p-2 border-b border-gray-200 bg-gray-50">
            <input
              type="text"
              placeholder={getActiveColumn() === "year" ? "Search year..." : "Search type..."}
              value={dropdownSearch}
              onChange={(e) => setDropdownSearch(e.target.value)}
              className="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:outline-none focus:border-darkblue1"
              autoFocus
            />
          </div>

          {/* Options List */}
          <div className="max-h-[150px] overflow-y-auto">
            {getDropdownOptions(getActiveColumn()).length > 0 ? (
              getDropdownOptions(getActiveColumn()).map((option) => {
                const currentValue = rows[getActiveRowIndex()][getActiveColumn()]
                const isSelected = currentValue === option.id

                return (
                  <div
                    key={option.id}
                    className={`flex items-center gap-2 px-3 py-1.5 cursor-pointer text-xs border-b border-gray-100 last:border-b-0 ${
                      isSelected ? "bg-blue-50" : "hover:bg-gray-50"
                    }`}
                    onClick={() =>
                      handleSelectOption(getActiveRowIndex(), getActiveColumn(), option.id)
                    }
                  >
                    <span
                      className={isSelected ? "text-blue-700 font-medium" : ""}
                    >
                      {option.label}
                    </span>
                    {isSelected && (
                      <span className="ml-auto text-blue-500">✓</span>
                    )}
                  </div>
                )
              })
            ) : (
              <div className="px-3 py-3 text-xs text-gray-400 text-center">
                No options found
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default BulkUploadMarcom