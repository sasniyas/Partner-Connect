import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import Filter from "../../../../../Components/Filter"
import DeleteModal from "../../../../../Components/DeleteModal"
import * as XLSX from "xlsx";
import ActivateStatus from "../../../../../Components/ActivateStatus"
import DeactivateStatus from "../../../../../Components/DeactivateStatus"
import { ChevronUp, ChevronDown } from "lucide-react";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { getMarketAreas } from "../../../../../services/pdpMaster/marketArea.service.js";
import { getDealers } from "../../../../../services/pdpMaster/dealership.service.js";
import { getAllCities, getAllDistricts } from "../../../../../services/pdpMaster/mainData.service.js";
import useCRUDWithReset from "../../../../../util/useCRUDWithReset"
import { 
  getBranchMasters, 
  addBranchMaster, 
  updateBranchMaster, 
  toggleBranchMaster, 
  deleteBranchMaster 
} from "../../../../../services/pdpMaster/branchMaster.service.js";
import { uploadTempFile } from "../../../../../services/download/bluckDownload.service.js"
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation.js"
function BranchMaster() {
  // ========== API DATA STATES ==========
  const [marketAreas, setMarketAreas] = useState([]);
  const [dealers, setDealers] = useState([]);
  const [cities, setCities] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const popupRef =useRef(null)
  const facilityTypes = [
    "Touch Point",
    "3S Facility",
    "2S Facility",
    "35 Facility",
    "25 Facility"
  ];

  const developmentStatusOptions = ["New", "In Progress", "Completed"];

  // ========== FILTER & UI STATES ==========
  const [selectedMarketAreas, setSelectedMarketAreas] = useState([]);
  const [selectedDealerships, setSelectedDealerships] = useState([]);
  const [selectedCities, setSelectedCities] = useState([]);
  const [selectedFacilityTypes, setSelectedFacilityTypes] = useState([]);
  const [selectedDevelopmentStatus, setSelectedDevelopmentStatus] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState([]);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [expandedRow, setExpandedRow] = useState(null);
  const [hoveredCell, setHoveredCell] = useState(null);

  // ========== SEARCH TERMS FOR MODAL DROPDOWNS ==========
  const [searchTerms, setSearchTerms] = useState({
    marketArea: "",
    dealership: "",
    city: "",
    district: "",
    facilityType: "",
    developmentStatus: ""
  });

  // ========== SORT & NAVIGATION ==========
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);

  // ========== FORM & MODAL STATES ==========
  const [tableData, setTableData] = useState([]);
  const [formData, setFormData] = useState({
    market_area_id: "",
    dealership_id: "",
    city_id: "",
    district_ids: [],
    branch_name: "",
    facility_type: "",
    development_status: ""
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  const [errors, setErrors] = useState({});
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteIndex, setDeleteIndex] = useState(null);
  const [selectedRow, setSelectedRow] = useState(null);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);

  const fileInputRef = useRef(null);
  const statusOptions = ["Active", "Inactive"];
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


  // ═══════════════════════════════════════════════════════
  // 🔗 DEPENDENT TABLE FILTER OPTIONS (Market Area → Dealership → City)
  // ═══════════════════════════════════════════════════════

  // Market Area filter options - all unique market areas from tableData (no dependency)
  const filterMarketAreaOptions = useMemo(() => {
    return [...new Set(tableData.map((i) => i.marketarea).filter(Boolean))].sort();
  }, [tableData]);

  // Dealership filter options - depends on selected market areas
  const filterDealershipOptions = useMemo(() => {
    let filtered = tableData;
    if (selectedMarketAreas.length > 0) {
      filtered = filtered.filter((item) => selectedMarketAreas.includes(item.marketarea));
    }
    return [...new Set(filtered.map((i) => i.dealer_name).filter(Boolean))].sort();
  }, [tableData, selectedMarketAreas]);

  // City filter options - depends on selected market areas + dealerships
  const filterCityOptions = useMemo(() => {
    let filtered = tableData;
    if (selectedMarketAreas.length > 0) {
      filtered = filtered.filter((item) => selectedMarketAreas.includes(item.marketarea));
    }
    if (selectedDealerships.length > 0) {
      filtered = filtered.filter((item) => selectedDealerships.includes(item.dealer_name));
    }
    return [...new Set(filtered.map((i) => i.cityName || i.city_name).filter(Boolean))].sort();
  }, [tableData, selectedMarketAreas, selectedDealerships]);

  // ═══════════════════════════════════════════════════════
  // 🔄 CASCADING FILTER CHANGE HANDLERS
  // ═══════════════════════════════════════════════════════

  // When Market Area changes → reset Dealership and City
  const handleMarketAreaFilterChange = (name, value) => {
    setSelectedMarketAreas(value);
    setSelectedDealerships([]);
    setSelectedCities([]);
  };

  // When Dealership changes → reset City
  const handleDealershipFilterChange = (name, value) => {
    setSelectedDealerships(value);
    setSelectedCities([]);
  };

  // City change - no child to reset
  const handleCityFilterChange = (name, value) => {
    setSelectedCities(value);
  };

  // ═══════════════════════════════════════════════════════
  // 🔗 DEPENDENT POPUP FORM DROPDOWN OPTIONS
  // ═══════════════════════════════════════════════════════

  const popupDealerOptions = useMemo(() => {
    if (!formData.market_area_id) return dealers;
    const dealerIdsForMarketArea = [
      ...new Set(
        tableData
          .filter((item) => item.market_area_id === formData.market_area_id)
          .map((item) => item.dealership_id)
          .filter(Boolean)
      ),
    ];
    const filtered = dealers.filter((d) => dealerIdsForMarketArea.includes(d.id));
    return filtered.length > 0 ? filtered : dealers;
  }, [dealers, formData.market_area_id, tableData]);

  const popupCityOptions = useMemo(() => {
    let filtered = tableData;
    if (formData.market_area_id) {
      filtered = filtered.filter((item) => item.market_area_id === formData.market_area_id);
    }
    if (formData.dealership_id) {
      filtered = filtered.filter((item) => item.dealership_id === formData.dealership_id);
    }
    const cityIdsFromData = [
      ...new Set(filtered.map((item) => item.city_id).filter(Boolean)),
    ];
    const filteredCities = cities.filter((c) => cityIdsFromData.includes(c.id));
    return filteredCities.length > 0 ? filteredCities : cities;
  }, [cities, formData.market_area_id, formData.dealership_id, tableData]);

  // ========== API LOADING FUNCTIONS ==========
  const loadMarketAreas = async () => {
    try {
      setLoading(true);
      const data = await getMarketAreas();
      setMarketAreas(data || []);
    } catch (error) {
      // console.error("Error loading market areas:", error);
      setError("Failed to load market areas");
    } finally {
      setLoading(false);
    }
  };

  const loadDealers = async () => {
    try {
      setLoading(true);
      const data = await getDealers();
      setDealers(data || []);
    } catch (error) {
      // console.error("Error loading dealers:", error);
      setError("Failed to load dealers");
    } finally {
      setLoading(false);
    }
  };

  const loadCities = async () => {
    try {
      setLoading(true);
      const data = await getAllCities();
      setCities(data || []);
    } catch (error) {
      // console.error("Error loading cities:", error);
      setError("Failed to load cities");
    } finally {
      setLoading(false);
    }
  };

  const loadDistricts = async () => {
    try {
      setLoading(true);
      const data = await getAllDistricts();
      setDistricts(data || []);
    } catch (error) {
      // console.error("Error loading districts:", error);
      setError("Failed to load districts");
    } finally {
      setLoading(false);
    }
  };

  const loadBranchMasters = async () => {
    try {
      setLoading(true);
      const data = await getBranchMasters();
      setTableData(data || []);
    } catch (error) {
      // console.error("Error loading branch masters:", error);
      setError("Failed to load branch masters");
    } finally {
      setLoading(false);
    }
  };

  // ========== UTILITY FUNCTIONS ==========
  const toggleDropdown = (name) => {
    setActiveDropdown((prev) => (prev === name ? null : name));
  };

  const toggleExpand = (id) => {
    setExpandedRow(expandedRow === id ? null : id);
  };

  const getFilteredDistrictsByCity = (cityId) => {
    if (!cityId) return [];
    const selectedCity = cities.find(c => c.id === cityId);
    if (!selectedCity?.state_name) return [];
    return districts.filter(d => d.state_name === selectedCity.state_name);
  };

  // ========== SEARCH HANDLER ==========
  const handleSearchChange = (field, value) => {
    setSearchTerms(prev => ({ ...prev, [field]: value }));
  };

  // ========== FILTER OPTIONS FUNCTION ==========
  const filterOptions = (options, searchTerm, labelKey = "name") => {
    if (!searchTerm) return options;
    return options.filter(option => {
      const label = option[labelKey] || option;
      return label.toString().toLowerCase().includes(searchTerm.toLowerCase());
    });
  };

  // ========== FILTERED DATA ==========
  const filteredData = useMemo(() => {
    return tableData?.filter((item) => {
      const matchesMarketArea =
        selectedMarketAreas.length > 0
          ? selectedMarketAreas.includes(item.marketarea)
          : true;

      const matchesDealership =
        selectedDealerships.length > 0
          ? selectedDealerships.includes(item.dealer_name)
          : true;

      const matchesCity =
        selectedCities.length > 0
          ? selectedCities.includes(item.city_name)
          : true;

      const matchesFacilityType =
        selectedFacilityTypes.length > 0
          ? selectedFacilityTypes.includes(item.facility_type)
          : true;

      const matchesDevelopmentStatus =
        selectedDevelopmentStatus.length > 0
          ? selectedDevelopmentStatus.includes(item.development_status)
          : true;

      const matchesStatus =
        selectedStatus.length > 0
          ? selectedStatus.includes(item.isActive === 1 ? "Active" : "Inactive")
          : true;
      
      const districtNames = Array.isArray(item.districts)
        ? item.districts.map((d) => d.district_name.toLowerCase())
        : [];

      const matchesSearch =
        Object.values(item).some((val) =>
          val?.toString().toLowerCase().includes(searchQuery.toLowerCase())
        ) ||
        districtNames.some((district) =>
          district.includes(searchQuery.toLowerCase())
        );

      return (
        matchesMarketArea &&
        matchesDealership &&
        matchesCity &&
        matchesFacilityType &&
        matchesDevelopmentStatus &&
        matchesSearch &&
        matchesStatus
      );
    }) || [];
  }, [
    tableData,
    selectedMarketAreas,
    selectedDealerships,
    selectedCities,
    selectedFacilityTypes,
    selectedDevelopmentStatus,
    searchQuery,
    selectedStatus
  ]);

  // ========== SORT HANDLER ==========
  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc");
        return;
      }
      if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
        return;
      }
    }
    setSortKey(key);
    setSortOrder("asc");
  };

  // ========== SORTED DATA ==========
  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredData;

    return [...filteredData].sort((a, b) => {
      const aVal = (a[sortKey] ?? "").toString().toLowerCase();
      const bVal = (b[sortKey] ?? "").toString().toLowerCase();

      return sortOrder === "asc"
        ? aVal.localeCompare(bVal, undefined, { numeric: true, sensitivity: "base" })
        : bVal.localeCompare(aVal, undefined, { numeric: true, sensitivity: "base" });
    });
  }, [filteredData, sortKey, sortOrder]);
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchQuery: { setter: setSearchQuery, resetValue: "" },
    selectedMarketAreas :{setter :setSelectedMarketAreas ,resetValue:[]},
    selectedDealerships:{setter:setSelectedDealerships , resetValue :[]},
    selectedCities :{setter :setSelectedCities ,resetValue :[]},
    selectedFacilityTypes:{setter :setSelectedFacilityTypes ,resetValue :[]},
    selectedDevelopmentStatus:{setter :setSelectedDevelopmentStatus ,resetValue:[]},
    selectedStatus:{setter:setSelectedStatus,resetValue:[]}
    

  }
);
useEffect(() => {
  if (isAddUserOpen && popupRef.current) {
    popupRef.current.focus();
  }
}, [isAddUserOpen]);
  // ========== LIFECYCLE ==========
  useEffect(() => {
    const loadAllData = async () => {
      await Promise.all([
        loadMarketAreas(),
        loadDealers(),
        loadCities(),
        loadDistricts(),
        loadBranchMasters()
      ]);
    };
    loadAllData();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

 useEffect(() => {
  const handleClickOutside = (e) => {
    const dropdown = e.target.closest(".dropdown-wrapper");
    const popup = popupRef.current;

    // ✅ if click inside dropdown → do nothing
    if (dropdown) return;

    // ✅ if click inside popup (including scroll area) → do nothing
    if (popup && popup.contains(e.target)) return;

    // ❌ only close when clicking truly outside
    setActiveDropdown(null);

    setSearchTerms({
      marketArea: "",
      dealership: "",
      city: "",
      district: "",
      facilityType: "",
      developmentStatus: ""
    });
  };

  document.addEventListener("mousedown", handleClickOutside);

  return () => {
    document.removeEventListener("mousedown", handleClickOutside);
  };
}, []);
  // ========== DOWNLOAD TEMPLATE ==========
  const handleDownloadTemplate = async () => {
    if (
      !marketAreas.length ||
      !dealers.length ||
      !cities.length ||
      !districts.length
    ) {
      // alert("Please load all master data first.");
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Branch Master");

    sheet.columns = [
      { header: "Market Area", key: "market_area", width: 25 },
      { header: "Dealership", key: "dealer_name", width: 35 },
      { header: "City", key: "city_name", width: 25 },
      { header: "Districts Covered", key: "districts", width: 40 },
      { header: "Branch Name", key: "branch_name", width: 30 },
      { header: "Facility Type", key: "facility_type", width: 20 },
      { header: "Development Status", key: "development_status", width: 20 },
    ];

    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });

    sheet.addRow({
      market_area: "North",
      dealer_name: "Navin Infrasolutions Pvt.Ltd.",
      city_name: "Gwalior",
      districts: "Kankarbagh,Udupi",
      branch_name: "Patna Branch",
      facility_type: "3S Facility",
      development_status: "New",
    });

    const listSheet = workbook.addWorksheet("Lists", { state: "hidden" });
    listSheet.getColumn("A").values = marketAreas.map((m) => m.marketarea);
    listSheet.getColumn("B").values = dealers.map((dealer) => dealer.dealerName);
    listSheet.getColumn("C").values = cities.map((c) => c.city_name);
    listSheet.getColumn("D").values = districts.map((d) => d.district_name);
    listSheet.getColumn("E").values = facilityTypes;
    listSheet.getColumn("F").values = developmentStatusOptions;

    const applyStrictDropdown = (columnLetter, formula) => {
      for (let row = 2; row <= 1000; row++) {
        sheet.getCell(`${columnLetter}${row}`).dataValidation = {
          type: "list",
          allowBlank: false,
          formulae: [formula],
          showErrorMessage: true,
          errorTitle: "Invalid Selection",
          error: "Please select a value from dropdown",
        };
      }
    };

    applyStrictDropdown("A", `=Lists!$A$1:$A$${marketAreas.length}`);
    applyStrictDropdown("B", `=Lists!$B$1:$B$${dealers.length}`);
    applyStrictDropdown("C", `=Lists!$C$1:$C$${cities.length}`);
    applyStrictDropdown("F", `=Lists!$E$1:$E$${facilityTypes.length}`);
    applyStrictDropdown("G", `=Lists!$F$1:$F$${developmentStatusOptions.length}`);

    for (let row = 2; row <= 1000; row++) {
      sheet.getCell(`D${row}`).dataValidation = {
        type: "list",
        allowBlank: true,
        formulae: [`=Lists!$D$1:$D$${districts.length}`],
        showErrorMessage: false,
        showInputMessage: true,
        promptTitle: "Districts",
        prompt: "Select from dropdown OR type multiple districts separated by comma (e.g., District1,District2,District3)",
      };
    }

    const instructionSheet = workbook.addWorksheet("Instructions");
    instructionSheet.columns = [{ header: "Instructions", width: 80 }];
    
    instructionSheet.addRow(["How to fill Branch Master Template:"]);
    instructionSheet.addRow([""]);
    instructionSheet.addRow(["1. Market Area - Select from dropdown (required)"]);
    instructionSheet.addRow(["2. Dealership - Select from dropdown (required)"]);
    instructionSheet.addRow(["3. City - Select from dropdown (required)"]);
    instructionSheet.addRow(["4. Districts - Select one from dropdown, then ADD more by typing comma-separated values"]);
    instructionSheet.addRow(["   Example: Kankarbagh,Udupi,Patna (no spaces after comma)"]);
    instructionSheet.addRow(["5. Branch Name - Type the branch name (required)"]);
    instructionSheet.addRow(["6. Facility Type - Select from dropdown (required)"]);
    instructionSheet.addRow(["7. Development Status - Select from dropdown (required)"]);
    instructionSheet.addRow([""]);
    instructionSheet.addRow(["Note: Districts column allows multiple values separated by comma."]);

    instructionSheet.getRow(1).font = { bold: true, size: 14 };

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(
      new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }),
      "BranchMaster_Bulk_Upload_Template.xlsx"
    );
  };

  // ========== PREVIEW & DOWNLOAD ==========
  const handlePreviewAndDownload = async () => {
    if (!sortedData || sortedData.length === 0) {
      // alert("No data available to preview");
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Branch Master");

    sheet.columns = [
      { header: "Sl No", key: "slNo", width: 10 },
      { header: "Market Area", key: "market_area", width: 25 },
      { header: "Dealership", key: "dealer_name", width: 35 },
      { header: "City", key: "city_name", width: 25 },
      { header: "Districts Covered", key: "districts", width: 40 },
      { header: "Branch Name", key: "branch_name", width: 30 },
      { header: "Facility Type", key: "facility_type", width: 20 },
      { header: "Dev Status", key: "development_status", width: 15 },
      { header: "Status", key: "status", width: 15 },
    ];

    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.alignment = { vertical: "middle", horizontal: "left" };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
    });

    sortedData.forEach((item, index) => {
      sheet.addRow({
        slNo: index + 1,
        market_area: item.marketarea || "",
        dealer_name: item.dealer_name || "",
        city_name: item.city_name || "",
        districts: Array.isArray(item.districts)
          ? item.districts.map(d => d.district_name).join(",")
          : "",
        branch_name: item.branch_name || "",
        facility_type: item.facility_type || "",
        development_status: item.development_status || "",
        status: item.isActive ? "Active" : "Inactive",
      }).eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const file = new File([blob], "BranchMaster.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    try {
      const response = await uploadTempFile(file);
      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        // console.warn("Upload succeeded but no file URL returned");
        // alert("Upload succeeded but preview URL not available");
      }
    } catch (error) {
      // console.error("Upload failed:", error);
      // alert("Failed to upload file. Check console for details.");
    }
  };
useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
    document.getElementById("saveBranchBtn")?.click();
  },

onCancel: () => {
  setIsAddUserOpen(false)
  setFormData({
    market_area_id: "",
    dealership_id: "",
    city_id: "",
    district_ids: [],
    branch_name: "",
    facility_type: "",
    development_status: "",
  })
  setErrors({})
  setIsEditing(false)
  setEditIndex(null)
  setSearchTerms({
    marketArea: "",
    dealership: "",
    city: "",
    district: "",
    facilityType: "",
    developmentStatus: "",
  })
}

});

  // ========== DROPDOWN ARROW SVG COMPONENT ==========
  const DropdownArrowSvg = ({ isOpen, className = "" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`w-3 h-3 cursor-pointer transform transition-transform ${isOpen ? "rotate-180" : ""} ${className}`}>
      <path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
    </svg>
  );


  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300  ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full  transition-all duration-300 ease-in-out">
            {/* HEADING */}
            <div className="flex items-center justify-between mb-2 flex-wrap gap-4">
              <h2 className="text-base font-medium font-VolvoNovum text-darkblue1 flex items-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1  p-1"
                />
                PDP Data / Branch Master
              </h2>

              {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3  mb-4">
                  {error}
                  <button
                    onClick={() => setError(null)}
                    className="float-right font-bold text-red-700"
                  >
                    ×
                  </button>
                </div>
              )}
            </div>

            {/* CONTROLS: Search + Filters + Actions */}
            <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto mb-2">
              <div className="">
                <Searchinput
                  onChange={(e) => setSearchQuery(e.target.value)}
                  value={searchQuery}
                  placeholder="Search"
                  className="w-[1/2]"
                  iconColor="text-black"
                  bgColor="bg-FrostWhite"
                  borderColor="border-black/60"
                  textColor="text-black"
                  shadow="shadow-none"
                  inputPadding="pl-6 pr-3 py-1.5"
                  iconSize="w-3 h-3"
                  iconLeft="left-3"
                  inputWidth="w-full"
                  focusRing="focus:ring-1 focus:ring-black/60"
                  hoverInputClasses="hover:bg-white hover:border-black/60"
                />
              </div>

              <Filter
                name="marketarea"
                placeholder="Market Area"
                options={filterMarketAreaOptions}
                value={selectedMarketAreas}
                onChange={handleMarketAreaFilterChange}
                customWidth="w-[120px]"
                textColor="text-black"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
              />

              <Filter
                name="dealership"
                placeholder="Dealership"
                options={filterDealershipOptions}
                value={selectedDealerships}
                onChange={handleDealershipFilterChange}
                customWidth="w-[180px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                textColor="text-black"
              />

              <Filter
                name="city"
                placeholder="City"
                options={filterCityOptions}
                value={selectedCities}
                onChange={handleCityFilterChange}
                customWidth="w-[120px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                textColor="text-black"
              />

              <Filter
                name="facilitytype"
                placeholder="Facility Type"
                options={facilityTypes}
                value={selectedFacilityTypes}
                onChange={(name, value) => setSelectedFacilityTypes(value)}
                customWidth="w-[150px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                textColor="text-black"
              />
              {/* Development Status Filter */}
              
                <Filter
                  name="developmentstatus"
                  placeholder="Dev Status"
                  options={developmentStatusOptions}
                  value={selectedDevelopmentStatus}
                  onChange={(name, value) => setSelectedDevelopmentStatus(value)}
                  customWidth="w-full"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/50"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-blue-100"
                  dropdownBorderColor="border-black/50"
                  textColor="text-black"
                />
              

             <Filter
                  name="status"
                  placeholder="Status"
                  options={statusOptions}
                  value={selectedStatus}
                  customWidth="w-full"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/50"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-blue-100"
                  dropdownBorderColor="border-black/50"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black"
                  openBgColor="bg-white"
                  textColor="text-black"
                  onChange={(name, value) => setSelectedStatus(value)}
                />


              <div className="flex justify-end items-center gap-2 w-full md:w-auto">
                <div className="relative w-[190px]" ref={dropdownRef}>
                  <button
                    onClick={() => setOpen(!open)}
                    className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-1.5 text-xs  flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
                  >
                    <Plus className="w-3 h-3 stroke-[3]" />
                    Add New
                  </button>

                  {open && (
                    <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1  shadow-lg z-50">
                      <button
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                        onClick={() => {
                          setIsAddUserOpen(true);
                          setOpen(false);
                        }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                          <path d="M14.0001 1.50009C13.6908 1.50064 13.3893 1.59712 13.1371 1.77622C12.8849 1.95532 12.6945 2.20823 12.5921 2.50009H10.9291C10.8203 2.07097 10.5716 1.69037 10.2222 1.4185C9.87283 1.14663 9.44278 0.999023 9.00009 0.999023C8.5574 0.999023 8.12735 1.14663 7.77797 1.4185C7.4286 1.69037 7.17985 2.07097 7.07109 2.50009H4.92909C4.84165 2.15889 4.66549 1.8469 4.41848 1.59581C4.17148 1.34471 3.86242 1.16345 3.52271 1.07043C3.18299 0.977407 2.8247 0.975936 2.48423 1.06617C2.14377 1.1564 1.83324 1.33512 1.58418 1.58418C1.33512 1.83324 1.1564 2.14377 1.06617 2.48423C0.975936 2.8247 0.977407 3.18299 1.07043 3.52271C1.16345 3.86242 1.34471 4.17148 1.59581 4.41848C1.8469 4.66549 2.15889 4.84165 2.50009 4.92909V7.07109C2.07097 7.17985 1.69037 7.4286 1.4185 7.77797C1.14663 8.12735 0.999023 8.5574 0.999023 9.00009C0.999023 9.44278 1.14663 9.87283 1.4185 10.2222C1.69037 10.5716 2.07097 10.8203 2.50009 10.9291V12.5921C2.16648 12.71 1.88531 12.9421 1.70627 13.2473C1.52723 13.5525 1.46185 13.9112 1.52169 14.26C1.58152 14.6087 1.76272 14.9251 2.03326 15.1531C2.30379 15.3812 2.64624 15.5063 3.00009 15.5063C3.35393 15.5063 3.69638 15.3812 3.96692 15.1531C4.23745 14.9251 4.41865 14.6087 4.47848 14.26C4.53832 13.9112 4.47294 13.5525 4.2939 13.2473C4.11486 12.9421 3.83369 12.71 3.50009 12.5921V10.9291C3.81115 10.848 4.09809 10.6931 4.33659 10.4776L6.01859 11.3186C6.00874 11.3787 6.00256 11.4393 6.00009 11.5001C5.99871 11.8476 6.11754 12.1848 6.33642 12.4547C6.55531 12.7246 6.86078 12.9104 7.20106 12.9808C7.54133 13.0512 7.89548 13.0017 8.20346 12.8408C8.51144 12.6799 8.7543 12.4175 8.89087 12.098C9.02745 11.7785 9.04933 11.4215 8.95282 11.0877C8.8563 10.7539 8.64732 10.4638 8.36131 10.2664C8.0753 10.0691 7.72985 9.97676 7.38352 10.005C7.0372 10.0333 6.7113 10.1805 6.46109 10.4216L4.88709 9.63459C4.95881 9.43059 4.99697 9.2163 5.00009 9.00009C4.99877 8.55789 4.8508 8.12863 4.57935 7.77955C4.30791 7.43047 3.92833 7.1813 3.50009 7.07109V4.92909C3.84371 4.83924 4.15721 4.6595 4.40835 4.40835C4.6595 4.15721 4.83924 3.84371 4.92909 3.50009H7.07109C7.13281 3.75207 7.24373 3.98937 7.39748 4.19834C7.55123 4.40731 7.74476 4.58383 7.96696 4.71774C8.18916 4.85166 8.43564 4.94033 8.69223 4.97866C8.94882 5.01699 9.21045 5.00422 9.46209 4.94109L10.3676 6.52609C10.132 6.7981 10.0004 7.14476 9.99611 7.50457C9.9918 7.86439 10.1151 8.21409 10.3441 8.49167C10.5731 8.76924 10.893 8.95673 11.247 9.02089C11.6011 9.08505 11.9665 9.02172 12.2783 8.84215C12.5901 8.66257 12.8283 8.37836 12.9505 8.03991C13.0727 7.70146 13.0711 7.33067 12.946 6.99329C12.8208 6.65592 12.5802 6.37377 12.2668 6.1969C11.9535 6.02003 11.5876 5.95987 11.2341 6.02709L10.3446 4.47009C10.6288 4.20982 10.8318 3.87298 10.9291 3.50009H12.5921C12.6842 3.75867 12.8456 3.98697 13.0587 4.16002C13.2718 4.33307 13.5283 4.44423 13.8003 4.48134C14.0723 4.51845 14.3492 4.48008 14.6009 4.37044C14.8526 4.26079 15.0692 4.08409 15.2273 3.85963C15.3853 3.63517 15.4786 3.37159 15.4969 3.09771C15.5153 2.82382 15.458 2.55015 15.3313 2.30662C15.2047 2.06308 15.0135 1.85905 14.7787 1.71681C14.5439 1.57457 14.2746 1.4996 14.0001 1.50009ZM4.00009 9.00009C4.00009 9.19787 3.94144 9.39121 3.83156 9.55566C3.72167 9.72011 3.5655 9.84828 3.38277 9.92397C3.20004 9.99965 2.99898 10.0195 2.805 9.98087C2.61102 9.94229 2.43283 9.84705 2.29298 9.70719C2.15313 9.56734 2.05789 9.38916 2.0193 9.19518C1.98072 9.0012 2.00052 8.80013 2.07621 8.6174C2.15189 8.43468 2.28007 8.2785 2.44452 8.16862C2.60897 8.05874 2.80231 8.00009 3.00009 8.00009C3.2653 8.00009 3.51966 8.10544 3.70719 8.29298C3.89473 8.48052 4.00009 8.73487 4.00009 9.00009ZM3.00009 4.00009C2.80231 4.00009 2.60897 3.94144 2.44452 3.83156C2.28007 3.72167 2.15189 3.5655 2.07621 3.38277C2.00052 3.20004 1.98072 2.99898 2.0193 2.805C2.05789 2.61102 2.15313 2.43283 2.29298 2.29298C2.43283 2.15313 2.61102 2.05789 2.805 2.0193C2.99898 1.98072 3.20004 2.00052 3.38277 2.07621C3.5655 2.15189 3.72167 2.28007 3.83156 2.44452C3.94144 2.60897 4.00009 2.80231 4.00009 3.00009C4.00009 3.2653 3.89473 3.51966 3.70719 3.70719C3.51966 3.89473 3.2653 4.00009 3.00009 4.00009ZM8.00009 3.00009C8.00009 2.80231 8.05874 2.60897 8.16862 2.44452C8.2785 2.28007 8.43468 2.15189 8.6174 2.07621C8.80013 2.00052 9.0012 1.98072 9.19518 2.0193C9.38916 2.05789 9.56734 2.15313 9.70719 2.29298C9.84705 2.43283 9.94229 2.61102 9.98087 2.805C10.0195 2.99898 9.99965 3.20004 9.92397 3.38277C9.84828 3.5655 9.72011 3.72167 9.55566 3.83156C9.39121 3.94144 9.19787 4.00009 9.00009 4.00009C8.73487 4.00009 8.48052 3.89473 8.29298 3.70719C8.10544 3.51966 8.00009 3.2653 8.00009 3.00009Z" fill="black"/>
                        </svg>
                        Add Branch
                      </button>

                      <button
                        onClick={() => navigate("/bulkupload/branch-master")}
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
                        </svg>
                        Bulk Upload
                      </button>

                       <input
                      type="file"
                      ref={fileInputRef}
                      className="hidden"
                      accept=".xlsx,.xls"
                    />
                    <button
                      onClick={handleDownloadTemplate}
                      className="w-full text-left px-4 py-2 hover:bg-blue-50 text-xs text-black flex items-center gap-2 whitespace-nowrap"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
                        <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
                        <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        <path d="M1 14.75H12" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      Download Template
                    </button>

                    </div>
                  )}
                </div>

                <button
                  onClick={handlePreviewAndDownload}
                  className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1  flex items-center gap-2 hover:bg-darkblue1 hover:text-white transition"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
                    <path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D"/>
                  </svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" className="w-3 h-3 hidden group-hover:block">
                    <path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white"/>
                  </svg>
                  <span className="font-semibold">Download</span>
                </button>
              </div>
            </div>
            {/* TABLE */}
            <div className="bg-white shadow-md border border-Dustyblue overflow-hidden  relative z-0">
              <div
              ref={tableContainerRef}
                className="overflow-y-auto relative z-0"
                style={{
                  scrollbarWidth: "none",
                  msOverflowStyle: "none",
                  maxHeight: sortedData.length > 7 ? "calc(100vh - 220px)" : "auto",
                }}
                onScroll={handleTableScroll}
              >
                <style jsx>{`
                  div::-webkit-scrollbar {
                    display: none;
                  }
                `}</style>

                <table className="w-full text-xs whitespace-nowrap">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                    <tr>
                      <th
                        className="text-left px-3 py-2 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none hover:bg-Dustyblue/80"
                        onClick={() => handleSort("marketarea")}
                      >
                        <div className="flex items-center gap-1">
                          Market Area
                          {sortKey !== "marketarea" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
                          {sortKey === "marketarea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
                          {sortKey === "marketarea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
                        </div>
                      </th>

                      <th
                        className="text-left px-3 py-2 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none hover:bg-Dustyblue/80"
                        onClick={() => handleSort("dealer_name")}
                      >
                        <div className="flex items-center gap-1">
                          Dealership
                          {sortKey === "dealer_name" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
                          {sortKey === "dealer_name" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
                        </div>
                      </th>

                      <th
                        className="text-left px-3 py-2 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none hover:bg-Dustyblue/80"
                        onClick={() => handleSort("city_name")}
                      >
                        <div className="flex items-center gap-1">
                          City
                          {sortKey === "city_name" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
                          {sortKey === "city_name" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
                        </div>
                      </th>

                      <th
                        className="text-left px-3 py-2 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none hover:bg-Dustyblue/80"
                        onClick={() => handleSort("districts")}
                      >
                        <div className="flex items-center gap-1">
                          Districts Covered
                          {sortKey === "districts" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
                          {sortKey === "districts" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
                        </div>
                      </th>

                      <th
                        className="text-left px-3 py-2 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none hover:bg-Dustyblue/80"
                        onClick={() => handleSort("branch_name")}
                      >
                        <div className="flex items-center gap-1">
                          Branch Name
                          {sortKey === "branch_name" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
                          {sortKey === "branch_name" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
                        </div>
                      </th>

                      <th
                        className="text-left px-3 py-2 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none hover:bg-Dustyblue/80"
                        onClick={() => handleSort("facility_type")}
                      >
                        <div className="flex items-center gap-1">
                          Facility Type
                          {sortKey === "facility_type" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
                          {sortKey === "facility_type" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
                        </div>
                      </th>

                      <th
                        className="text-left px-3 py-2 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none hover:bg-Dustyblue/80"
                        onClick={() => handleSort("development_status")}
                      >
                        <div className="flex items-center gap-1">
                          Dev Status
                          {sortKey === "development_status" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
                          {sortKey === "development_status" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
                        </div>
                      </th>

                      <th className="text-center py-2 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-black">
                    {sortedData.length > 0 ? (
                      sortedData.map((item, index) => (
                        <tr
                          key={index}
                          className={`text-xs border-b border-grey2 hover:bg-gray-50 ${
                            item.isActive !== 1 ? "text-gray-400" : ""
                          }`}
                        >
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[6rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.marketarea?.length > 6) setHoveredCell(item.id + "-market");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.marketarea || "-"}
                              </p>
                              {hoveredCell === item.id + "-market" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                  {item.marketarea}
                                </span>
                              )}
                            </div>
                          </td>
                          
                          {/* Dealer */}
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[10rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.dealer_name?.length > 10) setHoveredCell(item.id + "-dealer");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.dealer_name || "-"}
                              </p>
                              {hoveredCell === item.id + "-dealer" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                  {item.dealer_name}
                                </span>
                              )}
                            </div>
                          </td>
                          
                          {/* City */}
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[6rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.city_name?.length > 12) setHoveredCell(item.id + "-city");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.city_name || "-"}
                              </p>
                              {hoveredCell === item.id + "-city" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                  {item.city_name}
                                </span>
                              )}
                            </div>
                          </td>
                             <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 ">
                                                      {item?.districts && Array.isArray(item.districts) && item.districts.length > 0 ? (
                                                        (expandedRow === item.id
                                                          ? item.districts
                                                          : item.districts.slice(0, 2)
                                                        ).map((d, i, arr) => (
                                                          <div key={i} className="flex items-center gap-4">
                                                            <span>{d.district_name}</span>
                                                            {i === arr.length - 1 && item.districts.length > 2 && (
                                                              <button
                                                                onClick={(e) => {
                                                                  e.stopPropagation();
                                                                  toggleExpand(item.id);
                                                                }}
                                                                className="flex items-center text-blue-600 hover:text-blue-800 text-xs"
                                                              >
                                                                {expandedRow === item.id ? (
                                                                  <ChevronUp className="w-4 h-4" />
                                                                ) : (
                                                                  <ChevronDown className="w-4 h-4" />
                                                                )}
                                                              </button>
                                                            )}
                                                          </div>
                                                        ))
                                                      ) : (
                                                        <span className="text-gray-500">-</span>
                                                      )}
                                                    </td>
                          
                          {/* Branch Name */}
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[10rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.branch_name?.length > 40) setHoveredCell(item.id + "-branch");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.branch_name || "-"}
                              </p>
                              {hoveredCell === item.id + "-branch" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                  {item.branch_name}
                                </span>
                              )}
                            </div>
                          </td>
                          {/* Facility Type */}
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[6rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.facility_type?.length > 6) setHoveredCell(item.id + "-facility");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.facility_type || "-"}
                              </p>
                              {hoveredCell === item.id + "-facility" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                  {item.facility_type}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[6rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.development_status?.length > 6) setHoveredCell(item.id + "-development_status");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.development_status || "-"}
                              </p>
                          
                              {hoveredCell === item.id + "-development_status" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                  {item.development_status}
                                </span>
                              )}
                            </div>
                          </td>
                          
                         
                          
                          {/* ACTIONS */}
                          <td className="py-2 border border-grey2 border-t-0 border-l-0 border-r-0">
                            <div className="flex items-center justify-center gap-3">
                              {/* Edit */}
                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setFormData({
                                      market_area_id: item.market_area_id,
                                      dealership_id: item.dealership_id,
                                      city_id: item.city_id,
                                      district_ids: item.districts?.map(d => d.district_id) || [],
                                      branch_name: item.branch_name,
                                      facility_type: item.facility_type,
                                      development_status: item.development_status || ""
                                    });
                                    setIsEditing(true);
                                    setEditIndex(item.id);
                                    setIsAddUserOpen(true);
                                  }}
                                  className="text-blue-600 hover:underline"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                    <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                                    <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0 ">
                                  Edit
                                </span>
                              </div>

                              {/* Toggle */}
                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setSelectedRow(item.id);
                                    if (item.isActive === 1) {
                                      setShowDeactivateModal(true);
                                    } else {
                                      setShowActivateModal(true);
                                    }
                                  }}
                                >
                                  {item.isActive === 1 ? (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
                                      <path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                    </svg>
                                  ) : (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none">
                                      <g clipPath="url(#clip0_5669_3080)">
                                        <path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                      </g>
                                      <defs>
                                        <clipPath id="clip0_5669_3080">
                                          <rect width="24" height="24" fill="white"/>
                                        </clipPath>
                                      </defs>
                                    </svg>
                                  )}
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0 ">
                                  {item.isActive === 1 ? "Deactivate" : "Activate"}
                                </span>
                              </div>

                              {/* Delete */}
                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setDeleteIndex(item.id);
                                    setIsDeleteModalOpen(true);
                                  }}
                                  className="text-blue-600 hover:underline"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                                    <g clipPath="url(#clip0_6398_313)">
                                      <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                                    </g>
                                    <defs>
                                      <clipPath id="clip0_6398_313">
                                        <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                                      </clipPath>
                                    </defs>
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                  Delete
                                </span>
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={8} className="text-center py-8 text-gray-500 italic text-sm">
                          No data found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
               {showScrollButtons && (
            <div className="fixed bottom-14 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

            </div>
          </div>
        </div>
      </div>

     {/* ═══════════════════════════════════════════════════════ */}
      {/* ADD/EDIT MODAL WITH DEPENDENT DROPDOWNS                */}
      {/* ═══════════════════════════════════════════════════════ */}
      {isAddUserOpen && (
      <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
  <div
    ref={popupRef}
     tabIndex={0}
    
    className="bg-white p-6 w-full max-w-2xl max-h-[90vh] relative shadow-lg flex flex-col"
  >
    {/* Modal Header (fixed) */}
    <div className="bg-white flex items-center z-40 ">
  {/* Centered Heading */}
  <h2 className="absolute left-1/2 -translate-x-1/2 text-base sm:text-lg font-semibold text-MediumGrey">
    {isEditing ? "Edit Branch Master" : "Add Branch Master"}
  </h2>

  {/* Right-aligned Close Button */}
  <button
    onClick={() => {
      setIsAddUserOpen(false)
      setFormData({
        market_area_id: "",
        dealership_id: "",
        city_id: "",
        district_ids: [],
        branch_name: "",
        facility_type: "",
        development_status: "",
      })
      setErrors({})
      setIsEditing(false)
      setEditIndex(null)
      setSearchTerms({
        marketArea: "",
        dealership: "",
        city: "",
        district: "",
        facilityType: "",
        developmentStatus: "",
      })
    }}
    className="ml-auto text-red-600 font-bold text-lg hover:text-red-800"
  >
  <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>
  </button>
</div>

            
            {/* Modal Body - Scrollable Content */}
    <div className="flex-1 overflow-y-scroll scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200">
                {/* Form Grid - Responsive */}
              <div className="grid grid-cols-3  gap-3 sm:gap-4">
                
            {/* ========== MARKET AREA WITH SEARCH ========== */}
<div
  className="sm:col-span-1 dropdown-wrapper relative"ref={dropdownRef}
  style={{ zIndex: activeDropdown === "marketArea" ? 100 : 1 }}
 
>
  <label className="text-xs font-medium text-black/70">
    Market Area <span className=" text-red1">*</span>
  </label>

  <div className="relative w-full">
    {/* Display Field (Selected Value) */}
   <div
  onClick={() => toggleDropdown("marketArea")}
  tabIndex={0}
  onKeyDown={(e) => {

    if (e.key === "Enter") {
      toggleDropdown("marketArea")
      e.stopPropagation()

     
    }

    if (e.key === "Escape") {
      setActiveDropdown(null)
      e.stopPropagation()
    }

  }}
  
  className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all flex justify-between items-center 
  ${activeDropdown === "marketArea" ? "border-b-white" : ""}
  ${errors.marketArea ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
`}
>
      {formData.market_area_id ? (
        <span className="text-black">
          {
            marketAreas.find(
              area => area.id === formData.market_area_id
            )?.marketarea
          }
        </span>
      ) : (
        <span className="text-black/60">
          Select Market Area
        </span>
      )}
    </div>

    {/* Dropdown Arrow */}
   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`w-3 h-3 absolute right-3 top-3 cursor-pointer transform transition-transform
        ${activeDropdown === "marketArea" ? "rotate-180" : ""}
      `}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>
    {/* Dropdown */}
    {activeDropdown === "marketArea" && (
      <div className="absolute z-50 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto top-full left-0 scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100">

        {/* Search Input */}
        {marketAreas.length > 5 && (
          <div className="sticky top-0 bg-white px-3 py-1.5 z-10">
           <input
  type="text"
  placeholder="Search Market Area..."
  value={searchTerms.marketArea}
  onChange={(e) =>
    setSearchTerms(prev => ({
      ...prev,
      marketArea: e.target.value
    }))
  }

  onKeyDown={(e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation(); // 🔥 important

     setActiveDropdown(null); // or your dropdown state (change if different)

      setSearchTerms(prev => ({
        ...prev,
        marketArea: "" // optional clear
      }));
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation();

      const first = e.currentTarget
        .closest("ul")
        ?.querySelector("li[tabindex]");
      first?.focus();
    }
  }}

  className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
/>
          </div>
        )}

        {/* Options */}
        {marketAreas
          .filter(area =>
            searchTerms.marketArea
              ? area.marketarea
                  .toLowerCase()
                  .includes(searchTerms.marketArea.toLowerCase())
              : true
          )
          .sort((a, b) => a.marketarea.localeCompare(b.marketarea))
          .map(area => {
            const selected = area.id === formData.market_area_id;

            return (
           <div
  key={area.id}
  tabIndex={0}
  data-market-option

  onKeyDown={(e) => {

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-market-option]")
    )

    const index = items.indexOf(e.currentTarget)

    if (e.key === "ArrowDown") {
      e.preventDefault()
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus()
    }

    if (e.key === "ArrowUp") {
      e.preventDefault()
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus()
    }

    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      e.currentTarget.click()
    }

    if (e.key === "Escape") {
      e.stopPropagation()
      setActiveDropdown(null)
    }
  }}

  onClick={() => {
    setFormData({
      ...formData,
      market_area_id: area.id,
      dealership_id: "",
      city_id: "",
      district_ids: []
    })
 setErrors((prev) => ({
    ...prev,
    marketArea: ""
  }));

    setActiveDropdown(null)

    setSearchTerms(prev => ({
      ...prev,
      marketArea: ""
    }))
  }}

  className={`px-3 py-1.5 text-xs cursor-pointer hover:bg-gray-100 focus:bg-gray-100
  ${selected ? "bg-lightBlue font-medium" : ""}`}
>
  {area.marketarea}
</div>
            );
          })}

        {/* No results */}
        {marketAreas.filter(area =>
          searchTerms.marketArea
            ? area.marketarea
                .toLowerCase()
                .includes(searchTerms.marketArea.toLowerCase())
            : true
        ).length === 0 && (
          <div className="px-3 py-2 text-xs text-gray-500 text-center italic">
            No results found
          </div>
        )}
      </div>
    )}
  </div>

  {errors.marketArea && (
    <p className="text-red1 text-xs mt-1">{errors.marketArea}</p>
  )}
</div>


                {/* ========== DEALERSHIP WITH SEARCH (DEPENDS ON MARKET AREA) ========== */}
              <div
  className="col-span-1 sm:col-span-2 dropdown-wrapper relative"
  style={{ zIndex: activeDropdown === "dealership" ? 100 : 1 }}
>
  <label className="text-xs font-medium text-black/70">
    Dealership <span className=" text-red1">*</span>  
  </label>

  <div className="relative w-full">
    {/* Display Field */}
    <div
      onClick={() => {
        toggleDropdown("dealership");
        setSearchTerms(prev => ({ ...prev, dealership: "" }));
      }}
className={` border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all flex justify-between items-center 
                            ${activeDropdown === "dealership" ? "border-b-white" : ""}
        ${errors.dealership ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
      `}
      tabIndex={0}
      onKeyDown={(e) => {

  // ENTER → open dropdown only
  if (e.key === "Enter") {
    e.preventDefault()
    e.stopPropagation()

    toggleDropdown("dealership")
  }

  // ARROWDOWN → open + focus first option
 
  // ESC → close
  if (e.key === "Escape") {
    setActiveDropdown(null)
    e.stopPropagation()
  }

}}

    >
      {formData.dealership_id ? (
        <span className="text-black">
          {
            dealers.find(
              dealer => dealer.id === formData.dealership_id
            )?.dealerName
          }
        </span>
      ) : (
        <span className="text-black/60">
          Select Dealership
        </span>
      )}
    </div>

    {/* Arrow */}
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`w-3 h-3 absolute right-3 top-[14px] cursor-pointer transition-transform
        ${activeDropdown === "dealership" ? "rotate-180" : ""}
      `}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>

    {/* Dropdown */}
    {activeDropdown === "dealership" && (
      <div className="absolute z-50 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto top-full left-0 scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100">

        {/* Market Area dependency check */}
        {!formData.market_area_id ? (
          <div className="px-3 py-2 text-xs text-gray-500 text-center italic">
            Please select a market area first
          </div>
        ) : (
        <>
          {/* Search - uses popupDealerOptions */}
          {popupDealerOptions.length > 5 && (
            <div className="sticky top-0 bg-white px-3 py-1.5 z-10">
             <input
  type="text"
  placeholder="Search Dealership..."
  value={searchTerms.dealership}
  onChange={(e) =>
    setSearchTerms(prev => ({
      ...prev,
      dealership: e.target.value
    }))
  }

  onClick={(e) => e.stopPropagation()}

  onKeyDown={(e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation(); // 🔥 important

setActiveDropdown(null)
      setSearchTerms(prev => ({
        ...prev,
        dealership: "" // optional clear
      }));
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation();

      const first = e.currentTarget
        .closest("ul")
        ?.querySelector("li[tabindex]");
      first?.focus();
    }
  }}

  className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
  autoFocus
/>
            </div>
          )}

          {/* Options - uses popupDealerOptions */}
          {popupDealerOptions
            .filter(dealer =>
              searchTerms.dealership
                ? dealer.dealerName
                    .toLowerCase()
                    .includes(searchTerms.dealership.toLowerCase())
                : true
            )
            .filter(dealer => dealer.id !== formData.dealership_id)
            .sort((a, b) => a.dealerName.localeCompare(b.dealerName))
            .map(dealer => (
              <div
              key={dealer.id}
              tabIndex={0}
              data-dealer-option

              onKeyDown={(e) => {

                const items = Array.from(
                  e.currentTarget.parentElement.querySelectorAll("[data-dealer-option]")
                )

                const index = items.indexOf(e.currentTarget)

              if (e.key === "ArrowDown") {
                e.stopPropagation()
  items[(index + 1) % items.length]?.focus()
}

if (e.key === "ArrowUp") {
  e.stopPropagation()
  items[(index - 1 + items.length) % items.length]?.focus()
}

if (e.key === "Enter") {
  e.stopPropagation()
  e.currentTarget.click()
}
                if (e.key === "Escape") {
                  e.stopPropagation()
                  setActiveDropdown(null)
                }

              }}

            onClick={() => {

  setFormData({
    ...formData,
    dealership_id: dealer.id,
    city_id: "",
    district_ids: []
  })
 setErrors((prev) => ({
    ...prev,
    dealership: ""
  }));

  setActiveDropdown(null)

  setSearchTerms(prev => ({
    ...prev,
    dealership: ""
  }))

}}
              className="px-3 py-1.5 text-xs cursor-pointer hover:bg-gray-100 focus:bg-gray-100"
            >
              {dealer.dealerName}
            </div>
            ))}

          {/* No results */}
          {popupDealerOptions.filter(dealer =>
            searchTerms.dealership
              ? dealer.dealerName
                  .toLowerCase()
                  .includes(searchTerms.dealership.toLowerCase())
              : true
          ).length === 0 && (
            <div className="px-3 py-2 text-xs text-gray-500 text-center">
              No results found
            </div>
          )}
        </>
        )}
      </div>
    )}
  </div>

  {errors.dealership && (
    <p className="text-red1 text-xs mt-1">
      {errors.dealership}
    </p>
  )}
</div>


            {/* ========== CITY (DEPENDS ON DEALERSHIP, uses popupCityOptions) ========== */}
            <div
  className="col-span-1 sm:col-span-3 dropdown-wrapper relative"
  style={{ zIndex: activeDropdown === "city" ? 100 : 1 }}
>
  <label className="text-xs font-medium text-black/70">
    City <span className=" text-red1">*</span>
  </label>

  <div className="relative w-full">
    {/* Display Field */}
    <div
      onClick={() => {
        toggleDropdown("city");
        setSearchTerms(prev => ({ ...prev, city: "" }));
      }}
className={` border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all flex justify-between items-center
                            ${activeDropdown === "city" ? "border-b-white" : ""}
        ${errors.city ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
      `}
      tabIndex={0}
       onKeyDown={(e) => {

      const items = Array.from(
        e.currentTarget.parentElement.querySelectorAll("[data-city-option]")
      )

      const index = items.indexOf(e.currentTarget)

   

      if (e.key === "Enter") {
        e.preventDefault()
        e.stopPropagation()
        e.currentTarget.click()
      }

     if (e.key === "Escape") {
  e.preventDefault()
  e.stopPropagation()
  setActiveDropdown(null)
}

    }}

    >
      {formData.city_id ? (
        <span className="text-black">
          {
            cities.find(
              city => city.id === formData.city_id
            )?.city_name
          }
        </span>
      ) : (
        <span className="text-black/60">
          Select City
        </span>
      )}
    </div>

    {/* Arrow */}
   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"   className={`w-3 h-3 absolute right-3 top-[14px] cursor-pointer transition-transform
        ${activeDropdown === "city" ? "rotate-180" : ""}
      `}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>
    {/* Dropdown */}
    {activeDropdown === "city" && (
      <div className="absolute z-50 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto top-full left-0 scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100">

        {/* Dealership dependency */}
        {!formData.dealership_id ? (
          <div className="px-3 py-2 text-xs text-gray-500 text-center italic">
            Please select a dealership first
          </div>
        ) : (
          <>
            {/* Search - uses popupCityOptions */}
            {popupCityOptions.length > 5 && (
              <div className="sticky top-0 bg-white px-3 py-1.5 z-10">
               <input
  type="text"
  placeholder="Search City..."
  value={searchTerms.city}
  onChange={(e) =>
    setSearchTerms(prev => ({
      ...prev,
      city: e.target.value
    }))
  }

  onClick={(e) => e.stopPropagation()}

  onKeyDown={(e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation(); // 🔥 key fix

setActiveDropdown(null)
      setSearchTerms(prev => ({
        ...prev,
        city: "" // optional clear
      }));
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation();

      const first = e.currentTarget
        .closest("ul")
        ?.querySelector("li[tabindex]");
      first?.focus();
    }
  }}

  className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
  autoFocus
/>
              </div>
            )}

            {/* Options - uses popupCityOptions */}
            {popupCityOptions
              .filter(city =>
                searchTerms.city
                  ? city.city_name
                      .toLowerCase()
                      .includes(searchTerms.city.toLowerCase())
                  : true
              )
              .filter(city => city.id !== formData.city_id)
              .sort((a, b) => a.city_name.localeCompare(b.city_name))
             .map(city => (

  <div
    key={city.id}
    tabIndex={0}
    data-city-option

    onKeyDown={(e) => {

      const items = Array.from(
        e.currentTarget.parentElement.querySelectorAll("[data-city-option]")
      )

      const index = items.indexOf(e.currentTarget)

      if (e.key === "ArrowDown") {
        e.preventDefault()
        e.stopPropagation()
        items[(index + 1) % items.length]?.focus()
      }

      if (e.key === "ArrowUp") {
        e.preventDefault()
        e.stopPropagation()
        items[(index - 1 + items.length) % items.length]?.focus()
      }

      if (e.key === "Enter") {
        e.preventDefault()
        e.stopPropagation()
        e.currentTarget.click()
      }

     if (e.key === "Escape") {
  e.preventDefault()
  e.stopPropagation()
  setActiveDropdown(null)
}

    }}

    onClick={() => {

      setFormData({
        ...formData,
        city_id: city.id,
        district_ids: []
      })
 setErrors((prev) => ({
    ...prev,
   city: ""
  }));

      setActiveDropdown(null)

      setSearchTerms(prev => ({
        ...prev,
        city: ""
      }))

    }}

    className="px-3 py-1.5 text-xs cursor-pointer hover:bg-gray-100 focus:bg-gray-100"
  >
    {city.city_name}
  </div>

))}

            {/* No results - uses popupCityOptions */}
            {popupCityOptions.filter(city =>
              searchTerms.city
                ? city.city_name
                    .toLowerCase()
                    .includes(searchTerms.city.toLowerCase())
                : true
            ).length === 0 && (
              <div className="px-3 py-2 text-xs text-gray-500 text-center">
                No results found
              </div>
            )}
          </>
        )}
      </div>
    )}
  </div>

  {errors.city && (
    <p className="text-red1 text-xs mt-1">
      {errors.city}
    </p>
  )}
</div>


{/* /* ========== DISTRICTS (DEPENDS ON CITY) ========== */} 
<div className="col-span-2 md:col-span-3 dropdown-wrapper relative">
  <label className="text-xs font-medium text-black/70">
    Districts Covered <span className=" text-red1">*</span>
  </label>

  <div className="relative w-full">
    <div
      onClick={() => toggleDropdown("district")}
      className={` border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all flex items-center pr-8
        ${activeDropdown === "district" ? " border-b-white" : ""}
        ${errors.district ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
        ${!formData.city_id ? "bg-gray-100 cursor-not-allowed" : ""}
      `}
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          e.stopPropagation();
          toggleDropdown("district");
        }

        if (e.key === "Escape") {
          setActiveDropdown(null);
          e.stopPropagation();
        }
      }}
    >
      {/* Selected chips */}
      {formData.district_ids.length > 0 ? (
        <div className="flex items-center gap-[4px] overflow-x-auto whitespace-nowrap pr-6">
          {formData.district_ids.map((districtId) => {
            const district = districts.find(d => d.id === districtId);
            return (
              <span
                key={districtId}
                className="inline-flex items-center gap-[2px] bg-grey2 text-black px-1.5 py-[2px] text-xs rounded"
              >
                {district?.district_name}
                <button
                  type="button"
                  className="flex items-center ml-[2px]"
                  onClick={(e) => {
                    e.stopPropagation();
                    setFormData((prev) => ({
                      ...prev,
                      district_ids: prev.district_ids.filter((d) => d !== districtId),
                    }));
                  }}
                >
                  <svg width="12" height="12" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="8" fill="#BF2012" />
                    <path
                      d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
                      stroke="white"
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                  </svg>
                </button>
              </span>
            );
          })}
        </div>
      ) : (
        <span className="text-black/60">Select District *</span>
      )}
    </div>

    {/* Dropdown arrow icon */}
   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"   className={`w-3 h-3 absolute right-3 top-3 cursor-pointer transform transition-transform duration-200 ${
        activeDropdown === "district" ? "rotate-180" : "rotate-0"
      }`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>
    {/* Dropdown list */}
    {activeDropdown === "district" && (
      <div className="absolute z-50 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto top-full left-0 mt-0 scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100">
        
        {!formData.city_id ? (
          <div className="px-3 py-2 text-xs text-gray-500 text-center italic">
            Please select a city first
          </div>
        ) : (
          <>
            {getFilteredDistrictsByCity(formData.city_id).length > 5 && (
              <div className="sticky top-0 bg-white z-10 mb-2 px-3">
                <input
                  type="text"
                  placeholder="Search districts..."
                  value={searchTerms.district}
                  onChange={(e) => handleSearchChange("district", e.target.value)}
                  className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
                />
              </div>
            )}

            {getFilteredDistrictsByCity(formData.city_id)
              .filter((dist) =>
                searchTerms.district
                  ? dist.district_name.toLowerCase().includes(searchTerms.district.toLowerCase())
                  : true
              )
              .sort((a, b) => a.district_name.localeCompare(b.district_name))
              .map((dist) => {
                const selected = formData.district_ids.includes(dist.id);

                return (
                  <div
                    key={dist.id}
                    onClick={() => {
                      setFormData((prev) => ({
                        ...prev,
                        district_ids: selected
                          ? prev.district_ids.filter((d) => d !== dist.id)
                          : [...prev.district_ids, dist.id],
                      }));

                      setErrors((prev) => ({
                        ...prev,
                        district: ""
                      }));
                    }}
                    className={`px-3 py-1.5 text-xs cursor-pointer hover:bg-gray-100 ${
                      selected ? "bg-lightBlue font-medium" : ""
                    }`}
                  >
                    {dist.district_name}
                  </div>
                );
              })}
          </>
        )}
      </div>
    )}
  </div>

  {errors.district && <p className="text-red1 text-xs mt-1">{errors.district}</p>}
</div>



                {/* ========== BRANCH NAME ========== */}
                <div className="col-span-1 sm:col-span-3">
                  <label className="text-xs  text-gray-600 block mb-1">Branch Name <span className=" text-red1">*</span> </label>
                  <input
                    type="text"
                    value={formData.branch_name || ""}
                    tabIndex={0}
                    onChange={(e) =>{ 
                         if (errors.branch_name) {
          setErrors({ ...errors, branch_name: "" });
        }
                      setFormData({ ...formData, branch_name: e.target.value })}}
                    placeholder="Enter Branch Name"
className={` border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all flex justify-between items-center
                                          ${errors.branchName ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                    `}
                  />
                  {errors.branchName && <p className="text-red1 text-xs mt-1">{errors.branchName}</p>}
                </div>

{/* ========== FACILITY TYPE WITH SEARCH ========== */}
<div className="col-span-1 relative">
  <label className="text-xs font-medium text-black/70">
    Facility Type <span className=" text-red1">*</span>
  </label>

  <div className="relative mt-1">
    {/* Input */}
    <input
      type="text"
      readOnly
     
      value={formData.facility_type || ""}
      placeholder="Select Facility Type"
      onClick={() =>
        setActiveDropdown(
          activeDropdown === "facilityType" ? null : "facilityType"
        )
      }
className={` border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all flex justify-between items-center
                            ${activeDropdown === "facilityType" ? "border-b-white" : ""}
        ${errors.facilityType ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
      `}
      tabIndex={0}
       onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setActiveDropdown("facilityType")
    }

  

    // ESC → close
    if (e.key === "Escape") {
      e.stopPropagation()
      setActiveDropdown(null)
    }

  }}

    />

    {/* Arrow */}
       <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"  className={`w-3 h-3 absolute right-3 top-[14px] cursor-pointer transform transition-transform
        ${activeDropdown === "facilityType" ? "rotate-180" : ""}
      `}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>

    {/* Dropdown */}
    {activeDropdown === "facilityType" && (
      <div className="absolute z-50 w-full bg-white border border-black/30 border-t-white shadow-md max-h-20 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100">

        {/* Search (if >5 options) */}
        {facilityTypes.length > 5 && (
          <div className="sticky top-0 bg-white px-3 py-1.5 border-black/10">
            <input
              type="text"
              autoFocus
              placeholder="Search..."
              value={searchTerms.facilityType}
              onChange={(e) =>
                setSearchTerms((prev) => ({
                  ...prev,
                  facilityType: e.target.value,
                }))
              }
              className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        )}

        {/* Options */}
        {facilityTypes
          .filter((opt) =>
            searchTerms.facilityType
              ? opt.toLowerCase().includes(searchTerms.facilityType.toLowerCase())
              : true
          )
          .sort((a, b) => a.localeCompare(b))
        .map((type) => (

  <div
    key={type}
    tabIndex={0}
    data-facility-option

    onKeyDown={(e) => {

      const items = Array.from(
        e.currentTarget.parentElement.querySelectorAll("[data-facility-option]")
      )

      const index = items.indexOf(e.currentTarget)

      if (e.key === "ArrowDown") {
        e.preventDefault()
        e.stopPropagation()
        items[(index + 1) % items.length]?.focus()
      }

      if (e.key === "ArrowUp") {
        e.preventDefault()
        e.stopPropagation()
        items[(index - 1 + items.length) % items.length]?.focus()
      }

      if (e.key === "Enter") {
        e.preventDefault()
        e.stopPropagation()
        e.currentTarget.click()
      }

      if (e.key === "Escape") {
        e.stopPropagation()
        setActiveDropdown(null)
      }

    }}

    onClick={() => {

      setFormData((prev) => ({
        ...prev,
        facility_type: type,
      }))
 setErrors((prev) => ({
    ...prev,
    facilityType: ""
  }));

      setActiveDropdown(null)

      setSearchTerms((prev) => ({
        ...prev,
        facilityType: "",
      }))

    }}

    className="px-3 py-1.5 text-xs cursor-pointer hover:bg-gray-100 focus:bg-gray-100"
  >
    {type}
  </div>

))}

        {/* No results */}
        {facilityTypes.filter((opt) =>
          searchTerms.facilityType
            ? opt.toLowerCase().includes(searchTerms.facilityType.toLowerCase())
            : true
        ).length === 0 && (
          <div className="px-3 py-2 text-xs text-gray-500">
            No results found
          </div>
        )}
      </div>
    )}
  </div>

  {/* Error */}
  {errors.facilityType && (
    <p className="text-red1 text-xs mt-1">
      {errors.facilityType}
    </p>
  )}
</div>

                {/* ========== DEVELOPMENT STATUS WITH SEARCH ========== */}
               <div className="col-span-1 sm:col-span-2 relative">
  <label className="text-xs font-medium text-black/70">
    Development Status <span className=" text-red1">*</span>
  </label>

  <div className="relative mt-1">
    {/* Input */}
    <input
      type="text"
      readOnly
    tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          e.stopPropagation()
          setActiveDropdown("developmentStatus");  
        }

    
        if (e.key === "Escape") {
          setActiveDropdown(null);
          e.stopPropagation()
        }
      }}

      value={formData.development_status || ""}
      placeholder="Select Development Status"
      onClick={() =>
        setActiveDropdown(
          activeDropdown === "developmentStatus" ? null : "developmentStatus"
        )
      }
className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all  flex justify-between items-center 
                      ${activeDropdown === "developmentStatus" ? "border-b-white" : ""}
  ${errors.development_status ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
`}

    />

    {/* Arrow */}
   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`w-3 h-3 absolute right-3 top-[14px] cursor-pointer transform transition-transform ${activeDropdown === "developmentStatus" ? "rotate-180" : ""}`}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
</svg>
    {/* Dropdown */}
    {activeDropdown === "developmentStatus" && (
      <div className="absolute z-50 w-full bg-white border border-black/30 border-t-white shadow-md max-h-40 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100">

        {/* Search (only if >5 options) */}
        {developmentStatusOptions.length > 5 && (
          <div className="sticky top-0 bg-white px-3 py-1.5 border-black/10">
            <input
              type="text"
              autoFocus
              placeholder="Search..."
              value={searchTerms.developmentStatus}
              onChange={(e) =>
                setSearchTerms((prev) => ({
                  ...prev,
                  developmentStatus: e.target.value,
                }))
              }
              className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        )}

        {/* Options */}
        {developmentStatusOptions
          .filter((opt) =>
            searchTerms.developmentStatus
              ? opt
                  .toLowerCase()
                  .includes(searchTerms.developmentStatus.toLowerCase())
              : true
          )
          .sort((a, b) => a.localeCompare(b))
          .map((status) => (
             <div
              key={status}
              tabIndex={0}
              data-dev-status-option

              onKeyDown={(e) => {
                const items = Array.from(
                  e.currentTarget.parentElement.querySelectorAll(
                    "[data-dev-status-option]"
                  )
                );

                const currentIndex = items.indexOf(e.currentTarget);

                if (e.key === "ArrowDown") {
                  e.preventDefault();
                  e.stopPropagation()
                  items[(currentIndex + 1) % items.length]?.focus();
                }

                if (e.key === "ArrowUp") {
                  e.preventDefault();
                  e.stopPropagation()
                  items[
                    (currentIndex - 1 + items.length) % items.length
                  ]?.focus();
                }

                if (e.key === "Escape") {
                  setActiveDropdown(null);
                  e.stopPropagation()
                }

                if (e.key === "Enter") {
                  e.preventDefault();
e.stopPropagation()
                  setFormData((prev) => ({
                    ...prev,
                    development_status: status,
                  }));

                  setActiveDropdown(null);

                  setSearchTerms((prev) => ({
                    ...prev,
                    developmentStatus: "",
                  }));
                }
              }}

             onClick={(e) => {
               

                setFormData((prev) => ({
                  ...prev,
                  development_status: status,
                }));
 setErrors((prev) => ({
    ...prev,
   developmentStatus: ""
  }));

                setActiveDropdown(null);

                setSearchTerms((prev) => ({
                  ...prev,
                  developmentStatus: "",
                }));
              }}

              className="px-3 py-1.5 text-xs cursor-pointer hover:bg-gray-100"
            >
              {status}
            </div>
          ))}

        {/* No results */}
        {developmentStatusOptions.filter((opt) =>
          searchTerms.developmentStatus
            ? opt
                .toLowerCase()
                .includes(searchTerms.developmentStatus.toLowerCase())
            : true
        ).length === 0 && (
          <div className="px-3 py-2 text-xs text-gray-500">
            No results found
          </div>
        )}
      </div>
    )}
  </div>

  {errors.development_status && (
    <p className="text-red1 text-xs mt-1">
      {errors.development_status}
    </p>
  )}
</div>

              </div>
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-white p-4 sm:p-6 flex justify-center">
              <button
              id="saveBranchBtn"
                onClick={async () => {
                  const newErrors = {};
                  if (!formData.market_area_id) newErrors.marketArea = "Please select Market Area";
                  if (!formData.dealership_id) newErrors.dealership = "Please select Dealership";
                  if (!formData.city_id) newErrors.city = "Please select City";
                  if (!formData.district_ids || formData.district_ids.length === 0) newErrors.district = "Please select District";
                  if (!formData.branch_name) newErrors.branchName = "Please enter Branch Name";
                  if (!formData.facility_type) newErrors.facilityType = "Please select Facility Type";
                  if (!formData.development_status) newErrors.development_status = "Please select Development Status";

                  if (Object.keys(newErrors).length > 0) {
                    setErrors(newErrors);
                    return;
                  }

                  try {
                    setLoading(true);
                    
                    if (isEditing) {
                      await updateBranchMaster(editIndex, formData);
                    } else {
                      await addBranchMaster(formData);
                    }
   resetSortAndFilter ()
                    await loadBranchMasters();
                    
                    setFormData({
                      market_area_id: "", dealership_id: "", city_id: "", district_ids: [],
                      branch_name: "", facility_type: "", development_status: ""
                    });
                    setErrors({});
                    setIsAddUserOpen(false);
                    setIsEditing(false);
                    setEditIndex(null);
                    setSearchTerms({
                      marketArea: "",
                      dealership: "",
                      city: "",
                      district: "",
                      facilityType: "",
                      developmentStatus: ""
                    });
                  } catch (error) {
                    // console.error("Error saving branch master:", error);
                    setError(error.message || "Failed to save branch master");
                  } finally {
                    setLoading(false);
                  }
                }}
                disabled={loading}
              className="bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? "Saving..." : isEditing ? "Update" : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE MODAL */}
      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={async () => {
          if (deleteIndex !== null) {
            try {
              setLoading(true);
              await deleteBranchMaster(deleteIndex);
              resetSortAndFilter ()
              await loadBranchMasters();
              setDeleteIndex(null);
            } catch (error) {
              // console.error("Error deleting branch master:", error);
              setError(error.message || "Failed to delete branch master");
            } finally {
              setLoading(false);
            }
          }
          setIsDeleteModalOpen(false);
        }}
      />

      {/* ACTIVATE MODAL */}
      {showActivateModal && selectedRow !== null && (
        <ActivateStatus
          isOpen={showActivateModal}
          onClose={() => setShowActivateModal(false)}
          onConfirm={async () => {
            try {
              setLoading(true);
              await toggleBranchMaster(selectedRow);
              await loadBranchMasters();
              setShowActivateModal(false);
              setSelectedRow(null);
            } catch (error) {
              // console.error("Error activating branch master:", error);
              setError(error.message || "Failed to activate branch master");
            } finally {
              setLoading(false);
            }
          }}
        />
      )}

      {/* DEACTIVATE MODAL */}
      {showDeactivateModal && selectedRow !== null && (
        <DeactivateStatus
          isOpen={showDeactivateModal}
          onClose={() => setShowDeactivateModal(false)}
          onConfirm={async () => {
            try {
              setLoading(true);
              await toggleBranchMaster(selectedRow);
              await loadBranchMasters();
              setShowDeactivateModal(false);
              setSelectedRow(null);
            } catch (error) {
              // console.error("Error deactivating branch master:", error);
              setError(error.message || "Failed to deactivate branch master");
            } finally {
              setLoading(false);
            }
          }}
        />
      )}
    </div>
  )
}

export default BranchMaster;