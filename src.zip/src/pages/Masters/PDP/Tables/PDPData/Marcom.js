import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import Filter from "../../../../../Components/Filter"
import DeleteModal from "../../../../../Components/DeleteModal"
import * as XLSX from "xlsx";
import DeactivateStatus from "../../../../../Components/DeactivateStatus"
import ActivateStatus from "../../../../../Components/ActivateStatus"
import { useLocation } from "react-router-dom"
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
import { uploadTempFile } from "../../../../../services/download/bluckDownload.service"
import {
  addMarcom,
  getAllMarcoms,
  updateMarcom,
  toggleMarcom,
  deleteMarcom,
} from "../../../../../services/pdpMaster/marcom.service"
import MarketingMarcom from "./MarketingMarcom"
import { ChevronUp, ChevronDown } from "lucide-react";
import useCRUDWithReset from "../../../../../util/useCRUDWithReset"
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation"
// Custom debounce hook
const useDebounce = (value, delay) => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
};

function Marcom() {   
  const location = useLocation();
  const [selectedYears, setSelectedYears] = useState([]);
  const [marcom_type, setmarcom_type] = useState([]);
  const marcom_typeRef = useRef(null); 
  const [selectedRow, setSelectedRow] = useState(null);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [activeView, setActiveView] = useState("branding");
  const [selectedStatus, setSelectedStatus] = useState([]);
  const statusOptions = ["Active", "Inactive"];
  const [marcom_typeSearch, setMarcom_typeSearch] = useState("")
  const popupRef = useRef(null)
  // On mount, check if state is passed
  useEffect(() => {
    if (location.state?.activeView) {
      setActiveView(location.state.activeView);
    }
  }, [location.state]);

  const [menuOpen, setMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const dropdownRef = useRef(null)
  const [tableData, setTableData] = useState([])
  const [formData, setFormData] = useState({ 
    id: null,
    year: "",
    marcom_type: "", 
    marcom_name: ""
  })
  const [isEditing, setIsEditing] = useState(false)
  const [errors, setErrors] = useState({})
  const [searchQuery, setSearchQuery] = useState("")
  const fileInputRef = useRef(null)
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null);

  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [showmarcom_typeSuggestions, setShowmarcom_typeSuggestions] = useState(false);
  const [marcom_name, setmarcom_name] = useState("");
  const [marcomOptions, setMarcomOptions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [loadingToggle, setLoadingToggle] = useState(false);

  const [hoveredCell, setHoveredCell] = useState(null);

  // ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null);
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);

  // Dynamic year options from table data
  const yearOptions = useMemo(() => {
    const years = tableData
      .map(item => String(item.year || "").trim())
      .filter(y => y && /^\d{4}$/.test(y));
    return [...new Set(years)].sort((a, b) => Number(b) - Number(a));
  }, [tableData]);

  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    if (scrollTop > lastScrollTop) {
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);
    setScrollPosition(scrollTop);

    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") setSortOrder("desc");
      else if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
      } else setSortOrder("asc");
    } else {
      setSortKey(key);
      setSortOrder("asc");
    }
  };

  // Debounce search query
  const debouncedSearchQuery = useDebounce(searchQuery, 300);

  // Fetch data on mount
  useEffect(() => {
    fetchMarcomData();
  }, []);

  const fetchMarcomData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await getAllMarcoms();
      
      if (response) {
        const dataArray = Array.isArray(response) ? response : (response.data || []);
        
        if (!Array.isArray(dataArray)) {
          throw new Error("Invalid response format from API");
        }
        
        const transformedData = dataArray.map(item => ({
          id: item.id,
          year: item.year ? String(item.year) : "",
          marcom_type: item.marcom_type || "",
          marcom_name: item.marcom_name || "",
          status: item.isActive === 1 ? "Active" : "Inactive"
        }));
        setTableData(transformedData);
      }
    } catch (err) {
      // console.error("Error fetching marcom data:", err);
      setError(err.message || "Failed to fetch marcom data");
    } finally {
      setIsLoading(false);
    }
  };

  const handleBulkUploadClick = () => {
    fileInputRef.current.click()
  }

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsLoading(true);
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      if (jsonData.length === 0) {
        throw new Error("The file is empty or has no valid data");
      }

      const validatedData = jsonData.map((row, index) => {
        const year = row["Year"];
        const marcom_type = row["Marcom Type"];
        const marcom_name = row["Marcom Name"];

        if (!year || String(year).trim() === "") {
          throw new Error(`Row ${index + 2}: Year is required`);
        }
        if (!/^\d{4}$/.test(String(year).trim())) {
          throw new Error(`Row ${index + 2}: Year must be a 4-digit number`);
        }
        if (!marcom_type || String(marcom_type).trim() === "") {
          throw new Error(`Row ${index + 2}: Marcom Type is required`);
        }
        if (!marcom_name || String(marcom_name).trim() === "") {
          throw new Error(`Row ${index + 2}: Marcom Name is required`);
        }
        
        return {
          year: String(year).trim(),
          marcom_type: String(marcom_type).trim(),
          marcom_name: String(marcom_name).trim()
        };
      });

      let successCount = 0;
      let errorCount = 0;
      const errors = [];

      for (let i = 0; i < validatedData.length; i++) {
        try {
          await addMarcom(validatedData[i]);
          successCount++;
        } catch (err) {
          errorCount++;
          errors.push(`Row ${i + 2}: ${err.message}`);
        }
      }
      
      await fetchMarcomData();
      
      if (errorCount === 0) {
        // alert(`Successfully uploaded ${successCount} marcom(s)`);
      } else {
        // alert(`Upload completed with ${successCount} success and ${errorCount} error(s).\n\nErrors:\n${errors.join('\n')}`);
      }
    } catch (error) {
      // console.error("Bulk upload error:", error);
      // alert(error.message || "Failed to upload file");
    } finally {
      setIsLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  // Fixed filteredData with proper year comparison
  const filteredData = useMemo(() => {
    return tableData.filter((item) => {
      const matchesSearch = debouncedSearchQuery
        ? Object.values(item).some((val) =>
            String(val || "")
              .toLowerCase()
              .includes(debouncedSearchQuery.trim().toLowerCase())
          )
        : true;

      const matchesYear = selectedYears.length
        ? selectedYears.some((year) => String(year).trim() === String(item.year || "").trim())
        : true;

      const matchesmarcom_type =
        marcom_type.length > 0 ? marcom_type.includes(item.marcom_type) : true;

      const itemMarcomName = String(item.marcom_name || "");
      const matchesmarcom_name = marcom_name
        ? itemMarcomName.toLowerCase().includes(String(marcom_name || "").trim().toLowerCase())
        : true;

      const matchesStatus =
        selectedStatus.length > 0
          ? selectedStatus.some(
              (status) => status.toLowerCase() === String(item.status || "").toLowerCase()
            )
          : true;

      return matchesSearch && matchesYear && matchesmarcom_type && matchesmarcom_name && matchesStatus;
    });
  }, [tableData, debouncedSearchQuery, marcom_type, marcom_name, selectedStatus, selectedYears]);

  // Fixed sorting with numeric comparison for year
  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredData;

    return [...filteredData].sort((a, b) => {
      let valA = a[sortKey] ?? "";
      let valB = b[sortKey] ?? "";

      if (sortKey === "year") {
        valA = parseInt(valA) || 0;
        valB = parseInt(valB) || 0;
        return sortOrder === "asc" ? valA - valB : valB - valA;
      }

      return sortOrder === "asc"
        ? valA.toString().localeCompare(valB.toString(), undefined, { numeric: true, sensitivity: "base" })
        : valB.toString().localeCompare(valA.toString(), undefined, { numeric: true, sensitivity: "base" });
    });
  }, [filteredData, sortKey, sortOrder]);

  const { resetSortAndFilter } = useCRUDWithReset(
    setSortKey,
    setSortOrder,
    {
      searchQuery: { setter: setSearchQuery, resetValue: "" },
      selectedYears: { setter: setSelectedYears, resetValue: [] },
      marcom_type: { setter: setmarcom_type, resetValue: [] },
      marcom_name: { setter: setmarcom_name, resetValue: [] },
      selectedStatus: { setter: setSelectedStatus, resetValue: [] },
    }
  );

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (marcom_typeRef.current && !marcom_typeRef.current.contains(event.target)) {
        setShowmarcom_typeSuggestions(false);
        setMarcom_typeSearch("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const marcom_typeFromData = tableData
      .map(item => item.marcom_type?.trim())
      .filter(val => val && val.length > 0);

    setMarcomOptions(Array.from(new Set(marcom_typeFromData)));
  }, [tableData]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.key === 'Escape' && isAddUserOpen) {
        closePopup();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 's' && isAddUserOpen) {
        e.preventDefault();
        handleSave();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [isAddUserOpen, formData, isEditing]);

  // Sanitize input to prevent XSS
  const sanitizeInput = (input) => {
    if (typeof input !== "string") {
      input = String(input || "");
    }
    return input.trim().replace(/<[^>]*>/g, '');
  };

  // FIXED: handleEdit now properly sets formData without the buggy useEffect overwriting it
  const handleEdit = (item) => {
    const editFormData = {
      id: item.id,
      year: item.year ? String(item.year) : "",
      marcom_type: item.marcom_type || "",
      marcom_name: item.marcom_name || ""
    };
    setFormData(editFormData);
    setSelectedRow(item.id);
    setIsEditing(true);
    setErrors({});
    setIsAddUserOpen(true);
  };

  const handleDelete = async () => {
    if (selectedRow === null) return;

    try {
      await deleteMarcom(selectedRow);
      setTableData((prev) => prev.filter((item) => item.id !== selectedRow));
      resetSortAndFilter()
      setIsDeleteModalOpen(false);
      setSelectedRow(null);
    } catch (err) {
      // console.error("Error deleting marcom:", err);
      // alert(err.message || "Failed to delete marcom");
    }
  };

  // FIXED: handleSave - proper validation that clears errors on valid input, and correct update payload
  const handleSave = async () => {
    const newErrors = {};

    let yearValue = formData.year;
    if (yearValue === null || yearValue === undefined) {
      yearValue = "";
    } else if (typeof yearValue !== "string") {
      yearValue = String(yearValue);
    }

    const sanitizedYear = yearValue.trim();
    const sanitizedmarcom_type = String(formData.marcom_type || "").trim();
    const sanitizedmarcom_name = String(formData.marcom_name || "").trim();

    if (!sanitizedYear) {
      newErrors.year = "Please fill this field";
    } else if (!/^\d{4}$/.test(sanitizedYear)) {
      newErrors.year = "Enter a valid 4-digit year";
    }

    if (!sanitizedmarcom_type) newErrors.marcom_type = "Please fill this field";
    if (!sanitizedmarcom_name) newErrors.marcom_name = "Please fill this field";

    if (sanitizedmarcom_type && sanitizedmarcom_name && sanitizedYear) {
      const isDuplicate = tableData.some(item =>
        item.year?.toString() === sanitizedYear &&
        item.marcom_type?.trim().toLowerCase() === sanitizedmarcom_type.toLowerCase() &&
        item.marcom_name?.trim().toLowerCase() === sanitizedmarcom_name.toLowerCase() &&
        (!isEditing || item.id !== formData.id)
      );

      if (isDuplicate) {
        newErrors.marcom_type = "This combination already exists";
        newErrors.marcom_name = "This combination already exists";
      }
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const payload = {
      year: sanitizeInput(sanitizedYear),
      marcom_type: sanitizeInput(sanitizedmarcom_type),
      marcom_name: sanitizeInput(sanitizedmarcom_name)
    };

    try {
      if (isEditing) {
        if (!formData.id) {
          // alert("Error: No marcom ID found for update");
          return;
        }
        await updateMarcom(formData.id, payload);
        setTableData(prev => prev.map(item =>
          item.id === formData.id ? { ...item, ...payload } : item
        ));
      } else {
        await addMarcom(payload);
        resetSortAndFilter()
        await fetchMarcomData();
      }

      closePopup();
    } catch (err) {
      const errorMessage = err?.message || err?.response?.data?.message || "Failed to save marcom";
      // console.error("Error saving marcom:", err);
      // // alert(errorMessage);
    }
  };

  const handleToggleStatus = async () => {
    if (selectedRow === null) return;

    setLoadingToggle(true);
    
    try {
      await toggleMarcom(selectedRow);
      
      setTableData(prev => prev.map(item =>
        item.id === selectedRow
          ? { ...item, status: item.status === "Active" ? "Inactive" : "Active" }
          : item
      ));
      
      setShowDeactivateModal(false);
      setShowActivateModal(false);
      setSelectedRow(null);
    } catch (err) {
      // console.error("Error toggling status:", err);
      // alert(err.message || "Failed to toggle status");
    } finally {
      setLoadingToggle(false);
    }
  };

  const closePopup = () => {
    setIsAddUserOpen(false);
    setIsEditing(false);
    setSelectedRow(null);
    setFormData({ id: null, year: "", marcom_type: "", marcom_name: "" });
    setErrors({});
  };

  const handleDownloadTemplate = async () => {
    if (!marcomOptions || marcomOptions.length === 0) {
      // alert("Marcom Type list is empty. Please load data first.");
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Marcom");

    sheet.columns = [
      { header: "Year", key: "year", width: 15 },
      { header: "Marcom Type", key: "marcom_type", width: 60 },
      { header: "Marcom Element", key: "marcom_name", width: 30 },
    ];

    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = {
        vertical: "middle",
        horizontal: "left",
        wrapText: true,
      };
    });

    sheet.addRow({
      year: "2024",
      marcom_type: "Branding Total",
      marcom_name: "Dealer Website Design",
    });

    sheet.getColumn("year").eachCell({ includeEmpty: true }, (cell, rowNumber) => {
      if (rowNumber > 1) {
        cell.dataValidation = {
          type: "whole",
          operator: "between",
          formulae: [2015, 2025],
          allowBlank: false,
          showErrorMessage: true,
          errorTitle: "Invalid Year",
          error: "Please enter a year between 2015 and 2025",
        };
      }
    });

    const dropdownValues = marcomOptions.join(",");

    sheet.getColumn("marcom_type").eachCell({ includeEmpty: true }, (cell, rowNumber) => {
      if (rowNumber > 1) {
        cell.dataValidation = {
          type: "list",
          allowBlank: false,
          formulae: [`"${dropdownValues}"`],
          showErrorMessage: true,
          errorTitle: "Invalid Marcom Type",
          error: "Please select a value from the dropdown",
        };
      }
    });

    sheet.eachRow({ includeEmpty: true }, (row) => {
      row.eachCell({ includeEmpty: true }, (cell) => {
        cell.numFmt = "@";
        cell.alignment = {
          horizontal: "left",
          vertical: "middle",
          wrapText: true,
        };
      });
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    saveAs(blob, "Marcom_Bulk_Upload_Template.xlsx");
  };

  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const previewTab = window.open(
      "/bulkupload/marcom",
      "_blank"
    );

    if (!previewTab) {
      // alert("Popup blocked! Please allow popups.");
      return;
    }

    const reader = new FileReader();

    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];

      let rows = XLSX.utils.sheet_to_json(
        workbook.Sheets[sheetName],
        { defval: "" }
      );

      rows = rows.filter((row) =>
        Object.values(row).some((v) => v !== "")
      );

      const finalRows = rows.map((row, index) => ({
        slNo: index + 1,
        year: row["Year"] || "",
        marcomType: row["Marcom Type"] || "",
        marcomName: row["Marcom Name"] || "",
        hasError: !row["Year"] || !row["Marcom Type"],
      }));

      previewTab.postMessage(
        {
          type: "MARCOM_PREVIEW",
          payload: { rows: finalRows },
        },
        "*"
      );
    };

    reader.readAsArrayBuffer(file);
  };

  const handlePreviewAndDownload = async () => {
    if (!filteredData || filteredData.length === 0) {
      // alert("No data available to generate preview");
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Marcom");

    sheet.columns = [
      { header: "Sl. No", key: "slNo", width: 10 },
      { header: "Year", key: "year", width: 15 },
      { header: "Marcom Type", key: "marcomType", width: 75 },
      { header: "Marcom Element", key: "marcomName", width: 75 },
      { header: "Status", key: "status", width: 15 },
    ];

    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });

    filteredData.forEach((item, index) => {
      const row = sheet.addRow({
        slNo: index + 1,
        year: item.year || "",
        marcomType: item.marcom_type || "",
        marcomName: item.marcom_name || "",
        status: item.status || "",
      });

      row.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const file = new File([blob], "Marcom_Preview.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    try {
      const response = await uploadTempFile(file);
      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        // console.warn("Upload succeeded but no file URL returned");
        // alert("Upload succeeded but no preview available.");
      }
    } catch (error) {
      // console.error("Upload failed:", error);
      // alert("Failed to upload file for preview. Check console for details.");
    }
  };
useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
    handleSave()
  },

  onCancel: () => {
    closePopup()
  },
});

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300  ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full  transition-all duration-300 ease-in-out ">
            {/* Error Display */}
            {error && (
              <div className="mb-2 p-4 bg-red-50 border border-red-200 flex items-center justify-between">
                <span className="text-red-600">{error}</span>
                <button 
                  onClick={() => setError(null)}
                  className="text-red-600 hover:text-red-800"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Heading */}
            <div className="flex items-center justify-between mb-2 flex-wrap gap-4">
              <h2 className="text-base font-medium font-VolvoNovum text-center text-darkblue1 flex items-center justify-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
                />
                PDP Data / Marcom   
              </h2>
            </div>

            {/* Tab Navigation */}
            <div className="flex w-full mb-4  overflow-hidden ">
              <button
                onClick={() => setActiveView("branding")}
                className={`flex-1 py-2 text-sm font-medium transition ${
                  activeView === "branding"
                    ? "bg-darkblue1 text-white"
                    : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                }`}
              >
                Branding
              </button>

              <button
                onClick={() => setActiveView("marketing")}
                className={`flex-1 py-2 text-sm font-medium transition ${
                  activeView === "marketing"
                    ? "bg-darkblue1 text-white"
                    : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                }`}
              >
                Marketing
              </button>
            </div>

            {activeView === "branding" && (
              <div>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 md:gap-12 lg:gap-18 mb-2">
                  <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">      
                    {/* Controls: Search + Filters + Actions */}
                    <Searchinput
                      onChange={(e) => {
                        setSearchQuery(e.target.value);
                      }}
                      value={searchQuery}
                      placeholder="Search"
                      className="w-[1/2]"
                      iconColor="text-black/"
                      bgColor="bg-FrostWhite"
                      borderColor="border-black/60"
                      textColor="text-black"
                      shadow="shadow-none"
                      inputPadding="pl-6 pr-3 py-1.5"
                      iconSize="w-3 h-3"
                      iconLeft="left-3"
                      inputWidth="w-full"
                      focusRing="focus:ring-1 focus:ring-black/60"
                      hoverInputClasses="hover:bg-white hover:border-black/60"
                    />

                    <Filter
                      name="year"
                      placeholder="Year"
                      options={yearOptions}
                      className="w-[120px]"
                      placeholderColor="text-black"
                      buttonBorderColor="border-black/60"
                      dropdownBgColor="bg-white"
                      dropdownTextColor="text-black"
                      dropdownHoverColor="hover:bg-lightBlue/50"
                      dropdownBorderColor="border-black/60"
                      closedBgColor="bg-white"
                      hoverRingColor="ring-black"
                      openBgColor="bg-white"
                      textColor="text-black"
                      value={selectedYears}
                      onChange={(name, value) => {
                        setSelectedYears(value);
                      }}
                    />

                    <Filter
                      name="Marcom  Type"
                      pla
                      options={marcomOptions} 
                      value={marcom_type}
                      onChange={(name, selected) => {
                        setmarcom_type(selected)
                      }}
                      placeholder="Marcom Type"
                      multiSelect={true}
                      customWidth="w-[320px]"
                      buttonBorderColor="border-black/60"
                      dropdownBgColor="bg-white"
                      dropdownTextColor="text-black"
                      dropdownHoverColor="hover:bg-lightBlue/50"
                      dropdownBorderColor="border-black/60"
                      placeholderColor="text-black"
                      textColor="text-black"
                    />

                    <Filter
                      name="status"
                      placeholder="Status"
                      options={statusOptions}
                      value={selectedStatus}
                      customWidth="w-[80px]"
                      placeholderColor="text-black"
                      buttonBorderColor="border-black/60"
                      dropdownBgColor="bg-white"
                      dropdownTextColor="text-black"
                      dropdownHoverColor="hover:bg-lightBlue/50"
                      dropdownBorderColor="border-black/60"
                      closedBgColor="bg-white"
                      hoverRingColor="ring-black"
                      openBgColor="bg-white"
                      textColor="text-black"
                      onChange={(name, value) => {
                        setSelectedStatus(value);
                      }}
                    />
                  </div>

                  {/* Right Side: Action Buttons */}
                  <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                    {/* Add Dropdown */}
                    <div className="relative w-full sm:w-[190px]" ref={dropdownRef}>
                      <button
                        onClick={() => setOpen(!open)}
                        className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-1.5 text-xs  flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
                      >
                        <Plus className="w-3 h-3 stroke-[3]" />
                        Add New
                      </button>

                      {open && (
                        <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1  shadow-lg z-50">
                          <button
                            className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                            onClick={() => {
                              setIsAddUserOpen(true);
                              setOpen(false);
                            }}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                              <path d="M9.05461 9.0536C9.72985 8.37847 10.6456 7.99922 11.6005 7.9993C12.5554 7.99937 13.4711 8.37876 14.1462 9.054C14.8213 9.72924 15.2006 10.645 15.2005 11.5999C15.2004 12.5547 14.821 13.4705 14.1458 14.1456C14.0704 14.2185 13.9693 14.2588 13.8644 14.2579C13.7596 14.257 13.6592 14.2149 13.5851 14.1407C13.5109 14.0666 13.4689 13.9662 13.4679 13.8614C13.467 13.7565 13.5073 13.6554 13.5802 13.58C13.9718 13.1884 14.2384 12.6895 14.3464 12.1463C14.4544 11.6032 14.399 11.0402 14.187 10.5286C13.9751 10.017 13.6162 9.57972 13.1558 9.27207C12.6953 8.96441 12.154 8.8002 11.6002 8.8002C11.0464 8.8002 10.5051 8.96441 10.0446 9.27207C9.58419 9.57972 9.22531 10.017 9.01337 10.5286C8.80144 11.0402 8.74597 11.6032 8.85399 12.1463C8.96201 12.6895 9.22865 13.1884 9.62021 13.58C9.69307 13.6554 9.73339 13.7565 9.73248 13.8614C9.73157 13.9662 9.6895 14.0666 9.61534 14.1407C9.54117 14.2149 9.44085 14.257 9.33597 14.2579C9.23109 14.2588 9.13005 14.2185 9.05461 14.1456C8.72019 13.8113 8.45492 13.4144 8.27392 12.9775C8.09293 12.5407 7.99978 12.0725 7.99978 11.5996C7.99978 11.1267 8.09293 10.6585 8.27392 10.2217C8.45492 9.78482 8.72019 9.38791 9.05461 9.0536ZM10.185 10.1848C10.5637 9.8266 11.0671 9.63023 11.5883 9.63746C12.1095 9.6447 12.6073 9.85495 12.9759 10.2235C13.3445 10.5921 13.5547 11.0899 13.5619 11.6111C13.5692 12.1323 13.3728 12.6357 13.0146 13.0144C12.9395 13.0895 12.8376 13.1317 12.7314 13.1317C12.6252 13.1317 12.5233 13.0895 12.4482 13.0144C12.3731 12.9393 12.3309 12.8374 12.3309 12.7312C12.3309 12.625 12.3731 12.5231 12.4482 12.448C12.6165 12.2802 12.7311 12.0662 12.7777 11.8332C12.8243 11.6002 12.8007 11.3586 12.7099 11.139C12.6191 10.9194 12.4652 10.7317 12.2677 10.5996C12.0701 10.4675 11.8378 10.397 11.6002 10.397C11.3626 10.397 11.1303 10.4675 10.9328 10.5996C10.7352 10.7317 10.5813 10.9194 10.4905 11.139C10.3997 11.3586 10.3761 11.6002 10.4227 11.8332C10.4693 12.0662 10.584 12.2802 10.7522 12.448C10.8264 12.5234 10.8677 12.6251 10.8672 12.7308C10.8668 12.8366 10.8245 12.9379 10.7496 13.0126C10.6748 13.0874 10.5735 13.1295 10.4677 13.1298C10.3619 13.1302 10.2603 13.0887 10.185 13.0144C9.99912 12.8287 9.85165 12.6081 9.75104 12.3654C9.65042 12.1226 9.59864 11.8624 9.59864 11.5996C9.59864 11.3368 9.65042 11.0766 9.75104 10.8338C9.85165 10.5911 9.99912 10.3705 10.185 10.1848ZM8.00021 8C8.28901 8 8.56021 8.0768 8.79381 8.2112C8.57222 8.39437 8.36912 8.59881 8.18741 8.8216C8.12608 8.80705 8.06324 8.7998 8.00021 8.8H2.80021C2.58804 8.8 2.38455 8.88429 2.23452 9.03431C2.08449 9.18434 2.00021 9.38783 2.00021 9.6V9.6496L2.00581 9.7296C2.04922 10.1131 2.18602 10.4801 2.40421 10.7984C2.79221 11.36 3.61061 12 5.40021 12C6.16341 12 6.74981 11.884 7.20181 11.7072C7.20874 11.9867 7.24074 12.2587 7.29781 12.5232C6.78101 12.696 6.15621 12.8 5.40021 12.8C3.38981 12.8 2.30741 12.064 1.74661 11.252C1.45129 10.8223 1.26688 10.3262 1.20981 9.808C1.19941 9.7072 1.20021 9.66 1.20021 9.6C1.20021 9.17565 1.36878 8.76869 1.66884 8.46863C1.9689 8.16857 2.37586 8 2.80021 8H8.00021ZM5.40021 2C6.08977 2 6.75109 2.27393 7.23869 2.76152C7.72628 3.24912 8.00021 3.91044 8.00021 4.6C8.00021 5.28956 7.72628 5.95088 7.23869 6.43848C6.75109 6.92607 6.08977 7.2 5.40021 7.2C4.71065 7.2 4.04933 6.92607 3.56173 6.43848C3.07414 5.95088 2.80021 5.28956 2.80021 4.6C2.80021 3.91044 3.07414 3.24912 3.56173 2.76152C4.04933 2.27393 4.71065 2 5.40021 2ZM11.6002 3.2C12.1306 3.2 12.6393 3.41071 13.0144 3.78579C13.3895 4.16086 13.6002 4.66957 13.6002 5.2C13.6002 5.73043 13.3895 6.23914 13.0144 6.61421C12.6393 6.98929 12.1306 7.2 11.6002 7.2C11.0698 7.2 10.5611 6.98929 10.186 6.61421C9.81092 6.23914 9.60021 5.73043 9.60021 5.2C9.60021 4.66957 9.81092 4.16086 10.186 3.78579C10.5611 3.41071 11.0698 3.2 11.6002 3.2ZM5.40021 2.8C4.92282 2.8 4.46498 2.98964 4.12742 3.32721C3.78985 3.66477 3.60021 4.12261 3.60021 4.6C3.60021 5.07739 3.78985 5.53523 4.12742 5.87279C4.46498 6.21036 4.92282 6.4 5.40021 6.4C5.8776 6.4 6.33544 6.21036 6.673 5.87279C7.01057 5.53523 7.20021 5.07739 7.20021 4.6C7.20021 4.12261 7.01057 3.66477 6.673 3.32721C6.33544 2.98964 5.8776 2.8 5.40021 2.8ZM11.6002 4C11.2819 4 10.9767 4.12643 10.7517 4.35147C10.5266 4.57652 10.4002 4.88174 10.4002 5.2C10.4002 5.51826 10.5266 5.82348 10.7517 6.04853C10.9767 6.27357 11.2819 6.4 11.6002 6.4C11.9185 6.4 12.2237 6.27357 12.4487 6.04853C12.6738 5.82348 12.8002 5.51826 12.8002 5.2C12.8002 4.88174 12.6738 4.57652 12.4487 4.35147C12.2237 4.12643 11.9185 4 11.6002 4Z" fill="black"/>
                            </svg>
                            Add Marcom
                          </button>
                          
                          <button
                            onClick={() => navigate("/bulkupload/marcom")}
                            className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                              <path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
                            </svg>
                            Bulk Upload
                          </button>

                          <input
                            type="file"
                            ref={fileInputRef}
                            className="hidden"
                            accept=".xlsx,.xls"
                            onChange={handleBulkUpload}
                          />
                          
                          <button
                            onClick={() => {
                              handleDownloadTemplate();
                              setOpen(false);
                            }}
                            className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1  whitespace-nowrap"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            Bulk upload Template
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Download Button */}
                    <button
                      onClick={handlePreviewAndDownload}
                      className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1  flex items-center gap-1 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
                        <path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D"/>
                      </svg>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" className="w-3 h-3 hidden group-hover:block">
                        <path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white"/>
                      </svg>
                      <span className="font-semibold">Download</span>
                    </button>
                  </div>
                </div>

              {/* ✅ RESPONSIVE TABLE SECTION */}
                <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
                  <div
                  ref={tableContainerRef}
                    className="overflow-y-auto relative"
                    style={{
                      scrollbarWidth: "none",
                      msOverflowStyle: "none",
                      maxHeight: sortedData.length > 8 ? "calc(100vh - 240px)" : "auto",
                    }}
                    onScroll={handleTableScroll}
                  >
                    <style jsx>{`
                      div::-webkit-scrollbar {
                        display: none;
                      }
                    `}</style>

                    <table className="w-full text-xs whitespace-nowrap border-collapse">
                      <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                        <tr>
                          {/* Year - w-[20%] */}
                          <th
                            className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%] cursor-pointer select-none hover:bg-Dustyblue/80 transition"
                            onClick={() => handleSort("year")}
                          >
                            <div className="flex items-center gap-1">
                              <span className="whitespace-nowrap">Year</span>
                              {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}


                              {sortKey === "year" && sortOrder === "asc" && (
                                <ChevronUp className="w-3 h-3 text-white flex-shrink-0" />
                              )}
                              {sortKey === "year" && sortOrder === "desc" && (
                                <ChevronDown className="w-3 h-3 text-white flex-shrink-0" />
                              )}
                            </div>
                          </th>

                          {/* Marcom Type - w-[35%] */}
                          <th
                            className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[35%] cursor-pointer select-none hover:bg-Dustyblue/80 transition"
                            onClick={() => handleSort("marcom_type")}
                          >
                            <div className="flex items-center gap-1">
                              <span className="whitespace-nowrap">Marcom Type</span>
                              {sortKey === "marcom_type" && sortOrder === "asc" && (
                                <ChevronDown className="w-3 h-3 text-white flex-shrink-0" />
                              )}
                              {sortKey === "marcom_type" && sortOrder === "desc" && (
                                <ChevronUp className="w-3 h-3 text-white flex-shrink-0" />
                              )}
                            </div>
                          </th>

                          {/* Marcom Name - w-[35%] */}
                          <th
                            className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[35%] cursor-pointer select-none hover:bg-Dustyblue/80 transition"
                            onClick={() => handleSort("marcom_name")}
                          >
                            <div className="flex items-center gap-1">
                              <span className="whitespace-nowrap">Marcom Element</span>
                              {sortKey === "marcom_name" && sortOrder === "asc" && (
                                <ChevronDown className="w-3 h-3 text-white flex-shrink-0" />
                              )}
                              {sortKey === "marcom_name" && sortOrder === "desc" && (
                                <ChevronUp className="w-3 h-3 text-white flex-shrink-0" />
                              )}
                            </div>
                          </th>

                          {/* Actions - w-[10%] */}
                          <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 text-center font-medium w-[10%]">
                            Actions
                          </th>
                        </tr>
                      </thead>

                      <tbody className="text-black">
                        {isLoading && tableData.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="px-2 py-8 text-center text-gray-500">
                              <div className="flex items-center justify-center gap-2">
                                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                                <span>Loading marcom...</span>
                              </div>
                            </td>
                          </tr>
                        ) : sortedData.length > 0 ? (
                          sortedData.map((item) => (
                            <tr
                              key={item.id}
                              className={`hover:bg-lightBlue/50 text-xs ${
                                item.status === "Active" ? "text-black" : "text-gray-400"
                              }`}
                            >
                              {/* Year */}
                              <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs">
                                <div className="relative">
                                  <p
                                    className="truncate max-w-[5rem] cursor-pointer"
                                    onMouseEnter={() => {
                                      if (item.year && item.year.toString().length > 5)
                                        setHoveredCell(item.id + "-year");
                                    }}
                                    onMouseLeave={() => setHoveredCell(null)}
                                  >
                                    {item.year || "-"}
                                  </p>

                                  {hoveredCell === item.id + "-year" && (
                                    <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-nowrap transform -translate-x-1/2 z-0">
                                      {item.year}
                                    </span>
                                  )}
                                </div>
                              </td>

                              {/* Marcom Type */}
                              <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs">
                                <div className="relative">
                                  <p
                                    className="truncate max-w-[20rem] cursor-pointer"
                                    onMouseEnter={() => {
                                      if (item.marcom_type && item.marcom_type.length > 40)
                                        setHoveredCell(item.id + "-marcom_type");
                                    }}
                                    onMouseLeave={() => setHoveredCell(null)}
                                  >
                                    {item.marcom_type || "-"}
                                  </p>

                                  {hoveredCell === item.id + "-marcom_type" && (
                                    <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-normal max-w-[15rem] transform -translate-x-1/2 z-0">
                                      {item.marcom_type}
                                    </span>
                                  )}
                                </div>
                              </td>

                              {/* Marcom Name */}
                              <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs">
                                <div className="relative">
                                  <p
                                    className="truncate max-w-[20rem] cursor-pointer"
                                    onMouseEnter={() => {
                                      if (item.marcom_name && item.marcom_name.length > 40)
                                        setHoveredCell(item.id + "-marcom_name");
                                    }}
                                    onMouseLeave={() => setHoveredCell(null)}
                                  >
                                    {item.marcom_name || "-"}
                                  </p>

                                  {hoveredCell === item.id + "-marcom_name" && (
                                    <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-normal max-w-[15rem] transform -translate-x-1/2 z-0">
                                      {item.marcom_name}
                                    </span>
                                  )}
                                </div>
                              </td>

                              {/* Actions */}
                              <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                                <div className="flex items-center justify-center gap-2">
                                  {/* Edit */}
                                  <div className="relative group inline-block">
                                    <button onClick={() => handleEdit(item)} className="p-1 hover:scale-110 transition">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                        <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                                        <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                                      </svg>
                                    </button>
                                    <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 z-0 whitespace-nowrap">
                                      Edit
                                    </span>
                                  </div>

                                  {/* Status Toggle */}
                                  <div className="relative group inline-block">
                                    <button
                                      onClick={() => {
                                        setSelectedRow(item.id);
                                        if (item.status === "Active") {
                                          setShowDeactivateModal(true);
                                        } else {
                                          setShowActivateModal(true);
                                        }
                                      }}
                                      className="p-1 hover:scale-110 transition"
                                    >
                                      {item.status === "Active" ? (
                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
                                          <path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                        </svg>
                                      ) : (
                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none">
                                          <g clipPath="url(#clip0_5669_3080)">
                                            <path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                          </g>
                                          <defs>
                                            <clipPath id="clip0_5669_3080">
                                              <rect width="24" height="24" fill="white"/>
                                            </clipPath>
                                          </defs>
                                        </svg>
                                      )}
                                    </button>

                                    <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                      {item.status === "Active" ? "Deactivate" : "Activate"}
                                    </span>
                                  </div>

                                  {/* Delete */}
                                  <div className="relative group inline-block">
                                    <button
                                      onClick={() => {
                                        setSelectedRow(item.id);
                                        setIsDeleteModalOpen(true);
                                      }}
                                      className="p-1 hover:scale-110 transition"
                                    >
                                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                                        <g clipPath="url(#clip0_6398_313)">
                                          <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                                        </g>
                                        <defs>
                                          <clipPath id="clip0_6398_313">
                                            <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                                          </clipPath>
                                        </defs>
                                      </svg>
                                    </button>
                                    <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 z-0 whitespace-nowrap">
                                      Delete
                                    </span>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={4} className="px-2 py-8 text-center italic text-gray-500">
                              No data found
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                   {showScrollButtons && (
            <div className="fixed bottom-14 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

                </div>
              </div>
            )}

            {activeView === "marketing" && (
              <div>
                <MarketingMarcom/>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
          <div
          ref={popupRef} 
          className="bg-white  p-6 w-full max-w-xl relative">
            <h2 className="text-base font-semibold text-center mb-4 text-MediumGrey">
              {isEditing ? "Edit Marcom" : "Add Marcom"}
            </h2>
            <button
              onClick={closePopup}
              className="absolute top-3 right-4 text-red-600 font-bold text-xl"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
                role="img"
                aria-label="Error icon"
              >
                <circle cx="10" cy="10" r="8" fill="#BF2012" />
                <path
                  d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>
            </button>

            <div className="grid grid-cols-1 gap-2">
              <div className="col-span-1">
                <label className="text-xs font-medium text-black/70">Year <span className=" text-red1">*</span></label>
                <input
                  type="text"
                  value={formData.year}
                  tabIndex={0}
                  onChange={(e) => {
                    const value = e.target.value;
                     if (errors.year) {
          setErrors({ ...errors, year: "" });
        }
                    if (/^\d{0,4}$/.test(value)) {
                      setFormData({ ...formData, year: value });
                    }
                  }}
                  maxLength={4}
                  className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                    errors.year ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                  placeholder="Enter Year (e.g., 2024)"
                />
                {errors.year && <p className="text-red1 text-xs mt-1">{errors.year}</p>}
              </div>

              <div className="w-full relative" ref={marcom_typeRef}>
                <label className="text-xs font-medium text-black/70">Marcom Type <span className=" text-red1">*</span></label>
                <div className="w-full relative">
                  {((!isEditing && tableData.length > 0) || (isEditing && tableData.length > 1)) ? (
                    <>
                      <div className="relative w-full">
                        <input
                          type="text"
                          value={formData.marcom_type}
                          tabIndex={0}
                          onChange={(e) => {
                             if (errors.marcom_type) {
          setErrors({ ...errors, marcom_type: "" });
        }
                            setFormData({ ...formData, marcom_type: e.target.value });
                            setShowmarcom_typeSuggestions(true);
                            setErrors({ ...errors, marcom_type: "" });
                          }}
 onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setShowmarcom_typeSuggestions(true);
    }

   
    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowmarcom_typeSuggestions(false);
    }

  }}
                         onClick={() => setShowmarcom_typeSuggestions(true)}
                          placeholder="Select or type Marcom Type"
                          className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
                            ${showmarcom_typeSuggestions ? "border-b-white" : ""}
                            ${errors.marcom_type ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                          `}
                        />
                       
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"
                          onClick={() => setShowmarcom_typeSuggestions((prev) => !prev)}
                          className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
                            showmarcom_typeSuggestions ? "rotate-180" : "rotate-0"
                          }`}>
                          <path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
                        </svg>
                      </div>

               {/* Marcom Type Suggestions */}
{showmarcom_typeSuggestions && (
  <div
    ref={marcom_typeRef}
    className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {/* Search input (only show if more than 5 options) */}
    {Array.from(new Set(tableData.map(item => item.marcom_type))).filter(Boolean).length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5 border-black/10 z-10">
        <input
          type="text"
          placeholder="Search Marcom Type..."
          value={marcom_typeSearch}
          onChange={(e) => setMarcom_typeSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
        />
      </div>
    )}

    {/* Options list */}
    {Array.from(new Set(tableData.map(item => item.marcom_type)))
      .filter(Boolean) // remove undefined/null/empty
      .filter(option =>
        marcom_typeSearch
          ? String(option).toLowerCase().includes(marcom_typeSearch.toLowerCase())
          : true
      )
      .filter(option => option !== formData.marcom_type) // exclude current value
      .sort((a, b) => a.localeCompare(b))
      .map((option, idx) => (
       <div
  key={idx}
  tabIndex={0}
  data-marcom-option
  className={`px-3 py-1.5 text-xs cursor-pointer transition
  ${
    option === formData.marcom_type
      ? "bg-lightBlue/30 font-medium"
      : "hover:bg-gray-100"
  }`}

  onKeyDown={(e) => {

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-marcom-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation();
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      setShowmarcom_typeSuggestions(false);
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setFormData({ ...formData, marcom_type: option });
      setShowmarcom_typeSuggestions(false);
      setMarcom_typeSearch("");
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault();
    setFormData({ ...formData, marcom_type: option });
    setShowmarcom_typeSuggestions(false);
    setMarcom_typeSearch("");
  }}
>
  {option}
</div>
      ))}

    {/* No results message */}
    {Array.from(new Set(tableData.map(item => item.marcom_type)))
      .filter(Boolean)
      .filter(option =>
        marcom_typeSearch
          ? String(option).toLowerCase().includes(marcom_typeSearch.toLowerCase())
          : true
      ).length === 0 && (
        <div className="px-3 py-2 text-xs text-gray-400 italic">
          No Marcom Types found
        </div>
    )}
  </div>
)}


                    </>
                  ) : (
                    <input
                      type="text"
                      value={formData.marcom_type}
                      onChange={(e) => {
                         if (errors.marcom_type) {
          setErrors({ ...errors, marcom_type: "" });
        }
                        setFormData({ ...formData, marcom_type: e.target.value });
                        setErrors({ ...errors, marcom_type: "" });
                      }}
                      placeholder="Enter Marcom Type"
                      className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                        errors.marcom_type ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                      }`}
                    />
                  )}
                  {errors.marcom_type && <p className="text-red1 text-xs mt-1">{errors.marcom_type}</p>}
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-black/70">Marcom Name <span className=" text-red1">*</span></label>
                <input
                  type="text"
                  value={formData.marcom_name}
                  onChange={(e) => {
                     if (errors.marcom_name) {
          setErrors({ ...errors, marcom_name: "" });
        }
                    setFormData({ ...formData, marcom_name: e.target.value });
                    setErrors({ ...errors, marcom_name: "" });
                  }}
                  placeholder="Enter Marcom Name"
                  className={`border  px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                    errors.marcom_name ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                  tabIndex={0}
                />
                {errors.marcom_name && (
                  <p className="text-red1 text-xs mt-1">{errors.marcom_name}</p>
                )}
              </div>
            </div>
           
            <button
              onClick={handleSave}
              className="mt-6 bg-darkblue1 text-xs font-medium text-white px-8 py-1.5  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto"
            >
              Save
            </button>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setSelectedRow(null);
        }}
        onConfirm={handleDelete}
      />

      {/* Activate Modal */}
      {showActivateModal && selectedRow !== null && (
        <ActivateStatus
          isOpen={showActivateModal}
          loading={loadingToggle}
          onClose={() => {
            if (!loadingToggle) {
              setShowActivateModal(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={handleToggleStatus}
        />
      )}

      {/* Deactivate Modal */}
      {showDeactivateModal && selectedRow !== null && (
        <DeactivateStatus
          isOpen={showDeactivateModal}
          loading={loadingToggle}
          onClose={() => {
            if (!loadingToggle) {
              setShowDeactivateModal(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={handleToggleStatus}
        />
      )}

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept=".csv,.xlsx,.xls"
      />
    </div>
  )
}

export default Marcom;