import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import DeleteModal from "../../../../../Components/DeleteModal"
import * as XLSX from "xlsx";
import ActivateStatus from "../../../../../Components/ActivateStatus"
import DeactivateStatus from "../../../../../Components/DeactivateStatus"
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { uploadTempFile } from "../../../../../services/download/bluckDownload.service"
import useCRUDWithReset from "../../../../../util/useCRUDWithReset"
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation"
import {
  addSegmentPriority,
  getAllSegmentPriorities,
  updateSegmentPriority,
  toggleSegmentPriority,
  deleteSegmentPriority,
} from "../../../../../services/pdpMaster/segmentPriority.service"
import Filter from "../../../../../Components/Filter"
import { ChevronUp } from "lucide-react"
import { ChevronDown } from "lucide-react";
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
const useDebounce = (value, delay) => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
};

function SegmentPriority() {
  const [menuOpen, setMenuOpen] = useState(false)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const dropdownRef = useRef(null)
  const [tableData, setTableData] = useState([])
  const [selectedYears, setSelectedYears] = useState([]);
  const popupRef=useRef(null)
  const yearOptions = useMemo(() => {
    const years = new Set(tableData.map(item => item.year).filter(Boolean));
    return Array.from(years).sort((a, b) => parseInt(b) - parseInt(a));
  }, [tableData]);

  const [formData, setFormData] = useState({ 
    id: null,
    year: "",
    segment_focus_area: "" 
  });
  const [isEditing, setIsEditing] = useState(false)
  const [selectedRow, setSelectedRow] = useState(null)
  const [errors, setErrors] = useState({})
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedStatus, setSelectedStatus] = useState([]);
  const statusOptions = ["Active", "Inactive"];

  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [loadingToggle, setLoadingToggle] = useState(false);
  const [hoveredCell, setHoveredCell] = useState(null);
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null);

  const fileInputRef = useRef(null)

  const debouncedSearchQuery = useDebounce(searchQuery, 300);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  useEffect(() => {
    fetchSegmentPriorityData();
  }, []);

  const fetchSegmentPriorityData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await getAllSegmentPriorities();
      
      if (response) {
        const dataArray = Array.isArray(response) ? response : (response.data || []);
        
        if (!Array.isArray(dataArray)) {
          throw new Error("Invalid response format from API");
        }
        
        const transformedData = dataArray.map(item => ({
          id: item.id,
          year: item.year || "",
          segment_focus_area: item.segment_focus_area,
          status: item.isActive === 1 ? "Active" : "Inactive"
        }));
        setTableData(transformedData);
      }
    } catch (err) {
      // console.error("Error fetching segment priority data:", err);
      setError(err.message || "Failed to fetch segment priority data");
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsLoading(true);
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      if (jsonData.length === 0) {
        throw new Error("The file is empty or has no valid data");
      }

      const validatedData = jsonData.map((row, index) => {
        const year = row["Year"];
        const segmentName = row["Segment Name"];
        
        if (!year || String(year).trim() === "") {
          throw new Error(`Row ${index + 2}: Year is required`);
        }
        if (!/^\d{4}$/.test(String(year).trim())) {
          throw new Error(`Row ${index + 2}: Year must be a 4-digit number`);
        }
        if (!segmentName || String(segmentName).trim() === "") {
          throw new Error(`Row ${index + 2}: Segment Name is required`);
        }
        return {
          year: String(year).trim(),
          segment_focus_area: String(segmentName).trim()
        };
      });

      let successCount = 0;
      let errorCount = 0;
      const errors = [];

      for (let i = 0; i < validatedData.length; i++) {
        try {
          await addSegmentPriority(validatedData[i]);
          successCount++;
        } catch (err) {
          errorCount++;
          errors.push(`Row ${i + 2}: ${err.message}`);
        }
      }
      
      await fetchSegmentPriorityData();
      
      if (errorCount === 0) {
        // alert(`Successfully uploaded ${successCount} segment(s)`);
      } else {
        // alert(`Upload completed with ${successCount} success and ${errorCount} error(s).\n\nErrors:\n${errors.join('\n')}`);
      }
    } catch (error) {
      // console.error("Bulk upload error:", error);
      // alert(error.message || "Failed to upload file");
    } finally {
      setIsLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const filteredData = useMemo(() => {
    return tableData?.filter((item) => {
      const matchesSearch = debouncedSearchQuery
        ? Object.values(item).some((val) =>
            String(val || "")
              .toLowerCase()
              .includes(debouncedSearchQuery.trim().toLowerCase())
          )
        : true;

      const matchesStatus =
        selectedStatus.length > 0
          ? selectedStatus.includes(item.status)
          : true;

      const matchesYear = selectedYears.length
        ? selectedYears.some((year) => String(year) === String(item.year))
        : true;

      return matchesSearch && matchesStatus && matchesYear;
    }) || [];
  }, [tableData, debouncedSearchQuery, selectedStatus, selectedYears]);

  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc");
        return;
      }
      if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
        return;
      }
    }
    setSortKey(key);
    setSortOrder("asc");
  };

  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredData;

    return [...filteredData].sort((a, b) => {
      let valA = a[sortKey] ?? "";
      let valB = b[sortKey] ?? "";

      if (sortKey === "year") {
        valA = parseInt(valA) || 0;
        valB = parseInt(valB) || 0;
        return sortOrder === "asc" ? valA - valB : valB - valA;
      }

      const strA = valA.toString().toLowerCase();
      const strB = valB.toString().toLowerCase();

      return sortOrder === "asc"
        ? strA.localeCompare(strB, undefined, { numeric: true, sensitivity: "base" })
        : strB.localeCompare(strA, undefined, { numeric: true, sensitivity: "base" });
    });
  }, [filteredData, sortKey, sortOrder]);
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchQuery: { setter: setSearchQuery, resetValue: "" },
    selectedYears: { setter: setSelectedYears, resetValue: [] },
    selectedStatus :{setter :setSelectedStatus ,resetValue :[]}
  }
);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.key === 'Escape' && isAddUserOpen) {
        closePopup();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 's' && isAddUserOpen) {
        e.preventDefault();
        handleSave();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [isAddUserOpen, formData, isEditing]);

  const sanitizeInput = (input) => {
    return input.trim().replace(/<[^>]*>/g, '');
  };

  const handleEdit = (item) => {
    setFormData({
      id: item.id,
      year: String(item.year) || "",
      segment_focus_area: item.segment_focus_area
    });
    setSelectedRow(item.id);
    setIsEditing(true);
    setErrors({});
    setIsAddUserOpen(true);
  };

  const handleDelete = async () => {
    if (selectedRow === null) return;

    try {
      await deleteSegmentPriority(selectedRow);
      setTableData((prev) => prev.filter((item) => item.id !== selectedRow));
      resetSortAndFilter()
      setIsDeleteModalOpen(false);
      setSelectedRow(null);
    } catch (err) {
      // console.error("Error deleting segment priority:", err);
      // alert(err.message || "Failed to delete segment priority");
    }
  };

  const handleSave = async () => {
    const newErrors = {};

    const sanitizedYear = String(formData.year)?.trim();
    const sanitizedSegment = formData.segment_focus_area?.trim();

    if (!sanitizedYear) {
      newErrors.year = "Please fill this field";
    } else if (!/^\d{4}$/.test(sanitizedYear)) {
      newErrors.year = "Enter a valid 4-digit year";
    }

    if (!sanitizedSegment) {
      newErrors.segment_focus_area = "Please fill this field";
        }

    const isDuplicate = tableData.some(item => 
      item.year === formData.year &&
      item.segment_focus_area.toLowerCase() === sanitizedSegment.toLowerCase() && 
      (!isEditing || item.id !== formData.id)
    );
    
    if (isDuplicate) {
      newErrors.segment_focus_area = "This combination already exists";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      const payload = {
        year: sanitizeInput(formData.year),
        segment_focus_area: sanitizeInput(formData.segment_focus_area)
      };

      if (isEditing) {
        await updateSegmentPriority(formData.id, payload);
        
        // ✅ FIX: Update tableData immediately with complete item data
        setTableData(prev => prev.map(item =>
          item.id === formData.id 
            ? { 
                ...item,  // Keep all existing properties (including status, id, etc.)
                ...payload  // Override with new values
              } 
            : item
        ));
      } else {
        await addSegmentPriority(payload);
        resetSortAndFilter()
        await fetchSegmentPriorityData();
      }

      closePopup();
    } catch (err) {
      setErrors((prev) => ({ ...prev, submit: err.message || "Failed to save segment priority. Please try again." }));
    }
  };

  const handleToggleStatus = async () => {
    if (selectedRow === null) return;

    setLoadingToggle(true);
    
    try {
      await toggleSegmentPriority(selectedRow);
      
      // ✅ FIX: Update tableData immediately
      setTableData(prev => prev.map(item =>
        item.id === selectedRow
          ? { ...item, status: item.status === "Active" ? "Inactive" : "Active" }
          : item
      ));
      
      setShowDeactivateModal(false);
      setShowActivateModal(false);
      setSelectedRow(null);
    } catch (err) {
      // console.error("Error toggling status:", err);
      // alert(err.message || "Failed to toggle status");
    } finally {
      setLoadingToggle(false);
    }
  };

  const closePopup = () => {
    setIsAddUserOpen(false);
    setIsEditing(false);
    setSelectedRow(null);
    setFormData({ id: null, year: "", segment_focus_area: "" });
    setErrors({});
  };

  const handleDownloadTemplate = async () => {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Segment Priority");

    sheet.columns = [
      { header: "Year", key: "year", width: 15 },
      { header: "Segment Name", key: "segment_name", width: 40 },
    ];

    const headerRow = sheet.getRow(1);
    headerRow.eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" };
      cell.protection = { locked: true };
    });

    const sampleRow = sheet.addRow({
      year: "2024",
      segment_name: "GPE (General Production Equipment)",
    });
    sampleRow.eachCell((cell) => {
      cell.protection = { locked: false };
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });

    for (let row = 3; row <= 1000; row++) {
      const rowData = sheet.getRow(row);
      for (let col = 1; col <= 2; col++) {
        rowData.getCell(col).protection = { locked: false };
        rowData.getCell(col).alignment = { vertical: "middle", horizontal: "left" };
      }
    }

    sheet.dataValidations.add("A2:A1000", {
      type: "list",
      allowBlank: false,
      formulae: [`"2015,2016,2017,2018,2019,2020,2021,2022,2023,2024"`],
      showErrorMessage: true,
      errorTitle: "Invalid Year",
      error: "Please enter a year between 2015 and 2024",
    });

    await sheet.protect("12345", {
      selectLockedCells: true,
      selectUnlockedCells: true,
      insertRows: true,
      deleteRows: true,
      formatColumns: true,
      formatRows: true,
    });

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(
      new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }),
      "Segment_Priority_Bulk_Upload_Template.xlsx"
    );
  };

  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const previewTab = window.open("/bulkupload/segment-priority", "_blank");
    if (!previewTab) {
      // alert("Popup blocked! Please allow popups.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];

      let rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });

      rows = rows.filter((row) => Object.values(row).some((v) => v !== ""));

      const finalRows = rows.map((row) => ({
        year: row["Year"] || "",
        segmentName: row["Segment Name"] || "",
        hasError: !row["Year"] || !row["Segment Name"],
      }));

      previewTab.postMessage(
        {
          type: "SEGMENT_PRIORITY_PREVIEW",
          payload: { rows: finalRows },
        },
        "*"
      );
    };

    reader.readAsArrayBuffer(file);
  };

 const handlePreviewAndDownload = async () => {
  if (!sortedData || sortedData.length === 0) return;

  try {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Segment Priority");

    sheet.columns = [
      { header: "Sl. No", key: "slNo", width: 10 },
      { header: "Year", key: "year", width: 15 },
      { header: "Segment Name", key: "segment_name", width: 50 },
      { header: "Status", key: "status", width: 15 },
    ];

    // Header row styling: all left-aligned
    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" }; // ✅ left-aligned
    });

    // Add data rows
    sortedData.forEach((item, index) => {
      sheet.addRow({
        slNo: index + 1,
        year: item.year || "",
        segment_name: item.segment_focus_area || "",
        status: item.status || "Active",
      });
    });

    // Ensure all columns left-aligned
    sheet.columns.forEach((col) => {
      col.alignment = { horizontal: "left" };
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const file = new File([blob], "Segment_Priority.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const response = await uploadTempFile(file);
    const fileUrl = response
      ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
      : null;

    if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    }
  } catch (error) {
    // console.error("Preview generation failed:", error);
  }
};

useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
   handleSave()
  },

  onCancel: () => {
   closePopup()
  },
});

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300  ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full  transition-all duration-300 ease-in-out ">
            {error && (
              <div className="mb-4 p-4 bg-red-50 border border-red-200  flex items-center justify-between">
                <span className="text-red-600">{error}</span>
                <button 
                  onClick={() => setError(null)}
                  className="text-red-600 hover:text-red-800"
                >
                  ✕
                </button>
              </div>
            )}

            <div className="flex items-center justify-between mb-2 flex-wrap gap-4">
              <h2 className="text-base font-medium font-VolvoNovum text-center text-darkblue1 flex items-center justify-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1  p-1"
                />
                PDP Data / Segment Priority
              </h2>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2 w-full">
              <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-2 w-full ">
                <Searchinput
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                  }}
                  value={searchQuery}
                  placeholder="Search"
                  className="w-[1/2]"
                  iconColor="text-black"
                  bgColor="bg-FrostWhite"
                  borderColor="border-black/60"
                  textColor="text-black"
                  shadow="shadow-none"
                  inputPadding="pl-8 pr-3 py-1.5"
                  iconSize="w-3 h-3"
                  iconLeft="left-3"
                  inputWidth="w-full"
                  focusRing="focus:ring-1 focus:ring-black/60"
                  hoverInputClasses="hover:bg-white hover:border-black/60"
                />
                <Filter
                  name="year"
                  placeholder="Year"
                  options={yearOptions}
                  customWidth="w-[10px]"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black"
                  openBgColor="bg-white"
                  textColor="text-black"
                  value={selectedYears}
                  onChange={(name, value) => {
                    setSelectedYears(value);
                  }}
                />

                <Filter
                  name="status"
                  placeholder="Status"
                  options={statusOptions}
                  value={selectedStatus}
                  customWidth="w-[80px]"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black"
                  openBgColor="bg-white"
                  textColor="text-black"
                  onChange={(name, value) => {
                    setSelectedStatus(value);
                  }}
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                <div className="relative w-full sm:w-[190px]" ref={dropdownRef}>
                  <button
                    onClick={() => setOpen(!open)}
                    className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-1.5 text-xs  flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
                  >
                    <Plus className="w-3 h-3 stroke-[3]" />
                    Add New
                  </button>

                  {open && (
                    <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1  shadow-lg z-50">
                      <button
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                        onClick={() => {
                          setIsAddUserOpen(true);
                          setOpen(false);
                        }}
                      >
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
<path d="M14 2.5C14 2.79688 13.9505 3.08073 13.8516 3.35156C13.7526 3.6224 13.612 3.86719 13.4297 4.08594C13.2474 4.30469 13.0339 4.48958 12.7891 4.64062C12.5443 4.79167 12.2734 4.89583 11.9766 4.95312C11.9245 5.47917 11.7865 5.97396 11.5625 6.4375C11.3385 6.90104 11.0521 7.3099 10.7031 7.66406C10.3542 8.01823 9.94792 8.3099 9.48438 8.53906C9.02083 8.76823 8.52604 8.91406 8 8.97656V11.0469C8.29167 11.1094 8.5599 11.2161 8.80469 11.3672C9.04948 11.5182 9.26042 11.7005 9.4375 11.9141C9.61458 12.1276 9.7526 12.3724 9.85156 12.6484C9.95052 12.9245 10 13.2083 10 13.5C10 13.8438 9.9349 14.1667 9.80469 14.4688C9.67448 14.7708 9.49479 15.0365 9.26562 15.2656C9.03646 15.4948 8.77083 15.6745 8.46875 15.8047C8.16667 15.9349 7.84375 16 7.5 16C7.15625 16 6.83333 15.9349 6.53125 15.8047C6.22917 15.6745 5.96354 15.4974 5.73438 15.2734C5.50521 15.0495 5.32552 14.7839 5.19531 14.4766C5.0651 14.1693 5 13.8438 5 13.5C5 13.2031 5.04948 12.9193 5.14844 12.6484C5.2474 12.3776 5.38542 12.1354 5.5625 11.9219C5.73958 11.7083 5.95052 11.5234 6.19531 11.3672C6.4401 11.2109 6.70833 11.1042 7 11.0469V8.97656C6.47396 8.91406 5.98177 8.76823 5.52344 8.53906C5.0651 8.3099 4.65885 8.01823 4.30469 7.66406C3.95052 7.3099 3.66146 6.90104 3.4375 6.4375C3.21354 5.97396 3.07552 5.47917 3.02344 4.95312C2.73177 4.89583 2.46354 4.79167 2.21875 4.64062C1.97396 4.48958 1.76042 4.30729 1.57812 4.09375C1.39583 3.88021 1.25521 3.63542 1.15625 3.35938C1.05729 3.08333 1.00521 2.79688 1 2.5C1 2.15625 1.0651 1.83333 1.19531 1.53125C1.32552 1.22917 1.5026 0.966146 1.72656 0.742188C1.95052 0.518229 2.21615 0.338542 2.52344 0.203125C2.83073 0.0677083 3.15625 0 3.5 0C3.84375 0 4.16667 0.0651042 4.46875 0.195312C4.77083 0.325521 5.03385 0.505208 5.25781 0.734375C5.48177 0.963542 5.66146 1.22917 5.79688 1.53125C5.93229 1.83333 6 2.15625 6 2.5C6 2.79167 5.95312 3.07031 5.85938 3.33594C5.76562 3.60156 5.63021 3.84375 5.45312 4.0625C5.27604 4.28125 5.06771 4.46615 4.82812 4.61719C4.58854 4.76823 4.32292 4.8776 4.03125 4.94531C4.08333 5.38281 4.21094 5.78646 4.41406 6.15625C4.61719 6.52604 4.875 6.84896 5.1875 7.125C5.5 7.40104 5.85417 7.61458 6.25 7.76562C6.64583 7.91667 7.0625 7.99479 7.5 8C7.9375 8 8.35417 7.92448 8.75 7.77344C9.14583 7.6224 9.4974 7.40885 9.80469 7.13281C10.112 6.85677 10.3698 6.53385 10.5781 6.16406C10.7865 5.79427 10.9167 5.38802 10.9688 4.94531C10.6823 4.88281 10.4193 4.77604 10.1797 4.625C9.9401 4.47396 9.73177 4.28906 9.55469 4.07031C9.3776 3.85156 9.24219 3.60938 9.14844 3.34375C9.05469 3.07812 9.00521 2.79688 9 2.5C9 2.15625 9.0651 1.83333 9.19531 1.53125C9.32552 1.22917 9.5026 0.966146 9.72656 0.742188C9.95052 0.518229 10.2161 0.338542 10.5234 0.203125C10.8307 0.0677083 11.1562 0 11.5 0C11.8438 0 12.1667 0.0651042 12.4688 0.195312C12.7708 0.325521 13.0339 0.505208 13.2578 0.734375C13.4818 0.963542 13.6615 1.22917 13.7969 1.53125C13.9323 1.83333 14 2.15625 14 2.5ZM2 2.5C2 2.70833 2.03906 2.90365 2.11719 3.08594C2.19531 3.26823 2.30208 3.42708 2.4375 3.5625C2.57292 3.69792 2.73177 3.80469 2.91406 3.88281C3.09635 3.96094 3.29167 4 3.5 4C3.70833 4 3.90365 3.96094 4.08594 3.88281C4.26823 3.80469 4.42708 3.69792 4.5625 3.5625C4.69792 3.42708 4.80469 3.26823 4.88281 3.08594C4.96094 2.90365 5 2.70833 5 2.5C5 2.29167 4.96094 2.09635 4.88281 1.91406C4.80469 1.73177 4.69792 1.57292 4.5625 1.4375C4.42708 1.30208 4.26823 1.19531 4.08594 1.11719C3.90365 1.03906 3.70833 1 3.5 1C3.29167 1 3.09635 1.03906 2.91406 1.11719C2.73177 1.19531 2.57292 1.30208 2.4375 1.4375C2.30208 1.57292 2.19531 1.73177 2.11719 1.91406C2.03906 2.09635 2 2.29167 2 2.5ZM9 13.5C9 13.2917 8.96094 13.0964 8.88281 12.9141C8.80469 12.7318 8.69792 12.5729 8.5625 12.4375C8.42708 12.3021 8.26823 12.1953 8.08594 12.1172C7.90365 12.0391 7.70833 12 7.5 12C7.29167 12 7.09635 12.0391 6.91406 12.1172C6.73177 12.1953 6.57292 12.3021 6.4375 12.4375C6.30208 12.5729 6.19531 12.7318 6.11719 12.9141C6.03906 13.0964 6 13.2917 6 13.5C6 13.7083 6.03906 13.9036 6.11719 14.0859C6.19531 14.2682 6.30208 14.4271 6.4375 14.5625C6.57292 14.6979 6.73177 14.8047 6.91406 14.8828C7.09635 14.9609 7.29167 15 7.5 15C7.70833 15 7.90365 14.9609 8.08594 14.8828C8.26823 14.8047 8.42708 14.6979 8.5625 14.5625C8.69792 14.4271 8.80469 14.2682 8.88281 14.0859C8.96094 13.9036 9 13.7083 9 13.5ZM11.5 4C11.7083 4 11.9036 3.96094 12.0859 3.88281C12.2682 3.80469 12.4271 3.69792 12.5625 3.5625C12.6979 3.42708 12.8047 3.26823 12.8828 3.08594C12.9609 2.90365 13 2.70833 13 2.5C13 2.29167 12.9609 2.09635 12.8828 1.91406C12.8047 1.73177 12.6979 1.57292 12.5625 1.4375C12.4271 1.30208 12.2682 1.19531 12.0859 1.11719C11.9036 1.03906 11.7083 1 11.5 1C11.2917 1 11.0964 1.03906 10.9141 1.11719C10.7318 1.19531 10.5729 1.30208 10.4375 1.4375C10.3021 1.57292 10.1953 1.73177 10.1172 1.91406C10.0391 2.09635 10 2.29167 10 2.5C10 2.70833 10.0391 2.90365 10.1172 3.08594C10.1953 3.26823 10.3021 3.42708 10.4375 3.5625C10.5729 3.69792 10.7318 3.80469 10.9141 3.88281C11.0964 3.96094 11.2917 4 11.5 4Z" fill="black"/>
</svg>
                        Add Segment Priority
                      </button>
                      
                       <button
        onClick={() => navigate("/bulkupload/segment-priority")}
        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
      >
       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>

        Bulk Upload
      </button>

  <input
    type="file"
    ref={fileInputRef}
    className="hidden"
    accept=".xlsx,.xls"
    onChange={handleBulkUpload}
  />

                      <button
                        onClick={() => {
                          handleDownloadTemplate();
                          setOpen(false);
                        }}
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2  whitespace-nowrap"
                      >
<svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

                        Bulk upload Template
                      </button>
                    </div>
                  )}
                </div>

                <button
                  onClick={handlePreviewAndDownload}
                  className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1  flex items-center gap-1 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
                >
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
<path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D"/>
</svg>
           
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"className="w-3 h-3 hidden group-hover:block">
<path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white"/>
</svg>

                  <span className="font-semibold">Download</span>
                </button>
              </div>
            </div>

          
            <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
              <div
            ref={tableContainerRef}
                className="overflow-y-auto relative"
                style={{
                  scrollbarWidth: "none",
                  msOverflowStyle: "none",
                  maxHeight: sortedData.length > 8 ? "calc(100vh - 220px)" : "auto",
                }}
                onScroll={handleTableScroll}
              >
                <style jsx>{`
                  div::-webkit-scrollbar {
                    display: none;
                  }
                `}</style>

                <table className="w-full text-xs whitespace-nowrap border-collapse">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                    <tr>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[15%] cursor-pointer select-none hover:bg-Dustyblue/80 transition"
                        onClick={() => handleSort("year")}
                      >
                        <div className="flex items-center gap-1">
                          <span className="whitespace-nowrap">Year</span>
                          {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
                          {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white flex-shrink-0" />}
                          {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white flex-shrink-0" />}
                        </div>
                      </th>

                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[75%] cursor-pointer select-none hover:bg-Dustyblue/80 transition"
                        onClick={() => handleSort("segment_focus_area")}
                      >
                        <div className="flex items-center gap-1">
                          <span className="whitespace-nowrap">Segment Name</span>
                          {sortKey === "segment_focus_area" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white flex-shrink-0" />}
                          {sortKey === "segment_focus_area" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white flex-shrink-0" />}
                        </div>
                      </th>

                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 text-center font-medium w-[10%]">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-black">
                    {isLoading && tableData.length === 0 ? (
                      <tr>
                        <td colSpan={3} className="px-2 py-8 text-center text-gray-500">
                          <div className="flex items-center justify-center gap-2">
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                            <span>Loading...</span>
                          </div>
                        </td>
                      </tr>
                    ) : sortedData.length > 0 ? (
                      sortedData.map((item, index) => (
                        <tr
                          key={item.id}
                          className={`hover:bg-lightBlue/50 text-xs ${item.status === "Active" ? "text-black" : "text-gray-400"}`}
                        >
                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[4rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.year?.toString().length > 4)
                                    setHoveredCell(item.id + "-year");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.year || "-"}
                              </p>
                              {hoveredCell === item.id + "-year" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-nowrap transform -translate-x-1/2 z-0">
                                  {item.year}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 align-top text-xs">
                            <div className="relative">
                              <p
                                className="truncate cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.segment_focus_area?.length > 50)
                                    setHoveredCell(item.id + "-segment");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.segment_focus_area || "-"}
                              </p>
                              {hoveredCell === item.id + "-segment" && (
                                <span className="absolute left-0 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-1 whitespace-normal max-w-[20rem] transform z-0">
                                  {item.segment_focus_area}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                            <div className="flex items-center justify-center gap-2">
                              <div className="relative group inline-block">
                                <button onClick={() => handleEdit(item)} className="p-1 hover:scale-110 transition">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                    <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                                    <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 z-0 whitespace-nowrap">
                                  Edit
                                </span>
                              </div>

                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setSelectedRow(item.id);
                                    if (item.status === "Active") {
                                      setShowDeactivateModal(true);
                                    } else {
                                      setShowActivateModal(true);
                                    }
                                  }}
                                  className="p-1 hover:scale-110 transition"
                                >
                                  {item.status === "Active" ? (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
                                      <path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                    </svg>
                                  ) : (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none">
                                      <path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                    </svg>
                                  )}
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                  {item.status === "Active" ? "Deactivate" : "Activate"}
                                </span>
                              </div>

                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setSelectedRow(item.id);
                                    setIsDeleteModalOpen(true);
                                  }}
                                  className="p-1 hover:scale-110 transition"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                                    <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 z-0 whitespace-nowrap">
                                  Delete
                                </span>
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={3} className="px-2 py-8 text-center italic text-gray-500">
                          No data found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
               {showScrollButtons && (
            <div className="fixed bottom-14 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

            </div>
          </div>
        </div>
      </div>

      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center p-4">
          <div 
          ref={popupRef}
          className="bg-white p-6 w-full max-w-md relative rounded">
            <h2 className="text-base font-semibold text-center mb-4 text-MediumGrey">
              {isEditing ? "Edit Segment Priority" : "Add Segment Priority"}
            </h2>
            <button
              onClick={closePopup}
              className="absolute top-3 right-4 text-red-600 font-bold"
            >
              <svg width="14" height="14" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <circle cx="10" cy="10" r="8" fill="#BF2012" />
                <path d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5" stroke="white" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </button>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-medium text-black/70">Year <span className=" text-red1">*</span></label>
                <input
                  type="text"
                  value={formData.year}
                  onChange={(e) => {
                    const value = e.target.value;
                     if (errors.year) {
          setErrors({ ...errors, year: "" });
        }
                    if (/^\d{0,4}$/.test(value)) {
                      setFormData({ ...formData, year: value });
                    }
                  }}
                  maxLength={4}
                  className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                    errors.year ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                  placeholder="Enter Year"
                />
                {errors.year && <p className="text-red1 text-xs mt-1">{errors.year}</p>}
              </div>

              <div>
                <label className="text-xs font-medium text-black/70">Segment Name <span className=" text-red1">*</span></label>
                <input
                  type="text"
                  maxLength={75}
                  value={formData.segment_focus_area}
                  onChange={(e) => {
                     if (errors.segment_focus_area) {
          setErrors({ ...errors, segment_focus_area: "" });
        }
                    setFormData({ ...formData, segment_focus_area: e.target.value });
                    setErrors({ ...errors, segment_focus_area: "" });
                  }}
                  placeholder="Enter Segment Name"
                  className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                    errors.segment_focus_area ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                />
                {errors.segment_focus_area && (
                  <p className="text-red1 text-xs mt-1">{errors.segment_focus_area}</p>
                )}
              </div>
            </div>
           
            {errors.submit && (
              <p className="text-xs text-red1 text-center mb-2">{errors.submit}</p>
            )}
            <button
              onClick={handleSave}
              className="mt-6 bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto"
            >
              Save
            </button>
          </div>
        </div>
      )}

      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setSelectedRow(null);
        }}
        onConfirm={handleDelete}
      />

      {showActivateModal && selectedRow !== null && (
        <ActivateStatus
          isOpen={showActivateModal}
          loading={loadingToggle}
          onClose={() => {
            if (!loadingToggle) {
              setShowActivateModal(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={handleToggleStatus}
        />
      )}

      {showDeactivateModal && selectedRow !== null && (
        <DeactivateStatus
          isOpen={showDeactivateModal}
          loading={loadingToggle}
          onClose={() => {
            if (!loadingToggle) {
              setShowDeactivateModal(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={handleToggleStatus}
        />
      )}

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept=".csv,.xlsx,.xls"
      />
    </div>
  )
}

export default SegmentPriority;