import { useState, useEffect, useRef, useMemo, useReducer } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus, ArrowRight } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import Filter from "../../../../../Components/Filter"
import DeleteModal from "../../../../../Components/DeleteModal"
import * as XLSX from "xlsx";
import ActivateStatus from "../../../../../Components/ActivateStatus"
import DeactivateStatus from "../../../../../Components/DeactivateStatus"
import { saveAs } from "file-saver";
import ExcelJS from "exceljs";
import { ChevronUp, ChevronDown } from "lucide-react";
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
import useCRUDWithReset from "../../../../../util/useCRUDWithReset"
import {
  addUptimePartsCategory,
  getUptimePartsCategories,
  updateUptimePartsCategory,
  deleteUptimePartsCategory,
  toggleUptimePartsCategory
} from "../../../../../services/pdpMaster/uptimePartsCategory.service"
import { uploadTempFile } from "../../../../../services/download/bluckDownload.service"
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation"
function Uptimeandparts() {
  const [selectedYear, setSelectedYear] = useState([]);
  const [categoryName, setCategoryName] = useState([]);
  const [measurement, setMeasurement] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [makeOptions, setMakeOptions] = useState(["Volvo", "SDLG"]);
  const [showMakeSuggestions, setShowMakeSuggestions] = useState(false);
  const scrollRef = useRef(null);
  const [apiLoading, setApiLoading] = useState(false)
  const [error, setError] = useState(null)
  const [hoveredCell, setHoveredCell] = useState(null)  
  const [menuOpen, setMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const dropdownRef = useRef(null)
  const [tableData, setTableData] = useState([])
  const[showDIRequiredDropdown, setShowDIRequiredDropdown]=useState(false);
  const [selectedMakes, setSelectedMakes] = useState([]);
  const [selectedDIRequired, setSelectedDIRequired] = useState([]);
  const [makeSearch, setMakeSearch] = useState("");
const makeRef = useRef(null);
const [measurementSearch, setMeasurementSearch] = useState("");
const measurementRef = useRef(null);
const popupRef= useRef (null);
 const diRequiredRef=useRef()
  const [formData, setFormData] = useState({
    year: "",
    category: "",
    equipment_make: "",
    details: "",
    measurement_units: "",
    di_required: ""
  })
  const [isEditing, setIsEditing] = useState(false)
  const [editIndex, setEditIndex] = useState(null)
  const [errors, setErrors] = useState({})
  const [yearOptions, setYearOptions] = useState([])
  const [categoryOptions, setCategoryOptions] = useState([])
  const [searchQuery, setSearchQuery] = useState("")
  const [deleteIndex, setDeleteIndex] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showMeasurementSuggestions, setShowMeasurementSuggestions] = useState(false);
  const [measurementOptions, setMeasurementOptions] = useState([]);
  const fileInputRef = useRef(null)
  const [selectedStatus, setSelectedStatus] = useState([]);
  const statusOptions = [
    "Active", "Inactive"
  ];
  const diRequiredOptions = ["Yes", "No"];

  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null);
const [categorySearch, setCategorySearch] = useState("");
const categoryRef = useRef(null);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  const handleBulkUploadClick = () => {
    fileInputRef.current.click()
  }

  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc");
      } else if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
      }
    } else {
      setSortKey(key);
      setSortOrder("asc");
    }
  };

  // ═══════════════════════════════════════════════════════
  // 🔗 DEPENDENT FILTER OPTIONS (Make → Category → Measurement)
  // ═══════════════════════════════════════════════════════

  // Make options - always show ALL unique makes from data (no dependency)
  const filterMakeOptions = useMemo(() => {
    return [...new Set(tableData.map((i) => i.make).filter(Boolean))].sort();
  }, [tableData]);

  // Category options - depends on selectedMakes
  const filterCategoryOptions = useMemo(() => {
    let filtered = tableData;
    if (selectedMakes.length > 0) {
      filtered = filtered.filter((item) => selectedMakes.includes(item.make));
    }
    return [...new Set(filtered.map((i) => i.category).filter(Boolean))].sort();
  }, [tableData, selectedMakes]);

  // Measurement options - depends on selectedMakes + categoryName
  const filterMeasurementOptions = useMemo(() => {
    let filtered = tableData;
    if (selectedMakes.length > 0) {
      filtered = filtered.filter((item) => selectedMakes.includes(item.make));
    }
    if (categoryName.length > 0) {
      filtered = filtered.filter((item) => categoryName.includes(item.category));
    }
    return [...new Set(filtered.map((i) => i.measurement || i.measurement_units).filter(Boolean))].sort();
  }, [tableData, selectedMakes, categoryName]);

  // ═══════════════════════════════════════════════════════
  // 🔄 CASCADING FILTER CHANGE HANDLERS
  // ═══════════════════════════════════════════════════════

  // When Make changes → reset Category, Measurement
  const handleMakeFilterChange = (name, value) => {
    setSelectedMakes(value);
    setCategoryName([]);
    setMeasurement([]);
  };

  // When Category changes → reset Measurement
  const handleCategoryFilterChange = (name, value) => {
    setCategoryName(value);
    setMeasurement([]);
  };

  // Measurement change - no child to reset
  const handleMeasurementFilterChange = (name, value) => {
    setMeasurement(value);
  };

  const filteredData = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    return tableData.filter((item) => {
      const searchableValues = [
        item.year,
        item.category,
        item.make || item.equipment_make,
        item.details,
        item.measurement || item.measurement_units,
      ]
        .filter(Boolean)
        .map((v) => v.toString().toLowerCase());

      const matchesSearch = query
        ? searchableValues.some((val) => val.includes(query))
        : true;

      const matchesYear = selectedYear.length
        ? selectedYear.includes(item.year)
        : true;

      const matchesCategory = categoryName.length
        ? categoryName.includes(item.category)
        : true;

      const matchesMake = selectedMakes.length
        ? selectedMakes.includes(item.make)
        : true;

      const matchesMeasurement = measurement.length
        ? measurement.includes(item.measurement || item.measurement_units)
        : true;

      const matchesStatus = selectedStatus.length
        ? selectedStatus.includes(item.status)
        : true;

      const matchesDIRequired = selectedDIRequired.length
        ? selectedDIRequired.includes(item.di_required)
        : true;

      return matchesSearch && matchesYear && matchesCategory && matchesMeasurement && matchesStatus && matchesMake && matchesDIRequired;
    });
  }, [tableData, searchQuery, selectedYear, categoryName, measurement, selectedStatus, selectedMakes, selectedDIRequired]);

  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredData;

    return [...filteredData].sort((a, b) => {
      const valA = a[sortKey] ?? "";
      const valB = b[sortKey] ?? "";

      return sortOrder === "asc"
        ? valA.toString().localeCompare(valB.toString(), undefined, { numeric: true })
        : valB.toString().localeCompare(valA.toString(), undefined, { numeric: true });
    });
  }, [filteredData, sortKey, sortOrder]);
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchQuery: { setter: setSearchQuery, resetValue: "" },
    selectedYear:{setter: setSelectedYear,resetValue :[]},
    categoryName:{setter: setCategoryName,resetValue :[]},
    selectedMakes:{setter:setSelectedMakes,resetValue:[]},
    measurement:{setter:setMeasurement,resetValue:[]},
    selectedStatus:{setter:setSelectedStatus,resetValue:[]}

  }
);

  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 100);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
useEffect(() => {
  const handleClickOutside = (e) => {
    if (makeRef.current && !makeRef.current.contains(e.target)) {
      setShowMakeSuggestions(false);
      setMakeSearch("");
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);
useEffect(() => {
  const handleClickOutside = (e) => {
    if (measurementRef.current && !measurementRef.current.contains(e.target)) {
      setShowMeasurementSuggestions(false);
      setMeasurementSearch ()
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
useEffect(() => {
  const handleClickOutside = (e) => {
    if (categoryRef.current && !categoryRef.current.contains(e.target)) {
      setShowSuggestions(false);
      setCategorySearch("")
    }
  };

  document.addEventListener("mousedown", handleClickOutside);
  return () => document.removeEventListener("mousedown", handleClickOutside);
}, []);

  useEffect(() => {
    const years = [...new Set(tableData.map((item) => item.year))].sort((a, b) => Number(a) - Number(b));
    setYearOptions(years);

    const categories = [...new Set(tableData.map((item) => item.category))].sort();
    setCategoryOptions(categories);
  }, [tableData]);

  useEffect(() => {
    const measurementFromData = tableData
      .map(item => item.measurement_units?.trim())
      .filter(val => val && val.length > 0);

    const baseMeasurement = [];
    setMeasurementOptions([...new Set([...baseMeasurement, ...measurementFromData])]);
  }, [tableData]);
useEffect(() => {
  if (isEditing && selectedRow) {
    setFormData({
      ...selectedRow,
      equipment_type: selectedRow.equipment_type || "",
    });
  }
}, [isEditing, selectedRow]); // ❌ NOT formData

  const loadUptimePartsCategories = async () => {
    try {
      setApiLoading(true);
      setError(null);
      const data = await getUptimePartsCategories();

      const mappedData = data.map(item => ({
        id: item.id,
        year: item.year,
        category: item.category,
        make: item.equipment_make,
        equipment_make: item.equipment_make,
        details: item.details,
        measurement: item.measurement_units,
        measurement_units: item.measurement_units,
        status: item.isActive ? "Active" : "Inactive",
        di_required: item.di_required === 1 ? "Yes" : "No",
        di_required_value: item.di_required,
        createdOn: item.createdOn,
        isActive: item.isActive,
        isDeleted: item.isDeleted
      }));

      setTableData(mappedData);
    } catch (error) {
      // console.error("Error loading uptime parts categories:", error);
      setError(error.message);
    } finally {
      setApiLoading(false);
    }
  };

  const handleAddUptimePartsCategory = async (formData) => {
    try {
      setApiLoading(true);
      setError(null);

      const apiPayload = {
        year: parseInt(formData.year),
        category: formData.category,
        equipment_make: formData.equipment_make,
        details: formData.details,
        measurement_units: formData.measurement_units,
        di_required: formData.di_required === "Yes" ? 1 : 0
      };

      await addUptimePartsCategory(apiPayload);
      await loadUptimePartsCategories();
      return true;
    } catch (error) {
      // console.error("Error adding uptime parts category:", error);
      setError(error.message);
      return false;
    } finally {
      setApiLoading(false);
    }
  };

  const handleUpdateUptimePartsCategory = async (id, formData) => {
    try {
      setApiLoading(true);
      setError(null);

      const apiPayload = {
        year: parseInt(formData.year),
        category: formData.category,
        equipment_make: formData.equipment_make,
        details: formData.details,
        measurement_units: formData.measurement_units,
        di_required: formData.di_required === "Yes" ? 1 : 0
      };

      await updateUptimePartsCategory(id, apiPayload);
      await loadUptimePartsCategories();
      return true;
    } catch (error) {
      // console.error("Error updating uptime parts category:", error);
      setError(error.message);
      return false;
    } finally {
      setApiLoading(false);
    }
  };

  const handleDeleteUptimePartsCategory = async (id) => {
    try {
      setApiLoading(true);
      setError(null);

      await deleteUptimePartsCategory(id);
      await loadUptimePartsCategories();
      return true;
    } catch (error) {
      // console.error("Error deleting uptime parts category:", error);
      setError(error.message);
      return false;
    } finally {
      setApiLoading(false);
    }
  };

  const handleToggleUptimePartsCategory = async (id) => {
    try {
      setApiLoading(true);
      setError(null);

      await toggleUptimePartsCategory(id);
      await loadUptimePartsCategories();
      return true;
    } catch (error) {
      // console.error("Error toggling uptime parts category:", error);
      setError(error.message);
      return false;
    } finally {
      setApiLoading(false);
    }
  };

  useEffect(() => {
    loadUptimePartsCategories();
  }, []);

  const handleDownloadTemplate = async () => {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Uptime & Parts Category Details");

    sheet.columns = [
      { header: "Year", key: "year", width: 15 },
      { header: "Category", key: "category", width: 40 },
      { header: "Equipment Make", key: "make", width: 20 },
      { header: "Details", key: "details", width: 25 },
      { header: "Measurement", key: "measurement", width: 15 },
      { header: "DI Required", key: "di_required", width: 15 },
    ];

    sheet.columns.forEach((column) => {
      column.alignment = {
        vertical: "middle",
        horizontal: "left",
        wrapText: true,
      };
      column.numFmt = "@";
    });

    sheet.addRow({
      year: "2025",
      category: "GPE (General Production Equipment)",
      make: "Volvo",
      details: "Sample details...",
      measurement: "cm",
      di_required: "Yes",
    });

    sheet.columns.forEach((column) => {
      column.protection = { locked: false };
    });

    const headerRow = sheet.getRow(1);
    headerRow.eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" };
      cell.protection = { locked: true };
    });

    sheet.dataValidations.add("C2:C5000", {
      type: "list",
      allowBlank: false,
      formulae: ['"Volvo,SDLG"'],
      showErrorMessage: true,
      errorTitle: "Invalid Make",
      error: "Please select a valid Equipment Make from the list.",
    });

    sheet.dataValidations.add("F2:F5000", {
      type: "list",
      allowBlank: false,
      formulae: ['"Yes,No"'],
      showErrorMessage: true,
      errorTitle: "Invalid DI Required",
      error: "Please select Yes or No.",
    });

    await sheet.protect("12345", {
      selectLockedCells: true,
      selectUnlockedCells: true,
      insertRows: true,
      deleteRows: true,
      formatColumns: true,
      formatRows: true,
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    saveAs(blob, "Up_Time_And_Parts_Category_Details.xlsx");
  };

  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const previewTab = window.open("/bulkupload/uptimeparts", "_blank");
    if (!previewTab) {
      // alert("Popup blocked! Please allow popups.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];

      let rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });

      rows = rows.filter((row) => Object.values(row).some((v) => v !== ""));

      const finalRows = rows.map((row, index) => ({
        slNo: index + 1,
        year: row["Year"] || "",
        category: row["Category"] || "",
        equipmentMake: row["Equipment Make"] || "",
        details: row["Details"] || "",
        measurement: row["Measurement"] || "",
        di_required: row["DI Required"] || "",
        hasError: !row["Equipment Make"],
      }));

      previewTab.postMessage(
        {
          type: "PARTS_CATEGORY_PREVIEW",
          payload: { rows: finalRows },
        },
        "*"
      );
    };

    reader.readAsArrayBuffer(file);
  };

  const handlePreviewAndDownload = async () => {
    if (!filteredData || filteredData.length === 0) {
      // alert("No data available to upload");
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Uptime & Parts Category");

    sheet.columns = [
      { header: "Sl. No", key: "slNo", width: 10 },
      { header: "Year", key: "year", width: 15 },
      { header: "Category", key: "category", width: 15 },
      { header: "Equipment Make", key: "make", width: 25 },
      { header: "Details", key: "details", width: 75 },
      { header: "Measurement", key: "measurement", width: 15 },
      { header: "DI Required", key: "di_required", width: 15 },
      { header: "Status", key: "status", width: 15 },
    ];

    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.alignment = { vertical: "middle", horizontal: "left" };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
    });

    filteredData.forEach((item, index) => {
      const row = sheet.addRow({
        slNo: index + 1,
        year: item.year || "",
        category: item.category || "",
        make: item.make || item.equipment_make || "",
        details: item.details || "",
        measurement: item.measurement || item.measurement_units || "",
        di_required: item.di_required || "",
        status: item.isActive ? "Active" : "Inactive",
      });

      row.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const file = new File([blob], "Uptime_and_Parts_Category.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    try {
      const response = await uploadTempFile(file);

      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        // console.warn("Upload succeeded but no file URL returned");
      }
    } catch (error) {
      // console.error("Upload failed:", error);
      // alert("Failed to upload Excel file.");
    }
  };
useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
    document.getElementById("saveuptimetBtn")?.click();
  },

  onCancel: () => {
    setIsAddUserOpen(false);
    setIsEditing(false);
    setFormData({ year: "", category: "", equipment_make: "", details: "", measurement_units: "", di_required: "" })
                    setErrors({})
                    setIsEditing(false)
                    setEditIndex(null)
                    setIsAddUserOpen(false)
                  }
});

  return (
    <div className="bg-Frostwhite h-screen overflow-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300 flex-1 flex flex-col overflow-hidden ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4 flex-1 overflow-hidden">
          <div className="w-full transition-all duration-300 ease-in-out h-full flex flex-col">
            <div className="flex items-center mb-2">
              <h2 className="text-sm md:text-base font-medium font-VolvoNovum text-darkblue1 flex items-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={22}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1 flex-shrink-0"
                />
                PDP Data / Uptime & Parts Category Details
              </h2>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                {error}
                <button
                  onClick={() => setError(null)}
                  className="ml-2 text-red-500 hover:text-red-700"
                >
                  ×
                </button>
              </div>
            )}

            {apiLoading && (
              <div className="mb-4 p-3 bg-blue-100 border border-blue-400 text-blue-700 flex items-center gap-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
                Loading...
              </div>
            )}

            {/* ═══════════════════════════════════════════════════════
                🔗 TABLE FILTERS - DEPENDENT/CASCADING
                Equipment Make → Category → Measurement
            ═══════════════════════════════════════════════════════ */}
<div className="flex items-center gap-2 mb-2 whitespace-nowrap">
              {/* 🔍 Search Input */}
              <Searchinput
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                }}
                value={searchQuery}
                placeholder="Search"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
                borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3"
                inputWidth="w-[120px] md:w-[140px]"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />

              {/* 📆 Year Filter (independent) */}
              <Filter
                name="year"
                placeholder="Year"
                options={yearOptions}
                customWidth="w-[90px] md:w-[100px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                textColor="text-black"
                value={selectedYear}
                onChange={(name, value) => {
                  setSelectedYear(value);
                }}
              />

              {/* Equipment Make Filter (parent - resets Category, Measurement) */}
              <Filter
                name="equipmentMake"
                placeholder="Equipment Make"
                options={filterMakeOptions}
                customWidth="w-[80px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                closedBgColor="bg-white"
                hoverRingColor="ring-black"
                openBgColor="bg-white"
                textColor="text-black"
                value={selectedMakes}
                onChange={handleMakeFilterChange}
              />

              {/* Category Filter (depends on Make → resets Measurement) */}
              <Filter
                name="category"
                placeholder="Category"
                options={filterCategoryOptions}
                customWidth="w-[90px] md:w-[110px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                textColor="text-black"
                value={categoryName}
                onChange={handleCategoryFilterChange}
              />

              {/* Measurement Filter (depends on Make + Category) */}
              <Filter
                name="measurement"
                placeholder="Measurement"
                options={filterMeasurementOptions}
                customWidth="w-[100px] md:w-[130px]"
                placeholderColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBgColor="bg-white"
                dropdownTextColor="text-black"
                dropdownHoverColor="hover:bg-lightBlue/50"
                dropdownBorderColor="border-black/60"
                textColor="text-black"
                value={measurement}
                onChange={handleMeasurementFilterChange}
              />

              {/* Status Filter (independent) */}
  <Filter
  name="status"
  placeholder="Status"
  options={statusOptions}
  value={selectedStatus}
  customWidth="w-[80px]"
  placeholderColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black/60"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
  onChange={(name, value) => {
    setSelectedStatus(value);
  }}
/>
              {/* 🔸 Action Buttons - Push to right */}
<div className="flex items-center gap-2">
                {/* ➕ Add Dropdown */}
                <div className="relative w-full sm:w-[190px]" ref={dropdownRef}>
                  <button
                    onClick={() => setOpen(!open)}
                    className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-1.5 text-xs flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
                  >
                    <Plus className="w-3 h-3 stroke-[3]" />
                    Add New
                  </button>

                  {open && (
                    <div className="absolute top-full right-0 mt-1 w-[190px] bg-white border border-darkblue1 shadow-lg z-50">
                      <button
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 whitespace-nowrap"
                        onClick={() => {
                          setIsAddUserOpen(true);
                          setOpen(false);
                        }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
<g clipPath="url(#clip0_1415_1582)">
<path d="M9.59361 4.50209L4.50244 9.59326L6.41163 11.5025L11.5028 6.41128L9.59361 4.50209Z" stroke="black" strokeWidth="0.7" strokeMiterlimit="10"/>
<path d="M12.4534 6.09333C13.8599 6.09333 15.0001 4.95315 15.0001 3.54667C15.0001 2.14018 13.8599 1 12.4534 1C11.0469 1 9.90674 2.14018 9.90674 3.54667C9.90674 4.95315 11.0469 6.09333 12.4534 6.09333Z" stroke="black" strokeWidth="0.7" strokeMiterlimit="10"/>
<path d="M3.54667 15.0001C4.95315 15.0001 6.09333 13.8599 6.09333 12.4534C6.09333 11.0469 4.95315 9.90674 3.54667 9.90674C2.14018 9.90674 1 11.0469 1 12.4534C1 13.8599 2.14018 15.0001 3.54667 15.0001Z" stroke="black" strokeWidth="0.7" strokeMiterlimit="10"/>
<path d="M8 6.09333L6.09333 8L4.18 6.09333H2.90667C2.40038 6.09157 1.91542 5.88921 1.55804 5.53058C1.20066 5.17195 0.999997 4.68629 1 4.18V2.90667L1.26667 3.17333C1.50273 3.42412 1.82296 3.5791 2.1661 3.60861C2.50925 3.63813 2.85124 3.54012 3.12667 3.33333C3.27503 3.21546 3.39657 3.06732 3.48317 2.89879C3.56978 2.73026 3.61947 2.5452 3.62894 2.35595C3.6384 2.1667 3.60742 1.9776 3.53805 1.80127C3.46869 1.62494 3.36253 1.46541 3.22667 1.33333L2.90667 1H4.18C4.68629 0.999997 5.17195 1.20066 5.53058 1.55804C5.88921 1.91542 6.09157 2.40038 6.09333 2.90667V4.18L8 6.09333Z" stroke="black" strokeWidth="0.7" strokeMiterlimit="10"/>
<path d="M13.0933 9.90667C13.5996 9.90843 14.0846 10.1108 14.442 10.4694C14.7993 10.828 15 11.3137 15 11.82V13.0933L14.7333 12.8267C14.4973 12.5759 14.177 12.4209 13.8339 12.3914C13.4907 12.3619 13.1488 12.4599 12.8733 12.6667C12.725 12.7845 12.6034 12.9327 12.5168 13.1012C12.4302 13.2697 12.3805 13.4548 12.3711 13.6441C12.3616 13.8333 12.3926 14.0224 12.4619 14.1987C12.5313 14.3751 12.6375 14.5346 12.7733 14.6667L13.0933 14.9867H11.82C11.3137 14.9867 10.828 14.786 10.4694 14.4286C10.1108 14.0712 9.90843 13.5863 9.90667 13.08V11.82L8 9.90667L9.90667 8L11.82 9.90667H13.0933Z" stroke="black" strokeWidth="0.7" strokeMiterlimit="10"/>
</g>
<defs>
<clipPath id="clip0_1415_1582">
<rect width="16" height="16" fill="white"/>
</clipPath>
</defs>
</svg>
                        Add Uptime & parts
                      </button>
                       <button
        onClick={() => navigate("/bulkupload/uptimeparts")}
        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>


        Bulk Upload
      </button>

  <input
    type="file"
    ref={fileInputRef}
    className="hidden"
    accept=".xlsx,.xls"
    onChange={handleBulkUpload}
  />
                      <button
                        onClick={handleDownloadTemplate}
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1 whitespace-nowrap"
                      >
<svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fillOpacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fillOpacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fillOpacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fillOpacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fillOpacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M1 14.75H12" stroke="black" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M1 14.75H12" stroke="black" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M1 14.75H12" stroke="black" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M1 14.75H12" stroke="black" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
<path d="M1 14.75H12" stroke="black" strokeOpacity="0.2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
</svg>

                        Bulk upload Template
                      </button>
                    </div>
                  )}
                </div>

                {/* ⬇️ Download Button */}
                <button
                  onClick={handlePreviewAndDownload}
                  className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1 flex items-center gap-2 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
                >
                 <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
<path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D"/>
</svg>
           
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"className="w-3 h-3 hidden group-hover:block">
<path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white"/>
</svg>

                  <span className="font-semibold">Download</span>
                </button>
              </div>
            </div>

            <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
              <div
              ref={tableContainerRef}
                className="overflow-y-auto overflow-x-auto max-h-[calc(100vh-220px)] lg:max-h-[calc(100vh-200px)] scrollbar-hide"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                onScroll={handleTableScroll}
              >
                <style>{`
                  .scrollbar-hide::-webkit-scrollbar {
                    display: none;
                  }
                `}</style>
                <table className="w-full text-sm border-collapse min-w-[650px]">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-10">
                    <tr>
                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%] cursor-pointer select-none"
                        onClick={() => handleSort("year")}
                      >
                        <div className="flex items-center gap-1">
                          Year
                          {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

                          {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>

                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[15%] cursor-pointer select-none"
                        onClick={() => handleSort("category")}
                      >
                        <div className="flex items-center gap-1">
                          Category
                          {sortKey === "category" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "category" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>

                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[15%] cursor-pointer select-none"
                        onClick={() => handleSort("make")}
                      >
                        <div className="flex items-center gap-1">
                          Equip. Make
                          {sortKey === "make" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "make" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>

                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[30%] cursor-pointer select-none"
                        onClick={() => handleSort("details")}
                      >
                        <div className="flex items-center gap-1">
                          Details
                          {sortKey === "details" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "details" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>

                      <th
                        className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
                        onClick={() => handleSort("measurement")}
                      >
                        <div className="flex items-center gap-1">
                          Measurement
                          {sortKey === "measurement" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                          {sortKey === "measurement" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                        </div>
                      </th>

                      <th
                        className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
                        onClick={() => handleSort("di_required")}
                      >
                        <div className="flex items-center gap-1">
                          DI Required
                          {sortKey === "di_required" && sortOrder === "asc" && <ChevronUp className="w-3 h-3" />}
                          {sortKey === "di_required" && sortOrder === "desc" && <ChevronDown className="w-3 h-3" />}
                        </div>
                      </th>

                      <th className="text-center px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[17%]">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-black">
                    {(() => {
                      if (apiLoading && tableData.length === 0) {
                        return (
                          <tr>
                            <td colSpan={7} className="px-2 py-8 text-center text-gray-500">
                              <div className="flex items-center justify-center gap-2">
                                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                                Loading data...
                              </div>
                            </td>
                          </tr>
                        );
                      }
                      if (sortedData.length > 0) {
                        return sortedData.map((item, index) => (
                          <tr
                            key={item.id || index}
                            className={`hover:bg-lightBlue/50 text-xs ${item.status === "Active" ? "text-black" : "text-gray-400"}`}
                          >
                            <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 truncate">{item.year}</td>
                            <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                              <div className="relative">
                                <p
                                  className="truncate max-w-[15rem] cursor-pointer"
                                  onMouseEnter={() => {
                                    if (item.category && item.category.length > 18)
                                      setHoveredCell(item.id + "-category");
                                  }}
                                  onMouseLeave={() => setHoveredCell(null)}
                                >
                                  {item.category}
                                </p>

                                {hoveredCell === item.id + "-category" && (
                                  <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                    {item.category}
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                              <div className="relative">
                                <p
                                  className="truncate max-w-[10rem] cursor-pointer"
                                  onMouseEnter={() => {
                                    if (item.make && item.make.length > 15)
                                      setHoveredCell(item.id + "-make");
                                  }}
                                  onMouseLeave={() => setHoveredCell(null)}
                                >
                                  {item.make}
                                </p>

                                {hoveredCell === item.id + "-make" && (
                                  <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                    {item.make}
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                              <div className="relative">
                                <p
                                  className="truncate max-w-[25rem] cursor-pointer"
                                  onMouseEnter={() => {
                                    if (item.details && item.details.length > 40)
                                      setHoveredCell(item.id + "-details");
                                  }}
                                  onMouseLeave={() => setHoveredCell(null)}
                                >
                                  {item.details}
                                </p>

                                {hoveredCell === item.id + "-details" && (
                                  <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                    {item.details}
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                              <div className="relative">
                                <p
                                  className="truncate max-w-[10rem] cursor-pointer"
                                  onMouseEnter={() => {
                                    if (item.measurement && item.measurement.length > 15)
                                      setHoveredCell(item.id + "-measurement");
                                  }}
                                  onMouseLeave={() => setHoveredCell(null)}
                                >
                                  {item.measurement}
                                </p>

                                {hoveredCell === item.id + "-measurement" && (
                                  <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                    {item.measurement}
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs align-top">{item.di_required}</td>

                            <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                              <div className="flex item-center justify-center gap-4">
                                <div className="relative group inline-block">
                                  <button
                                    onClick={() => {
                                      const editData = {
                                        year: item.year,
                                        equipment_make: item.equipment_make || item.make || "",
                                        category: item.category,
                                        details: item.details || "",
                                        measurement_units: item.measurement_units || item.measurement || "",
                                        di_required: item.di_required || "",
                                      };
                                      setFormData(editData);
                                      setIsAddUserOpen(true);
                                      setIsEditing(true);
                                      setEditIndex(index);
                                    }}
                                    className="text-blue-600 hover:underline"
                                  >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                      <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                                      <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                                    </svg>
                                  </button>
                                  <span className="absolute left-1/2 top-full -mt-2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                    Edit
                                  </span>
                                </div>

                                <div className="relative group">
                                  <button
                                    onClick={() => {
                                      setSelectedRow(index);
                                      if (item.status === "Active") {
                                        setShowDeactivateModal(true);
                                      } else {
                                        setShowActivateModal(true);
                                      }
                                    }}
                                  >
                                    {item.status === "Active" ? (
                                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
                                        <path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                      </svg>
                                    ) : (
                                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                        <g clipPath="url(#clip0_5669_3080)">
                                          <path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                        </g>
                                        <defs>
                                          <clipPath id="clip0_5669_3080">
                                            <rect width="24" height="24" fill="white"/>
                                          </clipPath>
                                        </defs>
                                      </svg>
                                    )}
                                  </button>
                                  <span className="absolute left-1/2 top-full -mt-2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                    {item.status === "Active" ? "Deactivate" : "Activate"}
                                  </span>
                                </div>

                                <div className="relative group inline-block">
                                  <button
                                    onClick={() => {
                                      setDeleteIndex(index);
                                      setIsDeleteModalOpen(true);
                                    }}
                                    className="text-blue-600 hover:underline"
                                  >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                                      <g clipPath="url(#clip0_6398_313)">
                                        <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                                      </g>
                                      <defs>
                                        <clipPath id="clip0_6398_313">
                                          <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                                        </clipPath>
                                      </defs>
                                    </svg>
                                  </button>
                                  <span className="absolute left-1/2 top-full -mt-2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                    Delete
                                  </span>
                                </div>
                              </div>
                            </td>
                          </tr>
                        ))
                      }
                      return (
                        <tr>
                          <td colSpan={7} className="px-2 py-6 text-center italic text-gray-500">
                            No data found
                          </td>
                        </tr>
                      );
                    })()}
                  </tbody>
                </table>
              </div>
              {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

            </div>
          </div>
        </div>
      </div>

      {/* Add/Edit Modal - Popup form dropdowns remain INDEPENDENT (not cascading) */}
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
          <div 
          ref={popupRef}
          className="bg-white p-6 w-full max-w-xl relative">
            <h2 className="text-base font-semibold text-center mb-4 text-MediumGrey">
              {isEditing ? "Uptime & Parts Category" : "Add Uptime & Parts Category"}
            </h2>
            <button
              onClick={() => {
                setIsAddUserOpen(false)
                setIsEditing(false)
                setFormData({ year: "", category: "", equipment_make: "", details: "", measurement_units: "", di_required: "" })
                setErrors({})
              }}
              className="absolute top-3 right-4 text-red-600 font-bold text-xl"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
                role="img"
                aria-label="Error icon"
              >
                <circle cx="10" cy="10" r="8" fill="#BF2012" />
                <path
                  d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>
            </button>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div className="md:col-span-1">
                <label className="text-xs font-medium text-black/70">Year <span className=" text-red1">*</span></label>
                <input
                  type="text"
                  tableIndex={0}
                  value={formData.year}
                  onChange={(e) => {
                    const value = e.target.value;
                     if (errors.year) {
          setErrors({ ...errors, year: "" });
        }
                    if (/^\d{0,4}$/.test(value)) {
                      setFormData({ ...formData, year: value });
                    }
                    
                  }}
                  maxLength={4}
                  className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${errors.year ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                  placeholder="Enter Year"
                />
                {errors.year && <p className="text-red1 text-xs mt-1">{errors.year}</p>}
              </div>

              <div className="col-span-1 md:col-span-2">
                <label className="text-xs font-medium text-black/70">Category <span className=" text-red1">*</span></label>
                {isEditing && tableData.length > 1 ? (
                  <div className="relative w-full">
                    <input
                      type="text"
                      value={formData.category}
                      tabIndex={0}
                      maxLength={50}
                     onChange={(e) => {
    const value = e.target.value;

    // update form data
    setFormData((prev) => ({
      ...prev,
      category: value,
    }));

    // remove error when typing
    setErrors((prev) => ({
      ...prev,
      category: "",
    }));

    setShowSuggestions(true);
  }}
onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setShowSuggestions(true);
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowSuggestions(false);
    }

  }}
                      placeholder="Select or type Category"
                      className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all ${showSuggestions ? "border-b-white" : ""} ${errors.category ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                    />

                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowSuggestions((prev) => !prev)}
                      className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${showSuggestions ? "rotate-180" : "rotate-0"}`}
                    >
                      <path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
                    </svg>

                  {showSuggestions && (
  <div
    ref={categoryRef}
    className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {/* 🔍 Search (only if many categories) */}
    {Array.from(
      new Set(tableData.map((item) => item.category).filter(Boolean))
    ).length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5  z-10">
        <input
          type="text"
          placeholder="Search category..."
          value={categorySearch}
          onChange={(e) => setCategorySearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
        />
      </div>
    )}

    {/* 📋 Category list */}
    {Array.from(new Set(tableData.map((item) => item.category)))
      .filter(Boolean)
      .filter((category) => !categoryName.includes(category)) // hide used
      .filter((category) =>
        categorySearch
          ? category.toLowerCase().includes(categorySearch.toLowerCase())
          : true
      )
      .sort((a, b) => a.localeCompare(b))
      .map((category, idx) => (
        <div
  tabIndex={0}
  data-option
  key={idx}
  className={`w-full px-3 py-1.5 text-xs cursor-pointer transition
    ${
      formData.category === category
        ? "bg-lightBlue/30 font-medium"
        : "hover:bg-gray-100"
    }`}

  onKeyDown={(e) => {

    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowSuggestions(false);
      categoryRef.current?.querySelector("input")?.focus();
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData((prev) => ({ ...prev, category }));
      setShowSuggestions(false);
      setCategorySearch("");
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault();
    setFormData((prev) => ({ ...prev, category }));
    setShowSuggestions(false);
    setCategorySearch("");
  }}
>
  {category}
</div>
      ))}

    {/* ❌ No results */}
    {Array.from(new Set(tableData.map((item) => item.category)))
      .filter(Boolean)
      .filter((category) =>
        categorySearch
          ? category.toLowerCase().includes(categorySearch.toLowerCase())
          : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic">
        No categories found
      </div>
    )}
  </div>
)}

                  </div>
                ) : (
                  <input
                    type="text"
                    value={formData.category}
                    onChange={(e) => {
                       if (errors.category) {
          setErrors({ ...errors, category: "" });
        }
                      setFormData({ ...formData, category: e.target.value })}}
                    placeholder="Enter Category"
                    className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${errors.category ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                  />
                )}
                {errors.category && <p className="text-red1 text-xs mt-1">{errors.category}</p>}
              </div>

              <div className="col-span-3 relative">
                <label className="text-xs font-medium text-black/70">Equipment Make <span className=" text-red1">*</span></label>
                <div className="relative">
                  <input
                    type="text"
                    value={formData.equipment_make || ""}
                    maxLength={30}
                    onChange={(e) => {
                       if (errors.equipment_make) {
          setErrors({ ...errors, equipment_make: "" });
        }
                      setFormData({ ...formData, equipment_make: e.target.value });
                      setShowMakeSuggestions(true);
                    }}
onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setShowMakeSuggestions(true);
    }


    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowMakeSuggestions(false);
    }

  }}
                    placeholder="Select or type Equipment Make"
                    className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all ${showMakeSuggestions ? "border-b-white" : ""} ${errors.equipment_make ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                  />

                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowMakeSuggestions((prev) => !prev)}
                    className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${showMakeSuggestions ? "rotate-180" : "rotate-0"}`}>
                    <path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
                  </svg>

                </div>
               {showMakeSuggestions && (
  <div
    ref={makeRef}
    className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {/* 🔍 Search (show only if many options) */}
    {[...new Set([...makeOptions, ...tableData.map((item) => item.make)])]
      .filter(Boolean).length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5 border-b border-black/10 z-10">
        <input
          type="text"
          placeholder="Search make..."
          value={makeSearch}
          onChange={(e) => setMakeSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
        />
      </div>
    )}

    {/* 📋 Make list */}
    {[...new Set([...makeOptions, ...tableData.map((item) => item.make)])]
      .filter(Boolean)
      .filter((option) => option !== formData.equipment_make) // hide selected
      .filter((option) =>
        makeSearch
          ? option.toLowerCase().includes(makeSearch.toLowerCase())
          : true
      )
      .sort((a, b) => a.localeCompare(b))
      .map((option, idx) => (
        <div
  tabIndex={0}
  data-option
  key={idx}
  className={`px-3 py-1.5 text-xs cursor-pointer transition
  ${
    option === formData.equipment_make
      ? "bg-lightBlue/30 font-medium"
      : "hover:bg-gray-100"
  }`}

  onKeyDown={(e) => {

    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowMakeSuggestions(false);
      makeRef.current?.querySelector("input")?.focus();
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData((prev) => ({
        ...prev,
        equipment_make: option,
      }));
      setShowMakeSuggestions(false);
      setMakeSearch("");
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault();
    setFormData((prev) => ({
      ...prev,
      equipment_make: option,
    }));
    setShowMakeSuggestions(false);
    setMakeSearch("");
  }}
>
  {option}
</div>
      ))}

    {/* ❌ No results */}
    {[...new Set([...makeOptions, ...tableData.map((item) => item.make)])]
      .filter(Boolean)
      .filter((option) =>
        makeSearch
          ? option.toLowerCase().includes(makeSearch.toLowerCase())
          : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic">
        No makes found
      </div>
    )}
  </div>
)}

                {errors.equipment_make && <p className="text-red1 text-xs mt-1">{errors.equipment_make}</p>}
              </div>

              <div className="col-span-1 md:col-span-3">
                <label className="text-xs font-medium text-black/70">Details <span className=" text-red1">*</span></label>
                <input
                  type="text"
                  value={formData.details || ""}
                  onChange={(e) =>{ 
                      const value = e.target.value;
                       if (errors.details) {
          setErrors({ ...errors, details: "" });
        }
                    setFormData({ ...formData, details: e.target.value })}}
                  placeholder="Enter details"
                  className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${errors.details ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                />
                {errors.details && <p className="text-red1 text-xs mt-1">{errors.details}</p>}
              </div>

              <div className="col-span-1 md:col-span-3">
                <label className="text-xs font-medium text-black/70">Measurement Units <span className=" text-red1">*</span></label>
                {isEditing && tableData.length > 1 ? (
                  <div className="relative w-full">
                    <input
                      type="text"
                      value={formData.measurement_units}
                      maxLength={20}
                      onChange={(e) => {
                         if (errors.measurement_units) {
          setErrors({ ...errors,measurement_units: "" });
        }
                        setFormData({ ...formData, measurement_units: e.target.value });
                        setShowMeasurementSuggestions(true);
                      }}
 onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setShowMeasurementSuggestions(true);
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowMeasurementSuggestions(false);
    }

  }}                      placeholder="Select or type Measurement Units"
                      className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all ${showMeasurementSuggestions ? "border-b-white" : ""} ${errors.measurement_units ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                    />

                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowMeasurementSuggestions((prev) => !prev)}
                      className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${showMeasurementSuggestions ? "rotate-180" : "rotate-0"}`}
                    >
                      <path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
                    </svg>

                   {showMeasurementSuggestions && (
  <div
    ref={measurementRef}
    className="absolute left-0 right-0 z-10 bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto"
  >
    {/* 🔍 Search input if many options */}
    {[...new Set([...measurementOptions, ...tableData.map(item => item.measurement)])].filter(Boolean).length > 5 && (
      <div className="sticky top-0 bg-white px-3 py-1.5  z-10">
        <input
          type="text"
          placeholder="Search measurement..."
          value={measurementSearch}
          onChange={(e) => setMeasurementSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
        />
      </div>
    )}

    {/* 🔹 Options list */}
    {[...new Set([...measurementOptions, ...tableData.map(item => item.measurement)])]
      .filter(Boolean)
      .filter(option =>
        measurementSearch
          ? option.toLowerCase().includes(measurementSearch.toLowerCase())
          : true
      )
      .sort((a, b) => a.localeCompare(b))
      .map((option, idx) => (
        <div
  tabIndex={0}
  data-option
  key={idx}
  className={`px-3 py-1.5 text-xs cursor-pointer transition
  ${
    option === formData.measurement_units
      ? "bg-lightBlue/30 font-medium"
      : "hover:bg-gray-100"
  }`}

  onKeyDown={(e) => {

    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowMeasurementSuggestions(false);
      measurementRef.current?.querySelector("input")?.focus();
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData((prev) => ({
        ...prev,
        measurement_units: option,
      }));
      setShowMeasurementSuggestions(false);
      setMeasurementSearch("");
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault();
    setFormData((prev) => ({
      ...prev,
      measurement_units: option,
    }));
    setShowMeasurementSuggestions(false);
    setMeasurementSearch("");
  }}
>
  {option}
</div>
      ))}

    {/* ❌ No results */}
    {[...new Set([...measurementOptions, ...tableData.map(item => item.measurement)])]
      .filter(Boolean)
      .filter(option =>
        measurementSearch
          ? option.toLowerCase().includes(measurementSearch.toLowerCase())
          : true
      ).length === 0 && (
      <div className="px-3 py-2 text-xs text-gray-400 italic">
        No measurements found
      </div>
    )}
  </div>
)}

                  </div>
                ) : (
                  <input
                    type="text"
                    value={formData.measurement_units}
                    onChange={(e) =>{ 
                        const value = e.target.value;
                         if (errors.measurement_units) {
          setErrors({ ...errors, measurement_units: "" });
        }
                      setFormData({ ...formData, measurement_units: e.target.value })}}
                    placeholder="Enter Measurement Units"
                    className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${errors.measurement_units ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                  />
                )}
                {errors.measurement_units && <p className="text-red1 text-xs mt-1">{errors.measurement_units}</p>}
              </div>

              <div className="col-span-3 w-full relative">
                <label className="text-xs font-medium text-black/70">Is DI Required? <span className=" text-red1">*</span></label>

                <div className="relative w-full">
                  <input
                    type="text"
                    tabIndex={0}
                    value={formData.di_required || ""}
                    onChange={(e) => {
                       if (errors.di_required) {
          setErrors({ ...errors, di_required: "" });
        }
                      setFormData({ ...formData, di_required: e.target.value })}}
 onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      setShowDIRequiredDropdown(true);
    }

    

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowDIRequiredDropdown(false);
    }

  }}                    onBlur={() => setTimeout(() => setShowDIRequiredDropdown(false), 100)}
                    placeholder="Select or type"
                    className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
                      ${showDIRequiredDropdown ? "border-b-white" : ""}
                      ${errors.di_required ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
                    `}
                  />

                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" onClick={() => setShowDIRequiredDropdown((prev) => !prev)}
                    className={`w-3 h-3 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
                      showDIRequiredDropdown ? "rotate-180" : "rotate-0"
                    }`}>
                    <path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
                  </svg>

                  {showDIRequiredDropdown && (
                    <div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 shadow-md max-h-40 overflow-y-auto">
                      {["Yes", "No"]
                        .filter((option) => option !== formData.di_required)
                        .map((option, idx) => (
                         <div
  tabIndex={0}
  data-option
  key={idx}
  className={`px-3 py-1.5 text-xs cursor-pointer transition
    ${
      option === formData.di_required
        ? "bg-lightBlue/30 font-medium"
        : "hover:bg-gray-100"
    }`
  }

  onKeyDown={(e) => {

    e.stopPropagation();

    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("[data-option]")
    );

    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation()
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation()
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setShowDIRequiredDropdown(false);
      diRequiredRef.current?.querySelector("input")?.focus();
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation()
      setFormData({ ...formData, di_required: option });
      setShowDIRequiredDropdown(false);
    }

  }}

  onMouseDown={(e) => {
    e.preventDefault();
    setFormData({ ...formData, di_required: option });
    setShowDIRequiredDropdown(false);
  }}
>
  {option}
</div>
                        ))}
                    </div>
                  )}
                </div>

                {errors.di_required && (
                  <p className="text-red1 text-xs mt-1">{errors.di_required}</p>
                )}
              </div>
            </div>

            <button
            id="saveuptimetBtn"
              onClick={async () => {
                const newErrors = {}
                if (!formData.year) {
                  newErrors.year = "Please enter this field";
                } else if (!/^\d{4}$/.test(formData.year)) {
                  newErrors.year = "Enter a valid 4-digit year";
                } else if (isNaN(formData.year)) {
                  newErrors.year = "Please enter a valid year"
                }
                if (!formData.category) newErrors.category = "Please enter this field"
                if (!formData.equipment_make) newErrors.equipment_make = "Please enter this field"
                if (!formData.details) newErrors.details = "Please enter this field"
                if (!formData.measurement_units) newErrors.measurement_units = "Please enter this field"
                if (!formData.di_required) newErrors.di_required = "Please enter this field"

                if (Object.keys(newErrors).length > 0) {
                  setErrors(newErrors)
                  return
                }

                try {
                  let success = false;

                  if (isEditing) {
                    const itemId = filteredData[editIndex].id;
                    success = await handleUpdateUptimePartsCategory(itemId, formData);
                  } else {
                    success = await handleAddUptimePartsCategory(formData);
                     if (success) {
    resetSortAndFilter(); 
  }
                  }

                  if (success) {
                    setFormData({ year: "", category: "", equipment_make: "", details: "", measurement_units: "", di_required: "" })
                    setErrors({})
                    setIsEditing(false)
                    setEditIndex(null)
                    setIsAddUserOpen(false)
                  }
                } catch (error) {
                  // console.error("Error saving uptime parts category:", error);
                  setError("Failed to save. Please try again.");
                }
              }}
              disabled={apiLoading}
              className="mt-6 bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {apiLoading ? "Saving..." : "Save"}
            </button>
          </div>
        </div>
      )}

      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={async () => {
          if (deleteIndex !== null) {
            try {
              const itemId = filteredData[deleteIndex].id;
              const success = await handleDeleteUptimePartsCategory(itemId);

              if (success) {
                resetSortAndFilter(); // ✅ reset only on DELETE
                setDeleteIndex(null);
                setIsDeleteModalOpen(false);
              }
            } catch (error) {
              // console.error("Error deleting uptime parts category:", error);
              setError("Failed to delete. Please try again.");
            }
          }
        }}
      />

      {showActivateModal && selectedRow !== null && (
        <ActivateStatus
          isOpen={showActivateModal}
          onClose={() => setShowActivateModal(false)}
          onConfirm={async () => {
            try {
              const itemId = filteredData[selectedRow].id;
              const success = await handleToggleUptimePartsCategory(itemId);

              if (success) {
                setShowActivateModal(false);
                setSelectedRow(null);
              }
            } catch (error) {
              // console.error("Error activating uptime parts category:", error);
              setError("Failed to activate. Please try again.");
            }
          }}
        />
      )}

      {showDeactivateModal && selectedRow !== null && (
        <DeactivateStatus
          isOpen={showDeactivateModal}
          onClose={() => setShowDeactivateModal(false)}
          onConfirm={async () => {
            try {
              const itemId = filteredData[selectedRow].id;
              const success = await handleToggleUptimePartsCategory(itemId);

              if (success) {
                setShowDeactivateModal(false);
                setSelectedRow(null);
              }
            } catch (error) {
              // console.error("Error deactivating uptime parts category:", error);
              setError("Failed to deactivate. Please try again.");
            }
          }}
        />
      )}
    </div>
  )
}

export default Uptimeandparts;