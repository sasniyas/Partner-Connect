import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import DeleteModal from "../../../../../Components/DeleteModal"
import * as XLSX from "xlsx";
import ActivateStatus from "../../../../../Components/ActivateStatus"
import DeactivateStatus from "../../../../../Components/DeactivateStatus"
import Filter from "../../../../../Components/Filter"
import { ChevronUp } from "lucide-react"
import { ChevronDown } from "lucide-react";
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import { ChevronsUpDown } from "lucide-react"
import useCRUDWithReset from "../../../../../util/useCRUDWithReset"
import {
  addOthersData,
  getAllOthersData,
  updateOthersData,
  toggleOthersData,
  deleteOthersData,
} from "../../../../../services/pdpMaster/otherData.service"
import { uploadTempFile } from "../../../../../services/download/bluckDownload.service"
import { formatedTime } from "../../../../../util/timeFormat"
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { useKeyboardNavigation } from "../../../../../util/useKeyboardNavigation"
// Custom debounce hook
const useDebounce = (value, delay) => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
};

function OthersData() {
  // ========== UI STATES ==========
  const [menuOpen, setMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const dropdownRef = useRef(null)
  const fileInputRef = useRef(null)
  const popupRef = useRef (null)
  // ========== TABLE DATA STATES ==========
  const [tableData, setTableData] = useState([])
  const [formData, setFormData] = useState({ 
    id: null,
    file_name: "" 
  });
  const [isEditing, setIsEditing] = useState(false)
  const [selectedRow, setSelectedRow] = useState(null)
  const [errors, setErrors] = useState({})
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedStatus, setSelectedStatus] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [loadingToggle, setLoadingToggle] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [hoveredCell, setHoveredCell] = useState(null);

  // ========== SORT STATES ==========
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null);

  // ========== OPTIONS ==========
  const statusOptions = ["Active", "Inactive"];

  // ========== DEBOUNCE SEARCH ==========
  const debouncedSearchQuery = useDebounce(searchQuery, 300);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  // ========== SORT HANDLER ==========
  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc");
        return;
      }
      if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
        return;
      }
    }
    setSortKey(key);
    setSortOrder("asc");
  };

  // ========== FILTERED DATA (NO LAZY LOADING) ==========
  const filteredData = useMemo(() => {
    return tableData.filter((item) => {
      // 1️⃣ Search filter
      const matchesSearch = Object.values(item).some((val) =>
        String(val || "")
          .toLowerCase()
          .includes(debouncedSearchQuery.trim().toLowerCase())
      );

      // 2️⃣ Status filter
      const matchesStatus =
        selectedStatus.length > 0
          ? selectedStatus.includes(item.status)
          : true;

      return matchesSearch && matchesStatus;
    });
  }, [tableData, debouncedSearchQuery, selectedStatus]);

  // ========== SORTED DATA ==========
  const sortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredData;

    return [...filteredData].sort((a, b) => {
      const aVal = (a[sortKey] ?? "").toString().toLowerCase();
      const bVal = (b[sortKey] ?? "").toString().toLowerCase();

      return sortOrder === "asc"
        ? aVal.localeCompare(bVal, undefined, { numeric: true, sensitivity: "base" })
        : bVal.localeCompare(aVal, undefined, { numeric: true, sensitivity: "base" });
    });
  }, [filteredData, sortKey, sortOrder]);
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchQuery: { setter: setSearchQuery, resetValue: "" },
    selectedStatus: { setter: setSelectedStatus, resetValue: [] }
  }
);

  // ========== FETCH DATA ON MOUNT ==========
  useEffect(() => {
    fetchOthersData();
  }, []);

  const fetchOthersData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await getAllOthersData();
      
      if (response) {
        const dataArray = Array.isArray(response) ? response : (response.data || []);
        
        if (!Array.isArray(dataArray)) {
          throw new Error("Invalid response format from API");
        }
        
        const transformedData = dataArray.map(item => ({
          id: item.id,
          file_name: item.file_name,
          createdOn: item.createdOn,
          status: item.isActive === 1 ? "Active" : "Inactive"
        }));
        setTableData(transformedData);
      }
    } catch (err) {
      // console.error("Error fetching others data:", err);
      setError(err.message || "Failed to fetch others data");
    } finally {
      setIsLoading(false);
    }
  };

  // ========== SCROLL EVENT ==========
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // ========== DROPDOWN OUTSIDE CLICK ==========
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // ========== KEYBOARD SHORTCUTS ==========
  useEffect(() => {
    const handleKeyPress = (e) => {
      // Escape to close modal
      if (e.key === 'Escape' && isAddUserOpen) {
        closePopup();
      }
      // Ctrl+S or Cmd+S to save
      if ((e.ctrlKey || e.metaKey) && e.key === 's' && isAddUserOpen) {
        e.preventDefault();
        handleSave();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [isAddUserOpen, formData, isEditing]);

  // ========== SANITIZE INPUT ==========
  const sanitizeInput = (input) => {
    return input.trim().replace(/<[^>]*>/g, '');
  };

  // ========== EDIT HANDLER ==========
  const handleEdit = (item) => {
    setFormData({
      id: item.id,
      file_name: item.file_name
    });
    setSelectedRow(item.id);
    setIsEditing(true);
    setErrors({});
    setIsAddUserOpen(true);
  };

  // ========== DELETE HANDLER ==========
  const handleDelete = async () => {
    if (selectedRow === null) return;

    try {
      await deleteOthersData(selectedRow);
      setTableData((prev) => prev.filter((item) => item.id !== selectedRow));
      resetSortAndFilter()
      setIsDeleteModalOpen(false);
      setSelectedRow(null);
    } catch (err) {
      // console.error("Error deleting others data:", err);
      // alert(err.message || "Failed to delete others data");
    }
  };

  // ========== SAVE HANDLER ==========
  const handleSave = async () => {
    const newErrors = {};

    const sanitizedfile_name = formData.file_name?.trim();
    
    if (!sanitizedfile_name) {
      newErrors.file_name = "Please fill this field";
    } else if (sanitizedfile_name.length < 2) {
      newErrors.file_name = "File name must be at least 2 characters";
    } else if (sanitizedfile_name.length > 100) {
      newErrors.file_name = "File name cannot exceed 100 characters";
    }

    // Check for duplicates
    const isDuplicate = tableData.some(item => 
      item.file_name.toLowerCase() === sanitizedfile_name.toLowerCase() && 
      (!isEditing || item.id !== formData.id)
    );
    
    if (isDuplicate) {
      newErrors.file_name = "This file name already exists";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      const payload = {
        file_name: sanitizeInput(formData.file_name)
      };

      if (isEditing) {
        await updateOthersData(formData.id, payload);
        
        setTableData(prev => prev.map(item =>
          item.id === formData.id 
            ? { ...item, ...payload } 
            : item
        ));
      } else {
        await addOthersData(payload);
        resetSortAndFilter()
        await fetchOthersData();
      }

      closePopup();
    } catch (err) {
      // console.error("Error saving others data:", err);
      // alert(err.message || "Failed to save others data");
    }
  };

  // ========== TOGGLE STATUS HANDLER ==========
  const handleToggleStatus = async () => {
    if (selectedRow === null) return;

    setLoadingToggle(true);
    
    try {
      await toggleOthersData(selectedRow);
      
      setTableData(prev => prev.map(item =>
        item.id === selectedRow
          ? { ...item, status: item.status === "Active" ? "Inactive" : "Active" }
          : item
      ));
      
      setShowDeactivateModal(false);
      setShowActivateModal(false);
      setSelectedRow(null);
    } catch (err) {
      // console.error("Error toggling status:", err);
      // alert(err.message || "Failed to toggle status");
    } finally {
      setLoadingToggle(false);
    }
  };

  // ========== CLOSE POPUP ==========
  const closePopup = () => {
    setIsAddUserOpen(false);
    setIsEditing(false);
    setSelectedRow(null);
    setFormData({ id: null, file_name: "" });
    setErrors({});
  };

  // ========== DOWNLOAD TEMPLATE ==========
  const handleDownloadTemplate = async () => {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Others Data");

    sheet.columns = [
      { header: "File Name", key: "fileName", width: 40 },
    ];

    const headerRow = sheet.getRow(1);
    headerRow.eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      };
      cell.alignment = { vertical: "middle", horizontal: "left" };
      cell.protection = { locked: true };
    });

    const dummyRow = sheet.addRow({ fileName: "External SWOT" });
    dummyRow.getCell(1).protection = { locked: false };

    for (let row = 3; row <= 1000; row++) {
      sheet.getRow(row).getCell(1).protection = { locked: false };
    }

    sheet.dataValidations.add("A2:A1000", {
      type: "custom",
      allowBlank: false,
      formulae: ['LEN(TRIM(A2))>0'],
      showErrorMessage: true,
      errorTitle: "Required",
      error: "File Name cannot be blank",
    });

    await sheet.protect("password123", {
      selectLockedCells: true,
      selectUnlockedCells: true,
      insertRows: true,
      deleteRows: true,
      formatColumns: true,
      formatRows: true,
    });

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer]), "Others_Data_Bulk_Upload_Template.xlsx");
  };

  // ========== BULK UPLOAD ==========
  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const previewTab = window.open(
      "/bulkupload/other-data",
      "_blank"
    );

    if (!previewTab) {
      // alert("Popup blocked! Please allow popups.");
      return;
    }

    const reader = new FileReader();

    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];

      let rows = XLSX.utils.sheet_to_json(
        workbook.Sheets[sheetName],
        { defval: "" }
      );

      rows = rows.filter((row) =>
        Object.values(row).some((v) => v !== "")
      );

      const finalRows = rows.map((row, index) => ({
        slNo: index + 1,
        fileName: row["File Name"] || "",
        hasError: !row["File Name"],
      }));

      previewTab.postMessage(
        {
          type: "OTHER_DATA_PREVIEW",
          payload: { rows: finalRows },
        },
        "*"
      );
    };

    reader.readAsArrayBuffer(file);
  };

  // ========== PREVIEW & DOWNLOAD (✅ USES SORTEDDATA) ==========
  const handlePreviewAndDownload = async () => {
    if (!sortedData || sortedData.length === 0) {
      // alert("No data available to preview");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("Others Data");

      sheet.columns = [
        { header: "Sl No", key: "slNo", width: 10 },
        { header: "File Name", key: "fileName", width: 40 },
        { header: "Created On", key: "createdOn", width: 25 },
        { header: "Status", key: "status", width: 15 },
      ];

      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.alignment = { vertical: "middle", horizontal: "left" };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        };
      });

      sortedData.forEach((item, index) => {
        const row = sheet.addRow({
          slNo: index + 1,
          fileName: item.file_name || "",
          createdOn: item.createdOn ? formatedTime(item.createdOn) : "-",
          status: item.status || "Inactive",
        });

        row.eachCell((cell) => {
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const file = new File([blob], "OtherData.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const response = await uploadTempFile(file);

      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        // console.warn("Upload succeeded but no file URL returned");
        // alert("Upload succeeded but preview URL not available");
      }
    } catch (error) {
      // console.error("Preview & Download failed:", error);
      // alert("Failed to generate preview. Check console for details.");
    }
  };
useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
  handleSave()
  },

onCancel: () => {
closePopup()
}

});
  // ========== RENDER ==========
  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className="w-full transition-all duration-300 ease-in-out">
            {/* Error Display */}
            {error && (
              <div className="mb-4 p-4 bg-red-50 border border-red-200 flex items-center justify-between">
                <span className="text-red-600">{error}</span>
                <button 
                  onClick={() => setError(null)}
                  className="text-red-600 hover:text-red-800"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Heading */}
            <div className="flex items-center justify-between mb-2 flex-wrap gap-4">
              <h2 className="text-base font-medium font-VolvoNovum text-darkblue1 flex items-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1"
                />
                PDP Data / Other Data
              </h2>
            </div>

            {/* Controls: Search + Filters + Actions */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2 w-full">
              <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-2 w-full">
                <Searchinput
                  onChange={(e) => setSearchQuery(e.target.value)}
                  value={searchQuery}
                  placeholder="Search"
                  className="w-[1/2]"
                  iconColor="text-black"
                  bgColor="bg-FrostWhite"
                  borderColor="border-black/60"
                  textColor="text-black"
                  shadow="shadow-none"
                  inputPadding="pl-6 pr-3 py-1.5"
                  iconSize="w-3 h-3"
                  iconLeft="left-3"
                  inputWidth="w-full"
                  focusRing="focus:ring-1 focus:ring-black/60"
                  hoverInputClasses="hover:bg-white hover:border-black/60"
                />
                <Filter
                  name="status"
                  placeholder="Status"
                  options={statusOptions}
                  value={selectedStatus}
                  customWidth="w-[80px]"
                  placeholderColor="text-black"
                  buttonBorderColor="border-black/60"
                  dropdownBgColor="bg-white"
                  dropdownTextColor="text-black"
                  dropdownHoverColor="hover:bg-lightBlue/50"
                  dropdownBorderColor="border-black/60"
                  closedBgColor="bg-white"
                  hoverRingColor="ring-black"
                  openBgColor="bg-white"
                  textColor="text-black"
                  onChange={(name, value) => setSelectedStatus(value)}
                />
              </div>

              {/* Right Side: Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                <div className="relative w-full sm:w-[190px]" ref={dropdownRef}>
                  <button
                    onClick={() => setOpen(!open)}
                    className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-1.5 text-xs flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
                  >
                    <Plus className="w-3 h-3 stroke-[3]" />
                    Add New
                  </button>

                  {open && (
                    <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1 shadow-lg z-50">
                      <button
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                        onClick={() => {
                          setIsAddUserOpen(true);
                          setOpen(false);
                        }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="5" viewBox="0 0 18 5" fill="none">
                          <path d="M2.25 0C1.95453 -6.22665e-09 1.66194 0.0581978 1.38896 0.171271C1.11598 0.284344 0.867942 0.450078 0.65901 0.65901C0.450078 0.867942 0.284344 1.11598 0.171271 1.38896C0.058198 1.66195 0 1.95453 0 2.25C0 2.54547 0.058198 2.83806 0.171271 3.11104C0.284344 3.38402 0.450078 3.63206 0.65901 3.84099C0.867942 4.04992 1.11598 4.21566 1.38896 4.32873C1.66194 4.4418 1.95453 4.5 2.25 4.5C2.84674 4.5 3.41903 4.26295 3.84099 3.84099C4.26295 3.41903 4.5 2.84674 4.5 2.25C4.5 1.65326 4.26295 1.08097 3.84099 0.65901C3.41903 0.237053 2.84674 1.25753e-08 2.25 0ZM2.25 1.28571C2.50574 1.28571 2.75101 1.38731 2.93185 1.56815C3.11269 1.74899 3.21429 1.99426 3.21429 2.25C3.21429 2.50574 3.11269 2.75101 2.93185 2.93185C2.75101 3.11269 2.50574 3.21429 2.25 3.21429C1.99426 3.21429 1.74899 3.11269 1.56815 2.93185C1.38731 2.75101 1.28571 2.50574 1.28571 2.25C1.28571 1.99426 1.38731 1.74899 1.56815 1.56815C1.74899 1.38731 1.99426 1.28571 2.25 1.28571ZM9 0C9.29548 -6.22665e-09 9.58806 0.0581978 9.86104 0.171271C10.134 0.284344 10.3821 0.450078 10.591 0.65901C10.7999 0.867942 10.9657 1.11598 11.0787 1.38896C11.1918 1.66195 11.25 1.95453 11.25 2.25C11.25 2.54547 11.1918 2.83806 11.0787 3.11104C10.9657 3.38402 10.7999 3.63206 10.591 3.84099C10.3821 4.04992 10.134 4.21566 9.86104 4.32873C9.58806 4.4418 9.29548 4.5 9 4.5C8.40326 4.5 7.83097 4.26295 7.40901 3.84099C6.98705 3.41903 6.75 2.84674 6.75 2.25C6.75 1.65326 6.98705 1.08097 7.40901 0.65901C7.83097 0.237053 8.40326 1.25753e-08 9 0ZM9 1.28571C8.74426 1.28571 8.49899 1.38731 8.31815 1.56815C8.13731 1.74899 8.03572 1.99426 8.03572 2.25C8.03572 2.50574 8.13731 2.75101 8.31815 2.93185C8.49899 3.11269 8.74426 3.21429 9 3.21429C9.25574 3.21429 9.50101 3.11269 9.68185 2.93185C9.86269 2.75101 9.96429 2.50574 9.96429 2.25C9.96429 1.99426 9.86269 1.74899 9.68185 1.56815C9.50101 1.38731 9.25574 1.28571 9 1.28571ZM15.75 0C16.0455 -6.22665e-09 16.3381 0.0581978 16.611 0.171271C16.884 0.284344 17.1321 0.450078 17.341 0.65901C17.5499 0.867942 17.7157 1.11598 17.8287 1.38896C17.9418 1.66195 18 1.95453 18 2.25C18 2.54547 17.9418 2.83806 17.8287 3.11104C17.7157 3.38402 17.5499 3.63206 17.341 3.84099C17.1321 4.04992 16.884 4.21566 16.611 4.32873C16.3381 4.4418 16.0455 4.5 15.75 4.5C15.1533 4.5 14.581 4.26295 14.159 3.84099C13.7371 3.41903 13.5 2.84674 13.5 2.25C13.5 1.65326 13.7371 1.08097 14.159 0.65901C14.581 0.237053 15.1533 1.25753e-08 15.75 0ZM15.75 1.28571C15.4943 1.28571 15.249 1.38731 15.0681 1.56815C14.8873 1.74899 14.7857 1.99426 14.7857 2.25C14.7857 2.50574 14.8873 2.75101 15.0681 2.93185C15.249 3.11269 15.4943 3.21429 15.75 3.21429C16.0057 3.21429 16.251 3.11269 16.4319 2.93185C16.6127 2.75101 16.7143 2.50574 16.7143 2.25C16.7143 1.99426 16.6127 1.74899 16.4319 1.56815C16.251 1.38731 16.0057 1.28571 15.75 1.28571Z" fill="black"/>
                        </svg>
                        Add Other Data
                      </button>
                      
                      <button
                        onClick={() => navigate("/bulkupload/other-data")}
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                          <path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
                        </svg>
                        Bulk Upload
                      </button>

                      <input
                        type="file"
                        ref={fileInputRef}
                        className="hidden"
                        accept=".xlsx,.xls"
                        onChange={handleBulkUpload}
                      />

                      <button
                        onClick={() => {
                          handleDownloadTemplate();
                          setOpen(false);
                        }}
                        className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 whitespace-nowrap"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
                          <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
                          <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                          <path d="M1 14.75H12" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        Bulk upload Template
                      </button>
                    </div>
                  )}
                </div>

                {/* Download Button */}
                <button
                  onClick={handlePreviewAndDownload}
                  className="group relative text-xs bg-white text-darkblue1 px-4 py-1.5 border border-darkblue1 flex items-center gap-1 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none" className="w-3 h-3 group-hover:hidden">
                    <path d="M7.72667 4H6.66667V0.666667C6.66667 0.3 6.36667 0 6 0H3.33333C2.96667 0 2.66667 0.3 2.66667 0.666667V4H1.60667C1.01333 4 0.713333 4.72 1.13333 5.14L4.19333 8.2C4.45333 8.46 4.87333 8.46 5.13333 8.2L8.19333 5.14C8.61333 4.72 8.32 4 7.72667 4ZM0 10.6667C0 11.0333 0.3 11.3333 0.666667 11.3333H8.66667C9.03333 11.3333 9.33333 11.0333 9.33333 10.6667C9.33333 10.3 9.03333 10 8.66667 10H0.666667C0.3 10 0 10.3 0 10.6667Z" fill="#1B365D"/>
                  </svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" className="w-3 h-3 hidden group-hover:block">
                    <path d="M11.0602 6H10.0002V2.66667C10.0002 2.3 9.70016 2 9.3335 2H6.66683C6.30016 2 6.00016 2.3 6.00016 2.66667V6H4.94016C4.34683 6 4.04683 6.72 4.46683 7.14L7.52683 10.2C7.78683 10.46 8.20683 10.46 8.46683 10.2L11.5268 7.14C11.9468 6.72 11.6535 6 11.0602 6ZM3.3335 12.6667C3.3335 13.0333 3.6335 13.3333 4.00016 13.3333H12.0002C12.3668 13.3333 12.6668 13.0333 12.6668 12.6667C12.6668 12.3 12.3668 12 12.0002 12H4.00016C3.6335 12 3.3335 12.3 3.3335 12.6667Z" fill="white"/>
                  </svg>
                  <span className="font-semibold">Download</span>
                </button>
              </div>
            </div>

            {/* ✅ TABLE WITH DYNAMIC HEIGHT (auto ≤8 rows, scroll >8 rows) */}
            <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
              <div
              ref={tableContainerRef}
                className="overflow-y-auto relative"
                style={{
                  scrollbarWidth: "none",
                  msOverflowStyle: "none",
                  maxHeight: sortedData.length > 8 ? "calc(100vh - 220px)" : "auto",
                }}
                onScroll={handleTableScroll}
              >
                <style jsx>{`
                  div::-webkit-scrollbar {
                    display: none;
                  }
                `}</style>

                <table className="w-full text-xs whitespace-nowrap cursor-pointer">
                  <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                    <tr>
                      <th
                        className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[45%] cursor-pointer select-none"
                        onClick={() => handleSort("file_name")}
                      >
                        <div className="flex items-center gap-1">
                          File Name
                          {sortKey !== "file_name" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
                          {sortKey === "file_name" && sortOrder === "asc" && (
                            <ChevronUp className="w-3 h-3 text-white" />
                          )}
                          {sortKey === "file_name" && sortOrder === "desc" && (
                            <ChevronDown className="w-3 h-3 text-white" />
                          )}
                        </div>
                      </th>
                      <th
                        className="text-left px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[25%] cursor-pointer select-none"
                        onClick={() => handleSort("createdOn")}
                      >
                        <div className="flex items-center gap-1">
                          Created On
                          {sortKey === "createdOn" && sortOrder === "asc" && (
                            <ChevronUp className="w-3 h-3 text-white" />
                          )}
                          {sortKey === "createdOn" && sortOrder === "desc" && (
                            <ChevronDown className="w-3 h-3 text-white" />
                          )}
                        </div>
                      </th>
                      <th className="text-center py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[30%]">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-black">
                    {isLoading && tableData.length === 0 ? (
                      <tr>
                        <td colSpan={3} className="px-6 py-8 text-center text-gray-500">
                          <div className="flex items-center justify-center gap-2">
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                            Loading...
                          </div>
                        </td>
                      </tr>
                    ) : sortedData.length > 0 ? (
                      sortedData.map((item, index) => (
                        <tr
                          key={item.id}
                          className={`hover:bg-lightBlue/50 text-xs
                            ${item.status === "Active" ? "text-black" : "text-gray-400"}`}
                        >
                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                            <div className="relative">
                              <p
                                className="truncate max-w-[15rem] cursor-pointer"
                                onMouseEnter={() => {
                                  if (item.file_name?.length > 15)
                                    setHoveredCell(item.id + "-file_name");
                                }}
                                onMouseLeave={() => setHoveredCell(null)}
                              >
                                {item.file_name || "-"}
                              </p>
                              {hoveredCell === item.id + "-file_name" && (
                                <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                                  {item.file_name}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0">
                            {formatedTime(item.createdOn)}
                          </td>

                          <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                            <div className="flex items-center justify-center gap-4">
                              {/* Edit */}
                              <div className="relative group inline-block">
                                <button onClick={() => handleEdit(item)}>
                                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                    <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
                                    <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 z-0">
                                  Edit
                                </span>
                              </div>

                              {/* Activate / Deactivate */}
                              <div className="relative group">
                                <button
                                  onClick={() => {
                                    setSelectedRow(item.id);
                                    if (item.status === "Active") {
                                      setShowDeactivateModal(true);
                                    } else {
                                      setShowActivateModal(true);
                                    }
                                  }}
                                >
                                  {item.status === "Active" ? (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
                                      <path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                    </svg>
                                  ) : (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                      <g clipPath="url(#clip0_5669_3080)">
                                        <path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                      </g>
                                      <defs>
                                        <clipPath id="clip0_5669_3080">
                                          <rect width="24" height="24" fill="white"/>
                                        </clipPath>
                                      </defs>
                                    </svg>
                                  )}
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                  {item.status === "Active" ? "Deactivate" : "Activate"}
                                </span>
                              </div>

                              {/* Delete */}
                              <div className="relative group inline-block">
                                <button
                                  onClick={() => {
                                    setSelectedRow(item.id);
                                    setIsDeleteModalOpen(true);
                                  }}
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                                    <g clipPath="url(#clip0_6398_313)">
                                      <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                                    </g>
                                    <defs>
                                      <clipPath id="clip0_6398_313">
                                        <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                                      </clipPath>
                                    </defs>
                                  </svg>
                                </button>
                                <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 z-0">
                                  Delete
                                </span>
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={3} className="px-4 py-6 text-center italic text-gray-500">
                          No data found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
               {showScrollButtons && (
            <div className="fixed bottom-14 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

            </div>
          </div>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
          <div 
          ref={popupRef}
          className="bg-white p-6 w-full max-w-xl relative">
            <h2 className="text-base font-semibold text-center mb-4 text-MediumGrey">
              {isEditing ? "Edit Other Data" : "Add Other Data"}
            </h2>
            <button
              onClick={closePopup}
              className="absolute top-3 right-4 text-red-600 font-bold text-xl hover:scale-110 transition"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
                role="img"
                aria-label="Close icon"
              >
                <circle cx="10" cy="10" r="8" fill="#BF2012" />
                <path
                  d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>
            </button>
            
            <div className="grid grid-cols-1 gap-3">
              <div>
                <label className="text-xs font-medium text-black/70">File Name <span className="text-red1">*</span></label>
                <input
                  type="text"
                  value={formData.file_name}
                  onChange={(e) => {
                       if (errors.file_name) {
          setErrors({ ...errors, file_name: "" });
        }
                    setFormData({ ...formData, file_name: e.target.value });
                    setErrors({ ...errors, file_name: "" });
                  }}
                  placeholder="Enter File Name"
                  className={`border px-3 py-1.5 w-full mt-1 text-xs outline-none focus:ring-1 ${
                    errors.file_name ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                />
                {errors.file_name && (
                  <p className="text-red1 text-xs mt-1">{errors.file_name}</p>
                )}
              </div>
            </div>
           
            <div className="flex gap-2 justify-center mt-6">
             
              <button
                onClick={handleSave}
                className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setSelectedRow(null);
        }}
        onConfirm={handleDelete}
      />

      {/* Activate Modal */}
      {showActivateModal && selectedRow !== null && (
        <ActivateStatus
          isOpen={showActivateModal}
          loading={loadingToggle}
          onClose={() => {
            if (!loadingToggle) {
              setShowActivateModal(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={handleToggleStatus}
        />
      )}

      {/* Deactivate Modal */}
      {showDeactivateModal && selectedRow !== null && (
        <DeactivateStatus
          isOpen={showDeactivateModal}
          loading={loadingToggle}
          onClose={() => {
            if (!loadingToggle) {
              setShowDeactivateModal(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={handleToggleStatus}
        />
      )}

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleBulkUpload}
        className="hidden"
        accept=".csv,.xlsx,.xls"
      />
    </div>
  )
}

export default OthersData;