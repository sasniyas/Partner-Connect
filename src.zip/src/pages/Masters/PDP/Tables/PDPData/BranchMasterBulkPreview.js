"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../../Components/Header";
import SubNavbar3 from "../../../../../Components/SubNavbar3";
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import { getMarketAreas } from "../../../../../services/pdpMaster/marketArea.service";
import { getDealers } from "../../../../../services/pdpMaster/dealership.service";
import { getAllCities, getAllDistricts } from "../../../../../services/pdpMaster/mainData.service";
import { getBranchMasters, bulkAddBranchMaster } from "../../../../../services/pdpMaster/branchMaster.service";

const facilityTypeOptions = [
  "Touch Point",
  "3S Facility",
  "2S Facility",
  "35 Facility",
  "25 Facility",
];

const developmentStatusOptions = ["New", "In Progress", "Completed"];

function BulkUploadBranchMaster() {
  const [rows, setRows] = useState([]);
  const [fileName, setFileName] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [duplicateInfo, setDuplicateInfo] = useState(null);
  const [isDataLoading, setIsDataLoading] = useState(true);
  const [isDragActive, setIsDragActive] = useState(false);

  // Master data states
  const [marketAreas, setMarketAreas] = useState([]);
  const [dealers, setDealers] = useState([]);
  const [cities, setCities] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [existingBranches, setExistingBranches] = useState([]);

  // Dropdown states - track which dropdown is open and its position
  const [activeDropdown, setActiveDropdown] = useState(null); // { rowIndex, column }
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0, width: 0 });
  const [dropdownSearch, setDropdownSearch] = useState("");
  
  // Refs for dropdown buttons
  const dropdownButtonRefs = useRef({});
  const dropdownMenuRef = useRef(null);
  const tableContainerRef = useRef(null);

  const navigate = useNavigate();

  // =============================== BACK ===============================
  const handleBack = () => {
    navigate("/master/pdp/branchmaster");
  };

  // =============================== LOAD MASTER DATA ===============================
  useEffect(() => {
    const loadMasterData = async () => {
      try {
        setIsDataLoading(true);
        const [maData, dealerData, cityData, districtData, branchData] = await Promise.all([
          getMarketAreas(),
          getDealers(),
          getAllCities(),
          getAllDistricts(),
          getBranchMasters(),
        ]);

        setMarketAreas(maData || []);
        setDealers(dealerData || []);
        setCities(cityData || []);
        setDistricts(districtData || []);
        setExistingBranches(branchData || []);
      } catch (err) {
        console.error("Error loading master data:", err);
        toast.error("Failed to load master data");
      } finally {
        setIsDataLoading(false);
      }
    };

    loadMasterData();
  }, []);

  // =============================== HELPER FUNCTIONS ===============================
  const normalize = (str) => (str || "").toString().trim().toLowerCase();

  const findMarketAreaId = (name) => {
    const found = marketAreas.find((m) => normalize(m.marketarea) === normalize(name));
    return found ? found.id : null;
  };

  const findDealerId = (name) => {
    const found = dealers.find((d) => normalize(d.dealerName) === normalize(name));
    return found ? found.id : null;
  };

  const findCityId = (name) => {
    const found = cities.find((c) => normalize(c.city_name) === normalize(name));
    return found ? found.id : null;
  };

  const findDistrictIds = (districtNames, cityId) => {
    if (!districtNames || !Array.isArray(districtNames)) return [];
    
    const city = cities.find((c) => c.id === cityId);
    const stateName = city?.state_name;
    
    const foundIds = districtNames
      .map((name) => {
        const found = districts.find((d) => {
          const nameMatch = normalize(d.district_name) === normalize(name);
          if (stateName) {
            return nameMatch && d.state_name === stateName;
          }
          return nameMatch;
        });
        
        return found ? found.id : null;
      })
      .filter((id) => id !== null);
    
    return foundIds;
  };

  const getMarketAreaName = (id) => {
    const found = marketAreas.find((m) => m.id === id);
    return found ? found.marketarea : "";
  };

  const getDealerName = (id) => {
    const found = dealers.find((d) => d.id === id);
    return found ? found.dealerName : "";
  };

  const getCityName = (id) => {
    const found = cities.find((c) => c.id === id);
    return found ? found.city_name : "";
  };

  const getDistrictNames = (ids) => {
    if (!ids || !Array.isArray(ids)) return [];
    return ids
      .map((id) => {
        const found = districts.find((d) => d.id === id);
        return found ? found.district_name : null;
      })
      .filter((name) => name !== null);
  };

  const getStateNameFromCity = (cityId) => {
    if (!cityId) return null;
    const city = cities.find((c) => c.id === cityId);
    const state_name = city?.state_name ?? '';
    return state_name;
  };

  const getFilteredDistricts = (cityId) => {
    const state_name = getStateNameFromCity(cityId);
    if (!state_name) return [];
    return districts.filter(d => d.state_name === state_name);
  };

  // =============================== VALIDATE ROW ===============================
  const validateRow = (row) => {
    const errors = [];

    if (!row.market_area_id) errors.push("Invalid Market Area");
    if (!row.dealership_id) errors.push("Invalid Dealership");
    if (!row.city_id) errors.push("Invalid City");
    if (!row.district_ids || row.district_ids.length === 0) errors.push("No valid Districts");
    if (!row.branch_name || !row.branch_name.trim()) errors.push("Branch Name required");
    if (!row.facility_type || !facilityTypeOptions.includes(row.facility_type)) errors.push("Invalid Facility Type");
    if (!row.development_status || !developmentStatusOptions.includes(row.development_status)) errors.push("Invalid Development Status");

    return {
      hasError: errors.length > 0,
      errors,
    };
  };

  // =============================== PARSE EXCEL FILE ===============================
  const parseExcelFile = (arrayBuffer) => {
    const data = new Uint8Array(arrayBuffer);
    const workbook = XLSX.read(data, { type: "array" });
    const sheetName = workbook.SheetNames[0];

    let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });

    // Remove empty rows
    json = json.filter((row) => Object.values(row).some((cell) => String(cell).trim() !== ""));

    // Clean column names
    const cleanedJson = json.map((row) => {
      const newRow = {};
      Object.keys(row).forEach((key) => {
        newRow[key.trim()] = row[key];
      });
      return newRow;
    });

    const finalRows = cleanedJson.map((row, index) => {
      const marketAreaName = String(row["Market Area"] || row["MarketArea"] || "").trim();
      const dealerName = String(row["Dealership"] || row["Dealer Name"] || "").trim();
      const cityName = String(row["City"] || row["City Name"] || "").trim();
      const districtsStr = String(row["Districts"] || "").trim();
      const branchName = String(row["Branch Name"] || row["BranchName"] || "").trim();
      const facilityType = String(row["Facility Type"] || row["FacilityType"] || "").trim();
      const developmentStatus = String(row["Development Status"] || row["DevelopmentStatus"] || "").trim();

      const districtNamesArray = districtsStr
        ? districtsStr.split(",").map((d) => d.trim()).filter((d) => d)
        : [];

      const market_area_id = findMarketAreaId(marketAreaName);
      const dealership_id = findDealerId(dealerName);
      const city_id = findCityId(cityName);
      const district_ids = findDistrictIds(districtNamesArray, city_id);

      const rowData = {
        id: index + 1,
        market_area_id,
        dealership_id,
        city_id,
        district_ids,
        branch_name: branchName,
        facility_type: facilityType,
        development_status: developmentStatus,
        market_area_name: marketAreaName,
        dealer_name: dealerName,
        city_name: cityName,
        district_names: districtNamesArray,
        isDuplicate: false,
        duplicateReason: "",
      };

      const validation = validateRow(rowData);
      return {
        ...rowData,
        hasError: validation.hasError,
        errors: validation.errors,
      };
    });

    return finalRows;
  };

  // =============================== FILE UPLOAD ===============================
  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!marketAreas.length || !dealers.length || !cities.length || !districts.length) {
      toast.error("Master data not yet loaded. Please wait a moment and retry.");
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully`);
      } catch (error) {
        console.error("Error parsing file:", error);
        toast.error("Failed to parse Excel file");
      }
    };

    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  // =============================== DRAG AND DROP HANDLERS ===============================
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    const file = e.dataTransfer.files[0];
    if (!file) return;

    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error("Please drop an Excel file (.xlsx or .xls)");
      return;
    }

    if (!marketAreas.length || !dealers.length || !cities.length || !districts.length) {
      toast.error("Master data not yet loaded. Please wait a moment and retry.");
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully`);
      } catch (error) {
        console.error("Error parsing file:", error);
        toast.error("Failed to parse Excel file");
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // =============================== CHECK DUPLICATES ===============================
  const checkDuplicates = async () => {
    if (rows.length === 0) {
      toast.error("No data to check. Please upload a file first.");
      return;
    }

    setIsChecking(true);
    setDuplicateInfo(null);

    try {
      // Composite key matching backend: market_area_id | dealership_id | city_id | branch_name
      const existingKeys = new Set();
      if (Array.isArray(existingBranches)) {
        existingBranches.forEach((item) => {
          const compositeKey = [
            normalize(item.market_area_id),
            normalize(item.dealership_id),
            normalize(item.city_id),
            normalize(item.branch_name),
          ].join("||");
          existingKeys.add(compositeKey);
        });
      }

      const seenInFile = new Set();

      const updatedRows = rows.map((row) => {
        const compositeKey = [
          normalize(row.market_area_id),
          normalize(row.dealership_id),
          normalize(row.city_id),
          normalize(row.branch_name),
        ].join("||");

        let isDuplicate = false;
        let duplicateReason = "";

        if (row.branch_name) {
          if (existingKeys.has(compositeKey)) {
            isDuplicate = true;
            duplicateReason = "This branch combination already exists in database";
          }

          if (seenInFile.has(compositeKey) && !isDuplicate) {
            isDuplicate = true;
            duplicateReason = "Duplicate branch combination within uploaded file";
          }

          seenInFile.add(compositeKey);
        }
        return {
          ...row,
          isDuplicate,
          duplicateReason,
        };
      });

      setRows(updatedRows);

      const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

      if (duplicateCount > 0) {
        setDuplicateInfo({
          count: duplicateCount,
          message: `${duplicateCount} duplicate(s) found! These will be skipped during save.`,
          type: "warning",
        });
        toast.warning(`${duplicateCount} duplicate record(s) found!`);
      } else {
        setDuplicateInfo({
          count: 0,
          message: "No duplicates found. All records are unique.",
          type: "success",
        });
        toast.success("No duplicates found!");
      }
    } catch (error) {
      console.error("Error checking duplicates:", error);
      toast.error("Failed to check duplicates");
    } finally {
      setIsChecking(false);
    }
  };

  // =============================== EDIT CELL ===============================
  const handleCellChange = (rowIdx, key, value) => {
    const updated = [...rows];

    if (key === "market_area_id") {
      updated[rowIdx].market_area_id = value;
      updated[rowIdx].market_area_name = getMarketAreaName(value);
    } else if (key === "dealership_id") {
      updated[rowIdx].dealership_id = value;
      updated[rowIdx].dealer_name = getDealerName(value);
    } else if (key === "city_id") {
      updated[rowIdx].city_id = value;
      updated[rowIdx].city_name = getCityName(value);
      updated[rowIdx].district_ids = [];
      updated[rowIdx].district_names = [];
    } else if (key === "district_ids") {
      updated[rowIdx].district_ids = value;
      updated[rowIdx].district_names = getDistrictNames(value);
    } else {
      updated[rowIdx][key] = value;
    }

    const validation = validateRow(updated[rowIdx]);
    updated[rowIdx].hasError = validation.hasError;
    updated[rowIdx].errors = validation.errors;

    updated[rowIdx].isDuplicate = false;
    updated[rowIdx].duplicateReason = "";

    setRows(updated);
    setDuplicateInfo(null);
  };

  // =============================== TOGGLE DISTRICT ===============================
  const toggleDistrict = (rowIdx, districtId) => {
    const updated = [...rows];
    const currentIds = updated[rowIdx].district_ids || [];

    if (currentIds.includes(districtId)) {
      updated[rowIdx].district_ids = currentIds.filter((id) => id !== districtId);
    } else {
      updated[rowIdx].district_ids = [...currentIds, districtId];
    }

    updated[rowIdx].district_names = getDistrictNames(updated[rowIdx].district_ids);

    const validation = validateRow(updated[rowIdx]);
    updated[rowIdx].hasError = validation.hasError;
    updated[rowIdx].errors = validation.errors;

    updated[rowIdx].isDuplicate = false;
    updated[rowIdx].duplicateReason = "";

    setRows(updated);
    setDuplicateInfo(null);
  };

  // =============================== CLEAR ALL DISTRICTS FOR ROW ===============================
  const clearAllDistricts = (rowIdx) => {
    handleCellChange(rowIdx, "district_ids", []);
  };

  // =============================== CLOSE DROPDOWN ===============================
  const closeDropdown = useCallback(() => {
    setActiveDropdown(null);
    setDropdownSearch("");
  }, []);

  // =============================== OPEN DROPDOWN ===============================
  const handleOpenDropdown = (rowIndex, column) => {
    if (activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column) {
      closeDropdown();
      return;
    }

    if (column === "district_ids") {
      const row = rows[rowIndex];
      if (!row.city_id) {
        toast.warning("Please select a City first");
        return;
      }
    }

    const refKey = `${rowIndex}-${column}`;
    const buttonEl = dropdownButtonRefs.current[refKey];
    if (buttonEl) {
      const rect = buttonEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const dropdownHeight = 220;
      
      const spaceBelow = viewportHeight - rect.bottom;
      const openUpward = spaceBelow < dropdownHeight && rect.top > dropdownHeight;
      
      setDropdownPosition({
        top: openUpward ? rect.top - dropdownHeight : rect.bottom + 2,
        left: rect.left,
        width: Math.max(rect.width, 180),
      });
    }
    setActiveDropdown({ rowIndex, column });
    setDropdownSearch("");
  };

  // =============================== SELECT OPTION ===============================
  const handleSelectOption = (rowIdx, column, value) => {
    handleCellChange(rowIdx, column, value);
    closeDropdown();
  };

  // =============================== DELETE ROW ===============================
  const handleDeleteRow = (rowIdx) => {
    const updated = rows.filter((_, idx) => idx !== rowIdx);
    setRows(updated);
    setDuplicateInfo(null);
    closeDropdown();
  };

  // =============================== SAVE ===============================
  const handleSave = async () => {
    const hasError = rows.some((r) => r.hasError);

    if (hasError) {
      toast.error("Please fix all errors before saving. Check highlighted rows.");
      return;
    }

    if (rows.length === 0) {
      toast.error("No data to save. Please upload a file first.");
      return;
    }

    const rowsToSave = rows.filter((r) => !r.isDuplicate);

    if (rowsToSave.length === 0) {
      toast.error("All records are duplicates. Nothing to save.");
      return;
    }

    setIsSaving(true);

    try {
      const payload = rowsToSave.map((r) => ({
        market_area_id: r.market_area_id,
        dealership_id: r.dealership_id,
        city_id: r.city_id,
        district_ids: r.district_ids,
        branch_name: r.branch_name.trim(),
        facility_type: r.facility_type,
        development_status: r.development_status,
        target_date: null,
      }));

      const response = await bulkAddBranchMaster(payload);

      if (response?.status) {
        const insertedCount = response.data?.inserted || payload.length;
        const invalidCount = response.data?.invalid || 0;

        if (invalidCount > 0) {
          toast.success(
            `${insertedCount} record(s) added successfully! ${invalidCount} invalid/duplicate(s) were skipped.`,
            { autoClose: 5000 }
          );
        } else {
          toast.success(`${insertedCount} record(s) added successfully!`);
        }

        setTimeout(() => {
          navigate("/master/pdp/branchmaster");
        }, 1500);
      } else {
        toast.error(response?.message || "Failed to upload data");
      }
    } catch (error) {
      console.error("Bulk upload error:", error);
      toast.error(error.message || "Failed to upload data");
    } finally {
      setIsSaving(false);
    }
  };

  // =============================== CLEAR ALL ===============================
  const handleClearAll = () => {
    setRows([]);
    setFileName("");
    setDuplicateInfo(null);
    closeDropdown();
  };

  // =============================== CLOSE DROPDOWN ON OUTSIDE CLICK ===============================
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return;
      }
      
      const clickedOnButton = Object.values(dropdownButtonRefs.current).some(
        (ref) => ref?.contains(e.target)
      );
      
      if (!clickedOnButton) {
        closeDropdown();
      }
    };
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [closeDropdown]);

  // =============================== CLOSE DROPDOWN ON TABLE SCROLL ===============================
  useEffect(() => {
    const handleTableScroll = () => {
      if (activeDropdown !== null) {
        closeDropdown();
      }
    };

    const tableContainer = tableContainerRef.current;
    if (tableContainer) {
      tableContainer.addEventListener("scroll", handleTableScroll);
    }

    const handleWindowScroll = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return;
      }
      if (activeDropdown !== null) {
        closeDropdown();
      }
    };

    window.addEventListener("scroll", handleWindowScroll, true);

    return () => {
      if (tableContainer) {
        tableContainer.removeEventListener("scroll", handleTableScroll);
      }
      window.removeEventListener("scroll", handleWindowScroll, true);
    };
  }, [activeDropdown, closeDropdown]);

  // =============================== GET DROPDOWN OPTIONS ===============================
  const getDropdownOptions = () => {
    if (!activeDropdown) return [];
    
    const { rowIndex, column } = activeDropdown;
    const row = rows[rowIndex];
    let options = [];
    
    switch (column) {
      case "market_area_id":
        options = marketAreas.map(m => ({ id: m.id, label: m.marketarea }));
        break;
      case "dealership_id":
        options = dealers.map(d => ({ id: d.id, label: d.dealerName }));
        break;
      case "city_id":
        options = cities.map(c => ({ id: c.id, label: c.city_name }));
        break;
      case "facility_type":
        options = facilityTypeOptions.map(ft => ({ id: ft, label: ft }));
        break;
      case "development_status":
        options = developmentStatusOptions.map(ds => ({ id: ds, label: ds }));
        break;
      case "district_ids":
        const filteredDistricts = getFilteredDistricts(row?.city_id);
        options = filteredDistricts.map(d => ({ id: d.id, label: d.district_name }));
        break;
      default:
        options = [];
    }
    
    if (dropdownSearch) {
      options = options.filter(opt => 
        opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
      );
    }
    
    return options;
  };

  // =============================== GET DISPLAY VALUE ===============================
  const getDisplayValue = (row, column) => {
    switch (column) {
      case "market_area_id":
        return row.market_area_id ? getMarketAreaName(row.market_area_id) : "";
      case "dealership_id":
        return row.dealership_id ? getDealerName(row.dealership_id) : "";
      case "city_id":
        return row.city_id ? getCityName(row.city_id) : "";
      case "facility_type":
        return row.facility_type || "";
      case "development_status":
        return row.development_status || "";
      case "district_ids":
        if (row.district_ids?.length > 0) {
          const names = getDistrictNames(row.district_ids);
          return names.join(", ");
        }
        return "";
      default:
        return "";
    }
  };

  // =============================== CHECK IF VALUE IS SELECTED ===============================
  const isValueSelected = (row, column, optionId) => {
    if (column === "district_ids") {
      return row.district_ids?.includes(optionId) || false;
    }
    return row[column] === optionId;
  };

  // =============================== GET PLACEHOLDER ===============================
  const getPlaceholder = (column, row) => {
    switch (column) {
      case "market_area_id": return "Select Market Area";
      case "dealership_id": return "Select Dealership";
      case "city_id": return "Select City";
      case "facility_type": return "Select Facility Type";
      case "development_status": return "Select Dev Status";
      case "district_ids": 
        if (row && !row.city_id) return "Select City first";
        return "Select Districts";
      default: return "Select";
    }
  };

  // =============================== GET SEARCH PLACEHOLDER ===============================
  const getSearchPlaceholder = (column) => {
    switch (column) {
      case "market_area_id": return "Search market area...";
      case "dealership_id": return "Search dealership...";
      case "city_id": return "Search city...";
      case "facility_type": return "Search facility type...";
      case "development_status": return "Search status...";
      case "district_ids": return "Search districts...";
      default: return "Search...";
    }
  };

  // =============================== CHECK IF FIELD IS INVALID ===============================
  const isFieldInvalid = (row, column) => {
    switch (column) {
      case "market_area_id": return !row.market_area_id;
      case "dealership_id": return !row.dealership_id;
      case "city_id": return !row.city_id;
      case "facility_type": return !row.facility_type || !facilityTypeOptions.includes(row.facility_type);
      case "development_status": return !row.development_status || !developmentStatusOptions.includes(row.development_status);
      case "district_ids": return !row.district_ids || row.district_ids.length === 0;
      default: return false;
    }
  };

  // =============================== CHECK IF DISTRICTS DISABLED ===============================
  const isDistrictsDisabled = (row) => {
    return !row.city_id;
  };

  // =============================== RENDER CUSTOM DROPDOWN BUTTON ===============================
  const renderDropdownButton = (row, rowIndex, column) => {
    const isInvalid = isFieldInvalid(row, column);
    const displayValue = getDisplayValue(row, column);
    const placeholder = getPlaceholder(column, row);
    const isOpen = activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column;
    const refKey = `${rowIndex}-${column}`;
    const isDistricts = column === "district_ids";
    const isDisabled = isDistricts && isDistrictsDisabled(row);

    return (
      <div
        ref={(el) => (dropdownButtonRefs.current[refKey] = el)}
        className={`flex justify-between items-start px-2 py-1 border text-xs min-h-[26px] ${
          isDisabled
            ? "border-gray-200 bg-gray-100 cursor-not-allowed"
            : isInvalid
            ? "border-red-500 bg-red-50 cursor-pointer"
            : row.isDuplicate
            ? "border-yellow-500 bg-yellow-50 cursor-pointer"
            : "border-gray-300 bg-white hover:border-gray-400 cursor-pointer"
        }`}
        onClick={() => !isDisabled && handleOpenDropdown(rowIndex, column)}
      >
        <span className={`flex-1 ${isDistricts ? "break-words" : "truncate"} ${
          displayValue ? "text-gray-800" : isDisabled ? "text-gray-400 italic" : "text-gray-400"
        }`}>
          {displayValue || placeholder}
        </span>
        {!isDisabled && (
          isOpen ? (
            <ChevronUp className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1 mt-0.5" />
          ) : (
            <ChevronDown className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1 mt-0.5" />
          )
        )}
      </div>
    );
  };

  // =============================== UI ===============================
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex-1 flex justify-center`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Back */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer hover:scale-110 text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">Branch Master Bulk Upload</h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[8%] ml-7 mb-2"></div>

          {/* Loading Indicator */}
          {isDataLoading && (
            <div className="mb-2 p-2 bg-blue-50 border border-blue-200 text-blue-600 text-xs flex items-center gap-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              Loading master data for validation...
            </div>
          )}

          {/* Upload Section */}
          <div className="mb-4 flex flex-wrap items-center gap-2 w-full">
            {/* Drag & Drop Area */}
            <div
              className={`flex-1 min-w-[200px] max-w-md flex items-center border-2 border-dashed px-3 py-1.5 text-xs transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-black/30 bg-white hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" className="mr-2 flex-shrink-0">
                <path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
              </svg>
              <span className="text-xs text-gray-700 truncate">
                {isDragActive ? "Drop file here..." : fileName || "Drag & drop or click Browse"}
              </span>
              <input type="file" accept=".xlsx,.xls" className="hidden" onChange={handleBulkUpload} id="bulk-upload-input" disabled={isDataLoading} />
            </div>

            <label htmlFor="bulk-upload-input" className={`px-3 py-1.5 bg-darkblue1 text-white text-xs cursor-pointer hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition ${isDataLoading ? "opacity-50 cursor-not-allowed" : ""}`}>
              Browse
            </label>

            {rows.length > 0 && (
              <>
                <button onClick={handleClearAll} className="px-3 py-1.5 bg-gray-500 text-white text-xs hover:bg-gray-600 transition">
                  Clear
                </button>

                <button onClick={checkDuplicates} disabled={isChecking || rows.length === 0} className="px-3 py-1.5 bg-yellow-600 text-white text-xs hover:bg-yellow-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1">
                  {isChecking && <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>}
                  {isChecking ? "Checking..." : "Check Duplicates"}
                </button>
              </>
            )}

            <button onClick={handleSave} disabled={isSaving || rows.length === 0 || isDataLoading || rows.some((r) => r.hasError)} className="px-4 py-1.5 bg-darkblue1 text-white text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1">
              {isSaving && <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>}
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>

          {/* Duplicate Info Banner */}
          {duplicateInfo && (
            <div className={`mb-2 p-2 border text-xs flex items-center justify-between ${duplicateInfo.type === "warning" ? "bg-yellow-50 border-yellow-300 text-yellow-700" : "bg-green-50 border-green-300 text-green-700"}`}>
              <span>
                <span className="font-medium">{duplicateInfo.type === "warning" ? "⚠️ " : "✅ "}</span>
                {duplicateInfo.message}
              </span>
              <button onClick={() => setDuplicateInfo(null)} className="text-gray-500 hover:text-gray-700">✕</button>
            </div>
          )}

          {/* Error Summary */}
          {rows.length > 0 && rows.some((r) => r.hasError) && (
            <div className="mb-2 p-2 bg-red-50 border border-red-200 text-red-600 text-xs">
              <span className="font-medium">⚠️ {rows.filter((r) => r.hasError).length} row(s) have validation errors.</span>
              <span className="ml-2">Please fix all mandatory fields (highlighted in red).</span>
            </div>
          )}

          {/* Table */}
          {rows.length > 0 ? (
            <div className="overflow-auto border border-Dustyblue mb-2 bg-white shadow-md">
              <div ref={tableContainerRef} className="overflow-y-auto max-h-[400px]">
                <table className="w-full text-sm bg-white border-collapse">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-20">
                    <tr>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[3%]">#</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[9%]">Market Area <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[13%]">Dealership <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[9%]">City <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[15%]">Districts <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[12%]">Branch Name <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[10%]">Facility Type <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[12%]">Dev Status <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-center w-[5%]">Status</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium text-center w-[5%]">Action</th>
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((row, i) => (
                      <tr key={i} className={`text-xs hover:bg-lightBlue/50 ${row.hasError ? "bg-red-50" : row.isDuplicate ? "bg-yellow-50" : ""}`}>
                        <td className="px-2 py-1.5 border border-grey2 border-l-0 text-center text-gray-500">{i + 1}</td>
                        <td className="px-2 py-1.5 border border-grey2">{renderDropdownButton(row, i, "market_area_id")}</td>
                        <td className="px-2 py-1.5 border border-grey2">{renderDropdownButton(row, i, "dealership_id")}</td>
                        <td className="px-2 py-1.5 border border-grey2">{renderDropdownButton(row, i, "city_id")}</td>
                        <td className="px-2 py-1.5 border border-grey2">{renderDropdownButton(row, i, "district_ids")}</td>
                        <td className="px-2 py-1.5 border border-grey2">
                          <input type="text" className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${!row.branch_name || !row.branch_name.trim() ? "border-red-500 bg-red-50" : row.isDuplicate ? "border-yellow-500 bg-yellow-50" : "border-gray-300"}`} value={row.branch_name || ""} placeholder="Enter Branch Name" onChange={(e) => handleCellChange(i, "branch_name", e.target.value)} />
                        </td>
                        <td className="px-2 py-1.5 border border-grey2">{renderDropdownButton(row, i, "facility_type")}</td>
                        <td className="px-2 py-1.5 border border-grey2">{renderDropdownButton(row, i, "development_status")}</td>
                        <td className="px-2 py-1.5 border border-grey2 text-center">
                          {row.hasError ? (
                            <span className="px-2 py-0.5 bg-red-100 text-red-600 text-[10px] rounded-full cursor-help" title={row.errors?.join(", ")}>Invalid</span>
                          ) : row.isDuplicate ? (
                            <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full cursor-help" title={row.duplicateReason}>Duplicate</span>
                          ) : (
                            <span className="px-2 py-0.5 bg-green-100 text-green-600 text-[10px] rounded-full">Valid</span>
                          )}
                        </td>
                        <td className="px-2 py-1.5 border border-grey2 border-r-0 text-center">
                          <button onClick={() => handleDeleteRow(i)} className="text-red-500 hover:text-red-700 transition" title="Delete Row">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                              <g clipPath="url(#clip0_6398_313)">
                                <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                              </g>
                              <defs>
                                <clipPath id="clip0_6398_313">
                                  <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                                </clipPath>
                              </defs>
                            </svg>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Footer */}
              <div className="px-4 py-2 bg-gray-50 border-t border-grey2 flex flex-wrap justify-between items-center gap-2">
                <span className="text-xs text-gray-600">
                  Total: {rows.length} row(s) | <span className="text-green-600 ml-1">Valid: {rows.filter((r) => !r.hasError && !r.isDuplicate).length}</span> | <span className="text-yellow-600 ml-1">Duplicates: {rows.filter((r) => r.isDuplicate).length}</span> | <span className="text-red-600 ml-1">Errors: {rows.filter((r) => r.hasError).length}</span>
                </span>
                <span className="text-xs text-gray-500 italic">💡 Click "Check Duplicates" before saving to identify existing branch names</span>
              </div>
            </div>
          ) : (
            <div className={`bg-white shadow-md border-2 border-dashed p-8 text-center transition cursor-pointer ${isDragActive ? "border-darkblue1 bg-blue-50" : "border-Dustyblue hover:border-darkblue1"}`} onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop}>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" className="w-12 h-12 mx-auto mb-3 opacity-50">
                <path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
              </svg>
              <p className="text-gray-500 text-sm">{isDragActive ? "Drop your Excel file here!" : "No data loaded. Please upload an Excel file to preview."}</p>
              <p className="text-gray-400 text-xs mt-1">{isDragActive ? "Release to upload" : "Supported formats: .xlsx, .xls (Drag & drop or click Browse)"}</p>
              <p className="text-gray-400 text-xs mt-1">Required columns: Market Area, Dealership, City, Districts, Branch Name, Facility Type, Development Status</p>
            </div>
          )}
        </div>
      </div>

      {/* ========== DROPDOWN ========== */}
      {activeDropdown !== null && rows[activeDropdown.rowIndex] && (
        <div ref={dropdownMenuRef} className="fixed border border-gray-300 bg-white z-[9999] shadow-xl rounded overflow-hidden" style={{ top: `${dropdownPosition.top}px`, left: `${dropdownPosition.left}px`, width: `${dropdownPosition.width}px`, minWidth: "180px" }}>
          <div className="p-2 border-b border-gray-200 bg-gray-50">
            <input type="text" placeholder={getSearchPlaceholder(activeDropdown.column)} value={dropdownSearch} onChange={(e) => setDropdownSearch(e.target.value)} className="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:outline-none focus:border-darkblue1" autoFocus />
          </div>

          {activeDropdown.column === "district_ids" && rows[activeDropdown.rowIndex]?.district_ids?.length > 0 && (
            <div className="px-3 py-1.5 bg-blue-50 border-b border-gray-200 flex justify-between items-center">
              <span className="text-xs text-blue-700">{rows[activeDropdown.rowIndex].district_ids.length} selected</span>
              <button onClick={() => clearAllDistricts(activeDropdown.rowIndex)} className="text-xs text-red-500 hover:text-red-700">Clear all</button>
            </div>
          )}

          <div className="max-h-[150px] overflow-y-auto">
            {getDropdownOptions().length > 0 ? (
              getDropdownOptions().map((option) => {
                const isSelected = isValueSelected(rows[activeDropdown.rowIndex], activeDropdown.column, option.id);
                const isMultiSelect = activeDropdown.column === "district_ids";
                
                return (
                  <div key={option.id} className={`flex items-center gap-2 px-3 py-1.5 cursor-pointer text-xs border-b border-gray-100 last:border-b-0 ${isSelected ? "bg-blue-50" : "hover:bg-gray-50"}`} onClick={() => { isMultiSelect ? toggleDistrict(activeDropdown.rowIndex, option.id) : handleSelectOption(activeDropdown.rowIndex, activeDropdown.column, option.id); }}>
                    {isMultiSelect && <input type="checkbox" checked={isSelected} onChange={() => {}} className="w-3 h-3 accent-darkblue1" />}
                    <span className={isSelected ? "text-blue-700 font-medium" : ""}>{option.label}</span>
                    {isSelected && !isMultiSelect && <span className="ml-auto text-blue-500">✓</span>}
                  </div>
                );
              })
            ) : (
              <div className="px-3 py-3 text-xs text-gray-400 text-center">No options found</div>
            )}
          </div>

          {activeDropdown.column === "district_ids" && (
            <div className="p-2 border-t border-gray-200 bg-gray-50">
              <button onClick={closeDropdown} className="w-full px-3 py-1 text-xs bg-darkblue1 text-white rounded hover:bg-opacity-90">Done</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default BulkUploadBranchMaster;