"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../../Components/Header";
import SubNavbar3 from "../../../../../Components/SubNavbar3";
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import {
  getUptimePartsCategories,
  bulkAddUptimePartsCategory,
} from "../../../../../services/pdpMaster/uptimePartsCategory.service";

function BulkUploadUptimePartsCategory() {
  const navigate = useNavigate();

  const [rows, setRows] = useState([]);
  const [fileName, setFileName] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [duplicateInfo, setDuplicateInfo] = useState(null);
  const [isDataLoading, setIsDataLoading] = useState(true);
  const [isDragActive, setIsDragActive] = useState(false);

  // Master data states
  const [yearOptions, setYearOptions] = useState([]);
  const [categoryOptions, setCategoryOptions] = useState([]);
  const [equipmentMakeOptions, setEquipmentMakeOptions] = useState(["Volvo", "SDLG"]);
  const [measurementOptions, setMeasurementOptions] = useState([]);
  const [existingUptimePartsCategories, setExistingUptimePartsCategories] = useState([]);

  // Dropdown states
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [dropdownPosition, setDropdownPosition] = useState({
    top: 0,
    left: 0,
    width: 0,
  });
  const [dropdownSearch, setDropdownSearch] = useState("");

  // Refs
  const dropdownButtonRefs = useRef({});
  const dropdownMenuRef = useRef(null);
  const tableContainerRef = useRef(null);

  // =============================== BACK ===============================
  const handleBack = () => {
    navigate("/master/pdp/uptimeparts");
  };

  // =============================== LOAD MASTER DATA ===============================
  useEffect(() => {
    const loadMasterData = async () => {
      try {
        setIsDataLoading(true);
        const data = await getUptimePartsCategories();
        setExistingUptimePartsCategories(data || []);

        // Extract unique years for dropdown
        const years = Array.from(
          new Set((data || []).map((i) => i.year?.toString()).filter(Boolean))
        ).sort((a, b) => Number(b) - Number(a));
        setYearOptions(years);

        // Extract unique categories for dropdown
        const categories = Array.from(
          new Set((data || []).map((i) => i.category).filter(Boolean))
        ).sort();
        setCategoryOptions(categories);

        // Extract unique equipment makes for dropdown (merge with base options)
        const makes = Array.from(
          new Set([
            "Volvo",
            "SDLG",
            ...(data || []).map((i) => i.equipment_make).filter(Boolean),
          ])
        ).sort();
        setEquipmentMakeOptions(makes);

        // Extract unique measurement units for dropdown
        const measurements = Array.from(
          new Set((data || []).map((i) => i.measurement_units).filter(Boolean))
        ).sort();
        setMeasurementOptions(measurements);
      } catch (err) {
        console.error("Error loading master data:", err);
        toast.error("Failed to load master data");
      } finally {
        setIsDataLoading(false);
      }
    };

    loadMasterData();
  }, []);

  // =============================== HELPER FUNCTIONS ===============================
  const normalize = (str) => (str || "").toString().trim().toLowerCase();

  // =============================== VALIDATE ROW ===============================
  const validateRow = (row) => {
    const errors = [];

    if (!row.year || !row.year.toString().trim()) {
      errors.push("Year required");
    } else if (!/^\d{4}$/.test(row.year.toString().trim())) {
      errors.push("Year must be 4 digits");
    }
    if (!row.category || !row.category.trim()) {
      errors.push("Category required");
    }
    if (!row.equipment_make || !row.equipment_make.trim()) {
      errors.push("Equipment Make required");
    }
    if (!row.details || !row.details.trim()) {
      errors.push("Details required");
    }
    if (!row.measurement_units || !row.measurement_units.trim()) {
      errors.push("Measurement Units required");
    }
    if (!row.di_required || !row.di_required.trim()) {
      errors.push("DI Required required");
    } else if (!["Yes", "No"].includes(row.di_required.trim())) {
      errors.push("DI Required must be 'Yes' or 'No'");
    }

    return {
      hasError: errors.length > 0,
      errors,
    };
  };

  // =============================== PARSE EXCEL FILE ===============================
  const parseExcelFile = (arrayBuffer) => {
    const data = new Uint8Array(arrayBuffer);
    const workbook = XLSX.read(data, { type: "array" });
    const sheetName = workbook.SheetNames[0];

    let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
      defval: "",
    });

    // Remove empty rows
    json = json.filter((row) =>
      Object.values(row).some((cell) => String(cell).trim() !== "")
    );

    // Clean column names
    const cleanedJson = json.map((row) => {
      const newRow = {};
      Object.keys(row).forEach((key) => {
        newRow[key.trim()] = row[key];
      });
      return newRow;
    });

    console.log("Parsed Excel data:", cleanedJson);

    const finalRows = cleanedJson.map((row, index) => {
      const year = String(row["Year"] || "").trim();
      const category = String(row["Category"] || "").trim();
      const equipment_make = String(row["Equipment Make"] || "").trim();
      const details = String(row["Details"] || "").trim();
      const measurement_units = String(row["Measurement"] || row["Measurement Units"] || "").trim();
      const di_required = String(row["DI Required"] || "").trim();

      const rowData = {
        id: index + 1,
        year,
        category,
        equipment_make,
        details,
        measurement_units,
        di_required,
        isDuplicate: false,
        duplicateReason: "",
      };

      const validation = validateRow(rowData);
      return {
        ...rowData,
        hasError: validation.hasError,
        errors: validation.errors,
      };
    });

    return finalRows;
  };

  // =============================== FILE UPLOAD ===============================
  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully`);
      } catch (error) {
        console.error("Error parsing file:", error);
        toast.error("Failed to parse Excel file");
      }
    };

    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  // =============================== DRAG AND DROP HANDLERS ===============================
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    const file = e.dataTransfer.files[0];
    if (!file) return;

    // Validate file type
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error("Please drop an Excel file (.xlsx or .xls)");
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully`);
      } catch (error) {
        console.error("Error parsing file:", error);
        toast.error("Failed to parse Excel file");
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // =============================== CHECK DUPLICATES ===============================
  const checkDuplicates = async () => {
    if (rows.length === 0) {
      toast.error("No data to check. Please upload a file first.");
      return;
    }

    setIsChecking(true);
    setDuplicateInfo(null);

    try {
      // Create set of existing records using composite key (year + category + equipment_make + details + measurement_units + di_required)
      const existingKeys = new Set();
      if (Array.isArray(existingUptimePartsCategories)) {
        existingUptimePartsCategories.forEach((item) => {
          const compositeKey = [
            normalize(item.year),
            normalize(item.category),
            normalize(item.equipment_make),
            normalize(item.details),
            normalize(item.measurement_units),
            normalize(item.di_required === 1 || item.di_required === "1" || item.di_required === true ? "yes" : item.di_required === 0 || item.di_required === "0" || item.di_required === false ? "no" : item.di_required),
          ].join("||");
          existingKeys.add(compositeKey);
        });
      }

      const seenInFile = new Set();

      const updatedRows = rows.map((row) => {
        const compositeKey = [
          normalize(row.year),
          normalize(row.category),
          normalize(row.equipment_make),
          normalize(row.details),
          normalize(row.measurement_units),
          normalize(row.di_required),
        ].join("||");

        let isDuplicate = false;
        let duplicateReason = "";

        if (row.details) {
          // Check against database using composite key
          if (existingKeys.has(compositeKey)) {
            isDuplicate = true;
            duplicateReason = "This record combination already exists in database";
          }

          // Check for duplicates within the file using composite key
          if (seenInFile.has(compositeKey) && !isDuplicate) {
            isDuplicate = true;
            duplicateReason = "Duplicate record combination within uploaded file";
          }

          seenInFile.add(compositeKey);
        }

        return {
          ...row,
          isDuplicate,
          duplicateReason,
        };
      });

      setRows(updatedRows);

      const duplicateCount = updatedRows.filter((r) => r.isDuplicate).length;

      if (duplicateCount > 0) {
        setDuplicateInfo({
          count: duplicateCount,
          message: `${duplicateCount} duplicate(s) found! These will be skipped during save.`,
          type: "warning",
        });
        toast.warning(`${duplicateCount} duplicate record(s) found!`);
      } else {
        setDuplicateInfo({
          count: 0,
          message: "No duplicates found. All records are unique.",
          type: "success",
        });
        toast.success("No duplicates found!");
      }
    } catch (error) {
      console.error("Error checking duplicates:", error);
      toast.error("Failed to check duplicates");
    } finally {
      setIsChecking(false);
    }
  };

  // =============================== EDIT CELL ===============================
  const handleCellChange = (rowIdx, key, value) => {
    const updated = [...rows];
    updated[rowIdx][key] = value;

    // Re-validate row
    const validation = validateRow(updated[rowIdx]);
    updated[rowIdx].hasError = validation.hasError;
    updated[rowIdx].errors = validation.errors;

    // Reset duplicate flag
    updated[rowIdx].isDuplicate = false;
    updated[rowIdx].duplicateReason = "";

    setRows(updated);
    setDuplicateInfo(null);
  };

  // =============================== CLOSE DROPDOWN ===============================
  const closeDropdown = useCallback(() => {
    setActiveDropdown(null);
    setDropdownSearch("");
  }, []);

  // =============================== OPEN DROPDOWN ===============================
  const handleOpenDropdown = (rowIndex, column) => {
    const dropdownKey = `${rowIndex}-${column}`;

    if (activeDropdown === dropdownKey) {
      closeDropdown();
      return;
    }

    const refKey = `${rowIndex}-${column}`;
    const buttonEl = dropdownButtonRefs.current[refKey];
    if (buttonEl) {
      const rect = buttonEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const dropdownHeight = 220;

      const spaceBelow = viewportHeight - rect.bottom;
      const openUpward = spaceBelow < dropdownHeight && rect.top > dropdownHeight;

      setDropdownPosition({
        top: openUpward ? rect.top - dropdownHeight : rect.bottom + 2,
        left: rect.left,
        width: Math.max(rect.width, 180),
      });
    }
    setActiveDropdown(dropdownKey);
    setDropdownSearch("");
  };

  // =============================== SELECT OPTION ===============================
  const handleSelectOption = (rowIdx, column, value) => {
    handleCellChange(rowIdx, column, value);
    closeDropdown();
  };

  // =============================== DELETE ROW ===============================
  const handleDeleteRow = (rowIdx) => {
    const updated = rows.filter((_, idx) => idx !== rowIdx);
    const reIndexed = updated.map((row, index) => ({ ...row, id: index + 1 }));
    setRows(reIndexed);
    setDuplicateInfo(null);
    closeDropdown();
  };

  // =============================== SAVE ===============================
  const handleSave = async () => {
    const hasError = rows.some((r) => r.hasError);

    if (hasError) {
      toast.error("Please fix all errors before saving. Check highlighted rows.");
      return;
    }

    if (rows.length === 0) {
      toast.error("No data to save. Please upload a file first.");
      return;
    }

    const rowsToSave = rows.filter((r) => !r.isDuplicate);

    if (rowsToSave.length === 0) {
      toast.error("All records are duplicates. Nothing to save.");
      return;
    }

    setIsSaving(true);

    try {
      const payload = rowsToSave.map((r) => ({
        year: parseInt(r.year),
        category: r.category.trim(),
        equipment_make: r.equipment_make.trim(),
        details: r.details.trim(),
        measurement_units: r.measurement_units.trim(),
        di_required: r.di_required.trim() === "Yes" ? 1 : 0,
      }));

      console.log("Sending bulk upload payload:", payload);

      const response = await bulkAddUptimePartsCategory(payload);

      if (response?.status) {
        const insertedCount = response.data?.inserted || payload.length;
        const invalidCount = response.data?.invalid || 0;

        if (invalidCount > 0) {
          toast.success(
            `${insertedCount} record(s) added successfully! ${invalidCount} invalid/duplicate(s) were skipped.`,
            { autoClose: 5000 }
          );
        } else {
          toast.success(`${insertedCount} record(s) added successfully!`);
        }

        setTimeout(() => {
          navigate("/master/pdp/uptimeparts");
        }, 1500);
      } else {
        toast.error(response?.message || "Failed to upload data");
      }
    } catch (error) {
      console.error("Bulk upload error:", error);
      toast.error(error.message || "Failed to upload data");
    } finally {
      setIsSaving(false);
    }
  };

  // =============================== CLEAR ALL ===============================
  const handleClearAll = () => {
    setRows([]);
    setFileName("");
    setDuplicateInfo(null);
    closeDropdown();
  };

  // =============================== CLOSE DROPDOWN ON OUTSIDE CLICK ===============================
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return;
      }

      const clickedOnButton = Object.values(dropdownButtonRefs.current).some(
        (ref) => ref?.contains(e.target)
      );

      if (!clickedOnButton) {
        closeDropdown();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [closeDropdown]);

  // =============================== CLOSE DROPDOWN ON SCROLL (FIXED) ===============================
  useEffect(() => {
    const handleTableScroll = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return;
      }
      if (activeDropdown !== null) {
        closeDropdown();
      }
    };

    const handleWindowScroll = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return;
      }
      if (activeDropdown !== null) {
        closeDropdown();
      }
    };

    const tableContainer = tableContainerRef.current;
    if (tableContainer) {
      tableContainer.addEventListener("scroll", handleTableScroll);
    }

    window.addEventListener("scroll", handleWindowScroll, true);

    return () => {
      if (tableContainer) {
        tableContainer.removeEventListener("scroll", handleTableScroll);
      }
      window.removeEventListener("scroll", handleWindowScroll, true);
    };
  }, [activeDropdown, closeDropdown]);

  // =============================== GET DROPDOWN OPTIONS ===============================
  const getDropdownOptions = (column) => {
    if (column === "year") {
      // Generate years from 2020 to current year + 5
      const currentYear = new Date().getFullYear();
      const generatedYears = [];
      for (let y = currentYear + 5; y >= 2020; y--) {
        generatedYears.push(y.toString());
      }

      // Merge with existing years from data
      const allYears = Array.from(new Set([...generatedYears, ...yearOptions])).sort(
        (a, b) => Number(b) - Number(a)
      );

      let options = allYears.map((year) => ({ id: year, label: year }));

      if (dropdownSearch) {
        options = options.filter((opt) =>
          opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
        );
      }

      return options;
    }

    if (column === "category") {
      let options = categoryOptions.map((cat) => ({ id: cat, label: cat }));

      if (dropdownSearch) {
        options = options.filter((opt) =>
          opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
        );
      }

      return options;
    }

    if (column === "equipment_make") {
      let options = equipmentMakeOptions.map((make) => ({ id: make, label: make }));

      if (dropdownSearch) {
        options = options.filter((opt) =>
          opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
        );
      }

      return options;
    }

    if (column === "measurement_units") {
      let options = measurementOptions.map((unit) => ({ id: unit, label: unit }));

      if (dropdownSearch) {
        options = options.filter((opt) =>
          opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
        );
      }

      return options;
    }

    if (column === "di_required") {
      let options = ["Yes", "No"].map((val) => ({ id: val, label: val }));

      if (dropdownSearch) {
        options = options.filter((opt) =>
          opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
        );
      }

      return options;
    }

    return [];
  };

  // =============================== GET PLACEHOLDER ===============================
  const getPlaceholder = (column) => {
    switch (column) {
      case "year":
        return "Select Year";
      case "category":
        return "Select Category";
      case "equipment_make":
        return "Select Make";
      case "measurement_units":
        return "Select Unit";
      case "di_required":
        return "Yes/No";
      default:
        return "Select";
    }
  };

  // =============================== GET SEARCH PLACEHOLDER ===============================
  const getSearchPlaceholder = (column) => {
    switch (column) {
      case "year":
        return "Search year...";
      case "category":
        return "Search category...";
      case "equipment_make":
        return "Search make...";
      case "measurement_units":
        return "Search unit...";
      case "di_required":
        return "Search...";
      default:
        return "Search...";
    }
  };

  // =============================== RENDER DROPDOWN BUTTON ===============================
  const renderDropdownButton = (row, rowIndex, column) => {
    const value = row[column];
    let isInvalid = false;

    if (column === "year") {
      isInvalid = !value || !value.toString().trim() || !/^\d{4}$/.test(value.toString().trim());
    } else if (column === "di_required") {
      isInvalid = !value || !value.trim() || !["Yes", "No"].includes(value.trim());
    } else {
      isInvalid = !value || !value.trim();
    }

    const dropdownKey = `${rowIndex}-${column}`;
    const isOpen = activeDropdown === dropdownKey;
    const refKey = `${rowIndex}-${column}`;

    return (
      <div
        ref={(el) => (dropdownButtonRefs.current[refKey] = el)}
        className={`flex justify-between items-center px-2 py-1 border text-xs min-h-[26px] cursor-pointer ${
          isInvalid
            ? "border-red-500 bg-red-50"
            : row.isDuplicate
            ? "border-yellow-500 bg-yellow-50"
            : "border-gray-300 bg-white hover:border-gray-400"
        }`}
        onClick={() => handleOpenDropdown(rowIndex, column)}
      >
        <span
          className={`flex-1 truncate ${
            value ? "text-gray-800" : "text-gray-400"
          }`}
        >
          {value || getPlaceholder(column)}
        </span>
        {isOpen ? (
          <ChevronUp className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1" />
        ) : (
          <ChevronDown className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1" />
        )}
      </div>
    );
  };

  // =============================== GET ACTIVE COLUMN ===============================
  const getActiveColumn = () => {
    if (!activeDropdown) return null;
    return activeDropdown.split("-").slice(1).join("-");
  };

  const getActiveRowIndex = () => {
    if (!activeDropdown) return null;
    return parseInt(activeDropdown.split("-")[0]);
  };

  // =============================== UI ===============================
  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div
        className={`transition-all duration-300 ${
          menuOpen ? "lg:ml-60" : ""
        } flex-1 flex justify-center`}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Back */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer hover:scale-110 text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">
              Uptime & Parts Category Bulk Upload
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[12%] ml-7 mb-2"></div>

          {/* Loading Indicator */}
          {isDataLoading && (
            <div className="mb-2 p-2 bg-blue-50 border border-blue-200 text-blue-600 text-xs flex items-center gap-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              Loading master data for validation...
            </div>
          )}

          {/* Upload Section */}
          <div className="mb-4 flex flex-wrap items-center gap-2 w-full">
            {/* Drag & Drop Area */}
            <div
              className={`flex-1 min-w-[200px] max-w-md flex items-center border-2 border-dashed px-3 py-1.5 text-xs transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-black/30 bg-white hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="mr-2 flex-shrink-0"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>
              <span className="text-xs text-gray-700 truncate">
                {isDragActive
                  ? "Drop file here..."
                  : fileName || "Drag & drop or click Browse"}
              </span>
              <input
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleBulkUpload}
                id="bulk-upload-input"
                disabled={isDataLoading}
              />
            </div>

            <label
              htmlFor="bulk-upload-input"
              className={`px-3 py-1.5 bg-darkblue1 text-white text-xs cursor-pointer hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition ${
                isDataLoading ? "opacity-50 cursor-not-allowed" : ""
              }`}
            >
              Browse
            </label>

            {rows.length > 0 && (
              <>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 bg-gray-500 text-white text-xs hover:bg-gray-600 transition"
                >
                  Clear
                </button>

                <button
                  onClick={checkDuplicates}
                  disabled={isChecking || rows.length === 0}
                  className="px-3 py-1.5 bg-yellow-600 text-white text-xs hover:bg-yellow-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  {isChecking && (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  )}
                  {isChecking ? "Checking..." : "Check Duplicates"}
                </button>
              </>
            )}

            <button
              onClick={handleSave}
              disabled={
                isSaving ||
                rows.length === 0 ||
                isDataLoading ||
                rows.some((r) => r.hasError)
              }
              className="px-4 py-1.5 bg-darkblue1 text-white text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              {isSaving && (
                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
              )}
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>

          {/* Duplicate Info Banner */}
          {duplicateInfo && (
            <div
              className={`mb-2 p-2 border text-xs flex items-center justify-between ${
                duplicateInfo.type === "warning"
                  ? "bg-yellow-50 border-yellow-300 text-yellow-700"
                  : "bg-green-50 border-green-300 text-green-700"
              }`}
            >
              <span>
                <span className="font-medium">
                  {duplicateInfo.type === "warning" ? "⚠️ " : "✅ "}
                </span>
                {duplicateInfo.message}
              </span>
              <button
                onClick={() => setDuplicateInfo(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
          )}

          {/* Error Summary */}
          {rows.length > 0 && rows.some((r) => r.hasError) && (
            <div className="mb-2 p-2 bg-red-50 border border-red-200 text-red-600 text-xs">
              <span className="font-medium">
                ⚠ {rows.filter((r) => r.hasError).length} row(s) have validation
                errors.
              </span>
              <span className="ml-2">
                Please fix all mandatory fields (highlighted in red).
              </span>
            </div>
          )}

          {/* Table */}
          {rows.length > 0 ? (
            <div className="overflow-auto border border-Dustyblue mb-2 bg-white shadow-md">
              <div
                ref={tableContainerRef}
                className="overflow-y-auto max-h-[400px]"
              >
                <table className="w-full text-sm bg-white border-collapse">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-20">
                    <tr>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[4%]">
                        #
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[8%]">
                        Year <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[16%]">
                        Category <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[10%]">
                        Equip. Make <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[22%]">
                        Details <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[10%]">
                        Measurement <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[10%]">
                        DI Required <span className="text-red-300">*</span>
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-center w-[11%]">
                        Status
                      </th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium text-center w-[9%]">
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((row, i) => (
                      <tr
                        key={i}
                        className={`text-xs hover:bg-lightBlue/50 ${
                          row.hasError
                            ? "bg-red-50"
                            : row.isDuplicate
                            ? "bg-yellow-50"
                            : ""
                        }`}
                      >
                        {/* Row Number */}
                        <td className="px-2 py-1.5 border border-grey2 border-l-0 text-center text-gray-500">
                          {i + 1}
                        </td>

                        {/* Year - Custom Dropdown */}
                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "year")}
                        </td>

                        {/* Category - Custom Dropdown */}
                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "category")}
                        </td>

                        {/* Equipment Make - Custom Dropdown */}
                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "equipment_make")}
                        </td>

                        {/* Details - Text Input */}
                        <td className="px-2 py-1.5 border border-grey2">
                          <input
                            type="text"
                            className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                              !row.details || !row.details.trim()
                                ? "border-red-500 bg-red-50"
                                : row.isDuplicate
                                ? "border-yellow-500 bg-yellow-50"
                                : "border-gray-300"
                            }`}
                            value={row.details || ""}
                            placeholder="Enter Details"
                            onChange={(e) =>
                              handleCellChange(i, "details", e.target.value)
                            }
                          />
                        </td>

                        {/* Measurement Units - Custom Dropdown */}
                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "measurement_units")}
                        </td>

                        {/* DI Required - Custom Dropdown */}
                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "di_required")}
                        </td>

                        {/* Status */}
                        <td className="px-2 py-1.5 border border-grey2 text-center">
                          {row.hasError ? (
                            <span
                              className="px-2 py-0.5 bg-red-100 text-red-600 text-[10px] rounded-full cursor-help"
                              title={row.errors?.join(", ")}
                            >
                              Invalid
                            </span>
                          ) : row.isDuplicate ? (
                            <span
                              className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full cursor-help"
                              title={row.duplicateReason}
                            >
                              Duplicate
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-green-100 text-green-600 text-[10px] rounded-full">
                              Valid
                            </span>
                          )}
                        </td>

                        {/* Delete Action */}
                        <td className="px-2 py-1.5 border border-grey2 border-r-0 text-center">
                          <button
                            onClick={() => handleDeleteRow(i)}
                            className="text-red-500 hover:text-red-700 transition"
                            title="Delete Row"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="20"
                              height="20"
                              viewBox="0 0 32 32"
                              fill="none"
                            >
                              <g clipPath="url(#clip0_6398_313)">
                                <path
                                  d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z"
                                  fill="#BF2012"
                                />
                              </g>
                              <defs>
                                <clipPath id="clip0_6398_313">
                                  <rect
                                    width="24"
                                    height="24"
                                    fill="white"
                                    transform="translate(4 4)"
                                  />
                                </clipPath>
                              </defs>
                            </svg>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Footer */}
              <div className="px-4 py-2 bg-gray-50 border-t border-grey2 flex flex-wrap justify-between items-center gap-2">
                <span className="text-xs text-gray-600">
                  Total: {rows.length} row(s) |
                  <span className="text-green-600 ml-1">
                    Valid:{" "}
                    {rows.filter((r) => !r.hasError && !r.isDuplicate).length}
                  </span>{" "}
                  |
                  <span className="text-yellow-600 ml-1">
                    Duplicates: {rows.filter((r) => r.isDuplicate).length}
                  </span>{" "}
                  |
                  <span className="text-red-600 ml-1">
                    Errors: {rows.filter((r) => r.hasError).length}
                  </span>
                </span>
                <span className="text-xs text-gray-500 italic">
                  💡 Click "Check Duplicates" before saving to identify existing
                  records
                </span>
              </div>
            </div>
          ) : (
            /* Empty State - WITH DRAG AND DROP */
            <div
              className={`bg-white shadow-md border-2 border-dashed p-8 text-center transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-Dustyblue hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="w-12 h-12 mx-auto mb-3 opacity-50"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>

              <p className="text-gray-500 text-sm">
                {isDragActive
                  ? "Drop your Excel file here!"
                  : "No data loaded. Please upload an Excel file to preview."}
              </p>
              <p className="text-gray-400 text-xs mt-1">
                {isDragActive
                  ? "Release to upload"
                  : "Supported formats: .xlsx, .xls (Drag & drop or click Browse)"}
              </p>
              <p className="text-gray-400 text-xs mt-1">
                Required columns: Year, Category, Equipment Make, Details, Measurement, DI Required
              </p>
            </div>
          )}
        </div>
      </div>

      {/* ========== UNIVERSAL CUSTOM DROPDOWN ========== */}
      {activeDropdown !== null && rows[getActiveRowIndex()] && (
        <div
          ref={dropdownMenuRef}
          className="fixed border border-gray-300 bg-white z-[9999] shadow-xl rounded overflow-hidden"
          style={{
            top: `${dropdownPosition.top}px`,
            left: `${dropdownPosition.left}px`,
            width: `${dropdownPosition.width}px`,
            minWidth: "150px",
          }}
        >
          {/* Search Input */}
          <div className="p-2 border-b border-gray-200 bg-gray-50">
            <input
              type="text"
              placeholder={getSearchPlaceholder(getActiveColumn())}
              value={dropdownSearch}
              onChange={(e) => setDropdownSearch(e.target.value)}
              className="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:outline-none focus:border-darkblue1"
              autoFocus
            />
          </div>

          {/* Options List */}
          <div className="max-h-[150px] overflow-y-auto">
            {getDropdownOptions(getActiveColumn()).length > 0 ? (
              getDropdownOptions(getActiveColumn()).map((option) => {
                const currentValue = rows[getActiveRowIndex()][getActiveColumn()];
                const isSelected = currentValue === option.id;

                return (
                  <div
                    key={option.id}
                    className={`flex items-center gap-2 px-3 py-1.5 cursor-pointer text-xs border-b border-gray-100 last:border-b-0 ${
                      isSelected ? "bg-blue-50" : "hover:bg-gray-50"
                    }`}
                    onClick={() =>
                      handleSelectOption(getActiveRowIndex(), getActiveColumn(), option.id)
                    }
                  >
                    <span
                      className={isSelected ? "text-blue-700 font-medium" : ""}
                    >
                      {option.label}
                    </span>
                    {isSelected && (
                      <span className="ml-auto text-blue-500">✓</span>
                    )}
                  </div>
                );
              })
            ) : (
              <div className="px-3 py-3 text-xs text-gray-400 text-center">
                No options found
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default BulkUploadUptimePartsCategory;