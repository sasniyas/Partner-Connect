import { useState, useEffect, useRef } from "react"
import Header from "../../../../../Components/Header"
import { useNavigate } from "react-router-dom"
import SubNavbar3 from "../../../../../Components/SubNavbar3"
import { ArrowLeft, Plus, ArrowRight } from "lucide-react"
import Searchinput from "../../../../../Components/Searchinput"
import Filter from "../../../../../Components/Filter"
import DeleteModal from "../../../../../Components/DeleteModal"
import * as XLSX from "xlsx";

// Mock components - replace with your actual components

function KeyAccount() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const dropdownRef = useRef(null)
  const [tableData, setTableData] = useState([])
  const [formData, setFormData] = useState({customertype: "", customername: "",unit:""})
  const [isEditing, setIsEditing] = useState(false)
  const [editIndex, setEditIndex] = useState(null)
  const [errors, setErrors] = useState({})
  const [searchQuery, setSearchQuery] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const rowsPerPage = 7
//   const [competenceOptions,setCompetencename]=useState("")
const [deleteIndex, setDeleteIndex] = useState(null); // to track which row to delete
const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
const [showcustomernamesuggestion, setShowCustomernamesuggestion] = useState(false);
const [customertype, setCustomertype] = useState("");
const [customername, setCustomername] = useState("");
const [unit, setUnits] = useState("");
const fileInputRef = useRef(null)
const handleBulkUploadClick = () => {
    fileInputRef.current.click()
  }


const [showcustomerTypeSuggestions,setShowCustomerTypeSuggestions] =useState(false);
const [unitSuggestions,setUnitSuggestions] =useState(false);
const [customertypeOptions,setCustomerTypeOptions]= useState([

]);

  const filteredData = tableData.filter((item) => {
  const matchesSearch = Object.values(item).some((val) =>
    val?.toString().toLowerCase().includes(searchQuery.toLowerCase())
  );
  const matchescustomertype = customertype ? item.customertype === customertype : true;
const matchescustomername = customername ? item.customername === customername: true;
const matchesunits = unit ? item.units === unit: true;

  return matchesSearch && matchescustomertype &&matchescustomername &&matchesunits ;
});




  const totalPages = Math.ceil(filteredData.length / rowsPerPage)
  const paginatedData = filteredData.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage)

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 100)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

 
useEffect(() => {
  const customertypeFromData = tableData
    .map(item => item.customertype?.trim())
    .filter(val => val && val.length > 0);

  const basecustomerType = [  
  ];

  setCustomerTypeOptions(Array.from(new Set([...basecustomerType , ...customertypeFromData ])));
}, [tableData]);

const handleDownloadTemplate = () => {
  const headers = [["Sl.NO","Key Account Customers Type", "Key account Customers Name", "Units"]];

  const worksheet = XLSX.utils.aoa_to_sheet(headers);

  worksheet["!cols"] = [
    { wch: 20 },
    { wch: 30 },
    { wch: 20 },
    { wch: 20 },
    { wch: 25 },
  ];

  const data = [
    {
      "Sl.NO":"1",
     
      "Key Account Customers Type": "GPE (General Production Equipment)",
      "Key Account Customers Name": "Excavators",
      "Units": "NOS",
    }
  ];

  XLSX.utils.sheet_add_json(worksheet, data, {
    origin: "A2", // Avoid overwriting the header
    skipHeader: true
  });

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Users");

  XLSX.writeFile(workbook, "key_Account_Bulk_Upload_Template.xlsx");
};
const handlePreviewAndDownload = () => {
  const tableHeaders = ["SL.No","Key Account Customers Type", "Key Account Customers Name", "Units"];

  const tableRows = filteredData.map((item, index) => `
    <tr class="${index % 2 === 0 ? 'bg-white' : 'bg-gray-100'} hover:bg-blue-50">
      <td class="px-4 py-3 text-sm">${index + 1}</td>
      <td class="px-4 py-3 text-sm">${item.customertype}</td>
      <td class="px-4 py-3 text-sm">${item.customername}</td>
      <td class="px-4 py-3 text-sm">${item.unit}</td>
    </tr>
  `).join("");

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <script src="https://cdn.tailwindcss.com"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
      <title>Key Account Preview</title>
      <style>
        body { font-family: 'VolvoNovum', sans-serif; margin: 0; background-color: #F8FAFC; }
        .header {
          display: flex;
          align-items: center;
          padding: 10px 32px;
          background: white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          position: sticky;
          top: 0;
          z-index: 10;
        }
        .header img.volvo-logo { height: 70px; width: auto; }
        .table-container table {
          width: 100%;
          border-collapse: separate;
          border-spacing: 0;
          border: 2px solid #5B7C99;
          border-radius: 0.375rem;
          overflow: hidden;
        }
        .table-container th {
          background-color: #5B7C99;
          color: white;
          padding: 12px 8px;
          text-align: left;
          font-size: 0.95rem;
        }
        .table-container td {
          padding: 12px 8px;
          font-size: 0.875rem;
        }
        .download-btn {
          background-color: #1D2B50;
          color: white;
          padding: 10px 24px;
          border-radius: 0.375rem;
          font-weight: 500;
          cursor: pointer;
          border: 2px solid #1D2B50;
          margin-top: 20px;
        }
        .download-btn:hover {
          background-color: white;
          color: #1D2B50;
          border-color: #1D2B50;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Volvo Logo" class="volvo-logo"/>
      </div>

      <div class="p-8 table-container">
        <h1 class="text-2xl font-bold mb-4">Key Account </h1>
        <div class="overflow-x-auto">
          <table id="exportTable">
            <thead>
              <tr>${tableHeaders.map(header => `<th>${header}</th>`).join("")}</tr>
            </thead>
            <tbody>${tableRows}</tbody>
          </table>
        </div>
        <button class="download-btn" onclick="downloadAsExcel()">Download</button>
      </div>

      <script>
       function downloadAsExcel() {
  const wb = XLSX.utils.book_new();
  const headers = ["Sl.NO","Key account Customers Type", "Key account Customers Name", "Units"];
  const data = [headers];

  document.querySelectorAll("#exportTable tbody tr").forEach(row => {
    const rowData = Array.from(row.querySelectorAll("td")).map((td, index) => {
      let value = td.innerText;
      // Force first column (Sl.NO) and last column (Units) as string for left alignment
      if(index === 0 || index === 3) value = value.toString();
      return value;
    });
    data.push(rowData);
  });

  const ws = XLSX.utils.aoa_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, ws, "Key Account");
  XLSX.writeFile(wb, "Key_Account.xlsx");
}

      </script>
    </body>
    </html>
  `;

  const newWindow = window.open("", "_blank");
  newWindow.document.write(htmlContent);
  newWindow.document.close();
};





  return (
<div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />
      <div className={`transition-all duration-300 mt-20 lg:mt-[170px] ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full flex justify-center">
          <div className="w-full max-w-[1280px] transition-all duration-300 ease-in-out px-4 lg:px-2 xl:px-0">
            {/* 🔹 Heading */}
            <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
              <h2 className="text-base font-medium font-VolvoNovum text-center text-darkblue1 flex items-center justify-center gap-2">
                <ArrowLeft
                  onClick={() => navigate("/masterpdphomepage")}
                  size={28}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 rounded-md p-1"
                />
       PDP Data / Key Account
  </h2>
             
            </div>
          {/* 🔹 Controls: Search + Filters + Actions */}
<div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8 w-full">

  {/* 🔸 Left Side: Search + Filters */}
  <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-2 w-full ">
    
    {/* 🔍 Search Input */}
    {/* <div className="w-full sm:w-64 md:w-36 lg:w-80"> */}
      <Searchinput
        onChange={(e) => {
          setSearchQuery(e.target.value);
          setCurrentPage(1);
        }}
        value={searchQuery}
        placeholder="Search"
        className="w-96"
        iconColor="text-black"
        bgColor="bg-FrostWhite"
              borderColor="border-black"
        textColor="text-black"
        shadow="shadow-none"
        inputPadding="pl-8 pr-3 py-2"
        iconSize="w-4 h-4"
        iconLeft="left-3"
        inputWidth="w-full"
        focusRing="focus:ring-1 focus:ring-black/60"
        hoverInputClasses="hover:bg-white hover:border-black/60"
      />
    {/* </div> */}

    {/* 📆 Year Filter */}
   
    {/* 🏷️ Category Filter */}
     
 
 {/* <div className="ml-0 md:ml-5 lg:ml-0 xl:ml-0"> */}

<Filter
  name="Account Type"
  options={customertypeOptions}           // array of options
  value={customertype ? [customertype] : []} // pass as array
  onChange={(name, selectedValues) => {
    setCustomertype(selectedValues[0] || ""); // take first selected value
    setCurrentPage(1);
  }}
  // className="w-full"
  customWidth="w-52"
  placeholder="Account Type"
  placeholderColor="text-black"
  buttonBorderColor="border-black"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black"
  textColor="text-black"
/>


 {/* </div> */}
  </div>

  {/* 🔸 Right Side: Action Buttons */}
  <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
    
    {/* ➕ Add Dropdown */}
    <div className="relative w-full sm:w-[190px]" ref={dropdownRef}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full bg-darkblue1 font-medium pl-4 pr-3 py-2 text-sm rounded-lg flex items-center justify-center gap-1 text-white hover:bg-white hover:text-darkblue1 border border-darkblue1 transition"
      >
        <Plus className="w-4 h-4 stroke-[3]" />
        Add New
      </button>

      {open && (
        <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1 rounded-lg shadow-lg z-50">
          <button
            className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-2"
            onClick={() => {
              setIsAddUserOpen(true);
              setOpen(false);
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="8" r="5" fill="#374151"/>
                    <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="#374151" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                    <circle cx="12" cy="8" r="2" fill="white"/>
                </svg>

            Add Key Account
          </button>
          <button
  onClick={() => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = ".xlsx, .xls" // Accept only Excel files
    input.onchange = (e) => {
      const file = e.target.files[0]
      if (file && (file.name.endsWith(".xlsx") || file.name.endsWith(".xls"))) {
        handleBulkUploadClick(file) // your upload logic
      }
      // If not valid, do nothing (no alert)
    }
    input.click()
    setOpen(false)
  }}
  className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-1 hover:rounded-b-lg whitespace-nowrap"
>
  <img
    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/bulkupload.png"
    alt="bulk upload"
    className="w-5 h-5"
  />
  Bulk Upload
</button>


  <button
                      // onClick={() => {
                      //   handleBulkUploadClick()
                      //   setOpen(false)
                      // }}
                              onClick={handleDownloadTemplate}

                      className="w-full text-left px-4 py-2 hover:bg-lightBlue/50 text-sm text-black flex items-center gap-1 hover:rounded-b-lg whitespace-nowrap"
                    >
 <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/download.png" alt="Download" className="w-4 h-4" />                     
 Bulk upload Template
                    </button>



        </div>
      )}
    </div>

    {/* ⬇️ Download Button */}
   <button
      onClick={handlePreviewAndDownload}
      className="group relative text-sm bg-white text-darkblue1 px-4 py-2 border border-darkblue1 rounded-md flex items-center gap-1 hover:bg-darkblue1 hover:text-white transition w-full sm:w-auto"
    >
      <img
        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpmasterHomepage/download.png"
        alt="download"
        className="w-3 h-3 group-hover:hidden"
      />
      <img
        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpmasterHomepage/download1.png"
        alt="download-white"
        className="w-3 h-3 hidden group-hover:block"
      />
      <span className="font-semibold">Download</span>
    </button>



  </div>
</div>

            {/* 🔹 Table Section */}
          <div className="bg-white shadow-md rounded-lg border border-Dustyblue overflow-hidden">
  <table className="w-full table-auto text-sm cursor-pointer">
    <thead className="bg-Dustyblue text-white text-left">
      <tr>
        <th className="px-4 py-4 text-base font-medium w-1/2">Key Account Customers Type</th>
        <th className="px-4 py-4 text-base font-medium w-2/5">Key Account Customers Name</th>
                <th className="px-4 py-4 text-base font-medium w-2/5">Units</th>
        <th className="px-4 py-4 text-base font-medium w-1/8">Actions</th>
      </tr>
    </thead>

    <tbody className="text-black">
      {paginatedData.length > 0 ? (
    paginatedData.map((item, index) => (
 <tr
        key={index}
        className={`odd:bg-white even:bg-gery1 hover:bg-lightBlue/50 
          ${item.isActive ? "text-gray-400" : " text-black"}`}
      >            {/* Competence Type */}
          <td className="px-4 py-6 align-top">
                {item.customertype || "-"}     
          </td>
 <td className="px-4 py-6 align-top">
                {item.customername || "-"}     
          </td>
          {/* Competence Name */}
          <td className="px-4 py-6 align-top">
            
                {item.unit || "-"}
              
          </td>

          {/* Actions */}
          <td className="px-4 py-4">
            <div className="flex items-center gap-2">
              {/* Edit */}
              <div className="relative group inline-block">
                <button
                  onClick={() => {
                    setFormData({
                      customertype: item.customertype || "",
                     customername: item.customername|| "",
                     unit: item.unit|| "",

                    });
                    setIsAddUserOpen(true);
                    setIsEditing(true);
                    setEditIndex(index);
                  }}
                >
                  <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png" alt="edit" className="w-4 h-4" />
                </button>
                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-0 transition-opacity duration-200 z-50">
                  Edit
                </span>
              </div>

                   {/* Toggle Active/Deactivate Button */}
    <div className="relative group">
      <button
        onClick={() => {
          const updated = [...paginatedData];
          updated[index].isActive = !updated[index].isActive;
setTableData(updated);        }}
      >
        <img
                  src={item.isActive ?"https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/deactive.png" : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/active.png" }

          // src={item.isActive ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/active.png" : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/deactive.png"}
          alt="Toggle Status"
          className="w-4 h-4"
        />
      </button>
      <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
        {item.isActive ? "Activate" : " Deactivate"}
      </span>
    </div>

              {/* Delete */}
              <div className="relative group inline-block">
                <button
                  onClick={() => {
                    setDeleteIndex(index);
                    setIsDeleteModalOpen(true);
                  }}
                >
                  <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/PdpmasterHomepage/delete.png" alt="delete" className="w-4 h-4" />
                </button>
                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded px-2 py-0 transition-opacity duration-200 z-50">
                  Delete
                </span>
              </div>
            </div>
          </td>
        </tr>
      ))
      ) : (
         <tr>
      <td colSpan={4} className="px-4 py-6 text-center italic text-gray-500">
        No data found
      </td>
    </tr>)}
    </tbody>
  </table>
</div>

                  {totalPages > 1 && (
        <div className="flex justify-end mt-4 gap-2">
          <button
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="w-9 h-9 flex items-center justify-center rounded-lg bg-darkblue1 text-white text-lg font-bold hover:scale-110 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ArrowLeft size={20} />
          </button>
          <button
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="w-9 h-9 flex items-center justify-center rounded-lg bg-darkblue1 text-white text-lg font-bold hover:scale-110 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ArrowRight size={20} />
          </button>
        </div>
      )}

          </div>
        </div>
      </div>


      {/* 🔹 Scroll to Top Button */}
      {showScrollTop && (
   <div className="mt-12 mb-2 flex justify-end pr-4 ">
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
    className="bg-Silvergrey text-black font-bold px-4 py-2 rounded-lg shadow-lg hover:scale-110 transition duration-200"
    >
      ^
    </button>
  </div>
)}

      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-center">
          <div className="bg-white rounded-lg p-6 w-full max-w-xl relative">
            <h2 className="text-base font-semibold text-center mb-4 text-MediumGrey">
              {isEditing ? "Key Account " : "Add Key Account"}
            </h2>
            <button
              onClick={() => {
                setIsAddUserOpen(false)
                setIsEditing(false)
                setFormData({customertype: "", customername: "",units:"" })
                setErrors({})
              }}
              className="absolute top-3 right-4 text-red-600 font-bold text-xl"
            >
              <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" alt="close" className="w-5 h-5" />
            </button>
            {/* 🔹 Grid Inputs */}
            <div className="grid grid-cols-1  gap-2">
             

<div className="w-full relative">
               <label className="text-sm font-medium text-black/70">Key Accounts Customers Type</label>

{isEditing && tableData.length > 1 ? ( 
   <>
      <div className="relative w-full">
        <input
          type="text"
          value={formData.customertype}
          onChange={(e) => {
            setFormData({ ...formData, customertype: e.target.value });
          setShowCustomerTypeSuggestions(true);
          }}
          onFocus={() => setShowCustomerTypeSuggestions(true)}
          onBlur={() => setTimeout(() => setShowCustomerTypeSuggestions(false), 100)}
          placeholder="Select or type Equipment Type"
          className={`border w-full mt-1 text-sm px-3 py-2 outline-none focus:ring-1 transition-all
            ${showcustomerTypeSuggestions? "rounded-t-md border-b-white" : "rounded-md"}
            ${errors.customertype ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
          `}
        />
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/dropdown.png"
          alt="Dropdown"
          onClick={() =>  setShowCustomerTypeSuggestions((prev) => !prev)}
          className={`w-4 h-4 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
           showcustomerTypeSuggestions  ? "rotate-180" : "rotate-0"
          }`}
        />
      </div>

      {showcustomerTypeSuggestions&& (
        <div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 rounded-b-md shadow-md max-h-40 overflow-y-auto">
         {[...new Set([...customertypeOptions, ...tableData.map((item) => item.customertype)])]
  .filter(Boolean)
  .filter(option => option !== formData.customertype) 
  .sort((a, b) => a.localeCompare(b))
            .map((option, idx) => (
              <div
                key={idx}
                onMouseDown={() => {
                  setFormData({ ...formData, customertype: option });
                setShowCustomerTypeSuggestions(false);
                }}
                className={`px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 ${
                  option === formData.customertype? "bg-gray-100" : ""
                }`}
              >
                {option}
              </div>
            ))}
        </div>
      )}
    </>
  ) : (
    <input
      type="text"
      value={formData.customertype}
      onChange={(e) => setFormData({ ...formData, customertype: e.target.value })}
      placeholder="Enter Key Accounts Customer Type"
      className={`border rounded-md px-3 py-2 w-full mt-1 text-sm outline-none focus:ring-1 ${
        errors.customertype ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
      }`}
    />
  )}

  {errors.customertype && <p className="text-red1 text-xs mt-1">{errors.customertype}</p>}            </div>

  
<label className="text-sm font-medium text-black/70">Key Accounts Customers Name</label>

<input
  type="text"
  value={formData.customername}
  onChange={(e) => {
    const value = e.target.value;
    setFormData({ ...formData, customername: value });
  }}
  placeholder="Enter Key Accounts Customer Name"
  className={`border rounded-md px-3 py-2 w-full mt-1 text-sm outline-none focus:ring-1 ${
    errors.customername ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
  }`}
/>

{errors.customername && (
  <p className="text-red1 text-xs mt-1">{errors.customername}</p>
)}

  <label className="text-sm font-medium text-black/70">Units</label>

  {/* More than 1 row → dropdown with suggestions */}
  {isEditing && tableData.length > 1 ? (
    <>
     <div className="relative w-full">
  <input
    type="text"
    value={formData.unit}
    onChange={(e) => {
      setFormData({ ...formData, unit: e.target.value });
 setUnitSuggestions(true);
    }}
    onFocus={() =>  setUnitSuggestions(true)}
    onBlur={() => setTimeout(() =>  setUnitSuggestions(false), 100)}
    placeholder="Select or type Category"
    className={`border w-full mt-1 text-sm px-3 py-2 outline-none focus:ring-1 transition-all
      ${unitSuggestions? "rounded-t-md border-b-white" : "rounded-md"}
      ${errors.unitSuggestions? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}
    `}
  />

  {/* Dropdown Icon */}
  <img
    src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/dropdown.png"
    alt="Dropdown"
    onClick={() =>setUnitSuggestions((prev) => !prev)}
    className={`w-4 h-4 absolute right-3 top-[15px] cursor-pointer transform transition-transform duration-200 ${
     unitSuggestions? "rotate-180" : "rotate-0"
    }`}
  />

  {/* Suggestions */}
  {unitSuggestions && (
    <div className="absolute z-10 w-full bg-white border border-t-0 border-black/30 rounded-b-md shadow-md max-h-40 overflow-y-auto">
      {Array.from(new Set(tableData.map((item) => item.unit)))
       .filter((u) => u !== formData.unit) 
      .map((unit, idx) => (
        <div
          key={idx}
          onMouseDown={() => {
            setFormData({ ...formData, unit});
          setUnitSuggestions(false);
          }}
          className={`w-full px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 ${
           unit === formData.unitSuggestions? "bg-gray-100" : ""
          }`}
        >
          {unit}
        </div>
      ))}
    </div>
  )}
</div>

    </>
  ) : (
    // Only 1 row OR not editing → plain input
    <input
  type="text"
  value={formData.unit}
  onChange={(e) => {
    const value = e.target.value;
    setFormData({ ...formData, unit: value });
  }}
  placeholder="Enter Unit"
  className={`border rounded-md px-3 py-2 w-full mt-1 text-sm outline-none focus:ring-1 ${
    errors.unit? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
  }`}
/>

  )}

  {errors.unit&& (
    <p className="text-red1 text-xs mt-1">{errors.unit}</p>
  )}

</div>
           
            {/* Save Button */}
            <button
              onClick={() => {
                const newErrors = {}
                if (!formData.customertype) newErrors.customertype= "Please enter this field"
                if (!formData.customername) newErrors.customername= "Please enter this field"
                if (!formData.unit) newErrors.unit= "Please enter this field"

//                 if (!formData.category) newErrors.category = "Please enter this field"
// if (!formData.details) newErrors.details = "Please enter this field"
// if (!formData.measurement) newErrors.measurement = "Please enter this field"
                if (Object.keys(newErrors).length > 0) {
                  setErrors(newErrors)
                  return
                }
                const updatedData = [...tableData]

                if (isEditing) {
                  // Preserve existing templates when editing
                  const existingTemplates = updatedData[editIndex].templates || []
                  updatedData[editIndex] = {
                    ...formData,
                    templates: existingTemplates,
                  }
                } else {
                  // New item gets empty templates array
                  updatedData.push({ ...formData, templates: [] })
                }

                // ✅ Sort ascending by year
                // updatedData.sort((a, b) => Number(a.year) - Number(b.year))
                setTableData(updatedData)
             setCustomerTypeOptions   (prev => {
  const newOptions = [...prev];
  if (!newOptions.includes(formData.customertype)) {
    newOptions.push(formData.customertype);
    newOptions.sort();
  }
  return newOptions;
});
                // ✅ Reset everything
setFormData({ customertype: "", customername: "" ,unit:""});
                setErrors({})
                setIsEditing(false)
                setEditIndex(null)
                setIsAddUserOpen(false)
              }}
              className="mt-6 bg-darkblue1 text-sm font-medium text-white px-10 py-1.5 rounded-md hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition block mx-auto"
            >
              Save
            </button>
         </div>
       </div>
      )}

   
<DeleteModal
  isOpen={isDeleteModalOpen}
  onClose={() => setIsDeleteModalOpen(false)}
  onConfirm={() => {
    if (deleteIndex !== null) {
      const updated = tableData.filter((_, i) => i !== deleteIndex);
      setTableData(updated);
      setDeleteIndex(null); // reset
    }
    setIsDeleteModalOpen(false);
  }}
/>

    </div>
  )
}

export default  KeyAccount;
