import React from "react";
// import Pdpmastersdropdown from "./Pdpmastersdropdowns";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  // Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  Legend,
} from "recharts";
// Dummy Data
const departmentData = [
  { name: "Finance", value: 90 },
  { name: "HR", value: 75 },
  { name: "Marketing", value: 65 },
  { name: "Operations", value: 60 },
  { name: "IT", value: 45 },
  { name: "Sales", value: 55 },
];

const creationTrendData = [
  { month: "Jan", count: 5 },
  { month: "Feb", count: 15 },
  { month: "Mar", count: 25 },
  { month: "Apr", count: 30 },
  { month: "May", count: 35 },
  { month: "Jun", count: 38 },
];

const resourceData = [
  { name: "Presentation", value: 25 },
  { name: "Finance", value: 30 },
  { name: "Equipment", value: 20 },
  { name: "Competence", value: 15 },
  { name: "Other", value: 10 },
];

const COLORS = ["#4781C4", "#E77352", "#8252C7", "#50A294", "#1FA2C2"];

const topPerformanceData = [
  ["Financial Report Q2", "Finance", 248],
  ["Sales Presentation", "Presentation", 215],
  ["Project Timeline", "Operations", 196],
  ["Equipment Tracking", "Equipment", 189],
  ["Marketing Campaign", "Marketing", 173],
];


const Pdp = () => {
   
  
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
{/*      
  <div>
    <h1 className="text-xl text-blue text-volvoNovum font-semibold">PDP Master Data</h1>
  </div> */}

 {/* Centered dropdowns in a tight row */}
 
{/* <Pdpmastersdropdown/> */}
      

    {/* Stats Cards */}
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4  place-items-center">
  {[
    {
      title: "Total Templates",
      value: "126",
      note: "+12% from last month",
    },
    {
      title: "Active Projects",
      value: "38",
      note: "+5% from last month",
    },
    {
      title: "Resource Utilization",
      value: "84%",
      note: "-2% from last month",
    },
    {
      title: "Data Completeness",
      value: "92%",
      note: "+3% from last month",
    },
  ].map((item, idx) => {
    const isPositive = item.note.trim().startsWith("+");
    const noteColor = isPositive ? "text-lightgreen" : "text-red1";
    const barColor = isPositive ? "bg-mildBlue" :  "bg-red";
    const percent = parseInt(item.value);
   

    return (
      <div
        key={idx}
        // className="bg-white rounded-xl shadow p-4 border w-full h-35 md:h-40 flex flex-col justify-between"
         
        className={`bg-white border-l-8 border-l-mildBlue  rounded-xl shadow p-4 border w-[98%] h-35 md:h-40 flex flex-col justify-between 
          transform transition duration-300 ease-in-out hover:-translate-y-2 hover:shadow-lg`}
        
      >
        <div>
          <p className="text-sm font-medium text-VolvoNovum text-black mb-2">
            {item.title}
          </p>
          <h2 className="text-xl font-bold text-mildBlue">{item.value}</h2>
          <p className={`text-sm  ${noteColor}`}>{item.note}</p>
        </div>

        {/* Progress bar for last two cards */}
        {idx >= 2 && (
          <div className="w-full h-2 bg-gray-200 rounded-full mb-4">
            <div
              className={`h-full rounded-full ${barColor}`}
              style={{ width: `${percent}%` }}
            ></div>
          </div>
        )}
      </div>
    );
  })}
</div>


<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
<div className="bg-white rounded-xl border p-6 min-h-[420px]">
  <h3 className="text-lg font-semibold text-mildBlue mb-4 text-left w-full pl-16">
    Usage By Department
  </h3>

  <ResponsiveContainer width="100%" height={320}>
    <BarChart data={departmentData}>
      <XAxis
        dataKey="name"
        tickLine={false}
        axisLine={{ stroke: "rgba(0, 0, 0, 0.7)", strokeWidth: 1.5 }}

        tick={{ fill: "black/50", fontSize: 14 }}
      />
      <YAxis
        tickLine={false}
        // axisLine={true}
        axisLine={{ stroke: "rgba(0, 0, 0, 0.7)", strokeWidth: 1.5 }}

        tick={{ fill: "black/50", fontSize: 14 }}
      />
     
      <Bar dataKey="value" fill= "#4781C4" radius={[10, 10, 0, 0]}  barSize={40} />
    </BarChart>
  </ResponsiveContainer>
</div>


<div className="bg-white rounded-xl shadow p-6 border h-[390px]">
  <h3 className="text-lg font-semibold text-mildBlue mb-4 text-left w-full pl-16">
    Creation Trend
  </h3>
  <div className="w-full h-[280px] px-4">
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={creationTrendData}>
        {/* Horizontal grid lines */}
        {/* <CartesianGrid strokeDasharray="3 3" vertical={false} stroke= "rgba(0, 0, 0, 0.5)" /> */}
        <CartesianGrid
  strokeDasharray="3 3"
  vertical={false} // disables vertical grid lines (X axis)
  
  stroke="rgba(0, 0, 0, 0.3)" // soft horizontal lines
/>
        <XAxis 
          dataKey="month" 
          tickLine={false} 
          // axisLine={{ stroke: "#ccc", strokeWidth: 1.5 }}
          axisLine={{ stroke: "rgba(0, 0, 0, 0.7)", strokeWidth: 1.5 }}

          tick={{ fill: "black/50", fontSize: 14 }} 
        />
        <YAxis 
          tickLine={false} 
          axisLine={{ stroke: "rgba(0, 0, 0, 0.7)", strokeWidth: 1.5 }}
            tick={{ fill: "black/50", fontSize: 14 }}
            ticks={[ 10, 20, 30,40]}
        />
        <Line
          type="monotone"
          dataKey="count"
          stroke="#50A294"
          strokeWidth={2}
          dot={{ r: 4 ,fill:"#50A294"}}
        />
      </LineChart>
    </ResponsiveContainer>
  </div>
</div>
</div>

      {/* Pie Chart and Table */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Pie Chart */}
        <div className="bg-white rounded-xl shadow p-4 border">
  <h3 className="text-lg font-semibold text-mildBlue mb-4 text-left w-full pl-16">
    Resource Allocation
  </h3>
  <ResponsiveContainer width="100%" height={250}>
  <PieChart>
  <Pie
    data={resourceData}
    cx="35%"
    cy="50%"
    innerRadius={70}
    outerRadius={100}
    paddingAngle={1}
    dataKey="value"
  >
    {resourceData.map((_, index) => (
      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
    ))}
  </Pie>
  <Legend
  layout="vertical"
  verticalAlign="middle"
  align="right"
  content={({ payload }) => (
    <ul className="flex flex-col justify-center ml-[-250px] mt-[5px]">
      {payload.map((entry, index) => (
        <li key={`item-${index}`} className="flex items-center space-x-2 mb-2">
          <div
            className="w-5 h-5 rounded-md"
            style={{ backgroundColor: entry.color }}
          ></div>
          <span className="text-base" style={{ color: entry.color }}>
            {entry.value}
          </span>
        </li>
      ))}
    </ul>
  )}
/>

</PieChart>
  </ResponsiveContainer>
</div>


<div className="bg-white rounded-xl shadow-lg p-4 border mt-[-30px]">
  <h3 className="text-lg font-semibold mb-4 text-mildBlue">Top Performance</h3>

  <div className="overflow-hidden flex justify-center">
  <div className="w-full max-w-3xl"> {/* Reduced width */}
    <table className="w-full table-auto text-sm text-left border-separate border-spacing-y-1">
      <thead className="bg-ab/30">
        <tr>
          <th className="px-6 py-2 text-mildBlue rounded-tl-md rounded-bl-md">Name</th>
          <th className="px-6 py-2 text-mildBlue">Type</th>
          <th className="px-6 py-2 text-mildBlue">Usage</th>
          <th className="px-6 py-2 text-mildBlue rounded-tr-md">Performance</th>
        </tr>
      </thead>
      <tbody>
        {topPerformanceData.map(([name, type, usage], i) => (
          <tr key={name + i} className="border border-gray-200 rounded-md">
             <td
  className={`px-6 py-3 rounded-l-md ${
    i % 2 === 0
      ? 'bg-white border-t border-b border-l border-ab'
      : 'bg-lightGrey '
  }`}
>
              {name}</td>
              <td
  className={`px-6 py-3 rounded-l-md ${
   i % 2 === 0
      ? 'bg-white border-t border-b rounded-t-none rounded-l-none border-ab'
      : 'bg-lightGrey rounded-l-none rounded-r-none'
  }`}
>
          {type}</td>
          <td
  className={`px-6 py-3 rounded-l-md ${
i % 2 === 0
      ?'bg-white border-t border-b rounded-t-none rounded-l-none border-ab'
      :  'bg-lightGrey rounded-l-none rounded-r-none'
  }`}
>
              {usage}</td>
              <td
  className={`px-6 py-3 rounded-r-md ${
   i % 2 === 0
      ? 'bg-white border-t border-b border-r border-ab rounded-tr-md rounded-br-md'
      :   'bg-lightGrey'
  }`}
>    
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`h-full rounded-full ${
                    i < 3 ? 'bg-green' : 'bg-mildBlue'
                  }`}
                  style={{ width: `${Math.min((usage / 300) * 100, 100)}%` }}
                ></div>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
</div>

</div>

      </div>
    </div>
  );
};

export default Pdp;
