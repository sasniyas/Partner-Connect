import React, { useState, useRef, useEffect, useCallback } from "react";
import Searchinput from "../../../Components/Searchinput";
import { ArrowLeft, ArrowRight, Download } from "lucide-react";
import DeleteModal from "../../../Components/DeleteModal";
import ActivateStatus from "../../../Components/ActivateStatus";
import DeactivateStatus from "../../../Components/DeactivateStatus";
import Filter from "../../../Components/Filter";
import { useMemo } from "react";
import { ChevronUp, ChevronDown } from "lucide-react";
import {
  addEquipmentMlp,
  getEquipmentsMlp,
  updateEquipmentMlp,
  toggleEquipmentMlp,
  deleteEquipmentMlp,
} from "../../../services/masterdealerinvestment/equipmentMlp.service";
import { validateName } from "../../../util/Validator";
 import ExcelJS from "exceljs";
import { uploadTempFile } from "../../../services/download/bluckDownload.service";
const EquipmentTab = () => {
  const scrollRef = useRef(null);
  const [selectedStatus, setSelectedStatus] = useState([]);
const statusOptions = [
    "Active", "Inactive"
];
  const [data, setData] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRow, setSelectedRow] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [error, setError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [loadingToggle, setLoadingToggle] = useState(false);
  const [errors, setErrors] = useState({ type: false, multiplier: false });
  const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);
  // Lazy loading states
  const [displayedItems, setDisplayedItems] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const observerRef = useRef();

  const itemsPerLoad = 10;
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
      return;
    }
    if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }
  setSortKey(key);
  setSortOrder("asc");
};

  const [formData, setFormData] = useState({
    id: null,
    type: "",
    multiplier: ""
  });

  useEffect(() => {
    fetchEquipmentData();
  }, []);

  const fetchEquipmentData = async () => {
    setIsLoading(true);
    setError(false);
    try {
      const response = await getEquipmentsMlp();
      if (response) {
        const transformedData = response.map(item => ({
          id: item.id,
          type: item.type,
          multiplier: item.multiplier.toString(),
          status: item.isActive === 1 ? "Active" : "Inactive"
        }));
        setData(transformedData);
      }
    } catch (error) {
      console.error("Error fetching equipment data:", error);
      setError(true);
      alert(error.message || "Failed to fetch equipment data. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const openAdd = () => {
    setIsEdit(false);
    setFormData({
      id: null,
      type: "",
      multiplier: ""
    });
    setErrors({ type: false, multiplier: false });
    setShowPopup(true);
  };

  const handleEdit = (item) => {
    setIsEdit(true);
    setFormData({
      id: item.id,
      type: item.type,
      multiplier: item.multiplier.toString()
    });
    setErrors({ type: false, multiplier: false });
    setShowPopup(true);
  };

  const handleSave = async () => {
      const typeError = validateName(formData.type);

    let newErrors = {
      type: typeError,
      multiplier: !formData.multiplier.trim(),
    };

    setErrors(newErrors);

    if (newErrors.type || newErrors.multiplier) return;

    try {
      if (isEdit) {
        const payload = {
          type: formData.type.trim(),
          multiplier: parseInt(formData.multiplier)
        };
        
        await updateEquipmentMlp(formData.id, payload);
        
        const updatedData = data.map((item) =>
          item.id === formData.id 
            ? { 
                ...item, 
                type: payload.type, 
                multiplier: formData.multiplier.trim()
              } 
            : item
        );
        setData(updatedData);
      } else {
        const payload = {
          type: formData.type.trim(),
          multiplier: parseInt(formData.multiplier)
        };
        await addEquipmentMlp(payload);
        
        await fetchEquipmentData();
      }

      setShowPopup(false);
      setFormData({ id: null, type: "", multiplier: "" });
      setErrors({ type: false, multiplier: false });
    } catch (error) {
      console.error("Error saving equipment multiplier:", error);
      alert(error.message || "Failed to save equipment multiplier. Please try again.");
    }
  };

  const handleToggleStatus = async () => {
    if (selectedRow === null) return;

    setLoadingToggle(true);
    
    try {
      await toggleEquipmentMlp(selectedRow);
      
      const updatedData = data.map((item) =>
        item.id === selectedRow
          ? { ...item, status: item.status === "Active" ? "Inactive" : "Active" }
          : item
      );
      setData(updatedData);
      
      setShowDeactivateModal(false);
      setShowActivateModal(false);
      setSelectedRow(null);
    } catch (error) {
      console.error("Error toggling status:", error);
      alert(error.message || "Failed to toggle status. Please try again.");
    } finally {
      setLoadingToggle(false);
    }
  };

  const handleDelete = async () => {
    if (selectedRow !== null) {
      try {
        await deleteEquipmentMlp(selectedRow);
        
        setData((prev) => prev.filter((item) => item.id !== selectedRow));
        
        setIsDeleteModalOpen(false);
        setSelectedRow(null);
      } catch (error) {
        console.error("Error deleting equipment multiplier:", error);
        alert(error.message || "Failed to delete equipment multiplier. Please try again.");
      }
    }
  };

  const handleExcelDownload = () => {
    const headers = ['Type', 'Multiplier', 'Status'];
    const csvContent = [
      headers.join(','),
      ...filteredData.map(item => `"${item.type}","${item.multiplier}","${item.status}"`)
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `equipment_multiplier_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const closePopup = () => {
    setShowPopup(false);
    setFormData({ id: null, type: "", multiplier: "" });
    setErrors({ type: false, multiplier: false });
  };

 const filteredData = data.filter((item) => {
  const matchesSearch =
    item.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.multiplier.toString().toLowerCase().includes(searchTerm.toLowerCase());

  const matchesStatus = selectedStatus.length > 0
    ? selectedStatus.includes(item.status)  // only include items matching the chosen status
    : true; // if no status is selected, include everything

  return matchesSearch && matchesStatus;
});

const SortedData = useMemo(() => {
  const filtered = data.filter((item) => {
    const matchesSearch =
      item.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.multiplier.toString().toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = selectedStatus.length > 0
      ? selectedStatus.includes(item.status)
      : true;

    return matchesSearch && matchesStatus;
  });

  if (!sortKey || !sortOrder) return filtered;

  return [...filtered].sort((a, b) => {
    let aVal = a[sortKey];
    let bVal = b[sortKey];

    if (sortKey === "multiplier") {
      aVal = Number(aVal);
      bVal = Number(bVal);
    } else {
      aVal = aVal.toString().toLowerCase();
      bVal = bVal.toString().toLowerCase();
    }

    if (aVal < bVal) return sortOrder === "asc" ? -1 : 1;
    if (aVal > bVal) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [data, searchTerm, selectedStatus, sortKey, sortOrder]);


  // Load more items function
  const loadMoreItems = useCallback(() => {
    if (isLoadingMore || !hasMore) return;

    setIsLoadingMore(true);

    setTimeout(() => {
      const currentLength = displayedItems.length;
      const nextItems = filteredData.slice(currentLength, currentLength + itemsPerLoad);

      if (nextItems.length === 0) {
        setHasMore(false);
      } else {
        setDisplayedItems(prev => [...prev, ...nextItems]);
      }

      setIsLoadingMore(false);
    }, 300);
  }, [displayedItems.length, filteredData, isLoadingMore, hasMore]);

  // Intersection Observer callback
  const lastItemRef = useCallback(node => {
    if (isLoadingMore) return;
    if (observerRef.current) observerRef.current.disconnect();

    observerRef.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        loadMoreItems();
      }
    });

    if (node) observerRef.current.observe(node);
  }, [isLoadingMore, hasMore, loadMoreItems]);

  // Reset displayed items when search or filters change
 useEffect(() => {
  setDisplayedItems(filteredData.slice(0, itemsPerLoad))
  setHasMore(filteredData.length > itemsPerLoad)
}, [searchTerm, selectedStatus, data])


  // Initial load
  useEffect(() => {
    setDisplayedItems(filteredData.slice(0, itemsPerLoad));
    setHasMore(filteredData.length > itemsPerLoad);
  }, []);


const handlePreviewAndDownload = async () => {
  if (!filteredData || filteredData.length === 0) {
    alert("No data available to generate preview");
    return;
  }

  try {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Equipment Attachment Multiplier Master");

    // ========== HEADERS ==========
    sheet.columns = [
      { header: "Sl.No", key: "slNo", width: 10 },
      { header: "Type", key: "type", width: 30 },
      { header: "Multiplier", key: "multiplier", width: 20 },
      { header: "Status", key: "status", width: 15 }
    ];

    // Optional: header styling
    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
      cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF476896" } };
      cell.alignment = { vertical: "middle", horizontal: "left" };
    });

    // ========== DATA ROWS ==========
    filteredData.forEach((item, index) => {
      const row =
      sheet.addRow({
        slNo: index + 1,
        type: item.type,
        multiplier: item.multiplier,
        status: item.status
      });
    row.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });
    });
    

    // ========== CREATE EXCEL FILE ==========
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    });

    const file = new File([blob], "Equipment_Attachment_Multiplier_Master.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    });

    // ========== UPLOAD TO TEMP STORAGE ==========
    const response = await uploadTempFile(file); // Your backend should return a public URL
    const fileUrl = response
      ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
      : null;

    if (fileUrl) {
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    } else {
      console.warn("Upload succeeded but no file URL returned");
      alert("Upload succeeded but no preview available.");
    }
  } catch (error) {
    console.error("Preview generation failed:", error);
    alert("Failed to generate preview. Check console for details.");
  }
};


  return (
    <div className="w-full flex justify-center">
      <div className="w-full ">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2">
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto items-stretch sm:items-center">
            <div className="">
              <Searchinput
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                }}
                placeholder="Search"
                className="w-[1/2]"
                iconColor="text-black"
                bgColor="bg-FrostWhite"
              borderColor="border-black/60"
                textColor="text-black"
                shadow="shadow-none"
                inputPadding="pl-6 pr-3 py-1.5"
                iconSize="w-3 h-3"
                iconLeft="left-3 top-4"
                inputWidth="w-full"
                focusRing="focus:ring-1 focus:ring-black/60"
                hoverInputClasses="hover:bg-white hover:border-black/60"
              />
            </div>
                <Filter
  name="status"
  placeholder="Status"
  options={statusOptions}
  value={selectedStatus} // ✅ array
  customWidth="w-[80px]"
  placeholderColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBgColor="bg-white"
  dropdownTextColor="text-black"
  dropdownHoverColor="hover:bg-lightBlue/50"
  dropdownBorderColor="border-black/60"
  closedBgColor="bg-white"
  hoverRingColor="ring-black"
  openBgColor="bg-white"
  textColor="text-black"
  onChange={(name, value) => {
    setSelectedStatus(value);
  }}
/>
          </div>

          <div className="flex gap-2">
            <button
              onClick={openAdd}
              className="flex items-center gap-2 px-4 py-1 bg-darkblue1 text-white text-xs font-medium transition duration-200 hover:bg-darkblue1"
            >
              <span className="text-lg">+</span>
              Add New
            </button>
            
            <button 
              onClick={handlePreviewAndDownload}
              className="border border-gray-300 hover:bg-gray-300 text-gray-700 px-4 py-1 flex items-center justify-center gap-2 font-medium text-xs  w-full sm:w-auto"
            >
              <Download className="w-3 h-3" />
           Download
            </button>
          </div>
        </div>

        <div className="bg-white shadow-md  border border-Dustyblue overflow-hidden">
          <div
  className="
    overflow-y-auto relative
    max-h-[300px]        /* default (mobile / sm) */
    md:max-h-[350px]     /* medium screens */
    lg:max-h-[400px]     /* large screens */
    xl:max-h-[450px]     /* extra-large screens */
    2xl:max-h-[500px]    /* 2xl screens */
  "
  style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
>
  <style jsx>{`
    div::-webkit-scrollbar {
      display: none;
    }
  `}</style>
            <table className="w-full text-sm border-collapse">
              <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
  <tr>
    {/* Type */}
    <th
      className="px-6 py-1.5 text-xs border border-grey2  border-t-0 border-l-0 font-medium w-[40%] cursor-pointer select-none"
      onClick={() => handleSort("type")}
    >
      <div className="flex items-center gap-1">
        Type
        {sortKey === "type" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "type" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Multiplier */}
    <th
      className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium w-[40%] cursor-pointer select-none"
      onClick={() => handleSort("multiplier")}
    >
      <div className="flex items-center gap-1">
        Multiplier
        {sortKey === "multiplier" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "multiplier" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    {/* Actions (no sort) */}
    <th className="text-center py-1.5 text-xs border border-grey2 border-r-0  border-t-0 font-medium w-[10%]">
      Actions
    </th>
  </tr>
</thead>

              <tbody>
                {isLoading && data.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="px-6 py-8 text-center text-gray-500">
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        Loading...
                      </div>
                    </td>
                  </tr>
                ) : SortedData.length > 0 ? (
                  SortedData.map((item, index) => (
                    <tr 
                      key={item.id}
                      ref={index === SortedData.length - 1 ? lastItemRef : null}
                      className={` hover:bg-lightBlue/50 text-xs ${
                        item.status === "Active" ? "text-black" : "text-gray-400"
                      }`}
                    >
                      <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[20rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.type?.length > 20) setHoveredCell(item.id + "-type");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.type}
    </p>

    {hoveredCell === item.id + "-type" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {item.type}
      </span>
    )}
  </div>
</td>

                      <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[6rem] cursor-pointer"
      onMouseEnter={() => {
        if (item.multiplier?.toString().length > 6) setHoveredCell(item.id + "-multiplier");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {item.multiplier}
    </p>

    {hoveredCell === item.id + "-multiplier" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {item.multiplier}
      </span>
    )}
  </div>
</td>

                      <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                        <div className="flex items-center justify-center gap-4">
                          <div className="relative group">
                            <button 
                              onClick={() => handleEdit(item)}
                              className="text-green-600 hover:text-green-800 transition-colors"
                            >
                              <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/edit.png" className="w-4 h-4" alt="Edit" />
                            </button>
                            <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px]  px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                              Edit
                            </span>
                          </div>

                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedRow(item.id);
                                if (item.status === "Active") {
                                  setShowDeactivateModal(true);
                                } else {
                                  setShowActivateModal(true);
                                }
                              }}
                            >
                              <img
                                src={
                                  item.status === "Active"
                                    ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/active.png"
                                    : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/deactive.png"
                                }
                                alt="Status"
                                className="w-3.5 h-3.5"
                              />
                            </button>
                            <span className="absolute left-1/2 top-full mt-0 -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px]  px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50 pointer-events-none">
                              {item.status === "Active" ? "Deactivate" : "Activate"}
                            </span>
                          </div>

                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedRow(item.id);
                                setIsDeleteModalOpen(true);
                              }}
                              className="text-red-600 hover:text-red-800 transition-colors"
                            >
                              <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png" className="w-4 h-4" alt="Delete" />
                            </button>
                            <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px]  px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-50">
                              Delete
                            </span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={3} className="px-6 py-8 text-center text-gray-500">
                      No data available
                    </td>
                  </tr>
                )}
                {isLoadingMore && (
                  <tr>
                    <td colSpan={3} className="px-6 py-4 text-center text-gray-500">
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                        Loading more...
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {showPopup && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div className="bg-white  shadow-lg p-6 w-96 relative">
              <button
                onClick={closePopup}
                className="absolute top-4 right-4 text-gray-700 transition p-1 hover:scale-105 duration-200"
              >
                <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png" alt="Close" className="w-4 h-4" />
              </button>

              <div className="mb-4 text-center">
                <h3 className="text-gray-700 text-base font-semibold">
                  {isEdit ? "Edit Equipment Multiplier" : "Add New Equipment Multiplier"}
                </h3>
              </div>

              <div className="mb-4">
                <label className="block text-xs font-medium text-black/70 mb-2">Type Name</label>
                <input
                  type="text"
                  value={formData.type}
onChange={(e) => {
      const value = e.target.value;
      setFormData({ ...formData, type: value });

      // ✅ Always validate on change
      const err = validateName(value);
      setErrors({ ...errors, type: err });
    }}                 
    className={`w-full px-4 py-1.5 text-xs border  focus:outline-none focus:ring-1 ${
                    errors.type ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"
                  }`}
                />
                {errors.type && (
    <p className="text-xs text-red1 mt-1">{errors.type}</p>
  )}              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-black/70 mb-2">Multiplier</label>
                <input
                  type="number"
                  value={formData.multiplier}
                  onChange={(e) => setFormData({ ...formData, multiplier: e.target.value })}
                  className={`w-full px-4 py-1.5 text-xs border  focus:outline-none focus:ring-1 ${
                    errors.multiplier
                      ? "border-red1 focus:ring-red1"
                      : "border-black/30 focus:ring-black/30"
                  }`}
                />
                {errors.multiplier && (
                  <p className="text-xs text-red1 mt-1">Please Fill This field</p>
                )}
              </div>

              <div className="flex items-center justify-center gap-4 mt-6">
                <button
                  onClick={handleSave}
                  className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        )}

        {isDeleteModalOpen && selectedRow !== null && (
          <DeleteModal
            isOpen={isDeleteModalOpen}
            onClose={() => {
              setIsDeleteModalOpen(false);
              setSelectedRow(null);
            }}
            onConfirm={handleDelete}
          />
        )}

        <DeactivateStatus
          isOpen={showDeactivateModal}
          loading={loadingToggle}
          onClose={() => {
            if (!loadingToggle) {
              setShowDeactivateModal(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={handleToggleStatus}
        />

        <ActivateStatus
          isOpen={showActivateModal}
          loading={loadingToggle}
          onClose={() => {
            if (!loadingToggle) {
              setShowActivateModal(false);
              setSelectedRow(null);
            }
          }}
          onConfirm={handleToggleStatus}
        />
      </div>
    </div>
  );
};

export default EquipmentTab;