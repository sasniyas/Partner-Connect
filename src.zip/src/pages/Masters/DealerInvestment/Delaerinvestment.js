import React, { useState } from "react";
import Header from "../../../Components/Header";
import EquipmentTab from "./EquipmentTab";
import FinacialTab from "./FinancialTab";
import SubNavbar3 from "../../../Components/SubNavbar3";

function Dealerinvestment() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("equipment");

  return (
<div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          <div className=" w-full ">
            <h2 className="text-center text-xl   font-semibold text-darkblue1 font-VolvoNovum mb-2">
              Dealer Investment Master Data
            </h2>

            {/* Tab Buttons Container */}
           <div className="w-full overflow-x-auto">
  <div className="flex flex-wrap lg:flex-nowrap justify-center gap-3 sm:gap-4 lg:gap-5 min-w-full">
    {/* Equipment Attach Multiplier Master */}
    <button
      onClick={() => setActiveTab("equipment")}
      className={`px-4 py-1.5  font-medium text-sm font-VolvoNovum transition-all duration-200 flex items-center justify-center gap-2 min-w-[220px] sm:min-w-[250px] lg:min-w-[280px] shadow-sm
      ${
        activeTab === "equipment"
          ? "bg-[#7F96B3] text-white"
          : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
      }`}
    >
      Equipment Attachment Multiplier Master
    </button>

    {/* Financials Multiplier for Lube master */}
    <button
      onClick={() => setActiveTab("financial")}
      className={`px-4 py-1.5 font-medium text-sm font-VolvoNovum transition-all duration-200 flex items-center justify-center gap-2 min-w-[220px] sm:min-w-[250px] lg:min-w-[280px] shadow-sm
      ${
        activeTab === "financial"
          ? "bg-[#7F96B3] text-white"
          : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
      }`}
    >
      Financials Multiplier for Lube master
    </button>
  </div>
</div>

            {/* Tab content rendering */}
            <div className="w-full flex justify-center mt-2">
              <div className="w-full ">
                {activeTab === "equipment" && <EquipmentTab />}
                {activeTab === "financial" && <FinacialTab />}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dealerinvestment;