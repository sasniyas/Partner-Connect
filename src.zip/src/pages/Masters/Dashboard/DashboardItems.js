import React, { useState, useEffect } from "react";
import DeleteModal from "../../../Components/DeleteModal";
import { MdAdd } from "react-icons/md";
import {
  addPdpDashboardMedia,
  getPdpDashboardMedia,
  updatePdpDashboardMedia,
  deletePdpDashboardMedia,
  togglePdpDashboardMedia
} from "../../../services/mediaLibrary/pdpDashboardMedia.service";
import {
  addScorecardDashboardMedia,
  getScorecardDashboardMedia,
  updateScorecardDashboardMedia,
  deleteScorecardDashboardMedia,
  toggleScorecardDashboardMedia
} from "../../../services/mediaLibrary/scorecardDashboardMedia.service";
import {
  addMontlyMeetingMedia,
  getMontlyMeetingMedia,
  updateMontlyMeetingMedia,
  deleteMontlyMeetingMedia,
  toggleMontlyMeetingMedia
} from "../../../services/mediaLibrary/monthlyMeetingMedia.service";
import {
  addDealerInvestmentMedia,
  getDealerInvestmentMedia,
  updateDealerInvestmentMedia,
  deleteDealerInvestmentMedia,
  toggleDealerInvestmentMedia
} from "../../../services/mediaLibrary/dealerInvestmentMedia.service";
import {
  addDfhmMedia,
  getAllDfhmMedia,
  updateDfhmMedia,
  deleteDfhmMedia,
  toggleDfhmMedia
} from "../../../services/mediaLibrary/dfhmMedia.service";

function DashboardItems({ tabName, addHeading, editHeading }) {
  const [items, setItems] = useState([]);
  const [showAddPopup, setShowAddPopup] = useState(false);
  const [showEditPopup, setShowEditPopup] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [deletePopup, setDeletePopup] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Service mapping for different media types
  const serviceMap = {
    pdp: {
      get: getPdpDashboardMedia,
      add: addPdpDashboardMedia,
      update: updatePdpDashboardMedia,
      delete: deletePdpDashboardMedia,
      toggle: togglePdpDashboardMedia
    },
    scorecard: {
      get: getScorecardDashboardMedia,
      add: addScorecardDashboardMedia,
      update: updateScorecardDashboardMedia,
      delete: deleteScorecardDashboardMedia,
      toggle: toggleScorecardDashboardMedia
    },
    meeting: {
      get: getMontlyMeetingMedia,
      add: addMontlyMeetingMedia,
      update: updateMontlyMeetingMedia,
      delete: deleteMontlyMeetingMedia,
      toggle: toggleMontlyMeetingMedia
    },
    dealer: {
      get: getDealerInvestmentMedia,
      add: addDealerInvestmentMedia,
      update: updateDealerInvestmentMedia,
      delete: deleteDealerInvestmentMedia,
      toggle: toggleDealerInvestmentMedia
    },
    dfhm: {
      get: getAllDfhmMedia,
      add: addDfhmMedia,
      update: updateDfhmMedia,
      delete: deleteDfhmMedia,
      toggle: toggleDfhmMedia
    }
  };

  // Load data when component mounts or tabName changes
  useEffect(() => {
    const loadData = async () => {
      const service = serviceMap[tabName];
      if (service) {
        setLoading(true);
        setError(null);
        try {
          const data = await service.get();
          setItems(data || []);
        } catch (err) {
          setError(err.message);
          console.error(`Error loading ${tabName} media:`, err);
        } finally {
          setLoading(false);
        }
      }
    };
    loadData();
  }, [tabName]);

  // Add Item
  const handleAdd = async (e) => {
    e.preventDefault();
    const file = e.target.image.files[0];
    const service = serviceMap[tabName];

    if (file && file.size < 100000) {
      alert("Image size must be greater than 100KB");
      return;
    }

    if (service) {
      setLoading(true);
      setError(null);
      try {
        const formData = new FormData();
        formData.append('slide_title', e.target.title.value);
        formData.append('file', file);

        await service.add(formData);
        
        // Reload data after successful addition
        const data = await service.get();
        setItems(data || []);
        setShowAddPopup(false);
        
        // Reset form
        e.target.reset();
      } catch (err) {
        setError(err.message);
        console.error(`Error adding ${tabName} media:`, err);
        alert(`Error: ${err.message}`);
      } finally {
        setLoading(false);
      }
    }
  };

  // Delete Item
  const handleDelete = async () => {
    const service = serviceMap[tabName];
    if (service) {
      setLoading(true);
      setError(null);
      try {
        await service.delete(deleteTarget);
        
        // Reload data after successful deletion
        const data = await service.get();
        setItems(data || []);
        setDeletePopup(false);
        setDeleteTarget(null);
      } catch (err) {
        setError(err.message);
        console.error(`Error deleting ${tabName} media:`, err);
        alert(`Error: ${err.message}`);
      } finally {
        setLoading(false);
      }
    }
  };

  // Edit Item
  const handleEdit = async (e) => {
    e.preventDefault();
    const updatedTitle = e.target.title.value;
    const file = e.target.image.files[0];
    const service = serviceMap[tabName];

    if (file && file.size < 100000) {
      alert("Image size must be greater than 100KB");
      return;
    }

    if (service) {
      setLoading(true);
      setError(null);
      try {
        const formData = new FormData();
        formData.append('id', editingItem.id);
        formData.append('slide_title', updatedTitle);
        if (file) {
          formData.append('file', file);
        }

        await service.update(editingItem.id, formData);
        
        // Reload data after successful update
        const data = await service.get();
        setItems(data || []);
        setShowEditPopup(false);
        setEditingItem(null);
        
        // Reset form
        e.target.reset();
      } catch (err) {
        setError(err.message);
        console.error(`Error updating ${tabName} media:`, err);
        alert(`Error: ${err.message}`);
      } finally {
        setLoading(false);
      }
    }
  };
const [showScrollTop, setShowScrollTop] = useState(false);
  
useEffect(() => {
  const handleScroll = () => {
    setShowScrollTop(window.scrollY > 100);
  };

  window.addEventListener("scroll", handleScroll);
  return () => window.removeEventListener("scroll", handleScroll);
}, []);
  // Popup Modal Component
  function PopupModal({ showPopup, handleClose, handleSubmit, title, initialData }) {
    const [fileName, setFileName] = useState(initialData?.slide_title || "");
    const [fileError, setFileError] = useState("");
    const [isImageValid, setIsImageValid] = useState(!!initialData?.image_url);
    const [previewImage, setPreviewImage] = useState(initialData?.image_url || null);

    const handleImageChange = (e) => {
      const file = e.target.files[0];
      if (file) {
        if (file.size < 100000) {
          setFileError("File size must be greater than 100KB");
          setIsImageValid(false);
          setFileName("");
          setPreviewImage(null);
        } else {
          setFileError("");
          setIsImageValid(true);
          setFileName(file.name);
          const reader = new FileReader();
          reader.onloadend = () => {
            setPreviewImage(reader.result);
          };
          reader.readAsDataURL(file);
        }
      }
    };

    const handleFormSubmit = (e) => {
      e.preventDefault();
      if (!isImageValid && !previewImage) return;
      handleSubmit(e);
    };

    return (
      showPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
          <div className="bg-white p-6  w-[50%] shadow-lg relative">
            <div className="flex items-center justify-center relative mb-8">
              <h2 className="w-full text-center">
                <span className="text-base text-MediumGrey font-semibold bg-transparent px-4 py-1 inline-block">
                  {initialData ? `Edit ${title}` : `Add ${title}`}
                </span>
              </h2>
              <button
                onClick={handleClose}
                className="absolute top-0 right-0 text-gray-700 transition p-1 hover:scale-105 duration-200"
              >
                <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>


              </button>
            </div>

            <form onSubmit={handleFormSubmit}>
              <input
                type="text"
                name="title"
                placeholder="Enter Slide Title"
                defaultValue={initialData?.slide_title || ""}
                maxLength={20}
                className="w-full text-xs font-volvoNovum border border-black/30 focus:ring-black/30 focus:outline-none mb-3 p-2"
                required
              />

              <div className="w-full mb-3">
                {previewImage && (
                  <img
                    src={previewImage}
                    alt="Preview"
                    className="w-full h-32 object-cover  mb-2"
                  />
                )}
                <label
                  htmlFor="image"
                  className={`flex items-center justify-between w-full text-xs font-volvoNovum border border-black/30 p-1.5  cursor-pointer ${
                    fileName || previewImage ? "text-black" : "text-gray-500"
                  }`}
                >
                  <span>{fileName || "Upload Image"}</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<path d="M28.3327 17.3332V11.3332C28.3327 9.56506 27.6303 7.86937 26.3801 6.61913C25.1298 5.36888 23.4341 4.6665 21.666 4.6665H10.3327C8.56457 4.6665 6.86888 5.36888 5.61864 6.61913C4.36839 7.86937 3.66602 9.56506 3.66602 11.3332V20.6665C3.66602 21.542 3.83845 22.4089 4.17349 23.2177C4.50852 24.0266 4.99958 24.7615 5.61864 25.3805C6.86888 26.6308 8.56457 27.3332 10.3327 27.3332H18.6793" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M4.01172 22.6667L7.66505 18.4C8.14484 17.9235 8.77453 17.6274 9.44756 17.5618C10.1206 17.4962 10.7956 17.6651 11.3584 18.04C11.9212 18.4149 12.5962 18.5838 13.2692 18.5182C13.9422 18.4526 14.5719 18.1565 15.0517 17.68L18.1584 14.5733C19.051 13.6777 20.2329 13.1283 21.4931 13.0233C22.7533 12.9183 24.0098 13.2644 25.0384 14L28.3317 16.5467M10.6784 13.56C10.969 13.5583 11.2565 13.4993 11.5244 13.3864C11.7922 13.2736 12.0353 13.1091 12.2395 12.9023C12.4438 12.6955 12.6054 12.4506 12.715 12.1814C12.8246 11.9122 12.8801 11.624 12.8784 11.3333C12.8766 11.0427 12.8177 10.7552 12.7048 10.4874C12.592 10.2195 12.4275 9.97647 12.2207 9.77218C12.0139 9.56789 11.7689 9.40633 11.4997 9.29672C11.2305 9.18711 10.9424 9.13159 10.6517 9.13334C10.0647 9.13688 9.50314 9.37346 9.09056 9.79104C8.67798 10.2086 8.44818 10.773 8.45172 11.36C8.45526 11.947 8.69184 12.5086 9.10942 12.9212C9.527 13.3337 10.0914 13.5635 10.6784 13.56Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M24.9414 20V26.6667" stroke="black" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M27.9994 22.8067L25.3768 20.184C25.3198 20.1268 25.252 20.0814 25.1774 20.0504C25.1029 20.0194 25.0229 20.0034 24.9421 20.0034C24.8613 20.0034 24.7813 20.0194 24.7067 20.0504C24.6322 20.0814 24.5644 20.1268 24.5074 20.184L21.8848 22.8067" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
                </label>
                <input
                  id="image"
                  type="file"
                  name="image"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageChange}
                  required={!initialData}
                />
              </div>

              {fileError && (
                <div className="text-red1 text-xs mt-2">{fileError}</div>
              )}

              <div className="mt-6 flex justify-center">
                <button
                  type="submit"
                  className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 transition"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )
    );
  }

  const showAddCard = items.length > 0;
  return (
    <div className="p-4 md:p-10 flex flex-col min-h-screen">
      {/* Loading State */}
      {loading && (
        <div className="flex justify-center items-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
          <span className="ml-2 text-darkblue1">Loading...</span>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3  mb-4">
          <strong>Error:</strong> {error}
        </div>
      )}

     {!loading && items.length === 0 && (
  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-3 gap-4 flex-grow ">
    <div
      onClick={() => setShowAddPopup(true)}
      className="cursor-pointer border-2 border-dashed border-grey text-black flex flex-col justify-center items-center p-8 hover:bg-lightBlue/50 transition h-[245px]"
    >
      <span className="text-sm font-medium">+Add New</span>
    </div>
  </div>
)}


      {!loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-3 gap-4 flex-grow">
          {items.map((item, index) => (
            <div
              key={item.id}
              className="bg-white  shadow-[0_4px_10px_rgba(167,205,250,0.45)] overflow-hidden relative h-[260px] hover:scale-105 hover:shadow-xl transition-all duration-300 ease-in-out"
            >
              <div className="relative">
                <img
                  src={item.image_url}
                  alt="Uploaded"
                  className="w-full h-48 object-cover"
                />
                <div className="absolute inset-0 bg-black opacity-30"></div>
                <div className="absolute bottom-2 right-2 bg-white px-2 py-1 text-xs  shadow text-black font-VolvoNovum font-semibold">
                  ID: {(index + 1).toString().padStart(2, "0")}
                </div>
              </div>

              <div className="p-1">
                <div className="flex items-center justify-between gap-2 w-full">
                  <div className="relative group flex items-center gap-1 overflow-hidden cursor-pointer">
                    <span className="font-semibold text-VolovoNovum text-xs whitespace-nowrap">
                      Title:
                    </span>
                    <span className="text-xs font-normal truncate whitespace-nowrap text-ellipsis flex-1">
                      {item.slide_title}
                    </span>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <div className="relative group">
                      <button
                        onClick={() => {
                          setEditingItem(item);
                          setShowEditPopup(true);
                        }}
                        className="p-1 hover:scale-105 transition-all duration-200 ease-in-out"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="20" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

                      </button>
                    </div>
                    <div className="relative group">
                      <button
                        onClick={() => {
                          setDeleteTarget(item.id);
                          setDeletePopup(true);
                        }}
                        className="p-1 hover:scale-105 transition-all duration-200 ease-in-out"
                      >
                       <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>	

                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {showAddCard && (
            <div
              onClick={() => setShowAddPopup(true)}
              className="cursor-pointer border-2 border-dashed border-grey text-black  flex flex-col justify-center items-center p-8 hover:bg-lightBlue/50 transition h-[245px]"
            >
              <span className="text-sm font-medium">+Add New</span>
            </div>
          )}
        </div>
      )}
{showScrollTop && items.length >= 9 && (
  <div className="mb-2 flex justify-end">
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="bg-Silvergrey text-black font-bold px-4 py-2 shadow-lg hover:scale-110 transition duration-200"
    >
      ^
    </button>
  </div>
)}

      <DeleteModal
        isOpen={deletePopup}
        onClose={() => setDeletePopup(false)}
        onConfirm={handleDelete}
      />

      {showAddPopup && (
        <PopupModal
          showPopup={showAddPopup}
          handleClose={() => setShowAddPopup(false)}
          handleSubmit={handleAdd}
          title={addHeading}
        />
      )}

      {showEditPopup && editingItem && (
        <PopupModal
          showPopup={showEditPopup}
          handleClose={() => setShowEditPopup(false)}
          handleSubmit={handleEdit}
          title={editHeading}
          initialData={editingItem}
        />
      )}
    </div>
  );
}

export default DashboardItems;
