import React from "react";
import { useNavigate } from "react-router-dom";
import Competencetable from "./Competencetable";

const CompetenceScore = () => {
  const navigate = useNavigate();

 const buttons = [
     { label: "Competence Level", path: "/competencelevel"},
             { label: "Specialization", path: "/competencemanagement" },    
             ];
  const currentPath =  "/competencelevel" ; // ✅ Update currentPath

  return (
    <div className="w-full flex flex-col items-center justify-center px-2">
      {/* Heading */}
      <h2 className="text-center text-xl font-semibold text-darkblue1 font-VolvoNovum mb-2">
    Competence Management
      </h2>

      {/* Button Row */}
      <div className="w-full overflow-x-auto">
        {/* Tab Navigation */}
<div className="flex w-full mb-2 overflow-hidden ">
  {buttons.map(({ label, path }) => (
    <button
      key={label}
      onClick={() => {
        if (path !== currentPath && path !== "#") navigate(path);
      }}
      className={`flex-1 py-2 text-xs font-medium font-VolvoNovum transition
        ${
          path === currentPath
            ? "bg-Dustyblue text-white"
            : "bg-gray-200 text-gray-700 hover:bg-gray-300"
        }
      `}
    >
      {label}
    </button>
  ))}
</div>

      </div>

      {/* ✅ State Master Table */}
    <div className="w-full flex justify-center">
  <div className="w-full ">
        <Competencetable/>
      </div>
      </div>
    </div>
  );
};

export default CompetenceScore;
