import React, { useState, useEffect, useRef, useMemo, useReducer } from "react"
import Searchinput from "../../../../Components/Searchinput"
import Filter from "../../../../Components/Filter"
import ActivateStatus from "../../../../Components/ActivateStatus"
import DeactivateStatus from "../../../../Components/DeactivateStatus"
import DeleteModal from "../../../../Components/DeleteModal"
import ExcelJS from "exceljs"
import { saveAs } from "file-saver"
import { uploadTempFile } from "../../../../services/download/bluckDownload.service"
import { useNavigate } from "react-router-dom"
import { ChevronDown, ChevronUp } from "lucide-react"
import { toast } from "react-toastify"
import { ChevronsUpDown } from "lucide-react"
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import useCRUDWithReset from "../../../../util/useCRUDWithReset"

import {
  addSpecializationCompetence,
  updateSpecializationCompetence,
  toggleSpecializationCompetenceStatus,
  deleteSpecializationCompetence,
  getAllSpecializationCompetences,
} from "../../../../services/masterOthers/specializationCompetence.service"
import { useKeyboardNavigation } from "../../../../util/useKeyboardNavigation"

const SpecializationTable = () => {
  const navigate = useNavigate()

  /* ========== MAIN TABLE DATA ========== */
  const [tableData, setTableData] = useState([])

  /* ========== UI STATES ========== */
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState([])
  const [hoveredCell, setHoveredCell] = useState(null)
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const popupRef = useRef(null)
  /* ========== FORM STATES ========== */
  const [specialization, setSpecialization] = useState("")
  const [error, setError] = useState("")
  const [editId, setEditId] = useState(null)
  const [selectedRow, setSelectedRow] = useState(null)

  /* ========== MODAL STATES ========== */
  const [showPopup, setShowPopup] = useState(false)
  const [showActivateModal, setShowActivateModal] = useState(false)
  const [showDeactivateModal, setShowDeactivateModal] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)

  /* ========== LOADING & ERROR ========== */
  const [isLoadingData, setIsLoadingData] = useState(false)
  const [loading, setLoading] = useState(false)
  const [loadingToggle, setLoadingToggle] = useState(false)
  const [fetchError, setFetchError] = useState(null)

  /* ========== SORT STATES ========== */
  const [sortKey, setSortKey] = useState(null)
  const [sortOrder, setSortOrder] = useState(null)

  /* ========== UI REFS ========== */
  const dropdownRef = useRef(null)
  const tableContainerRef = useRef(null)

  // ========== SCROLL STATES ==========
    const [showScrollButtons, setShowScrollButtons] = useState(false);
    const [scrollPosition, setScrollPosition] = useState(0);
    const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
    const [lastScrollTop, setLastScrollTop] = useState(0);
  
   // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  /* ========== DROPDOWNS ========== */
  const statusOptions = ["Active", "Inactive"]

  // ========== FETCH DATA ON MOUNT ==========
  useEffect(() => {
    fetchSpecializationCompetences()
  }, [])

  const fetchSpecializationCompetences = async () => {
    setIsLoadingData(true)
    setFetchError(null)
    try {
      const response = await getAllSpecializationCompetences()
      setTableData(response)
    } catch (err) {
      // console.error("Error fetching specialization competences:", err)
      setFetchError(err.message || "Failed to fetch specialization competences")
      toast.error(err.message || "Failed to fetch specialization competences")
    } finally {
      setIsLoadingData(false)
    }
  }

  // ========== SORT HANDLER ==========
  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc")
        return
      }
      if (sortOrder === "desc") {
        setSortKey(null)
        setSortOrder(null)
        return
      }
    }
    setSortKey(key)
    setSortOrder("asc")
  }

  // ========== CLOSE DROPDOWN ON OUTSIDE CLICK ==========
  useEffect(() => {
    const handler = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false)
      }
    }
    document.addEventListener("mousedown", handler)
    return () => document.removeEventListener("mousedown", handler)
  }, [])

  // ========== FILTERED & SORTED DATA ==========
  const filteredAndSortedData = useMemo(() => {
    let filtered = tableData.filter((item) => {
      const searchLower = (searchTerm || "").toLowerCase()

      const matchesSearch =
        (item.specialization || "").toLowerCase().includes(searchLower)

      const matchesStatus =
        selectedStatus.length === 0 ||
        selectedStatus.includes(item.status)

      return matchesSearch && matchesStatus
    })

    if (!sortKey || !sortOrder) return filtered

    return [...filtered].sort((a, b) => {
      const valA = (a[sortKey] || "").toString().trim().toLowerCase()
      const valB = (b[sortKey] || "").toString().trim().toLowerCase()

      return sortOrder === "asc"
        ? valA.localeCompare(valB, undefined, { sensitivity: "base", numeric: true })
        : valB.localeCompare(valA, undefined, { sensitivity: "base", numeric: true })
    })
  }, [tableData, searchTerm, selectedStatus, sortKey, sortOrder])
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchTerm: { setter: setSearchTerm, resetValue: "" },
   selectedStatus: {setter :setSelectedStatus,resetValue :[]}
  }
);
  // ========== HANDLE EDIT ==========
  const handleEdit = (item) => {
    setEditId(item.id)
    setSpecialization(item.specialization)
    setError("")
    setShowPopup(true)
  }

  // ========== HANDLE SAVE ==========
  const handleSave = async () => {
    if (!specialization.trim()) {
      setError("Please fill out this field")
      return
    }

    if (specialization.trim().length > 100) {
      setError("Specialization cannot exceed 100 characters")
      return
    }

    setLoading(true)

    try {
      if (editId) {
        // UPDATE
        await updateSpecializationCompetence({
          id: editId,
          specialization: specialization.trim(),
        })
        
        setTableData((prev) =>
          prev.map((item) =>
            item.id === editId
              ? {
                  ...item,
                  specialization: specialization.trim(),
                }
              : item
          )
        )
        toast.success("Specialization updated successfully")
      } else {
        // ADD NEW
        await addSpecializationCompetence({
          specialization: specialization.trim(),
        })
        resetSortAndFilter()
        await fetchSpecializationCompetences()
        toast.success("Specialization added successfully")
      }

      // Reset
      setSpecialization("")
      setError("")
      setEditId(null)
      setShowPopup(false)
    } catch (err) {
      // console.error("Error saving specialization:", err)
      toast.error(err.message || "Failed to save specialization")
    } finally {
      setLoading(false)
    }
  }

  // ========== HANDLE TOGGLE STATUS ==========
  const handleToggleStatus = async () => {
    if (selectedRow === null) return

    setLoadingToggle(true)

    try {
      await toggleSpecializationCompetenceStatus(selectedRow)

      setTableData((prev) =>
        prev.map((item) =>
          item.id === selectedRow
            ? { ...item, status: item.status === "Active" ? "Inactive" : "Active" }
            : item
        )
      )

      toast.success(`Specialization ${tableData.find(t => t.id === selectedRow)?.status === "Active" ? "deactivated" : "activated"} successfully`)
      setShowActivateModal(false)
      setShowDeactivateModal(false)
      setSelectedRow(null)
    } catch (err) {
      // console.error("Error toggling status:", err)
      toast.error(err.message || "Failed to toggle status")
    } finally {
      setLoadingToggle(false)
    }
  }

  // ========== HANDLE DELETE ==========
  const handleDelete = async () => {
    if (selectedRow === null) return

    try {
      await deleteSpecializationCompetence(selectedRow)
      setTableData((prev) => prev.filter((item) => item.id !== selectedRow))
      resetSortAndFilter()
      setIsDeleteModalOpen(false)
      setSelectedRow(null)
      toast.success("Specialization deleted successfully")
    } catch (err) {
      // console.error("Error deleting specialization:", err)
      toast.error(err.message || "Failed to delete specialization")
    }
  }

  // ========== HANDLE DOWNLOAD TEMPLATE ==========
  const handleDownloadTemplate = async () => {
    try {
      const workbook = new ExcelJS.Workbook()
      const sheet = workbook.addWorksheet("Specialization Template")

      const header = sheet.addRow(["Specialization"])
      header.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: "FFFFFFFF" } }
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        }
        cell.alignment = { vertical: "middle", horizontal: "left" }
      })

      sheet.columns = [{ width: 40 }]

      const exampleRow = sheet.addRow(["Cardiology & Interventional Medicine"])
      exampleRow.eachCell((cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" }
      })

      const buffer = await workbook.xlsx.writeBuffer()
      saveAs(
        new Blob([buffer], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        }),
        "Specialization_Template.xlsx"
      )
      toast.success("Template downloaded successfully")
    } catch (error) {
      // console.error("Error downloading template:", error)
      toast.error("Failed to download template")
    }
  }

  // ========== HANDLE PREVIEW & DOWNLOAD ==========
  const handlePreviewAndDownload = async () => {
    if (!filteredAndSortedData || filteredAndSortedData.length === 0) {
      toast.error("No data available to generate preview")
      return
    }

    try {
      const workbook = new ExcelJS.Workbook()
      const sheet = workbook.addWorksheet("Specialization")

      sheet.columns = [
        { header: "Sl. No", key: "slNo", width: 10 },
        { header: "Specialization", key: "specialization", width: 40 },
        { header: "Status", key: "status", width: 15 },
      ]

      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } }
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FF476896" },
        }
        cell.alignment = { vertical: "middle", horizontal: "left" }
      })

      filteredAndSortedData.forEach((item, index) => {
        const row = sheet.addRow({
          slNo: index + 1,
          specialization: item.specialization || "",
          status: item.status || "",
        })

        row.eachCell((cell) => {
          cell.alignment = { vertical: "middle", horizontal: "left" }
        })
      })

      const buffer = await workbook.xlsx.writeBuffer()
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      })
      const file = new File([blob], "Specialization.xlsx", {
        type: blob.type,
      })

      const response = await uploadTempFile(file)
      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer")
        toast.success("Preview opened successfully")
      } else {
        toast.warning("Upload succeeded but no preview available")
      }
    } catch (error) {
      // console.error("Preview generation failed:", error)
      toast.error("Failed to generate preview")
    }
  }
useKeyboardNavigation({
  containerRef: popupRef,
  onSubmit: handleSave,
  onCancel: () =>{
     setSpecialization("")
      setError("")
      setEditId(null)
      setShowPopup(false)
  },
});
  return (
    <div className="w-full mt-2">
      {/* Error Display */}
      {fetchError && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 flex items-center justify-between">
          <span className="text-red-600">{fetchError}</span>
          <button onClick={() => setFetchError(null)} className="text-red-600 hover:text-red-800">
            ✕
          </button>
        </div>
      )}

      {/* SEARCH + FILTER + ACTIONS */}
      <div className="flex justify-between mb-2">
        <div className="flex gap-2">
          <Searchinput
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search"
            bgColor="bg-FrostWhite"
            borderColor="border-black/60"
            textColor="text-black"
            shadow="shadow-none"
            inputPadding="pl-6 pr-3 py-1.5"
            iconSize="w-3 h-3"
            iconLeft="left-3"
            inputWidth="w-full"
            focusRing="focus:ring-1 focus:ring-black/60"
            hoverInputClasses="hover:bg-white hover:border-black/60"
          />

          <Filter
            name="status"
            value={selectedStatus}
            options={statusOptions}
            onChange={(name, val) => setSelectedStatus(val)}
            placeholder="Status"
            customWidth="w-[100px]"
            placeholderColor="text-black"
            buttonBorderColor="border-black/60"
            dropdownBgColor="bg-white"
            dropdownTextColor="text-black"
            dropdownHoverColor="hover:bg-lightBlue/50"
            dropdownBorderColor="border-black/60"
            closedBgColor="bg-white"
            hoverRingColor="ring-black"
            openBgColor="bg-white"
            textColor="text-black"
          />
        </div>

        {/* ACTIONS BUTTON */}
        <div className="relative w-[10%]" ref={dropdownRef}>
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className={`flex items-center justify-center w-full px-4 py-1 text-white text-xs font-medium bg-darkblue1 shadow-md transition duration-200 ${
              dropdownOpen ? "" : "hover:scale-105"
            }`}
          >
            Actions
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              className={`w-5 h-5 cursor-pointer transition-transform duration-300 ${
                dropdownOpen ? "rotate-180" : "rotate-0"
              }`}
              fill="none"
            >
              <path
                d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
                fill="currentColor"
              />
            </svg>
          </button>

          {dropdownOpen && (
            <div className="absolute left-0 mt-1 w-full bg-white border border-darkblue1 shadow-lg z-[90] cursor-pointer">
              <ul className="p-0">
                <li
                  onClick={() => {
                    setShowPopup(true)
                    setDropdownOpen(false)
                    setEditId(null)
                    setSpecialization("")
                  }}
                  className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center justify-start gap-2.5"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15" fill="none">
                    <path d="M12.8333 5.5H9.16667V1.83333C9.16667 1.3471 8.97351 0.880787 8.6297 0.536971C8.28588 0.193154 7.81956 0 7.33333 0C6.8471 0 6.38079 0.193154 6.03697 0.536971C5.69315 0.880787 5.5 1.3471 5.5 1.83333L5.56508 5.5H1.83333C1.3471 5.5 0.880787 5.69315 0.536971 6.03697C0.193154 6.38079 0 6.8471 0 7.33333C0 7.81956 0.193154 8.28588 0.536971 8.62969C0.880787 8.97351 1.3471 9.16667 1.83333 9.16667L5.56508 9.10158L5.5 12.8333C5.5 13.3196 5.69315 13.7859 6.03697 14.1297C6.38079 14.4735 6.8471 14.6667 7.33333 14.6667C7.81956 14.6667 8.28588 14.4735 8.6297 14.1297C8.97351 13.7859 9.16667 13.3196 9.16667 12.8333V9.10158L12.8333 9.16667C13.3196 9.16667 13.7859 8.97351 14.1297 8.62969C14.4735 8.28588 14.6667 7.81956 14.6667 7.33333C14.6667 6.8471 14.4735 6.38079 14.1297 6.03697C13.7859 5.69315 13.3196 5.5 12.8333 5.5Z" fill="#212121" />
                  </svg>
                  <span>Add New</span>
                </li>

                <li>
                  <button
                    onClick={() => navigate("/specializationbulkupload")}
                    className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-1.5"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black" />
                    </svg>
                    Bulk Upload
                  </button>
                </li>

                <li
                  onClick={() => {
                    setDropdownOpen(false)
                    handlePreviewAndDownload()
                  }}
                  className="flex items-center gap-1.5 px-4 py-1.5 text-xs hover:bg-lightBlue/50 cursor-pointer whitespace-nowrap"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
                    <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121" />
                    <path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M1 14.75H12" stroke="#212121" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  <span>Download</span>
                </li>

                <li
                  onClick={() => {
                    handleDownloadTemplate()
                    setDropdownOpen(false)
                  }}
                  className="w-full text-left px-4 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center justify-start gap-2 cursor-pointer whitespace-nowrap"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 22 22" fill="none">
                    <path d="M10.9994 10.0834C11.2425 10.0834 11.4756 10.18 11.6475 10.3519C11.8195 10.5238 11.916 10.7569 11.916 11V17.0354L13.1013 15.851C13.2734 15.6792 13.5068 15.5827 13.75 15.5829C13.9933 15.583 14.2265 15.6798 14.3984 15.852C14.5702 16.0241 14.6667 16.2574 14.6665 16.5007C14.6664 16.7439 14.5696 16.9772 14.3974 17.149L11.8088 19.7331C11.5769 19.9641 11.3504 20.1667 10.9994 20.1667C10.6914 20.1667 10.4805 20.0118 10.277 19.8184L7.60128 17.149C7.42915 16.9772 7.33236 16.7439 7.33218 16.5007C7.33201 16.2574 7.42848 16.0241 7.60036 15.852C7.77224 15.6798 8.00546 15.583 8.24871 15.5829C8.49196 15.5827 8.72532 15.6792 8.89744 15.851L10.0827 17.0354V11C10.0827 10.7569 10.1793 10.5238 10.3512 10.3519C10.5231 10.18 10.7562 10.0834 10.9994 10.0834ZM10.541 1.83337C13.093 1.83337 15.271 3.43754 16.1199 5.69437C17.2507 6.00528 18.2525 6.66933 18.9794 7.58967C19.7063 8.51001 20.1201 9.6385 20.1605 10.8106C20.2009 11.9826 19.8658 13.1369 19.2041 14.1052C18.5424 15.0734 17.5886 15.8049 16.4819 16.193C16.4126 15.5742 16.1353 14.9974 15.6954 14.5567C15.2264 14.0869 14.6032 13.8027 13.9409 13.7565L13.7494 13.75V11C13.7501 10.2842 13.4716 9.59632 12.9732 9.08254C12.4747 8.56876 11.7956 8.26958 11.0801 8.24857C10.3645 8.22757 9.66903 8.48639 9.1413 8.97005C8.61358 9.4537 8.29525 10.1241 8.25394 10.8387L8.24936 11V13.75C7.88788 13.75 7.52994 13.8212 7.19601 13.9596C6.86209 14.0981 6.55872 14.3009 6.30328 14.5567C5.81094 15.05 5.52426 15.7118 5.50119 16.4084C4.54688 16.2134 3.67945 15.7195 3.02465 14.9984C2.36986 14.2773 1.96171 13.3664 1.85937 12.3978C1.75703 11.4291 1.96582 10.4531 2.45547 9.61105C2.94512 8.76904 3.6902 8.10483 4.58269 7.71471C4.60295 6.14784 5.23962 4.65202 6.35484 3.55122C7.47006 2.45041 8.97403 1.83324 10.541 1.83337Z" fill="black" />
                  </svg>
                  <span>Template File</span>
                </li>
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* TABLE */}
      <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
        <div
          ref={tableContainerRef}
          className="w-full overflow-y-auto overflow-x-hidden"
          style={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
            maxHeight: filteredAndSortedData.length > 8 ? "calc(100vh - 240px)" : "auto",
          }}
            onScroll={handleTableScroll}
        >
          <style>{`
            div::-webkit-scrollbar {
              display: none;
            }
          `}</style>

          <table className="w-full text-xs whitespace-nowrap">
            <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
              <tr>
                <th
                  className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%] cursor-pointer select-none"
                  onClick={() => handleSort("specialization")}
                >
                  <div className="flex items-center gap-1">
                    Specialization
                    {sortKey !== "specialization" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}


                    {sortKey === "specialization" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                    {sortKey === "specialization" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                  </div>
                </th>

              

                <th className="text-center py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[20%]">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody>
              {isLoadingData && filteredAndSortedData.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-6 py-8 text-center text-gray-500">
                    <div className="flex items-center justify-center gap-2">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                      Loading...
                    </div>
                  </td>
                </tr>
              )}

              {!isLoadingData && filteredAndSortedData.length > 0
                ? filteredAndSortedData.map((item) => (
                    <tr
                      key={item.id}
                      className={`hover:bg-lightBlue/50 text-xs ${
                        item.status === "Inactive" ? "text-gray-400" : "text-black"
                      }`}
                    >
                      <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                        <div className="relative">
                          <p
                            className="truncate max-w-[30rem] cursor-pointer"
                            onMouseEnter={() => {
                              if ((item.specialization ?? "").length > 20)
                                setHoveredCell(item.id + "-specialization")
                            }}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {item.specialization}
                          </p>

                          {hoveredCell === item.id + "-specialization" && (
                            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                              {item.specialization}
                            </span>
                          )}
                        </div>
                      </td>

                      
                      <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 border-r-0 w-[20%]">
                        <div className="flex items-center justify-center gap-4">
                          {/* Edit */}
                          <div className="relative group">
                            <button onClick={() => handleEdit(item)}>
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                <path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6" />
                                <path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6" />
                              </svg>
                            </button>
                            <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              Edit
                            </span>
                          </div>

                          {/* Activate/Deactivate */}
                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedRow(item.id)
                                item.status === "Active"
                                  ? setShowDeactivateModal(true)
                                  : setShowActivateModal(true)
                              }}
                            >
                              {item.status === "Active" ? (
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
                                  <path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round" />
                                </svg>
                              ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none">
                                  <g clipPath="url(#clip0_5669_3080)">
                                    <path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round" />
                                  </g>
                                  <defs>
                                    <clipPath id="clip0_5669_3080">
                                      <rect width="24" height="24" fill="white" />
                                    </clipPath>
                                  </defs>
                                </svg>
                              )}
                            </button>
                            <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              {item.status === "Active" ? "Deactivate" : "Activate"}
                            </span>
                          </div>

                          {/* Delete */}
                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedRow(item.id)
                                setIsDeleteModalOpen(true)
                              }}
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                                <g clipPath="url(#clip0_6398_313)">
                                  <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012" />
                                </g>
                                <defs>
                                  <clipPath id="clip0_6398_313">
                                    <rect width="24" height="24" fill="white" transform="translate(4 4)" />
                                  </clipPath>
                                </defs>
                              </svg>
                            </button>
                            <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              Delete
                            </span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))
                : !isLoadingData && (
                    <tr>
                      <td colSpan={3} className="text-center py-8 text-gray-500 italic">
                        No data found
                      </td>
                    </tr>
                  )}
            </tbody>
          </table>
           {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  title="Scroll to bottom"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}
        </div>
        
      </div>

      {/* ADD / EDIT POPUP */}
      {showPopup && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div
          ref={popupRef} 
          className="bg-white shadow-lg p-6 w-96 relative">
            <button
              onClick={() => {
                setShowPopup(false)
                setSpecialization("")
                setError("")
                setEditId(null)
              }}
              className="absolute top-4 right-4 p-1 hover:scale-105 transition"
            >
              <svg width="14" height="14" viewBox="0 0 20 20">
                <circle cx="10" cy="10" r="8" fill="#BF2012" />
                <path
                  d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>
            </button>

            <div className="mb-4 text-center">
              <h3 className="text-MediumGrey text-base font-semibold">
                {editId ? "Edit Specialization" : "Add Specialization"}
              </h3>
            </div>

            <div className="mb-4">
              <label className="block text-xs font-medium text-black/70 mb-1">
                Specialization <span className=" text-red1">*</span>
              </label>
              <input
                type="text"
                maxLength={100}
                value={specialization}
                placeholder="Enter Specialization"
                onChange={(e) => {
                  setSpecialization(e.target.value)
                  setError("")
                }}
                className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all
                  ${
                    error
                      ? "border-red1 focus:ring-red1"
                      : "border-black/30 focus:ring-black/30"
                  }`}
              />
              {error && <p className="text-red1 text-xs mt-1">{error}</p>}
            </div>

            <div className="text-center">
              <button
                disabled={loading}
                onClick={handleSave}
                className={`bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 transition
                  ${
                    loading
                      ? "opacity-50 cursor-not-allowed"
                      : "hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
                  }`}
              >
                {loading ? "Saving..." : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODALS */}
      <ActivateStatus
        isOpen={showActivateModal}
        loading={loadingToggle}
        onClose={() => {
          if (!loadingToggle) {
            setShowActivateModal(false)
            setSelectedRow(null)
          }
        }}
        onConfirm={handleToggleStatus}
      />
      <DeactivateStatus
        isOpen={showDeactivateModal}
        loading={loadingToggle}
        onClose={() => {
          if (!loadingToggle) {
            setShowDeactivateModal(false)
            setSelectedRow(null)
          }
        }}
        onConfirm={handleToggleStatus}
      />
      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false)
          setSelectedRow(null)
        }}
        onConfirm={handleDelete}
      />
    </div>
  )
}

export default SpecializationTable