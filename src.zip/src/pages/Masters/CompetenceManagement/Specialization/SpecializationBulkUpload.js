import React, { useState, useRef } from "react";
import * as XLSX from "xlsx";
import Header from "../../../../Components/Header";
import SubNavbar3 from "../../../../Components/SubNavbar3";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import {
  bulkAddSpecializationCompetence,
  getAllSpecializationCompetences,
} from "../../../../services/masterOthers/specializationCompetence.service";

const SpecializationBulkUpload = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  const [menuOpen, setMenuOpen] = useState(false);
  const [fileName, setFileName] = useState("");
  const [rows, setRows] = useState([]);
  const [isChecking, setIsChecking] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [duplicateInfo, setDuplicateInfo] = useState(null);
  const [isDragActive, setIsDragActive] = useState(false);

  // BACK
  const handleBack = () => {
    navigate("/competencemanagement");
  };

  // ================= PARSE EXCEL FILE =================
  const parseExcelFile = (arrayBuffer) => {
    const data = new Uint8Array(arrayBuffer);
    const workbook = XLSX.read(data, { type: "array" });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    
    if (!sheet) {
      toast.error("Excel file appears to be empty");
      return null;
    }

    let json = XLSX.utils.sheet_to_json(sheet, { defval: "" });

    json = json.filter((row) =>
      Object.values(row).some((cell) => String(cell).trim() !== "")
    );

    if (json.length === 0) {
      toast.warning("No data rows found in the Excel file");
      return [];
    }

    const parsedRows = json.map((row) => ({
      specialization: String(row["Specialization"] || "").trim(),
      hasError: false,
      isDuplicate: false,
      errors: [],
    }));

    return validateRows(parsedRows);
  };

  // FILE UPLOAD
  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const finalRows = parseExcelFile(evt.target.result);
        if (finalRows !== null) {
          setRows(finalRows);
          if (finalRows.length > 0) {
            toast.success(`${finalRows.length} row(s) loaded successfully`);
          }
        }
      } catch (error) {
        console.error("Error parsing Excel file:", error);
        toast.error("Failed to parse Excel file. Please check the format.");
      }
    };

    reader.onerror = () => {
      toast.error("Failed to read the file");
    };

    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  // ================= DRAG AND DROP HANDLERS =================
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    const file = e.dataTransfer.files[0];
    if (!file) return;

    // Validate file type
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error("Please drop an Excel file (.xlsx or .xls)");
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const finalRows = parseExcelFile(evt.target.result);
        if (finalRows !== null) {
          setRows(finalRows);
          if (finalRows.length > 0) {
            toast.success(`${finalRows.length} row(s) loaded successfully`);
          }
        }
      } catch (error) {
        console.error("Error parsing Excel file:", error);
        toast.error("Failed to parse Excel file. Please check the format.");
      }
    };

    reader.onerror = () => {
      toast.error("Failed to read the file");
    };

    reader.readAsArrayBuffer(file);
  };

  // VALIDATION
  const validateRows = (data) =>
    data.map((row) => {
      const errors = [];
      if (!row.specialization.trim())
        errors.push("Specialization is required");
      if (row.specialization.length > 100)
        errors.push("Specialization cannot exceed 100 characters");

      return {
        ...row,
        errors,
        hasError: errors.length > 0,
      };
    });

  // CELL CHANGE
  const handleCellChange = (index, value) => {
    const updated = [...rows];
    updated[index].specialization = value;
    updated[index].isDuplicate = false;
    updated[index].errors = [];
    setRows(validateRows(updated));
    setDuplicateInfo(null);
  };

  // DELETE ROW
  const handleDeleteRow = (index) => {
    const updated = rows.filter((_, idx) => idx !== index);
    setRows(updated);
    setDuplicateInfo(null);
    toast.info("Row deleted");
  };

  // CLEAR ALL
  const handleClearAll = () => {
    setRows([]);
    setFileName("");
    setDuplicateInfo(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // DUPLICATE CHECK
  const checkDuplicates = async () => {
    if (rows.length === 0) {
      toast.error("No data to check. Please upload a file first.");
      return;
    }

    setIsChecking(true);
    setDuplicateInfo(null);

    try {
      const existingData = await getAllSpecializationCompetences();

      const existingCombinations = new Set();
      if (Array.isArray(existingData)) {
        existingData.forEach((item) => {
          const key = (item.specialization || "").toLowerCase();
          existingCombinations.add(key);
        });
      }

      const seenInFile = new Set();
      let duplicateCount = 0;

      const updated = rows.map((row) => {
        const key = row.specialization.toLowerCase();

        let isDuplicate = false;
        let duplicateReason = "";

        if (existingCombinations.has(key)) {
          isDuplicate = true;
          duplicateReason = "Already exists in database";
          duplicateCount++;
        }

        if (seenInFile.has(key) && !isDuplicate) {
          isDuplicate = true;
          duplicateReason = "Duplicate within file";
          duplicateCount++;
        }

        seenInFile.add(key);

        return {
          ...row,
          isDuplicate,
          duplicateReason,
        };
      });

      setRows(updated);

      if (duplicateCount > 0) {
        setDuplicateInfo({
          count: duplicateCount,
          message: `${duplicateCount} duplicate(s) found! These will be skipped during save.`,
          type: "warning",
        });
        toast.warning(`${duplicateCount} duplicate record(s) found!`);
      } else {
        setDuplicateInfo({
          count: 0,
          message: "No duplicates found. All records are unique.",
          type: "success",
        });
        toast.success("No duplicates found!");
      }
    } catch (error) {
      console.error("Error checking duplicates:", error);
      toast.error("Failed to check duplicates");
    } finally {
      setIsChecking(false);
    }
  };

  // SAVE
  const handleSave = async () => {
    const hasError = rows.some((r) => r.hasError);

    if (hasError) {
      toast.error("Please fix all errors before saving.");
      return;
    }

    if (rows.length === 0) {
      toast.error("No data to save. Please upload a file first.");
      return;
    }

    const rowsToSave = rows.filter((r) => !r.isDuplicate);

    if (rowsToSave.length === 0) {
      toast.error("All records are duplicates. Nothing to save.");
      return;
    }

    setIsSaving(true);

    try {
      const payload = rowsToSave.map((r) => ({
        specialization: r.specialization.trim(),
      }));

      const response = await bulkAddSpecializationCompetence(payload);

      if (response.status) {
        const insertedCount = response.data?.inserted || payload.length;
        const invalidCount = response.data?.invalid || 0;

        if (invalidCount > 0) {
          toast.success(
            `${insertedCount} record(s) added successfully! ${invalidCount} duplicate(s) were skipped.`,
            { autoClose: 5000 }
          );
        } else {
          toast.success(`${insertedCount} record(s) added successfully!`);
        }

        setTimeout(() => {
          navigate("/competencemanagement");
        }, 1500);
      } else {
        toast.error(response.message || "Failed to upload Specialization data");
      }
    } catch (error) {
      console.error("Bulk upload error:", error);
      toast.error(error.message || "Failed to upload Specialization data");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-4">

          {/* BACK */}
          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">
              Specialization Master Bulk Upload
            </h2>
          </div>

          <div className="hidden lg:block h-1 bg-darkblue1 w-[8%] ml-7 mb-2"></div>

          {/* Upload Section */}
          <div className="mb-4 flex flex-wrap items-center gap-2 w-full">
            {/* Drag & Drop Area */}
            <div
              className={`flex-1 min-w-[200px] max-w-md flex items-center border-2 border-dashed px-3 py-1.5 text-xs transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-black/30 bg-white hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="mr-2 flex-shrink-0"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>
              <span className="text-xs text-gray-700 truncate">
                {isDragActive
                  ? "Drop file here..."
                  : fileName || "Drag & drop or click Browse"}
              </span>
              <input
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleBulkUpload}
                id="bulk-upload-input"
                ref={fileInputRef}
              />
            </div>

            <label
              htmlFor="bulk-upload-input"
              className="px-3 py-1.5 bg-darkblue1 text-white text-xs cursor-pointer hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition"
            >
              Browse
            </label>

            {rows.length > 0 && (
              <>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 bg-gray-500 text-white text-xs hover:bg-gray-600 transition"
                >
                  Clear
                </button>

                <button
                  onClick={checkDuplicates}
                  disabled={isChecking || rows.length === 0}
                  className="px-3 py-1.5 bg-yellow-600 text-white text-xs hover:bg-yellow-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  {isChecking && (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  )}
                  {isChecking ? "Checking..." : "Check Duplicates"}
                </button>
              </>
            )}

            <button
              onClick={handleSave}
              disabled={isSaving || rows.length === 0 || rows.some((r) => r.hasError)}
              className="px-4 py-1.5 bg-darkblue1 text-white text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              {isSaving && (
                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
              )}
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>

          {/* Duplicate Info Banner */}
          {duplicateInfo && (
            <div
              className={`mb-2 p-2 border text-xs flex items-center justify-between ${
                duplicateInfo.type === "warning"
                  ? "bg-yellow-50 border-yellow-300 text-yellow-700"
                  : "bg-green-50 border-green-300 text-green-700"
              }`}
            >
              <span>
                <span className="font-medium">
                  {duplicateInfo.type === "warning" ? "⚠️ " : "✅ "}
                </span>
                {duplicateInfo.message}
              </span>
              <button
                onClick={() => setDuplicateInfo(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
          )}

          {/* Error Summary */}
          {rows.length > 0 && rows.some((r) => r.hasError) && (
            <div className="mb-2 p-2 bg-red-50 border border-red-200 text-red-600 text-xs">
              <span className="font-medium">
                ⚠️ {rows.filter((r) => r.hasError).length} row(s) have validation errors.
              </span>
              <span className="ml-2">Please fix all mandatory fields (highlighted in red).</span>
            </div>
          )}

          {/* TABLE */}
          {rows.length > 0 ? (
            <div className="overflow-auto bg-white border shadow">
              <table className="w-full text-xs">
                <thead className="bg-Dustyblue text-white">
                  <tr>
                    <th className="px-3 py-2 border border-grey2 border-t-0 border-l-0 text-left w-[5%]">#</th>
                    <th className="px-3 py-2 border border-grey2 border-t-0 border-l-0 text-left w-[50%]">Specialization <span className="text-red-300">*</span></th>
                    <th className="px-3 py-2 border border-grey2 border-t-0 border-l-0 text-center w-[20%]">Status</th>
                    <th className="px-3 py-2 border border-grey2 border-t-0 border-l-0 text-center w-[10%]">Action</th>
                  </tr>
                </thead>

                <tbody>
                  {rows.map((row, i) => (
                    <tr
                      key={i}
                      className={`text-xs hover:bg-lightBlue/50 ${
                        row.hasError ? "bg-red-50" : row.isDuplicate ? "bg-yellow-50" : ""
                      }`}
                    >
                      <td className="px-3 py-2 text-center border border-grey2 border-t-0 border-l-0 text-gray-500">
                        {i + 1}
                      </td>

                      <td className="px-3 py-2 border border-grey2 border-t-0 border-l-0">
                        <input
                          type="text"
                          className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                            row.hasError
                              ? "border-red-500 bg-red-50"
                              : row.isDuplicate
                              ? "border-yellow-500 bg-yellow-50"
                              : "border-gray-300"
                          }`}
                          value={row.specialization}
                          placeholder="Enter Specialization"
                          onChange={(e) => handleCellChange(i, e.target.value)}
                        />
                      </td>

                      <td className="px-3 py-2 text-center border border-grey2 border-t-0 border-l-0">
                        {row.hasError ? (
                          <span
                            className="px-2 py-0.5 bg-red-100 text-red-600 text-[10px] rounded-full cursor-help"
                            title={row.errors?.join(", ")}
                          >
                            Invalid
                          </span>
                        ) : row.isDuplicate ? (
                          <span
                            className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full cursor-help"
                            title={row.duplicateReason}
                          >
                            Duplicate
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 bg-green-100 text-green-600 text-[10px] rounded-full">
                            Valid
                          </span>
                        )}
                      </td>

                      <td className="px-3 py-2 text-center border border-grey2 border-t-0 border-l-0">
                        <button
                          onClick={() => handleDeleteRow(i)}
                          className="text-red-500 hover:text-red-700 transition"
                          title="Delete Row"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
                            <g clipPath="url(#clip0_6398_313)">
                              <path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
                            </g>
                            <defs>
                              <clipPath id="clip0_6398_313">
                                <rect width="24" height="24" fill="white" transform="translate(4 4)"/>
                              </clipPath>
                            </defs>
                          </svg>	
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            /* Empty State - WITH DRAG AND DROP */
            <div
              className={`bg-white shadow-md border-2 border-dashed p-8 text-center transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-Dustyblue hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="w-12 h-12 mx-auto mb-3 opacity-50"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>
              <p className="text-gray-500 text-sm">
                {isDragActive
                  ? "Drop your Excel file here!"
                  : "No data loaded. Please upload an Excel file to preview."}
              </p>
              <p className="text-gray-400 text-xs mt-1">
                {isDragActive
                  ? "Release to upload"
                  : "Supported formats: .xlsx, .xls (Drag & drop or click Browse)"}
              </p>
              <p className="text-gray-400 text-xs mt-1">Required column: Specialization</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SpecializationBulkUpload;