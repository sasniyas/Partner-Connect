"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";

function DepartmentMasterDownload() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]);

  // Listen for postMessage from parent window
 useEffect(() => {
  const handler = (event) => {
    console.log("📩 Received message:", event.data); // Debug line

    if (event.data?.type === "INIT_DATA") {
      setTableData(event.data.payload || []);
    }
  };

  window.addEventListener("message", handler);
  return () => window.removeEventListener("message", handler);
}, []);


  const handleDownloadExcel = () => {
    if (!tableData || tableData.length === 0) return;

    const excelData = tableData.map((item, index) => ({
      "Sl. No": String(index + 1),
      "Department Name": item.name,
      "Created By": item.createdBy,
      "Created Date": item.createdOn,
      "Status": item.isActive === 1 ? "Active" : "Inactive"
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);

    // Apply left alignment style explicitly
    Object.keys(worksheet).forEach((cell) => {
      if (cell.startsWith("A")) {
        worksheet[cell].s = { alignment: { horizontal: "left" } };
      }
    });

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Department Master");
    const currentDate = new Date().toISOString().split("T")[0];
    XLSX.writeFile(workbook, `Department_Master_${currentDate}.xlsx`);
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-4 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">
            Department Master
          </h2>
          <button
            className="bg-darkblue1 text-white text-sm font-medium px-4 py-1.5  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadExcel}
          >
            Download 
          </button>
        </div>

        <div className="bg-white shadow-md border border-Dustyblue overflow-x-auto">
          <table className="w-full min-w-[600px] text-sm text-left whitespace-nowrap">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4  py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%]">Sl. No</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">Department Name</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">Created By</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%]">Created Date</th>
                <th className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[10%]">Status</th>
              </tr>
            </thead>
            <tbody>
              {tableData.length > 0 ? (
                tableData.map((item, index) => (
                  <tr 
                    key={index} 
                    className={` hover:bg-lightBlue/50 text-xs }`}
                  >
                    <td className="px-4  py-1  border border-grey2 border-t-0 border-l-0  border border-grey2 border-t-0 border-l-0">{index + 1}</td>
                    <td className="px-6 py-1   border border-grey2 border-t-0 border-l-0font-normal text-steelBlue1">
                      {item.name}
                    </td>
                    <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 font-normal">{item.createdBy}</td>
                    <td className="px-6 py-1  border border-grey2 border-t-0 border-l-0 font-normal">{item.createdOn}</td>
                    <td className="px-6 py-1  border border-grey2 border-t-0 border-l-0 border-r-0 font-normal">
                    
                     
                    
                        {item.isActive === 1 ? "Active" : "Inactive"}
                   
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default DepartmentMasterDownload;