"use client"

import { useState, useEffect, useRef, useCallback, useMemo } from "react"
import Searchinput from "../../../Components/Searchinput"
import { Plus, Download } from "lucide-react"
import DeleteModal from "../../../Components/DeleteModal"
import ActivateStatus from "../../../Components/ActivateStatus"
import DeactivateStatus from "../../../Components/DeactivateStatus"
import { formatDateOnly } from "../../../util/timeFormat"
import ExcelJS from "exceljs";
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import {ChevronsUpDown} from "lucide-react"
import useCRUDWithReset from "../../../util/useCRUDWithReset"
import {
  addFile,
  getAllFiles,
  updateFile,
  toggleFile,
  deleteFile,
} from "../../../services/monthlyMeetingMaster/fileMaster.service"
import { filesname } from "../../../util/Validator"
import { uploadTempFile } from "../../../services/download/bluckDownload.service"
import { ChevronUp } from "lucide-react"
import { ChevronDown } from "lucide-react";
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation"

const MasterMonthlymeeting = () => {
  // ========== UI STATES ==========
  const [selectedRow, setSelectedRow] = useState(null)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [showPopup, setShowPopup] = useState(false)
  const [editPopup, setEditPopup] = useState(false)
  const [fileName, setFileName] = useState("")
  const [selectedFile, setSelectedFile] = useState(null)
  const [existingFileName, setExistingFileName] = useState("")
  const [existingFileUrl, setExistingFileUrl] = useState("")
  const [editingIndex, setEditingIndex] = useState(null)
  const [uploadBy, setUploadBy] = useState("")
  const [uploadDate, setUploadDate] = useState("")
  const [errors, setErrors] = useState({})
  const [isLoading, setIsLoading] = useState(false)
   const [showScrollButtons, setShowScrollButtons] = useState(false);
    const [scrollPosition, setScrollPosition] = useState(0);
    const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
    const [lastScrollTop, setLastScrollTop] = useState(0);
    const tableContainerRef = useRef(null);
    const popupRef=useRef(null)
  // ========== TABLE DATA STATES ==========
  const [files, setFiles] = useState([])

  // ========== STATUS MODALS ==========
  const [showDeactivateModal, setShowDeactivateModal] = useState(false)
  const [showActivateModal, setShowActivateModal] = useState(false)
  const [loadingToggle, setLoadingToggle] = useState(false)

  // ========== SORT STATES ==========
  const [sortKey, setSortKey] = useState(null);
  const [sortOrder, setSortOrder] = useState(null);
  const [hoveredCell, setHoveredCell] = useState(null);
 // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };

  

  // ========== SORT HANDLER ==========
  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc");
        return;
      }
      if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
        return;
      }
    }
    setSortKey(key);
    setSortOrder("asc");
  };

  // ========== FETCH FILES ON MOUNT ==========
  const fetchFiles = async () => {
    setIsLoading(true);
    try {
      const data = await getAllFiles()
      // console.log(data)
      setFiles(data || [])
    } catch (err) {
      // console.error("Failed to fetch files:", err.message)
    }
    setIsLoading(false);
  }

  useEffect(() => {
    fetchFiles()
  }, [])

  // ========== FILTER DATA (NO LAZY LOADING) ==========
  const filteredFiles = useMemo(() => {
    return files.filter(
      (file) =>
        file.fileName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        file.fileUrl?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [files, searchTerm]);

  // ========== SORTED DATA ==========
  const sortedFiles = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredFiles;

    return [...filteredFiles].sort((a, b) => {
      let aVal = a[sortKey];
      let bVal = b[sortKey];

      // If sorting by date, compare as Date objects
      if (sortKey === "createdOn") {
        aVal = aVal ? new Date(aVal) : new Date(0);
        bVal = bVal ? new Date(bVal) : new Date(0);
      } else {
        aVal = (aVal ?? "").toString().toLowerCase();
        bVal = (bVal ?? "").toString().toLowerCase();
      }

      return sortOrder === "asc"
        ? aVal > bVal ? 1 : aVal < bVal ? -1 : 0
        : aVal < bVal ? 1 : aVal > bVal ? -1 : 0;
    });
  }, [filteredFiles, sortKey, sortOrder]);
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchTerm: { setter:setSearchTerm, resetValue: "" },
  }
);

  // ========== PREVIEW & DOWNLOAD (✅ USES SORTEDFILES) ==========
  const handlePreviewAndDownload = async () => {
    if (!sortedFiles || sortedFiles.length === 0) {
      // alert("No data available to generate preview");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("File Master");

      // ================== HEADERS ==================
      sheet.columns = [
        { header: "Sl. No", key: "slNo", width: 10 },
        { header: "File Name", key: "fileName", width: 40 },
        { header: "File", key: "fileUrl", width: 120 },
        { header: "Uploaded By", key: "uploadBy", width: 25 },
        { header: "Upload Date", key: "uploadDate", width: 20 },
      ];

      // ================== HEADER STYLE ==================
      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF476896" } };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      // ================== DATA ROWS (✅ USE sortedFiles) ==================
      sortedFiles.forEach((item, index) => {
        const row = sheet.addRow({
          slNo: index + 1,
          fileName: item.fileName || "",
          fileUrl: item.fileUrl || "",
          uploadBy: item.uploadedUser || "",
          uploadDate: item.createdOn ? formatDateOnly(item.createdOn) : "",
        });
        row.eachCell((cell) => {
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });
      });

      // ================== CREATE FILE ==================
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const file = new File([blob], "File_Master.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      // ✅ Upload to temp storage for preview in Office Online
      const response = await uploadTempFile(file);
      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        // console.warn("Upload succeeded but no file URL returned");
        // alert("Upload succeeded but no preview available.");
      }
    } catch (error) {
      // console.error("Preview generation failed:", error);
      // alert("Failed to generate preview. Check console for details.");
    }
  };

  // ========== HANDLE FILE UPLOAD ==========
  const handleDragOver = (e) => {
  e.preventDefault();
  e.stopPropagation();
};

const handleDrop = (e) => {
  e.preventDefault();
  e.stopPropagation();

  const file = e.dataTransfer.files?.[0];
  if (file) {
    handleFileUpload({ target: { files: [file] } }); 
    // reuse your existing upload function
  }
};
 const handleFileUpload = (e) => {
  const file = e.target.files[0];
  if (file) {
    setSelectedFile(file);   // store full file object
    setErrors((prev) => ({ ...prev, selectedFile: "" }));
  }
};
  // ========== HANDLE EDIT ==========
  const handleEdit = (item) => {
    const originalIndex = item.id
    setEditingIndex(originalIndex)
    setFileName(item.fileName)
    setExistingFileName(item.fileUrl.split("/").pop())
    setExistingFileUrl(item.fileUrl || "")
    setEditPopup(true)
  }

  // ========== HANDLE ADD ==========
  const handleSubmit = async () => {
    let newErrors = {};

    // Validate file name
    const fileNameError = filesname(fileName);
    if (fileNameError) newErrors.fileName = fileNameError;

    // Validate file selection
    if (!selectedFile) newErrors.selectedFile = "Please select a file to upload";

    // Check for duplicates
    const isDuplicate = files.some(
      (item) => item.fileName.toLowerCase() === fileName.trim().toLowerCase()
    );

    if (isDuplicate) {
      newErrors.fileName = "File name already exists";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});

    try {
      await addFile({ fileName }, selectedFile)
      resetSortAndFilter ()
      await fetchFiles()
      resetPopupState()
    } catch (err) {
      // alert(err.message)
    }
  }

  // ========== HANDLE EDIT SUBMIT ==========
  const handleEditSubmit = async () => {
    let newErrors = {};

    // Validate file name
    const fileNameError = filesname(fileName);
    if (fileNameError) newErrors.fileName = fileNameError;

    // Check for duplicates
    const isDuplicate = files.some(
      (item) =>
        item.fileName.toLowerCase() === fileName.trim().toLowerCase() &&
        item.id !== editingIndex
    );

    if (isDuplicate) {
      newErrors.fileName = "File name already exists";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      const fileData = {
        id: editingIndex,
        fileName,
        fileUrl: existingFileUrl  // preserve existing URL if no new file uploaded
      }
      await updateFile(fileData, selectedFile)
      await fetchFiles()
      resetPopupState()
    } catch (err) {
      setErrors((prev) => ({ ...prev, submit: err.message || "Failed to update file. Please try again." }));
    }
  }

  // ========== HANDLE TOGGLE STATUS ==========
  const handleToggleStatus = async () => {
    if (selectedRow === null) return
    setLoadingToggle(true)
    try {
      await toggleFile(selectedRow)
      await fetchFiles()
    } catch (err) {
      // alert(err.message)
    }
    setShowDeactivateModal(false)
    setShowActivateModal(false)
    setSelectedRow(null)
    setLoadingToggle(false)
  }

  // ========== HANDLE DELETE ==========
  const handleDelete = async () => {
    try {
      await deleteFile(selectedRow)
      resetSortAndFilter ()
      await fetchFiles()
      setIsDeleteModalOpen(false)
      setSelectedRow(null)
    } catch (err) {
      // alert(err.message)
    }
  }

  // ========== RESET POPUP STATE ==========
  const resetPopupState = () => {
    setShowPopup(false)
    setEditPopup(false)
    setFileName("")
    setSelectedFile(null)
    setExistingFileName("")
    setExistingFileUrl("")
    setEditingIndex(null)
    setUploadBy("")
    setUploadDate("")
    setErrors({})
  }
useKeyboardNavigation({
  containerRef: popupRef, // your popup div ref

  onSubmit: () => { 
    if (editPopup) {
      handleEditSubmit();
    } else {
       handleSubmit();
    }
  },

  onCancel: () => {
    resetPopupState(); // closes popup and resets state
  },
});
  return (
    <div className="w-full mt-2 flex justify-center">
      <div className="w-full">

        {/* Search and Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2">
          <div className="">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="w-[1/2]"
              iconColor="text-black"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-1.5"
              iconSize="w-3 h-3"
              iconLeft="left-3 top-4"
              inputWidth="w-full"
              focusRing="focus:ring-1 focus:ring-black/60"
              hoverInputClasses="hover:bg-white"
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <button
              onClick={() => setShowPopup(true)}
              className="bg-slate-700 hover:bg-slate-800 text-white px-4 py-1.5 flex items-center justify-center gap-2 font-medium text-xs w-full"
            >
              <Plus className="w-3 h-3" />
              Add New
            </button>

            <button
              onClick={handlePreviewAndDownload}
              className="border border-gray-300 hover:bg-gray-300 text-gray-700 px-4 py-1.5 flex items-center justify-center gap-1 font-medium text-xs w-full"
            >
              <Download className="w-3 h-3" />
              Download
            </button>
          </div>
        </div>

        {/* ✅ TABLE WITH DYNAMIC HEIGHT (auto ≤8 rows, scroll >8 rows) */}
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
          <div
          ref ={tableContainerRef}
            className="overflow-y-auto relative"
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
              maxHeight: sortedFiles.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >
            <style jsx>{`
              div::-webkit-scrollbar {
                display: none;
              }
            `}</style>

            <table className="w-full text-sm">
              <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                <tr>
                  <th
                    className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[20%] cursor-pointer select-none"
                    onClick={() => handleSort("fileName")}
                  >
                    <div className="flex items-center gap-1">
                      File Name
                        {sortKey !== "fileName" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
                      {sortKey === "fileName" && sortOrder === "asc" && (
                        <ChevronUp className="w-3 h-3 text-white" />
                      )}
                      {sortKey === "fileName" && sortOrder === "desc" && (
                        <ChevronDown className="w-3 h-3 text-white" />
                      )}
                    </div>
                  </th>

                  <th
                    className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[40%] cursor-pointer select-none"
                    onClick={() => handleSort("fileUrl")}
                  >
                    <div className="flex items-center gap-1">
                      File
                    



                      {sortKey === "fileUrl" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "fileUrl" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>

                  <th
                    className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
                    onClick={() => handleSort("uploadedUser")}
                  >
                    <div className="flex items-center gap-1">
                      Upload By
                      {sortKey === "uploadedUser" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "uploadedUser" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>

                  <th
                    className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
                    onClick={() => handleSort("createdOn")}
                  >
                    <div className="flex items-center gap-1">
                      Upload Date
                      {sortKey === "createdOn" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "createdOn" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>

                  <th className="py-1.5 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[10%]">
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {/* Initial Loading */}
                {isLoading && sortedFiles.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        Loading...
                      </div>
                    </td>
                  </tr>
                )}

                {/* Table Rows */}
                {!isLoading && sortedFiles.length > 0
                  ? sortedFiles.map((item, index) => (
                    <tr
                      key={`${item.name}-${item.uploadDate}-${index}`}
                      className={`hover:bg-lightBlue/50 text-xs ${item.isActive ? "text-black" : "text-gray-400"}`}
                    >
                      <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                        <div className="relative">
                          <p
                            className="truncate max-w-[20rem] cursor-pointer"
                            onMouseEnter={() => {
                              if (item.fileName?.length > 20) setHoveredCell(item.id + "-fileName");
                            }}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {item.fileName}
                          </p>

                          {hoveredCell === item.id + "-fileName" && (
                            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                              {item.fileName}
                            </span>
                          )}
                        </div>
                      </td>

                      <td
                        className="px-6 py-1 underline text-SteelBlue1 border border-grey2 border-t-0 border-l-0 cursor-pointer text-xs"
                        onClick={() => {
                          if (item.fileUrl) window.open(item.fileUrl, "_blank");
                        }}
                      >
                        <div className="relative">
                          <p
                            className="truncate max-w-[50rem] cursor-pointer"
                            onMouseEnter={() => {
                              const name = item.fileUrl?.split("/").pop() || "";
                              if (name.length > 50) setHoveredCell(item.id + "-fileUrl");
                            }}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {item.fileUrl
                              ? (() => {
                                const fileName = item.fileUrl.substring(item.fileUrl.lastIndexOf("/") + 1);
                                return fileName.length > 50
                                  ? `${fileName.substring(0, 50)}...`
                                  : fileName;
                              })()
                              : "No file"}
                          </p>

                          {hoveredCell === item.id + "-fileUrl" && (
                            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                              {item.fileUrl?.split("/").pop()}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                        <div className="relative">
                          <p
                            className="truncate max-w-[15rem] cursor-pointer"
                            onMouseEnter={() => {
                              if (item.uploadedUser?.length > 15) setHoveredCell(item.id + "-uploadedUser");
                            }}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {item.uploadedUser}
                          </p>

                          {hoveredCell === item.id + "-uploadedUser" && (
                            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                              {item.uploadedUser}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="px-6 py-1 font-normal border border-grey2 border-t-0 border-l-0">
                        {formatDateOnly(item.createdOn)}
                      </td>

                      <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                        <div className="flex items-center justify-center gap-2">
                          {/* Edit */}
                          <div className="relative group">
                            <button
                              onClick={() => handleEdit(item)}
                              className="flex items-center justify-center w-6 h-6 text-green-600 hover:text-green-800 transition-colors"
                            >
                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>

                            </button>
                            <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              Edit
                            </span>
                          </div>

                          {/* Delete */}
                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedRow(item.id);
                                setIsDeleteModalOpen(true);
                              }}
                              className="flex items-center justify-center w-6 h-6 text-red-600 hover:text-red-800 transition-colors"
                            >
                             <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>


                            </button>
                            <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              Delete
                            </span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))
                  : !isLoading && (
                    <tr>
                      <td colSpan={5} className="px-6 py-8 text-center text-gray-500 italic">
                        No data available
                      </td>
                    </tr>
                  )}
              </tbody>
            </table>
            
          </div>
           {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Add/Edit Popup */}
        {(showPopup || editPopup) && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4">
            <div 
            ref={popupRef}
            className="bg-white shadow-lg p-6 w-full max-w-md mx-4 relative max-h-[90vh] overflow-y-auto">

              <button
                onClick={resetPopupState}
                className="absolute top-4 right-4 text-gray-700 transition p-1 hover:scale-105 duration-200"
              >
 <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>


              </button>

              <div className="text-center pr-8">
                <h3 className="text-gray-600 text-base font-medium">
                  {editPopup ? "File Master" : "Add File Master"}
                </h3>
              </div>

              <div className="mb-2">
                <label className="block text-xs font-medium text-gray-700 sm:mb-3">
                  File Name  <span className=" text-red1">*</span>
                </label>
                <input
                  type="text"
                  value={fileName}
                  maxLength={50}
                  tableIndex={0}
                  onChange={(e) => {
                    const value = e.target.value;
                    setFileName(value);

                    // Validate the file name on every change
                    const err = filesname(value);
                    setErrors({ ...errors, fileName: err });
                  }}
                  placeholder="Enter File Name"
                  className={`w-full px-4 py-1.5 text-xs border focus:outline-none focus:ring-1 ${errors.fileName ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                />
                {errors.fileName && (
                  <p className="text-xs text-red1 mt-1">{errors.fileName}</p>
                )}
              </div>

              <div className="mb-4">
                <label className="block text-xs font-medium text-gray-700 sm:mb-3">
                  {editPopup ? "File " : "Upload File"}<span className=" text-red1">*</span>
                </label>

                <div 
  className="relative"
  onDragOver={handleDragOver}
  onDrop={handleDrop}
    tabIndex={0}
>
                  <input
                    type="file"
                    id="fileUpload"
                    className="hidden"
                
                    onChange={handleFileUpload}
                    accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.png,.jpg,.jpeg"
                  />
                  
                  <label
                    htmlFor="fileUpload"
                    className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 focus:ring-black/30 transition-all flex items-center ${errors.selectedFile ? "border-red1 focus:ring-red1" : "border-black/30 focus:ring-black/30"}`}
                  >
                    <span className="text-gray-600 flex-1 truncate">
                      {editPopup
                        ? (selectedFile ? selectedFile.name : existingFileName)
                        : (selectedFile ? selectedFile.name : "Upload File")
                      }
                    </span>
                  </label>
                  <div className="absolute right-3 sm:right-4 top-1/2 transform -translate-y-1/2 pointer-events-none">
                    <svg className="w-3 h-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 10v6m0 0l-3-3m3 3l3-3M3 17V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                </div>
                {errors.selectedFile && (
                  <p className="text-xs text-red1 mt-1">{errors.selectedFile}</p>
                )}
              </div>

              {errors.submit && (
                <p className="text-xs text-red1 text-center mb-2">{errors.submit}</p>
              )}
              <div className="flex items-center justify-center">
                <button
                 type="submit" 
                  onClick={editPopup ? handleEditSubmit : handleSubmit}
                  className="bg-darkblue1 text-white text-xs font-medium px-8  py-1.5 hover:bg-white hover:border hover:border hover:border-darkblue1 hover:text-darkblue1 transition duration-200 w-full sm:w-auto"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Delete Modal */}
        {isDeleteModalOpen && selectedRow !== null && (
          <DeleteModal
            isOpen={isDeleteModalOpen}
            onClose={() => {
              setIsDeleteModalOpen(false)
              setSelectedRow(null)
            }}
            onConfirm={handleDelete}
          />
        )}

        {/* Deactivate Modal */}
        <DeactivateStatus
          isOpen={showDeactivateModal}
          loading={loadingToggle}
          onClose={() => {
            if (!loadingToggle) {
              setShowDeactivateModal(false)
              setSelectedRow(null)
            }
          }}
          onConfirm={handleToggleStatus}
        />

        {/* Activate Modal */}
        <ActivateStatus
          isOpen={showActivateModal}
          loading={loadingToggle}
          onClose={() => {
            if (!loadingToggle) {
              setShowActivateModal(false)
              setSelectedRow(null)
            }
          }}
          onConfirm={handleToggleStatus}
        />
      </div>
    </div>
  )
}

export default MasterMonthlymeeting;