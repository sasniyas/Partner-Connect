"use client";
import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import Header from "../../../Components/Header";
import { Download } from "lucide-react";
import { formatDateOnly } from "../../../util/timeFormat";

function Downloadfilemaster() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tableData, setTableData] = useState([]); // ⬅️ now controlled by postMessage

  // ✅ Listen for postMessage from parent window
  useEffect(() => {
    const handler = (event) => {
      if (event.data?.type === "INIT_DATA") {
        setTableData(event.data.payload || []);
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  const handleDownloadExcel = () => {
  if (!tableData || tableData.length === 0) return;

  const excelData = tableData.map((item, index) => ({
  "Sl. No": String(index + 1),
  "File Name": item.fileName,
  "File":item.fileUrl,
  "Upload By":item.uploadedUser,
  "Upload Date":item.createdOn,
 "Status": item.isActive === 1 ? "Active" : "Inactive",   // ✅ use lowercase
}));


  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // 👇 Apply left alignment style explicitly
  Object.keys(worksheet).forEach((cell) => {
    if (cell.startsWith("A")) {
      worksheet[cell].s = { alignment: { horizontal: "left" } };
    }
  });

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "City Master");
  XLSX.writeFile(workbook, "City_Master.xlsx");
};


  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col ">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""} p-4`}>
        <div className="mt-10 mb-4 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-darkblue1">File Master</h2>
          <button
            className="bg-darkblue1 text-white text-sm font-medium px-4 py-1.5  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
            onClick={handleDownloadExcel}
          >
            Download 
          </button>
        </div>

        <div className="bg-white shadow-md  border border-Dustyblue  overflow-x-auto">
          <table className="w-full text-sm text-left whitespace-nowrap">
            <thead className="bg-Dustyblue text-white">
              <tr>
                <th className="px-4  text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium ">Sl. No</th>
               <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium ">File Name</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium ">File</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium ">Upload By</th>
                <th className="px-4 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium">Upload Date</th>
               <th className="px-4 py-1 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium ">Status</th>

              </tr>
            </thead>
            <tbody>
              {tableData.length > 0 ? (
                tableData.map((item, index) => (
                  <tr key={index} className=" hover:bg-lightBlue/50 text-xs">
                                        <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0">{index+1}</td>

                    <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0">{item.fileName}</td>
<td
  className="px-4 py-1 border border-grey2 border-t-0 border-l-0 
             max-w-[250px] truncate whitespace-nowrap overflow-hidden"
  title={item.fileUrl}
>
  {item.fileUrl}
</td>

                                        <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0">{item.uploadedUser}</td>

                                       <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0">{formatDateOnly(item.createdOn)}</td>
                   

                                        <td className="px-4 py-1  border border-grey2 border-t-0 border-l-0 border-r-0">{item.isActive === 1 ? "Active" : "Inactive"}</td>

                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-gray-500 italic">
                    No data found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Downloadfilemaster;