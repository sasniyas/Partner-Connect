"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import Searchinput from "../../../Components/Searchinput"
import { Plus, Download } from "lucide-react"
import * as XLSX from "xlsx"
import DeleteModal from "../../../Components/DeleteModal"
import DeactivateStatus from "../../../Components/DeactivateStatus"
import ActivateStatus from "../../../Components/ActivateStatus"
import Filter from "../../../Components/Filter"
import {ChevronsUpDown} from "lucide-react"
import { useRef } from "react"
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import useCRUDWithReset from "../../../util/useCRUDWithReset"
import {
  addDepartment,
  getDepartments,
  updateDepartment,
  deleteDepartment,
  toggleDepartment,
} from "../../../services/monthlyMeetingMaster/departmentMaster.service"
import { formatDateOnly, formatedTime } from "../../../util/timeFormat"
import ExcelJS from "exceljs"
import { uploadTempFile } from "../../../services/download/bluckDownload.service"
import { ChevronUp, ChevronDown } from "lucide-react"
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation"

const DepartmentMaster = () => {
  // ========== UI STATES ==========
  const [selectedRow, setSelectedRow] = useState(null)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [showPopup, setShowPopup] = useState(false)
  const [editPopup, setEditPopup] = useState(false)
  const [deptName, setDeptName] = useState("")
  const [editingIndex, setEditingIndex] = useState(null)
  const [errors, setErrors] = useState({})
  const [hoveredCell, setHoveredCell] = useState(null)
  const [selectedStatus, setSelectedStatus] = useState([])
  const [isLoadingdata, setIsLoadingdata] = useState(false)
  const popupRef =useRef(null)
  // ========== TABLE DATA STATES ==========
  const [departments, setDepartments] = useState([])

  // ========== STATUS MODALS ==========
  const [showDeactivateModal, setShowDeactivateModal] = useState(false)
  const [showActivateModal, setShowActivateModal] = useState(false)
  const [loadingToggle, setLoadingToggle] = useState(false)

  // ========== SORT STATES ==========
  const [sortKey, setSortKey] = useState(null)
  const [sortOrder, setSortOrder] = useState(null)

  // ========== OPTIONS ==========
  const statusOptions = ["Active", "Inactive"]
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  // ========== SORT HANDLER ==========
  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        setSortOrder("desc");
        return;
      }
      if (sortOrder === "desc") {
        setSortKey(null);
        setSortOrder(null);
        return;
      }
    }
    setSortKey(key);
    setSortOrder("asc");
  };

  // ========== FETCH DEPARTMENTS ON MOUNT ==========
  const fetchDepartments = async () => {
    try {
      setIsLoadingdata(true);
      const data = await getDepartments();
      setDepartments(data || []);
    } catch (error) {
      // console.error("Error fetching departments:", error);
      // alert("Failed to load departments.");
    } finally {
      setIsLoadingdata(false);
    }
  };

  useEffect(() => {
    fetchDepartments();
  }, []);

  // ========== FILTERED DATA (NO LAZY LOADING) ==========
  const filteredData = useMemo(() => {
    return departments.filter((item) => {
      const matchesSearch = item.name
        ?.toLowerCase()
        .includes(searchTerm.trim().toLowerCase());

      const matchesStatus =
        selectedStatus.length > 0
          ? selectedStatus.includes(item.isActive ? "Active" : "Inactive")
          : true;

      return matchesSearch && matchesStatus;
    });
  }, [departments, searchTerm, selectedStatus]);

  // ========== SORTED DATA ==========
  const SortedData = useMemo(() => {
    if (!sortKey || !sortOrder) return filteredData;

    return [...filteredData].sort((a, b) => {
      let aVal = a[sortKey];
      let bVal = b[sortKey];

      // If sorting by created date
      if (sortKey === "createdOn") {
        aVal = new Date(aVal);
        bVal = new Date(bVal);
      } else {
        aVal = (aVal ?? "").toString().toLowerCase();
        bVal = (bVal ?? "").toString().toLowerCase();
      }

      if (aVal < bVal) return sortOrder === "asc" ? -1 : 1;
      if (aVal > bVal) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [filteredData, sortKey, sortOrder]);
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchTerm: { setter: setSearchTerm, resetValue: "" },
    selectedStatus: { setter: setSelectedStatus, resetValue: [] }
  }
);

  // ========== PREVIEW & DOWNLOAD (✅ USES SORTEDDATA) ==========
  const handlePreviewAndDownload = async () => {
    if (!SortedData || SortedData.length === 0) {
      // alert("No data available to generate preview");
      return;
    }

    try {
      const workbook = new ExcelJS.Workbook();
      const sheet = workbook.addWorksheet("Department Master");

      // ================== HEADERS ==================
      sheet.columns = [
        { header: "S.No", key: "slNo", width: 10 },
        { header: "Department Name", key: "deptName", width: 30 },
        { header: "Created By", key: "createdBy", width: 25 },
        { header: "Created Date", key: "createdDate", width: 20 },
        { header: "Status", key: "status", width: 15 },
      ];

      // ================== HEADER STYLE ==================
      sheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: false, color: { argb: "FFFFFFFF" } };
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF476896" } };
        cell.alignment = { vertical: "middle", horizontal: "left" };
      });

      // ================== DATA ROWS (✅ USE SortedData) ==================
      SortedData.forEach((item, index) => {
        const row = sheet.addRow({
          slNo: index + 1,
          deptName: item.name || "",
          createdBy: item.createdBy || "",
          createdDate: item.createdOn ? formatDateOnly(item.createdOn) : "",
          status: item.isActive ? "Active" : "Inactive",
        });

        row.eachCell((cell) => {
          cell.alignment = { vertical: "middle", horizontal: "left" };
        });
      });

      // ================== CREATE EXCEL FILE ==================
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const file = new File([blob], "Department_Master.xlsx", {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      // ✅ Upload to temporary storage for Office Online preview
      const response = await uploadTempFile(file);
      const fileUrl = response
        ? `https://view.officeapps.live.com/op/view.aspx?src=${response}`
        : null;

      if (fileUrl) {
        window.open(fileUrl, "_blank", "noopener,noreferrer");
      } else {
        // console.warn("Upload succeeded but no file URL returned");
        // alert("Upload succeeded but no preview available.");
      }
    } catch (error) {
      // console.error("Preview generation failed:", error);
      // alert("Failed to generate preview. Check console for details.");
    }
  };

  // ========== HANDLE ADD DEPARTMENT ==========
  const handleSubmit = async () => {
    let newErrors = {};

    // Validate department name
   

    // Check for duplicates
    const isDuplicate = departments.some(
      (item) => item.name.toLowerCase() === deptName.trim().toLowerCase()
    );

    if (isDuplicate) {
      newErrors.deptName = "Department name already exists";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});

    try {
      await addDepartment(deptName.trim())
      resetSortAndFilter()
      fetchDepartments()
      resetPopupState()
    } catch (error) {
      // alert(error.message)
    }
  }

  // ========== HANDLE EDIT DEPARTMENT ==========
  const handleEditSubmit = async () => {
    let newErrors = {};


    // Check for duplicates (excluding current item)
    const isDuplicate = departments.some(
      (item) =>
        item.name.toLowerCase() === deptName.trim().toLowerCase() &&
        item.id !== editingIndex
    );

    if (isDuplicate) {
      newErrors.deptName = "Department name already exists";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});

    if (editingIndex !== null) {
      try {
        await updateDepartment({
          id: editingIndex,
          departmentName: deptName.trim(),
        })
        fetchDepartments()
        resetPopupState()
      } catch (error) {
        setErrors((prev) => ({ ...prev, submit: error.message || "Failed to update department. Please try again." }));
      }
    }
  }

  // ========== HANDLE EDIT ==========
  const handleEdit = (item) => {
    setEditingIndex(item.id)
    setDeptName(item.name)
    setEditPopup(true)
  }

  // ========== HANDLE TOGGLE STATUS ==========
  const handleToggleStatus = async () => {
    if (!selectedRow) return
    setLoadingToggle(true)
    try {
      await toggleDepartment(selectedRow)
      await fetchDepartments()
    } catch (err) {
      // console.error("Toggle Error:", err)
      // alert(err.message || "Failed to change status.")
    } finally {
      setShowDeactivateModal(false)
      setShowActivateModal(false)
      setSelectedRow(null)
      setLoadingToggle(false)
    }
  }

  // ========== HANDLE DELETE ==========
  const handleDelete = async () => {
    if (!selectedRow) return
    try {
      await deleteDepartment(selectedRow)
      resetSortAndFilter()
      fetchDepartments()
      setIsDeleteModalOpen(false)
      setSelectedRow(null)
    } catch (error) {
      // alert(error.message)
    }
  }

  // ========== RESET POPUP STATE ==========
  const resetPopupState = () => {
    setShowPopup(false)
    setEditPopup(false)
    setDeptName("")
    setEditingIndex(null)
    setErrors({})
  }
useKeyboardNavigation({
  containerRef: popupRef, // your popup div ref

  onSubmit: () => { 
    if (editPopup) {
      handleEditSubmit();
    } else {
      handleSubmit();
    }
  },

  onCancel: () => {
    resetPopupState (); // closes popup and resets state
  },
});
  return (
    <div className="w-full mt-2 flex justify-center">
      <div className="w-full">
        {/* Search + Filter + Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
          {/* SEARCH + STATUS GROUP */}
          <div className="flex flex-row items-center gap-2 w-full sm:w-auto">
            {/* Search input */}
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="flex-1 sm:flex-none"
              iconColor="text-black"
              bgColor="bg-FrostWhite"
              borderColor="border-black/60"
              textColor="text-black"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-1.5"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              inputWidth="w-full"
              focusRing="focus:ring-1 focus:ring-black/60"
              hoverInputClasses="hover:bg-white hover:border-black/60"
            />

            {/* Status filter */}
            <Filter
              name="status"
              placeholder="Status"
              options={statusOptions}
              value={selectedStatus}
              customWidth="w-[80px]"
              placeholderColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBgColor="bg-white"
              dropdownTextColor="text-black"
              dropdownHoverColor="hover:bg-lightBlue/50"
              dropdownBorderColor="border-black/60"
              closedBgColor="bg-white"
              hoverRingColor="ring-black"
              textColor="text-black"
              onChange={(name, value) => {
                setSelectedStatus(value);
              }}
            />
          </div>

          {/* BUTTON GROUP */}
          <div className="flex flex-row gap-3 justify-start sm:justify-end w-full sm:w-auto">
            <button
              onClick={() => setShowPopup(true)}
              className="bg-slate-700 hover:bg-slate-800 text-white px-4 py-1 text-xs flex items-center justify-center gap-2 font-medium"
            >
              <Plus className="w-3 h-3" />
              Add Department
            </button>

            <button
              onClick={handlePreviewAndDownload}
              className="border border-gray-300 hover:bg-gray-300 text-gray-700 px-4 py-1 text-xs flex items-center justify-center gap-2 font-medium"
            >
              <Download className="w-3 h-3" />
              Download
            </button>
          </div>
        </div>

        {/* ✅ TABLE WITH DYNAMIC HEIGHT (auto ≤8 rows, scroll >8 rows) */}
        <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
          <div
            className="overflow-y-auto relative"
            ref={tableContainerRef}
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
              maxHeight: SortedData.length > 8 ? "calc(100vh - 240px)" : "auto",
            }}
            onScroll={handleTableScroll}
          >
            <style jsx>{`
              div::-webkit-scrollbar {
                display: none;
              }
            `}</style>

            <table className="w-full text-xs border-collapse">
              <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                <tr>
                  <th
                    className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[30%] cursor-pointer select-none"
                    onClick={() => handleSort("name")}
                  >
                    <div className="flex items-center gap-1">
                      Department Name
                       {sortKey !== "name" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

                      {sortKey === "name" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "name" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>

                  <th
                    className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[30%] cursor-pointer select-none"
                    onClick={() => handleSort("createdBy")}
                  >
                    <div className="flex items-center gap-1">
                      Created By
                      {sortKey === "createdBy" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "createdBy" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>

                  <th
                    className="px-6 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[30%] cursor-pointer select-none"
                    onClick={() => handleSort("createdOn")}
                  >
                    <div className="flex items-center gap-1">
                      Created Date
                      {sortKey === "createdOn" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                      {sortKey === "createdOn" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                    </div>
                  </th>

                  <th className="text-center py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[10%]">
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {isLoadingdata && SortedData.length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                        Loading...
                      </div>
                    </td>
                  </tr>
                )}

                {!isLoadingdata && SortedData.length > 0
                  ? SortedData.map((item, index) => (
                    <tr
                      key={`${item.name}-${index}`}
                      className={`hover:bg-lightBlue/50 ${item.isActive ? "text-black" : "text-gray-400"}`}
                    >
                      <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                        <div className="relative">
                          <p
                            className="truncate max-w-[20rem] cursor-pointer"
                            onMouseEnter={() => {
                              if (item.name?.length > 20) setHoveredCell(item.id + "-name");
                            }}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {item.name}
                          </p>

                          {hoveredCell === item.id + "-name" && (
                            <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                              {item.name}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
                        <div className="relative">
                          <p
                            className="truncate max-w-[20rem] cursor-pointer"
                            onMouseEnter={() => {
                              if (item.createdBy?.length > 20) setHoveredCell(item.id + "-createdBy");
                            }}
                            onMouseLeave={() => setHoveredCell(null)}
                          >
                            {item.createdBy}
                          </p>

                          {hoveredCell === item.id + "-createdBy" && (
                            <span className="absolute left-1/2 top-full -mt-1 bg-black text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
                              {item.createdBy}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="px-6 py-1 border border-grey2 border-t-0 border-l-0">
                        {formatDateOnly(item.createdOn)}
                      </td>

                      <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0">
                        <div className="flex items-center justify-center gap-4">
                          {/* Edit */}
                          <div className="relative group">
                            <button
                              onClick={() => handleEdit(item)}
                              className="text-green-600 hover:text-green-800"
                            >
                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M18.988 2.01196L21.988 5.01196L19.701 7.29996L16.701 4.29996L18.988 2.01196ZM8 16H11L18.287 8.71296L15.287 5.71296L8 13V16Z" fill="#66B3A6"/>
<path d="M19 19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.896 3 5V19C3 20.104 3.897 21 5 21H19C19.5304 21 20.0391 20.7893 20.4142 20.4142C20.7893 20.0391 21 19.5304 21 19V10.332L19 12.332V19Z" fill="#66B3A6"/>
</svg>


                            </button>
                            <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              Edit
                            </span>
                          </div>

                          {/* Toggle Status */}
                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedRow(item.id)
                                if (item.isActive) {
                                  setShowDeactivateModal(true)
                                } else {
                                  setShowActivateModal(true)
                                }
                              }}
                            >
                                {item.isActive ? (
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 21 23" fill="none">
                                  <path d="M16.7457 5.97337C17.8213 7.04952 18.6066 8.38081 19.028 9.84281C19.4495 11.3048 19.4934 12.8498 19.1557 14.3334M4.54571 5.49337C3.59031 6.2958 2.81219 7.28811 2.26075 8.4073C1.70931 9.52649 1.39659 10.7481 1.34246 11.9946C1.28833 13.2411 1.49395 14.4852 1.94629 15.648C2.39863 16.8108 3.08779 17.8668 3.97002 18.7491C4.85226 19.6313 5.90829 20.3205 7.07107 20.7728C8.23386 21.2251 9.47799 21.4308 10.7245 21.3766C11.971 21.3225 13.1926 21.0098 14.3118 20.4583C15.431 19.9069 16.4233 19.1288 17.2257 18.1734M10.3857 1.33337V5.33337" stroke="#50A294" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                </svg>
                              ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                  <g clipPath="url(#clip0_5669_3080)">
                                    <path d="M18.36 6.64C19.4356 7.71615 20.2209 9.04743 20.6423 10.5094C21.0638 11.9714 21.1077 13.5164 20.77 15M6.16 6.16C5.2046 6.96243 4.42648 7.95474 3.87504 9.07393C3.3236 10.1931 3.01089 11.4147 2.95675 12.6612C2.90262 13.9077 3.10825 15.1519 3.56058 16.3146C4.01292 17.4774 4.70208 18.5335 5.58431 19.4157C6.46655 20.2979 7.52258 20.9871 8.68536 21.4394C9.84815 21.8918 11.0923 22.0974 12.3388 22.0432C13.5853 21.9891 14.8069 21.6764 15.9261 21.125C17.0453 20.5735 18.0376 19.7954 18.84 18.84M12 2V6M2 2L22 22" stroke="#BF2012" strokeWidth="2.66667" strokeLinecap="round" strokeLinejoin="round"/>
                                  </g>
                                  <defs>
                                    <clipPath id="clip0_5669_3080">
                                      <rect width="24" height="24" fill="white"/>
                                    </clipPath>
                                  </defs>
                                </svg>
                              )}
                            </button>
                            <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              {item.isActive ? "Deactivate" : "Activate"}
                            </span>
                          </div>

                          {/* Delete */}
                          <div className="relative group">
                            <button
                              onClick={() => {
                                setSelectedRow(item.id)
                                setIsDeleteModalOpen(true)
                              }}
                              className="text-red-600 hover:text-red-800"
                            >
                             <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>



                            </button>
                            <span className="absolute left-1/2 top-full -mt-1 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              Delete
                            </span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))
                  : !isLoadingdata && (
                    <tr>
                      <td colSpan={4} className="px-6 py-8 text-center text-gray-500 italic">
                        No data available
                      </td>
                    </tr>
                  )}
              </tbody>
            </table>
          </div>
          {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

        </div>

        {/* Add/Edit Popup */}
        {(showPopup || editPopup) && (
          <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50 p-4">
            <div
          
            className="bg-white shadow-lg p-6 w-full max-w-md relative">
              
              <button onClick={resetPopupState} className="absolute top-4 right-4">
               <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>



              </button>

              <h3 className="text-center text-gray-600 text-lg font-medium mb-6">
                {editPopup ? "Department" : "Add Department"}
              </h3>

              <div className="mb-4">
                <label className="block text-xs font-medium text-gray-700 mb-2">
                  Department Name <span className=" text-red1">*</span>
                </label>
                <input
                  type="text"
                  value={deptName}
                  maxLength={50}
                 onChange={(e) => {
  setDeptName(e.target.value);
}}
                  placeholder="Enter Department Name"
                  className={`border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 transition-all ${
                    errors.deptName
                      ? "border-red1 focus:ring-red1"
                      : "border-black/30 focus:ring-black/30"
                  }`}
                />
                {errors.deptName && (
                  <p className="text-xs text-red1 mt-1">{errors.deptName}</p>
                )}
              </div>

              {errors.submit && (
                <p className="text-xs text-red1 text-center mb-2">{errors.submit}</p>
              )}
              <div className="flex justify-center">
                <button
                  onClick={editPopup ? handleEditSubmit : handleSubmit}
                  className="bg-darkblue1 text-xs font-medium text-white px-8 py-1.5 hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Delete Modal */}
        {isDeleteModalOpen && selectedRow && (
          <DeleteModal 
            isOpen={isDeleteModalOpen} 
            onClose={() => setIsDeleteModalOpen(false)} 
            onConfirm={handleDelete} 
          />
        )}

        {/* Activate Modal */}
        {showActivateModal && selectedRow && (
          <ActivateStatus 
            isOpen={showActivateModal} 
            loading={loadingToggle}
            onClose={() => setShowActivateModal(false)} 
            onConfirm={handleToggleStatus} 
          />
        )}

        {/* Deactivate Modal */}
        {showDeactivateModal && selectedRow && (
          <DeactivateStatus 
            isOpen={showDeactivateModal} 
            loading={loadingToggle}
            onClose={() => setShowDeactivateModal(false)} 
            onConfirm={handleToggleStatus} 
          />
        )}
      </div>
    </div>
  )
}

export default DepartmentMaster;