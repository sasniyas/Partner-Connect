


import React, { useState } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import MasterMonthlymeeting from "../MonthlyMeeting/MasterMonthlymeeting";
import Department from "./Deapartment";
import DepartmentMaster from "./Deapartment";
// import DepartmentComponent from "../Department/DepartmentComponent"; // Uncomment when you create it

function MasterMonthlyMeetingHomepage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("fileMaster"); // Default active tab

  return (
    <div className="bg-Frostwhite h-screen overflow-y-hidden flex flex-col  ">
      {/* Header */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      {/* Main Content */}
      <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : ""}`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
           <div className="w-full flex justify-center  ">
          <div className="w-full">
            {/* Tabs */}<h2 className="text-center text-xl  font-semibold text-darkblue1 font-VolvoNovum mb-2 ">
          Monthly Meeting Master
        </h2>

         <div className="flex w-full mb-2 overflow-hidden ">
  <button
    onClick={() => setActiveTab("fileMaster")}
    className={`flex-1 py-2 text-xs font-medium transition
      ${
        activeTab === "fileMaster"
          ? "bg-Dustyblue text-white"
          : "bg-gray-200 text-gray-700 hover:bg-gray-300"
      }
    `}
  >
    File Master
  </button>

  <button
    onClick={() => setActiveTab("department")}
    className={`flex-1 py-2 text-xs font-medium transition
      ${
        activeTab === "department"
          ? "bg-Dustyblue text-white"
          : "bg-gray-200 text-gray-700 hover:bg-gray-300"
      }
    `}
  >
    Department Master
  </button>
</div>

            {/* Tab Content */}
          <div className="w-full transition-all duration-300 ease-in-out ">
              {activeTab === "fileMaster" && <MasterMonthlymeeting />}
              {activeTab === "department" &&<DepartmentMaster/>}
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  );
}

export default MasterMonthlyMeetingHomepage;
