"use client"

import { useState, useEffect, useRef, useMemo } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"
import { useNavigate } from "react-router-dom"
import AddUser from "./AddUser"
import SuccessMessage from "./SuccessMessage"
import ActivationEmail from "./ActivationEmail"
import DeleteModal from "../../../Components/DeleteModal"
import TemporaryDeactive from "./TemporaryDeactive"
import * as XLSX from "xlsx"
import ActivateStatus from "../../../Components/ActivateStatus"
import DeactivateStatus from "../../../Components/DeactivateStatus"
import axios from "axios"
import Filter from "../../../Components/Filter"
import Searchinput from "../../../Components/Searchinput"
import ShowHistoryUserdetails from "./ShowHistoryUsedetails"
import { API } from '../../../api';
import { userLogin } from '../../../services/login/multiplelogin.service'
import { useDispatch } from "react-redux";
import { fetchLoggedInUser } from "../../../store/userSlice";
import {ChevronsUpDown} from "lucide-react"
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { ArrowUp } from "lucide-react"
import { ArrowDown } from "lucide-react"
import useCRUDWithReset from "../../../util/useCRUDWithReset"

const UserManagement = () => {
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const dispatch = useDispatch();
  const [stats, setStats] = useState([])
  const [isLoadingdata, setIsLoadingdata] = useState(false)
  const [toggleLoading, setToggleLoading] = useState(false)
  const [hoveredName, setHoveredName] = useState(null)
  const [hoveredLogin, setHoveredLogin] = useState(null)
  const [expandedRow, setExpandedRow] = useState(null)
  const [users, setUsers] = useState([])
  const [hoveredEmail, setHoveredEmail] = useState(null)

  const [searchQuery, setSearchQuery] = useState("")
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const [isActivateOpen, setIsActivateOpen] = useState(false)
  const [isDeactivateOpen, setIsDeactivateOpen] = useState(false)
  const [isedituserOpen, setIsEdituserOpen] = useState(false)
  const [showHistoryPopup, setShowHistoryPopup] = useState(false)
  const [selectedUser, setSelectedUser] = useState(null)
  const [isActivationemailOpen, setIsActivationemailOpen] = useState(false)
  const [DeactiveemailOpen, setIsDeactivemailOpen] = useState(false)
  const [isDeleteuserOpen, setIsDeleteuserOpen] = useState(false)
  const [successemailMessage, setSuccessemailMessage] = useState(null)
  const [successMessage, setSuccessMessage] = useState("")
  const [currentUser, setCurrentUser] = useState(null)
  const [emailLoading, setEmailLoading] = useState(false)
  const [dealers, setDealers] = useState([])
  const [marketAreas, setMarketAreas] = useState([])
  const [roleOptions, setRoleOptions] = useState({})
  const [allRoles, setAllRoles] = useState([])
  const fileInputRef = useRef(null)
  const tableContainerRef = useRef(null)
  const actionMenuRef = useRef(null);
  const [sortOrder, setSortOrder] = useState()
  const actionDropdownRef = useRef(null)
  const addUserDropdownRef = useRef(null)
  const dropdownRefs = useRef({})
const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0 });
  const [isOpen, setIsOpen] = useState({
    marketArea: false,
    userType: false,
    userrole: false,
    status: false,
    action: false,
    dealerShortName: false,
  })

useEffect(() => {
  const handleClickOutside = (e) => {
    const dropdowns = document.querySelectorAll(".custom-dropdown");
    const dropdownCells = document.querySelectorAll(".dropdown-cell");

    const isInsideDropdown = Array.from(dropdowns).some((dropdown) =>
      dropdown.contains(e.target)
    );

    const isInsideCell = Array.from(dropdownCells).some((cell) =>
      cell.contains(e.target)
    );

    if (!isInsideDropdown && !isInsideCell) {
      setIsOpen("");
      setOpen(false);
    }
  };

  document.addEventListener("mousedown", handleClickOutside);

  return () => {
    document.removeEventListener("mousedown", handleClickOutside);
  };
}, []);

  const [selectedValues, setSelectedValues] = useState({
    marketArea: [],
    userType: [],
    userrole: [],
    status: [],
    dealership: [],
  })
const INITIAL_SELECTED_VALUES = {
  userType: [],
  userrole: [],
  marketArea: [],
  dealership: [],
  status: []
};

  const [isMobileView, setIsMobileView] = useState(false)
  const [showMobileFilters, setShowMobileFilters] = useState(false)

  const statusMap = {
    NEW: "New",
    ACTIVE: "Active",
    INACTIVE: "Inactive",
    TEMPORARILY_DEACTIVATED: "Temporarily Deactivated",
  }

  const statusConfig = {
    New: {
      textColor: "text-blue",
    },
    Active: {
      textColor: "text-green",
    },
    "Inactive": {
      textColor: "text-red",
    },
    "Temporarily Deactivated": {
      textColor: "text-bluegreen",
    },
  };

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 1024)
    }

    checkScreenSize()
    window.addEventListener("resize", checkScreenSize)
    return () => window.removeEventListener("resize", checkScreenSize)
  }, [])

  const fetchUsers = async () => {
    try {
      setIsLoadingdata(true)
      let token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
      if (!token) {
        navigate("/")
        return
      }

      const res = await axios.get(
        `${API.domain}${API.userManagement.getAllUsers}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      )

      if (res.data?.status) {
        const mappedUsers = res.data.data.map((u) => {
          const initials =
            (u.firstName?.[0] || "").toUpperCase() + (u.lastName?.[0] || "").toUpperCase()

          return {
            id: u.id,
            name: `${u.firstName} ${u.middleName || ""} ${u.lastName}`.trim(),
            initials,
            email: u.email,
            type: u.role === "VOLVO_USER" ? "Volvo User" : "Dealer User",
            role: u.persona || u.role,
            location: u.locationType,
            marketArea: u.marketArea || "-",
            dealership:
              u.dealers && u.dealers.length > 0
                ? u.dealers.map((d) => d.dealerShortName || d.dealerName).join(", ")
                : "",
            status: statusMap[u.status] || u.status,
            createdAt: u.createdOn,
          }
        })

        setUsers(mappedUsers)

        const totalUsers = mappedUsers.length
        const activeUsers = mappedUsers.filter((u) => u.status === "Active").length
        const inactiveUsers = mappedUsers.filter((u) => u.status === "Inactive").length
        const newUsers = mappedUsers.filter(
          (u) => u.status !== "Active" && u.status !== "Inactive"
        ).length

        const calculatedStats = [
          { title: "Total Users:", value: totalUsers, color: "text-mildBlue" },
          { title: "Active Users:", value: activeUsers, color: "text-mildBlue" },
          { title: "Inactive Users:", value: inactiveUsers, color: "text-red3" },
          { title: "New Users:", value: newUsers, color: "text-mildBlue" },
        ]

        setStats(calculatedStats)
      }
    } catch (err) {
      const message = err.response?.data?.message;
      if (message === "token is invalid" || message === "jwt expired") {
        localStorage.removeItem("userToken")
        localStorage.removeItem("superUserToken")
        window.location.href = "/";
      }
      // console.log(err.response?.data?.message || err)
    } finally {
      setIsLoadingdata(false)
    }
  }

  useEffect(() => {
    fetchUsers()
  }, [])

  useEffect(() => {
    const fetchMarketAreas = async () => {
      try {
        let token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) {
          navigate("/")
          return
        }

        const res = await axios.get(
          `${API.domain}${API.userManagement.getMarketarea}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        )

        if (res.data.status && res.data.data) {
          setMarketAreas(res.data.data)
        }
      } catch (err) {
        const message = err.response?.data?.message;
        if (message === "token is invalid" || message === "jwt expired") {
          localStorage.removeItem("userToken")
          localStorage.removeItem("superUserToken")
          window.location.href = "/";
        }
      }
    }

    fetchMarketAreas()
  }, [])

  useEffect(() => {
    const fetchDealers = async () => {
      try {
        const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) {
          navigate("/")
          return
        }

        const res = await axios.get(
          `${API.domain}${API.userManagement.getDealers}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        )

        if (res.data.status && Array.isArray(res.data.data)) {
          setDealers(res.data.data)
        }
      } catch (err) {
        const message = err.response?.data?.message;
        if (message === "token is invalid" || message === "jwt expired") {
          localStorage.removeItem("userToken")
          localStorage.removeItem("superUserToken")
          window.location.href = "/";
        }
      }
    }

    fetchDealers()
  }, [navigate])

  useEffect(() => {
    const fetchRoles = async () => {
      try {
        let token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) {
          navigate("/")
          return
        }

        const res = await axios.get(
          `${API.domain}${API.userManagement.getRoles}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        )

        const rolesByType = {}
        const rolesSet = new Set()

        res.data.data.forEach((item) => {
          if (!rolesByType[item.userType]) rolesByType[item.userType] = []
          if (!rolesByType[item.userType].includes(item.userRole)) {
            rolesByType[item.userType].push(item.userRole)
          }
          rolesSet.add(item.userRole)
        })

        setRoleOptions(rolesByType)
        setAllRoles([...rolesSet])
      } catch (err) {
        const message = err.response?.data?.message;
        if (message === "token is invalid" || message === "jwt expired") {
          localStorage.removeItem("userToken")
          localStorage.removeItem("superUserToken")
          window.location.href = "/";
        }
      }
    }

    fetchRoles()
  }, [])

  const toggleDropdown = (name) => {
    setIsOpen((prev) => {
      const newState = Object.keys(prev).reduce((acc, key) => ({ ...acc, [key]: false }), {})
      return { ...newState, [name]: !prev[name] }
    })
  }

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (actionMenuRef.current && !actionMenuRef.current.contains(event.target)) {
        setIsOpen("");
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const normalize = (str) => (str || "").toLowerCase().replace(/\s+/g, "").trim()

  const normalizedQuery = normalize(searchQuery)

  const filteredUsers = useMemo(() => {
  return users
    // 🔎 SEARCH
  .filter((user) => {
  const searchWords = searchQuery
    .toLowerCase()
    .trim()
    .split(/\s+/); // split by space

  const userData = [
    user.name,
    user.email,
    user.role,
    user.marketArea,
    user.dealership,
    user.status,
  ]
    .join(" ")
    .toLowerCase();

  return searchWords.every((word) => userData.includes(word));
})

    // 📍 MARKET AREA FILTER
    .filter((user) => {
      if (selectedValues.marketArea.length > 0) {
        return selectedValues.marketArea.includes(user.marketArea);
      }
      return true;
    })

    // 👤 USER TYPE FILTER
    .filter((user) => {
      if (selectedValues.userType.length > 0) {
        return selectedValues.userType.includes(user.type);
      }
      return true;
    })

    // 🧑‍💼 USER ROLE FILTER
    .filter((user) => {
      if (selectedValues.userrole.length > 0) {
        return selectedValues.userrole.includes(user.role);
      }
      return true;
    })

    // 🏢 DEALERSHIP FILTER
    .filter((user) => {
      if (selectedValues.dealership.length > 0) {
        return selectedValues.dealership.some((dealer) =>
          user.dealership?.toLowerCase().includes(dealer.toLowerCase())
        );
      }
      return true;
    })

    // 📊 STATUS FILTER
    .filter((user) => {
      if (selectedValues.status.length > 0) {
        return selectedValues.status.includes(user.status);
      }
      return true;
    });

}, [users, searchQuery, selectedValues]);

  const toggleUserStatus = async (id, status) => {
    try {
      let token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
      if (!token) {
        navigate("/")
        return
      }

      setToggleLoading(true)

      const response = await axios.put(
        `${API.domain}${API.userManagement.toggleUserStatus}`,
        { id, status },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      )

      if (response.data?.status) {
        fetchUsers()
        setIsActivateOpen(false)
        setIsDeactivateOpen(false)
        setCurrentUser(null)
      } else {
        throw new Error(response.data?.message || "Failed to update status")
      }
    } catch (error) {
      const message = error.response?.data?.message;
      if (message === "token is invalid" || message === "jwt expired") {
        localStorage.removeItem("userToken")
        localStorage.removeItem("superUserToken")
        window.location.href = "/";
      }
      // console.error("Error toggling user status:", error)
    } finally {
      setToggleLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!currentUser) return

    try {
      const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
      if (!token) return navigate("/")

      setToggleLoading(true)

      await axios.delete(
        `${API.domain}${API.userManagement.deleteUser}/${currentUser.id}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      )
       resetSortAndFilter()
      await fetchUsers()
      setIsDeleteuserOpen(false)
      setCurrentUser(null)
    } catch (error) {
      // console.error("Error deleting user:", error)
      const message = error.response?.data?.message;
      if (message === "token is invalid" || message === "jwt expired") {
        localStorage.removeItem("userToken")
        localStorage.removeItem("superUserToken")
        window.location.href = "/";
      }

    } finally {
      setToggleLoading(false)
    }
  }

  const handleSendActivationEmail = async () => {
    if (!currentUser) return

    setEmailLoading(true)

    try {
      let token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
      if (!token) {
        navigate("/")
        return
      }

      const payload = {
        userId: currentUser.id,
        admin: "Sameer",
        user: currentUser.name,
        mail: currentUser.email,
      }

      const response = await axios.put(
        `${API.domain}${API.userManagement.activationLink}`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      )

      if (response.data?.status) {
        setSuccessemailMessage({
          title: "Activation Email Sent",
          description: `Activation email successfully sent to ${currentUser.name}.`,
        })
      } else {
        throw new Error(response.data?.message || "Failed to send activation email")
      }
    } catch (error) {
      const message = error.response?.data?.message;
      if (message === "token is invalid" || message === "jwt expired") {
        localStorage.removeItem("userToken")
        localStorage.removeItem("superUserToken")
        window.location.href = "/";
      }
      setSuccessemailMessage({
        title: "Error",
        description: "Something went wrong while sending activation email.",
      })
    } finally {
      setEmailLoading(false)
      setIsActivationemailOpen(false)
    }
  }

  const handleAddUser = async () => {
    setSuccessMessage(`User added successfully!`)
    setIsAddUserOpen(false)
// 1️⃣ Reset filters & sorting (ADD only)
  resetSortAndFilter();
    fetchUsers()
  }

  const handleEditUser = async (updatedUser) => {
    if (!updatedUser) {
      // console.error("Updated user is undefined!")
      return
    }
    if (!updatedUser.id) {
      // console.error("Updated user has no id!", updatedUser)
      return
    }

    await fetchUsers()
    setIsEdituserOpen(false)
  }

  const afterAddUser = async () => {
    await fetchUsers()
  }

  const handleView = (user) => {
    navigate("/userdetails", { state: { userId: user.id } })
  }

  const handleLogin = async (user) => {
    try {
      const result = await userLogin(user.email);

      if (result.success) {
        await dispatch(fetchLoggedInUser());
        navigate("/homepage");
      } else {
        // alert(result.error);
      }
    } catch (err) {
      // console.error("Login failed:", err);
    }
  };

  const toggleExpand = (id) => {
    setExpandedRow(expandedRow === id ? null : id)
  }

  const handleBulkUploadClick = () => {
    fileInputRef.current.click()
  }

  const handleFileChange = (event) => {
    const files = event.target.files
    if (files.length > 0) {
      // console.log("Selected files:", files)
    }
  }

  const handleSendDeactivationEmail = () => {
    setIsDeactivemailOpen(false)
  }

  const handleDownloadTemplate = async () => {
    const workbook = new ExcelJS.Workbook()

    const sheet = workbook.addWorksheet("Users")

    sheet.columns = [
      { header: "First Name", key: "firstName", width: 20 },
      { header: "Middle Name", key: "middleName", width: 20 },
      { header: "Last Name", key: "lastName", width: 20 },
      { header: "Email ID", key: "email", width: 30 },
      { header: "User Type", key: "userType", width: 18 },
      { header: "User Location", key: "userLocation", width: 18 },
      { header: "User Role", key: "userRole", width: 20 },
      { header: "Market Area", key: "marketArea", width: 22 },
      { header: "Dealership", key: "dealership", width: 25 },
    ]

    sheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" } }
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF476896" },
      }
      cell.alignment = { vertical: "middle", horizontal: "left" }
    })

    sheet.addRow({
      firstName: "John",
      middleName: "Michael",
      lastName: "Smith",
      email: "john.smith@example.com",
      userType: "Dealer User",
      userLocation: "Headquarters",
      userRole: "Administrator",
      marketArea: "East",
      dealership: "SMP-BH",
    })

    const dropdownSheet = workbook.addWorksheet("Dropdowns", {
      state: "veryHidden",
    })

    const userTypeOptions = ["Volvo User", "Dealer User"]
    const userLocationOptions = ["Headquarters", "Region"]
    const userRoleOptions =
      allRoles && allRoles.length > 0 ? allRoles : ["Manager", "Executive"]
    const marketAreaOptions = marketAreas.map(
      (a) => a.marketarea || a.name
    )
    const dealerOptions = dealers.map(
      (d) => d.dealerShortName || d.dealerName
    )

    const dropdownMap = {
      userType: userTypeOptions,
      userLocation: userLocationOptions,
      userRole: userRoleOptions,
      marketArea: marketAreaOptions,
      dealership: dealerOptions,
    }

    Object.entries(dropdownMap).forEach(([key, values], index) => {
      dropdownSheet.getColumn(index + 1).values = ["", ...values]
      dropdownSheet.getColumn(index + 1).width = 30
    })

    Object.keys(dropdownMap).forEach((key, index) => {
      const colIndex = sheet.getColumn(key).number
      const columnLetter = dropdownSheet.getColumn(index + 1).letter
      const lastRow = dropdownMap[key].length + 1

      for (let row = 2; row <= 1000; row++) {
        sheet.getCell(row, colIndex).dataValidation = {
          type: "list",
          allowBlank: true,
          formulae: [
            `Dropdowns!$${columnLetter}$2:$${columnLetter}$${lastRow}`,
          ],
          showErrorMessage: true,
          errorTitle: "Invalid value",
          error: "Please select a value from the dropdown",
        }
      }
    })

    for (let row = 2; row <= 1000; row++) {
      sheet.getRow(row).eachCell({ includeEmpty: true }, (cell) => {
        cell.alignment = { vertical: "middle", horizontal: "left" }
      })
    }

    const buffer = await workbook.xlsx.writeBuffer()
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })

    saveAs(blob, "User_Bulk_Upload_Template.xlsx")
  }

  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const previewTab = window.open("/bulkupload/usermanagement", "_blank");
    if (!previewTab) {
      // alert("Popup blocked! Please allow popups.");
      return;
    }

    const reader = new FileReader();

    reader.onload = (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];

      let rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
        defval: "",
      });

      rows = rows.filter((row) =>
        Object.values(row).some((v) => String(v).trim() !== "")
      );

      const finalRows = rows.map((row, index) => {
        const userType = row["User Type"] || row["user type"] || "";
        const firstName = row["First Name"] || row["first name"] || "";
        const lastName = row["Last Name"] || row["last name"] || "";
        const email = row["Email"] || row["email"] || "";
        const userRole = row["User Role"] || row["user role"] || "";
        const marketArea = row["Market Area"] || row["market area"] || "";
        const dealership = row["Dealership"] || row["dealership"] || "";

        return {
          slNo: index + 1,
          firstName: String(firstName).trim(),
          lastName: String(lastName).trim(),
          email: String(email).trim(),
          userType: String(userType).trim(),
          userRole: String(userRole).trim(),
          marketArea: String(marketArea).trim(),
          dealership: String(dealership).trim(),
          hasError:
            !firstName ||
            !lastName ||
            !email ||
            !userType ||
            !userRole ||
            !marketArea ||
            !dealership,
        };
      });

      previewTab.postMessage(
        {
          type: "USER_PREVIEW",
          payload: { rows: finalRows },
        },
        "*"
      );
    };

    reader.readAsArrayBuffer(file);
  };

  const selectedMarket = selectedValues.marketArea
    ? selectedValues.marketArea.name || selectedValues.marketArea
    : ""

  const selectedMarkets = Array.isArray(selectedMarket) ? selectedMarket : [selectedMarket]

  const filteredDealers = dealers.filter((dealer) => {
    const dealerMarketLower = String(dealer.marketName || "").trim().toLowerCase()
    return (
      selectedMarkets.length === 0 ||
      selectedMarkets.some((market) => String(market).trim().toLowerCase() === dealerMarketLower)
    )
  })

  const dealerOptions = filteredDealers.map((dealer) => dealer.dealerShortName)

  const MobileUserCard = ({ user, index }) => (
    <div className="bg-white border border-gray-200 rounded-lg p-3 mb-3 shadow-sm">
      <div className="flex items-center gap-2 mb-2">
        <div className="flex items-center justify-center rounded-lg w-10 h-10 text-xs font-semibold bg-grey2 text-black">
          {user.initials}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm text-black truncate">{user.name}</p>
          <p className="text-xs text-gray-600 truncate">{user.email}</p>
        </div>
      </div>

      <div className="space-y-1.5 mb-2">
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Role:</span>
          <span className="text-xs text-black font-medium text-right flex-1 ml-2">
            {user.role} <span className="text-xs text-gray-600">({user.type})</span>
          </span>
        </div>

        {user.marketArea && (
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">Market:</span>
            <span className="text-xs text-black text-right">{user.marketArea}</span>
          </div>
        )}

        {user.dealership && (
          <div className="flex justify-between items-start">
            <span className="text-xs text-gray-500 mt-0.5">Dealership:</span>
            <div className="text-xs text-black text-right flex-1 ml-2">
              {user.dealership.split(",").slice(0, 2).map((d, i) => (
                <div key={i}>{d.trim()}</div>
              ))}
              {user.dealership.split(",").length > 2 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    toggleExpand(user.id)
                  }}
                  className="text-blue-600 text-xs flex items-center gap-1 mt-0.5"
                >
                  {expandedRow === user.id
                    ? "Show less"
                    : `+${user.dealership.split(",").length - 2} more`}
                  {expandedRow === user.id ? (
                    <ChevronUp className="w-3 h-3" />
                  ) : (
                    <ChevronDown className="w-3 h-3" />
                  )}
                </button>
              )}
              {expandedRow === user.id &&
                user.dealership.split(",").slice(2).map((d, i) => <div key={i + 2}>{d.trim()}</div>)}
            </div>
          </div>
        )}

        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Status:</span>
          <div className="flex items-center gap-1.5">
            {statusConfig[user.status] && (
              <>
                <span
                  className={`w-2 h-2 rounded-full flex-shrink-0 ${
                    user.status === "New"
                      ? "bg-SteelBlue1"
                      : user.status === "Active"
                      ? "bg-green"
                      : user.status === "Inactive"
                      ? "bg-red1"
                      : "bg-gray-400"
                  }`}
                />
                <span className={`text-xs ${statusConfig[user.status].textColor}`}>
                  {user.status}
                </span>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-between items-center pt-2 border-t border-gray-100">
        <button
          onClick={() => handleView(user)}
          className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded-md text-xs font-medium hover:bg-blue-100 transition-colors"
        >
          View Details
        </button>

        <div className="flex items-center gap-1.5">
          <button
            onClick={(e) => {
              e.stopPropagation()
              handleLogin(user)
            }}
            className="p-1.5  hover:bg-gray-100 transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 32 32" fill="none">
              <rect x="0.5" y="0.5" width="31" height="31" rx="4.5" stroke="#E1E1E1"/>
              <g clipPath="url(#clip0_5669_1242)">
                <path d="M15 11L13.6 12.4L16.2 15H6V17H16.2L13.6 19.6L15 21L20 16L15 11ZM24 23H16V25H24C25.1 25 26 24.1 26 23V9C26 7.9 25.1 7 24 7H16V9H24V23Z" fill="#212121"/>
              </g>
            </svg>
          </button>

          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation()
                setIsOpen(isOpen === user.id.toString() ? "" : user.id.toString())
                setCurrentUser(user)
              }}
              className="p-1.5 rounded-md hover:bg-gray-100 transition-colors"
            >
              <span className="text-lg font-bold leading-none">⋮</span>
            </button>

            {isOpen === user.id.toString() && (
              <div className="absolute right-0 w-44 bg-white border border-gray-300 rounded-lg shadow-lg z-10 top-full mt-1">
                {[
                  {
                    label: "View",
                    icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/view.png",
                    onClick: () => {
                      setIsOpen("")
                      handleView(user)
                    },
                  },
                  {
                    label: "Edit",
                    icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/edit.png",
                    onClick: () => {
                      setIsEdituserOpen(true)
                      setIsOpen("")
                    },
                  },
                  {
                    label: user.status === "Active" ? "Deactivate User" : "Activate User",
                    icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/toggleuser.png",
                    onClick: () => {
                      setCurrentUser(user)
                      setIsOpen("")
                      if (user.status === "Active") setIsDeactivateOpen(true)
                      else setIsActivateOpen(true)
                    },
                  },
                  {
                    label: "Show History",
                    icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/showhistory.png",
                    onClick: () => {
                      setSelectedUser(user)
                      setShowHistoryPopup(true)
                      setIsOpen("")
                    },
                  },
                  ...(user.status === "Inactive"
                    ? [
                      {
                        label: "Send Activation Email",
                        icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/email.png",
                        onClick: () => {
                          setCurrentUser(user)
                          setIsActivationemailOpen(true)
                          setIsOpen("")
                        },
                      },
                    ]
                    : []),
                  {
                    label: "Delete",
                    icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/delete.png",
                    onClick: () => {
                      setCurrentUser(user)
                      setIsDeleteuserOpen(true)
                      setIsOpen("")
                    },
                  },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 py-1.5 px-3 hover:bg-gray-50 cursor-pointer text-xs"
                    onClick={(e) => {
                      e.stopPropagation()
                      item.onClick()
                    }}
                  >
                    {typeof item.icon === "string" ? (
                      <img src={item.icon} alt={item.label} className="w-3.5 h-3.5" />
                    ) : (
                      item.icon
                    )}
                    <span>{item.label}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )

  const [hoveredUser, setHoveredUser] = useState(null);
  const [hoveredRole, setHoveredRole] = useState(null);
  const [hoveredMarket, setHoveredMarket] = useState(null);
  const [originalUsers, setOriginalUsers] = useState([]);
  const [sortedUsers, setSortedUsers] = useState([]);
  const [sortKey, setSortKey] = useState(null);
const isSmallTable = sortedUsers.length < 7;
  useEffect(() => {
    setOriginalUsers(filteredUsers);
    setSortedUsers(filteredUsers);
  }, [filteredUsers]);

  const handleSort = (key) => {
    if (sortKey === key) {
      if (sortOrder === "asc") {
        const sortedDesc = [...sortedUsers].sort((a, b) => {
          const valA = (a[key] || "").toString().toLowerCase();
          const valB = (b[key] || "").toString().toLowerCase();
          return valB.localeCompare(valA);
        });
        setSortedUsers(sortedDesc);
        setSortOrder("desc");
        return;
      } else if (sortOrder === "desc") {
        setSortedUsers(originalUsers);
        setSortKey(null);
        setSortOrder(null);
        return;
      }
    }

    const sortedAsc = [...sortedUsers].sort((a, b) => {
      const valA = (a[key] || "").toString().toLowerCase();
      const valB = (b[key] || "").toString().toLowerCase();
      return valA.localeCompare(valB);
    });

    setSortedUsers(sortedAsc);
    setSortKey(key);
    setSortOrder("asc");
  };
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchQuery: { setter: setSearchQuery, resetValue: "" },
    selectedValues: {
      setter: setSelectedValues,
      resetValue: INITIAL_SELECTED_VALUES
    }
  }
);

  const calculateDropdownPosition = (userId) => {
    if (!dropdownRefs.current[userId]) {
      return { top: "full", transformOrigin: "top right" };
    }

    const button = dropdownRefs.current[userId];
    const buttonRect = button.getBoundingClientRect();
    const containerRect = tableContainerRef.current?.getBoundingClientRect();

    if (!containerRect) {
      return { top: "full", transformOrigin: "top right" };
    }

    const spaceBelow = containerRect.bottom - buttonRect.bottom;
    const spaceAbove = buttonRect.top - containerRect.top;
    const dropdownHeight = 250;

    if (spaceBelow < dropdownHeight && spaceAbove > dropdownHeight) {
      return { 
        bottom: "full", 
        top: "auto",
        transformOrigin: "bottom right",
        marginBottom: "4px"
      };
    }

    return { 
      top: "full",
      transformOrigin: "top right",
      marginTop: "4px"
    };
  };

  const getDropdownClasses = (userId) => {
    const position = calculateDropdownPosition(userId);
    let classes = "absolute right-0 w-44 bg-white border border-gray-300 rounded-lg shadow-lg z-10";
    
    if (position.top === "full") {
      classes += " top-full mt-1";
    } else {
      classes += " bottom-full mb-1";
    }

    return classes;
  };
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
      setIsOpen(""); // 🔴 close dropdown when scrolling
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  return (
    <div className="w-full flex justify-center">
      <div className="w-full">
        <div className="bg-white shadow-[0_4px_10px_#0000001A] p-2 mb-2">
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 text-center gap-2">
            {stats.map((stat, index) => (
              <div
                key={index}
                className={`relative py-0 px-3 ${index < stats.length - 1 ? "border-r border-darkblue1" : ""
                  } flex items-center justify-center bg-white`}
              >
                <div className="flex items-center gap-1 sm:gap-1.5 text-xs sm:text-sm font-VolvoNovum font-medium">
                  <span className="text-black">{stat.title}</span>
                  <span
                    className={`font-bold ${stat.color || "text-SteelBlue1"
                      }`}
                  >
                    {stat.value}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="w-full mb-2.5">
          <div className="flex lg:hidden items-center gap-2 mb-2">
            <Searchinput
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value)
              }}
              placeholder="Search"
              className="flex-1 h-8"
              bgColor="bg-white"
              borderColor="border-black/60"
              textColor="text-black"
              focusRing="focus:ring-black/60"
              shadow="shadow-none"
              inputPadding="pl-7 pr-3 py-1.5"
              iconSize="w-3.5 h-3.5"
              iconLeft="left-3"
              iconColor="text-black"
            />
            <button
              onClick={() => setShowMobileFilters(!showMobileFilters)}
              className="flex items-center gap-1 px-3 py-1.5 border border-black/60 bg-white text-black text-xs font-medium h-8"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
              </svg>
              Filters
            </button>

            <div className="relative custom-dropdown">
              <button
                className="font-medium py-1 text-xs flex items-center justify-center gap-1 text-white bg-darkblue1 hover:bg-opacity-80 transition duration-200 h-8 px-3"
                onClick={() => toggleDropdown("action")}
              >
                Add
              </button>

              {isOpen.action && (
                <div className="absolute top-full right-0 mt-1 w-40 bg-white border border-darkblue1 shadow-lg z-50">
                  <button
                    className="w-full text-left py-1.5 px-3 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                    onClick={() => {
                      setIsAddUserOpen(true)
                      setIsOpen({ ...isOpen, action: false })
                    }}
                  >
                    Add New
                  </button>

                  <button
                    onClick={() => navigate("/bulkupload/usermanagement")}
                    className="w-full text-left px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                  >
                    Bulk Upload
                  </button>

                  <button
                    onClick={() => {
                      handleDownloadTemplate()
                      setIsOpen({ ...isOpen, action: false })
                    }}
                    className="w-full text-left py-1.5 px-3 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                  >
                    Template File
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className={`lg:hidden ${showMobileFilters ? 'block' : 'hidden'} mb-2`}>
            <div className="grid grid-cols-2 gap-2">
              <Filter
                name="userType"
                value={selectedValues.userType}
                options={["Dealer User", "Volvo User"]}
                onChange={(name, newValue) => {
                  setSelectedValues((prev) => ({
                    ...prev,
                    [name]: newValue,
                    userrole: [],
                  }))
                }}
                placeholder="User Type"
                textColor="text-black/60"
                buttonBorderColor="border-black/60"
                dropdownBorderColor="border-black/60"
                dropdownHoverColor="hover:bg-lightBlue/50"
                customWidth="w-full"
              />

              <Filter
                name="userrole"
                value={selectedValues.userrole}
                options={
                  selectedValues.userType.length > 0
                    ? selectedValues.userType.flatMap((type) => roleOptions[type] || [])
                    : allRoles
                }
                onChange={(name, newValue) => {
                  setSelectedValues((prev) => ({
                    ...prev,
                    [name]: newValue,
                  }))
                }}
                placeholder="User Role"
                textColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBorderColor="border-black/60"
                dropdownHoverColor="hover:bg-lightBlue/50"
                customWidth="w-full"
              />

              <Filter
                name="marketArea"
                value={selectedValues.marketArea}
                options={marketAreas.map((area) => area.marketarea || area.name)}
                onChange={(name, newValue) => {
                  setSelectedValues((prev) => ({
                    ...prev,
                    [name]: newValue,
                    dealership: [],
                  }))
                }}
                placeholder="Market Area"
                textColor="text-black/60"
                buttonBorderColor="border-black/60"
                dropdownBorderColor="border-black/60"
                dropdownHoverColor="hover:bg-lightBlue/50"
                customWidth="w-full"
              />

              <Filter
                name="dealership"
                value={selectedValues.dealership}
                options={dealerOptions}
                onChange={(name, newValue) =>
                  setSelectedValues((prev) => ({ ...prev, [name]: newValue }))
                }
                placeholder="Dealership"
                textColor="text-black/60"
                buttonBorderColor="border-black/60"
                dropdownBorderColor="border-black/60"
                dropdownHoverColor="hover:bg-lightBlue/50"
                customWidth="w-full"
              />

              <Filter
                name="status"
                value={selectedValues.status}
                options={["New", "Active", "Inactive"]}
                onChange={(name, newValue) => {
                  setSelectedValues((prev) => ({
                    ...prev,
                    [name]: newValue,
                  }))
                }}
                placeholder="Status"
                textColor="text-black"
                buttonBorderColor="border-black/60"
                dropdownBorderColor="border-black/60"
                dropdownHoverColor="hover:bg-lightBlue/50"
                customWidth="w-full"
              />
            </div>
          </div>

          <div className="hidden lg:grid grid-cols-7 gap-2 items-center">
            <Searchinput
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value)
              }}
              placeholder="Search"
              className="w-full h-8"
              bgColor="bg-white"
              borderColor="border-black/60"
              textColor="text-black"
              focusRing="focus:ring-black/60"
              shadow="shadow-none"
              inputPadding="pl-7 pr-3 py-1.5"
              iconSize="w-3.5 h-3.5"
              iconLeft="left-3"
              iconColor="text-black"
            />

            <Filter
              name="userType"
              value={selectedValues.userType}
              options={["Dealer User", "Volvo User"]}
              onChange={(name, newValue) => {
                setSelectedValues((prev) => ({
                  ...prev,
                  [name]: newValue,
                  userrole: [],
                }))
              }}
              placeholder="User Type"
              textColor="text-black/60"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-full"
            />

            <Filter
              name="userrole"
              value={selectedValues.userrole}
              options={
                selectedValues.userType.length > 0
                  ? selectedValues.userType.flatMap((type) => roleOptions[type] || [])
                  : allRoles
              }
              onChange={(name, newValue) => {
                setSelectedValues((prev) => ({
                  ...prev,
                  [name]: newValue,
                }))
              }}
              placeholder="User Role"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-full"
              customHeight="h-9"
            />

            <Filter
              name="marketArea"
              value={selectedValues.marketArea}
              options={marketAreas.map((area) => area.marketarea || area.name)}
              onChange={(name, newValue) => {
                setSelectedValues((prev) => ({
                  ...prev,
                  [name]: newValue,
                  dealership: [],
                }))
              }}
              placeholder="Market Area"
              textColor="text-black/60"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-full"
              customHeight="h-9"
            />

            <Filter
              name="dealership"
              value={selectedValues.dealership}
              options={dealerOptions}
              onChange={(name, newValue) =>
                setSelectedValues((prev) => ({ ...prev, [name]: newValue }))
              }
              placeholder="Dealership"
              textColor="text-black/60"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-full"
              customHeight="h-9"
            />

            <Filter
              name="status"
              value={selectedValues.status}
              options={["New", "Active", "Inactive"]}
              onChange={(name, newValue) => {
                setSelectedValues((prev) => ({
                  ...prev,
                  [name]: newValue,
                }))
              }}
              placeholder="Status"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-full"
              customHeight="h-9"
            />

           <div className="relative w-full custom-dropdown sm:col-span-2 lg:col-span-1">
              <button
                className="font-medium py-1 text-xs flex items-center justify-center gap-2 text-white bg-darkblue1 hover:bg-opacity-80 transition duration-200 w-full h-8"
                onClick={() => toggleDropdown("action")}
              >
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="14" viewBox="0 0 24 14" fill="none">
<path d="M13 6C13.5933 6 14.1734 5.82405 14.6667 5.49441C15.1601 5.16477 15.5446 4.69623 15.7716 4.14805C15.9987 3.59987 16.0581 2.99667 15.9424 2.41473C15.8266 1.83279 15.5409 1.29824 15.1213 0.878681C14.7018 0.459123 14.1672 0.173401 13.5853 0.0576455C13.0033 -0.0581102 12.4001 0.00129986 11.8519 0.228363C11.3038 0.455426 10.8352 0.839943 10.5056 1.33329C10.1759 1.82664 10 2.40666 10 3C10 3.79565 10.3161 4.55871 10.8787 5.12132C11.4413 5.68393 12.2044 6 13 6ZM13 2C13.1978 2 13.3911 2.05865 13.5556 2.16853C13.72 2.27841 13.8482 2.43459 13.9239 2.61732C13.9996 2.80004 14.0194 3.00111 13.9808 3.19509C13.9422 3.38907 13.847 3.56726 13.7071 3.70711C13.5673 3.84696 13.3891 3.9422 13.1951 3.98079C13.0011 4.01937 12.8 3.99957 12.6173 3.92388C12.4346 3.84819 12.2784 3.72002 12.1685 3.55557C12.0586 3.39112 12 3.19778 12 3C12 2.73478 12.1054 2.48043 12.2929 2.29289C12.4804 2.10536 12.7348 2 13 2ZM17.11 5.86C17.6951 5.02103 18.0087 4.02282 18.0087 3C18.0087 1.97718 17.6951 0.97897 17.11 0.140001C17.3976 0.0472552 17.6979 1.87014e-05 18 1.1415e-06C18.7956 1.1415e-06 19.5587 0.316072 20.1213 0.878681C20.6839 1.44129 21 2.20435 21 3C21 3.79565 20.6839 4.55871 20.1213 5.12132C19.5587 5.68393 18.7956 6 18 6C17.6979 5.99998 17.3976 5.95275 17.11 5.86ZM13 8C7 8 7 12 7 12V14H19V12C19 12 19 8 13 8ZM9 12C9 11.71 9.32 10 13 10C16.5 10 16.94 11.56 17 12M24 12V14H21V12C20.9766 11.2566 20.8054 10.5254 20.4964 9.84891C20.1873 9.17244 19.7466 8.5643 19.2 8.06C24 8.55 24 12 24 12ZM8 7H5V10H3V7H0V5H3V2H5V5H8V7Z" fill="white"/>
</svg>
                <span className="hidden sm:inline">Add User</span>
                <span className="sm:hidden">Add</span>
              </button>

              {isOpen.action && (
                <div className="absolute top-full left-0 mt-1 w-full bg-white border border-darkblue1 shadow-lg z-50">
                  <button
                    className="w-full text-left py-1.5 px-3 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 hover:rounded-t-lg"
                    onClick={() => {
                      setIsAddUserOpen(true)
                      setIsOpen({ ...isOpen, action: false })
                    }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="20" viewBox="0 0 24 24" fill="none">
<path d="M13 11C13.5933 11 14.1734 10.8241 14.6667 10.4944C15.1601 10.1648 15.5446 9.69623 15.7716 9.14805C15.9987 8.59987 16.0581 7.99667 15.9424 7.41473C15.8266 6.83279 15.5409 6.29824 15.1213 5.87868C14.7018 5.45912 14.1672 5.1734 13.5853 5.05765C13.0033 4.94189 12.4001 5.0013 11.8519 5.22836C11.3038 5.45543 10.8352 5.83994 10.5056 6.33329C10.1759 6.82664 10 7.40666 10 8C10 8.79565 10.3161 9.55871 10.8787 10.1213C11.4413 10.6839 12.2044 11 13 11ZM13 7C13.1978 7 13.3911 7.05865 13.5556 7.16853C13.72 7.27841 13.8482 7.43459 13.9239 7.61732C13.9996 7.80004 14.0194 8.00111 13.9808 8.19509C13.9422 8.38907 13.847 8.56726 13.7071 8.70711C13.5673 8.84696 13.3891 8.9422 13.1951 8.98079C13.0011 9.01937 12.8 8.99957 12.6173 8.92388C12.4346 8.84819 12.2784 8.72002 12.1685 8.55557C12.0586 8.39112 12 8.19778 12 8C12 7.73478 12.1054 7.48043 12.2929 7.29289C12.4804 7.10536 12.7348 7 13 7ZM17.11 10.86C17.6951 10.021 18.0087 9.02282 18.0087 8C18.0087 6.97718 17.6951 5.97897 17.11 5.14C17.3976 5.04726 17.6979 5.00002 18 5C18.7956 5 19.5587 5.31607 20.1213 5.87868C20.6839 6.44129 21 7.20435 21 8C21 8.79565 20.6839 9.55871 20.1213 10.1213C19.5587 10.6839 18.7956 11 18 11C17.6979 11 17.3976 10.9527 17.11 10.86ZM13 13C7 13 7 17 7 17V19H19V17C19 17 19 13 13 13ZM9 17C9 16.71 9.32 15 13 15C16.5 15 16.94 16.56 17 17M24 17V19H21V17C20.9766 16.2566 20.8054 15.5254 20.4964 14.8489C20.1873 14.1724 19.7466 13.5643 19.2 13.06C24 13.55 24 17 24 17ZM8 12H5V15H3V12H0V10H3V7H5V10H8V12Z" fill="#212121"/>
<path d="M13 11C13.5933 11 14.1734 10.8241 14.6667 10.4944C15.1601 10.1648 15.5446 9.69623 15.7716 9.14805C15.9987 8.59987 16.0581 7.99667 15.9424 7.41473C15.8266 6.83279 15.5409 6.29824 15.1213 5.87868C14.7018 5.45912 14.1672 5.1734 13.5853 5.05765C13.0033 4.94189 12.4001 5.0013 11.8519 5.22836C11.3038 5.45543 10.8352 5.83994 10.5056 6.33329C10.1759 6.82664 10 7.40666 10 8C10 8.79565 10.3161 9.55871 10.8787 10.1213C11.4413 10.6839 12.2044 11 13 11ZM13 7C13.1978 7 13.3911 7.05865 13.5556 7.16853C13.72 7.27841 13.8482 7.43459 13.9239 7.61732C13.9996 7.80004 14.0194 8.00111 13.9808 8.19509C13.9422 8.38907 13.847 8.56726 13.7071 8.70711C13.5673 8.84696 13.3891 8.9422 13.1951 8.98079C13.0011 9.01937 12.8 8.99957 12.6173 8.92388C12.4346 8.84819 12.2784 8.72002 12.1685 8.55557C12.0586 8.39112 12 8.19778 12 8C12 7.73478 12.1054 7.48043 12.2929 7.29289C12.4804 7.10536 12.7348 7 13 7ZM17.11 10.86C17.6951 10.021 18.0087 9.02282 18.0087 8C18.0087 6.97718 17.6951 5.97897 17.11 5.14C17.3976 5.04726 17.6979 5.00002 18 5C18.7956 5 19.5587 5.31607 20.1213 5.87868C20.6839 6.44129 21 7.20435 21 8C21 8.79565 20.6839 9.55871 20.1213 10.1213C19.5587 10.6839 18.7956 11 18 11C17.6979 11 17.3976 10.9527 17.11 10.86ZM13 13C7 13 7 17 7 17V19H19V17C19 17 19 13 13 13ZM9 17C9 16.71 9.32 15 13 15C16.5 15 16.94 16.56 17 17M24 17V19H21V17C20.9766 16.2566 20.8054 15.5254 20.4964 14.8489C20.1873 14.1724 19.7466 13.5643 19.2 13.06C24 13.55 24 17 24 17ZM8 12H5V15H3V12H0V10H3V7H5V10H8V12Z" fill="black" fill-opacity="0.2"/>
<path d="M13 11C13.5933 11 14.1734 10.8241 14.6667 10.4944C15.1601 10.1648 15.5446 9.69623 15.7716 9.14805C15.9987 8.59987 16.0581 7.99667 15.9424 7.41473C15.8266 6.83279 15.5409 6.29824 15.1213 5.87868C14.7018 5.45912 14.1672 5.1734 13.5853 5.05765C13.0033 4.94189 12.4001 5.0013 11.8519 5.22836C11.3038 5.45543 10.8352 5.83994 10.5056 6.33329C10.1759 6.82664 10 7.40666 10 8C10 8.79565 10.3161 9.55871 10.8787 10.1213C11.4413 10.6839 12.2044 11 13 11ZM13 7C13.1978 7 13.3911 7.05865 13.5556 7.16853C13.72 7.27841 13.8482 7.43459 13.9239 7.61732C13.9996 7.80004 14.0194 8.00111 13.9808 8.19509C13.9422 8.38907 13.847 8.56726 13.7071 8.70711C13.5673 8.84696 13.3891 8.9422 13.1951 8.98079C13.0011 9.01937 12.8 8.99957 12.6173 8.92388C12.4346 8.84819 12.2784 8.72002 12.1685 8.55557C12.0586 8.39112 12 8.19778 12 8C12 7.73478 12.1054 7.48043 12.2929 7.29289C12.4804 7.10536 12.7348 7 13 7ZM17.11 10.86C17.6951 10.021 18.0087 9.02282 18.0087 8C18.0087 6.97718 17.6951 5.97897 17.11 5.14C17.3976 5.04726 17.6979 5.00002 18 5C18.7956 5 19.5587 5.31607 20.1213 5.87868C20.6839 6.44129 21 7.20435 21 8C21 8.79565 20.6839 9.55871 20.1213 10.1213C19.5587 10.6839 18.7956 11 18 11C17.6979 11 17.3976 10.9527 17.11 10.86ZM13 13C7 13 7 17 7 17V19H19V17C19 17 19 13 13 13ZM9 17C9 16.71 9.32 15 13 15C16.5 15 16.94 16.56 17 17M24 17V19H21V17C20.9766 16.2566 20.8054 15.5254 20.4964 14.8489C20.1873 14.1724 19.7466 13.5643 19.2 13.06C24 13.55 24 17 24 17ZM8 12H5V15H3V12H0V10H3V7H5V10H8V12Z" fill="black" fill-opacity="0.2"/>
<path d="M13 11C13.5933 11 14.1734 10.8241 14.6667 10.4944C15.1601 10.1648 15.5446 9.69623 15.7716 9.14805C15.9987 8.59987 16.0581 7.99667 15.9424 7.41473C15.8266 6.83279 15.5409 6.29824 15.1213 5.87868C14.7018 5.45912 14.1672 5.1734 13.5853 5.05765C13.0033 4.94189 12.4001 5.0013 11.8519 5.22836C11.3038 5.45543 10.8352 5.83994 10.5056 6.33329C10.1759 6.82664 10 7.40666 10 8C10 8.79565 10.3161 9.55871 10.8787 10.1213C11.4413 10.6839 12.2044 11 13 11ZM13 7C13.1978 7 13.3911 7.05865 13.5556 7.16853C13.72 7.27841 13.8482 7.43459 13.9239 7.61732C13.9996 7.80004 14.0194 8.00111 13.9808 8.19509C13.9422 8.38907 13.847 8.56726 13.7071 8.70711C13.5673 8.84696 13.3891 8.9422 13.1951 8.98079C13.0011 9.01937 12.8 8.99957 12.6173 8.92388C12.4346 8.84819 12.2784 8.72002 12.1685 8.55557C12.0586 8.39112 12 8.19778 12 8C12 7.73478 12.1054 7.48043 12.2929 7.29289C12.4804 7.10536 12.7348 7 13 7ZM17.11 10.86C17.6951 10.021 18.0087 9.02282 18.0087 8C18.0087 6.97718 17.6951 5.97897 17.11 5.14C17.3976 5.04726 17.6979 5.00002 18 5C18.7956 5 19.5587 5.31607 20.1213 5.87868C20.6839 6.44129 21 7.20435 21 8C21 8.79565 20.6839 9.55871 20.1213 10.1213C19.5587 10.6839 18.7956 11 18 11C17.6979 11 17.3976 10.9527 17.11 10.86ZM13 13C7 13 7 17 7 17V19H19V17C19 17 19 13 13 13ZM9 17C9 16.71 9.32 15 13 15C16.5 15 16.94 16.56 17 17M24 17V19H21V17C20.9766 16.2566 20.8054 15.5254 20.4964 14.8489C20.1873 14.1724 19.7466 13.5643 19.2 13.06C24 13.55 24 17 24 17ZM8 12H5V15H3V12H0V10H3V7H5V10H8V12Z" fill="black" fill-opacity="0.2"/>
<path d="M13 11C13.5933 11 14.1734 10.8241 14.6667 10.4944C15.1601 10.1648 15.5446 9.69623 15.7716 9.14805C15.9987 8.59987 16.0581 7.99667 15.9424 7.41473C15.8266 6.83279 15.5409 6.29824 15.1213 5.87868C14.7018 5.45912 14.1672 5.1734 13.5853 5.05765C13.0033 4.94189 12.4001 5.0013 11.8519 5.22836C11.3038 5.45543 10.8352 5.83994 10.5056 6.33329C10.1759 6.82664 10 7.40666 10 8C10 8.79565 10.3161 9.55871 10.8787 10.1213C11.4413 10.6839 12.2044 11 13 11ZM13 7C13.1978 7 13.3911 7.05865 13.5556 7.16853C13.72 7.27841 13.8482 7.43459 13.9239 7.61732C13.9996 7.80004 14.0194 8.00111 13.9808 8.19509C13.9422 8.38907 13.847 8.56726 13.7071 8.70711C13.5673 8.84696 13.3891 8.9422 13.1951 8.98079C13.0011 9.01937 12.8 8.99957 12.6173 8.92388C12.4346 8.84819 12.2784 8.72002 12.1685 8.55557C12.0586 8.39112 12 8.19778 12 8C12 7.73478 12.1054 7.48043 12.2929 7.29289C12.4804 7.10536 12.7348 7 13 7ZM17.11 10.86C17.6951 10.021 18.0087 9.02282 18.0087 8C18.0087 6.97718 17.6951 5.97897 17.11 5.14C17.3976 5.04726 17.6979 5.00002 18 5C18.7956 5 19.5587 5.31607 20.1213 5.87868C20.6839 6.44129 21 7.20435 21 8C21 8.79565 20.6839 9.55871 20.1213 10.1213C19.5587 10.6839 18.7956 11 18 11C17.6979 11 17.3976 10.9527 17.11 10.86ZM13 13C7 13 7 17 7 17V19H19V17C19 17 19 13 13 13ZM9 17C9 16.71 9.32 15 13 15C16.5 15 16.94 16.56 17 17M24 17V19H21V17C20.9766 16.2566 20.8054 15.5254 20.4964 14.8489C20.1873 14.1724 19.7466 13.5643 19.2 13.06C24 13.55 24 17 24 17ZM8 12H5V15H3V12H0V10H3V7H5V10H8V12Z" fill="black" fill-opacity="0.2"/>
<path d="M13 11C13.5933 11 14.1734 10.8241 14.6667 10.4944C15.1601 10.1648 15.5446 9.69623 15.7716 9.14805C15.9987 8.59987 16.0581 7.99667 15.9424 7.41473C15.8266 6.83279 15.5409 6.29824 15.1213 5.87868C14.7018 5.45912 14.1672 5.1734 13.5853 5.05765C13.0033 4.94189 12.4001 5.0013 11.8519 5.22836C11.3038 5.45543 10.8352 5.83994 10.5056 6.33329C10.1759 6.82664 10 7.40666 10 8C10 8.79565 10.3161 9.55871 10.8787 10.1213C11.4413 10.6839 12.2044 11 13 11ZM13 7C13.1978 7 13.3911 7.05865 13.5556 7.16853C13.72 7.27841 13.8482 7.43459 13.9239 7.61732C13.9996 7.80004 14.0194 8.00111 13.9808 8.19509C13.9422 8.38907 13.847 8.56726 13.7071 8.70711C13.5673 8.84696 13.3891 8.9422 13.1951 8.98079C13.0011 9.01937 12.8 8.99957 12.6173 8.92388C12.4346 8.84819 12.2784 8.72002 12.1685 8.55557C12.0586 8.39112 12 8.19778 12 8C12 7.73478 12.1054 7.48043 12.2929 7.29289C12.4804 7.10536 12.7348 7 13 7ZM17.11 10.86C17.6951 10.021 18.0087 9.02282 18.0087 8C18.0087 6.97718 17.6951 5.97897 17.11 5.14C17.3976 5.04726 17.6979 5.00002 18 5C18.7956 5 19.5587 5.31607 20.1213 5.87868C20.6839 6.44129 21 7.20435 21 8C21 8.79565 20.6839 9.55871 20.1213 10.1213C19.5587 10.6839 18.7956 11 18 11C17.6979 11 17.3976 10.9527 17.11 10.86ZM13 13C7 13 7 17 7 17V19H19V17C19 17 19 13 13 13ZM9 17C9 16.71 9.32 15 13 15C16.5 15 16.94 16.56 17 17M24 17V19H21V17C20.9766 16.2566 20.8054 15.5254 20.4964 14.8489C20.1873 14.1724 19.7466 13.5643 19.2 13.06C24 13.55 24 17 24 17ZM8 12H5V15H3V12H0V10H3V7H5V10H8V12Z" fill="black" fill-opacity="0.2"/>
</svg>
                    Add New
                  </button>

                  <button
                    onClick={() => navigate("/bulkupload/usermanagement")}
                    className="w-full text-left px-3 py-1.5 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="20" viewBox="0 0 24 24" fill="none">
<path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
</svg>
                    Bulk Upload
                  </button>

                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept=".xlsx,.xls"
                    onChange={handleBulkUpload}
                  />

                  <button
                    onClick={() => {
                      handleDownloadTemplate()
                      setIsOpen({ ...isOpen, action: false })
                    }}
                    className="w-full text-left py-1.5 px-3 hover:bg-lightBlue/50 text-xs text-black flex items-center gap-2 hover:rounded-b-lg"
                  >
                   <svg xmlns="http://www.w3.org/2000/svg" width="13" height="10" viewBox="0 0 13 16" fill="none">
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="#212121"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625M6.5 1H4.66667V6.5H2.375L6.5 10.625" fill="black" fill-opacity="0.2"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.5 1H8.33333V6.5H10.625L6.5 10.625L2.375 6.5H4.66667V1H6.5Z" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="#212121" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1 14.75H12" stroke="black" stroke-opacity="0.2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
                    Template File
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>


        {successMessage && (
          <SuccessMessage
            message={{
              title: "User Added Successfully",
              description: "They can now log in to the system using their email address.",
            }}
            onClose={() => setSuccessMessage("")}
          />
        )}

        <style>
          {`
            .hide-scrollbar::-webkit-scrollbar {
              display: none;
            }
          `}
        </style>

        {isMobileView ? (
          <div
            className={`overflow-y-auto hide-scrollbar ${showMobileFilters ? 'max-h-[calc(100vh-26rem)]' : 'max-h-[calc(100vh-14rem)]'}`}
            style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
          >
            <div className="space-y-3 pb-4">
              {filteredUsers.length > 0 ? (
                <>
                  {filteredUsers.map((user, index) => (
                    <MobileUserCard key={`${user.id}-${index}`} user={user} index={index} />
                  ))}
                </>
              ) : (
                <div className="bg-white border border-gray-200 rounded-lg p-6 text-center text-gray-500">
                  No data found.
                </div>
              )}
            </div>
          </div>
        ) : (
          
          <div className="flex-shrink overflow-hidden bg-white shadow-md border border-Dustyblue w-full relative z-10">
            <div
              ref={tableContainerRef}
              className="overflow-y-auto overflow-x-auto lg:overflow-x-hidden lg:max-h-[calc(100vh-14rem)] max-h-[calc(100vh-16rem)] hide-scrollbar"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
              onScroll={handleTableScroll}
            >
              <table className="w-full text-sm border-collapse table-fixed">
                <thead className="bg-Dustyblue text-white sticky top-0 z-20">
                  <tr>
                  <th
  onClick={() => handleSort("name")}
  className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[12%] cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    User

    {/* Not sorted yet → show neutral icon */}
    {sortKey !== "name" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

    {/* Sorted ASC */}
    {sortKey === "name" && sortOrder === "asc" && (
      <ChevronUp className="w-3 h-3 text-white" />
    )}

    {/* Sorted DESC */}
    {sortKey === "name" && sortOrder === "desc" && (
      <ChevronDown className="w-3 h-3 text-white" />
    )}
  </div>
</th>

                    <th
                      onClick={() => handleSort("email")}
                      className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[16%] cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-1">
                        Email ID
                        {sortKey === "email" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                        {sortKey === "email" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                      </div>
                    </th>

                    <th
                      onClick={() => handleSort("type")}
                      className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[9%] cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-1">
                        User Type
                        {sortKey === "type" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                        {sortKey === "type" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                      </div>
                    </th>

                    <th
                      onClick={() => handleSort("role")}
                      className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-b-0 font-medium w-[14%] cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-1">
                        User Role
                        {sortKey === "role" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                        {sortKey === "role" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                      </div>
                    </th>

                    <th
                      onClick={() => handleSort("marketArea")}
                      className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-1">
                        Market Area
                        {sortKey === "marketArea" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                        {sortKey === "marketArea" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                      </div>
                    </th>

                    <th
                      onClick={() => handleSort("dealership")}
                      className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[13%] cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-1">
                        Dealership
                        {sortKey === "dealership" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                        {sortKey === "dealership" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                      </div>
                    </th>

                    <th
                      onClick={() => handleSort("status")}
                      className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%] cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-1">
                        Status
                        {sortKey === "status" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
                        {sortKey === "status" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
                      </div>
                    </th>

                    <th className="py-1.5 px-2 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[6%]">
                      Login
                    </th>

                    <th className="py-1.5 px-2 text-center text-xs border border-grey2 border-b-0 border-r-0 border-t-0 font-medium w-[6%]">
                      Action
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {isLoadingdata && filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-6 text-center text-gray-500">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-5 w-5 border-gray-500"></div>
                          Loading...
                        </div>
                      </td>
                    </tr>
                  ) : sortedUsers.length > 0 ? (
                    <>
                      {sortedUsers.map((user, index) => (
                        <tr
                          key={`${user.id}-${index}`}
                          className={`hover:bg-lightBlue/50 transition duration-200 cursor-pointer ${index % 2 === 0 ? "bg-white" : ""
                            } ${user.status === "Active" || user.status === "New"
                              ? "text-black"
                              : "text-gray-400"
                            }`}
                        >
<td className="py-1 px-2 border border-grey2 border-t-0 border-l-0">
                            <div className="flex items-center gap-2">
                              <div className="flex flex-col min-w-0">
                                <div
                                  className="relative"
                                  onMouseEnter={() => setHoveredName(user.id)}
                                  onMouseLeave={() => setHoveredName(null)}
                                >
                                  <p className="font-semibold text-xs truncate max-w-[10rem]">
                                    {user.name.length > 30
                                      ? `${user.name.slice(0, 30)}...`
                                      : user.name}
                                  </p>
                                  {hoveredName === user.id && user.name.length > 20 && (
                                    <span className="absolute left-1/2 top-full mt-0 bg-SteelBlue1 text-white  text-[10px] px-2 py-0 whitespace-nowrap z-10">
                                      {user.name}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0 relative">
                            <div
                              ref={(el) => {
                                if (!el) return;
                                if (el.scrollWidth > el.clientWidth) {
                                  el.setAttribute("data-overflow", "true");
                                } else {
                                  el.removeAttribute("data-overflow");
                                }
                              }}
                              className="truncate"
                              onMouseEnter={(e) => {
                                if (e.currentTarget.getAttribute("data-overflow")) {
                                  setHoveredEmail(user.id);
                                }
                              }}
                              onMouseLeave={() => setHoveredEmail(null)}
                            >
                              {user.email}
                              {hoveredEmail === user.id && (
                                <span className="absolute left-1/2 top-full -mt-3 bg-SteelBlue1 text-white transform -translate-x-1/2 text-[10px] px-2 py-0 whitespace-nowrap z-10">
                                  {user.email}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0">{user.type}</td>
                          <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0">
                            <div className="relative">
                              <p
                                className="truncate max-w-[9rem]"
                                onMouseEnter={(e) => {
                                  if (e.currentTarget.scrollWidth > e.currentTarget.clientWidth) {
                                    setHoveredRole(user.id);
                                  }
                                }}
                                onMouseLeave={() => setHoveredRole(null)}
                              >
                                {user.role}
                              </p>

                              {hoveredRole === user.id && (
                                <span className="absolute left-1/2 top-full bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                                  {user.role}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0">
                            <div className="relative">
                              <p
                                className="truncate max-w-[8rem]"
                                onMouseEnter={(e) => {
                                  if (e.currentTarget.scrollWidth > e.currentTarget.clientWidth) {
                                    setHoveredMarket(user.id);
                                  }
                                }}
                                onMouseLeave={() => setHoveredMarket(null)}
                              >
                                {user.marketArea}
                              </p>

                              {hoveredMarket === user.id && (
                                <span className="absolute left-1/2 top-full bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
                                  {user.marketArea}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0">
                            {user?.dealership && typeof user.dealership === "string" ? (
                              (expandedRow === user.id
                                ? user.dealership.split(",")
                                : user.dealership.split(",").slice(0, 2)
                              ).map((d, i, arr) => (
                                <div key={i} className="flex items-center gap-1">
                                  <span className="truncate">{d.trim()}</span>
                                  {i === arr.length - 1 &&
                                    user.dealership.split(",").length > 2 && (
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation()
                                          toggleExpand(user.id)
                                        }}
                                        className="flex items-center text-blue-600 hover:text-blue-800 text-xs"
                                      >
                                        {expandedRow === user.id ? (
                                          <ChevronUp className="w-3 h-3" />
                                        ) : (
                                          <ChevronDown className="w-3 h-3" />
                                        )}
                                      </button>
                                    )}
                                </div>
                              ))
                            ) : (
                              <span className="text-gray-500">-</span>
                            )}
                          </td>

                          <td className="py-1 px-2 border border-grey2 border-t-0 border-l-0">
                            <div className="flex items-center gap-1 text-xs">
                              {statusConfig[user.status] && (
                                <>
                                  <span
                                    className={`w-2 h-2 rounded-full flex-shrink-0 ${
                                      user.status === "Active"
                                        ? "bg-green"
                                        : user.status === "Inactive"
                                        ? "bg-red1"
                                        : user.status === "New"
                                        ? "bg-SteelBlue1"
                                        : "bg-gray-400"
                                    }`}
                                  />
                                  <span
                                    className={`${
                                      user.status === "New" ? "text-SteelBlue1" : statusConfig[user.status].textColor
                                    }`}
                                  >
                                    {user.status}
                                  </span>
                                </>
                              )}
                            </div>
                          </td>

                          <td className="py-1 px-2 text-center border border-grey2 border-t-0 border-l-0">
                            <div className="relative flex justify-center">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleLogin(user);
                                }}
                                className="p-1 hover:bg-white transition relative"
                                onMouseEnter={() => setHoveredLogin(user.id)}
                                onMouseLeave={() => setHoveredLogin(null)}
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 32 32" fill="none">
                                  <rect x="0.5" y="0.5" width="31" height="31" rx="4.5" stroke="#E1E1E1"/>
                                  <g clipPath="url(#clip0_5669_1242)">
                                    <path d="M15 11L13.6 12.4L16.2 15H6V17H16.2L13.6 19.6L15 21L20 16L15 11ZM24 23H16V25H24C25.1 25 26 24.1 26 23V9C26 7.9 25.1 7 24 7H16V9H24V23Z" fill="#212121"/>
                                  </g>
                                </svg>

                                {hoveredLogin === user.id && (
                                  <span className="absolute top-[110%] left-1/2 -translate-x-1/2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap z-10">
                                    Login
                                  </span>
                                )}
                              </button>
                            </div>
                          </td>

                          <td className="relative text-center py-1 px-2 border border-grey2 border-t-0 border-l-0 border-r-0 dropdown-cell">
                            <div className="relative flex justify-center">
                              <button
                                ref={(el) => {
                                  if (el) dropdownRefs.current[user.id] = el;
                                }}
                              onClick={(e) => {
  e.stopPropagation();

  if (isSmallTable) {
    const rect = e.currentTarget.getBoundingClientRect();

    setDropdownPosition({
      top: rect.bottom + 4,
      left: rect.left - 160,
    });
  }

  setIsOpen(isOpen === user.id.toString() ? "" : user.id.toString());
  setCurrentUser(user);
}}
                                className="group relative w-5 h-5 flex items-center justify-center hover:bg-white transition"
                              >
                                <span className="text-lg font-bold leading-none">⋮</span>
                                <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                                  Actions
                                </span>
                              </button>

                              {isOpen === user.id.toString() && (
<ul
  className={`w-48 bg-white border border-gray-300 shadow-lg text-xs text-black max-h-64 overflow-y-auto z-10
  ${isSmallTable ? "fixed" : "absolute right-0"}
  ${
    !isSmallTable
      ? getDropdownClasses(user.id).split(" ").slice(-2).join(" ")
      : ""
  }`}
  style={
    isSmallTable
      ? {
          top: dropdownPosition.top,
          left: dropdownPosition.left,
        }
      : {}
  }
>                                  {[
                                    {
                                      label: "View",
                                      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/view.png",
                                      onClick: () => {
                                        setIsOpen("")
                                        handleView(user)
                                      },
                                    },
                                    {
                                      label: "Edit",
                                      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/edit.png",
                                      onClick: () => {
                                        setIsEdituserOpen(true)
                                        setIsOpen("")
                                      },
                                    },
                                    {
                                      label:
                                        user.status === "Active"
                                          ? "Deactivate User"
                                          : "Activate User",
                                      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/toggleuser.png",
                                      onClick: () => {
                                        setCurrentUser(user)
                                        setIsOpen("")
                                        if (user.status === "Active") setIsDeactivateOpen(true)
                                        else setIsActivateOpen(true)
                                      },
                                    },
                                    {
                                      label: "Show History",
                                      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/showhistory.png",
                                      onClick: () => {
                                        setSelectedUser(user)
                                        setShowHistoryPopup(true)
                                        setIsOpen("")
                                      },
                                    },
                                    ...(user.status === "Inactive"
                                      ? [
                                        {
                                          label: "Send Activation Email",
                                          icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/email.png",
                                          onClick: () => {
                                            setCurrentUser(user)
                                            setIsActivationemailOpen(true)
                                            setIsOpen("")
                                          },
                                        },
                                      ]
                                      : []),
                                    {
                                      label: "Delete",
                                      icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/delete.png",
                                      onClick: () => {
                                        setCurrentUser(user)
                                        setIsDeleteuserOpen(true)
                                        setIsOpen("")
                                      },
                                    },
                                  ].map((item, idx) => (
                                    <li
                                      key={idx}
                                      className="flex items-center gap-2 py-1.5 px-3 hover:bg-lightBlue cursor-pointer whitespace-nowrap"
                                      onClick={(e) => {
                                        e.stopPropagation()
                                        item.onClick()
                                      }}
                                    >
                                      <span>{item.label}</span>
                                    </li>
                                  ))}
                                </ul>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </>
                  ) : (
                    <tr>
                      <td colSpan={9} className="text-center py-4 text-gray-500 italic">
                        No data found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
              {showScrollButtons && (
            <div className="fixed bottom-10 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}
            </div>
          </div>
        )}

      <AddUser
  isAddUserOpen={isAddUserOpen || isedituserOpen}
  headerStatus={isAddUserOpen}
  onClose={() => {
    setIsAddUserOpen(false);
    setIsEdituserOpen(false); 
  }}
  onSave={isedituserOpen ? handleEditUser : handleAddUser}
  user={isedituserOpen ? currentUser : null}
  onUserAdded={afterAddUser}
/>
        {showHistoryPopup && (
          <ShowHistoryUserdetails
            user={{ ...selectedUser, id: currentUser?.id }}
            onClose={() => setShowHistoryPopup(false)}
          />
        )}

        {isActivationemailOpen && (
          <ActivationEmail
            isactivationemailOpen={isActivationemailOpen}
            user={currentUser}
            onConfirm={handleSendActivationEmail}
            onCancel={() => setIsActivationemailOpen(false)}
            emailLoading={emailLoading}
          />
        )}

        {DeactiveemailOpen && (
          <TemporaryDeactive
            isOpen={DeactiveemailOpen}
            user={currentUser}
            onConfirm={handleSendDeactivationEmail}
            onCancel={() => setIsDeactivemailOpen(false)}
          />
        )}

        {successemailMessage && (
          <SuccessMessage
            message={successemailMessage}
            onClose={() => setSuccessemailMessage(null)}
          />
        )}

        <ActivateStatus
          isOpen={isActivateOpen}
          loading={toggleLoading}
          onClose={() => {
            if (!toggleLoading) setIsActivateOpen(false)
          }}
          onConfirm={() => toggleUserStatus(currentUser?.id, "ACTIVE")}
        />

        <DeactivateStatus
          isOpen={isDeactivateOpen}
          loading={toggleLoading}
          onClose={() => {
            if (!toggleLoading) setIsDeactivateOpen(false)
          }}
          onConfirm={() => toggleUserStatus(currentUser?.id, "INACTIVE")}
        />

        <DeleteModal
          isOpen={isDeleteuserOpen}
          loading={toggleLoading}
          onClose={() => {
            if (!toggleLoading) setIsDeleteuserOpen(false)
          }}
          onConfirm={() => handleDelete()}
        />
      </div>
    </div>
  )
}

export default UserManagement