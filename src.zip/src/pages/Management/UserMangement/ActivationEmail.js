import React from "react";

const ActivationEmail = ({ isactivationemailOpen, user, onConfirm, onCancel, emailLoading }) => {
  if (!isactivationemailOpen) return null;

const fullName = [user?.firstName, user?.middleName, user?.lastName]
  .filter(Boolean)
  .join(" ") || user?.name || "this user";

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 px-4">
      <div className="bg-white p-4 sm:p-6  shadow-lg w-full max-w-sm sm:max-w-lg relative border-l-8 border-green">
        <p className="text-xs  font-medium font-VolvoNovum text-black mb-6 text-center leading-snug">
          Would you like to send an activation email to{" "}
          <span className="font-semibold">{fullName || "this user"}</span>?
        </p>

        <div className="flex flex-row flex-nowrap justify-center gap-4">
          <button
            onClick={onCancel}
            disabled={emailLoading}
            className={`px-6 py-1.5 border-2 text-xs font-bold border-red2 text-red bg-white  hover:bg-red2 hover:shadow-md hover:scale-105 transition duration-200 ${
              emailLoading ? "opacity-50 cursor-not-allowed" : ""
            }`}
          >
            No
          </button>
          <button
            onClick={onConfirm}
            disabled={emailLoading}
            className={`px-6 py-1.5 bg-green4 text-green5 text-xs border-2 border-transparent font-bold font-VolvoNovum  hover:bg-white hover:border-green4 hover:shadow-md hover:scale-105 transition duration-200 ${
              emailLoading ? "opacity-50 cursor-not-allowed" : ""
            }`}
          >
            {emailLoading ? "Sending..." : "Yes"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActivationEmail;
