import React from "react";

const Table = ({ currentRecords, handleView, colors, textColor }) => {
  return (
    <div className="bg-white shadow-lg rounded-lg border border-green1 overflow-hidden">
      <table className="w-full table-fixed border-collapse">
        <thead className="bg-green1 text-green2">
          <tr>
            <th className="pl-20 px-4 py-3 text-left w-[20%]">User</th>
            <th className="pl-20 py-3 text-left w-[20%]">User Role</th>
            <th className="pl-20 py-3 text-left w-[20%]">Market Area</th>
            <th className="pl-20 py-3 text-left w-[20%]">Dealership</th>
            <th className="pl-20 py-3 text-left w-[20%]">Status</th>
            <th className="pl-20 py-3 text-left w-[20%]">Login</th>
            <th className="pl-20 py-3 text-left w-[20%]">View</th>
          </tr>
        </thead>
        <tbody>
          {currentRecords.map((user, index) => (
            <tr
              key={user.id}
              className="border-b hover:bg-lightGrey transition duration-300"
              onClick={handleView}
            >
              <td className="px-5 py-3 flex items-center gap-3">
                <div
                  className={`px-5 flex items-center justify-center rounded-lg w-10 h-10 text-sm font-semibold hover:bg-opacity-80 transition duration-300 ${colors[index % colors.length]} ${textColor[index % textColor.length]}`}
                >
                  {user.initials}
                </div>
                <div>
                  <p className="font-semibold text-sm">{user.name}</p>
                  <p className="text-xs text-gray-500">{user.email}</p>
                </div>
              </td>
              <td className="pl-10 px-0 py-3 text-sm text-left font-normal">
                <div className={`flex items-center justify-center rounded-lg py-2 px-4 text-sm font-semibold hover:bg-opacity-80 transition duration-300 shadow-sm ${colors[index % colors.length]} ${textColor[index % textColor.length]} w-auto max-w-[180px] text-center break-words`}>
                  {user.role.replace(/-/g, " ").replace(/\b\w/g, (char) => char.toUpperCase())}
                </div>
              </td>
              <td className="py-3 pr-10 text-sm text-right font-normal">{user.area}</td>
              <td className="pr-15 py-3 text-sm text-right font-normal">
                {(user?.dealership && typeof user.dealership === "string"
                  ? user.dealership.split(",")
                  : ["N/A"]
                ).map((dealership, idx) => (
                  <span key={idx} className={`px-2 py-0 rounded-md ${idx === 0 ? "bg-lightGrey" : ""}`}>
                    {dealership.trim()}
                    {idx !== user.dealership.split(",").length - 1 && <br />}
                  </span>
                ))}
              </td>
              <td className="pr-6 py-3 text-sm text-right flex items-center justify-end gap-0">
                <img src={user.status === "Active" ? "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Ellipse 13.png" : "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Ellipse 12.png"} alt={user.status} className="w-2 h-2" />
                <span className={`px-3 py-1 rounded-full ${user.status === "Active" ? " text-green" : " text-red"}`}>{user.status}</span>
              </td>
              <td className="pr-20 py-3 text-right">
                <button className="text-blue-600 font-medium">
                  <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Frame 6393 (1).png" alt="login" className="w-5 h-5 hover:bg-lightBlue transition duration-300" />
                </button>
              </td>
              <td className="pr-20 py-3 text-right">
                <button className="text-blue-600 font-medium" onClick={handleView}>
                  <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Frame 6409.png" alt="view" className="w-5 h-5 hover:bg-lightBlue transition duration-300" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
