import React, { useState } from "react";
import Header from "../../../Components/Header";
import UserDetailscontent from "./UserDetailscontent";
import SubNavbar3 from "../../../Components/SubNavbar3";

function UserDetails() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
<div className="bg-Frostwhite min-h-screen flex flex-col">      {/* Navigation Bar */}
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
<SubNavbar3/>
      {/* Main Content - Moves Right when Sidebar Opens */}
      {/* <div className={`transition-all duration-300 ${menuOpen ? "ml-60" : "ml-0"} mt-[-10px] p-4`}> */}
      <div
        className={`
          transition-all duration-300
          ${menuOpen ? "lg:ml-60" : ""}
          flex justify-center
          flex-1
        `}
      >
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">

    <UserDetailscontent />
  </div>
</div>
</div>
        
  );
}

export default UserDetails;
