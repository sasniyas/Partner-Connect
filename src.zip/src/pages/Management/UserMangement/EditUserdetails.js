

"use client"

import { useState, useEffect, useRef } from "react"
import axios from "axios"
import { useNavigate } from "react-router-dom"
import { API } from '../../../api';
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation";

const EditUserdetails = ({ isOpen, onClose, onSave, user,userId, }) => {
  const navigate = useNavigate()

  // -------------------- STATE --------------------
  const [firstName, setFirstName] = useState("")
  const [middleName, setMiddleName] = useState("")
  const [lastName, setLastName] = useState("")
  const [email, setEmail] = useState("")
  const [selectedType, setSelectedType] = useState("")
  const [selectedRole, setSelectedRole] = useState("")
  const [selectedRoleId, setSelectedRoleId] = useState("")
  const [selectedMarketArea, setSelectedMarketArea] = useState("")
  const [selectedDealerships, setSelectedDealerships] = useState([])
  const [location, setLocation] = useState("")
  const [errors, setErrors] = useState({})
  const [rolesList, setRolesList] = useState([])
  const [marketAreas, setMarketAreas] = useState([])
  const [dealerships, setDealerships] = useState([])
  const [isSaving, setIsSaving] = useState(false)
  const [searchTerm,setSearchTerm] = useState ()
  const [locationSearch,setLocationSearch] =useState ()
  const [roleSearch,setRoleSearch] = useState ()
  const [marketAreaSearch,setMarketAreaSearch] = useState ("")
  const [dealershipSearch,setDealershipSearch] = useState ("")
    const popupRef = useRef()

  // Dropdown state & refs
  const [isTypeDropdownOpen, setIsTypeDropdownOpen] = useState(false)
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false)
  const [isMarketAreaDropdownOpen, setIsMarketAreaDropdownOpen] = useState(false)
  const [isDealershipDropdownOpen, setIsDealershipDropdownOpen] = useState(false)
  const [isLocationDropdownOpen, setIsLocationDropdownOpen] = useState(false)
const locationListRef = useRef(null);
  const typeRef = useRef(null)
  const roleRef = useRef(null)
  const marketAreaRef = useRef(null)
  const dealershipRef = useRef(null)
  const locationRef = useRef(null)
const roleListRef = useRef(null);
const dealershipListRef = useRef(null);
const marketAreaListRef = useRef(null);
  const types = [
    { value: "dealer-user", label: "Dealer User" },
    { value: "volvo-user", label: "Volvo User" },
  ]

  const locations = [
    { value: "Region", label: "Region" },
    { value: "Head Quarter", label: "Head Quarter" },
  ]

  // -------------------- STATE --------------------
  const [userHasMarketAreaData, setUserHasMarketAreaData] = useState(false)
  const [userHasDealershipData, setUserHasDealershipData] = useState(false)
const validateLastName = (value) => {
  if (!value.trim()) return "Last Name is required";

  if (value.startsWith(" ")) return "Cannot start with space";

  if (value.endsWith(" ")) return "Cannot end with space";

  if (value.includes("  ")) return "Only single space allowed";

  if (!/^[A-Za-z]+( [A-Za-z]+)*$/.test(value))
    return "Only alphabets allowed";

  return "";
};
  // -------------------- FETCH DATA --------------------
  useEffect(() => {
    if (!isOpen) return

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) return navigate("/")

    const fetchRoles = async () => {
      try {
        const res = await axios.get(
         `${API.domain}${API.userManagement.getRoles}`,
          { headers: { Authorization: `Bearer ${token}` } },
        )
        if (res.data.status) setRolesList(res.data.data.map((r) => ({label:r.userRole,id:r.id})))
               
      } catch (err) {
              const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
      }
    }

    const fetchMarketAreas = async () => {
      try {
        const res = await axios.get(
           `${API.domain}${API.userManagement.getMarketarea}`,
          { headers: { Authorization: `Bearer ${token}` } },
        )
        if (res.data.status) {
          const activeMA = res.data.data.filter((ma) => ma.isActive === 1)
          setMarketAreas(activeMA)
        }
      } catch (err) {
             const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
      }
    }

    const fetchDealers = async () => {
      try {
        const res = await axios.get(
           `${API.domain}${API.userManagement.getDealers}`,
          { headers: { Authorization: `Bearer ${token}` } },
        )
        if (res.data.status) setDealerships(res.data.data.filter((d) => d.isActive === 1))
      } catch (err) {
              const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
      }
    }

    fetchRoles()
    fetchMarketAreas()
    fetchDealers()
  }, [isOpen, navigate])

  useEffect(() => {
    // Only prefill when modal is open, user exists, and all required data is loaded
    if (!isOpen || !user) return

    console.log("[v0] Prefilling user data:", user)
    console.log("[v0] User location value:", user.location)

    // Basic fields can be set immediately
    setFirstName(user.firstName || "")
    setMiddleName(user.middleName || "")
    setLastName(user.lastName || "")
    setEmail(user.email || "")

    setUserHasMarketAreaData(!!user.area || !!user.marketAreaId)
    setUserHasDealershipData(!!user.dealership || (user.dealers && user.dealers.length > 0))

    // Set type based on user role
    const userType = user.type?.toLowerCase() === "dealer user" ? "dealer-user" : "volvo-user"
    setSelectedType(userType)

    if (user.location) {
      // Normalize the location string by removing spaces, underscores, hyphens and converting to lowercase
      const locationNormalized = user.location.toLowerCase().replace(/[_\s-]/g, "")

      console.log("[v0] Normalized location:", locationNormalized)

      // Check if it matches "headquarter" or "region"
      let mappedLocation = ""
      if (
        locationNormalized.includes("headquarter") ||
        locationNormalized.includes("headoffice") ||
        locationNormalized.includes("hq")
      ) {
        mappedLocation = "Head Quarter"
      } else if (locationNormalized.includes("region")) {
        mappedLocation = "Region"
      } else {
        // If no match, try to match exactly with our location options
        const exactMatch = locations.find(
          (loc) => loc.value.toLowerCase().replace(/[_\s-]/g, "") === locationNormalized,
        )
        mappedLocation = exactMatch ? exactMatch.value : ""
      }

      console.log("[v0] Setting location to:", mappedLocation)
      setLocation(mappedLocation)
    } else {
      console.log("[v0] No location found in user data")
    }

    // Set role if rolesList is loaded
    if (rolesList.length > 0 && user.userrole) {
      setSelectedRole(user.userrole)
       setSelectedRoleId(user.userroleId)
    }

    // Set market area if marketAreas is loaded
    if (marketAreas.length > 0 && user.area) {
      const matchedMA = marketAreas.find((ma) => ma.marketarea?.toLowerCase() === user.area?.toLowerCase())
      if (matchedMA) {
        setSelectedMarketArea(matchedMA.id)
      }
    }

    // Set dealerships if dealerships data is loaded
    if (dealerships.length > 0 && user.dealership) {
      // Parse dealership string (e.g., "ALPINA DL, ALPINA UP")
      const dealershipNames = user.dealership.split(",").map((d) => d.trim())
      // Find matching dealer IDs
      const matchedDealerIds = dealershipNames
        .map((name) => {
          const dealer = dealerships.find(
            (d) =>
              d.dealerShortName?.toLowerCase() === name.toLowerCase() ||
              d.dealerName?.toLowerCase() === name.toLowerCase(),
          )
          return dealer?.id
        })
        .filter(Boolean)
      setSelectedDealerships(matchedDealerIds)
    }
  }, [isOpen, user, rolesList, marketAreas, dealerships])

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (typeRef.current && !typeRef.current.contains(event.target)) setIsTypeDropdownOpen(false)
      if (roleRef.current && !roleRef.current.contains(event.target)) {setIsRoleDropdownOpen(false)
        setRoleSearch("")
      }
      if (marketAreaRef.current && !marketAreaRef.current.contains(event.target)) {setIsMarketAreaDropdownOpen(false)
        setMarketAreaSearch("")
      }
      if (dealershipRef.current && !dealershipRef.current.contains(event.target)) {setIsDealershipDropdownOpen(false) 
        setDealershipSearch("") }
      if (locationRef.current && !locationRef.current.contains(event.target)) setIsLocationDropdownOpen(false)
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // -------------------- SAVE HANDLER --------------------
  const handleSubmit = async (e) => {
  e.preventDefault();

  const newErrors = {};
  if (!firstName.trim()) newErrors.firstName = "Please fill out this field";
  if (!lastName.trim()) newErrors.lastName = "Please fill out this field";
  if (!email.trim()) newErrors.email = "Please fill out this field";
  if (!selectedType) newErrors.selectedType = "Please fill out this field";
  if (selectedType === "volvo-user" && !location) newErrors.location = "Please fill out this field";
  if (!selectedRole) newErrors.selectedRole = "Please fill out this field";

  setErrors(newErrors);
  if (Object.keys(newErrors).length > 0) return;

  try {
    setIsSaving(true);

    // Fetch all users to check for duplicates
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) return navigate("/");

    const usersRes = await axios.get(
       `${API.domain}${API.userManagement.getAllUsers}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );

    const users = usersRes.data?.status ? usersRes.data.data : [];
    const emailExists = users.some(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.id !== userId
    );

    if (emailExists) {
      setErrors((prev) => ({ ...prev, email: "This email already exists" }));
      return;
    }

    const payload = {
      id: userId,
      firstName,
      middleName,
      lastName,
      email,
      role: selectedType === "volvo-user" ? "VOLVO_USER" : "DEALER_USER",
      locationType: location === "Region" ? "REGION" : "HEAD_QUARTER",
      persona: selectedRole,
      personaId: selectedRoleId,
      marketAreaId: selectedMarketArea || null,
      dealers: selectedDealerships,
    };
    console.log(payload)

    const res = await axios.put(
     `${API.domain}${API.userManagement.updateUser}`,
      payload,
      { headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` } }
    );

    if (res?.data?.status) {
      onSave();
      onClose();
    } else {
      alert(res?.data?.message || "Failed to save user");
    }
  } catch (err) {
       const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
  } finally {
    setIsSaving(false);
  }
};
useKeyboardNavigation({
  containerRef: popupRef,

  onSubmit: () => {
    popupRef.current?.querySelector("form")?.requestSubmit();
  },

  onCancel: () => {
    onClose();
  },

  enableArrowNavigation: true,
  enableEnterSubmit: true,
});


  if (!isOpen) return null

  // -------------------- RENDER --------------------
  const shouldShowMarketAreaAndDealership = () => {
    // Always show for dealer users
    if (selectedType === "dealer-user") return true

    // Show for volvo users in Region location
    if (selectedType === "volvo-user" && location === "Region") return true

    // Show if user originally had this data (even if role doesn't require it)
    if (userHasMarketAreaData || userHasDealershipData) return true

    return false
  }

  const showFields = shouldShowMarketAreaAndDealership()

  return (
    <div 
     ref={popupRef}
    className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 px-2">
      <div className="bg-white p-4 sm:p-6 shadow-lg w-full sm:w-[90%] md:w-[75%] lg:w-[60%] xl:w-[45%] max-w-4xl relative">
        <button
          className="absolute top-3 right-3 w-5 h-5 flex items-center justify-center rounded-full bg-red1 hover:scale-110"
          onClick={onClose}
          aria-label="Close"
        >
          <svg width="12" height="12" viewBox="0 0 20 20">
            <circle cx="8" cy="8" r="8" fill="#BF2012" />
            <path d="M6.5 6.5L13.5 13.5M13.5 6.5L6.5 13.5" stroke="white" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>

        <h2 className="text-base font-semibold text-MediumGrey mb-2 text-center">
          Edit {firstName} {middleName && middleName + " "} {lastName}
        </h2>

        <form className="space-y-4 cursor-pointer" onSubmit={handleSubmit}>
          {/* Name Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <input
                type="text"
                placeholder="First Name *"
                value={firstName}
                 maxLength={15}
                onChange={(e) => {
                  setFirstName(e.target.value)
                  if (errors.firstName) setErrors((prev) => ({ ...prev, firstName: null }))
                }}
                className={`w-full border text-black text-xs  px-3 py-1.5 hover:border-2 focus:outline-none focus:border-2 ${
                  errors.firstName ? "border-red1" : "border-black/60"
                }`}
              />
              {errors.firstName && <p className="text-red1 text-xs mt-1">{errors.firstName}</p>}
            </div>
            <input
              type="text"
              placeholder="Middle Name"
              value={middleName}
              onChange={(e) => setMiddleName(e.target.value)}
              className="w-full border border-black/60 text-black text-xs  px-3 py-1.5 hover:border-2 focus:outline-none focus:border-2"
            />
<div>
  <input
    type="text"
    placeholder="Last Name *"
    value={lastName}
    maxLength={15}
    onChange={(e) => {
      const value = e.target.value;
      setLastName(value);

      const errorMsg = validateLastName(value);
      setErrors((prev) => ({ ...prev, lastName: errorMsg }));
    }}
    onBlur={() => {
      const trimmed = lastName.trim();
      setLastName(trimmed);

      const errorMsg = validateLastName(trimmed);
      setErrors((prev) => ({ ...prev, lastName: errorMsg }));
    }}
    className={`w-full border text-black text-xs px-3 py-1.5 hover:border-2 focus:outline-none focus:border-2 ${
      errors.lastName ? "border-red1" : "border-black/60"
    }`}
  />

  {errors.lastName && (
    <p className="text-red1 text-xs mt-1">{errors.lastName}</p>
  )}
</div>
          </div>

          {/* Email */}
          <div>
            <input
              type="email"
              placeholder="Email ID *"
              value={email}
                 maxLength={75-100}
              onChange={(e) => {
                setEmail(e.target.value)
                if (errors.email) setErrors((prev) => ({ ...prev, email: null }))
              }}
              className={`w-full border text-black text-xs  px-3 py-1.5 hover:border-2 focus:outline-none focus:border-2 ${
                errors.email ? "border-red1" : "border-black/60"
              }`}
            />
            {errors.email && <p className="text-red1 text-xs mt-1">{errors.email}</p>}
          </div>

          {/* User Type */}
          <div className="relative w-full" ref={typeRef}>
            <div
              className={`w-full border  px-3 py-1.5 pr-10 text-xs cursor-pointer transition-all duration-200 ${
                isTypeDropdownOpen
                  ? `${errors.selectedType ? "border-red1" : "border-black/60"} text-black border-b-white `
                  : `${errors.selectedType ? "border-red1" : "border-black/60"} hover:border-2 focus:outline-none focus:border-2`
              }`}
              onClick={() => setIsTypeDropdownOpen((v) => !v)}
               tabIndex={0}
                onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setIsTypeDropdownOpen(true)
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setIsTypeDropdownOpen(false)
    }

  }} 
            >
              {selectedType ? types.find((t) => t.value === selectedType)?.label : "Select User Type *"}
            </div>
           
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"
            className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-3 h-3 transition-transform duration-200 ${
                isTypeDropdownOpen ? "rotate-180" : "rotate-0"
              }`}
              onClick={() => setIsTypeDropdownOpen((v) => !v)}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>
             {isTypeDropdownOpen && (
  <ul className="absolute w-full bg-white border border-black/60 border-t-white mt-0 max-h-52 overflow-auto shadow-md z-50">
    
    {/* Show search only if more than 5 options */}
    {types.length > 5 && (
           <li className="sticky top-0 bg-white px-3 py-1.5  z-10">
        <input
          type="text"
          placeholder="Search types..."
          value={searchTerm} // you need a state like: const [searchTerm, setSearchTerm] = useState("")
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </li>
    )}

    {/* Filter, sort, and display options */}
    {types
      .filter((type) => type.value !== selectedType) // hide already selected
      .filter((type) =>
        !searchTerm ? true : type.label.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .sort((a, b) => a.label.localeCompare(b.label)) // sort alphabetically
      .map((type) => (
       <li
  key={type.value}
  tabIndex={0}
  className="px-3 py-1.5 hover:bg-lightBlue cursor-pointer text-xs"
  onKeyDown={(e) => {
    const items = Array.from(
      e.currentTarget.parentElement.querySelectorAll("li[tabindex]")
    );
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setIsTypeDropdownOpen(false)
    }

    if (e.key === "Enter") {
      e.preventDefault();
      setSelectedType(type.value);
      setSelectedRole("");
      setSelectedRoleId("");
      e.stopPropagation();   
      setLocation("");
      setIsTypeDropdownOpen(false);
      setErrors((prev) => ({
        ...prev,
        selectedType: "",
        selectedRole: "",
        location: "",
      }));
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setSelectedType(type.value);
    setSelectedRole("");
    setSelectedRoleId("");
    setLocation("");
    setIsTypeDropdownOpen(false);
    setErrors((prev) => ({
      ...prev,
      selectedType: "",
      selectedRole: "",
      location: "",
    }));
  }}
>
  {type.label}
</li>
      ))}
    
    {/* No results message */}
    {types.filter(
      (type) =>
        type.value !== selectedType &&
        (!searchTerm || type.label.toLowerCase().includes(searchTerm.toLowerCase()))
    ).length === 0 && (
      <li className="px-3 py-1.5 text-xs text-gray-500">No results found</li>
    )}
  </ul>
)}

            {errors.selectedType && <p className="text-red1 text-xs mt-1">{errors.selectedType}</p>}
          </div>

          {/* Location for Volvo User */}
          {selectedType === "volvo-user" && (
            <div className="relative w-full" ref={locationRef}>
             <div
  className={`w-full border  px-3 py-1.5 pr-10 text-xs cursor-pointer transition-all duration-200 ${
    isLocationDropdownOpen
      ? `${errors.location ? "border-red1" : "border-black/60"} text-black border-b-white `
      : `${errors.location ? "border-red1" : "border-black/60"} hover:border-2 focus:outline-none focus:border-2`
  }`}
  onClick={() => setIsLocationDropdownOpen((v) => !v)}
   tabIndex={0}
    onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
     setIsLocationDropdownOpen(true)
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setIsLocationDropdownOpen(false)
    }

  }} 
>
  {location || "Select Location"}
</div>

              {/* <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Vector (25).png"
                alt="Dropdown Icon"
                className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-3 h-3 transition-transform duration-200 ${
                  isLocationDropdownOpen ? "rotate-180" : "rotate-0"
                  
                }`}
                              onClick={() => setIsLocationDropdownOpen((v) => !v)}

              /> */}
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"
              className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-3 h-3 transition-transform duration-200 ${
                  isLocationDropdownOpen ? "rotate-180" : "rotate-0"
                  
                }`}
                              onClick={() => setIsLocationDropdownOpen((v) => !v)}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>
             {isLocationDropdownOpen && (
  <ul 
   ref={locationListRef}
  className="absolute w-full bg-white border border-black/60 border-t-white mt-0 max-h-52 overflow-auto shadow-md z-50">
    
    {/* Show search input only if options > 5 */}
    {["Headquarters", "Region"].length > 5 && (
      <li className="px-3 py-1.5">
        <input
          type="text"
          placeholder="Search locations..."
          value={locationSearch} // add a state: const [locationSearch, setLocationSearch] = useState("")
          onChange={(e) => setLocationSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30  outline-none"
          autoFocus
        />
      </li>
    )}

    {/* Filter, sort, and map options */}
    {["Headquarters", "Region"]
      .filter((loc) => loc !== location) // hide already selected
      .filter((loc) =>
        !locationSearch ? true : loc.toLowerCase().includes(locationSearch.toLowerCase())
      )
      .sort((a, b) => a.localeCompare(b)) // sort alphabetically
      .map((loc) => (
        <li
  tabIndex={0}
  key={loc}
  className="px-3 py-1.5 hover:bg-lightBlue cursor-pointer text-xs"
  onKeyDown={(e) => {
    const items = Array.from(
      locationListRef.current.querySelectorAll("li[tabindex]")
    );
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setIsLocationDropdownOpen(false)
    }

    if (e.key === "Enter") {
      e.preventDefault();
      setLocation(loc);
      setSelectedRole("");
      setSelectedRoleId("");
      e.stopPropagation();   
      setIsLocationDropdownOpen(false);
      setErrors((prev) => ({
        ...prev,
        location: "",
        selectedRole: "",
      }));
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setLocation(loc);
    setSelectedRole("");
    setSelectedRoleId("");
    setIsLocationDropdownOpen(false);
    setErrors((prev) => ({
      ...prev,
      location: "",
      selectedRole: "",
    }));
  }}
>
  {loc}
</li>
      ))}

    {/* No results message */}
    {["Head Quarter", "Region"]
      .filter((loc) => loc !== location)
      .filter((loc) =>
        !locationSearch ? true : loc.toLowerCase().includes(locationSearch.toLowerCase())
      ).length === 0 && (
        <li className="px-3 py-1.5 text-xs text-gray-500">No results found</li>
      )}
  </ul>
)}
              {errors.location && <p className="text-red1 text-xs mt-1">{errors.location}</p>}
            </div>
          )}

          {/* User Role */}
          <div className="relative w-full" ref={roleRef}>
            <div
              className={`w-full border  px-3 py-1.5 pr-10 text-xs cursor-pointer transition-all duration-200 ${
                isRoleDropdownOpen
                  ? `${errors.selectedRole ? "border-red1" : "border-black/60"} text-black border-b-white`
                  : `${errors.selectedRole ? "border-red1" : "border-black/60"} hover:border-2 focus:outline-none focus:border-2`
              } ${!selectedType ? "opacity-50 cursor-not-allowed" : ""}`}
              onClick={() => selectedType && setIsRoleDropdownOpen((v) => !v)}
               tabIndex={0}
                onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setIsRoleDropdownOpen(true)
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
     setIsRoleDropdownOpen(false)
    }

  }} 
            >
              {selectedRole || "Select User Role *"}
            </div>
            
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-3 h-3 transition-transform duration-200 ${
                isRoleDropdownOpen ? "rotate-180" : "rotate-0"
              }`}
                            onClick={() => setIsRoleDropdownOpen((v) => !v)}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>
             {isRoleDropdownOpen && selectedType && (
  <ul 
   ref={roleListRef}
  className="absolute w-full bg-white border border-black/60 border-t-white mt-0 max-h-40 overflow-auto shadow-md z-50">

    {/* Show search input only if rolesList has more than 5 items */}
    {rolesList.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1.5  z-10">
        <input
          type="text"
          placeholder="Search roles..."
          value={roleSearch} // state: const [roleSearch, setRoleSearch] = useState("")
          onChange={(e) => setRoleSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </li>
    )}

    {/* Filter, sort, and map roles */}
    {rolesList
      .filter((r) => r.label !== selectedRole) // hide already selected
      .filter((r) =>
        !roleSearch ? true : r.label.toLowerCase().includes(roleSearch.toLowerCase())
      )
      .sort((a, b) => a.label.localeCompare(b.label))
      .map((r) => (
       <li
  tabIndex={0}
  key={r.id || r.label}
  className="px-3 py-1.5 hover:bg-lightBlue cursor-pointer text-xs"
  onKeyDown={(e) => {
    const items = Array.from(
      roleListRef.current.querySelectorAll("li[tabindex]")
    );
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setIsRoleDropdownOpen(false)
    }

    if (e.key === "Enter") {
      e.preventDefault();
      setSelectedRole(r.label);
      setSelectedRoleId(r.id);
      setIsRoleDropdownOpen(false);
      e.stopPropagation();   
      setErrors((prev) => ({ ...prev, selectedRole: "" }));
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setSelectedRole(r.label);
    setSelectedRoleId(r.id);
    setIsRoleDropdownOpen(false);
    setErrors((prev) => ({ ...prev, selectedRole: "" }));
  }}
>
  {r.label}
</li>
      ))}

    {/* No results message */}
    {rolesList
      .filter((r) => r.label !== selectedRole)
      .filter((r) =>
        !roleSearch ? true : r.label.toLowerCase().includes(roleSearch.toLowerCase())
      ).length === 0 && (
        <li className="px-3 py-2 text-xs text-gray-500">No roles found</li>
      )}

  </ul>
)}

            {errors.selectedRole && <p className="text-red1 text-xs mt-1">{errors.selectedRole}</p>}
          </div>

          {/* Market Area */}
          {showFields && (
            <div className="relative w-full" ref={marketAreaRef}>
              <div
                className={`w-full border  px-3 py-1.5 pr-10 text-xs cursor-pointer transition-all duration-200 ${
                  isMarketAreaDropdownOpen
                    ? `${errors.selectedMarketArea ? "border-red1" : "border-black/60"} text-black border-b-white `
                    : `${errors.selectedMarketArea ? "border-red1" : "border-black/60"} hover:border-2 focus:outline-none focus:border-2`
                }`}
                onClick={() => setIsMarketAreaDropdownOpen((v) => !v)}
                 tabIndex={0}
                  onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setIsMarketAreaDropdownOpen(true)
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setIsMarketAreaDropdownOpen(false)
    }

  }} 
              >
                {selectedMarketArea
                  ? marketAreas.find((m) => m.id === selectedMarketArea)?.marketarea
                  : "Select Market Area *"}
              </div>
              
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-3 h-3 transition-transform duration-200 ${
                  isMarketAreaDropdownOpen ? "rotate-180" : "rotate-0"
                }`}
                              onClick={() => setIsMarketAreaDropdownOpen((v) => !v)}>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>
             {isMarketAreaDropdownOpen && (
  <ul
   ref={marketAreaListRef} 
  className="absolute w-full bg-white border border-black/60 border-t-white mt-0 max-h-40 overflow-auto shadow-md z-50">

    {/* Show search input only if more than 5 market areas */}
    {marketAreas.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1.5 z-10">
        <input
          type="text"
          placeholder="Search market areas..."
          value={marketAreaSearch} // state: [marketAreaSearch, setMarketAreaSearch]
          onChange={(e) => setMarketAreaSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </li>
    )}

    {/* Filter, sort, and map */}
    {[...marketAreas]
      .filter((m) => m.marketarea) // remove undefined/null marketarea
      .filter((m) => m.id !== selectedMarketArea) // exclude selected
      .filter((m) =>
        !marketAreaSearch
          ? true
          : m.marketarea.toLowerCase().includes(marketAreaSearch.toLowerCase())
      )
      .sort((a, b) => a.marketarea.localeCompare(b.marketarea))
      .map((m) => (
       <li
  tabIndex={0}
  key={m.id}
  className="px-3 py-1.5 hover:bg-lightBlue cursor-pointer text-xs"
  onKeyDown={(e) => {
   const items = Array.from(
  marketAreaListRef.current?.querySelectorAll("li[tabindex]") || []
);
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setIsMarketAreaDropdownOpen(false)
    }

    if (e.key === "Enter") {
      e.preventDefault();
      setSelectedMarketArea(m.id);
      setSelectedDealerships([]);
      e.stopPropagation();   
      setIsMarketAreaDropdownOpen(false);

      if (errors.selectedMarketArea) {
        setErrors((prev) => ({ ...prev, selectedMarketArea: null }));
      }
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setSelectedMarketArea(m.id);
    setSelectedDealerships([]);
    setIsMarketAreaDropdownOpen(false);

    if (errors.selectedMarketArea) {
      setErrors((prev) => ({ ...prev, selectedMarketArea: null }));
    }
  }}
>
  {m.marketarea}
</li>
      ))}

    {/* No results found */}
    {[...marketAreas]
      .filter((m) => m.marketarea)
      .filter((m) => m.id !== selectedMarketArea)
      .filter((m) =>
        !marketAreaSearch
          ? true
          : m.marketarea.toLowerCase().includes(marketAreaSearch.toLowerCase())
      ).length === 0 && (
        <li className="px-3 py-2 text-sm text-black/60 cursor-default">No Market Area found</li>
      )}

  </ul>
)}

              {errors.selectedMarketArea && <p className="text-red1 text-xs mt-1">{errors.selectedMarketArea}</p>}
            </div>
          )}

          {/* Dealership */}
          {showFields && (
            <div className="relative w-full" ref={dealershipRef}>
              <div
                className={`w-full border px-3 py-1.5 pr-10 text-xs cursor-pointer flex flex-wrap gap-2 items-center ${
                  isDealershipDropdownOpen
                    ? `${errors.selectedDealerships ? "border-red1" : "border-black/60"} text-black border-b-white `
                    : `${errors.selectedDealerships ? "border-red1" : "border-black/60"} hover:border-2 focus:outline-none focus:border-2`
                }`}
                onClick={() => setIsDealershipDropdownOpen((v) => !v)}
                 tabIndex={0}
                  onKeyDown={(e) => {

    // ENTER → open dropdown
    if (e.key === "Enter") {
      e.preventDefault()
      e.stopPropagation()
      setIsDealershipDropdownOpen(true)
    }

    // ESC → close dropdown
    if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setIsDealershipDropdownOpen(false)
    }

  }} 
              >
                {selectedDealerships.length > 0 ? (
                  selectedDealerships.map((val) => {
                    const label = dealerships.find((d) => d.id === val)?.dealerShortName
                    return (
                      <span
                        key={val}
                        className="flex items-center gap-2 bg-grey2 text-black px-2 py-0  text-xs"
                      >
                        {label}
                        <button
                          type="button"
                          className="hover:text-red-500"
                          onClick={(e) => {
                            e.stopPropagation()
                            setSelectedDealerships((prev) => prev.filter((d) => d !== val))
                          }}
                        >
                           <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Error icon"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>
                        </button>
                      </span>
                    )
                  })
                ) : (
                  <span className="text-black/60">Select Dealership *</span>
                )}
              </div>
              {/* <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Vector (25).png"
                alt="Dropdown Icon"
                className={`absolute right-3 top-5 transform -translate-y-1/2 w-3 h-3 transition-transform duration-200 ${
                  isDealershipDropdownOpen ? "rotate-180" : "rotate-0"
                }`}
                              onClick={() => setIsDealershipDropdownOpen((v) => !v)}

              /> */}
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"
              className={`absolute right-3 top-4 transform -translate-y-1/2 w-3 h-3 transition-transform duration-200 ${
                  isDealershipDropdownOpen ? "rotate-180" : "rotate-0"
                }`}
                              onClick={() => setIsDealershipDropdownOpen((v) => !v)}
              >
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="#212121"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
<path d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z" fill="black" fill-opacity="0.2"/>
</svg>
              {isDealershipDropdownOpen && (
  <ul 
  ref={dealershipListRef}
  className="absolute w-full bg-white border border-black/60 border-t-white mt-0 max-h-40 overflow-auto shadow-md z-50">

    {/* Show search input only if more than 5 filtered dealerships */}
    {[...dealerships]
      .filter((d) => {
        if (!selectedMarketArea) return true;
        const selectedMA = marketAreas.find((ma) => ma.id === selectedMarketArea);
        return d.marketName?.toLowerCase() === selectedMA?.marketarea?.toLowerCase();
      }).length > 5 && (
        <li className="sticky top-0 bg-white px-3 py-1.5 z-10">
          <input
            type="text"
            placeholder="Search dealerships..."
            value={dealershipSearch} // state: const [dealershipSearch, setDealershipSearch] = useState("")
            onChange={(e) => setDealershipSearch(e.target.value)}
            className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
            autoFocus
          />
        </li>
      )}

    {/* Filter, sort, and map dealerships */}
    {[...dealerships]
      .filter((d) => {
        if (!selectedMarketArea) return true;
        const selectedMA = marketAreas.find((ma) => ma.id === selectedMarketArea);
        return d.marketName?.toLowerCase() === selectedMA?.marketarea?.toLowerCase();
      })
      .filter((d) =>
        !dealershipSearch
          ? true
          : d.dealerShortName?.toLowerCase().includes(dealershipSearch.toLowerCase())
      )
      .sort((a, b) => (a.dealerShortName || "").localeCompare(b.dealerShortName || ""))
      .map((dealer) => {
        const isSelected = selectedDealerships.includes(dealer.id);
        return (
         <li
  tabIndex={0}
  key={dealer.id}
  className={`px-3 py-1.5 text-xs cursor-pointer hover:bg-lightBlue ${
    isSelected ? "bg-lightBlue font-semibold" : ""
  }`}
  onKeyDown={(e) => {
    const items = Array.from(
      dealershipListRef.current.querySelectorAll("li[tabindex]")
    );
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault()
      e.stopPropagation()
      setIsDealershipDropdownOpen(false)
    }

    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      e.stopPropagation();   
      setSelectedDealerships((prev) =>
        prev.includes(dealer.id)
          ? prev.filter((d) => d !== dealer.id)
          : [...prev, dealer.id]
      );

      if (errors.selectedDealerships) {
        setErrors((prev) => ({ ...prev, selectedDealerships: null }));
      }
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setSelectedDealerships((prev) =>
      prev.includes(dealer.id)
        ? prev.filter((d) => d !== dealer.id)
        : [...prev, dealer.id]
    );

    if (errors.selectedDealerships) {
      setErrors((prev) => ({ ...prev, selectedDealerships: null }));
    }
  }}
>
  {dealer.dealerShortName}
</li>
        );
      })}

    {/* No results found */}
    {[...dealerships]
      .filter((d) => {
        if (!selectedMarketArea) return true;
        const selectedMA = marketAreas.find((ma) => ma.id === selectedMarketArea);
        return d.marketName?.toLowerCase() === selectedMA?.marketarea?.toLowerCase();
      })
      .filter((d) =>
        !dealershipSearch
          ? true
          : d.dealerShortName?.toLowerCase().includes(dealershipSearch.toLowerCase())
      ).length === 0 && (
        <li className="px-3 py-2 text-sm text-black/60 cursor-default">
          No Dealership found
        </li>
      )}

  </ul>
)}

              {errors.selectedDealerships && <p className="text-red1 text-xs mt-1">{errors.selectedDealerships}</p>}
            </div>
          )}

          {/* Buttons */}
          <div className="flex justify-center gap-4 mt-4">
            <button
              type="button"
              className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium  hover:bg-mildBlue1 hover:scale-105"
              onClick={onClose}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 18 20" fill="none">
<path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>{" "}
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default EditUserdetails
