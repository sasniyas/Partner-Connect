import React, { useState, useRef, useEffect } from "react";
import DeleteModal from "../../../Components/DeleteModal";
import Searchinput from "../../../Components/Searchinput";
import DeleteAllRecords from "../../../Components/DeleteAllRecords";
import { IoSearch } from "react-icons/io5";
import { getUserLogs, deleteUserLog } from "../../../services/authLogs/authLogs.service";
import Filter from "../../../Components/Filter";
import CommentPopup from "../AuthenticationLog/CommentPopup";
import { formatDateOnly, formatedTime } from "../../../util/timeFormat";
import { ChevronDown, ChevronUp } from "lucide-react"
import { ArrowUp } from "lucide-react";
import { ArrowDown } from "lucide-react";
import { ChevronsUpDown } from "lucide-react";
import useCRUDWithReset from "../../../util/useCRUDWithReset"

const ShowHistoryUserdetails = ({ user, onClose }) => {
  const [userLogs, setUserLogs] = useState([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);
  const [error, setError] = useState(null);
  const [hoveredLog,setHoveredLog] =useState()
  const [hoveredPerformedBy, setHoveredPerformedBy] =useState(null)
  const [deletePopup, setDeletePopup] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [isDeleteAllOpen, setIsDeleteAllOpen] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [searchText, setSearchText] = useState("");
  const [showFromInput, setShowFromInput] = useState(false);
  const [showToInput, setShowToInput] = useState(false);
const [activityOptions, setActivityOptions] = useState(["All"]);
const [sortKey, setSortKey] = useState(null);   // column being sorted
const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc" | null
  const [showRealToInput, setShowRealToInput] = useState(false);
  const [showRealFromInput, setShowRealFromInput] = useState(false);
const today = new Date().toISOString().split("T")[0];
  const dropdownRef = useRef(null);
  const fromDateRef = useRef(null);
  const toDateRef = useRef(null);
const [selectedLog, setSelectedLog] = useState(null);
const [logDetailsVisible, setLogDetailsVisible] = useState(false);

  
const [performedByOptions, setPerformedByOptions] = useState([""]);


// state
const [selectedPerformedBy, setSelectedPerformedBy] = useState("");


  const scrollRef = useRef(null);
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState([]);
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  // Fetch user logs from API
  const fetchUserLogs = async (filters = {}) => {
  if (!user?.id) return;
    
  setIsLoadingLogs(true);
  setError(null);
    
  try {
    const logs = await getUserLogs({ 
      userId: user.id,
      ...filters 
    });

    const transformedLogs = logs.map(log => ({
      id: log.id,
      logDate: log.createdOn ? new Date(log.createdOn).toISOString().split('T')[0] : log.logDate,
      activity: log.activity,
      performedBy: log.performed_by || log.performedBy,
      message: log.message,
      logType: log.log_type || log.logType
    }));

    setUserLogs(transformedLogs);

    // 🔹 Populate Activity options dynamically
    fetchActivityOptions(transformedLogs);

  } catch (err) {
    console.error("Error fetching user logs:", err);
    setError(err.message || "Failed to fetch user logs");
    setUserLogs([]);
    setActivityOptions(["All"]);
  } finally {
    setIsLoadingLogs(false);
  }
};


  // Load user logs when component mounts or user changes
  useEffect(() => {
    if (user?.id) {
      fetchUserLogs();
    }
  }, [user?.id]);
useEffect(() => {
  if (userLogs.length > 0) {
    const uniquePerformedBy = Array.from(
      new Set(
        userLogs
          .map(log => log.performedBy)
          .filter(v => v && v.trim() !== "")
      )
    );

setPerformedByOptions([...uniquePerformedBy]);
  }
}, [userLogs]);
const fetchActivityOptions = (logs) => {
  if (!Array.isArray(logs) || logs.length === 0) return;

  // Get unique activities
  const uniqueActivities = [...new Set(logs.map(log => log.activity?.trim()).filter(Boolean))];

  // Set state with "All" as default option
  setActivityOptions(["All", ...uniqueActivities]);
};

  const loadMoreData = () => {
    setIsLoading(true);
    setTimeout(() => {
      const newItems = Array.from({ length: 5 }).map((_, i) => ({
        id: Date.now() + i,
        type: "Extra Equipment " + (data.length + i + 1),
        multiplier: (50000 + i * 1000).toString(),
      }));
      setData((prev) => [...prev, ...newItems]);
      setIsLoading(false);
    }, 1000);
  };

  const handleScroll = () => {
    const div = scrollRef.current;
    if (!div) return;
    if (div.scrollTop + div.clientHeight >= div.scrollHeight - 20 && !isLoading) {
      loadMoreData();
    }
  };

  useEffect(() => {
    const div = scrollRef.current;
    if (div) div.addEventListener("scroll", handleScroll);
    return () => { if (div) div.removeEventListener("scroll", handleScroll); };
  }, [isLoading, data]);

  const handleDelete = async () => {
    try {
      await deleteUserLog(deleteTarget);
      setUserLogs((prev) => prev.filter((item) => item.id !== deleteTarget));
      resetSortAndFilter()
      setDeletePopup(false);
      setDeleteTarget(null);
    } catch (err) {
      console.error("Error deleting user log:", err);
      setError(err.message || "Failed to delete user log");
    }
  };

  const handleDeleteAll = async () => {
    try {
      // Delete all logs for this user
      const deletePromises = userLogs.map(log => deleteUserLog(log.id));
      await Promise.all(deletePromises);
      
      setUserLogs([]);
      setIsDeleteAllOpen(false);
    } catch (err) {
      console.error("Error deleting all user logs:", err);
      setError(err.message || "Failed to delete all user logs");
    }
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Handle filter changes and refetch data
//  const handleFilterChange = () => {
//   const filters = {};

//   // Activity filter
//   if (selectedActivity) {
//     filters.activity = selectedActivity;
//   }

//   // Performed By filter (if used separately)
//   if (selectedActivity.length > 0 && Array.isArray(selectedActivity)) {
//     filters.performedBy = selectedActivity[0];
//   }

//   if (fromDate) filters.startDate = fromDate;
//   if (toDate) filters.endDate = toDate;
//   if (searchText) filters.search = searchText;

//   console.log("Sending filters to API:", filters);
//   fetchUserLogs(filters);
// };


  // Apply filters when they change
 useEffect(() => {
  if (user?.id) {
    fetchUserLogs(); // fetch all logs once
  }
}, [user?.id]);


  const filteredLogs = userLogs.filter((log) => {
  const logActivity = log.activity?.toLowerCase().trim() || "";
  const logPerformedBy = log.performedBy?.toLowerCase().trim() || "";

  // Activity filter
  const matchesActivity =
    selectedActivity.length === 0 ||
    selectedActivity.some(
      (activity) => activity.toLowerCase().trim() === logActivity
    );

  // Date filter
 let matchesDate = true;

if (fromDate || toDate) {
  const logDate = new Date(log.logDate);
  logDate.setHours(0, 0, 0, 0);

  const fromTime = fromDate ? new Date(fromDate) : null;
  const toTime = toDate ? new Date(toDate) : null;

  if (fromTime) fromTime.setHours(0, 0, 0, 0);
  if (toTime) toTime.setHours(0, 0, 0, 0);

  // If both same date → exact match
  if (fromTime && toTime && fromTime.getTime() === toTime.getTime()) {
    matchesDate = logDate.getTime() === fromTime.getTime();
  } else {
    matchesDate =
      (!fromTime || logDate >= fromTime) &&
      (!toTime || logDate <= toTime);
  }
}
  // Search filter (activity + performedBy + date)
  const searchLower = searchText.toLowerCase();
  const matchesSearch =
    searchText === "" ||
    logActivity.includes(searchLower) ||
    logPerformedBy.includes(searchLower) ||
    (log.logDate && String(log.logDate).toLowerCase().includes(searchLower));
// 🔹 Match performedBy dropdown
const matchesPerformedBy =
  selectedPerformedBy.length === 0 ||
  selectedPerformedBy.some(
    (p) => p.toLowerCase().trim() === logPerformedBy
  );

return (
  matchesActivity &&
  matchesPerformedBy &&
  matchesDate &&
  matchesSearch
);
});
const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      // Second click → descending
      const sortedDesc = [...userLogs].sort((a, b) => {
        if (key === "logDate") {
          return new Date(b[key]) - new Date(a[key]);
        }
        const valA = (a[key] || "").toString().toLowerCase();
        const valB = (b[key] || "").toString().toLowerCase();
        return valB.localeCompare(valA);
      });
      setUserLogs(sortedDesc);
      setSortOrder("desc");
      return;
    } else if (sortOrder === "desc") {
      // Third click → reset to original
      fetchUserLogs(); // refetch original
      setSortKey(null);
      setSortOrder(null);
      return;
    }
  }

  // First click → ascending
  const sortedAsc = [...userLogs].sort((a, b) => {
    if (key === "logDate") {
      return new Date(a[key]) - new Date(b[key]);
    }
    const valA = (a[key] || "").toString().toLowerCase();
    const valB = (b[key] || "").toString().toLowerCase();
    return valA.localeCompare(valB);
  });
  setUserLogs(sortedAsc);
  setSortKey(key);
  setSortOrder("asc");
};
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchText: { setter: setSearchText, resetValue: "" },
    fromDate:{setter:setFromDate,resetValue:""},
    toDate:{setter:setToDate,resetValue:""},
    selectedActivity:{setter:setSelectedActivity,resetValue:[]},
    selectedPerformedBy:{setter:setSelectedPerformedBy,resetValue:[]}
  }
);


const displayUserName =
  user?.name ||
  [user?.firstName, user?.middleName, user?.lastName]
    .filter(Boolean)
    .join(" ") ||
  "User";

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
<div className="relative w-full max-w-5xl bg-white shadow-lg h-[500px] flex flex-col ">
          <button
          className="absolute top-4 right-4 w-4 h-4 flex items-center justify-center bg-red1 rounded-full transition duration-200 hover:scale-110"
          onClick={onClose}
          aria-label="Close"
        >
          <svg width="14" height="14" viewBox="0 0 20 20">
            <circle cx="8" cy="8" r="8" fill="#BF2012" />
            <path d="M6.5 6.5L13.5 13.5M13.5 6.5L6.5 13.5" stroke="white" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>

        <div className="pt-6 px-4 sm:px-6 lg:px-10 mb-2 ">
         <h2 className="text-base font-medium text-MediumGrey text-center">
  User log of {displayUserName}
</h2>


        </div>

        <div className="flex flex-wrap sm:flex-nowrap items-center gap-4 px-4 sm:px-6 lg:px-10 mb-2">
          {/* Search */}
          <div className="">
            {/* <Searchinput
              placeholder="Search...."
              inputWidth="w-full h-10"
              borderColor="border-black"
              shadow="shadow-none"
              focusRing="focus:ring focus:ring-1 focus:ring-black"
              hoverInputClasses="hover:border-black hover:ring-1 hover:ring-black"
              icon={<IoSearch className="text-black" />}
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            /> */}
              <Searchinput
              value={searchText}
              onChange={(e) => {
                setSearchText(e.target.value)
              }}
              placeholder="Search"
              className="w-[1/2]"
              bgColor="bg-white"
                           borderColor="border-black/60"
                           
              textColor="text-black"
              focusRing="focus:ring-black/60"
              shadow="shadow-none"
              inputPadding="pl-7 pr-3 py-1.5"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              iconColor="text-black"
            />
          </div>

       <div className="relative w-[150px]">
  {!showRealFromInput && (
    <input
      type="text"
      placeholder="From Date"
      readOnly
        max={today}   // ✅ future dates disabled
      className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-gray-400 cursor-pointer"
      onFocus={() => {
        setShowRealFromInput(true);
        setTimeout(() => fromDateRef.current?.showPicker(), 0);
      }}
    />
  )}
  {showRealFromInput && (
    <input
      type="date"
      ref={fromDateRef}
      value={fromDate}
        max={today}   // ✅ future dates disabled
      onChange={(e) => setFromDate(e.target.value)}
      className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-black"
    />
  )}
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
    fill="none"
    onClick={() => {
      setShowRealFromInput(true);
      setTimeout(() => fromDateRef.current?.showPicker(), 0);
    }}
  >
    <path
      d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
    />
    <path
      d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path
      d="M18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18C16.7348 18 16.4804 17.8946 16.2929 17.7071C16.1054 17.5196 16 17.2652 16 17C16 16.7348 16.1054 16.4804 16.2929 16.2929C16.4804 16.1054 16.7348 16 17 16C17.2652 16 17.5196 16.1054 17.7071 16.2929C17.8946 16.4804 18 16.7348 18 17ZM18 13C18 13.2652 17.8946 13.5196 17.7071 13.7071C17.5196 13.8946 17.2652 14 17 14C16.7348 14 16.4804 13.8946 16.2929 13.7071C16.1054 13.5196 16 13.2652 16 13C16 12.7348 16.1054 12.4804 16.2929 12.2929C16.4804 12.1054 16.7348 12 17 12C17.2652 12 17.5196 12.1054 17.7071 12.2929C17.8946 12.4804 18 12.7348 18 13ZM13 17C13 17.2652 12.8946 17.5196 12.7071 17.7071C12.5196 17.8946 12.2652 18 12 18C11.7348 18 11.4804 17.8946 11.2929 17.7071C11.1054 17.5196 11 17.2652 11 17C11 16.7348 11.1054 16.4804 11.2929 16.2929C11.4804 16.1054 11.7348 16 12 16C12.2652 16 12.5196 16.1054 12.7071 16.2929C12.8946 16.4804 13 16.7348 13 17ZM13 13C13 13.2652 12.8946 13.5196 12.7071 13.7071C12.5196 13.8946 12.2652 14 12 14C11.7348 14 11.4804 13.8946 11.2929 13.7071C11.1054 13.5196 11 13.2652 11 13C11 12.7348 11.1054 12.4804 11.2929 12.2929C11.4804 12.1054 11.7348 12 12 12C12.2652 12 12.5196 12.1054 12.7071 12.2929C12.8946 12.4804 13 12.7348 13 13ZM8 17C8 17.2652 7.89464 17.5196 7.70711 17.7071C7.51957 17.8946 7.26522 18 7 18C6.73478 18 6.48043 17.8946 6.29289 17.7071C6.10536 17.5196 6 17.2652 6 17C6 16.7348 6.10536 16.4804 6.29289 16.2929C6.48043 16.1054 6.73478 16 7 16C7.26522 16 7.51957 16.1054 7.70711 16.2929C7.89464 16.4804 8 16.7348 8 17ZM8 13C8 13.2652 7.89464 13.5196 7.70711 13.7071C7.51957 13.8946 7.26522 14 7 14C6.73478 14 6.48043 13.8946 6.29289 13.7071C6.10536 13.5196 6 13.2652 6 13C6 12.7348 6.10536 12.4804 6.29289 12.2929C6.48043 12.1054 6.73478 12 7 12C7.26522 12 7.51957 12.1054 7.70711 12.2929C7.89464 12.4804 8 12.7348 8 13Z"
      fill="black"
      fillOpacity="0.7"
    />
  </svg>
</div>

{/* To Date */}
<div className="relative w-[150px]">
  {!showRealToInput && (
    <input
      type="text"
      placeholder="To Date"
      readOnly
        max={today}   // ✅ future dates disabled
      className="w-full py-1.5 px-3 text-xs border border-black/50 pr-10 text-gray-400 cursor-pointer"
      onFocus={() => {
        setShowRealToInput(true);
        setTimeout(() => toDateRef.current?.showPicker(), 0);
      }}
    />
  )}
  {showRealToInput && (
    <input
      type="date"
      ref={toDateRef}
        max={today}   // ✅ future dates disabled
      value={toDate}
      onChange={(e) => setToDate(e.target.value)}
      className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-black"
    />
  )}
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
    fill="none"
    onClick={() => {
      setShowRealToInput(true);
      setTimeout(() => toDateRef.current?.showPicker(), 0);
    }}
  >
    <path
      d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
    />
    <path
      d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path
      d="M18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18C16.7348 18 16.4804 17.8946 16.2929 17.7071C16.1054 17.5196 16 17.2652 16 17C16 16.7348 16.1054 16.4804 16.2929 16.2929C16.4804 16.1054 16.7348 16 17 16C17.2652 16 17.5196 16.1054 17.7071 16.2929C17.8946 16.4804 18 16.7348 18 17ZM18 13C18 13.2652 17.8946 13.5196 17.7071 13.7071C17.5196 13.8946 17.2652 14 17 14C16.7348 14 16.4804 13.8946 16.2929 13.7071C16.1054 13.5196 16 13.2652 16 13C16 12.7348 16.1054 12.4804 16.2929 12.2929C16.4804 12.1054 16.7348 12 17 12C17.2652 12 17.5196 12.1054 17.7071 12.2929C17.8946 12.4804 18 12.7348 18 13ZM13 17C13 17.2652 12.8946 17.5196 12.7071 17.7071C12.5196 17.8946 12.2652 18 12 18C11.7348 18 11.4804 17.8946 11.2929 17.7071C11.1054 17.5196 11 17.2652 11 17C11 16.7348 11.1054 16.4804 11.2929 16.2929C11.4804 16.1054 11.7348 16 12 16C12.2652 16 12.5196 16.1054 12.7071 16.2929C12.8946 16.4804 13 16.7348 13 17ZM13 13C13 13.2652 12.8946 13.5196 12.7071 13.7071C12.5196 13.8946 12.2652 14 12 14C11.7348 14 11.4804 13.8946 11.2929 13.7071C11.1054 13.5196 11 13.2652 11 13C11 12.7348 11.1054 12.4804 11.2929 12.2929C11.4804 12.1054 11.7348 12 12 12C12.2652 12 12.5196 12.1054 12.7071 12.2929C12.8946 12.4804 13 12.7348 13 13ZM8 17C8 17.2652 7.89464 17.5196 7.70711 17.7071C7.51957 17.8946 7.26522 18 7 18C6.73478 18 6.48043 17.8946 6.29289 17.7071C6.10536 17.5196 6 17.2652 6 17C6 16.7348 6.10536 16.4804 6.29289 16.2929C6.48043 16.1054 6.73478 16 7 16C7.26522 16 7.51957 16.1054 7.70711 16.2929C7.89464 16.4804 8 16.7348 8 17ZM8 13C8 13.2652 7.89464 13.5196 7.70711 13.7071C7.51957 13.8946 7.26522 14 7 14C6.73478 14 6.48043 13.8946 6.29289 13.7071C6.10536 13.5196 6 13.2652 6 13C6 12.7348 6.10536 12.4804 6.29289 12.2929C6.48043 12.1054 6.73478 12 7 12C7.26522 12 7.51957 12.1054 7.70711 12.2929C7.89464 12.4804 8 12.7348 8 13Z"
      fill="black"
      fillOpacity="0.7"
    />
  </svg>
</div>

          {/* Performed By Dropdown */}
     <Filter
  name="activity"
  value={selectedActivity}
  options={activityOptions}  // 🔹 Dynamic from API
  onChange={(name, newValue) => setSelectedActivity(newValue)}
  placeholder="Activity"
  textColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBorderColor="border-black/60"
  dropdownHoverColor="hover:bg-lightBlue/50"
  customWidth="w-[250px]"
/>


<Filter
  name="performedBy"
  value={selectedPerformedBy}
  options={performedByOptions}
  onChange={(name, newValue) => setSelectedPerformedBy(newValue)}
  placeholder="Performed By"
  textColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBorderColor="border-black/60"
  dropdownHoverColor="hover:bg-lightBlue/50"
  customWidth="w-[180px]"
/>



          {/* Delete All */}
          <div className="w-[12%]">
            <button
              onClick={() => setIsDeleteAllOpen(true)}
              className="w-full py-1.5 flex items-center justify-center gap-2 text-red bg-red2  hover:bg-white hover:border hover:border-red text-xs"
            >
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>              Delete All
            </button>
          </div>
        </div>

        {/* Logs Table */}
        <div className="px-4 sm:px-6 lg:px-10 pb-6">
          {/* Error Message */}
          {error && (
            <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 ">
              {error}
            </div>
          )}
          
          <div className="bg-white shadow-md  border border-Dustyblue overflow-hidden">
           <div
  ref={tableContainerRef}
  className="overflow-y-auto relative flex-1 h-[370px]"
  style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
  onScroll={handleTableScroll}
>
  <style jsx>{`
    div::-webkit-scrollbar {
      display: none;
    }
  `}</style>
              <table className="w-full text-sm border-collapse">
                <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
                  <tr>

                 <th
  onClick={() => handleSort("activity")}
  className="p-1.5 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 w-[20%] font-medium cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Activity
    {sortKey !== "activity" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
    {sortKey === "activity" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "activity" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

<th
  onClick={() => handleSort("performedBy")}
  className="p-1.5 text-left text-xs border border-grey2 border-t-0  border-l-0 border-b-0  w-[20%] font-medium cursor-pointer select-none"
>
  <div className="flex items-center gap-1">
    Performed By
    {sortKey === "performedBy" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "performedBy" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>
<th
  className="p-1.5 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
  onClick={() => handleSort("logDate")}
>
  <div className="flex items-center gap-1">
    Log date
    
    {sortKey === "logDate" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "logDate" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>
   <th className="p-1.5  text-center text-xs border border-grey2 border-t-0 border-l-0 border-r-0 border-b-0 font-medium w-[10%]">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoadingLogs ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-gray-500"></div>
                          Loading user logs...
                        </div>
                      </td>
                    </tr>
                  ) : filteredLogs.length > 0 ? (
                    filteredLogs.map((log) => (
                      <tr key={log.id} className=" cursor-pointer">
  <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[9rem] cursor-pointer"
      onMouseEnter={() => {
        if (log.activity && log.activity.length > 30) setHoveredLog(log.id);
      }}
      onMouseLeave={() => setHoveredLog(null)}
    >
      {log.activity}
    </p>

    {hoveredLog === log.id && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {log.activity}
      </span>
    )}
  </div>
</td>

                        <td className="p-1 border border-grey2 border-t-0 border-l-0 text-xs">{formatedTime(log.logDate)}</td>


  <td className="py-1 px-2 text-xs border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[9rem] cursor-pointer"
      onMouseEnter={() => {
        if (log.performedBy && log.performedBy.length > 30) setHoveredPerformedBy(log.id);
      }}
      onMouseLeave={() => setHoveredPerformedBy(null)}
    >
      {log.performedBy}
    </p>

    {hoveredPerformedBy === log.id && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {log.performedBy}
      </span>
    )}
  </div>
</td>



                     <td className="p-1 border border-grey2 border-t-0 border-l-0 border-r-0  ">
  <div className="flex items-center justify-center space-x-0">
    {/* 🟢 Comment Button */}
    <button
  className="relative group"
  onClick={() => {
    setSelectedLog({
      id: log.id,
      date: log.logDate || "-", // ✅ Use logDate you already have
      activity: log.activity || "-", // ✅ Use transformed activity field
      user: { name: `${user?.firstName || ""} ${user?.lastName || ""}`.trim() || "-" }, // ✅ Show the user from props
      performedBy: log.performedBy || "-", // ✅ Comes from your transformed data
      message: log.message || "No message available", // ✅ Message fallback
    });
    setLogDetailsVisible(true);
  }}
>
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M12.3604 4C6.58038 4 2.64438 9.857 4.82438 15.21L5.75738 17.498C5.79812 17.5978 5.80553 17.7081 5.7785 17.8124C5.75147 17.9167 5.69144 18.0095 5.60738 18.077L3.63438 19.66C3.5536 19.7248 3.49494 19.8131 3.4665 19.9127C3.43805 20.0122 3.44123 20.1182 3.47558 20.2159C3.50994 20.3136 3.57378 20.3982 3.6583 20.458C3.74281 20.5179 3.84382 20.55 3.94738 20.55H11.7674C12.9142 20.5504 14.0499 20.3248 15.1096 19.8861C16.1692 19.4475 17.1321 18.8043 17.9431 17.9934C18.7541 17.1825 19.3973 16.2197 19.8361 15.1601C20.2749 14.1005 20.5006 12.9649 20.5004 11.818C20.5004 7.5 17.0004 4 12.6824 4H12.3604Z" fill="#1B365D"/>
</svg>
  <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100  bg-SteelBlue1 text-white text-[10px]  px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-10">
    Comment
  </span>
</button>


    {/* 🔴 Delete Button */}
    <button
      onClick={() => {
        setDeleteTarget(log.id);
        setDeletePopup(true);
      }}
      className="relative group"
    >
     <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>
      <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100  bg-SteelBlue1 text-white text-[10px]  px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-10">
        Delete
      </span>
    </button>
  </div>
</td>

                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="4" className="text-center p-8 text-gray-500 italic">
                        {userLogs.length === 0 ? "No user logs found" : "No logs match the current filters"}
                      </td>
                    </tr>
                  )}
                  {isLoading && (
                    <tr>
                      <td colSpan={4} className="px-6 py-4 text-center text-gray-500">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                          Loading more...
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
             {showScrollButtons && (
  <div className="absolute bottom-10 right-12 z-40 flex flex-col gap-1">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

          </div>
        </div>

        {/* Modals */}
        <DeleteModal isOpen={deletePopup} onClose={() => setDeletePopup(false)} onConfirm={handleDelete} />
        <DeleteAllRecords
          isOpen={isDeleteAllOpen}
          onClose={() => setIsDeleteAllOpen(false)}
          onConfirm={handleDeleteAll}
          message="Are you sure you want to delete all user log records? This action cannot be undone."
        />
              {logDetailsVisible && <CommentPopup log={selectedLog} 
                userName={displayUserName}
              onClose={() => setLogDetailsVisible(false)} />}

      </div>
    </div>
  );
};

export default ShowHistoryUserdetails;
