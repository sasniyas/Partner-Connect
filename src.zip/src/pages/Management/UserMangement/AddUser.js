"use client"

import { useState, useEffect, useRef, useMemo } from "react"
import axios from "axios"
import { useNavigate } from "react-router-dom"
import { validateName,validateEmail,StringNumber } from "../../../util/Validator"
import { API } from '../../../api';
import { useKeyboardNavigation } from "../../../util/useKeyboardNavigation"

// ═══════════════════════════════════════════════════════════════
// REUSABLE DROPDOWN ARROW — single clean SVG path (FIX #5)
// ═══════════════════════════════════════════════════════════════
const DropdownArrow = ({ onClick, isOpen, className = "" }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    onClick={onClick}
    className={`absolute right-3 -translate-y-1/2 w-3 h-3 cursor-pointer transition-transform duration-200 ${
      isOpen ? "rotate-180" : "rotate-0"
    } ${className}`}
  >
    <path
      d="M9.97739 12.9999L14.007 9.02976L6.00721 8.97034L9.97739 12.9999ZM9.9254 19.9997C8.54211 19.9895 7.2441 19.7172 6.03136 19.1828C4.81863 18.6484 3.76562 17.9283 2.87232 17.0223C1.97903 16.1163 1.27457 15.0527 0.758962 13.8315C0.243351 12.6103 -0.00965302 11.3084 -5.05241e-05 9.92575C0.00955197 8.54312 0.281867 7.2451 0.816893 6.03171C1.35192 4.81832 2.07209 3.7653 2.97742 2.87267C3.88274 1.98003 4.94633 1.27558 6.1682 0.759309C7.39007 0.243036 8.69198 -0.00996825 10.0739 0.000295938C11.4559 0.0105601 12.7539 0.282875 13.968 0.81724C15.182 1.3516 16.2351 2.07178 17.127 2.97776C18.019 3.88374 18.7238 4.94734 19.2414 6.16855C19.759 7.38976 20.0117 8.69168 19.9994 10.0743C19.9871 11.4569 19.7148 12.7549 19.1825 13.9683C18.6501 15.1817 17.9299 16.2348 17.0219 17.1274C16.1139 18.02 15.0503 18.7248 13.8311 19.2417C12.6119 19.7587 11.31 20.0114 9.9254 19.9997ZM9.94026 17.9998C12.1735 18.0164 14.0709 17.2555 15.6324 15.717C17.1938 14.1786 17.9829 12.2927 17.9995 10.0594C18.016 7.82616 17.2551 5.92879 15.7167 4.36732C14.1782 2.80586 12.2924 2.01683 10.0591 2.00024C7.82582 1.98365 5.92845 2.74458 4.36698 4.28303C2.80551 5.82147 2.01648 7.70733 1.99989 9.9406C1.98331 12.1739 2.74424 14.0712 4.28268 15.6327C5.82113 17.1942 7.70698 17.9832 9.94026 17.9998Z"
      fill="#212121"
    />
  </svg>
);

const AddUser = ({ isAddUserOpen,headerStatus, onClose, onSave, onUserAdded, onuseredit,user}) => {
  console.log("AddUser props:", { isAddUserOpen, headerStatus, onClose, onSave, onUserAdded, onuseredit, user });
  // -------------------- STATE --------------------
  const navigate =useNavigate()
  const [firstName, setFirstName] = useState("")
  const [middleName, setMiddleName] = useState("")  
  const [lastName, setLastName] = useState("")
  const [email, setEmail] = useState("")
  const [selectedType, setSelectedType] = useState("")
  const [selectedRole, setSelectedRole] = useState("")
  const [selectedRoleId, setSelectedRoleId] = useState("")
  const [selectedMarketArea, setSelectedMarketArea] = useState("")
  const [selectedDealerships, setSelectedDealerships] = useState([]);
  const [location, setLocation] = useState("")
  const [errors, setErrors] = useState({})
  const [rolesList, setRolesList] = useState([]) // dynamic roles from API
  const [apiData, setApiData] = useState([])
  const [marketAreas, setMarketAreas] = useState([])
  const [dealerships, setDealerships] = useState([])
  const typeListRef = useRef(null);
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(false)
  const [emailError, setEmailError] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [searchTerm,setSearchTerm] = useState("")
  const [locationSearch,setLocationSearch] = useState("")
  const [roleSearch, setRoleSearch] = useState("");
  const [dealershipSearch, setDealershipSearch] = useState("");
  const [marketAreaSearch, setMarketAreaSearch] = useState("");
const locationListRef = useRef(null);
  const formRef = useRef(null)
const roleListRef = useRef(null);
const marketAreaListRef = useRef(null);
const dealershipListRef = useRef(null);
  // Dropdown state
  const [isTypeDropdownOpen, setIsTypeDropdownOpen] = useState(false)
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false)
  const [isMarketAreaDropdownOpen, setIsMarketAreaDropdownOpen] = useState(false)
  const [isDealershipDropdownOpen, setIsDealershipDropdownOpen] = useState(false)
  const [isLocationDropdownOpen, setIsLocationDropdownOpen] = useState(false)

  const validateLastName = (value) => {
  if (!value.trim()) return "Last Name is required";

  if (value.startsWith(" ")) return "Cannot start with space";

  if (value.endsWith(" ")) return "Cannot end with space";

  if (value.includes("  ")) return "Only single space allowed";

  if (!/^[A-Za-z]+( [A-Za-z]+)*$/.test(value))
    return "Only alphabets allowed";

  return "";
};
  // Refs for closing dropdowns
  const typeRef = useRef(null)
  const roleRef = useRef(null)
  const marketAreaRef = useRef(null)
  const dealershipRef = useRef(null)
  const locationRef = useRef(null)

  // -------------------- CONSTANTS --------------------
  const types = [
    { value: "dealer-user", label: "Dealer User" },
    { value: "volvo-user", label: "Volvo User" }
  ]

  // FIX #1: REMOVED local validateName that shadowed the imported one.
  // Now uses the imported validateName from "../../../util/Validator"

  // ═══════════════════════════════════════════════════════════════
  // LOCATION MAPPING HELPER (FIX #7)
  // UI displays "Headquarters" but API data uses "Head Quarter"
  // ═══════════════════════════════════════════════════════════════
  const locationToApiValue = (loc) => {
    if (loc === "Headquarters") return "Head Quarter";
    return loc; // "Region" stays "Region"
  };

  // -------------------- HELPER FUNCTIONS --------------------
  const resetForm = () => {
    setFirstName("")
    setMiddleName("")
    setLastName("")
    setEmail("")
    setSelectedType("")
    setSelectedRole("")
    setSelectedRoleId("")
    setSelectedMarketArea("")
    setSelectedDealerships([])
    setLocation("")
    setErrors({})
    setIsTypeDropdownOpen(false)
    setIsRoleDropdownOpen(false)
    setIsMarketAreaDropdownOpen(false)
    setIsDealershipDropdownOpen(false)
    setIsLocationDropdownOpen(false)
    // FIX #9: Reset all search terms
    setSearchTerm("")
    setLocationSearch("")
    setRoleSearch("")
    setDealershipSearch("")
    setMarketAreaSearch("")
  }

  // Function to remove a dealership
  const removeDealership = (val) => {
    setSelectedDealerships((prev) => prev.filter((d) => d !== val))
  }

  // Function to toggle dealership selection
  const toggleDealershipSelection = (val) => {
    setSelectedDealerships((prev) => (prev.includes(val) ? prev.filter((d) => d !== val) : [...prev, val]))
  }

  // ═══════════════════════════════════════════════════════════════
  // KEYBOARD HANDLER for dropdown triggers (FIX #6)
  // ═══════════════════════════════════════════════════════════════
  const handleDropdownKeyDown = (e, toggleFn) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      toggleFn();
    }
  };

  // -------------------- FETCH DATA --------------------
  useEffect(() => {
    const fetchRoles = async () => {
      try {
         let token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token){
      navigate("/")
      return;
    }
        const res = await axios.get(
           `${API.domain}${API.userManagement.getRoles}`,
          {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
        )
        if (res.data.status) {
          setApiData(res.data.data)
        }
      } catch (err) {
           const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";
            }
      }
    }
    fetchRoles()
  }, [])

  // FIX #7: filteredRoles maps "Headquarters" → "Head Quarter" for API filtering
  const filteredRoles = useMemo(() => {
    if (!selectedType) return []
    const typeLabel = types.find((t) => t.value === selectedType)?.label

    const activeRoles = apiData.filter((d) => d.userType === typeLabel && d.isActive === 1)

    if (typeLabel === "Volvo User") {
      const apiLocation = locationToApiValue(location);
      if (apiLocation === "Head Quarter") {
        return activeRoles
          .filter((d) => d.location === "Head Quarter")
          .map((d) => ({id:d.id, value: d.userRole, label: d.userRole }))
      } else if (apiLocation === "Region") {
        return activeRoles.filter((d) => d.location === "Region").map((d) => ({ id:d.id,value: d.userRole, label: d.userRole }))
      }
    }
    // Dealer User: show all active roles
    return activeRoles.map((d) => ({ id:d.id,value: d.userRole, label: d.userRole }))

  }, [selectedType, location, apiData])

  // Update rolesList whenever filteredRoles changes
  useEffect(() => {
    setRolesList(filteredRoles.map((r) => ({label:r.label,id:r.id})))
  }, [filteredRoles])

  useEffect(() => {
    const fetchMarketAreas = async () => {
      try {
         let token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token){
      navigate("/")
      return;
    }
        const res = await axios.get(
           `${API.domain}${API.userManagement.getMarketarea}`,
          {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
        )
        if (res.data.status) {
          const activeMA = res.data.data
            .filter((ma) => ma.isActive === 1)
            .map((ma) => ({ value: ma.id, label: ma.marketarea }))
          setMarketAreas(activeMA)
        }
      } catch (err) {
             const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";
            }
      }
    }

    const fetchDealers = async () => {
      try {
         let token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token){
      navigate("/")
      return;
    }
        const res = await axios.get(
         `${API.domain}${API.userManagement.getDealers}`,
          {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
        )
        if (res.data.status) {
          const activeDealers = res.data.data
            .filter((d) => d.isActive === 1)
            .map((d) => ({
              value: d.id,
              label: d.dealerShortName,
              marketName: d.marketName,
            }))
          setDealerships(activeDealers)
        }
      } catch (err) {
      const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";
            }
   }
    }

    fetchMarketAreas()
    fetchDealers()
  }, [])

  //table fetch
  const fetchUsers = async () => {
    setLoading(true)
    try {
       let token=localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token){
      navigate("/")
      return;
    }
      const res = await axios(
        `${API.domain}${API.userManagement.getAllUsers}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      )

      if (res.data?.status) {
        setUsers(res.data.data || [])
      }
    } catch (err) {
          const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";
            }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchUsers()
  }, [])

  useEffect(() => {
    function handleClickOutside(event) {
      if (typeRef.current && !typeRef.current.contains(event.target)){ setIsTypeDropdownOpen(false); setSearchTerm("") }
      if (roleRef.current && !roleRef.current.contains(event.target)) {setIsRoleDropdownOpen(false)
         setRoleSearch("")}
      if (marketAreaRef.current && !marketAreaRef.current.contains(event.target)) {setIsMarketAreaDropdownOpen(false)
         setMarketAreaSearch("")  }
      if (dealershipRef.current && !dealershipRef.current.contains(event.target)) {setIsDealershipDropdownOpen(false)
         setDealershipSearch("")} 
      if (locationRef.current && !locationRef.current.contains(event.target)) {setIsLocationDropdownOpen(false); setLocationSearch("") }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const filteredDealerships = dealerships.filter(
    (d) =>
      d.marketName?.trim().toLowerCase() ===
      marketAreas
        .find((ma) => ma.value === selectedMarketArea)
        ?.label?.trim()
        .toLowerCase(),
  )

  // Determine if Market Area & Dealership dropdowns should be shown
  const shouldShowMAandDealership = useMemo(() => {
    const typeLabel = types.find((t) => t.value === selectedType)?.label
    if (!typeLabel) return false

    if (typeLabel === "Dealer User") return true

    if (typeLabel === "Volvo User") {
      return location === "Region"
    }

    return false
  }, [selectedType, location])

  // Reset dependent fields
  useEffect(() => {
    if (!shouldShowMAandDealership) {
      setSelectedMarketArea("")
      setSelectedDealerships([])
    }
  }, [shouldShowMAandDealership])

const [resolvedUser, setResolvedUser] = useState(null);

useEffect(() => {
  const fetchResolvedUser = async () => {
    if (!user?.id) return;

    try {
      const token=localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
      if (!token) {
        navigate("/");
        return;
      }

      const res = await axios.get(
        `${API.domain}${API.userManagement.getUser}/${user.id}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (res.data?.status && res.data.data) {
        setResolvedUser(res.data.data);
      } else {
        console.warn("Failed to fetch resolved user:", res.data?.message);
        setResolvedUser(user);
      }
    } catch (err) {
          const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";
            }else {
        console.error("Error fetching resolved user:", err);
      }
      setResolvedUser(user);
    }
  };

  fetchResolvedUser();
}, [user]);


  useEffect(() => {
    if (!resolvedUser) return
    setFirstName(resolvedUser.firstName || "")
    setMiddleName(resolvedUser.middleName || "")
    setLastName(resolvedUser.lastName || "")
    setEmail(resolvedUser.email || "")
    setSelectedType(resolvedUser.role === "VOLVO_USER" ? "volvo-user" : "dealer-user")
    setLocation(
      resolvedUser.locationType === "REGION" ? "Region" : resolvedUser.locationType === "HQ" ? "Headquarters" : "",
    )
    setSelectedRole(resolvedUser.persona || "")
     setSelectedRoleId(resolvedUser.personaId || "")
    setErrors({})
  }, [resolvedUser])

  useEffect(() => {
    if (!resolvedUser) return
    if (!marketAreas.length || !dealerships.length) return

    const matchedMA = marketAreas.find(
      (m) =>
        m.value === resolvedUser.marketAreaId ||
        (resolvedUser.marketArea && m.label?.toLowerCase() === resolvedUser.marketArea?.toLowerCase()),
    )
    setSelectedMarketArea(matchedMA?.value || "")

 const dealerIds = Array.isArray(resolvedUser.dealers)
  ? resolvedUser.dealers
      .map((d) => {
        if (typeof d === "number") return d
        if (typeof d === "string") {
          const byLabel = dealerships.find(
            (dl) => dl.label?.toLowerCase() === d.toLowerCase()
          )
          return byLabel?.value ?? null
        }
        if (d && typeof d === "object") {
          return (
            d.id ??
            dealerships.find(
              (dl) =>
                dl.label?.toLowerCase() === d.dealerShortName?.toLowerCase() ||
                dl.label?.toLowerCase() === d.dealerName?.toLowerCase()
            )?.value ?? null
          )
        }
        return null
      })
      .filter(v => v !== null && v !== undefined && v !== "")
  : []

    // FIX #3: Removed duplicate setSelectedDealerships call
    setSelectedDealerships(dealerIds)
  }, [resolvedUser, marketAreas, dealerships])

  useEffect(() => {
    if (!isAddUserOpen) return

    if (!resolvedUser) {
      setFirstName("")
      setMiddleName("")
      setLastName("")
      setEmail("")
      setSelectedType("")
      setLocation("")
      setSelectedRole("")
      setSelectedRoleId("")
      setSelectedMarketArea("")
      setSelectedDealerships([])
      setErrors({})
    }
  }, [isAddUserOpen, resolvedUser])

  // -------------------- SAVE HANDLER --------------------
 const handleSave = async (e) => {
  e.preventDefault();
  setEmailError("");

 const newErrors = {};
const firstNameError = validateName(firstName);
  if (firstNameError) newErrors.firstName = firstNameError;
const middleNameError =  StringNumber (middleName, { required: false });
if (middleNameError) newErrors.middleName = middleNameError;

  const lastNameError = validateName(lastName);
  if (lastNameError) newErrors.lastName = lastNameError;

  const emailErr = validateEmail(email);
  if (emailErr) newErrors.email = emailErr;

if (!selectedType) newErrors.selectedType = "Please fill out this field";
if (selectedType === "volvo-user" && !location)
  newErrors.location = "Please fill out this field";
if (!selectedRole) newErrors.selectedRole = "Please fill out this field";
if (shouldShowMAandDealership && !selectedMarketArea)
  newErrors.selectedMarketArea = "Please fill out this field";

setErrors(newErrors);
if (Object.keys(newErrors).length > 0) return;


  try {
    setIsSaving(true);

    const exists = users.some(
      (u) =>
        u.email.toLowerCase() === email.toLowerCase() &&
        (!resolvedUser?.id || u.id !== resolvedUser?.id)
    );

    if (exists) {
      setEmailError("This email already exists");
      return;
    }

    const payload = {
      firstName,
      middleName,
      lastName,
      email,
      role: selectedType === "volvo-user" ? "VOLVO_USER" : "DEALER_USER",
      locationType: location === "Region" ? "REGION" : "HQ",
      persona: selectedRole,
      personaId:selectedRoleId,
      marketArea: marketAreas.find((m) => m.value === selectedMarketArea)?.label || "",
      dealers: selectedDealerships,
    };

 if (resolvedUser?.id) payload.id = resolvedUser.id;

    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) { navigate("/"); return; }

    let res;
    if (resolvedUser?.id) {
      res = await axios.put(
         `${API.domain}${API.userManagement.updateUser}`,
        payload,
        { headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` } }
      );
    } else {
      res = await axios.post(
        `${API.domain}${API.userManagement.addUser}`,
        payload,
        { headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` } }
      );
    }

    if (res?.data?.status) {
      onSave(resolvedUser);
      onClose();
      resetForm();
      fetchUsers();
    } else {
      alert(res?.data?.message || "Failed to save user");
    }
  } catch (err) {
       const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";
            }
    alert(message || "Something went wrong");
  } finally {
    setIsSaving(false);
  }
};


  useKeyboardNavigation({
    containerRef: formRef,

    onSubmit: () => {
      formRef.current?.requestSubmit();
    },

    onCancel: () => {
      resetForm();
      onClose();
    },

    enableArrowNavigation: true,
    enableEnterSubmit: true,
  });

  if (!isAddUserOpen) return null

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50"
    tabIndex={0}
    >
      <div className="bg-white p-6  w-full max-w-2xl relative">
        <button
          className="absolute top-3 right-3 w-5 h-5 flex items-center justify-center rounded-full bg-red1 transition duration-200 hover:scale-110"
          onClick={() => {
            resetForm()
            onClose()
          }}
          aria-label="Close"
        >
          <svg width="12" height="12" viewBox="0 0 20 20">
            <circle cx="8" cy="8" r="8" fill="#BF2012" />
            <path d="M6.5 6.5L13.5 13.5M13.5 6.5L6.5 13.5" stroke="white" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>

        <h2 className="text-base text-MediumGrey font-semibold text-center mb-4">
 {headerStatus 
    ? "Create New User" 
    : `Edit ${resolvedUser?.firstName || ""} ${resolvedUser?.lastName || ""}`
  }        </h2>

        <form 
          ref={formRef} className="space-y-4" onSubmit={handleSave}>
          {/* Names */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <input
                type="text"
                placeholder="First Name *"
                className={`w-full text-black text-xs  px-3 py-1.5 focus:outline-none ${
                  errors.firstName ? "border border-red1" : "border border-black/60 hover:border-2 focus:border-2"
                }`}
                maxLength={15}
                value={firstName}
               onChange={(e) => {
    const value = e.target.value;
    setFirstName(value);
    const errorMsg = validateName(value);
    setErrors((prev) => ({ ...prev, firstName: errorMsg }));
  }}
  onBlur={() => {
    const errorMsg = validateName(firstName);
    setErrors((prev) => ({ ...prev, firstName: errorMsg }));
  }}
/>
              
              {errors.firstName && <p className="text-red1 text-xs mt-1">{errors.firstName}</p>}
            </div>
            <div>
              <input
                type="text"
                placeholder="Middle Name"
                maxLength={15}
                className="w-full border border-black/60 text-black text-xs  px-3 py-1.5 hover:border-2 focus:outline-none focus:border-2"
                value={middleName}
  onChange={(e) => {
      const value = e.target.value;
      setMiddleName(value);
      const errorMsg = value ? StringNumber(value) : "";
      setErrors((prev) => ({ ...prev, middleName: errorMsg }));
    }}
    onBlur={() => {
      const errorMsg = middleName ? StringNumber(middleName) : "";
      setErrors((prev) => ({ ...prev, middleName: errorMsg }));
    }}
/>
              {errors.middleName && <p className="text-red1 text-xs mt-1">{errors.middleName}</p>}
            </div>

            {/* Last Name */}
           <div>
   <input
    type="text"
    placeholder="Last Name *"
    value={lastName}
    maxLength={15}
    onChange={(e) => {
      const value = e.target.value;
      setLastName(value);

      const errorMsg = validateLastName(value);
      setErrors((prev) => ({ ...prev, lastName: errorMsg }));
    }}
    onBlur={() => {
      const trimmed = lastName.trim();
      setLastName(trimmed);

      const errorMsg = validateLastName(trimmed);
      setErrors((prev) => ({ ...prev, lastName: errorMsg }));
    }}
    className={`w-full border text-black text-xs px-3 py-1.5 hover:border-2 focus:outline-none focus:border-2 ${
      errors.lastName ? "border-red1" : "border-black/60"
    }`}
  />

  {errors.lastName && (
    <p className="text-red1 text-xs mt-1">{errors.lastName}</p>
  )}
</div>
          </div>

          {/* Email — FIX #2: maxLength={100} instead of {75-100} which evaluated to -25 */}
          <div>
            <input
              type="email"
              placeholder="Email ID *"
              className={`w-full text-black text-xs  px-3 py-1.5 focus:outline-none ${
                errors.email ? "border border-red1" : "border border-black/60 hover:border-2 focus:border-2"
              }`}
              value={email}
              maxLength={100}
             onChange={(e) => {
    const value = e.target.value;
    setEmail(value);
    const errorMsg = validateEmail(value);
    setErrors((prev) => ({ ...prev, email: errorMsg }));
  }}
  onBlur={() => {
    const errorMsg = validateEmail(email);
    setErrors((prev) => ({ ...prev, email: errorMsg }));
  }}
            />
            {errors.email && <p className="text-red1 text-xs mt-1">{errors.email}</p>}
            {emailError && <p className="text-red1 text-xs mt-1">{emailError}</p>}
          </div>

          {/* ═══════════════════════════════════════════════════════════ */}
          {/* USER TYPE DROPDOWN                                         */}
          {/* FIX #5: DropdownArrow, FIX #6: tabIndex + onKeyDown        */}
          {/* FIX #8: Show all options with highlight                     */}
          {/* ═══════════════════════════════════════════════════════════ */}
          <div className="relative w-full" ref={typeRef}>
            <div
              className={`w-full border px-3 py-1.5 pr-10 text-xs cursor-pointer transition-all duration-200 ${
                errors.selectedType
                  ? "border-red1"
                  : isTypeDropdownOpen
                    ? "bg-white border-l border-r border-t border-black/60 text-black border-b-0"
                    : "bg-white border-black/60 hover:border-2 focus:outline-none focus:border-1"
              } focus:ring-1 focus:ring-darkblue1`}
              tabIndex={0}
              onClick={() => setIsTypeDropdownOpen((v) => !v)}
              onKeyDown={(e) => handleDropdownKeyDown(e, () => setIsTypeDropdownOpen((v) => !v))}
            >
              <div className={`text-xs font-normal ${selectedType ? "text-black" : "text-gray-400"}`}>
                {selectedType ? types.find((t) => t.value === selectedType)?.label : "Select User Type *"}
              </div>
            </div>

            <DropdownArrow
              onClick={(e) => { e.stopPropagation(); setIsTypeDropdownOpen((v) => !v) }}
              isOpen={isTypeDropdownOpen}
              className="top-4"
            />

            {isTypeDropdownOpen && (
  <ul 
    ref={typeListRef}
  className="absolute w-full bg-white border-l border-r border-b border-black/60 mt-0 max-h-52 overflow-auto shadow-md z-50">
    
    {types.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1 z-10">
        <input
          type="text"
          placeholder="Search types..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </li>
    )}

    {/* FIX #8: Show ALL options including selected, with highlight */}
    {types
      .filter((type) =>
        !searchTerm ? true : type.label.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .sort((a, b) => a.label.localeCompare(b.label))
      .map((type) => (
       <li
  tabIndex={0}
  key={type.value}
  className={`px-3 py-1.5 cursor-pointer text-xs ${
    selectedType === type.value
      ? "bg-darkblue1/10 text-darkblue1 font-medium"
      : "hover:bg-lightBlue"
  }`}
  onKeyDown={(e) => {
    const items = Array.from(typeListRef.current.querySelectorAll("li[tabindex]"));
    const currentIndex = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      const next = (currentIndex + 1) % items.length;
      items[next]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      const prev = (currentIndex - 1 + items.length) % items.length;
      items[prev]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsTypeDropdownOpen(false);
      return;
    }
    if (e.key === "Enter") {
      setSelectedType(type.value);
      setSelectedRole("");
      setSelectedRoleId("");
      e.stopPropagation();   
      setLocation("");
      setIsTypeDropdownOpen(false);
      setSearchTerm("");
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setSelectedType(type.value);
    setSelectedRole("");
    setSelectedRoleId("");
    setLocation("");
    setIsTypeDropdownOpen(false);
    setSearchTerm("");
  }}
>
  {type.label}
</li>
      ))}
    
    {types.filter(
      (type) =>
        (!searchTerm || type.label.toLowerCase().includes(searchTerm.toLowerCase()))
    ).length === 0 && (
      <li className="px-3 py-1.5 text-xs text-gray-500">No results found</li>
    )}
  </ul>
)}

            {errors.selectedType && <p className="text-red1 text-xs mt-1">{errors.selectedType}</p>}
          </div>

          {/* ═══════════════════════════════════════════════════════════ */}
          {/* LOCATION DROPDOWN (Volvo Users only)                       */}
          {/* FIX #7: Display "Headquarters" but map to "Head Quarter"    */}
          {/* FIX #10: "No results" uses same array as display options    */}
          {/* ═══════════════════════════════════════════════════════════ */}
          {selectedType === "volvo-user" && (
            <div className="relative w-full" ref={locationRef}>
              <div
                className={`w-full border px-3 py-1.5 pr-10 text-xs cursor-pointer transition-all duration-200 ${
                  errors.location
                    ? "border-red1"
                    : isLocationDropdownOpen
                      ? "bg-white border-l border-r border-t border-black/60 text-black border-b-0"
                      : "bg-white border-black/60 hover:border-2 focus:outline-none focus:border-1"
                } focus:ring-1 focus:ring-darkblue1`}
                tabIndex={0}
                onClick={() => setIsLocationDropdownOpen((v) => !v)}
                onKeyDown={(e) => handleDropdownKeyDown(e, () => setIsLocationDropdownOpen((v) => !v))}
              >
                <div className={`text-xs font-normal ${location ? "text-black" : "text-gray-400"}`}>
                  {location || "Select Location *"}
                </div>
              </div>

              <DropdownArrow
                onClick={(e) => { e.stopPropagation(); setIsLocationDropdownOpen((v) => !v) }}
                isOpen={isLocationDropdownOpen}
                className="top-4"
              />

            {isLocationDropdownOpen && (
  <ul 
    ref={locationListRef}
  className="absolute w-full bg-white border-l border-r border-b border-black/60 mt-0 max-h-52 overflow-auto shadow-md z-50">
    
    {["Headquarters", "Region"].length > 5 && (
      <li className="px-3 py-1">
        <input
          type="text"
          placeholder="Search locations..."
          value={locationSearch}
          onChange={(e) => setLocationSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </li>
    )}

    {/* FIX #8: Show all options with highlight */}
    {["Headquarters", "Region"]
      .filter((loc) =>
        !locationSearch ? true : loc.toLowerCase().includes(locationSearch.toLowerCase())
      )
      .sort((a, b) => a.localeCompare(b))
      .map((loc) => (
   <li
  tabIndex={0}
  key={loc}
  className={`px-3 py-1.5 cursor-pointer text-xs ${
    location === loc
      ? "bg-darkblue1/10 text-darkblue1 font-medium"
      : "hover:bg-lightBlue"
  }`}
  onKeyDown={(e) => {
    const items = Array.from(locationListRef.current.querySelectorAll("li[tabindex]"));
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsLocationDropdownOpen(false);
      return;
    }
    if (e.key === "Enter") {
      setLocation(loc);
      setSelectedRole("");
      setSelectedRoleId("");
      setIsLocationDropdownOpen(false);
      e.stopPropagation();   
      setLocationSearch("");
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setLocation(loc);
    setSelectedRole("");
    setSelectedRoleId("");
    setIsLocationDropdownOpen(false);
    setLocationSearch("");
  }}
>
  {loc}
</li>
      ))}

    {/* FIX #10: Use same array ["Headquarters", "Region"] for "no results" check */}
    {["Headquarters", "Region"]
      .filter((loc) =>
        !locationSearch ? true : loc.toLowerCase().includes(locationSearch.toLowerCase())
      ).length === 0 && (
        <li className="px-3 py-1.5 text-xs text-gray-500">No results found</li>
      )}
  </ul>
)}

              {errors.location && <p className="text-red1 text-xs mt-1">{errors.location}</p>}
            </div>
          )}

          {/* ═══════════════════════════════════════════════════════════ */}
          {/* ROLE DROPDOWN                                               */}
          {/* ═══════════════════════════════════════════════════════════ */}
          <div className="relative w-full" ref={roleRef}>
            <div
              className={`w-full border px-3 py-1.5 pr-10 text-xs cursor-pointer transition-all duration-200 ${
                errors.selectedRole
                  ? "border-red1"
                  : isRoleDropdownOpen
                    ? "bg-white border-l border-r border-t border-black/60 text-black border-b-0"
                    : "bg-white border-black/60 hover:border-2 focus:outline-none focus:border-1"
              } focus:ring-1 focus:ring-darkblue1`}
              tabIndex={0}
              onClick={() => setIsRoleDropdownOpen((v) => !v)}
              onKeyDown={(e) => handleDropdownKeyDown(e, () => setIsRoleDropdownOpen((v) => !v))}
            >
              <div className={`text-xs font-normal ${selectedRole ? "text-black" : "text-gray-400"}`}>
                {selectedRole ? selectedRole : "Select User Role *"}
              </div>
            </div>

            <DropdownArrow
              onClick={(e) => { e.stopPropagation(); setIsRoleDropdownOpen((v) => !v) }}
              isOpen={isRoleDropdownOpen}
              className="top-4"
            />

            {isRoleDropdownOpen && (
  <ul 
   ref={roleListRef}
  className="absolute w-full bg-white border-l border-r border-b border-black/60 mt-0 max-h-40 overflow-auto shadow-md z-50">

    {rolesList.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1 z-10">
        <input
          type="text"
          placeholder="Search roles..."
          value={roleSearch}
          onChange={(e) => setRoleSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </li>
    )}

    {/* FIX #8: Show all roles with highlight */}
    {rolesList
      .filter((r) =>
        !roleSearch ? true : r.label.toLowerCase().includes(roleSearch.toLowerCase())
      )
      .sort((a, b) => a.label.localeCompare(b.label))
      .map((r) => (
       <li
  tabIndex={0}
  key={r.id || r.label}
  className={`px-3 py-1.5 cursor-pointer text-xs ${
    selectedRole === r.label
      ? "bg-darkblue1/10 text-darkblue1 font-medium"
      : "hover:bg-lightBlue"
  }`}
  onKeyDown={(e) => {
    const items = Array.from(roleListRef.current.querySelectorAll("li[tabindex]"));
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsRoleDropdownOpen(false);
      return;
    }
    if (e.key === "Enter") {
      setSelectedRole(r.label);
      setSelectedRoleId(r.id);
      setIsRoleDropdownOpen(false);
      e.stopPropagation();   
      setRoleSearch("");
      setErrors((prev) => ({ ...prev, selectedRole: "" }));
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setSelectedRole(r.label);
    setSelectedRoleId(r.id);
    setIsRoleDropdownOpen(false);
    setRoleSearch("");
    setErrors((prev) => ({ ...prev, selectedRole: "" }));
  }}
>
  {r.label}
</li>
      ))}

    {rolesList
      .filter((r) =>
        !roleSearch ? true : r.label.toLowerCase().includes(roleSearch.toLowerCase())
      ).length === 0 && (
        <li className="px-3 py-2 text-xs text-gray-500">No roles found</li>
      )}

  </ul>
)}

            {errors.selectedRole && <p className="text-red1 text-xs mt-1">{errors.selectedRole}</p>}
          </div>

          {/* ═══════════════════════════════════════════════════════════ */}
          {/* MARKET AREA DROPDOWN                                       */}
          {/* ═══════════════════════════════════════════════════════════ */}
          {shouldShowMAandDealership && (
            <div className="relative w-full" ref={marketAreaRef}>
              <div
                className={`w-full border px-3 py-1.5 pr-10 text-xs cursor-pointer flex items-center transition-all duration-200 ${
                  errors.selectedMarketArea
                    ? "border-red1"
                    : isMarketAreaDropdownOpen
                      ? "bg-white border-l border-r border-t border-black/60 text-black border-b-0"
                      : "bg-white border-black/60 hover:border-2 focus:outline-none focus:border-1"
                } focus:ring-1 focus:ring-darkblue1`}
                tabIndex={0}
                onClick={() => setIsMarketAreaDropdownOpen((v) => !v)}
                onKeyDown={(e) => handleDropdownKeyDown(e, () => setIsMarketAreaDropdownOpen((v) => !v))}
              >
                {selectedMarketArea ? (
                  marketAreas.find((m) => m.value === selectedMarketArea)?.label
                ) : (
                  <span className="text-black/60">Select Market Area *</span>
                )}
              </div>

              <DropdownArrow
                onClick={(e) => { e.stopPropagation(); setIsMarketAreaDropdownOpen((prev) => !prev) }}
                isOpen={isMarketAreaDropdownOpen}
                className="top-4"
              />

{isMarketAreaDropdownOpen && (
  <ul
   ref={marketAreaListRef} 
  className="absolute w-full bg-white border-l border-r border-b border-black/60 max-h-40 overflow-auto shadow-md z-50">

    {marketAreas.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1 z-10">
        <input
          type="text"
          placeholder="Search market areas..."
          value={marketAreaSearch}
          onChange={(e) => setMarketAreaSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </li>
    )}

    {marketAreas
      .filter((m) =>
        !marketAreaSearch
          ? true
          : m.label.toLowerCase().includes(marketAreaSearch.toLowerCase())
      )
      .sort((a, b) => a.label.localeCompare(b.label))
      .map((m) => (
       <li
  tabIndex={0}
  key={m.value}
  className={`px-3 py-1.5 text-xs cursor-pointer hover:bg-lightBlue ${
    selectedMarketArea === m.value
      ? "bg-darkblue1/10 text-darkblue1 font-medium"
      : ""
  }`}
  onKeyDown={(e) => {
    const items = Array.from(
      marketAreaListRef.current.querySelectorAll("li[tabindex]")
    );
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsMarketAreaDropdownOpen(false);
      return;
    }
    if (e.key === "Enter") {
      setSelectedMarketArea(m.value);
      setSelectedDealerships([]);
      setIsMarketAreaDropdownOpen(false);
      e.stopPropagation();   
      setMarketAreaSearch("");
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    setSelectedMarketArea(m.value);
    setSelectedDealerships([]);
    setIsMarketAreaDropdownOpen(false);
    setMarketAreaSearch("");
  }}
>
  {m.label}
</li>
      ))}

    {marketAreas
      .filter((m) =>
        !marketAreaSearch
          ? true
          : m.label.toLowerCase().includes(marketAreaSearch.toLowerCase())
      ).length === 0 && (
        <li className="px-3 py-2 text-sm text-black/60 cursor-default">No Market Area found</li>
      )}

  </ul>
)}

              {errors.selectedMarketArea && <p className="text-red1 text-xs mt-1">{errors.selectedMarketArea}</p>}
            </div>
          )}

          {/* ═══════════════════════════════════════════════════════════ */}
          {/* DEALERSHIP DROPDOWN (multi-select)                          */}
          {/* ═══════════════════════════════════════════════════════════ */}
          {shouldShowMAandDealership && (
            <div className="relative w-full mt-4" ref={dealershipRef}>
              <div
                className={`w-full border px-3 py-1.5 pr-10 text-xs cursor-pointer flex flex-wrap gap-2 items-center ${
                  errors.selectedDealerships
                    ? "border-red1"
                    : isDealershipDropdownOpen
                      ? "bg-white border-l border-r border-t border-black/60 text-black border-b-0"
                      : "bg-white border-black/60 hover:border-2 focus:outline-none focus:border-1"
                } focus:ring-1 focus:ring-darkblue1`}
                tabIndex={0}
                onClick={() => setIsDealershipDropdownOpen((v) => !v)}
                onKeyDown={(e) => handleDropdownKeyDown(e, () => setIsDealershipDropdownOpen((v) => !v))}
              >
                {selectedDealerships.length > 0 ? (
                  selectedDealerships.map((val) => {
                    const label = dealerships.find((d) => d.value === val)?.label
                    return (
                      <span
                        key={val}
                        className="flex items-center gap-2 bg-grey2 text-black px-2 py-0 text-xs"
                      >
                        {label}
                        <button
                          type="button"
                          className="text-white hover:text-red-300 text-sm"
                          onClick={(e) => {
                            e.stopPropagation()
                            removeDealership(val)
                          }}
                        >
                           <svg
  width="14"
  height="14"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
  role="img"
  aria-label="Remove"
>
  <circle cx="10" cy="10" r="8" fill="#BF2012" />
  <path
    d="M7.5 7.5L12.5 12.5M12.5 7.5L7.5 12.5"
    stroke="white"
    strokeWidth="2"
    strokeLinecap="round"
  />
</svg>
                        </button>
                      </span>
                    )
                  })
                ) : (
                  <span className="text-black/60">Select Dealership *</span>
                )}
              </div>

              <DropdownArrow
                onClick={(e) => { e.stopPropagation(); setIsDealershipDropdownOpen((prev) => !prev) }}
                isOpen={isDealershipDropdownOpen}
                className="top-1/2"
              />

             {isDealershipDropdownOpen && (
  <ul 
   ref={dealershipListRef}
  className="absolute w-full bg-white border-l border-r border-b border-black/60 max-h-40 overflow-auto shadow-md z-50 mb-5">

    {filteredDealerships.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1 z-10">
        <input
          type="text"
          placeholder="Search dealerships..."
          value={dealershipSearch}
          onChange={(e) => setDealershipSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </li>
    )}

    {filteredDealerships
      .filter((d) =>
        !dealershipSearch
          ? true
          : d.label.toLowerCase().includes(dealershipSearch.toLowerCase())
      )
      .sort((a, b) => a.label.localeCompare(b.label))
      .map((dealer) => (
       <li
  tabIndex={0}
  key={dealer.value}
  className={`px-3 py-1.5 text-xs cursor-pointer hover:bg-lightBlue ${
    selectedDealerships.includes(dealer.value)
      ? "bg-darkblue1/10 text-darkblue1 font-medium"
      : ""
  }`}
  onKeyDown={(e) => {
    const items = Array.from(
      dealershipListRef.current.querySelectorAll("li[tabindex]")
    );
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }
 if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation()
      setIsDealershipDropdownOpen(false);
      return;
    }
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();   
      toggleDealershipSelection(dealer.value);
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    toggleDealershipSelection(dealer.value);
  }}
>
  {dealer.label}
</li>
      ))}

    {filteredDealerships
      .filter((d) =>
        !dealershipSearch
          ? true
          : d.label.toLowerCase().includes(dealershipSearch.toLowerCase())
      ).length === 0 && (
        <li className="px-3 py-2 text-sm text-black/60 cursor-default">No Dealership found</li>
      )}

  </ul>
)}

              {errors.selectedDealerships && <p className="text-red1 text-xs mt-1">{errors.selectedDealerships}</p>}
            </div>
          )}

          {/* Actions — FIX #4: Removed onClick={handleSave} from submit button */}
          <div className="flex justify-center gap-4 mt-4">
            <button
              type="button"
              className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium  hover:bg-mildBlue1 hover:scale-105"
              onClick={() => {
                resetForm()
                onClose()
              }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 18 20" fill="none">
<path d="M3.074 5.70509C3.80907 4.9676 4.68269 4.38271 5.6446 3.98405C6.60651 3.58538 7.63775 3.3808 8.679 3.38209C10.7818 3.38235 12.7984 4.21781 14.2854 5.70473C15.7723 7.19165 16.6077 9.20827 16.608 11.3111C16.6077 13.4148 15.7726 15.4325 14.286 16.921C12.7993 18.4095 10.7827 19.2472 8.679 19.2501C6.57509 19.2472 4.55834 18.4094 3.07168 16.9206C1.58502 15.4319 0.749998 13.414 0.75 11.3101" stroke="#1B365D" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round"/>
<path d="M3.79923 0.750122L2.84923 4.60812C2.76491 4.9501 2.81968 5.31155 3.00152 5.61319C3.18337 5.91483 3.47744 6.13203 3.81923 6.21712L7.68823 7.16512" stroke="#1B365D" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
</svg>
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className={`bg-darkblue1 text-white text-xs font-medium px-8 py-1.5  transition
                ${isSaving ? "opacity-50 cursor-not-allowed" : "hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"}`}
            >
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default AddUser