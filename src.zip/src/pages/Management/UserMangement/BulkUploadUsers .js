"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import * as XLSX from "xlsx";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { API } from "../../../api";
import { ArrowLeft, ChevronDown, ChevronUp } from "lucide-react";

function BulkUploadUserManagement() {
  const [rows, setRows] = useState([]);
  const [fileName, setFileName] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [duplicateInfo, setDuplicateInfo] = useState(null);
  const [isDragActive, setIsDragActive] = useState(false);

  const [marketAreas, setMarketAreas] = useState([]);
  const [dealers, setDealers] = useState([]);
  const [roleOptions, setRoleOptions] = useState({});
  const [allRoles, setAllRoles] = useState([]);
  const [existingUsers, setExistingUsers] = useState([]);
  const [isDataLoading, setIsDataLoading] = useState(true);

  const [activeDropdown, setActiveDropdown] = useState(null);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0, width: 0 });
  const [dropdownSearch, setDropdownSearch] = useState("");

  const dropdownButtonRefs = useRef({});
  const dropdownMenuRef = useRef(null);
  const tableContainerRef = useRef(null);
  const fileInputRef = useRef(null);

  const navigate = useNavigate();

  // VALIDATION CONSTANTS
  const NAME_MIN_LENGTH = 2;
  const NAME_MAX_LENGTH = 50;
  const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const userTypeOptions = ["Volvo User", "Dealer User"];
  const userLocationOptions = ["Head Quarter", "Region"];

  const handleBack = () => {
    navigate("/usermangement");
  };

  // FETCH EXISTING USERS
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return navigate("/");

        const res = await axios.get(
          `${API.domain}${API.userManagement.getAllUsers}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (res.data?.status) {
          setExistingUsers(res.data.data || []);
        }
      } catch (err) {
        const message = err.response?.data?.message;
        if (message === "token is invalid" || message === "jwt expired") {
          localStorage.removeItem("userToken");
          localStorage.removeItem("superUserToken");
          window.location.href = "/";
        }
        console.error("Error fetching users:", err);
      }
    };
    fetchUsers();
  }, [navigate]);

  // FETCH MARKET AREAS
  useEffect(() => {
    const fetchMarketAreas = async () => {
      try {
        const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return navigate("/");

        const res = await axios.get(
          `${API.domain}${API.userManagement.getMarketarea}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (res.data?.status) {
          setMarketAreas(res.data.data || []);
        }
      } catch (err) {
        const message = err.response?.data?.message;
        if (message === "token is invalid" || message === "jwt expired") {
          localStorage.removeItem("userToken");
          localStorage.removeItem("superUserToken");
          window.location.href = "/";
        }
      }
    };
    fetchMarketAreas();
  }, [navigate]);

  // FETCH DEALERS
  useEffect(() => {
    const fetchDealers = async () => {
      try {
        const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return navigate("/");

        const res = await axios.get(
          `${API.domain}${API.userManagement.getDealers}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (res.data?.status) {
          setDealers(res.data.data || []);
        }
      } catch (err) {
        const message = err.response?.data?.message;
        if (message === "token is invalid" || message === "jwt expired") {
          localStorage.removeItem("userToken");
          localStorage.removeItem("superUserToken");
          window.location.href = "/";
        }
      }
    };
    fetchDealers();
  }, [navigate]);

  // FETCH ROLES
  useEffect(() => {
    const fetchRoles = async () => {
      try {
        const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return navigate("/");

        const res = await axios.get(
          `${API.domain}${API.userManagement.getRoles}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const rolesByType = {};
        const rolesWithIds = [];

        res.data.data.forEach((r) => {
          if (!rolesByType[r.userType]) rolesByType[r.userType] = [];
          if (!rolesByType[r.userType].some(role => role.name === r.userRole)) {
            rolesByType[r.userType].push({ id: r.id, name: r.userRole });
          }
          rolesWithIds.push({ id: r.id, name: r.userRole, userType: r.userType });
        });

        setRoleOptions(rolesByType);
        setAllRoles(rolesWithIds);
        setIsDataLoading(false);
      } catch (err) {
        console.error("Error fetching roles:", err);
        const message = err.response?.data?.message;
        if (message === "token is invalid" || message === "jwt expired") {
          localStorage.removeItem("userToken");
          localStorage.removeItem("superUserToken");
          window.location.href = "/";
        }
        setIsDataLoading(false);
      }
    };
    fetchRoles();
  }, [navigate]);

  const closeDropdown = useCallback(() => {
    setActiveDropdown(null);
    setDropdownSearch("");
  }, []);

  const handleOpenDropdown = (rowIndex, column) => {
    if (activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column) {
      closeDropdown();
      return;
    }

    if (column === "userRole") {
      const row = rows[rowIndex];
      if (!row.userType) {
        toast.warning("Please select User Type first");
        return;
      }
    }

    if (column === "dealership") {
      const row = rows[rowIndex];
      if (!row.marketArea) {
        toast.warning("Please select Market Area first");
        return;
      }
    }

    const refKey = `${rowIndex}-${column}`;
    const buttonEl = dropdownButtonRefs.current[refKey];
    if (buttonEl) {
      const rect = buttonEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const dropdownHeight = 220;

      const spaceBelow = viewportHeight - rect.bottom;
      const openUpward = spaceBelow < dropdownHeight && rect.top > dropdownHeight;

      setDropdownPosition({
        top: openUpward ? rect.top - dropdownHeight : rect.bottom + 2,
        left: rect.left,
        width: Math.max(rect.width, 180),
      });
    }
    setActiveDropdown({ rowIndex, column });
    setDropdownSearch("");
  };

  const handleSelectOption = (rowIdx, column, value) => {
    handleCellChange(rowIdx, column, value);
    closeDropdown();
  };

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return;
      }

      const clickedOnButton = Object.values(dropdownButtonRefs.current).some(
        (ref) => ref?.contains(e.target)
      );

      if (!clickedOnButton) {
        closeDropdown();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [closeDropdown]);

  useEffect(() => {
    const handleTableScroll = () => {
      if (activeDropdown !== null) {
        closeDropdown();
      }
    };

    const tableContainer = tableContainerRef.current;
    if (tableContainer) {
      tableContainer.addEventListener("scroll", handleTableScroll);
    }

    const handleWindowScroll = (e) => {
      if (dropdownMenuRef.current?.contains(e.target)) {
        return;
      }
      if (activeDropdown !== null) {
        closeDropdown();
      }
    };

    window.addEventListener("scroll", handleWindowScroll, true);

    return () => {
      if (tableContainer) {
        tableContainer.removeEventListener("scroll", handleTableScroll);
      }
      window.removeEventListener("scroll", handleWindowScroll, true);
    };
  }, [activeDropdown, closeDropdown]);

  // VALIDATION FUNCTIONS
  const validateFirstName = (value) => {
    if (!value) return { valid: false, error: "First name is required" };
    const trimmed = String(value).trim();
    if (trimmed.length < NAME_MIN_LENGTH) return { valid: false, error: `Min ${NAME_MIN_LENGTH} characters` };
    if (trimmed.length > NAME_MAX_LENGTH) return { valid: false, error: `Max ${NAME_MAX_LENGTH} characters` };
    if (!/^[a-zA-Z\s'-]+$/.test(trimmed)) return { valid: false, error: "Only letters, spaces, hyphens, apostrophes allowed" };
    return { valid: true, error: "" };
  };

  const validateMiddleName = (value) => {
    if (!value) return { valid: true, error: "" };
    const trimmed = String(value).trim();
    if (trimmed.length > NAME_MAX_LENGTH) return { valid: false, error: `Max ${NAME_MAX_LENGTH} characters` };
    if (trimmed && !/^[a-zA-Z\s'-]+$/.test(trimmed)) return { valid: false, error: "Only letters, spaces, hyphens, apostrophes allowed" };
    return { valid: true, error: "" };
  };

  const validateLastName = (value) => {
    if (!value) return { valid: false, error: "Last name is required" };
    const trimmed = String(value).trim();
    if (trimmed.length < NAME_MIN_LENGTH) return { valid: false, error: `Min ${NAME_MIN_LENGTH} characters` };
    if (trimmed.length > NAME_MAX_LENGTH) return { valid: false, error: `Max ${NAME_MAX_LENGTH} characters` };
    if (!/^[a-zA-Z\s'-]+$/.test(trimmed)) return { valid: false, error: "Only letters, spaces, hyphens, apostrophes allowed" };
    return { valid: true, error: "" };
  };

  const validateEmail = (value) => {
    if (!value) return { valid: false, error: "Email is required" };
    const trimmed = String(value).trim().toLowerCase();
    if (!EMAIL_REGEX.test(trimmed)) return { valid: false, error: "Invalid email format" };
    if (trimmed.length > 100) return { valid: false, error: "Email too long" };
    return { valid: true, error: "" };
  };

  const validateUserType = (value) => {
    if (!value) return { valid: false, error: "User type is required" };
    const normalized = value.trim().toLowerCase();
    const match = userTypeOptions.find(opt => opt.toLowerCase() === normalized);
    return match ? { valid: true, value: match, error: "" } : { valid: false, error: "Invalid user type" };
  };

  const validateUserLocation = (value) => {
    if (!value) return { valid: true, value: "", error: "" };
    const normalized = value.trim().toLowerCase();
    const match = userLocationOptions.find(opt => opt.toLowerCase() === normalized);
    return match ? { valid: true, value: match, error: "" } : { valid: false, error: "Invalid location" };
  };

  const validateUserRole = (roleName, userType) => {
    if (!roleName) return { valid: false, error: "User role is required" };
    if (!userType) return { valid: false, error: "Select user type first" };
    
    const rolesForType = roleOptions[userType] || [];
    const normalized = roleName.trim().toLowerCase();
    const match = rolesForType.find(role => role.name.toLowerCase() === normalized);
    return match ? { valid: true, value: match.name, error: "" } : { valid: false, error: "Invalid role for this user type" };
  };

  const validateMarketArea = (value) => {
    if (!value) return { valid: true, value: "", error: "" };
    const normalized = value.trim().toLowerCase();
    const match = marketAreas.find(area => {
      const areaName = (area.marketarea || area.name || "").toLowerCase();
      return areaName === normalized;
    });
    return match ? { valid: true, value: match.marketarea || match.name, error: "" } : { valid: false, error: "Market area not found" };
  };

  const validateDealerships = (dealershipStr, marketArea) => {
    if (!dealershipStr) return { valid: true, value: [], error: "" };
    
    const dealersForMarket = marketArea 
      ? dealers.filter(d => (d.marketName || "").toLowerCase() === marketArea.toLowerCase())
      : dealers;

    const inputDealerships = dealershipStr.split(",").map(d => d.trim()).filter(d => d);
    const validDealerships = [];
    const invalidOnes = [];

    inputDealerships.forEach(inputDealer => {
      const normalized = inputDealer.toLowerCase();
      const match = dealersForMarket.find(d => 
        (d.dealerShortName || "").toLowerCase() === normalized ||
        (d.dealerName || "").toLowerCase() === normalized
      );
      if (match) {
        validDealerships.push(match.dealerShortName || match.dealerName);
      } else {
        invalidOnes.push(inputDealer);
      }
    });

    return {
      valid: validDealerships.length > 0 || inputDealerships.length === 0,
      value: validDealerships,
      error: invalidOnes.length > 0 ? `Invalid dealership(s): ${invalidOnes.join(", ")}` : ""
    };
  };

  // ================= PARSE EXCEL FILE =================
  const parseExcelFile = (arrayBuffer) => {
    const data = new Uint8Array(arrayBuffer);
    const workbook = XLSX.read(data, { type: "array" });
    const sheetName = workbook.SheetNames[0];

    let json = XLSX.utils.sheet_to_json(
      workbook.Sheets[sheetName],
      { defval: "" }
    );

    json = json.filter((row) =>
      Object.values(row).some((cell) => String(cell).trim() !== "")
    );

    const finalRows = json.map((row, idx) => {
      const firstName = String(row["First Name"] || row["first name"] || "").trim();
      const middleName = String(row["Middle Name"] || row["middle name"] || "").trim();
      const lastName = String(row["Last Name"] || row["last name"] || "").trim();
      const email = String(row["Email ID"] || row["Email"] || row["email"] || "").trim().toLowerCase();
      const rawUserType = String(row["User Type"] || row["user type"] || "").trim();
      const rawUserLocation = String(row["User Location"] || row["user location"] || "").trim();
      const rawUserRole = String(row["User Role"] || row["user role"] || "").trim();
      const rawMarketArea = String(row["Market Area"] || row["market area"] || "").trim();
      const rawDealership = String(row["Dealership"] || row["dealership"] || row["Dealer"] || "").trim();

      // Validate each field
      const firstNameVal = validateFirstName(firstName);
      const middleNameVal = validateMiddleName(middleName);
      const lastNameVal = validateLastName(lastName);
      const emailVal = validateEmail(email);
      const userTypeVal = validateUserType(rawUserType);
      const userLocationVal = validateUserLocation(rawUserLocation);
      const userRoleVal = validateUserRole(rawUserRole, userTypeVal.value);
      const marketAreaVal = validateMarketArea(rawMarketArea);
      const dealershipsVal = validateDealerships(rawDealership, marketAreaVal.value);

      const hasError = !firstNameVal.valid || !lastNameVal.valid || !emailVal.valid || 
                      !userTypeVal.valid || !userRoleVal.valid || !dealershipsVal.valid;

      return {
        slNo: idx + 1,
        firstName: firstNameVal.valid ? firstName : "",
        firstNameError: firstNameVal.error,
        middleName: middleNameVal.valid ? middleName : "",
        middleNameError: middleNameVal.error,
        lastName: lastNameVal.valid ? lastName : "",
        lastNameError: lastNameVal.error,
        email: emailVal.valid ? email : "",
        emailError: emailVal.error,
        userType: userTypeVal.valid ? userTypeVal.value : "",
        userTypeError: userTypeVal.error,
        userLocation: userLocationVal.valid ? userLocationVal.value : "",
        userLocationError: userLocationVal.error,
        userRole: userRoleVal.valid ? userRoleVal.value : "",
        userRoleError: userRoleVal.error,
        marketArea: marketAreaVal.valid ? marketAreaVal.value : "",
        marketAreaError: marketAreaVal.error,
        dealerships: dealershipsVal.valid ? dealershipsVal.value : [],
        dealershipsError: dealershipsVal.error,
        hasError,
        isDuplicate: false,
        duplicateReason: "",
      };
    });

    return finalRows;
  };

  // FILE UPLOAD
  const handleBulkUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (isDataLoading) {
      toast.warning("Please wait for data to load before uploading");
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully`);
      } catch (error) {
        console.error("Error parsing Excel file:", error);
        toast.error("Failed to parse Excel file. Please check the format.");
      }
    };

    reader.onerror = () => {
      toast.error("Failed to read the file");
    };

    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  // ================= DRAG AND DROP HANDLERS =================
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    if (isDataLoading) {
      toast.warning("Please wait for data to load before uploading");
      return;
    }

    const file = e.dataTransfer.files[0];
    if (!file) return;

    // Validate file type
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error("Please drop an Excel file (.xlsx or .xls)");
      return;
    }

    setFileName(file.name);
    setDuplicateInfo(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const finalRows = parseExcelFile(event.target.result);
        setRows(finalRows);
        toast.success(`${finalRows.length} row(s) loaded successfully`);
      } catch (error) {
        console.error("Error parsing Excel file:", error);
        toast.error("Failed to parse Excel file. Please check the format.");
      }
    };

    reader.onerror = () => {
      toast.error("Failed to read the file");
    };

    reader.readAsArrayBuffer(file);
  };

  // CHECK DUPLICATES
  const checkDuplicates = async () => {
    if (rows.length === 0) {
      toast.error("No data to check. Please upload a file first.");
      return;
    }

    setIsChecking(true);
    setDuplicateInfo(null);

    try {
      const existingEmails = new Set();
      if (Array.isArray(existingUsers)) {
        existingUsers.forEach(user => {
          if (user.email) {
            existingEmails.add(user.email.toLowerCase());
          }
        });
      }

      const seenInFile = new Set();

      const updatedRows = rows.map((row) => {
        const emailKey = row.email.toLowerCase();

        let isDuplicate = false;
        let duplicateReason = "";

        if (existingEmails.has(emailKey)) {
          isDuplicate = true;
          duplicateReason = "Email already exists in database";
        }

        if (seenInFile.has(emailKey) && !isDuplicate) {
          isDuplicate = true;
          duplicateReason = "Duplicate email within file";
        }

        seenInFile.add(emailKey);

        return {
          ...row,
          isDuplicate,
          duplicateReason,
        };
      });

      setRows(updatedRows);

      const duplicateCount = updatedRows.filter(r => r.isDuplicate).length;

      if (duplicateCount > 0) {
        setDuplicateInfo({
          count: duplicateCount,
          message: `${duplicateCount} duplicate(s) found! These will be skipped during save.`,
          type: "warning"
        });
        toast.warning(`${duplicateCount} duplicate record(s) found!`);
      } else {
        setDuplicateInfo({
          count: 0,
          message: "No duplicates found. All records are unique.",
          type: "success"
        });
        toast.success("No duplicates found!");
      }

    } catch (error) {
      console.error("Error checking duplicates:", error);
      toast.error("Failed to check duplicates");
    } finally {
      setIsChecking(false);
    }
  };

  // EDIT CELL
  const handleCellChange = (rowIdx, key, value) => {
    const updated = [...rows];
    
    if (key === "firstName") {
      const val = validateFirstName(value);
      updated[rowIdx].firstName = value;
      updated[rowIdx].firstNameError = val.error;
    } else if (key === "middleName") {
      const val = validateMiddleName(value);
      updated[rowIdx].middleName = value;
      updated[rowIdx].middleNameError = val.error;
    } else if (key === "lastName") {
      const val = validateLastName(value);
      updated[rowIdx].lastName = value;
      updated[rowIdx].lastNameError = val.error;
    } else if (key === "email") {
      const val = validateEmail(value);
      updated[rowIdx].email = value.toLowerCase();
      updated[rowIdx].emailError = val.error;
      updated[rowIdx].isDuplicate = false;
      updated[rowIdx].duplicateReason = "";
    } else if (key === "userType") {
      const val = validateUserType(value);
      updated[rowIdx].userType = val.valid ? val.value : "";
      updated[rowIdx].userTypeError = val.error;
      updated[rowIdx].userRole = "";
      updated[rowIdx].userRoleError = "";
    } else if (key === "userLocation") {
      const val = validateUserLocation(value);
      updated[rowIdx].userLocation = val.valid ? val.value : "";
      updated[rowIdx].userLocationError = val.error;
    } else if (key === "userRole") {
      const val = validateUserRole(value, updated[rowIdx].userType);
      updated[rowIdx].userRole = val.valid ? val.value : "";
      updated[rowIdx].userRoleError = val.error;
    } else if (key === "marketArea") {
      const val = validateMarketArea(value);
      updated[rowIdx].marketArea = val.valid ? val.value : "";
      updated[rowIdx].marketAreaError = val.error;
      updated[rowIdx].dealerships = [];
    } else if (key === "dealership") {
      const val = validateDealerships(value, updated[rowIdx].marketArea);
      updated[rowIdx].dealerships = val.value;
      updated[rowIdx].dealershipsError = val.error;
    }

    updated[rowIdx].hasError = !(
      updated[rowIdx].firstName &&
      updated[rowIdx].lastName &&
      updated[rowIdx].email &&
      updated[rowIdx].userType &&
      updated[rowIdx].userRole &&
      !updated[rowIdx].firstNameError &&
      !updated[rowIdx].lastNameError &&
      !updated[rowIdx].emailError &&
      !updated[rowIdx].userTypeError &&
      !updated[rowIdx].userRoleError
    );

    setRows(updated);
    setDuplicateInfo(null);
  };

  const toggleDealership = (rowIdx, dealerShortName) => {
    const updated = [...rows];
    const currentDealerships = updated[rowIdx].dealerships || [];

    if (currentDealerships.includes(dealerShortName)) {
      updated[rowIdx].dealerships = currentDealerships.filter((d) => d !== dealerShortName);
    } else {
      updated[rowIdx].dealerships = [...currentDealerships, dealerShortName];
    }

    setRows(updated);
    setDuplicateInfo(null);
  };

  const clearAllDealerships = (rowIdx) => {
    const updated = [...rows];
    updated[rowIdx].dealerships = [];
    setRows(updated);
    setDuplicateInfo(null);
  };

  const handleDeleteRow = (rowIdx) => {
    const updated = rows.filter((_, idx) => idx !== rowIdx);
    setRows(updated);
    setDuplicateInfo(null);
    closeDropdown();
  };

  const getDealersForMarket = (market) => {
    if (!market) return dealers;
    return dealers.filter(d =>
      (d.marketName || "").toLowerCase() === market.toLowerCase()
    );
  };

  const getRoleId = (roleName, userType) => {
    const role = allRoles.find(r =>
      r.name.toLowerCase() === roleName.toLowerCase() &&
      r.userType === userType
    );
    return role ? role.id : null;
  };

  const getDealerId = (dealerName) => {
    const dealer = dealers.find(d =>
      (d.dealerShortName || "").toLowerCase() === dealerName.toLowerCase() ||
      (d.dealerName || "").toLowerCase() === dealerName.toLowerCase()
    );
    return dealer ? dealer.id : null;
  };

  const getRolesForUserType = (userType) => {
    if (!userType || !roleOptions[userType]) return [];
    return roleOptions[userType].map(r => r.name);
  };

  const handleSave = async () => {
    const hasError = rows.some((r) =>
      r.hasError || !r.firstName || !r.lastName || !r.email || !r.userType || !r.userRole
    );

    if (hasError) {
      toast.error("Please fix all validation errors before saving. Check red highlighted fields.");
      return;
    }

    if (rows.length === 0) {
      toast.error("No data to save. Please upload a file first.");
      return;
    }

    const rowsToSave = rows.filter(r => !r.isDuplicate);

    if (rowsToSave.length === 0) {
      toast.error("All records are duplicates. Nothing to save.");
      return;
    }

    setIsSaving(true);

    try {
      const token = localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
      if (!token) {
        navigate("/");
        return;
      }

      const payload = rowsToSave.map((r) => {
        const role = r.userType === "Volvo User" ? "VOLVO_USER" : "DEALER_USER";
        const locationType = r.userLocation === "Head Quarter" ? "HQ" :
          r.userLocation === "Region" ? "REGION" : "";

        const personaId = getRoleId(r.userRole, r.userType);

        const dealerIds = [];
        if (r.dealerships && r.dealerships.length > 0) {
          r.dealerships.forEach(name => {
            const dealerId = getDealerId(name);
            if (dealerId) dealerIds.push(dealerId);
          });
        }

        return {
          firstName: r.firstName.trim(),
          middleName: r.middleName.trim(),
          lastName: r.lastName.trim(),
          email: r.email.trim().toLowerCase(),
          role: role,
          locationType: locationType,
          persona: r.userRole.trim(),
          personaId: personaId,
          marketArea: r.marketArea.trim(),
          dealers: dealerIds
        };
      });

      const response = await axios.post(
        `${API.domain}${API.userManagement.bulkAddUser}`,
        { rows: payload },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.data?.status) {
        const insertedCount = response.data.data?.inserted || payload.length;
        const invalidCount = response.data.data?.invalid || 0;

        if (invalidCount > 0) {
          toast.success(
            `${insertedCount} user(s) added successfully! ${invalidCount} duplicate(s) were skipped.`,
            { autoClose: 5000 }
          );
        } else {
          toast.success(`${insertedCount} user(s) added successfully!`);
        }

        setTimeout(() => {
          navigate("/usermangement");
        }, 1500);
      } else {
        toast.error(response.data?.message || "Failed to upload users");
      }
    } catch (error) {
      console.error("Bulk upload error:", error);
      const message = error.response?.data?.message;
      if (message === "token is invalid" || message === "jwt expired") {
        localStorage.removeItem("userToken");
        localStorage.removeItem("superUserToken");
        window.location.href = "/";
      }
      toast.error(error.response?.data?.message || error.message || "Failed to upload users");
    } finally {
      setIsSaving(false);
    }
  };

  const handleClearAll = () => {
    setRows([]);
    setFileName("");
    setDuplicateInfo(null);
    closeDropdown();
  };

  const getDropdownOptions = () => {
    if (!activeDropdown) return [];

    const { rowIndex, column } = activeDropdown;
    const row = rows[rowIndex];
    let options = [];

    switch (column) {
      case "userType":
        options = userTypeOptions.map(ut => ({ id: ut, label: ut }));
        break;
      case "userLocation":
        options = userLocationOptions.map(ul => ({ id: ul, label: ul }));
        break;
      case "userRole":
        const roles = getRolesForUserType(row?.userType);
        options = roles.map(r => ({ id: r, label: r }));
        break;
      case "marketArea":
        options = marketAreas.map(m => ({
          id: m.marketarea || m.name,
          label: m.marketarea || m.name
        }));
        break;
      case "dealership":
        const filteredDealers = getDealersForMarket(row?.marketArea);
        options = filteredDealers.map(d => ({
          id: d.dealerShortName,
          label: d.dealerShortName || d.dealerName
        }));
        break;
      default:
        options = [];
    }

    if (dropdownSearch) {
      options = options.filter(opt =>
        opt.label.toLowerCase().includes(dropdownSearch.toLowerCase())
      );
    }

    return options;
  };

  const getDisplayValue = (row, column) => {
    switch (column) {
      case "userType":
        return row.userType || "";
      case "userLocation":
        return row.userLocation || "";
      case "userRole":
        return row.userRole || "";
      case "marketArea":
        return row.marketArea || "";
      case "dealership":
        if (row.dealerships?.length > 0) {
          return row.dealerships.join(", ");
        }
        return "";
      default:
        return "";
    }
  };

  const isValueSelected = (row, column, optionId) => {
    if (column === "dealership") {
      return row.dealerships?.includes(optionId) || false;
    }
    return row[column] === optionId;
  };

  const getPlaceholder = (column, row) => {
    switch (column) {
      case "userType":
        return "Select User Type";
      case "userLocation":
        return "Select Location";
      case "userRole":
        if (row && !row.userType) return "Select User Type first";
        return "Select Role";
      case "marketArea":
        return "Select Market Area";
      case "dealership":
        if (row && !row.marketArea) return "Select Market Area first";
        return "Select Dealership";
      default:
        return "Select";
    }
  };

  const getSearchPlaceholder = (column) => {
    switch (column) {
      case "userType":
        return "Search user type...";
      case "userLocation":
        return "Search location...";
      case "userRole":
        return "Search role...";
      case "marketArea":
        return "Search market area...";
      case "dealership":
        return "Search dealership...";
      default:
        return "Search...";
    }
  };

  const isFieldInvalid = (row, column) => {
    switch (column) {
      case "userType":
        return !row.userType || row.userTypeError;
      case "userRole":
        return !row.userRole || row.userRoleError;
      default:
        return false;
    }
  };

  const isDropdownDisabled = (row, column) => {
    if (column === "userRole") {
      return !row.userType;
    }
    if (column === "dealership") {
      return !row.marketArea;
    }
    return false;
  };

  const renderDropdownButton = (row, rowIndex, column) => {
    const isInvalid = isFieldInvalid(row, column);
    const displayValue = getDisplayValue(row, column);
    const placeholder = getPlaceholder(column, row);
    const isOpen = activeDropdown?.rowIndex === rowIndex && activeDropdown?.column === column;
    const refKey = `${rowIndex}-${column}`;
    const isDisabled = isDropdownDisabled(row, column);
    const isDealerships = column === "dealership";

    return (
      <div
        ref={(el) => (dropdownButtonRefs.current[refKey] = el)}
        className={`flex justify-between items-start px-2 py-1 border text-xs min-h-[26px] ${
          isDisabled
            ? "border-gray-200 bg-gray-100 cursor-not-allowed"
            : isInvalid
              ? "border-red-500 bg-red-50 cursor-pointer"
              : row.isDuplicate
                ? "border-yellow-500 bg-yellow-50 cursor-pointer"
                : "border-gray-300 bg-white hover:border-gray-400 cursor-pointer"
        }`}
        onClick={() => !isDisabled && handleOpenDropdown(rowIndex, column)}
      >
        <span className={`flex-1 ${isDealerships ? "break-words" : "truncate"} ${
          displayValue ? "text-gray-800" : isDisabled ? "text-gray-400 italic" : "text-gray-400"
        }`}>
          {displayValue || placeholder}
        </span>
        {!isDisabled && (
          isOpen ? (
            <ChevronUp className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1 mt-0.5" />
          ) : (
            <ChevronDown className="w-3 h-3 text-gray-400 flex-shrink-0 ml-1 mt-0.5" />
          )
        )}
      </div>
    );
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex-1 flex justify-center`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">

          <div className="flex items-center gap-2">
            <ArrowLeft
              onClick={handleBack}
              size={20}
              className="cursor-pointer hover:scale-110 text-white bg-darkblue1 p-1"
            />
            <h2 className="text-sm font-semibold text-darkblue1">
              User Management Bulk Upload
            </h2>
          </div>
          <div className="hidden lg:block h-1 bg-darkblue1 w-[8%] ml-7 mb-2"></div>

          {isDataLoading && (
            <div className="mb-2 p-2 bg-blue-50 border border-blue-200 text-blue-600 text-xs flex items-center gap-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              Loading roles and market data...
            </div>
          )}

          <div className="mb-4 flex flex-wrap items-center gap-2 w-full">
            {/* Drag & Drop Area */}
            <div
              className={`flex-1 min-w-[200px] max-w-md flex items-center border-2 border-dashed px-3 py-1.5 text-xs transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-black/30 bg-white hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="mr-2 flex-shrink-0"
              >
                <path
                  d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z"
                  fill="black"
                />
              </svg>

              <span className="text-xs text-gray-700 truncate">
                {isDragActive
                  ? "Drop file here..."
                  : fileName || "Drag & drop or click Browse"}
              </span>
              <input
                type="file"
                ref={fileInputRef}
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleBulkUpload}
                id="bulk-upload-input"
                disabled={isDataLoading}
              />
            </div>

            <label
              htmlFor="bulk-upload-input"
              className={`px-3 py-1.5 bg-darkblue1 text-white text-xs cursor-pointer hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition ${isDataLoading ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              Browse
            </label>

            {rows.length > 0 && (
              <>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 bg-gray-500 text-white text-xs hover:bg-gray-600 transition"
                >
                  Clear
                </button>

                <button
                  onClick={checkDuplicates}
                  disabled={isChecking || rows.length === 0}
                  className="px-3 py-1.5 bg-yellow-600 text-white text-xs hover:bg-yellow-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  {isChecking && (
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                  )}
                  {isChecking ? "Checking..." : "Check Duplicates"}
                </button>
              </>
            )}

            <button
              onClick={handleSave}
              disabled={isSaving || rows.length === 0 || isDataLoading}
              className="px-4 py-1.5 bg-darkblue1 text-white text-xs hover:bg-white hover:border hover:border-darkblue1 hover:text-darkblue1 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              {isSaving && (
                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
              )}
              {isSaving ? "Saving..." : "Save"}
            </button>
          </div>

          {duplicateInfo && (
            <div className={`mb-2 p-2 border text-xs flex items-center justify-between ${
              duplicateInfo.type === "warning"
                ? "bg-yellow-50 border-yellow-300 text-yellow-700"
                : "bg-green-50 border-green-300 text-green-700"
            }`}>
              <span>
                <span className="font-medium">
                  {duplicateInfo.type === "warning" ? "⚠️ " : "✅ "}
                </span>
                {duplicateInfo.message}
              </span>
              <button
                onClick={() => setDuplicateInfo(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
          )}

          {rows.length > 0 && rows.some(r => r.hasError) && (
            <div className="mb-2 p-2 bg-red-50 border border-red-200 text-red-600 text-xs">
              <span className="font-medium">⚠️ {rows.filter(r => r.hasError).length} row(s) have validation errors.</span>
              <span className="ml-2">Check red highlighted cells for details.</span>
            </div>
          )}

          {rows.length > 0 ? (
            <div className="overflow-auto border border-Dustyblue mb-2 bg-white shadow-md">
              <div ref={tableContainerRef} className="overflow-y-auto max-h-[400px]">
                <table className="w-full text-xs bg-white border-collapse min-w-[1600px]">
                  <thead className="bg-Dustyblue text-white sticky top-0 z-20">
                    <tr>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[2%]">#</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[8%]">First Name <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[8%]">Middle Name</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[8%]">Last Name <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[12%]">Email ID <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[8%]">User Type <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[8%]">Location</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[10%]">User Role <span className="text-red-300">*</span></th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[8%]">Market Area</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-left w-[10%]">Dealership</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 font-medium text-center w-[5%]">Status</th>
                      <th className="px-2 py-1.5 text-xs border border-grey2 border-t-0 border-l-0 border-r-0 font-medium text-center w-[3%]">Action</th>
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((row, i) => (
                      <tr
                        key={i}
                        className={`text-xs hover:bg-lightBlue/50 ${
                          row.hasError ? "bg-red-50" : row.isDuplicate ? "bg-yellow-50" : ""
                        }`}
                      >
                        <td className="px-2 py-1.5 border border-grey2 border-l-0 text-center text-gray-500">
                          {i + 1}
                        </td>

                        <td className="px-2 py-1.5 border border-grey2">
                          <div>
                            <input
                              type="text"
                              className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                                row.firstNameError ? "border-red-500 bg-red-50" : "border-gray-300"
                              }`}
                              value={row.firstName}
                              placeholder="First Name"
                              onChange={(e) => handleCellChange(i, "firstName", e.target.value)}
                            />
                            {row.firstNameError && <span className="text-red-500 text-[10px]">{row.firstNameError}</span>}
                          </div>
                        </td>

                        <td className="px-2 py-1.5 border border-grey2">
                          <div>
                            <input
                              type="text"
                              className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                                row.middleNameError ? "border-red-500 bg-red-50" : "border-gray-300"
                              }`}
                              value={row.middleName}
                              placeholder="Middle Name"
                              onChange={(e) => handleCellChange(i, "middleName", e.target.value)}
                            />
                            {row.middleNameError && <span className="text-red-600 text-[10px]">{row.middleNameError}</span>}
                          </div>
                        </td>

                        <td className="px-2 py-1.5 border border-grey2">
                          <div>
                            <input
                              type="text"
                              className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                                row.lastNameError ? "border-red-500 bg-red-50" : "border-gray-300"
                              }`}
                              value={row.lastName}
                              placeholder="Last Name"
                              onChange={(e) => handleCellChange(i, "lastName", e.target.value)}
                            />
                            {row.lastNameError && <span className="text-red-600 text-[10px]">{row.lastNameError}</span>}
                          </div>
                        </td>

                        <td className="px-2 py-1.5 border border-grey2">
                          <div>
                            <input
                              type="email"
                              className={`w-full text-xs border px-2 py-1 focus:outline-none focus:ring-1 focus:ring-darkblue1 ${
                                row.emailError
                                  ? "border-red-500 bg-red-50"
                                  : row.isDuplicate
                                    ? "border-yellow-500 bg-yellow-50"
                                    : "border-gray-300"
                              }`}
                              value={row.email}
                              placeholder="Email"
                              onChange={(e) => handleCellChange(i, "email", e.target.value)}
                            />
                            {row.emailError && <span className="text-red-600 text-[10px]">{row.emailError}</span>}
                          </div>
                        </td>

                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "userType")}
                          {row.userTypeError && <span className="text-red-600 text-[10px]">{row.userTypeError}</span>}
                        </td>

                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "userLocation")}
                        </td>

                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "userRole")}
                          {row.userRoleError && <span className="text-red-600 text-[10px]">{row.userRoleError}</span>}
                        </td>

                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "marketArea")}
                          {row.marketAreaError && <span className="text-red-600 text-[10px]">{row.marketAreaError}</span>}
                        </td>

                        <td className="px-2 py-1.5 border border-grey2">
                          {renderDropdownButton(row, i, "dealership")}
                          {row.dealershipsError && <span className="text-red-600 text-[10px]">{row.dealershipsError}</span>}
                        </td>

                        <td className="px-2 py-1.5 border border-grey2 text-center">
                          {row.hasError ? (
                            <span className="px-2 py-0.5 bg-red-100 text-red-600 text-[10px] rounded-full">
                              Error
                            </span>
                          ) : row.isDuplicate ? (
                            <span
                              className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full cursor-help"
                              title={row.duplicateReason}
                            >
                              Duplicate
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-green-100 text-green-600 text-[10px] rounded-full">
                              Valid
                            </span>
                          )}
                        </td>

                        <td className="px-2 py-1.5 border border-grey2 border-r-0 text-center">
                          <button
                            onClick={() => handleDeleteRow(i)}
                            className="text-red-500 hover:text-red-700 transition"
                            title="Delete Row"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-9l-1 1H5v2h14V4z"/>
                            </svg>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="px-4 py-2 bg-gray-50 border-t border-grey2 flex flex-wrap justify-between items-center gap-2 text-xs">
                <span className="text-gray-600">
                  Total: {rows.length} | 
                  <span className="text-green-600 ml-1">Valid: {rows.filter(r => !r.hasError && !r.isDuplicate).length}</span> |
                  <span className="text-yellow-600 ml-1">Duplicates: {rows.filter(r => r.isDuplicate).length}</span> |
                  <span className="text-red-600 ml-1">Errors: {rows.filter(r => r.hasError).length}</span>
                </span>
              </div>
            </div>
          ) : (
            /* Empty State - WITH DRAG AND DROP */
            <div
              className={`bg-white shadow-md border-2 border-dashed p-8 text-center transition cursor-pointer ${
                isDragActive
                  ? "border-darkblue1 bg-blue-50"
                  : "border-Dustyblue hover:border-darkblue1"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" className="w-12 h-12 mx-auto mb-3 opacity-50"> 
                <path d="M11 19H13V14.825L14.6 16.425L16 15L12 11L8 15L9.425 16.4L11 14.825V19ZM6 22C5.45 22 4.97933 21.8043 4.588 21.413C4.19667 21.0217 4.00067 20.5507 4 20V4C4 3.45 4.196 2.97933 4.588 2.588C4.98 2.19667 5.45067 2.00067 6 2H14L20 8V20C20 20.55 19.8043 21.021 19.413 21.413C19.0217 21.805 18.5507 22.0007 18 22H6ZM13 9V4H6V20H18V9H13Z" fill="black"/>
              </svg>

              <p className="text-gray-500 text-sm">
                {isDragActive
                  ? "Drop your Excel file here!"
                  : "No data loaded. Please upload an Excel file to preview."}
              </p>
              <p className="text-gray-400 text-xs mt-1">
                {isDragActive
                  ? "Release to upload"
                  : "Supported formats: .xlsx, .xls (Drag & drop or click Browse)"}
              </p>
            </div>
          )}
        </div>
      </div>

      {activeDropdown !== null && rows[activeDropdown.rowIndex] && (
        <div
          ref={dropdownMenuRef}
          className="fixed border border-gray-300 bg-white z-[9999] shadow-xl rounded overflow-hidden"
          style={{
            top: `${dropdownPosition.top}px`,
            left: `${dropdownPosition.left}px`,
            width: `${dropdownPosition.width}px`,
            minWidth: "180px",
          }}
        >
          <div className="p-2 border-b border-gray-200 bg-gray-50">
            <input
              type="text"
              placeholder={getSearchPlaceholder(activeDropdown.column)}
              value={dropdownSearch}
              onChange={(e) => setDropdownSearch(e.target.value)}
              className="w-full px-2 py-1 text-xs border border-gray-300 rounded focus:outline-none focus:border-darkblue1"
              autoFocus
            />
          </div>

          {activeDropdown.column === "dealership" &&
            rows[activeDropdown.rowIndex]?.dealerships?.length > 0 && (
              <div className="px-3 py-1.5 bg-blue-50 border-b border-gray-200 flex justify-between items-center">
                <span className="text-xs text-blue-600">
                  {rows[activeDropdown.rowIndex].dealerships.length} selected
                </span>
                <button
                  onClick={() => clearAllDealerships(activeDropdown.rowIndex)}
                  className="text-xs text-red-600 hover:text-red-700"
                >
                  Clear all
                </button>
              </div>
            )}

          <div className="max-h-[150px] overflow-y-auto">
            {getDropdownOptions().length > 0 ? (
              getDropdownOptions().map((option) => {
                const isSelected = isValueSelected(rows[activeDropdown.rowIndex], activeDropdown.column, option.id);
                const isMultiSelect = activeDropdown.column === "dealership";

                return (
                  <div
                    key={option.id}
                    className={`flex items-center gap-2 px-3 py-1.5 cursor-pointer text-xs border-b border-gray-100 last:border-b-0 ${
                      isSelected ? "bg-blue-50" : "hover:bg-gray-50"
                    }`}
                    onClick={() => {
                      if (isMultiSelect) {
                        toggleDealership(activeDropdown.rowIndex, option.id);
                      } else {
                        handleSelectOption(activeDropdown.rowIndex, activeDropdown.column, option.id);
                      }
                    }}
                  >
                    {isMultiSelect && (
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => {}}
                        className="w-3 h-3 accent-darkblue1"
                      />
                    )}
                    <span className={isSelected ? "text-blue-700 font-medium" : ""}>{option.label}</span>
                    {isSelected && !isMultiSelect && (
                      <span className="ml-auto text-blue-600">✓</span>
                    )}
                  </div>
                );
              })
            ) : (
              <div className="px-3 py-3 text-xs text-gray-400 text-center">
                No options found
              </div>
            )}
          </div>

          {activeDropdown.column === "dealership" && (
            <div className="p-2 border-t border-gray-200 bg-gray-50">
              <button
                onClick={closeDropdown}
                className="w-full px-3 py-1 text-xs bg-darkblue1 text-white rounded hover:bg-opacity-90"
              >
                Done
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default BulkUploadUserManagement;