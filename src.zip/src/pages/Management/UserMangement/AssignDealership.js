"use client";
import { useState, useEffect, useRef } from "react";
import DeleteModal from "../../../Components/DeleteModal";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { API } from '../../../api';

const AssignDealership = ({ onClose, currentUser, userId, onSave }) => {
  const navigate = useNavigate();
  const [assignments, setAssignments] = useState([]);
  const [originalAssignments, setOriginalAssignments] = useState([]); // Track pre-existing
  const [isOpen, setIsOpen] = useState(null);
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [indexToDelete, setIndexToDelete] = useState(null);
  const containerRef = useRef(null);
const [marketSearch, setMarketSearch] = useState("");
const marketSearchRef = useRef(null);
const [dealerSearch, setDealerSearch] = useState("");
const dealerSearchRef = useRef(null);
const marketAreaListRef = useRef(null);
  const [allMarketAreas, setAllMarketAreas] = useState([]);
  const [selectedMarketAreas, setSelectedMarketAreas] = useState([]);
  const [allAvailableDealersData, setAllAvailableDealersData] = useState([]);
  const [selectedDealers, setSelectedDealers] = useState([]);
const dealerListRef = useRef(null);
  const userEmail = currentUser?.email || "yogesh@alphatechnical.in";
useEffect(() => {
  if (isOpen !== "marketArea") {
    setMarketSearch("");
  }
}, [isOpen]);
useEffect(() => {
  if (isOpen !== "dealer") {
    setDealerSearch("");
  }
}, [isOpen]);

  // Fetch Market Areas
  useEffect(() => {
    const fetchMarketAreas = async () => {
      try {
        const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return navigate("/");

        const res = await axios.get(
           `${API.domain}${API.userManagement.getMarketarea}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (res.data.status) {
          const activeMA = res.data.data
            .filter((ma) => ma.isActive === 1)
            .map((ma) => ({
              value: ma.id,
              label: ma.marketarea,
            }));
          setAllMarketAreas(activeMA);
        }
      } catch (err) {
             const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
      }
    };
    fetchMarketAreas();
  }, [navigate]);

  // Fetch Dealers
  useEffect(() => {
    const fetchDealers = async () => {
      try {
        const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
        if (!token) return navigate("/");

        const res = await axios.get(
         `${API.domain}${API.userManagement.getDealers}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );

        if (res.data.status) {
          const activeDealers = res.data.data
            .filter((d) => d.isActive === 1)
            .map((d) => ({
              value: d.id,
              label: d.dealerShortName,
              marketName: d.marketName,
            }));
          setAllAvailableDealersData(activeDealers);
        }
      } catch (err) {
              const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
      }
    };
    fetchDealers();
  }, [navigate]);

  // Prefill existing assignments
  useEffect(() => {
    if (allAvailableDealersData.length && currentUser?.dealership) {
      const existingDealers = currentUser.dealership
        .split(",")
        .map((d) => d.trim())
        .filter(Boolean);

      const existingAssignments = existingDealers.map((dealership) => {
        const dealer = allAvailableDealersData.find(
          (d) => d.label === dealership
        );
        const marketArea = dealer?.marketName || currentUser.area || "";
        return {
          user: currentUser.email,
          dealership,
          marketArea: marketArea.toUpperCase(),
        };
      });

      setAssignments(existingAssignments);
      setOriginalAssignments(existingAssignments); // Track original assignments
    }
  }, [allAvailableDealersData, currentUser]);

  // Filter dealers dynamically based on selected Market Areas & table
  const filteredDealers = allAvailableDealersData.filter(
    (d) =>
      selectedMarketAreas.some(
        (ma) => ma.label.toUpperCase() === d.marketName.toUpperCase()
      ) &&
      !assignments.some(
        (a) =>
          a.dealership === d.label &&
          a.marketArea.toUpperCase() === d.marketName.toUpperCase()
      )
  );

  const toggleDropdown = (key) =>
    setIsOpen(isOpen === key ? null : key);

  // Multi-select Market Area
  const toggleMarketArea = (ma) => {
    setSelectedMarketAreas((prev) => {
      const exists = prev.some((m) => m.value === ma.value);

      if (exists) {
        // Remove only newly added assignments for this Market Area
        setAssignments((prevAssignments) =>
          prevAssignments.filter(
            (a) =>
              a.marketArea.toUpperCase() !== ma.label.toUpperCase() ||
              originalAssignments.some(
                (orig) =>
                  orig.dealership === a.dealership &&
                  orig.marketArea.toUpperCase() === a.marketArea.toUpperCase()
              )
          )
        );

        setSelectedDealers((prevDealers) =>
          prevDealers.filter(
            (d) => d.marketName.toUpperCase() !== ma.label.toUpperCase()
          )
        );

        return prev.filter((m) => m.value !== ma.value);
      } else {
        return [...prev, ma];
      }
    });
  };

  // Multi-select Dealer
  const toggleDealer = (dealer) => {
    const exists = selectedDealers.some((d) => d.value === dealer.value);
    if (exists) {
      setSelectedDealers((prev) =>
        prev.filter((d) => d.value !== dealer.value)
      );
      setAssignments((prev) =>
        prev.filter(
          (a) =>
            !(
              a.dealership === dealer.label &&
              a.marketArea.toUpperCase() === dealer.marketName.toUpperCase() &&
              !originalAssignments.some(
                (orig) =>
                  orig.dealership === a.dealership &&
                  orig.marketArea.toUpperCase() === a.marketArea.toUpperCase()
              )
            )
        )
      );
    } else {
      setSelectedDealers((prev) => [...prev, dealer]);
      setAssignments((prev) => [
        ...prev,
        {
          user: userEmail,
          dealership: dealer.label,
          marketArea: dealer.marketName.toUpperCase(),
        },
      ]);
    }
  };

  // Delete row
  const handleConfirmDelete = () => {
    if (indexToDelete !== null) {
      const deleted = assignments[indexToDelete];
      setAssignments((prev) =>
        prev.filter((_, i) => i !== indexToDelete)
      );
      setSelectedDealers((prev) =>
        prev.filter((d) => d.label !== deleted.dealership)
      );
      // Remove Market Area if no dealers remain
      const remaining = assignments.filter(
        (a, i) => i !== indexToDelete && a.marketArea === deleted.marketArea
      );
      if (!remaining.some((a) => a.marketArea === deleted.marketArea)) {
        setSelectedMarketAreas((prev) =>
          prev.filter(
            (ma) => ma.label.toUpperCase() !== deleted.marketArea.toUpperCase()
          )
        );
      }
      setIndexToDelete(null);
      setDeleteModalVisible(false);
    }
  };

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside, true);
    return () =>
      document.removeEventListener("mousedown", handleClickOutside, true);
  }, []);

  // Save assignments
  const handleSave = async () => {
    if (!assignments.length) {
      alert("No assignments to save.");
      return;
    }

    const dealerIds = [
      ...new Set(
        assignments
          .map(
            (a) =>
              allAvailableDealersData.find((d) => d.label === a.dealership)
                ?.value
          )
          .filter(Boolean)
      ),
    ];

    if (!dealerIds.length) {
      // alert("No valid dealers selected.");
      return;
    }

    const payload = { id: userId, dealers: dealerIds };

    try {
      const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
      if (!token) return navigate("/");

      const response = await axios.put(
       `${API.domain}${API.userManagement.assignRemoveDealers}`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.data?.status) {
        const userRes = await axios.get(
          ` ${API.domain}${API.userManagement.getUser}/${userId}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );

        if (userRes.data?.status) onSave && onSave(userRes.data.data);
        onClose();
      } else {
        alert(response.data?.message || "Failed to save assignments.");
      }
    } catch (err) {
            const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
      alert("Something went wrong while saving assignments.");
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 z-50 overflow-y-auto py-8 px-2">
      <div className="bg-white p-6  w-full max-w-4xl shadow-lg">
        {/* Header */}
        <div className="relative mb-4">
          <h2 className="text-base font-semibold text-center text-MediumGrey">
            Assign Dealerships
          </h2>
          <button
            className="absolute top-0 right-3 w-5 h-5 flex items-center justify-center rounded-full bg-red1 hover:scale-110"
            onClick={onClose}
          >
            <svg width="14" height="14" viewBox="0 0 20 20">
              <circle cx="8" cy="8" r="8" fill="#BF2012" />
              <path
                d="M6.5 6.5L13.5 13.5M13.5 6.5L6.5 13.5"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
          </button>
        </div>

        <div
          ref={containerRef}
          className="flex flex-wrap justify-left gap-5 mb-2"
        >
          
         {/* Market Area */}
<div className="relative w-full md:w-[230px]">
  <div
    className={` border border-black/60 px-3  py-1.5 pr-8 text-xs cursor-pointer flex flex-wrap gap-2 items-center bg-white hover:ring-1 hover:ring-black ${
      isOpen === "marketArea"
        ? " border-b-white"
        : ""
    }`}
    onClick={() => toggleDropdown("marketArea")}
  >
    {selectedMarketAreas.length > 0 ? (
      selectedMarketAreas.map((ma) => (
        <span
          key={ma.value}
          className="flex items-center gap-1 bg-grey2 text-black px-2 py-1  text-xs"
        >
          {ma.label}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleMarketArea(ma);
            }}
          >
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
              alt="x"
              className="w-3 h-3"
            />
          </button>
        </span>
      ))
    ) : (
      <span className="text-black">Select Market Area *</span>
    )}
  </div>
 <img
             src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Vector (25).png"
               alt="dropdown"
              className={`absolute right-2 top-2.5 w-3 h-3 transition-transform ${isOpen === "marketArea" ? "rotate-180" : ""}`}
              onClick={(e) => {
                e.stopPropagation()
                toggleDropdown("marketArea")
               }}
           />

  {isOpen === "marketArea" && (
  <ul 
  ref={marketAreaListRef}
  className="absolute left-0 right-0 bg-white border border-black/60 border-t-white mt-0 max-h-52 overflow-auto shadow-md z-50">

    {/* 🔍 Search – only if more than 5 options */}
    {allMarketAreas.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1.5 z-10">
        <input
          ref={marketSearchRef}
          type="text"
          placeholder="Search market area..."
          value={marketSearch}
          onChange={(e) => setMarketSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </li>
    )}

    {/* Market area list */}
    {allMarketAreas
      .filter((ma) =>
        !marketSearch
          ? true
          : ma.label.toLowerCase().includes(marketSearch.toLowerCase())
      )
      .map((ma) => {
        const hasDealer = allAvailableDealersData.some(
          (d) =>
            d.marketName.toUpperCase() === ma.label.toUpperCase() &&
            !assignments.some(
              (a) =>
                a.dealership === d.label &&
                a.marketArea.toUpperCase() === d.marketName.toUpperCase()
            )
        );

        return (
         <li
  tabIndex={0}
  key={ma.value}
  className={`px-3 py-1.5 text-xs cursor-pointer hover:bg-lightBlue
    ${
      selectedMarketAreas.some((m) => m.value === ma.value)
        ? "bg-lightBlue/50 font-semibold"
        : ""
    }`}
  onKeyDown={(e) => {
    const items = Array.from(
      marketAreaListRef.current.querySelectorAll("li[tabindex]")
    );
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      toggleMarketArea(ma);
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    toggleMarketArea(ma);
  }}
>
  {ma.label}
</li>
        );
      })}

    {/* No results */}
    {allMarketAreas.filter((ma) =>
      !marketSearch
        ? true
        : ma.label.toLowerCase().includes(marketSearch.toLowerCase())
    ).length === 0 && (
      <li className="px-3 py-2 text-xs text-gray-500">
        No market areas found
      </li>
    )}
  </ul>
)}

</div>

{/* Dealer */}
<div className="relative w-full md:w-[230px]">
  <div
    className={`border border-black/60 px-3 py-1.5 pr-8 text-xs cursor-pointer flex flex-wrap gap-2 items-center bg-white hover:ring-1 hover:ring-black ${
      isOpen === "dealer"
        ? " border-b-white"
        : ""
    }`}
    onClick={() => toggleDropdown("dealer")}
  >
    {selectedDealers.length > 0 ? (
      selectedDealers.map((dealer) => (
        <span
          key={dealer.value}
          className="flex items-center gap-1 bg-grey2 text-black px-2 py-[1px] text-xs"
        >
          {dealer.label}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleDealer(dealer);
            }}
          >
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/MarketAreaatble/cancel.png"
              alt="x"
              className="w-3 h-3"
            />
          </button>
        </span>
      ))
    ) : (
      <span className="text-black">Select Dealer *</span>
    )}
  </div>
 <img
               src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Vector (25).png"
              alt="dropdown"
               className={`absolute right-2 top-2.5 w-3 h-3 transition-transform ${isOpen === "dealer" ? "rotate-180" : ""}`}
           onClick={(e) => {
                e.stopPropagation()
                 toggleDropdown("dealer")
           }}
             />

  {isOpen === "dealer" && (
  <ul 
   ref={dealerListRef}
  className="absolute left-0 right-0 bg-white border border-black/60 border-t-white mt-0 max-h-52 overflow-auto shadow-md z-50">

    {/* 🔍 Search – only if more than 5 dealers */}
    {filteredDealers.length > 5 && (
      <li className="sticky top-0 bg-white px-3 py-1.5 z-10">
        <input
          ref={dealerSearchRef}
          type="text"
          placeholder="Search dealer..."
          value={dealerSearch}
          onChange={(e) => setDealerSearch(e.target.value)}
          className="w-full px-2 py-1 text-xs border border-black/30 outline-none"
          autoFocus
        />
      </li>
    )}

    {/* Empty state */}
    {filteredDealers.length === 0 ? (
      <li className="px-3 py-2 text-xs text-black">
        {selectedMarketAreas.length === 0
          ? "Select Market Area first"
          : "No dealers found"}
      </li>
    ) : (
      filteredDealers
        .filter((dealer) =>
          !dealerSearch
            ? true
            : dealer.label.toLowerCase().includes(dealerSearch.toLowerCase())
        )
        .map((dealer) => (
          <li
  tabIndex={0}
  key={dealer.value}
  className={`px-3 py-1.5 text-xs cursor-pointer hover:bg-lightBlue
    ${
      selectedDealers.some((s) => s.value === dealer.value)
        ? "bg-lightBlue/50 font-semibold"
        : ""
    }`}
  onKeyDown={(e) => {
    const items = Array.from(
      dealerListRef.current.querySelectorAll("li[tabindex]")
    );
    const index = items.indexOf(e.currentTarget);

    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(index + 1) % items.length]?.focus();
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(index - 1 + items.length) % items.length]?.focus();
    }

    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      toggleDealer(dealer);
    }
  }}
  onMouseDown={(e) => {
    e.preventDefault();
    toggleDealer(dealer);
  }}
>
  {dealer.label}
</li>
        ))
    )}

    {/* No search results */}
    {filteredDealers.length > 0 &&
      filteredDealers.filter((dealer) =>
        !dealerSearch
          ? true
          : dealer.label.toLowerCase().includes(dealerSearch.toLowerCase())
      ).length === 0 && (
        <li className="px-3 py-2 text-xs text-gray-500">
          No dealers found
        </li>
      )}
  </ul>
)}

</div>

        </div>

        {/* Table */}
        <div className="overflow-x-auto  border border-Dustyblue">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-Dustyblue text-xs text-white">
                <th className="py-1.5 px-4 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-semibold ">Market Area</th>
                <th className="py-1.5 px-4  text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-semibold">Dealership</th>
                <th className="py-1.5 px-4 text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {assignments.map((assignment, index) => (
                <tr
                  key={index}
                  className={ 
                    index % 2 === 0
                      ? ""
                      : ""
                  }
                >
                  <td className="py-1  border border-grey2 border-t-0 border-l-0 px-4 text-xs">
                    {assignment.marketArea.toUpperCase()}
                  </td>
                  <td className="py-1  border border-grey2 border-t-0 border-l-0 px-4 text-xs">{assignment.dealership}</td>
                  <td className="py-1  border border-grey2 border-t-0 border-l-0 border-r-0 px-4 text-xs">
                    <button
                      onClick={() => {
                        setIndexToDelete(index);
                        setDeleteModalVisible(true);
                      }}
                      className="text-red-600 hover:text-red-800"
                    >
                      <img
                        src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png"
                        alt="delete"
                        className="w-4 h-4"
                      />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-4 mt-6"> 
          <button type="button" className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-5 py-1.5 text-xs font-medium  hover:bg-mildBlue1 hover:scale-105" 
          onClick={onClose} 
          >
            <img
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/cancel.png"
                alt=""
                className="w-3 h-3"/>
             Cancel
           </button> 
           <button 
           onClick={handleSave} 
           className="bg-darkblue1 text-white text-xs font-medium px-10 py-1.5  hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1" >
             Save
              </button>
               </div>

        {/* Delete Modal */}
        {deleteModalVisible && (
           <DeleteModal
          isOpen={deleteModalVisible}
          onClose={() => {
            setDeleteModalVisible(false);
            setIndexToDelete(null);
          }}
          onConfirm={handleConfirmDelete}
        />
        )}
      </div>
    </div>
  );
};

export default AssignDealership;
