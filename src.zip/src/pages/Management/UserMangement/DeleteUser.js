


import React from "react";

const DeleteUser = ({ isdeleteuserOpen, onCancel, onDelete, user }) => {
  if (!isdeleteuserOpen || !user) return null; // also check if user is passed

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 px-4">
      <div className="bg-white p-4 sm:p-6  shadow-lg w-full max-w-3xl relative overflow-y-auto max-h-[90vh]">
        {/* Warning Text */}
        <div className="bg-red2 text-red1 text-xs  mb-4 p-2">
          <p className="leading-relaxed">
            You are about to permanently delete{" "}
            <strong>"{user.firstName} {user.lastName}"</strong> from the database.
            This action will remove all user details and authentication logs, and it cannot be undone.
          </p>
        </div>

        <p className="text-xs font-normal mb-4 font-VolvoNovum text-black">
          Are you sure you want to permanently delete this user?
        </p>

        {/* User Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 bg-gray-50 p-4 ">
          {[
            ["First Name", user.firstName],
            ["Last Name", user.lastName],
            ["User Role", user.userrole || user.role],
            ["Email Address", user.email],
            ["Last Login", user.lastLoginTime || ""],
          ].map(([label, value]) => (
            <div key={label} className="bg-lightGrey  p-1">
              <div className="flex items-center gap-x-2 flex-wrap">
                <p className="text-xs text-black font-medium whitespace-nowrap">{label}:</p>
                <p className="text-xs  text-black font-norml break-words">{value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-center gap-4 mt-6">
          <button
            type="button"
            className="flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-5 py-1.5 text-xs font-medium  hover:bg-mildBlue1 hover:scale-105 transition duration-200"
            onClick={onCancel}
          >
            <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/cancel.png" alt="cancel" className="w-3 h-3" />
            Cancel
          </button>
          <button
            onClick={onDelete}
            className="flex items-center gap-2 text-red1 text-xs font-medium font-VolvoNovum px-5 py-1.5  border-2 border-red2 hover:bg-red2 hover:text-red1 hover:shadow-md hover:scale-105 transition duration-200"
          >
            <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Adddealership/Delete.png" alt="delete" className="w-3 h-3" />
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteUser;
