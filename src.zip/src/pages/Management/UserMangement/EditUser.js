"use client"

import { useState, useEffect, useRef, useMemo } from "react"
import axios from "axios"
import { API } from '../../../api';

const EditUser = ({ isOpen, onClose, user, onUpdated }) => {
  const [firstName, setFirstName] = useState("")
  const [middleName, setMiddleName] = useState("")
  const [lastName, setLastName] = useState("")
  const [email, setEmail] = useState("")
  const [selectedType, setSelectedType] = useState("")
  const [selectedRole, setSelectedRole] = useState("")
  const [location, setLocation] = useState("")
  const [marketArea, setMarketArea] = useState("")
  const [dealerships, setDealerships] = useState([])
  const [errors, setErrors] = useState({})
  const [apiData, setApiData] = useState([])
  const [rolesList, setRolesList] = useState([])
  const [marketAreas, setMarketAreas] = useState([])
  const [allDealers, setAllDealers] = useState([])
  const [isSaving, setIsSaving] = useState(false)

  const typeRef = useRef(null)
  const roleRef = useRef(null)
  const locationRef = useRef(null)
  const marketRef = useRef(null)
  const dealerRef = useRef(null)

  const [isTypeOpen, setIsTypeOpen] = useState(false)
  const [isRoleOpen, setIsRoleOpen] = useState(false)
  const [isLocationOpen, setIsLocationOpen] = useState(false)
  const [isMarketOpen, setIsMarketOpen] = useState(false)
  const [isDealerOpen, setIsDealerOpen] = useState(false)

  // ---- Prefill user ----
  useEffect(() => {
    if (!user) return
    setFirstName(user.firstName || "")
    setMiddleName(user.middleName || "")
    setLastName(user.lastName || "")
    setEmail(user.email || "")
    setSelectedType(user.role === "VOLVO_USER" ? "volvo-user" : "dealer-user")
    setLocation(user.locationType === "REGION" ? "Region" : user.locationType === "HQ" ? "Head Quarter" : "")
    setSelectedRole(user.persona || "")
    setMarketArea(user.marketAreaId || "")
    setDealerships(user.dealers || [])
  }, [user])

  // ---- Fetch dropdown data ----
  useEffect(() => {
    const fetchRoles = async () => {
      const res = await axios.get( `${API.domain}${API.userManagement.getRoles}`,)
      if (res.data.status) setApiData(res.data.data)
    }
    const fetchMarketAreas = async () => {
      const res = await axios.get( `${API.domain}${API.userManagement.getMarketarea}`)
      if (res.data.status) {
        setMarketAreas(
          res.data.data.filter((ma) => ma.isActive === 1).map((ma) => ({
            value: ma.id,
            label: ma.marketarea,
          }))
        )
      }
    }
    const fetchDealers = async () => {
      const res = await axios.get( `${API.domain}${API.userManagement.getDealers}`)
      if (res.data.status) {
        setAllDealers(
          res.data.data.filter((d) => d.isActive === 1).map((d) => ({
            value: d.id,
            label: d.dealerShortName,
            marketName: d.marketName,
          }))
        )
      }
    }
    fetchRoles()
    fetchMarketAreas()
    fetchDealers()
  }, [])

  // ---- Filter roles ----
  const filteredRoles = useMemo(() => {
    if (!selectedType) return []
    const typeLabel = selectedType === "volvo-user" ? "Volvo User" : "Dealer User"
    const activeRoles = apiData.filter((d) => d.userType === typeLabel && d.isActive === 1)
    if (typeLabel === "Volvo User") {
      return activeRoles.filter((d) => d.location === location).map((d) => d.userRole)
    }
    return activeRoles.map((d) => d.userRole)
  }, [selectedType, location, apiData])

  useEffect(() => setRolesList(filteredRoles), [filteredRoles])

  // ---- Save ----
  const handleSubmit = async () => {
    const newErrors = {}
    if (!firstName) newErrors.firstName = "Required"
    if (!lastName) newErrors.lastName = "Required"
    if (!email) newErrors.email = "Required"
    if (!selectedType) newErrors.selectedType = "Required"
    if (!selectedRole) newErrors.selectedRole = "Required"
    if (!marketArea) newErrors.marketArea = "Required"
    // if (dealerships.length === 0) newErrors.dealers = "Select at least one dealer"
    setErrors(newErrors)
    if (Object.keys(newErrors).length > 0) return

    try {
      setIsSaving(true)
      const payload = {
        firstName,
        middleName,
        lastName,
        email,
        role: selectedType === "volvo-user" ? "VOLVO_USER" : "DEALER_USER",
        locationType: location === "Region" ? "REGION" : "HQ",
        persona: selectedRole,
        marketArea,
        dealers: dealerships,
      }
      const res = await axios.put(`${API.domain}${API.userManagement.updateUser}/${user.id}`, payload)
      if (res.data.status) {
        onUpdated()
        onClose()
      } else {
        alert(res.data.message || "Failed to update")
      }
    } catch (err) {
         const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    } finally {
      setIsSaving(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-full max-w-2xl relative">
        <button className="absolute top-3 right-3" onClick={onClose}>
          ✖
        </button>
        <h2 className="text-base font-semibold mb-2">Edit User</h2>

        <div className="grid grid-cols-2 gap-4">
          <input className="border px-3 py-1.5 text-xs rounded" placeholder="First Name" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
          <input className="border px-3 py-1.5 text-xs rounded" placeholder="Middle Name" value={middleName} onChange={(e) => setMiddleName(e.target.value)} />
          <input className="border px-3 py-1.5 text-xs rounded" placeholder="Last Name" value={lastName} onChange={(e) => setLastName(e.target.value)} />
          <input className="border px-3 py-1.5 rounded" type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />

          {/* User Type dropdown */}
          <div className="relative" ref={typeRef}>
            <div className={`border px-3 py-2 rounded cursor-pointer ${errors.selectedType ? "border-red-500" : "border-gray-300"}`} onClick={() => setIsTypeOpen(!isTypeOpen)}>
              {selectedType === "volvo-user" ? "Volvo User" : selectedType === "dealer-user" ? "Dealer User" : "Select User Type"}
            </div>
            {isTypeOpen && (
              <div className="absolute z-10 bg-white border rounded mt-1 w-full">
                {["Dealer User", "Volvo User"].map((t) => (
                  <div key={t} className="px-3 py-2 hover:bg-gray-100 cursor-pointer" onClick={() => { setSelectedType(t.toLowerCase().replace(" ", "-")); setIsTypeOpen(false) }}>
                    {t}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Location dropdown (only if Volvo) */}
          {selectedType === "volvo-user" && (
            <div className="relative" ref={locationRef}>
              <div className={`border px-3 py-2 rounded cursor-pointer ${errors.location ? "border-red-500" : "border-gray-300"}`} onClick={() => setIsLocationOpen(!isLocationOpen)}>
                {location || "Select Location"}
              </div>
              {isLocationOpen && (
                <div className="absolute z-10 bg-white border rounded mt-1 w-full">
                  {["Head Quarter", "Region"].map((loc) => (
                    <div key={loc} className="px-3 py-2 hover:bg-gray-100 cursor-pointer" onClick={() => { setLocation(loc); setIsLocationOpen(false) }}>
                      {loc}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Role dropdown */}
          <div className="relative" ref={roleRef}>
            <div className={`border px-3 py-2 rounded cursor-pointer ${errors.selectedRole ? "border-red-500" : "border-gray-300"}`} onClick={() => setIsRoleOpen(!isRoleOpen)}>
              {selectedRole || "Select Role"}
            </div>
            {isRoleOpen && (
              <div className="absolute z-10 bg-white border rounded mt-1 w-full">
                {rolesList.map((r) => (
                  <div key={r} className="px-3 py-2 hover:bg-gray-100 cursor-pointer" onClick={() => { setSelectedRole(r); setIsRoleOpen(false) }}>
                    {r}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Market Area dropdown */}
          <div className="relative" ref={marketRef}>
            <div className={`border px-3 py-2 rounded cursor-pointer ${errors.marketArea ? "border-red-500" : "border-gray-300"}`} onClick={() => setIsMarketOpen(!isMarketOpen)}>
              {marketAreas.find((ma) => ma.value === marketArea)?.label || "Select Market Area"}
            </div>
            {isMarketOpen && (
              <div className="absolute z-10 bg-white border rounded mt-1 w-full max-h-40 overflow-y-auto">
                {marketAreas.map((ma) => (
                  <div key={ma.value} className="px-3 py-2 hover:bg-gray-100 cursor-pointer" onClick={() => { setMarketArea(ma.value); setIsMarketOpen(false) }}>
                    {ma.label}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Dealerships multi-select */}
          <div className="relative col-span-2" ref={dealerRef}>
            <div className={`border px-3 py-2 rounded cursor-pointer min-h-[42px] flex flex-wrap gap-2 ${errors.dealers ? "border-red-500" : "border-gray-300"}`} onClick={() => setIsDealerOpen(!isDealerOpen)}>
              {dealerships.length > 0 ? dealerships.map((d) => (
                <span key={d} className="bg-blue-100 px-2 py-1 rounded flex items-center gap-1">
                  {allDealers.find((ad) => ad.value === d)?.label || d}
                  <button type="button" onClick={(e) => { e.stopPropagation(); setDealerships(dealerships.filter((x) => x !== d)) }}>✕</button>
                </span>
              )) : "Select Dealerships"}
            </div>
            {isDealerOpen && (
              <div className="absolute z-10 bg-white border rounded mt-1 w-full max-h-40 overflow-y-auto">
                {allDealers.filter((d) => d.marketName === marketArea).map((d) => (
                  <div key={d.value} className="px-3 py-2 hover:bg-gray-100 cursor-pointer" onClick={() => { if (!dealerships.includes(d.value)) setDealerships([...dealerships, d.value]) }}>
                    {d.label}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-2 mt-6">
          <button onClick={onClose} className="px-4 py-2 border rounded">Cancel</button>
          <button onClick={handleSubmit} disabled={isSaving} className="px-4 py-2 bg-darkblue1 text-white rounded">
            {isSaving ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </div>
  )
}

export default EditUser
