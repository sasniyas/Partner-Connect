


import React, { useEffect } from "react";

const SuccessMessage = ({ message, onClose }) => {
  // Automatically close the popup after 5 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 2000); // 2 seconds

    return () => clearTimeout(timer); // cleanup on unmount
  }, [onClose]);

  return (
    <div className="fixed top-5 right-5 w-96 bg-white shadow-lg  p-4 flex items-start gap-3 z-50 border-l-8 border-green">
      {/* ✅ Success Icon */}
      <div className="bg-green4 rounded-full p-2 mt-5 w-8 h-8 flex items-center justify-center">
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/prime_check-circle.png"
          alt="Success"
          className="w-4 h-4"
        />
      </div>

      {/* ✅ Success Message */}
      <div className="flex-1">
        <p className="font-bold font-VolvoNovum text-lg text-black">{message.title}</p>
        <p className="text-xs text-black font-VolvoNovum">{message.description}</p>
      </div>

      {/* ✅ Close Button */}
      <button
        className="absolute top-2 right-3 w-5 h-5 flex items-center justify-center rounded-full bg-red1 transition duration-200 hover:scale-110"
        onClick={onClose}
        aria-label="Close"
      >
        <svg width="14" height="14" viewBox="0 0 20 20">
          <circle cx="8" cy="8" r="8" fill="#BF2012" />
          <path
            d="M6.5 6.5L13.5 13.5M13.5 6.5L6.5 13.5"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      </button>
    </div>
  );
};

export default SuccessMessage;
