// import React, { useState, useEffect } from "react";
// import { IoSearch } from "react-icons/io5";

// const SearchFilter = ({ users, setFilteredUsers }) => {
//   const [searchTerm, setSearchTerm] = useState("");
//   const [isOpen, setIsOpen] = useState(null);
//   const [selectedValues, setSelectedValues] = useState({
//     marketArea: "Market Area",
//     dealer: "Dealer",
//     userrole: [],
//     status: [],
//   });

//   const toggleDropdown = (key) => {
//     setIsOpen(isOpen === key ? null : key);
//   };

//   const handleSelect = (key, value) => {
//     setSelectedValues((prev) => ({ ...prev, [key]: value }));
//     setIsOpen(null);
//   };

//   const handleMultiSelect = (key, value) => {
//     setSelectedValues((prev) => {
//       const updated = prev[key].includes(value)
//         ? prev[key].filter((v) => v !== value)
//         : [...prev[key], value];
//       return { ...prev, [key]: updated };
//     });
//   };

//   useEffect(() => {
//     const filtered = users.filter((user) =>
//       (searchTerm === "" ||
//         user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         user.email.toLowerCase().includes(searchTerm.toLowerCase())) &&
//       (selectedValues.marketArea === "Market Area" || user.marketArea === selectedValues.marketArea) &&
//       (selectedValues.dealer === "Dealer" || user.dealer === selectedValues.dealer) &&
//       (selectedValues.userrole.length === 0 || user.userrole.some((role) => selectedValues.userrole.includes(role))) &&
//       (selectedValues.status.length === 0 || selectedValues.status.includes(user.status))
//     );
//     setFilteredUsers(filtered);
//   }, [searchTerm, selectedValues, users, setFilteredUsers]);

//   return (
//     <div className="relative w-full md:w-1/4 min-w-[150px]">
//         <input
//           type="text"
//           placeholder="Search by name or email"
//           value={searchTerm}
//               onChange={(e) => setSearchTerm(e.target.value)}
//           className="w-full pl-10 pr-3 py-2 border rounded-lg bg-gray-200 
//           focus:outline-none focus:ring hover:bg-gray-300 transition duration-200"
//         />
//         <IoSearch className="absolute left-3 top-3 text-gray-400" />
//       </div>
    
//       {/* Dropdown Filters */}
//       <div className="flex flex-wrap md:flex-nowrap gap-2 md:gap-4 w-full md:w-1/2 justify-center">
//       {/* MarketArea */}
//       <div className="relative w-[24%] min-w-[140px]">
//             <div
//               className={`rounded-lg px-4 py-2 w-full text-black text-sm  cursor-pointer
                
//                 ${isOpen === "marketArea" ? "border-lightBlue border-2 bg-white rounded-b-none border-b-white" : "border-gray-300 bg-gray-200"} 
//                 border transition-all duration-300`}
//                 onClick={() => toggleDropdown("marketArea")}
//             >
//               {selectedValues.marketArea}
//             </div>
    
//             {/* Clickable Image for Dropdown */}
//             <img
//               src="/icons/material-symbols-light_arrow-drop-down-rounded.png"
//               alt="dropdown"
//               onClick={() => toggleDropdown("marketArea")}
//               className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-7 h-7 cursor-pointer 
//                 ${isOpen=== "marketArea" ? "rotate-180" : "rotate-0"}`}
//             />
    
//             {/* Dropdown Options */}
//             {isOpen === "marketArea" && (
//               <ul className="absolute left-0 mt-0 w-full bg-white shadow-lg rounded-b-lg text-sm font-VolvoNovum  ">
//                 {["East", "West", "North", "South", "Central"].map((area) => (
//                   <li
//                     key={area}
//                     className="px-4 py-2 hover:bg-lightBlue cursor-pointer w-full block"
//                     onClick={() => handleSelect("marketArea", area)}
//                   >
//                     {area}
//                   </li>
//                 ))}
//               </ul>
//             )}
//           </div>
//     {/* Dealer */}
//     <div className="relative w-[24%] min-w-[140px]">
//             <div
//               className={`rounded-lg px-4 py-2 w-full text-black text-sm  cursor-pointer
//                 ${isOpen === "dealer" ? "border-lightBlue border-2 bg-white rounded-b-none border-b-white" : "border-gray-300 bg-gray-200"} 
//                 border transition-all duration-300`}
//                 onClick={() => toggleDropdown("dealer")}
//             >
//               {selectedValues.dealer}
//             </div>
    
//             {/* Clickable Image for Dropdown */}
//             <img
//               src="/icons/material-symbols-light_arrow-drop-down-rounded.png"
//               alt="dropdown"
//               onClick={() => toggleDropdown("dealer")}
//               className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-7 h-7 cursor-pointer 
//                 ${isOpen=== "dealer" ? "rotate-180" : "rotate-0"}`}
//             />
    
//             {/* Dropdown Options */}
//             {isOpen === "dealer" && (
//               <ul className="absolute left-0 mt-0 w-full bg-white shadow-lg text-sm font-VolvoNovum rounded-b-lg  max-h-56 overflow-y-auto border border-lightBlue">
//                 {[  "APHA-DL","ALPHA-UP","BSES","DRS","ENCORE","ESDEE","INFRA","NAVIN","PACT","PAL","PT ENGG","RPSL-TS","RPSL-AP","TEAM","WIE","TD"].map((deal) => (
//                   <li
//                     key={deal}
//                     className="px-4 py-2 hover:bg-lightBlue cursor-pointer w-full block"
//                     onClick={() => handleSelect("dealer",deal)}
//                   >
//                     {deal}
//                   </li>
//                 ))}
//               </ul>
//             )}
//           </div>
//     {/* UsrRole */}
//     <div className="relative w-[24%] min-w-[140px]">
//       {/* Selected values display */}
//       {/* Selected values display */}
//     <div
//       className={`rounded-lg px-4 py-2 w-full text-black text-sm  cursor-pointer
//         ${isOpen === "userrole" ? "border-lightBlue border-2 bg-white rounded-b-none border-b-white" : "border-gray-300 bg-gray-200"} 
//                 border transition-all duration-300`}
//       onClick={() => toggleDropdown("userrole")}
//     >
//       {selectedValues.userrole?.length > 0
//         ? selectedValues.userrole.join(", ")
//         : "User Role"}
//     </div>
    
    
//       {/* Clickable Image for Dropdown */}
//       <img
//         src="/icons/material-symbols-light_arrow-drop-down-rounded.png"
//         alt="dropdown"
//         className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-7 h-7 cursor-pointer 
//           ${isOpen === "userrole" ? "rotate-180" : "rotate-0"}`}
//         onClick={() => toggleDropdown("userrole")}
//       />
    
//       {/* Dropdown Options with Checkboxes */}
//       {isOpen === "userrole" && (
//         // <ul className="absolute left-0 mt-0 w-70 p-0 text-sm font-VolvoNovum bg-white shadow-lg rounded-b-lg whitespace-nowrap">
//         <ul className="absolute left-0 mt-0 w-70 p-0 text-sm font-VolvoNovum bg-white shadow-lg rounded-b-lg whitespace-nowrap 
//         max-h-56 overflow-y-auto border border-lightBlue">
//           {["Administrator",
//             "Auditor",
//             "Volvo User",
//             "Dealer Coordinator",
//             "Dealer Sales Head",
//             "Dealer CST Head",
//             "Uptime & Parts Manager",
//             "Market Area Head",
//             "Volvo Functional Manager",
//             "IMT",
//             "Retail Sales Manager",
//             "Dealer Finance Head",
//             "Dealer HR Head",
//             "Dealer Principal",
//             "Financial Analyst",
//             "Key Account Manager (Uptime & Parts)",
//             "Head of Channel Development (Region India)",
//             "Dealer CEO",
//             "Dealer Parts Manager",
//             "Key Account Manager (Sales)",].map((role) => (
//             <li key={role} className="flex items-center gap-2 px-4 py-2 hover:bg-lightBlue cursor-pointer">
//               <input
//                 type="checkbox"
//                 checked={selectedValues.userrole.includes(role)}
//                 onChange={() => handleMultiSelect("userrole", role)}
//                 className="w-4 h-4"
//               />
//               <span>{role}</span>
//             </li>
//           ))}
//         </ul>
//       )}
//     </div>
    
//         {/* Status */}
//         <div className="relative w-[24%] min-w-[140px]">
//       {/* Selected values display */}
//       {/* Selected values display */}
//     <div
//       className={`rounded-lg px-4 py-2 w-full text-black text-sm  cursor-pointer
//         ${isOpen === "status" ? "border-lightBlue border-2 bg-white rounded-b-none border-b-white" : "border-gray-300 bg-gray-200"} 
//                 border transition-all duration-300`}
//       onClick={() => toggleDropdown("status")}
//     >
//       {selectedValues.status?.length > 0
//         ? selectedValues.userrole.join(", ")
//         : "Status"}
//     </div>
    
    
//       {/* Clickable Image for Dropdown */}
//       <img
//         src="/icons/material-symbols-light_arrow-drop-down-rounded.png"
//         alt="dropdown"
//         className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-7 h-7 cursor-pointer 
//           ${isOpen === "status" ? "rotate-180" : "rotate-0"}`}
//         onClick={() => toggleDropdown("status")}
//       />
    
//       {/* Dropdown Options with Checkboxes */}
//       {isOpen === "status" && (
//         // <ul className="absolute left-0 mt-0 w-70 p-0 text-sm font-VolvoNovum bg-white shadow-lg rounded-b-lg whitespace-nowrap">
//         <ul className="absolute left-0 mt-0 w-full p-1 text-sm font-VolvoNovum bg-white shadow-lg rounded-b-lg whitespace-nowrap 
//        ">
//           {["New","Active","Inactive","Delete"].map((stat) => (
//             <li key={stat} className="flex items-center gap-2 px-4 py-2 hover:bg-lightBlue cursor-pointer">
//               <input
//                 type="checkbox"
//                 checked={selectedValues.userrole.includes(stat)}
//                 onChange={() => handleMultiSelect("status", stat)}
//                 className="w-4 h-4"
//               />
//               <span>{stat}</span>
//             </li>
//           ))}
//         </ul>
//       )}
//     <></>
//   );
// };

// export default SearchFilter;
