
"use client"

import { useState, useEffect, useRef, use } from "react"
import { useNavigate, useLocation } from "react-router-dom"
import EditUserdetails from "./EditUserdetails"
import ActivationEmail from "./ActivationEmail"
import DeleteUser from "./DeleteUser"
import AssignDealership from "./AssignDealership"
import ShowHistoryUserdetails from "./ShowHistoryUsedetails"
import TemporaryDeactive from "./TemporaryDeactive"
import axios from "axios"
import AddUser from "./AddUser"
import ActivateStatus from "../../../Components/ActivateStatus"
import DeactivateStatus from "../../../Components/DeactivateStatus"
import moment from "moment-timezone";
import { formatedTime } from "../../../util/timeFormat"
import { ArrowLeft } from "lucide-react"
import { API } from '../../../api';
const UserDetailscontent = () => {
  const navigate = useNavigate();
  const locationRouter = useLocation();
  const passedUserId = locationRouter.state?.userId;
const [currentUser, setCurrentUser] = useState({
  firstName: "",
  middleName: "",
  lastName: "",
  email: "",
  userrole: "",
  type: "",
  area: "",
  dealership: "",
  status: "",
  initials: "",
  location: "",
});

  const [isOpen, setIsOpen] = useState(false)
  const [isedituserOpen, setIsEdituserOpen] = useState(false)
  const [isActive, setIsActive] = useState(true)
  const [isactivationemailOpen, setIsActivationemailOpen] = useState(false)
  const [isdeleteuserOpen, IsDeleteuserOpen] = useState(false)
  const [isassigndealershipOpen, IsAssigndealershipOpen] = useState(false)
  const [showHistoryPopup, setShowHistoryPopup] = useState(false)
  const [selectedUser, setSelectedUser] = useState(null)
  const [isDeactivemailOpen, setIsDeactivemailOpen] = useState(false)
  const [loading, setLoading] = useState(true);
const [isAddUserOpen, setIsAddUserOpen] = useState(false)
const[toggleLoading,setToggleLoading] =useState()
const [isActivateOpen,setIsActivateOpen]=useState()
const[isDeactivateOpen,setIsDeactivateOpen] =useState()
const [allAvailableDealersData, setAllAvailableDealersData] = useState([]);
const [emailLoading, setEmailLoading] = useState(false);

useEffect(() => {
  const fetchDealers = async () => {
    try {
      let token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token){
      navigate("/")
      return;
    }
      const res = await axios.get(
         `${API.domain}${API.userManagement.getDealers}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`, // ✅ add token in header
          },
        }
      );
      if (res.data?.status) {
        const activeDealers = res.data.data.filter(d => d.isActive === 1);
        setAllAvailableDealersData(activeDealers);
      }
    } catch (err) {
          const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
      // console.error("Error fetching dealers:", err);
    }
  };

  fetchDealers();
}, []);
const statusMap = {
  NEW: "New",
  ACTIVE: "Active",
  INACTIVE: "Inactive",
  TEMPORARILY_DEACTIVATED: "Temporarily Deactivated", // if needed
};
console.log("selecteduser",selectedUser);
const fetchUser = async () => {
  if (!passedUserId) return;

  try {
    let token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      navigate("/");
      return;
    }

    const res = await axios.get(
      `${API.domain}${API.userManagement.getUser}/${passedUserId}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );

    if (res.data?.status) {
      const user = res.data.data;
      console.log("User",passedUserId);
      setCurrentUser({
        id:passedUserId,
        firstName: user.firstName || "",
        middleName: user.middleName || "",
        lastName: user.lastName || "",
        email: user.email || "",
        userrole: user.persona || "",
        userroleId: user.personaId || "",
        type:
          user.role === "VOLVO_USER"
            ? "Volvo User"
            : user.role === "DEALER_USER"
            ? "Dealer User"
            : user.role || "",
        area: user.marketArea || "",
        dealership:
          user.dealers && user.dealers.length > 0
            ? user.dealers.map((d) => d.dealerShortName || d.dealerName).join(", ")
            : "",
        status: statusMap[user.status] || user.status,
        initials:
          (user.firstName?.[0] || "").toUpperCase() +
          (user.lastName?.[0] || "").toUpperCase(),
        location:
  user.locationType === "REGION"
    ? "Region"
    : user.locationType === "HEAD_QUARTER" || user.locationType === "HQ"
    ? "Head Quarter"
    : user.locationType || "",


        createdOn: user.createdOn || null,
        lastActivationEmail: user.activationMailTimestamp || null,
        lastLogin: user.lastLoginTime || null
      });
    }
  } catch (err) {
      const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
  } finally {
    setLoading(false);
  }
};
useEffect(() => {
  fetchUser();
}, [passedUserId]);

const toggleUserStatus = async (userId, status) => {
  try {
    const token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      navigate("/");
      return;
    }

    setToggleLoading(true);

    const payload = { id: passedUserId, status }; // ✅ API expects 'id'
    console.log("Sending toggle request:", payload);

    const response = await axios.put(
      `${API.domain}${API.userManagement.toggleUserStatus}`,
      payload, // ✅ pass payload here
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, // ✅ include token
        },
      }
    );

    console.log("Toggle response:", response.data);

    if (response.data.status) {
      setCurrentUser((prev) => ({
        ...prev,
        status: status === "ACTIVE" ? "Active" : "Inactive",
      }));
    } else {
      console.error("Failed to toggle status:", response.data);
    }

  } catch (err) {
      const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            } } finally {
    setToggleLoading(false);
    setIsActivateOpen(false);
    setIsDeactivateOpen(false);
  }
};


//aCTIVATE EMAIL
const handleConfirm = async () => {
  if (!currentUser) return;
setEmailLoading(true)
  const payload = {
    userId: passedUserId,
    admin: "Sameer", // or get from logged-in user
    user: `${currentUser.firstName.toUpperCase()}`,
    mail: currentUser.email,
  };

  try {
    let token =localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token){
      navigate("/")
      return;
    }
    const res = await axios.put(
       `${API.domain}${API.userManagement.activationLink}`,
      payload,
      {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`, // ✅ add token in header
          },
        }
    );

    if (res.data?.status) {
      // alert("Activation email sent successfully");
      setIsActivationemailOpen(false); 
    } else {
      alert(res.data?.message || "Failed to send activation email");
    }
  } catch (err) {
        const message = err.response?.data?.message;
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }
    // console.error("Activation email error:", err.response?.data || err);
    // alert("Something went wrong while sending activation email");
  } finally{
    setEmailLoading(false)
  }
};
const showDealership =
  currentUser?.type?.toLowerCase() === "dealer user" ||
  (currentUser?.type?.toLowerCase() === "volvo user" &&
    currentUser?.location?.toLowerCase().trim() === "region");

const showLocation =
  currentUser?.type?.toLowerCase() === "volvo user" &&
  currentUser?.location?.toLowerCase().trim() === "head quarter";

  const dropdownRef = useRef(null)

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleback = () => navigate("/usermangement")

  const handleToggle = () => {
    const newStatus = isActive ? "Inactive" : "Active"
    setIsActive(!isActive)
    setCurrentUser((prevUser) => ({
      ...prevUser,
      status: newStatus,
    }))
  }

  // const handleConfirm = () => setIsActivationemailOpen(false)
  const handleCancel = () => setIsActivationemailOpen(false)
  const handleClose = () => IsDeleteuserOpen(false)
  const handleDeleteUser = async () => {
  if (!currentUser) {
    console.warn("No user selected for deletion");
    return;
  }

  try {
    const token=localStorage.getItem("userToken") || localStorage.getItem("superUserToken");
    if (!token) {
      console.warn("No auth token found, redirecting to login");
      navigate("/");
      return;
    }

    // DELETE request
    const response = await axios.delete(
    `${API.domain}${API.userManagement.deleteUser}/${passedUserId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.data?.status) {
      console.log("User deleted successfully!", response.data);

      // Close modal and navigate
      IsDeleteuserOpen(false);
      navigate("/usermangement");
    } else {
      console.error("Failed to delete user:", response.data?.message);
      alert(response.data?.message || "Failed to delete user");
    }

  } catch (error) {
    const message = error.response?.data?.message || error.message || "Failed to delete user.";
    
           if ( message === "token is invalid" || message === "jwt expired") {
                localStorage.removeItem("userToken")
                localStorage.removeItem("superUserToken")
                window.location.href = "/";   // redirect to login
            }

    console.error("Delete user error:", message);
    alert(message);
  }
};
const status = currentUser?.status || "Active"


  return (
    <div className=" ">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
        <button className="flex items-center gap-2" onClick={handleback}>
 <ArrowLeft
                  size={24}
                  className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1  p-1"
                />          <span className="text-Darkblue1 text-lg font-VolvoNovum font-medium">User Details</span>
        </button>

        {/* Actions Dropdown */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="flex items-center justify-center gap-2 px-6 py-1.5 text-white font-medium shadow-md w-full md:w-40 text-xs bg-darkblue1 border hover:bg-opacity-80"
          >
            Actions
            <svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 24 24"
  className={`w-6 h-6 transform duration-300 ${isOpen ? "rotate-180" : "rotate-0"}`}
  fill="none"
>
  <path
    d="M11.5648 13.873L8.88781 11.196C8.85114 11.1593 8.82015 11.1163 8.79481 11.067C8.77015 11.0183 8.75781 10.966 8.75781 10.91C8.75781 10.798 8.79448 10.7017 8.86781 10.621C8.94248 10.5403 9.04048 10.5 9.16181 10.5H14.8388C14.9595 10.5 15.0568 10.5413 15.1308 10.624C15.2048 10.7067 15.2418 10.8027 15.2418 10.912C15.2418 10.94 15.1985 11.0347 15.1118 11.196L12.4348 13.873C12.3728 13.935 12.3061 13.9827 12.2348 14.016C12.1635 14.0493 12.0851 14.066 11.9998 14.066C11.9145 14.066 11.8361 14.0493 11.7648 14.016C11.6935 13.9827 11.6268 13.935 11.5648 13.873Z"
    fill="currentColor"
  />
</svg>

          </button>
          {isOpen && (
            <div className="absolute left-0 mt-1 w-full text-xs md:w-40 bg-white border border-darkblue1  shadow-lg z-10 whitespace-nowrap">
              <ul className="m-0 p-0">
                {[
                  {
                    label: "Edit",
                    icon: (<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none">
<path d="M19.71 8.04006L17.37 10.3701L13.62 6.62006L15.96 4.29006C16.35 3.90006 17 3.90006 17.37 4.29006L19.71 6.63006C20.1 7.00006 20.1 7.65006 19.71 8.04006ZM3 17.2501L13.06 7.18006L16.81 10.9301L6.75 21.0001H3V17.2501ZM16.62 5.04006L15.08 6.58006L17.42 8.92006L18.96 7.38006L16.62 5.04006ZM15.36 11.0001L13 8.64006L4 17.6601V20.0001H6.34L15.36 11.0001Z" fill="#212121"/>
<path d="M19.71 8.04006L17.37 10.3701L13.62 6.62006L15.96 4.29006C16.35 3.90006 17 3.90006 17.37 4.29006L19.71 6.63006C20.1 7.00006 20.1 7.65006 19.71 8.04006ZM3 17.2501L13.06 7.18006L16.81 10.9301L6.75 21.0001H3V17.2501ZM16.62 5.04006L15.08 6.58006L17.42 8.92006L18.96 7.38006L16.62 5.04006ZM15.36 11.0001L13 8.64006L4 17.6601V20.0001H6.34L15.36 11.0001Z" fill="black" fill-opacity="0.2"/>
<path d="M19.71 8.04006L17.37 10.3701L13.62 6.62006L15.96 4.29006C16.35 3.90006 17 3.90006 17.37 4.29006L19.71 6.63006C20.1 7.00006 20.1 7.65006 19.71 8.04006ZM3 17.2501L13.06 7.18006L16.81 10.9301L6.75 21.0001H3V17.2501ZM16.62 5.04006L15.08 6.58006L17.42 8.92006L18.96 7.38006L16.62 5.04006ZM15.36 11.0001L13 8.64006L4 17.6601V20.0001H6.34L15.36 11.0001Z" fill="black" fill-opacity="0.2"/>
<path d="M19.71 8.04006L17.37 10.3701L13.62 6.62006L15.96 4.29006C16.35 3.90006 17 3.90006 17.37 4.29006L19.71 6.63006C20.1 7.00006 20.1 7.65006 19.71 8.04006ZM3 17.2501L13.06 7.18006L16.81 10.9301L6.75 21.0001H3V17.2501ZM16.62 5.04006L15.08 6.58006L17.42 8.92006L18.96 7.38006L16.62 5.04006ZM15.36 11.0001L13 8.64006L4 17.6601V20.0001H6.34L15.36 11.0001Z" fill="black" fill-opacity="0.2"/>
<path d="M19.71 8.04006L17.37 10.3701L13.62 6.62006L15.96 4.29006C16.35 3.90006 17 3.90006 17.37 4.29006L19.71 6.63006C20.1 7.00006 20.1 7.65006 19.71 8.04006ZM3 17.2501L13.06 7.18006L16.81 10.9301L6.75 21.0001H3V17.2501ZM16.62 5.04006L15.08 6.58006L17.42 8.92006L18.96 7.38006L16.62 5.04006ZM15.36 11.0001L13 8.64006L4 17.6601V20.0001H6.34L15.36 11.0001Z" fill="black" fill-opacity="0.2"/>
<path d="M19.71 8.04006L17.37 10.3701L13.62 6.62006L15.96 4.29006C16.35 3.90006 17 3.90006 17.37 4.29006L19.71 6.63006C20.1 7.00006 20.1 7.65006 19.71 8.04006ZM3 17.2501L13.06 7.18006L16.81 10.9301L6.75 21.0001H3V17.2501ZM16.62 5.04006L15.08 6.58006L17.42 8.92006L18.96 7.38006L16.62 5.04006ZM15.36 11.0001L13 8.64006L4 17.6601V20.0001H6.34L15.36 11.0001Z" fill="black" fill-opacity="0.2"/>
</svg>)
                    ,
                    onClick: () => {
                      setIsEdituserOpen(true)
                      setIsOpen(false)
                    },
                  },
              {
  label: currentUser.status === "Active" ? "Deactivate User" : "Activate User",
  icon: currentUser.status === "Active" ? (
    // Active SVG
    <span className="w-5 h-5 flex items-center justify-center">
     
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
<path d="M2.8125 2.8125L12.9375 12.9375M15.1875 7.875C15.1875 9.8144 14.4171 11.6744 13.0457 13.0457C11.6744 14.4171 9.8144 15.1875 7.875 15.1875C5.9356 15.1875 4.07564 14.4171 2.70428 13.0457C1.33292 11.6744 0.5625 9.8144 0.5625 7.875C0.5625 5.9356 1.33292 4.07564 2.70428 2.70428C4.07564 1.33292 5.9356 0.5625 7.875 0.5625C9.8144 0.5625 11.6744 1.33292 13.0457 2.70428C14.4171 4.07564 15.1875 5.9356 15.1875 7.875Z" stroke="black" stroke-width="1.125" stroke-linejoin="round"/>
</svg>
    </span>
  ) : (
    // Inactive SVG
    <span className="w-6 h-6 flex items-center justify-center">
    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none">
<g clip-path="url(#clip0_1393_1774)">
<path d="M0 8.5C0 3.80588 3.80588 0 8.5 0C13.1941 0 17 3.80588 17 8.5C17 13.1941 13.1941 17 8.5 17C3.808 16.9943 0.00566667 13.192 0 8.50071V8.5ZM1.7 8.5C1.7 12.2556 4.74442 15.3 8.5 15.3C12.2556 15.3 15.3 12.2556 15.3 8.5C15.3 4.74442 12.2556 1.7 8.5 1.7C4.74654 1.70425 1.70425 4.74654 1.7 8.49929V8.5ZM4.53333 8.5C4.53333 7.44797 4.95125 6.43904 5.69514 5.69514C6.43904 4.95125 7.44797 4.53333 8.5 4.53333C9.55202 4.53333 10.561 4.95125 11.3049 5.69514C12.0488 6.43904 12.4667 7.44797 12.4667 8.5C12.4667 9.55202 12.0488 10.561 11.3049 11.3049C10.561 12.0488 9.55202 12.4667 8.5 12.4667C7.44797 12.4667 6.43904 12.0488 5.69514 11.3049C4.95125 10.561 4.53333 9.55202 4.53333 8.5Z" fill="black"/>
</g>
<defs>
<clipPath id="clip0_1393_1774">
<rect width="17" height="17" fill="white"/>
</clipPath>
</defs>
</svg>
    </span>
  ),
  onClick: () => {
    setIsOpen(false);
    if (currentUser.status === "Active") {
      setIsDeactivateOpen(true);
    } else {
      setIsActivateOpen(true);
    }
  },
},



                  {
                    label: "Show History",
                    icon: <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none">
<path d="M11.9622 20C9.93158 20 8.16125 19.3367 6.65125 18.01C5.14192 16.684 4.26858 15.014 4.03125 13H5.04225C5.31425 14.72 6.09792 16.15 7.39325 17.29C8.68858 18.43 10.2116 19 11.9622 19C13.9122 19 15.5662 18.321 16.9242 16.963C18.2822 15.605 18.9616 13.9507 18.9622 12C18.9629 10.0493 18.2836 8.395 16.9242 7.037C15.5649 5.679 13.9109 5 11.9622 5C10.9269 5 9.95425 5.21867 9.04425 5.656C8.13425 6.09267 7.33092 6.69433 6.63425 7.461H9.11525V8.461H4.96225V4.309H5.96225V6.697C6.73558 5.84833 7.64158 5.187 8.68025 4.713C9.71892 4.239 10.8129 4.00133 11.9622 4C13.0709 4 14.1102 4.20867 15.0802 4.626C16.0503 5.04333 16.8976 5.61467 17.6222 6.34C18.3469 7.06533 18.9183 7.91267 19.3363 8.882C19.7543 9.85133 19.9629 10.8907 19.9622 12C19.9616 13.1093 19.7529 14.1487 19.3363 15.118C18.9196 16.0873 18.3482 16.9347 17.6222 17.66C16.8962 18.3853 16.0489 18.9567 15.0802 19.374C14.1116 19.7913 13.0722 20 11.9622 20ZM15.1663 15.854L11.5192 12.208V7H12.5192V11.792L15.8733 15.146L15.1663 15.854Z" fill="black"/>
</svg>,
                    onClick: () => {
                      setSelectedUser(currentUser)
                      setShowHistoryPopup(true)
                      setIsOpen(false)
                    },
                  },
                    ...(currentUser.status === "Inactive"
  ? [
      {
        label: "Send Activation Email",
        icon: (<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 18 14" fill="none">
<path d="M1.616 14C1.15533 14 0.771 13.846 0.463 13.538C0.155 13.23 0.000666667 12.8453 0 12.384V1.616C0 1.15533 0.154333 0.771 0.463 0.463C0.771667 0.155 1.15567 0.000666667 1.615 0H16.385C16.845 0 17.229 0.154333 17.537 0.463C17.845 0.771667 17.9993 1.156 18 1.616V12.385C18 12.845 17.8457 13.2293 17.537 13.538C17.2283 13.8467 16.8443 14.0007 16.385 14H1.616ZM9 7.116L1 1.885V12.385C1 12.5643 1.05767 12.7117 1.173 12.827C1.28833 12.9423 1.436 13 1.616 13H16.385C16.5643 13 16.7117 12.9423 16.827 12.827C16.9423 12.7117 17 12.564 17 12.384V1.884L9 7.116ZM9 6L16.692 1H1.308L9 6ZM1 1.885V1V12.385C1 12.5643 1.05767 12.7117 1.173 12.827C1.28833 12.9423 1.436 13 1.616 13H1V1.885Z" fill="black"/>
</svg>),
        onClick: () => {
          setCurrentUser({
            ...currentUser,
            firstName: currentUser.firstName || "",
            middleName: currentUser.middleName || "",
            lastName: currentUser.lastName || "",
          });
          setIsActivationemailOpen(true);
          setIsOpen("");
        },
      },
    ]
  : []),
                  {
                    label: "Delete",
                    icon: (<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none">
<path d="M7.616 20C7.168 20 6.78667 19.8426 6.472 19.528C6.15733 19.2133 6 18.8323 6 18.385V5.99998H5V4.99998H9V4.22998H15V4.99998H19V5.99998H18V18.385C18 18.845 17.846 19.2293 17.538 19.538C17.23 19.8466 16.8453 20.0006 16.384 20H7.616ZM17 5.99998H7V18.385C7 18.5643 7.05767 18.7116 7.173 18.827C7.28833 18.9423 7.436 19 7.616 19H16.385C16.5383 19 16.6793 18.936 16.808 18.808C16.9367 18.68 17.0007 18.5386 17 18.384V5.99998ZM9.808 17H10.808V7.99998H9.808V17ZM13.192 17H14.192V7.99998H13.192V17Z" fill="black"/>
</svg>),
                    onClick: () => {
                      IsDeleteuserOpen(true)
                      setIsOpen(false)
                    },
                  },
                  // {
                  //   label: "Temporarily Deactivate",
                  //   icon: "https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/temporarlydeactive.png",
                  //   onClick: () => {
                  //     setIsDeactivemailOpen(true)
                  //     setIsOpen(false)
                  //   },
                  // },
                ].map((item, idx) => (
                  <div
  key={idx}
  className="flex items-center gap-1 px-4 py-1.5 hover:bg-lightBlue/50 cursor-pointer text-xs"
  onClick={(e) => {
    e.stopPropagation()
    item.onClick()
  }}
>
  {item.icon && (
    typeof item.icon === "string" ? (
      <img src={item.icon} alt={item.label} className="w-3 h-3" />
    ) : (
      <span className="">{item.icon}</span>
    )
  )}
  <span>{item.label}</span>
</div>

                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Details Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-6xl mx-auto">
        {/* Personal Information */}
        <div className="bg-white p-6  shadow-md ">
          <h2 className="text-base   font-bold mb-4 border-b-2 pb-1 border-black w-fit">Personal Information</h2>
          <div className="space-y-3 text-xs">
            <div className="bg-lightGrey px-4 py-1 ">
              <InfoRow
  label="Name :"
  value={
    currentUser
      ? [currentUser.firstName, currentUser.middleName, currentUser.lastName]
          .filter(Boolean)
          .join(" ")
      : ""
  }
/>


            </div>
            <div className="bg-lightGrey px-4 py-1  ">
            <InfoRow label="Email ID :" value={currentUser?.email || ""} />

            </div>
            <div className="bg-lightGrey px-4 py-1  ">  {/* User Type */}
  
    <InfoRow label="User Type :" value={currentUser?.type} />
  
</div>
            <div className="bg-lightGrey px-4 py-1  ">  {/* User Type */}

  {/* User Role */}
  
    <InfoRow label="User Role :" value={currentUser?.userrole} />
    </div>




       {/* Dealership Section */}
{/* Market Area */}
{showDealership && currentUser?.area && (
  <div className="bg-lightGrey px-4 py-1 ">
    <InfoRow label="Market Area :" value={currentUser?.area || "N/A"} />
  </div>
)}

{/* Dealership */}
{showDealership && currentUser.dealership && (
  <div className="bg-lightGrey px-4 py-1 ">
    <InfoRow label="Dealership :" value={currentUser.dealership} />
  </div>
)}

{/* Assign Dealership */}
{showDealership && (
  <div className="bg-lightGrey px-4 py-1  mt-2">
    <InfoRow
      label="Assign Dealership :"
      value={
        <button
          onClick={() => IsAssigndealershipOpen(true)}
  className="w-7 h-6 bg-darkblue1 text-white  flex items-center justify-center text-xs leading-[0] font-bold"
        >
          +
        </button>
      }
    />
  </div>
)}


{/* Location Section only for Volvo Users in HQ */}
{showLocation && (
  <div className="bg-lightGrey px-4 py-1 mt-2">
    <InfoRow label="Location :" value={currentUser.location} />
  </div>
)}


          </div>
        </div>

        {/* Activity Status */}
        <div className="bg-white p-6  shadow-md">
          <h2 className="text-base font-bold mb-4 border-b-2 pb-1 border-black w-fit">Activity Status</h2>
          <div className="space-y-3 text-xs">
            <div className="bg-lightGrey px-4 py-1 ">
  <InfoRow
    label="Created On :"
    // value={
    //   currentUser?.createdOn
    //     ? moment(currentUser.createdOn)
    //         .tz("Asia/Kolkata")
    //         .format("DD MMM YYYY, hh:mm A") // 12-hour format with AM/PM
    //     : "N/A"
    // }
      value={formatedTime(currentUser?.createdOn)}

  />
</div>

<div className="bg-lightGrey px-4 py-1 ">
  <InfoRow
  label="Last Activation Email:"
  value={formatedTime(currentUser?.lastActivationEmail)}
/>

</div>

<div className="bg-lightGrey px-4 py-1 ">
  <InfoRow
    label="Last Login :"
    value={
      currentUser?.lastLoginTime
        ? formatedTime(currentUser.user.lastLoginTime)
        : "Not Yet Activated"
    }
  />
</div>


<div className="bg-lightGrey px-4 py-1 ">
  <InfoRow
    label="Account Activated :"
    value={currentUser?.status === "Active" ? "Yes" : "No"}
  />
</div>

<div className="bg-lightGrey px-4 py-1 ">
  <InfoRow
    label="Active User :"
    value={
    currentUser?.lastLogin &&
      moment().diff(moment(currentUser.lastLogin), "days") <= 90
        ? "Yes"
        : "No"
    }
  />
</div>


<div className="bg-lightGrey px-4 py-1 ">
  <InfoRow
    label="Current Status :"
    value={
      <span
        className={`font-medium ${
          currentUser?.status === "New"
            ? "text-blue"
            : currentUser?.status === "Active"
            ? "text-green"
            : currentUser?.status === "Inactive"
            ? "text-red"
            : currentUser?.status === "Temporarily Deactivated"
            ? "text-bluegreen"
            : "text-black"
        }`}
      >
        {currentUser?.status || "N/A"}
      </span>
    }
  />
</div>

          </div>
        </div>
      </div>

      {/* Modals */}
     
{/* Edit User Modal */}


      <ActivationEmail
        isactivationemailOpen={isactivationemailOpen}
        user={currentUser}
        onConfirm={handleConfirm}
        onCancel={handleCancel}
        emailLoading={emailLoading}
      />

    
   {isassigndealershipOpen && (
  <AssignDealership
    userId={passedUserId}
    currentUser={currentUser}
    allAvailableDealersData={allAvailableDealersData}
    onClose={() => IsAssigndealershipOpen(false)}
    onSave={() => {
      fetchUser();  // <-- refetch user after saving
    }}
  />
)}





      {showHistoryPopup && selectedUser && (
        <ShowHistoryUserdetails
          user={{ ...selectedUser, id: passedUserId }}
          onClose={() => setShowHistoryPopup(false)}
        />
      )}


     
{isedituserOpen && currentUser && (
  <EditUserdetails
    isOpen={isedituserOpen}
    onClose={() => setIsEdituserOpen(false)}
    user={currentUser}          // Pre-fill form
    userId={passedUserId}       // Pass the ID for API update
     onSave={() => {
      fetchUser();  // <-- refetch user after saving
    }}
  />
)}



{currentUser && (
  <DeleteUser
    isdeleteuserOpen={isdeleteuserOpen}
    onCancel={() => IsDeleteuserOpen(false)}
    onDelete={handleDeleteUser}
    user={currentUser}
  />
)}


<ActivateStatus
  isOpen={isActivateOpen}
  loading={toggleLoading}
  onClose={() => { if (!toggleLoading) setIsActivateOpen(false); }}
  onConfirm={() => toggleUserStatus(currentUser.id, "ACTIVE")}
/>

<DeactivateStatus
  isOpen={isDeactivateOpen}
  loading={toggleLoading}
  onClose={() => { if (!toggleLoading) setIsDeactivateOpen(false); }}
  onConfirm={() => toggleUserStatus(currentUser.id, "INACTIVE")}
/>


    </div>
  )
}

export default UserDetailscontent

// Reusable Row Component
const InfoRow = ({ label, value }) => (
  <div className="flex justify-start w-full items-center">
    <div className="font-semibold text-black">{label}</div>
    <div className="text-black text-right truncate ml-4">{value}</div>
  </div>
)