import React from "react";

const TemporaryDeactive = ({ isOpen, user, onConfirm, onCancel }) => {
  if (!isOpen) return null;


  // const fullName = [user?.firstName, user?.middleName, user?.lastName].filter(Boolean).join(" ");
const fullName =
  user?.firstName || user?.middleName || user?.lastName
    ? [user?.firstName, user?.middleName, user?.lastName].filter(Boolean).join(" ")
    : user?.name || user?.email || "";

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 px-4">
      <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg w-full max-w-sm sm:max-w-lg relative border-l-8 border-green">
        <p className="text-xs  font-medium font-VolvoNovum text-black mb-6 text-center leading-snug">
  Are you sure you want to temporarily deactivate{" "}
  <span className="font-semibold">{fullName || "this user"}</span>?
</p>

        <div className="flex flex-row flex-nowrap justify-center gap-4">
          <button
            onClick={onCancel}
            className="border-2 border-red2 text-red px-4 text-xs font-bold rounded-md hover:bg-red2 hover:shadow-md hover:scale-105 transition duration-200"
          >
            No
          </button>
          <button
            onClick={onConfirm}
            className="px-6 py-2 bg-green4 text-green5 text-xs border-2 border-transparent font-bold font-VolvoNovum rounded-md hover:bg-white hover:border-green4 hover:shadow-md hover:scale-105 transition duration-200"
          >
            Yes
          </button>
        </div>
      </div>
    </div>
  );
};

export default TemporaryDeactive;
