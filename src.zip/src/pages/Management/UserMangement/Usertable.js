import { useState } from "react";
import { IoSearch } from "react-icons/io5";

const Usertable = ({ onFilterChange }) => {
  const [filters, setFilters] = useState({
    search: "",
    marketArea: "Market Area",
    dealer: "Dealer",
    userrole: [],
    status: [],
  });
  const [isOpen, setIsOpen] = useState(null);

  const toggleDropdown = (dropdown) => {
    setIsOpen(isOpen === dropdown ? null : dropdown);
  };

  const handleSelect = (key, value) => {
    setFilters({ ...filters, [key]: value });
    onFilterChange({ ...filters, [key]: value });
    setIsOpen(null);
  };

  const handleMultiSelect = (key, value) => {
    const newValues = filters[key].includes(value)
      ? filters[key].filter((item) => item !== value)
      : [...filters[key], value];
    setFilters({ ...filters, [key]: newValues });
    onFilterChange({ ...filters, [key]: newValues });
  };

  return (
    <div className="flex flex-wrap md:flex-nowrap gap-2 md:gap-4 w-full justify-center">
      {/* Search Input */}
      <div className="relative w-full md:w-1/4 min-w-[150px]">
        <input
          type="text"
          placeholder="Search by name or email"
          value={filters.search}
          onChange={(e) => handleSelect("search", e.target.value)}
          className="w-full pl-10 pr-3 py-2 border rounded-lg bg-lightGrey focus:outline-none focus:ring hover:border-lightBlue transition"
        />
        <IoSearch className="absolute left-3 top-3 text-gray" />
      </div>
      
      {/* Dropdowns */}
      {[
        { key: "marketArea", label: "Market Area", options: ["East", "West", "North", "South", "Central"] },
        { key: "dealer", label: "Dealer", options: ["APHA-DL", "ALPHA-UP", "BSES", "DRS", "ENCORE", "ESDEE", "INFRA"] },
        { key: "status", label: "Status", options: ["New", "Active", "Inactive", "Delete"], multi: true },
        { key: "userrole", label: "User Role", options: ["Administrator", "Auditor", "Dealer CEO", "Retail Sales Manager"], multi: true },
      ].map(({ key, label, options, multi }) => (
        <div key={key} className="relative w-[24%] min-w-[140px]">
          <div className="rounded-lg px-4 py-2 bg-lightGrey cursor-pointer border" onClick={() => toggleDropdown(key)}>
            {multi ? (filters[key].length > 0 ? filters[key].join(", ") : label) : filters[key]}
          </div>
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/dropdown.png" alt="dropdown" className="absolute right-3 top-1/2 transform -translate-y-1/2 w-7 h-7 cursor-pointer" onClick={() => toggleDropdown(key)} />
          {isOpen === key && (
            <ul className="absolute left-0 mt-0 w-full bg-white shadow-lg rounded-b-lg text-sm max-h-56 overflow-y-auto border">
              {options.map((option) => (
                <li key={option} className="px-4 py-2 hover:bg-lightBlue cursor-pointer flex items-center gap-2">
                  {multi && <input type="checkbox" checked={filters[key].includes(option)} onChange={() => handleMultiSelect(key, option)} className="w-4 h-4" />}
                  <span onClick={() => !multi && handleSelect(key, option)}>{option}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </div>
  );
};

export default Usertable;
