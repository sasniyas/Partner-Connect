


// import React, { useState, useEffect } from "react";
// import Header from "../../../Components/Header";
// import { useNavigate } from "react-router-dom";
// import { motion } from "framer-motion";
// import SubNavbar3 from "../../../Components/SubNavbar3";
// import { useLocation } from "react-router-dom";

// function UserLogin() {
//   const [menuOpen, setMenuOpen] = useState(false);
//   const [user, setUser] = useState(null);
//   const navigate = useNavigate();
// const locationRouter = useLocation();
// const passedUser = locationRouter.state?.user;

 

//   const handleback = () => {
//     navigate("/usermangement");
//   };

//   return (
//     <div className="bg-white min-h-screen flex flex-col cursor-pointer">
//       <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
// <SubNavbar3/>
//       <div className={`transition-all duration-300 mt-[130px] p-4 ${menuOpen ? "ml-60" : "ml-[20px]"}`}>
//         <div className="p-4">
//           {/* Header Row */}
//           <div className="flex justify-between items-center">
//             <div className="flex items-center space-x-4">
//               <img onClick={handleback} src="/icons/Usermanagement/goback.png" alt="Back" className="w-8 h-8" />
// <h1 className="text-5xl font-medium text-darkblue1">
//   Welcome back, {user?.name || "User"}
// </h1>
             
//             </div>

//             {/* Action Buttons */}
//             <div className="flex space-x-6">
//               <button className="bg-white text-darkblue1 px-6 py-2 rounded-md border-2 border-darkblue1 text-base font-medium flex items-center justify-center gap-2 hover:scale-105 transition-transform duration-200">
//                 <img src="/icons/Usermanagement/export.png" alt="Export" className="w-5 h-5" />
//                 Export Report
//               </button>

//               <button className="bg-darkblue1 text-white px-6 py-2 rounded-md  text-base font-medium flex items-center justify-center gap-2 hover:scale-105 transition-transform duration-200">
//                 <img src="/icons/Usermanagement/calender.png" alt="Calendar" className="w-5 h-5" />
//                 Schedule Meeting
//               </button>
//             </div>
//           </div>

//           <p className="mt-2 ml-12 text-sm font-medium text-black/50 mb-10">
//             Here’s what’s happening with your dealership today.
//           </p>

//           {/* Banner */}
//         <div className="relative w-full rounded-xl overflow-hidden mb-10 shadow-md">
//   <img
//     src="/icons/Usermanagement/userloginimage.png"
//     alt="Banner"
//     className="w-full h-25 object-cover"
//   />
//   <div className="absolute inset-0 bg-black bg-opacity-30 flex flex-col justify-between p-20 font-VolvoNovum">
//     {/* Top Left Text */}
//     <div>
//       <h2 className="text-white text-3xl font-bold">Q1 Performance Highlights</h2>
//       <p className="text-white text-base mt-1">
//         Your dealership is outperforming 89% of dealers in your region.
//       </p>
//     </div>

//     {/* Bottom Left Box */}
//     <div className="bg-white/50 text-black px-4 py-2 inline-block rounded-lg font-semibold text-base w-max">
//       +23% Year-over-Year Growth
//     </div>
//   </div>
// </div>
// <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-20 px-2 min-h-[150px]">
//   {/* Card 1 */}
//   <motion.div
//   initial={{ opacity: 0, y: 20 }}
//   animate={{ opacity: 1, y: 0 }}
//   whileHover={{ scale: 1.05 }}
//   transition={{ duration: 0.4 }}
//   className="bg-white p-8 rounded-xl shadow-[0_2px_10px_#4E78A159] cursor-pointer"
// >
//   <div className="flex flex-col items-center space-y-2">
//     <img src="/icons/Usermanagement/dealercompelence.png" alt="Dealer" className="w-8 h-8" />
//     <h4 className="text-black font-medium text-sm">Dealer Compliance</h4>
//      <h2 className="text-2xl font-bold mt-10 text-mildBlue ">94%</h2>
//   <p className="text-lightgreen text-sm"> 2.1% vs last month</p>
//   </div>
 
// </motion.div>

//   {/* Card 2 */}
//   <motion.div
//   initial={{ opacity: 0, y: 20 }}
//   animate={{ opacity: 1, y: 0 }}
//   whileHover={{ scale: 1.05 }}
//   transition={{ duration: 0.4 }}
//     // className="bg-white p-8 rounded-xl shadow-[0_2px_10px_#4E78A159]"
//       className="bg-white p-6 rounded-xl shadow-[0_2px_10px_#4E78A159] cursor-pointer w-full max-w-[260px] mx-auto"

//   >
//     <div className="flex flex-col items-center space-y-2">
//       <img src="/icons/Usermanagement/activedealer.png" alt="Active Dealer" className="w-8 h-8" />
//       <h4 className="text-black font-medium text-sm">Active Dealer</h4>
//        <h2 className="text-2xl font-bold mt-10 text-mildBlue">145</h2>
//     <p className="text-lightgreen text-sm">3 new this month</p>
//     </div>
   
//   </motion.div>

//   <motion.div
//   initial={{ opacity: 0, y: 20 }}
//   animate={{ opacity: 1, y: 0 }}
//   whileHover={{ scale: 1.05 }}
//   transition={{ duration: 0.4 }}
//     // className="bg-white p-8 rounded-xl shadow-[0_2px_10px_#4E78A159]"
//       className="bg-white p-6 rounded-xl shadow-[0_2px_10px_#4E78A159] cursor-pointer w-full max-w-[260px] mx-auto"

//   >
//     <div className="flex flex-col items-center space-y-2">
//       <img src="/icons/Usermanagement/pdpcompletion.png" alt="PDP" className="w-8 h-8" />
//       <h4 className="text-black font-medium text-sm">PDP Completion</h4>
//       <h2 className="text-2xl font-bold mt-10 text-mildBlue">87%</h2>
//     <p className="text-green-600 text-sm">5.4% vs last month</p>
//     </div>
    
//   </motion.div>

//   {/* Card 4 */}
//   <motion.div
//   initial={{ opacity: 0, y: 20 }}
//   animate={{ opacity: 1, y: 0 }}
//   whileHover={{ scale: 1.05 }}
//   transition={{ duration: 0.4 }}
//     // className="bg-white p-8 rounded-xl shadow-[0_2px_10px_#4E78A159]"
//       className="bg-white p-6 rounded-xl shadow-[0_2px_10px_#4E78A159] cursor-pointer w-full max-w-[260px] mx-auto"

//   >
//     <div className="flex flex-col items-center space-y-2">
//       <img src="/icons/Usermanagement/monthlyinvestment.png" alt="Investment" className="w-8 h-8" />
//       <h4 className="text-black font-medium text-sm">Monthly Investment</h4>
//        <h2 className="text-2xl font-bold mt-10 text-mildBlue">$4.2M</h2>
//     <p className="text-red text-sm">0.8% vs last month</p>
//     </div>
   
//   </motion.div>
// </div>

//  <div className="mt-12 mb-2 flex justify-end ">
//           <button
//             onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
//             className="bg-Silvergrey text-black font-bold px-4 py-2 rounded-lg shadow-lg hover:scale-110 transition duration-200"
//           >
//             ^
//           </button>
//         </div>
//                  </div>
//       </div>
//     </div>
//   );
// }

// export default UserLogin;


"use client";

import React, { useState } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";

function UserLogin() {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  // Get user from router state
  const locationRouter = useLocation();
  const passedUser = locationRouter.state?.user;
  const [user, setUser] = useState(passedUser || { name: "User" });

  const handleBack = () => navigate("/usermangement");

  return (
    <div className="bg-white min-h-screen flex flex-col cursor-pointer">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 mt-[130px] p-4 ${menuOpen ? "ml-60" : "ml-[20px]"}`}>
        <div className="p-4">
          {/* Header Row */}
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <img
                onClick={handleBack}
                src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/goback.png"
                alt="Back"
                className="w-8 h-8"
              />
              <h1 className="text-5xl font-medium text-darkblue1">
                Welcome back, {user?.name || "User"}
              </h1>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-6">
              <button className="bg-white text-darkblue1 px-6 py-2 rounded-md border-2 border-darkblue1 text-base font-medium flex items-center justify-center gap-2 hover:scale-105 transition-transform duration-200">
                <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/export.png" alt="Export" className="w-5 h-5" />
                Export Report
              </button>

              <button className="bg-darkblue1 text-white px-6 py-2 rounded-md text-base font-medium flex items-center justify-center gap-2 hover:scale-105 transition-transform duration-200">
                <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/calender.png" alt="Calendar" className="w-5 h-5" />
                Schedule Meeting
              </button>
            </div>
          </div>

          <p className="mt-2 ml-12 text-sm font-medium text-black/50 mb-10">
            Here’s what’s happening with your dealership today.
          </p>

          {/* Banner */}
          <div className="relative w-full rounded-xl overflow-hidden mb-10 shadow-md">
            <img
              src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/userloginimage.png"
              alt="Banner"
              className="w-full h-25 object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-30 flex flex-col justify-between p-20 font-VolvoNovum">
              <div>
                <h2 className="text-white text-3xl font-bold">Q1 Performance Highlights</h2>
                <p className="text-white text-base mt-1">
                  Your dealership is outperforming 89% of dealers in your region.
                </p>
              </div>

              <div className="bg-white/50 text-black px-4 py-2 inline-block rounded-lg font-semibold text-base w-max">
                +23% Year-over-Year Growth
              </div>
            </div>
          </div>

          {/* Dashboard Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-20 px-2 min-h-[150px]">
            {/* Card 1 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.4 }}
              className="bg-white p-8 rounded-xl shadow-[0_2px_10px_#4E78A159] cursor-pointer"
            >
              <div className="flex flex-col items-center space-y-2">
                <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/dealercompelence.png" alt="Dealer" className="w-8 h-8" />
                <h4 className="text-black font-medium text-sm">Dealer Compliance</h4>
                <h2 className="text-2xl font-bold mt-10 text-mildBlue ">94%</h2>
                <p className="text-lightgreen text-sm">2.1% vs last month</p>
              </div>
            </motion.div>

            {/* Card 2 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.4 }}
              className="bg-white p-6 rounded-xl shadow-[0_2px_10px_#4E78A159] cursor-pointer w-full max-w-[260px] mx-auto"
            >
              <div className="flex flex-col items-center space-y-2">
                <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/activedealer.png" alt="Active Dealer" className="w-8 h-8" />
                <h4 className="text-black font-medium text-sm">Active Dealer</h4>
                <h2 className="text-2xl font-bold mt-10 text-mildBlue">145</h2>
                <p className="text-lightgreen text-sm">3 new this month</p>
              </div>
            </motion.div>

            {/* Card 3 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.4 }}
              className="bg-white p-6 rounded-xl shadow-[0_2px_10px_#4E78A159] cursor-pointer w-full max-w-[260px] mx-auto"
            >
              <div className="flex flex-col items-center space-y-2">
                <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/pdpcompletion.png" alt="PDP" className="w-8 h-8" />
                <h4 className="text-black font-medium text-sm">PDP Completion</h4>
                <h2 className="text-2xl font-bold mt-10 text-mildBlue">87%</h2>
                <p className="text-green-600 text-sm">5.4% vs last month</p>
              </div>
            </motion.div>

            {/* Card 4 */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.4 }}
              className="bg-white p-6 rounded-xl shadow-[0_2px_10px_#4E78A159] cursor-pointer w-full max-w-[260px] mx-auto"
            >
              <div className="flex flex-col items-center space-y-2">
                <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/monthlyinvestment.png" alt="Investment" className="w-8 h-8" />
                <h4 className="text-black font-medium text-sm">Monthly Investment</h4>
                <h2 className="text-2xl font-bold mt-10 text-mildBlue">$4.2M</h2>
                <p className="text-red text-sm">0.8% vs last month</p>
              </div>
            </motion.div>
          </div>

          {/* Scroll to Top Button */}
          <div className="mt-12 mb-2 flex justify-end">
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="bg-Silvergrey text-black font-bold px-4 py-2 rounded-lg shadow-lg hover:scale-110 transition duration-200"
            >
              ^
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserLogin;
