"use client";

import { useState, useEffect, useRef } from "react";
import { IoSearch } from "react-icons/io5";
import DeleteModal from "../../../Components/DeleteModal";
import CommentPopup from "./CommentPopup";
import Filter from "../../../Components/Filter";
import DeleteAllRecords from "../../../Components/DeleteAllRecords";
import { getUserLogs, deleteUserLog } from "../../../services/authLogs/authLogs.service";
import { formatDateOnly, formatedTime } from "../../../util/timeFormat";
import Searchinput from "../../../Components/Searchinput";
import { data } from "react-router-dom";
import { ChevronUp, ChevronDown } from "lucide-react";
import { ArrowUp } from "lucide-react";
import { ArrowDown } from "lucide-react";
import { ChevronsUpDown } from "lucide-react";
import useCRUDWithReset from "../../../util/useCRUDWithReset"

const AuthenticationLog = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [isOpen, setIsOpen] = useState("");
  const loginStatusRef = useRef(null);
  const [logs, setLogs] = useState([]);
  const [isDeleteAllOpen, setIsDeleteAllOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [hoveredLogName, setHoveredLogName] = useState(null);
const [hoveredActivity, setHoveredActivity] = useState(null);
const [hoveredPerformedBy, setHoveredPerformedBy] = useState(null);
const today = new Date().toISOString().split("T")[0];
  const [showRealFromInput, setShowRealFromInput] = useState(false);
  const [showRealToInput, setShowRealToInput] = useState(false);

  const fromDateRef = useRef(null);
  const toDateRef = useRef(null);

  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [selectedLog, setSelectedLog] = useState(null);
  const [logDetailsVisible, setLogDetailsVisible] = useState(false);
  const [selectedPerformedBy, setSelectedPerformedBy] = useState("");
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  const [selectedValues, setSelectedValues] = useState({ loginStatus: [] });
  // ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);
  const tableContainerRef = useRef(null);


  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };
  // Mobile view state
  const [isMobileView, setIsMobileView] = useState(false);
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  const [performedByOptions, setPerformedByOptions] = useState(["All"]);
const [loginStatusOptions, setLoginStatusOptions] = useState(["All"]);


  // Check screen size for mobile view
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 1024);
    };
    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  // Fetch logs from API
  const fetchLogs = async (filters = {}) => {
    try {
      setIsLoading(true);
      setError(null);
      const authFilters = { ...filters, logType: 'auth' };
      const data = await getUserLogs(authFilters);
      // console.log("✅ getUserLogs response:", data);
      setLogs(data || []);
    } catch (err) {
      // console.error("Error fetching logs:", err);
      setError(err.message);
      setLogs([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);
  const fetchPerformedByOptions = async () => {
  try {
    const data = await getUserLogs({ logType: 'auth' }); // fetch all auth logs
    if (Array.isArray(data)) {
      const uniquePerformedBy = [
        ...new Set(
          data
            .map((log) => log.performed_by?.trim())
            .filter(Boolean) // remove null/undefined/empty
        ),
      ];
      setPerformedByOptions(uniquePerformedBy);
    }
  } catch (err) {
    // console.error("Error fetching performedBy options:", err);
    setPerformedByOptions([]); // fallback
  }
};
useEffect(() => {
             // fetch all logs
  fetchPerformedByOptions(); // fetch unique "Performed By" options
}, []);
const fetchActivityOptions = async () => {
  try {
    // Fetch all auth logs
    const data = await getUserLogs({ logType: 'auth' });
    
    if (Array.isArray(data)) {
      // Extract unique activity values
      const uniqueActivities = [
        ...new Set(
          data
            .map((log) => log.activity?.trim())
            .filter(Boolean) // remove null/undefined/empty
        )
      ];
      
      setLoginStatusOptions(uniqueActivities); // Add "All" as default
    }
  } catch (err) {
    // console.error("Error fetching activity options:", err);
    setLoginStatusOptions([]); // fallback in case of error
  }
};
useEffect(() => {
  fetchLogs();              // your logs
  fetchPerformedByOptions(); // your performedBy options
  fetchActivityOptions();   // fetch activity options
}, []);

  // useEffect(() => {
  //   const filters = {
  //     ...(searchTerm && { search: searchTerm }),
  //     ...(fromDate && { startDate: fromDate }),
  //     ...(toDate && { endDate: toDate }),
  //     ...(selectedValues.loginStatus.length > 0 && { activity: selectedValues.loginStatus.join(',') })
  //   };

  //   if (Object.keys(filters).length > 0) {
  //     fetchLogs(filters);
  //   }
  // }, [searchTerm, fromDate, toDate, selectedValues.loginStatus]);

  // const parseDate = (dateStr) => {
  //   const parsed = new Date(dateStr);
  //   return isNaN(parsed.getTime()) ? null : parsed;
  // };

  const handleDeleteAll = async () => {
    try {
      const deletePromises = logs.map(log => deleteUserLog(log.id));
      await Promise.all(deletePromises);
      await fetchLogs();
      setIsDeleteAllOpen(false);
    } catch (err) {
      // console.error("Error deleting all logs:", err);
      setError(err.message);
    }
  };
const parseDate = (date) => {
  if (!date) return null;
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
};
 const filteredLogs = logs.filter((log) => {
  const logDate = parseDate(log.createdOn);
  const from = parseDate(fromDate);
  const to = parseDate(toDate);

  const isWithinDateRange =
    (!from || (logDate && logDate.getTime() >= from.getTime())) &&
    (!to || (logDate && logDate.getTime() <= to.getTime()));

  const matchesActivity =
    selectedValues.loginStatus.length === 0 ||
    selectedValues.loginStatus.includes(log.activity);

  const matchesPerformedBy =
    !selectedPerformedBy ||
    selectedPerformedBy.length === 0 ||
    selectedPerformedBy.includes("All") ||
    selectedPerformedBy.some(
      (role) =>
        role.toLowerCase() === log.performed_by?.toLowerCase()
    );

  const lowerSearch = searchTerm.toLowerCase();

  const matchesSearch =
    !searchTerm ||
    `${log.firstName} ${log.lastName}`.toLowerCase().includes(lowerSearch) ||
    log.email?.toLowerCase().includes(lowerSearch) ||
    log.activity?.toLowerCase().includes(lowerSearch) ||
    log.performed_by?.toLowerCase().includes(lowerSearch);

  return (
    matchesSearch &&
    matchesActivity &&
    matchesPerformedBy &&
    isWithinDateRange
  );
});
let sortedLogs = [...filteredLogs];

if (sortKey) {
  sortedLogs.sort((a, b) => {
    let valA, valB;

    switch (sortKey) {
      case "name":
        valA = `${a.firstName} ${a.lastName}`.toLowerCase();
        valB = `${b.firstName} ${b.lastName}`.toLowerCase();
        break;
      case "performedBy":
        valA = (a.performed_by || "").toLowerCase();
        valB = (b.performed_by || "").toLowerCase();
        break;
      default:
        valA = (a[sortKey] || "").toString().toLowerCase();
        valB = (b[sortKey] || "").toString().toLowerCase();
    }

    if (sortOrder === "asc") return valA.localeCompare(valB);
    if (sortOrder === "desc") return valB.localeCompare(valA);
    return 0;
  });
}

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (loginStatusRef.current && !loginStatusRef.current.contains(event.target)) {
        setIsOpen("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleDelete = async () => {
    if (itemToDelete) {
      try {
        await deleteUserLog(itemToDelete.id);
        resetSortAndFilter()
        await fetchLogs();
        setDeleteModalVisible(false);
        setItemToDelete(null);
      } catch (err) {
        // console.error("Error deleting log:", err);
        setError(err.message);
      }
    }
  };
const { resetSortAndFilter } = useCRUDWithReset(
  setSortKey,
  setSortOrder,
  {
    searchTerm: { setter: setSearchTerm, resetValue: "" },
    fromDate: { setter: setFromDate, resetValue: "" },
    toDate: { setter: setToDate, resetValue: "" },

    selectedValues: {
      setter: setSelectedValues,
      resetValue: {
        loginStatus: [],
        performedBy: [],
      },
    },

    selectedPerformedBy: {
      setter: setSelectedPerformedBy,
      resetValue: [],
    },
  }
);

  // Mobile Card Component
  const MobileLogCard = ({ log }) => (
    <div className="bg-white border border-gray-200 rounded-lg p-3 mb-3 shadow-sm">
      <div className="flex justify-between items-start mb-2">
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm text-black truncate">
            {`${log.firstName} ${log.lastName}`}
          </p>
          <p className="text-xs text-gray-500 mt-0.5">
            {formatedTime(log.createdOn)}
          </p>
        </div>
        <div className="flex items-center gap-2 ml-2">
          <button
            className="p-1.5 rounded-md hover:bg-gray-100 transition-colors"
            onClick={() => {
              setSelectedLog({
                ...log,
                date: new Date(log.createdOn).toLocaleDateString(),
                user: { name: `${log.firstName} ${log.lastName}` },
                performedBy: log.performed_by,
                message: log.message || "No message available"
              });
              setLogDetailsVisible(true);
            }}
          >
           <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M12.3604 4C6.58038 4 2.64438 9.857 4.82438 15.21L5.75738 17.498C5.79812 17.5978 5.80553 17.7081 5.7785 17.8124C5.75147 17.9167 5.69144 18.0095 5.60738 18.077L3.63438 19.66C3.5536 19.7248 3.49494 19.8131 3.4665 19.9127C3.43805 20.0122 3.44123 20.1182 3.47558 20.2159C3.50994 20.3136 3.57378 20.3982 3.6583 20.458C3.74281 20.5179 3.84382 20.55 3.94738 20.55H11.7674C12.9142 20.5504 14.0499 20.3248 15.1096 19.8861C16.1692 19.4475 17.1321 18.8043 17.9431 17.9934C18.7541 17.1825 19.3973 16.2197 19.8361 15.1601C20.2749 14.1005 20.5006 12.9649 20.5004 11.818C20.5004 7.5 17.0004 4 12.6824 4H12.3604Z" fill="#1B365D"/>
</svg>
          </button>
          <button
            className="p-1.5 rounded-md hover:bg-gray-100 transition-colors"
            onClick={() => {
              setItemToDelete(log);
              setDeleteModalVisible(true);
            }}
          >
           <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>
          </button>
        </div>
      </div>

      <div className="space-y-1.5">
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Activity:</span>
          <span className="text-xs text-black font-medium text-right flex-1 ml-2 truncate">
            {log.activity}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Performed By:</span>
          <span className="text-xs text-black text-right">{log.performed_by}</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="w-full flex justify-center px-2 sm:px-3 lg:px-2">
      <div className="w-full">
        <h2 className="text-xl font-semibold text-darkblue1 text-center mb-2">Authentication Log</h2>

        {/* Filters - Mobile */}
        <div className="lg:hidden mb-2">
          <div className="flex items-center gap-2 mb-2">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="flex-1 h-8"
              bgColor="bg-white"
              borderColor="border-black/60"
              textColor="text-black"
              focusRing="focus:ring-black/60"
              shadow="shadow-none"
              inputPadding="pl-7 pr-3 py-1.5"
              iconSize="w-3.5 h-3.5"
              iconLeft="left-3"
              iconColor="text-black"
            />
            <button
              onClick={() => setShowMobileFilters(!showMobileFilters)}
              className="flex items-center gap-1 px-3 py-1.5 border border-black/60 bg-white text-black text-xs font-medium h-8"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
              </svg>
              Filters
              <svg xmlns="http://www.w3.org/2000/svg" className={`w-3 h-3 transition-transform ${showMobileFilters ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            <button
              onClick={() => setIsDeleteAllOpen(true)}
              className="flex items-center justify-center gap-1 text-red bg-red2 px-3 py-1.5 h-8 hover:bg-white hover:border hover:border-red text-xs whitespace-nowrap"
            >
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>              Delete All
            </button>
          </div>

          {/* Mobile Collapsible Filters */}
          <div className={`${showMobileFilters ? 'block' : 'hidden'} mb-2`}>
            <div className="grid grid-cols-2 gap-2">
              <Filter
                name="loginStatus"
                value={selectedValues.loginStatus}
                options={["Login successful", "Login successful", "Log out"]}
                onChange={(name, newValue) =>
                  setSelectedValues((prev) => ({ ...prev, [name]: newValue }))
                }
                placeholder="Activity"
                buttonBorderColor="border-black/60"
                dropdownBorderColor="border-black/60"
                textColor="text-black"
                customWidth="w-full"
              />
             <Filter
  name="performedBy"
  value={selectedPerformedBy}
  options={performedByOptions}
  onChange={(name, newValue) => setSelectedPerformedBy(newValue)}
  placeholder="Performed By"
  textColor="text-black"
  buttonBorderColor="border-black/60"
  dropdownBorderColor="border-black/60"
  customWidth="w-full"
/>

           {/* From Date */}
<div className="relative w-full">
  {!showRealFromInput && (
    <div className="relative w-full">
      <input
        type="date"
        ref={fromDateRef}
        value={fromDate}
          max={today}   // ✅ future dates disabled
        onChange={(e) => setFromDate(e.target.value)}
        className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-black cursor-pointer"
        onClick={() => fromDateRef.current?.showPicker()}
      />

      {/* Calendar SVG */}
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
        fill="none"
        onClick={() => fromDateRef.current?.showPicker()}
      >
        <path
          d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
          stroke="black"
          strokeOpacity="0.7"
          strokeWidth="1.5"
        />
        <path
          d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
          stroke="black"
          strokeOpacity="0.7"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        <path
          d="M18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18C16.7348 18 16.4804 17.8946 16.2929 17.7071C16.1054 17.5196 16 17.2652 16 17C16 16.7348 16.1054 16.4804 16.2929 16.2929C16.4804 16.1054 16.7348 16 17 16C17.2652 16 17.5196 16.1054 17.7071 16.2929C17.8946 16.4804 18 16.7348 18 17ZM18 13C18 13.2652 17.8946 13.5196 17.7071 13.7071C17.5196 13.8946 17.2652 14 17 14C16.7348 14 16.4804 13.8946 16.2929 13.7071C16.1054 13.5196 16 13.2652 16 13C16 12.7348 16.1054 12.4804 16.2929 12.2929C16.4804 12.1054 16.7348 12 17 12C17.2652 12 17.5196 12.1054 17.7071 12.2929C17.8946 12.4804 18 12.7348 18 13ZM13 17C13 17.2652 12.8946 17.5196 12.7071 17.7071C12.5196 17.8946 12.2652 18 12 18C11.7348 18 11.4804 17.8946 11.2929 17.7071C11.1054 17.5196 11 17.2652 11 17C11 16.7348 11.1054 16.4804 11.2929 16.2929C11.4804 16.1054 11.7348 16 12 16C12.2652 16 12.5196 16.1054 12.7071 16.2929C12.8946 16.4804 13 16.7348 13 17ZM13 13C13 13.2652 12.8946 13.5196 12.7071 13.7071C12.5196 13.8946 12.2652 14 12 14C11.7348 14 11.4804 13.8946 11.2929 13.7071C11.1054 13.5196 11 13.2652 11 13C11 12.7348 11.1054 12.4804 11.2929 12.2929C11.4804 12.1054 11.7348 12 12 12C12.2652 12 12.5196 12.1054 12.7071 12.2929C12.8946 12.4804 13 12.7348 13 13ZM8 17C8 17.2652 7.89464 17.5196 7.70711 17.7071C7.51957 17.8946 7.26522 18 7 18C6.73478 18 6.48043 17.8946 6.29289 17.7071C6.10536 17.5196 6 17.2652 6 17C6 16.7348 6.10536 16.4804 6.29289 16.2929C6.48043 16.1054 6.73478 16 7 16C7.26522 16 7.51957 16.1054 7.70711 16.2929C7.89464 16.4804 8 16.7348 8 17ZM8 13C8 13.2652 7.89464 13.5196 7.70711 13.7071C7.51957 13.8946 7.26522 14 7 14C6.73478 14 6.48043 13.8946 6.29289 13.7071C6.10536 13.5196 6 13.2652 6 13C6 12.7348 6.10536 12.4804 6.29289 12.2929C6.48043 12.1054 6.73478 12 7 12C7.26522 12 7.51957 12.1054 7.70711 12.2929C7.89464 12.4804 8 12.7348 8 13Z"
          fill="black"
          fillOpacity="0.7"
        />
      </svg>
    </div>
  )}
  {showRealFromInput && (
    <div className="relative w-full">
      <input
        type="date"
        ref={fromDateRef}
          max={today}   // ✅ future dates disabled
        value={fromDate}
        onChange={(e) => setFromDate(e.target.value)}
        className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-black cursor-pointer"
        onClick={() => fromDateRef.current?.showPicker()}
      />

      {/* Calendar SVG */}
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
        fill="none"
        onClick={() => fromDateRef.current?.showPicker()}
      >
        <path
          d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
          stroke="black"
          strokeOpacity="0.7"
          strokeWidth="1.5"
        />
        <path
          d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
          stroke="black"
          strokeOpacity="0.7"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        <path
          d="M18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18C16.7348 18 16.4804 17.8946 16.2929 17.7071C16.1054 17.5196 16 17.2652 16 17C16 16.7348 16.1054 16.4804 16.2929 16.2929C16.4804 16.1054 16.7348 16 17 16C17.2652 16 17.5196 16.1054 17.7071 16.2929C17.8946 16.4804 18 16.7348 18 17ZM18 13C18 13.2652 17.8946 13.5196 17.7071 13.7071C17.5196 13.8946 17.2652 14 17 14C16.7348 14 16.4804 13.8946 16.2929 13.7071C16.1054 13.5196 16 13.2652 16 13C16 12.7348 16.1054 12.4804 16.2929 12.2929C16.4804 12.1054 16.7348 12 17 12C17.2652 12 17.5196 12.1054 17.7071 12.2929C17.8946 12.4804 18 12.7348 18 13ZM13 17C13 17.2652 12.8946 17.5196 12.7071 17.7071C12.5196 17.8946 12.2652 18 12 18C11.7348 18 11.4804 17.8946 11.2929 17.7071C11.1054 17.5196 11 17.2652 11 17C11 16.7348 11.1054 16.4804 11.2929 16.2929C11.4804 16.1054 11.7348 16 12 16C12.2652 16 12.5196 16.1054 12.7071 16.2929C12.8946 16.4804 13 16.7348 13 17ZM13 13C13 13.2652 12.8946 13.5196 12.7071 13.7071C12.5196 13.8946 12.2652 14 12 14C11.7348 14 11.4804 13.8946 11.2929 13.7071C11.1054 13.5196 11 13.2652 11 13C11 12.7348 11.1054 12.4804 11.2929 12.2929C11.4804 12.1054 11.7348 12 12 12C12.2652 12 12.5196 12.1054 12.7071 12.2929C12.8946 12.4804 13 12.7348 13 13ZM8 17C8 17.2652 7.89464 17.5196 7.70711 17.7071C7.51957 17.8946 7.26522 18 7 18C6.73478 18 6.48043 17.8946 6.29289 17.7071C6.10536 17.5196 6 17.2652 6 17C6 16.7348 6.10536 16.4804 6.29289 16.2929C6.48043 16.1054 6.73478 16 7 16C7.26522 16 7.51957 16.1054 7.70711 16.2929C7.89464 16.4804 8 16.7348 8 17ZM8 13C8 13.2652 7.89464 13.5196 7.70711 13.7071C7.51957 13.8946 7.26522 14 7 14C6.73478 14 6.48043 13.8946 6.29289 13.7071C6.10536 13.5196 6 13.2652 6 13C6 12.7348 6.10536 12.4804 6.29289 12.2929C6.48043 12.1054 6.73478 12 7 12C7.26522 12 7.51957 12.1054 7.70711 12.2929C7.89464 12.4804 8 12.7348 8 13Z"
          fill="black"
          fillOpacity="0.7"
        />
      </svg>
    </div>
  )}
</div>

{/* To Date */}
<div className="relative w-full">
  {!showRealToInput && (
    <input
      type="text"
        max={today}   // ✅ future dates disabled
      placeholder="To Date"
      readOnly
      className="w-full py-1.5 px-3 text-xs border border-black/50 pr-10 text-gray-400 cursor-pointer"
      onFocus={() => {
        setShowRealToInput(true);
        setTimeout(() => toDateRef.current?.showPicker(), 0);
      }}
    />
  )}
  {showRealToInput && (
    <input
      type="date"
      ref={toDateRef}
      value={toDate}
        max={today}   // ✅ future dates disabled
      onChange={(e) => setToDate(e.target.value)}
      className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-black"
    />
  )}

  {/* Calendar SVG */}
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
    fill="none"
    onClick={() => {
      setShowRealToInput(true);
      setTimeout(() => toDateRef.current?.showPicker(), 0);
    }}
  >
    <path
      d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
    />
    <path
      d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path
      d="M18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18C16.7348 18 16.4804 17.8946 16.2929 17.7071C16.1054 17.5196 16 17.2652 16 17C16 16.7348 16.1054 16.4804 16.2929 16.2929C16.4804 16.1054 16.7348 16 17 16C17.2652 16 17.5196 16.1054 17.7071 16.2929C17.8946 16.4804 18 16.7348 18 17ZM18 13C18 13.2652 17.8946 13.5196 17.7071 13.7071C17.5196 13.8946 17.2652 14 17 14C16.7348 14 16.4804 13.8946 16.2929 13.7071C16.1054 13.5196 16 13.2652 16 13C16 12.7348 16.1054 12.4804 16.2929 12.2929C16.4804 12.1054 16.7348 12 17 12C17.2652 12 17.5196 12.1054 17.7071 12.2929C17.8946 12.4804 18 12.7348 18 13ZM13 17C13 17.2652 12.8946 17.5196 12.7071 17.7071C12.5196 17.8946 12.2652 18 12 18C11.7348 18 11.4804 17.8946 11.2929 17.7071C11.1054 17.5196 11 17.2652 11 17C11 16.7348 11.1054 16.4804 11.2929 16.2929C11.4804 16.1054 11.7348 16 12 16C12.2652 16 12.5196 16.1054 12.7071 16.2929C12.8946 16.4804 13 16.7348 13 17ZM13 13C13 13.2652 12.8946 13.5196 12.7071 13.7071C12.5196 13.8946 12.2652 14 12 14C11.7348 14 11.4804 13.8946 11.2929 13.7071C11.1054 13.5196 11 13.2652 11 13C11 12.7348 11.1054 12.4804 11.2929 12.2929C11.4804 12.1054 11.7348 12 12 12C12.2652 12 12.5196 12.1054 12.7071 12.2929C12.8946 12.4804 13 12.7348 13 13ZM8 17C8 17.2652 7.89464 17.5196 7.70711 17.7071C7.51957 17.8946 7.26522 18 7 18C6.73478 18 6.48043 17.8946 6.29289 17.7071C6.10536 17.5196 6 17.2652 6 17C6 16.7348 6.10536 16.4804 6.29289 16.2929C6.48043 16.1054 6.73478 16 7 16C7.26522 16 7.51957 16.1054 7.70711 16.2929C7.89464 16.4804 8 16.7348 8 17ZM8 13C8 13.2652 7.89464 13.5196 7.70711 13.7071C7.51957 13.8946 7.26522 14 7 14C6.73478 14 6.48043 13.8946 6.29289 13.7071C6.10536 13.5196 6 13.2652 6 13C6 12.7348 6.10536 12.4804 6.29289 12.2929C6.48043 12.1054 6.73478 12 7 12C7.26522 12 7.51957 12.1054 7.70711 12.2929C7.89464 12.4804 8 12.7348 8 13Z"
      fill="black"
      fillOpacity="0.7"
    />
  </svg>
</div>
            </div>
          </div>
        </div>

        {/* Filters - Desktop */}
        <div className="hidden lg:flex flex-row items-center justify-between gap-4 mb-2">
          <div className="flex items-center gap-3">
            <Searchinput
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search"
              className="w-[180px]"
              bgColor="bg-white"
              borderColor="border-black/60"
              textColor="text-black"
              focusRing="focus:ring-black/60"
              shadow="shadow-none"
              inputPadding="pl-6 pr-3 py-1.5"
              iconSize="w-3 h-3"
              iconLeft="left-3"
              iconColor="text-black"
            />

          <Filter
  name="loginStatus"
  value={selectedValues.loginStatus}
  options={loginStatusOptions} // <-- dynamic from API
  onChange={(name, newValue) =>
    setSelectedValues((prev) => ({ ...prev, [name]: newValue }))
  }
  placeholder="Activity"
  buttonBorderColor="border-black/60"
  dropdownBorderColor="border-black/60"
  textColor="text-black"
  customWidth="w-[220px]"
/>


            <Filter
              name="performedBy"
              value={selectedPerformedBy}
              options={performedByOptions}
              onChange={(name, newValue) => setSelectedPerformedBy(newValue)}
              placeholder="Performed By"
              textColor="text-black"
              buttonBorderColor="border-black/60"
              dropdownBorderColor="border-black/60"
              dropdownHoverColor="hover:bg-lightBlue/50"
              customWidth="w-[180px]"
            />

         {/* From Date */}
<div className="relative w-[150px]">
  {!showRealFromInput && (
    <input
      type="text"
      placeholder="From Date"
      readOnly
        max={today}   // ✅ future dates disabled
      className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-gray-400 cursor-pointer"
      onFocus={() => {
        setShowRealFromInput(true);
        setTimeout(() => fromDateRef.current?.showPicker(), 0);
      }}
    />
  )}
  {showRealFromInput && (
    <input
      type="date"
      ref={fromDateRef}
      value={fromDate}
        max={today}   // ✅ future dates disabled
      onChange={(e) => setFromDate(e.target.value)}
      className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-black"
    />
  )}
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
    fill="none"
    onClick={() => {
      setShowRealFromInput(true);
      setTimeout(() => fromDateRef.current?.showPicker(), 0);
    }}
  >
    <path
      d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
    />
    <path
      d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path
      d="M18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18C16.7348 18 16.4804 17.8946 16.2929 17.7071C16.1054 17.5196 16 17.2652 16 17C16 16.7348 16.1054 16.4804 16.2929 16.2929C16.4804 16.1054 16.7348 16 17 16C17.2652 16 17.5196 16.1054 17.7071 16.2929C17.8946 16.4804 18 16.7348 18 17ZM18 13C18 13.2652 17.8946 13.5196 17.7071 13.7071C17.5196 13.8946 17.2652 14 17 14C16.7348 14 16.4804 13.8946 16.2929 13.7071C16.1054 13.5196 16 13.2652 16 13C16 12.7348 16.1054 12.4804 16.2929 12.2929C16.4804 12.1054 16.7348 12 17 12C17.2652 12 17.5196 12.1054 17.7071 12.2929C17.8946 12.4804 18 12.7348 18 13ZM13 17C13 17.2652 12.8946 17.5196 12.7071 17.7071C12.5196 17.8946 12.2652 18 12 18C11.7348 18 11.4804 17.8946 11.2929 17.7071C11.1054 17.5196 11 17.2652 11 17C11 16.7348 11.1054 16.4804 11.2929 16.2929C11.4804 16.1054 11.7348 16 12 16C12.2652 16 12.5196 16.1054 12.7071 16.2929C12.8946 16.4804 13 16.7348 13 17ZM13 13C13 13.2652 12.8946 13.5196 12.7071 13.7071C12.5196 13.8946 12.2652 14 12 14C11.7348 14 11.4804 13.8946 11.2929 13.7071C11.1054 13.5196 11 13.2652 11 13C11 12.7348 11.1054 12.4804 11.2929 12.2929C11.4804 12.1054 11.7348 12 12 12C12.2652 12 12.5196 12.1054 12.7071 12.2929C12.8946 12.4804 13 12.7348 13 13ZM8 17C8 17.2652 7.89464 17.5196 7.70711 17.7071C7.51957 17.8946 7.26522 18 7 18C6.73478 18 6.48043 17.8946 6.29289 17.7071C6.10536 17.5196 6 17.2652 6 17C6 16.7348 6.10536 16.4804 6.29289 16.2929C6.48043 16.1054 6.73478 16 7 16C7.26522 16 7.51957 16.1054 7.70711 16.2929C7.89464 16.4804 8 16.7348 8 17ZM8 13C8 13.2652 7.89464 13.5196 7.70711 13.7071C7.51957 13.8946 7.26522 14 7 14C6.73478 14 6.48043 13.8946 6.29289 13.7071C6.10536 13.5196 6 13.2652 6 13C6 12.7348 6.10536 12.4804 6.29289 12.2929C6.48043 12.1054 6.73478 12 7 12C7.26522 12 7.51957 12.1054 7.70711 12.2929C7.89464 12.4804 8 12.7348 8 13Z"
      fill="black"
      fillOpacity="0.7"
    />
  </svg>
</div>

{/* To Date */}
<div className="relative w-[150px]">
  {!showRealToInput && (
    <input
      type="text"
      placeholder="To Date"
      readOnly
        max={today}   // ✅ future dates disabled
      className="w-full py-1.5 px-3 text-xs border border-black/50 pr-10 text-gray-400 cursor-pointer"
      onFocus={() => {
        setShowRealToInput(true);
        setTimeout(() => toDateRef.current?.showPicker(), 0);
      }}
    />
  )}
  {showRealToInput && (
    <input
      type="date"
      ref={toDateRef}
        max={today}   // ✅ future dates disabled
      value={toDate}
      onChange={(e) => setToDate(e.target.value)}
      className="w-full py-1.5 px-3 text-xs border border-black/60 pr-10 text-black"
    />
  )}
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className="absolute right-3 top-1/2 w-4 h-4 transform -translate-y-1/2 cursor-pointer"
    fill="none"
    onClick={() => {
      setShowRealToInput(true);
      setTimeout(() => toDateRef.current?.showPicker(), 0);
    }}
  >
    <path
      d="M2 12C2 8.229 2 6.343 3.172 5.172C4.344 4.001 6.229 4 10 4H14C17.771 4 19.657 4 20.828 5.172C21.999 6.344 22 8.229 22 12V14C22 17.771 22 19.657 20.828 20.828C19.656 21.999 17.771 22 14 22H10C6.229 22 4.343 22 3.172 20.828C2.001 19.656 2 17.771 2 14V12Z"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
    />
    <path
      d="M7 4V2.5M17 4V2.5M2.5 9H21.5"
      stroke="black"
      strokeOpacity="0.7"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path
      d="M18 17C18 17.2652 17.8946 17.5196 17.7071 17.7071C17.5196 17.8946 17.2652 18 17 18C16.7348 18 16.4804 17.8946 16.2929 17.7071C16.1054 17.5196 16 17.2652 16 17C16 16.7348 16.1054 16.4804 16.2929 16.2929C16.4804 16.1054 16.7348 16 17 16C17.2652 16 17.5196 16.1054 17.7071 16.2929C17.8946 16.4804 18 16.7348 18 17ZM18 13C18 13.2652 17.8946 13.5196 17.7071 13.7071C17.5196 13.8946 17.2652 14 17 14C16.7348 14 16.4804 13.8946 16.2929 13.7071C16.1054 13.5196 16 13.2652 16 13C16 12.7348 16.1054 12.4804 16.2929 12.2929C16.4804 12.1054 16.7348 12 17 12C17.2652 12 17.5196 12.1054 17.7071 12.2929C17.8946 12.4804 18 12.7348 18 13ZM13 17C13 17.2652 12.8946 17.5196 12.7071 17.7071C12.5196 17.8946 12.2652 18 12 18C11.7348 18 11.4804 17.8946 11.2929 17.7071C11.1054 17.5196 11 17.2652 11 17C11 16.7348 11.1054 16.4804 11.2929 16.2929C11.4804 16.1054 11.7348 16 12 16C12.2652 16 12.5196 16.1054 12.7071 16.2929C12.8946 16.4804 13 16.7348 13 17ZM13 13C13 13.2652 12.8946 13.5196 12.7071 13.7071C12.5196 13.8946 12.2652 14 12 14C11.7348 14 11.4804 13.8946 11.2929 13.7071C11.1054 13.5196 11 13.2652 11 13C11 12.7348 11.1054 12.4804 11.2929 12.2929C11.4804 12.1054 11.7348 12 12 12C12.2652 12 12.5196 12.1054 12.7071 12.2929C12.8946 12.4804 13 12.7348 13 13ZM8 17C8 17.2652 7.89464 17.5196 7.70711 17.7071C7.51957 17.8946 7.26522 18 7 18C6.73478 18 6.48043 17.8946 6.29289 17.7071C6.10536 17.5196 6 17.2652 6 17C6 16.7348 6.10536 16.4804 6.29289 16.2929C6.48043 16.1054 6.73478 16 7 16C7.26522 16 7.51957 16.1054 7.70711 16.2929C7.89464 16.4804 8 16.7348 8 17ZM8 13C8 13.2652 7.89464 13.5196 7.70711 13.7071C7.51957 13.8946 7.26522 14 7 14C6.73478 14 6.48043 13.8946 6.29289 13.7071C6.10536 13.5196 6 13.2652 6 13C6 12.7348 6.10536 12.4804 6.29289 12.2929C6.48043 12.1054 6.73478 12 7 12C7.26522 12 7.51957 12.1054 7.70711 12.2929C7.89464 12.4804 8 12.7348 8 13Z"
      fill="black"
      fillOpacity="0.7"
    />
  </svg>
</div>

          </div>

          <button
            onClick={() => setIsDeleteAllOpen(true)}
            className="flex items-center justify-center gap-1 text-red bg-red2 px-4 py-1.5 hover:bg-white hover:border hover:border-red text-xs whitespace-nowrap"
          >
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>            Delete All
          </button>
        </div>

        {/* Hide scrollbar style */}
        <style>
          {`
            .hide-scrollbar::-webkit-scrollbar {
              display: none;
            }
            .hide-scrollbar {
              -ms-overflow-style: none;
              scrollbar-width: none;
            }
          `}
        </style>

        {/* Data Display */}
        {isMobileView ? (
          /* Mobile Card View */
          <div
            className={`overflow-y-auto hide-scrollbar ${showMobileFilters ? 'max-h-[calc(100vh-22rem)]' : 'max-h-[calc(100vh-14rem)]'}`}
          >
            <div className="space-y-3 pb-4">
              {isLoading ? (
                <div className="bg-white border border-gray-200 rounded-lg p-6 text-center text-gray-500">
                  <div className="flex items-center justify-center gap-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                    Loading logs...
                  </div>
                </div>
              ) : error ? (
                <div className="bg-white border border-gray-200 rounded-lg p-6 text-center text-red-500">
                  Error: {error}
                </div>
              ) : filteredLogs.length === 0 ? (
                <div className="bg-white border border-gray-200 rounded-lg p-6 text-center text-gray-500">
                  No data found.
                </div>
              ) : (
                filteredLogs.map((log) => (
                  <MobileLogCard key={log.id} log={log} />
                ))
              )}
            </div>
          </div>
        ) : (
          /* Desktop Table - Dynamic height based on content */
          <div className="bg-white shadow-md border border-Dustyblue overflow-hidden">
            <div
            ref={tableContainerRef}
              className="overflow-y-auto overflow-x-auto hide-scrollbar"
              style={{
                // Dynamic max-height: shrinks to content, expands up to max
                maxHeight: sortedLogs.length === 0 || isLoading || error
                  ? 'auto'
                  : 'calc(100vh - 14rem)',
              }}
              onScroll={handleTableScroll}
            >
              <table className="w-full border-collapse table-fixed">
                
                <thead className="bg-Dustyblue text-white text-left sticky top-0 z-10">
  <tr>
    <th
      className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[22%] cursor-pointer select-none"
      onClick={() => handleSort("name")}
    >
      <div className="flex items-center gap-1">
        User Name
        {sortKey !== "name" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}
        {sortKey === "name" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "name" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[22%] cursor-pointer select-none"
      onClick={() => handleSort("activity")}
    >
      <div className="flex items-center gap-1">
        Activity
        {sortKey === "activity" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "activity" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[22%] cursor-pointer select-none"
      onClick={() => handleSort("performedBy")}
    >
      <div className="flex items-center gap-1">
        Performed By
        {sortKey === "performedBy" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "performedBy" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th
      className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[22%] cursor-pointer select-none"
      onClick={() => handleSort("createdOn")}
    >
      <div className="flex items-center gap-1">
        Log In Date
        {sortKey === "createdOn" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
        {sortKey === "createdOn" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
      </div>
    </th>

    <th className="py-1.5 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-[12%]">
      Actions
    </th>
  </tr>
</thead>
                <tbody>
                  {isLoading && (
                    <tr>
                      <td colSpan={5} className="text-center py-8 text-gray-500">
                        <div className="flex items-center justify-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div>
                          Loading logs...
                        </div>
                      </td>
                    </tr>
                  )}
                  {error && !isLoading && (
                    <tr>
                      <td colSpan={5} className="text-center py-8 text-red-500">
                        Error: {error}
                      </td>
                    </tr>
                  )}
                  {!isLoading && !error && sortedLogs.length === 0 && (
                    <tr>
                      <td colSpan={5} className="text-center py-8 text-gray-500 italic">
                        No data found
                      </td>
                    </tr>
                  )}
                  {!isLoading && !error && sortedLogs.map((log, index) => (
                    <tr key={log.id} className={`hover:bg-lightBlue/50 cursor-pointer ${index % 2 === 0 ? 'bg-white' : ''}`}>
                      {/* User Name */}
<td className="py-1 px-4 text-left border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[30rem] cursor-pointer"
      ref={(el) => (log.nameRef = el)}
      onMouseEnter={() => {
        if (log.nameRef && log.nameRef.scrollWidth > log.nameRef.clientWidth) {
          setHoveredLogName(log.id);
        }
      }}
      onMouseLeave={() => setHoveredLogName(null)}
    >
      {`${log.firstName} ${log.lastName}`}
    </p>

    {hoveredLogName === log.id && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {`${log.firstName} ${log.lastName}`}
      </span>
    )}
  </div>
</td>

{/* Activity */}
<td className="py-1 px-4 border border-grey2 border-t-0 border-l-0 text-left text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[30rem] cursor-pointer"
      ref={(el) => (log.activityRef = el)}
      onMouseEnter={() => {
        if (log.activityRef && log.activityRef.scrollWidth > log.activityRef.clientWidth) {
          setHoveredActivity(log.id);
        }
      }}
      onMouseLeave={() => setHoveredActivity(null)}
    >
      {log.activity}
    </p>

    {hoveredActivity === log.id && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {log.activity}
      </span>
    )}
  </div>
</td>

{/* Performed By */}
<td className="py-1 px-4 border border-grey2 border-t-0 border-l-0 text-xs text-left">
  <div className="relative">
    <p
      className="truncate max-w-[30rem] cursor-pointer"
      ref={(el) => (log.performedByRef = el)}
      onMouseEnter={() => {
        if (log.performedByRef && log.performedByRef.scrollWidth > log.performedByRef.clientWidth) {
          setHoveredPerformedBy(log.id);
        }
      }}
      onMouseLeave={() => setHoveredPerformedBy(null)}
    >
      {log.performed_by}
    </p>

    {hoveredPerformedBy === log.id && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-0">
        {log.performed_by}
      </span>
    )}
  </div>
</td>

                      <td className="py-1 px-4 border border-grey2 border-t-0 border-l-0 text-xs text-left whitespace-nowrap">
                        {formatedTime(log.createdOn)}
                      </td>
                      <td className="py-1 border border-grey2 border-t-0 border-l-0 border-r-0 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            className="relative group p-1 hover:bg-gray-100 rounded transition"
                            onClick={() => {
                              setSelectedLog({
                                ...log,
      date: log.createdOn || "-", // ✅ Use logDate you already have
                                user: { name: `${log.firstName} ${log.lastName}` },
                                performedBy: log.performed_by,
                                message: log.message || "No message available"
                              });
                              setLogDetailsVisible(true);
                            }}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none">
<path d="M12.3604 4C6.58038 4 2.64438 9.857 4.82438 15.21L5.75738 17.498C5.79812 17.5978 5.80553 17.7081 5.7785 17.8124C5.75147 17.9167 5.69144 18.0095 5.60738 18.077L3.63438 19.66C3.5536 19.7248 3.49494 19.8131 3.4665 19.9127C3.43805 20.0122 3.44123 20.1182 3.47558 20.2159C3.50994 20.3136 3.57378 20.3982 3.6583 20.458C3.74281 20.5179 3.84382 20.55 3.94738 20.55H11.7674C12.9142 20.5504 14.0499 20.3248 15.1096 19.8861C16.1692 19.4475 17.1321 18.8043 17.9431 17.9934C18.7541 17.1825 19.3973 16.2197 19.8361 15.1601C20.2749 14.1005 20.5006 12.9649 20.5004 11.818C20.5004 7.5 17.0004 4 12.6824 4H12.3604Z" fill="#1B365D"/>
</svg>
                            <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              Comment
                            </span>
                          </button>
                          <button
                            className="relative group p-1 hover:bg-gray-100 rounded transition"
                            onClick={() => {
                              setItemToDelete(log);
                              setDeleteModalVisible(true);
                            }}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>
                            <span className="absolute left-1/2 top-full mt-0 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-SteelBlue1 text-white text-[10px] px-2 py-0 transition-opacity duration-200 whitespace-nowrap z-0">
                              Delete
                            </span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
             {showScrollButtons && (
            <div className="fixed bottom-12 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

          </div>
        )}

        {/* Modals */}
        <DeleteModal
          isOpen={deleteModalVisible}
          onClose={() => setDeleteModalVisible(false)}
          onConfirm={handleDelete}
        />
        {logDetailsVisible && (
          <CommentPopup
            log={selectedLog}
            onClose={() => setLogDetailsVisible(false)}
          />
        )}
        <DeleteAllRecords
          isOpen={isDeleteAllOpen}
          onClose={() => setIsDeleteAllOpen(false)}
          onConfirm={handleDeleteAll}
          message="Are you sure you want to delete all records? This action cannot be undone."
        />
      </div>
    </div>
  );
};

export default AuthenticationLog;