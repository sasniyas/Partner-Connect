
import React from "react";
import { formatDateOnly, formatedTime } from "../../../util/timeFormat";

const CommentPopup = ({ log, userName, onClose }) => {
  const displayUserName =
  userName ||                 // from parent if passed
  log?.user?.name ||          // fallback if already inside log
  "-";
    if (!log) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-30 px-2 sm:px-4">
      <div className="bg-white shadow-xl w-full max-w-lg relative my-4 sm:my-0 max-h-[90vh] overflow-y-auto p-3 sm:p-6">

        {/* Sticky Header */}
        <div className="sticky top-0 z-10 bg-white pb-2">
          <div className="relative h-6 sm:h-8">
            <h2 className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 text-sm sm:text-base text-MediumGrey font-medium flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 18 20" fill="none">
<path d="M3.5 5.5C3.5 4.04131 4.07946 2.64236 5.11091 1.61091C6.14236 0.579463 7.54131 0 9 0C10.4587 0 11.8576 0.579463 12.8891 1.61091C13.9205 2.64236 14.5 4.04131 14.5 5.5C14.5 6.95869 13.9205 8.35764 12.8891 9.38909C11.8576 10.4205 10.4587 11 9 11C7.54131 11 6.14236 10.4205 5.11091 9.38909C4.07946 8.35764 3.5 6.95869 3.5 5.5ZM0 17C0 15.6739 0.526784 14.4021 1.46447 13.4645C2.40215 12.5268 3.67392 12 5 12H13C14.3261 12 15.5979 12.5268 16.5355 13.4645C17.4732 14.4021 18 15.6739 18 17V20H0V17Z" fill="#204D80"/>
</svg>
              Log details
            </h2>

            <button
              className="absolute top-0 right-0 w-5 h-5 flex items-center justify-center rounded-full bg-red1 hover:scale-110 transition"
              onClick={onClose}
              aria-label="Close"
            >
              <svg width="12" height="12" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="10" r="10" fill="#BF2012" />
                <path d="M6 6L14 14M14 6L6 14" stroke="white" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        </div>

        {/* Fields Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
  <label className="block text-xs font-medium mb-1">User Name</label>
  <input
value={displayUserName}   
 readOnly
    className="w-full border border-black/60  px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-black/60"
  />
</div>
<div>
            <label className="block text-xs font-medium mb-1">Activity</label>
            <input
              value={log.activity}
              readOnly
              className="w-full border border-black/60  px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-black/60"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Performed By </label>
            <input
              value={log.performedBy}
              readOnly
              className="w-full border border-black/60  px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-black/60"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Log In Date</label>
            <input
              value={formatedTime(log.date)}
              readOnly
              className="w-full border border-black/60  px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-black/60"
            />
          </div>
          
        
        </div>

        {/* Message Field */}
<div>
  <label className="block text-xs font-medium mb-1">Message</label>
  <textarea
    value={log.message || "No message available"}
    rows={4}
    readOnly
    className="w-full border border-black/60  px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-black/60 resize-none"
  />
</div>

      </div>
    </div>
  );
};

export default CommentPopup;
