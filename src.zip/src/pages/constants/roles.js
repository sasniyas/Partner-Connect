// ═══════════════════════════════════════════════════════════════
// DEALER ROLES - Users who can edit/enter data
// ═══════════════════════════════════════════════════════════════
export const DEALER_ROLES = [
  "Dealer Parts Manager",
  "Dealer Finance Head",
  "Dealer Coordinator",
  "Dealer Sales Head",
  "Dealer CST Head",
  "Dealer CEO",
  "Dealer HR Head",
  "Dealer Principal"
];

// ═══════════════════════════════════════════════════════════════
// ADMIN/MANAGER ROLES - Users who can approve/return (read-only for data)
// ═══════════════════════════════════════════════════════════════
export const ADMIN_ROLES = [
  "Administrator",
  "Head Of Channel Developement (Region India)",
  "Uptime & Parts Manager",
  "Market Area Head"
];

// ═══════════════════════════════════════════════════════════════
// STATUSES THAT ALLOW EDITING
// ═══════════════════════════════════════════════════════════════
export const EDITABLE_STATUSES = ["Created", "Started"];

// ═══════════════════════════════════════════════════════════════
// Helper function to check if status allows editing
// ═══════════════════════════════════════════════════════════════
export const isEditableStatus = (status) => {
  if (!status) return false;
  return EDITABLE_STATUSES.some(
    s => s.toLowerCase() === status.toLowerCase()
  );
};

// ═══════════════════════════════════════════════════════════════
// Helper function to check if user can edit data
// Now considers both role AND status
// ═══════════════════════════════════════════════════════════════
export const canEditData = (userRole, pdpStatus = null) => {
  if (!userRole) return false;
  
  // Check if user has a dealer role
  const isDealerRole = DEALER_ROLES.some(
    role => role.toLowerCase() === userRole.toLowerCase()
  );
  
  if (!isDealerRole) return false;
  
  // If status is provided, check if it's an editable status
  if (pdpStatus) {
    return isEditableStatus(pdpStatus);
  }
  
  // If no status provided, default to allowing edit for dealer roles
  return true;
};

// ═══════════════════════════════════════════════════════════════
// Helper function to check if user is admin
// ═══════════════════════════════════════════════════════════════
export const isAdminRole = (userRole) => {
  if (!userRole) return false;
  return ADMIN_ROLES.some(
    role => role.toLowerCase() === userRole.toLowerCase()
  );
};

// ═══════════════════════════════════════════════════════════════
// Helper function to check if user is a dealer
// ═══════════════════════════════════════════════════════════════
export const isDealerRole = (userRole) => {
  if (!userRole) return false;
  return DEALER_ROLES.some(
    role => role.toLowerCase() === userRole.toLowerCase()
  );
};