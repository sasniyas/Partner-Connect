import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Login from "./pages/Login/Login";
import ForgotPassword from "./pages/Forgotpassword/ForgotPassword";
import ResetPassword from "./pages/Resetpassword/ResetPasword";

import Outlook from "./pages/Outlook/Outlook";
import NotificationPage  from "./pages/Notification/NotificationPage";

import UserManagementHome from "./pages/Management/UserMangement/UserManagementHome";
import BulkUploadUsers from "./pages/Management/UserMangement/BulkUploadUsers ";
import UserDetails from "./pages/Management/UserMangement/UserDetails";
// import ShowHistory from "./pages/Management/UserMangement/ShowHistory";
import AuthenticationlogHome from "./pages/Management/AuthenticationLog/AuthenticationlogHome";
import UserLogin from "./pages/Management/UserMangement/UserLogin";

import PDPHomepagemaster from "./pages/Masters/PDP/PDPHomepagemaster";
import MonthlymeetingHomepage from "./pages/Masters/MonthlyMeeting/MontlymeetingHomepage";
import Dealerinvestment from "./pages/Masters/DealerInvestment/Delaerinvestment";
import DashboardHomepage from "./pages/Masters/Dashboard/DashboardHomepage";

import MonthlymeetingHomepageMain from "./pages/MonthlyMeeting/MonthlyMeetingHomePageMain";
import TrendChart from "./pages/MonthlyMeeting/Viewmonthlymeeting/TrendChart";
import ActionItemview from "./pages/MonthlyMeeting/Viewmonthlymeeting/ActionItemview";
import Viewdetails from "./pages/MonthlyMeeting/Viewmonthlymeeting/Viewdetails";

import Home3 from "./pages/HomePage/Home3";
import UserHistoryHome from "./pages/Management/AuthenticationLog/UserHistotyHome";
import SubkpiAdd from "./pages/Masters/Scorecard/Subkpi/SubkpiAdd";
import Subkpiformulae from "./pages/Masters/Developer/Subkpiformulae.js";
import CountryMaster from "./pages/Masters/Scorecard/CountryMaster/CountryMaster";
import StateMaster from "./pages/Masters/Scorecard/StateMaster.js/StateMaster";
import CityMaster from "./pages/Masters/Scorecard/CityMaster/CityMaster";
import Marketarea from "./pages/Masters/Scorecard/MarketArea/Marketarea";
import DealerMaster from "./pages/Masters/Scorecard/Dealeramster/DealerMaster";
import KpiMaster from "./pages/Masters/Scorecard/KpiMaster/KpiMaster";
import Subkpi from "./pages/Masters/Scorecard/Subkpi/Subkpi";
import Updates from "./pages/Masters/Scorecard/Updates/Updates";
import StrategicObjective from "./pages/Masters/Scorecard/Strategicobjective/StrategicObjective";
import ViewMonthlymeetingHome from "./pages/MonthlyMeeting/Viewmonthlymeeting/ViewMonthlymeetingHomepage";
import AddActionitem from "./pages/MonthlyMeeting/Viewmonthlymeeting/AddActionitem";
import Actionitemhome from "./pages/MonthlyMeeting/Actionitem/MonthlymeetingActionitem/Actionitemhome";
// import EditAction from "./pages/MonthlyMeeting/Actionitem/MonthlymeetingActionitem/EditAction";
import PdPActionitemhome from "./pages/MonthlyMeeting/Actionitem/PdpActionitem/PdpActionitemhome";
import Presentationtemplate from "./pages/Masters/PDP/Tables/PDPFillTemplate/Presentationtemplate";
import FinanaceTemplate from "./pages/Masters/PDP/Tables/PDPFillTemplate/FinanceTemplate";

// Master Equipment (keep for master data management)
import MasterEquipment from "./pages/Masters/PDP/Tables/PDPData/Equipment";

// UNIFIED EQUIPMENT COMPONENT - Handles both Admin and User PDP views
import Equipment from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/Equipment";

// Equipment Details Component - Handles ALL equipment types dynamically
import Equipments from "./pages/PDPMAINMODULE/ViewPdp/Hyperlinks/Equipment/Equipments";

import Uptimeandparts from "./pages/Masters/PDP/Tables/PDPData/Uptimeandparts";

// UNIFIED INFRASTRUCTURE COMPONENT - Handles both Admin and User PDP views
import Infrastructure from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/Infrastructure";

// Master Infrastructure (for master data management only)
import MasterInfrastructure from "./pages/Masters/PDP/Tables/PDPData/Infrastructure";

// Infrastructure Vehicles Pages
import InfrastructureVehiclesPage from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/InfrastructureVehiclesPage";
import InfrastructureVehicleForm from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/InfrastructureVehicleForm";

// Infrastructure Tools & Accessories Pages
import InfrastructureToolsPage from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/InfrastructureToolsPage";
import InfrastructureToolForm from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/InfrastructureToolForm";
import InfrastructureAccessoriesPage from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/InfrastructureAccessoriesPage";
import InfrastructureAccessoryForm from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/InfrastructureAccessoryForm";

import Competence from "./pages/Masters/PDP/Tables/PDPData/Competence";
import Marcom from "./pages/Masters/PDP/Tables/PDPData/Marcom";
import KeyAccount from "./pages/Masters/PDP/Tables/PDPData/KeyAccount";
import NationalKeyAccount from "./pages/Masters/PDP/Tables/PDPData/NationalKeyAccount";
import SegmentPriority from "./pages/Masters/PDP/Tables/PDPData/SegmentPriority";
import PDPDataExplorer from "./pages/Masters/PDP/Tables/Explorer/PDPDataExplorer";
import PDPFillTemplatesExplorer from "./pages/Masters/PDP/Tables/Explorer/PDPFillTemplatesExplorer";
import Xaxismonth from "./pages/Masters/PDP/Tables/Trendcharts/Xaxismonth";
import RoleMaster from "./pages/Masters/Scorecard/Role Master/RoleMaster";
import Dfhmhome from "./pages/Masters/DFHM/Dfhmhome";
import DfhmMasterData from "./pages/Masters/DFHM/Dfhmhome";
import PDPViewdetails from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/PDPViewdetails";
import MADownload from "./pages/Masters/Scorecard/MarketArea/MADownload";
import CountryMasterDownload from "./pages/Masters/Scorecard/CountryMaster/CountryMasterDownload";
import StateMasterDownload from "./pages/Masters/Scorecard/StateMaster.js/StateMasterDownload";
import CityMasterDownload from "./pages/Masters/Scorecard/CityMaster/CityMasterDownload";
import RoleMasterDownload from "./pages/Masters/Scorecard/Role Master/RoleMasterDownload";
import StrategicObjDownload from "./pages/Masters/Scorecard/Strategicobjective/StrategicObjDownload";
import KpimasterDownload from "./pages/Masters/Scorecard/KpiMaster/KpiMasterDownload";
import SubkpiDownload from "./pages/Masters/Scorecard/Subkpi/SubkpiDownload";
import PresentationDownload from "./pages/Masters/PDP/Tables/DownloadFiles/PresentaionDownload";
import FinanceDownload from "./pages/Masters/PDP/Tables/DownloadFiles/FinanceDownload";
import Equipmentdownload from "./pages/Masters/PDP/Tables/DownloadFiles/Equipmentdownload";
import UptimeDownload from "./pages/Masters/PDP/Tables/DownloadFiles/UptimeDownload";
import InfrastructureDownload from "./pages/Masters/PDP/Tables/DownloadFiles/Infrastructuredownload";
import CompetenceDownload from "./pages/Masters/PDP/Tables/DownloadFiles/CompetenceDownload";
import MarcomDownload from "./pages/Masters/PDP/Tables/DownloadFiles/MarcomDownload";
import NationalKeyDownload from "./pages/Masters/PDP/Tables/DownloadFiles/NationalKeyDownload";
import SegmentDownload from "./pages/Masters/PDP/Tables/DownloadFiles/SegmentDownload";
import Download from "./pages/Masters/MonthlyMeeting/Downloadfilemaster";
import DepartmentMasterDownload from "./pages/Masters/MonthlyMeeting/DepartmentMasterDownload";
import BranchMaster from "./pages/Masters/PDP/Tables/PDPData/BranchMaster";
import BranchMasterDownload from "./pages/Masters/PDP/Tables/DownloadFiles/BranchMasterDownload";
import OthersData from "./pages/Masters/PDP/Tables/PDPData/OthersData";
import OthersDataDownload from "./pages/Masters/PDP/Tables/DownloadFiles/OthersDataDownload";
import FinancialtabDownload from "./pages/Masters/DealerInvestment/FinancialtabDownload";
import EquipmenttabDownload from "./pages/Masters/DealerInvestment/EquipmenttabDownload";
import PLDownload from "./pages/Masters/DFHM/PLDownload";
import BalanceSheetDownload from "./pages/Masters/DFHM/BalanceSheetDownload";
import HeadCountDownload from "./pages/Masters/DFHM/HeadCountDownload";
import RationAnalysisDownload from "./pages/Masters/DFHM/RationAnalysisDownload";
import DealerMasterDownload from "./pages/Masters/Scorecard/Dealeramster/DealerMasterDownload";
import NotFound, { ErrorBoundary } from "./pages/NotFound/NotFound";
import CreatePassword from "./pages/CreatePassword/CreatePassword";
import ViewPdp from "./pages/PDPMAINMODULE/ViewPdp/ViewPdp";
import Downloadfilemaster from "./pages/Masters/MonthlyMeeting/Downloadfilemaster";
import PdpOutlook from "./pages/PDPMAINMODULE/pdpOutlook";
import CreatePdp from "./pages/PDPMAINMODULE/CreateNewPDP/CreatePdp";
import ViewMonthlymeetingHomepage from "./pages/MonthlyMeeting/Viewmonthlymeeting/ViewMonthlymeetingHomepage";
import Downloadpdpddeatils from "./pages/PDPMAINMODULE/ViewPdp/Downloadpdpdeatils";
import EditActionitem from "./pages/MonthlyMeeting/Viewmonthlymeeting/EditActionitem";
import UptimeParts from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/Uptimeparts";
import Createpdphome from "./pages/PDPMAINMODULE/CreateNewPDP/Createpdphome";
import SubkpiHome from "./pages/Masters/Scorecard/Subkpi/SubkpiHome";

import DownloadPDPdetails from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/DownloadPDPdetails";
import ActionPlannerManagemnet from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/ActionPlanner/ActionPlannerManagemnet";
import AddAction from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/ActionPlanner/AddAction";
import EditActionForm from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/ActionPlanner/EditActionForm";

import OthersDownload from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/Downloads/OthersDownload";
import Marcomdownload from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/Downloads/Marcomdownload";
import EquipmentDownload from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/Downloads/EquipmentDownload";
import UptimepartsDownload from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/Downloads/UptimepartsDownload";
import Infrastructuredownload from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/Downloads/Infrastructuredownload";
import TerritoryDownload from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/Downloads/TerritoryDownload";
import CompetenceDevelopment from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/CompetencDevelopment";
import CompetenceDvlpDownload from "./pages/PDPMAINMODULE/ViewPdp/ViewDetails/Downloads/CompetenceDvlpDownload";

import UptimepartsRetail from "./pages/PDPMAINMODULE/ViewPdp/Hyperlinks/Uptimeparts/Retail/UptimepartsRetail";
import PDPBranchMaster from "./pages/PDPMAINMODULE/BranchMaster/PDPBranchMaster";
import PDPBranchMasterDownload from "./pages/PDPMAINMODULE/BranchMaster/PDPBranchMasterDownload";
import PDPActionItems from "./pages/PDPMAINMODULE/PDPActionPlanner/PDPActionItems";
import ActionPlannerhome from "./pages/PDPMAINMODULE/PDPActionPlanner/ActionPlannerhome";
import EditActionplanner from "./pages/PDPMAINMODULE/PDPActionPlanner/EditActionplanner";
import PDPTrendChart from "./pages/PDPMAINMODULE/PDPActionPlanner/PDPTrendChart";

// Dealer Investment Components
import Dealerhome from "./pages/DEALERINVESTMENT/ViewDealerInvestment/ViewDealerhome";
import ViewDealerInvestment from "./pages/DEALERINVESTMENT/ViewDealerInvestment/view";
import FillEntries from "./pages/DEALERINVESTMENT/ViewDealerInvestment/FillEntries";
import VehiclesList from "./pages/DEALERINVESTMENT/ViewDealerInvestment/VehiclesList";
import AddVehicle from "./pages/DEALERINVESTMENT/ViewDealerInvestment/AddVehicle";
import FillEntriesEqup from "./pages/DEALERINVESTMENT/ViewDealerInvestment/FillEntriesEqup";
import Allocationhome from "./pages/DEALERINVESTMENT/Allocation/Allocationhome";
import InfrastructureReportsHome from "./pages/DEALERINVESTMENT/InfrastructureReports/InfrastructureReportsHome";
import ViewInventory from "./pages/DEALERINVESTMENT/Allocation/Inventory/ViewInventory";

// Scorecard Component
import Createscorecard from "./pages/Scorecard/CreateScorecard/Createscorecard";
import ViewreviewHome from "./pages/Scorecard/ViewReview/ViewreviewHome";
import ViewAudit from "./pages/Scorecard/ViewReview/ViewAudit";
import ScoreAudit from "./pages/Scorecard/ViewReview/ScoreAudit";
import Scoring from "./pages/Scorecard/Scoring/Scoring";
import Createscorecardhome from "./pages/Scorecard/CreateScorecard/Createscorecardhome";
import Actionitemshome from "./pages/Scorecard/ActionItems/Actionitemshome";
import Actionitems from "./pages/Scorecard/ActionItems/Actionitems";
import EditActionItem from "./pages/Scorecard/ActionItems/Editactionitem";
import ScorecardResults from "./pages/Scorecard/Results/Scorecardresults";
import UserView from "./pages/Scorecard/ViewReview/UserView";
import Userviewdeatils from "./pages/Scorecard/ViewReview/Userviewdetails";
import ScorecardAnnualView from "./pages/Scorecard/ViewReview/ScorecardAnnualView";

// DFHM Components
import CreateDfhmhome from "./pages/DFHM/CreateDFHM/CreateDfhmhome";
import ViewDfhm from "./pages/DFHM/ViewDFHM/ViewDfhm";
// import ViewDfhmDetails from "./pages/DFHM/ViewDFHM/ViewDfhmDetails";
import Profit from "./pages/DFHM/ViewDFHM/FillEntries/Profit";
import FillEntryBalanceSheet from "./pages/DFHM/ViewDFHM/FillEntries/FillEntryBalanceSheet";
import FillEntryHeadCount from "./pages/DFHM/ViewDFHM/FillEntries/FillEntryHeadCount";
import ArAging from "./pages/DFHM/ViewDFHM/FillEntries/ArAging";
import DFRatio from "./pages/DFHM/DealerFinanacialRatio/DFRatio";
// import DFViewdetails from "./pages/DFHM/DealerFinanacialRatio/DFViewdetails";
import DFViewdetailsprofit from "./pages/DFHM/DealerFinanacialRatio/DFViewdetailsprofit";
import DFBalanceSheet from "./pages/DFHM/DealerFinanacialRatio/DFBalanceSheet";
import DFHeadCount from "./pages/DFHM/DealerFinanacialRatio/DFHeadCount";
import DFArAging from "./pages/DFHM/DealerFinanacialRatio/DFArAging";
import DFRatioChart from "./pages/DFHM/DealerFinanacialRatio/DFRatioChart";

import Specialization from "./pages/Masters/CompetenceManagement/Specialization/Specialization.js";
import CompetenceLevel from "./pages/Masters/CompetenceManagement/CompetenceLevel/CompetenceLevel.js";
 import CompetenceLevelBulkUpload from "./pages/Masters/CompetenceManagement/CompetenceLevel/CompetenceLevelBulkUpload.js";
import SpecializationBulkUpload from "./pages/Masters/CompetenceManagement/Specialization/SpecializationBulkUpload.js";



//Bulk Upload
import MABulkUpload from "./pages/Masters/Scorecard/MarketArea/MABulkUpload";
import BulkUploadPreview from "./pages/Masters/Scorecard/CountryMaster/BulkUploadPreview";
import BulkUploadSM from "./pages/Masters/Scorecard/StateMaster.js/BulkUploadSM";
import BulkUploadCityMaster from "./pages/Masters/Scorecard/CityMaster/BulkUploadCityMaster";
import BulkUploadDealerMaster from "./pages/Masters/Scorecard/Dealeramster/BulkUploadDealerMaster";
import RoleMasterBulkPreview from "./pages/Masters/Scorecard/Role Master/RoleMasterBulkPreview";
import StrategicObjectiveBulkUpload from "./pages/Masters/Scorecard/Strategicobjective/StrategicObjectiveBulkUpload";
import KpiMasterBulkPreview from "./pages/Masters/Scorecard/KpiMaster/KpiMasterBulkPreview";
import SubKpiBulkPreview from "./pages/Masters/Scorecard/Subkpi/SubKpiBulkPreview";
import BulkUploadPresentationTemplate from "./pages/Masters/PDP/Tables/PDPFillTemplate/BulkUploadPresentationTemplate";
import FinanceTemplateBulkPreview from "./pages/Masters/PDP/Tables/PDPFillTemplate/FinanceTemplateBulkPreview";
import BulkUploadEquipment from "./pages/Masters/PDP/Tables/PDPData/BulkUploadEquipment";
import BulkUploadPartsCategory from "./pages/Masters/PDP/Tables/PDPData/BulkUploadPartsCategory";
import BulkUploadInfrastructure from "./pages/Masters/PDP/Tables/PDPData/BulkUploadInfrastructure";
import MarcomBulkPreview from "./pages/Masters/PDP/Tables/PDPData/MarcomBulkPreview";
import MarcomMarketingBulkPreview from "./pages/Masters/PDP/Tables/PDPData/MarcomMarketingBulkPreview";
import NationalKeyAccountBulkPreview from "./pages/Masters/PDP/Tables/PDPData/NationalKeyAccountBulkPreview";
import SegmentPriorityBulkPreview from "./pages/Masters/PDP/Tables/PDPData/SegmentPriorityBulkPreview";
import BranchMasterBulkPreview from "./pages/Masters/PDP/Tables/PDPData/BranchMasterBulkPreview";
import BulkUploadOthers from "./pages/Masters/PDP/Tables/PDPData/BulkUploadOthers";
import BulkUploadPNL from "./pages/Masters/DFHM/BulkUploadPNL";
import BulkUploadBalancesheet from "./pages/Masters/DFHM/BulkUploadBalancesheet";
import HeadCountBulkPreview from "./pages/Masters/DFHM/HeadCountBulkPreview";
import RatioAnalysisBulkPreview from "./pages/Masters/DFHM/RatioAnalysisBulkPreview";
import BulkUploadCompetence from "./pages/Masters/PDP/Tables/PDPData/BulkUploadCompetence";

//Contact Magement 

import ContactManagementHome from "./pages/ContactManagement/ContactMangementHome";
import DealerAddUser from "./pages/ContactManagement/DealerUser/DealerAddUser";
import EditDealerUser from "./pages/ContactManagement/DealerUser/EditDealerUser";
import AddVolvoUser from "./pages/ContactManagement/VolvoUser/AddVolvoUser";
import DealerUserDownload from "./pages/ContactManagement/DealerUser/DealerUserDownload";
import EditVolvoUser from "./pages/ContactManagement/VolvoUser/EditVolvoUser";
import VolvoUserDownload from "./pages/ContactManagement/VolvoUser/VolvoUserDownload";
import DealerUserBulkUpload from "./pages/ContactManagement/DealerUser/DealerUserBulkUpload";
import AddDealerAdress from "./pages/ContactManagement/DealerAdressBook/AddDealerAdress";
import EditDealerAddress from "./pages/ContactManagement/DealerAdressBook/EditDealerAddress";
import DealerAddressBookDownload from "./pages/ContactManagement/DealerAdressBook/DealerAddressBookDownload";

//Process Mangement 
import ProcessmangementHoeme from "./pages/ProcessManagemnet.js/ProcessmanagementHome";
import AddTemplate from "./pages/ProcessManagemnet.js/Templates/AddTemplate";
import DownloadTemplate from "./pages/ProcessManagemnet.js/Templates/Downlaodtemplate";
import TemplateBulkPreview from "./pages/ProcessManagemnet.js/Templates/TemplateBulkPreview";
import ProcessDownlaod from "./pages/ProcessManagemnet.js/Templates/Process/ProcessDownlaod";
import PreocessBulkPreview from "./pages/ProcessManagemnet.js/Templates/Process/ProcessBulkPreview";
import SchemDownload from "./pages/ProcessManagemnet.js/Schems/SchemDownlod";
import Schembulkpreview from "./pages/ProcessManagemnet.js/Schems/Schembulkpreview";
import VolvoUserBulkUpload from "./pages/ContactManagement/VolvoUser/VolvoUserBulkUpload";

// import Designation from "./pages/Masters/Scorecard/Designation/Designation";
import Deptmaster from "./pages/Masters/Others/DeptMaster/DeptMaster";
import Designation from "./pages/Masters/Others/Designation/Designation";
import DesignationMasterBulkPreview from "./pages/Masters/Others/Designation/DesignationMasterBulkPreview";
import DesignationMasterDownload from "./pages/Masters/Others/Designation/DesignationMasterDownload";
import DepartmentMasterBulkPreview from "./pages/Masters/Others/DeptMaster/DepartmentMasterBulkPreview";
import DeptDownload from "./pages/Masters/Others/DeptMaster/DeptDownload";

import Unauthorized from "./pages/Authorization/Unauthorized.js";
import AddNewCollection from "./pages/ProcessManagemnet.js/DataCollection/AddNewCollection.js";
import CollectionView from "./pages/ProcessManagemnet.js/DataCollection/Collectionview.js";
import DownloadCollections from "./pages/ProcessManagemnet.js/DataCollection/DownloadCollections.js";
import DownloadCollectionView from "./pages/ProcessManagemnet.js/DataCollection/DownloadCollectionView.js";
import Rationanalysis from "./pages/DFHM/DealerFinanacialRatio/Ratioanalysis";
import DFHealthIndex from "./pages/DFHM/DealerFinanacialRatio/DFHealthIndex.js";
import DFHMDashboard from "./pages/DFHM/DealerFinanacialRatio/DFHMDashboard.js";
import Support from "./pages/Support/Support.js";
import EditTicket from "./pages/Support/EditTicket.js";
import ViewTicket from "./pages/Support/ViewTicket.js";
import AllTickets from "./pages/Support/AllTickets.js"
import TicketTrendChart from "./pages/Support/Tickettrendchart.js";


function App() {

  return (
    <Router>
      <ErrorBoundary>
      <Routes>
        {/* ============================================================================================================ */}
        {/* AUTH & GENERAL ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/" element={<Login />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/resetpassword" element={<ResetPassword />} />
        <Route path="/useractivation" element={<CreatePassword />} />

        <Route path="/outlook" element={<Outlook />} />
        <Route path="/homepage" element={<Home3 />} />
        {/* un authrization */}
        <Route path="/unautharization" element={<Unauthorized />} />
        <Route path="/notifications" element={<NotificationPage  />} />
        {/* ============================================================================================================ */}
        {/* USER MANAGEMENT ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/usermangement" element={<UserManagementHome />} />
        <Route path="/userlogin" element={<UserLogin />} />
        <Route path="/userdetails" element={<UserDetails />} />
        {/* <Route path="/showhistory" element={<ShowHistory />} /> */}
        <Route path="/authentication" element={<AuthenticationlogHome />} />
        <Route path="/userhistory" element={<UserHistoryHome />} />

        <Route path="/bulkupload/usermanagement" element={<BulkUploadUsers />} />

        {/* ============================================================================================================ */}
        {/* SCORECARD MASTER ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/subkpiformulae" element={<Subkpiformulae />} />
        <Route path="/masters/scorecard" element={<Marketarea />} />
        <Route path="/masters/madownload" element={<MADownload />} />
        <Route path="/marketarea/bulkupload" element={<MABulkUpload />} />

        <Route path="/masters/countrymaster" element={<CountryMaster />} />
        <Route path="/masters/countrymaster/download" element={<CountryMasterDownload />} />
        <Route path="/bulk-upload" element={<BulkUploadPreview />} />


        <Route path="/masters/statemaster" element={<StateMaster />} />
        <Route path="/masters/statemaster/download" element={<StateMasterDownload />} />
        <Route path="/masters/statemaster/bulkupload" element={<BulkUploadSM />} />

        <Route path="/masters/citymaster" element={<CityMaster />} />
        <Route path="/masters/citymaster/download" element={<CityMasterDownload />} />
        <Route path="/bulkupload/citymaster" element={<BulkUploadCityMaster />} />

        <Route path="/masters/dealermaster" element={<DealerMaster />} />
        <Route path="/masters/dealermaster/download" element={<DealerMasterDownload />} />
        <Route path="/bulkupload/dealermaster" element={<BulkUploadDealerMaster />} />


        <Route path="/masters/strategicobjective" element={<StrategicObjective />} />
        <Route path="/masters/strategicobjective/download" element={<StrategicObjDownload />} />
        <Route path="/strategicobjective/bulkupload" element={<StrategicObjectiveBulkUpload />} />

        <Route path="/masters/kpimaster" element={<KpiMaster />} />
        <Route path="/masters/kpimaster/download" element={<KpimasterDownload />} />
        <Route path="/bulkupload/kpimaster" element={<KpiMasterBulkPreview />} />

        <Route path="/masters/subkpimaster" element={<Subkpi />} />
        <Route path="/masters/subkpimaster/download" element={<SubkpiDownload />} />
        <Route path="/subkpi/bulkuplaod" element={<SubKpiBulkPreview />} />

        <Route path="/masters/updates" element={<Updates />} />
        <Route path="/masters/roles" element={<RoleMaster />} />
        <Route path="/masters/roles/download" element={<RoleMasterDownload />} />
        <Route path="/bulkupload/rolemaster" element={<RoleMasterBulkPreview />} />

        <Route path="/subkpiadd" element={<SubkpiHome />} />

        {/* ============================================================================================================ */}
        {/* PDP MASTER ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/masterpdphomepage" element={<PDPHomepagemaster />} />
        <Route path="/master/pdp/presentationtemplate" element={<Presentationtemplate />} />
        <Route path="/master/pdp/presentationtemplate/download" element={<PresentationDownload />} />
        <Route path="/bulkupload/presentaiontemplate" element={<BulkUploadPresentationTemplate />} />

        <Route path="/master/pdp/financetemplate" element={<FinanaceTemplate />} />
        <Route path="/master/pdp/financetemplate/download" element={<FinanceDownload />} />
        <Route path="/bulkupload/financetemplate" element={<FinanceTemplateBulkPreview />} />

        {/* Master Equipment - For Master Data Management */}
        <Route path="/master/pdp/equipment" element={<MasterEquipment />} />
        <Route path="/master/pdp/equipment/download" element={<Equipmentdownload />} />
        <Route path="/bulkupload/equipment" element={<BulkUploadEquipment />} />

        <Route path="/master/pdp/uptimeparts" element={<Uptimeandparts />} />
        <Route path="/master/pdp/uptimeparts/download" element={<UptimeDownload />} />
        <Route path="/bulkupload/uptimeparts" element={<BulkUploadPartsCategory />} />

        {/* Master Infrastructure - For Master Data Management */}
        <Route path="/master/pdp/infrastructure" element={<MasterInfrastructure />} />
        <Route path="/master/pdp/infrastructure/download" element={<InfrastructureDownload />} />
        <Route path="/bulkupload/infrastructure" element={<BulkUploadInfrastructure />} />

        <Route path="/master/pdp/competence" element={<Competence />} />
        <Route path="/master/pdp/competence/download" element={<CompetenceDownload />} />
        <Route path="/bulkupload/competence" element={<BulkUploadCompetence />} />

        <Route path="/master/pdp/marcom" element={<Marcom />} />
        <Route path="/master/pdp/marcom/download" element={<MarcomDownload />} />
        <Route path="/bulkupload/marcom" element={<MarcomBulkPreview />} />
        <Route path="/bulkupload/marcom/marketing" element={<MarcomMarketingBulkPreview />} />

        <Route path="/master/pdp/keyaccount" element={<KeyAccount />} />
        <Route path="/master/pdp/nationalkeyaccount" element={<NationalKeyAccount />} />
        <Route path="/master/pdp/nationalkeyaccount/dowmload" element={<NationalKeyDownload />} />
        <Route path="/master/pdp/nationalkeyaccount/preview" element={<NationalKeyAccountBulkPreview />} />

        <Route path="/master/pdp/segmnetpriority" element={<SegmentPriority />} />
        <Route path="/master/pdp/segmnetpriority/download" element={<SegmentDownload />} />
        <Route path="/bulkupload/segment-priority" element={<SegmentPriorityBulkPreview />} />


        <Route path="/master/pdp/branchmaster" element={<BranchMaster />} />
        <Route path="/master/pdp/branchmaster/download" element={<BranchMasterDownload />} />
        <Route path="/bulkupload/branch-master" element={<BranchMasterBulkPreview />} />


        <Route path="/master/pdp/othersdata" element={<OthersData />} />
        <Route path="/master/pdp/othersdata/download" element={<OthersDataDownload />} />
        <Route path="/bulkupload/other-data" element={<BulkUploadOthers />} />

        <Route path="/master/pdp/trendchart" element={<Xaxismonth />} />

        {/* ============================================================================================================ */}
        {/* MONTHLY MEETING MASTER ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/mastermothlymeeting" element={<MonthlymeetingHomepage />} />
        <Route path="/mastermothlymeeting/download" element={<Downloadfilemaster />} />
        <Route path="/Deapartment" element={<MonthlymeetingHomepage />} />
        <Route path="/Deapartment/DepartmentMasterDownload" element={<DepartmentMasterDownload />} />

        {/* ============================================================================================================ */}
        {/* DEALER INVESTMENT MASTER ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/masterdealerinvestment" element={<Dealerinvestment />} />
        <Route path="/masterdealerinvestment/finanacialdownload" element={<FinancialtabDownload />} />
        <Route path="/masterdealerinvestment/equipmentdownoad" element={<EquipmenttabDownload />} />


        {/* ============================================================================================================ */}
        {/* COMPETENCE MANAGEMENT*/}
        {/* ============================================================================================================ */}
        <Route path="/competencemanagement" element={<Specialization />} />
        <Route path="/competencelevel" element={<CompetenceLevel />} />
        <Route path="/competencebulkupload" element={<CompetenceLevelBulkUpload />} />
        <Route path="//specializationbulkupload" element={< SpecializationBulkUpload/>} />
        

        {/* ============================================================================================================ */}
        {/* DASHBOARD & DFHM MASTER ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/masterdashboard" element={<DashboardHomepage />} />
        <Route path="/masterdfhm" element={< DfhmMasterData />} />
        <Route path="/bulkupload/pnl" element={< BulkUploadPNL />} />
        <Route path="/bulkupload/balancesheet" element={< BulkUploadBalancesheet />} />
        <Route path="/bulkupload/headcount" element={< HeadCountBulkPreview />} />
        <Route path="/bulkupload/ratioanalysis" element={< RatioAnalysisBulkPreview />} />

        <Route path="/masterdfhm/pl" element={<PLDownload />} />
        <Route path="/masterdfhm/balancesheetdownload" element={<BalanceSheetDownload />} />
        <Route path="/masterdfhm/headcountdownlaod" element={<HeadCountDownload />} />
        <Route path="/masterdfhm/ratioanalysisdownalod" element={<RationAnalysisDownload />} />

        {/* ============================================================================================================ */}
        {/*Conteact Mangement Master Other */}
        {/* ============================================================================================================ */}
        <Route path="/others" element={<Deptmaster />} />
        <Route path="/bulkupload/department" element={<DepartmentMasterBulkPreview />} />
        <Route path="/deptdownload" element={<DeptDownload />} />

        <Route path="/others/designation" element={<Designation />} />
        <Route path="/bulkupload/designation" element={<DesignationMasterBulkPreview />} />
        <Route path="/masters/designations/download" element={<DesignationMasterDownload />} />
        {/* ============================================================================================================ */}
        {/* MONTHLY MEETING MODULE ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/monthlymeetinghomepage" element={<MonthlymeetingHomepageMain />} />
        <Route path="/viewmonthlymeeting" element={<ViewMonthlymeetingHomepage />} />
        <Route path="/addactionitem" element={<AddActionitem />} />
        <Route path="/editactionitem" element={<EditActionitem />} />

        <Route path="/trendchart" element={<TrendChart />} />
        <Route path="/actionitemview" element={<ActionItemview />} />
        <Route path="/monthlymeetingviewdetails" element={<Viewdetails />} />
        <Route path="/actionitemhomepage" element={<Actionitemhome />} />
        {/* <Route path="/editmonthlymeetingactionitem" element={<EditAction />} /> */}
        <Route path="/pdpactionitemhome" element={<PdPActionitemhome />} />

        {/* ============================================================================================================ */}
        {/* ADMIN PDP MODULE ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/pdp/outlook" element={<PdpOutlook />} />
        <Route path="/pdp/create" element={<Createpdphome />} />
        <Route path="/pdp/view" element={<ViewPdp />} />

        {/* Main PDP View Details - Uses Unified Infrastructure Component */}
        <Route path="/pdp/viewdetails" element={<PDPViewdetails />} />
        <Route path="/pdp/view/download" element={<Downloadpdpddeatils />} />

        {/* ========== ADMIN ACTION PLANNER ROUTES ========== */}
        <Route path="/pdp/view/actionplannermanagemnet" element={<ActionPlannerManagemnet />} />
        <Route path="/pdp/view/actionplannermanagemnet/add" element={<AddAction />} />
        <Route path="/pdp/view/actionplannermanagemnet/edit" element={<EditActionForm />} />

        {/* ========== ADMIN UPTIME PARTS ROUTES ========== */}
        <Route path="/pdp/viewdetails/uptimeparts" element={<UptimeParts />} />
        <Route path="/pdp/view/retail/uptimeparts" element={<UptimepartsRetail />} />
        <Route path="/pdp/view/keyaccount/uptimeparts" element={<UptimepartsRetail />} />
        <Route path="/pdp/viewdetails/uptimepartsdownload" element={<UptimepartsDownload />} />

        {/* ========== ADMIN EQUIPMENT ROUTES ========== */}
        {/* NEW GENERIC EQUIPMENT DETAILS ROUTE - Works for ALL Equipment Types */}
        <Route path="/pdp/view/equipment/details" element={<Equipments />} />

        {/* ADMIN Legacy Equipment Routes - Keep for backward compatibility */}
        <Route path="/pdp/view/retail/equipmets" element={<Equipments />} />



        {/* ========== ADMIN INFRASTRUCTURE VEHICLE ROUTES ========== */}
        <Route path="/pdp/viewdetails/infrastructure/vehicles" element={<InfrastructureVehiclesPage />} />
        <Route path="/pdp/viewdetails/infrastructure/vehicles/add" element={<InfrastructureVehicleForm />} />
        <Route path="/pdp/viewdetails/infrastructure/vehicles/edit/:id" element={<InfrastructureVehicleForm />} />

        {/* ========== ADMIN INFRASTRUCTURE TOOLS ROUTES ========== */}
        <Route path="/pdp/viewdetails/infrastructure/tools" element={<InfrastructureToolsPage />} />
        <Route path="/pdp/viewdetails/infrastructure/tools/add" element={<InfrastructureToolForm />} />
        <Route path="/pdp/viewdetails/infrastructure/tools/edit/:id" element={<InfrastructureToolForm />} />

        {/* ========== ADMIN INFRASTRUCTURE ACCESSORIES ROUTES ========== */}
        <Route path="/pdp/viewdetails/infrastructure/accessories" element={<InfrastructureAccessoriesPage />} />
        <Route path="/pdp/viewdetails/infrastructure/accessories/add" element={<InfrastructureAccessoryForm />} />
        <Route path="/pdp/viewdetails/infrastructure/accessories/edit/:id" element={<InfrastructureAccessoryForm />} />

        {/* ========== USER INFRASTRUCTURE TOOLS ROUTES ========== */}
        <Route path="/user/pdp/viewdetails/infrastructure/tools" element={<InfrastructureToolsPage />} />
        <Route path="/user/pdp/viewdetails/infrastructure/tools/add" element={<InfrastructureToolForm />} />
        <Route path="/user/pdp/viewdetails/infrastructure/tools/edit/:id" element={<InfrastructureToolForm />} />

        {/* ========== USER INFRASTRUCTURE ACCESSORIES ROUTES ========== */}
        <Route path="/user/pdp/viewdetails/infrastructure/accessories" element={<InfrastructureAccessoriesPage />} />
        <Route path="/user/pdp/viewdetails/infrastructure/accessories/add" element={<InfrastructureAccessoryForm />} />
        <Route path="/user/pdp/viewdetails/infrastructure/accessories/edit/:id" element={<InfrastructureAccessoryForm />} />

        {/* ========== ADMIN DOWNLOAD ROUTES ========== */}
        <Route path="/pdp/viewdetails/downloadpdpdetails" element={<DownloadPDPdetails />} />
        <Route path="/pdp/viewdetails/othersdowmloadpreview" element={<OthersDownload />} />
        <Route path="/pdp/viewdetails/marcomdownloadpreview" element={<Marcomdownload />} />
        <Route path="/pdp/viewdetails/equipmentdownload" element={<EquipmentDownload />} />
        <Route path="/pdp/viewdetails/infrastructuredownload" element={<Infrastructuredownload />} />
        <Route path="/pdp/viewdetails/territoryfocusdownload" element={<TerritoryDownload />} />
        <Route path="/pdp/viewdetails/competencedevelopmentdownload" element={<CompetenceDvlpDownload />} />

        {/* ========== ADMIN BRANCH MASTER ROUTES ========== */}
        <Route path="/pdp/branchmaster" element={<PDPBranchMaster />} />
        <Route path="/pdp/branchmaster/download" element={<PDPBranchMasterDownload />} />

        {/* ========== ADMIN PDP ACTION PLANNER ROUTES ========== */}
        <Route path="/pdp/PDPActionPlanner" element={<ActionPlannerhome />} />
        <Route path="/pdp/PDPActionPlanner/PDPActionItems" element={<PDPActionItems />} />
        <Route path="/pdp/PDPActionPlanner/editactionplanner" element={<EditActionplanner />} />
        <Route path="/pdp/PDPActionPlanner/PDPTrendChart" element={<PDPTrendChart />} />



        {/* ============================================================================================================ */}
        {/* DEALER INVESTMENT MODULE ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/DEALERINVESTMENT/ViewDealerInvestment/ViewDealerhome" element={<Dealerhome />} />
        <Route path="/DEALERINVESTMENT/ViewDealerInvestment/FillEntries" element={<FillEntries />} />
        <Route path="/DEALERINVESTMENT/ViewDealerInvestment/VehiclesList" element={<VehiclesList />} />
        <Route path="/DEALERINVESTMENT/ViewDealerInvestment/AddVehicle" element={<AddVehicle />} />
        <Route path="/DEALERINVESTMENT/ViewDealerInvestment/EditVehicle/:id" element={<AddVehicle />} />
        <Route path="/DEALERINVESTMENT/ViewDealerInvestment/FillEntriesEquipment" element={<FillEntriesEqup />} />

        <Route path="/DEALERINVESTMENT/Allocation/Allocationhome" element={<Allocationhome />} />
        <Route path="/viewinventory" element={<ViewInventory />} />

        <Route
          path="/DEALERINVESTMENT/InfrastructureReports/InfrastructureReportsHome"
          element={<InfrastructureReportsHome />}
        />

        {/* ============================================================================================================ */}
        {/* SCORECARD MODULE ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/scorecard/createscorecard" element={<Createscorecardhome />} />
        <Route path="/scorecard/viewreview" element={<ViewreviewHome />} />
        <Route path="/scorecard/viewaudit" element={<ViewAudit />} />
        <Route path="/scorecard/scoreaudit" element={<ScoreAudit />} />
        <Route path="/scorecard/scoring" element={<Scoring />} />
        <Route path="/scorecard/Actionitems" element={<Actionitemshome />} />
        <Route path="/scorecard/Editactionitem" element={<EditActionItem />} />
        <Route path="/scorecard/results" element={<ScorecardResults />} />
        <Route path="/scorecard/viewreview/userview" element={<UserView />} />
        <Route path="/scorecard/userview/view" element={<Userviewdeatils />} />
        <Route path="/scorecard/annualview" element={<ScorecardAnnualView />} />

        {/* ============================================================================================================ */}
        {/* DFHM MODULE ROUTES */}
        {/* ============================================================================================================ */}
        <Route path="/dfhm/createdfhm" element={<CreateDfhmhome />} />
        <Route path="/dfhm/viewdfhm" element={<ViewDfhm />} />
        <Route path="/dfhm/viewdfhm/fillentries" element={<Profit />} />
        <Route path="/dfhm/viewdfhm/fillentries/balance" element={<FillEntryBalanceSheet />} />
        <Route path="/dfhm/viewdfhm/fillentries/headcount" element={<FillEntryHeadCount />} />
        <Route path="/dfhm/viewdfhm/fillentries/Araging" element={<ArAging />} />
        <Route path="/dfhm/dealerfinacialratio" element={<DFRatio />} />
        <Route path="/dfhm/dealerfinacialratio/viewdetails" element={<DFViewdetailsprofit />} />
        <Route path="/dfhm/dealerfinacialratio/dfbalancesheet" element={<DFBalanceSheet />} />
        <Route path="/dfhm/dealerfinacialratio/dfheadcount" element={<DFHeadCount />} />
        <Route path="/dfhm/dealerfinacialratio/dfaraging" element={<DFArAging />} />
        <Route path="/dfhm/dealerfinacialratio/rationanalysis" element={<Rationanalysis />} />
        <Route path="/dfhm/dealerfinacialratio/ratiochart" element={<DFRatioChart />} />
        <Route path="/dfhm/dealerfinacialratio/healthindex" element={<DFHealthIndex />} />
        <Route path="/dfhm/dashboard" element={<DFHMDashboard />} />

        {/* ==========Contact-Mangemnet ========== */}
        <Route path="/contactmanagemnet" element={<ContactManagementHome />} />
        <Route path="/contactmanagemnet/adduser" element={<DealerAddUser />} />
        <Route path="/contactmanagemnet/edituser" element={<EditDealerUser />} />
        <Route path="/contactmanagemnet/addvolvouser" element={<AddVolvoUser />} />
        <Route path="/dealeruser/download" element={<DealerUserDownload />} />
        {/* <Route path="/dealeruser/download"element={<DealerUserDownload/>} /> */}
        <Route path="/contactmanagemnet/editvolvouser" element={<EditVolvoUser />} />
        <Route path="/volvouser/downlaod" element={<VolvoUserDownload />} />
        <Route path="/dealeruser/bulkupload" element={<DealerUserBulkUpload />} />
        <Route path="/dealeradressbook/Adddealeradress" element={<AddDealerAdress />} />
        <Route path="/dealeradressbook/Editdealeradress" element={<EditDealerAddress />} />
        <Route path="/dealeradressbook/download" element={<DealerAddressBookDownload />} />
        <Route path="/volvousers/bulkupload" element={<VolvoUserBulkUpload />} />


        {/* ==========processmangement ========== */}
        <Route path="/processmangement" element={<ProcessmangementHoeme />} />
        <Route path="proceemangemnet/downlaod" element={<DownloadTemplate />} />
        <Route path="/templates/bulkupload" element={<TemplateBulkPreview />} />
        <Route path="proceemangemnet/process/download" element={<ProcessDownlaod />} />
        <Route path="/process/bulkupload" element={<PreocessBulkPreview />} />
        <Route path="schem/downlaod" element={<SchemDownload />} />
        <Route path="/schem/bulkupload" element={<Schembulkpreview />} />
        <Route path="/addnewcollection" element={<AddNewCollection />} />
        <Route path="/collections/view" element={<CollectionView />} />
        <Route path="/collectiondwonload" element={<DownloadCollections />} />
        <Route path="/DownloadCollectionView" element={<DownloadCollectionView />} />


        {/* ==========Support========== */}
        <Route path="/support" element={<Support />} />
        <Route path="/support/trend-chart" element={<TicketTrendChart />} />
        <Route path="/ticket/edit" element={<EditTicket />} />
        <Route path="/ticket/view" element={<ViewTicket />} />
        <Route path="/support/all-tickets" element={<AllTickets />} />

        {/* ============================================================================================================ */}
        {/* 404 CATCH-ALL - MUST BE LAST */}
        {/* ============================================================================================================ */}
        <Route path="*" element={<NotFound />} />

      </Routes>
      </ErrorBoundary>
    </Router>
  );
}

export default App;