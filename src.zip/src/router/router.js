const expres=require('express')
const router=expres.Router()
const {authentication}=require('../middleware/auth')
const {upPaintBoothOne,upPaintBoothTwo,fatchingpaintBooth,volvoUserLogin,fatchingpaintBoothJoin }=require('../controller/paintBooth')
const { uploadCar,fatchingCardetection,fetchemployee,fatchingCarTemp}=require('../controller/carDetect')
const {upBleData}=require('../controller/bleTag')
const {uploadDummy}=require('../controller/text')
//........................testing Api....................
router.get("/test-me", (req, res) => {
    res.status(200).send({
        Status:true,
        Message:"Hello From The Server" 
    }) 
}) 

//..............................PaintBooth API...............................................//




router.post('/voluserlogin',volvoUserLogin)
router.post('/upPaintBoothOne',upPaintBoothOne)
router.post('/upPaintBoothTwo',upPaintBoothTwo)
router.get('/fatchingpaintBooth',authentication,fatchingpaintBooth) 
router.get('/fatchingpaintBoothJoin',authentication,fatchingpaintBoothJoin)


//....................................vehicleNo Detection......................................//


router.post('/uploadCar',uploadCar)
router.get('/fatchingCardetection',authentication,fatchingCardetection)
router.get('/fetchemployee/:id',authentication,fetchemployee)
router.get('/fatchingCarTemp',fatchingCarTemp)
//.....................................BleTag Dtection ............................................//

router.post('/upBleData',upBleData)


//.............................uploadDummy.....................................................//

router.post('/uploadDummy',uploadDummy)

//....................................................................................
router.all('*',(req,res)=>{
    res.status(404).send({status:false,message:"Url is not correct"})
})
module.exports=router
