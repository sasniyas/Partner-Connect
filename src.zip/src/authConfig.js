export const msalConfig = {
  auth: {
    clientId: "dd6b1598-fab8-4241-930e-e1de370a9e64",
    authority:
      "https://login.microsoftonline.com/f25493ae-1c98-41d7-8a33-0be75f5fe603",
    redirectUri: window.location.origin,
  },
  cache: {
    cacheLocation: "localStorage",
  },
};

export const loginRequest = {
  scopes: ["User.Read"],
};
