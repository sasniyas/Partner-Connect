const expres = require('express')
const router = expres.Router()
const { authentication } = require('../middleware/auth')
const { testMail } = require('../controller/other/testmailer')
const { test } = require('../controller/azurestorage/storage')

const { ssoLogin } = require('../controller/other/authController')
const { xlxFiles } = require('../controller/xlx/xlx')

//User Mangement
const { addUser, bulkAddUser, setPassword, login, Adminlogin, logout, getUser, logedInUser, getAllUsers, toggleUserStatus, assignRemoveDealers, updateUser,
    deleteUser, urlValidation, forgotPassword, activationLink
} = require('../controller/user/user')
const UserLogs = require('../controller/user/userLogs')
const { addUserLog, getAllUserLogs, getUserLogById, updateUserLog, deleteUserLog } = require('../controller/user/userLogController')
const { getAllCuntries, getAllStates, getAllDistricts, getAllCities } = require("../controller/masterController/scrorecard/mainData")
const { addMarketArea, bulkAddMarketArea, getMarketAreas, updateMarketArea, toggleMarketArea, deleteMarketArea } = require("../controller/masterController/scrorecard/marketarea");

const { addCountry, bulkAddCountry, getCountries, updateCountry, toggleCountry, deleteCountry } = require("../controller/masterController/scrorecard/cuntry");

const { addState, bulkAddState, getStates, updateState, toggleState, deleteState } = require("../controller/masterController/scrorecard/state");

const { addCity, bulkAddCity, getCities, updateCity, toggleCity, deleteCity } = require("../controller/masterController/scrorecard/city");

const { addDealer, bulkAddDealer, getDealers, updateDealer, toggleDealer, deleteDealer } = require("../controller/masterController/scrorecard/dealer");

const { addRole, bulkAddRole, getRoles, updateRole, toggleRole, deleteRole } = require("../controller/masterController/scrorecard/userRole");

const { addStrategicObjective, bulkAddStrategicObjective, getStrategicObjectives, updateStrategicObjective, toggleStrategicObjective, deleteStrategicObjective } = require("../controller/masterController/scrorecard/strategicObj");

const { addKPI, bulkAddKpi, getKPIs, updateKPI, toggleKPI, deleteKPI } = require("../controller/masterController/scrorecard/kpi");

// const { addSubKPI, bulkAddSubKpi, getAllSubKPIs, getSubKPIById, updateSubKPI, toggleSubKPI, deleteSubKPI } = require("../controller/masterController/scrorecard/subKpi");
const { addSubKPI, bulkAddSubKpi, getAllSubKPIs, getSubKPIById, updateSubKPI, toggleSubKPI, deleteSubKPI, updateFormula } = require("../controller/masterController/scrorecard/subKpi");



//...........................Controller Imports From Master PDP.........................................................//
const { updateDefaultPreTemplate, getDefaultPreTemplate, addPresentationTemplate, bulkAddPresentationTemplate, getAllPresentationTemplates, updatePresentationTemplate, togglePresentationTemplate, deletePresentationTemplate } = require("../controller/masterController/pdp/presentationTemplate/presentationTemplate")

const { addPresentationTemplateCategory, getAllPresentationTemplateCategories, getCategoriesByTemplateId, updatePresentationTemplateCategory, deletePresentationTemplateCategory, restorePresentationTemplateCategory } = require("../controller/masterController/pdp/presentationTemplate/presentationTemplateCategory")

const { updateDefaultFinTemplate, getDefaultFinTemplate, addFinanceTemplate, bulkAddFinanceTemplate, getAllFinanceTemplates, updateFinanceTemplate, toggleFinanceTemplate, deleteFinanceTemplate } = require("../controller/masterController/pdp/financeTemplate/financeTemplate")

const { addFinanceTemplateCategory, getAllFinanceTemplateCategories, getCategoriesByFinanceTemplateId, updateFinanceTemplateCategory, deleteFinanceTemplateCategory } = require("../controller/masterController/pdp/financeTemplate/financeTemplateCategory")

const { addEquipment, bulkAddEquipment, getAllEquipments, updateEquipment, toggleEquipment, deleteEquipment } = require("../controller/masterController/pdp/pdpData/equipments")

const { addUptimePartsCategory, bulkAddUptimePartsCategory, getAllUptimePartsCategories, updateUptimePartsCategory, toggleUptimePartsCategory, deleteUptimePartsCategory } = require("../controller/masterController/pdp/pdpData/uptimePartsCategory")

const { addInfrastructure, bulkAddInfrastructure, getAllInfrastructures, updateInfrastructure, toggleInfrastructure, deleteInfrastructure } = require("../controller/masterController/pdp/pdpData/infrastructure")

const { addCompetence, bulkAddCompetence, getAllCompetences, updateCompetence, toggleCompetence, deleteCompetence } = require("../controller/masterController/pdp/pdpData/competence")

const { addMarcom, bulkAddMarcom, getAllMarcoms, updateMarcom, toggleMarcom, deleteMarcom } = require("../controller/masterController/pdp/pdpData/marcom")

const { addMrkMarcom, bulkAddMarcomMrk, getAllMrkMarcoms, updateMrkMarcom, toggleMrkMarcom, deleteMrkMarcom } = require("../controller/masterController/pdp/pdpData/marcomMarketing")

const { addNationalKeyAccount, bulkAddNationalKeyAccounts, getAllNationalKeyAccounts, updateNationalKeyAccount, toggleNationalKeyAccount, deleteNationalKeyAccount } = require("../controller/masterController/pdp/pdpData/nationalKeyAccounts")

const { addSegmentPriority, bulkAddSegmentPriority, getAllSegmentPriorities, updateSegmentPriority, toggleSegmentPriority, deleteSegmentPriority } = require("../controller/masterController/pdp/pdpData/segmentPriority")

const { addBranchMaster, bulkAddBranchMaster, getAllBranchMasters, updateBranchMaster, toggleBranchMaster, deleteBranchMaster } = require("../controller/masterController/pdp/pdpData/branchMaster")

const { addOtherData, bulkAddOtherData, getAllOtherData, updateOtherData, toggleOtherData, deleteOtherData } = require("../controller/masterController/pdp/pdpData/otherData")

const { addSpecializationCompetence, bulkAddSpecializationCompetence, getAllSpecializationCompetences, getSpecializationCompetenceById, updateSpecializationCompetence, toggleSpecializationCompetence, deleteSpecializationCompetence } = require("../controller/masterController/competenceManagement/specializationCompetence.controller")

const { addCompetenceLevel, bulkAddCompetenceLevel, getAllCompetenceLevels, getCompetenceLevelById, updateCompetenceLevel, toggleCompetenceLevel, deleteCompetenceLevel } = require("../controller/masterController/competenceManagement/competenceLevel.controller")


//Monthly Meeting Controllers..............
const { addFile, getAllFiles, updateFile, toggleFile, deleteFile } = require('../controller/masterController/monthlymeeting/fileMasterController')
const { addDepartment, getDepartments, updateDepartment, toggleDepartment, deleteDepartment } = require('../controller/masterController/monthlymeeting/departmentController')

//Dealer Investment  Controllers...............

const { addEquipmentMlp, getEquipmentsMlp, updateEquipmentMlp, toggleEquipmentMlp, deleteEquipmentMlp } = require('../controller/masterController/dealerinvestment/equipmentMultiplierController')
const { addFinancial, getFinancials, updateFinancial, toggleFinancial, deleteFinancial } = require('../controller/masterController/dealerinvestment/financialMultiplierController')

//DFHM Controllers...............................

const { addBalanceSheet, bulkAddBalanceSheet, getBalanceSheets, updateBalanceSheet, toggleBalanceSheet, deleteBalanceSheet } = require('../controller/masterController/dfhm/balanceSheetController')
const { addHeadCount, bulkAddHeadCount, getHeadCounts, updateHeadCount, toggleHeadCount, deleteHeadCount } = require('../controller/masterController/dfhm/headCountController')
const { addPL, bulkAddPL, getPLs, updatePL, togglePL, deletePL } = require('../controller/masterController/dfhm/plController')
const { addRatioAnalysis, bulkAddRatioAnalysis, getRatioAnalysis, updateRatioAnalysis, toggleRatioAnalysis, deleteRatioAnalysis } = require('../controller/masterController/dfhm/ratioAnalysisController')



//...........................Media Library Controller Imports.........................................................//
const { addPdpDashboardMedia, getAllPdpDashboardMedia, getPdpDashboardMediaById, updatePdpDashboardMedia, togglePdpDashboardMedia, deletePdpDashboardMedia } = require("../controller/masterController/mediaLibrary/pdpDashboard")

const { addScorecardDashboardMedia, getAllScorecardDashboardMedia, getScorecardDashboardMediaById, updateScorecardDashboardMedia, toggleScorecardDashboardMedia, deleteScorecardDashboardMedia } = require("../controller/masterController/mediaLibrary/scorecardDashboard")

const { addMontlyMeetingMedia, getAllMontlyMeetingMedia, getMontlyMeetingMediaById, updateMontlyMeetingMedia, toggleMontlyMeetingMedia, deleteMontlyMeetingMedia } = require("../controller/masterController/mediaLibrary/montlyMeetingMedia")

const { addDealerInvestmentMedia, getAllDealerInvestmentMedia, getDealerInvestmentMediaById, updateDealerInvestmentMedia, toggleDealerInvestmentMedia, deleteDealerInvestmentMedia } = require("../controller/masterController/mediaLibrary/dealerInvestmentMedia")

const { addDfhmMedia, getAllDfhmMedia, getDfhmMediaById, updateDfhmMedia, toggleDfhmMedia, deleteDfhmMedia } = require("../controller/masterController/mediaLibrary/dfhmMedia")




//...........................Monthly Meeting Controller Imports.........................................................//
const { addMonthlyMeeting, getAllMonthlyMeetings, updateMonthlyMeeting, deleteMonthlyMeeting, getMonthlyMeetingById } = require("../controller/monthlyMeetingController/monthlyMeeting")

//...........................Action Item Controller Imports.........................................................//
const { addActionItem, getAllActionItems, updateActionItem, deleteActionItem, getActionItemById, getActionItemsByMeeting, updateActionItemStatus } = require("../controller/monthlyMeetingController/actionItem")

//...........................Action Log Controller Imports.........................................................//
const { addActionLog, getAllActionLogs, getActionLogById, getActionLogsByActionItem, updateActionLog, deleteActionLog, getTargetDate } = require("../controller/monthlyMeetingController/actionItemLog")

//...........................Monthly Meeting Template Controller Imports.........................................................//
const { addMonthlyMeetingTemplate, getAllMonthlyMeetingTemplates, getMonthlyMeetingTemplateById, getMonthlyMeetingTemplatesByMonthlyMeeting, updateMonthlyMeetingTemplate, bulkUploadMonthlyMeetingTemplates, deleteMonthlyMeetingTemplate } = require("../controller/monthlyMeetingController/monthly_meeting_template")

//...........................Monthly Meeting User Responsibility Controller Imports.........................................................//
const { getUsersByMonthlyMeetingDealer } = require("../controller/monthlyMeetingController/userResponsibility")



//...........................PDP Controller Imports.........................................................//
const { addPdp, getAllPdp, getPdpById, updatePdp, deletePdp, getAllPdpWithActionItemCounts, pdpStatusChange, updatePdpMeetingDetails } = require("../controller/pdp/pdp.controller")

//...........................PDP Action Item Controller Imports.........................................................//
const { addPdpActionItem, getAllPdpActionItem, getPdpActionItemById, updatePdpActionItem, deletePdpActionItem } = require("../controller/pdp/pdpActionPlanner.controller")

//...........................PDP Action Log Controller Imports.........................................................//
const { addActionLog: addPdpActionLog, getAllActionLogs: getAllPdpActionLogs, getActionLogById: getPdpActionLogById, getActionLogsByActionItem: getPdpActionLogsByActionItem, updateActionLog: updatePdpActionLog, deleteActionLog: deletePdpActionLog, getTargetDate: getPdpTargetDate } = require("../controller/pdp/pdpActionItemLog.controller")

//...........................PDP Equipment Controller Imports.........................................................//
const { addPdpEquipment, getAllPdpEquipments, getPdpEquipmentById, getPdpEquipmentsByPdpId, updatePdpEquipment, updateMultiplePdpEquipments, deletePdpEquipment } = require("../controller/pdp/pdpEquipments/pdpEquipments.controller")

//...........................PDP Uptime Parts Controller Imports.........................................................//
const { addPdpUptimeParts, getAllPdpUptimeParts, getPdpUptimePartsById, getPdpUptimePartsByPdpId, updatePdpUptimeParts, updateMultiplePdpUptimeParts, deletePdpUptimeParts } = require("../controller/pdp/pdpUptimeParts/pdpUptimeParts.controller")

//...........................PDP Infrastructure Controller Imports.........................................................//
const { addPdpInfrastructure, getAllPdpInfrastructures, getPdpInfrastructureById, getPdpInfrastructuresByPdpId, updatePdpInfrastructure, deletePdpInfrastructure } = require("../controller/pdp/pdpInfrastructure/pdpInfrastructure.controller")

//...........................PDP Infrastructure Location Count Controller Imports.........................................................//
const { addPdpInfrastructureLocationCount, getAllPdpInfrastructureLocationCounts, getPdpInfrastructureLocationCountById, getPdpInfrastructureLocationCountsByPdpId, getPdpInfrastructureLocationCountsByPdpInfrastructureId, updatePdpInfrastructureLocationCount, deletePdpInfrastructureLocationCount } = require("../controller/pdp/pdpInfrastructure/pdpInfrastructureLocation/pdpInfrastructureLocation.controller")

//...........................PDP Infrastructure Vehicle Controller Imports.........................................................//
const { addPdpInfrastructureVehicle, getAllPdpInfrastructureVehicles, getPdpInfrastructureVehicleById, getPdpInfrastructureVehiclesByPdpId, getPdpInfrastructureVehiclesByPdpInfrastructureId, updatePdpInfrastructureVehicle, deletePdpInfrastructureVehicle } = require("../controller/pdp/pdpInfrastructure/pdpInfrastructureVehicle/pdpInfrastructureVehicle.controller")

//...........................PDP Infrastructure Tools Controller Imports.........................................................//
const { addPdpInfrastructureTool, getAllPdpInfrastructureTools, getPdpInfrastructureToolById, getPdpInfrastructureToolsByPdpId, getPdpInfrastructureToolsByPdpInfrastructureId, updatePdpInfrastructureTool, deletePdpInfrastructureTool } = require("../controller/pdp/pdpInfrastructure/pdpInfrastructureTools/pdpInfrastructureTools.controller")

//...........................PDP Infrastructure Assets Controller Imports.........................................................//
const { addPdpInfrastructureAsset, getAllPdpInfrastructureAssets, getPdpInfrastructureAssetById, getPdpInfrastructureAssetsByPdpId, getPdpInfrastructureAssetsByPdpInfrastructureId, updatePdpInfrastructureAsset, deletePdpInfrastructureAsset } = require("../controller/pdp/pdpInfrastructure/pdpInfrastructureAssets/pdpInfrstructureAssets.controller")

//...........................PDP Territory Focus Controller Imports.........................................................//
const { addPdpTerritoryFocus, getAllPdpTerritoryFocus, getPdpTerritoryFocusById, getPdpTerritoryFocusByPdpId, updatePdpTerritoryFocus, deletePdpTerritoryFocus } = require("../controller/pdp/pdpTerritoryFocus/pdpTerritoryFocus.controller")

//...........................PDP Territory Focus Entries Controller Imports.........................................................//
const { addPdpTerritoryFocusEntry, getAllPdpTerritoryFocusEntries, getPdpTerritoryFocusEntryById, getPdpTerritoryFocusEntriesByPdpId, getPdpTerritoryFocusEntriesByTerritoryFocusId, updatePdpTerritoryFocusEntry, deletePdpTerritoryFocusEntry } = require("../controller/pdp/pdpTerritoryFocus/pdpTerritoryFocusEntries/pdpTerritoryFocusEntries.controller")

//...........................PDP Territory Focus Entries Stats Controller Imports.........................................................//
const { addPdpTerritoryFocusEntriesStats, getAllPdpTerritoryFocusEntriesStats, getPdpTerritoryFocusEntriesStatsById, getPdpTerritoryFocusEntriesStatsByPdpId, updatePdpTerritoryFocusEntriesStats, deletePdpTerritoryFocusEntriesStats } = require("../controller/pdp/pdpTerritoryFocus/pdpTerritoryFocusEntriesStats/pdpTerritoryFocusEntriesStats.controller")

//...........................PDP Competence Development Controller ...............................................................//
const { addPdpCompetenceDevelopment, getAllPdpCompetenceDevelopments, getPdpCompetenceDevelopmentById, getPdpCompetenceDevelopmentsByPdpId, getActiveMachines, updatePdpCompetenceDevelopment, updateMultiplePdpCompeDev, deletePdpCompetenceDevelopment } = require("../controller/pdp/pdpCompetence/pdpCompetence.controller")

//...........................PDP Marcom Branding Controller Imports.........................................................//
const { getAllPdpMarcomBranding, getPdpMarcomBrandingById, getPdpMarcomBrandingByPdpId, updatePdpMarcomBranding, updateMultiplePdpMarcomBranding, updatePdpMarcomSupdoc, deletePdpMarcomSupdoc, deletePdpMarcomBranding } = require("../controller/pdp/pdpMarcom/pdpMarcomBranding.controller")

//...........................PDP Marcom Marketing Controller Imports.........................................................//
const { getAllPdpMarcomMarketing, getPdpMarcomMarketingById, getPdpMarcomMarketingByPdpId, updatePdpMarcomMarketing, updateMultiplePdpMarcomMarketing, deletePdpMarcomMarketing } = require("../controller/pdp/pdpMarcom/pdpMarcomMarketing.controller")



//...........................PDP Upload Files Controller Imports.........................................................//
const { addPdpUploadFile, getAllPdpUploadFiles, getPdpUploadFileById, getPdpUploadFilesByPdpId, updatePdpUploadFile, deletePdpUploadFile } = require("../controller/pdp/pdpUploadFiles/pdpUploadFiles.controller")

//...........................PDP Signoff Controller Imports.........................................................//
const { addPdpSignoff, getAllPdpSignoffs, getPdpSignoffById, getPdpSignoffsByPdpId, getPdpSignoffsByUserId, updatePdpSignoff, signPdpSignoff, deletePdpSignoff } = require("../controller/pdp/pdpSignoff/pdpSignoff.controller")

//...........................PDP Others Controller Imports.........................................................//
const { addPdpOthers, getAllPdpOthers, getPdpOthersById, getPdpOthersByPdpId, updatePdpOthers, deletePdpOthers } = require("../controller/pdp/pdpOthers/pdpOthers.controller")




//...........................Scorecard Controller Imports.........................................................//
const { addScorecard, getAllScorecards, getScorecardById, updateScorecard, toggleScorecard, deleteScorecard, completeScorecard, bulkCompleteScorecard } = require("../controller/scorecard/scorecard.controller");
//...........................Scorecard Score View Controller Imports.........................................................//
const { getAllScorecardScoreViews, getScorecardScoreViewById, getScorecardScoreViewsByScorecardId, updateScorecardScoreView, bulkToggleScorecardScoreViewExclusion, deleteScorecardScoreView } = require("../controller/scorecard/scorecardScoreView/scorecardScoreView.controller");

//...........................Scorecard Score View Doc Controller Imports.........................................................//
const { addScorecardScoreViewDoc, getAllScorecardScoreViewDocs, getScorecardScoreViewDocById, getScorecardScoreViewDocsByScorecardId, updateScorecardScoreViewDoc, toggleScorecardScoreViewDoc, deleteScorecardScoreViewDoc } = require("../controller/scorecard/scorecardScoreView/scorecardScoreViewDoc.controller");

//...........................Scorecard Action Item Controller Imports.........................................................//
const { addScorecardActionItem, getAllScorecardActionItems, getScorecardActionItemById, getScorecardActionItemsByScoreId, updateScorecardActionItem, toggleScorecardActionItem, deleteScorecardActionItem } = require("../controller/scorecard/scorecardActionItem/scorecardActionItem.controller");

//...........................Scorecard Action Log Controller Imports.........................................................//
const { addScorecardActionLog, getAllScorecardActionLogs, getScorecardActionLogById, getScorecardActionLogsByActionItemId, getFirstLogCommentsByActionItemId, updateScorecardActionLog, deleteScorecardActionLog } = require("../controller/scorecard/scorecardActionLog/scorecardActionLog.controller");



//...........................Dealer Investment.................................................//

//...........................Dealer Investment Controller Imports.........................................................//
const { getAllDealerInvestment, getDealerInvestmentById, getDealerInvestmentBypdpId, updateDealerInvestment, deleteDealerInvestment, mbpStatusEquipmentsChange, mbpStatusUapChange } = require("../controller/dealerInvestment/dealerInvestment.controller")

//...........................Dealer Investment Infrastructure Controller Imports.........................................................//
const { getAllDealerInvestmentInfrastructure, getDealerInvestmentInfrastructureById, getDealerInvestmentInfrastructureByDealerInvestmentId, getDealerInvestmentInfrastructureByPdpId, updateDealerInvestmentInfrastructure, updateMultipleDealerInvestmentInfrastructure, deleteDealerInvestmentInfrastructure } = require("../controller/dealerInvestment/dealerInvestmentInfrastructure/dealerInvestmentInfrastructure.controller")

//...........................Dealer Investment Competence Controller Imports.........................................................//
const { getAllDealerInvestmentCompetence, getDealerInvestmentCompetenceById, getDealerInvestmentCompetenceByDealerInvestmentId, getDealerInvestmentCompetenceByPdpId, updateDealerInvestmentCompetence, updateMultipleDealerInvestmentCompetence, deleteDealerInvestmentCompetence } = require("../controller/dealerInvestment/dealerInvestmentCompetence/dealerInvestmentCompetence.controller")

//...........................Dealer Investment Machine Population Controller Imports.........................................................//
const { getAllDealerInvestmentMachinePopulation, getDealerInvestmentMachinePopulationById, getDealerInvestmentMachinePopulationByDealerInvestmentId, getDealerInvestmentMachinePopulationByPdpId, updateDealerInvestmentMachinePopulation, updateMultipleDealerInvestmentMachinePopulation, deleteDealerInvestmentMachinePopulation } = require("../controller/dealerInvestment/dealerInvestmentMachinePopulation/dealerInvestmentMachinePopulation.controller")

//...........................Dealer Investment Equipment MBP Controller Imports.........................................................//
const { getAllDealerInvestmentEquipmentMbp, getDealerInvestmentEquipmentMbpById, getDealerInvestmentEquipmentMbpByDealerInvestmentId, getDealerInvestmentEquipmentMbpByPdpId, updateDealerInvestmentEquipmentMbp, updateMultipleDealerInvestmentEquipmentMbp, deleteDealerInvestmentEquipmentMbp } = require("../controller/dealerInvestment/dealerInvestmentEquipments/dealerInvestmentEquipmentsMbp.controller")

//...........................Dealer Investment Equipment Projection Controller Imports.........................................................//
const { getAllDealerInvestmentEquipmentProjection, getDealerInvestmentEquipmentProjectionById, getDealerInvestmentEquipmentProjectionByDealerInvestmentId, getDealerInvestmentEquipmentProjectionByPdpId, updateDealerInvestmentEquipmentProjection, updateMultipleDealerInvestmentEquipmentProjection, deleteDealerInvestmentEquipmentProjection } = require("../controller/dealerInvestment/dealerInvestmentEquipments/dealerInvestmentEquipmentsProjection.controller")

//...........................Dealer Investment Equipment Actuals Controller Imports.........................................................//
const { getAllDealerInvestmentEquipmentActuals, getDealerInvestmentEquipmentActualsById, getDealerInvestmentEquipmentActualsByDealerInvestmentId, getDealerInvestmentEquipmentActualsByPdpId, updateDealerInvestmentEquipmentActuals, updateMultipleDealerInvestmentEquipmentActuals, deleteDealerInvestmentEquipmentActuals } = require("../controller/dealerInvestment/dealerInvestmentEquipments/dealerInvestmentEquipmentsActuals.controller")

//...........................Dealer Investment Uptime MBP Controller Imports.........................................................//
const { getAllDealerInvestmentUptimeMbp, getDealerInvestmentUptimeMbpById, getDealerInvestmentUptimeMbpByDealerInvestmentId, getDealerInvestmentUptimeMbpByPdpId, updateDealerInvestmentUptimeMbp, updateMultipleDealerInvestmentUptimeMbp, deleteDealerInvestmentUptimeMbp } = require("../controller/dealerInvestment/dealerInvestmentUptime/dealerInvestmentUptimeMbp.controller")

//...........................Dealer Investment Uptime Projection Controller Imports.........................................................//
const { getAllDealerInvestmentUptimeProjection, getDealerInvestmentUptimeProjectionById, getDealerInvestmentUptimeProjectionByDealerInvestmentId, getDealerInvestmentUptimeProjectionByPdpId, updateDealerInvestmentUptimeProjection, updateMultipleDealerInvestmentUptimeProjection, deleteDealerInvestmentUptimeProjection } = require("../controller/dealerInvestment/dealerInvestmentUptime/dealerInvestmentUptimeProjection.controller")

//...........................Dealer Investment Uptime Actuals Controller Imports.........................................................//
const { getAllDealerInvestmentUptimeActuals, getDealerInvestmentUptimeActualsById, getDealerInvestmentUptimeActualsByDealerInvestmentId, getDealerInvestmentUptimeActualsByPdpId, updateDealerInvestmentUptimeActuals, updateMultipleDealerInvestmentUptimeActuals, deleteDealerInvestmentUptimeActuals } = require("../controller/dealerInvestment/dealerInvestmentUptime/dealerInvestmentUptimeActuals.controller")

//.....................Dealer Investment Vehicles Controller Imports.........................................................//
const { addDealerInvestmentVehicle, getAllDealerInvestmentVehicles, getDealerInvestmentVehicleById, getDealerInvestmentVehiclesByDealerInvestmentId, updateDealerInvestmentVehicle, deleteDealerInvestmentVehicle } = require("../controller/dealerInvestment/dealerInvestmentVehicles/dealerInvestmentVehicles.controller")

//.....................Dealer Investment File Controller Imports.........................................................//
const { addDealerInvestmentFile, getAllDealerInvestmentFiles, getDealerInvestmentFileById, getDealerInvestmentFilesByDealerInvestmentId, updateDealerInvestmentFile, deleteDealerInvestmentFile } = require("../controller/dealerInvestment/dealerInvestmentFile/dealerInvestmentFile.controller")

//.....................Inventory Allocation Management Controller Imports.........................................................//
const { addInventoryAllocation, getAllInventoryAllocations, getInventoryAllocationById, updateInventoryAllocation, toggleInventoryAllocationStatus, deleteInventoryAllocation } = require("../controller/dealerInvestment/allocationManagement/inventory/inventory.controller")

//.....................Inventory Data Allocation Management Controller Imports.........................................................//
const { getAllInventoryDataAllocations, getInventoryDataAllocationById, getInventoryDataAllocationsByInventoryId, updateInventoryDataAllocation, updateMultipleInventoryDataAllocations, toggleInventoryDataAllocationStatus, deleteInventoryDataAllocation } = require("../controller/dealerInvestment/allocationManagement/inventory/inventoryData.controller")

//.....................Dealer Investment Allocation Controller Imports.........................................................//
const { getAllDealerInvestmentAllocation, getDealerInvestmentAllocationById, getDealerInvestmentAllocationByDealerInvestmentId, getDealerInvestmentAllocationByPdpId, updateDealerInvestmentAllocation, updateMultipleDealerInvestmentAllocation, deleteDealerInvestmentAllocation } = require("../controller/dealerInvestment/dealerInvestmentAllocation/dealerInvestmentAllocation.controller")

//....................DFHM Controllers..........................//

//DFHM Controllers...............................

const { addDfhm, getAllDfhm, getDfhmById, updateDfhm, toggleDfhm, deleteDfhm } = require('../controller/dfhm/dfhm.controller')

//...........................DFHM Child Controllers.........................................................//
const { getAllDfhmPl, getDfhmPlById, getDfhmPlByDfhmId, getDfhmPlByFilters, updateDfhmPl, updateMultipleDfhmPl, deleteDfhmPl } = require("../controller/dfhm/dfhmMasterChild/dfhm_pl.controller")
const { getAllDfhmBs, getDfhmBsById, getDfhmBsByDfhmId, getDfhmBsByFilters, updateDfhmBs, updateMultipleDfhmBs, deleteDfhmBs } = require("../controller/dfhm/dfhmMasterChild/dfhm_bs.controller")
const { getAllDfhmHc, getDfhmHcById, getDfhmHcByDfhmId, getDfhmHcByFilters, updateDfhmHc, updateMultipleDfhmHc, deleteDfhmHc } = require("../controller/dfhm/dfhmMasterChild/dfhm_hc.controller")
const { addDfhmAging, getAllDfhmAging, getDfhmAgingById, getDfhmAgingByFilters, getDfhmAgingByDfhmId, updateDfhmAging, updateMultipleDfhmAging, deleteDfhmAging } = require("../controller/dfhm/dfhmMasterChild/dfhm_aging.controller")

//.....................Dealer User Details Controller Imports.........................................................//
const { addDealerUserDetail, bulkAddDealerUserDetails, getAllDealerUserDetails, getDealerUserDetailById, updateDealerUserDetail, deleteDealerUserDetail, toggleDealerUserDetailStatus } = require("../controller/contactManagement/userDetails/dealerUserDetails.controller")

//.....................Volvo User Details Controller Imports.........................................................//
const { addVolvoUserDetail, bulkAddVolvoUserDetails, getAllVolvoUserDetails, getVolvoUserDetailById, updateVolvoUserDetail, deleteVolvoUserDetail, toggleVolvoUserDetailStatus } = require("../controller/contactManagement/userDetails/volvoUserDetails.controller")

//.....................Dealer Address Book Controller Imports.........................................................//
const { addDealerAddressBook, updateDealerAddressBook, bulkAddDealerAddressBooks, getAllDealerAddressBooks, getDealerAddressBookById, deleteDealerAddressBook, toggleDealerAddressBookStatus } = require("../controller/contactManagement/dealerAddressBook/dealerAddressBook.controller")

//.....................Contact Management Department Controller Imports.........................................................//
const {
    addDepartment: addCMDepartment,
    bulkAddDepartment: bulkAddCMDepartment,
    getAllDepartments: getAllCMDepartments,
    getDepartmentById: getCMDepartmentById,
    updateDepartment: updateCMDepartment,
    toggleDepartmentStatus: toggleCMDepartmentStatus,
    deleteDepartment: deleteCMDepartment
} = require("../controller/masterController/contactManagement/department.controller")

const {
    addDesignation: addCMDesignation,
    bulkAddDesignation: bulkAddCMDesignation,
    getAllDesignations: getAllCMDesignations,
    getDesignationById: getCMDesignationById,
    updateDesignation: updateCMDesignation,
    toggleDesignationStatus: toggleCMDesignationStatus,
    deleteDesignation: deleteCMDesignation
} = require("../controller/masterController/contactManagement/designation.controller")

//.....................Process Management Template Controller Imports.........................................................//
const {
    addProcessManagementTemplate,
    bulkAddProcessManagementTemplates,
    getAllProcessManagementTemplates,
    getProcessManagementTemplateById,
    updateProcessManagementTemplate,
    deleteProcessManagementTemplate,
    toggleProcessManagementTemplateStatus
} = require("../controller/processManagement/processManagementTemplates/processManagementTemplate.controller")

//.....................My Support Ticket Controller Imports.........................................................//
const {
    addTicket,
    getAllTickets,
    getTicketById,
    getTicketByUserId,
    updateTicket,
    deleteTicket,
    toggleTicketStatus
} = require("../controller/mySupport/ticket.controller")

const {
    addTicketAttachment,
    getAttachmentsByTicketId,
    getTicketAttachmentById,
    deleteTicketAttachment,
    toggleTicketAttachmentStatus
} = require("../controller/mySupport/ticketAttachments/ticketAttachments.controller")

const {
    addTicketComment,
    getCommentsByTicketId,
    getTicketCommentById,
    updateTicketComment,
    deleteTicketComment,
    toggleTicketCommentStatus
} = require("../controller/mySupport/ticketComments/ticketComment.controller")

const {
    addNotification,
    getAllNotifications,
    getNotificationById,
    updateNotification,
    toggleNotificationStatus,
    deleteNotification
} = require("../controller/notification/notification.controller")

const {
    getAllUserNotifications,
    getUserNotificationById,
    getUserNotificationsByUserId,
    toggleSeenStatus,
    bulkToggleSeenStatus
} = require("../controller/notification/user_notification.controller")

const {
    addProcessManagementProcess,
    bulkAddProcessManagementProcesses,
    getAllProcessManagementProcesses,
    getProcessManagementProcessById,
    updateProcessManagementProcess,
    deleteProcessManagementProcess,
    toggleProcessManagementProcessStatus
} = require("../controller/processManagement/processManagementProcess/processManagementProcess.controller")

//.....................Process Management Policy Controller Imports.........................................................//
const {
    addProcessManagementPolicy,
    bulkAddProcessManagementPolicies,
    getAllProcessManagementPolicies,
    getProcessManagementPolicyById,
    updateProcessManagementPolicy,
    deleteProcessManagementPolicy,
    toggleProcessManagementPolicyStatus
} = require("../controller/processManagement/processManagementPolicy/processManagementPolicy.controller")

//.....................Data Collection Controller Imports.........................................................//
const {
    addDataCollection,
    getAllDataCollections,
    getDataCollectionById,
    updateDataCollection,
    deleteDataCollection
} = require("../controller/processManagement/dataCollection/dataCollection.controller")

//.....................Child Table Controller Imports.........................................................//
const {
    addChildTableRow,
    getChildTableRows,
    updateChildTableRow,
    deleteChildTableRow,
    getChildTableStructure
} = require("../controller/processManagement/dataCollection/childTable.controller")

//.....................City Master Fetch Controller Imports.........................................................//
const { bulkInsertCities } = require("../controller/cityMasterFetch/city.controller");


//SSO login Api............................

router.post("/ssoLogin", ssoLogin)

//xlxFiles Upload Api............................

router.post("/xlxFiles", xlxFiles)
//...........................User MAngement API..................................//
router.post("/addUser", authentication, addUser); // Add User
router.post("/bulkAddUser", authentication, bulkAddUser); // Bulk Add User
router.put("/setPassword", setPassword); // Set New password
router.post("/login", login); // Login User
router.post("/adminLogin", authentication, Adminlogin); // Logout User
router.post("/logout", authentication, logout); // Logout User
router.get("/getUser/:id", authentication, getUser); // Get Individual User
router.get("/logedInUser", authentication, logedInUser); // Get Individual Loged In User
router.get("/getAllUsers", authentication, getAllUsers); // Get All Users
router.put("/toggleUserStatus", authentication, toggleUserStatus) //toggle user status
router.put("/assignRemoveDealers", authentication, assignRemoveDealers) //assign and remode delaerships for user
router.put("/updateUser", authentication, updateUser) //Update User Data
router.delete("/deleteUser/:id", authentication, deleteUser)//Dlete The user
router.get("/urlValidation", authentication, urlValidation) //Activation Or forgot password 
router.put("/forgotPassword", forgotPassword) //Frogot password
router.put("/activationLink", authentication, activationLink)//activation Mail

//...........................User Logs API..................................//
router.post("/addUserLog", authentication, addUserLog);

router.get("/getUserLogs", authentication, getAllUserLogs);

router.get("/getUserLog/:id", authentication, getUserLogById);

router.put("/updateUserLog/:id", authentication, updateUserLog);

router.delete("/deleteUserLog/:id", authentication, deleteUserLog);

//.........................Main Data API.......................................//

router.get("/getAllCuntries", authentication, getAllCuntries); // Get all
router.get("/getAllStates", authentication, getAllStates); // Get all
router.get("/getAllDistricts", authentication, getAllDistricts); // Get all
router.get("/getAllCities", authentication, getAllCities); // Get all

//...............Score Card Master..................................
//.................................Market Area.......API....................................//

router.post("/addMarket-area", authentication, addMarketArea); // Add
router.post("/bulkAddMarket-area", authentication, bulkAddMarketArea); // Bulk Add
router.get("/getMarket-area", authentication, getMarketAreas); // Get all
router.put("/updateMarket-area", authentication, updateMarketArea); // Update
router.patch("/patchMarket-area/toggle/:id", authentication, toggleMarketArea); // Toggle enable/disable
router.delete("/deleteMarket-area/:id", authentication, deleteMarketArea); // Delete

//........................Cuntry.............API.......................................//

router.post("/addCountry", authentication, addCountry); // Add
router.post("/bulkAddCountry", authentication, bulkAddCountry); // Bulk Add
router.get("/getCountries", authentication, getCountries); // Get all
router.put("/updateCountry", authentication, updateCountry); // Update
router.patch("/toggleCountry/toggle/:id", authentication, toggleCountry); // Toggle enable/disable
router.delete("/deleteCountry/:id", authentication, deleteCountry); // Delete






//........................State.............API.......................................//

router.post("/addState", authentication, addState); // Add
router.post("/bulkAddState", authentication, bulkAddState); // Bulk Add
router.get("/getStates", authentication, getStates); // Get all
router.put("/updateState", authentication, updateState); // Update
router.patch("/toggleState/toggle/:id", authentication, toggleState); // Toggle enable/disable
router.delete("/deleteState/:id", authentication, deleteState); // Delete


//......................City.......................API .......................//

router.post("/addCity", authentication, addCity); // Add
router.post("/bulkAddCity", authentication, bulkAddCity); // Bulk Add
router.get("/getCities", authentication, getCities); // Get all
router.put("/updateCity", authentication, updateCity); // Update
router.patch("/toggleCity/toggle/:id", authentication, toggleCity); // Toggle enable/disable
router.delete("/deleteCity/:id", authentication, deleteCity); // Delete


//.............................Dealer ....................API...................
router.post("/addDealer", authentication, addDealer); // Add
router.post("/bulkAddDealer", authentication, bulkAddDealer); // Bulk Add
router.get("/getDealers", authentication, getDealers); // Get all
router.put("/updateDealer", authentication, updateDealer); // Update
router.patch("/toggleDealer/toggle/:id", authentication, toggleDealer); // Toggle enable/disable
router.delete("/deleteDealer/:id", authentication, deleteDealer); // Delete

//.....................Role.......................API..........................

router.post("/addRole", authentication, addRole); // Add
router.post("/bulkAddRole", authentication, bulkAddRole); // Bulk Add
router.get("/getRoles", authentication, getRoles); // Get all 
router.put("/updateRole", authentication, updateRole); // Update
router.patch("/toggleRole/toggle/:id", authentication, toggleRole); // Toggle enable/disable
router.delete("/deleteRole/:id", authentication, deleteRole); // Delete

//.....................StrategicObjectives.......................API..........................

router.post("/addStrategicObjective", authentication, addStrategicObjective); // Add
router.post("/bulkAddStrategicObjective", authentication, bulkAddStrategicObjective); // Bulk Add
router.get("/getStrategicObjectives", authentication, getStrategicObjectives); // Get all
router.put("/updateStrategicObjective", authentication, updateStrategicObjective); // Update
router.patch("/toggleStrategicObjective/toggle/:id", authentication, toggleStrategicObjective); // Toggle enable/disable
router.delete("/deleteStrategicObjective/:id", authentication, deleteStrategicObjective); // Delete

//.....................KPI.......................API..........................

router.post("/addKPI", authentication, addKPI); // Add
router.post("/bulkAddKpi", authentication, bulkAddKpi); // Bulk Add
router.get("/getKPIs", authentication, getKPIs); // Get all
router.put("/updateKPI", authentication, updateKPI); // Update
router.patch("/toggleKPI/toggle/:id", authentication, toggleKPI); // Toggle enable/disable
router.delete("/deleteKPI/:id", authentication, deleteKPI); // Delete


//.....................SUB KPI.......................API..........................

router.post("/addSubKPI", authentication, addSubKPI); // Add
router.post("/bulkAddSubKpi", authentication, bulkAddSubKpi); // Bulk Add
router.get("/getAllSubKPIs", authentication, getAllSubKPIs); // Get all
router.get("/getSubKPIById/:id", authentication, getSubKPIById); // Get all
router.put("/updateSubKPI", authentication, updateSubKPI); // Update
router.patch("/toggleSubKPI/toggle/:id", authentication, toggleSubKPI); // Toggle enable/disable
router.delete("/deleteSubKPI/:id", authentication, deleteSubKPI); // Delete
router.put("/updateFormula", authentication, updateFormula); // Update Formula

//.................................PDP Master Data..............................................//

//.....................PresentationTemplate.......................API..........................
router.put("/updateDefaultPreTemplate", authentication, updateDefaultPreTemplate); // update default file
router.get("/getDefaultPreTemplate", authentication, getDefaultPreTemplate); // get default file
router.post("/addPresentationTemplate", authentication, addPresentationTemplate); // Add
router.post("/bulkAddPresentationTemplate", authentication, bulkAddPresentationTemplate); // Bulk Add
router.get("/getPresentationTemplates", authentication, getAllPresentationTemplates); // Get all
router.put("/updatePresentationTemplate", authentication, updatePresentationTemplate); // Update
router.patch("/togglePresentationTemplate/toggle/:id", authentication, togglePresentationTemplate); // Toggle enable/disable
router.delete("/deletePresentationTemplate/:id", authentication, deletePresentationTemplate); // Delete

//.....................PresentationTemplateCategory.......................API..........................

router.post("/addPresentationTemplateCategory", authentication, addPresentationTemplateCategory); // Add
router.get("/getPresentationTemplateCategories", authentication, getAllPresentationTemplateCategories); // Get all
router.get("/getCategoriesByTemplateId/:presentation_template_id", authentication, getCategoriesByTemplateId); // Get by template ID
router.put("/updatePresentationTemplateCategory", authentication, updatePresentationTemplateCategory); // Update
router.delete("/deletePresentationTemplateCategory/:id", authentication, deletePresentationTemplateCategory); // Delete (soft delete)
// router.patch("/restorePresentationTemplateCategory/:id", authentication, restorePresentationTemplateCategory); // Restore deleted

//.....................FinanceTemplate.......................API..........................
router.put("/updateDefaultFinTemplate", authentication, updateDefaultFinTemplate); // update default file
router.get("/getDefaultFinTemplate", authentication, getDefaultFinTemplate); // get default file
router.post("/addFinanceTemplate", authentication, addFinanceTemplate); // Add
router.post("/bulkAddFinanceTemplate", authentication, bulkAddFinanceTemplate); // Bulk Add
router.get("/getFinanceTemplates", authentication, getAllFinanceTemplates); // Get all
router.put("/updateFinanceTemplate", authentication, updateFinanceTemplate); // Update
router.patch("/toggleFinanceTemplate/toggle/:id", authentication, toggleFinanceTemplate); // Toggle enable/disable
router.delete("/deleteFinanceTemplate/:id", authentication, deleteFinanceTemplate); // Delete

//.....................FinanceTemplateCategory.......................API..........................

router.post("/addFinanceTemplateCategory", authentication, addFinanceTemplateCategory); // Add
router.get("/getFinanceTemplateCategories", authentication, getAllFinanceTemplateCategories); // Get all
router.get("/getCategoriesByFinanceTemplateId/:finance_template_id", authentication, getCategoriesByFinanceTemplateId); // Get by template ID
router.put("/updateFinanceTemplateCategory", authentication, updateFinanceTemplateCategory); // Update
router.delete("/deleteFinanceTemplateCategory/:id", authentication, deleteFinanceTemplateCategory); // Delete (soft delete)

//.....................Equipment.......................API..........................

router.post("/addEquipment", authentication, addEquipment); // Add
router.post("/bulkAddEquipment", authentication, bulkAddEquipment); // Bulk Add
router.get("/getEquipments", authentication, getAllEquipments); // Get all
router.put("/updateEquipment", authentication, updateEquipment); // Update
router.patch("/toggleEquipment/toggle/:id", authentication, toggleEquipment); // Toggle enable/disable
router.delete("/deleteEquipment/:id", authentication, deleteEquipment); // Delete

//.....................UptimePartsCategory.......................API..........................

router.post("/addUptimePartsCategory", authentication, addUptimePartsCategory); // Add
router.post("/bulkAddUptimePartsCategory", authentication, bulkAddUptimePartsCategory); // Bulk Add
router.get("/getUptimePartsCategories", authentication, getAllUptimePartsCategories); // Get all
router.put("/updateUptimePartsCategory", authentication, updateUptimePartsCategory); // Update
router.patch("/toggleUptimePartsCategory/toggle/:id", authentication, toggleUptimePartsCategory); // Toggle enable/disable
router.delete("/deleteUptimePartsCategory/:id", authentication, deleteUptimePartsCategory); // Delete

//.....................Infrastructure.......................API..........................

router.post("/addInfrastructure", authentication, addInfrastructure); // Add
router.post("/bulkAddInfrastructure", authentication, bulkAddInfrastructure); // Bulk Add
router.get("/getInfrastructures", authentication, getAllInfrastructures); // Get all
router.put("/updateInfrastructure", authentication, updateInfrastructure); // Update 
router.patch("/toggleInfrastructure/toggle/:id", authentication, toggleInfrastructure); // Toggle enable/disable
router.delete("/deleteInfrastructure/:id", authentication, deleteInfrastructure); // Delete

//.....................Competence.......................API..........................

router.post("/addCompetence", authentication, addCompetence); // Add
router.post("/bulkAddCompetence", authentication, bulkAddCompetence); // Bulk Add
router.get("/getCompetences", authentication, getAllCompetences); // Get all
router.put("/updateCompetence", authentication, updateCompetence); // Update
router.patch("/toggleCompetence/toggle/:id", authentication, toggleCompetence); // Toggle enable/disable
router.delete("/deleteCompetence/:id", authentication, deleteCompetence); // Delete

//.....................Marcom.......................API..........................

router.post("/addMarcom", authentication, addMarcom); // Add
router.post("/bulkAddMarcom", authentication, bulkAddMarcom); // Bulk Add
router.get("/getMarcoms", authentication, getAllMarcoms); // Get all
router.put("/updateMarcom", authentication, updateMarcom); // Update
router.patch("/toggleMarcom/toggle/:id", authentication, toggleMarcom); // Toggle enable/disable
router.delete("/deleteMarcom/:id", authentication, deleteMarcom); // Delete

//.....................Marcom Marketing.......................API..........................

router.post("/addMrkMarcom", authentication, addMrkMarcom); // Add
router.post("/bulkAddMarcomMrk", authentication, bulkAddMarcomMrk); // Bulk Add
router.get("/getAllMrkMarcoms", authentication, getAllMrkMarcoms); // Get all
router.put("/updateMrkMarcom", authentication, updateMrkMarcom); // Update
router.patch("/toggleMrkMarcom/toggle/:id", authentication, toggleMrkMarcom); // Toggle enable/disable
router.delete("/deleteMrkMarcom/:id", authentication, deleteMrkMarcom); // Delete

//.....................NationalKeyAccounts.......................API..........................

router.post("/addNationalKeyAccount", authentication, addNationalKeyAccount); // Add
router.post("/bulkAddNationalKeyAccounts", authentication, bulkAddNationalKeyAccounts); // Bulk Add
router.get("/getNationalKeyAccounts", authentication, getAllNationalKeyAccounts); // Get all
router.put("/updateNationalKeyAccount", authentication, updateNationalKeyAccount); // Update
router.patch("/toggleNationalKeyAccount/toggle/:id", authentication, toggleNationalKeyAccount); // Toggle enable/disable
router.delete("/deleteNationalKeyAccount/:id", authentication, deleteNationalKeyAccount); // Delete


//.....................Segment Priority.......................API..........................

router.post("/addSegmentPriority", authentication, addSegmentPriority); // Add
router.post("/bulkAddSegmentPriority", authentication, bulkAddSegmentPriority); // Bulk Add
router.get("/getSegmentPriorities", authentication, getAllSegmentPriorities); // Get all
router.put("/updateSegmentPriority", authentication, updateSegmentPriority); // Update
router.patch("/toggleSegmentPriority/toggle/:id", authentication, toggleSegmentPriority); // Toggle enable/disable
router.delete("/deleteSegmentPriority/:id", authentication, deleteSegmentPriority); // Delete

//.....................BranchMaster.......................API..........................

router.post("/addBranchMaster", authentication, addBranchMaster); // Add
router.post("/bulkAddBranchMaster", authentication, bulkAddBranchMaster); // Bulk Add
router.get("/getBranchMasters", authentication, getAllBranchMasters); // Get all
router.put("/updateBranchMaster", authentication, updateBranchMaster); // Update
router.patch("/toggleBranchMaster/toggle/:id", authentication, toggleBranchMaster); // Toggle enable/disable
router.delete("/deleteBranchMaster/:id", authentication, deleteBranchMaster); // Delete

//.....................OtherData.......................API..........................

router.post("/addOtherData", authentication, addOtherData); // Add
router.post("/bulkAddOtherData", authentication, bulkAddOtherData); // Bulk Add
router.get("/getOtherData", authentication, getAllOtherData); // Get all
router.put("/updateOtherData", authentication, updateOtherData); // Update
router.patch("/toggleOtherData/toggle/:id", authentication, toggleOtherData); // Toggle enable/disable
router.delete("/deleteOtherData/:id", authentication, deleteOtherData); // Delete

//.....................Specialization Competence.......................API..........................

router.post("/addSpecializationCompetence", authentication, addSpecializationCompetence); // Add
router.post("/bulkAddSpecializationCompetence", authentication, bulkAddSpecializationCompetence); // Bulk Add
router.get("/getSpecializationCompetences", authentication, getAllSpecializationCompetences); // Get all
router.get("/getSpecializationCompetenceById/:id", authentication, getSpecializationCompetenceById); // Get by ID
router.put("/updateSpecializationCompetence", authentication, updateSpecializationCompetence); // Update
router.patch("/toggleSpecializationCompetence/toggle/:id", authentication, toggleSpecializationCompetence); // Toggle enable/disable
router.delete("/deleteSpecializationCompetence/:id", authentication, deleteSpecializationCompetence); // Delete

//.....................Competence Level.......................API..........................

router.post("/addCompetenceLevel", authentication, addCompetenceLevel); // Add
router.post("/bulkAddCompetenceLevel", authentication, bulkAddCompetenceLevel); // Bulk Add
router.get("/getCompetenceLevels", authentication, getAllCompetenceLevels); // Get all
router.get("/getCompetenceLevelById/:id", authentication, getCompetenceLevelById); // Get by ID
router.put("/updateCompetenceLevel", authentication, updateCompetenceLevel); // Update
router.patch("/toggleCompetenceLevel/toggle/:id", authentication, toggleCompetenceLevel); // Toggle enable/disable
router.delete("/deleteCompetenceLevel/:id", authentication, deleteCompetenceLevel); // Delete

//.....................Monthly Metting Master...........................

//..............File Master..........................

router.post("/addFile", authentication, addFile); // Add
router.get("/getAllFiles", authentication, getAllFiles); // Get all
router.put("/updateFile", authentication, updateFile); // Update
router.patch("/toggleFile/toggle/:id", authentication, toggleFile); // Toggle enable/disable
router.delete("/deleteFile/:id", authentication, deleteFile); // Delete

//...............Department Master......................

router.post("/addDepartment", authentication, addDepartment); // Add
router.get("/getDepartments", authentication, getDepartments); // Get all
router.put("/updateDepartment", authentication, updateDepartment); // Update
router.patch("/toggleDepartment/toggle/:id", authentication, toggleDepartment); // Toggle enable/disable
router.delete("/deleteDepartment/:id", authentication, deleteDepartment); // Delete

//Dealer Investment API
//...............Equpment Multiplier Master......................

router.post("/addEquipmentMlp", authentication, addEquipmentMlp); // Add
router.get("/getEquipmentsMlp", authentication, getEquipmentsMlp); // Get all
router.put("/updateEquipmentMlp", authentication, updateEquipmentMlp); // Update
router.patch("/toggleEquipmentMlp/toggle/:id", authentication, toggleEquipmentMlp); // Toggle enable/disable
router.delete("/deleteEquipmentMlp/:id", authentication, deleteEquipmentMlp); // Delete

//...............Financial Multiplier Master......................

router.post("/addFinancial", authentication, addFinancial); // Add
router.get("/getFinancials", authentication, getFinancials); // Get all
router.put("/updateFinancial", authentication, updateFinancial); // Update
router.patch("/toggleFinancial/toggle/:id", authentication, toggleFinancial); // Toggle enable/disable
router.delete("/deleteFinancial/:id", authentication, deleteFinancial); // Delete

//DFHM API...................................

//....................Balance Sheet API.................
router.post("/addBalanceSheet", authentication, addBalanceSheet); // Add
router.post("/bulkAddBalanceSheet", authentication, bulkAddBalanceSheet); // Bulk Add
router.get("/getBalanceSheets", authentication, getBalanceSheets); // Get all
router.put("/updateBalanceSheet", authentication, updateBalanceSheet); // Update
router.patch("/toggleBalanceSheet/toggle/:id", authentication, toggleBalanceSheet); // Toggle enable/disable
router.delete("/deleteBalanceSheet/:id", authentication, deleteBalanceSheet); // Delete

//...................Head Count API...........................

router.post("/addHeadCount", authentication, addHeadCount); // Add
router.post("/bulkAddHeadCount", authentication, bulkAddHeadCount); // Bulk Add
router.get("/getHeadCounts", authentication, getHeadCounts); // Get all
router.put("/updateHeadCount", authentication, updateHeadCount); // Update
router.patch("/toggleHeadCount/toggle/:id", authentication, toggleHeadCount); // Toggle enable/disable
router.delete("/deleteHeadCount/:id", authentication, deleteHeadCount); // Delete


//.....................PL API..................................

router.post("/addPL", authentication, addPL); // Add
router.post("/bulkAddPL", authentication, bulkAddPL); // Bulk Add
router.get("/getPLs", authentication, getPLs); // Get all
router.put("/updatePL", authentication, updatePL); // Update
router.patch("/togglePL/toggle/:id", authentication, togglePL); // Toggle enable/disable
router.delete("/deletePL/:id", authentication, deletePL); // Delete


//.........................Ratio Analysis..................
router.post("/addRatioAnalysis", authentication, addRatioAnalysis); // Add
router.post("/bulkAddRatioAnalysis", authentication, bulkAddRatioAnalysis); // Bulk Add
router.get("/getRatioAnalysis", authentication, getRatioAnalysis); // Get all
router.put("/updateRatioAnalysis", authentication, updateRatioAnalysis); // Update
router.patch("/toggleRatioAnalysis/toggle/:id", authentication, toggleRatioAnalysis); // Toggle enable/disable
router.delete("/deleteRatioAnalysis/:id", authentication, deleteRatioAnalysis); // Delete


//Media Library API...



//.....................PDP Dashboard Media.......................API..........................

router.post("/addPdpDashboardMedia", authentication, addPdpDashboardMedia); // Add
router.get("/getPdpDashboardMedia", authentication, getAllPdpDashboardMedia); // Get all
router.get("/getPdpDashboardMedia/:id", authentication, getPdpDashboardMediaById); // Get by ID
router.put("/updatePdpDashboardMedia", authentication, updatePdpDashboardMedia); // Update
router.patch("/togglePdpDashboardMedia/toggle/:id", authentication, togglePdpDashboardMedia); // Toggle enable/disable
router.delete("/deletePdpDashboardMedia/:id", authentication, deletePdpDashboardMedia); // Delete

//.....................Scorecard Dashboard Media.......................API..........................

router.post("/addScorecardDashboardMedia", authentication, addScorecardDashboardMedia); // Add
router.get("/getScorecardDashboardMedia", authentication, getAllScorecardDashboardMedia); // Get all
router.get("/getScorecardDashboardMedia/:id", authentication, getScorecardDashboardMediaById); // Get by ID
router.put("/updateScorecardDashboardMedia", authentication, updateScorecardDashboardMedia); // Update
router.patch("/toggleScorecardDashboardMedia/toggle/:id", authentication, toggleScorecardDashboardMedia); // Toggle enable/disable
router.delete("/deleteScorecardDashboardMedia/:id", authentication, deleteScorecardDashboardMedia); // Delete

//.....................Monthly Meeting Media.......................API..........................

router.post("/addMontlyMeetingMedia", authentication, addMontlyMeetingMedia); // Add
router.get("/getMontlyMeetingMedia", authentication, getAllMontlyMeetingMedia); // Get all
router.get("/getMontlyMeetingMedia/:id", authentication, getMontlyMeetingMediaById); // Get by ID
router.put("/updateMontlyMeetingMedia", authentication, updateMontlyMeetingMedia); // Update
router.patch("/toggleMontlyMeetingMedia/toggle/:id", authentication, toggleMontlyMeetingMedia); // Toggle enable/disable
router.delete("/deleteMontlyMeetingMedia/:id", authentication, deleteMontlyMeetingMedia); // Delete

//.....................Dealer Investment Media.......................API..........................

router.post("/addDealerInvestmentMedia", authentication, addDealerInvestmentMedia); // Add
router.get("/getDealerInvestmentMedia", authentication, getAllDealerInvestmentMedia); // Get all
router.get("/getDealerInvestmentMedia/:id", authentication, getDealerInvestmentMediaById); // Get by ID
router.put("/updateDealerInvestmentMedia", authentication, updateDealerInvestmentMedia); // Update
router.patch("/toggleDealerInvestmentMedia/toggle/:id", authentication, toggleDealerInvestmentMedia); // Toggle enable/disable
router.delete("/deleteDealerInvestmentMedia/:id", authentication, deleteDealerInvestmentMedia); // Delete


//.....................DFHM  Media.......................API..........................

router.post("/addDfhmMedia", authentication, addDfhmMedia); // Add
router.get("/getAllDfhmMedia", authentication, getAllDfhmMedia); // Get all
router.get("/getDfhmMediaById/:id", authentication, getDfhmMediaById); // Get by ID
router.put("/updateDfhmMedia", authentication, updateDfhmMedia); // Update
router.patch("/toggleDfhmMedia/toggle/:id", authentication, toggleDfhmMedia); // Toggle enable/disable
router.delete("/deleteDfhmMedia/:id", authentication, deleteDfhmMedia); // Delete




//Main Monthly Meeting 

//.....................MonthlyMeeting.......................API..........................

router.post("/addMonthlyMeeting", authentication, addMonthlyMeeting); // Add
router.get("/getMonthlyMeetings", authentication, getAllMonthlyMeetings); // Get all
router.get("/getMonthlyMeeting/:id", authentication, getMonthlyMeetingById); // Get by ID
router.put("/updateMonthlyMeeting", authentication, updateMonthlyMeeting); // Update
router.delete("/deleteMonthlyMeeting/:id", authentication, deleteMonthlyMeeting); // Delete
router.get("/getUsersByMonthlyMeetingDealer/:monthlyMeetingid", authentication, getUsersByMonthlyMeetingDealer); // Get users by monthly meeting dealer

//.....................ActionItem.......................API..........................

router.post("/addActionItem", authentication, addActionItem); // Add
router.get("/getActionItems", authentication, getAllActionItems); // Get all
router.get("/getActionItem/:id", authentication, getActionItemById); // Get by ID
router.get("/getActionItemsByMeeting/:meeting_id", authentication, getActionItemsByMeeting); // Get by meeting ID
router.put("/updateActionItem", authentication, updateActionItem); // Update
router.patch("/updateActionItemStatus/:id", authentication, updateActionItemStatus); // Update status only
router.delete("/deleteActionItem/:id", authentication, deleteActionItem); // Delete

//.....................ActionLog.......................API..........................

router.post("/addActionLog", authentication, addActionLog); // Add
router.get("/getActionLogs", authentication, getAllActionLogs); // Get all
router.get("/getActionLog/:id", authentication, getActionLogById); // Get by ID
router.get("/getActionLogsByActionItem/:action_item_id", authentication, getActionLogsByActionItem); // Get by action item ID
router.get("/getTargetDate/:action_item_id", authentication, getTargetDate);
router.put("/updateActionLog/:id", authentication, updateActionLog); // Update
router.delete("/deleteActionLog/:id", authentication, deleteActionLog); // Delete

//.....................MonthlyMeetingTemplate.......................API..........................

router.post("/addMonthlyMeetingTemplate", authentication, addMonthlyMeetingTemplate); // Add
router.get("/getMonthlyMeetingTemplates", authentication, getAllMonthlyMeetingTemplates); // Get all
router.get("/getMonthlyMeetingTemplate/:id", authentication, getMonthlyMeetingTemplateById); // Get by ID
router.get("/getMonthlyMeetingTemplatesByMonthlyMeeting/:monthly_meeting", authentication, getMonthlyMeetingTemplatesByMonthlyMeeting); // Get by monthly meeting ID
router.put("/updateMonthlyMeetingTemplate/:id", authentication, updateMonthlyMeetingTemplate); // Update
router.post("/bulkUploadMonthlyMeetingTemplates", authentication, bulkUploadMonthlyMeetingTemplates); // Bulk upload files
router.delete("/deleteMonthlyMeetingTemplate/:id", authentication, deleteMonthlyMeetingTemplate); // Delete



//.....................PDP.......................API..........................

router.post("/addPdp", authentication, addPdp); // Add
router.get("/getAllPdp", authentication, getAllPdp); // Get all
router.get("/getAllPdpWithActionItemCounts", authentication, getAllPdpWithActionItemCounts); // Get all with action item counts
router.get("/getPdp/:id", authentication, getPdpById); // Get by ID
router.put("/updatePdp", authentication, updatePdp); // Update
router.put("/pdpStatusChange", authentication, pdpStatusChange); // Update status
router.put("/updatePdpMeetingDetails", authentication, updatePdpMeetingDetails); // Update meeting details
router.delete("/deletePdp/:id", authentication, deletePdp); // Delete

//.....................PDP Action Item.......................API..........................

router.post("/addPdpActionItem", authentication, addPdpActionItem); // Add
router.get("/getAllPdpActionItem", authentication, getAllPdpActionItem); // Get all
router.get("/getPdpActionItem/:id", authentication, getPdpActionItemById); // Get by ID
router.put("/updatePdpActionItem", authentication, updatePdpActionItem); // Update
router.delete("/deletePdpActionItem/:id", authentication, deletePdpActionItem); // Delete

//.....................PDP Action Log.......................API..........................

router.post("/addPdpActionLog", authentication, addPdpActionLog); // Add
router.get("/getPdpActionLogs", authentication, getAllPdpActionLogs); // Get all
router.get("/getPdpActionLog/:id", authentication, getPdpActionLogById); // Get by ID
router.get("/getPdpActionLogsByActionItem/:pdp_action_item", authentication, getPdpActionLogsByActionItem); // Get by PDP action item ID
router.get("/getPdpTargetDate/:pdp_action_item", authentication, getPdpTargetDate); // Get target dates
router.put("/updatePdpActionLog/:id", authentication, updatePdpActionLog); // Update
router.delete("/deletePdpActionLog/:id", authentication, deletePdpActionLog); // Delete

//.....................PDP Equipment.......................API..........................

router.post("/addPdpEquipment", authentication, addPdpEquipment); // Add
router.get("/getAllPdpEquipments", authentication, getAllPdpEquipments); // Get all
router.get("/getPdpEquipment/:id", authentication, getPdpEquipmentById); // Get by ID
router.get("/getPdpEquipmentsByPdpId/:pdpId", authentication, getPdpEquipmentsByPdpId); // Get by PDP ID
router.put("/updatePdpEquipment", authentication, updatePdpEquipment); // Update
router.put("/updateMultiplePdpEquipments", authentication, updateMultiplePdpEquipments); // Update
router.delete("/deletePdpEquipment/:id", authentication, deletePdpEquipment); // Delete


//.....................PDP Uptime Parts.......................API..........................

router.post("/addPdpUptimeParts", authentication, addPdpUptimeParts); // Add
router.get("/getAllPdpUptimeParts", authentication, getAllPdpUptimeParts); // Get all
router.get("/getPdpUptimeParts/:id", authentication, getPdpUptimePartsById); // Get by ID
router.get("/getPdpUptimePartsByPdpId/:pdpId", authentication, getPdpUptimePartsByPdpId); // Get by PDP ID
router.put("/updatePdpUptimeParts", authentication, updatePdpUptimeParts); // Update
router.put("/updateMultiplePdpUptimeParts", authentication, updateMultiplePdpUptimeParts); // Update
router.delete("/deletePdpUptimeParts/:id", authentication, deletePdpUptimeParts); // Delete

//.....................PDP Infrastructure.......................API..........................

router.post("/addPdpInfrastructure", authentication, addPdpInfrastructure); // Add
router.get("/getAllPdpInfrastructures", authentication, getAllPdpInfrastructures); // Get all
router.get("/getPdpInfrastructure/:id", authentication, getPdpInfrastructureById); // Get by ID
router.get("/getPdpInfrastructuresByPdpId/:pdpId", authentication, getPdpInfrastructuresByPdpId); // Get by PDP ID
router.put("/updatePdpInfrastructure", authentication, updatePdpInfrastructure); // Update
router.delete("/deletePdpInfrastructure/:id", authentication, deletePdpInfrastructure); // Delete


//.....................PDP Infrastructure Location Count.......................API..........................

router.post("/addPdpInfrastructureLocationCount", authentication, addPdpInfrastructureLocationCount); // Add
router.get("/getAllPdpInfrastructureLocationCounts", authentication, getAllPdpInfrastructureLocationCounts); // Get all
router.get("/getPdpInfrastructureLocationCount/:id", authentication, getPdpInfrastructureLocationCountById); // Get by ID
router.get("/getPdpInfrastructureLocationCountsByPdpId/:pdpId", authentication, getPdpInfrastructureLocationCountsByPdpId); // Get by PDP ID
router.get("/getPdpInfrastructureLocationCountsByPdpInfrastructureId/:pdpInfrastructureId", authentication, getPdpInfrastructureLocationCountsByPdpInfrastructureId); // Get by PDP Infrastructure ID
router.put("/updatePdpInfrastructureLocationCount", authentication, updatePdpInfrastructureLocationCount); // Update
router.delete("/deletePdpInfrastructureLocationCount/:id", authentication, deletePdpInfrastructureLocationCount); // Delete

//.....................PDP Infrastructure Vehicle.......................API..........................

router.post("/addPdpInfrastructureVehicle", authentication, addPdpInfrastructureVehicle); // Add
router.get("/getAllPdpInfrastructureVehicles", authentication, getAllPdpInfrastructureVehicles); // Get all
router.get("/getPdpInfrastructureVehicle/:id", authentication, getPdpInfrastructureVehicleById); // Get by ID
router.get("/getPdpInfrastructureVehiclesByPdpId/:pdpId", authentication, getPdpInfrastructureVehiclesByPdpId); // Get by PDP ID
router.get("/getPdpInfrastructureVehiclesByPdpInfrastructureId/:pdpInfrastructureId", authentication, getPdpInfrastructureVehiclesByPdpInfrastructureId); // Get by PDP Infrastructure ID
router.put("/updatePdpInfrastructureVehicle", authentication, updatePdpInfrastructureVehicle); // Update
router.delete("/deletePdpInfrastructureVehicle/:id", authentication, deletePdpInfrastructureVehicle); // Delete

//.....................PDP Infrastructure Tools.......................API..........................

router.post("/addPdpInfrastructureTool", authentication, addPdpInfrastructureTool); // Add
router.get("/getAllPdpInfrastructureTools", authentication, getAllPdpInfrastructureTools); // Get all
router.get("/getPdpInfrastructureTool/:id", authentication, getPdpInfrastructureToolById); // Get by ID
router.get("/getPdpInfrastructureToolsByPdpId/:pdpId", authentication, getPdpInfrastructureToolsByPdpId); // Get by PDP ID
router.get("/getPdpInfrastructureToolsByPdpInfrastructureId/:pdpInfrastructureId", authentication, getPdpInfrastructureToolsByPdpInfrastructureId); // Get by PDP Infrastructure ID
router.put("/updatePdpInfrastructureTool", authentication, updatePdpInfrastructureTool); // Update
router.delete("/deletePdpInfrastructureTool/:id", authentication, deletePdpInfrastructureTool); // Delete

//.....................PDP Infrastructure Assets.......................API..........................

router.post("/addPdpInfrastructureAsset", authentication, addPdpInfrastructureAsset); // Add
router.get("/getAllPdpInfrastructureAssets", authentication, getAllPdpInfrastructureAssets); // Get all
router.get("/getPdpInfrastructureAsset/:id", authentication, getPdpInfrastructureAssetById); // Get by ID
router.get("/getPdpInfrastructureAssetsByPdpId/:pdpId", authentication, getPdpInfrastructureAssetsByPdpId); // Get by PDP ID
router.get("/getPdpInfrastructureAssetsByPdpInfrastructureId/:pdpInfrastructureId", authentication, getPdpInfrastructureAssetsByPdpInfrastructureId); // Get by PDP Infrastructure ID
router.put("/updatePdpInfrastructureAsset", authentication, updatePdpInfrastructureAsset); // Update
router.delete("/deletePdpInfrastructureAsset/:id", authentication, deletePdpInfrastructureAsset); // Delete



//.....................PDP Territory Focus.......................API..........................

router.post("/addPdpTerritoryFocus", authentication, addPdpTerritoryFocus); // Add
router.get("/getAllPdpTerritoryFocus", authentication, getAllPdpTerritoryFocus); // Get all
router.get("/getPdpTerritoryFocus/:id", authentication, getPdpTerritoryFocusById); // Get by ID
router.get("/getPdpTerritoryFocusByPdpId/:pdpId", authentication, getPdpTerritoryFocusByPdpId); // Get by PDP ID
router.put("/updatePdpTerritoryFocus", authentication, updatePdpTerritoryFocus); // Update
router.delete("/deletePdpTerritoryFocus/:id", authentication, deletePdpTerritoryFocus); // Delete

//.....................PDP Territory Focus Entries.......................API..........................

router.post("/addPdpTerritoryFocusEntry", authentication, addPdpTerritoryFocusEntry); // Add
router.get("/getAllPdpTerritoryFocusEntries", authentication, getAllPdpTerritoryFocusEntries); // Get all
router.get("/getPdpTerritoryFocusEntry/:id", authentication, getPdpTerritoryFocusEntryById); // Get by ID
router.get("/getPdpTerritoryFocusEntriesByPdpId/:pdpId", authentication, getPdpTerritoryFocusEntriesByPdpId); // Get by PDP ID
router.get("/getPdpTerritoryFocusEntriesByTerritoryFocusId/:territoryFocusId", authentication, getPdpTerritoryFocusEntriesByTerritoryFocusId); // Get by Territory Focus ID
router.put("/updatePdpTerritoryFocusEntry", authentication, updatePdpTerritoryFocusEntry); // Update
router.delete("/deletePdpTerritoryFocusEntry/:id", authentication, deletePdpTerritoryFocusEntry); // Delete

//.....................PDP Territory Focus Entries Stats.......................API..........................

router.post("/addPdpTerritoryFocusEntriesStats", authentication, addPdpTerritoryFocusEntriesStats); // Add
router.get("/getAllPdpTerritoryFocusEntriesStats", authentication, getAllPdpTerritoryFocusEntriesStats); // Get all
router.get("/getPdpTerritoryFocusEntriesStats/:id", authentication, getPdpTerritoryFocusEntriesStatsById); // Get by ID
router.get("/getPdpTerritoryFocusEntriesStatsByPdpId/:pdpId", authentication, getPdpTerritoryFocusEntriesStatsByPdpId); // Get by PDP ID
router.put("/updatePdpTerritoryFocusEntriesStats", authentication, updatePdpTerritoryFocusEntriesStats); // Update
router.delete("/deletePdpTerritoryFocusEntriesStats/:id", authentication, deletePdpTerritoryFocusEntriesStats); // Delete




//.....................PDP Competence Development.......................API..........................

router.post("/addPdpCompetenceDevelopment", authentication, addPdpCompetenceDevelopment); // Add
router.get("/getPdpCompetenceDevelopments", authentication, getAllPdpCompetenceDevelopments); // Get all
router.get("/getPdpCompetenceDevelopment/:id", authentication, getPdpCompetenceDevelopmentById); // Get by ID
router.get("/getPdpCompetenceDevelopmentsByPdpId/:pdpId", authentication, getPdpCompetenceDevelopmentsByPdpId); // Get by PDP ID
router.get("/getActiveMachines/:pdpId", authentication, getActiveMachines); // Get by PDP ID
router.put("/updatePdpCompetenceDevelopment", authentication, updatePdpCompetenceDevelopment); // Update
router.put("/updateMultiplePdpCompeDev", authentication, updateMultiplePdpCompeDev); // Update
router.delete("/deletePdpCompetenceDevelopment/:id", authentication, deletePdpCompetenceDevelopment); // Delete

//.....................PDP Marcom Branding.......................API..........................

router.get("/getAllPdpMarcomBranding", authentication, getAllPdpMarcomBranding); // Get all
router.get("/getPdpMarcomBranding/:id", authentication, getPdpMarcomBrandingById); // Get by ID
router.get("/getPdpMarcomBrandingByPdpId/:pdpId", authentication, getPdpMarcomBrandingByPdpId); // Get by PDP ID
router.put("/updatePdpMarcomBranding", authentication, updatePdpMarcomBranding); // Update (supports file upload via form data)
router.put("/updateMultiplePdpMarcomBranding", authentication, updateMultiplePdpMarcomBranding); // Update (supports file upload via form data)
router.put("/updatePdpMarcomSupdoc", authentication, updatePdpMarcomSupdoc); // Update (supports file upload via form data)
router.delete("/deletePdpMarcomSupdoc/:id", authentication, deletePdpMarcomSupdoc); // Update (supports file upload via form data)
router.delete("/deletePdpMarcomBranding/:id", authentication, deletePdpMarcomBranding); // Delete

//.....................PDP Marcom Marketing.......................API..........................

router.get("/getAllPdpMarcomMarketing", authentication, getAllPdpMarcomMarketing); // Get all
router.get("/getPdpMarcomMarketing/:id", authentication, getPdpMarcomMarketingById); // Get by ID
router.get("/getPdpMarcomMarketingByPdpId/:pdpId", authentication, getPdpMarcomMarketingByPdpId); // Get by PDP ID
router.put("/updatePdpMarcomMarketing", authentication, updatePdpMarcomMarketing); // Update
router.put("/updateMultiplePdpMarcomMarketing", authentication, updateMultiplePdpMarcomMarketing); // Update
router.delete("/deletePdpMarcomMarketing/:id", authentication, deletePdpMarcomMarketing); // Delete



//.....................PDP Upload Files.......................API..........................

router.post("/addPdpUploadFile", authentication, addPdpUploadFile); // Add (supports file upload via form data)
router.get("/getAllPdpUploadFiles", authentication, getAllPdpUploadFiles); // Get all
router.get("/getPdpUploadFile/:id", authentication, getPdpUploadFileById); // Get by ID
router.get("/getPdpUploadFilesByPdpId/:pdpId", authentication, getPdpUploadFilesByPdpId); // Get by PDP ID
router.put("/updatePdpUploadFile", authentication, updatePdpUploadFile); // Update (supports file upload via form data)
router.delete("/deletePdpUploadFile/:id", authentication, deletePdpUploadFile); // Delete (soft delete)

//.....................PDP Signoff.......................API..........................

router.post("/addPdpSignoff", authentication, addPdpSignoff); // Add
router.get("/getAllPdpSignoffs", authentication, getAllPdpSignoffs); // Get all
router.get("/getPdpSignoff/:id", authentication, getPdpSignoffById); // Get by ID
router.get("/getPdpSignoffsByPdpId/:pdpId", authentication, getPdpSignoffsByPdpId); // Get by PDP ID
router.get("/getPdpSignoffsByUserId/:userId", authentication, getPdpSignoffsByUserId); // Get by User ID
router.put("/updatePdpSignoff", authentication, updatePdpSignoff); // Update
router.put("/signPdpSignoff", authentication, signPdpSignoff); // Sign off (convenience method)
router.delete("/deletePdpSignoff/:id", authentication, deletePdpSignoff); // Delete

//.....................PDP Others.......................API..........................

router.post("/addPdpOthers", authentication, addPdpOthers); // Add
router.get("/getAllPdpOthers", authentication, getAllPdpOthers); // Get all
router.get("/getPdpOthers/:id", authentication, getPdpOthersById); // Get by ID
router.get("/getPdpOthersByPdpId/:pdpId", authentication, getPdpOthersByPdpId); // Get by PDP ID
router.put("/updatePdpOthers", authentication, updatePdpOthers); // Update (supports file upload via form data)
router.delete("/deletePdpOthers/:id", authentication, deletePdpOthers); // Delete



//.....................Scorecard.......................API..........................

router.post("/addScorecard", authentication, addScorecard); // Add
router.get("/getAllScorecards", authentication, getAllScorecards); // Get all
router.get("/getScorecard/:id", authentication, getScorecardById); // Get by ID
router.put("/updateScorecard", authentication, updateScorecard); // Update
router.put("/completeScorecard/:id", authentication, completeScorecard); // Update
router.get("/bulkCompleteScorecard", authentication, bulkCompleteScorecard); // Bulk complete Q4 scorecards
router.patch("/toggleScorecard/toggle/:id", authentication, toggleScorecard); // Toggle enable/disable
router.delete("/deleteScorecard/:id", authentication, deleteScorecard); // Delete

//.....................Scorecard Score View.......................API..........................

router.get("/getAllScorecardScoreViews", authentication, getAllScorecardScoreViews); // Get all
router.get("/getScorecardScoreView/:id", authentication, getScorecardScoreViewById); // Get by ID
router.get("/getScorecardScoreViewsByScorecardId/:scorecard_id", authentication, getScorecardScoreViewsByScorecardId); // Get by Scorecard ID
router.put("/updateScorecardScoreView", authentication, updateScorecardScoreView); // Update
router.put("/bulkToggleScorecardScoreViewExclusion", authentication, bulkToggleScorecardScoreViewExclusion); // Bulk toggle exclusion
router.delete("/deleteScorecardScoreView/:id", authentication, deleteScorecardScoreView); // Delete

//.....................Scorecard Score View Doc.......................API..........................

router.post("/addScorecardScoreViewDoc", authentication, addScorecardScoreViewDoc); // Add
router.get("/getAllScorecardScoreViewDocs", authentication, getAllScorecardScoreViewDocs); // Get all
router.get("/getScorecardScoreViewDoc/:id", authentication, getScorecardScoreViewDocById); // Get by ID
router.get("/getScorecardScoreViewDocsByScorecardId/:scorecard_id", authentication, getScorecardScoreViewDocsByScorecardId); // Get by Scorecard ID
router.put("/updateScorecardScoreViewDoc", authentication, updateScorecardScoreViewDoc); // Update
router.patch("/toggleScorecardScoreViewDoc/toggle/:id", authentication, toggleScorecardScoreViewDoc); // Toggle enable/disable
router.delete("/deleteScorecardScoreViewDoc/:id", authentication, deleteScorecardScoreViewDoc); // Delete

//.....................Scorecard Action Items.......................API..........................

router.post("/addScorecardActionItem", authentication, addScorecardActionItem); // Add
router.get("/getAllScorecardActionItems", authentication, getAllScorecardActionItems); // Get all
router.get("/getScorecardActionItem/:id", authentication, getScorecardActionItemById); // Get by ID
router.get("/getScorecardActionItemsByScoreId/:scorecard_score_id", authentication, getScorecardActionItemsByScoreId); // Get by scorecard score ID
router.put("/updateScorecardActionItem", authentication, updateScorecardActionItem); // Update
router.patch("/toggleScorecardActionItem/toggle/:id", authentication, toggleScorecardActionItem); // Toggle enable/disable
router.delete("/deleteScorecardActionItem/:id", authentication, deleteScorecardActionItem); // Delete

//.....................Scorecard Action Logs.......................API..........................

router.post("/addScorecardActionLog", authentication, addScorecardActionLog); // Add
router.get("/getAllScorecardActionLogs", authentication, getAllScorecardActionLogs); // Get all
router.get("/getScorecardActionLog/:id", authentication, getScorecardActionLogById); // Get by ID
router.get("/getScorecardActionLogsByActionItemId/:action_item_id", authentication, getScorecardActionLogsByActionItemId); // Get by action item ID
router.get("/getFirstLogCommentsByActionItemId/:action_item_id", authentication, getFirstLogCommentsByActionItemId); // Get first log comments by action item ID
router.put("/updateScorecardActionLog", authentication, updateScorecardActionLog); // Update
router.delete("/deleteScorecardActionLog/:id", authentication, deleteScorecardActionLog); // Delete
// .............................................................


//....................Dealer Investment Main API.................
router.get("/getAllDealerInvestment", authentication, getAllDealerInvestment); // Get all
router.get("/getDealerInvestment/:id", authentication, getDealerInvestmentById); // Get by ID
router.get("/getDealerInvestmentByPdpId/:pdpId", authentication, getDealerInvestmentBypdpId); // Get by PDP ID
router.put("/updateDealerInvestment", authentication, updateDealerInvestment); // Update
router.put("/mbpStatusEquipmentsChange", authentication, mbpStatusEquipmentsChange); // Update MBP Status Equipments
router.put("/mbpStatusUapChange", authentication, mbpStatusUapChange); // Update MBP Status UAP
router.delete("/deleteDealerInvestment/:id", authentication, deleteDealerInvestment); // Delete

//.....................Dealer Investment Infrastructure API..........................
router.get("/getAllDealerInvestmentInfrastructure", authentication, getAllDealerInvestmentInfrastructure); // Get all
router.get("/getDealerInvestmentInfrastructure/:id", authentication, getDealerInvestmentInfrastructureById); // Get by ID
router.get("/getDealerInvestmentInfrastructureByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentInfrastructureByDealerInvestmentId); // Get by Dealer Investment ID
router.get("/getDealerInvestmentInfrastructureByPdpId/:pdpId", authentication, getDealerInvestmentInfrastructureByPdpId); // Get by PDP ID
router.put("/updateDealerInvestmentInfrastructure", authentication, updateDealerInvestmentInfrastructure); // Update
router.put("/updateMultipleDealerInvestmentInfrastructure", authentication, updateMultipleDealerInvestmentInfrastructure); // Update multiple rows
router.delete("/deleteDealerInvestmentInfrastructure/:id", authentication, deleteDealerInvestmentInfrastructure); // Delete

//.....................Dealer Investment Competence API..........................
router.get("/getAllDealerInvestmentCompetence", authentication, getAllDealerInvestmentCompetence); // Get all
router.get("/getDealerInvestmentCompetence/:id", authentication, getDealerInvestmentCompetenceById); // Get by ID
router.get("/getDealerInvestmentCompetenceByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentCompetenceByDealerInvestmentId); // Get by Dealer Investment ID
router.get("/getDealerInvestmentCompetenceByPdpId/:pdpId", authentication, getDealerInvestmentCompetenceByPdpId); // Get by PDP ID
router.put("/updateDealerInvestmentCompetence", authentication, updateDealerInvestmentCompetence); // Update
router.put("/updateMultipleDealerInvestmentCompetence", authentication, updateMultipleDealerInvestmentCompetence); // Update multiple rows
router.delete("/deleteDealerInvestmentCompetence/:id", authentication, deleteDealerInvestmentCompetence); // Delete

//.....................Dealer Investment Machine Population API..........................
router.get("/getAllDealerInvestmentMachinePopulation", authentication, getAllDealerInvestmentMachinePopulation); // Get all
router.get("/getDealerInvestmentMachinePopulation/:id", authentication, getDealerInvestmentMachinePopulationById); // Get by ID
router.get("/getDealerInvestmentMachinePopulationByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentMachinePopulationByDealerInvestmentId); // Get by Dealer Investment ID
router.get("/getDealerInvestmentMachinePopulationByPdpId/:pdpId", authentication, getDealerInvestmentMachinePopulationByPdpId); // Get by PDP ID
router.put("/updateDealerInvestmentMachinePopulation", authentication, updateDealerInvestmentMachinePopulation); // Update
router.put("/updateMultipleDealerInvestmentMachinePopulation", authentication, updateMultipleDealerInvestmentMachinePopulation); // Update multiple rows
router.delete("/deleteDealerInvestmentMachinePopulation/:id", authentication, deleteDealerInvestmentMachinePopulation); // Delete

//.....................Dealer Investment Equipment MBP API..........................
router.get("/getAllDealerInvestmentEquipmentMbp", authentication, getAllDealerInvestmentEquipmentMbp); // Get all
router.get("/getDealerInvestmentEquipmentMbp/:id", authentication, getDealerInvestmentEquipmentMbpById); // Get by ID
router.get("/getDealerInvestmentEquipmentMbpByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentEquipmentMbpByDealerInvestmentId); // Get by Dealer Investment ID
router.get("/getDealerInvestmentEquipmentMbpByPdpId/:pdpId", authentication, getDealerInvestmentEquipmentMbpByPdpId); // Get by PDP ID
router.put("/updateDealerInvestmentEquipmentMbp", authentication, updateDealerInvestmentEquipmentMbp); // Update
router.put("/updateMultipleDealerInvestmentEquipmentMbp", authentication, updateMultipleDealerInvestmentEquipmentMbp); // Update multiple rows
router.delete("/deleteDealerInvestmentEquipmentMbp/:id", authentication, deleteDealerInvestmentEquipmentMbp); // Delete

//.....................Dealer Investment Equipment Projection API..........................
router.get("/getAllDealerInvestmentEquipmentProjection", authentication, getAllDealerInvestmentEquipmentProjection); // Get all
router.get("/getDealerInvestmentEquipmentProjection/:id", authentication, getDealerInvestmentEquipmentProjectionById); // Get by ID
router.get("/getDealerInvestmentEquipmentProjectionByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentEquipmentProjectionByDealerInvestmentId); // Get by Dealer Investment ID
router.get("/getDealerInvestmentEquipmentProjectionByPdpId/:pdpId", authentication, getDealerInvestmentEquipmentProjectionByPdpId); // Get by PDP ID
router.put("/updateDealerInvestmentEquipmentProjection", authentication, updateDealerInvestmentEquipmentProjection); // Update
router.put("/updateMultipleDealerInvestmentEquipmentProjection", authentication, updateMultipleDealerInvestmentEquipmentProjection); // Update multiple rows
router.delete("/deleteDealerInvestmentEquipmentProjection/:id", authentication, deleteDealerInvestmentEquipmentProjection); // Delete

//.....................Dealer Investment Equipment Actuals API..........................
router.get("/getAllDealerInvestmentEquipmentActuals", authentication, getAllDealerInvestmentEquipmentActuals); // Get all
router.get("/getDealerInvestmentEquipmentActuals/:id", authentication, getDealerInvestmentEquipmentActualsById); // Get by ID
router.get("/getDealerInvestmentEquipmentActualsByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentEquipmentActualsByDealerInvestmentId); // Get by Dealer Investment ID
router.get("/getDealerInvestmentEquipmentActualsByPdpId/:pdpId", authentication, getDealerInvestmentEquipmentActualsByPdpId); // Get by PDP ID
router.put("/updateDealerInvestmentEquipmentActuals", authentication, updateDealerInvestmentEquipmentActuals); // Update
router.put("/updateMultipleDealerInvestmentEquipmentActuals", authentication, updateMultipleDealerInvestmentEquipmentActuals); // Update multiple rows
router.delete("/deleteDealerInvestmentEquipmentActuals/:id", authentication, deleteDealerInvestmentEquipmentActuals); // Delete

//.....................Dealer Investment Uptime MBP API..........................
router.get("/getAllDealerInvestmentUptimeMbp", authentication, getAllDealerInvestmentUptimeMbp); // Get all
router.get("/getDealerInvestmentUptimeMbp/:id", authentication, getDealerInvestmentUptimeMbpById); // Get by ID
router.get("/getDealerInvestmentUptimeMbpByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentUptimeMbpByDealerInvestmentId); // Get by Dealer Investment ID
router.get("/getDealerInvestmentUptimeMbpByPdpId/:pdpId", authentication, getDealerInvestmentUptimeMbpByPdpId); // Get by PDP ID
router.put("/updateDealerInvestmentUptimeMbp", authentication, updateDealerInvestmentUptimeMbp); // Update
router.put("/updateMultipleDealerInvestmentUptimeMbp", authentication, updateMultipleDealerInvestmentUptimeMbp); // Update multiple rows
router.delete("/deleteDealerInvestmentUptimeMbp/:id", authentication, deleteDealerInvestmentUptimeMbp); // Delete

//.....................Dealer Investment Uptime Projection API..........................
router.get("/getAllDealerInvestmentUptimeProjection", authentication, getAllDealerInvestmentUptimeProjection); // Get all
router.get("/getDealerInvestmentUptimeProjection/:id", authentication, getDealerInvestmentUptimeProjectionById); // Get by ID
router.get("/getDealerInvestmentUptimeProjectionByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentUptimeProjectionByDealerInvestmentId); // Get by Dealer Investment ID
router.get("/getDealerInvestmentUptimeProjectionByPdpId/:pdpId", authentication, getDealerInvestmentUptimeProjectionByPdpId); // Get by PDP ID
router.put("/updateDealerInvestmentUptimeProjection", authentication, updateDealerInvestmentUptimeProjection); // Update
router.put("/updateMultipleDealerInvestmentUptimeProjection", authentication, updateMultipleDealerInvestmentUptimeProjection); // Update multiple rows
router.delete("/deleteDealerInvestmentUptimeProjection/:id", authentication, deleteDealerInvestmentUptimeProjection); // Delete

//.....................Dealer Investment Uptime Actuals API..........................
router.get("/getAllDealerInvestmentUptimeActuals", authentication, getAllDealerInvestmentUptimeActuals); // Get all
router.get("/getDealerInvestmentUptimeActuals/:id", authentication, getDealerInvestmentUptimeActualsById); // Get by ID
router.get("/getDealerInvestmentUptimeActualsByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentUptimeActualsByDealerInvestmentId); // Get by Dealer Investment ID
router.get("/getDealerInvestmentUptimeActualsByPdpId/:pdpId", authentication, getDealerInvestmentUptimeActualsByPdpId); // Get by PDP ID
router.put("/updateDealerInvestmentUptimeActuals", authentication, updateDealerInvestmentUptimeActuals); // Update
router.put("/updateMultipleDealerInvestmentUptimeActuals", authentication, updateMultipleDealerInvestmentUptimeActuals); // Update multiple rows
router.delete("/deleteDealerInvestmentUptimeActuals/:id", authentication, deleteDealerInvestmentUptimeActuals); // Delete

//.....................Dealer Investment Vehicles API..........................
router.post("/addDealerInvestmentVehicle", authentication, addDealerInvestmentVehicle); // Add
router.get("/getAllDealerInvestmentVehicles", authentication, getAllDealerInvestmentVehicles); // Get all
router.get("/getDealerInvestmentVehicle/:id", authentication, getDealerInvestmentVehicleById); // Get by ID
router.get("/getDealerInvestmentVehiclesByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentVehiclesByDealerInvestmentId); // Get by dealer investment ID
router.put("/updateDealerInvestmentVehicle", authentication, updateDealerInvestmentVehicle); // Update
router.delete("/deleteDealerInvestmentVehicle/:id", authentication, deleteDealerInvestmentVehicle); // Delete

//.....................Dealer Investment File API..........................
router.post("/addDealerInvestmentFile", authentication, addDealerInvestmentFile); // Add (supports file upload via form data)
router.get("/getAllDealerInvestmentFiles", authentication, getAllDealerInvestmentFiles); // Get all
router.get("/getDealerInvestmentFile/:id", authentication, getDealerInvestmentFileById); // Get by ID
router.get("/getDealerInvestmentFilesByDealerInvestmentId/:dealer_investment_id", authentication, getDealerInvestmentFilesByDealerInvestmentId); // Get by dealer investment ID
router.put("/updateDealerInvestmentFile", authentication, updateDealerInvestmentFile); // Update (supports file upload via form data)
router.delete("/deleteDealerInvestmentFile/:id", authentication, deleteDealerInvestmentFile); // Delete

//.....................Inventory Allocation Management API..........................
router.post("/addInventoryAllocation", authentication, addInventoryAllocation); // Add
router.get("/getAllInventoryAllocations", authentication, getAllInventoryAllocations); // Get all
router.get("/getInventoryAllocation/:id", authentication, getInventoryAllocationById); // Get by ID
router.put("/updateInventoryAllocation", authentication, updateInventoryAllocation); // Update
router.patch("/toggleInventoryAllocationStatus/toggle/:id", authentication, toggleInventoryAllocationStatus); // Toggle active status
router.delete("/deleteInventoryAllocation/:id", authentication, deleteInventoryAllocation); // Delete (soft delete)

//.....................Inventory Data Allocation Management API..........................
router.get("/getAllInventoryDataAllocations", authentication, getAllInventoryDataAllocations); // Get all
router.get("/getInventoryDataAllocation/:id", authentication, getInventoryDataAllocationById); // Get by ID
router.get("/getInventoryDataAllocationsByInventoryId/:inventory_id", authentication, getInventoryDataAllocationsByInventoryId); // Get by inventory ID
router.put("/updateInventoryDataAllocation", authentication, updateInventoryDataAllocation); // Update
router.put("/updateMultipleInventoryDataAllocations", authentication, updateMultipleInventoryDataAllocations); // Update multiple rows
router.patch("/toggleInventoryDataAllocationStatus/toggle/:id", authentication, toggleInventoryDataAllocationStatus); // Toggle active status
router.delete("/deleteInventoryDataAllocation/:id", authentication, deleteInventoryDataAllocation); // Delete (soft delete)

//.....................Dealer Investment Allocation API..........................
router.get("/getAllDealerInvestmentAllocation", authentication, getAllDealerInvestmentAllocation); // Get all
router.get("/getDealerInvestmentAllocation/:id", authentication, getDealerInvestmentAllocationById); // Get by ID
router.get("/getDealerInvestmentAllocationByDealerInvestmentId/:dealerInvestmentId", authentication, getDealerInvestmentAllocationByDealerInvestmentId); // Get by dealer investment ID
router.get("/getDealerInvestmentAllocationByPdpId/:pdpId", authentication, getDealerInvestmentAllocationByPdpId); // Get by PDP ID
router.put("/updateDealerInvestmentAllocation", authentication, updateDealerInvestmentAllocation); // Update
router.put("/updateMultipleDealerInvestmentAllocation", authentication, updateMultipleDealerInvestmentAllocation); // Update multiple rows
router.delete("/deleteDealerInvestmentAllocation/:id", authentication, deleteDealerInvestmentAllocation); // Delete

//.....................Dealer User Details API..........................
router.post("/addDealerUserDetail", authentication, addDealerUserDetail); // Add
router.post("/bulkAddDealerUserDetail", authentication, bulkAddDealerUserDetails); // Bulk Add
router.get("/getAllDealerUserDetails", authentication, getAllDealerUserDetails); // Get all
router.get("/getDealerUserDetail/:id", authentication, getDealerUserDetailById); // Get by ID
router.put("/updateDealerUserDetail", authentication, updateDealerUserDetail); // Update
router.delete("/deleteDealerUserDetail/:id", authentication, deleteDealerUserDetail); // Delete
router.patch("/toggleDealerUserDetailStatus/toggle/:id", authentication, toggleDealerUserDetailStatus); // Toggle status

//.....................Volvo User Details API..........................
router.post("/addVolvoUserDetail", authentication, addVolvoUserDetail); // Add
router.post("/bulkAddVolvoUserDetail", authentication, bulkAddVolvoUserDetails); // Bulk Add
router.get("/getAllVolvoUserDetails", authentication, getAllVolvoUserDetails); // Get all
router.get("/getVolvoUserDetail/:id", authentication, getVolvoUserDetailById); // Get by ID
router.put("/updateVolvoUserDetail", authentication, updateVolvoUserDetail); // Update
router.delete("/deleteVolvoUserDetail/:id", authentication, deleteVolvoUserDetail); // Delete
router.patch("/toggleVolvoUserDetailStatus/toggle/:id", authentication, toggleVolvoUserDetailStatus); // Toggle status

//.....................Dealer Address Book API..........................
router.post("/addDealerAddressBook", authentication, addDealerAddressBook); // Add with file uploads
router.put("/updateDealerAddressBook", authentication, updateDealerAddressBook); // Update with file uploads
router.post("/bulkAddDealerAddressBooks", authentication, bulkAddDealerAddressBooks); // Bulk Add
router.get("/getAllDealerAddressBooks", authentication, getAllDealerAddressBooks); // Get all
router.get("/getDealerAddressBookById/:id", authentication, getDealerAddressBookById); // Get by ID
router.delete("/deleteDealerAddressBook/:id", authentication, deleteDealerAddressBook); // Delete
router.patch("/toggleDealerAddressBookStatus/toggle/:id", authentication, toggleDealerAddressBookStatus); // Toggle status


//.....................Contact Management Department API..........................
router.post("/addCMDepartment", authentication, addCMDepartment); // Add
router.post("/bulkAddCMDepartment", authentication, bulkAddCMDepartment); // Bulk Add
router.get("/getAllCMDepartments", authentication, getAllCMDepartments); // Get all
router.get("/getCMDepartment/:id", authentication, getCMDepartmentById); // Get by ID
router.put("/updateCMDepartment", authentication, updateCMDepartment); // Update
router.delete("/deleteCMDepartment/:id", authentication, deleteCMDepartment); // Delete
router.patch("/toggleCMDepartmentStatus/toggle/:id", authentication, toggleCMDepartmentStatus); // Toggle status

//.....................Contact Management Designation API..........................
router.post("/addCMDesignation", authentication, addCMDesignation); // Add
router.post("/bulkAddCMDesignation", authentication, bulkAddCMDesignation); // Bulk Add
router.get("/getAllCMDesignations", authentication, getAllCMDesignations); // Get all
router.get("/getCMDesignation/:id", authentication, getCMDesignationById); // Get by ID
router.put("/updateCMDesignation", authentication, updateCMDesignation); // Update
router.delete("/deleteCMDesignation/:id", authentication, deleteCMDesignation); // Delete
router.patch("/toggleCMDesignationStatus/toggle/:id", authentication, toggleCMDesignationStatus); // Toggle status

//.....................Process Management Template API..........................
router.post("/addProcessManagementTemplate", authentication, addProcessManagementTemplate); // Add (supports file upload via form data)
router.post("/bulkAddProcessManagementTemplate", authentication, bulkAddProcessManagementTemplates); // Bulk Add
router.get("/getAllProcessManagementTemplates", authentication, getAllProcessManagementTemplates); // Get all
router.get("/getProcessManagementTemplate/:id", authentication, getProcessManagementTemplateById); // Get by ID
router.put("/updateProcessManagementTemplate", authentication, updateProcessManagementTemplate); // Update (supports file upload via form data)
router.delete("/deleteProcessManagementTemplate/:id", authentication, deleteProcessManagementTemplate); // Delete
router.patch("/toggleProcessManagementTemplateStatus/toggle/:id", authentication, toggleProcessManagementTemplateStatus); // Toggle status

//.....................My Support Ticket API..........................
router.post("/addTicket", authentication, addTicket); // Add (supports file upload via form data)
router.get("/getAllTickets", authentication, getAllTickets); // Get all
router.get("/getTicket/:id", authentication, getTicketById); // Get by ID
router.get("/getTicketByUserId", authentication, getTicketByUserId);
router.put("/updateTicket", authentication, updateTicket); // Update (supports file upload via form data)
router.delete("/deleteTicket/:id", authentication, deleteTicket); // Delete (soft delete)
router.patch("/toggleTicketStatus/toggle/:id", authentication, toggleTicketStatus); // Toggle status

//.....................Ticket Attachments API..........................
router.post("/addTicketAttachment", authentication, addTicketAttachment); // Add (form-data: ticket_id + files)
router.get("/getAttachmentsByTicketId/:ticket_id", authentication, getAttachmentsByTicketId); // Get all by ticket_id
router.get("/getTicketAttachment/:id", authentication, getTicketAttachmentById); // Get by attachment id
router.delete("/deleteTicketAttachment/:id", authentication, deleteTicketAttachment); // Soft delete
router.patch("/toggleTicketAttachmentStatus/toggle/:id", authentication, toggleTicketAttachmentStatus); // Toggle status

//.....................Ticket Comments API..........................
router.post("/addTicketComment", authentication, addTicketComment); // Add (form-data: ticket_id, comment; optional file)
router.get("/getCommentsByTicketId/:ticket_id", authentication, getCommentsByTicketId); // Get all by ticket_id
router.get("/getTicketComment/:id", authentication, getTicketCommentById); // Get by comment id
router.put("/updateTicketComment", authentication, updateTicketComment); // Update (optional comment + file)
router.delete("/deleteTicketComment/:id", authentication, deleteTicketComment); // Soft delete
router.patch("/toggleTicketCommentStatus/toggle/:id", authentication, toggleTicketCommentStatus); // Toggle status

//.....................Notification API..........................
router.post("/addNotification", authentication, addNotification); // Add
router.get("/getAllNotifications", authentication, getAllNotifications); // Get all
router.get("/getNotification/:id", authentication, getNotificationById); // Get by ID
router.put("/updateNotification", authentication, updateNotification); // Update
router.delete("/deleteNotification/:id", authentication, deleteNotification); // Soft delete
router.patch("/toggleNotificationStatus/toggle/:id", authentication, toggleNotificationStatus); // Toggle status

//.....................User Notification (notification_user_mapping) API..........................
router.get("/getAllUserNotifications", authentication, getAllUserNotifications); // Get all mappings
router.get("/getUserNotification/:id", authentication, getUserNotificationById); // Get mapping by id
router.get("/getUserNotificationsByUserId", authentication, getUserNotificationsByUserId); // Get by user_id
router.put("/toggleUserNotificationSeenStatus/toggle/:id", authentication, toggleSeenStatus); // Toggle isSeen
router.put("/bulkToggleUserNotificationSeenStatus", authentication, bulkToggleSeenStatus); // Bulk mark as seen

//.....................Process Management Process API..........................
router.post("/addProcessManagementProcess", authentication, addProcessManagementProcess); // Add (supports file upload via form data)
router.post("/bulkAddProcessManagementProcess", authentication, bulkAddProcessManagementProcesses); // Bulk Add
router.get("/getAllProcessManagementProcesses", authentication, getAllProcessManagementProcesses); // Get all
router.get("/getProcessManagementProcess/:id", authentication, getProcessManagementProcessById); // Get by ID
router.put("/updateProcessManagementProcess", authentication, updateProcessManagementProcess); // Update (supports file upload via form data)
router.delete("/deleteProcessManagementProcess/:id", authentication, deleteProcessManagementProcess); // Delete
router.patch("/toggleProcessManagementProcessStatus/toggle/:id", authentication, toggleProcessManagementProcessStatus); // Toggle status

//.....................Process Management Policy API..........................
router.post("/addProcessManagementPolicy", authentication, addProcessManagementPolicy); // Add (supports file upload via form data)
router.post("/bulkAddProcessManagementPolicy", authentication, bulkAddProcessManagementPolicies); // Bulk Add
router.get("/getAllProcessManagementPolicies", authentication, getAllProcessManagementPolicies); // Get all
router.get("/getProcessManagementPolicy/:id", authentication, getProcessManagementPolicyById); // Get by ID
router.put("/updateProcessManagementPolicy", authentication, updateProcessManagementPolicy); // Update (supports file upload via form data)
router.delete("/deleteProcessManagementPolicy/:id", authentication, deleteProcessManagementPolicy); // Delete
router.patch("/toggleProcessManagementPolicyStatus/toggle/:id", authentication, toggleProcessManagementPolicyStatus); // Toggle status

//.....................Data Collection API..........................\n
router.post("/addDataCollection", authentication, addDataCollection); // Add (creates dynamic child table)
router.get("/getAllDataCollections", authentication, getAllDataCollections); // Get all
router.get("/getDataCollectionById/:id", authentication, getDataCollectionById); // Get by ID
router.put("/updateDataCollection", authentication, updateDataCollection); // Update
router.delete("/deleteDataCollection/:id", authentication, deleteDataCollection); // Delete (soft delete)

//.....................Data Collection Child Table API..........................\n
router.post("/addChildTableRow", authentication, addChildTableRow); // Add row to dynamic child table
router.get("/getChildTableRows/:collection_id", authentication, getChildTableRows); // Get all rows from child table
router.put("/updateChildTableRow", authentication, updateChildTableRow); // Update row in child table
router.delete("/deleteChildTableRow", authentication, deleteChildTableRow); // Delete row from child table
router.get("/getChildTableStructure/:collection_id", authentication, getChildTableStructure); // Get child table column structure

//.....................City Master Fetch API..........................
router.post("/bulkInsertCities", authentication, bulkInsertCities); // Bulk Insert Cities from External API





//............................ Main DFHM API ..........................//
//....................DFHM  API.................
router.post("/addDfhm", authentication, addDfhm); // Add
router.get("/getAllDfhm", authentication, getAllDfhm); // Get all
router.get("/getDfhm/:id", authentication, getDfhmById); // Get by ID
router.put("/updateDfhm", authentication, updateDfhm); // Update
router.patch("/toggleDfhm/toggle/:id", authentication, toggleDfhm); // Toggle enable/disable
router.delete("/deleteDfhm/:id", authentication, deleteDfhm); // Delete

//.........................DFHM PL (Profit & Loss) Child API..................
router.get("/getAllDfhmPl", authentication, getAllDfhmPl); // Get all
router.get("/getDfhmPl/:id", authentication, getDfhmPlById); // Get by ID
router.get("/getDfhmPlByDfhmId/:dfhmId", authentication, getDfhmPlByDfhmId); // Get by DFHM ID
router.get("/getDfhmPlByFilter", authentication, getDfhmPlByFilters); // Get by DFHM ID
router.put("/updateDfhmPl", authentication, updateDfhmPl); // Update
router.put("/updateMultipleDfhmPl", authentication, updateMultipleDfhmPl); // Update multiple rows
router.delete("/deleteDfhmPl/:id", authentication, deleteDfhmPl); // Delete

//.........................DFHM BS (Balance Sheet) Child API..................
router.get("/getAllDfhmBs", authentication, getAllDfhmBs); // Get all
router.get("/getDfhmBs/:id", authentication, getDfhmBsById); // Get by ID
router.get("/getDfhmBsByDfhmId/:dfhmId", authentication, getDfhmBsByDfhmId); // Get by DFHM ID
router.get("/getDfhmBsByFilters", authentication, getDfhmBsByFilters); // Get by DFHM ID
router.put("/updateDfhmBs", authentication, updateDfhmBs); // Update
router.put("/updateMultipleDfhmBs", authentication, updateMultipleDfhmBs); // Update multiple rows
router.delete("/deleteDfhmBs/:id", authentication, deleteDfhmBs); // Delete

//.........................DFHM HC (Head Count) Child API..................
router.get("/getAllDfhmHc", authentication, getAllDfhmHc); // Get all
router.get("/getDfhmHc/:id", authentication, getDfhmHcById); // Get by ID
router.get("/getDfhmHcByDfhmId/:dfhmId", authentication, getDfhmHcByDfhmId); // Get by DFHM ID
router.get("/getDfhmHcByFilters", authentication, getDfhmHcByFilters); // Get by DFHM ID
router.put("/updateDfhmHc", authentication, updateDfhmHc); // Update
router.put("/updateMultipleDfhmHc", authentication, updateMultipleDfhmHc); // Update multiple rows
router.delete("/deleteDfhmHc/:id", authentication, deleteDfhmHc); // Delete

//.........................DFHM AR Aging Child API..................
router.post("/addDfhmAging", authentication, addDfhmAging); // Add
router.get("/getAllDfhmAging", authentication, getAllDfhmAging); // Get all
router.get("/getDfhmAging/:id", authentication, getDfhmAgingById); // Get by ID
router.get("/getDfhmAgingByDfhmId/:dfhmId", authentication, getDfhmAgingByDfhmId); // Get by DFHM ID
router.get("/getDfhmAgingByFilters", authentication, getDfhmAgingByFilters); // Get by DFHM ID
router.put("/updateDfhmAging", authentication, updateDfhmAging); // Update
router.put("/updateMultipleDfhmAging", authentication, updateMultipleDfhmAging); // Update multiple rows
router.delete("/deleteDfhmAging/:id", authentication, deleteDfhmAging); // Delete

//........................testing Api....................
router.get("/test-me", (req, res) => {
    res.status(200).send({
        Status: true,
        Message: "Hello From The Server"
    })
})

//........................testing Api....................
router.get("/test-Email", async (req, res) => {
    try {
        let data = await testMail()
        return res.status(200).send({
            Status: true,
            Message: "Hello From The Test Email",
            data
        })
    } catch (error) {
        return res.status(500).send({
            Status: false,
            message: error.Message
        })
    }
})

router.get("/health", (req, res) => res.send("OK"));

//..............................User API...............................................//

//router.post('/userReg',userReg)
//router.post('/login',userLogin)
router.post('/doc', test)




//....................................................................................
// 404 handler (must be after all routes)
router.use((req, res, next) => {
    res.status(404).send({
        status: false,
        message: `The route ${req.originalUrl} [${req.method}] was not found. Please check the API documentation.`
    });
});

// Global error handler
router.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send({
        status: false,
        message: "Internal Server Error",
        error: err.message
    });
});



module.exports = router
