const mysql = require("mysql2");
const util = require("util");

const pool = mysql.createPool({
  host: "parnerconnect-test.mysql.database.azure.com",
  port:3306,
  user: "pctvce",
  password: "Sr5slt178",
  database: "pctest",
  multipleStatements: true,
    ssl: {
    rejectUnauthorized: true // or false if you don’t have CA cert
  },
  waitForConnections: true,
  connectionLimit: 10,   // adjust based on load
  queueLimit: 0
});

// Convert query method to use promises
pool.query = util.promisify(pool.query);

module.exports = { connection: pool };

