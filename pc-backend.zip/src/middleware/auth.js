const jwt = require('jsonwebtoken')


const { connection } = require("../mySql/mySql"); // Import connection

let authentication = async function (req, res, next) {
    try {
        let token = req.headers["authorization"]
        if (!token) return res.status(400).send({ status: false, message: "token must be present" })
        token = token.slice(7)
        jwt.verify(token, "VCEPCADVITIIXSr5slt178", async (error, decodedToken) => {
            if (error) {
                let message = 'token is invalid'
                if (error.message == "jwt expired" || error.message == 'jwt malformed') {
                    message = 'jwt expired'
                }
                return res.status(400).send({ status: false, message: message })
            }

            const { id, tokenId } = decodedToken;

            // Check if tokenId is active in token_management
            const tokenRows = await connection.query(
                "SELECT isActive FROM token_management WHERE id = ? AND userId = ?",
                [tokenId, id]
            );

            if (tokenRows.length === 0 || !tokenRows[0].isActive) {
                return res.status(401).send({ status: false, message: "Session expired or inactive. Please login again." });
            }

            req.decodedToken = id;
            req.tokenId=tokenId;
            next();
        })
    }
    catch (error) {
        res.status(500).send({ status: false, message: error.message })
    }
}

module.exports = { authentication }