const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {

    /* 
  demo req body addDealerInvestmentVehicle:
  {
    "dealer_investment_id": 1,
    "assigned_user": 2,
    "quarter": "Q1",
    "vehicle_category": "Personal",
    "vehicle_type": "2 Wheeler",
    "brand": "Honda",
    "registration_number": "KA-01-HH-1234",
    "yop": 2023,
    "location": "Bangalore",
    "remarks": "New vehicle added for survey"
  }
  */
    addDealerInvestmentVehicle: async function (req, res) {
        try {
            const {
                dealer_investment_id,
                assigned_user,
                quarter,
                vehicle_category,
                vehicle_type,
                brand,
                registration_number,
                yop,
                location,
                remarks
            } = req.body;

            if (!dealer_investment_id || !assigned_user || !quarter || !vehicle_category || !vehicle_type || !brand || !registration_number || !yop) {
                return res.status(400).send({
                    status: false,
                    message: "Required: dealer_investment_id, assigned_user, quarter, vehicle_category, vehicle_type, brand, registration_number, yop"
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const insertQuery = `
        INSERT INTO dealer_investment_vehicles (
          dealer_investment_id, assigned_user, quarter, vehicle_category, vehicle_type,
          brand, registration_number, yop, location, remarks,
          created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

            await connection.query(insertQuery, [
                dealer_investment_id,
                assigned_user,
                quarter,
                vehicle_category,
                vehicle_type,
                brand,
                registration_number,
                yop,
                location || null,
                remarks || null,
                createdAt,
                createdAt
            ]);

            return res.status(200).send({
                status: true,
                message: "Dealer investment vehicle added successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllDealerInvestmentVehicles: async function (req, res) {
        try {
            const query = `
        SELECT 
          divv.*,
          CONCAT(u.firstName, ' ', COALESCE(u.middleName, ''), ' ', u.lastName) as assigned_user_name,
          u.email as assigned_user_email
        FROM dealer_investment_vehicles divv
        LEFT JOIN userdetails u ON divv.assigned_user = u.id
        WHERE (divv.isDeleted = 0 OR divv.isDeleted IS NULL)
        ORDER BY divv.id DESC
      `;

            const data = await connection.query(query);

            return res.status(200).send({
                status: true,
                message: "Dealer investment vehicles list retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getDealerInvestmentVehicleById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const query = `
        SELECT 
          divv.*,
          CONCAT(u.firstName, ' ', COALESCE(u.middleName, ''), ' ', u.lastName) as assigned_user_name,
          u.email as assigned_user_email
        FROM dealer_investment_vehicles divv
        LEFT JOIN userdetails u ON divv.assigned_user = u.id
        WHERE divv.id = ? AND (divv.isDeleted = 0 OR divv.isDeleted IS NULL)
      `;

            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer investment vehicle not found" });
            }

            return res.status(200).send({
                status: true,
                message: "Dealer investment vehicle retrieved",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getDealerInvestmentVehiclesByDealerInvestmentId: async function (req, res) {
        try {
            const { dealerInvestmentId } = req.params;

            if (!dealerInvestmentId) {
                return res.status(400).send({ status: false, message: "Dealer Investment ID is required" });
            }

            const query = `
        SELECT 
          divv.*,
          CONCAT(u.firstName, ' ', COALESCE(u.middleName, ''), ' ', u.lastName) as assigned_user_name,
          u.email as assigned_user_email
        FROM dealer_investment_vehicles divv
        LEFT JOIN userdetails u ON divv.assigned_user = u.id
        WHERE divv.dealer_investment_id = ? AND (divv.isDeleted = 0 OR divv.isDeleted IS NULL)
        ORDER BY divv.id DESC
      `;

            const data = await connection.query(query, [dealerInvestmentId]);

            return res.status(200).send({
                status: true,
                message: "Dealer investment vehicles for the given dealer investment retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateDealerInvestmentVehicle: async function (req, res) {
        try {
            const {
                id,
                dealer_investment_id,
                assigned_user,
                quarter,
                vehicle_category,
                vehicle_type,
                brand,
                registration_number,
                yop,
                location,
                remarks,
                isActive
            } = req.body;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                `SELECT id FROM dealer_investment_vehicles WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer investment vehicle not found" });
            }

            const updateFields = [];
            const updateValues = [];

            if (dealer_investment_id !== undefined) {
                updateFields.push("dealer_investment_id = ?");
                updateValues.push(dealer_investment_id);
            }
            if (assigned_user !== undefined) {
                updateFields.push("assigned_user = ?");
                updateValues.push(assigned_user);
            }
            if (quarter !== undefined) {
                updateFields.push("quarter = ?");
                updateValues.push(quarter);
            }
            if (vehicle_category !== undefined) {
                updateFields.push("vehicle_category = ?");
                updateValues.push(vehicle_category);
            }
            if (vehicle_type !== undefined) {
                updateFields.push("vehicle_type = ?");
                updateValues.push(vehicle_type);
            }
            if (brand !== undefined) {
                updateFields.push("brand = ?");
                updateValues.push(brand);
            }
            if (registration_number !== undefined) {
                updateFields.push("registration_number = ?");
                updateValues.push(registration_number);
            }
            if (yop !== undefined) {
                updateFields.push("yop = ?");
                updateValues.push(yop);
            }
            if (location !== undefined) {
                updateFields.push("location = ?");
                updateValues.push(location);
            }
            if (remarks !== undefined) {
                updateFields.push("remarks = ?");
                updateValues.push(remarks);
            }
            if (isActive !== undefined) {
                updateFields.push("isActive = ?");
                updateValues.push(isActive);
            }

            if (updateFields.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "No fields to update"
                });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("updated_at = ?");
            updateValues.push(updatedAt);

            updateValues.push(id);

            const updateQuery = `
        UPDATE dealer_investment_vehicles
        SET ${updateFields.join(", ")}
        WHERE id = ?
      `;

            await connection.query(updateQuery, updateValues);

            return res.status(200).send({
                status: true,
                message: "Dealer investment vehicle updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteDealerInvestmentVehicle: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                `SELECT id FROM dealer_investment_vehicles WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer investment vehicle not found" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(`UPDATE dealer_investment_vehicles SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?`, [updatedAt, id]);

            return res.status(200).send({
                status: true,
                message: "Dealer investment vehicle deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};
