const { connection } = require("../../../../mySql/mySql");
const moment = require("moment-timezone");

/**
 * Calculate closing stock for a specific month
 * Formula: closing_stock = open_stock + arrivals - allocation
 * 
 * @param {number} year - The year for which to calculate closing stock
 * @param {number} equipmentId - The equipment ID
 * @param {string} month - Month name (e.g., 'jan', 'feb', 'mar', etc.)
 * @param {number} openStock - Opening stock for the month
 * @param {number} arrivals - Arrivals for the month
 * @returns {Promise<number>} - Calculated closing stock
 */
async function calculateClosingStock(year, equipmentId, month, openStock, arrivals) {
    try {
        console.log(`[calculateClosingStock] Calculating for year: ${year}, equipmentId: ${equipmentId}, month: ${month}`);
        console.log(`[calculateClosingStock] Open Stock: ${openStock}, Arrivals: ${arrivals}`);

        // Map month names to column names in dealer_investment_allocation table
        const monthColumnMap = {
            'january': 'jan',
            'february': 'feb',
            'march': 'mar',
            'april': 'apr',
            'may': 'may',
            'june': 'jun',
            'july': 'jul',
            'august': 'aug',
            'september': 'sep',
            'october': 'oct',
            'november': 'nov',
            'december': 'decem'
        };

        // Normalize month input (handle both 'january' and 'jan' formats)
        const normalizedMonth = month.toLowerCase();
        const columnName = monthColumnMap[normalizedMonth] || normalizedMonth;

        // Validate month column name
        const validMonths = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'decem'];
        if (!validMonths.includes(columnName)) {
            throw new Error(`Invalid month: ${month}. Must be one of: ${validMonths.join(', ')}`);
        }

        // Fetch total allocation for the given year, equipment, and month
        const allocationQuery = `
      SELECT 
        SUM(dia.${columnName}) AS total_allocation
      FROM 
        dealer_investment_allocation AS dia
      JOIN 
        dealer_investment AS di ON dia.dealerInvestmentId = di.id
      JOIN 
        pdp ON di.pdpId = pdp.id
      WHERE 
        pdp.year = ? 
        AND dia.equipmentId = ?
        AND (dia.isDeleted = 0 OR dia.isDeleted IS NULL)
    `;

        console.log(`[calculateClosingStock] Fetching allocation for column: ${columnName}`);
        const allocationResult = await connection.query(allocationQuery, [year, equipmentId]);

        // Get allocation value (default to 0 if null)
        const allocation = allocationResult[0]?.total_allocation || 0;
        console.log(`[calculateClosingStock] Total Allocation: ${allocation}`);

        // Calculate closing stock
        const closingStock = (openStock || 0) + (arrivals || 0) - allocation;
        console.log(`[calculateClosingStock] Closing Stock: ${closingStock} (${openStock} + ${arrivals} - ${allocation})`);

        return closingStock;
    } catch (error) {
        console.error(`[calculateClosingStock] Error:`, error.message);
        throw error;
    }
}

/**
 * Recalculate and update closing stock for inventory records affected by allocation change
 * This is triggered when dealer_investment_allocation is updated
 * 
 * @param {number} year - PDP year
 * @param {number} equipmentId - Equipment ID
 * @param {string} month - Month name ('jan', 'feb', 'mar', etc.)
 * @returns {Promise<number>} - Number of inventory records updated
 */
async function recalculateClosingStockForAllocation(year, equipmentId, month) {
    try {
        console.log(`[recalculateClosingStockForAllocation] Triggered for year: ${year}, equipmentId: ${equipmentId}, month: ${month}`);

        // Map short month names to full names for inventory table columns
        const monthColumnMap = {
            'jan': 'january',
            'feb': 'february',
            'mar': 'march',
            'apr': 'april',
            'may': 'may',
            'jun': 'june',
            'jul': 'july',
            'aug': 'august',
            'sep': 'september',
            'oct': 'october',
            'nov': 'november',
            'decem': 'december'
        };

        const fullMonthName = monthColumnMap[month] || month;
        const openStockField = `${fullMonthName}_open_stock`;
        const arrivalsField = `${fullMonthName}_arrivals`;
        const closingStockField = `${fullMonthName}_closing_stock`;

        // Find inventory records matching year and equipmentId
        const inventoryRecords = await connection.query(`
            SELECT 
                idam.id,
                idam.${openStockField} as open_stock,
                idam.${arrivalsField} as arrivals
            FROM inventory_data_allocation_management idam
            LEFT JOIN inventory_allocation_management iam ON idam.inventory_id = iam.id
            WHERE iam.inventory_year = ? 
                AND idam.equipment_id = ?
                AND idam.isDeleted = 0
        `, [year, equipmentId]);

        if (inventoryRecords.length === 0) {
            console.log(`[recalculateClosingStockForAllocation] No inventory records found for year ${year}, equipmentId ${equipmentId}`);
            return 0;
        }

        console.log(`[recalculateClosingStockForAllocation] Found ${inventoryRecords.length} inventory record(s) to update`);

        // Recalculate closing stock for each record
        let updatedCount = 0;
        for (const record of inventoryRecords) {
            const closingStock = await calculateClosingStock(
                year,
                equipmentId,
                month,
                record.open_stock,
                record.arrivals
            );

            // Update the closing stock
            const updated_at = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(`
                UPDATE inventory_data_allocation_management
                SET ${closingStockField} = ?,
                    updated_at = ?
                WHERE id = ?
            `, [closingStock, updated_at, record.id]);

            console.log(`[recalculateClosingStockForAllocation] ✓ Updated ${closingStockField} = ${closingStock} for inventory record id: ${record.id}`);
            updatedCount++;
        }

        return updatedCount;
    } catch (error) {
        console.error(`[recalculateClosingStockForAllocation] ✗ Error:`, error.message);
        throw error;
    }
}

module.exports = {
    // 📋 Get All Inventory Data Allocations
    getAllInventoryDataAllocations: async function (req, res) {
        try {
            const { year } = req.query;

            let query = `
  SELECT 
    idam.id,
    idam.inventory_id,
    idam.equipment_id,
    idam.january_open_stock,
    idam.january_arrivals,
    idam.january_closing_stock,
    idam.february_open_stock,
    idam.february_arrivals,
    idam.february_closing_stock,
    idam.march_open_stock,
    idam.march_arrivals,
    idam.march_closing_stock,
    idam.april_open_stock,
    idam.april_arrivals,
    idam.april_closing_stock,
    idam.may_open_stock,
    idam.may_arrivals,
    idam.may_closing_stock,
    idam.june_open_stock,
    idam.june_arrivals,
    idam.june_closing_stock,
    idam.july_open_stock,
    idam.july_arrivals,
    idam.july_closing_stock,
    idam.august_open_stock,
    idam.august_arrivals,
    idam.august_closing_stock,
    idam.september_open_stock,
    idam.september_arrivals,
    idam.september_closing_stock,
    idam.october_open_stock,
    idam.october_arrivals,
    idam.october_closing_stock,
    idam.november_open_stock,
    idam.november_arrivals,
    idam.november_closing_stock,
    idam.december_open_stock,
    idam.december_arrivals,
    idam.december_closing_stock,
    idam.created_at,
    idam.updated_at,
    idam.isActive,
    idam.isDeleted,
    iam.inventory_year,
    iam.created_by,
    e.year AS equipment_year,
    e.equipment_type,
    e.equipment_make,
    e.equipment_line,
    e.equipment_model
  FROM inventory_data_allocation_management idam
  LEFT JOIN inventory_allocation_management iam 
    ON idam.inventory_id = iam.id
  LEFT JOIN equipments e 
    ON idam.equipment_id = e.id
  WHERE idam.isDeleted = 0
`;

            const params = [];

            // ✅ Apply year filter ONLY if available
            if (year) {
                query += ` AND iam.inventory_year = ?`;
                params.push(year);
            }

            query += `
  ORDER BY iam.inventory_year DESC, e.equipment_type, e.equipment_make
`;


            const data = await connection.query(query,params);

            if (data.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "No inventory data allocation records found",
                    data: []
                });
            }

            return res.status(200).send({
                status: true,
                message: "Inventory data allocation list retrieved successfully",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // 🔍 Get Inventory Data Allocation by ID
    getInventoryDataAllocationById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const query = `
        SELECT 
          idam.id,
          idam.inventory_id,
          idam.equipment_id,
          idam.january_open_stock,
          idam.january_arrivals,
          idam.january_closing_stock,
          idam.february_open_stock,
          idam.february_arrivals,
          idam.february_closing_stock,
          idam.march_open_stock,
          idam.march_arrivals,
          idam.march_closing_stock,
          idam.april_open_stock,
          idam.april_arrivals,
          idam.april_closing_stock,
          idam.may_open_stock,
          idam.may_arrivals,
          idam.may_closing_stock,
          idam.june_open_stock,
          idam.june_arrivals,
          idam.june_closing_stock,
          idam.july_open_stock,
          idam.july_arrivals,
          idam.july_closing_stock,
          idam.august_open_stock,
          idam.august_arrivals,
          idam.august_closing_stock,
          idam.september_open_stock,
          idam.september_arrivals,
          idam.september_closing_stock,
          idam.october_open_stock,
          idam.october_arrivals,
          idam.october_closing_stock,
          idam.november_open_stock,
          idam.november_arrivals,
          idam.november_closing_stock,
          idam.december_open_stock,
          idam.december_arrivals,
          idam.december_closing_stock,
          idam.created_at,
          idam.updated_at,
          idam.isActive,
          idam.isDeleted,
          iam.inventory_year,
          iam.created_by,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model
        FROM inventory_data_allocation_management idam
        LEFT JOIN inventory_allocation_management iam ON idam.inventory_id = iam.id
        LEFT JOIN equipments e ON idam.equipment_id = e.id
        WHERE idam.id = ? AND idam.isDeleted = 0
      `;

            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Inventory data allocation not found" });
            }

            return res.status(200).send({
                status: true,
                message: "Inventory data allocation retrieved successfully",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // 🔍 Get Inventory Data Allocations by Inventory ID
    getInventoryDataAllocationsByInventoryId: async function (req, res) {
        try {
            const { inventory_id } = req.params;

            if (!inventory_id) {
                return res.status(400).send({ status: false, message: "Inventory ID is required" });
            }

            const query = `
        SELECT 
          idam.id,
          idam.inventory_id,
          idam.equipment_id,
          idam.january_open_stock,
          idam.january_arrivals,
          idam.january_closing_stock,
          idam.february_open_stock,
          idam.february_arrivals,
          idam.february_closing_stock,
          idam.march_open_stock,
          idam.march_arrivals,
          idam.march_closing_stock,
          idam.april_open_stock,
          idam.april_arrivals,
          idam.april_closing_stock,
          idam.may_open_stock,
          idam.may_arrivals,
          idam.may_closing_stock,
          idam.june_open_stock,
          idam.june_arrivals,
          idam.june_closing_stock,
          idam.july_open_stock,
          idam.july_arrivals,
          idam.july_closing_stock,
          idam.august_open_stock,
          idam.august_arrivals,
          idam.august_closing_stock,
          idam.september_open_stock,
          idam.september_arrivals,
          idam.september_closing_stock,
          idam.october_open_stock,
          idam.october_arrivals,
          idam.october_closing_stock,
          idam.november_open_stock,
          idam.november_arrivals,
          idam.november_closing_stock,
          idam.december_open_stock,
          idam.december_arrivals,
          idam.december_closing_stock,
          idam.created_at,
          idam.updated_at,
          idam.isActive,
          idam.isDeleted,
          iam.inventory_year,
          iam.created_by,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model
        FROM inventory_data_allocation_management idam
        LEFT JOIN inventory_allocation_management iam ON idam.inventory_id = iam.id
        LEFT JOIN equipments e ON idam.equipment_id = e.id
        WHERE idam.inventory_id = ? AND idam.isDeleted = 0
        ORDER BY e.equipment_type, e.equipment_make
      `;

            const data = await connection.query(query, [inventory_id]);

            return res.status(200).send({
                status: true,
                message: "Inventory data allocations retrieved successfully",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // ✏️ Update Inventory Data Allocation
    updateInventoryDataAllocation: async function (req, res) {
        try {
            const { id, ...updateFields } = req.body;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            // Fetch current record with inventory_year and equipment_id
            const currentRecord = await connection.query(`
                SELECT 
                    idam.*,
                    iam.inventory_year
                FROM inventory_data_allocation_management idam
                LEFT JOIN inventory_allocation_management iam ON idam.inventory_id = iam.id
                WHERE idam.id = ? AND idam.isDeleted = 0
            `, [id]);

            if (currentRecord.length === 0) {
                return res.status(404).send({ status: false, message: "Inventory data allocation not found" });
            }

            const record = currentRecord[0];
            const inventoryYear = record.inventory_year;
            const equipmentId = record.equipment_id;

            // Build update query dynamically
            const allowedFields = [
                'january_open_stock', 'january_arrivals', 'january_closing_stock',
                'february_open_stock', 'february_arrivals', 'february_closing_stock',
                'march_open_stock', 'march_arrivals', 'march_closing_stock',
                'april_open_stock', 'april_arrivals', 'april_closing_stock',
                'may_open_stock', 'may_arrivals', 'may_closing_stock',
                'june_open_stock', 'june_arrivals', 'june_closing_stock',
                'july_open_stock', 'july_arrivals', 'july_closing_stock',
                'august_open_stock', 'august_arrivals', 'august_closing_stock',
                'september_open_stock', 'september_arrivals', 'september_closing_stock',
                'october_open_stock', 'october_arrivals', 'october_closing_stock',
                'november_open_stock', 'november_arrivals', 'november_closing_stock',
                'december_open_stock', 'december_arrivals', 'december_closing_stock'
            ];

            const updateFieldsArray = [];
            const updateValues = [];

            // Track which months need closing stock calculation
            const monthsToCalculate = new Set();

            for (const field of allowedFields) {
                if (updateFields[field] !== undefined) {
                    updateFieldsArray.push(`${field} = ?`);
                    updateValues.push(updateFields[field]);

                    // Check if this is an open_stock or arrivals field
                    if (field.endsWith('_open_stock') || field.endsWith('_arrivals')) {
                        const monthName = field.split('_')[0]; // Extract month name
                        monthsToCalculate.add(monthName);
                    }
                }
            }

            // Calculate closing stock for affected months
            for (const monthName of monthsToCalculate) {
                // Get the updated or current values
                const openStockField = `${monthName}_open_stock`;
                const arrivalsField = `${monthName}_arrivals`;
                const closingStockField = `${monthName}_closing_stock`;

                // Use updated value if provided, otherwise use current value from record
                const openStock = updateFields[openStockField] !== undefined
                    ? updateFields[openStockField]
                    : record[openStockField];

                const arrivals = updateFields[arrivalsField] !== undefined
                    ? updateFields[arrivalsField]
                    : record[arrivalsField];

                // Calculate closing stock
                const closingStock = await calculateClosingStock(
                    inventoryYear,
                    equipmentId,
                    monthName,
                    openStock,
                    arrivals
                );

                // Add closing stock to update if not already provided by user
                if (updateFields[closingStockField] === undefined) {
                    updateFieldsArray.push(`${closingStockField} = ?`);
                    updateValues.push(closingStock);
                    console.log(`[updateInventoryDataAllocation] Auto-calculated ${closingStockField}: ${closingStock}`);
                }
            }

            // Always update updated_at
            const updated_at = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFieldsArray.push("updated_at = ?");
            updateValues.push(updated_at);

            if (updateFieldsArray.length === 1) { // Only updated_at
                return res.status(400).send({
                    status: false,
                    message: "No valid fields to update"
                });
            }

            updateValues.push(id);

            const updateQuery = `
        UPDATE inventory_data_allocation_management
        SET ${updateFieldsArray.join(", ")}
        WHERE id = ?
      `;

            await connection.query(updateQuery, updateValues);

            return res.status(200).send({
                status: true,
                message: "Inventory data allocation updated successfully with calculated closing stock"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // ✏️ Update Multiple Inventory Data Allocations
    updateMultipleInventoryDataAllocations: async function (req, res) {
        try {
            const { rows } = req.body;

            if (!Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({ status: false, message: "Rows array required" });
            }

            const allowedFields = [
                'january_open_stock', 'january_arrivals', 'january_closing_stock',
                'february_open_stock', 'february_arrivals', 'february_closing_stock',
                'march_open_stock', 'march_arrivals', 'march_closing_stock',
                'april_open_stock', 'april_arrivals', 'april_closing_stock',
                'may_open_stock', 'may_arrivals', 'may_closing_stock',
                'june_open_stock', 'june_arrivals', 'june_closing_stock',
                'july_open_stock', 'july_arrivals', 'july_closing_stock',
                'august_open_stock', 'august_arrivals', 'august_closing_stock',
                'september_open_stock', 'september_arrivals', 'september_closing_stock',
                'october_open_stock', 'october_arrivals', 'october_closing_stock',
                'november_open_stock', 'november_arrivals', 'november_closing_stock',
                'december_open_stock', 'december_arrivals', 'december_closing_stock'
            ];

            const updated_at = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            for (const row of rows) {
                const { id, ...fields } = row;

                if (!id) continue;

                // Fetch current record with inventory_year and equipment_id
                const currentRecord = await connection.query(`
                    SELECT 
                        idam.*,
                        iam.inventory_year
                    FROM inventory_data_allocation_management idam
                    LEFT JOIN inventory_allocation_management iam ON idam.inventory_id = iam.id
                    WHERE idam.id = ? AND idam.isDeleted = 0
                `, [id]);

                if (currentRecord.length === 0) continue;

                const record = currentRecord[0];
                const inventoryYear = record.inventory_year;
                const equipmentId = record.equipment_id;

                const updateFieldsArray = [];
                const updateValues = [];
                const monthsToCalculate = new Set();

                for (const key in fields) {
                    if (allowedFields.includes(key)) {
                        updateFieldsArray.push(`${key} = ?`);
                        updateValues.push(fields[key]);

                        // Check if this is an open_stock or arrivals field
                        if (key.endsWith('_open_stock') || key.endsWith('_arrivals')) {
                            const monthName = key.split('_')[0]; // Extract month name
                            monthsToCalculate.add(monthName);
                        }
                    }
                }

                // Calculate closing stock for affected months
                for (const monthName of monthsToCalculate) {
                    const openStockField = `${monthName}_open_stock`;
                    const arrivalsField = `${monthName}_arrivals`;
                    const closingStockField = `${monthName}_closing_stock`;

                    // Use updated value if provided, otherwise use current value from record
                    const openStock = fields[openStockField] !== undefined
                        ? fields[openStockField]
                        : record[openStockField];

                    const arrivals = fields[arrivalsField] !== undefined
                        ? fields[arrivalsField]
                        : record[arrivalsField];

                    // Calculate closing stock
                    const closingStock = await calculateClosingStock(
                        inventoryYear,
                        equipmentId,
                        monthName,
                        openStock,
                        arrivals
                    );

                    // Add closing stock to update if not already provided by user
                    if (fields[closingStockField] === undefined) {
                        updateFieldsArray.push(`${closingStockField} = ?`);
                        updateValues.push(closingStock);
                        console.log(`[updateMultipleInventoryDataAllocations] Auto-calculated ${closingStockField} for id ${id}: ${closingStock}`);
                    }
                }

                if (updateFieldsArray.length === 0) continue;

                updateFieldsArray.push("updated_at = ?");
                updateValues.push(updated_at);
                updateValues.push(id);

                const query = `
          UPDATE inventory_data_allocation_management 
          SET ${updateFieldsArray.join(", ")} 
          WHERE id = ?
        `;

                await connection.query(query, updateValues);
            }

            return res.status(200).send({
                status: true,
                message: "Multiple inventory data allocation rows updated successfully with calculated closing stock"
            });

        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // 🔄 Toggle Active Status
    toggleInventoryDataAllocationStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            // Check if inventory data allocation exists
            const exists = await connection.query(
                `SELECT id, isActive FROM inventory_data_allocation_management WHERE id = ? AND isDeleted = 0`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Inventory data allocation not found" });
            }

            const currentStatus = exists[0].isActive;
            const newStatus = currentStatus ? 0 : 1;

            const updated_at = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                `UPDATE inventory_data_allocation_management SET isActive = ?, updated_at = ? WHERE id = ?`,
                [newStatus, updated_at, id]
            );

            return res.status(200).send({
                status: true,
                message: `Inventory data allocation ${newStatus ? 'activated' : 'deactivated'} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // 🗑️ Delete Inventory Data Allocation (Soft Delete)
    deleteInventoryDataAllocation: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            // Check if inventory data allocation exists
            const exists = await connection.query(
                `SELECT id FROM inventory_data_allocation_management WHERE id = ? AND isDeleted = 0`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Inventory data allocation not found" });
            }

            const updated_at = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                `UPDATE inventory_data_allocation_management SET isDeleted = 1, updated_at = ? WHERE id = ?`,
                [updated_at, id]
            );

            return res.status(200).send({
                status: true,
                message: "Inventory data allocation deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // Export helper function for use in other controllers
    recalculateClosingStockForAllocation
};
