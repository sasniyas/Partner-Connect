const { connection } = require("../../../../mySql/mySql");
const moment = require("moment-timezone");

module.exports = {
    // ➕ Add Inventory Allocation Management
    addInventoryAllocation: async function (req, res) {
        try {
            const { inventory_year } = req.body;
            const userId = req.decodedToken;

            if (!inventory_year) {
                return res.status(400).send({
                    status: false,
                    message: "inventory_year is required"
                });
            }

            // Check for duplicate (same inventory_year and created_by)
            const duplicateCheck = await connection.query(
                `SELECT id FROM inventory_allocation_management WHERE inventory_year = ? AND created_by = ? AND isDeleted = 0`,
                [inventory_year, userId]
            );
            if (duplicateCheck.length > 0) {
                return res.status(400).send({
                    status: false,
                    message: "Inventory allocation already exists for this year"
                });
            }

            const created_at = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const updated_at = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const insertQuery = `
        INSERT INTO inventory_allocation_management (
          created_by, inventory_year, created_at, updated_at
        )
        VALUES (?, ?, ?, ?)
      `;

            const insertResult = await connection.query(insertQuery, [
                userId,
                inventory_year,
                created_at,
                updated_at
            ]);

            const inventoryId = insertResult.insertId;

            // Get all non-deleted equipments
            const equipmentsQuery = `
        SELECT id FROM equipments 
        WHERE (isDeleted = 0 OR isDeleted IS NULL)
      `;
            const equipments = await connection.query(equipmentsQuery);

            // Create inventory_data_allocation_management entries for each equipment
            if (equipments.length > 0) {
                const dataInsertQuery = `
          INSERT INTO inventory_data_allocation_management (
            inventory_id, equipment_id, 
            january_open_stock, january_arrivals, january_closing_stock,
            february_open_stock, february_arrivals, february_closing_stock,
            march_open_stock, march_arrivals, march_closing_stock,
            april_open_stock, april_arrivals, april_closing_stock,
            may_open_stock, may_arrivals, may_closing_stock,
            june_open_stock, june_arrivals, june_closing_stock,
            july_open_stock, july_arrivals, july_closing_stock,
            august_open_stock, august_arrivals, august_closing_stock,
            september_open_stock, september_arrivals, september_closing_stock,
            october_open_stock, october_arrivals, october_closing_stock,
            november_open_stock, november_arrivals, november_closing_stock,
            december_open_stock, december_arrivals, december_closing_stock,
            created_at, updated_at
          )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

                for (const equipment of equipments) {
                    await connection.query(dataInsertQuery, [
                        inventoryId,
                        equipment.id,
                        0, 0, 0, // january: open_stock, arrivals, closing_stock
                        0, 0, 0, // february
                        0, 0, 0, // march
                        0, 0, 0, // april
                        0, 0, 0, // may
                        0, 0, 0, // june
                        0, 0, 0, // july
                        0, 0, 0, // august
                        0, 0, 0, // september
                        0, 0, 0, // october
                        0, 0, 0, // november
                        0, 0, 0, // december
                        created_at,
                        updated_at
                    ]);
                }
            }

            return res.status(200).send({
                status: true,
                message: "Inventory allocation added successfully",
                data: {
                    id: inventoryId,
                    equipments_count: equipments.length
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // 📋 Get All Inventory Allocations
    getAllInventoryAllocations: async function (req, res) {
        try {
            const query = `
        SELECT 
          iam.id,
          iam.created_by,
          iam.inventory_year,
          iam.created_at,
          iam.updated_at,
          iam.isActive,
          iam.isDeleted,
          u.firstName as created_by_name,
          u.email as created_by_email
        FROM inventory_allocation_management iam
        LEFT JOIN userdetails u ON iam.created_by = u.id
        WHERE iam.isDeleted = 0
        ORDER BY iam.inventory_year DESC, iam.id DESC
      `;

            const data = await connection.query(query);

            if (data.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "No inventory allocation records found",
                    data: []
                });
            }

            return res.status(200).send({
                status: true,
                message: "Inventory allocation list retrieved successfully",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // 🔍 Get Inventory Allocation by ID
    getInventoryAllocationById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const query = `
        SELECT 
          iam.id,
          iam.created_by,
          iam.inventory_year,
          iam.created_at,
          iam.updated_at,
          iam.isActive,
          iam.isDeleted,
          u.firstName as created_by_name,
          u.email as created_by_email
        FROM inventory_allocation_management iam
        LEFT JOIN userdetails u ON iam.created_by = u.id
        WHERE iam.id = ? AND iam.isDeleted = 0
      `;

            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Inventory allocation not found" });
            }

            return res.status(200).send({
                status: true,
                message: "Inventory allocation retrieved successfully",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // ✏️ Update Inventory Allocation
    updateInventoryAllocation: async function (req, res) {
        try {
            const { id, inventory_year } = req.body;
            const userId = req.decodedToken;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            // Check if inventory allocation exists
            const exists = await connection.query(
                `SELECT id FROM inventory_allocation_management WHERE id = ? AND isDeleted = 0`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Inventory allocation not found" });
            }

            // Check for duplicate if inventory_year is being changed
            if (inventory_year) {
                const duplicateCheck = await connection.query(
                    `SELECT id FROM inventory_allocation_management WHERE inventory_year = ? AND created_by = ? AND id != ? AND isDeleted = 0`,
                    [inventory_year, userId, id]
                );
                if (duplicateCheck.length > 0) {
                    return res.status(400).send({
                        status: false,
                        message: "Inventory allocation already exists for this year"
                    });
                }
            }

            // Build update query dynamically
            const updateFields = [];
            const updateValues = [];

            if (inventory_year !== undefined) {
                updateFields.push("inventory_year = ?");
                updateValues.push(inventory_year);
            }

            // Always update updated_at
            const updated_at = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("updated_at = ?");
            updateValues.push(updated_at);

            if (updateFields.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "No fields to update"
                });
            }

            updateValues.push(id);

            const updateQuery = `
        UPDATE inventory_allocation_management
        SET ${updateFields.join(", ")}
        WHERE id = ?
      `;

            await connection.query(updateQuery, updateValues);

            return res.status(200).send({
                status: true,
                message: "Inventory allocation updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // 🔄 Toggle Active Status
    toggleInventoryAllocationStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            // Check if inventory allocation exists
            const exists = await connection.query(
                `SELECT id, isActive FROM inventory_allocation_management WHERE id = ? AND isDeleted = 0`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Inventory allocation not found" });
            }

            const currentStatus = exists[0].isActive;
            const newStatus = currentStatus ? 0 : 1;

            const updated_at = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                `UPDATE inventory_allocation_management SET isActive = ?, updated_at = ? WHERE id = ?`,
                [newStatus, updated_at, id]
            );

            return res.status(200).send({
                status: true,
                message: `Inventory allocation ${newStatus ? 'activated' : 'deactivated'} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // 🗑️ Delete Inventory Allocation (Soft Delete)
    deleteInventoryAllocation: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            // Check if inventory allocation exists
            const exists = await connection.query(
                `SELECT id FROM inventory_allocation_management WHERE id = ? AND isDeleted = 0`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Inventory allocation not found" });
            }

            const updated_at = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                `UPDATE inventory_allocation_management SET isDeleted = 1, updated_at = ? WHERE id = ?`,
                [updated_at, id]
            );

            return res.status(200).send({
                status: true,
                message: "Inventory allocation deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};
