const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../../azurestorage/fileUpload");

module.exports = {
    // ➕ Add Dealer Investment File
    // Demo Request Body (multipart/form-data):
    // {
    //   "dealer_investment_id": 1,
    //   "file": <file upload>,
    //   "type": "Document Type",
    //   "category": "Infrastructure" or "Monthly Business Plan"
    // }
    addDealerInvestmentFile: async function (req, res) {
        try {
            const { dealer_investment_id, type, category } = req.body;
            const files = req.files;
            // Upload file to Azure Storage
            let fileUrl


            if (files && files.length > 0) {
                const file = files[0]; // Get the first file
                const uploadedUrl = await uploadFile(file);
                if (!uploadedUrl || typeof uploadedUrl === 'object') {
                    return res.status(400).send({ status: false, message: "Failed to upload file!" });
                }
                fileUrl = uploadedUrl;
                console.log("File uploaded successfully, URL:", fileUrl);
            } else {
                return res.status(400).send({ status: false, message: "File is required" });
            }

            if (!dealer_investment_id) {
                return res.status(400).send({
                    status: false,
                    message: "dealer_investment_id is required"
                });
            }


            // Validate category if provided
            if (category && !["Infrastructure", "Monthly Business Plan"].includes(category)) {
                return res.status(400).send({
                    status: false,
                    message: "Category must be either 'Infrastructure' or 'Monthly Business Plan'"
                });
            }

            // Check if dealer_investment exists
            const dealerInvestmentExists = await connection.query(
                `SELECT id FROM dealer_investment WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
                [dealer_investment_id]
            );
            if (dealerInvestmentExists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Dealer investment not found"
                });
            }

           console.log(fileUrl)

            const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const insertQuery = `
        INSERT INTO dealer_investment_file (dealer_investment_id, file, type, category, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `;

            const result = await connection.query(insertQuery, [
                dealer_investment_id,
                fileUrl,
                type || null,
                category || null,
                createdOn,
                createdOn
            ]);

            return res.status(200).send({
                status: true,
                message: "Dealer investment file added successfully",
                id: result.insertId,
                fileUrl: fileUrl
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    // 📥 Get All Dealer Investment Files
    getAllDealerInvestmentFiles: async function (req, res) {
        try {
            const query = `
        SELECT 
          dif.id,
          dif.dealer_investment_id,
          dif.file,
          dif.type,
          dif.category,
          dif.created_at,
          dif.updated_at,
          dif.isActive,
          dif.isDeleted
        FROM dealer_investment_file dif
        WHERE (dif.isDeleted = FALSE OR dif.isDeleted = 0)
        ORDER BY dif.created_at DESC, dif.id DESC
      `;
            const data = await connection.query(query);

            if (data.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "No dealer investment files found",
                    data: []
                });
            }

            return res.status(200).send({
                status: true,
                message: "Dealer investment files retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    // 🔍 Get Dealer Investment File by ID
    getDealerInvestmentFileById: async function (req, res) {
        try {
            const { id } = req.params;
            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            const query = `
        SELECT 
          dif.id,
          dif.dealer_investment_id,
          dif.file,
          dif.type,
          dif.category,
          dif.created_at,
          dif.updated_at,
          dif.isActive,
          dif.isDeleted
        FROM dealer_investment_file dif
        WHERE dif.id = ? AND (dif.isDeleted = FALSE OR dif.isDeleted = 0)
      `;
            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Dealer investment file not found"
                });
            }

            return res.status(200).send({
                status: true,
                message: "Dealer investment file retrieved",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    // 🔍 Get Dealer Investment Files by Dealer Investment ID
    getDealerInvestmentFilesByDealerInvestmentId: async function (req, res) {
        try {
            const { dealer_investment_id } = req.params;
            if (!dealer_investment_id) {
                return res.status(400).send({
                    status: false,
                    message: "dealer_investment_id is required"
                });
            }

            const query = `
        SELECT 
          dif.id,
          dif.dealer_investment_id,
          dif.file,
          dif.type,
          dif.category,
          dif.created_at,
          dif.updated_at,
          dif.isActive,
          dif.isDeleted
        FROM dealer_investment_file dif
        WHERE dif.dealer_investment_id = ? AND (dif.isDeleted = FALSE OR dif.isDeleted = 0)
        ORDER BY dif.created_at DESC, dif.id DESC
      `;
            const data = await connection.query(query, [dealer_investment_id]);

            if (data.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "No files found for this dealer investment",
                    data: []
                });
            }

            return res.status(200).send({
                status: true,
                message: "Dealer investment files retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    // 📝 Update Dealer Investment File
    updateDealerInvestmentFile: async function (req, res) {
        try {
            const { id, type, category, isActive } = req.body;
            const files = req.files;

            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            // Check if file exists
            const exists = await connection.query(
                `SELECT id FROM dealer_investment_file WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Dealer investment file not found"
                });
            }

            // Validate category if provided
            if (category && !["Infrastructure", "Monthly Business Plan"].includes(category)) {
                return res.status(400).send({
                    status: false,
                    message: "Category must be either 'Infrastructure' or 'Monthly Business Plan'"
                });
            }

            // Build update query dynamically based on provided fields
            const updateFields = [];
            const updateValues = [];

            // Handle file upload if new file is provided
            if (files && files.length > 0) {
                const fileUrl = await uploadFile(files[0]);
                if (!fileUrl || typeof fileUrl !== 'string') {
                    return res.status(500).send({
                        status: false,
                        message: "File upload failed"
                    });
                }
                updateFields.push("file = ?");
                updateValues.push(fileUrl);
            }

            if (type !== undefined) {
                updateFields.push("type = ?");
                updateValues.push(type);
            }

            if (category !== undefined) {
                updateFields.push("category = ?");
                updateValues.push(category);
            }

            if (isActive !== undefined) {
                updateFields.push("isActive = ?");
                updateValues.push(isActive);
            }

            if (updateFields.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "At least one field must be provided for update"
                });
            }

            // Always update updated_at
            const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("updated_at = ?");
            updateValues.push(updatedOn);

            updateValues.push(id);

            const updateQuery = `
        UPDATE dealer_investment_file 
        SET ${updateFields.join(", ")}
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;

            const result = await connection.query(updateQuery, updateValues);

            if (result.affectedRows === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Dealer investment file not found or could not be updated"
                });
            }

            return res.status(200).send({
                status: true,
                message: "Dealer investment file updated successfully"
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    // ❌ Delete Dealer Investment File (Soft Delete)
    deleteDealerInvestmentFile: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            // Check if file exists
            const exists = await connection.query(
                `SELECT id FROM dealer_investment_file WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Dealer investment file not found"
                });
            }

            // Soft delete by setting isDeleted = TRUE
            const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const deleteQuery = `
        UPDATE dealer_investment_file 
        SET isDeleted = TRUE, updated_at = ?
        WHERE id = ?
      `;
            const result = await connection.query(deleteQuery, [updatedOn, id]);

            if (result.affectedRows === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Dealer investment file not found"
                });
            }

            return res.status(200).send({
                status: true,
                message: "Dealer investment file deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    }
};
