const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  getAllDealerInvestmentUptimeProjection: async function (req, res) {
    try {
      const { pdpId, pdpUptimeId, dealerInvestmentId } = req.query;
      
      // Build WHERE clause dynamically based on query parameters
      const whereConditions = ["(diu_proj.isDeleted = FALSE OR diu_proj.isDeleted = 0)"];
      const queryValues = [];

      if (pdpId) {
        whereConditions.push("pup.pdpId = ?");
        queryValues.push(pdpId);
      }

      if (pdpUptimeId) {
        whereConditions.push("diu_proj.pdpUptimeId = ?");
        queryValues.push(pdpUptimeId);
      }

      if (dealerInvestmentId) {
        whereConditions.push("diu_proj.dealerInvestmentId = ?");
        queryValues.push(dealerInvestmentId);
      }

      const query = `
        SELECT 
          diu_proj.id,
          diu_proj.pdpUptimeId,
          diu_proj.dealerInvestmentId,
          diu_proj.jan,
          diu_proj.feb,
          diu_proj.mar,
          diu_proj.apr,
          diu_proj.may,
          diu_proj.jun,
          diu_proj.jul,
          diu_proj.aug,
          diu_proj.sep,
          diu_proj.oct,
          diu_proj.nov,
          diu_proj.decem,
          diu_proj.category,
          diu_proj.created_at,
          diu_proj.updated_at,
          diu_proj.isActive,
          diu_proj.isDeleted,
          pup.pdpId,
          pup.uptimePartsId,
          pup.category as pdp_uptime_category,
          pup.target,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          upc.year as uptime_parts_year,
          upc.category as uptime_parts_category,
          upc.equipment_make,
          upc.details,
          upc.measurement_units,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_uptime_projection diu_proj
        LEFT JOIN pdp_uptime_parts pup ON diu_proj.pdpUptimeId = pup.id
        LEFT JOIN pdp p ON pup.pdpId = p.id
        LEFT JOIN uptime_parts_category upc ON pup.uptimePartsId = upc.id
        LEFT JOIN dealer_investment di ON diu_proj.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE ${whereConditions.join(" AND ")}
        ORDER BY diu_proj.created_at DESC, diu_proj.id DESC
      `;
      const data = await connection.query(query, queryValues);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No dealer investment uptime projection records found", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpUptimeId: item.pdpUptimeId,
        dealerInvestmentId: item.dealerInvestmentId,
        jan: item.jan,
        feb: item.feb,
        mar: item.mar,
        apr: item.apr,
        may: item.may,
        jun: item.jun,
        jul: item.jul,
        aug: item.aug,
        sep: item.sep,
        oct: item.oct,
        nov: item.nov,
        decem: item.decem,
        category: item.category,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pdp_uptime_info: {
          pdpId: item.pdpId,
          uptimePartsId: item.uptimePartsId,
          category: item.pdp_uptime_category,
          target: item.target
        },
        pdp_info: {
          year: item.pdp_year,
          market_area: item.pdp_market_area
        },
        uptime_info: {
          uptime_parts_id: item.uptimePartsId,
          year: item.uptime_parts_year,
          category: item.uptime_parts_category,
          equipment_make: item.equipment_make,
          details: item.details,
          measurement_units: item.measurement_units
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment uptime projection list retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  getDealerInvestmentUptimeProjectionById: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      const query = `
        SELECT 
          diu_proj.id,
          diu_proj.pdpUptimeId,
          diu_proj.dealerInvestmentId,
          diu_proj.jan,
          diu_proj.feb,
          diu_proj.mar,
          diu_proj.apr,
          diu_proj.may,
          diu_proj.jun,
          diu_proj.jul,
          diu_proj.aug,
          diu_proj.sep,
          diu_proj.oct,
          diu_proj.nov,
          diu_proj.decem,
          diu_proj.category,
          diu_proj.created_at,
          diu_proj.updated_at,
          diu_proj.isActive,
          diu_proj.isDeleted,
          pup.pdpId,
          pup.uptimePartsId,
          pup.category as pdp_uptime_category,
          pup.target,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          upc.year as uptime_parts_year,
          upc.category as uptime_parts_category,
          upc.equipment_make,
          upc.details,
          upc.measurement_units,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_uptime_projection diu_proj
        LEFT JOIN pdp_uptime_parts pup ON diu_proj.pdpUptimeId = pup.id
        LEFT JOIN pdp p ON pup.pdpId = p.id
        LEFT JOIN uptime_parts_category upc ON pup.uptimePartsId = upc.id
        LEFT JOIN dealer_investment di ON diu_proj.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE diu_proj.id = ? AND (diu_proj.isDeleted = FALSE OR diu_proj.isDeleted = 0)
      `;
      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment uptime projection not found" 
        });
      }

      const result = {
        id: data[0].id,
        pdpUptimeId: data[0].pdpUptimeId,
        dealerInvestmentId: data[0].dealerInvestmentId,
        jan: data[0].jan,
        feb: data[0].feb,
        mar: data[0].mar,
        apr: data[0].apr,
        may: data[0].may,
        jun: data[0].jun,
        jul: data[0].jul,
        aug: data[0].aug,
        sep: data[0].sep,
        oct: data[0].oct,
        nov: data[0].nov,
        decem: data[0].decem,
        category: data[0].category,
        created_at: data[0].created_at,
        updated_at: data[0].updated_at,
        isActive: data[0].isActive,
        isDeleted: data[0].isDeleted,
        pdp_uptime_info: {
          pdpId: data[0].pdpId,
          uptimePartsId: data[0].uptimePartsId,
          category: data[0].pdp_uptime_category,
          target: data[0].target
        },
        pdp_info: {
          year: data[0].pdp_year,
          market_area: data[0].pdp_market_area
        },
        uptime_info: {
          uptime_parts_id: data[0].uptimePartsId,
          year: data[0].uptime_parts_year,
          category: data[0].uptime_parts_category,
          equipment_make: data[0].equipment_make,
          details: data[0].details,
          measurement_units: data[0].measurement_units
        },
        dealer_info: {
          dealer_id: data[0].dealerId,
          dealer_name: data[0].dealerName,
          dealer_short_name: data[0].dealerShortName,
          market_id: data[0].market_id,
          market_area_name: data[0].market_area_name,
          state_id: data[0].state_id
        }
      };

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment uptime projection retrieved", 
        data: result 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  getDealerInvestmentUptimeProjectionByDealerInvestmentId: async function (req, res) {
    try {
      const { dealerInvestmentId } = req.params;
      if (!dealerInvestmentId) {
        return res.status(400).send({ 
          status: false, 
          message: "dealerInvestmentId is required" 
        });
      }

      const query = `
        SELECT 
          diu_proj.id,
          diu_proj.pdpUptimeId,
          diu_proj.dealerInvestmentId,
          diu_proj.jan,
          diu_proj.feb,
          diu_proj.mar,
          diu_proj.apr,
          diu_proj.may,
          diu_proj.jun,
          diu_proj.jul,
          diu_proj.aug,
          diu_proj.sep,
          diu_proj.oct,
          diu_proj.nov,
          diu_proj.decem,
          diu_proj.category,
          diu_proj.created_at,
          diu_proj.updated_at,
          diu_proj.isActive,
          diu_proj.isDeleted,
          pup.pdpId,
          pup.uptimePartsId,
          pup.category as pdp_uptime_category,
          pup.target,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          upc.year as uptime_parts_year,
          upc.category as uptime_parts_category,
          upc.equipment_make,
          upc.details,
          upc.measurement_units,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_uptime_projection diu_proj
        LEFT JOIN pdp_uptime_parts pup ON diu_proj.pdpUptimeId = pup.id
        LEFT JOIN pdp p ON pup.pdpId = p.id
        LEFT JOIN uptime_parts_category upc ON pup.uptimePartsId = upc.id
        LEFT JOIN dealer_investment di ON diu_proj.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE diu_proj.dealerInvestmentId = ? AND (diu_proj.isDeleted = FALSE OR diu_proj.isDeleted = 0)
        ORDER BY diu_proj.created_at DESC, diu_proj.id DESC
      `;
      const data = await connection.query(query, [dealerInvestmentId]);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No dealer investment uptime projection records found for this dealer investment", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpUptimeId: item.pdpUptimeId,
        dealerInvestmentId: item.dealerInvestmentId,
        jan: item.jan,
        feb: item.feb,
        mar: item.mar,
        apr: item.apr,
        may: item.may,
        jun: item.jun,
        jul: item.jul,
        aug: item.aug,
        sep: item.sep,
        oct: item.oct,
        nov: item.nov,
        decem: item.decem,
        category: item.category,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pdp_uptime_info: {
          pdpId: item.pdpId,
          uptimePartsId: item.uptimePartsId,
          category: item.pdp_uptime_category,
          target: item.target
        },
        pdp_info: {
          year: item.pdp_year,
          market_area: item.pdp_market_area
        },
        uptime_info: {
          uptime_parts_id: item.uptimePartsId,
          year: item.uptime_parts_year,
          category: item.uptime_parts_category,
          equipment_make: item.equipment_make,
          details: item.details,
          measurement_units: item.measurement_units
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment uptime projection records retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  getDealerInvestmentUptimeProjectionByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;
      if (!pdpId) {
        return res.status(400).send({ 
          status: false, 
          message: "pdpId is required" 
        });
      }

      const query = `
        SELECT 
          diu_proj.id,
          diu_proj.pdpUptimeId,
          diu_proj.dealerInvestmentId,
          diu_proj.jan,
          diu_proj.feb,
          diu_proj.mar,
          diu_proj.apr,
          diu_proj.may,
          diu_proj.jun,
          diu_proj.jul,
          diu_proj.aug,
          diu_proj.sep,
          diu_proj.oct,
          diu_proj.nov,
          diu_proj.decem,
          diu_proj.category,
          diu_proj.created_at,
          diu_proj.updated_at,
          diu_proj.isActive,
          diu_proj.isDeleted,
          pup.pdpId,
          pup.uptimePartsId,
          pup.category as pdp_uptime_category,
          pup.target,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          upc.year as uptime_parts_year,
          upc.category as uptime_parts_category,
          upc.equipment_make,
          upc.details,
          upc.measurement_units,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_uptime_projection diu_proj
        LEFT JOIN pdp_uptime_parts pup ON diu_proj.pdpUptimeId = pup.id
        LEFT JOIN pdp p ON pup.pdpId = p.id
        LEFT JOIN uptime_parts_category upc ON pup.uptimePartsId = upc.id
        LEFT JOIN dealer_investment di ON diu_proj.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE pup.pdpId = ? AND (diu_proj.isDeleted = FALSE OR diu_proj.isDeleted = 0)
        ORDER BY diu_proj.created_at DESC, diu_proj.id DESC
      `;
      const data = await connection.query(query, [pdpId]);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No dealer investment uptime projection records found for this PDP", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpUptimeId: item.pdpUptimeId,
        dealerInvestmentId: item.dealerInvestmentId,
        jan: item.jan,
        feb: item.feb,
        mar: item.mar,
        apr: item.apr,
        may: item.may,
        jun: item.jun,
        jul: item.jul,
        aug: item.aug,
        sep: item.sep,
        oct: item.oct,
        nov: item.nov,
        decem: item.decem,
        category: item.category,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pdp_uptime_info: {
          pdpId: item.pdpId,
          uptimePartsId: item.uptimePartsId,
          category: item.pdp_uptime_category,
          target: item.target
        },
        pdp_info: {
          year: item.pdp_year,
          market_area: item.pdp_market_area
        },
        uptime_info: {
          uptime_parts_id: item.uptimePartsId,
          year: item.uptime_parts_year,
          category: item.uptime_parts_category,
          equipment_make: item.equipment_make,
          details: item.details,
          measurement_units: item.measurement_units
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment uptime projection records retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  updateDealerInvestmentUptimeProjection: async function (req, res) {
    try {
      const { 
        id, 
        pdpUptimeId, 
        dealerInvestmentId, 
        jan, 
        feb, 
        mar, 
        apr, 
        may, 
        jun, 
        jul, 
        aug, 
        sep, 
        oct, 
        nov, 
        decem, 
        category, 
        isActive 
      } = req.body;

      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      // Check if dealer investment uptime projection exists
      const exists = await connection.query(
        `SELECT id FROM dealer_investment_uptime_projection WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`, 
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment uptime projection not found" 
        });
      }

      // Build update query dynamically based on provided fields
      const updateFields = [];
      const updateValues = [];

      if (pdpUptimeId !== undefined) {
        // Validate pdpUptimeId exists
        const pdpUptimeExists = await connection.query(`SELECT id FROM pdp_uptime_parts WHERE id = ?`, [pdpUptimeId]);
        if (pdpUptimeExists.length === 0) {
          return res.status(400).send({ 
            status: false, 
            message: "Invalid pdpUptimeId: PDP Uptime Parts not found" 
          });
        }
        updateFields.push("pdpUptimeId = ?");
        updateValues.push(pdpUptimeId);
      }

      if (dealerInvestmentId !== undefined) {
        // Validate dealerInvestmentId exists
        const dealerInvestmentExists = await connection.query(`SELECT id FROM dealer_investment WHERE id = ?`, [dealerInvestmentId]);
        if (dealerInvestmentExists.length === 0) {
          return res.status(400).send({ 
            status: false, 
            message: "Invalid dealerInvestmentId: Dealer Investment not found" 
          });
        }
        updateFields.push("dealerInvestmentId = ?");
        updateValues.push(dealerInvestmentId);
      }

      if (jan !== undefined) {
        updateFields.push("jan = ?");
        updateValues.push(jan);
      }

      if (feb !== undefined) {
        updateFields.push("feb = ?");
        updateValues.push(feb);
      }

      if (mar !== undefined) {
        updateFields.push("mar = ?");
        updateValues.push(mar);
      }

      if (apr !== undefined) {
        updateFields.push("apr = ?");
        updateValues.push(apr);
      }

      if (may !== undefined) {
        updateFields.push("may = ?");
        updateValues.push(may);
      }

      if (jun !== undefined) {
        updateFields.push("jun = ?");
        updateValues.push(jun);
      }

      if (jul !== undefined) {
        updateFields.push("jul = ?");
        updateValues.push(jul);
      }

      if (aug !== undefined) {
        updateFields.push("aug = ?");
        updateValues.push(aug);
      }

      if (sep !== undefined) {
        updateFields.push("sep = ?");
        updateValues.push(sep);
      }

      if (oct !== undefined) {
        updateFields.push("oct = ?");
        updateValues.push(oct);
      }

      if (nov !== undefined) {
        updateFields.push("nov = ?");
        updateValues.push(nov);
      }

      if (decem !== undefined) {
        updateFields.push("decem = ?");
        updateValues.push(decem);
      }

      if (category !== undefined) {
        // Validate category
        const validCategories = ["Off Take", "Retails"];
        if (!validCategories.includes(category)) {
          return res.status(400).send({ 
            status: false, 
            message: "Category must be either 'Off Take' or 'Retails'" 
          });
        }
        updateFields.push("category = ?");
        updateValues.push(category);
      }

      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({ 
          status: false, 
          message: "At least one field must be provided for update" 
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE dealer_investment_uptime_projection 
        SET ${updateFields.join(", ")}
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;

      const result = await connection.query(updateQuery, updateValues);

      if (result.affectedRows === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment uptime projection not found or could not be updated" 
        });
      }

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment uptime projection updated successfully" 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  updateMultipleDealerInvestmentUptimeProjection: async function (req, res) {
    try {
      const { rows } = req.body;

      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ 
          status: false, 
          message: "Rows array is required" 
        });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      for (const row of rows) {
        const { id, ...fields } = row;

        if (!id) continue;

        const updateFields = [];
        const updateValues = [];

        for (const key in fields) {
          updateFields.push(`${key} = ?`);
          updateValues.push(fields[key]);
        }

        if (updateFields.length === 0) continue;

        // Always update updated_at
        updateFields.push("updated_at = ?");
        updateValues.push(updatedOn);

        updateValues.push(id);

        const query = `
          UPDATE dealer_investment_uptime_projection 
          SET ${updateFields.join(", ")} 
          WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
        `;

        await connection.query(query, updateValues);
      }

      return res.status(200).send({
        status: true,
        message: "Multiple dealer investment uptime projection rows updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  deleteDealerInvestmentUptimeProjection: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      // Check if dealer investment uptime projection exists
      const exists = await connection.query(
        `SELECT id FROM dealer_investment_uptime_projection WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`, 
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment uptime projection not found" 
        });
      }

      // Soft delete by setting isDeleted = TRUE
      const deleteQuery = `
        UPDATE dealer_investment_uptime_projection 
        SET isDeleted = TRUE
        WHERE id = ?
      `;
      const result = await connection.query(deleteQuery, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment uptime projection not found" 
        });
      }

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment uptime projection deleted successfully" 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  }
};

