const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  getAllDealerInvestmentEquipmentActuals: async function (req, res) {
    try {
      const { pdpId, pdpEquipmentId, dealerInvestmentId } = req.query;
      
      // Build WHERE clause dynamically based on query parameters
      const whereConditions = ["(die_actuals.isDeleted = FALSE OR die_actuals.isDeleted = 0)"];
      const queryValues = [];

      if (pdpId) {
        whereConditions.push("pe.pdpId = ?");
        queryValues.push(pdpId);
      }

      if (pdpEquipmentId) {
        whereConditions.push("die_actuals.pdpEquipmentId = ?");
        queryValues.push(pdpEquipmentId);
      }

      if (dealerInvestmentId) {
        whereConditions.push("die_actuals.dealerInvestmentId = ?");
        queryValues.push(dealerInvestmentId);
      }

      const query = `
        SELECT 
          die_actuals.id,
          die_actuals.pdpEquipmentId,
          die_actuals.dealerInvestmentId,
          die_actuals.jan,
          die_actuals.feb,
          die_actuals.mar,
          die_actuals.apr,
          die_actuals.may,
          die_actuals.jun,
          die_actuals.jul,
          die_actuals.aug,
          die_actuals.sep,
          die_actuals.oct,
          die_actuals.nov,
          die_actuals.decem,
          die_actuals.category,
          die_actuals.created_at,
          die_actuals.updated_at,
          die_actuals.isActive,
          die_actuals.isDeleted,
          pe.pdpId,
          pe.equipmentMasterId,
          pe.category as pdp_equipment_category,
          pe.pdp_target,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_equipment_actuals die_actuals
        LEFT JOIN pdp_equipments pe ON die_actuals.pdpEquipmentId = pe.id
        LEFT JOIN pdp p ON pe.pdpId = p.id
        LEFT JOIN equipments e ON pe.equipmentMasterId = e.id
        LEFT JOIN dealer_investment di ON die_actuals.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE ${whereConditions.join(" AND ")}
        ORDER BY die_actuals.created_at DESC, die_actuals.id DESC
      `;
      const data = await connection.query(query, queryValues);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No dealer investment equipment actuals records found", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpEquipmentId: item.pdpEquipmentId,
        dealerInvestmentId: item.dealerInvestmentId,
        jan: item.jan,
        feb: item.feb,
        mar: item.mar,
        apr: item.apr,
        may: item.may,
        jun: item.jun,
        jul: item.jul,
        aug: item.aug,
        sep: item.sep,
        oct: item.oct,
        nov: item.nov,
        decem: item.decem,
        category: item.category,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pdp_equipment_info: {
          pdpId: item.pdpId,
          equipmentMasterId: item.equipmentMasterId,
          category: item.pdp_equipment_category,
          pdp_target: item.pdp_target
        },
        pdp_info: {
          year: item.pdp_year,
          market_area: item.pdp_market_area
        },
        equipment_info: {
          equipment_id: item.equipmentMasterId,
          year: item.equipment_year,
          equipment_type: item.equipment_type,
          equipment_make: item.equipment_make,
          equipment_line: item.equipment_line,
          equipment_model: item.equipment_model
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment equipment actuals list retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  getDealerInvestmentEquipmentActualsById: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      const query = `
        SELECT 
          die_actuals.id,
          die_actuals.pdpEquipmentId,
          die_actuals.dealerInvestmentId,
          die_actuals.jan,
          die_actuals.feb,
          die_actuals.mar,
          die_actuals.apr,
          die_actuals.may,
          die_actuals.jun,
          die_actuals.jul,
          die_actuals.aug,
          die_actuals.sep,
          die_actuals.oct,
          die_actuals.nov,
          die_actuals.decem,
          die_actuals.category,
          die_actuals.created_at,
          die_actuals.updated_at,
          die_actuals.isActive,
          die_actuals.isDeleted,
          pe.pdpId,
          pe.equipmentMasterId,
          pe.category as pdp_equipment_category,
          pe.pdp_target,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_equipment_actuals die_actuals
        LEFT JOIN pdp_equipments pe ON die_actuals.pdpEquipmentId = pe.id
        LEFT JOIN pdp p ON pe.pdpId = p.id
        LEFT JOIN equipments e ON pe.equipmentMasterId = e.id
        LEFT JOIN dealer_investment di ON die_actuals.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE die_actuals.id = ? AND (die_actuals.isDeleted = FALSE OR die_actuals.isDeleted = 0)
      `;
      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment equipment actuals not found" 
        });
      }

      const result = {
        id: data[0].id,
        pdpEquipmentId: data[0].pdpEquipmentId,
        dealerInvestmentId: data[0].dealerInvestmentId,
        jan: data[0].jan,
        feb: data[0].feb,
        mar: data[0].mar,
        apr: data[0].apr,
        may: data[0].may,
        jun: data[0].jun,
        jul: data[0].jul,
        aug: data[0].aug,
        sep: data[0].sep,
        oct: data[0].oct,
        nov: data[0].nov,
        decem: data[0].decem,
        category: data[0].category,
        created_at: data[0].created_at,
        updated_at: data[0].updated_at,
        isActive: data[0].isActive,
        isDeleted: data[0].isDeleted,
        pdp_equipment_info: {
          pdpId: data[0].pdpId,
          equipmentMasterId: data[0].equipmentMasterId,
          category: data[0].pdp_equipment_category
        },
        pdp_info: {
          year: data[0].pdp_year,
          market_area: data[0].pdp_market_area
        },
        equipment_info: {
          equipment_id: data[0].equipmentMasterId,
          year: data[0].equipment_year,
          equipment_type: data[0].equipment_type,
          equipment_make: data[0].equipment_make,
          equipment_line: data[0].equipment_line,
          equipment_model: data[0].equipment_model
        },
        dealer_info: {
          dealer_id: data[0].dealerId,
          dealer_name: data[0].dealerName,
          dealer_short_name: data[0].dealerShortName,
          market_id: data[0].market_id,
          market_area_name: data[0].market_area_name,
          state_id: data[0].state_id
        }
      };

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment equipment actuals retrieved", 
        data: result 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  getDealerInvestmentEquipmentActualsByDealerInvestmentId: async function (req, res) {
    try {
      const { dealerInvestmentId } = req.params;
      if (!dealerInvestmentId) {
        return res.status(400).send({ 
          status: false, 
          message: "dealerInvestmentId is required" 
        });
      }

      const query = `
        SELECT 
          die_actuals.id,
          die_actuals.pdpEquipmentId,
          die_actuals.dealerInvestmentId,
          die_actuals.jan,
          die_actuals.feb,
          die_actuals.mar,
          die_actuals.apr,
          die_actuals.may,
          die_actuals.jun,
          die_actuals.jul,
          die_actuals.aug,
          die_actuals.sep,
          die_actuals.oct,
          die_actuals.nov,
          die_actuals.decem,
          die_actuals.category,
          die_actuals.created_at,
          die_actuals.updated_at,
          die_actuals.isActive,
          die_actuals.isDeleted,
          pe.pdpId,
          pe.equipmentMasterId,
          pe.category as pdp_equipment_category,
          pe.pdp_target,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_equipment_actuals die_actuals
        LEFT JOIN pdp_equipments pe ON die_actuals.pdpEquipmentId = pe.id
        LEFT JOIN pdp p ON pe.pdpId = p.id
        LEFT JOIN equipments e ON pe.equipmentMasterId = e.id
        LEFT JOIN dealer_investment di ON die_actuals.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE die_actuals.dealerInvestmentId = ? AND (die_actuals.isDeleted = FALSE OR die_actuals.isDeleted = 0)
        ORDER BY die_actuals.created_at DESC, die_actuals.id DESC
      `;
      const data = await connection.query(query, [dealerInvestmentId]);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No dealer investment equipment actuals records found for this dealer investment", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpEquipmentId: item.pdpEquipmentId,
        dealerInvestmentId: item.dealerInvestmentId,
        jan: item.jan,
        feb: item.feb,
        mar: item.mar,
        apr: item.apr,
        may: item.may,
        jun: item.jun,
        jul: item.jul,
        aug: item.aug,
        sep: item.sep,
        oct: item.oct,
        nov: item.nov,
        decem: item.decem,
        category: item.category,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pdp_equipment_info: {
          pdpId: item.pdpId,
          equipmentMasterId: item.equipmentMasterId,
          category: item.pdp_equipment_category,
          pdp_target: item.pdp_target
        },
        pdp_info: {
          year: item.pdp_year,
          market_area: item.pdp_market_area
        },
        equipment_info: {
          equipment_id: item.equipmentMasterId,
          year: item.equipment_year,
          equipment_type: item.equipment_type,
          equipment_make: item.equipment_make,
          equipment_line: item.equipment_line,
          equipment_model: item.equipment_model
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment equipment actuals records retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  getDealerInvestmentEquipmentActualsByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;
      if (!pdpId) {
        return res.status(400).send({ 
          status: false, 
          message: "pdpId is required" 
        });
      }

      const query = `
        SELECT 
          die_actuals.id,
          die_actuals.pdpEquipmentId,
          die_actuals.dealerInvestmentId,
          die_actuals.jan,
          die_actuals.feb,
          die_actuals.mar,
          die_actuals.apr,
          die_actuals.may,
          die_actuals.jun,
          die_actuals.jul,
          die_actuals.aug,
          die_actuals.sep,
          die_actuals.oct,
          die_actuals.nov,
          die_actuals.decem,
          die_actuals.category,
          die_actuals.created_at,
          die_actuals.updated_at,
          die_actuals.isActive,
          die_actuals.isDeleted,
          pe.pdpId,
          pe.equipmentMasterId,
          pe.category as pdp_equipment_category,
          pe.pdp_target,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_equipment_actuals die_actuals
        LEFT JOIN pdp_equipments pe ON die_actuals.pdpEquipmentId = pe.id
        LEFT JOIN pdp p ON pe.pdpId = p.id
        LEFT JOIN equipments e ON pe.equipmentMasterId = e.id
        LEFT JOIN dealer_investment di ON die_actuals.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE pe.pdpId = ? AND (die_actuals.isDeleted = FALSE OR die_actuals.isDeleted = 0)
        ORDER BY die_actuals.created_at DESC, die_actuals.id DESC
      `;
      const data = await connection.query(query, [pdpId]);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No dealer investment equipment actuals records found for this PDP", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpEquipmentId: item.pdpEquipmentId,
        dealerInvestmentId: item.dealerInvestmentId,
        jan: item.jan,
        feb: item.feb,
        mar: item.mar,
        apr: item.apr,
        may: item.may,
        jun: item.jun,
        jul: item.jul,
        aug: item.aug,
        sep: item.sep,
        oct: item.oct,
        nov: item.nov,
        decem: item.decem,
        category: item.category,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pdp_equipment_info: {
          pdpId: item.pdpId,
          equipmentMasterId: item.equipmentMasterId,
          category: item.pdp_equipment_category,
          pdp_target: item.pdp_target
        },
        pdp_info: {
          year: item.pdp_year,
          market_area: item.pdp_market_area
        },
        equipment_info: {
          equipment_id: item.equipmentMasterId,
          year: item.equipment_year,
          equipment_type: item.equipment_type,
          equipment_make: item.equipment_make,
          equipment_line: item.equipment_line,
          equipment_model: item.equipment_model
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment equipment actuals records retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  updateDealerInvestmentEquipmentActuals: async function (req, res) {
    try {
      const { 
        id, 
        pdpEquipmentId, 
        dealerInvestmentId, 
        jan, 
        feb, 
        mar, 
        apr, 
        may, 
        jun, 
        jul, 
        aug, 
        sep, 
        oct, 
        nov, 
        decem, 
        category, 
        isActive 
      } = req.body;

      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      // Check if dealer investment equipment actuals exists
      const exists = await connection.query(
        `SELECT id FROM dealer_investment_equipment_actuals WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`, 
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment equipment actuals not found" 
        });
      }

      // Build update query dynamically based on provided fields
      const updateFields = [];
      const updateValues = [];

      if (pdpEquipmentId !== undefined) {
        // Validate pdpEquipmentId exists
        const pdpEquipmentExists = await connection.query(`SELECT id FROM pdp_equipments WHERE id = ?`, [pdpEquipmentId]);
        if (pdpEquipmentExists.length === 0) {
          return res.status(400).send({ 
            status: false, 
            message: "Invalid pdpEquipmentId: PDP Equipment not found" 
          });
        }
        updateFields.push("pdpEquipmentId = ?");
        updateValues.push(pdpEquipmentId);
      }

      if (dealerInvestmentId !== undefined) {
        // Validate dealerInvestmentId exists
        const dealerInvestmentExists = await connection.query(`SELECT id FROM dealer_investment WHERE id = ?`, [dealerInvestmentId]);
        if (dealerInvestmentExists.length === 0) {
          return res.status(400).send({ 
            status: false, 
            message: "Invalid dealerInvestmentId: Dealer Investment not found" 
          });
        }
        updateFields.push("dealerInvestmentId = ?");
        updateValues.push(dealerInvestmentId);
      }

      if (jan !== undefined) {
        updateFields.push("jan = ?");
        updateValues.push(jan);
      }

      if (feb !== undefined) {
        updateFields.push("feb = ?");
        updateValues.push(feb);
      }

      if (mar !== undefined) {
        updateFields.push("mar = ?");
        updateValues.push(mar);
      }

      if (apr !== undefined) {
        updateFields.push("apr = ?");
        updateValues.push(apr);
      }

      if (may !== undefined) {
        updateFields.push("may = ?");
        updateValues.push(may);
      }

      if (jun !== undefined) {
        updateFields.push("jun = ?");
        updateValues.push(jun);
      }

      if (jul !== undefined) {
        updateFields.push("jul = ?");
        updateValues.push(jul);
      }

      if (aug !== undefined) {
        updateFields.push("aug = ?");
        updateValues.push(aug);
      }

      if (sep !== undefined) {
        updateFields.push("sep = ?");
        updateValues.push(sep);
      }

      if (oct !== undefined) {
        updateFields.push("oct = ?");
        updateValues.push(oct);
      }

      if (nov !== undefined) {
        updateFields.push("nov = ?");
        updateValues.push(nov);
      }

      if (decem !== undefined) {
        updateFields.push("decem = ?");
        updateValues.push(decem);
      }

      if (category !== undefined) {
        // Validate category
        const validCategories = ["Key Account", "Retails"];
        if (!validCategories.includes(category)) {
          return res.status(400).send({ 
            status: false, 
            message: "Category must be either 'Key Account' or 'Retails'" 
          });
        }
        updateFields.push("category = ?");
        updateValues.push(category);
      }

      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({ 
          status: false, 
          message: "At least one field must be provided for update" 
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE dealer_investment_equipment_actuals 
        SET ${updateFields.join(", ")}
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;

      const result = await connection.query(updateQuery, updateValues);

      if (result.affectedRows === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment equipment actuals not found or could not be updated" 
        });
      }

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment equipment actuals updated successfully" 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  updateMultipleDealerInvestmentEquipmentActuals: async function (req, res) {
    try {
      const { rows } = req.body;

      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ 
          status: false, 
          message: "Rows array is required" 
        });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      for (const row of rows) {
        const { id, ...fields } = row;

        if (!id) continue;

        const updateFields = [];
        const updateValues = [];

        for (const key in fields) {
          updateFields.push(`${key} = ?`);
          updateValues.push(fields[key]);
        }

        if (updateFields.length === 0) continue;

        // Always update updated_at
        updateFields.push("updated_at = ?");
        updateValues.push(updatedOn);

        updateValues.push(id);

        const query = `
          UPDATE dealer_investment_equipment_actuals 
          SET ${updateFields.join(", ")} 
          WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
        `;

        await connection.query(query, updateValues);
      }

      return res.status(200).send({
        status: true,
        message: "Multiple dealer investment equipment actuals rows updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  deleteDealerInvestmentEquipmentActuals: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      // Check if dealer investment equipment actuals exists
      const exists = await connection.query(
        `SELECT id FROM dealer_investment_equipment_actuals WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`, 
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment equipment actuals not found" 
        });
      }

      // Soft delete by setting isDeleted = TRUE
      const deleteQuery = `
        UPDATE dealer_investment_equipment_actuals 
        SET isDeleted = TRUE
        WHERE id = ?
      `;
      const result = await connection.query(deleteQuery, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment equipment actuals not found" 
        });
      }

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment equipment actuals deleted successfully" 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  }
};

