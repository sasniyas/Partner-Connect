const { connection } = require("../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  getAllDealerInvestment: async function (req, res) {
    try {
      // Extract userId from decoded token
      const userId = req.decodedToken;

      if (!userId) {
        return res.status(401).send({ status: false, message: "User not authenticated" });
      }

      // Fetch user persona and marketArea from userdetails table
      const userQuery = `
        SELECT persona, marketArea 
        FROM userdetails 
        WHERE id = ?
      `;
      const userResult = await connection.query(userQuery, [userId]);

      if (userResult.length === 0) {
        return res.status(404).send({ status: false, message: "User not found" });
      }

      const userPersona = userResult[0].persona;
      let userMarketArea = userResult[0].marketArea;

      // Debug logging
      console.log(`[getAllDealerInvestment] User ID: ${userId}`);
      console.log(`[getAllDealerInvestment] User Persona: "${userPersona}"`);
      console.log(`[getAllDealerInvestment] User Market Area (raw): ${userMarketArea}`);

      // If marketArea is a string (name), convert it to ID
      if (userMarketArea && isNaN(userMarketArea)) {
        const marketAreaQuery = `
          SELECT id FROM market_area WHERE marketarea = ?
        `;
        const marketAreaResult = await connection.query(marketAreaQuery, [userMarketArea]);
        if (marketAreaResult.length > 0) {
          userMarketArea = marketAreaResult[0].id;
          console.log(`[getAllDealerInvestment] Converted Market Area name to ID: ${userMarketArea}`);
        } else {
          console.log(`[getAllDealerInvestment] WARNING: Market Area "${userMarketArea}" not found in market_area table`);
          userMarketArea = null;
        }
      }

      // Define personas with full access (can see all dealer investments)
      const fullAccessPersonas = [
        'Administrator',
        'Volvo Functional Manager',
        'IMT',
        'Head of Channel Development Region India'
      ];

      // Define personas with restricted access (can only see dealer investments for their mapped dealers)
      const restrictedAccessPersonas = [
        'Dealer Parts Manager',
        'Dealer Coordinator',
        'Dealer sales head',
        'Dealer CST Head',
        'Dealer Finance Head',
        'Dealer HR Head',
        'Dealer Principal',
        'Dealer CEO'
      ];

      // Define personas with market area restriction (can see dealer investments for mapped dealers AND their market area)
      const restrictedMarketArea = [
        'Uptime & Parts Manager',
        'Retail Sales Manager',
        'Key Account Manager Uptime & Parts',
        'Key Account Manager Sales',
        'Market Area Head'
      ];

      // Pagination: default page 1, limit 300
      const page = req.query.page && !isNaN(parseInt(req.query.page)) ? parseInt(req.query.page) : 1;
      const limit = 300;
      const offset = (page - 1) * limit;

      // Extract filters
      const { year, market_area, dealer, search, mbpStatusEquipments, mbpStatusUap } = req.query;

      let baseQuery = `
          SELECT 
            di.id,
            di.pdpId,
            di.dealerId,
            di.created_at,
            di.updated_at,
            di.isActive,
            di.isDeleted,
            di.mbpStatusEquipments,
            di.mbpStatusUap,
            p.year,
            p.market_area,
            p.dealer as pdp_dealer,
            p.choose_dealer,
            p.pdp_start_date,
            p.pdp_end_date,
            p.physical_pdp_start_date,
            p.physical_pdp_end_date,
            p.sign_of_status,
            dm.dealerName,
            dm.dealerShortName,
            dm.market_id,
            dm.state_id,
            ma.marketarea as market_area_name
          FROM dealer_investment di
          LEFT JOIN pdp p ON di.pdpId = p.id
          LEFT JOIN dealer_master dm ON di.dealerId = dm.id
          LEFT JOIN market_area ma ON dm.market_id = ma.id
      `;

      let accessControlWhere = "";
      let accessControlParams = [];

      if (fullAccessPersonas.includes(userPersona)) {
        console.log(`[getAllDealerInvestment] Access Level: Full Access`);
        accessControlWhere = "(di.isDeleted = FALSE OR di.isDeleted = 0)";
      } else if (restrictedMarketArea.includes(userPersona)) {
        console.log(`[getAllDealerInvestment] Access Level: Market Area Restricted`);
        if (!userMarketArea) {
          accessControlWhere = "(di.dealerId IN (SELECT dealerId FROM userdealers WHERE userId = ?)) AND (di.isDeleted = FALSE OR di.isDeleted = 0)";
          accessControlParams = [userId];
        } else {
          accessControlWhere = "(dm.market_id = ? OR di.dealerId IN (SELECT dealerId FROM userdealers WHERE userId = ?)) AND (di.isDeleted = FALSE OR di.isDeleted = 0)";
          accessControlParams = [userMarketArea, userId];
        }
      } else if (restrictedAccessPersonas.includes(userPersona)) {
        console.log(`[getAllDealerInvestment] Access Level: Dealer Restricted`);
        accessControlWhere = "di.dealerId IN (SELECT dealerId FROM userdealers WHERE userId = ?) AND (di.isDeleted = FALSE OR di.isDeleted = 0)";
        accessControlParams = [userId];
      } else {
        console.log(`[getAllDealerInvestment] Access Level: DENIED - Unknown persona`);
        return res.status(403).send({
          status: false,
          message: "Access denied: Your persona does not have permission to view dealer investments"
        });
      }

      // Dynamic Filters
      let filterWhere = [];
      let filterParams = [];

      // Helper to process multiple selection (handles arrays and comma-separated strings)
      const getFilterArray = (val) => {
        if (!val) return [];
        if (Array.isArray(val)) return val.filter(v => typeof v === 'string' ? v.trim() !== "" : v !== null);
        return typeof val === 'string' ? val.split(',').map(v => v.trim()).filter(v => v !== "") : [val];
      };

      const yearArr = getFilterArray(year);
      if (yearArr.length > 0) {
        filterWhere.push("p.year IN (?)");
        filterParams.push(yearArr);
      }

      const marketAreaArr = getFilterArray(market_area);
      if (marketAreaArr.length > 0) {
        // If filtering by name or ID (Check first element to decide column)
        if (isNaN(marketAreaArr[0])) {
          filterWhere.push("ma.marketarea IN (?)");
        } else {
          filterWhere.push("dm.market_id IN (?)");
        }
        filterParams.push(marketAreaArr);
      }

      const dealerArr = getFilterArray(dealer);
      if (dealerArr.length > 0) {
        // If filtering by name or ID
        if (isNaN(dealerArr[0])) {
          filterWhere.push("(dm.dealerName IN (?) OR dm.dealerShortName IN (?))");
          filterParams.push(dealerArr, dealerArr);
        } else {
          filterWhere.push("di.dealerId IN (?)");
          filterParams.push(dealerArr);
        }
      }

      const mbpStatusEquipmentsArr = getFilterArray(mbpStatusEquipments);
      if (mbpStatusEquipmentsArr.length > 0) {
        filterWhere.push("di.mbpStatusEquipments IN (?)");
        filterParams.push(mbpStatusEquipmentsArr);
      }

      const mbpStatusUapArr = getFilterArray(mbpStatusUap);
      if (mbpStatusUapArr.length > 0) {
        filterWhere.push("di.mbpStatusUap IN (?)");
        filterParams.push(mbpStatusUapArr);
      }

      if (search && search.trim() !== "") {
        const searchTerm = `%${search.trim()}%`;
        filterWhere.push("(p.year LIKE ? OR ma.marketarea LIKE ? OR dm.dealerName LIKE ?)");
        filterParams.push(searchTerm, searchTerm, searchTerm);
      }

      let finalQuery = `
          SELECT * FROM (
            ${baseQuery}
            WHERE ${accessControlWhere}
            ${filterWhere.length > 0 ? "AND " + filterWhere.join(" AND ") : ""}
          ) as derived_table
          ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?
      `;

      let finalParams = [...accessControlParams, ...filterParams, limit, offset];

      console.log(`[getAllDealerInvestment] Final Query: ${finalQuery}`);
      console.log(`[getAllDealerInvestment] Params: ${JSON.stringify(finalParams)}`);

      const data = await connection.query(finalQuery, finalParams);

      console.log(`[getAllDealerInvestment] Query returned ${data.length} dealer investments`);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No dealer investment records found",
          data: []
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpId: item.pdpId,
        dealerId: item.dealerId,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        mbpStatusEquipments: item.mbpStatusEquipments,
        mbpStatusUap: item.mbpStatusUap,
        pdp_info: {
          year: item.year,
          market_area: item.market_area,
          dealer: item.pdp_dealer,
          choose_dealer: item.choose_dealer,
          pdp_start_date: item.pdp_start_date,
          pdp_end_date: item.pdp_end_date,
          physical_pdp_start_date: item.physical_pdp_start_date,
          physical_pdp_end_date: item.physical_pdp_end_date,
          sign_of_status: item.sign_of_status
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({
        status: true,
        message: "Dealer investment list retrieved",
        data: formattedData
      });
    } catch (error) {
      console.error(`[getAllDealerInvestment] Error:`, error);
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getDealerInvestmentById: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      const query = `
        SELECT 
          di.id,
          di.pdpId,
          di.dealerId,
          di.created_at,
          di.updated_at,
          di.isActive,
          di.isDeleted,
          di.mbpStatusEquipments,
          di.mbpStatusUap,
          p.year,
          p.market_area,
          p.dealer as pdp_dealer,
          p.choose_dealer,
          p.pdp_start_date,
          p.pdp_end_date,
          p.physical_pdp_start_date,
          p.physical_pdp_end_date,
          p.sign_of_status,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment di
        LEFT JOIN pdp p ON di.pdpId = p.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE di.id = ? AND (di.isDeleted = FALSE OR di.isDeleted = 0)
      `;
      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Dealer investment not found"
        });
      }

      const result = {
        id: data[0].id,
        pdpId: data[0].pdpId,
        dealerId: data[0].dealerId,
        created_at: data[0].created_at,
        updated_at: data[0].updated_at,
        isActive: data[0].isActive,
        isDeleted: data[0].isDeleted,
        mbpStatusEquipments: data[0].mbpStatusEquipments,
        mbpStatusUap: data[0].mbpStatusUap,
        pdp_info: {
          year: data[0].year,
          market_area: data[0].market_area,
          dealer: data[0].pdp_dealer,
          choose_dealer: data[0].choose_dealer,
          pdp_start_date: data[0].pdp_start_date,
          pdp_end_date: data[0].pdp_end_date,
          physical_pdp_start_date: data[0].physical_pdp_start_date,
          physical_pdp_end_date: data[0].physical_pdp_end_date,
          sign_of_status: data[0].sign_of_status
        },
        dealer_info: {
          dealer_id: data[0].dealerId,
          dealer_name: data[0].dealerName,
          dealer_short_name: data[0].dealerShortName,
          market_id: data[0].market_id,
          market_area_name: data[0].market_area_name,
          state_id: data[0].state_id
        }
      };

      return res.status(200).send({
        status: true,
        message: "Dealer investment retrieved",
        data: result
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getDealerInvestmentBypdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;
      if (!pdpId) {
        return res.status(400).send({
          status: false,
          message: "pdpId is required"
        });
      }

      const query = `
        SELECT 
          di.id,
          di.pdpId,
          di.dealerId,
          di.created_at,
          di.updated_at,
          di.isActive,
          di.isDeleted,
          di.mbpStatusEquipments,
          di.mbpStatusUap,
          p.year,
          p.market_area,
          p.dealer as pdp_dealer,
          p.choose_dealer,
          p.pdp_start_date,
          p.pdp_end_date,
          p.physical_pdp_start_date,
          p.physical_pdp_end_date,
          p.sign_of_status,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment di
        LEFT JOIN pdp p ON di.pdpId = p.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE di.pdpId = ? AND (di.isDeleted = FALSE OR di.isDeleted = 0)
        ORDER BY di.created_at DESC, di.id DESC
      `;
      const data = await connection.query(query, [pdpId]);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No dealer investment records found for this PDP",
          data: []
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpId: item.pdpId,
        dealerId: item.dealerId,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        mbpStatusEquipments: item.mbpStatusEquipments,
        mbpStatusUap: item.mbpStatusUap,
        pdp_info: {
          year: item.year,
          market_area: item.market_area,
          dealer: item.pdp_dealer,
          choose_dealer: item.choose_dealer,
          pdp_start_date: item.pdp_start_date,
          pdp_end_date: item.pdp_end_date,
          physical_pdp_start_date: item.physical_pdp_start_date,
          physical_pdp_end_date: item.physical_pdp_end_date,
          sign_of_status: item.sign_of_status
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({
        status: true,
        message: "Dealer investment records retrieved",
        data: formattedData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  updateDealerInvestment: async function (req, res) {
    try {
      const { id, pdpId, dealerId, isActive } = req.body;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      // Check if dealer investment exists
      const exists = await connection.query(
        `SELECT id FROM dealer_investment WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Dealer investment not found"
        });
      }

      // Build update query dynamically based on provided fields
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        // Validate pdpId exists
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ?`, [pdpId]);
        if (pdpExists.length === 0) {
          return res.status(400).send({
            status: false,
            message: "Invalid pdpId: PDP not found"
          });
        }
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }

      if (dealerId !== undefined) {
        // Validate dealerId exists
        const dealerExists = await connection.query(`SELECT id FROM dealer_master WHERE id = ?`, [dealerId]);
        if (dealerExists.length === 0) {
          return res.status(400).send({
            status: false,
            message: "Invalid dealerId: Dealer not found"
          });
        }
        updateFields.push("dealerId = ?");
        updateValues.push(dealerId);
      }

      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "At least one field (pdpId, dealerId, or isActive) must be provided for update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE dealer_investment 
        SET ${updateFields.join(", ")}
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;

      const result = await connection.query(updateQuery, updateValues);

      if (result.affectedRows === 0) {
        return res.status(404).send({
          status: false,
          message: "Dealer investment not found or could not be updated"
        });
      }

      return res.status(200).send({
        status: true,
        message: "Dealer investment updated successfully"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  deleteDealerInvestment: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      // Check if dealer investment exists
      const exists = await connection.query(
        `SELECT id FROM dealer_investment WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Dealer investment not found"
        });
      }

      // Soft delete by setting isDeleted = TRUE
      const deleteQuery = `
        UPDATE dealer_investment 
        SET isDeleted = TRUE
        WHERE id = ?
      `;
      const result = await connection.query(deleteQuery, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({
          status: false,
          message: "Dealer investment not found"
        });
      }

      return res.status(200).send({
        status: true,
        message: "Dealer investment deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  mbpStatusEquipmentsChange: async function (req, res) {
    try {
      const { id, status } = req.body;

      // Validate required fields
      if (!id || !status) {
        return res.status(400).send({
          status: false,
          message: "Required: id and status"
        });
      }

      // Check if dealer investment exists
      const dealerInvestmentExists = await connection.query(
        `SELECT id, mbpStatusEquipments FROM dealer_investment WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
        [id]
      );
      if (dealerInvestmentExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Dealer investment not found"
        });
      }

      // Map status to mbpStatusEquipments values
      let mbpStatusEquipments;
      switch (status) {
        case "Submitted":
          mbpStatusEquipments = "Submitted";
          break;
        case "Requested":
          mbpStatusEquipments = "Requested";
          break;
        case "Disabled":
          mbpStatusEquipments = "Submitted";
          break;
        case "Enable":
          mbpStatusEquipments = "Enable";
          break;
        default:
          return res.status(400).send({
            status: false,
            message: "Invalid status. Allowed values: Submitted, Requested, Disabled, Enable"
          });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Update mbpStatusEquipments
      const updateQuery = `
        UPDATE dealer_investment
        SET mbpStatusEquipments = ?, updated_at = ?
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;
      await connection.query(updateQuery, [mbpStatusEquipments, updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: `MBP Status Equipments updated to ${mbpStatusEquipments} successfully`
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  mbpStatusUapChange: async function (req, res) {
    try {
      const { id, status } = req.body;

      // Validate required fields
      if (!id || !status) {
        return res.status(400).send({
          status: false,
          message: "Required: id and status"
        });
      }

      // Check if dealer investment exists
      const dealerInvestmentExists = await connection.query(
        `SELECT id, mbpStatusUap FROM dealer_investment WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
        [id]
      );
      if (dealerInvestmentExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Dealer investment not found"
        });
      }

      // Map status to mbpStatusUap values
      let mbpStatusUap;
      switch (status) {
        case "Submitted":
          mbpStatusUap = "Submitted";
          break;
        case "Requested":
          mbpStatusUap = "Requested";
          break;
        case "Disabled":
          mbpStatusUap = "Submitted";
          break;
        case "Enable":
          mbpStatusUap = "Enable";
          break;
        default:
          return res.status(400).send({
            status: false,
            message: "Invalid status. Allowed values: Submitted, Requested, Disabled, Enable"
          });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Update mbpStatusUap
      const updateQuery = `
        UPDATE dealer_investment
        SET mbpStatusUap = ?, updated_at = ?
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;
      await connection.query(updateQuery, [mbpStatusUap, updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: `MBP Status UAP updated to ${mbpStatusUap} successfully`
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  }
};

