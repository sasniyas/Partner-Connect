const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { recalculateClosingStockForAllocation } = require('../allocationManagement/inventory/inventoryData.controller');

module.exports = {
    getAllDealerInvestmentAllocation: async function (req, res) {
        try {
            const { equipmentId, dealerInvestmentId } = req.query;

            // Build WHERE clause dynamically based on query parameters
            const whereConditions = ["(dia.isDeleted = FALSE OR dia.isDeleted = 0)"];
            const queryValues = [];

            if (equipmentId) {
                whereConditions.push("dia.equipmentId = ?");
                queryValues.push(equipmentId);
            }

            if (dealerInvestmentId) {
                whereConditions.push("dia.dealerInvestmentId = ?");
                queryValues.push(dealerInvestmentId);
            }

            const query = `
        SELECT 
          dia.id,
          dia.equipmentId,
          dia.dealerInvestmentId,
          dia.jan,
          dia.feb,
          dia.mar,
          dia.apr,
          dia.may,
          dia.jun,
          dia.jul,
          dia.aug,
          dia.sep,
          dia.oct,
          dia.nov,
          dia.decem,
          dia.created_at,
          dia.updated_at,
          dia.isActive,
          dia.isDeleted,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model,
          di.pdpId,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name,
          p.year as pdp_year,
          p.market_area as pdp_market_area
        FROM dealer_investment_allocation dia
        LEFT JOIN equipments e ON dia.equipmentId = e.id
        LEFT JOIN dealer_investment di ON dia.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        LEFT JOIN pdp p ON di.pdpId = p.id
        WHERE ${whereConditions.join(" AND ")}
        ORDER BY dia.created_at DESC, dia.id DESC
      `;
            const data = await connection.query(query, queryValues);

            if (data.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "No dealer investment allocation records found",
                    data: []
                });
            }

            const formattedData = data.map(item => ({
                id: item.id,
                equipmentId: item.equipmentId,
                dealerInvestmentId: item.dealerInvestmentId,
                jan: item.jan,
                feb: item.feb,
                mar: item.mar,
                apr: item.apr,
                may: item.may,
                jun: item.jun,
                jul: item.jul,
                aug: item.aug,
                sep: item.sep,
                oct: item.oct,
                nov: item.nov,
                decem: item.decem,
                created_at: item.created_at,
                updated_at: item.updated_at,
                isActive: item.isActive,
                isDeleted: item.isDeleted,
                equipment_info: {
                    equipment_id: item.equipmentId,
                    year: item.equipment_year,
                    equipment_type: item.equipment_type,
                    equipment_make: item.equipment_make,
                    equipment_line: item.equipment_line,
                    equipment_model: item.equipment_model
                },
                dealer_investment_info: {
                    pdpId: item.pdpId,
                    dealerId: item.dealerId
                },
                pdp_info: {
                    year: item.pdp_year,
                    market_area: item.pdp_market_area
                },
                dealer_info: {
                    dealer_id: item.dealerId,
                    dealer_name: item.dealerName,
                    dealer_short_name: item.dealerShortName,
                    market_id: item.market_id,
                    market_area_name: item.market_area_name,
                    state_id: item.state_id
                }
            }));

            return res.status(200).send({
                status: true,
                message: "Dealer investment allocation list retrieved",
                data: formattedData
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    getDealerInvestmentAllocationById: async function (req, res) {
        try {
            const { id } = req.params;
            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            const query = `
        SELECT 
          dia.id,
          dia.equipmentId,
          dia.dealerInvestmentId,
          dia.jan,
          dia.feb,
          dia.mar,
          dia.apr,
          dia.may,
          dia.jun,
          dia.jul,
          dia.aug,
          dia.sep,
          dia.oct,
          dia.nov,
          dia.decem,
          dia.created_at,
          dia.updated_at,
          dia.isActive,
          dia.isDeleted,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model,
          di.pdpId,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name,
          p.year as pdp_year,
          p.market_area as pdp_market_area
        FROM dealer_investment_allocation dia
        LEFT JOIN equipments e ON dia.equipmentId = e.id
        LEFT JOIN dealer_investment di ON dia.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        LEFT JOIN pdp p ON di.pdpId = p.id
        WHERE dia.id = ? AND (dia.isDeleted = FALSE OR dia.isDeleted = 0)
      `;
            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Dealer investment allocation not found"
                });
            }

            const result = {
                id: data[0].id,
                equipmentId: data[0].equipmentId,
                dealerInvestmentId: data[0].dealerInvestmentId,
                jan: data[0].jan,
                feb: data[0].feb,
                mar: data[0].mar,
                apr: data[0].apr,
                may: data[0].may,
                jun: data[0].jun,
                jul: data[0].jul,
                aug: data[0].aug,
                sep: data[0].sep,
                oct: data[0].oct,
                nov: data[0].nov,
                decem: data[0].decem,
                created_at: data[0].created_at,
                updated_at: data[0].updated_at,
                isActive: data[0].isActive,
                isDeleted: data[0].isDeleted,
                equipment_info: {
                    equipment_id: data[0].equipmentId,
                    year: data[0].equipment_year,
                    equipment_type: data[0].equipment_type,
                    equipment_make: data[0].equipment_make,
                    equipment_line: data[0].equipment_line,
                    equipment_model: data[0].equipment_model
                },
                dealer_investment_info: {
                    pdpId: data[0].pdpId,
                    dealerId: data[0].dealerId
                },
                pdp_info: {
                    year: data[0].pdp_year,
                    market_area: data[0].pdp_market_area
                },
                dealer_info: {
                    dealer_id: data[0].dealerId,
                    dealer_name: data[0].dealerName,
                    dealer_short_name: data[0].dealerShortName,
                    market_id: data[0].market_id,
                    market_area_name: data[0].market_area_name,
                    state_id: data[0].state_id
                }
            };

            return res.status(200).send({
                status: true,
                message: "Dealer investment allocation retrieved",
                data: result
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    getDealerInvestmentAllocationByDealerInvestmentId: async function (req, res) {
        try {
            const { dealerInvestmentId } = req.params;
            if (!dealerInvestmentId) {
                return res.status(400).send({
                    status: false,
                    message: "dealerInvestmentId is required"
                });
            }

            const query = `
        SELECT 
          dia.id,
          dia.equipmentId,
          dia.dealerInvestmentId,
          dia.jan,
          dia.feb,
          dia.mar,
          dia.apr,
          dia.may,
          dia.jun,
          dia.jul,
          dia.aug,
          dia.sep,
          dia.oct,
          dia.nov,
          dia.decem,
          dia.created_at,
          dia.updated_at,
          dia.isActive,
          dia.isDeleted,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model,
          di.pdpId,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name,
          p.year as pdp_year,
          p.market_area as pdp_market_area
        FROM dealer_investment_allocation dia
        LEFT JOIN equipments e ON dia.equipmentId = e.id
        LEFT JOIN dealer_investment di ON dia.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        LEFT JOIN pdp p ON di.pdpId = p.id
        WHERE dia.dealerInvestmentId = ? AND (dia.isDeleted = FALSE OR dia.isDeleted = 0)
        ORDER BY dia.created_at DESC, dia.id DESC
      `;
            const data = await connection.query(query, [dealerInvestmentId]);

            if (data.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "No dealer investment allocation records found for this dealer investment",
                    data: []
                });
            }

            const formattedData = data.map(item => ({
                id: item.id,
                equipmentId: item.equipmentId,
                dealerInvestmentId: item.dealerInvestmentId,
                jan: item.jan,
                feb: item.feb,
                mar: item.mar,
                apr: item.apr,
                may: item.may,
                jun: item.jun,
                jul: item.jul,
                aug: item.aug,
                sep: item.sep,
                oct: item.oct,
                nov: item.nov,
                decem: item.decem,
                created_at: item.created_at,
                updated_at: item.updated_at,
                isActive: item.isActive,
                isDeleted: item.isDeleted,
                equipment_info: {
                    equipment_id: item.equipmentId,
                    year: item.equipment_year,
                    equipment_type: item.equipment_type,
                    equipment_make: item.equipment_make,
                    equipment_line: item.equipment_line,
                    equipment_model: item.equipment_model
                },
                dealer_investment_info: {
                    pdpId: item.pdpId,
                    dealerId: item.dealerId
                },
                pdp_info: {
                    year: item.pdp_year,
                    market_area: item.pdp_market_area
                },
                dealer_info: {
                    dealer_id: item.dealerId,
                    dealer_name: item.dealerName,
                    dealer_short_name: item.dealerShortName,
                    market_id: item.market_id,
                    market_area_name: item.market_area_name,
                    state_id: item.state_id
                }
            }));

            return res.status(200).send({
                status: true,
                message: "Dealer investment allocation records retrieved",
                data: formattedData
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    getDealerInvestmentAllocationByPdpId: async function (req, res) {
        try {
            const { pdpId } = req.params;
            if (!pdpId) {
                return res.status(400).send({
                    status: false,
                    message: "pdpId is required"
                });
            }

            const query = `
        SELECT 
          dia.id,
          dia.equipmentId,
          dia.dealerInvestmentId,
          dia.jan,
          dia.feb,
          dia.mar,
          dia.apr,
          dia.may,
          dia.jun,
          dia.jul,
          dia.aug,
          dia.sep,
          dia.oct,
          dia.nov,
          dia.decem,
          dia.created_at,
          dia.updated_at,
          dia.isActive,
          dia.isDeleted,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model,
          di.pdpId,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name,
          p.year as pdp_year,
          p.market_area as pdp_market_area
        FROM dealer_investment_allocation dia
        LEFT JOIN equipments e ON dia.equipmentId = e.id
        LEFT JOIN dealer_investment di ON dia.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        LEFT JOIN pdp p ON di.pdpId = p.id
        WHERE di.pdpId = ? AND (dia.isDeleted = FALSE OR dia.isDeleted = 0)
        ORDER BY dia.created_at DESC, dia.id DESC
      `;
            const data = await connection.query(query, [pdpId]);

            if (data.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "No dealer investment allocation records found for this PDP",
                    data: []
                });
            }

            const formattedData = data.map(item => ({
                id: item.id,
                equipmentId: item.equipmentId,
                dealerInvestmentId: item.dealerInvestmentId,
                jan: item.jan,
                feb: item.feb,
                mar: item.mar,
                apr: item.apr,
                may: item.may,
                jun: item.jun,
                jul: item.jul,
                aug: item.aug,
                sep: item.sep,
                oct: item.oct,
                nov: item.nov,
                decem: item.decem,
                created_at: item.created_at,
                updated_at: item.updated_at,
                isActive: item.isActive,
                isDeleted: item.isDeleted,
                equipment_info: {
                    equipment_id: item.equipmentId,
                    year: item.equipment_year,
                    equipment_type: item.equipment_type,
                    equipment_make: item.equipment_make,
                    equipment_line: item.equipment_line,
                    equipment_model: item.equipment_model
                },
                dealer_investment_info: {
                    pdpId: item.pdpId,
                    dealerId: item.dealerId
                },
                pdp_info: {
                    year: item.pdp_year,
                    market_area: item.pdp_market_area
                },
                dealer_info: {
                    dealer_id: item.dealerId,
                    dealer_name: item.dealerName,
                    dealer_short_name: item.dealerShortName,
                    market_id: item.market_id,
                    market_area_name: item.market_area_name,
                    state_id: item.state_id
                }
            }));

            return res.status(200).send({
                status: true,
                message: "Dealer investment allocation records retrieved",
                data: formattedData
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    updateDealerInvestmentAllocation: async function (req, res) {
        try {
            const {
                id,
                equipmentId,
                dealerInvestmentId,
                jan,
                feb,
                mar,
                apr,
                may,
                jun,
                jul,
                aug,
                sep,
                oct,
                nov,
                decem,
                isActive
            } = req.body;

            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            // Check if dealer investment allocation exists
            const exists = await connection.query(
                `SELECT id FROM dealer_investment_allocation WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Dealer investment allocation not found"
                });
            }

            // Build update query dynamically based on provided fields
            const updateFields = [];
            const updateValues = [];

            if (equipmentId !== undefined) {
                // Validate equipmentId exists
                const equipmentExists = await connection.query(`SELECT id FROM equipments WHERE id = ?`, [equipmentId]);
                if (equipmentExists.length === 0) {
                    return res.status(400).send({
                        status: false,
                        message: "Invalid equipmentId: Equipment not found"
                    });
                }
                updateFields.push("equipmentId = ?");
                updateValues.push(equipmentId);
            }

            if (dealerInvestmentId !== undefined) {
                // Validate dealerInvestmentId exists
                const dealerInvestmentExists = await connection.query(`SELECT id FROM dealer_investment WHERE id = ?`, [dealerInvestmentId]);
                if (dealerInvestmentExists.length === 0) {
                    return res.status(400).send({
                        status: false,
                        message: "Invalid dealerInvestmentId: Dealer Investment not found"
                    });
                }
                updateFields.push("dealerInvestmentId = ?");
                updateValues.push(dealerInvestmentId);
            }

            if (jan !== undefined) {
                updateFields.push("jan = ?");
                updateValues.push(jan);
            }

            if (feb !== undefined) {
                updateFields.push("feb = ?");
                updateValues.push(feb);
            }

            if (mar !== undefined) {
                updateFields.push("mar = ?");
                updateValues.push(mar);
            }

            if (apr !== undefined) {
                updateFields.push("apr = ?");
                updateValues.push(apr);
            }

            if (may !== undefined) {
                updateFields.push("may = ?");
                updateValues.push(may);
            }

            if (jun !== undefined) {
                updateFields.push("jun = ?");
                updateValues.push(jun);
            }

            if (jul !== undefined) {
                updateFields.push("jul = ?");
                updateValues.push(jul);
            }

            if (aug !== undefined) {
                updateFields.push("aug = ?");
                updateValues.push(aug);
            }

            if (sep !== undefined) {
                updateFields.push("sep = ?");
                updateValues.push(sep);
            }

            if (oct !== undefined) {
                updateFields.push("oct = ?");
                updateValues.push(oct);
            }

            if (nov !== undefined) {
                updateFields.push("nov = ?");
                updateValues.push(nov);
            }

            if (decem !== undefined) {
                updateFields.push("decem = ?");
                updateValues.push(decem);
            }

            if (isActive !== undefined) {
                updateFields.push("isActive = ?");
                updateValues.push(isActive);
            }

            if (updateFields.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "At least one field must be provided for update"
                });
            }

            // Always update updated_at
            const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("updated_at = ?");
            updateValues.push(updatedOn);

            updateValues.push(id);

            const updateQuery = `
        UPDATE dealer_investment_allocation 
        SET ${updateFields.join(", ")}
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;

            const result = await connection.query(updateQuery, updateValues);

            if (result.affectedRows === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Dealer investment allocation not found or could not be updated"
                });
            }

            // Trigger inventory closing stock recalculation for affected months
            try {
                // Fetch the record details to get year and equipmentId
                const recordDetails = await connection.query(`
                    SELECT 
                        dia.equipmentId,
                        p.year
                    FROM dealer_investment_allocation dia
                    LEFT JOIN dealer_investment di ON dia.dealerInvestmentId = di.id
                    LEFT JOIN pdp p ON di.pdpId = p.id
                    WHERE dia.id = ?
                `, [id]);

                if (recordDetails.length > 0) {
                    const { equipmentId: eqId, year: pdpYear } = recordDetails[0];

                    // Track which months were updated
                    const updatedMonths = [];
                    if (jan !== undefined) updatedMonths.push('jan');
                    if (feb !== undefined) updatedMonths.push('feb');
                    if (mar !== undefined) updatedMonths.push('mar');
                    if (apr !== undefined) updatedMonths.push('apr');
                    if (may !== undefined) updatedMonths.push('may');
                    if (jun !== undefined) updatedMonths.push('jun');
                    if (jul !== undefined) updatedMonths.push('jul');
                    if (aug !== undefined) updatedMonths.push('aug');
                    if (sep !== undefined) updatedMonths.push('sep');
                    if (oct !== undefined) updatedMonths.push('oct');
                    if (nov !== undefined) updatedMonths.push('nov');
                    if (decem !== undefined) updatedMonths.push('decem');

                    // Recalculate closing stock for affected months
                    for (const month of updatedMonths) {
                        try {
                            const updatedCount = await recalculateClosingStockForAllocation(pdpYear, eqId, month);
                            console.log(`[updateDealerInvestmentAllocation] Recalculated closing stock for ${month}: ${updatedCount} inventory record(s) updated`);
                        } catch (error) {
                            console.error(`[updateDealerInvestmentAllocation] Failed to recalculate closing stock for ${month}:`, error.message);
                            // Continue with other months even if one fails
                        }
                    }
                }
            } catch (error) {
                console.error(`[updateDealerInvestmentAllocation] Error during inventory recalculation:`, error.message);
                // Don't fail the request if inventory update fails
            }

            return res.status(200).send({
                status: true,
                message: "Dealer investment allocation updated successfully"
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    updateMultipleDealerInvestmentAllocation: async function (req, res) {
        try {
            const { rows } = req.body;

            if (!Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "Rows array is required"
                });
            }

            const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            for (const row of rows) {
                const { id, ...fields } = row;

                if (!id) continue;

                const updateFields = [];
                const updateValues = [];

                for (const key in fields) {
                    updateFields.push(`${key} = ?`);
                    updateValues.push(fields[key]);
                }

                if (updateFields.length === 0) continue;

                // Always update updated_at
                updateFields.push("updated_at = ?");
                updateValues.push(updatedOn);

                updateValues.push(id);

                const query = `
          UPDATE dealer_investment_allocation 
          SET ${updateFields.join(", ")} 
          WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
        `;

                await connection.query(query, updateValues);

                // Trigger inventory closing stock recalculation for affected months
                try {
                    // Fetch the record details to get year and equipmentId
                    const recordDetails = await connection.query(`
                        SELECT 
                            dia.equipmentId,
                            p.year
                        FROM dealer_investment_allocation dia
                        LEFT JOIN dealer_investment di ON dia.dealerInvestmentId = di.id
                        LEFT JOIN pdp p ON di.pdpId = p.id
                        WHERE dia.id = ?
                    `, [id]);

                    if (recordDetails.length > 0) {
                        const { equipmentId: eqId, year: pdpYear } = recordDetails[0];

                        // Track which months were updated
                        const updatedMonths = [];
                        if (fields.jan !== undefined) updatedMonths.push('jan');
                        if (fields.feb !== undefined) updatedMonths.push('feb');
                        if (fields.mar !== undefined) updatedMonths.push('mar');
                        if (fields.apr !== undefined) updatedMonths.push('apr');
                        if (fields.may !== undefined) updatedMonths.push('may');
                        if (fields.jun !== undefined) updatedMonths.push('jun');
                        if (fields.jul !== undefined) updatedMonths.push('jul');
                        if (fields.aug !== undefined) updatedMonths.push('aug');
                        if (fields.sep !== undefined) updatedMonths.push('sep');
                        if (fields.oct !== undefined) updatedMonths.push('oct');
                        if (fields.nov !== undefined) updatedMonths.push('nov');
                        if (fields.decem !== undefined) updatedMonths.push('decem');

                        // Recalculate closing stock for affected months
                        for (const month of updatedMonths) {
                            try {
                                const updatedCount = await recalculateClosingStockForAllocation(pdpYear, eqId, month);
                                console.log(`[updateMultipleDealerInvestmentAllocation] Recalculated closing stock for ${month}: ${updatedCount} inventory record(s) updated`);
                            } catch (error) {
                                console.error(`[updateMultipleDealerInvestmentAllocation] Failed to recalculate closing stock for ${month}:`, error.message);
                                // Continue with other months even if one fails
                            }
                        }
                    }
                } catch (error) {
                    console.error(`[updateMultipleDealerInvestmentAllocation] Error during inventory recalculation for id ${id}:`, error.message);
                    // Continue with next row even if this fails
                }
            }

            return res.status(200).send({
                status: true,
                message: "Multiple dealer investment allocation rows updated successfully"
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    },

    deleteDealerInvestmentAllocation: async function (req, res) {
        try {
            const { id } = req.params;
            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            // Check if dealer investment allocation exists
            const exists = await connection.query(
                `SELECT id FROM dealer_investment_allocation WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Dealer investment allocation not found"
                });
            }

            // Soft delete
            const query = `UPDATE dealer_investment_allocation SET isDeleted = TRUE WHERE id = ?`;
            await connection.query(query, [id]);

            return res.status(200).send({
                status: true,
                message: "Dealer investment allocation deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    }
};
