const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  getAllDealerInvestmentInfrastructure: async function (req, res) {
    try {
      const { pdpId, pdpInfrastructureId, dealerInvestmentId } = req.query;
      
      // Build WHERE clause dynamically based on query parameters
      const whereConditions = ["(dii.isDeleted = FALSE OR dii.isDeleted = 0)"];
      const queryValues = [];

      if (pdpId) {
        whereConditions.push("dii.pdpId = ?");
        queryValues.push(pdpId);
      }

      if (pdpInfrastructureId) {
        whereConditions.push("dii.pdpInfrastructureId = ?");
        queryValues.push(pdpInfrastructureId);
      }

      if (dealerInvestmentId) {
        whereConditions.push("dii.dealerInvestmentId = ?");
        queryValues.push(dealerInvestmentId);
      }

      const query = `
        SELECT 
          dii.id,
          dii.pdpId,
          dii.pdpInfrastructureId,
          dii.dealerInvestmentId,
          dii.q1,
          dii.q2,
          dii.q3,
          dii.q4,
          dii.ytd_actual,
          dii.created_at,
          dii.updated_at,
          dii.isActive,
          dii.isDeleted,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          pi.infrastructureId,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_infrastructure dii
        LEFT JOIN pdp p ON dii.pdpId = p.id
        LEFT JOIN pdp_infrastructure pi ON dii.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        LEFT JOIN dealer_investment di ON dii.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE ${whereConditions.join(" AND ")}
        ORDER BY dii.created_at DESC, dii.id DESC
      `;
      const data = await connection.query(query, queryValues);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No dealer investment infrastructure records found", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpId: item.pdpId,
        pdpInfrastructureId: item.pdpInfrastructureId,
        dealerInvestmentId: item.dealerInvestmentId,
        q1: item.q1,
        q2: item.q2,
        q3: item.q3,
        q4: item.q4,
        ytd_actual: item.ytd_actual,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pdp_info: {
          year: item.pdp_year,
          market_area: item.pdp_market_area
        },
        infrastructure_info: {
          infrastructure_id: item.infrastructureId,
          year: item.infrastructure_year,
          facility_type: item.facility_type,
          facility_definition: item.facility_definition,
          target: item.infrastructure_target
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment infrastructure list retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  getDealerInvestmentInfrastructureById: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      const query = `
        SELECT 
          dii.id,
          dii.pdpId,
          dii.pdpInfrastructureId,
          dii.dealerInvestmentId,
          dii.q1,
          dii.q2,
          dii.q3,
          dii.q4,
          dii.ytd_actual,
          dii.created_at,
          dii.updated_at,
          dii.isActive,
          dii.isDeleted,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          pi.infrastructureId,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_infrastructure dii
        LEFT JOIN pdp p ON dii.pdpId = p.id
        LEFT JOIN pdp_infrastructure pi ON dii.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        LEFT JOIN dealer_investment di ON dii.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE dii.id = ? AND (dii.isDeleted = FALSE OR dii.isDeleted = 0)
      `;
      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment infrastructure not found" 
        });
      }

      const result = {
        id: data[0].id,
        pdpId: data[0].pdpId,
        pdpInfrastructureId: data[0].pdpInfrastructureId,
        dealerInvestmentId: data[0].dealerInvestmentId,
        q1: data[0].q1,
        q2: data[0].q2,
        q3: data[0].q3,
        q4: data[0].q4,
        ytd_actual: data[0].ytd_actual,
        created_at: data[0].created_at,
        updated_at: data[0].updated_at,
        isActive: data[0].isActive,
        isDeleted: data[0].isDeleted,
        pdp_info: {
          year: data[0].pdp_year,
          market_area: data[0].pdp_market_area
        },
        infrastructure_info: {
          infrastructure_id: data[0].infrastructureId,
          year: data[0].infrastructure_year,
          facility_type: data[0].facility_type,
          facility_definition: data[0].facility_definition,
          target: data[0].infrastructure_target
        },
        dealer_info: {
          dealer_id: data[0].dealerId,
          dealer_name: data[0].dealerName,
          dealer_short_name: data[0].dealerShortName,
          market_id: data[0].market_id,
          market_area_name: data[0].market_area_name,
          state_id: data[0].state_id
        }
      };

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment infrastructure retrieved", 
        data: result 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  getDealerInvestmentInfrastructureByDealerInvestmentId: async function (req, res) {
    try {
      const { dealerInvestmentId } = req.params;
      if (!dealerInvestmentId) {
        return res.status(400).send({ 
          status: false, 
          message: "dealerInvestmentId is required" 
        });
      }

      const query = `
        SELECT 
          dii.id,
          dii.pdpId,
          dii.pdpInfrastructureId,
          dii.dealerInvestmentId,
          dii.q1,
          dii.q2,
          dii.q3,
          dii.q4,
          dii.ytd_actual,
          dii.created_at,
          dii.updated_at,
          dii.isActive,
          dii.isDeleted,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          pi.infrastructureId,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_infrastructure dii
        LEFT JOIN pdp p ON dii.pdpId = p.id
        LEFT JOIN pdp_infrastructure pi ON dii.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        LEFT JOIN dealer_investment di ON dii.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE dii.dealerInvestmentId = ? AND (dii.isDeleted = FALSE OR dii.isDeleted = 0)
        ORDER BY dii.created_at DESC, dii.id DESC
      `;
      const data = await connection.query(query, [dealerInvestmentId]);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No dealer investment infrastructure records found for this dealer investment", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpId: item.pdpId,
        pdpInfrastructureId: item.pdpInfrastructureId,
        dealerInvestmentId: item.dealerInvestmentId,
        q1: item.q1,
        q2: item.q2,
        q3: item.q3,
        q4: item.q4,
        ytd_actual: item.ytd_actual,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pdp_info: {
          year: item.pdp_year,
          market_area: item.pdp_market_area
        },
        infrastructure_info: {
          infrastructure_id: item.infrastructureId,
          year: item.infrastructure_year,
          facility_type: item.facility_type,
          facility_definition: item.facility_definition,
          target: item.infrastructure_target
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment infrastructure records retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  getDealerInvestmentInfrastructureByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;
      if (!pdpId) {
        return res.status(400).send({ 
          status: false, 
          message: "pdpId is required" 
        });
      }

      const query = `
        SELECT 
          dii.id,
          dii.pdpId,
          dii.pdpInfrastructureId,
          dii.dealerInvestmentId,
          dii.q1,
          dii.q2,
          dii.q3,
          dii.q4,
          dii.ytd_actual,
          dii.created_at,
          dii.updated_at,
          dii.isActive,
          dii.isDeleted,
          p.year as pdp_year,
          p.market_area as pdp_market_area,
          pi.infrastructureId,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          di.dealerId,
          dm.dealerName,
          dm.dealerShortName,
          dm.market_id,
          dm.state_id,
          ma.marketarea as market_area_name
        FROM dealer_investment_infrastructure dii
        LEFT JOIN pdp p ON dii.pdpId = p.id
        LEFT JOIN pdp_infrastructure pi ON dii.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        LEFT JOIN dealer_investment di ON dii.dealerInvestmentId = di.id
        LEFT JOIN dealer_master dm ON di.dealerId = dm.id
        LEFT JOIN market_area ma ON dm.market_id = ma.id
        WHERE dii.pdpId = ? AND (dii.isDeleted = FALSE OR dii.isDeleted = 0)
        ORDER BY dii.created_at DESC, dii.id DESC
      `;
      const data = await connection.query(query, [pdpId]);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No dealer investment infrastructure records found for this PDP", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        pdpId: item.pdpId,
        pdpInfrastructureId: item.pdpInfrastructureId,
        dealerInvestmentId: item.dealerInvestmentId,
        q1: item.q1,
        q2: item.q2,
        q3: item.q3,
        q4: item.q4,
        ytd_actual: item.ytd_actual,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pdp_info: {
          year: item.pdp_year,
          market_area: item.pdp_market_area
        },
        infrastructure_info: {
          infrastructure_id: item.infrastructureId,
          year: item.infrastructure_year,
          facility_type: item.facility_type,
          facility_definition: item.facility_definition,
          target: item.infrastructure_target
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName,
          market_id: item.market_id,
          market_area_name: item.market_area_name,
          state_id: item.state_id
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment infrastructure records retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  updateDealerInvestmentInfrastructure: async function (req, res) {
    try {
      const { id, pdpId, pdpInfrastructureId, dealerInvestmentId, q1, q2, q3, q4, ytd_actual, isActive } = req.body;

      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      // Check if dealer investment infrastructure exists
      const exists = await connection.query(
        `SELECT id FROM dealer_investment_infrastructure WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`, 
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment infrastructure not found" 
        });
      }

      // Build update query dynamically based on provided fields
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        // Validate pdpId exists
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ?`, [pdpId]);
        if (pdpExists.length === 0) {
          return res.status(400).send({ 
            status: false, 
            message: "Invalid pdpId: PDP not found" 
          });
        }
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }

      if (pdpInfrastructureId !== undefined) {
        // Validate pdpInfrastructureId exists
        const pdpInfrastructureExists = await connection.query(`SELECT id FROM pdp_infrastructure WHERE id = ?`, [pdpInfrastructureId]);
        if (pdpInfrastructureExists.length === 0) {
          return res.status(400).send({ 
            status: false, 
            message: "Invalid pdpInfrastructureId: PDP Infrastructure not found" 
          });
        }
        updateFields.push("pdpInfrastructureId = ?");
        updateValues.push(pdpInfrastructureId);
      }

      if (dealerInvestmentId !== undefined) {
        // Validate dealerInvestmentId exists
        const dealerInvestmentExists = await connection.query(`SELECT id FROM dealer_investment WHERE id = ?`, [dealerInvestmentId]);
        if (dealerInvestmentExists.length === 0) {
          return res.status(400).send({ 
            status: false, 
            message: "Invalid dealerInvestmentId: Dealer Investment not found" 
          });
        }
        updateFields.push("dealerInvestmentId = ?");
        updateValues.push(dealerInvestmentId);
      }

      if (q1 !== undefined) {
        updateFields.push("q1 = ?");
        updateValues.push(q1);
      }

      if (q2 !== undefined) {
        updateFields.push("q2 = ?");
        updateValues.push(q2);
      }

      if (q3 !== undefined) {
        updateFields.push("q3 = ?");
        updateValues.push(q3);
      }

      if (q4 !== undefined) {
        updateFields.push("q4 = ?");
        updateValues.push(q4);
      }

      if (ytd_actual !== undefined) {
        updateFields.push("ytd_actual = ?");
        updateValues.push(ytd_actual);
      }

      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({ 
          status: false, 
          message: "At least one field must be provided for update" 
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE dealer_investment_infrastructure 
        SET ${updateFields.join(", ")}
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;

      const result = await connection.query(updateQuery, updateValues);

      if (result.affectedRows === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment infrastructure not found or could not be updated" 
        });
      }

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment infrastructure updated successfully" 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  updateMultipleDealerInvestmentInfrastructure: async function (req, res) {
    try {
      const { rows } = req.body;

      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ 
          status: false, 
          message: "Rows array is required" 
        });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      for (const row of rows) {
        const { id, ...fields } = row;

        if (!id) continue;

        const updateFields = [];
        const updateValues = [];

        for (const key in fields) {
          updateFields.push(`${key} = ?`);
          updateValues.push(fields[key]);
        }

        if (updateFields.length === 0) continue;

        // Always update updated_at
        updateFields.push("updated_at = ?");
        updateValues.push(updatedOn);

        updateValues.push(id);

        const query = `
          UPDATE dealer_investment_infrastructure 
          SET ${updateFields.join(", ")} 
          WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
        `;

        await connection.query(query, updateValues);
      }

      return res.status(200).send({
        status: true,
        message: "Multiple dealer investment infrastructure rows updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  deleteDealerInvestmentInfrastructure: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      // Check if dealer investment infrastructure exists
      const exists = await connection.query(
        `SELECT id FROM dealer_investment_infrastructure WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`, 
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment infrastructure not found" 
        });
      }

      // Soft delete by setting isDeleted = TRUE
      const deleteQuery = `
        UPDATE dealer_investment_infrastructure 
        SET isDeleted = TRUE
        WHERE id = ?
      `;
      const result = await connection.query(deleteQuery, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "Dealer investment infrastructure not found" 
        });
      }

      return res.status(200).send({ 
        status: true, 
        message: "Dealer investment infrastructure deleted successfully" 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  }
};

