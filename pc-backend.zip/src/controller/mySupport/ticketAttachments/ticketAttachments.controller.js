const { connection } = require("../../../mySql/mySql");
const moment = require("moment-timezone");
const { uploadFile } = require("../../azurestorage/fileUpload");

module.exports = {
    addTicketAttachment: async function (req, res) {
        try {
            const { ticket_id } = req.body;

            if (!ticket_id) {
                return res.status(400).send({
                    status: false,
                    message: "ticket_id is required"
                });
            }

            const ticketExists = await connection.query(
                "SELECT id FROM ticket_mysupport WHERE id = ? AND isDeleted = 0",
                [ticket_id]
            );
            if (ticketExists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Ticket not found"
                });
            }

            if (!req.files || req.files.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "At least one file is required"
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const inserted = [];

            for (const file of req.files) {
                const attachmentUrl = await uploadFile(file);
                if (attachmentUrl && !(attachmentUrl instanceof Error)) {
                    const insertQuery = `
                        INSERT INTO ticket_attachments (
                            ticket_id, attachment_url, created_at, updated_at, isActive, isDeleted
                        )
                        VALUES (?, ?, ?, ?, 1, 0)
                    `;
                    const result = await connection.query(insertQuery, [
                        ticket_id,
                        attachmentUrl,
                        createdAt,
                        createdAt
                    ]);
                    inserted.push({
                        id: result.insertId,
                        ticket_id: parseInt(ticket_id),
                        attachment_url: attachmentUrl,
                        created_at: createdAt
                    });
                }
            }

            if (inserted.length === 0) {
                return res.status(500).send({
                    status: false,
                    message: "File upload failed"
                });
            }

            return res.status(200).send({
                status: true,
                message: "Attachment(s) added successfully",
                data: inserted.length === 1 ? inserted[0] : inserted
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAttachmentsByTicketId: async function (req, res) {
        try {
            const { ticket_id } = req.params;

            if (!ticket_id) {
                return res.status(400).send({
                    status: false,
                    message: "ticket_id is required"
                });
            }

            const ticketExists = await connection.query(
                "SELECT id FROM ticket_mysupport WHERE id = ? AND isDeleted = 0",
                [ticket_id]
            );
            if (ticketExists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Ticket not found"
                });
            }

            const query = `
                SELECT id, ticket_id, attachment_url, created_at, updated_at, isActive
                FROM ticket_attachments
                WHERE ticket_id = ? AND isDeleted = 0
                ORDER BY id DESC
            `;
            const data = await connection.query(query, [ticket_id]);

            return res.status(200).send({
                status: true,
                message: "Attachments retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getTicketAttachmentById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            const query = `
                SELECT id, ticket_id, attachment_url, created_at, updated_at, isActive
                FROM ticket_attachments
                WHERE id = ? AND isDeleted = 0
            `;
            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Attachment not found"
                });
            }

            return res.status(200).send({
                status: true,
                message: "Attachment retrieved",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteTicketAttachment: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            const exists = await connection.query(
                "SELECT id FROM ticket_attachments WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Attachment not found"
                });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE ticket_attachments SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: "Attachment deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleTicketAttachmentStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            const data = await connection.query(
                "SELECT isActive FROM ticket_attachments WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (data.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Attachment not found"
                });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE ticket_attachments SET isActive = ?, updated_at = ? WHERE id = ?",
                [newStatus, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Attachment ${newStatus ? "enabled" : "disabled"} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};
