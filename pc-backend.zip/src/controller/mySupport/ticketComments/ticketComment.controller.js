const { connection } = require("../../../mySql/mySql");
const moment = require("moment-timezone");
const { uploadFile } = require("../../azurestorage/fileUpload");

module.exports = {
    addTicketComment: async function (req, res) {
        try {
            const { ticket_id, comment } = req.body;

            if (!ticket_id || !comment) {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: ticket_id, comment"
                });
            }

            const created_by = req.decodedToken;
            if (!created_by) {
                return res.status(401).send({
                    status: false,
                    message: "User not authenticated"
                });
            }

            const ticketExists = await connection.query(
                "SELECT id FROM ticket_mysupport WHERE id = ? AND isDeleted = 0",
                [ticket_id]
            );
            if (ticketExists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Ticket not found"
                });
            }

            let attachment_url = null;
            if (req.files && req.files.length > 0) {
                const file = req.files[0];
                const uploadedUrl = await uploadFile(file);
                if (uploadedUrl && !(uploadedUrl instanceof Error)) {
                    attachment_url = uploadedUrl;
                }
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const insertQuery = `
                INSERT INTO ticket_comments (
                    ticket_id, created_by, comment, attachment_url,
                    created_at, updated_at, isActive, isDeleted
                )
                VALUES (?, ?, ?, ?, ?, ?, 1, 0)
            `;
            const result = await connection.query(insertQuery, [
                ticket_id,
                created_by,
                comment,
                attachment_url,
                createdAt,
                createdAt
            ]);

            return res.status(200).send({
                status: true,
                message: "Comment added successfully",
                data: {
                    id: result.insertId,
                    ticket_id: parseInt(ticket_id),
                    created_by,
                    comment,
                    attachment_url,
                    created_at: createdAt
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getCommentsByTicketId: async function (req, res) {
        try {
            const { ticket_id } = req.params;

            if (!ticket_id) {
                return res.status(400).send({
                    status: false,
                    message: "ticket_id is required"
                });
            }

            const ticketExists = await connection.query(
                "SELECT id FROM ticket_mysupport WHERE id = ? AND isDeleted = 0",
                [ticket_id]
            );
            if (ticketExists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Ticket not found"
                });
            }

            const query = `
                SELECT 
                    tc.id, tc.ticket_id, tc.created_by, tc.comment, tc.attachment_url,
                    tc.created_at, tc.updated_at, tc.isActive,
                    ud.firstName as created_by_first_name,
                    ud.lastName as created_by_last_name
                FROM ticket_comments tc
                LEFT JOIN userdetails ud ON tc.created_by = ud.id
                WHERE tc.ticket_id = ? AND tc.isDeleted = 0
                ORDER BY tc.id ASC
            `;
            const data = await connection.query(query, [ticket_id]);

            return res.status(200).send({
                status: true,
                message: "Comments retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getTicketCommentById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            const query = `
                SELECT 
                    tc.id, tc.ticket_id, tc.created_by, tc.comment, tc.attachment_url,
                    tc.created_at, tc.updated_at, tc.isActive,
                    ud.firstName as created_by_first_name,
                    ud.lastName as created_by_last_name
                FROM ticket_comments tc
                LEFT JOIN userdetails ud ON tc.created_by = ud.id
                WHERE tc.id = ? AND tc.isDeleted = 0
            `;
            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Comment not found"
                });
            }

            return res.status(200).send({
                status: true,
                message: "Comment retrieved",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateTicketComment: async function (req, res) {
        try {
            const { id, comment } = req.body;

            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            const exists = await connection.query(
                "SELECT id, attachment_url FROM ticket_comments WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Comment not found"
                });
            }

            let attachment_url = exists[0].attachment_url;
            if (req.files && req.files.length > 0) {
                const file = req.files[0];
                const uploadedUrl = await uploadFile(file);
                if (uploadedUrl && !(uploadedUrl instanceof Error)) {
                    attachment_url = uploadedUrl;
                }
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const updateFields = ["updated_at = ?"];
            const updateValues = [updatedAt];

            if (comment !== undefined) {
                updateFields.push("comment = ?");
                updateValues.push(comment);
            }
            if (attachment_url !== undefined) {
                updateFields.push("attachment_url = ?");
                updateValues.push(attachment_url);
            }

            updateValues.push(id);
            const updateQuery = `
                UPDATE ticket_comments
                SET ${updateFields.join(", ")}
                WHERE id = ?
            `;
            await connection.query(updateQuery, updateValues);

            return res.status(200).send({
                status: true,
                message: "Comment updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteTicketComment: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            const exists = await connection.query(
                "SELECT id FROM ticket_comments WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Comment not found"
                });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE ticket_comments SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: "Comment deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleTicketCommentStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({
                    status: false,
                    message: "ID is required"
                });
            }

            const data = await connection.query(
                "SELECT isActive FROM ticket_comments WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (data.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Comment not found"
                });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE ticket_comments SET isActive = ?, updated_at = ? WHERE id = ?",
                [newStatus, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Comment ${newStatus ? "enabled" : "disabled"} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};
