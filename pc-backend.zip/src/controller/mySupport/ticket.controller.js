const { connection } = require("../../mySql/mySql");
const moment = require("moment-timezone");
const crypto = require("crypto");
const { uploadFile } = require("../azurestorage/fileUpload");

const VALID_PRIORITIES = ["Low", "Medium", "High"];
const VALID_TICKET_STATUSES = ["New", "Open", "In Progress", "Closed"];

module.exports = {
    addTicket: async function (req, res) {
        try {
            const {
                ticket_subject,
                issue,
                priority,
                description,
                expected_resolution_date
            } = req.body;

            if (!ticket_subject || !issue || !priority) {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: ticket_subject, issue, priority"
                });
            }

            if (!VALID_PRIORITIES.includes(priority)) {
                return res.status(400).send({
                    status: false,
                    message: "priority must be one of: Low, Medium, High"
                });
            }

            const submitted_by = req.decodedToken;
            if (!submitted_by) {
                return res.status(401).send({
                    status: false,
                    message: "User not authenticated"
                });
            }

            const ticket_no = "TC-" + crypto.randomUUID();
            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const insertTicketQuery = `
                INSERT INTO ticket_mysupport (
                    ticket_no, submitted_by, ticket_subject, issue, priority,
                    description, expected_resolution_date, ticket_status,
                    created_at, updated_at, isActive, isDeleted
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, 'New', ?, ?, 1, 0)
            `;

            const result = await connection.query(insertTicketQuery, [
                ticket_no,
                submitted_by,
                ticket_subject,
                issue,
                priority,
                description || null,
                expected_resolution_date || null,
                createdAt,
                createdAt
            ]);

            const ticketId = result.insertId;

            if (req.files && req.files.length > 0) {
                for (const file of req.files) {
                    const attachmentUrl = await uploadFile(file);
                    if (attachmentUrl && !(attachmentUrl instanceof Error)) {
                        const insertAttachmentQuery = `
                            INSERT INTO ticket_attachments (
                                ticket_id, attachment_url, created_at, updated_at, isActive, isDeleted
                            )
                            VALUES (?, ?, ?, ?, 1, 0)
                        `;
                        await connection.query(insertAttachmentQuery, [
                            ticketId,
                            attachmentUrl,
                            createdAt,
                            createdAt
                        ]);
                    }
                }
            }

            return res.status(200).send({
                status: true,
                message: "Ticket created successfully",
                data: { id: ticketId, ticket_no }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllTickets: async function (req, res) {
        try {
            const query = `
                SELECT 
                    t.*,
                    ud.firstName as submitted_by_first_name,
                    ud.lastName as submitted_by_last_name
                FROM ticket_mysupport t
                LEFT JOIN userdetails ud ON t.submitted_by = ud.id
                WHERE t.isDeleted = 0
                ORDER BY t.id DESC
            `;

            const tickets = await connection.query(query);

            if (tickets.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "Tickets list retrieved",
                    data: []
                });
            }

            const ticketIds = tickets.map((t) => t.id);
            const placeholders = ticketIds.map(() => "?").join(",");
            const attachmentsQuery = `
                SELECT id, ticket_id, attachment_url, created_at
                FROM ticket_attachments
                WHERE ticket_id IN (${placeholders}) AND isDeleted = 0
            `;
            const attachments = await connection.query(attachmentsQuery, ticketIds);

            const attachmentsByTicketId = {};
            attachments.forEach((att) => {
                if (!attachmentsByTicketId[att.ticket_id]) {
                    attachmentsByTicketId[att.ticket_id] = [];
                }
                attachmentsByTicketId[att.ticket_id].push(att);
            });

            const commentsQuery = `
                SELECT 
                    tc.id, tc.ticket_id, tc.created_by, tc.comment, tc.attachment_url,
                    tc.created_at, tc.updated_at,
                    ud.firstName as created_by_first_name,
                    ud.lastName as created_by_last_name
                FROM ticket_comments tc
                LEFT JOIN userdetails ud ON tc.created_by = ud.id
                WHERE tc.ticket_id IN (${placeholders}) AND tc.isDeleted = 0
                ORDER BY tc.ticket_id, tc.id ASC
            `;
            const comments = await connection.query(commentsQuery, ticketIds);

            const commentsByTicketId = {};
            comments.forEach((c) => {
                if (!commentsByTicketId[c.ticket_id]) {
                    commentsByTicketId[c.ticket_id] = [];
                }
                commentsByTicketId[c.ticket_id].push(c);
            });

            const data = tickets.map((ticket) => ({
                ...ticket,
                attachments: attachmentsByTicketId[ticket.id] || [],
                comments: commentsByTicketId[ticket.id] || []
            }));

            return res.status(200).send({
                status: true,
                message: "Tickets list retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getTicketById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const ticketQuery = `
                SELECT 
                    t.*,
                    ud.firstName as submitted_by_first_name,
                    ud.lastName as submitted_by_last_name
                FROM ticket_mysupport t
                LEFT JOIN userdetails ud ON t.submitted_by = ud.id
                WHERE t.id = ? AND t.isDeleted = 0
            `;

            const ticketData = await connection.query(ticketQuery, [id]);

            if (ticketData.length === 0) {
                return res.status(404).send({ status: false, message: "Ticket not found" });
            }

            const attachmentsQuery = `
                SELECT id, ticket_id, attachment_url, created_at
                FROM ticket_attachments
                WHERE ticket_id = ? AND isDeleted = 0
            `;
            const attachments = await connection.query(attachmentsQuery, [id]);

            const commentsQuery = `
                SELECT 
                    tc.id, tc.ticket_id, tc.created_by, tc.comment, tc.attachment_url,
                    tc.created_at, tc.updated_at,
                    ud.firstName as created_by_first_name,
                    ud.lastName as created_by_last_name
                FROM ticket_comments tc
                LEFT JOIN userdetails ud ON tc.created_by = ud.id
                WHERE tc.ticket_id = ? AND tc.isDeleted = 0
                ORDER BY tc.id ASC
            `;
            const comments = await connection.query(commentsQuery, [id]);

            const ticket = {
                ...ticketData[0],
                attachments,
                comments: comments || []
            };

            return res.status(200).send({
                status: true,
                message: "Ticket retrieved",
                data: ticket
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },
    getTicketByUserId: async function (req, res) {
        try {

            const submitted_by = req.decodedToken;
            if (!submitted_by) {
                return res.status(401).send({
                    status: false,
                    message: "User not authenticated"
                });
            }
const query = `
                SELECT 
                    t.*,
                    ud.firstName as submitted_by_first_name,
                    ud.lastName as submitted_by_last_name
                FROM ticket_mysupport t
                LEFT JOIN userdetails ud ON t.submitted_by = ud.id
                WHERE t.isDeleted = 0 AND t.submitted_by=${submitted_by}
                ORDER BY t.id DESC
            `;

            const tickets = await connection.query(query);

            if (tickets.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "Tickets list retrieved",
                    data: []
                });
            }

            const ticketIds = tickets.map((t) => t.id);
            const placeholders = ticketIds.map(() => "?").join(",");
            const attachmentsQuery = `
                SELECT id, ticket_id, attachment_url, created_at
                FROM ticket_attachments
                WHERE ticket_id IN (${placeholders}) AND isDeleted = 0
            `;
            const attachments = await connection.query(attachmentsQuery, ticketIds);

            const attachmentsByTicketId = {};
            attachments.forEach((att) => {
                if (!attachmentsByTicketId[att.ticket_id]) {
                    attachmentsByTicketId[att.ticket_id] = [];
                }
                attachmentsByTicketId[att.ticket_id].push(att);
            });

            const commentsQuery = `
                SELECT 
                    tc.id, tc.ticket_id, tc.created_by, tc.comment, tc.attachment_url,
                    tc.created_at, tc.updated_at,
                    ud.firstName as created_by_first_name,
                    ud.lastName as created_by_last_name
                FROM ticket_comments tc
                LEFT JOIN userdetails ud ON tc.created_by = ud.id
                WHERE tc.ticket_id IN (${placeholders}) AND tc.isDeleted = 0
                ORDER BY tc.ticket_id, tc.id ASC
            `;
            const comments = await connection.query(commentsQuery, ticketIds);

            const commentsByTicketId = {};
            comments.forEach((c) => {
                if (!commentsByTicketId[c.ticket_id]) {
                    commentsByTicketId[c.ticket_id] = [];
                }
                commentsByTicketId[c.ticket_id].push(c);
            });

            const data = tickets.map((ticket) => ({
                ...ticket,
                attachments: attachmentsByTicketId[ticket.id] || [],
                comments: commentsByTicketId[ticket.id] || []
            }));

            return res.status(200).send({
                status: true,
                message: "Tickets list retrieved",
                data: data
            });
   

        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateTicket: async function (req, res) {
        try {
            const {
                id,
                ticket_subject,
                issue,
                priority,
                description,
                expected_resolution_date,
                ticket_status,
                isActive
            } = req.body;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM ticket_mysupport WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Ticket not found" });
            }

            if (priority && !VALID_PRIORITIES.includes(priority)) {
                return res.status(400).send({
                    status: false,
                    message: "priority must be one of: Low, Medium, High"
                });
            }

            if (ticket_status && !VALID_TICKET_STATUSES.includes(ticket_status)) {
                return res.status(400).send({
                    status: false,
                    message: "ticket_status must be one of: New, Open, In Progress, Closed"
                });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const updateFields = [];
            const updateValues = [];

            if (ticket_subject !== undefined) {
                updateFields.push("ticket_subject = ?");
                updateValues.push(ticket_subject);
            }
            if (issue !== undefined) {
                updateFields.push("issue = ?");
                updateValues.push(issue);
            }
            if (priority !== undefined) {
                updateFields.push("priority = ?");
                updateValues.push(priority);
            }
            if (description !== undefined) {
                updateFields.push("description = ?");
                updateValues.push(description);
            }
            if (expected_resolution_date !== undefined) {
                updateFields.push("expected_resolution_date = ?");
                updateValues.push(expected_resolution_date);
            }
            if (ticket_status !== undefined) {
                updateFields.push("ticket_status = ?");
                updateValues.push(ticket_status);
            }
            if (isActive !== undefined) {
                updateFields.push("isActive = ?");
                updateValues.push(isActive ? 1 : 0);
            }

            if (req.files && req.files.length > 0) {
                for (const file of req.files) {
                    const attachmentUrl = await uploadFile(file);
                    if (attachmentUrl && !(attachmentUrl instanceof Error)) {
                        const insertAttachmentQuery = `
                            INSERT INTO ticket_attachments (
                                ticket_id, attachment_url, created_at, updated_at, isActive, isDeleted
                            )
                            VALUES (?, ?, ?, ?, 1, 0)
                        `;
                        await connection.query(insertAttachmentQuery, [
                            id,
                            attachmentUrl,
                            updatedAt,
                            updatedAt
                        ]);
                    }
                }
            }

            if (updateFields.length > 0) {
                updateFields.push("updated_at = ?");
                updateValues.push(updatedAt);
                updateValues.push(id);

                const updateQuery = `
                    UPDATE ticket_mysupport
                    SET ${updateFields.join(", ")}
                    WHERE id = ?
                `;
                await connection.query(updateQuery, updateValues);
            }

            return res.status(200).send({
                status: true,
                message: "Ticket updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteTicket: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM ticket_mysupport WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Ticket not found" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE ticket_mysupport SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: "Ticket deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleTicketStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const data = await connection.query(
                "SELECT isActive FROM ticket_mysupport WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Ticket not found" });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE ticket_mysupport SET isActive = ?, updated_at = ? WHERE id = ?",
                [newStatus, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Ticket ${newStatus ? "enabled" : "disabled"} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};
