const { connection } = require("../../mySql/mySql");
const moment = require("moment-timezone");

module.exports = {

    getAllUserNotifications: async function (req, res) {
        try {
            const query = `
                SELECT 
                    num.id, num.notification_id, num.user_id, num.isSeen,
                    num.created_at, num.updated_at, num.isActive,
                    n.title as notification_title,
                    n.message as notification_message,
                    ud.firstName as user_first_name,
                    ud.lastName as user_last_name
                FROM notification_user_mapping num
                LEFT JOIN notification n ON num.notification_id = n.id AND n.isDeleted = 0
                LEFT JOIN userdetails ud ON num.user_id = ud.id
                WHERE num.isDeleted = 0
                ORDER BY num.id DESC
            `;
            const data = await connection.query(query);

            return res.status(200).send({ status: true, data });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getUserNotificationById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const query = `
                SELECT 
                    num.id, num.notification_id, num.user_id, num.isSeen,
                    num.created_at, num.updated_at, num.isActive,
                    n.title as notification_title,
                    n.message as notification_message,
                    ud.firstName as user_first_name,
                    ud.lastName as user_last_name
                FROM notification_user_mapping num
                LEFT JOIN notification n ON num.notification_id = n.id AND n.isDeleted = 0
                LEFT JOIN userdetails ud ON num.user_id = ud.id
                WHERE num.id = ? AND num.isDeleted = 0
            `;
            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "User notification mapping not found!" });
            }

            return res.status(200).send({ status: true, data: data[0] });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getUserNotificationsByUserId: async function (req, res) {
        try {
            const user_id = req.decodedToken;
            console.log(`User id should be ${user_id}`);

            if (!user_id) {
                return res.status(400).send({ status: false, message: "user_id is required!" });
            }

            const query = `
                SELECT 
                    num.id, num.notification_id, num.user_id, num.isSeen,
                    num.created_at, num.updated_at, num.isActive,
                    n.title as notification_title,
                    n.message as notification_message
                FROM notification_user_mapping num
                LEFT JOIN notification n ON num.notification_id = n.id AND n.isDeleted = 0
                WHERE num.user_id = ? AND num.isDeleted = 0
                ORDER BY num.id DESC
            `;
            const data = await connection.query(query, [user_id]);

            return res.status(200).send({ status: true, data });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleSeenStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const row = await connection.query(
                "SELECT isSeen FROM notification_user_mapping WHERE id = ? AND isDeleted = 0",
                [id]
            );

            if (row.length === 0) {
                return res.status(404).send({ status: false, message: "User notification mapping not found!" });
            }

            const newSeen = row[0].isSeen ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE notification_user_mapping SET isSeen = ?, updated_at = ? WHERE id = ?",
                [newSeen, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Marked as ${newSeen ? "seen" : "unseen"} successfully!`,
                data: { id, isSeen: !!newSeen }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    bulkToggleSeenStatus: async function (req, res) {
        try {
            const { ids } = req.body;

            if (!ids || !Array.isArray(ids) || ids.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "An array of IDs is required!"
                });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const query = `
                UPDATE notification_user_mapping 
                SET isSeen = 1, updated_at = ? 
                WHERE id IN (?) AND isDeleted = 0
            `;
            await connection.query(query, [updatedAt, ids]);

            return res.status(200).send({
                status: true,
                message: "Notifications marked as seen successfully!",
                data: { updatedIds: ids }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};
