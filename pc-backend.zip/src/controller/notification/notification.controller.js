const { connection } = require("../../mySql/mySql");
const moment = require("moment-timezone");

/**
 * Reusable function to create a notification (can be called from other controllers)
 * @param {string} title - Notification title
 * @param {string} message - Notification message
 * @param {Array|string|null} userIds - Array of user IDs or comma-separated string (optional)
 * @returns {Promise<{success: boolean, notificationId?: number, userIdsMapped?: number, error?: string}>}
 */
async function createNotification(title, message, userIds = null) {
    try {
        if (!title || !message) {
            return { success: false, error: "Title and message are required!" };
        }

        const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

        const query = `
            INSERT INTO notification (title, message, created_at, updated_at, isActive, isDeleted)
            VALUES (?, ?, ?, ?, 1, 0)
        `;
        const result = await connection.query(query, [title.trim(), message.trim(), createdAt, createdAt]);
        const notificationId = result.insertId;

        const userIdList = normalizeUserIds(userIds);
        if (userIdList.length > 0) {
            const mappingQuery = `
                INSERT INTO notification_user_mapping (notification_id, user_id, isSeen, created_at, updated_at, isActive, isDeleted)
                VALUES (?, ?, 0, ?, ?, 1, 0)
            `;
            for (const userId of userIdList) {
                await connection.query(mappingQuery, [notificationId, userId, createdAt, createdAt]);
            }
        }

        return { success: true, notificationId, userIdsMapped: userIdList.length };
    } catch (error) {
        console.error("createNotification error:", error.message);
        return { success: false, error: error.message };
    }
}

module.exports = {

    // Export the reusable function
    createNotification,

    addNotification: async function (req, res) {
        try {
            const { title, message, userIds } = req.body;

            const result = await createNotification(title, message, userIds);

            if (!result.success) {
                return res.status(400).send({
                    status: false,
                    message: result.error
                });
            }

            return res.status(200).send({
                status: true,
                message: "Notification added successfully!",
                data: { id: result.notificationId, userIdsMapped: result.userIdsMapped }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllNotifications: async function (req, res) {
        try {
            const query = `
                SELECT id, title, message, created_at, updated_at, isActive
                FROM notification
                WHERE isDeleted = 0
                ORDER BY id DESC
            `;
            const data = await connection.query(query);

            return res.status(200).send({ status: true, data });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getNotificationById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const query = `SELECT * FROM notification WHERE id = ? AND isDeleted = 0`;
            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Notification not found!" });
            }

            return res.status(200).send({ status: true, data: data[0] });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateNotification: async function (req, res) {
        try {
            const { id, title, message, userIds } = req.body;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const exists = await connection.query(
                "SELECT id FROM notification WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Notification not found!" });
            }

            const updateFields = [];
            const updateValues = [];

            if (title !== undefined) {
                updateFields.push("title = ?");
                updateValues.push(title.trim());
            }
            if (message !== undefined) {
                updateFields.push("message = ?");
                updateValues.push(message.trim());
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            if (updateFields.length > 0) {
                updateFields.push("updated_at = ?");
                updateValues.push(updatedAt);
                updateValues.push(id);
                const query = `UPDATE notification SET ${updateFields.join(", ")} WHERE id = ?`;
                await connection.query(query, updateValues);
            }

            if (userIds !== undefined) {
                const updatedAtMapping = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
                await connection.query(
                    "UPDATE notification_user_mapping SET isDeleted = 1, isActive = 0, updated_at = ? WHERE notification_id = ?",
                    [updatedAtMapping, id]
                );

                const userIdList = normalizeUserIds(userIds);
                if (userIdList.length > 0) {
                    const mappingQuery = `
                        INSERT INTO notification_user_mapping (notification_id, user_id, isSeen, created_at, updated_at, isActive, isDeleted)
                        VALUES (?, ?, 0, ?, ?, 1, 0)
                    `;
                    for (const userId of userIdList) {
                        await connection.query(mappingQuery, [id, userId, updatedAtMapping, updatedAtMapping]);
                    }
                }
            }

            if (updateFields.length === 0 && userIds === undefined) {
                return res.status(400).send({ status: false, message: "No fields to update!" });
            }

            return res.status(200).send({ status: true, message: "Notification updated successfully!" });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleNotificationStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const data = await connection.query(
                "SELECT isActive FROM notification WHERE id = ? AND isDeleted = 0",
                [id]
            );

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Notification not found!" });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE notification SET isActive = ?, updated_at = ? WHERE id = ?",
                [newStatus, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Notification ${newStatus ? "enabled" : "disabled"} successfully!`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteNotification: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const exists = await connection.query(
                "SELECT id FROM notification WHERE id = ? AND isDeleted = 0",
                [id]
            );

            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Notification not found!" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE notification SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [updatedAt, id]
            );

            return res.status(200).send({ status: true, message: "Notification deleted successfully!" });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};

function normalizeUserIds(userIds) {
    if (userIds == null) return [];
    if (Array.isArray(userIds)) {
        return userIds.map((u) => parseInt(u, 10)).filter((u) => !Number.isNaN(u) && u > 0);
    }
    if (typeof userIds === "string") {
        return userIds
            .split(",")
            .map((u) => parseInt(u.trim(), 10))
            .filter((u) => !Number.isNaN(u) && u > 0);
    }
    return [];
}
