const { connection } = require('../../../mySql/mySql');
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add Financial Multiplier
  addFinancial: async function (req, res) {
    try {
      
      let { type, value } = req.body;

      if (!type || !type.trim()) {
        return res.status(400).send({ status: false, message: "Type is required!" });
      }
      if (!value || !value.toString().trim()) {
        return res.status(400).send({ status: false, message: "Value is required!" });
      }

      // Check for duplicate
      let validateQ = `SELECT id FROM financial_multiplier_master WHERE type = ?`;
      let validateData = await connection.query(validateQ, [type.trim()]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Financial type already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      let query = `
        INSERT INTO financial_multiplier_master 
        (type, value, isActive, createdOn)
        VALUES (?, ?, 1, ?)
      `;
      await connection.query(query, [type.trim(), value.toString().trim(), createdOn]);

      return res.status(200).send({ status: true, message: "Financial multiplier added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Financial Multipliers
  getFinancials: async function (req, res) {
    try {
      let query = `
        SELECT id, type, value, isActive, createdOn
        FROM financial_multiplier_master
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Financial Multiplier
  updateFinancial: async function (req, res) {
    try {
      let { id, type, value } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }
      if (!type || !type.trim()) {
        return res.status(400).send({ status: false, message: "Type is required!" });
      }
      if (!value || !value.toString().trim()) {
        return res.status(400).send({ status: false, message: "Value is required!" });
      }

      // Check for duplicate (excluding current id)
      let validateQ = `SELECT id FROM financial_multiplier_master WHERE type = ? AND id != ?`;
      let validateData = await connection.query(validateQ, [type.trim(), id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Financial type already exists!" });
      }

      let query = `
        UPDATE financial_multiplier_master 
        SET type = ?, value = ?
        WHERE id = ?
      `;
      let result = await connection.query(query, [type.trim(), value.toString().trim(), id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Financial multiplier not found!" });
      }

      return res.status(200).send({ status: true, message: "Financial multiplier updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Toggle Financial Status (Enable/Disable)
  toggleFinancial: async function (req, res) {
    try {
      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM financial_multiplier_master WHERE id = ?`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Financial multiplier not found!" });
      }

      // Toggle status
      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE financial_multiplier_master SET isActive = ? WHERE id = ?`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Financial multiplier ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete Financial Multiplier (Hard Delete)
  deleteFinancial: async function (req, res) {
    try {
      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `DELETE FROM financial_multiplier_master WHERE id = ?`;
      let result = await connection.query(query, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Financial multiplier not found!" });
      }

      return res.status(200).send({ status: true, message: "Financial multiplier deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Bulk Download (Excel, CSV, etc.)
  bulkDownloadFinancial: async function (req, res) {
    try {
      let query = `
        SELECT type, value
        FROM financial_multiplier_master
        WHERE isActive = 1
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data[0] });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
