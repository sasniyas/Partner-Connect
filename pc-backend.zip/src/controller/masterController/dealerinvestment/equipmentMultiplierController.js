const { connection } = require("../../../mySql/mySql");
const moment = require("moment-timezone");

module.exports = {
  // ➕ Add Equipment Multiplier
  addEquipmentMlp: async function (req, res) {
    try {
      let { type, multiplier } = req.body;

      if (!type?.trim()) {
        return res.status(400).send({ status: false, message: "Type is required!" });
      }

      if (!multiplier?.toString().trim()) {
        return res.status(400).send({ status: false, message: "Multiplier is required!" });
      }

      // Check for duplicate
      let validateData = await connection.query(
        `SELECT id FROM equipment_multiplier_master WHERE type = ?`,
        [type.trim()]
      );

      if (validateData.length > 0) {
        return res.status(200).send({ status: false, message: "Equipment type already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      await connection.query(
        `INSERT INTO equipment_multiplier_master (type, multiplier, isActive, createdOn) VALUES (?, ?, 1, ?)`,
        [type.trim(), multiplier.toString().trim(), createdOn]
      );

      return res.status(200).send({ status: true, message: "Equipment multiplier added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Equipment Multipliers
  getEquipmentsMlp: async function (req, res) {
    try {
      let data = await connection.query(`
        SELECT id, type, multiplier, isActive, createdOn
        FROM equipment_multiplier_master
        ORDER BY id DESC
      `);

      return res.status(200).send({ status: true, data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Equipment Multiplier
  updateEquipmentMlp: async function (req, res) {
    try {
      let { id, type, multiplier } = req.body;

      if (!id) return res.status(400).send({ status: false, message: "ID is required!" });
      if (!type?.trim()) return res.status(400).send({ status: false, message: "Type is required!" });
      if (!multiplier?.toString().trim()) return res.status(400).send({ status: false, message: "Multiplier is required!" });

      // Check for duplicate (excluding current ID)
      let validateData = await connection.query(
        `SELECT id FROM equipment_multiplier_master WHERE type = ? AND id != ?`,
        [type.trim(), id]
      );

      if (validateData.length > 0) {
        return res.status(200).send({ status: false, message: "Equipment type already exists!" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      let result = await connection.query(
        `UPDATE equipment_multiplier_master SET type = ?, multiplier = ? WHERE id = ?`,
        [type.trim(), multiplier.toString().trim(), id]
      );

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Equipment multiplier not found!" });
      }

      return res.status(200).send({ status: true, message: "Equipment multiplier updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Toggle Equipment Status (Enable/Disable)
  toggleEquipmentMlp: async function (req, res) {
    try {
      let { id } = req.params;
      if (!id) return res.status(400).send({ status: false, message: "ID is required!" });

      let data = await connection.query(`SELECT isActive FROM equipment_multiplier_master WHERE id = ?`, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Equipment multiplier not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;

      await connection.query(`UPDATE equipment_multiplier_master SET isActive = ? WHERE id = ?`, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Equipment multiplier ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete Equipment Multiplier (Hard Delete)
  deleteEquipmentMlp: async function (req, res) {
    try {
      let { id } = req.params;
      if (!id) return res.status(400).send({ status: false, message: "ID is required!" });

      let result = await connection.query(`DELETE FROM equipment_multiplier_master WHERE id = ?`, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Equipment multiplier not found!" });
      }

      return res.status(200).send({ status: true, message: "Equipment multiplier deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Bulk Download (Get All for Excel)
  bulkDownloadEquipmentMlp: async function (req, res) {
    try {
      let data = await connection.query(`
        SELECT type, multiplier
        FROM equipment_multiplier_master
        WHERE isActive = 1
        ORDER BY id DESC
      `);

      return res.status(200).send({ status: true, data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
