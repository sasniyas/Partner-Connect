const { connection } = require('../../../mySql/mySql');
const moment = require('moment-timezone');
const { createNotification } = require("../../notification/notification.controller");

// Validation function for bulk add ratio analysis
const validateRatioAnalysisRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenCombinations = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row, index) => {
    const { category, subCategory } = row;

    // Check required fields
    if (!category || !category.trim()) {
      invalidCount++;
      return;
    }

    if (!subCategory || !subCategory.trim()) {
      invalidCount++;
      return;
    }

    // Check for duplicates within the batch (combination of category and subCategory)
    const trimmedCategory = category.trim();
    const trimmedSubCategory = subCategory.trim();
    const combinationKey = `${trimmedCategory.toLowerCase()}|${trimmedSubCategory.toLowerCase()}`;

    if (seenCombinations.has(combinationKey)) {
      invalidCount++;
      return;
    }
    seenCombinations.add(combinationKey);

    // Row is valid
    validRows.push({
      category: trimmedCategory,
      subCategory: trimmedSubCategory
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // ➕ Bulk Add Ratio Analysis
  bulkAddRatioAnalysis: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateRatioAnalysisRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database (optimized with single query)
      const existingQuery = `
        SELECT category, subCategory FROM ratio_analysis_master WHERE isDeleted = 0
      `;
      const existingRecords = await connection.query(existingQuery);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.category.toLowerCase()}|${r.subCategory.toLowerCase()}`)
      );

      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.category.toLowerCase()}|${row.subCategory.toLowerCase()}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all ratio analysis records
      const insertValues = rowsToInsert.map(row => [
        row.category,
        row.subCategory,
        1, // isActive
        0, // isDeleted
        createdOn
      ]);

      const query = `
        INSERT INTO ratio_analysis_master (category, subCategory, isActive, isDeleted, createdOn) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Ratio Analysis(ies) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Add Ratio Analysis
  addRatioAnalysis: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { category, subCategory } = req.body;

      if (!category || !category.trim()) {
        return res.status(400).send({
          status: false,
          message: "Category is required!"
        });
      }

      if (!subCategory || !subCategory.trim()) {
        return res.status(400).send({
          status: false,
          message: "Sub Category is required!"
        });
      }

      // Check for duplicate
      let validateQ = `SELECT id FROM ratio_analysis_master WHERE category = ? AND subCategory = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [category.trim(), subCategory.trim()]);

      if (validateData.length !== 0) {
        return res.status(200).send({
          status: false,
          message: "Ratio analysis entry already exists!"
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      let query = `
        INSERT INTO ratio_analysis_master 
        (category, subCategory, isActive, isDeleted, createdOn)
        VALUES (?, ?, 1, 0, ?)
      `;

      await connection.query(query, [category.trim(), subCategory.trim(), createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Ratio Analysis Entry Added",
          `A new Ratio Analysis entry "${subCategory.trim()}" has been added.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({
        status: true,
        message: "Ratio analysis added successfully!"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📥 Get All Ratio Analysis
  getRatioAnalysis: async function (req, res) {
    try {
      let query = `
        SELECT id, category, subCategory, isActive, createdOn
        FROM ratio_analysis_master
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({
        status: true,
        data: data
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📝 Update Ratio Analysis
  updateRatioAnalysis: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, category, subCategory } = req.body;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      if (!category || !category.trim()) {
        return res.status(400).send({
          status: false,
          message: "Category is required!"
        });
      }

      if (!subCategory || !subCategory.trim()) {
        return res.status(400).send({
          status: false,
          message: "Sub Category is required!"
        });
      }

      // Check for duplicate (excluding current id)
      let validateQ = `SELECT id FROM ratio_analysis_master WHERE category = ? AND subCategory = ? AND id != ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [category.trim(), subCategory.trim(), id]);

      if (validateData.length !== 0) {
        return res.status(200).send({
          status: false,
          message: "Ratio analysis entry already exists!"
        });
      }

      let query = `
        UPDATE ratio_analysis_master 
        SET category = ?, subCategory = ?
        WHERE id = ? AND isDeleted = 0
      `;

      let result = await connection.query(query, [category.trim(), subCategory.trim(), id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Ratio Analysis Entry Updated",
          `The Ratio Analysis entry "${subCategory.trim()}" has been updated.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      if (result.affectedRows === 0) {
        return res.status(404).send({
          status: false,
          message: "Ratio analysis not found!"
        });
      }

      return res.status(200).send({
        status: true,
        message: "Ratio analysis updated successfully!"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 🔄 Toggle Ratio Analysis Status
  toggleRatioAnalysis: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      let getQuery = `SELECT isActive FROM ratio_analysis_master WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Ratio analysis not found!"
        });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE ratio_analysis_master SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Ratio analysis ${newStatus === 1 ? "activated" : "deactivated"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // ❌ Delete Ratio Analysis (Soft Delete)
  deleteRatioAnalysis: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Soft delete: set isDeleted to 1
      let query = `UPDATE ratio_analysis_master SET isDeleted = 1 WHERE id = ?`;
      let result = await connection.query(query, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({
          status: false,
          message: "Ratio analysis not found!"
        });
      }

      return res.status(200).send({
        status: true,
        message: "Ratio analysis deleted successfully!"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📥 Bulk Download
  bulkDownloadRatioAnalysis: async function (req, res) {
    try {
      let query = `
        SELECT category, subCategory
        FROM ratio_analysis_master
        WHERE isActive = 1 AND isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({
        status: true,
        data: data
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  }
};