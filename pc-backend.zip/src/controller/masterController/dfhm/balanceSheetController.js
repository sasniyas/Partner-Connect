const { connection } = require("../../../mySql/mySql");
const moment = require("moment-timezone");
const { createNotification } = require("../../notification/notification.controller");

// Validation function for bulk add balance sheet
const validateBalanceSheetRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenCombinations = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row, index) => {
    const { categoryType, category, subCategory } = row;

    // Check required fields
    if (!categoryType || !categoryType.trim()) {
      invalidCount++;
      return;
    }

    if (!category || !category.trim()) {
      invalidCount++;
      return;
    }

    if (!subCategory || !subCategory.trim()) {
      invalidCount++;
      return;
    }

    // Check for duplicates within the batch (combination of categoryType, category, and subCategory)
    const trimmedCategoryType = categoryType.trim();
    const trimmedCategory = category.trim();
    const trimmedSubCategory = subCategory.trim();
    const combinationKey = `${trimmedCategoryType.toLowerCase()}|${trimmedCategory.toLowerCase()}|${trimmedSubCategory.toLowerCase()}`;

    if (seenCombinations.has(combinationKey)) {
      invalidCount++;
      return;
    }
    seenCombinations.add(combinationKey);

    // Row is valid
    validRows.push({
      categoryType: trimmedCategoryType,
      category: trimmedCategory,
      subCategory: trimmedSubCategory
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // ➕ Bulk Add Balance Sheet
  bulkAddBalanceSheet: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateBalanceSheetRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database (optimized with single query)
      const existingQuery = `
        SELECT categoryType, category, subCategory FROM balance_sheet_master WHERE isDeleted = 0
      `;
      const existingRecords = await connection.query(existingQuery);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.categoryType.toLowerCase()}|${r.category.toLowerCase()}|${r.subCategory.toLowerCase()}`)
      );

      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.categoryType.toLowerCase()}|${row.category.toLowerCase()}|${row.subCategory.toLowerCase()}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all balance sheets
      const insertValues = rowsToInsert.map(row => [
        row.categoryType,
        row.category,
        row.subCategory,
        1, // isActive
        0, // isDeleted
        createdOn
      ]);

      const query = `
        INSERT INTO balance_sheet_master (categoryType, category, subCategory, isActive, isDeleted, createdOn) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Balance Sheet(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Add Balance Sheet
  addBalanceSheet: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { categoryType, category, subCategory } = req.body;

      if (!categoryType || !categoryType.trim()) {
        return res.status(400).send({
          status: false,
          message: "categoryType is required!"
        });
      }

      if (!category || !category.trim()) {
        return res.status(400).send({ status: false, message: "Category is required!" });
      }
      if (!subCategory || !subCategory.trim()) {
        return res.status(400).send({ status: false, message: "Sub Category is required!" });
      }

      // Duplicate check
      let validateQ = `SELECT id FROM balance_sheet_master WHERE categoryType=? AND  category=? AND subCategory=? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [categoryType.trim(), category.trim(), subCategory.trim()]);
      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Balance sheet entry already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `INSERT INTO balance_sheet_master (categoryType,category, subCategory, isActive, isDeleted, createdOn) VALUES (?,?, ?, 1, 0, ?)`;
      await connection.query(query, [categoryType.trim(), category.trim(), subCategory.trim(), createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Balance Sheet Entry Added",
          `A new Balance Sheet entry "${subCategory.trim()}" has been added to the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Balance sheet added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Balance Sheets
  getBalanceSheets: async function (req, res) {
    try {
      let query = `SELECT id,categoryType, category, subCategory, isActive, createdOn FROM balance_sheet_master WHERE isDeleted = 0 ORDER BY id DESC`;
      let data = await connection.query(query);
      return res.status(200).send({ status: true, data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Balance Sheet
  updateBalanceSheet: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, categoryType, category, subCategory } = req.body;

      if (!id) return res.status(400).send({ status: false, message: "ID is required!" });
      if (!categoryType || !categoryType.trim()) return res.status(400).send({ status: false, message: "categoryType is required!" });
      if (!category || !category.trim()) return res.status(400).send({ status: false, message: "Category is required!" });
      if (!subCategory || !subCategory.trim()) return res.status(400).send({ status: false, message: "Sub Category is required!" });

      // Check for duplicate
      let validateQ = `SELECT id FROM balance_sheet_master WHERE categoryType=? AND category=? AND subCategory=? AND id!=? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [categoryType.trim(), category.trim(), subCategory.trim(), id]);
      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Balance sheet entry already exists!" });
      }

      let query = `UPDATE balance_sheet_master SET categoryType=?, category=?, subCategory=? WHERE id=? AND isDeleted = 0`;
      let result = await connection.query(query, [categoryType.trim(), category.trim(), subCategory.trim(), id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Balance Sheet Entry Updated",
          `The Balance Sheet entry "${subCategory.trim()}" has been updated.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Balance sheet not found!" });
      }

      return res.status(200).send({ status: true, message: "Balance sheet updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Toggle Status
  toggleBalanceSheet: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;
      if (!id) return res.status(400).send({ status: false, message: "ID is required!" });

      let getQuery = `SELECT isActive FROM balance_sheet_master WHERE id=? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Balance sheet not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE balance_sheet_master SET isActive=? WHERE id=? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({ status: true, message: `Balance sheet ${newStatus === 1 ? "activated" : "deactivated"} successfully!` });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete
  deleteBalanceSheet: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;
      if (!id) return res.status(400).send({ status: false, message: "ID is required!" });

      // Soft delete: set isDeleted to 1
      let query = `UPDATE balance_sheet_master SET isDeleted = 1 WHERE id=?`;
      let result = await connection.query(query, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Balance sheet not found!" });
      }

      return res.status(200).send({ status: true, message: "Balance sheet deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Bulk Download
  bulkDownloadBalanceSheet: async function (req, res) {
    try {
      let query = `SELECT categoryType,category, subCategory FROM balance_sheet_master WHERE isActive=1 AND isDeleted = 0 ORDER BY id DESC`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
