const { connection } = require('../../../mySql/mySql');
const moment = require('moment-timezone');
const { createNotification } = require("../../notification/notification.controller");

// Validation function for bulk add P&L
const validatePLRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenCombinations = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row, index) => {
    const { categoryType, category, subCategory } = row;

    // Check required fields
    if (!categoryType || !categoryType.trim()) {
      invalidCount++;
      return;
    }

    if (!category || !category.trim()) {
      invalidCount++;
      return;
    }

    if (!subCategory || !subCategory.trim()) {
      invalidCount++;
      return;
    }

    // Check for duplicates within the batch (combination of categoryType, category, and subCategory)
    const trimmedCategoryType = categoryType.trim();
    const trimmedCategory = category.trim();
    const trimmedSubCategory = subCategory.trim();
    const combinationKey = `${trimmedCategoryType.toLowerCase()}|${trimmedCategory.toLowerCase()}|${trimmedSubCategory.toLowerCase()}`;

    if (seenCombinations.has(combinationKey)) {
      invalidCount++;
      return;
    }
    seenCombinations.add(combinationKey);

    // Row is valid
    validRows.push({
      categoryType: trimmedCategoryType,
      category: trimmedCategory,
      subCategory: trimmedSubCategory
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // ➕ Bulk Add P&L
  bulkAddPL: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validatePLRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database (optimized with single query)
      const existingQuery = `
        SELECT categoryType, category, subCategory FROM pl_master WHERE isDeleted = 0
      `;
      const existingRecords = await connection.query(existingQuery);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.categoryType.toLowerCase()}|${r.category.toLowerCase()}|${r.subCategory.toLowerCase()}`)
      );

      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.categoryType.toLowerCase()}|${row.category.toLowerCase()}|${row.subCategory.toLowerCase()}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all P&L records
      const insertValues = rowsToInsert.map(row => [
        row.categoryType,
        row.category,
        row.subCategory,
        1, // isActive
        0, // isDeleted
        createdOn
      ]);

      const query = `
        INSERT INTO pl_master (categoryType, category, subCategory, isActive, isDeleted, createdOn) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} P&L(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Add P&L
  addPL: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { categoryType, category, subCategory } = req.body;


      if (!categoryType || !categoryType.trim()) {
        return res.status(400).send({
          status: false,
          message: "categoryType is required!"
        });
      }
      if (!category || !category.trim()) {
        return res.status(400).send({
          status: false,
          message: "Category is required!"
        });
      }

      if (!subCategory || !subCategory.trim()) {
        return res.status(400).send({
          status: false,
          message: "Sub Category is required!"
        });
      }

      // Check for duplicate
      let validateQ = `SELECT id FROM pl_master WHERE categoryType=? AND category = ? AND subCategory = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [categoryType.trim(), category.trim(), subCategory.trim()]);

      if (validateData.length !== 0) {
        return res.status(200).send({
          status: false,
          message: "P&L entry already exists!"
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      let query = `
        INSERT INTO pl_master 
        (categoryType,category, subCategory, isActive, isDeleted, createdOn)
        VALUES (?,?, ?, 1, 0, ?)
      `;

      await connection.query(query, [categoryType.trim(), category.trim(), subCategory.trim(), createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New P&L Entry Added",
          `A new P&L entry "${subCategory.trim()}" has been added.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({
        status: true,
        message: "P&L added successfully!"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📥 Get All P&L
  getPLs: async function (req, res) {
    try {
      let query = `
        SELECT id,categoryType, category, subCategory, isActive, createdOn
        FROM pl_master
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({
        status: true,
        data: data
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📝 Update P&L
  updatePL: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, categoryType, category, subCategory } = req.body;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      if (!category || !category.trim()) {
        return res.status(400).send({
          status: false,
          message: "Category is required!"
        });
      }

      if (!categoryType || !categoryType.trim()) {
        return res.status(400).send({
          status: false,
          message: "categoryType is required!"
        });
      }

      if (!subCategory || !subCategory.trim()) {
        return res.status(400).send({
          status: false,
          message: "Sub Category is required!"
        });
      }

      // Check for duplicate (excluding current id)
      let validateQ = `SELECT id FROM pl_master WHERE categoryType=? AND category = ? AND subCategory = ? AND id != ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [categoryType.trim(), category.trim(), subCategory.trim(), id]);

      if (validateData.length !== 0) {
        return res.status(200).send({
          status: false,
          message: "P&L entry already exists!"
        });
      }

      let query = `
        UPDATE pl_master 
        SET categoryType = ?, category = ?, subCategory = ?
        WHERE id = ? AND isDeleted = 0
      `;

      let result = await connection.query(query, [categoryType.trim(), category.trim(), subCategory.trim(), id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "P&L Entry Updated",
          `The P&L entry "${subCategory.trim()}" has been updated.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      if (result.affectedRows === 0) {
        return res.status(404).send({
          status: false,
          message: "P&L not found!"
        });
      }

      return res.status(200).send({
        status: true,
        message: "P&L updated successfully!"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 🔄 Toggle P&L Status
  togglePL: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      let getQuery = `SELECT isActive FROM pl_master WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({
          status: false,
          message: "P&L not found!"
        });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE pl_master SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `P&L ${newStatus === 1 ? "activated" : "deactivated"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // ❌ Delete P&L (Soft Delete)
  deletePL: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Soft delete: set isDeleted to 1
      let query = `UPDATE pl_master SET isDeleted = 1 WHERE id = ?`;
      let result = await connection.query(query, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({
          status: false,
          message: "P&L not found!"
        });
      }

      return res.status(200).send({
        status: true,
        message: "P&L deleted successfully!"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📥 Bulk Download
  bulkDownloadPL: async function (req, res) {
    try {
      let query = `
        SELECT categoryType,category, subCategory
        FROM pl_master
        WHERE isActive = 1 AND isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({
        status: true,
        data: data
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  }
};