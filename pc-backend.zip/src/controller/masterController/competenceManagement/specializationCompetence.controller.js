const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { createNotification } = require("../../notification/notification.controller");

// Validation function for bulk add specialization competence
const validateSpecializationCompetenceRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenSpecializations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row, index) => {
        const { specialization } = row;

        // Check required fields
        if (!specialization) {
            invalidCount++;
            return;
        }

        // Check for duplicates within the batch
        if (seenSpecializations.has(specialization.toLowerCase())) {
            invalidCount++;
            return;
        }
        seenSpecializations.add(specialization.toLowerCase());

        // Row is valid
        validRows.push({
            specialization
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    // ➕ Add Specialization Competence
    addSpecializationCompetence: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            let { specialization } = req.body;
            if (!specialization) {
                return res.status(400).send({ status: false, message: "Specialization is required!" });
            }

            // Check for duplicate specialization (not deleted)
            let validateQ = `
        SELECT * FROM specialization_competence_management 
        WHERE specialization = ? AND isDeleted = 0
      `;
            let validateData = await connection.query(validateQ, [specialization]);

            if (validateData.length !== 0) {
                return res.status(200).send({ status: false, message: "Specialization already exists!" });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            let query = `
        INSERT INTO specialization_competence_management 
        (specialization, created_at, updated_at, isActive, isDeleted) 
        VALUES (?, ?, ?, 1, 0)
      `;
            const insertResult = await connection.query(query, [specialization, createdAt, createdAt]);

            // Send Notification
            try {
                const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
                const adminIds = admins.map(admin => admin.id);
                const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

                await createNotification(
                    "New Specialization Competence Added",
                    `A new specialization competence "${specialization}" has been added.`,
                    userIdsToNotify
                );
            } catch (notifError) {
                console.error("Notification Error:", notifError.message);
            }

            return res.status(200).send({ status: true, message: "Specialization added successfully!" });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // ➕ Bulk Add Specialization Competence
    bulkAddSpecializationCompetence: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            const { rows } = req.body;

            if (!rows || !Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
            }

            // Validate rows using validation function
            const { data: validRows, error: invalidCount } = validateSpecializationCompetenceRows(rows);

            if (validRows.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
                });
            }

            // Check for existing specializations in database
            const specializations = validRows.map(row => row.specialization);
            const existingQuery = `
        SELECT specialization FROM specialization_competence_management 
        WHERE specialization IN (${specializations.map(() => '?').join(',')}) AND isDeleted = 0
      `;
            const existingEntries = await connection.query(existingQuery, specializations);
            const existingSpecializations = new Set(existingEntries.map(e => e.specialization.toLowerCase()));

            // Filter out rows that already exist in DB
            const rowsToInsert = validRows.filter(row => !existingSpecializations.has(row.specialization.toLowerCase()));
            const duplicateCount = validRows.length - rowsToInsert.length;
            const totalInvalidCount = invalidCount + duplicateCount;

            if (rowsToInsert.length === 0) {
                return res.status(200).send({
                    status: false,
                    message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            // Build single bulk insert query
            const insertValues = rowsToInsert.map(row => [
                row.specialization,
                createdAt,
                createdAt,
                1, // isActive
                0  // isDeleted
            ]);

            const query = `
        INSERT INTO specialization_competence_management 
        (specialization, created_at, updated_at, isActive, isDeleted) 
        VALUES ?
      `;
            await connection.query(query, [insertValues]);

            let message = `${rowsToInsert.length} Specialization(s) added successfully!`;
            if (totalInvalidCount > 0) {
                message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
            }

            return res.status(200).send({
                status: true,
                message: message,
                data: {
                    inserted: rowsToInsert.length,
                    invalid: totalInvalidCount
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllSpecializationCompetences: async function (req, res) {
        try {
            let query = `
        SELECT id, specialization, created_at, updated_at, isActive 
        FROM specialization_competence_management 
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
            let data = await connection.query(query);

            return res.status(200).send({ status: true, data: data });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getSpecializationCompetenceById: async function (req, res) {
        try {
            let { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            let query = `
        SELECT id, specialization, created_at, updated_at, isActive 
        FROM specialization_competence_management 
        WHERE id = ? AND isDeleted = 0
      `;
            let data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Specialization not found!" });
            }

            return res.status(200).send({ status: true, data: data[0] });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateSpecializationCompetence: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            let { id, specialization } = req.body;

            if (!id || !specialization) {
                return res.status(400).send({ status: false, message: "ID and specialization are required!" });
            }

            // Check for duplicate specialization (excluding current id)
            let validateQ = `
        SELECT * FROM specialization_competence_management 
        WHERE specialization = ? AND id != ? AND isDeleted = 0
      `;
            let validateData = await connection.query(validateQ, [specialization, id]);

            if (validateData.length !== 0) {
                return res.status(200).send({ status: false, message: "Specialization already exists!" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            let query = `
        UPDATE specialization_competence_management 
        SET specialization = ?, updated_at = ?
        WHERE id = ? AND isDeleted = 0
      `;
            let updatedResult = await connection.query(query, [specialization, updatedAt, id]);

            // Send Notification
            try {
                const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
                const adminIds = admins.map(admin => admin.id);
                const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

                await createNotification(
                    "Specialization Competence Updated",
                    `The specialization competence "${specialization}" has been updated.`,
                    userIdsToNotify
                );
            } catch (notifError) {
                console.error("Notification Error:", notifError.message);
            }

            return res.status(200).send({ status: true, message: "Specialization updated successfully!", data: updatedResult });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleSpecializationCompetence: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            let { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            // Get current status
            let getQuery = `SELECT isActive FROM specialization_competence_management WHERE id = ? AND isDeleted = 0`;
            let data = await connection.query(getQuery, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Specialization not found!" });
            }

            let newStatus = data[0].isActive === 1 ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            let updateQuery = `UPDATE specialization_competence_management SET isActive = ?, updated_at = ? WHERE id = ? AND isDeleted = 0`;
            let updatedResult = await connection.query(updateQuery, [newStatus, updatedAt, id]);

            return res.status(200).send({
                status: true,
                message: `Specialization ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
                data: updatedResult
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteSpecializationCompetence: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            let { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            let query = `UPDATE specialization_competence_management SET isDeleted = 1, updated_at = ? WHERE id = ?`;
            let updatedResult = await connection.query(query, [updatedAt, id]);

            return res.status(200).send({ status: true, message: "Specialization deleted successfully!", data: updatedResult });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};
