const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { createNotification } = require("../../notification/notification.controller");

// Validation function for bulk add competence levels
const validateCompetenceLevelRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row, index) => {
        const { competence_type, competence } = row;

        // Check required fields
        if (!competence_type || !competence) {
            invalidCount++;
            return;
        }

        // Check for duplicates within the batch
        const combination = `${competence_type.toLowerCase()}-${competence.toLowerCase()}`;
        if (seenCombinations.has(combination)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combination);

        // Row is valid
        validRows.push({
            competence_type,
            competence
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    // ➕ Add Competence Level
    addCompetenceLevel: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            let { competence_type, competence } = req.body;
            if (!competence_type || !competence) {
                return res.status(400).send({ status: false, message: "Competence type and competence are required!" });
            }

            // Check for duplicate competence level (not deleted)
            let validateQ = `
        SELECT * FROM competence_level_competence_management 
        WHERE competence_type = ? AND competence = ? AND isDeleted = 0
      `;
            let validateData = await connection.query(validateQ, [competence_type, competence]);

            if (validateData.length !== 0) {
                return res.status(200).send({ status: false, message: "Competence level already exists!" });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            let query = `
        INSERT INTO competence_level_competence_management 
        (competence_type, competence, created_at, updated_at, isActive, isDeleted) 
        VALUES (?, ?, ?, ?, 1, 0)
      `;
            const insertResult = await connection.query(query, [competence_type, competence, createdAt, createdAt]);

            // Send Notification
            try {
                const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
                const adminIds = admins.map(admin => admin.id);
                const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

                await createNotification(
                    "New Competence Level Added",
                    `A new competence level "${competence}" of type "${competence_type}" has been added.`,
                    userIdsToNotify
                );
            } catch (notifError) {
                console.error("Notification Error:", notifError.message);
            }

            return res.status(200).send({ status: true, message: "Competence level added successfully!" });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // ➕ Bulk Add Competence Level
    bulkAddCompetenceLevel: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            const { rows } = req.body;

            if (!rows || !Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
            }

            // Validate rows using validation function
            const { data: validRows, error: invalidCount } = validateCompetenceLevelRows(rows);

            if (validRows.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
                });
            }

            // Check for existing entries in database
            const rowsToInsert = [];
            let duplicateInDbCount = 0;

            for (const row of validRows) {
                let validateQ = `
                    SELECT id FROM competence_level_competence_management 
                    WHERE competence_type = ? AND competence = ? AND isDeleted = 0
                `;
                let existing = await connection.query(validateQ, [row.competence_type, row.competence]);
                if (existing.length === 0) {
                    rowsToInsert.push(row);
                } else {
                    duplicateInDbCount++;
                }
            }

            const totalInvalidCount = invalidCount + duplicateInDbCount;

            if (rowsToInsert.length === 0) {
                return res.status(200).send({
                    status: false,
                    message: `No new records to insert. ${totalInvalidCount} invalid/duplicate entry/entries found.`
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            // Build single bulk insert query for all valid new rows
            const insertValues = rowsToInsert.map(row => [
                row.competence_type,
                row.competence,
                createdAt,
                createdAt,
                1, // isActive
                0  // isDeleted
            ]);

            const query = `
        INSERT INTO competence_level_competence_management 
        (competence_type, competence, created_at, updated_at, isActive, isDeleted) 
        VALUES ?
      `;
            await connection.query(query, [insertValues]);

            let message = `${rowsToInsert.length} Competence level(s) added successfully!`;
            if (totalInvalidCount > 0) {
                message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
            }

            return res.status(200).send({
                status: true,
                message: message,
                data: {
                    inserted: rowsToInsert.length,
                    invalid: totalInvalidCount
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllCompetenceLevels: async function (req, res) {
        try {
            let query = `
        SELECT id, competence_type, competence, created_at, updated_at, isActive 
        FROM competence_level_competence_management 
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
            let data = await connection.query(query);

            return res.status(200).send({ status: true, data: data });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getCompetenceLevelById: async function (req, res) {
        try {
            let { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            let query = `
        SELECT id, competence_type, competence, created_at, updated_at, isActive 
        FROM competence_level_competence_management 
        WHERE id = ? AND isDeleted = 0
      `;
            let data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Competence level not found!" });
            }

            return res.status(200).send({ status: true, data: data[0] });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateCompetenceLevel: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            let { id, competence_type, competence } = req.body;

            if (!id || !competence_type || !competence) {
                return res.status(400).send({ status: false, message: "ID, competence type and competence are required!" });
            }

            // Check for duplicate (excluding current id)
            let validateQ = `
        SELECT * FROM competence_level_competence_management 
        WHERE competence_type = ? AND competence = ? AND id != ? AND isDeleted = 0
      `;
            let validateData = await connection.query(validateQ, [competence_type, competence, id]);

            if (validateData.length !== 0) {
                return res.status(200).send({ status: false, message: "Competence level already exists with these details!" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            let query = `
        UPDATE competence_level_competence_management 
        SET competence_type = ?, competence = ?, updated_at = ?
        WHERE id = ? AND isDeleted = 0
      `;
            let updatedResult = await connection.query(query, [competence_type, competence, updatedAt, id]);

            // Send Notification
            try {
                const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
                const adminIds = admins.map(admin => admin.id);
                const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

                await createNotification(
                    "Competence Level Updated",
                    `The competence level "${competence}" of type "${competence_type}" has been updated.`,
                    userIdsToNotify
                );
            } catch (notifError) {
                console.error("Notification Error:", notifError.message);
            }

            return res.status(200).send({ status: true, message: "Competence level updated successfully!", data: updatedResult });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleCompetenceLevel: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            let { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            // Get current status
            let getQuery = `SELECT isActive FROM competence_level_competence_management WHERE id = ? AND isDeleted = 0`;
            let data = await connection.query(getQuery, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Competence level not found!" });
            }

            let newStatus = data[0].isActive === 1 ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            let updateQuery = `UPDATE competence_level_competence_management SET isActive = ?, updated_at = ? WHERE id = ? AND isDeleted = 0`;
            let updatedResult = await connection.query(updateQuery, [newStatus, updatedAt, id]);

            return res.status(200).send({
                status: true,
                message: `Competence level ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
                data: updatedResult
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteCompetenceLevel: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            let { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            let query = `UPDATE competence_level_competence_management SET isDeleted = 1, updated_at = ? WHERE id = ?`;
            let updatedResult = await connection.query(query, [updatedAt, id]);

            return res.status(200).send({ status: true, message: "Competence level deleted successfully!", data: updatedResult });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};
