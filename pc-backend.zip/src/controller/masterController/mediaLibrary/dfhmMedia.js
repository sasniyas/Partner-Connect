const { connection } = require("../../../mySql/mySql");
const moment = require("moment-timezone");
const { uploadFile } = require("../../azurestorage/fileUpload");
const { createNotification } = require("../../notification/notification.controller");

module.exports = {
  // ➕ Add DFHM Media
  addDfhmMedia: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { slide_title } = req.body;

      if (!slide_title || !req.files.length) {
        return res.status(400).send({ status: false, message: "slide_title and image file are required!" });
      }
      let file = req.files[0]

      const image_url = await uploadFile(file);
      if (!image_url) {
        return res.status(400).send({ status: false, message: "Failed to upload image!" });
      }

      // Check for duplicate title
      let validateQ = `SELECT * FROM dfhm_media WHERE slide_title = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [slide_title]);

      if (validateData.length !== 0) {
        return res
          .status(200)
          .send({ status: false, message: "DFHM Media with this title already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `INSERT INTO dfhm_media (slide_title, image_url, createdOn, isActive, isDeleted) VALUES (?, ?, ?, 1, 0)`;
      const insertResult = await connection.query(query, [slide_title, image_url, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New DFHM Media Added",
          `A new DFHM Media slide "${slide_title}" has been added.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res
        .status(200)
        .send({ status: true, message: "DFHM Media added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All DFHM Media
  getAllDfhmMedia: async function (req, res) {
    try {
      let query = `SELECT id, slide_title, image_url, createdOn, isActive, isDeleted FROM dfhm_media WHERE isDeleted = 0 ORDER BY id DESC`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get DFHM Media by ID
  getDfhmMediaById: async function (req, res) {
    try {
      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `SELECT id, slide_title, image_url, createdOn, isActive, isDeleted FROM dfhm_media WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "DFHM Media not found!" });
      }

      return res.status(200).send({ status: true, data: data[0] });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update DFHM Media
  updateDfhmMedia: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, slide_title, isActive } = req.body;

      if (!id || !slide_title) {
        return res.status(400).send({ status: false, message: "ID and slide_title are required!" });
      }

      let image_url = null;
      if (req.files.length) {
        let file = req.files[0]
        image_url = await uploadFile(file);
        if (!image_url) {
          return res.status(400).send({ status: false, message: "Failed to upload image!" });
        }
      }

      // Check for duplicate title (excluding current id)
      let validateQ = `SELECT * FROM dfhm_media WHERE slide_title = ? AND id != ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [slide_title, id]);

      if (validateData.length !== 0) {
        return res
          .status(200)
          .send({ status: false, message: "DFHM Media with this title already exists!" });
      }

      let query;
      let params;

      if (image_url) {
        query = `UPDATE dfhm_media SET slide_title = ?, image_url = ? WHERE id = ? AND isDeleted = 0`;
        params = [slide_title, image_url, id];
      } else {
        query = `UPDATE dfhm_media SET slide_title = ? WHERE id = ? AND isDeleted = 0`;
        params = [slide_title, id];
      }

      const updatedResult = await connection.query(query, params);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "DFHM Media Updated",
          `The DFHM Media slide "${slide_title}" has been updated.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res
        .status(200)
        .send({ status: true, message: "DFHM Media updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable DFHM Media
  toggleDfhmMedia: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM dfhm_media WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "DFHM Media not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE dfhm_media SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      const updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `DFHM Media ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete DFHM Media
  deleteDfhmMedia: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE dfhm_media SET isDeleted = 1 WHERE id = ?`;
      const updatedResult = await connection.query(query, [id]);

      return res
        .status(200)
        .send({ status: true, message: "DFHM Media deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
