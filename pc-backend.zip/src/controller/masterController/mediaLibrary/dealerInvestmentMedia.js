const { connection } = require("../../../mySql/mySql"); // adjust path
const moment = require('moment-timezone');
const { uploadFile } = require("../../azurestorage/fileUpload");
const { createNotification } = require("../../notification/notification.controller");
module.exports = {
  // ➕ Add Dealer Investment Media
  addDealerInvestmentMedia: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { slide_title } = req.body;

      if (!slide_title || !req.files.length) {
        return res.status(400).send({ status: false, message: "slide_title and image file are required!" });
      }
      let file = req.files[0]

      const image_url = await uploadFile(file);
      if (!image_url) {
        return res.status(400).send({ status: false, message: "Failed to upload image!" });
      }

      // Check for duplicate slide title
      let validateQ = `SELECT * FROM dealer_investment_media WHERE slide_title = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [slide_title]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Dealer Investment Media with this title already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `INSERT INTO dealer_investment_media (slide_title, image_url, createdOn, isActive, isDeleted) VALUES (?, ?, ?, 1, 0)`;
      const insertResult = await connection.query(query, [slide_title, image_url, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserIdInt = currentUserId;
        const userIdsToNotify = [...new Set([...adminIds, currentUserIdInt])].filter(Boolean);

        await createNotification(
          "New Dealer Investment Media Added",
          `A new Dealer Investment Media slide "${slide_title}" has been added.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Dealer Investment Media added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Dealer Investment Media
  getAllDealerInvestmentMedia: async function (req, res) {
    try {
      let query = `SELECT id, slide_title, image_url, createdOn, isActive, isDeleted FROM dealer_investment_media WHERE isDeleted = 0 ORDER BY id DESC`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get Dealer Investment Media by ID
  getDealerInvestmentMediaById: async function (req, res) {
    try {
      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `SELECT id, slide_title, image_url, createdOn, isActive, isDeleted FROM dealer_investment_media WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Dealer Investment Media not found!" });
      }

      return res.status(200).send({ status: true, data: data[0] });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Dealer Investment Media
  updateDealerInvestmentMedia: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, slide_title, isActive } = req.body;


      if (!id || !slide_title) {
        return res.status(400).send({ status: false, message: "ID and slide_title are required!" });
      }

      let image_url = null;
      if (req.files.length) {
        let file = req.files[0]
        image_url = await uploadFile(file);
        if (!image_url) {
          return res.status(400).send({ status: false, message: "Failed to upload image!" });
        }
      }

      // Check for duplicate slide title (excluding current id)
      let validateQ = `SELECT * FROM dealer_investment_media WHERE slide_title = ? AND id != ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [slide_title, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Dealer Investment Media with this title already exists!" });
      }

      let query;
      let params;

      if (image_url) {
        query = `UPDATE dealer_investment_media SET slide_title = ?, image_url = ? WHERE id = ? AND isDeleted = 0`;
        params = [slide_title, image_url, id];
      } else {
        query = `UPDATE dealer_investment_media SET slide_title = ? WHERE id = ? AND isDeleted = 0`;
        params = [slide_title, id];
      }

      const updatedResult = await connection.query(query, params);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserIdInt = currentUserId;
        const userIdsToNotify = [...new Set([...adminIds, currentUserIdInt])].filter(Boolean);

        await createNotification(
          "Dealer Investment Media Updated",
          `The Dealer Investment Media slide "${slide_title}" has been updated.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Dealer Investment Media updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable Dealer Investment Media
  toggleDealerInvestmentMedia: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM dealer_investment_media WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Dealer Investment Media not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE dealer_investment_media SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      const updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Dealer Investment Media ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete Dealer Investment Media
  deleteDealerInvestmentMedia: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE dealer_investment_media SET isDeleted = 1 WHERE id = ?`;
      const updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Dealer Investment Media deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

