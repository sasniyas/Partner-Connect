const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { createNotification } = require("../../notification/notification.controller");

const validateDepartmentRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seen = new Set();

    rows.forEach((row) => {
        const { name, category } = row;

        if (!name || !category) {
            invalidCount++;
            return;
        }

        const trimmedName = name.trim();
        const key = `${trimmedName.toLowerCase()}_${category.toLowerCase()}`;

        if (trimmedName === "" || seen.has(key)) {
            invalidCount++;
            return;
        }
        seen.add(key);

        validRows.push({
            name: trimmedName,
            category: category
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {

    addDepartment: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            const { name, category } = req.body;

            if (!name || !category) {
                return res.status(400).send({
                    status: false,
                    message: "Name and Category are required!"
                });
            }

            // Check duplicate
            const validateQ = `SELECT id FROM department WHERE name = ? AND category = ? AND isDeleted = 0`;
            const validateData = await connection.query(validateQ, [name.trim(), category]);

            if (validateData.length !== 0) {
                return res.status(200).send({ status: false, message: "Department already exists for this category!" });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const query = `
                INSERT INTO department (name, category, created_at, updated_at, isActive, isDeleted) 
                VALUES (?, ?, ?, ?, 1, 0)
            `;
            await connection.query(query, [name.trim(), category, createdAt, createdAt]);

            // Send Notification
            try {
                const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
                const adminIds = admins.map(admin => admin.id);
                const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

                await createNotification(
                    "New Department Added",
                    `A new department "${name.trim()}" has been added in the "${category}" category.`,
                    userIdsToNotify
                );
            } catch (notifError) {
                console.error("Notification Error:", notifError.message);
            }

            return res.status(200).send({ status: true, message: "Department added successfully!" });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllDepartments: async function (req, res) {
        try {
            const query = `
                SELECT id, name, category, created_at, updated_at, isActive 
                FROM department 
                WHERE isDeleted = 0 
                ORDER BY id DESC
            `;
            const data = await connection.query(query);

            return res.status(200).send({ status: true, data });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getDepartmentById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const query = `SELECT * FROM department WHERE id = ? AND isDeleted = 0`;
            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Department not found!" });
            }

            return res.status(200).send({ status: true, data: data[0] });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateDepartment: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            const { id, name, category } = req.body;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            // Check if exists
            const exists = await connection.query(
                "SELECT id FROM department WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Department not found!" });
            }

            const updateFields = [];
            const updateValues = [];

            if (name !== undefined) {
                updateFields.push("name = ?");
                updateValues.push(name.trim());
            }
            if (category !== undefined) {
                updateFields.push("category = ?");
                updateValues.push(category);
            }

            if (updateFields.length === 0) {
                return res.status(400).send({ status: false, message: "No fields to update!" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("updated_at = ?");
            updateValues.push(updatedAt);
            updateValues.push(id);

            const query = `UPDATE department SET ${updateFields.join(", ")} WHERE id = ?`;
            await connection.query(query, updateValues);

            // Send Notification
            try {
                const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
                const adminIds = admins.map(admin => admin.id);
                const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

                await createNotification(
                    "Department Updated",
                    `The department details for "${name ? name.trim() : 'a department'}" have been updated.`,
                    userIdsToNotify
                );
            } catch (notifError) {
                console.error("Notification Error:", notifError.message);
            }

            return res.status(200).send({ status: true, message: "Department updated successfully!" });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleDepartmentStatus: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const data = await connection.query(
                "SELECT isActive FROM department WHERE id = ? AND isDeleted = 0",
                [id]
            );

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Department not found!" });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE department SET isActive = ?, updated_at = ? WHERE id = ?",
                [newStatus, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Department ${newStatus ? "enabled" : "disabled"} successfully!`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteDepartment: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required!" });
            }

            const exists = await connection.query(
                "SELECT id FROM department WHERE id = ? AND isDeleted = 0",
                [id]
            );

            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Department not found!" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE department SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [updatedAt, id]
            );

            return res.status(200).send({ status: true, message: "Department deleted successfully!" });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    bulkAddDepartment: async function (req, res) {
        try {
            // Persona Validation
            const currentUserId = req.decodedToken;
            const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

            if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
                return res.status(401).send({ status: false, message: "unauthorized access error" });
            }

            const { rows } = req.body;

            if (!rows || !Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
            }

            const { data: validRows, error: invalidCount } = validateDepartmentRows(rows);

            if (validRows.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
                });
            }

            // Check for existing records (name + category + isDeleted=0)
            let duplicateCount = 0;
            const finalRowsToInsert = [];

            for (const row of validRows) {
                const validateQ = `SELECT id FROM department WHERE name = ? AND category = ? AND isDeleted = 0`;
                const validateData = await connection.query(validateQ, [row.name, row.category]);

                if (validateData.length === 0) {
                    finalRowsToInsert.push(row);
                } else {
                    duplicateCount++;
                }
            }

            const totalInvalidCount = invalidCount + duplicateCount;

            if (finalRowsToInsert.length === 0) {
                return res.status(200).send({
                    status: false,
                    message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const insertValues = finalRowsToInsert.map(row => [
                row.name,
                row.category,
                createdAt,
                createdAt,
                1,
                0
            ]);

            const query = `
                INSERT INTO department (name, category, created_at, updated_at, isActive, isDeleted) 
                VALUES ?
            `;
            await connection.query(query, [insertValues]);

            let message = `${finalRowsToInsert.length} Department(s) added successfully!`;
            if (totalInvalidCount > 0) {
                message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
            }

            return res.status(200).send({
                status: true,
                message: message,
                data: {
                    inserted: finalRowsToInsert.length,
                    invalid: totalInvalidCount
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};
