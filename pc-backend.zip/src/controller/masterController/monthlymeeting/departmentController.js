const { connection } = require('../../../mySql/mySql');
const moment = require('moment-timezone');
const { createNotification } = require("../../notification/notification.controller");

module.exports = {
  // ➕ Add Department
  addDepartment: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let createdBy = currentUserId
      let { departmentName } = req.body;
      console.log(createdBy)
      if (!departmentName || !departmentName.trim() || !createdBy) {
        return res.status(400).send({
          status: false,
          message: "Department name and createdBy (userId) are required!"
        });
      }

      // Check duplicate
      let validateQ = `SELECT id FROM departments WHERE name = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [departmentName.trim()]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Department already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      let query = `
        INSERT INTO departments (name, createdBy, createdOn, isActive, isDeleted) 
        VALUES (?, ?, ?, 1, 0)
      `;
      await connection.query(query, [departmentName.trim(), currentUserId, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Department Added",
          `A new Department "${departmentName.trim()}" has been added.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Department added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Departments
  getDepartments: async function (req, res) {
    try {
      let query = `
        SELECT d.id, d.name, u.firstName AS createdBy, d.createdOn, d.isActive
        FROM departments d
        LEFT JOIN userdetails u ON d.createdBy = u.id
        WHERE d.isDeleted = 0
        ORDER BY d.id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Department
  updateDepartment: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, departmentName } = req.body;

      if (!id || !departmentName || !departmentName.trim()) {
        return res.status(400).send({ status: false, message: "ID and Department name are required!" });
      }

      // Check duplicate (excluding current id)
      let validateQ = `SELECT id FROM departments WHERE name = ? AND id != ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [departmentName.trim(), id]);
      console.log(validateData)
      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Department already exists!" });
      }

      let query = `UPDATE departments SET name = ? WHERE id = ? AND isDeleted = 0`;
      let result = await connection.query(query, [departmentName.trim(), id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Department Updated",
          `The Department "${departmentName.trim()}" has been updated.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Department not found!" });
      }

      return res.status(200).send({ status: true, message: "Department updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Toggle Department Status
  toggleDepartment: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let getQuery = `SELECT isActive FROM departments WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Department not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE departments SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Department ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete Department
  deleteDepartment: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Soft delete: set isDeleted to 1
      let query = `UPDATE departments SET isDeleted = 1 WHERE id = ?`;
      let result = await connection.query(query, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Department not found!" });
      }

      return res.status(200).send({ status: true, message: "Department deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
