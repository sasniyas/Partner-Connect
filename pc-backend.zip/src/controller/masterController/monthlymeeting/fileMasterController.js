const { connection } = require("../../../mySql/mySql");
const moment = require("moment-timezone");
const { uploadFile } = require("../../azurestorage/fileUpload");
const { createNotification } = require("../../notification/notification.controller");

module.exports = {
  // ➕ Add File
  addFile: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { fileName } = req.body;
      if (!fileName || !req.files || req.files.length === 0) {
        return res.status(400).send({
          status: false,
          message: "File name and file are required!"
        });
      }

      // Upload to Azure
      let file = req.files[0];
      let url = await uploadFile(file);

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Insert into DB
      await connection.query(
        `INSERT INTO file_master (fileName, fileUrl, uploadedBy, createdOn, isActive, isDeleted)
         VALUES (?, ?, ?, ?, 1, 0)`,
        [fileName, url, currentUserId, createdOn]
      );

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New File Uploaded",
          `A new File "${fileName}" has been uploaded to the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "File uploaded successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📌 Get All Files
  getAllFiles: async function (req, res) {
    try {
      const rows = await connection.query(`
        SELECT f.*, u.FirstName as uploadedUser
        FROM file_master f
        LEFT JOIN userdetails u ON f.uploadedBy = u.id
        WHERE f.isDeleted = 0
        ORDER BY f.createdOn DESC
      `);

      return res.status(200).send({ status: true, data: rows });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📌 Get File by ID
  getFileById: async function (req, res) {
    try {
      const { id } = req.params;
      const rows = await connection.query(`SELECT * FROM file_master WHERE id=? AND isDeleted = 0`, [id]);

      if (rows.length === 0) {
        return res.status(404).send({ status: false, message: "File not found" });
      }

      return res.status(200).send({ status: true, data: rows[0] });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📌 Update File
  updateFile: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, fileName } = req.body;

      let url = "";
      if (req.files && req.files.length > 0) {
        let file = req.files[0];
        url = await uploadFile(file);
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      await connection.query(
        `UPDATE file_master SET 
          fileName=?, 
          fileUrl=IF(?!='', ?, fileUrl)
         WHERE id=? AND isDeleted = 0`,
        [fileName, url, url, id]
      );

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "File Updated",
          `The File "${fileName}" has been updated in the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "File updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📌 Toggle Active/Inactive
  toggleFile: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { id } = req.params;
      const rows = await connection.query(`SELECT isActive FROM file_master WHERE id=? AND isDeleted = 0`, [id]);

      if (rows.length === 0) {
        return res.status(404).send({ status: false, message: "File not found" });
      }

      const newStatus = rows[0].isActive === 1 ? 0 : 1;
      await connection.query(`UPDATE file_master SET isActive=? WHERE id=? AND isDeleted = 0`, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `File ${newStatus === 1 ? "activated" : "deactivated"} successfully!`
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📌 Delete File
  deleteFile: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { id } = req.params;

      // Soft delete: set isDeleted = 1
      const result = await connection.query(`UPDATE file_master SET isDeleted = 1 WHERE id=?`, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "File not found" });
      }

      return res.status(200).send({ status: true, message: "File deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
