const { connection } = require("../../../mySql/mySql"); // adjust path
const moment = require("moment-timezone");
const { validateUserRole, validateLocation, validateRoleRows } = require("../../../utils/validation/scorecardValidation/userRole.validation");
const { createNotification } = require("../../notification/notification.controller");

module.exports = {
  // ➕ Add Role
  addRole: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { userType, location, userRole } = req.body;

      if (!userType || !validateUserRole(userRole)) {
        return res.status(400).send({ status: false, message: "User Type and User Role are required! User Role must be less than 100 characters." });
      }

      // For Volvo User -> Location is required
      if (!validateLocation(userType, location)) {
        return res.status(400).send({ status: false, message: "Location is required for Volvo User!" });
      }

      const trimmedUserRole = userRole.trim();

      // For Dealer User -> Location should be null
      let finalLocation = null;
      if (userType === "Dealer User") {
        finalLocation = location ? location.trim() : null;
      } else if (userType === "Volvo User") {
        finalLocation = location.trim();
      } else {
        finalLocation = location ? location.trim() : null;
      }

      // Check for duplicate role with same userType + location
      let validateQ = `SELECT * FROM role_master WHERE userType = ? AND userRole = ? AND (location = ? OR location IS NULL) AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [userType, trimmedUserRole, finalLocation]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Role already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO role_master (userType, location, userRole, createdOn, isActive, isDeleted)
        VALUES (?, ?, ?, ?, 1, 0)
      `;
      await connection.query(query, [userType, finalLocation, trimmedUserRole, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Role Added",
          `A new user role "${trimmedUserRole}" has been added to the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Role added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Role
  bulkAddRole: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateRoleRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database (userType + userRole + location)
      const existingQuery = `SELECT userType, userRole, location FROM role_master WHERE isDeleted = 0`;
      const existingRecords = await connection.query(existingQuery);

      const existingCombinationsSet = new Set(
        existingRecords.map(r => {
          const locationKey = r.location || "NULL";
          return `${r.userType.toLowerCase()}|${r.userRole.toLowerCase()}|${locationKey.toLowerCase()}`;
        })
      );

      const rowsToInsert = validRows.filter(row => {
        const locationKey = row.location || "NULL";
        return !existingCombinationsSet.has(`${row.userType.toLowerCase()}|${row.userRole.toLowerCase()}|${locationKey.toLowerCase()}`);
      });

      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All roles already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all roles
      const insertValues = rowsToInsert.map(row => [
        row.userType,
        row.location,
        row.userRole,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO role_master (userType, location, userRole, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Role(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      console.log(error);
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Roles
  getRoles: async function (req, res) {
    try {
      let query = `
        SELECT id, userType, location, userRole, isActive, createdOn
        FROM role_master
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Role
  updateRole: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, userType, location, userRole } = req.body;

      if (!id || !userType || !validateUserRole(userRole)) {
        return res.status(400).send({ status: false, message: "ID, User Type and User Role are required! User Role must be less than 100 characters." });
      }

      if (!validateLocation(userType, location)) {
        return res.status(400).send({ status: false, message: "Location is required for Volvo User!" });
      }

      const trimmedUserRole = userRole.trim();

      // For Dealer User -> Location should be null
      let finalLocation = null;
      if (userType === "Dealer User") {
        finalLocation = location ? location.trim() : null;
      } else if (userType === "Volvo User") {
        finalLocation = location.trim();
      } else {
        finalLocation = location ? location.trim() : null;
      }

      // Check for duplicate role with same userType + location
      let validateQ = `SELECT * FROM role_master WHERE userType = ? AND userRole = ? AND(location = ? OR location IS NULL) AND id != ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [userType, trimmedUserRole, finalLocation, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Role already exists!" });
      }

      let query = `
        UPDATE role_master 
        SET userType = ?, location = ?, userRole = ?
        WHERE id = ? AND isDeleted = 0
      `;
      await connection.query(query, [userType, finalLocation, trimmedUserRole, id]);

      let query2 = `
        UPDATE userDetails 
        SET persona = ?
        WHERE personaId = ?
      `;
      await connection.query(query2, [trimmedUserRole, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Role Updated",
          `The user role "${trimmedUserRole}" has been updated in the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Role updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable Role
  toggleRole: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let getQuery = `SELECT isActive FROM role_master WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Role not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE role_master SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Role ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete Role
  deleteRole: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Soft delete: set isDeleted to 1
      let query = `UPDATE role_master SET isDeleted = 1 WHERE id = ? `;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Role deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
