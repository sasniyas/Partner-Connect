const { connection } = require("../../../mySql/mySql"); // adjust path
const moment = require("moment-timezone");
const { createNotification } = require("../../notification/notification.controller");

// Validation function for bulk add state
const validateStateRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenCombinations = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row, index) => {
    const { marketarea_id, stateName } = row;

    // Check required fields
    if (!marketarea_id || !stateName || stateName.trim() === "") {
      invalidCount++;
      return;
    }

    const trimmedStateName = stateName.trim();

    // Check for duplicates within the batch (combination of stateName and marketarea_id)
    const combinationKey = `${marketarea_id}_${trimmedStateName.toLowerCase()}`;
    if (seenCombinations.has(combinationKey)) {
      invalidCount++;
      return;
    }
    seenCombinations.add(combinationKey);

    // Row is valid
    validRows.push({
      marketarea_id,
      stateName: trimmedStateName
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // ➕ Add State
  addState: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { marketarea_id, stateName } = req.body;

      if (!marketarea_id || !stateName || stateName.trim() === "") {
        return res.status(400).send({ status: false, message: "Market Area and State Name are required!" });
      }

      // Validate duplicate
      let validateQ = `SELECT * FROM state_master WHERE stateName = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [stateName]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "State already exists in this Market Area!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `INSERT INTO state_master (stateName,marketarea_id, createdOn, isActive, isDeleted) VALUES (?, ?, ?, 1, 0)`;
      await connection.query(query, [stateName, marketarea_id, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New State Added",
          `A new state "${stateName}" has been added to the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "State added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add State (Check duplicate by stateName only)
  bulkAddState: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateStateRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing STATE NAMES in database (stateName only, NOT combination)
      const existingQuery = `SELECT stateName FROM state_master WHERE isDeleted = 0`;
      const existingRecords = await connection.query(existingQuery);

      const existingStateNames = new Set(
        existingRecords.map(r => r.stateName.toLowerCase())
      );

      // Filter out rows where stateName already exists
      const rowsToInsert = validRows.filter(row =>
        !existingStateNames.has(row.stateName.toLowerCase())
      );

      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All states already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all states
      const insertValues = rowsToInsert.map(row => [
        row.stateName,
        row.marketarea_id,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO state_master (stateName, marketarea_id, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} State(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      console.log(error);
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 📥 Get All States (with Market Area Name)
  getStates: async function (req, res) {
    try {
      let query = `
        SELECT s.id, s.stateName, s.isActive, s.createdOn, 
               m.marketarea AS marketAreaName, s.marketarea_id
        FROM state_master s
        JOIN market_area m ON s.marketarea_id = m.id
        WHERE s.isDeleted = 0
        ORDER BY s.id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update State
  updateState: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, stateName, marketarea_id } = req.body;

      if (!id || !stateName || !marketarea_id) {
        return res.status(400).send({ status: false, message: "ID, Market Area and State Name are required!" });
      }
      // Validate duplicate
      let validateQ = `SELECT * FROM state_master WHERE stateName = ? AND marketarea_id= ? AND id!=? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [stateName, marketarea_id, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "State already exists in this Market Area!" });
      }

      let query = `UPDATE state_master SET stateName = ?, marketarea_id = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(query, [stateName, marketarea_id, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "State Updated",
          `The state "${stateName}" has been updated in the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "State updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable State
  toggleState: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let getQuery = `SELECT isActive FROM state_master WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "State not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE state_master SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `State ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete State
  deleteState: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Soft delete: set isDeleted to 1
      let query = `UPDATE state_master SET isDeleted = 1 WHERE id = ?`;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "State deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
