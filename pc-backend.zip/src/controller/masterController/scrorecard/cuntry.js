const { connection } = require("../../../mySql/mySql"); // adjust path
const moment = require("moment-timezone");
const { createNotification } = require("../../notification/notification.controller");

// Validation function for bulk add country
const validateCountryRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenCountryNames = new Set();
  const seenCountryCodes = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row, index) => {
    const { countryName, countryCode } = row;

    // Check required fields
    if (!countryName || countryName.trim() === "" || !countryCode || countryCode.trim() === "") {
      invalidCount++;
      return;
    }

    const trimmedName = countryName.trim();
    const trimmedCode = countryCode.trim();

    // Check for duplicates within the batch (by countryName or countryCode)
    if (seenCountryNames.has(trimmedName.toLowerCase()) || seenCountryCodes.has(trimmedCode.toUpperCase())) {
      invalidCount++;
      return;
    }
    seenCountryNames.add(trimmedName.toLowerCase());
    seenCountryCodes.add(trimmedCode.toUpperCase());

    // Row is valid
    validRows.push({
      countryName: trimmedName,
      countryCode: trimmedCode
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // ➕ Add Country
  addCountry: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { countryName, countryCode } = req.body;

      if (!countryName || countryName.trim() === "" || !countryCode || countryCode.trim() === "") {
        return res.status(400).send({ status: false, message: "Country Name and Country Code are required!" });
      }

      // Check if already exists
      let validateQ = `SELECT * FROM country_master WHERE (countryName = ? OR countryCode = ?) AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [countryName, countryCode]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Country already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `INSERT INTO country_master (countryName, countryCode, createdOn, isActive, isDeleted) VALUES (?, ?, ?, 1, 0)`;
      await connection.query(query, [countryName, countryCode, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Country Added",
          `A new country "${countryName}" (${countryCode}) has been added to the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Country added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Country
  bulkAddCountry: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateCountryRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing countries in database (optimized with single query)
      const existingQuery = `
        SELECT countryName, countryCode FROM country_master WHERE isDeleted = 0
      `;
      const existingRecords = await connection.query(existingQuery);
      const existingCountryNames = new Set(existingRecords.map(r => r.countryName));
      const existingCountryCodes = new Set(existingRecords.map(r => r.countryCode));

      const rowsToInsert = validRows.filter(row =>
        !existingCountryNames.has(row.countryName) && !existingCountryCodes.has(row.countryCode)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all countries
      const insertValues = rowsToInsert.map(row => [
        row.countryName,
        row.countryCode,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO country_master (countryName, countryCode, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Country(ies) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Countries
  getCountries: async function (req, res) {
    try {
      let query = `SELECT id, countryName, countryCode, isActive, createdOn FROM country_master WHERE isDeleted = 0 ORDER BY id DESC`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Country
  updateCountry: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, countryName, countryCode } = req.body;

      if (!id || !countryName || !countryCode) {
        return res.status(400).send({ status: false, message: "ID, Country Name and Country Code are required!" });
      }


      // Check if already exists (another row with same countryName or countryCode, excluding current id)
      let validateQ = `SELECT * FROM country_master WHERE id != ? AND (countryName = ? OR countryCode = ?) AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [id, countryName.trim(), countryCode.trim()]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Country already exists!" });
      }

      const trimmedName = countryName.trim();
      const trimmedCode = countryCode.trim();
      let query = `UPDATE country_master SET countryName = ?, countryCode = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(query, [trimmedName, trimmedCode, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Country Updated",
          `The country "${trimmedName}" (${trimmedCode}) has been updated in the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Country updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable Country
  toggleCountry: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let getQuery = `SELECT isActive FROM country_master WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Country not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE country_master SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Country ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete Country
  deleteCountry: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Soft delete: set isDeleted to 1
      let query = `UPDATE country_master SET isDeleted = 1 WHERE id = ?`;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Country deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
