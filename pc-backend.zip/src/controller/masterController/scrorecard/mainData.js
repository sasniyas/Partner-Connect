const {connection }= require("../../../mySql/mySql"); // adjust path

module.exports = {
  // 📥 Get All cuntries
  getAllCuntries: async function (req, res) {
    try {
      let query = `SELECT * FROM countries`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
   // 📥 Get All States
  getAllStates: async function (req, res) {
    try {
      let query = `SELECT * FROM indian_states`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

   // 📥 Get All Districts
  getAllDistricts: async function (req, res) {
    try {
      let query = `SELECT * FROM districts`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

   // 📥 Get All Cities
  getAllCities: async function (req, res) {
    try {
      let query = `SELECT * FROM cities`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

 
};

