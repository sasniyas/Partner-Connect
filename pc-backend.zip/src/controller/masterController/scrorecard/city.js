const { connection } = require("../../../mySql/mySql"); // adjust path
const moment = require("moment-timezone");
const { createNotification } = require("../../notification/notification.controller");

// Validation function for bulk add city
const validateCityRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenCombinations = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row, index) => {
    const { state_id, cityName } = row;

    // Check required fields
    if (!state_id || !cityName || cityName.trim() === "") {
      invalidCount++;
      return;
    }

    // Check for duplicates within the batch (combination of cityName and state_id)
    const combinationKey = `${state_id}_${cityName.trim().toLowerCase()}`;
    if (seenCombinations.has(combinationKey)) {
      invalidCount++;
      return;
    }
    seenCombinations.add(combinationKey);

    // Row is valid
    validRows.push({
      state_id,
      cityName: cityName.trim()
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // ➕ Add City
  addCity: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { state_id, cityName } = req.body;

      if (!state_id || !cityName || cityName.trim() === "") {
        return res.status(400).send({ status: false, message: "State and City Name are required!" });
      }

      // Check for duplicate city under same state
      let validateQ = `SELECT * FROM city_master WHERE cityName = ? AND state_id = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [cityName, state_id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "City already exists in this State!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `INSERT INTO city_master (cityName,state_id, createdOn, isActive, isDeleted) VALUES (?, ?, ?, 1, 0)`;
      await connection.query(query, [cityName, state_id, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New City Added",
          `A new city "${cityName}" has been added to the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "City added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add City
  bulkAddCity: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateCityRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database (optimized with single query)
      const existingQuery = `
        SELECT cityName, state_id FROM city_master WHERE isDeleted = 0
      `;
      const existingRecords = await connection.query(existingQuery);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.cityName}|${r.state_id}`)
      );

      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.cityName}|${row.state_id}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all cities
      const insertValues = rowsToInsert.map(row => [
        row.cityName,
        row.state_id,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO city_master (cityName, state_id, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} City(ies) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Cities (with State Name)
  getCities: async function (req, res) {
    try {
      let query = `
        SELECT 
  c.id AS cityId,
  c.cityName,
  c.isActive AS cityActive,
  c.createdOn AS cityCreatedOn,
  s.id AS stateId,
  s.stateName,
  s.isActive AS stateActive,
  s.createdOn AS stateCreatedOn,
  m.id AS marketAreaId,
  m.marketarea AS marketArea
FROM city_master c
JOIN state_master s ON c.state_id = s.id
JOIN market_area m ON s.marketarea_id = m.id
WHERE c.isDeleted = 0
ORDER BY c.id DESC;
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update City
  updateCity: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, cityName, state_id } = req.body;

      if (!id || !cityName || !state_id) {
        return res.status(400).send({ status: false, message: "ID, State and City Name are required!" });
      }

      // Check for duplicate city under same state
      let validateQ = `SELECT * FROM city_master WHERE id != ? AND cityName = ? AND state_id = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [id, cityName, state_id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "City already exists in this State!" });
      }

      let query = `UPDATE city_master SET cityName = ?, state_id = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(query, [cityName, state_id, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "City Updated",
          `The city "${cityName}" has been updated in the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "City updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable City
  toggleCity: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let getQuery = `SELECT isActive FROM city_master WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "City not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE city_master SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `City ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete City
  deleteCity: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Soft delete: set isDeleted to 1
      let query = `UPDATE city_master SET isDeleted = 1 WHERE id = ?`;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "City deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
