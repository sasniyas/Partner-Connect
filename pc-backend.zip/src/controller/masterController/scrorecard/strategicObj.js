const { connection } = require("../../../mySql/mySql"); // adjust path
const moment = require("moment-timezone");
const { createNotification } = require("../../notification/notification.controller");

// Validation function for bulk add strategic objective
const validateStrategicObjectiveRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenObjectiveNames = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row, index) => {
    const { objectiveName } = row;

    // Check required fields
    if (!objectiveName || objectiveName.trim() === "") {
      invalidCount++;
      return;
    }

    const trimmedObjectiveName = objectiveName.trim();

    // Check for duplicates within the batch
    if (seenObjectiveNames.has(trimmedObjectiveName.toLowerCase())) {
      invalidCount++;
      return;
    }
    seenObjectiveNames.add(trimmedObjectiveName.toLowerCase());

    // Row is valid
    validRows.push({
      objectiveName: trimmedObjectiveName
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // ➕ Add Strategic Objective
  addStrategicObjective: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { objectiveName } = req.body;

      if (!objectiveName || objectiveName.trim() === "") {
        return res.status(400).send({ status: false, message: "Strategic Objective is required!" });
      }

      // Check duplicate
      let validateQ = `SELECT * FROM strategic_objective_master WHERE objectiveName = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [objectiveName.trim()]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Strategic Objective already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO strategic_objective_master (objectiveName, createdOn, isActive, isDeleted) 
        VALUES (?, ?, 1, 0)
      `;
      await connection.query(query, [objectiveName.trim(), createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Strategic Objective Added",
          `A new strategic objective "${objectiveName.trim()}" has been added to the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Strategic Objective added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Strategic Objective
  bulkAddStrategicObjective: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateStrategicObjectiveRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing objective names in database
      const existingQuery = `SELECT objectiveName FROM strategic_objective_master WHERE isDeleted = 0`;
      const existingRecords = await connection.query(existingQuery);

      const existingObjectiveNames = new Set(
        existingRecords.map(r => r.objectiveName.toLowerCase())
      );

      // Filter out rows that already exist in DB
      const rowsToInsert = validRows.filter(row =>
        !existingObjectiveNames.has(row.objectiveName.toLowerCase())
      );

      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All Strategic Objectives already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all strategic objectives
      const insertValues = rowsToInsert.map(row => [
        row.objectiveName,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO strategic_objective_master (objectiveName, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Strategic Objective(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      console.log(error);
      return res.status(500).send({ status: false, message: error.message });
    }
  },


  // 📥 Get All Strategic Objectives
  getStrategicObjectives: async function (req, res) {
    try {
      let query = `
        SELECT id, objectiveName, isActive, createdOn
        FROM strategic_objective_master
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Strategic Objective
  updateStrategicObjective: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, objectiveName } = req.body;

      if (!id || !objectiveName || objectiveName.trim() === "") {
        return res.status(400).send({ status: false, message: "ID and Strategic Objective are required!" });
      }


      // Check duplicate
      let validateQ = `SELECT * FROM strategic_objective_master WHERE objectiveName = ? AND id!=? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [objectiveName.trim(), id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Strategic Objective already exists!" });
      }

      let query = `
        UPDATE strategic_objective_master 
        SET objectiveName = ?
        WHERE id = ? AND isDeleted = 0
      `;
      await connection.query(query, [objectiveName.trim(), id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Strategic Objective Updated",
          `The strategic objective "${objectiveName.trim()}" has been updated in the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Strategic Objective updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable Strategic Objective
  toggleStrategicObjective: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let getQuery = `SELECT isActive FROM strategic_objective_master WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Strategic Objective not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE strategic_objective_master SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Strategic Objective ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete Strategic Objective
  deleteStrategicObjective: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Soft delete: set isDeleted to 1
      let query = `UPDATE strategic_objective_master SET isDeleted = 1 WHERE id = ?`;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Strategic Objective deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
