const { connection } = require("../../../mySql/mySql");
const moment = require("moment-timezone");
const { uploadFile } = require("../../azurestorage/fileUpload");
const { createNotification } = require("../../notification/notification.controller");

// Validation function for bulk add sub KPI
const validateSubKpiRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenCombinations = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row, index) => {
    const {
      createdYear,
      strategicObjective,
      kpiId,
      subKpiName,
      kpiNumber,
      assessmentPeriod,
      minScore,
      maxScore,
      scoringCriteria,
      measurement,
      annualScore,
      annualScoringCriteria,
      userRoles,
      userIds,
      docStaus,
      doc,
      criteriaDefinition,
      dataSource
    } = row;

    // Check required fields
    if (!createdYear || !strategicObjective || !kpiId || !subKpiName) {
      invalidCount++;
      return;
    }

    const trimmedSubKpiName = subKpiName.trim();
    if (trimmedSubKpiName === "") {
      invalidCount++;
      return;
    }

    // Check for duplicates within the batch (combination of subKpiName and kpiId)
    const combinationKey = `${kpiId}_${trimmedSubKpiName.toLowerCase()}`;
    if (seenCombinations.has(combinationKey)) {
      invalidCount++;
      return;
    }
    seenCombinations.add(combinationKey);

    // Row is valid
    validRows.push({
      createdYear,
      strategicObjective,
      kpiId,
      subKpiName: trimmedSubKpiName,
      kpiNumber: kpiNumber || "",
      assessmentPeriod: assessmentPeriod || "",
      minScore: minScore || 0,
      maxScore: maxScore || 0,
      scoringCriteria: scoringCriteria || "",
      measurement: measurement || "",
      annualScore: annualScore || 0,
      annualScoringCriteria: annualScoringCriteria || "",
      userRoles: userRoles || [],
      userIds: userIds || [],
      docStaus: docStaus || 0,
      doc: doc || null,
      criteriaDefinition: criteriaDefinition || "",
      dataSource: dataSource || ""
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // ➕ Add Sub KPI
  addSubKPI: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let {
        createdYear,
        strategicObjective,
        kpiNumber,
        kpiId,
        subKpiName,
        assessmentPeriod,
        minScore,
        maxScore,
        scoringCriteria,
        measurement,
        annualScore,
        annualScoringCriteria,
        userRoles,
        userIds,
        docStaus,
        criteriaDefinition,
        dataSource
      } = req.body;

      if (!createdYear || !strategicObjective || !kpiId || !subKpiName) {
        return res.status(400).send({
          status: false,
          message: "CreatedYear, Objective, KPI, SubKPI Name are required!"
        });
      }

      // Handle file upload
      let url = "";
      if (docStaus && req.files && req.files.length > 0) {
        let file = req.files[0];
        url = await uploadFile(file);
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Insert Sub KPI
      let result = await connection.query(
        `INSERT INTO sub_kpi_master
        (createdYear, objectiveId, kpiId, kpiNumber, subKpiName, assessmentPeriod,
         minScore, maxScore, scoringCriteria, measurement, annualScore, annualScoringCriteria,
         docStaus, doc, criteriaDefinition, dataSource, createdOn, updatedOn, isActive, isDeleted)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0)`,
        [
          createdYear,
          strategicObjective,
          kpiId,
          kpiNumber || "",
          subKpiName,
          assessmentPeriod || "",
          minScore || 0,
          maxScore || 0,
          scoringCriteria || "",
          measurement || "",
          annualScore || 0,
          annualScoringCriteria || "",
          docStaus || 0,
          url || null,
          criteriaDefinition || "",
          dataSource || "",
          createdOn,
          createdOn
        ]
      );

      let subKpiId = result.insertId;

      // Insert Roles
      if (userRoles?.length > 0) {
        let roleValues = userRoles.map((rid) => [subKpiId, rid, createdOn]);
        await connection.query(`INSERT INTO subKpiUserRoles (subKpiId, roleId, createdOn) VALUES ?`, [roleValues]);
      }

      // Insert Users
      if (userIds?.length > 0) {
        let userValues = userIds.map((uid) => [subKpiId, uid, createdOn]);
        await connection.query(`INSERT INTO subKpiUsers (subKpiId, userId, createdOn) VALUES ?`, [userValues]);
      }



      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Sub KPI Added",
          `A new Sub KPI "${subKpiName}" has been added to the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Sub KPI added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Sub KPI
  bulkAddSubKpi: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      console.log("=== BULK ADD SUB KPI ===");
      console.log("Received rows count:", rows?.length || 0);

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({
          status: false,
          message: "Rows array is required and must not be empty!"
        });
      }

      // Validate rows
      const { data: validRows, error: invalidCount } = validateSubKpiRows(rows);

      console.log("Valid rows:", validRows.length, "Invalid:", invalidCount);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check if all strategic objectives exist
      const objectiveIds = [...new Set(validRows.map(row => row.strategicObjective))].filter(id => id != null);

      let existingObjectiveIds = new Set();
      if (objectiveIds.length > 0) {
        const placeholders = objectiveIds.map(() => '?').join(',');
        const objectiveCheckQuery = `SELECT id FROM strategic_objective_master WHERE id IN (${placeholders}) AND isDeleted = 0`;
        const existingObjectives = await connection.query(objectiveCheckQuery, objectiveIds);
        existingObjectiveIds = new Set(existingObjectives.map(o => o.id));
      }

      // Check if all KPIs exist
      const kpiIds = [...new Set(validRows.map(row => row.kpiId))].filter(id => id != null);

      let existingKpiIds = new Set();
      if (kpiIds.length > 0) {
        const placeholders = kpiIds.map(() => '?').join(',');
        const kpiCheckQuery = `SELECT id FROM kpi_master WHERE id IN (${placeholders}) AND isDeleted = 0`;
        const existingKPIs = await connection.query(kpiCheckQuery, kpiIds);
        existingKpiIds = new Set(existingKPIs.map(k => k.id));
      }

      // Filter out rows with invalid objectives or KPIs
      const rowsWithValidReferences = validRows.filter(row =>
        existingObjectiveIds.has(row.strategicObjective) && existingKpiIds.has(row.kpiId)
      );
      const invalidReferenceCount = validRows.length - rowsWithValidReferences.length;
      const totalInvalidSoFar = invalidCount + invalidReferenceCount;

      console.log("Rows with valid references:", rowsWithValidReferences.length);

      if (rowsWithValidReferences.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows have invalid objectives or KPIs. ${totalInvalidSoFar} invalid entry/entries found.`
        });
      }

      // Check for existing subKPIs in database (kpiId + subKpiName combination)
      const existingQuery = `SELECT kpiId, subKpiName FROM sub_kpi_master WHERE isDeleted = 0`;
      const existingRecords = await connection.query(existingQuery);
      const existingCombinationsSet = new Set(
        existingRecords
          .filter(r => r.subKpiName != null)
          .map(r => `${r.kpiId}|${String(r.subKpiName).toLowerCase()}`)
      );

      const rowsToInsert = rowsWithValidReferences.filter(row =>
        !existingCombinationsSet.has(`${row.kpiId}|${row.subKpiName.toLowerCase()}`)
      );
      const duplicateCount = rowsWithValidReferences.length - rowsToInsert.length;
      const totalInvalidCount = totalInvalidSoFar + duplicateCount;

      console.log("Rows to insert:", rowsToInsert.length, "Duplicates skipped:", duplicateCount);

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All Sub KPIs already exist in database. ${totalInvalidCount} duplicate/invalid entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Insert one by one to get individual IDs for role/user mapping
      let insertedCount = 0;

      for (const row of rowsToInsert) {
        try {
          console.log("Inserting row:", {
            subKpiName: row.subKpiName,
            strategicObjective: row.strategicObjective,
            kpiId: row.kpiId,
            createdYear: row.createdYear
          });

          // Insert the sub KPI
          const insertQuery = `
            INSERT INTO sub_kpi_master
            (createdYear, objectiveId, kpiId, kpiNumber, subKpiName, assessmentPeriod,
             minScore, maxScore, scoringCriteria, measurement, annualScore, annualScoringCriteria,
             docStaus, doc, criteriaDefinition, dataSource, createdOn, updatedOn, isActive, isDeleted)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0)
          `;

          const result = await connection.query(insertQuery, [
            row.createdYear,
            row.strategicObjective,
            row.kpiId,
            row.kpiNumber || "",
            row.subKpiName,
            row.assessmentPeriod || "",
            row.minScore || 0,
            row.maxScore || 0,
            row.scoringCriteria || "",
            row.measurement || "",
            row.annualScore || 0,
            row.annualScoringCriteria || "",
            row.docStaus || 0,
            row.doc || null,
            row.criteriaDefinition || "",
            row.dataSource || "",
            createdOn,
            createdOn // updatedOn - same as createdOn for new records
          ]);

          const subKpiId = result.insertId;
          console.log("Inserted with ID:", subKpiId);

          // Insert Roles if any
          if (row.userRoles && Array.isArray(row.userRoles) && row.userRoles.length > 0) {
            const roleValues = row.userRoles
              .filter(rid => rid != null)
              .map((rid) => [subKpiId, rid, createdOn]);
            if (roleValues.length > 0) {
              await connection.query(`INSERT INTO subKpiUserRoles (subKpiId, roleId, createdOn) VALUES ?`, [roleValues]);
            }
          }

          // Insert Users if any
          if (row.userIds && Array.isArray(row.userIds) && row.userIds.length > 0) {
            const userValues = row.userIds
              .filter(uid => uid != null)
              .map((uid) => [subKpiId, uid, createdOn]);
            if (userValues.length > 0) {
              await connection.query(`INSERT INTO subKpiUsers (subKpiId, userId, createdOn) VALUES ?`, [userValues]);
            }
          }

          insertedCount++;
        } catch (insertError) {
          console.log("Error inserting row:", row.subKpiName, insertError.message);
          // Continue with next row
        }
      }

      let message = `${insertedCount} Sub KPI(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      console.log("Final result:", message);

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: insertedCount,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      console.log("bulkAddSubKpi error:", error);
      return res.status(500).send({ status: false, message: error.message });
    }
  },


  // 📌 Get All Sub KPIs
  getAllSubKPIs: async function (req, res) {
    try {
      const rows = await connection.query(`
        SELECT sk.*, so.objectiveName, k.kpiName
        FROM sub_kpi_master sk
        LEFT JOIN strategic_objective_master so ON sk.objectiveId = so.id
        LEFT JOIN kpi_master k ON sk.kpiId = k.id
        WHERE sk.isDeleted = 0
        ORDER BY sk.createdOn DESC
      `);

      for (let sub of rows) {
        const roles = await connection.query(
          `SELECT r.* FROM subKpiUserRoles sur 
           JOIN role_master r ON sur.roleId = r.id 
           WHERE sur.subKpiId=?`,
          [sub.id]
        );

        const users = await connection.query(
          `SELECT u.* FROM subKpiUsers su 
           JOIN userdetails u ON su.userId = u.id 
           WHERE su.subKpiId=?`,
          [sub.id]
        );



        sub.userRoles = roles;
        sub.users = users;
      }

      return res.status(200).send({ status: true, data: rows });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📌 Get SubKPI by ID
  getSubKPIById: async function (req, res) {
    try {
      const { id } = req.params;

      const rows = await connection.query(`
        SELECT sk.*, so.objectiveName, k.kpiName
        FROM sub_kpi_master sk
        LEFT JOIN strategic_objective_master so ON sk.objectiveId = so.id
        LEFT JOIN kpi_master k ON sk.kpiId = k.id
        WHERE sk.id=? AND sk.isDeleted = 0`,
        [id]
      );

      if (rows.length === 0) {
        return res.status(404).send({ status: false, message: "Sub KPI not found" });
      }

      const sub = rows[0];
      const roles = await connection.query(
        `SELECT r.* FROM subKpiUserRoles sur 
         JOIN role_master r ON sur.roleId = r.id 
         WHERE sur.subKpiId=?`,
        [sub.id]
      );

      const users = await connection.query(
        `SELECT u.* FROM subKpiUsers su 
         JOIN userdetails u ON su.userId = u.id 
         WHERE su.subKpiId=?`,
        [sub.id]
      );



      sub.userRoles = roles;
      sub.users = users;

      return res.status(200).send({ status: true, data: sub });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📌 Update Sub KPI
  updateSubKPI: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }


      let {
        id,
        createdYear,
        strategicObjective,
        kpiNumber,
        kpiId,
        subKpiName,
        assessmentPeriod,
        minScore,
        maxScore,
        scoringCriteria,
        measurement,
        annualScore,
        annualScoringCriteria,
        userRoles,
        userIds,
        docStaus,
        criteriaDefinition,
        dataSource
      } = req.body;

      let url = "";
      if (docStaus && req.files && req.files.length > 0) {
        let file = req.files[0];
        url = await uploadFile(file);
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      await connection.query(
        `UPDATE sub_kpi_master SET 
          createdYear=?, objectiveId=?, kpiId=?, kpiNumber=?, subKpiName=?, 
          assessmentPeriod=?, minScore=?, maxScore=?, scoringCriteria=?, 
          measurement=?, annualScore=?, annualScoringCriteria=?, 
          docStaus=?, doc=?, criteriaDefinition=?, dataSource=?, updatedOn=? 
        WHERE id=? AND isDeleted = 0`,
        [
          createdYear, strategicObjective, kpiId, kpiNumber || "", subKpiName,
          assessmentPeriod || "", minScore || 0, maxScore || 0, scoringCriteria || "",
          measurement || "", annualScore || 0, annualScoringCriteria || "",
          docStaus || 0, url || null, criteriaDefinition || "",
          dataSource || "", updatedOn, id
        ]
      );

      await connection.query(`DELETE FROM subKpiUserRoles WHERE subKpiId=?`, [id]);
      if (userRoles?.length > 0) {
        let roleValues = userRoles.map((rid) => [id, rid, updatedOn]);
        await connection.query(`INSERT INTO subKpiUserRoles (subKpiId, roleId, createdOn) VALUES ?`, [roleValues]);
      }

      await connection.query(`DELETE FROM subKpiUsers WHERE subKpiId=?`, [id]);
      if (userIds?.length > 0) {
        let userValues = userIds.map((uid) => [id, uid, updatedOn]);
        await connection.query(`INSERT INTO subKpiUsers (subKpiId, userId, createdOn) VALUES ?`, [userValues]);
      }


      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Sub KPI Updated",
          `The Sub KPI "${subKpiName}" has been updated in the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Sub KPI updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📌 Toggle Active/Inactive
  toggleSubKPI: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { id } = req.params;
      const rows = await connection.query(`SELECT isActive FROM sub_kpi_master WHERE id=? AND isDeleted = 0`, [id]);

      if (rows.length === 0) {
        return res.status(404).send({ status: false, message: "Sub KPI not found" });
      }

      const newStatus = rows[0].isActive === 1 ? 0 : 1;
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE sub_kpi_master SET isActive=?, updatedOn=? WHERE id=? AND isDeleted = 0`, [newStatus, updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: `Sub KPI ${newStatus === 1 ? "activated" : "deactivated"} successfully!`
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📌 Delete Sub KPI
  deleteSubKPI: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;
      // Soft delete: set isDeleted to 1
      const result = await connection.query(`UPDATE sub_kpi_master SET isDeleted = 1 WHERE id=?`, [id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Sub KPI not found" });
      }

      return res.status(200).send({ status: true, message: "Sub KPI deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 📌 Update Formula
  updateFormula: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { id, formula } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      const result = await connection.query(
        `UPDATE sub_kpi_master SET formula=?, updatedOn=? WHERE id=? AND isDeleted = 0`,
        [formula, updatedOn, id]
      );

      if (result.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Sub KPI not found" });
      }

      return res.status(200).send({ status: true, message: "Formula updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
