const { connection } = require("../../../mySql/mySql"); // adjust path
const moment = require("moment-timezone");
const { validateKpiName, validateKpiRows } = require("../../../utils/validation/scorecardValidation/kpi.validation");
const { createNotification } = require("../../notification/notification.controller");

module.exports = {
  // ➕ Add KPI
  addKPI: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { objectiveId, kpiName, maxScore } = req.body;

      if (!objectiveId || !maxScore || !validateKpiName(kpiName)) {
        return res.status(400).send({ status: false, message: "Objective ID, KPI Name and Max Score are required! KPI Name must be less than 50 characters." });
      }

      const trimmedKpiName = kpiName.trim();

      // Check if Objective exists
      let checkObj = await connection.query(`SELECT id FROM strategic_objective_master WHERE id = ? AND isDeleted = 0`, [objectiveId]);
      if (checkObj.length === 0) {
        return res.status(404).send({ status: false, message: "Strategic Objective not found!" });
      }

      // Check duplicate KPI under same Objective
      let validateQ = `SELECT * FROM kpi_master WHERE objectiveId = ? AND kpiName = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [objectiveId, trimmedKpiName]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "KPI already exists under this Objective!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO kpi_master (kpiName, objectiveId, maxScore, createdOn, isActive, isDeleted) 
        VALUES (?, ?, ?, ?, 1, 0)
      `;
      await connection.query(query, [trimmedKpiName, objectiveId, maxScore, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New KPI Added",
          `A new KPI "${trimmedKpiName}" has been added to the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "KPI added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add KPI
  bulkAddKpi: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateKpiRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid.${invalidCount} invalid entry / entries found.`
        });
      }

      // Check if all objectives exist in database
      const objectiveIds = [...new Set(validRows.map(row => row.objectiveId))];
      const objectiveCheckQuery = `
        SELECT id FROM strategic_objective_master 
        WHERE id IN(${objectiveIds.map(() => '?').join(',')}) AND isDeleted = 0
        `;
      const existingObjectives = await connection.query(objectiveCheckQuery, objectiveIds);
      const existingObjectiveIds = new Set(existingObjectives.map(o => o.id));

      // Filter out rows with invalid objectives
      const rowsWithValidObjectives = validRows.filter(row => existingObjectiveIds.has(row.objectiveId));
      const invalidObjectiveCount = validRows.length - rowsWithValidObjectives.length;
      const totalInvalidSoFar = invalidCount + invalidObjectiveCount;

      if (rowsWithValidObjectives.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All valid rows have invalid objectives.${totalInvalidSoFar} invalid entry / entries found.`
        });
      }

      // Check for existing KPIs in database (combination of objectiveId + kpiName)
      const existingQuery = `SELECT objectiveId, kpiName FROM kpi_master WHERE isDeleted = 0`;
      const existingRecords = await connection.query(existingQuery);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.objectiveId}| ${r.kpiName.toLowerCase()} `)
      );

      const rowsToInsert = rowsWithValidObjectives.filter(row =>
        !existingCombinationsSet.has(`${row.objectiveId}| ${row.kpiName.toLowerCase()} `)
      );
      const duplicateCount = rowsWithValidObjectives.length - rowsToInsert.length;
      const totalInvalidCount = totalInvalidSoFar + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All KPIs already exist in database.${totalInvalidCount} invalid / duplicate entry / entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all KPIs
      const insertValues = rowsToInsert.map(row => [
        row.kpiName,
        row.objectiveId,
        row.maxScore,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO kpi_master(kpiName, objectiveId, maxScore, createdOn, isActive, isDeleted)
      VALUES ?
        `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} KPI(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid / duplicate entry / entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      console.log(error);
      return res.status(500).send({ status: false, message: error.message });
    }
  },


  // 📥 Get All KPIs
  getKPIs: async function (req, res) {
    try {
      let query = `
        SELECT k.id, k.kpiName, k.maxScore, k.isActive, k.createdOn,
        s.objectiveName AS strategicObjective
        FROM kpi_master k
        JOIN strategic_objective_master s ON k.objectiveId = s.id
        WHERE k.isDeleted = 0 AND s.isDeleted = 0
        ORDER BY k.id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update KPI
  updateKPI: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, objectiveId, kpiName, maxScore } = req.body;

      if (!id || !objectiveId || !maxScore || !validateKpiName(kpiName)) {
        return res.status(400).send({ status: false, message: "ID, Objective ID, KPI Name and Max Score are required! KPI Name must be less than 50 characters." });
      }

      const trimmedKpiName = kpiName.trim();

      // Check if Objective exists
      let checkObj = await connection.query(`SELECT id FROM strategic_objective_master WHERE id = ? AND isDeleted = 0`, [objectiveId]);
      if (checkObj.length === 0) {
        return res.status(404).send({ status: false, message: "Strategic Objective not found!" });
      }

      // Check duplicate KPI under same Objective
      let validateQ = `SELECT * FROM kpi_master WHERE objectiveId = ? AND kpiName = ? AND id != ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [objectiveId, trimmedKpiName, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "KPI already exists under this Objective!" });
      }

      let query = `
        UPDATE kpi_master 
        SET objectiveId = ?, kpiName = ?, maxScore = ?
        WHERE id = ? AND isDeleted = 0
          `;
      await connection.query(query, [objectiveId, trimmedKpiName, maxScore, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "KPI Updated",
          `The KPI "${trimmedKpiName}" has been updated in the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "KPI updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable KPI
  toggleKPI: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let getQuery = `SELECT isActive FROM kpi_master WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "KPI not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE kpi_master SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `KPI ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete KPI
  deleteKPI: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Soft delete: set isDeleted to 1
      let query = `UPDATE kpi_master SET isDeleted = 1 WHERE id = ? `;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "KPI deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
