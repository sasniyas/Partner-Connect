const { connection } = require("../../../mySql/mySql"); // adjust path
const moment = require("moment-timezone");
const { validateDealerName, validateDealerShortName, validateDealerRows } = require("../../../utils/validation/scorecardValidation/dealerMaster.validation");
const { createNotification } = require("../../notification/notification.controller");

module.exports = {
  // ➕ Add Dealer
  addDealer: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { market_id, state_id, dealerName, dealerShortName } = req.body;

      if (!market_id || !state_id || !validateDealerName(dealerName)) {
        return res
          .status(400)
          .send({ status: false, message: "Market, State and Dealer Name are required! Dealer Name must be less than 100 characters." });
      }

      if (dealerShortName && !validateDealerShortName(dealerShortName)) {
        return res
          .status(400)
          .send({ status: false, message: "Dealer Short Name must be less than 50 characters." });
      }

      const trimmedDealerName = dealerName.trim();
      const trimmedDealerShortName = dealerShortName ? dealerShortName.trim() : null;

      // Check for duplicate dealer under same market + state
      let validateQ = `SELECT * FROM dealer_master WHERE dealerName = ? AND market_id = ? AND state_id = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [trimmedDealerName, market_id, state_id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Dealer already exists in this Market & State!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO dealer_master (market_id, state_id, dealerName, dealerShortName, createdOn, isActive, isDeleted) 
        VALUES (?, ?, ?, ?, ?, 1, 0)
      `;
      await connection.query(query, [market_id, state_id, trimmedDealerName, trimmedDealerShortName, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Dealer Added",
          `A new dealer "${trimmedDealerName}" has been added to the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Dealer added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Dealer
  bulkAddDealer: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateDealerRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database (dealerName + market_id + state_id)
      const existingQuery = `SELECT dealerName, market_id, state_id FROM dealer_master WHERE isDeleted = 0`;
      const existingRecords = await connection.query(existingQuery);

      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.dealerName.toLowerCase()}|${r.market_id}|${r.state_id}`)
      );

      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.dealerName.toLowerCase()}|${row.market_id}|${row.state_id}`)
      );

      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All dealers already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all dealers
      const insertValues = rowsToInsert.map(row => [
        row.market_id,
        row.state_id,
        row.dealerName,
        row.dealerShortName,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO dealer_master (market_id, state_id, dealerName, dealerShortName, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Dealer(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      console.log(error);
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Dealers (with Market & State Name)
  getDealers: async function (req, res) {
    try {
      let query = `
        SELECT d.id, d.dealerName, d.dealerShortName, d.isActive, d.createdOn, 
               m.marketarea AS marketName, s.stateName AS stateName,
               d.market_id, d.state_id
        FROM dealer_master d
        JOIN market_area m ON d.market_id = m.id
        JOIN state_master s ON d.state_id = s.id
        WHERE d.isDeleted = 0
        ORDER BY d.id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Dealer
  updateDealer: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, dealerName, dealerShortName, market_id, state_id } = req.body;

      if (!id || !market_id || !state_id || !validateDealerName(dealerName)) {
        return res
          .status(400)
          .send({ status: false, message: "ID, Market, State and Dealer Name are required! Dealer Name must be less than 100 characters." });
      }

      if (dealerShortName && !validateDealerShortName(dealerShortName)) {
        return res
          .status(400)
          .send({ status: false, message: "Dealer Short Name must be less than 50 characters." });
      }

      const trimmedDealerName = dealerName.trim();
      const trimmedDealerShortName = dealerShortName ? dealerShortName.trim() : null;

      // Check for duplicate dealer under same market + state
      let validateQ = `SELECT * FROM dealer_master WHERE id!=? AND dealerName = ? AND market_id = ? AND state_id = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [id, trimmedDealerName, market_id, state_id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Dealer already exists in this Market & State!" });
      }


      let query = `
        UPDATE dealer_master 
        SET dealerName = ?, dealerShortName = ?, market_id = ?, state_id = ? 
        WHERE id = ? AND isDeleted = 0
      `;
      await connection.query(query, [trimmedDealerName, trimmedDealerShortName, market_id, state_id, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Dealer Updated",
          `The dealer "${trimmedDealerName}" has been updated in the master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Dealer updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable Dealer
  toggleDealer: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let getQuery = `SELECT isActive FROM dealer_master WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Dealer not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE dealer_master SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Dealer ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete Dealer
  deleteDealer: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Soft delete: set isDeleted to 1
      let query = `UPDATE dealer_master SET isDeleted = 1 WHERE id = ?`;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Dealer deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
