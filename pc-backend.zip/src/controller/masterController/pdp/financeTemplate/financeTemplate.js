const { connection } = require("../../../../mySql/mySql"); // adjust path
const moment = require('moment-timezone');
const { uploadFile } = require("../../../azurestorage/fileUpload");
const { createNotification } = require("../../../notification/notification.controller");

// Validation function for bulk add finance template
const validateFinanceTemplateRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenCombinations = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row) => {
    const { year, financeTemplate } = row;

    // Check required fields
    if (!year || !financeTemplate) {
      invalidCount++;
      return;
    }

    const trimmedFinanceTemplate = financeTemplate.trim();
    if (trimmedFinanceTemplate === "") {
      invalidCount++;
      return;
    }

    // Check for duplicates within the batch (combination of year and financeTemplate)
    const combinationKey = `${year}_${trimmedFinanceTemplate.toLowerCase()}`;
    if (seenCombinations.has(combinationKey)) {
      invalidCount++;
      return;
    }
    seenCombinations.add(combinationKey);

    // Row is valid
    validRows.push({
      year,
      financeTemplate: trimmedFinanceTemplate
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // 📝 Update Default Finance Template
  updateDefaultFinTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { sampleFileUrl } = req.body;

      if (req.files.length) {
        let file = req.files[0]
        sampleFileUrl = await uploadFile(file);
      }



      let query = `UPDATE tempFiles SET  url = ? WHERE id =2`;
      await connection.query(query, [sampleFileUrl]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Default Finance Template Updated",
          "The default finance template has been updated.",
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Default Template updated successfully!", data: sampleFileUrl });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Default Finance Template
  getDefaultFinTemplate: async function (req, res) {
    try {
      let query = `select * from tempFiles WHERE id =2`;
      let data = await connection.query(query);
      data = data[0]
      return res.status(200).send({ status: true, message: "Default Template!", data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Finance Template
  bulkAddFinanceTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateFinanceTemplateRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing finance templates in database (optimized with single query)
      const existingQuery = `
        SELECT year, finance_template FROM finance_templates
      `;
      const existingRecords = await connection.query(existingQuery);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.year}|${r.finance_template}`)
      );

      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.year}|${row.financeTemplate}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all finance templates
      // Note: sample_file (url) defaults to null for bulk operations (no file upload)
      const insertValues = rowsToInsert.map(row => [
        row.year,
        row.financeTemplate,
        null, // sample_file (url) defaults to null for bulk add (no file upload)
        createdOn,
        1 // isActive
      ]);

      const query = `
        INSERT INTO finance_templates
        (year, finance_template, sample_file, createdOn, isActive)
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Finance Template(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  addFinanceTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { year, financeTemplate } = req.body;

      if (!req.files.length) {
        return res.status(400).send({ status: false, message: " file is required!" });
      }

      if (!year || !financeTemplate) {
        return res.status(400).send({ status: false, message: "Req Data is required!" });
      }

      let file = req.files[0]

      const blobUrl = await uploadFile(file);
      console.log("blobUrl", blobUrl);


      let validateQ = `SELECT * FROM finance_templates WHERE year = ? AND finance_template=?`;
      let validateData = await connection.query(validateQ, [year, financeTemplate]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Finance Template already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `INSERT INTO finance_templates (year,finance_template,sample_file, createdOn, isActive) VALUES (?, ?, ?, ?, 1)`;
      const insertResult = await connection.query(query, [year, financeTemplate, blobUrl, createdOn]);
      console.log("insertResult", insertResult);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Finance Template Added",
          `A new Finance Template "${financeTemplate}" for year ${year} has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Finance Template added successfully!", data: insertResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Market Areas
  getAllFinanceTemplates: async function (req, res) {
    try {
      let query = `SELECT id, year, finance_template, sample_file, isActive, createdOn FROM finance_templates ORDER BY id DESC`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Finance Template
  updateFinanceTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { year, financeTemplate, id, sampleFileUrl } = req.body;

      if (!id || !year || !financeTemplate || !sampleFileUrl) {
        return res.status(400).send({ status: false, message: "ID, Year, Finance Template and Sample File URL are required!" });
      }

      if (req.files.length) {
        let file = req.files[0]
        sampleFileUrl = await uploadFile(file);
      }

      // Check for duplicate finance template under same year
      let validateQ = `SELECT * FROM finance_templates WHERE year = ? AND finance_template = ? AND id != ?`;
      let validateData = await connection.query(validateQ, [year, financeTemplate, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Finance Template already exists for this year!" });
      }

      let query = `UPDATE finance_templates SET year = ?, finance_template = ?, sample_file = ? WHERE id = ?`;
      let updateResult = await connection.query(query, [year, financeTemplate, sampleFileUrl, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Finance Template Updated",
          `The Finance Template "${financeTemplate}" for year ${year} has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Finance Template updated successfully!", data: [sampleFileUrl, updateResult] });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable Finance Template
  toggleFinanceTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM finance_templates WHERE id = ?`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Finance Template not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE finance_templates SET isActive = ? WHERE id = ?`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Finance Template ${newStatus === 1 ? "enabled" : "disabled"} successfully!`
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete Finance Template
  deleteFinanceTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `DELETE FROM finance_templates WHERE id = ?`;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Finance Template deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

