const { connection } = require("../../../../mySql/mySql"); // adjust path
const moment = require('moment-timezone');
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Finance Template Category
  addFinanceTemplateCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { category_name, page_number, finance_template_id } = req.body;

      if (!category_name || !page_number || !finance_template_id) {
        return res.status(400).send({ status: false, message: "Category name, page number, and finance template ID are required!" });
      }

      // Validate that the finance template exists
      let validateTemplateQ = `SELECT id FROM finance_templates WHERE id = ? AND isActive = 1`;
      let templateData = await connection.query(validateTemplateQ, [finance_template_id]);

      if (templateData.length === 0) {
        return res.status(400).send({ status: false, message: "Invalid finance template ID or template is not active!" });
      }

      // Check for duplicate category name under same finance template
      let validateQ = `SELECT * FROM finance_template_category WHERE category_name = ? AND finance_template_id = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [category_name, finance_template_id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Category already exists for this finance template!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `INSERT INTO finance_template_category (category_name, page_number, finance_template_id, createdOn, isDeleted) VALUES (?, ?, ?, ?, 0)`;
      const insertResult = await connection.query(query, [category_name, page_number, finance_template_id, createdOn]);
      console.log("insertResult", insertResult);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Finance Template Category Added",
          `A new Finance Template Category "${category_name}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Finance Template Category added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllFinanceTemplateCategories: async function (req, res) {
    try {
      let query = `SELECT 
        ptc.id, 
        ptc.category_name, 
        ptc.page_number, 
        ptc.finance_template_id,
        pt.finance_template,
        pt.year,
        ptc.createdOn 
      FROM finance_template_category ptc
      LEFT JOIN finance_templates pt ON ptc.finance_template_id = pt.id
      WHERE ptc.isDeleted = 0
      ORDER BY ptc.id DESC`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getCategoriesByFinanceTemplateId: async function (req, res) {
    try {
      let { finance_template_id } = req.params;

      if (!finance_template_id) {
        return res.status(400).send({ status: false, message: "Finance template ID is required!" });
      }

      let query = `SELECT 
        ptc.id, 
        ptc.category_name, 
        ptc.page_number, 
        ptc.finance_template_id,
        pt.finance_template,
        pt.year,
        ptc.createdOn 
      FROM finance_template_category ptc
      LEFT JOIN finance_templates pt ON ptc.finance_template_id = pt.id
      WHERE ptc.finance_template_id = ? AND ptc.isDeleted = 0
      ORDER BY ptc.page_number ASC`;
      let data = await connection.query(query, [finance_template_id]);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateFinanceTemplateCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, category_name, page_number, finance_template_id } = req.body;

      if (!id || !category_name || !page_number || !finance_template_id) {
        return res.status(400).send({ status: false, message: "ID, category name, page number, and finance template ID are required!" });
      }

      let validateTemplateQ = `SELECT id FROM finance_templates WHERE id = ? AND isActive = 1`;
      let templateData = await connection.query(validateTemplateQ, [finance_template_id]);

      if (templateData.length === 0) {
        return res.status(400).send({ status: false, message: "Invalid finance template ID or template is not active!" });
      }

      let validateQ = `SELECT * FROM finance_template_category WHERE category_name = ? AND finance_template_id = ? AND id != ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [category_name, finance_template_id, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Category already exists for this finance template!" });
      }

      let query = `UPDATE finance_template_category SET category_name = ?, page_number = ?, finance_template_id = ? WHERE id = ? AND isDeleted = 0`;
      const updateResult = await connection.query(query, [category_name, page_number, finance_template_id, id]);

      if (updateResult.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Finance Template Category not found!" });
      }

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Finance Template Category Updated",
          `The Finance Template Category "${category_name}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Finance Template Category updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteFinanceTemplateCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Check if category exists
      let checkQuery = `SELECT id FROM finance_template_category WHERE id = ? AND isDeleted = 0`;
      let categoryData = await connection.query(checkQuery, [id]);

      if (categoryData.length === 0) {
        return res.status(404).send({ status: false, message: "Finance Template Category not found!" });
      }

      // Soft delete
      let query = `UPDATE finance_template_category SET isDeleted = 1 WHERE id = ?`;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Finance Template Category deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  //   // 🔄 Restore Deleted Finance Template Category
  //   restoreFinanceTemplateCategory: async function (req, res) {
  //     try {
  //       let { id } = req.params;

  //       if (!id) {
  //         return res.status(400).send({ status: false, message: "ID is required!" });
  //       }

  //       // Check if category exists and is deleted
  //       let checkQuery = `SELECT id FROM finance_template_category WHERE id = ? AND isDeleted = 1`;
  //       let categoryData = await connection.query(checkQuery, [id]);

  //       if (categoryData.length === 0) {
  //         return res.status(404).send({ status: false, message: "Deleted Finance Template Category not found!" });
  //       }

  //       // Restore
  //       let query = `UPDATE finance_template_category SET isDeleted = 0 WHERE id = ?`;
  //       await connection.query(query, [id]);

  //       return res.status(200).send({ status: true, message: "Finance Template Category restored successfully!" });
  //     } catch (error) {
  //       return res.status(500).send({ status: false, message: error.message });
  //     }
  //   }
};
