const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');
const { validateEquipmentField, validateEquipmentRows } = require("../../../../utils/validation/pdpMasterValidation/equipment.validation");
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Equipment
  addEquipment: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { year, equipment_type, equipment_make, equipment_line, equipment_model } = req.body;
      if (!year || !equipment_type || !equipment_make || !equipment_line || !equipment_model) {
        return res.status(400).send({ status: false, message: "All fields (year, equipment_type, equipment_make, equipment_line, equipment_model) are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateEquipmentField(equipment_type) ||
        !validateEquipmentField(equipment_make) ||
        !validateEquipmentField(equipment_line) ||
        !validateEquipmentField(equipment_model)
      ) {
        return res.status(400).send({ status: false, message: "Equipment details (type, make, line, model) must be valid and less than 100 characters!" });
      }

      // Check for duplicate equipment (same year, type, make, line, model, and not deleted)
      let validateQ = `
        SELECT * FROM equipments 
        WHERE year = ? AND equipment_type = ? AND equipment_make = ? AND equipment_line = ? AND equipment_model = ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [year, equipment_type, equipment_make, equipment_line, equipment_model]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Equipment already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO equipments 
        (year, equipment_type, equipment_make, equipment_line, equipment_model, createdOn, isActive, isDeleted) 
        VALUES (?, ?, ?, ?, ?, ?, 1, 0)
      `;
      const insertResult = await connection.query(query, [year, equipment_type, equipment_make, equipment_line, equipment_model, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Equipment Added",
          `A new Equipment "${equipment_model}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Equipment added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Equipment
  bulkAddEquipment: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateEquipmentRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing equipment in database using multi-column IN
      const checkValues = validRows.map(row => [row.year, row.equipment_type, row.equipment_make, row.equipment_line, row.equipment_model]);
      const existingQuery = `
        SELECT year, equipment_type, equipment_make, equipment_line, equipment_model FROM equipments 
        WHERE (year, equipment_type, equipment_make, equipment_line, equipment_model) IN (?) AND isDeleted = 0
      `;
      const existingEquipments = await connection.query(existingQuery, [checkValues]);

      const existingSet = new Set(existingEquipments.map(e =>
        `${e.year}_${e.equipment_type.toLowerCase()}_${e.equipment_make.toLowerCase()}_${e.equipment_line.toLowerCase()}_${e.equipment_model.toLowerCase()}`
      ));

      // Filter out rows that already exist in DB
      const rowsToInsert = validRows.filter(row => {
        const key = `${row.year}_${row.equipment_type.toLowerCase()}_${row.equipment_make.toLowerCase()}_${row.equipment_line.toLowerCase()}_${row.equipment_model.toLowerCase()}`;
        return !existingSet.has(key);
      });
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all equipments
      const insertValues = rowsToInsert.map(row => [
        row.year,
        row.equipment_type,
        row.equipment_make,
        row.equipment_line,
        row.equipment_model,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO equipments 
        (year, equipment_type, equipment_make, equipment_line, equipment_model, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Equipment(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllEquipments: async function (req, res) {
    try {
      let query = `
        SELECT id, year, equipment_type, equipment_make, equipment_line, equipment_model, createdOn, isActive 
        FROM equipments 
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateEquipment: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, year, equipment_type, equipment_make, equipment_line, equipment_model, isActive } = req.body;

      if (!id || !year || !equipment_type || !equipment_make || !equipment_line || !equipment_model) {
        return res.status(400).send({ status: false, message: "ID, year, equipment_type, equipment_make, equipment_line, and equipment_model are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateEquipmentField(equipment_type) ||
        !validateEquipmentField(equipment_make) ||
        !validateEquipmentField(equipment_line) ||
        !validateEquipmentField(equipment_model)
      ) {
        return res.status(400).send({ status: false, message: "Equipment details (type, make, line, model) must be valid and less than 100 characters!" });
      }

      // Check for duplicate equipment (excluding current id)
      let validateQ = `
        SELECT * FROM equipments 
        WHERE year = ? AND equipment_type = ? AND equipment_make = ? AND equipment_line = ? AND equipment_model = ? AND id != ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [year, equipment_type, equipment_make, equipment_line, equipment_model, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Equipment already exists with these details!" });
      }

      let query = `
        UPDATE equipments 
        SET year = ?, equipment_type = ?, equipment_make = ?, equipment_line = ?, equipment_model = ?
        WHERE id = ? AND isDeleted = 0
      `;
      let updatedResult = await connection.query(query, [year, equipment_type, equipment_make, equipment_line, equipment_model, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Equipment Updated",
          `The Equipment "${equipment_model}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Equipment updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleEquipment: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM equipments WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Equipment not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE equipments SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      let updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Equipment ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteEquipment: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE equipments SET isDeleted = 1 WHERE id = ?`;
      let updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Equipment deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
