const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');
const { validateMarcomField, validateMarcomRows } = require("../../../../utils/validation/pdpMasterValidation/marcom.validation");
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Marcom
  addMarcom: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { marcom_type, marcom_name, year } = req.body;
      if (!marcom_type || !marcom_name) {
        return res.status(400).send({ status: false, message: "All fields (marcom_type, marcom_name) are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateMarcomField(marcom_type) ||
        !validateMarcomField(marcom_name)
      ) {
        return res.status(400).send({ status: false, message: "Marcom details (type, name) must be valid and less than 255 characters!" });
      }

      // Check for duplicate marcom (same marcom_name AND marcom_type and not deleted)
      let validateQ = `
        SELECT * FROM marcom 
        WHERE marcom_name = ? AND marcom_type = ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [marcom_name, marcom_type]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Marcom already exists with this name and type!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO marcom 
        (marcom_type, marcom_name, year, createdOn, isActive, isDeleted) 
        VALUES (?, ?, ?, ?, 1, 0)
      `;
      const insertResult = await connection.query(query, [marcom_type, marcom_name, year || null, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Marcom Added",
          `A new Marcom "${marcom_name}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Marcom added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Marcom
  bulkAddMarcom: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateMarcomRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database using multi-column IN
      const checkValues = validRows.map(row => [row.marcom_type, row.marcom_name]);
      const existingQuery = `
        SELECT marcom_type, marcom_name FROM marcom 
        WHERE (marcom_type, marcom_name) IN (?) AND isDeleted = 0
      `;
      const existingMarcoms = await connection.query(existingQuery, [checkValues]);
      const existingSet = new Set(existingMarcoms.map(m =>
        `${m.marcom_type.toLowerCase()}_${m.marcom_name.toLowerCase()}`
      ));

      // Filter out rows that already exist in DB
      const rowsToInsert = validRows.filter(row =>
        !existingSet.has(`${row.marcom_type.toLowerCase()}_${row.marcom_name.toLowerCase()}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all marcoms
      const insertValues = rowsToInsert.map(row => [
        row.marcom_type,
        row.marcom_name,
        row.year || null,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO marcom 
        (marcom_type, marcom_name, year, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Marcom(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllMarcoms: async function (req, res) {
    try {
      let query = `
        SELECT id, marcom_type, marcom_name, year, createdOn, isActive 
        FROM marcom 
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateMarcom: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, marcom_type, marcom_name, year, isActive } = req.body;

      if (!id || !marcom_type || !marcom_name) {
        return res.status(400).send({ status: false, message: "ID, marcom_type, and marcom_name are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateMarcomField(marcom_type) ||
        !validateMarcomField(marcom_name)
      ) {
        return res.status(400).send({ status: false, message: "Marcom details (type, name) must be valid and less than 255 characters!" });
      }

      // Check for duplicate marcom (same marcom_name AND marcom_type, excluding current id)
      let validateQ = `
        SELECT * FROM marcom 
        WHERE marcom_name = ? AND marcom_type = ? AND id != ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [marcom_name, marcom_type, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Marcom already exists with this name and type!" });
      }

      let query = `
        UPDATE marcom 
        SET marcom_type = ?, marcom_name = ?, year = ?
        WHERE id = ? AND isDeleted = 0
      `;
      let updatedResult = await connection.query(query, [marcom_type, marcom_name, year || null, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Marcom Updated",
          `The Marcom "${marcom_name}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Marcom updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleMarcom: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM marcom WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Marcom not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE marcom SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      let updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Marcom ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteMarcom: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE marcom SET isDeleted = 1 WHERE id = ?`;
      let updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Marcom deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
