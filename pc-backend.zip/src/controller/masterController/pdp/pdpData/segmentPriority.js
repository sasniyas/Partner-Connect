const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');
const { validateSegmentFocusAreaField, validateSegmentPriorityRows } = require("../../../../utils/validation/pdpMasterValidation/segmentPriority.validation");
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Segment Priority
  addSegmentPriority: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { segment_focus_area, year } = req.body;
      if (!segment_focus_area) {
        return res.status(400).send({ status: false, message: "segment_focus_area field is required!" });
      }

      // Check field lengths using external validation
      if (!validateSegmentFocusAreaField(segment_focus_area)) {
        return res.status(400).send({ status: false, message: "Segment focus area must be valid and less than 100 characters!" });
      }

      // Check for duplicate segment priority (same segment_focus_area, year and not deleted)
      let validateQ = `
        SELECT * FROM segment_priority 
        WHERE segment_focus_area = ? AND (year = ? OR (year IS NULL AND ? IS NULL)) AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [segment_focus_area, year || null, year || null]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Segment Priority already exists with these details!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO segment_priority 
        (segment_focus_area, year, createdOn, isActive, isDeleted) 
        VALUES (?, ?, ?, 1, 0)
      `;
      const insertResult = await connection.query(query, [segment_focus_area, year || null, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Segment Priority Added",
          `A new Segment Priority "${segment_focus_area}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Segment Priority added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Segment Priority
  bulkAddSegmentPriority: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateSegmentPriorityRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database using multi-column check
      const existingRecords = await connection.query(`SELECT segment_focus_area, year FROM segment_priority WHERE isDeleted = 0`);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.segment_focus_area.toLowerCase()}|${r.year || 'null'}`)
      );

      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.segment_focus_area.toLowerCase()}|${row.year || 'null'}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all segment priorities
      const insertValues = rowsToInsert.map(row => [
        row.segment_focus_area,
        row.year || null,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO segment_priority 
        (segment_focus_area, year, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Segment Priority(ies) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllSegmentPriorities: async function (req, res) {
    try {
      let query = `
        SELECT id, segment_focus_area, year, createdOn, isActive, isDeleted 
        FROM segment_priority 
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateSegmentPriority: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, segment_focus_area, year, isActive } = req.body;

      if (!id || !segment_focus_area) {
        return res.status(400).send({ status: false, message: "ID and segment_focus_area are required!" });
      }

      // Check field lengths using external validation
      if (!validateSegmentFocusAreaField(segment_focus_area)) {
        return res.status(400).send({ status: false, message: "Segment focus area must be valid and less than 100 characters!" });
      }

      // Check for duplicate segment priority (excluding current id)
      let validateQ = `
        SELECT * FROM segment_priority 
        WHERE segment_focus_area = ? AND (year = ? OR (year IS NULL AND ? IS NULL)) AND id != ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [segment_focus_area, year || null, year || null, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Segment Priority already exists with these details!" });
      }

      let query = `
        UPDATE segment_priority 
        SET segment_focus_area = ?, year = ?
        WHERE id = ? AND isDeleted = 0
      `;
      let updatedResult = await connection.query(query, [segment_focus_area, year || null, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Segment Priority Updated",
          `The Segment Priority "${segment_focus_area}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Segment Priority updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleSegmentPriority: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM segment_priority WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Segment Priority not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE segment_priority SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      let updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Segment Priority ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteSegmentPriority: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE segment_priority SET isDeleted = 1 WHERE id = ?`;
      let updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Segment Priority deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
