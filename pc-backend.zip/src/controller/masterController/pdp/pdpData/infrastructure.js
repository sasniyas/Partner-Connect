const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');
const { validateInfrastructureField, validateInfrastructureRows } = require("../../../../utils/validation/pdpMasterValidation/infrastructure.validation");
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Infrastructure
  addInfrastructure: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { year, facility_type, facility_definition } = req.body;
      if (!year || !facility_type || !facility_definition) {
        return res.status(400).send({ status: false, message: "All fields (year, facility_type, facility_definition) are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateInfrastructureField(facility_type) ||
        !validateInfrastructureField(facility_definition)
      ) {
        return res.status(400).send({ status: false, message: "Infrastructure details (type, definition) must be valid and less than 100 characters!" });
      }

      // Check for duplicate infrastructure (same year, facility_type, facility_definition, and not deleted)
      let validateQ = `
        SELECT * FROM infrastructure 
        WHERE year = ? AND facility_type = ? AND facility_definition = ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [year, facility_type, facility_definition]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Infrastructure already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO infrastructure 
        (year, facility_type, facility_definition, createdOn, isActive, isDeleted) 
        VALUES (?, ?, ?, ?, 1, 0)
      `;
      const insertResult = await connection.query(query, [year, facility_type, facility_definition, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Infrastructure Added",
          `A new Infrastructure "${facility_type} - ${facility_definition}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Infrastructure added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Infrastructure
  bulkAddInfrastructure: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateInfrastructureRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database using multi-column IN
      const checkValues = validRows.map(row => [row.year, row.facility_type, row.facility_definition]);
      const existingQuery = `
        SELECT year, facility_type, facility_definition FROM infrastructure 
        WHERE (year, facility_type, facility_definition) IN (?) AND isDeleted = 0
      `;
      const existingInfrastructures = await connection.query(existingQuery, [checkValues]);
      const existingSet = new Set(existingInfrastructures.map(i =>
        `${i.year}_${i.facility_type.toLowerCase()}_${i.facility_definition.toLowerCase()}`
      ));

      // Filter out rows that already exist in DB
      const rowsToInsert = validRows.filter(row =>
        !existingSet.has(`${row.year}_${row.facility_type.toLowerCase()}_${row.facility_definition.toLowerCase()}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all infrastructures
      const insertValues = rowsToInsert.map(row => [
        row.year,
        row.facility_type,
        row.facility_definition,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO infrastructure 
        (year, facility_type, facility_definition, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Infrastructure(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllInfrastructures: async function (req, res) {
    try {
      let query = `
        SELECT id, year, facility_type, facility_definition, createdOn, isActive 
        FROM infrastructure 
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateInfrastructure: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, year, facility_type, facility_definition, isActive } = req.body;

      if (!id || !year || !facility_type || !facility_definition) {
        return res.status(400).send({ status: false, message: "ID, year, facility_type, and facility_definition are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateInfrastructureField(facility_type) ||
        !validateInfrastructureField(facility_definition)
      ) {
        return res.status(400).send({ status: false, message: "Infrastructure details (type, definition) must be valid and less than 100 characters!" });
      }

      // Check for duplicate infrastructure (excluding current id)
      let validateQ = `
        SELECT * FROM infrastructure 
        WHERE year = ? AND facility_type = ? AND facility_definition = ? AND id != ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [year, facility_type, facility_definition, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Infrastructure already exists with these details!" });
      }

      let query = `
        UPDATE infrastructure 
        SET year = ?, facility_type = ?, facility_definition = ?
        WHERE id = ? AND isDeleted = 0
      `;
      let updatedResult = await connection.query(query, [year, facility_type, facility_definition, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Infrastructure Updated",
          `The Infrastructure "${facility_type} - ${facility_definition}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Infrastructure updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleInfrastructure: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM infrastructure WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Infrastructure not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE infrastructure SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      let updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Infrastructure ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteInfrastructure: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE infrastructure SET isDeleted = 1 WHERE id = ?`;
      let updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Infrastructure deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
