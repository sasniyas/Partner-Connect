const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');
const { validateBranchMasterField, validateBranchMasterRows } = require("../../../../utils/validation/pdpMasterValidation/branchMaster.validation");
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Branch Master
  addBranchMaster: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { market_area_id, dealership_id, city_id, district_ids, branch_name, facility_type, target_date, development_status } = req.body;
      if (!market_area_id || !dealership_id || !city_id || !district_ids || !branch_name || !facility_type) {
        return res.status(400).send({ status: false, message: "All fields (market_area_id, dealership_id, city_id, district_id, branch_name, facility_type) are required!" });
      }

      // Check field lengths using external validation
      if (!validateBranchMasterField(branch_name)) {
        return res.status(400).send({ status: false, message: "Branch name must be valid and less than 100 characters!" });
      }

      // Validate development_status if provided
      const allowedStatuses = ['Completed', 'New', 'In Progress'];
      if (development_status && !allowedStatuses.includes(development_status)) {
        return res.status(400).send({
          status: false,
          message: `development_status must be one of: ${allowedStatuses.join(', ')}`
        });
      }

      // Check for duplicate branch master (same market_area_id, dealership_id, city_id, branch_name and not deleted)
      let validateQ = `
        SELECT * FROM branch_master 
        WHERE market_area_id = ? AND dealership_id = ? AND city_id = ? AND branch_name = ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [market_area_id, dealership_id, city_id, branch_name]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Branch Master already exists with these details!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const query = `
        INSERT INTO branch_master 
        (market_area_id, dealership_id, city_id, branch_name, facility_type, createdOn, isActive, isDeleted, target_date, development_status) 
        VALUES (?, ?, ?, ?, ?, ?, 1, 0, ?, ?)
      `;

      const insertResult = await connection.query(query, [
        market_area_id,
        dealership_id,
        city_id,
        branch_name,
        facility_type,
        createdOn,
        target_date || null,
        development_status || null
      ]);
      const createdId = insertResult.insertId;
      // district_ids is the array of ids, so we iterate directly over it
      for (const district_id of district_ids) {
        await connection.query(
          `INSERT INTO branch_district_mapping(branch_master_id, district_id, createdOn) VALUES (?, ?, ?)`,
          [createdId, district_id, createdOn]
        );
      }

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Branch Master Added",
          `A new Branch Master "${branch_name}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Branch Master added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Branch Master
  bulkAddBranchMaster: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;



      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateBranchMasterRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database using multi-column check
      const existingRecords = await connection.query(`SELECT market_area_id, dealership_id, city_id, branch_name FROM branch_master WHERE isDeleted = 0`);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.market_area_id}|${r.dealership_id}|${r.city_id}|${r.branch_name.toLowerCase()}`)
      );

      // Filter out rows that already exist in DB
      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.market_area_id}|${row.dealership_id}|${row.city_id}|${row.branch_name.toLowerCase()}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all branch masters
      const values = rowsToInsert.map(row => [
        row.market_area_id,
        row.dealership_id,
        row.city_id,
        row.branch_name,
        row.facility_type,
        createdOn,
        1,
        0,
        row.target_date,
        row.development_status
      ]);

      const placeholders = rowsToInsert.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
      const query = `
        INSERT INTO branch_master 
        (market_area_id, dealership_id, city_id, branch_name, facility_type, createdOn, isActive, isDeleted, target_date, development_status) 
        VALUES ${placeholders}
      `;

      const flatValues = values.flat();
      await connection.query(query, flatValues);

      // Get the inserted branch IDs by querying back using branch_names and createdOn
      const insertedBranchNames = rowsToInsert.map(row => row.branch_name);
      const getInsertedIdsQuery = `
        SELECT id, branch_name FROM branch_master 
        WHERE branch_name IN (${insertedBranchNames.map(() => '?').join(',')}) 
        AND createdOn = ? AND isDeleted = 0
        ORDER BY id DESC
        LIMIT ?
      `;
      const insertedBranches = await connection.query(getInsertedIdsQuery, [...insertedBranchNames, createdOn, rowsToInsert.length]);

      // Create a map of branch_name to id
      const branchNameToIdMap = {};
      insertedBranches.forEach(branch => {
        branchNameToIdMap[branch.branch_name] = branch.id;
      });

      // Build single bulk insert query for all district mappings
      const districtMappingValues = [];
      for (const row of rowsToInsert) {
        const branchId = branchNameToIdMap[row.branch_name];
        if (branchId) {
          for (const district_id of row.district_ids) {
            districtMappingValues.push([branchId, district_id, createdOn]);
          }
        }
      }

      if (districtMappingValues.length > 0) {
        const districtPlaceholders = districtMappingValues.map(() => '(?, ? ,?)').join(', ');
        const districtQuery = `
          INSERT INTO branch_district_mapping(branch_master_id, district_id,createdOn) 
          VALUES ${districtPlaceholders}
        `;
        const flatDistrictValues = districtMappingValues.flat();
        await connection.query(districtQuery, flatDistrictValues);
      }

      let message = `${rowsToInsert.length} Branch Master(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllBranchMasters: async function (req, res) {
    try {
      // First get all branch masters
      let branchQuery = `
        SELECT bm.id, bm.market_area_id, bm.dealership_id, bm.city_id, bm.branch_name, bm.facility_type, 
               bm.isActive, bm.isDeleted, bm.createdOn, bm.target_date, bm.development_status,
               ma.marketarea, dm.dealerName as dealer_name, cm.cityName
        FROM branch_master bm 
        LEFT JOIN market_area ma ON bm.market_area_id = ma.id 
        LEFT JOIN dealer_master dm ON bm.dealership_id = dm.id 
        LEFT JOIN city_master cm ON bm.city_id = cm.id 
        WHERE bm.isDeleted = 0 AND ma.isDeleted = 0 AND dm.isDeleted = 0 AND cm.isDeleted = 0
        ORDER BY bm.id DESC
      `;
      let branchData = await connection.query(branchQuery);

      // Get district mappings for all branches
      let districtQuery = `
        SELECT bdm.branch_master_id, dt.district_name, dt.id as district_id
        FROM branch_district_mapping bdm
        LEFT JOIN districts dt ON bdm.district_id = dt.id
        WHERE bdm.branch_master_id IN (${branchData.length ? branchData.map(b => b.id).join(',') : 0})
      `;
      let districtData = await connection.query(districtQuery);

      // Group districts by branch_master_id
      let districtMap = {};
      districtData.forEach(district => {
        if (!districtMap[district.branch_master_id]) {
          districtMap[district.branch_master_id] = [];
        }
        districtMap[district.branch_master_id].push({
          district_id: district.district_id,
          district_name: district.district_name
        });
      });

      // Combine branch data with district data
      let result = branchData.map(branch => ({
        ...branch,
        districts: districtMap[branch.id] || []
      }));

      return res.status(200).send({ status: true, data: result });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateBranchMaster: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, market_area_id, dealership_id, city_id, district_ids, branch_name, facility_type, isActive, target_date, development_status } = req.body;

      if (!id || !market_area_id || !dealership_id || !city_id || !district_ids || !branch_name || !facility_type) {
        return res.status(400).send({ status: false, message: "ID, market_area_id, dealership_id, city_id, district_ids, branch_name, and facility_type are required!" });
      }

      // Check field lengths using external validation
      if (!validateBranchMasterField(branch_name)) {
        return res.status(400).send({ status: false, message: "Branch name must be valid and less than 100 characters!" });
      }

      // Validate development_status if provided
      const allowedStatuses = ['Completed', 'New', 'In Progress'];
      if (development_status && !allowedStatuses.includes(development_status)) {
        return res.status(400).send({
          status: false,
          message: `development_status must be one of: ${allowedStatuses.join(', ')}`
        });
      }

      // Check for duplicate branch master (excluding current id)
      let validateQ = `
        SELECT * FROM branch_master 
        WHERE market_area_id = ? AND dealership_id = ? AND city_id = ? AND branch_name = ? AND id != ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [market_area_id, dealership_id, city_id, branch_name, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Branch Master already exists with these details!" });
      }

      // Update branch master table
      let query = `
        UPDATE branch_master 
        SET market_area_id = ?, dealership_id = ?, city_id = ?, branch_name = ?, facility_type = ?, 
         target_date = ?, development_status = ?
        WHERE id = ? AND isDeleted = 0
      `;
      let updatedResult = await connection.query(query, [
        market_area_id,
        dealership_id,
        city_id,
        branch_name,
        facility_type,
        target_date || null,
        development_status || null,
        id
      ]);

      // Delete existing district mappings
      await connection.query(`DELETE FROM branch_district_mapping WHERE branch_master_id = ?`, [id]);

      // Insert new district mappings with createdOn
      const updatedCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      for (const district_id of district_ids) {
        await connection.query(
          `INSERT INTO branch_district_mapping(branch_master_id, district_id, createdOn) VALUES (?, ?, ?)`,
          [id, district_id, updatedCreatedOn]
        );
      }

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Branch Master Updated",
          `The Branch Master "${branch_name}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Branch Master updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleBranchMaster: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM branch_master WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Branch Master not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE branch_master SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      let updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Branch Master ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteBranchMaster: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Soft delete branch master - we keep district mappings for historical data
      let query = `UPDATE branch_master SET isDeleted = 1 WHERE id = ?`;
      let updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Branch Master deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
