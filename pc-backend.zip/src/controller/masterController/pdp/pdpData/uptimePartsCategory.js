const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');
const { validateUptimePartsCategoryField, validateUptimePartsCategoryRows } = require("../../../../utils/validation/pdpMasterValidation/uptimePartsCategory.validation");
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Uptime Parts Category
  addUptimePartsCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { year, category, equipment_make, details, measurement_units, di_required } = req.body;
      if (!year || !category || !equipment_make || !details || !measurement_units) {
        return res.status(400).send({ status: false, message: "Fields year, category, equipment_make, details, measurement_units are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateUptimePartsCategoryField(category) ||
        !validateUptimePartsCategoryField(equipment_make) ||
        !validateUptimePartsCategoryField(measurement_units)
      ) {
        return res.status(400).send({ status: false, message: "Category, equipment make, and measurement units must be valid and less than 100 characters!" });
      }

      // Check for duplicate (same year, category, equipment_make, and not deleted)
      let validateQ = `
        SELECT * FROM uptime_parts_category
        WHERE year = ? AND category = ? AND equipment_make = ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [year, category, equipment_make]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Uptime Parts details already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO uptime_parts_category
        (year, category, equipment_make, details, measurement_units, di_required, createdOn, isActive, isDeleted)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0)
      `;
      const insertResult = await connection.query(query, [
        year,
        category,
        equipment_make,
        details || null,
        measurement_units || null,
        di_required !== undefined ? di_required : 1,
        createdOn
      ]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Uptime Parts Category Added",
          `A new Uptime Parts Category "${category}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Uptime Parts Category added successfully!", data: insertResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Uptime Parts Category
  bulkAddUptimePartsCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateUptimePartsCategoryRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database
      const checkValues = validRows.map(row => [row.year, row.category, row.equipment_make]);
      const existingQuery = `
        SELECT year, category, equipment_make FROM uptime_parts_category 
        WHERE (year, category, equipment_make) IN (?) AND isDeleted = 0
      `;
      const existingUptimePartsCategories = await connection.query(existingQuery, [checkValues]);
      const existingCombinations = new Set(
        existingUptimePartsCategories.map(u => `${u.year}_${u.category.toLowerCase()}_${u.equipment_make.toLowerCase()}`)
      );

      // Filter out rows that already exist in DB
      const rowsToInsert = validRows.filter(row =>
        !existingCombinations.has(`${row.year}_${row.category.toLowerCase()}_${row.equipment_make.toLowerCase()}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all uptime parts categories
      const insertValues = rowsToInsert.map(row => [
        row.year,
        row.category,
        row.equipment_make,
        row.details,
        row.measurement_units,
        row.di_required !== undefined ? row.di_required : 1,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO uptime_parts_category
        (year, category, equipment_make, details, measurement_units, di_required, createdOn, isActive, isDeleted)
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Uptime Parts Category(ies) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // Get all uptime parts categories
  getAllUptimePartsCategories: async function (req, res) {
    try {
      let query = `
        SELECT id, year, category, equipment_make, details, measurement_units, di_required, createdOn, isActive
        FROM uptime_parts_category
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // Update uptime parts category
  updateUptimePartsCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, year, category, equipment_make, details, measurement_units, di_required, isActive } = req.body;

      if (!id || !year || !category || !equipment_make) {
        return res.status(400).send({ status: false, message: "ID, year, category, and equipment_make are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateUptimePartsCategoryField(category) ||
        !validateUptimePartsCategoryField(equipment_make) ||
        (measurement_units && !validateUptimePartsCategoryField(measurement_units))
      ) {
        return res.status(400).send({ status: false, message: "Category, equipment make, and measurement units must be valid and less than 100 characters!" });
      }

      // Check for duplicate (excluding current id)
      let validateQ = `
        SELECT * FROM uptime_parts_category
        WHERE year = ? AND category = ? AND equipment_make = ? AND id != ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [year, category, equipment_make, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Uptime Parts Category already exists with these details!" });
      }

      let query = `
        UPDATE uptime_parts_category
        SET year = ?, category = ?, equipment_make = ?, details = ?, measurement_units = ?, di_required = ?
        WHERE id = ? AND isDeleted = 0
      `;
      let updatedResult = await connection.query(query, [
        year,
        category,
        equipment_make,
        details || null,
        measurement_units || null,
        di_required !== undefined ? di_required : 1,
        id
      ]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Uptime Parts Category Updated",
          `The Uptime Parts Category "${category}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Uptime Parts Category updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // Toggle enable/disable uptime parts category
  toggleUptimePartsCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM uptime_parts_category WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Uptime Parts Category not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE uptime_parts_category SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      let updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Uptime Parts Category ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // Soft delete uptime parts category
  deleteUptimePartsCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE uptime_parts_category SET isDeleted = 1 WHERE id = ?`;
      let updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Uptime Parts Category deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
