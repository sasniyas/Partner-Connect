const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');
const { validateMarcomMarketingField, validateMarcomMarketingRows } = require("../../../../utils/validation/pdpMasterValidation/marcomMarketing.validation");
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Marcom
  addMrkMarcom: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { activity_Type, target, year } = req.body;
      if (!activity_Type || !target) {
        return res.status(400).send({ status: false, message: "All fields (activity_Type, target) are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateMarcomMarketingField(activity_Type) ||
        !validateMarcomMarketingField(target)
      ) {
        return res.status(400).send({ status: false, message: "Marcom Marketing details (activity type, target) must be valid and less than 100 characters!" });
      }

      // Check for duplicate (activity_Type, target, year combination)
      const existingQuery = `
        SELECT id FROM marcomMrk 
        WHERE activity_Type = ? AND target = ? AND (year = ? OR (year IS NULL AND ? IS NULL))
          AND isDeleted = 0
      `;
      const existing = await connection.query(existingQuery, [activity_Type, target, year || null, year || null]);
      if (existing.length > 0) {
        return res.status(400).send({
          status: false,
          message: "Marcom Marketing already exists for this activity_Type, target, and year combination!"
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO marcomMrk 
        (activity_Type, target, year, createdOn, isActive, isDeleted) 
        VALUES (?, ?, ?, ?, 1, 0)
      `;
      const insertResult = await connection.query(query, [activity_Type, target, year || null, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Marcom Marketing Added",
          `A new Marcom Marketing "${activity_Type}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Marcom added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Marcom Marketing
  bulkAddMarcomMrk: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateMarcomMarketingRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database using multi-column check
      const checkValues = validRows.map(row => [row.activity_Type, row.target, row.year || null]);
      const existingQuery = `
        SELECT activity_Type, target, year FROM marcomMrk 
        WHERE (activity_Type, target, IFNULL(year, 'NULL')) IN (?) AND isDeleted = 0
      `;
      // We need to handle NULL year specifically if we want to use IN with combinations. 
      // However, MySQL (activity_Type, target, year) IN (?) might not work perfectly with NULLs.
      // Let's stick to the current Set approach but make it case-insensitive/consistent.
      const existingRecords = await connection.query(`SELECT activity_Type, target, year FROM marcomMrk WHERE isDeleted = 0`);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.activity_Type.toLowerCase()}|${r.target.toLowerCase()}|${r.year || 'null'}`)
      );

      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.activity_Type.toLowerCase()}|${row.target.toLowerCase()}|${row.year || 'null'}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all marcom marketing records
      const insertValues = rowsToInsert.map(row => [
        row.activity_Type,
        row.target,
        row.year || null,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO marcomMrk 
        (activity_Type, target, year, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Marcom Marketing(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllMrkMarcoms: async function (req, res) {
    try {
      let query = `
        SELECT id, activity_Type, target, year, createdOn, isActive 
        FROM marcomMrk 
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateMrkMarcom: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, activity_Type, target, year, isActive } = req.body;

      if (!id || !activity_Type || !target) {
        return res.status(400).send({ status: false, message: "ID, activity_Type, and target are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateMarcomMarketingField(activity_Type) ||
        !validateMarcomMarketingField(target)
      ) {
        return res.status(400).send({ status: false, message: "Marcom Marketing details (activity type, target) must be valid and less than 100 characters!" });
      }

      // Check for duplicate (activity_Type, target, year combination) excluding current record
      const existingQuery = `
        SELECT id FROM marcomMrk 
        WHERE activity_Type = ? AND target = ? AND (year = ? OR (year IS NULL AND ? IS NULL))
          AND id != ? AND isDeleted = 0
      `;
      const existing = await connection.query(existingQuery, [activity_Type, target, year || null, year || null, id]);
      if (existing.length > 0) {
        return res.status(400).send({
          status: false,
          message: "Marcom Marketing already exists for this activity_Type, target, and year combination!"
        });
      }

      let query = `
        UPDATE marcomMrk 
        SET activity_Type = ?, target = ?, year = ?
        WHERE id = ? AND isDeleted = 0
      `;
      let updatedResult = await connection.query(query, [activity_Type, target, year || null, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Marcom Marketing Updated",
          `The Marcom Marketing "${activity_Type}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Marcom updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleMrkMarcom: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM marcomMrk WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "MarcomMrk not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE marcomMrk SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      let updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `MarcomMrk ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteMrkMarcom: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE marcomMrk SET isDeleted = 1 WHERE id = ?`;
      let updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "MarcomMrk deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
