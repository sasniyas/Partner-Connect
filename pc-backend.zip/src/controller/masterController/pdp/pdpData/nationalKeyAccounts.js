const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');
const { validateNationalKeyAccountsField, validateNationalKeyAccountRows } = require("../../../../utils/validation/pdpMasterValidation/nationalKeyAccounts.validation");
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add National Key Account
  addNationalKeyAccount: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { market_area_id, dealer_id, key_account_customer, year } = req.body;
      if (!market_area_id || !dealer_id || !key_account_customer) {
        return res.status(400).send({ status: false, message: "All fields (market_area_id, dealer_id, key_account_customer) are required!" });
      }

      // Check field lengths using external validation
      if (!validateNationalKeyAccountsField(key_account_customer)) {
        return res.status(400).send({ status: false, message: "Key account customer must be valid and less than 100 characters!" });
      }

      // Check for duplicate national key account (same market_area_id, dealer_id, key_account_customer, year, and not deleted)
      let validateQ = `
        SELECT * FROM national_key_accounts 
        WHERE market_area_id = ? AND dealer_id = ? AND key_account_customer = ? AND (year = ? OR (year IS NULL AND ? IS NULL)) AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [market_area_id, dealer_id, key_account_customer, year || null, year || null]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "National Key Account already exists with these details!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const query = `INSERT INTO national_key_accounts 
        (market_area_id, dealer_id, key_account_customer, year, isActive, isDeleted, createdOn) 
        VALUES (?, ?, ?, ?, 1, 0, ?)
      `;
      const insertResult = await connection.query(query, [market_area_id, dealer_id, key_account_customer, year || null, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New National Key Account Added",
          `A new National Key Account "${key_account_customer}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "National Key Account added successfully!", data: insertResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add National Key Accounts
  bulkAddNationalKeyAccounts: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateNationalKeyAccountRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database using multi-column check
      const existingRecords = await connection.query(`SELECT market_area_id, dealer_id, key_account_customer, year FROM national_key_accounts WHERE isDeleted = 0`);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.market_area_id}|${r.dealer_id}|${r.key_account_customer.toLowerCase()}|${r.year || 'null'}`)
      );

      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.market_area_id}|${row.dealer_id}|${row.key_account_customer.toLowerCase()}|${row.year || 'null'}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all national key accounts
      const insertValues = rowsToInsert.map(row => [
        row.market_area_id,
        row.dealer_id,
        row.key_account_customer,
        row.year || null,
        1, // isActive
        0, // isDeleted
        createdOn
      ]);

      const query = `
        INSERT INTO national_key_accounts 
        (market_area_id, dealer_id, key_account_customer, year, isActive, isDeleted, createdOn) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} National Key Account(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllNationalKeyAccounts: async function (req, res) {
    try {
      // let query = `
      //   SELECT id, market_area_id, dealer_id, key_account_customer, createdOn, isActive, isDeleted 
      //   FROM national_key_accounts 
      //   WHERE isDeleted = 0
      //   ORDER BY id DESC
      // `;
      let query = `
        SELECT nka.id, ma.marketarea, dm.dealerName as dealer_name, nka.key_account_customer, nka.year, nka.isActive, nka.isDeleted, nka.createdOn 
        FROM national_key_accounts nka 
        LEFT JOIN market_area ma ON nka.market_area_id = ma.id 
        LEFT JOIN dealer_master dm ON nka.dealer_id = dm.id 
        WHERE nka.isDeleted = 0 AND ma.isDeleted = 0 AND dm.isDeleted = 0
        ORDER BY nka.id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateNationalKeyAccount: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, market_area_id, dealer_id, key_account_customer, year, isActive } = req.body;

      if (!id || !market_area_id || !dealer_id || !key_account_customer) {
        return res.status(400).send({ status: false, message: "ID, market_area_id, dealer_id, and key_account_customer are required!" });
      }

      // Check field lengths using external validation
      if (!validateNationalKeyAccountsField(key_account_customer)) {
        return res.status(400).send({ status: false, message: "Key account customer must be valid and less than 100 characters!" });
      }

      // Check for duplicate national key account (excluding current id)
      let validateQ = `
      SELECT * FROM national_key_accounts 
        WHERE market_area_id = ? AND dealer_id = ? AND key_account_customer = ? AND(year = ? OR(year IS NULL AND ? IS NULL)) AND id != ? AND isDeleted = 0
        `;
      let validateData = await connection.query(validateQ, [market_area_id, dealer_id, key_account_customer, year || null, year || null, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "National Key Account already exists with these details!" });
      }

      let query = `
        UPDATE national_key_accounts 
        SET market_area_id = ?, dealer_id = ?, key_account_customer = ?, year = ?
        WHERE id = ? AND isDeleted = 0
          `;
      let updatedResult = await connection.query(query, [market_area_id, dealer_id, key_account_customer, year || null, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "National Key Account Updated",
          `The National Key Account "${key_account_customer}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "National Key Account updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleNationalKeyAccount: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM national_key_accounts WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "National Key Account not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE national_key_accounts SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      let updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `National Key Account ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteNationalKeyAccount: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE national_key_accounts SET isDeleted = 1 WHERE id = ? `;
      let updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "National Key Account deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
