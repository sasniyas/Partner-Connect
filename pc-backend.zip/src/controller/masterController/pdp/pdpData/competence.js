const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');
const { validateCompetenceField, validateCompetenceRows } = require("../../../../utils/validation/pdpMasterValidation/competence.validation");
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Competence
  addCompetence: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { competence_type, competence_name, di_required } = req.body;
      if (!competence_type || !competence_name) {
        return res.status(400).send({ status: false, message: "All fields (competence_type, competence_name) are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateCompetenceField(competence_type) ||
        !validateCompetenceField(competence_name)
      ) {
        return res.status(400).send({ status: false, message: "Competence details (type, name) must be valid and less than 100 characters!" });
      }

      // Check for duplicate competence (same competence_type, competence_name and not deleted)
      let validateQ = `
        SELECT * FROM competence 
        WHERE competence_type = ? AND competence_name = ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [competence_type, competence_name]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Competence already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO competence 
        (competence_type, competence_name, createdOn,di_required, isActive, isDeleted) 
        VALUES (?, ?, ?,?, 1, 0)
      `;
      const insertResult = await connection.query(query, [competence_type, competence_name, createdOn, di_required]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Competence Added",
          `A new Competence "${competence_name}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Competence added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Competence
  bulkAddCompetence: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateCompetenceRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing combinations in database using multi-column IN
      const checkValues = validRows.map(row => [row.competence_type, row.competence_name]);
      const existingQuery = `
        SELECT competence_type, competence_name FROM competence 
        WHERE (competence_type, competence_name) IN (?) AND isDeleted = 0
      `;
      const existingCompetences = await connection.query(existingQuery, [checkValues]);
      const existingSet = new Set(existingCompetences.map(c =>
        `${c.competence_type.toLowerCase()}_${c.competence_name.toLowerCase()}`
      ));

      // Filter out rows that already exist in DB
      const rowsToInsert = validRows.filter(row =>
        !existingSet.has(`${row.competence_type.toLowerCase()}_${row.competence_name.toLowerCase()}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all competences
      const insertValues = rowsToInsert.map(row => [
        row.competence_type,
        row.competence_name,
        createdOn,
        row.di_required,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO competence 
        (competence_type, competence_name, createdOn, di_required, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Competence(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllCompetences: async function (req, res) {
    try {
      let query = `
        SELECT id, competence_type, competence_name, createdOn,di_required, isActive 
        FROM competence 
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateCompetence: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, competence_type, competence_name, di_required, isActive } = req.body;

      if (!id || !competence_type || !competence_name) {
        return res.status(400).send({ status: false, message: "ID, competence_type, and competence_name are required!" });
      }

      // Check field lengths using external validation
      if (
        !validateCompetenceField(competence_type) ||
        !validateCompetenceField(competence_name)
      ) {
        return res.status(400).send({ status: false, message: "Competence details (type, name) must be valid and less than 100 characters!" });
      }

      // Check for duplicate competence (excluding current id)
      let validateQ = `
        SELECT * FROM competence 
        WHERE competence_type = ? AND competence_name = ? AND id != ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [competence_type, competence_name, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Competence already exists with these details!" });
      }

      let query = `
        UPDATE competence 
        SET competence_type = ?, competence_name = ?,di_required=?
        WHERE id = ? AND isDeleted = 0
      `;
      let updatedResult = await connection.query(query, [competence_type, competence_name, di_required, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Competence Updated",
          `The Competence "${competence_name}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Competence updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleCompetence: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM competence WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Competence not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE competence SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      let updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Competence ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteCompetence: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE competence SET isDeleted = 1 WHERE id = ?`;
      let updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Competence deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
