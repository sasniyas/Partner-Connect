const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');
const { validateOtherDataField, validateOtherDataRows } = require("../../../../utils/validation/pdpMasterValidation/otherData.validation");
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Other Data
  addOtherData: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { file_name } = req.body;
      if (!file_name) {
        return res.status(400).send({ status: false, message: "file_name field is required!" });
      }

      // Check field length using external validation
      if (!validateOtherDataField(file_name)) {
        return res.status(400).send({ status: false, message: "File name must be valid and less than 100 characters!" });
      }

      // Check for duplicate other data (same file_name and not deleted)
      let validateQ = `
        SELECT * FROM others_data 
        WHERE file_name = ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [file_name]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Other Data already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `
        INSERT INTO others_data 
        (file_name, createdOn, isActive, isDeleted) 
        VALUES (?, ?, 1, 0)
      `;
      const insertResult = await connection.query(query, [file_name, createdOn]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Other Data Added",
          `A new Other Data entry "${file_name}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Other Data added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Other Data
  bulkAddOtherData: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateOtherDataRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing file names in database (optimized check)
      const existingRecords = await connection.query(`SELECT file_name FROM others_data WHERE isDeleted = 0`);
      const existingFileNamesSet = new Set(existingRecords.map(o => o.file_name.toLowerCase()));

      // Filter out rows that already exist in DB
      const rowsToInsert = validRows.filter(row => !existingFileNamesSet.has(row.file_name.toLowerCase()));
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all other data records
      const insertValues = rowsToInsert.map(row => [
        row.file_name,
        createdOn,
        1, // isActive
        0  // isDeleted
      ]);

      const query = `
        INSERT INTO others_data 
        (file_name, createdOn, isActive, isDeleted) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Other Data added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllOtherData: async function (req, res) {
    try {
      let query = `
        SELECT id, file_name, createdOn, isActive, isDeleted 
        FROM others_data 
        WHERE isDeleted = 0
        ORDER BY id DESC
      `;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateOtherData: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, file_name, isActive } = req.body;

      if (!id || !file_name) {
        return res.status(400).send({ status: false, message: "ID and file_name are required!" });
      }

      // Check field length using external validation
      if (!validateOtherDataField(file_name)) {
        return res.status(400).send({ status: false, message: "File name must be valid and less than 100 characters!" });
      }

      // Check for duplicate other data (excluding current id)
      let validateQ = `
        SELECT * FROM others_data 
        WHERE file_name = ? AND id != ? AND isDeleted = 0
      `;
      let validateData = await connection.query(validateQ, [file_name, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Other Data already exists with these details!" });
      }

      let query = `
        UPDATE others_data 
        SET file_name = ?
        WHERE id = ? AND isDeleted = 0
      `;
      let updatedResult = await connection.query(query, [file_name, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Other Data Updated",
          `The Other Data entry "${file_name}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Other Data updated successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleOtherData: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM others_data WHERE id = ? AND isDeleted = 0`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Other Data not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE others_data SET isActive = ? WHERE id = ? AND isDeleted = 0`;
      let updatedResult = await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Other Data ${newStatus === 1 ? "enabled" : "disabled"} successfully!`,
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteOtherData: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `UPDATE others_data SET isDeleted = 1 WHERE id = ?`;
      let updatedResult = await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Other Data deleted successfully!", data: updatedResult });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
