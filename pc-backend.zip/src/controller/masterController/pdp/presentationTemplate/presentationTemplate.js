const { connection } = require("../../../../mySql/mySql"); // adjust path
const moment = require('moment-timezone');
const { uploadFile } = require("../../../azurestorage/fileUpload");
const { createNotification } = require("../../../notification/notification.controller");

// Validation function for bulk add presentation template
const validatePresentationTemplateRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenCombinations = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row) => {
    const { year, presentationTemplate } = row;

    // Check required fields
    if (!year || !presentationTemplate) {
      invalidCount++;
      return;
    }

    const trimmedPresentationTemplate = presentationTemplate.trim();
    if (trimmedPresentationTemplate === "") {
      invalidCount++;
      return;
    }

    // Check for duplicates within the batch (combination of year and presentationTemplate)
    const combinationKey = `${year}_${trimmedPresentationTemplate.toLowerCase()}`;
    if (seenCombinations.has(combinationKey)) {
      invalidCount++;
      return;
    }
    seenCombinations.add(combinationKey);

    // Row is valid
    validRows.push({
      year,
      presentationTemplate: trimmedPresentationTemplate
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // 📝 Update Default Presentation Template
  updateDefaultPreTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { sampleFileUrl } = req.body;

      if (req.files.length) {
        let file = req.files[0]
        sampleFileUrl = await uploadFile(file);
      }


      let query = `UPDATE tempFiles SET  url = ? WHERE id =1`;
      await connection.query(query, [sampleFileUrl]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Default Presentation Template Updated",
          "The default presentation template has been updated.",
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Default Template updated successfully!", data: sampleFileUrl });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 📝 Update Default Finance Template
  getDefaultPreTemplate: async function (req, res) {
    try {
      let query = `select * from tempFiles WHERE id =1`;
      let data = await connection.query(query);
      data = data[0]
      return res.status(200).send({ status: true, message: "Default Template!", data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Bulk Add Presentation Template
  bulkAddPresentationTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validatePresentationTemplateRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing presentation templates in database (optimized with single query)
      const existingQuery = `
        SELECT year, presentation_template FROM presentation_templates
      `;
      const existingRecords = await connection.query(existingQuery);
      const existingCombinationsSet = new Set(
        existingRecords.map(r => `${r.year}|${r.presentation_template}`)
      );

      const rowsToInsert = validRows.filter(row =>
        !existingCombinationsSet.has(`${row.year}|${row.presentationTemplate}`)
      );
      const duplicateCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows already exist in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build single bulk insert query for all presentation templates
      // Note: sample_file (url) defaults to null for bulk operations (no file upload)
      const insertValues = rowsToInsert.map(row => [
        row.year,
        row.presentationTemplate,
        null, // sample_file (url) defaults to null for bulk add (no file upload)
        createdOn,
        1 // isActive
      ]);

      const query = `
        INSERT INTO presentation_templates
        (year, presentation_template, sample_file, createdOn, isActive)
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      let message = `${rowsToInsert.length} Presentation Template(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Add Market Area
  addPresentationTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { year, presentationTemplate } = req.body;
      if (!req.files.length) {
        return res.status(400).send({ status: false, message: " file is required!" });
      }
      if (!year || !presentationTemplate) {
        return res.status(400).send({ status: false, message: "Req Data is required!" });
      }

      let file = req.files[0]
      const blobUrl = await uploadFile(file);
      console.log("blobUrl", blobUrl);

      let validateQ = `SELECT * FROM presentation_templates WHERE year = ? AND presentation_template=?`;
      let validateData = await connection.query(validateQ, [year, presentationTemplate]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Presentation Template already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `INSERT INTO presentation_templates (year,presentation_template,sample_file, createdOn, isActive) VALUES (?, ?, ?, ?, 1)`;
      const insertResult = await connection.query(query, [year, presentationTemplate, blobUrl, createdOn]);
      console.log("insertResult", insertResult);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Presentation Template Added",
          `A new Presentation Template "${presentationTemplate}" for year ${year} has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Presentation Template added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📥 Get All Market Areas
  getAllPresentationTemplates: async function (req, res) {
    try {
      let query = `SELECT id, year, presentation_template, sample_file, isActive, createdOn FROM presentation_templates ORDER BY id DESC`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📝 Update Presentation Template
  updatePresentationTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { year, presentationTemplate, id, sampleFileUrl } = req.body;

      if (!id || !year || !presentationTemplate || !sampleFileUrl) {
        return res.status(400).send({ status: false, message: "ID, Year, Presentation Template and Sample File URL are required!" });
      }

      if (req.files.length) {
        let file = req.files[0]
        sampleFileUrl = await uploadFile(file);
      }

      // Check for duplicate presentation template under same year
      let validateQ = `SELECT * FROM presentation_templates WHERE year = ? AND presentation_template = ? AND id != ?`;
      let validateData = await connection.query(validateQ, [year, presentationTemplate, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Presentation Template already exists for this year!" });
      }

      let query = `UPDATE presentation_templates SET year = ?, presentation_template = ?, sample_file = ? WHERE id = ?`;
      await connection.query(query, [year, presentationTemplate, sampleFileUrl, id]);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Presentation Template Updated",
          `The Presentation Template "${presentationTemplate}" for year ${year} has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Presentation Template updated successfully!", data: sampleFileUrl });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔄 Enable/Disable Presentation Template
  togglePresentationTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Get current status
      let getQuery = `SELECT isActive FROM presentation_templates WHERE id = ?`;
      let data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Presentation Template not found!" });
      }

      let newStatus = data[0].isActive === 1 ? 0 : 1;
      let updateQuery = `UPDATE presentation_templates SET isActive = ? WHERE id = ?`;
      await connection.query(updateQuery, [newStatus, id]);

      return res.status(200).send({
        status: true,
        message: `Presentation Template ${newStatus === 1 ? "enabled" : "disabled"} successfully!`
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ❌ Delete Presentation Template
  deletePresentationTemplate: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      let query = `DELETE FROM presentation_templates WHERE id = ?`;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Presentation Template deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

