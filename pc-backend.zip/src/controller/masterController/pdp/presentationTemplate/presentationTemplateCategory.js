const { connection } = require("../../../../mySql/mySql"); // adjust path
const moment = require('moment-timezone');
const { createNotification } = require("../../../notification/notification.controller");

module.exports = {
  // ➕ Add Presentation Template Category
  addPresentationTemplateCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { category_name, page_number, presentation_template_id } = req.body;

      if (!category_name || !page_number || !presentation_template_id) {
        return res.status(400).send({ status: false, message: "Category name, page number, and presentation template ID are required!" });
      }

      // Validate that the presentation template exists
      let validateTemplateQ = `SELECT id FROM presentation_templates WHERE id = ? AND isActive = 1`;
      let templateData = await connection.query(validateTemplateQ, [presentation_template_id]);

      if (templateData.length === 0) {
        return res.status(400).send({ status: false, message: "Invalid presentation template ID or template is not active!" });
      }

      // Check for duplicate category name under same presentation template
      let validateQ = `SELECT * FROM presentation_template_category WHERE category_name = ? AND presentation_template_id = ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [category_name, presentation_template_id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Category already exists for this presentation template!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let query = `INSERT INTO presentation_template_category (category_name, page_number, presentation_template_id, createdOn, isDeleted) VALUES (?, ?, ?, ?, 0)`;
      const insertResult = await connection.query(query, [category_name, page_number, presentation_template_id, createdOn]);
      console.log("insertResult", insertResult);

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New Presentation Template Category Added",
          `A new Presentation Template Category "${category_name}" has been added to the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Presentation Template Category added successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllPresentationTemplateCategories: async function (req, res) {
    try {
      let query = `SELECT 
        ptc.id, 
        ptc.category_name, 
        ptc.page_number, 
        ptc.presentation_template_id,
        pt.presentation_template,
        pt.year,
        ptc.createdOn 
      FROM presentation_template_category ptc
      LEFT JOIN presentation_templates pt ON ptc.presentation_template_id = pt.id
      WHERE ptc.isDeleted = 0
      ORDER BY ptc.id DESC`;
      let data = await connection.query(query);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getCategoriesByTemplateId: async function (req, res) {
    try {
      let { presentation_template_id } = req.params;

      if (!presentation_template_id) {
        return res.status(400).send({ status: false, message: "Presentation template ID is required!" });
      }

      let query = `SELECT 
        ptc.id, 
        ptc.category_name, 
        ptc.page_number, 
        ptc.presentation_template_id,
        pt.presentation_template,
        pt.year,
        ptc.createdOn 
      FROM presentation_template_category ptc
      LEFT JOIN presentation_templates pt ON ptc.presentation_template_id = pt.id
      WHERE ptc.presentation_template_id = ? AND ptc.isDeleted = 0
      ORDER BY ptc.page_number ASC`;
      let data = await connection.query(query, [presentation_template_id]);

      return res.status(200).send({ status: true, data: data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updatePresentationTemplateCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, category_name, page_number, presentation_template_id } = req.body;

      if (!id || !category_name || !page_number || !presentation_template_id) {
        return res.status(400).send({ status: false, message: "ID, category name, page number, and presentation template ID are required!" });
      }

      let validateTemplateQ = `SELECT id FROM presentation_templates WHERE id = ? AND isActive = 1`;
      let templateData = await connection.query(validateTemplateQ, [presentation_template_id]);

      if (templateData.length === 0) {
        return res.status(400).send({ status: false, message: "Invalid presentation template ID or template is not active!" });
      }

      let validateQ = `SELECT * FROM presentation_template_category WHERE category_name = ? AND presentation_template_id = ? AND id != ? AND isDeleted = 0`;
      let validateData = await connection.query(validateQ, [category_name, presentation_template_id, id]);

      if (validateData.length !== 0) {
        return res.status(200).send({ status: false, message: "Category already exists for this presentation template!" });
      }

      let query = `UPDATE presentation_template_category SET category_name = ?, page_number = ?, presentation_template_id = ? WHERE id = ? AND isDeleted = 0`;
      const updateResult = await connection.query(query, [category_name, page_number, presentation_template_id, id]);

      if (updateResult.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Presentation Template Category not found!" });
      }

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator'");
        const adminIds = admins.map(admin => admin.id);
        const currentUserId = req.decodedToken;
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Presentation Template Category Updated",
          `The Presentation Template Category "${category_name}" has been updated in the PDP master data.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "Presentation Template Category updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deletePresentationTemplateCategory: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required!" });
      }

      // Check if category exists
      let checkQuery = `SELECT id FROM presentation_template_category WHERE id = ? AND isDeleted = 0`;
      let categoryData = await connection.query(checkQuery, [id]);

      if (categoryData.length === 0) {
        return res.status(404).send({ status: false, message: "Presentation Template Category not found!" });
      }

      // Soft delete
      let query = `UPDATE presentation_template_category SET isDeleted = 1 WHERE id = ?`;
      await connection.query(query, [id]);

      return res.status(200).send({ status: true, message: "Presentation Template Category deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  //   // 🔄 Restore Deleted Presentation Template Category
  //   restorePresentationTemplateCategory: async function (req, res) {
  //     try {
  //       let { id } = req.params;

  //       if (!id) {
  //         return res.status(400).send({ status: false, message: "ID is required!" });
  //       }

  //       // Check if category exists and is deleted
  //       let checkQuery = `SELECT id FROM presentation_template_category WHERE id = ? AND isDeleted = 1`;
  //       let categoryData = await connection.query(checkQuery, [id]);

  //       if (categoryData.length === 0) {
  //         return res.status(404).send({ status: false, message: "Deleted Presentation Template Category not found!" });
  //       }

  //       // Restore
  //       let query = `UPDATE presentation_template_category SET isDeleted = 0 WHERE id = ?`;
  //       await connection.query(query, [id]);

  //       return res.status(200).send({ status: true, message: "Presentation Template Category restored successfully!" });
  //     } catch (error) {
  //       return res.status(500).send({ status: false, message: error.message });
  //     }
  //   }
};
