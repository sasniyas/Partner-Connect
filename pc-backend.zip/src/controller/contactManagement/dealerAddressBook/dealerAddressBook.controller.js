const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../../azurestorage/fileUpload");

module.exports = {

    addDealerAddressBook: async function (req, res) {
        try {
            // Debug logging
            console.log('=== Request Body ===');
            console.log('Body:', req.body);
            console.log('Files:', req.files);
            console.log('===================');

            const {
                market_area_id,
                dealer_id,
                dealer_principal_name,
                hq_city,
                hq_state,
                hq_pincode,
                hq_full_address,
                company_website,
                association_with_volvo,
                notes,
                branches,
                brands
            } = req.body;

            // Validate required fields
            if (!market_area_id || !dealer_id || !hq_city || !hq_state || !hq_pincode) {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: market_area_id, dealer_id, hq_city, hq_state, hq_pincode"
                });
            }

            // Parse branches and brands if they are strings (from form-data)
            let parsedBranches = branches;
            let parsedBrands = brands;

            if (typeof branches === 'string') {
                try {
                    parsedBranches = JSON.parse(branches);
                } catch (e) {
                    parsedBranches = [];
                }
            }

            if (typeof brands === 'string') {
                try {
                    parsedBrands = JSON.parse(brands);
                } catch (e) {
                    parsedBrands = [];
                }
            }

            // Handle logo file upload
            let logo_url = "";
            let logoFile = null;
            if (req.files && Array.isArray(req.files)) {
                logoFile = req.files.find(f => f.fieldname === 'logo');
            }

            if (logoFile) {
                logo_url = await uploadFile(logoFile);
            }

            const timestamp = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            // INSERT into parent table
            const insertQuery = `
                INSERT INTO dealer_addressbook_cm (
                    market_area_id, dealer_id, logo_url, dealer_principal_name,
                    hq_city, hq_state, hq_pincode, hq_full_address, company_website,
                    association_with_volvo, notes, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `;

            const result = await connection.query(insertQuery, [
                market_area_id,
                dealer_id,
                logo_url || null,
                dealer_principal_name || null,
                hq_city,
                hq_state,
                hq_pincode,
                hq_full_address || null,
                company_website || null,
                association_with_volvo || null,
                notes || null,
                timestamp,
                timestamp
            ]);

            const dealerAddressBookId = result.insertId;

            // Insert branches if provided
            if (parsedBranches && Array.isArray(parsedBranches) && parsedBranches.length > 0) {
                const branchValues = parsedBranches.map(branch => [
                    dealerAddressBookId,
                    branch.city,
                    branch.state,
                    branch.pincode,
                    branch.full_address || null,
                    timestamp,
                    timestamp
                ]);

                const branchQuery = `
                    INSERT INTO branch_dealer_addressbook_cm (
                        dealer_addressbook_id, city, state, pincode, full_address,
                        created_at, updated_at
                    ) VALUES ?
                `;
                await connection.query(branchQuery, [branchValues]);
            }

            // Insert brands if provided
            if (parsedBrands && Array.isArray(parsedBrands) && parsedBrands.length > 0) {
                // Find all brand logo files
                const allFiles = req.files && Array.isArray(req.files) ? req.files : [];
                // Filter files that belong to 'brandLogos' field
                const brandLogos = allFiles.filter(f => f.fieldname === 'brandLogos');

                for (let i = 0; i < parsedBrands.length; i++) {
                    const brand = parsedBrands[i];
                    let file_url = "";

                    // Logic to match file to brand: 
                    // Since we can't easily map array index to file input index in simple multipart without specific keys,
                    // we will assume the order of files matches the order of brands IF the user uploaded them in order.
                    // BETTER APPROACH: Allow frontend to specific exact index via separate logic, 
                    // but for now, we map by index if available.

                    if (brandLogos[i]) {
                        file_url = await uploadFile(brandLogos[i]);
                    }

                    const brandQuery = `
                        INSERT INTO brand_dealer_addressbook_cm (
                            dealer_addressbook_id, brand_name, file_url, product_segment,
                            product_name, since_when, yoa, location, created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    `;
                    await connection.query(brandQuery, [
                        dealerAddressBookId,
                        brand.brand_name,
                        file_url,
                        brand.product_segment,
                        brand.product_name,
                        brand.since_when || null,
                        brand.yoa || null,
                        brand.location || null,
                        timestamp,
                        timestamp
                    ]);
                }
            }

            return res.status(200).send({
                status: true,
                message: "Dealer address book added successfully",
                data: { id: dealerAddressBookId }
            });

        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateDealerAddressBook: async function (req, res) {
        try {
            const {
                id,
                market_area_id,
                dealer_id,
                dealer_principal_name,
                hq_city,
                hq_state,
                hq_pincode,
                hq_full_address,
                company_website,
                association_with_volvo,
                notes,
                branches,
                brands
            } = req.body;

            // Validate ID
            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            // Check if record exists
            const exists = await connection.query(
                "SELECT id FROM dealer_addressbook_cm WHERE id = ? AND isDeleted = 0",
                [id]
            );

            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer address book not found" });
            }

            // Parse branches and brands if they are strings (from form-data)
            let parsedBranches = branches;
            let parsedBrands = brands;

            if (typeof branches === 'string') {
                try {
                    parsedBranches = JSON.parse(branches);
                } catch (e) {
                    parsedBranches = [];
                }
            }

            if (typeof brands === 'string') {
                try {
                    parsedBrands = JSON.parse(brands);
                } catch (e) {
                    parsedBrands = [];
                }
            }

            // Handle logo file upload
            let logo_url = "";
            let logoFile = null;
            if (req.files && Array.isArray(req.files)) {
                logoFile = req.files.find(f => f.fieldname === 'logo');
            }

            if (logoFile) {
                logo_url = await uploadFile(logoFile);
            }

            const timestamp = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            // Build dynamic update query
            const updateFields = [];
            const updateValues = [];

            if (market_area_id !== undefined) {
                updateFields.push("market_area_id = ?");
                updateValues.push(market_area_id);
            }
            if (dealer_id !== undefined) {
                updateFields.push("dealer_id = ?");
                updateValues.push(dealer_id);
            }
            if (logo_url) {
                updateFields.push("logo_url = ?");
                updateValues.push(logo_url);
            }
            if (dealer_principal_name !== undefined) {
                updateFields.push("dealer_principal_name = ?");
                updateValues.push(dealer_principal_name);
            }
            if (hq_city !== undefined) {
                updateFields.push("hq_city = ?");
                updateValues.push(hq_city);
            }
            if (hq_state !== undefined) {
                updateFields.push("hq_state = ?");
                updateValues.push(hq_state);
            }
            if (hq_pincode !== undefined) {
                updateFields.push("hq_pincode = ?");
                updateValues.push(hq_pincode);
            }
            if (hq_full_address !== undefined) {
                updateFields.push("hq_full_address = ?");
                updateValues.push(hq_full_address);
            }
            if (company_website !== undefined) {
                updateFields.push("company_website = ?");
                updateValues.push(company_website);
            }
            if (association_with_volvo !== undefined) {
                updateFields.push("association_with_volvo = ?");
                updateValues.push(association_with_volvo);
            }
            if (notes !== undefined) {
                updateFields.push("notes = ?");
                updateValues.push(notes);
            }

            if (updateFields.length === 0 && !parsedBranches && !parsedBrands) {
                return res.status(400).send({
                    status: false,
                    message: "No fields to update"
                });
            }

            // Update parent table if there are fields to update
            if (updateFields.length > 0) {
                updateFields.push("updated_at = ?");
                updateValues.push(timestamp);
                updateValues.push(id);

                const updateQuery = `
                    UPDATE dealer_addressbook_cm
                    SET ${updateFields.join(", ")}
                    WHERE id = ?
                `;
                await connection.query(updateQuery, updateValues);
            }

            // Delete existing branches
            await connection.query(
                "DELETE FROM branch_dealer_addressbook_cm WHERE dealer_addressbook_id = ?",
                [id]
            );

            // Delete existing brands
            await connection.query(
                "DELETE FROM brand_dealer_addressbook_cm WHERE dealer_addressbook_id = ?",
                [id]
            );

            // Insert new branches if provided
            if (parsedBranches && Array.isArray(parsedBranches) && parsedBranches.length > 0) {
                const branchValues = parsedBranches.map(branch => [
                    id,
                    branch.city,
                    branch.state,
                    branch.pincode,
                    branch.full_address || null,
                    timestamp,
                    timestamp
                ]);

                const branchQuery = `
                    INSERT INTO branch_dealer_addressbook_cm (
                        dealer_addressbook_id, city, state, pincode, full_address,
                        created_at, updated_at
                    ) VALUES ?
                `;
                await connection.query(branchQuery, [branchValues]);
            }

            // Insert new brands if provided
            if (parsedBrands && Array.isArray(parsedBrands) && parsedBrands.length > 0) {
                // Find all brand logo files
                const allFiles = req.files && Array.isArray(req.files) ? req.files : [];
                // Filter files that belong to 'brandLogos' field
                const brandLogos = allFiles.filter(f => f.fieldname === 'brandLogos');

                for (let i = 0; i < parsedBrands.length; i++) {
                    const brand = parsedBrands[i];
                    let file_url = "";

                    // If there's a corresponding file in the upload
                    if (brandLogos[i]) {
                        file_url = await uploadFile(brandLogos[i]);
                    }

                    const brandQuery = `
                        INSERT INTO brand_dealer_addressbook_cm (
                            dealer_addressbook_id, brand_name, file_url, product_segment,
                            product_name, since_when, yoa, location, created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    `;
                    await connection.query(brandQuery, [
                        id,
                        brand.brand_name,
                        file_url,
                        brand.product_segment,
                        brand.product_name,
                        brand.since_when || null,
                        brand.yoa || null,
                        brand.location || null,
                        timestamp,
                        timestamp
                    ]);
                }
            }

            return res.status(200).send({
                status: true,
                message: "Dealer address book updated successfully"
            });

        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllDealerAddressBooks: async function (req, res) {
        try {
            const query = `
                SELECT 
                    dab.*,
                    ma.marketarea as market_area_name,
                    dm.dealerName as dealer_name
                FROM dealer_addressbook_cm dab
                LEFT JOIN market_area ma ON dab.market_area_id = ma.id
                LEFT JOIN dealer_master dm ON dab.dealer_id = dm.id
                WHERE dab.isDeleted = 0
                ORDER BY dab.id DESC
            `;

            const data = await connection.query(query);

            if (data.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "No dealer address books found",
                    data: []
                });
            }

            // Fetch branches and brands for each record
            const detailedData = await Promise.all(data.map(async (item) => {
                // Get branches
                const branchQuery = `
                    SELECT * FROM branch_dealer_addressbook_cm 
                    WHERE dealer_addressbook_id = ? AND isDeleted = 0
                `;
                const branches = await connection.query(branchQuery, [item.id]);

                // Get brands
                const brandQuery = `
                    SELECT * FROM brand_dealer_addressbook_cm 
                    WHERE dealer_addressbook_id = ? AND isDeleted = 0
                `;
                const brands = await connection.query(brandQuery, [item.id]);

                return {
                    ...item,
                    branches: branches,
                    brands: brands
                };
            }));

            return res.status(200).send({
                status: true,
                message: "Dealer address books retrieved successfully",
                data: detailedData
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getDealerAddressBookById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            // Get parent data
            const parentQuery = `
                SELECT 
                    dab.*,
                    ma.marketarea as market_area_name,
                    dm.dealerName as dealer_name
                FROM dealer_addressbook_cm dab
                LEFT JOIN market_area ma ON dab.market_area_id = ma.id
                LEFT JOIN dealer_master dm ON dab.dealer_id = dm.id
                WHERE dab.id = ? AND dab.isDeleted = 0
            `;

            const parentData = await connection.query(parentQuery, [id]);

            if (parentData.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer address book not found" });
            }

            // Get branches
            const branchQuery = `
                SELECT * FROM branch_dealer_addressbook_cm
                WHERE dealer_addressbook_id = ? AND isDeleted = 0
                ORDER BY id ASC
            `;
            const branches = await connection.query(branchQuery, [id]);

            // Get brands
            const brandQuery = `
                SELECT * FROM brand_dealer_addressbook_cm
                WHERE dealer_addressbook_id = ? AND isDeleted = 0
                ORDER BY id ASC
            `;
            const brands = await connection.query(brandQuery, [id]);

            const result = {
                ...parentData[0],
                branches: branches,
                brands: brands
            };

            return res.status(200).send({
                status: true,
                message: "Dealer address book retrieved successfully",
                data: result
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteDealerAddressBook: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM dealer_addressbook_cm WHERE id = ? AND isDeleted = 0",
                [id]
            );

            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer address book not found" });
            }

            const timestamp = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            // Soft delete parent
            await connection.query(
                "UPDATE dealer_addressbook_cm SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [timestamp, id]
            );

            // Soft delete branches
            await connection.query(
                "UPDATE branch_dealer_addressbook_cm SET isDeleted = 1, isActive = 0, updated_at = ? WHERE dealer_addressbook_id = ?",
                [timestamp, id]
            );

            // Soft delete brands
            await connection.query(
                "UPDATE brand_dealer_addressbook_cm SET isDeleted = 1, isActive = 0, updated_at = ? WHERE dealer_addressbook_id = ?",
                [timestamp, id]
            );

            return res.status(200).send({
                status: true,
                message: "Dealer address book deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleDealerAddressBookStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const data = await connection.query(
                "SELECT isActive FROM dealer_addressbook_cm WHERE id = ? AND isDeleted = 0",
                [id]
            );

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer address book not found" });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const timestamp = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE dealer_addressbook_cm SET isActive = ?, updated_at = ? WHERE id = ?",
                [newStatus, timestamp, id]
            );

            return res.status(200).send({
                status: true,
                message: `Dealer address book ${newStatus ? "enabled" : "disabled"} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    bulkAddDealerAddressBooks: async function (req, res) {
        try {
            const { rows } = req.body;

            if (!rows || !Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
            }

            const { data: validRows, error: invalidCount } = validateDealerAddressBookRows(rows);

            if (validRows.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
                });
            }

            const timestamp = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const insertValues = validRows.map(row => [
                row.market_area_id,
                row.dealer_id,
                "", // logo_url - empty string as per requirement
                row.dealer_principal_name || null,
                row.hq_city,
                row.hq_state,
                row.hq_pincode,
                row.hq_full_address || null,
                row.company_website || null,
                row.association_with_volvo || null,
                row.notes || null,
                timestamp,
                timestamp
            ]);

            const query = `
                INSERT INTO dealer_addressbook_cm (
                    market_area_id, dealer_id, logo_url, dealer_principal_name,
                    hq_city, hq_state, hq_pincode, hq_full_address, company_website,
                    association_with_volvo, notes, created_at, updated_at
                ) VALUES ?
            `;

            await connection.query(query, [insertValues]);

            let message = `${validRows.length} Dealer address book(s) added successfully!`;
            if (invalidCount > 0) {
                message += ` ${invalidCount} invalid entry/entries were skipped.`;
            }

            return res.status(200).send({
                status: true,
                message: message,
                data: {
                    inserted: validRows.length,
                    invalid: invalidCount
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};

const validateDealerAddressBookRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;

    rows.forEach((row) => {
        const {
            market_area_id,
            dealer_id,
            hq_city,
            hq_state,
            hq_pincode
        } = row;

        // Check required fields
        if (!market_area_id || !dealer_id || !hq_city || !hq_state || !hq_pincode) {
            invalidCount++;
            return;
        }

        validRows.push(row);
    });

    return { data: validRows, error: invalidCount };
};
