const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../../azurestorage/fileUpload");

module.exports = {

    addDealerUserDetail: async function (req, res) {
        try {
            const {
                market_area_id,
                dealer_id,
                firstName,
                lastName,
                vdn_id,
                phone,
                email,
                work_location,
                joining_date,
                yoe,
                notes,
                departmentId,
                designationId,
                resignation_date,
                reporting_manager
            } = req.body;

            if (!market_area_id || !dealer_id || !firstName || !lastName || !vdn_id || !phone || !email || !work_location || !joining_date || !yoe || !departmentId || !designationId) {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: market_area_id, dealer_id, firstName, lastName, vdn_id, phone, email, work_location, joining_date, yoe, departmentId, designationId"
                });
            }


            let image_url = null;
            if (req.files && req.files.length > 0) {
                image_url = await uploadFile(req.files[0]);
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const insertQuery = `
                INSERT INTO dealer_userdetails (
                    market_area_id, dealer_id, firstName, lastName, vdn_id, phone, email,
                    work_location, joining_date, yoe, notes, departmentId, designationId,
                    resignation_date, image_url, reporting_manager,
                    created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `;

            await connection.query(insertQuery, [
                market_area_id,
                dealer_id,
                firstName,
                lastName,
                vdn_id,
                phone,
                email,
                work_location,
                joining_date,
                yoe,
                notes || null,
                departmentId,
                designationId,
                resignation_date || null,
                image_url,
                reporting_manager || null,
                createdAt,
                createdAt
            ]);

            return res.status(200).send({
                status: true,
                message: "Dealer user detail added successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllDealerUserDetails: async function (req, res) {
        try {
            const query = `
                SELECT 
                    du.*,
                    ma.marketarea as market_area_name,
                    dm.dealerName as dealer_name,
                    dept.name as department_name,
                    desg.name as designation_name,
                    CONCAT(rm.firstName, ' ', rm.lastName) as reporting_manager_name
                FROM dealer_userdetails du
                LEFT JOIN market_area ma ON du.market_area_id = ma.id
                LEFT JOIN dealer_master dm ON du.dealer_id = dm.id
                LEFT JOIN department dept ON du.departmentId = dept.id
                LEFT JOIN designation desg ON du.designationId = desg.id
                LEFT JOIN dealer_userdetails rm ON du.reporting_manager = rm.id
                WHERE du.isDeleted = 0
                ORDER BY du.id DESC
            `;

            const data = await connection.query(query);

            return res.status(200).send({
                status: true,
                message: "Dealer user details list retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getDealerUserDetailById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const query = `
                SELECT 
                    du.*,
                    ma.marketarea as market_area_name,
                    dm.dealerName as dealer_name,
                    dept.name as department_name,
                    desg.name as designation_name,
                    CONCAT(rm.firstName, ' ', rm.lastName) as reporting_manager_name
                FROM dealer_userdetails du
                LEFT JOIN market_area ma ON du.market_area_id = ma.id
                LEFT JOIN dealer_master dm ON du.dealer_id = dm.id
                LEFT JOIN department dept ON du.departmentId = dept.id
                LEFT JOIN designation desg ON du.designationId = desg.id
                LEFT JOIN dealer_userdetails rm ON du.reporting_manager = rm.id
                WHERE du.id = ? AND du.isDeleted = 0
            `;

            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer user detail not found" });
            }

            return res.status(200).send({
                status: true,
                message: "Dealer user detail retrieved",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateDealerUserDetail: async function (req, res) {
        try {
            const {
                id,
                market_area_id,
                dealer_id,
                firstName,
                lastName,
                vdn_id,
                phone,
                email,
                work_location,
                joining_date,
                yoe,
                notes,
                departmentId,
                designationId,
                isActive,
                resignation_date,
                reporting_manager
            } = req.body;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM dealer_userdetails WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer user detail not found" });
            }

            const updateFields = [];
            const updateValues = [];

            if (market_area_id !== undefined) {
                updateFields.push("market_area_id = ?");
                updateValues.push(market_area_id);
            }
            if (dealer_id !== undefined) {
                updateFields.push("dealer_id = ?");
                updateValues.push(dealer_id);
            }
            if (firstName !== undefined) {
                updateFields.push("firstName = ?");
                updateValues.push(firstName);
            }
            if (lastName !== undefined) {
                updateFields.push("lastName = ?");
                updateValues.push(lastName);
            }
            if (vdn_id !== undefined) {
                updateFields.push("vdn_id = ?");
                updateValues.push(vdn_id);
            }
            if (phone !== undefined) {
                updateFields.push("phone = ?");
                updateValues.push(phone);
            }
            if (email !== undefined) {
                updateFields.push("email = ?");
                updateValues.push(email);
            }
            if (work_location !== undefined) {
                updateFields.push("work_location = ?");
                updateValues.push(work_location);
            }
            if (joining_date !== undefined) {
                updateFields.push("joining_date = ?");
                updateValues.push(joining_date);
            }
            if (yoe !== undefined) {
                updateFields.push("yoe = ?");
                updateValues.push(yoe);
            }
            if (notes !== undefined) {
                updateFields.push("notes = ?");
                updateValues.push(notes);
            }
            if (departmentId !== undefined) {
                updateFields.push("departmentId = ?");
                updateValues.push(departmentId);
            }
            if (designationId !== undefined) {
                updateFields.push("designationId = ?");
                updateValues.push(designationId);
            }
            if (isActive !== undefined) {
                updateFields.push("isActive = ?");
                updateValues.push(isActive);
            }
            if (resignation_date !== undefined) {
                updateFields.push("resignation_date = ?");
                updateValues.push(resignation_date);
            }
            if (reporting_manager !== undefined) {
                updateFields.push("reporting_manager = ?");
                updateValues.push(reporting_manager);
            }

            if (req.files && req.files.length > 0) {
                const image_url = await uploadFile(req.files[0]);
                updateFields.push("image_url = ?");
                updateValues.push(image_url);
            }

            if (updateFields.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "No fields to update"
                });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("updated_at = ?");
            updateValues.push(updatedAt);

            updateValues.push(id);

            const updateQuery = `
                UPDATE dealer_userdetails
                SET ${updateFields.join(", ")}
                WHERE id = ?
            `;

            await connection.query(updateQuery, updateValues);

            return res.status(200).send({
                status: true,
                message: "Dealer user detail updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteDealerUserDetail: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM dealer_userdetails WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer user detail not found" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE dealer_userdetails SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: "Dealer user detail deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleDealerUserDetailStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const data = await connection.query(
                "SELECT isActive FROM dealer_userdetails WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Dealer user detail not found" });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE dealer_userdetails SET isActive = ?, updated_at = ? WHERE id = ?",
                [newStatus, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Dealer user detail ${newStatus ? "enabled" : "disabled"} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    bulkAddDealerUserDetails: async function (req, res) {
        try {
            const { rows } = req.body;

            if (!rows || !Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
            }

            const { data: validRows, error: invalidCount } = validateDealerUserRows(rows);

            if (validRows.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
                });
            }

            const emails = validRows.map(row => row.email);
            const existingEmailsQuery = `
                SELECT email FROM dealer_userdetails WHERE email IN (${emails.map(() => '?').join(',')}) AND isDeleted = 0
            `;
            const existingEmails = await connection.query(existingEmailsQuery, emails);
            const existingEmailsSet = new Set(existingEmails.map(e => e.email.toLowerCase()));

            const rowsToInsert = validRows.filter(row => !existingEmailsSet.has(row.email));
            const duplicateEmailCount = validRows.length - rowsToInsert.length;
            const totalInvalidCount = invalidCount + duplicateEmailCount;

            if (rowsToInsert.length === 0) {
                return res.status(200).send({
                    status: false,
                    message: `All valid rows have duplicate emails in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const insertValues = rowsToInsert.map(row => [
                row.market_area_id,
                row.dealer_id,
                row.firstName,
                row.lastName,
                row.vdn_id,
                row.phone,
                row.email,
                row.work_location,
                row.joining_date,
                row.yoe,
                row.notes || null,
                row.departmentId,
                row.designationId,
                row.resignation_date || null,
                row.image_url || null,
                row.reporting_manager || null,
                createdAt,
                createdAt
            ]);

            const query = `
                INSERT INTO dealer_userdetails (
                    market_area_id, dealer_id, firstName, lastName, vdn_id, phone, email,
                    work_location, joining_date, yoe, notes, departmentId, designationId,
                    resignation_date, image_url, reporting_manager,
                    created_at, updated_at
                )
                VALUES ?
            `;
            await connection.query(query, [insertValues]);

            let message = `${rowsToInsert.length} Dealer user detail(s) added successfully!`;
            if (totalInvalidCount > 0) {
                message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
            }

            return res.status(200).send({
                status: true,
                message: message,
                data: {
                    inserted: rowsToInsert.length,
                    invalid: totalInvalidCount
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};

const validateDealerUserRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenEmails = new Set();

    rows.forEach((row) => {
        const {
            market_area_id,
            dealer_id,
            firstName,
            lastName,
            vdn_id,
            phone,
            email,
            work_location,
            joining_date,
            yoe,
            departmentId,
            designationId,
            reporting_manager
        } = row;

        if (!market_area_id || !dealer_id || !firstName || !lastName || !vdn_id || !phone || !email || !work_location || !joining_date || !yoe || !departmentId || !designationId) {
            invalidCount++;
            return;
        }

        const trimmedEmail = email.trim().toLowerCase();
        if (trimmedEmail === "" || seenEmails.has(trimmedEmail)) {
            invalidCount++;
            return;
        }
        seenEmails.add(trimmedEmail);

        validRows.push({
            ...row,
            email: trimmedEmail
        });
    });

    return { data: validRows, error: invalidCount };
};
