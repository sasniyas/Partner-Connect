const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {

    addVolvoUserDetail: async function (req, res) {
        try {
            const {
                firstName,
                lastName,
                vdn_id,
                phone,
                email,
                work_location,
                notes,
                departmentId,
                designationId
            } = req.body;

            if (!firstName || !lastName || !vdn_id || !phone || !email || !work_location || !departmentId || !designationId) {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: firstName, lastName, vdn_id, phone, email, work_location, departmentId, designationId"
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const insertQuery = `
                INSERT INTO volvo_userdetails (
                    firstName, lastName, vdn_id, phone, email,
                    work_location, notes, departmentId, designationId,
                    created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `;

            await connection.query(insertQuery, [
                firstName,
                lastName,
                vdn_id,
                phone,
                email,
                work_location,
                notes || null,
                departmentId,
                designationId,
                createdAt,
                createdAt
            ]);

            return res.status(200).send({
                status: true,
                message: "Volvo user detail added successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllVolvoUserDetails: async function (req, res) {
        try {
            const query = `
                SELECT 
                    vu.*,
                    dept.name as department_name,
                    desg.name as designation_name
                FROM volvo_userdetails vu
                LEFT JOIN departments dept ON vu.departmentId = dept.id
                LEFT JOIN designation desg ON vu.designationId = desg.id
                WHERE vu.isDeleted = 0
                ORDER BY vu.id DESC
            `;

            const data = await connection.query(query);

            return res.status(200).send({
                status: true,
                message: "Volvo user details list retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getVolvoUserDetailById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const query = `
                SELECT 
                    vu.*,
                    dept.name as department_name,
                    desg.name as designation_name
                FROM volvo_userdetails vu
                LEFT JOIN departments dept ON vu.departmentId = dept.id
                LEFT JOIN designation desg ON vu.designationId = desg.id
                WHERE vu.id = ? AND vu.isDeleted = 0
            `;

            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Volvo user detail not found" });
            }

            return res.status(200).send({
                status: true,
                message: "Volvo user detail retrieved",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateVolvoUserDetail: async function (req, res) {
        try {
            const {
                id,
                firstName,
                lastName,
                vdn_id,
                phone,
                email,
                work_location,
                notes,
                departmentId,
                designationId,
                isActive
            } = req.body;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM volvo_userdetails WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Volvo user detail not found" });
            }

            const updateFields = [];
            const updateValues = [];

            if (firstName !== undefined) {
                updateFields.push("firstName = ?");
                updateValues.push(firstName);
            }
            if (lastName !== undefined) {
                updateFields.push("lastName = ?");
                updateValues.push(lastName);
            }
            if (vdn_id !== undefined) {
                updateFields.push("vdn_id = ?");
                updateValues.push(vdn_id);
            }
            if (phone !== undefined) {
                updateFields.push("phone = ?");
                updateValues.push(phone);
            }
            if (email !== undefined) {
                updateFields.push("email = ?");
                updateValues.push(email);
            }
            if (work_location !== undefined) {
                updateFields.push("work_location = ?");
                updateValues.push(work_location);
            }
            if (notes !== undefined) {
                updateFields.push("notes = ?");
                updateValues.push(notes);
            }
            if (departmentId !== undefined) {
                updateFields.push("departmentId = ?");
                updateValues.push(departmentId);
            }
            if (designationId !== undefined) {
                updateFields.push("designationId = ?");
                updateValues.push(designationId);
            }
            if (isActive !== undefined) {
                updateFields.push("isActive = ?");
                updateValues.push(isActive);
            }

            if (updateFields.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "No fields to update"
                });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("updated_at = ?");
            updateValues.push(updatedAt);

            updateValues.push(id);

            const updateQuery = `
                UPDATE volvo_userdetails
                SET ${updateFields.join(", ")}
                WHERE id = ?
            `;

            await connection.query(updateQuery, updateValues);

            return res.status(200).send({
                status: true,
                message: "Volvo user detail updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteVolvoUserDetail: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM volvo_userdetails WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Volvo user detail not found" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE volvo_userdetails SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: "Volvo user detail deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleVolvoUserDetailStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const data = await connection.query(
                "SELECT isActive FROM volvo_userdetails WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Volvo user detail not found" });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE volvo_userdetails SET isActive = ?, updated_at = ? WHERE id = ?",
                [newStatus, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Volvo user detail ${newStatus ? "enabled" : "disabled"} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    bulkAddVolvoUserDetails: async function (req, res) {
        try {
            const { rows } = req.body;

            if (!rows || !Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
            }

            const { data: validRows, error: invalidCount } = validateVolvoUserRows(rows);

            if (validRows.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
                });
            }

            const emails = validRows.map(row => row.email);
            const existingEmailsQuery = `
                SELECT email FROM volvo_userdetails WHERE email IN (${emails.map(() => '?').join(',')}) AND isDeleted = 0
            `;
            const existingEmails = await connection.query(existingEmailsQuery, emails);
            const existingEmailsSet = new Set(existingEmails.map(e => e.email.toLowerCase()));

            const rowsToInsert = validRows.filter(row => !existingEmailsSet.has(row.email));
            const duplicateEmailCount = validRows.length - rowsToInsert.length;
            const totalInvalidCount = invalidCount + duplicateEmailCount;

            if (rowsToInsert.length === 0) {
                return res.status(200).send({
                    status: false,
                    message: `All valid rows have duplicate emails in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const insertValues = rowsToInsert.map(row => [
                row.firstName,
                row.lastName,
                row.vdn_id,
                row.phone,
                row.email,
                row.work_location,
                row.notes || null,
                row.departmentId,
                row.designationId,
                createdAt,
                createdAt
            ]);

            const query = `
                INSERT INTO volvo_userdetails (
                    firstName, lastName, vdn_id, phone, email,
                    work_location, notes, departmentId, designationId,
                    created_at, updated_at
                )
                VALUES ?
            `;
            await connection.query(query, [insertValues]);

            let message = `${rowsToInsert.length} Volvo user detail(s) added successfully!`;
            if (totalInvalidCount > 0) {
                message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
            }

            return res.status(200).send({
                status: true,
                message: message,
                data: {
                    inserted: rowsToInsert.length,
                    invalid: totalInvalidCount
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};

const validateVolvoUserRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenEmails = new Set();

    rows.forEach((row) => {
        const {
            firstName,
            lastName,
            vdn_id,
            phone,
            email,
            work_location,
            departmentId,
            designationId
        } = row;

        if (!firstName || !lastName || !vdn_id || !phone || !email || !work_location || !departmentId || !designationId) {
            invalidCount++;
            return;
        }

        const trimmedEmail = email.trim().toLowerCase();
        if (trimmedEmail === "" || seenEmails.has(trimmedEmail)) {
            invalidCount++;
            return;
        }
        seenEmails.add(trimmedEmail);

        validRows.push({
            ...row,
            email: trimmedEmail
        });
    });

    return { data: validRows, error: invalidCount };
};
