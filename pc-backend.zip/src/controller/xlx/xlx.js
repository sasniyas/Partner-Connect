const {uploadFile}=require("../azurestorage/xlxFileUpload");

module.exports = {
xlxFiles: async function (req, res) {
  try {
    let sampleFileUrl = null;

    if (req.files && req.files.length) {
      const file = req.files[0];


      const allowedExtensions = [".xlsx", ".xls", ".csv"];
      const path = require("path");

      const ext = path.extname(file.originalname).toLowerCase();

      // ❌ Invalid file
      if (!allowedExtensions.includes(ext)) {
        return res.status(400).send({
          status: false,
          message: "Only Excel (.xls, .xlsx) or CSV files are allowed"
        });
      }

      // ✅ Upload
      sampleFileUrl = await uploadFile(file);
    }

    return res.status(200).send({
      status: true,
      message: "Default Template updated successfully!",
      data: sampleFileUrl
    });

  } catch (error) {
    return res.status(500).send({
      status: false,
      message: error.message
    });
  }
},

};

