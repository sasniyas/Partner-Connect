const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../../azurestorage/fileUpload");

module.exports = {

    addProcessManagementProcess: async function (req, res) {
        try {
            const {
                process_id,
                process_name,
                department_id,
                process_owner,
                description
            } = req.body;

            const uploaded_by = req.decodedToken;

            if (!process_id || !process_name || !department_id || !process_owner || !description) {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: process_id, process_name, department_id, process_owner, description"
                });
            }

            if (!req.files || req.files.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "Process file is required!"
                });
            }

            const file = req.files[0];
            const processFileUrl = await uploadFile(file);

            if (processFileUrl instanceof Error) {
                return res.status(500).send({ status: false, message: "File upload failed: " + processFileUrl.message });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const insertQuery = `
                INSERT INTO process_management_process (
                    process_id, process_name, department_id, process_owner, 
                    description, process_file, uploaded_by, last_modified_by,
                    created_at, updated_at, isActive, isDeleted
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0)
            `;

            await connection.query(insertQuery, [
                process_id,
                process_name,
                department_id,
                process_owner,
                description,
                processFileUrl,
                uploaded_by,
                uploaded_by, // last_modified_by initially same as uploaded_by
                createdAt,
                createdAt
            ]);

            return res.status(200).send({
                status: true,
                message: "Process management process added successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllProcessManagementProcesses: async function (req, res) {
        try {
            const query = `
                SELECT 
                    pmp.*,
                    dept.name as department_name,
                    u_up.firstName as uploader_first_name,
                    u_up.lastName as uploader_last_name,
                    u_mod.firstName as modifier_first_name,
                    u_mod.lastName as modifier_last_name
                FROM process_management_process pmp
                LEFT JOIN department dept ON pmp.department_id = dept.id
                LEFT JOIN userdetails u_up ON pmp.uploaded_by = u_up.id
                LEFT JOIN userdetails u_mod ON pmp.last_modified_by = u_mod.id
                WHERE pmp.isDeleted = 0
                ORDER BY pmp.id DESC
            `;

            const data = await connection.query(query);

            return res.status(200).send({
                status: true,
                message: "Process management processes list retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getProcessManagementProcessById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const query = `
                SELECT 
                    pmp.*,
                    dept.name as department_name,
                    u_up.firstName as uploader_first_name,
                    u_up.lastName as uploader_last_name,
                    u_mod.firstName as modifier_first_name,
                    u_mod.lastName as modifier_last_name
                FROM process_management_process pmp
                LEFT JOIN department dept ON pmp.department_id = dept.id
                LEFT JOIN userdetails u_up ON pmp.uploaded_by = u_up.id
                LEFT JOIN userdetails u_mod ON pmp.last_modified_by = u_mod.id
                WHERE pmp.id = ? AND pmp.isDeleted = 0
            `;

            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Process management process not found" });
            }

            return res.status(200).send({
                status: true,
                message: "Process management process retrieved",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateProcessManagementProcess: async function (req, res) {
        try {
            const {
                id,
                process_id,
                process_name,
                department_id,
                process_owner,
                description,
                isActive
            } = req.body;

            const last_modified_by = req.decodedToken;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id, process_file FROM process_management_process WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Process management process not found" });
            }

            let processFileUrl = exists[0].process_file;
            if (req.files && req.files.length > 0) {
                const file = req.files[0];
                const uploadResult = await uploadFile(file);
                if (uploadResult instanceof Error) {
                    return res.status(500).send({ status: false, message: "File upload failed: " + uploadResult.message });
                }
                processFileUrl = uploadResult;
            }

            const updateFields = [];
            const updateValues = [];

            if (process_id !== undefined) {
                updateFields.push("process_id = ?");
                updateValues.push(process_id);
            }
            if (process_name !== undefined) {
                updateFields.push("process_name = ?");
                updateValues.push(process_name);
            }
            if (department_id !== undefined) {
                updateFields.push("department_id = ?");
                updateValues.push(department_id);
            }
            if (process_owner !== undefined) {
                updateFields.push("process_owner = ?");
                updateValues.push(process_owner);
            }
            if (description !== undefined) {
                updateFields.push("description = ?");
                updateValues.push(description);
            }
            if (processFileUrl !== undefined) {
                updateFields.push("process_file = ?");
                updateValues.push(processFileUrl);
            }
            if (isActive !== undefined) {
                updateFields.push("isActive = ?");
                updateValues.push(isActive);
            }

            // Always update last_modified_by and updated_at
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("last_modified_by = ?");
            updateValues.push(last_modified_by);
            updateFields.push("updated_at = ?");
            updateValues.push(updatedAt);

            updateValues.push(id);

            const updateQuery = `
                UPDATE process_management_process
                SET ${updateFields.join(", ")}
                WHERE id = ?
            `;

            await connection.query(updateQuery, updateValues);

            return res.status(200).send({
                status: true,
                message: "Process management process updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteProcessManagementProcess: async function (req, res) {
        try {
            const { id } = req.params;
            const last_modified_by = req.decodedToken;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM process_management_process WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Process management process not found" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE process_management_process SET isDeleted = 1, isActive = 0, last_modified_by = ?, updated_at = ? WHERE id = ?",
                [last_modified_by, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: "Process management process deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleProcessManagementProcessStatus: async function (req, res) {
        try {
            const { id } = req.params;
            const last_modified_by = req.decodedToken;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const data = await connection.query(
                "SELECT isActive FROM process_management_process WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Process management process not found" });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE process_management_process SET isActive = ?, last_modified_by = ?, updated_at = ? WHERE id = ?",
                [newStatus, last_modified_by, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Process management process ${newStatus ? "enabled" : "disabled"} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    bulkAddProcessManagementProcesses: async function (req, res) {
        try {
            const { rows } = req.body;
            const uploaded_by = req.decodedToken;

            if (!rows || !Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
            }

            const { data: validRows, error: invalidCount } = validateProcessManagementProcessRows(rows);

            if (validRows.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const processFileUrl = ""; // Empty URL as requested

            const insertValues = validRows.map(row => [
                row.process_id,
                row.process_name,
                row.department_id,
                row.process_owner,
                row.description,
                processFileUrl,
                uploaded_by,
                uploaded_by, // last_modified_by initially same as uploaded_by
                createdAt,
                createdAt,
                1, // isActive
                0  // isDeleted
            ]);

            const query = `
                INSERT INTO process_management_process (
                    process_id, process_name, department_id, process_owner, 
                    description, process_file, uploaded_by, last_modified_by,
                    created_at, updated_at, isActive, isDeleted
                )
                VALUES ?
            `;
            await connection.query(query, [insertValues]);

            let message = `${validRows.length} Process management process(s) added successfully!`;
            if (invalidCount > 0) {
                message += ` ${invalidCount} invalid entry/entries were skipped.`;
            }

            return res.status(200).send({
                status: true,
                message: message,
                data: {
                    inserted: validRows.length,
                    invalid: invalidCount
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};

const validateProcessManagementProcessRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;

    rows.forEach((row) => {
        const {
            process_id,
            process_name,
            department_id,
            process_owner,
            description
        } = row;

        if (!process_id || !process_name || !department_id || !process_owner || !description) {
            invalidCount++;
            return;
        }

        validRows.push(row);
    });

    return { data: validRows, error: invalidCount };
};
