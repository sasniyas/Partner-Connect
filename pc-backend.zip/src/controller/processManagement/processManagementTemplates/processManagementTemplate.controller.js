const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../../azurestorage/fileUpload");

module.exports = {

    addProcessManagementTemplate: async function (req, res) {
        try {
            const {
                template_name,
                department_id,
                description,
                valid_till
            } = req.body;

            if (!template_name || !department_id || !description || !valid_till) {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: template_name, department_id, description, valid_till"
                });
            }

            if (!req.files || req.files.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "Template file is required!"
                });
            }

            const file = req.files[0];
            const templateUrl = await uploadFile(file);

            if (templateUrl instanceof Error) {
                return res.status(500).send({ status: false, message: "File upload failed: " + templateUrl.message });
            }
            let userId = req.decodedToken;

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const insertQuery = `
                INSERT INTO process_management_templates (
                    template_name, department_id, description, template_file,
                    valid_till, uploaded_by, created_at, updated_at, isActive, isDeleted
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 0)
            `;

            await connection.query(insertQuery, [
                template_name,
                department_id,
                description,
                templateUrl,
                valid_till,
                userId,
                createdAt,
                createdAt
            ]);

            return res.status(200).send({
                status: true,
                message: "Process management template added successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllProcessManagementTemplates: async function (req, res) {
        try {
            const query = `
                SELECT 
                    pmt.*,
                    dept.name as department_name,
                    ud.firstName as uploader_first_name,
                    ud.lastName as uploader_last_name
                FROM process_management_templates pmt
                LEFT JOIN department dept ON pmt.department_id = dept.id
                LEFT JOIN userdetails ud ON pmt.uploaded_by = ud.id
                WHERE pmt.isDeleted = 0
                ORDER BY pmt.id DESC
            `;

            const data = await connection.query(query);

            return res.status(200).send({
                status: true,
                message: "Process management templates list retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getProcessManagementTemplateById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const query = `
                SELECT 
                    pmt.*,
                    dept.name as department_name,
                    ud.firstName as uploader_first_name,
                    ud.lastName as uploader_last_name
                FROM process_management_templates pmt
                LEFT JOIN department dept ON pmt.department_id = dept.id
                LEFT JOIN userdetails ud ON pmt.uploaded_by = ud.id
                WHERE pmt.id = ? AND pmt.isDeleted = 0
            `;

            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Process management template not found" });
            }

            return res.status(200).send({
                status: true,
                message: "Process management template retrieved",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateProcessManagementTemplate: async function (req, res) {
        try {
            const {
                id,
                template_name,
                department_id,
                description,
                valid_till,
                isActive
            } = req.body;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id, template_file FROM process_management_templates WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Process management template not found" });
            }

            let templateUrl = exists[0].template_file;
            if (req.files && req.files.length > 0) {
                const file = req.files[0];
                const uploadResult = await uploadFile(file);
                if (uploadResult instanceof Error) {
                    return res.status(500).send({ status: false, message: "File upload failed: " + uploadResult.message });
                }
                templateUrl = uploadResult;
            }

            let userId = req.decodedToken;

            const updateFields = [];
            const updateValues = [];

            if (template_name !== undefined) {
                updateFields.push("template_name = ?");
                updateValues.push(template_name);
            }
            if (department_id !== undefined) {
                updateFields.push("department_id = ?");
                updateValues.push(department_id);
            }
            if (description !== undefined) {
                updateFields.push("description = ?");
                updateValues.push(description);
            }
            if (templateUrl !== undefined) {
                updateFields.push("template_file = ?");
                updateValues.push(templateUrl);
            }
            if (valid_till !== undefined) {
                updateFields.push("valid_till = ?");
                updateValues.push(valid_till);
            }
            if (userId !== undefined) {
                updateFields.push("uploaded_by = ?");
                updateValues.push(userId);
            }
            if (isActive !== undefined) {
                updateFields.push("isActive = ?");
                updateValues.push(isActive);
            }

            if (updateFields.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "No fields to update"
                });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("updated_at = ?");
            updateValues.push(updatedAt);

            updateValues.push(id);

            const updateQuery = `
                UPDATE process_management_templates
                SET ${updateFields.join(", ")}
                WHERE id = ?
            `;

            await connection.query(updateQuery, updateValues);

            return res.status(200).send({
                status: true,
                message: "Process management template updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteProcessManagementTemplate: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM process_management_templates WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Process management template not found" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE process_management_templates SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: "Process management template deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleProcessManagementTemplateStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const data = await connection.query(
                "SELECT isActive FROM process_management_templates WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Process management template not found" });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE process_management_templates SET isActive = ?, updated_at = ? WHERE id = ?",
                [newStatus, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Process management template ${newStatus ? "enabled" : "disabled"} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    /*
    * Demo Request Body
    * {
    *  "rows": [
    *      {
    *          "template_name": "Template 1",
    *          "department_id": 1,
    *          "description": "Description 1",
    *          "valid_till": "2023-12-31"
    *      },
    *      {
    *          "template_name": "Template 2",
    *          "department_id": 2,
    *          "description": "Description 2",
    *          "valid_till": "2023-12-31"
    *      }
    *  ]
    * }
    */
    bulkAddProcessManagementTemplates: async function (req, res) {
        try {
            const { rows } = req.body;
            const uploaded_by = req.decodedToken;

            if (!rows || !Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
            }

            const { data: validRows, error: invalidCount } = validateProcessManagementTemplateRows(rows);

            if (validRows.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const templateUrl = ""; // Empty URL as requested

            const insertValues = validRows.map(row => [
                row.template_name,
                row.department_id,
                row.description,
                templateUrl,
                row.valid_till,
                uploaded_by,
                createdAt,
                createdAt,
                1, // isActive
                0  // isDeleted
            ]);

            const query = `
                INSERT INTO process_management_templates (
                    template_name, department_id, description, template_file,
                    valid_till, uploaded_by, created_at, updated_at, isActive, isDeleted
                )
                VALUES ?
            `;
            await connection.query(query, [insertValues]);

            let message = `${validRows.length} Process management template(s) added successfully!`;
            if (invalidCount > 0) {
                message += ` ${invalidCount} invalid entry/entries were skipped.`;
            }

            return res.status(200).send({
                status: true,
                message: message,
                data: {
                    inserted: validRows.length,
                    invalid: invalidCount
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};

const validateProcessManagementTemplateRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;

    rows.forEach((row) => {
        const {
            template_name,
            department_id,
            description,
            valid_till
        } = row;

        if (!template_name || !department_id || !description || !valid_till) {
            invalidCount++;
            return;
        }

        validRows.push(row);
    });

    return { data: validRows, error: invalidCount };
};
