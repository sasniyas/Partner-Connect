const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../../azurestorage/fileUpload");

module.exports = {

    addProcessManagementPolicy: async function (req, res) {
        try {
            const {
                process_no,
                policy,
                department_id,
                effective_date,
                description,
                valid_till
            } = req.body;

            const uploaded_by = req.decodedToken;

            if (!process_no || !policy || !department_id || !effective_date || !description || !valid_till) {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: process_no, policy, department_id, effective_date, description, valid_till"
                });
            }

            if (!req.files || req.files.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "Template file is required!"
                });
            }

            const file = req.files[0];
            const templateUrl = await uploadFile(file);

            if (templateUrl instanceof Error) {
                return res.status(500).send({ status: false, message: "File upload failed: " + templateUrl.message });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const insertQuery = `
                INSERT INTO process_management_policies (
                    process_no, policy, department_id, effective_date, 
                    description, valid_till, template_file, uploaded_by,
                    created_at, updated_at, isActive, isDeleted
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0)
            `;

            await connection.query(insertQuery, [
                process_no,
                policy,
                department_id,
                effective_date,
                description,
                valid_till,
                templateUrl,
                uploaded_by,
                createdAt,
                createdAt
            ]);

            return res.status(200).send({
                status: true,
                message: "Process management policy added successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllProcessManagementPolicies: async function (req, res) {
        try {
            const query = `
                SELECT 
                    pmp.*,
                    dept.name as department_name,
                    u.firstName as uploader_first_name,
                    u.lastName as uploader_last_name
                FROM process_management_policies pmp
                LEFT JOIN department dept ON pmp.department_id = dept.id
                LEFT JOIN userdetails u ON pmp.uploaded_by = u.id
                WHERE pmp.isDeleted = 0
                ORDER BY pmp.id DESC
            `;

            const data = await connection.query(query);

            return res.status(200).send({
                status: true,
                message: "Process management policies list retrieved",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getProcessManagementPolicyById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const query = `
                SELECT 
                    pmp.*,
                    dept.name as department_name,
                    u.firstName as uploader_first_name,
                    u.lastName as uploader_last_name
                FROM process_management_policies pmp
                LEFT JOIN department dept ON pmp.department_id = dept.id
                LEFT JOIN userdetails u ON pmp.uploaded_by = u.id
                WHERE pmp.id = ? AND pmp.isDeleted = 0
            `;

            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Process management policy not found" });
            }

            return res.status(200).send({
                status: true,
                message: "Process management policy retrieved",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateProcessManagementPolicy: async function (req, res) {
        try {
            const {
                id,
                process_no,
                policy,
                department_id,
                effective_date,
                description,
                valid_till,
                isActive
            } = req.body;

            const uploaded_by = req.decodedToken;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id, template_file FROM process_management_policies WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Process management policy not found" });
            }

            let templateUrl = exists[0].template_file;
            if (req.files && req.files.length > 0) {
                const file = req.files[0];
                const uploadResult = await uploadFile(file);
                if (uploadResult instanceof Error) {
                    return res.status(500).send({ status: false, message: "File upload failed: " + uploadResult.message });
                }
                templateUrl = uploadResult;
            }

            const updateFields = [];
            const updateValues = [];

            if (process_no !== undefined) {
                updateFields.push("process_no = ?");
                updateValues.push(process_no);
            }
            if (policy !== undefined) {
                updateFields.push("policy = ?");
                updateValues.push(policy);
            }
            if (department_id !== undefined) {
                updateFields.push("department_id = ?");
                updateValues.push(department_id);
            }
            if (effective_date !== undefined) {
                updateFields.push("effective_date = ?");
                updateValues.push(effective_date);
            }
            if (description !== undefined) {
                updateFields.push("description = ?");
                updateValues.push(description);
            }
            if (valid_till !== undefined) {
                updateFields.push("valid_till = ?");
                updateValues.push(valid_till);
            }
            if (templateUrl !== undefined) {
                updateFields.push("template_file = ?");
                updateValues.push(templateUrl);
            }
            if (isActive !== undefined) {
                updateFields.push("isActive = ?");
                updateValues.push(isActive);
            }

            if (updateFields.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "No fields to update"
                });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("updated_at = ?");
            updateValues.push(updatedAt);

            // Optionally update uploaded_by to the person who last updated it
            updateFields.push("uploaded_by = ?");
            updateValues.push(uploaded_by);

            updateValues.push(id);

            const updateQuery = `
                UPDATE process_management_policies
                SET ${updateFields.join(", ")}
                WHERE id = ?
            `;

            await connection.query(updateQuery, updateValues);

            return res.status(200).send({
                status: true,
                message: "Process management policy updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteProcessManagementPolicy: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM process_management_policies WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Process management policy not found" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE process_management_policies SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: "Process management policy deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    toggleProcessManagementPolicyStatus: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const data = await connection.query(
                "SELECT isActive FROM process_management_policies WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Process management policy not found" });
            }

            const newStatus = data[0].isActive ? 0 : 1;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            await connection.query(
                "UPDATE process_management_policies SET isActive = ?, updated_at = ? WHERE id = ?",
                [newStatus, updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: `Process management policy ${newStatus ? "enabled" : "disabled"} successfully`
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    bulkAddProcessManagementPolicies: async function (req, res) {
        try {
            const { rows } = req.body;
            const uploaded_by = req.decodedToken;

            if (!rows || !Array.isArray(rows) || rows.length === 0) {
                return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
            }

            const { data: validRows, error: invalidCount } = validateProcessManagementPolicyRows(rows);

            if (validRows.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
                });
            }

            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const templateUrl = ""; // Empty URL as requested

            const insertValues = validRows.map(row => [
                row.process_no,
                row.policy,
                row.department_id,
                row.effective_date,
                row.description,
                row.valid_till,
                templateUrl,
                uploaded_by,
                createdAt,
                createdAt,
                1, // isActive
                0  // isDeleted
            ]);

            const query = `
                INSERT INTO process_management_policies (
                    process_no, policy, department_id, effective_date, 
                    description, valid_till, template_file, uploaded_by,
                    created_at, updated_at, isActive, isDeleted
                )
                VALUES ?
            `;
            await connection.query(query, [insertValues]);

            let message = `${validRows.length} Process management policy(s) added successfully!`;
            if (invalidCount > 0) {
                message += ` ${invalidCount} invalid entry/entries were skipped.`;
            }

            return res.status(200).send({
                status: true,
                message: message,
                data: {
                    inserted: validRows.length,
                    invalid: invalidCount
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};

const validateProcessManagementPolicyRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;

    rows.forEach((row) => {
        const {
            process_no,
            policy,
            department_id,
            effective_date,
            description,
            valid_till
        } = row;

        if (!process_no || !policy || !department_id || !effective_date || !description || !valid_till) {
            invalidCount++;
            return;
        }

        validRows.push(row);
    });

    return { data: validRows, error: invalidCount };
};
