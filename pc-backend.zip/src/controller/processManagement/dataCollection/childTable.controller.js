const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../../azurestorage/fileUpload");

// Helper: Sanitize column name for SQL
const sanitizeColumnName = (name) => {
    return name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
};

module.exports = {

    // ==================== CHILD TABLE CRUD ====================

    /*
    * POST /addChildTableRow (multipart/form-data)
    * Example:
    * - collection_id: 1 (form field)
    * - row_data: JSON string of text/dropdown fields (form field)
    *   e.g. {"Employee Name": "John Doe", "Department": "IT", "Status": "Active"}
    * - Resume: file attachment (form field - file type)
    * 
    * OR for JSON body without files:
    * {
    *     "collection_id": 1,
    *     "row_data": {
    *         "Employee Name": "John Doe",
    *         "Department": "IT",
    *         "Resume": "https://storage.example.com/resume.pdf",
    *         "Status": "Active"
    *     }
    * }
    */
    addChildTableRow: async function (req, res) {
        try {
            let { collection_id, row_data } = req.body;

            // Parse row_data if it's a string (from form-data)
            if (typeof row_data === 'string') {
                try {
                    row_data = JSON.parse(row_data);
                } catch (e) {
                    return res.status(400).send({
                        status: false,
                        message: "Invalid row_data format. Must be a valid JSON object."
                    });
                }
            }

            if (!collection_id || !row_data || typeof row_data !== 'object') {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: collection_id, row_data (object)"
                });
            }

            // Get child table name
            const collectionData = await connection.query(
                "SELECT child_table_name FROM data_collection WHERE id = ? AND isDeleted = 0",
                [collection_id]
            );

            if (collectionData.length === 0) {
                return res.status(404).send({ status: false, message: "Data collection not found" });
            }

            // Handle file uploads - upload files and add URLs to row_data
            if (req.files && req.files.length > 0) {
                for (const file of req.files) {
                    const columnName = file.fieldname; // The form field name is the column name
                    const uploadResult = await uploadFile(file);

                    if (uploadResult instanceof Error) {
                        return res.status(500).send({
                            status: false,
                            message: `File upload failed for ${columnName}: ${uploadResult.message}`
                        });
                    }

                    // Store the URL in row_data with the column name as key
                    row_data[columnName] = uploadResult;
                }
            }

            const child_table_name = collectionData[0].child_table_name;
            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            // Build dynamic INSERT query
            const columns = Object.keys(row_data).map(k => `\`${sanitizeColumnName(k)}\``);
            const values = Object.values(row_data);

            columns.push('created_at', 'updated_at');
            values.push(createdAt, createdAt);

            const placeholders = values.map(() => '?').join(', ');

            const insertQuery = `
                INSERT INTO \`${child_table_name}\` (${columns.join(', ')})
                VALUES (${placeholders})
            `;

            const result = await connection.query(insertQuery, values);

            return res.status(200).send({
                status: true,
                message: "Row added successfully",
                data: { id: result.insertId }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getChildTableRows: async function (req, res) {
        try {
            const { collection_id } = req.params;

            if (!collection_id) {
                return res.status(400).send({ status: false, message: "Collection ID is required" });
            }

            // Get child table name
            const collectionData = await connection.query(
                "SELECT child_table_name FROM data_collection WHERE id = ? AND isDeleted = 0",
                [collection_id]
            );

            if (collectionData.length === 0) {
                return res.status(404).send({ status: false, message: "Data collection not found" });
            }

            const child_table_name = collectionData[0].child_table_name;

            const query = `SELECT * FROM \`${child_table_name}\` ORDER BY id DESC`;
            const data = await connection.query(query);

            return res.status(200).send({
                status: true,
                message: "Rows retrieved successfully",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateChildTableRow: async function (req, res) {
        try {
            let { collection_id, row_id, row_data } = req.body;

            // Parse row_data if it's a string (from form-data)
            if (typeof row_data === 'string') {
                try {
                    row_data = JSON.parse(row_data);
                } catch (e) {
                    return res.status(400).send({
                        status: false,
                        message: "Invalid row_data format. Must be a valid JSON object."
                    });
                }
            }

            if (!collection_id || !row_id || !row_data || typeof row_data !== 'object') {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: collection_id, row_id, row_data (object)"
                });
            }

            // Get child table name
            const collectionData = await connection.query(
                "SELECT child_table_name FROM data_collection WHERE id = ? AND isDeleted = 0",
                [collection_id]
            );

            if (collectionData.length === 0) {
                return res.status(404).send({ status: false, message: "Data collection not found" });
            }

            // Handle file uploads - upload files and add URLs to row_data
            if (req.files && req.files.length > 0) {
                for (const file of req.files) {
                    const columnName = file.fieldname;
                    const uploadResult = await uploadFile(file);

                    if (uploadResult instanceof Error) {
                        return res.status(500).send({
                            status: false,
                            message: `File upload failed for ${columnName}: ${uploadResult.message}`
                        });
                    }

                    row_data[columnName] = uploadResult;
                }
            }

            const child_table_name = collectionData[0].child_table_name;
            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            // Build dynamic UPDATE query
            const setClause = Object.keys(row_data)
                .map(k => `\`${sanitizeColumnName(k)}\` = ?`)
                .join(', ');
            const values = [...Object.values(row_data), updatedAt, row_id];

            const updateQuery = `
                UPDATE \`${child_table_name}\`
                SET ${setClause}, updated_at = ?
                WHERE id = ?
            `;

            await connection.query(updateQuery, values);

            return res.status(200).send({
                status: true,
                message: "Row updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteChildTableRow: async function (req, res) {
        try {
            const { collection_id, row_id } = req.body;

            if (!collection_id || !row_id) {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: collection_id, row_id"
                });
            }

            // Get child table name
            const collectionData = await connection.query(
                "SELECT child_table_name FROM data_collection WHERE id = ? AND isDeleted = 0",
                [collection_id]
            );

            if (collectionData.length === 0) {
                return res.status(404).send({ status: false, message: "Data collection not found" });
            }

            const child_table_name = collectionData[0].child_table_name;

            const deleteQuery = `DELETE FROM \`${child_table_name}\` WHERE id = ?`;
            await connection.query(deleteQuery, [row_id]);

            return res.status(200).send({
                status: true,
                message: "Row deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    // ==================== GET CHILD TABLE STRUCTURE ====================

    getChildTableStructure: async function (req, res) {
        try {
            const { collection_id } = req.params;

            if (!collection_id) {
                return res.status(400).send({ status: false, message: "Collection ID is required" });
            }

            // Get child table name
            const collectionData = await connection.query(
                "SELECT child_table_name FROM data_collection WHERE id = ? AND isDeleted = 0",
                [collection_id]
            );

            if (collectionData.length === 0) {
                return res.status(404).send({ status: false, message: "Data collection not found" });
            }

            const child_table_name = collectionData[0].child_table_name;

            // Get column information
            const columns = await connection.query(`DESCRIBE \`${child_table_name}\``);

            // Filter out system columns
            const userColumns = columns.filter(col =>
                !['id', 'created_at', 'updated_at'].includes(col.Field)
            );

            return res.status(200).send({
                status: true,
                message: "Table structure retrieved successfully",
                data: {
                    table_name: child_table_name,
                    columns: userColumns.map(col => ({
                        name: col.Field,
                        type: col.Type,
                        nullable: col.Null === 'YES'
                    }))
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};
