const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

// Type mapping for dynamic table columns
const typeMapping = {
    'text': 'VARCHAR(255)',
    'file': 'VARCHAR(500)'
    // 'dropdown' is handled separately to create ENUM with options
};

// Helper: Sanitize column name for SQL
const sanitizeColumnName = (name) => {
    return name.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase();
};

// Helper: Generate unique table name
const generateTableName = (collectionName) => {
    const sanitized = collectionName.replace(/\s+/g, '_').toLowerCase().replace(/[^a-z0-9_]/g, '');
    return `dc_${Date.now()}_${sanitized}`;
};

module.exports = {

    // ==================== DATA COLLECTION CRUD ====================

    /*
    * POST /addDataCollection
    * Example req.body:
    * {
    *     "year": 2025,
    *     "collection_name": "Employee Survey 2025",
    *     "headers": [
    *         { "name": "Employee Name", "type": "text" },
    *         { "name": "Department", "type": "dropdown", "options": ["HR", "IT", "Finance", "Sales"] },
    *         { "name": "Resume", "type": "file" },
    *         { "name": "Status", "type": "dropdown", "options": ["Active", "Inactive", "Pending"] }
    *     ]
    * }
    */
    addDataCollection: async function (req, res) {
        try {
            const { year, collection_name, headers } = req.body;
            const created_by = req.decodedToken;

            if (!year || !collection_name || !headers || !Array.isArray(headers) || headers.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "Required fields: year, collection_name, headers (array with at least one header)"
                });
            }

            // Validate headers structure
            for (const header of headers) {
                if (!header.name || !header.type) {
                    return res.status(400).send({
                        status: false,
                        message: "Each header must have 'name' and 'type' properties"
                    });
                }
                if (!typeMapping[header.type] && header.type !== 'dropdown') {
                    return res.status(400).send({
                        status: false,
                        message: `Invalid header type: ${header.type}. Allowed types: text, file, dropdown`
                    });
                }
                // Validate dropdown has options
                if (header.type === 'dropdown' && (!header.options || !Array.isArray(header.options) || header.options.length === 0)) {
                    return res.status(400).send({
                        status: false,
                        message: `Dropdown header '${header.name}' must have an 'options' array with at least one option`
                    });
                }
            }

            // Generate unique child table name
            const child_table_name = generateTableName(collection_name);

            // Build dynamic CREATE TABLE query
            const columnDefinitions = headers.map(h => {
                const colName = sanitizeColumnName(h.name);
                let colType;

                if (h.type === 'dropdown') {
                    // Create ENUM type with options
                    const enumValues = h.options.map(opt => `'${opt.replace(/'/g, "''")}'`).join(', ');
                    colType = `ENUM(${enumValues})`;
                } else {
                    colType = typeMapping[h.type];
                }

                return `\`${colName}\` ${colType}`;
            }).join(',\n  ');

            const createTableQuery = `
                CREATE TABLE \`${child_table_name}\` (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    ${columnDefinitions},
                    created_at VARCHAR(255) NOT NULL,
                    updated_at VARCHAR(255) NOT NULL
                )
            `;

            // Create the dynamic child table
            await connection.query(createTableQuery);

            // Insert into data_collection
            const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            const insertQuery = `
                INSERT INTO data_collection (
                    year, collection_name, child_table_name, created_by,
                    created_at, updated_at, isActive, isDeleted
                )
                VALUES (?, ?, ?, ?, ?, ?, 1, 0)
            `;

            const result = await connection.query(insertQuery, [
                year,
                collection_name,
                child_table_name,
                created_by,
                createdAt,
                createdAt
            ]);

            return res.status(200).send({
                status: true,
                message: "Data collection created successfully",
                data: {
                    id: result.insertId,
                    child_table_name: child_table_name,
                    headers: headers
                }
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getAllDataCollections: async function (req, res) {
        try {
            const query = `
                SELECT 
                    dc.*,
                    u.firstName as creator_first_name,
                    u.lastName as creator_last_name
                FROM data_collection dc
                LEFT JOIN userdetails u ON dc.created_by = u.id
                WHERE dc.isDeleted = 0
                ORDER BY dc.id DESC
            `;

            const data = await connection.query(query);

            return res.status(200).send({
                status: true,
                message: "Data collections retrieved successfully",
                data: data
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    getDataCollectionById: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const query = `
                SELECT 
                    dc.*,
                    u.firstName as creator_first_name,
                    u.lastName as creator_last_name
                FROM data_collection dc
                LEFT JOIN userdetails u ON dc.created_by = u.id
                WHERE dc.id = ? AND dc.isDeleted = 0
            `;

            const data = await connection.query(query, [id]);

            if (data.length === 0) {
                return res.status(404).send({ status: false, message: "Data collection not found" });
            }

            return res.status(200).send({
                status: true,
                message: "Data collection retrieved successfully",
                data: data[0]
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    updateDataCollection: async function (req, res) {
        try {
            const { id, year, collection_name, isActive } = req.body;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM data_collection WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Data collection not found" });
            }

            const updateFields = [];
            const updateValues = [];

            if (year !== undefined) {
                updateFields.push("year = ?");
                updateValues.push(year);
            }
            if (collection_name !== undefined) {
                updateFields.push("collection_name = ?");
                updateValues.push(collection_name);
            }
            if (isActive !== undefined) {
                updateFields.push("isActive = ?");
                updateValues.push(isActive);
            }

            if (updateFields.length === 0) {
                return res.status(400).send({
                    status: false,
                    message: "No fields to update"
                });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            updateFields.push("updated_at = ?");
            updateValues.push(updatedAt);

            updateValues.push(id);

            const updateQuery = `
                UPDATE data_collection
                SET ${updateFields.join(", ")}
                WHERE id = ?
            `;

            await connection.query(updateQuery, updateValues);

            return res.status(200).send({
                status: true,
                message: "Data collection updated successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    },

    deleteDataCollection: async function (req, res) {
        try {
            const { id } = req.params;

            if (!id) {
                return res.status(400).send({ status: false, message: "ID is required" });
            }

            const exists = await connection.query(
                "SELECT id FROM data_collection WHERE id = ? AND isDeleted = 0",
                [id]
            );
            if (exists.length === 0) {
                return res.status(404).send({ status: false, message: "Data collection not found" });
            }

            const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
                "UPDATE data_collection SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?",
                [updatedAt, id]
            );

            return res.status(200).send({
                status: true,
                message: "Data collection deleted successfully"
            });
        } catch (error) {
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};

