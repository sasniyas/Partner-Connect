const { connection } = require("../../mySql/mySql");
const eMailerActionItem = require("../../controller/other/eMailerActionItemMonthlyMeeting");
const moment = require('moment-timezone');

module.exports = {
  addPdpActionItem: async function (req, res) {
    try {
      const {
        pdp,
        focus_area,
        objective,
        actions_to_achieve,
        actions_progress_update,
        responsibility,
        priority,
        target_date,
        completed_date,
        status,
        isActive,
        target_data_change
      } = req.body;

      const created_by = req.decodedToken;

      if (!pdp || !focus_area || !objective || !priority) {
        return res.status(400).send({
          status: false,
          message: "Required: pdp, focus_area, objective, priority"
        });
      }
      if (created_by === responsibility) {
        return res.status(400).send({
          status: false,
          message: "Created by and Responsibility can't be same !!"
        });
      }

      // Validate focus_area enum
      const validFocusAreas = ["Uptime & Parts", "DD- CD and Infra", "Finance", "Key Accounts", "Machine Attach- sales", "Marcom", "People and Culture", "Territory Focus"];
      if (!validFocusAreas.includes(focus_area.trim())) {
        return res.status(400).send({
          status: false,
          message: `Invalid focus_area. Must be one of: ${validFocusAreas.join(", ")}`
        });
      }

      // Validate priority enum
      const validPriorities = ["High", "Medium", "Low"];
      if (!validPriorities.includes(priority)) {
        return res.status(400).send({
          status: false,
          message: `Invalid priority. Must be one of: ${validPriorities.join(", ")}`
        });
      }

      // Validate status if provided
      if (status) {
        const validStatuses = ["Open", "Closed", "In Progress"];
        if (!validStatuses.includes(status)) {
          return res.status(400).send({
            status: false,
            message: `Invalid status. Must be one of: ${validStatuses.join(", ")}`
          });
        }
      }

      // Verify pdp exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdp]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_action_item (
          pdp, created_by, focus_area, objective, actions_to_achieve,
          actions_progress_update, responsibility, priority, target_date,
          completed_date, status, isActive, target_data_change,
          created_on, updated_on, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
      `;

      const insertResult = await connection.query(insertQuery, [
        pdp,
        created_by,
        focus_area,
        objective,
        actions_to_achieve || null,
        actions_progress_update || null,
        responsibility || null,
        priority,
        target_date || null,
        completed_date || null,
        status || "Open",
        isActive !== undefined ? isActive : true,
        target_data_change !== undefined ? (target_data_change === true || target_data_change === "true" || target_data_change === 1) : false,
        pdpCreatedOn,
        pdpCreatedOn
      ]);

      // Create action log entry for creation
      const actionItemId = insertResult.insertId;
      const logComment = `Action item created with focus area: ${focus_area}, objective: ${objective}, priority: ${priority}`;
      const logCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const logQuery = `
        INSERT INTO pdp_action_log 
        (updated_by, pdp_action_item, comment, createdOn, isDeleted, target_date) 
        VALUES (?, ?, ?, ?, 0, ?)
      `;
      await connection.query(logQuery, [created_by, actionItemId, logComment, logCreatedOn, target_date || null]);

      // Fetch complete action item details with all joins for email
      const actionItemDetailsQuery = `
        SELECT 
          pai.id,
          pai.pdp,
          pai.created_on,
          pai.created_by,
          pai.focus_area,
          pai.objective,
          pai.actions_to_achieve,
          pai.actions_progress_update,
          pai.responsibility,
          pai.priority,
          pai.target_date,
          pai.completed_date,
          pai.status,
          pai.updated_on,
          pai.isActive,
          pai.isDeleted,
          pai.target_data_change,
          cb.firstName as created_by_name,
          cb.lastName as created_by_lastname,
          cb.email as created_by_email,
          r.firstName as responsibility_name,
          r.lastName as responsibility_lastname,
          r.email as responsibility_email
        FROM pdp_action_item pai
        LEFT JOIN userdetails cb ON pai.created_by = cb.id
        LEFT JOIN userdetails r ON pai.responsibility = r.id
        WHERE pai.id = ? AND pai.isDeleted = 0
      `;

      const actionItemDetails = await connection.query(actionItemDetailsQuery, [actionItemId]);

      // Send email notifications to responsibility and created_by users
      if (actionItemDetails.length > 0) {
        const actionItemData = actionItemDetails[0];
        const emailArray = [];

        // Add responsibility user email if available
        if (actionItemData.responsibility_email && actionItemData.responsibility_email.trim() !== '') {
          emailArray.push(actionItemData.responsibility_email);
        }

        // Add created_by user email if available and different from responsibility
        if (actionItemData.created_by_email &&
          actionItemData.created_by_email.trim() !== '' &&
          actionItemData.created_by_email !== actionItemData.responsibility_email) {
          emailArray.push(actionItemData.created_by_email);
        }

        // Send emails asynchronously (don't wait for completion to avoid blocking response)
        if (emailArray.length > 0) {
          eMailerActionItem.pdpActionItemCreatedMail(emailArray, actionItemData)
            .then(emailResults => {
              console.log('PDP action item creation emails sent:', emailResults);
            })
            .catch(emailError => {
              console.error('Error sending PDP action item creation emails:', emailError);
            });
        } else {
          console.log('No valid email addresses found for PDP action item notification');
        }
      }

      return res.status(200).send({
        status: true,
        message: "PDP action item created successfully",
        id: insertResult.insertId
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllPdpActionItem: async function (req, res) {
    try {
      const { pdp_id, isActive } = req.query;

      let whereConditions = ["pai.isDeleted = 0"];
      let queryParams = [];

      if (pdp_id) {
        whereConditions.push("pai.pdp = ?");
        queryParams.push(pdp_id);
      }

      if (isActive !== undefined) {
        whereConditions.push("pai.isActive = ?");
        queryParams.push(isActive === "true" || isActive === true);
      }

      const query = `
        SELECT 
          pai.id,
          pai.pdp,
          pai.created_on,
          pai.created_by,
          pai.focus_area,
          pai.objective,
          pai.actions_to_achieve,
          pai.actions_progress_update,
          pai.responsibility,
          pai.priority,
          pai.target_date,
          pai.completed_date,
          pai.status,
          pai.updated_on,
          pai.isActive,
          pai.isDeleted,
          pai.target_data_change,
          creator.firstName as created_by_name,
          resp.firstName as responsibility_name
        FROM pdp_action_item pai
        LEFT JOIN userdetails creator ON pai.created_by = creator.id
        LEFT JOIN userdetails resp ON pai.responsibility = resp.id
        WHERE ${whereConditions.join(" AND ")} AND (creator.isDeleted = 0 OR creator.isDeleted IS NULL) AND (resp.isDeleted = 0 OR resp.isDeleted IS NULL)
        ORDER BY pai.created_on DESC, pai.id DESC
      `;

      const rows = await connection.query(query, queryParams);

      if (rows.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP action items found",
          data: []
        });
      }

      const data = rows.map(row => ({
        ...row,
        created_by_info: row.created_by ? {
          user_id: row.created_by,
          user_name: row.created_by_name
        } : null,
        responsibility_info: row.responsibility ? {
          user_id: row.responsibility,
          user_name: row.responsibility_name
        } : null
      }));

      return res.status(200).send({
        status: true,
        message: "PDP action items retrieved",
        data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getPdpActionItemById: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          pai.id,
          pai.pdp,
          pai.created_on,
          pai.created_by,
          pai.focus_area,
          pai.objective,
          pai.actions_to_achieve,
          pai.actions_progress_update,
          pai.responsibility,
          pai.priority,
          pai.target_date,
          pai.completed_date,
          pai.status,
          pai.updated_on,
          pai.isActive,
          pai.isDeleted,
          pai.target_data_change,
          creator.firstName as created_by_name,
          resp.firstName as responsibility_name
        FROM pdp_action_item pai
        LEFT JOIN userdetails creator ON pai.created_by = creator.id
        LEFT JOIN userdetails resp ON pai.responsibility = resp.id
        WHERE pai.id = ? AND pai.isDeleted = 0 AND (creator.isDeleted = 0 OR creator.isDeleted IS NULL) AND (resp.isDeleted = 0 OR resp.isDeleted IS NULL)
      `;

      const rows = await connection.query(query, [id]);

      if (rows.length === 0) {
        return res.status(404).send({
          status: false,
          message: "PDP action item not found"
        });
      }

      const result = {
        ...rows[0],
        created_by_info: rows[0].created_by ? {
          user_id: rows[0].created_by,
          user_name: rows[0].created_by_name
        } : null,
        responsibility_info: rows[0].responsibility ? {
          user_id: rows[0].responsibility,
          user_name: rows[0].responsibility_name
        } : null
      };

      return res.status(200).send({
        status: true,
        message: "PDP action item retrieved",
        data: result
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updatePdpActionItem: async function (req, res) {
    try {
      const {
        id,
        pdp,
        focus_area,
        objective,
        actions_to_achieve,
        actions_progress_update,
        responsibility,
        priority,
        target_date,
        completed_date,
        status,
        isActive,
        target_data_change
      } = req.body;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      const user = req.decodedToken
      console.log("User", user)
      if (user === responsibility) {
        return res.status(400).send({
          status: false,
          message: "Updated by and Responsibility can't be same !!"
        });
      }

      const exists = await connection.query(
        `SELECT id FROM pdp_action_item WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (exists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "PDP action item not found"
        });
      }

      // Fetch current values with user details to compare changes and for email
      const currentValuesQuery = `
        SELECT 
          pai.pdp,
          pai.focus_area,
          pai.objective,
          pai.actions_to_achieve,
          pai.actions_progress_update,
          pai.responsibility,
          pai.priority,
          pai.target_date,
          pai.completed_date,
          pai.status,
          pai.isActive,
          pai.target_data_change,
          cb.firstName as created_by_name,
          cb.lastName as created_by_lastname,
          cb.email as created_by_email,
          r.firstName as responsibility_name,
          r.lastName as responsibility_lastname,
          r.email as responsibility_email
        FROM pdp_action_item pai
        LEFT JOIN userdetails cb ON pai.created_by = cb.id
        LEFT JOIN userdetails r ON pai.responsibility = r.id
        WHERE pai.id = ? AND pai.isDeleted = 0
      `;
      const currentValues = await connection.query(currentValuesQuery, [id]);

      const current = currentValues[0];
      const oldActionItemDetails = currentValues[0];

      // Validate focus_area enum if provided
      if (focus_area) {
        const validFocusAreas = ["Uptime & Parts", "DD- CD and Infra", "Finance", "Key Accounts", "Machine Attach- sales", "Marcom", "People and Culture", "Territory Focus"];
        if (!validFocusAreas.includes(focus_area.trim())) {
          return res.status(400).send({
            status: false,
            message: `Invalid focus_area. Must be one of: ${validFocusAreas.join(", ")}`
          });
        }
      }

      // Validate priority enum if provided
      if (priority) {
        const validPriorities = ["High", "Medium", "Low"];
        if (!validPriorities.includes(priority)) {
          return res.status(400).send({
            status: false,
            message: `Invalid priority. Must be one of: ${validPriorities.join(", ")}`
          });
        }
      }

      // Validate status if provided
      if (status) {
        const validStatuses = ["Open", "Closed", "In Progress"];
        if (!validStatuses.includes(status)) {
          return res.status(400).send({
            status: false,
            message: `Invalid status. Must be one of: ${validStatuses.join(", ")}`
          });
        }
      }

      // Verify pdp exists if provided
      if (pdp) {
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdp]);
        if (pdpExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP not found" });
        }
      }

      // Build dynamic update query
      const updateFields = [];
      const updateValues = [];

      if (pdp !== undefined) {
        updateFields.push("pdp = ?");
        updateValues.push(pdp);
      }
      if (focus_area !== undefined) {
        updateFields.push("focus_area = ?");
        updateValues.push(focus_area);
      }
      if (objective !== undefined) {
        updateFields.push("objective = ?");
        updateValues.push(objective);
      }
      if (actions_to_achieve !== undefined) {
        updateFields.push("actions_to_achieve = ?");
        updateValues.push(actions_to_achieve);
      }
      if (actions_progress_update !== undefined) {
        updateFields.push("actions_progress_update = ?");
        updateValues.push(actions_progress_update);
      }
      if (responsibility !== undefined) {
        updateFields.push("responsibility = ?");
        updateValues.push(responsibility);
      }
      if (priority !== undefined) {
        updateFields.push("priority = ?");
        updateValues.push(priority);
      }
      if (target_date !== undefined) {
        updateFields.push("target_date = ?");
        updateValues.push(target_date);
      }
      if (completed_date === undefined && status === "Closed") {
        updateFields.push("completed_date = ?");
        updateValues.push(completed_date);
      }
      if (status !== undefined) {
        updateFields.push("status = ?");
        updateValues.push(status);
      }
      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }
      if (target_data_change !== undefined) {
        updateFields.push("target_data_change = ?");
        updateValues.push(target_data_change === true || target_data_change === "true" || target_data_change === 1);
      }

      // Always update updated_on timestamp
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_on = ?");
      updateValues.push(updatedOn);

      if (updateFields.length === 1) {
        // Only updated_on is being updated, which is fine
      }
      // If status is "Closing" and completed_date is null, set it to current date
      if (status === "Closed" && (completed_date === null || completed_date === undefined)) {
        const currentDate = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
        console.log("Current Date", currentDate);
        // Check if completed_date is already in updateFields
        const completedDateIndex = updateFields.findIndex(field => field.startsWith("completed_date"));
        if (completedDateIndex === -1) {
          // completed_date not in updateFields, add it
          updateFields.push("completed_date = ?");
          updateValues.push(currentDate);
        } else {
          // completed_date already in updateFields, find its corresponding value index
          // Count fields with placeholders before completed_date
          let valueIndex = 0;
          for (let i = 0; i < completedDateIndex; i++) {
            if (updateFields[i].includes('?')) {
              valueIndex++;
            }
          }
          updateValues[valueIndex] = currentDate;
        }
      }

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_action_item
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      // Create action log entry for update - only log fields that actually changed
      const changedFields = [];
      let targetDateChanged = false;
      let targetDateOldValue = null;
      let targetDateNewValue = null;

      // Helper function to compare values (handles null, undefined, and type conversion)
      const hasChanged = (oldVal, newVal) => {
        if (newVal === undefined) return false; // Field not provided in update
        const old = oldVal === null ? null : String(oldVal).trim();
        const newValStr = newVal === null ? null : String(newVal).trim();
        return old !== newValStr;
      };

      if (pdp !== undefined && hasChanged(current.pdp, pdp)) changedFields.push("pdp");
      if (focus_area !== undefined && hasChanged(current.focus_area, focus_area)) changedFields.push("focus_area");
      if (objective !== undefined && hasChanged(current.objective, objective)) changedFields.push("objective");
      if (actions_to_achieve !== undefined && hasChanged(current.actions_to_achieve, actions_to_achieve)) changedFields.push("actions_to_achieve");
      if (actions_progress_update !== undefined && hasChanged(current.actions_progress_update, actions_progress_update)) changedFields.push("actions_progress_update");
      if (responsibility !== undefined && hasChanged(current.responsibility, responsibility)) changedFields.push("responsibility");
      if (priority !== undefined && hasChanged(current.priority, priority)) changedFields.push("priority");
      if (target_date !== undefined && hasChanged(current.target_date, target_date)) {
        changedFields.push("target_date");
        targetDateChanged = true;
        targetDateOldValue = current.target_date || null;
        targetDateNewValue = target_date || null;
      }
      if (completed_date !== undefined && hasChanged(current.completed_date, completed_date)) changedFields.push("completed_date");
      if (status !== undefined && hasChanged(current.status, status)) changedFields.push("status");

      // Handle boolean fields
      const currentIsActive = current.isActive === 1 || current.isActive === true || String(current.isActive).toLowerCase() === 'true';
      const newIsActive = isActive === true || isActive === 1 || String(isActive).toLowerCase() === 'true';
      if (isActive !== undefined && currentIsActive !== newIsActive) changedFields.push("isActive");

      const currentTargetDataChange = current.target_data_change === 1 || current.target_data_change === true || String(current.target_data_change).toLowerCase() === 'true';
      const newTargetDataChange = target_data_change === true || target_data_change === "true" || target_data_change === 1;
      if (target_data_change !== undefined && currentTargetDataChange !== newTargetDataChange) changedFields.push("target_data_change");

      if (changedFields.length > 0) {
        let logComment = `Action item updated. Fields changed: ${changedFields.join(", ")}`;

        // Add detailed target_date change information if it changed
        if (targetDateChanged) {
          const oldValue = targetDateOldValue ? targetDateOldValue : "null";
          const newValue = targetDateNewValue ? targetDateNewValue : "null";
          logComment += `. Target date is changed from ${oldValue} -> ${newValue}`;
        }

        const logCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        const logQuery = `
          INSERT INTO pdp_action_log 
          (updated_by, pdp_action_item, comment, createdOn, target_date) 
          VALUES (?, ?, ?, ?, ?)
        `;
        await connection.query(logQuery, [user, id, logComment, logCreatedOn, target_date || null]);
      }

      // Fetch complete updated action item details with all joins for email
      const newActionItemDetailsQuery = `
        SELECT 
          pai.id,
          pai.pdp,
          pai.created_on,
          pai.created_by,
          pai.focus_area,
          pai.objective,
          pai.actions_to_achieve,
          pai.actions_progress_update,
          pai.responsibility,
          pai.priority,
          pai.target_date,
          pai.completed_date,
          pai.status,
          pai.updated_on,
          pai.isActive,
          pai.isDeleted,
          pai.target_data_change,
          cb.firstName as created_by_name,
          cb.lastName as created_by_lastname,
          cb.email as created_by_email,
          r.firstName as responsibility_name,
          r.lastName as responsibility_lastname,
          r.email as responsibility_email
        FROM pdp_action_item pai
        LEFT JOIN userdetails cb ON pai.created_by = cb.id
        LEFT JOIN userdetails r ON pai.responsibility = r.id
        WHERE pai.id = ? AND pai.isDeleted = 0
      `;

      const newActionItemDetails = await connection.query(newActionItemDetailsQuery, [id]);

      // Send email notifications to responsibility and created_by users
      if (newActionItemDetails.length > 0) {
        const newActionItemData = newActionItemDetails[0];
        const emailArray = [];

        // Add responsibility user email if available
        if (newActionItemData.responsibility_email && newActionItemData.responsibility_email.trim() !== '') {
          emailArray.push(newActionItemData.responsibility_email);
        }

        // Add created_by user email if available and different from responsibility
        if (newActionItemData.created_by_email &&
          newActionItemData.created_by_email.trim() !== '' &&
          newActionItemData.created_by_email !== newActionItemData.responsibility_email) {
          emailArray.push(newActionItemData.created_by_email);
        }

        // Also include old responsibility email if it changed and is different
        if (oldActionItemDetails.responsibility_email &&
          oldActionItemDetails.responsibility_email.trim() !== '' &&
          oldActionItemDetails.responsibility_email !== newActionItemData.responsibility_email &&
          !emailArray.includes(oldActionItemDetails.responsibility_email)) {
          emailArray.push(oldActionItemDetails.responsibility_email);
        }

        // Send emails asynchronously (don't wait for completion to avoid blocking response)
        if (emailArray.length > 0) {
          eMailerActionItem.pdpActionItemUpdatedMail(emailArray, oldActionItemDetails, newActionItemData)
            .then(emailResults => {
              console.log('PDP action item update emails sent:', emailResults);
            })
            .catch(emailError => {
              console.error('Error sending PDP action item update emails:', emailError);
            });
        } else {
          console.log('No valid email addresses found for PDP action item update notification');
        }
      }

      return res.status(200).send({
        status: true,
        message: "PDP action item updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deletePdpActionItem: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(
        `SELECT id FROM pdp_action_item WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (exists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "PDP action item not found"
        });
      }

      // Soft delete
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(
        `UPDATE pdp_action_item SET isDeleted = 1, updated_on = ? WHERE id = ? AND isDeleted = 0`,
        [updatedOn, id]
      );

      return res.status(200).send({
        status: true,
        message: "PDP action item deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
