const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Equipment
  addPdpEquipment: async function (req, res) {
    try {
      const {
        pdpId,
        equipmentMasterId,
        category,
        py_pdpEquipment_id,
        py_market_share,
        actual_sales_ytd,
        market_volume_ytd,
        market_share_ytd,
        forecast_sales_eoy,
        forecast_market_volume_eoy,
        forecast_market_share_eoy,
        pdp_target,
        total_market_volume,
        market_share,
        remarks
      } = req.body;

      if (!pdpId || !equipmentMasterId || !category) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, equipmentMasterId, category"
        });
      }

      // Validate category
      const validCategories = ["Retails", "Key Account"];
      if (!validCategories.includes(category)) {
        return res.status(400).send({
          status: false,
          message: "Category must be either 'Retails' or 'Key Account'"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if equipment exists
      const equipmentExists = await connection.query(`SELECT id FROM equipments WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`, [equipmentMasterId]);
      if (equipmentExists.length === 0) {
        return res.status(404).send({ status: false, message: "Equipment not found or inactive" });
      }

      // Check for duplicate (same pdpId, equipmentMasterId, and category)
      const duplicateCheck = await connection.query(
        `SELECT id FROM pdp_equipments WHERE pdpId = ? AND equipmentMasterId = ? AND category = ? AND isDeleted = 0`,
        [pdpId, equipmentMasterId, category]
      );
      if (duplicateCheck.length > 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Equipment entry already exists for this PDP, Equipment, and Category combination"
        });
      }

      const insertQuery = `
        INSERT INTO pdp_equipments (
          pdpId, equipmentMasterId, category, py_pdpEquipment_id,
          py_market_share,
          actual_sales_ytd, market_volume_ytd, market_share_ytd,
          forecast_sales_eoy, forecast_market_volume_eoy, forecast_market_share_eoy,
          pdp_target, total_market_volume, market_share, remarks,
          created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      await connection.query(insertQuery, [
        pdpId,
        equipmentMasterId,
        category,
        py_pdpEquipment_id || null,
        py_market_share || 0.00,
        actual_sales_ytd || 0,
        market_volume_ytd || 0,
        market_share_ytd || 0.00,
        forecast_sales_eoy || 0,
        forecast_market_volume_eoy || 0,
        forecast_market_share_eoy || 0.00,
        pdp_target || 0,
        total_market_volume || 0,
        market_share || 0.00,
        remarks || null,
        moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
        moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
        0
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Equipment added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Equipments
  getAllPdpEquipments: async function (req, res) {
    try {
      const query = `
        SELECT 
          pe.id,
          pe.pdpId,
          pe.equipmentMasterId,
          pe.category,
          pe.py_pdpEquipment_id,
          pe.py_market_share,
          pe.actual_sales_ytd,
          pe.market_volume_ytd,
          pe.market_share_ytd,
          pe.forecast_sales_eoy,
          pe.forecast_market_volume_eoy,
          pe.forecast_market_share_eoy,
          pe.pdp_target,
          pe.total_market_volume,
          pe.market_share,
          pe.remarks,
          py_pe.pdp_target as py_pdp_target,
          py_pe.total_market_volume as py_total_market_volume,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_equipments pe
        LEFT JOIN pdp_equipments py_pe ON pe.py_pdpEquipment_id = py_pe.id
        LEFT JOIN equipments e ON pe.equipmentMasterId = e.id
        LEFT JOIN pdp p ON pe.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pe.isDeleted = 0 AND e.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
        ORDER BY pe.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Equipment records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Equipment list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Equipment by ID
  getPdpEquipmentById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          pe.id,
          pe.pdpId,
          pe.equipmentMasterId,
          pe.category,
          pe.py_pdpEquipment_id,
          pe.py_market_share,
          pe.actual_sales_ytd,
          pe.market_volume_ytd,
          pe.market_share_ytd,
          pe.forecast_sales_eoy,
          pe.forecast_market_volume_eoy,
          pe.forecast_market_share_eoy,
          pe.pdp_target,
          pe.total_market_volume,
          pe.market_share,
          pe.remarks,
          py_pe.pdp_target as py_pdp_target,
          py_pe.total_market_volume as py_total_market_volume,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_equipments pe
        LEFT JOIN pdp_equipments py_pe ON pe.py_pdpEquipment_id = py_pe.id
        LEFT JOIN equipments e ON pe.equipmentMasterId = e.id
        LEFT JOIN pdp p ON pe.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pe.id = ? AND pe.isDeleted = 0 AND e.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Equipment not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Equipment retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Equipments by PDP ID
  getPdpEquipmentsByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }



      let query = `
        SELECT 
          pe.id,
          pe.pdpId,
          pe.equipmentMasterId,
          pe.category,
          pe.py_pdpEquipment_id,
          pe.py_market_share,
          pe.actual_sales_ytd,
          pe.market_volume_ytd,
          pe.market_share_ytd,
          pe.forecast_sales_eoy,
          pe.forecast_market_volume_eoy,
          pe.forecast_market_share_eoy,
          pe.pdp_target,
          pe.total_market_volume,
          pe.market_share,
          pe.remarks,
          py_pe.pdp_target as py_pdp_target,
          py_pe.total_market_volume as py_total_market_volume,
          e.year as equipment_year,
          e.equipment_type,
          e.equipment_make,
          e.equipment_line,
          e.equipment_model
        FROM pdp_equipments pe
        LEFT JOIN pdp_equipments py_pe ON pe.py_pdpEquipment_id = py_pe.id
        LEFT JOIN equipments e ON pe.equipmentMasterId = e.id
        WHERE pe.isDeleted = 0 AND e.isDeleted = 0
      `;

      let values = [];

      if (pdpId) {
        query += " AND pe.pdpId = ?";
        values.push(pdpId);
      }

      if (req.query.category) {
        query += " AND pe.category = ? ";
        values.push(req.query.category);
      }

      if (req.query.equipment_type) {
        query += " AND e.equipment_type = ? ";
        values.push(req.query.equipment_type);
      }

      query += " ORDER BY pe.equipmentMasterId, pe.category";


      const data = await connection.query(query, values);

      return res.status(200).send({
        status: true,
        message: "PDP Equipments retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Equipment
  updatePdpEquipment: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        equipmentMasterId,
        category,
        py_pdpEquipment_id,
        py_market_share,
        actual_sales_ytd,
        market_volume_ytd,
        market_share_ytd,
        forecast_sales_eoy,
        forecast_market_volume_eoy,
        forecast_market_share_eoy,
        pdp_target,
        total_market_volume,
        market_share,
        remarks
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Equipment exists
      const exists = await connection.query(`SELECT id FROM pdp_equipments WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Equipment not found" });
      }

      // Validate category if provided
      if (category) {
        const validCategories = ["Retails", "Key Account"];
        if (!validCategories.includes(category)) {
          return res.status(400).send({
            status: false,
            message: "Category must be either 'Retails' or 'Key Account'"
          });
        }
      }

      // Check for duplicate if pdpId, equipmentMasterId, or category is being changed
      if (pdpId || equipmentMasterId || category) {
        const currentData = await connection.query(
          `SELECT pdpId, equipmentMasterId, category FROM pdp_equipments WHERE id = ? AND isDeleted = 0`,
          [id]
        );
        const finalPdpId = pdpId || currentData[0].pdpId;
        const finalEquipmentId = equipmentMasterId || currentData[0].equipmentMasterId;
        const finalCategory = category || currentData[0].category;

        const duplicateCheck = await connection.query(
          `SELECT id FROM pdp_equipments WHERE pdpId = ? AND equipmentMasterId = ? AND category = ? AND id != ? AND isDeleted = 0`,
          [finalPdpId, finalEquipmentId, finalCategory, id]
        );
        if (duplicateCheck.length > 0) {
          return res.status(400).send({
            status: false,
            message: "PDP Equipment entry already exists for this PDP, Equipment, and Category combination"
          });
        }
      }

      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];

      // if (pdpId !== undefined) {
      //   updateFields.push("pdpId = ?");
      //   updateValues.push(pdpId);
      // }
      // if (equipmentMasterId !== undefined) {
      //   updateFields.push("equipmentMasterId = ?");
      //   updateValues.push(equipmentMasterId);
      // }
      // if (category !== undefined) {
      //   updateFields.push("category = ?");
      //   updateValues.push(category);
      // }
      // if (py_pdpEquipment_id !== undefined) {
      //   updateFields.push("py_pdpEquipment_id = ?");
      //   updateValues.push(py_pdpEquipment_id);
      // }
      // if (py_market_share !== undefined) {
      //   updateFields.push("py_market_share = ?");
      //   updateValues.push(py_market_share);
      // }
      if (actual_sales_ytd !== undefined) {
        updateFields.push("actual_sales_ytd = ?");
        updateValues.push(actual_sales_ytd);
      }
      if (market_volume_ytd !== undefined) {
        updateFields.push("market_volume_ytd = ?");
        updateValues.push(market_volume_ytd);
      }
      // if (market_share_ytd !== undefined) {
      //   updateFields.push("market_share_ytd = ?");
      //   updateValues.push(market_share_ytd);
      // }
      if (forecast_sales_eoy !== undefined) {
        updateFields.push("forecast_sales_eoy = ?");
        updateValues.push(forecast_sales_eoy);
      }
      if (forecast_market_volume_eoy !== undefined) {
        updateFields.push("forecast_market_volume_eoy = ?");
        updateValues.push(forecast_market_volume_eoy);
      }
      // if (forecast_market_share_eoy !== undefined) {
      //   updateFields.push("forecast_market_share_eoy = ?");
      //   updateValues.push(forecast_market_share_eoy);
      // }
      if (pdp_target !== undefined) {
        updateFields.push("pdp_target = ?");
        updateValues.push(pdp_target);
      }
      if (total_market_volume !== undefined) {
        updateFields.push("total_market_volume = ?");
        updateValues.push(total_market_volume);
      }
      // if (market_share !== undefined) {
      //   updateFields.push("market_share = ?");
      //   updateValues.push(market_share);
      // }
      if (remarks !== undefined) {
        updateFields.push("remarks = ?");
        updateValues.push(remarks);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_equipments
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Equipment updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update Multiple PDP Equipment
  updateMultiplePdpEquipments: async function (req, res) {
    try {
      const { rows } = req.body;

      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array required" });
      }

      for (const row of rows) {
        const { id, ...fields } = row;

        if (!id) continue;

        const updateFields = [];
        const updateValues = [];

        for (const key in fields) {
          updateFields.push(`${key} = ?`);
          updateValues.push(fields[key]);
        }

        if (updateFields.length === 0) continue;

        // Always update updated_at
        const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        updateFields.push("updated_at = ?");
        updateValues.push(updatedOn);

        updateValues.push(id);

        const query = `
        UPDATE pdp_equipments 
        SET ${updateFields.join(", ")} 
        WHERE id = ? AND isDeleted = 0
      `;

        await connection.query(query, updateValues);
      }

      return res.status(200).send({
        status: true,
        message: "Multiple PDP Equipment rows updated successfully"
      });

    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },


  // 🗑️ Delete PDP Equipment
  deletePdpEquipment: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Equipment exists
      const exists = await connection.query(`SELECT id FROM pdp_equipments WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Equipment not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_equipments SET isDeleted = 1, updated_at = ? WHERE id = ?`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Equipment deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};



