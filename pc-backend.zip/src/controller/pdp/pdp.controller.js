const { connection } = require("../../mySql/mySql");
const eMailer = require("../../controller/other/eMailer");
const moment = require('moment-timezone');
const { createNotification } = require("../notification/notification.controller");

function parseJsonArray(jsonData) {
  if (!jsonData || jsonData === null || jsonData === "null" || jsonData === "") {
    return [];
  }
  try {
    if (Array.isArray(jsonData)) {
      return jsonData;
    }
    return JSON.parse(jsonData);
  } catch (error) {
    return [];
  }
}

/**
 * Helper function to insert dealer investment allocation entries
 * @param {number} dealerInvestmentId - The dealer investment ID
 * @returns {Promise<void>}
 */
async function insertDealerInvestmentAllocation(dealerInvestmentId) {
  try {
    console.log(`[insertDealerInvestmentAllocation] Starting insertion for dealerInvestmentId: ${dealerInvestmentId}`);

    // Fetch all active equipment IDs from equipments table
    const equipmentsQuery = `
      SELECT id 
      FROM equipments 
      WHERE (isActive = 1 OR isActive IS NULL) AND isDeleted = 0
    `;
    const equipments = await connection.query(equipmentsQuery);
    const equipmentIds = equipments.map(eq => eq.id);

    console.log(`[insertDealerInvestmentAllocation] Found ${equipmentIds.length} active equipment IDs`);

    if (equipmentIds.length === 0) {
      console.log(`[insertDealerInvestmentAllocation] No active equipments found, skipping insertion`);
      return;
    }

    // Prepare allocation values for bulk insert
    const allocationCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
    const dealerInvestmentAllocationValues = [];

    for (const equipmentId of equipmentIds) {
      dealerInvestmentAllocationValues.push([
        equipmentId,
        dealerInvestmentId,
        null, // jan
        null, // feb
        null, // mar
        null, // apr
        null, // may
        null, // jun
        null, // jul
        null, // aug
        null, // sep
        null, // oct
        null, // nov
        null, // decem
        allocationCreatedOn, // created_at
        allocationCreatedOn,  // updated_at
        0                     // isDeleted
      ]);
    }

    // Bulk insert all dealer_investment_allocation entries
    if (dealerInvestmentAllocationValues.length > 0) {
      console.log(`[insertDealerInvestmentAllocation] Attempting BULK INSERT into table: dealer_investment_allocation (${dealerInvestmentAllocationValues.length} entries)`);

      const placeholders = dealerInvestmentAllocationValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
      const bulkInsertQuery = `
        INSERT INTO dealer_investment_allocation (equipmentId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, created_at, updated_at, isDeleted)
        VALUES ${placeholders}
      `;
      const flatValues = dealerInvestmentAllocationValues.flat();

      console.log(`[insertDealerInvestmentAllocation] Query columns: equipmentId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, created_at, updated_at`);
      console.log(`[insertDealerInvestmentAllocation] Total values count: ${flatValues.length}, Expected: ${dealerInvestmentAllocationValues.length * 17}`);

      await connection.query(bulkInsertQuery, flatValues);
      console.log(`[insertDealerInvestmentAllocation] ✓ Successfully inserted ${dealerInvestmentAllocationValues.length} entries into dealer_investment_allocation`);
    }
  } catch (error) {
    console.error(`[insertDealerInvestmentAllocation] ✗ ERROR inserting into dealer_investment_allocation:`, error.message);
    console.error(`[insertDealerInvestmentAllocation] Error details:`, error);
    throw error;
  }
}

module.exports = {

  addPdp: async function (req, res) {
    try {
      const {
        year,
        market_area,
        choose_dealer,
        pdp_start_date,
        pdp_end_date,
        physical_pdp_start_date,
        physical_pdp_end_date,
        sign_of_status,
        dealers
      } = req.body;

      if (!year || !market_area || !choose_dealer || !pdp_start_date || !pdp_end_date) {
        return res.status(400).send({
          status: false,
          message: "Required: year, market_area, choose_dealer, pdp_start_date, pdp_end_date"
        });
      }

      const dealerIds = parseJsonArray(dealers);
      if (!dealerIds || dealerIds.length === 0) {
        return res.status(400).send({
          status: false,
          message: "At least one dealer is required"
        });
      }

      // Check for existing PDPs to prevent duplication (same year, same dealership, same MA)
      const existingPdpQuery = `
        SELECT d.dealerName 
        FROM pdp p
        JOIN dealer_master d ON p.dealer = d.id
        WHERE p.year = ? AND p.market_area = ? AND p.dealer IN (?) AND p.isDeleted = 0 AND d.isDeleted = 0
      `;
      const existingPdps = await connection.query(existingPdpQuery, [year, market_area, dealerIds]);

      if (existingPdps.length > 0) {
        const duplicateDealerNames = existingPdps.map(p => p.dealerName).join(', ');
        return res.status(400).send({
          status: false,
          message: `PDP already exists for Year: ${year}, selected Market Area and Dealers: ${duplicateDealerNames}`
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertPdpQuery = `
        INSERT INTO pdp (year, market_area, dealer, choose_dealer, pdp_start_date, pdp_end_date, physical_pdp_start_date, physical_pdp_end_date, sign_of_status, created_at, updated_at, isDeleted)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const signOffStatus = sign_of_status || "Created";

      // Fetch all admin users' emails and IDs for notifications
      const adminUsersQuery = `
        SELECT id, email 
        FROM userdetails 
        WHERE persona = 'Administrator' AND email IS NOT NULL AND email != '' AND isDeleted = 0
      `;
      const adminUsers = await connection.query(adminUsersQuery);
      const adminEmails = adminUsers.map(user => user.email).filter(email => email && email.trim() !== '');
      const adminUserIds = adminUsers.map(user => user.id).filter(id => id);

      // Fetch all active equipment IDs from equipments table
      const equipmentsQuery = `
        SELECT id 
        FROM equipments 
        WHERE (isActive = 1 OR isActive IS NULL) AND isDeleted = 0
      `;
      const equipments = await connection.query(equipmentsQuery);
      const equipmentIds = equipments.map(eq => eq.id);

      const normalizeCategory = value => String(value || "").trim().toLowerCase();

      // Fetch all active uptime parts IDs from uptime_parts_category table
      const uptimePartsQuery = `
        SELECT id 
        FROM uptime_parts_category 
        WHERE (isActive = 1 OR isActive IS NULL) AND isDeleted = 0
      `;
      const uptimeParts = await connection.query(uptimePartsQuery);
      const uptimePartsIds = uptimeParts.map(up => up.id);

      // Fetch all active infrastructure IDs from infrastructure table
      const infrastructureQuery = `
        SELECT id 
        FROM infrastructure 
        WHERE (isActive = 1 OR isActive IS NULL) AND isDeleted = 0
      `;
      const infrastructures = await connection.query(infrastructureQuery);
      const infrastructureIds = infrastructures.map(inf => inf.id);
      console.log(`[addPdp] Found ${infrastructureIds.length} active infrastructure IDs:`, infrastructureIds);

      // Fetch all active competence IDs from competence table
      const competenceQuery = `
        SELECT id
        FROM competence
        WHERE (isActive = 1 OR isActive IS NULL) AND isDeleted = 0
      `;
      const competences = await connection.query(competenceQuery);
      const competenceIds = competences.map(comp => comp.id);

      // Fetch all active others_data IDs from others_data table
      const othersDataQuery = `
        SELECT id 
        FROM others_data 
        WHERE (isActive = 1 OR isActive IS NULL) AND isDeleted = 0
      `;
      const othersData = await connection.query(othersDataQuery);
      const othersDataIds = othersData.map(od => od.id);

      // Fetch all active marcom IDs from marcom table
      const marcomQuery = `
        SELECT id 
        FROM marcom 
        WHERE (isActive = 1 OR isActive IS NULL) AND isDeleted = 0
      `;
      const marcoms = await connection.query(marcomQuery);
      const marcomIds = marcoms.map(m => m.id);
      console.log(`[addPdp] Found ${marcomIds.length} active marcom IDs:`, marcomIds);

      // Fetch all active marcommrk IDs from marcommrk table
      const marcommrkQuery = `
        SELECT id 
        FROM marcommrk 
        WHERE (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)
      `;
      const marcommrks = await connection.query(marcommrkQuery);
      const marcommrkIds = marcommrks.map(m => m.id);
      console.log(`[addPdp] Found ${marcommrkIds.length} active marcommrk IDs:`, marcommrkIds);

      const createdPdpIds = [];
      const pdpDetailsForEmail = [];
      const pdpEquipmentValues = [];
      const pdpUptimePartsValues = [];
      const pdpInfrastructureValues = [];
      const pdpOthersValues = [];
      const pdpCompetenceValues = [];
      const pdpSignoffValues = [];
      const pdpMarcomBrandingValues = [];
      const pdpMarcomMarketingValues = [];
      const pdpIdToDealerInvestmentIdMap = new Map();

      const signoffCategories = [
        "Equipments_Volvo",
        "Equipments_Dealer",
        "Uptime_Volvo",
        "Uptime_Dealer",
        "Sales_Head",
        "CEO",
        "Business_Head",
        "Regional_Head"
      ];

      for (const dealerId of dealerIds) {
        console.log(`[addPdp] ===== Starting INSERT for dealerId: ${dealerId} =====`);
        console.log(`[addPdp] Attempting INSERT into table: pdp`);
        const pdpInsertValues = [
          year,
          market_area,
          dealerId,
          choose_dealer,
          pdp_start_date,
          pdp_end_date,
          physical_pdp_start_date || null,
          physical_pdp_end_date || null,
          signOffStatus,
          pdpCreatedOn,
          pdpCreatedOn,
          0 // isDeleted
        ];
        console.log(`[addPdp] Query: INSERT INTO pdp (year, market_area, dealer, choose_dealer, pdp_start_date, pdp_end_date, physical_pdp_start_date, physical_pdp_end_date, sign_of_status, created_at, updated_at, isDeleted)`);
        console.log(`[addPdp] Values count: ${pdpInsertValues.length}, Values:`, pdpInsertValues);
        const insertResult = await connection.query(insertPdpQuery, pdpInsertValues);
        const pdpId = insertResult.insertId;
        console.log(`[addPdp] ✓ Successfully inserted into pdp table, pdpId: ${pdpId}`);
        createdPdpIds.push(pdpId);

        console.log(`[addPdp] Attempting INSERT into table: pdp_territory_focus_entries_stats for pdpId: ${pdpId}`);
        const insertStatsQuery = `
          INSERT INTO pdp_territory_focus_entries_stats (
            pdpId, py_gpe_pvtv, py_rm_pvtv, py_sdlg_pvtv, py_breaker_pvtv,
            py_gpe_etmv, py_rm_etmv, py_sdlg_etmv, py_breaker_etmv,
            gpe_etmv, rm_etmv, sdlg_etmv, breaker_etmv, created_at, updated_at, isDeleted
          )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        const statsInsertValues = [
          pdpId,
          0, // py_gpe_pvtv
          0, // py_rm_pvtv
          0, // py_sdlg_pvtv
          0, // py_breaker_pvtv
          0, // py_gpe_etmv
          0, // py_rm_etmv
          0, // py_sdlg_etmv
          0, // py_breaker_etmv
          0, // gpe_etmv
          0, // rm_etmv
          0, // sdlg_etmv
          0, // breaker_etmv
          pdpCreatedOn,
          pdpCreatedOn,
          0  // isDeleted
        ];
        console.log(`[addPdp] Query columns: pdpId, py_gpe_pvtv, py_rm_pvtv, py_sdlg_pvtv, py_breaker_pvtv, py_gpe_etmv, py_rm_etmv, py_sdlg_etmv, py_breaker_etmv, gpe_etmv, rm_etmv, sdlg_etmv, breaker_etmv, created_at, updated_at, isDeleted`);
        console.log(`[addPdp] Values count: ${statsInsertValues.length}, Values:`, statsInsertValues);
        await connection.query(insertStatsQuery, statsInsertValues);
        console.log(`[addPdp] ✓ Successfully inserted into pdp_territory_focus_entries_stats for pdpId: ${pdpId}`);

        // Insert into dealer_investment table
        const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        console.log(`[addPdp] Attempting INSERT into table: dealer_investment for pdpId: ${pdpId}`);
        const insertDealerInvestmentQuery = `
          INSERT INTO dealer_investment (pdpId, dealerId, created_at, updated_at, isDeleted)
          VALUES (?, ?, ?, ?, ?)
        `;
        const dealerInvestmentValues = [pdpId, dealerId, createdOn, createdOn, 0];
        console.log(`[addPdp] Query columns: pdpId, dealerId, created_at, updated_at, isDeleted`);
        console.log(`[addPdp] Values count: ${dealerInvestmentValues.length}, Values:`, dealerInvestmentValues);
        const dealerInvestmentResult = await connection.query(insertDealerInvestmentQuery, dealerInvestmentValues);
        const dealerInvestmentId = dealerInvestmentResult.insertId;
        console.log(`[addPdp] ✓ Successfully inserted into dealer_investment, dealerInvestmentId: ${dealerInvestmentId}`);
        pdpIdToDealerInvestmentIdMap.set(pdpId, dealerInvestmentId);

        // Insert dealer investment allocation entries for all active equipments
        await insertDealerInvestmentAllocation(dealerInvestmentId);

        // Insert into dealer_investment_machine_population table (one for Volvo and one for SDLG)
        try {
          console.log(`[addPdp] Attempting INSERT into table: dealer_investment_machine_population for pdpId: ${pdpId}, dealerInvestmentId: ${dealerInvestmentId}`);
          const insertMachinePopulationQuery = `
            INSERT INTO dealer_investment_machine_population (pdpId, dealerInvestmentId, q1, q2, q3, q4, actual, make, created_at, updated_at, isDeleted)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `;
          // Insert entry for Volvo
          const volvoValues = [pdpId, dealerInvestmentId, null, null, null, null, null, "Volvo", createdOn, createdOn, 0];
          console.log(`[addPdp] Query columns: pdpId, dealerInvestmentId, q1, q2, q3, q4, actual, make, created_at, updated_at, isDeleted`);
          console.log(`[addPdp] Volvo values count: ${volvoValues.length}, Values:`, volvoValues);
          await connection.query(insertMachinePopulationQuery, volvoValues);
          console.log(`[addPdp] ✓ Successfully inserted Volvo entry into dealer_investment_machine_population`);
          // Insert entry for SDLG
          const sdlgValues = [pdpId, dealerInvestmentId, null, null, null, null, null, "SDLG", createdOn, createdOn, 0];
          console.log(`[addPdp] SDLG values count: ${sdlgValues.length}, Values:`, sdlgValues);
          await connection.query(insertMachinePopulationQuery, sdlgValues);
          console.log(`[addPdp] ✓ Successfully inserted SDLG entry into dealer_investment_machine_population`);
        } catch (error) {
          console.error(`[addPdp] ✗ ERROR inserting into dealer_investment_machine_population for pdpId ${pdpId}:`, error.message);
          console.error(`[addPdp] Error details:`, error);
          throw error;
        }

        // Find previous year's PDP for this dealer and market_area
        const previousYear = year - 1;
        const previousYearPdpQuery = `
          SELECT id 
          FROM pdp 
          WHERE year = ? AND dealer = ? AND market_area = ? AND isDeleted = 0
          LIMIT 1
        `;
        const previousYearPdp = await connection.query(previousYearPdpQuery, [
          previousYear,
          dealerId,
          market_area
        ]);
        const previousYearPdpId = previousYearPdp.length > 0 ? previousYearPdp[0].id : null;

        console.log(`[addPdp] Current year: ${year}, Previous year: ${previousYear}, Dealer: ${dealerId}, Market Area: ${market_area}`);
        console.log(`[addPdp] Previous year PDP ID: ${previousYearPdpId}`);

        // Fetch all previous year's pdp_equipments entries for this PDP to create a lookup map
        let previousYearEquipmentMap = new Map();
        if (previousYearPdpId && equipmentIds.length > 0) {
          const previousYearEquipmentQuery = `
            SELECT id, equipmentMasterId, category 
            FROM pdp_equipments 
            WHERE pdpId = ? AND isDeleted = 0
          `;
          const previousYearEquipments = await connection.query(previousYearEquipmentQuery, [previousYearPdpId]);

          console.log(`[addPdp] Found ${previousYearEquipments.length} previous year equipment entries for PDP ID ${previousYearPdpId}`);

          // Create a map with key: "equipmentMasterId_category" for quick lookup
          previousYearEquipments.forEach(equipment => {
            // Ensure both equipmentMasterId and category are converted to strings for consistent key matching
            const key = `${String(equipment.equipmentMasterId)}_${String(equipment.category)}`;
            previousYearEquipmentMap.set(key, equipment.id);
            console.log(`[addPdp] Mapped key: ${key} -> id: ${equipment.id}`);
          });
        }

        // Fetch all previous year's pdp_uptime_parts entries for this PDP to create a lookup map
        let previousYearUptimePartsMap = new Map();
        if (previousYearPdpId && uptimePartsIds.length > 0) {
          const previousYearUptimePartsQuery = `
            SELECT id, uptimePartsId, category 
            FROM pdp_uptime_parts 
            WHERE pdpId = ? AND isDeleted = 0
          `;
          const previousYearUptimeParts = await connection.query(previousYearUptimePartsQuery, [previousYearPdpId]);

          console.log(`[addPdp] Found ${previousYearUptimeParts.length} previous year uptime parts entries for PDP ID ${previousYearPdpId}`);

          // Create a map with key: "uptimePartsId_category" for quick lookup
          previousYearUptimeParts.forEach(uptimePart => {
            // Ensure both uptimePartsId and category are converted to strings for consistent key matching
            const key = `${String(uptimePart.uptimePartsId)}_${String(uptimePart.category)}`;
            previousYearUptimePartsMap.set(key, uptimePart.id);
            console.log(`[addPdp] Mapped uptime parts key: ${key} -> id: ${uptimePart.id}`);
          });
        }

        // Fetch all previous year's pdp_infrastructure entries for this PDP to create a lookup map
        let previousYearInfrastructureMap = new Map();
        if (previousYearPdpId) {
          const previousYearInfrastructureQuery = `
            SELECT id, infrastructureId 
            FROM pdp_infrastructure 
            WHERE pdpId = ? AND isDeleted = 0
          `;
          const previousYearInfrastructures = await connection.query(previousYearInfrastructureQuery, [previousYearPdpId]);

          // Create a map with key: "infrastructureId" for quick lookup (category column removed)
          previousYearInfrastructures.forEach(infrastructure => {
            const key = String(infrastructure.infrastructureId);
            previousYearInfrastructureMap.set(key, infrastructure.id);
          });
        }

        // Fetch all previous year's pdp_competence_development entries for this PDP to create a lookup map
        let previousYearCompetenceMap = new Map();
        if (previousYearPdpId && competenceIds.length > 0) {
          const previousYearCompetenceQuery = `
            SELECT id, competenceId
            FROM pdp_competence_development
            WHERE pdpId = ? AND isDeleted = 0
          `;
          const previousYearCompetences = await connection.query(previousYearCompetenceQuery, [previousYearPdpId]);

          previousYearCompetences.forEach(competence => {
            const key = String(competence.competenceId);
            previousYearCompetenceMap.set(key, competence.id);
          });
        }

        // Collect pdp_equipments data for bulk insert with py_pdpEquipment_id
        if (equipmentIds.length > 0) {
          const categories = ["Retails", "Key Account"];
          for (const equipmentId of equipmentIds) {
            for (const category of categories) {
              let pyPdpEquipmentId = null;

              // Look up the corresponding entry in previous year's pdp_equipments using the map
              if (previousYearEquipmentMap.size > 0) {
                // Ensure equipmentId is converted to string for consistent key matching
                const key = `${String(equipmentId)}_${category}`;
                pyPdpEquipmentId = previousYearEquipmentMap.get(key) || null;
                if (pyPdpEquipmentId) {
                  console.log(`[addPdp] Found match for key: ${key} -> py_pdpEquipment_id: ${pyPdpEquipmentId}`);
                }
              }

              pdpEquipmentValues.push([pdpId, equipmentId, category, pyPdpEquipmentId, 0]);
            }
          }
        }

        // Collect pdp_uptime_parts data for bulk insert with py_pdpUptime_id
        if (uptimePartsIds.length > 0) {
          const categories = ["Retails", "Key Account"];
          for (const uptimePartsId of uptimePartsIds) {
            for (const category of categories) {
              let pyPdpUptimeId = null;

              // Look up the corresponding entry in previous year's pdp_uptime_parts using the map
              if (previousYearUptimePartsMap.size > 0) {
                // Ensure uptimePartsId is converted to string for consistent key matching
                const key = `${String(uptimePartsId)}_${category}`;
                pyPdpUptimeId = previousYearUptimePartsMap.get(key) || null;
                if (pyPdpUptimeId) {
                  console.log(`[addPdp] Found uptime parts match for key: ${key} -> py_pdpUptime_id: ${pyPdpUptimeId}`);
                }
              }

              pdpUptimePartsValues.push([pdpId, uptimePartsId, category, pyPdpUptimeId, 0]);
            }
          }
        }

        // Collect pdp_infrastructure data for bulk insert with py_infrastructure_id
        if (infrastructureIds.length > 0) {
          for (const infrastructureId of infrastructureIds) {
            let pyInfrastructureId = null;

            // Look up the corresponding entry in previous year's pdp_infrastructure using the map
            if (previousYearInfrastructureMap.size > 0) {
              const key = String(infrastructureId);
              pyInfrastructureId = previousYearInfrastructureMap.get(key) || null;
            }

            pdpInfrastructureValues.push([pdpId, infrastructureId, pyInfrastructureId, pdpCreatedOn, pdpCreatedOn, 0]);
          }
        }

        // Collect pdp_others data for bulk insert aligned with new schema
        if (othersDataIds.length > 0) {
          for (const othersId of othersDataIds) {
            pdpOthersValues.push([pdpId, othersId, null, pdpCreatedOn, pdpCreatedOn, 0]);
          }
        }

        // Collect pdp_competence_development data for bulk insert with py_target reference
        if (competenceIds.length > 0) {
          for (const competenceId of competenceIds) {
            let pyCompetenceId = null;

            if (previousYearCompetenceMap.size > 0) {
              const key = String(competenceId);
              pyCompetenceId = previousYearCompetenceMap.get(key) || null;
            }

            pdpCompetenceValues.push([pdpId, competenceId, pyCompetenceId, null, null, null, pdpCreatedOn, pdpCreatedOn, 0]);
          }
        }

        // Collect pdp_signoff entries for each predefined category
        if (signoffCategories.length > 0) {
          signoffCategories.forEach(category => {
            pdpSignoffValues.push([pdpId, null, category, pdpCreatedOn, pdpCreatedOn, 0]);
          });
        }

        // Collect pdp_marcom_branding data for bulk insert
        if (marcomIds.length > 0) {
          for (const marcomId of marcomIds) {
            pdpMarcomBrandingValues.push([pdpId, marcomId, null, null, null, pdpCreatedOn, pdpCreatedOn, 0]);
          }
        }

        // Collect pdp_marcom_marketing data for bulk insert
        if (marcommrkIds.length > 0) {
          for (const marcommrkId of marcommrkIds) {
            pdpMarcomMarketingValues.push([pdpId, marcommrkId, null, null, null, null, null, pdpCreatedOn, pdpCreatedOn, 0]);
          }
        }

        // Fetch complete PDP details with market area and dealer names for email
        const pdpDetailsQuery = `
          SELECT 
            p.id,
            p.year,
            p.market_area,
            p.dealer,
            p.choose_dealer,
            p.pdp_start_date,
            p.pdp_end_date,
            p.physical_pdp_start_date,
            p.physical_pdp_end_date,
            p.sign_of_status,
            ma.marketarea as market_area_name,
            d.dealerName as dealer_name
          FROM pdp p
          LEFT JOIN market_area ma ON p.market_area = ma.id
          LEFT JOIN dealer_master d ON p.dealer = d.id
          WHERE p.id = ? AND p.isDeleted = 0 AND ma.isDeleted = 0 AND d.isDeleted = 0
        `;
        const pdpDetails = await connection.query(pdpDetailsQuery, [pdpId]);

        if (pdpDetails.length > 0) {
          pdpDetailsForEmail.push(pdpDetails[0]);
        }
      }

      // Bulk insert all pdp_equipments entries in a single query
      if (pdpEquipmentValues.length > 0) {
        let bulkInsertPdpEquipmentQuery = "";
        let flatValues = [];
        try {
          console.log(`[addPdp] Attempting BULK INSERT into table: pdp_equipments (${pdpEquipmentValues.length} entries)`);
          // Build placeholders for bulk insert: (?, ?, ?, ?), (?, ?, ?, ?), ...
          const placeholders = pdpEquipmentValues.map(() => '(?, ?, ?, ?, ?)').join(', ');
          bulkInsertPdpEquipmentQuery = `
            INSERT INTO pdp_equipments (pdpId, equipmentMasterId, category, py_pdpEquipment_id, isDeleted)
            VALUES ${placeholders}
          `;
          // Flatten the array of arrays into a single array for the query
          flatValues = pdpEquipmentValues.flat();

          // Log first few entries for debugging
          console.log(`[addPdp] Query columns: pdpId, equipmentMasterId, category, py_pdpEquipment_id`);
          console.log(`[addPdp] Sample entries (first 3):`, pdpEquipmentValues.slice(0, 3));
          console.log(`[addPdp] Entries with py_pdpEquipment_id:`, pdpEquipmentValues.filter(v => v[3] !== null).length);
          console.log(`[addPdp] Total values count: ${flatValues.length}, Expected: ${pdpEquipmentValues.length * 5}`);

          await connection.query(bulkInsertPdpEquipmentQuery, flatValues);
          console.log(`[addPdp] ✓ Successfully inserted ${pdpEquipmentValues.length} entries into pdp_equipments`);
        } catch (error) {
          console.error(`[addPdp] ✗ ERROR inserting into pdp_equipments:`, error.message);
          console.error(`[addPdp] Error details:`, error);
          console.error(`[addPdp] Query:`, bulkInsertPdpEquipmentQuery);
          console.error(`[addPdp] Values count: ${flatValues.length}`);
          throw error;
        }
      }

      // Insert into dealer_investment_equipment_mbp for all pdp_equipments entries
      if (pdpIdToDealerInvestmentIdMap.size > 0 && createdPdpIds.length > 0) {
        const dealerInvestmentEquipmentMbpValues = [];
        const equipmentMbpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

        // Fetch all pdp_equipments IDs for each pdpId
        for (const pdpId of createdPdpIds) {
          const dealerInvestmentId = pdpIdToDealerInvestmentIdMap.get(pdpId);
          if (dealerInvestmentId) {
            const pdpEquipmentQuery = `
              SELECT id, category 
              FROM pdp_equipments 
              WHERE pdpId = ? AND isDeleted = 0
            `;
            const pdpEquipmentEntries = await connection.query(pdpEquipmentQuery, [pdpId]);

            // Create dealer_investment_equipment_mbp entries for each pdp_equipments entry
            for (const equipmentEntry of pdpEquipmentEntries) {
              dealerInvestmentEquipmentMbpValues.push([
                equipmentEntry.id, // pdpEquipmentId
                dealerInvestmentId,
                null, // jan
                null, // feb
                null, // mar
                null, // apr
                null, // may
                null, // jun
                null, // jul
                null, // aug
                null, // sep
                null, // oct
                null, // nov
                null, // decem
                equipmentEntry.category, // category (Key Account or Retails)
                equipmentMbpCreatedOn, // created_at
                equipmentMbpCreatedOn, // updated_at
                0  // isDeleted
              ]);
            }
          }
        }

        // Bulk insert all dealer_investment_equipment_mbp entries
        if (dealerInvestmentEquipmentMbpValues.length > 0) {
          let bulkInsertDealerInvestmentEquipmentMbpQuery = "";
          let dealerInvestmentEquipmentMbpFlatValues = [];
          try {
            console.log(`[addPdp] Attempting BULK INSERT into table: dealer_investment_equipment_mbp (${dealerInvestmentEquipmentMbpValues.length} entries)`);
            const dealerInvestmentEquipmentMbpPlaceholders = dealerInvestmentEquipmentMbpValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
            bulkInsertDealerInvestmentEquipmentMbpQuery = `
              INSERT INTO dealer_investment_equipment_mbp (pdpEquipmentId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted)
              VALUES ${dealerInvestmentEquipmentMbpPlaceholders}
            `;
            dealerInvestmentEquipmentMbpFlatValues = dealerInvestmentEquipmentMbpValues.flat();
            console.log(`[addPdp] Query columns: pdpEquipmentId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted`);
            console.log(`[addPdp] Total values count: ${dealerInvestmentEquipmentMbpFlatValues.length}, Expected: ${dealerInvestmentEquipmentMbpValues.length * 18}`);
            await connection.query(bulkInsertDealerInvestmentEquipmentMbpQuery, dealerInvestmentEquipmentMbpFlatValues);
            console.log(`[addPdp] ✓ Successfully inserted ${dealerInvestmentEquipmentMbpValues.length} entries into dealer_investment_equipment_mbp`);
          } catch (error) {
            console.error(`[addPdp] ✗ ERROR inserting into dealer_investment_equipment_mbp:`, error.message);
            console.error(`[addPdp] Error details:`, error);
            console.error(`[addPdp] Query:`, bulkInsertDealerInvestmentEquipmentMbpQuery);
            console.error(`[addPdp] Values count: ${dealerInvestmentEquipmentMbpFlatValues.length}`);
            throw error;
          }
        }
      }

      // Insert into dealer_investment_equipment_projection for all pdp_equipments entries
      if (pdpIdToDealerInvestmentIdMap.size > 0 && createdPdpIds.length > 0) {
        const dealerInvestmentEquipmentProjectionValues = [];
        const equipmentProjectionCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

        // Fetch all pdp_equipments IDs for each pdpId
        for (const pdpId of createdPdpIds) {
          const dealerInvestmentId = pdpIdToDealerInvestmentIdMap.get(pdpId);
          if (dealerInvestmentId) {
            const pdpEquipmentQuery = `
              SELECT id, category 
              FROM pdp_equipments 
              WHERE pdpId = ?
            `;
            const pdpEquipmentEntries = await connection.query(pdpEquipmentQuery, [pdpId]);

            // Create dealer_investment_equipment_projection entries for each pdp_equipments entry
            for (const equipmentEntry of pdpEquipmentEntries) {
              dealerInvestmentEquipmentProjectionValues.push([
                equipmentEntry.id, // pdpEquipmentId
                dealerInvestmentId,
                null, // jan
                null, // feb
                null, // mar
                null, // apr
                null, // may
                null, // jun
                null, // jul
                null, // aug
                null, // sep
                null, // oct
                null, // nov
                null, // decem
                equipmentEntry.category, // category (Key Account or Retails)
                equipmentProjectionCreatedOn, // created_at
                equipmentProjectionCreatedOn, // updated_at
                0  // isDeleted
              ]);
            }
          }
        }

        // Bulk insert all dealer_investment_equipment_projection entries
        if (dealerInvestmentEquipmentProjectionValues.length > 0) {
          let bulkInsertDealerInvestmentEquipmentProjectionQuery = "";
          let dealerInvestmentEquipmentProjectionFlatValues = [];
          try {
            console.log(`[addPdp] Attempting BULK INSERT into table: dealer_investment_equipment_projection (${dealerInvestmentEquipmentProjectionValues.length} entries)`);
            const dealerInvestmentEquipmentProjectionPlaceholders = dealerInvestmentEquipmentProjectionValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
            bulkInsertDealerInvestmentEquipmentProjectionQuery = `
              INSERT INTO dealer_investment_equipment_projection (pdpEquipmentId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted)
              VALUES ${dealerInvestmentEquipmentProjectionPlaceholders}
            `;
            dealerInvestmentEquipmentProjectionFlatValues = dealerInvestmentEquipmentProjectionValues.flat();
            console.log(`[addPdp] Query columns: pdpEquipmentId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted`);
            console.log(`[addPdp] Total values count: ${dealerInvestmentEquipmentProjectionFlatValues.length}, Expected: ${dealerInvestmentEquipmentProjectionValues.length * 18}`);
            await connection.query(bulkInsertDealerInvestmentEquipmentProjectionQuery, dealerInvestmentEquipmentProjectionFlatValues);
            console.log(`[addPdp] ✓ Successfully inserted ${dealerInvestmentEquipmentProjectionValues.length} entries into dealer_investment_equipment_projection`);
          } catch (error) {
            console.error(`[addPdp] ✗ ERROR inserting into dealer_investment_equipment_projection:`, error.message);
            console.error(`[addPdp] Error details:`, error);
            console.error(`[addPdp] Query:`, bulkInsertDealerInvestmentEquipmentProjectionQuery);
            console.error(`[addPdp] Values count: ${dealerInvestmentEquipmentProjectionFlatValues.length}`);
            throw error;
          }
        }
      }



      // Insert into dealer_investment_equipment_actuals for all pdp_equipments entries
      if (pdpIdToDealerInvestmentIdMap.size > 0 && createdPdpIds.length > 0) {
        const dealerInvestmentEquipmentActualsValues = [];
        const equipmentActualsCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

        // Fetch all pdp_equipments IDs for each pdpId
        for (const pdpId of createdPdpIds) {
          const dealerInvestmentId = pdpIdToDealerInvestmentIdMap.get(pdpId);
          if (dealerInvestmentId) {
            const pdpEquipmentQuery = `
              SELECT id, category 
              FROM pdp_equipments 
              WHERE pdpId = ?
            `;
            const pdpEquipmentEntries = await connection.query(pdpEquipmentQuery, [pdpId]);

            // Create dealer_investment_equipment_actuals entries for each pdp_equipments entry
            for (const equipmentEntry of pdpEquipmentEntries) {
              dealerInvestmentEquipmentActualsValues.push([
                equipmentEntry.id, // pdpEquipmentId
                dealerInvestmentId,
                null, // jan
                null, // feb
                null, // mar
                null, // apr
                null, // may
                null, // jun
                null, // jul
                null, // aug
                null, // sep
                null, // oct
                null, // nov
                null, // decem
                equipmentEntry.category, // category (Key Account or Retails)
                equipmentActualsCreatedOn, // created_at
                equipmentActualsCreatedOn, // updated_at
                0  // isDeleted
              ]);
            }
          }
        }

        // Bulk insert all dealer_investment_equipment_actuals entries
        if (dealerInvestmentEquipmentActualsValues.length > 0) {
          let bulkInsertDealerInvestmentEquipmentActualsQuery = "";
          let dealerInvestmentEquipmentActualsFlatValues = [];
          try {
            console.log(`[addPdp] Attempting BULK INSERT into table: dealer_investment_equipment_actuals (${dealerInvestmentEquipmentActualsValues.length} entries)`);
            const dealerInvestmentEquipmentActualsPlaceholders = dealerInvestmentEquipmentActualsValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
            bulkInsertDealerInvestmentEquipmentActualsQuery = `
              INSERT INTO dealer_investment_equipment_actuals (pdpEquipmentId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted)
              VALUES ${dealerInvestmentEquipmentActualsPlaceholders}
            `;
            dealerInvestmentEquipmentActualsFlatValues = dealerInvestmentEquipmentActualsValues.flat();
            console.log(`[addPdp] Query columns: pdpEquipmentId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted`);
            console.log(`[addPdp] Total values count: ${dealerInvestmentEquipmentActualsFlatValues.length}, Expected: ${dealerInvestmentEquipmentActualsValues.length * 18}`);
            await connection.query(bulkInsertDealerInvestmentEquipmentActualsQuery, dealerInvestmentEquipmentActualsFlatValues);
            console.log(`[addPdp] ✓ Successfully inserted ${dealerInvestmentEquipmentActualsValues.length} entries into dealer_investment_equipment_actuals`);
          } catch (error) {
            console.error(`[addPdp] ✗ ERROR inserting into dealer_investment_equipment_actuals:`, error.message);
            console.error(`[addPdp] Error details:`, error);
            console.error(`[addPdp] Query:`, bulkInsertDealerInvestmentEquipmentActualsQuery);
            console.error(`[addPdp] Values count: ${dealerInvestmentEquipmentActualsFlatValues.length}`);
            throw error;
          }
        }
      }

      // Bulk insert all pdp_uptime_parts entries in a single query
      if (pdpUptimePartsValues.length > 0) {
        let bulkInsertPdpUptimePartsQuery = "";
        let uptimePartsFlatValues = [];
        try {
          console.log(`[addPdp] Attempting BULK INSERT into table: pdp_uptime_parts (${pdpUptimePartsValues.length} entries)`);
          // Build placeholders for bulk insert: (?, ?, ?, ?), (?, ?, ?, ?), ...
          const uptimePartsPlaceholders = pdpUptimePartsValues.map(() => '(?, ?, ?, ?, ?)').join(', ');
          bulkInsertPdpUptimePartsQuery = `
            INSERT INTO pdp_uptime_parts (pdpId, uptimePartsId, category, py_pdpUptime_id, isDeleted)
            VALUES ${uptimePartsPlaceholders}
          `;
          // Flatten the array of arrays into a single array for the query
          uptimePartsFlatValues = pdpUptimePartsValues.flat();

          // Log first few entries for debugging
          console.log(`[addPdp] Query columns: pdpId, uptimePartsId, category, py_pdpUptime_id, isDeleted`);
          console.log(`[addPdp] Sample uptime parts entries (first 3):`, pdpUptimePartsValues.slice(0, 3));
          console.log(`[addPdp] Uptime parts entries with py_pdpUptime_id:`, pdpUptimePartsValues.filter(v => v[3] !== null).length);
          console.log(`[addPdp] Total values count: ${uptimePartsFlatValues.length}, Expected: ${pdpUptimePartsValues.length * 5}`);

          await connection.query(bulkInsertPdpUptimePartsQuery, uptimePartsFlatValues);
          console.log(`[addPdp] ✓ Successfully inserted ${pdpUptimePartsValues.length} entries into pdp_uptime_parts`);
        } catch (error) {
          console.error(`[addPdp] ✗ ERROR inserting into pdp_uptime_parts:`, error.message);
          console.error(`[addPdp] Error details:`, error);
          console.error(`[addPdp] Query:`, bulkInsertPdpUptimePartsQuery);
          console.error(`[addPdp] Values count: ${uptimePartsFlatValues.length}`);
          throw error;
        }
      }

      // Insert into dealer_investment_uptime_mbp, projection, and actuals for all pdp_uptime_parts entries
      // Only for entries where uptime_parts_category.details is 'Parts', 'Lubes', or 'Service Revenue' AND di_required=true
      // Optimized: Single loop and single query per pdpId to populate all three tables
      if (pdpIdToDealerInvestmentIdMap.size > 0 && createdPdpIds.length > 0) {
        const dealerInvestmentUptimeMbpValues = [];
        const dealerInvestmentUptimeProjectionValues = [];
        const dealerInvestmentUptimeActualsValues = [];
        const uptimeCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

        // Single loop to fetch and populate all three arrays
        for (const pdpId of createdPdpIds) {
          const dealerInvestmentId = pdpIdToDealerInvestmentIdMap.get(pdpId);
          if (dealerInvestmentId) {
            // Single query to fetch all pdp_uptime_parts entries for this pdpId
            // Filter by di_required=true similar to competence development logic
            const pdpUptimePartsQuery = `
              SELECT pup.id, pup.category 
              FROM pdp_uptime_parts pup
              INNER JOIN uptime_parts_category upc ON pup.uptimePartsId = upc.id
              WHERE pup.pdpId = ? 
              AND upc.details IN ('Parts', 'Lubes', 'Service Revenue')
              AND upc.di_required = true
              AND pup.isDeleted = 0 AND upc.isDeleted = 0
            `;
            const pdpUptimePartsEntries = await connection.query(pdpUptimePartsQuery, [pdpId]);

            // Single loop to populate all three arrays
            for (const uptimeEntry of pdpUptimePartsEntries) {
              // Map category: "Key Account" -> "Off Take", "Retails" -> "Retails"
              const mappedCategory = uptimeEntry.category === "Key Account" ? "Off Take" : "Retails";

              // Common values for all three tables
              const commonValues = [
                uptimeEntry.id, // pdpUptimeId
                dealerInvestmentId,
                null, // jan
                null, // feb
                null, // mar
                null, // apr
                null, // may
                null, // jun
                null, // jul
                null, // aug
                null, // sep
                null, // oct
                null, // nov
                null, // decem
                mappedCategory, // category (Off Take or Retails)
                uptimeCreatedOn, // created_at
                uptimeCreatedOn, // updated_at
                0                // isDeleted
              ];

              // Populate all three arrays with the same data
              dealerInvestmentUptimeMbpValues.push([...commonValues]);
              dealerInvestmentUptimeProjectionValues.push([...commonValues]);
              dealerInvestmentUptimeActualsValues.push([...commonValues]);
            }
          }
        }

        // Bulk insert all dealer_investment_uptime_mbp entries
        if (dealerInvestmentUptimeMbpValues.length > 0) {
          let bulkInsertDealerInvestmentUptimeMbpQuery = "";
          let dealerInvestmentUptimeMbpFlatValues = [];
          try {
            console.log(`[addPdp] Attempting BULK INSERT into table: dealer_investment_uptime_mbp (${dealerInvestmentUptimeMbpValues.length} entries)`);
            const dealerInvestmentUptimeMbpPlaceholders = dealerInvestmentUptimeMbpValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
            bulkInsertDealerInvestmentUptimeMbpQuery = `
              INSERT INTO dealer_investment_uptime_mbp (pdpUptimeId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted)
              VALUES ${dealerInvestmentUptimeMbpPlaceholders}
            `;
            dealerInvestmentUptimeMbpFlatValues = dealerInvestmentUptimeMbpValues.flat();
            console.log(`[addPdp] Query columns: pdpUptimeId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted`);
            console.log(`[addPdp] Total values count: ${dealerInvestmentUptimeMbpFlatValues.length}, Expected: ${dealerInvestmentUptimeMbpValues.length * 18}`);
            await connection.query(bulkInsertDealerInvestmentUptimeMbpQuery, dealerInvestmentUptimeMbpFlatValues);
            console.log(`[addPdp] ✓ Successfully inserted ${dealerInvestmentUptimeMbpValues.length} entries into dealer_investment_uptime_mbp`);
          } catch (error) {
            console.error(`[addPdp] ✗ ERROR inserting into dealer_investment_uptime_mbp:`, error.message);
            console.error(`[addPdp] Error details:`, error);
            console.error(`[addPdp] Query:`, bulkInsertDealerInvestmentUptimeMbpQuery);
            console.error(`[addPdp] Values count: ${dealerInvestmentUptimeMbpFlatValues.length}`);
            throw error;
          }
        }

        // Bulk insert all dealer_investment_uptime_projection entries
        if (dealerInvestmentUptimeProjectionValues.length > 0) {
          let bulkInsertDealerInvestmentUptimeProjectionQuery = "";
          let dealerInvestmentUptimeProjectionFlatValues = [];
          try {
            console.log(`[addPdp] Attempting BULK INSERT into table: dealer_investment_uptime_projection (${dealerInvestmentUptimeProjectionValues.length} entries)`);
            const dealerInvestmentUptimeProjectionPlaceholders = dealerInvestmentUptimeProjectionValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
            bulkInsertDealerInvestmentUptimeProjectionQuery = `
              INSERT INTO dealer_investment_uptime_projection (pdpUptimeId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted)
              VALUES ${dealerInvestmentUptimeProjectionPlaceholders}
            `;
            dealerInvestmentUptimeProjectionFlatValues = dealerInvestmentUptimeProjectionValues.flat();
            console.log(`[addPdp] Query columns: pdpUptimeId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted`);
            console.log(`[addPdp] Total values count: ${dealerInvestmentUptimeProjectionFlatValues.length}, Expected: ${dealerInvestmentUptimeProjectionValues.length * 18}`);
            await connection.query(bulkInsertDealerInvestmentUptimeProjectionQuery, dealerInvestmentUptimeProjectionFlatValues);
            console.log(`[addPdp] ✓ Successfully inserted ${dealerInvestmentUptimeProjectionValues.length} entries into dealer_investment_uptime_projection`);
          } catch (error) {
            console.error(`[addPdp] ✗ ERROR inserting into dealer_investment_uptime_projection:`, error.message);
            console.error(`[addPdp] Error details:`, error);
            console.error(`[addPdp] Query:`, bulkInsertDealerInvestmentUptimeProjectionQuery);
            console.error(`[addPdp] Values count: ${dealerInvestmentUptimeProjectionFlatValues.length}`);
            throw error;
          }
        }

        // Bulk insert all dealer_investment_uptime_actuals entries
        if (dealerInvestmentUptimeActualsValues.length > 0) {
          let bulkInsertDealerInvestmentUptimeActualsQuery = "";
          let dealerInvestmentUptimeActualsFlatValues = [];
          try {
            console.log(`[addPdp] Attempting BULK INSERT into table: dealer_investment_uptime_actuals (${dealerInvestmentUptimeActualsValues.length} entries)`);
            const dealerInvestmentUptimeActualsPlaceholders = dealerInvestmentUptimeActualsValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
            bulkInsertDealerInvestmentUptimeActualsQuery = `
              INSERT INTO dealer_investment_uptime_actuals (pdpUptimeId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted)
              VALUES ${dealerInvestmentUptimeActualsPlaceholders}
            `;
            dealerInvestmentUptimeActualsFlatValues = dealerInvestmentUptimeActualsValues.flat();
            console.log(`[addPdp] Query columns: pdpUptimeId, dealerInvestmentId, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, decem, category, created_at, updated_at, isDeleted`);
            console.log(`[addPdp] Total values count: ${dealerInvestmentUptimeActualsFlatValues.length}, Expected: ${dealerInvestmentUptimeActualsValues.length * 18}`);
            await connection.query(bulkInsertDealerInvestmentUptimeActualsQuery, dealerInvestmentUptimeActualsFlatValues);
            console.log(`[addPdp] ✓ Successfully inserted ${dealerInvestmentUptimeActualsValues.length} entries into dealer_investment_uptime_actuals`);
          } catch (error) {
            console.error(`[addPdp] ✗ ERROR inserting into dealer_investment_uptime_actuals:`, error.message);
            console.error(`[addPdp] Error details:`, error);
            console.error(`[addPdp] Query:`, bulkInsertDealerInvestmentUptimeActualsQuery);
            console.error(`[addPdp] Values count: ${dealerInvestmentUptimeActualsFlatValues.length}`);
            throw error;
          }
        }
      }

      // Bulk insert all pdp_infrastructure entries in a single query
      if (pdpInfrastructureValues.length > 0) {
        try {
          console.log(`[addPdp] Attempting BULK INSERT into table: pdp_infrastructure (${pdpInfrastructureValues.length} entries)`);
          const infrastructurePlaceholders = pdpInfrastructureValues.map(() => '(?, ?, ?, ?, ?, ?)').join(', ');
          const bulkInsertPdpInfrastructureQuery = `
            INSERT INTO pdp_infrastructure (pdpId, infrastructureId, py_infrastructure_id, created_at, updated_at, isDeleted)
            VALUES ${infrastructurePlaceholders}
          `;
          const infrastructureFlatValues = pdpInfrastructureValues.flat();
          console.log(`[addPdp] Query columns: pdpId, infrastructureId, py_infrastructure_id, created_at, updated_at`);
          console.log(`[addPdp] Total values count: ${infrastructureFlatValues.length}, Expected: ${pdpInfrastructureValues.length * 6}`);
          await connection.query(bulkInsertPdpInfrastructureQuery, infrastructureFlatValues);
          console.log(`[addPdp] ✓ Successfully inserted ${pdpInfrastructureValues.length} entries into pdp_infrastructure`);
        } catch (error) {
          console.error(`[addPdp] ✗ ERROR inserting into pdp_infrastructure:`, error.message);
          console.error(`[addPdp] Error details:`, error);
          console.error(`[addPdp] Query:`, bulkInsertPdpInfrastructureQuery);
          console.error(`[addPdp] Values count: ${infrastructureFlatValues.length}`);
          throw error;
        }
      }

      // Insert into dealer_investment_infrastructure for all pdp_infrastructure entries
      if (pdpIdToDealerInvestmentIdMap.size > 0 && createdPdpIds.length > 0) {
        const dealerInvestmentInfrastructureValues = [];
        const infrastructureCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

        // Fetch all pdp_infrastructure IDs for each pdpId
        for (const pdpId of createdPdpIds) {
          const dealerInvestmentId = pdpIdToDealerInvestmentIdMap.get(pdpId);
          if (dealerInvestmentId) {
            const pdpInfrastructureQuery = `
              SELECT id 
              FROM pdp_infrastructure 
              WHERE pdpId = ? AND isDeleted = 0
            `;
            const pdpInfrastructureEntries = await connection.query(pdpInfrastructureQuery, [pdpId]);

            // Create dealer_investment_infrastructure entries for each pdp_infrastructure entry
            for (const infrastructureEntry of pdpInfrastructureEntries) {
              dealerInvestmentInfrastructureValues.push([
                pdpId,
                infrastructureEntry.id, // pdpInfrastructureId
                dealerInvestmentId,
                null, // q1
                null, // q2
                null, // q3
                null, // q4
                null, // ytd_actual
                infrastructureCreatedOn, // created_at
                infrastructureCreatedOn, // updated_at
                0  // isDeleted
              ]);
            }
          }
        }

        // Bulk insert all dealer_investment_infrastructure entries
        if (dealerInvestmentInfrastructureValues.length > 0) {
          let bulkInsertDealerInvestmentInfrastructureQuery = "";
          let dealerInvestmentInfrastructureFlatValues = [];
          try {
            console.log(`[addPdp] Attempting BULK INSERT into table: dealer_investment_infrastructure (${dealerInvestmentInfrastructureValues.length} entries)`);
            const dealerInvestmentInfrastructurePlaceholders = dealerInvestmentInfrastructureValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
            bulkInsertDealerInvestmentInfrastructureQuery = `
              INSERT INTO dealer_investment_infrastructure (pdpId, pdpInfrastructureId, dealerInvestmentId, q1, q2, q3, q4, ytd_actual, created_at, updated_at, isDeleted)
              VALUES ${dealerInvestmentInfrastructurePlaceholders}
            `;
            dealerInvestmentInfrastructureFlatValues = dealerInvestmentInfrastructureValues.flat();
            console.log(`[addPdp] Query columns: pdpId, pdpInfrastructureId, dealerInvestmentId, q1, q2, q3, q4, ytd_actual, created_at, updated_at, isDeleted`);
            console.log(`[addPdp] Total values count: ${dealerInvestmentInfrastructureFlatValues.length}, Expected: ${dealerInvestmentInfrastructureValues.length * 11}`);
            await connection.query(bulkInsertDealerInvestmentInfrastructureQuery, dealerInvestmentInfrastructureFlatValues);
            console.log(`[addPdp] ✓ Successfully inserted ${dealerInvestmentInfrastructureValues.length} entries into dealer_investment_infrastructure`);
          } catch (error) {
            console.error(`[addPdp] ✗ ERROR inserting into dealer_investment_infrastructure:`, error.message);
            console.error(`[addPdp] Error details:`, error);
            console.error(`[addPdp] Query:`, bulkInsertDealerInvestmentInfrastructureQuery);
            console.error(`[addPdp] Values count: ${dealerInvestmentInfrastructureFlatValues.length}`);
            throw error;
          }
        }
      }

      // Bulk insert all pdp_others entries in a single query
      if (pdpOthersValues.length > 0) {
        let bulkInsertPdpOthersQuery = "";
        let othersFlatValues = [];
        try {
          console.log(`[addPdp] Attempting BULK INSERT into table: pdp_others (${pdpOthersValues.length} entries)`);
          const othersPlaceholders = pdpOthersValues.map(() => '(?, ?, ?, ?, ?, ?)').join(', ');
          bulkInsertPdpOthersQuery = `
            INSERT INTO pdp_others (pdpId, othersId, optional_document_url, created_at, updated_at, isDeleted)
            VALUES ${othersPlaceholders}
          `;
          // Flatten the array of arrays into a single array for the query
          othersFlatValues = pdpOthersValues.flat();
          console.log(`[addPdp] Query columns: pdpId, othersId, optional_document_url, created_at, updated_at, isDeleted`);
          console.log(`[addPdp] Total values count: ${othersFlatValues.length}, Expected: ${pdpOthersValues.length * 6}`);
          await connection.query(bulkInsertPdpOthersQuery, othersFlatValues);
          console.log(`[addPdp] ✓ Successfully inserted ${pdpOthersValues.length} entries into pdp_others`);
        } catch (error) {
          console.error(`[addPdp] ✗ ERROR inserting into pdp_others:`, error.message);
          console.error(`[addPdp] Error details:`, error);
          console.error(`[addPdp] Query:`, bulkInsertPdpOthersQuery);
          console.error(`[addPdp] Values count: ${othersFlatValues.length}`);
          throw error;
        }
      }

      // Bulk insert all pdp_competence_development entries in a single query
      if (pdpCompetenceValues.length > 0) {
        let bulkInsertPdpCompetenceQuery = "";
        let competenceFlatValues = [];
        try {
          console.log(`[addPdp] Attempting BULK INSERT into table: pdp_competence_development (${pdpCompetenceValues.length} entries)`);
          const competencePlaceholders = pdpCompetenceValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
          bulkInsertPdpCompetenceQuery = `
            INSERT INTO pdp_competence_development (pdpId, competenceId, py_target, py_eoy, target, remarks, created_at, updated_at, isDeleted)
            VALUES ${competencePlaceholders}
          `;
          competenceFlatValues = pdpCompetenceValues.flat();
          console.log(`[addPdp] Query columns: pdpId, competenceId, py_target, py_eoy, target, remarks, created_at, updated_at, isDeleted`);
          console.log(`[addPdp] Total values count: ${competenceFlatValues.length}, Expected: ${pdpCompetenceValues.length * 9}`);
          await connection.query(bulkInsertPdpCompetenceQuery, competenceFlatValues);
          console.log(`[addPdp] ✓ Successfully inserted ${pdpCompetenceValues.length} entries into pdp_competence_development`);
        } catch (error) {
          console.error(`[addPdp] ✗ ERROR inserting into pdp_competence_development:`, error.message);
          console.error(`[addPdp] Error details:`, error);
          console.error(`[addPdp] Query:`, bulkInsertPdpCompetenceQuery);
          console.error(`[addPdp] Values count: ${competenceFlatValues.length}`);
          throw error;
        }
      }

      // Insert into dealer_investment_competence for all pdp_competence_development entries
      if (pdpIdToDealerInvestmentIdMap.size > 0 && createdPdpIds.length > 0) {
        const dealerInvestmentCompetenceValues = [];
        const competenceCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

        // Fetch all pdp_competence_development IDs for each pdpId
        for (const pdpId of createdPdpIds) {
          const dealerInvestmentId = pdpIdToDealerInvestmentIdMap.get(pdpId);
          if (dealerInvestmentId) {
            const pdpCompetenceQuery = `
            SELECT pc.id,pc.competenceid,c.di_required FROM pdp_competence_development as pc Left join competence 
            as c on pc.competenceId=c.id WHERE pc.pdpId = ? And c.di_required=true AND pc.isDeleted = 0 AND c.isDeleted = 0;

            `;
            const pdpCompetenceEntries = await connection.query(pdpCompetenceQuery, [pdpId]);

            // Create dealer_investment_competence entries for each pdp_competence_development entry
            for (const competenceEntry of pdpCompetenceEntries) {
              dealerInvestmentCompetenceValues.push([
                pdpId,
                competenceEntry.id, // pdpCompetenceId
                dealerInvestmentId,
                null, // q1
                null, // q2
                null, // q3
                null, // q4
                null, // ytd_actual
                competenceCreatedOn, // created_at
                competenceCreatedOn,   // updated_at
                0  // isDeleted
              ]);
            }
          }
        }

        // Bulk insert all dealer_investment_competence entries
        if (dealerInvestmentCompetenceValues.length > 0) {
          let bulkInsertDealerInvestmentCompetenceQuery = "";
          let dealerInvestmentCompetenceFlatValues = [];
          try {
            console.log(`[addPdp] Attempting BULK INSERT into table: dealer_investment_competence (${dealerInvestmentCompetenceValues.length} entries)`);
            const dealerInvestmentCompetencePlaceholders = dealerInvestmentCompetenceValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
            bulkInsertDealerInvestmentCompetenceQuery = `
              INSERT INTO dealer_investment_competence (pdpId, pdpCompetenceId, dealerInvestmentId, q1, q2, q3, q4, ytd_actual, created_at, updated_at, isDeleted)
              VALUES ${dealerInvestmentCompetencePlaceholders}
            `;
            dealerInvestmentCompetenceFlatValues = dealerInvestmentCompetenceValues.flat();
            console.log(`[addPdp] Query columns: pdpId, pdpCompetenceId, dealerInvestmentId, q1, q2, q3, q4, ytd_actual, created_at, updated_at, isDeleted`);
            console.log(`[addPdp] Total values count: ${dealerInvestmentCompetenceFlatValues.length}, Expected: ${dealerInvestmentCompetenceValues.length * 11}`);
            await connection.query(bulkInsertDealerInvestmentCompetenceQuery, dealerInvestmentCompetenceFlatValues);
            console.log(`[addPdp] ✓ Successfully inserted ${dealerInvestmentCompetenceValues.length} entries into dealer_investment_competence`);
          } catch (error) {
            console.error(`[addPdp] ✗ ERROR inserting into dealer_investment_competence:`, error.message);
            console.error(`[addPdp] Error details:`, error);
            console.error(`[addPdp] Query:`, bulkInsertDealerInvestmentCompetenceQuery);
            console.error(`[addPdp] Values count: ${dealerInvestmentCompetenceFlatValues.length}`);
            throw error;
          }
        }
      }

      // Bulk insert all pdp_signoff entries in a single query
      if (pdpSignoffValues.length > 0) {
        const signoffPlaceholders = pdpSignoffValues.map(() => '(?, ?, ?, ?, ?, ?)').join(', ');
        const bulkInsertPdpSignoffQuery = `
          INSERT INTO pdp_signoff (pdpId, userId, category, created_at, updated_at, isDeleted)
          VALUES ${signoffPlaceholders}
        `;
        const signoffFlatValues = pdpSignoffValues.flat();
        try {
          console.log(`[addPdp] Attempting BULK INSERT into table: pdp_signoff (${pdpSignoffValues.length} entries)`);
          console.log(`[addPdp] Query columns: pdpId, userId, category, created_at, updated_at`);
          console.log(`[addPdp] Total values count: ${signoffFlatValues.length}, Expected: ${pdpSignoffValues.length * 5}`);
          await connection.query(bulkInsertPdpSignoffQuery, signoffFlatValues);
          console.log(`[addPdp] ✓ Successfully inserted ${pdpSignoffValues.length} entries into pdp_signoff`);
        } catch (error) {
          console.error(`[addPdp] ✗ ERROR inserting into pdp_signoff:`, error.message);
          console.error(`[addPdp] Error details:`, error);
          console.error(`[addPdp] Query:`, bulkInsertPdpSignoffQuery);
          console.error(`[addPdp] Values count: ${signoffFlatValues.length}`);
          throw error;
        }
      }

      // Bulk insert all pdp_marcom_branding entries in a single query
      if (pdpMarcomBrandingValues.length > 0) {
        let bulkInsertPdpMarcomBrandingQuery = "";
        let marcomBrandingFlatValues = [];
        try {
          console.log(`[addPdp] Attempting BULK INSERT into table: pdp_marcom_branding (${pdpMarcomBrandingValues.length} entries)`);
          const marcomBrandingPlaceholders = pdpMarcomBrandingValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
          bulkInsertPdpMarcomBrandingQuery = `
            INSERT INTO pdp_marcom_branding (pdpId, marcom_branding_id, budget, remarks, supportive_doc_url, created_at, updated_at, isDeleted)
            VALUES ${marcomBrandingPlaceholders}
          `;
          marcomBrandingFlatValues = pdpMarcomBrandingValues.flat();
          console.log(`[addPdp] Query columns: pdpId, marcom_branding_id, budget, remarks, supportive_doc_url, created_at, updated_at, isDeleted`);
          console.log(`[addPdp] Total values count: ${marcomBrandingFlatValues.length}, Expected: ${pdpMarcomBrandingValues.length * 8}`);
          await connection.query(bulkInsertPdpMarcomBrandingQuery, marcomBrandingFlatValues);
          console.log(`[addPdp] ✓ Successfully inserted ${pdpMarcomBrandingValues.length} entries into pdp_marcom_branding`);
        } catch (error) {
          console.error(`[addPdp] ✗ ERROR inserting into pdp_marcom_branding:`, error.message);
          console.error(`[addPdp] Error details:`, error);
          console.error(`[addPdp] Query:`, bulkInsertPdpMarcomBrandingQuery);
          console.error(`[addPdp] Values count: ${marcomBrandingFlatValues.length}`);
          throw error;
        }
      }

      // Bulk insert all pdp_marcom_marketing entries in a single query
      if (pdpMarcomMarketingValues.length > 0) {
        let bulkInsertPdpMarcomMarketingQuery = "";
        let marcomMarketingFlatValues = [];
        try {
          console.log(`[addPdp] Attempting BULK INSERT into table: pdp_marcom_marketing (${pdpMarcomMarketingValues.length} entries)`);
          const marcomMarketingPlaceholders = pdpMarcomMarketingValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
          bulkInsertPdpMarcomMarketingQuery = `
            INSERT INTO pdp_marcom_marketing (pdpId, marcom_marketing_id, marketing_area, count_of_activities, activity_description, amount_spent, impacts, created_at, updated_at, isDeleted)
            VALUES ${marcomMarketingPlaceholders}
          `;
          marcomMarketingFlatValues = pdpMarcomMarketingValues.flat();
          console.log(`[addPdp] Query columns: pdpId, marcom_marketing_id, marketing_area, count_of_activities, activity_description, amount_spent, impacts, created_at, updated_at, isDeleted`);
          console.log(`[addPdp] Total values count: ${marcomMarketingFlatValues.length}, Expected: ${pdpMarcomMarketingValues.length * 10}`);
          await connection.query(bulkInsertPdpMarcomMarketingQuery, marcomMarketingFlatValues);
          console.log(`[addPdp] ✓ Successfully inserted ${pdpMarcomMarketingValues.length} entries into pdp_marcom_marketing`);
        } catch (error) {
          console.error(`[addPdp] ✗ ERROR inserting into pdp_marcom_marketing:`, error.message);
          console.error(`[addPdp] Error details:`, error);
          console.error(`[addPdp] Query:`, bulkInsertPdpMarcomMarketingQuery);
          console.error(`[addPdp] Values count: ${marcomMarketingFlatValues.length}`);
          throw error;
        }
      }

      // Send email notifications to admin users for each PDP created
      if (adminEmails.length > 0 && pdpDetailsForEmail.length > 0) {
        for (const pdpDetail of pdpDetailsForEmail) {
          // Send emails asynchronously (don't wait for completion to avoid blocking response)
          eMailer.pdpCreatedMail(adminEmails, pdpDetail)
            .then(emailResults => {
              console.log(`PDP creation emails sent for PDP ID ${pdpDetail.id}:`, emailResults);
            })
            .catch(emailError => {
              console.error(`Error sending PDP creation emails for PDP ID ${pdpDetail.id}:`, emailError);
            });
        }
      } else {
        if (adminEmails.length === 0) {
          console.log('No admin users found with valid email addresses for PDP creation notification');
        }
      }

      // Create notification for relevant users
      if (createdPdpIds.length > 0) {
        // Fetch mapped users for these dealers from userdealers table
        const mappedUsers = await connection.query(
          "SELECT DISTINCT userId FROM userdealers WHERE dealerId IN (?) AND isDeleted = 0",
          [dealerIds]
        );
        const mappedUserIds = mappedUsers.map((u) => u.userId).filter((id) => id);

        // Combine Current User + Administrators + Mapped Dealer Users
        const allRecipientUserIds = [
          ...new Set([
            req.decodedToken,
            ...adminUserIds,
            ...mappedUserIds
          ])
        ].filter(id => id);

        if (allRecipientUserIds.length > 0) {
          console.log(`[addPdp] Sending notifications to userIds:`, allRecipientUserIds);
          const notificationTitle = "New PDP Created";
          const notificationMessage = `${createdPdpIds.length} new PDP(s) have been created for year ${year}. PDP IDs: ${createdPdpIds.join(', ')}`;
          createNotification(notificationTitle, notificationMessage, allRecipientUserIds).catch(err => {
            console.error("Error creating notification for PDP creation:", err);
          });
        }
      }

      return res.status(200).send({
        status: true,
        message: "PDP created successfully",
        ids: createdPdpIds,
        count: createdPdpIds.length
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllPdp: async function (req, res) {
    try {
      // Extract userId from decoded token
      const userId = req.decodedToken;

      if (!userId) {
        return res.status(401).send({ status: false, message: "User not authenticated" });
      }

      // Fetch user persona and marketArea from userdetails table
      const userQuery = `
        SELECT persona, marketArea 
        FROM userdetails 
        WHERE id = ? AND isDeleted = 0
      `;
      const userResult = await connection.query(userQuery, [userId]);

      if (userResult.length === 0) {
        return res.status(404).send({ status: false, message: "User not found" });
      }

      const userPersona = userResult[0].persona;
      let userMarketArea = userResult[0].marketArea;

      // Debug logging
      console.log(`[getAllPdp] User ID: ${userId}`);
      console.log(`[getAllPdp] User Persona: "${userPersona}"`);
      console.log(`[getAllPdp] User Market Area (raw): ${userMarketArea}`);

      // If marketArea is a string (name), convert it to ID
      if (userMarketArea && isNaN(userMarketArea)) {
        const marketAreaQuery = `
          SELECT id FROM market_area WHERE marketarea = ? AND isDeleted = 0
        `;
        const marketAreaResult = await connection.query(marketAreaQuery, [userMarketArea]);
        if (marketAreaResult.length > 0) {
          userMarketArea = marketAreaResult[0].id;
          console.log(`[getAllPdp] Converted Market Area name to ID: ${userMarketArea}`);
        } else {
          console.log(`[getAllPdp] WARNING: Market Area "${userMarketArea}" not found in market_area table`);
          userMarketArea = null;
        }
      }

      // Define personas with full access (can see all PDPs)
      // TODO: Update this array based on actual business requirements
      const fullAccessPersonas = [
        'Administrator',
        'Volvo Functional Manager',
        'IMT',
        'Head of Channel Development Region India'
      ];

      // Define personas with restricted access (can only see PDPs for their mapped dealers)
      // TODO: Update this array based on actual business requirements
      const restrictedAccessPersonas = [
        'Dealer Parts Manager',
        'Dealer Coordinator',
        'Dealer sales head',
        'Dealer CST Head',
        'Dealer Finance Head',
        'Dealer HR Head',
        'Dealer Principal',
        'Dealer CEO'
      ];

      // Define personas with market area restriction (can see PDPs for mapped dealers AND their market area)
      const restrictedMarketArea = [
        'Uptime & Parts Manager',
        'Retail Sales Manager',
        'Key Account Manager Uptime & Parts',
        'Key Account Manager Sales',
        'Market Area Head'
      ]

      // Pagination: default page 1, size 500
      const page = req.query.page && !isNaN(parseInt(req.query.page)) ? parseInt(req.query.page) : 1;
      const limit = 300;
      const offset = (page - 1) * limit;

      // Extract filters
      const { year, market_area, dealer, sign_of_status, action_item_status, search } = req.query;

      // START Building Base Query (WITHOUT WHERE clauses for specific filters yet)
      let baseQuery = `
        SELECT 
          p.id,
          p.year,
          p.market_area,
          p.dealer,
          p.choose_dealer,
          p.pdp_start_date,
          p.pdp_end_date,
          p.physical_pdp_start_date,
          p.physical_pdp_end_date,
          p.sign_of_status,
          p.return_back_comment,
          p.sign_off_meeting_date,
          p.venue_details,
          p.special_note,
          p.completed_date,
          p.approved_by,
          p.scheduled_by,
          p.created_at,
          p.updated_at,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          d.dealerShortName as dealer_short_name,
          approver.firstName as approved_by_name,
          scheduler.firstName as scheduled_by_name,
          COALESCE(action_stats.total_count, 0) as action_item_count,
          CAST(COALESCE(action_stats.open_count, 0) AS UNSIGNED) as action_item_count_open,
          CAST(COALESCE(action_stats.completed_count, 0) AS UNSIGNED) as action_item_count_completed,
          CASE 
            WHEN COALESCE(action_stats.total_count, 0) = 0 THEN 'Not Started'
            WHEN COALESCE(action_stats.open_count, 0) = COALESCE(action_stats.total_count, 0) THEN 'Open'
            WHEN COALESCE(action_stats.completed_count, 0) = COALESCE(action_stats.total_count, 0) THEN 'Completed'
            ELSE 'In Progress'
          END as consolidated_actionItem_status
        FROM pdp p
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        LEFT JOIN userdetails approver ON p.approved_by = approver.id
        LEFT JOIN userdetails scheduler ON p.scheduled_by = scheduler.id
        LEFT JOIN (
          SELECT 
            pdp,
            COUNT(*) as total_count,
            SUM(CASE WHEN status = 'Open' THEN 1 ELSE 0 END) as open_count,
            SUM(CASE WHEN status = 'Closed' THEN 1 ELSE 0 END) as completed_count
          FROM pdp_action_item
          WHERE (isActive = 1 OR isActive IS NULL) AND isDeleted = 0
          GROUP BY pdp
        ) as action_stats ON p.id = action_stats.pdp
      `;

      // Helper to handle access control logic
      let accessControlWhere = "";
      let accessControlParams = [];

      if (fullAccessPersonas.includes(userPersona)) {
        console.log(`[getAllPdp] Access Level: Full Access`);
        accessControlWhere = "1=1";
      } else if (restrictedMarketArea.includes(userPersona)) {
        console.log(`[getAllPdp] Access Level: Market Area Restricted`);
        // If userMarketArea is null, they might see nothing, or we might need to handle it.
        // Assuming userMarketArea is required for this persona.
        if (!userMarketArea) {
          // Fallback to mapped dealers if no market area is found/assigned
          accessControlWhere = "p.dealer IN (SELECT dealerId FROM userdealers WHERE userId = ? AND isDeleted = 0)";
          accessControlParams = [userId];
        } else {
          accessControlWhere = "(p.market_area = ? OR p.dealer IN (SELECT dealerId FROM userdealers WHERE userId = ? AND isDeleted = 0))";
          accessControlParams = [userMarketArea, userId];
        }

      } else if (restrictedAccessPersonas.includes(userPersona)) {
        console.log(`[getAllPdp] Access Level: Dealer Restricted`);
        accessControlWhere = "p.dealer IN (SELECT dealerId FROM userdealers WHERE userId = ? AND isDeleted = 0)";
        accessControlParams = [userId];
      } else {
        console.log(`[getAllPdp] Access Level: DENIED - Unknown persona`);
        return res.status(403).send({
          status: false,
          message: "Access denied: Your persona does not have permission to view PDPs"
        });
      }

      // Now apply dynamic filters
      let filterWhere = [];
      let filterParams = [];

      // Helper to process multiple selection (handles arrays and comma-separated strings)
      const getFilterArray = (val) => {
        if (!val) return [];
        if (Array.isArray(val)) return val.filter(v => typeof v === 'string' ? v.trim() !== "" : v !== null);
        return typeof val === 'string' ? val.split(',').map(v => v.trim()).filter(v => v !== "") : [val];
      };

      const yearArr = getFilterArray(year);
      if (yearArr.length > 0) {
        filterWhere.push("p.year IN (?)");
        filterParams.push(yearArr);
      }

      const marketAreaArr = getFilterArray(market_area);
      if (marketAreaArr.length > 0) {
        // If filtering by name or ID (Check first element to decide column)
        if (isNaN(marketAreaArr[0])) {
          filterWhere.push("ma.marketarea IN (?)");
        } else {
          filterWhere.push("p.market_area IN (?)");
        }
        filterParams.push(marketAreaArr);
      }

      const dealerArr = getFilterArray(dealer);
      if (dealerArr.length > 0) {
        // If filtering by name or ID
        if (isNaN(dealerArr[0])) {
          filterWhere.push("d.dealerShortName IN (?)");
        } else {
          filterWhere.push("p.dealer IN (?)");
        }
        filterParams.push(dealerArr);
      }

      const signOfStatusArr = getFilterArray(sign_of_status);
      if (signOfStatusArr.length > 0) {
        if (signOfStatusArr.includes('Created')) {
          // If 'Created' is selected, we include NULL values as well as per original logic
          filterWhere.push("(p.sign_of_status IN (?) OR p.sign_of_status IS NULL)");
        } else {
          filterWhere.push("p.sign_of_status IN (?)");
        }
        filterParams.push(signOfStatusArr);
      }

      if (search && search.trim() !== "") {
        const searchTerm = `%${search.trim()}%`;
        filterWhere.push("(p.year LIKE ? OR ma.marketarea LIKE ? OR d.dealerName LIKE ?)");
        filterParams.push(searchTerm, searchTerm, searchTerm);
      }

      // Combine Access Control AND Filters AND Search
      // We will wrap the base query to handle 'consolidated_actionItem_status' simpler?
      // Or just apply the WHERE clauses to the inner query.
      // consolidated_actionItem_status is computed. can't filter in WHERE.
      // So we MUST wrap if filtering by action_item_status.
      // Even if not filtering by it, clean separation is nice.

      let finalQuery = `
          SELECT * FROM (
            ${baseQuery}
            WHERE ${accessControlWhere} AND p.isDeleted = 0 AND ma.isDeleted = 0 AND d.isDeleted = 0
            ${filterWhere.length > 0 ? "AND " + filterWhere.join(" AND ") : ""}
          ) as derived_table
      `;

      let finalParams = [...accessControlParams, ...filterParams];

      // Now filter by action_item_status (if present)
      const actionItemStatusArr = getFilterArray(action_item_status);
      if (actionItemStatusArr.length > 0) {
        finalQuery += " WHERE consolidated_actionItem_status IN (?)";
        finalParams.push(actionItemStatusArr);
      }

      // Add Order By and Pagination
      finalQuery += ` ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`;
      finalParams.push(limit, offset);

      console.log(`[getAllPdp] Final Query: ${finalQuery}`);
      console.log(`[getAllPdp] Params: ${JSON.stringify(finalParams)}`);

      const pdpRows = await connection.query(finalQuery, finalParams);

      console.log(`[getAllPdp] Query returned ${pdpRows.length} PDPs`);

      if (pdpRows.length === 0) {
        return res.status(200).send({ status: true, message: "No PDP records found", data: [] });
      }

      const data = pdpRows.map(p => ({
        ...p,
        action_item_count: Number(p.action_item_count),
        action_item_count_open: Number(p.action_item_count_open),
        action_item_count_completed: Number(p.action_item_count_completed),
        dealer_info: {
          dealer_id: p.dealer,
          dealer_name: p.dealer_name
        },
        approved_by_info: {
          user_id: p.approved_by,
          user_name: p.approved_by_name
        },
        scheduled_by_info: {
          user_id: p.scheduled_by,
          user_name: p.scheduled_by_name
        }
      }));

      return res.status(200).send({ status: true, message: "PDP list retrieved", data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getPdpById: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const pdpQuery = `
        SELECT 
          p.id,
          p.year,
          p.market_area,
          p.dealer,
          p.choose_dealer,
          p.pdp_start_date,
          p.pdp_end_date,
          p.physical_pdp_start_date,
          p.physical_pdp_end_date,
          p.sign_of_status,
          p.return_back_comment,
          p.sign_off_meeting_date,
          p.venue_details,
          p.special_note,
          p.completed_date,
          p.approved_by,
          p.scheduled_by,
          p.created_at,
          p.updated_at,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          approver.name as approved_by_name,
          scheduler.name as scheduled_by_name
        FROM pdp p
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        LEFT JOIN userdetails approver ON p.approved_by = approver.id
        LEFT JOIN userdetails scheduler ON p.scheduled_by = scheduler.id
        WHERE p.id = ? AND p.isDeleted = 0 AND ma.isDeleted = 0 AND d.isDeleted = 0
      `;
      const pdpRows = await connection.query(pdpQuery, [id]);
      if (pdpRows.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const result = {
        ...pdpRows[0],
        dealer_info: {
          dealer_id: pdpRows[0].dealer,
          dealer_name: pdpRows[0].dealer_name
        },
        approved_by_info: {
          user_id: pdpRows[0].approved_by,
          user_name: pdpRows[0].approved_by_name
        },
        scheduled_by_info: {
          user_id: pdpRows[0].scheduled_by,
          user_name: pdpRows[0].scheduled_by_name
        }
      };

      return res.status(200).send({ status: true, message: "PDP retrieved", data: result });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updatePdp: async function (req, res) {
    try {
      const {
        id,
        year,
        market_area,
        dealer,
        choose_dealer,
        pdp_start_date,
        pdp_end_date,
        physical_pdp_start_date,
        physical_pdp_end_date,
        sign_of_status,
        return_back_comment,
        sign_off_meeting_date,
        venue_details,
        special_note
      } = req.body;

      if (!id || !year || !market_area || !dealer || !choose_dealer || !pdp_start_date || !pdp_end_date) {
        return res.status(400).send({
          status: false,
          message: "Required: id, year, market_area, dealer, choose_dealer, pdp_start_date, pdp_end_date"
        });
      }

      const exists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Fetch old PDP details with market area and dealer names for email
      const oldPdpDetailsQuery = `
        SELECT 
          p.id,
          p.year,
          p.market_area,
          p.dealer,
          p.choose_dealer,
          p.pdp_start_date,
          p.pdp_end_date,
          p.physical_pdp_start_date,
          p.physical_pdp_end_date,
          p.sign_of_status,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp p
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE p.id = ? AND p.isDeleted = 0 AND ma.isDeleted = 0 AND d.isDeleted = 0
      `;
      const oldPdpDetails = await connection.query(oldPdpDetailsQuery, [id]);

      if (oldPdpDetails.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build UPDATE query with all fields including the new columns
      const updatePdpQuery = `
        UPDATE pdp
        SET year = ?, market_area = ?, dealer = ?, choose_dealer = ?, pdp_start_date = ?, pdp_end_date = ?,
            physical_pdp_start_date = ?, physical_pdp_end_date = ?, sign_of_status = ?, 
            return_back_comment = ?, sign_off_meeting_date = ?, venue_details = ?, special_note = ?, updated_at = ?
        WHERE id = ? AND isDeleted = 0
      `;

      const queryParams = [
        year,
        market_area,
        dealer,
        choose_dealer,
        pdp_start_date,
        pdp_end_date,
        physical_pdp_start_date || null,
        physical_pdp_end_date || null,
        sign_of_status || null,
        return_back_comment || null,
        sign_off_meeting_date || null,
        venue_details || null,
        special_note || null,
        updatedOn,
        id
      ];

      await connection.query(updatePdpQuery, queryParams);

      // Fetch new PDP details with market area and dealer names for email
      const newPdpDetailsQuery = `
        SELECT 
          p.id,
          p.year,
          p.market_area,
          p.dealer,
          p.choose_dealer,
          p.pdp_start_date,
          p.pdp_end_date,
          p.physical_pdp_start_date,
          p.physical_pdp_end_date,
          p.sign_of_status,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp p
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE p.id = ? AND p.isDeleted = 0 AND ma.isDeleted = 0 AND d.isDeleted = 0
      `;
      const newPdpDetails = await connection.query(newPdpDetailsQuery, [id]);

      // Fetch all admin users' emails and IDs
      const adminUsersQuery = `
        SELECT id, email 
        FROM userdetails 
        WHERE persona = 'Administrator' AND email IS NOT NULL AND email != '' AND isDeleted = 0
      `;
      const adminUsers = await connection.query(adminUsersQuery);
      const adminEmails = adminUsers.map(user => user.email).filter(email => email && email.trim() !== '');
      const adminUserIds = adminUsers.map(user => user.id).filter(id => id);

      // Send email notifications to admin users
      if (adminEmails.length > 0 && newPdpDetails.length > 0) {
        const oldPdpData = oldPdpDetails[0];
        const newPdpData = newPdpDetails[0];

        // Send emails asynchronously (don't wait for completion to avoid blocking response)
        eMailer.pdpUpdatedMail(adminEmails, oldPdpData, newPdpData)
          .then(emailResults => {
            console.log(`PDP update emails sent for PDP ID ${id}:`, emailResults);
          })
          .catch(emailError => {
            console.error(`Error sending PDP update emails for PDP ID ${id}:`, emailError);
          });
      } else {
        if (adminEmails.length === 0) {
          console.log('No admin users found with valid email addresses for PDP update notification');
        }
      }

      // Create notification for admin users
      if (adminUserIds.length > 0) {
        const notificationTitle = "PDP Updated";
        const notificationMessage = `PDP has been updated. PDP ID: ${id}`;
        createNotification(notificationTitle, notificationMessage, adminUserIds).catch(err => {
          console.error("Error creating notification for PDP update:", err);
        });
      }

      return res.status(200).send({ status: true, message: "PDP updated successfully" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  pdpStatusChange: async function (req, res) {
    try {
      const { id, status, return_back_comment } = req.body;

      // Extract userId from decoded token
      const userId = req.decodedToken;

      // Validate required fields
      if (!id || !status) {
        return res.status(400).send({
          status: false,
          message: "Required: id and status"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id, sign_of_status, isDeleted FROM pdp WHERE id = ?`, [id]);
      if (pdpExists.length === 0 || pdpExists[0].isDeleted) {
        return res.status(404).send({ status: false, message: "PDP not found or deleted" });
      }

      // Map status to sign_of_status values
      let signOfStatus;
      switch (status) {
        case "Started":
          signOfStatus = "Started";
          break;
        case "Submit":
          signOfStatus = "Pending Review";
          break;
        case "Approved":
          signOfStatus = "Approved";
          break;
        case "Return":
          signOfStatus = "Started";
          break;
        default:
          return res.status(400).send({
            status: false,
            message: "Invalid status. Allowed values: Started, Submit, Approved, Return"
          });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Build UPDATE query
      let updateQuery;
      let queryParams;

      if (status === "Return") {
        // Update both sign_of_status and return_back_comment for Return status (return_back_comment is optional)
        updateQuery = `
          UPDATE pdp
          SET sign_of_status = ?, return_back_comment = ?, updated_at = ?
          WHERE id = ? AND isDeleted = 0
        `;
        queryParams = [signOfStatus, return_back_comment || null, updatedOn, id];
      } else if (status === "Approved") {
        // Update sign_of_status and approved_by for Approved status
        updateQuery = `
          UPDATE pdp
          SET sign_of_status = ?, approved_by = ?, updated_at = ?
          WHERE id = ? AND isDeleted = 0
        `;
        queryParams = [signOfStatus, userId, updatedOn, id];
      } else {
        // Update only sign_of_status for other statuses
        updateQuery = `
          UPDATE pdp
          SET sign_of_status = ?, updated_at = ?
          WHERE id = ? AND isDeleted = 0
        `;
        queryParams = [signOfStatus, updatedOn, id];
      }

      await connection.query(updateQuery, queryParams);

      return res.status(200).send({
        status: true,
        message: `PDP status updated to ${signOfStatus} successfully`
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updatePdpMeetingDetails: async function (req, res) {
    try {
      const { id, sign_off_meeting_date, venue_details, special_note } = req.body;

      // Extract userId from decoded token
      const userId = req.decodedToken;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      if (!sign_off_meeting_date || !venue_details) {
        return res.status(400).send({
          status: false,
          message: "Required: sign_off_meeting_date and venue_details"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [id]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found or deleted" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // Update the meeting details
      const updateQuery = `
        UPDATE pdp
        SET sign_off_meeting_date = ?, venue_details = ?, special_note = ?, scheduled_by = ?, updated_at = ?
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, [
        sign_off_meeting_date,
        venue_details,
        special_note || null,
        userId,
        updatedOn,
        id
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP meeting details updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deletePdp: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP exists and get its sign_of_status
      const pdpResult = await connection.query(`SELECT id, sign_of_status, isDeleted FROM pdp WHERE id = ?`, [id]);
      if (pdpResult.length === 0 || pdpResult[0].isDeleted) {
        return res.status(404).send({ status: false, message: "PDP not found or already deleted" });
      }

      const pdp = pdpResult[0];

      // Only allow deletion if sign_of_status is "Created"
      if (pdp.sign_of_status !== "Created") {
        return res.status(403).send({
          status: false,
          message: `Cannot delete PDP. Only PDPs with status "Created" can be deleted. Current status: "${pdp.sign_of_status}"`
        });
      }

      console.log(`[deletePdp] Starting cascade delete for PDP ID: ${id}`);

      // Get dealer_investment IDs for this PDP (needed for nested deletions)
      const dealerInvestmentResult = await connection.query(
        `SELECT id FROM dealer_investment WHERE pdpId = ? AND isDeleted = 0`,
        [id]
      );
      const dealerInvestmentIds = dealerInvestmentResult.map(di => di.id);
      console.log(`[deletePdp] Found ${dealerInvestmentIds.length} active dealer_investment records`);

      // Get pdp_equipments IDs for this PDP (needed for nested deletions)
      const pdpEquipmentsResult = await connection.query(
        `SELECT id FROM pdp_equipments WHERE pdpId = ? AND isDeleted = 0`,
        [id]
      );
      const pdpEquipmentIds = pdpEquipmentsResult.map(pe => pe.id);
      console.log(`[deletePdp] Found ${pdpEquipmentIds.length} active pdp_equipments records`);

      // Get pdp_uptime_parts IDs for this PDP (needed for nested deletions)
      const pdpUptimePartsResult = await connection.query(
        `SELECT id FROM pdp_uptime_parts WHERE pdpId = ? AND isDeleted = 0`,
        [id]
      );
      const pdpUptimeIds = pdpUptimePartsResult.map(pu => pu.id);
      console.log(`[deletePdp] Found ${pdpUptimeIds.length} active pdp_uptime_parts records`);

      // Get pdp_infrastructure IDs for this PDP (needed for nested deletions)
      const pdpInfrastructureResult = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE pdpId = ? AND isDeleted = 0`,
        [id]
      );
      const pdpInfrastructureIds = pdpInfrastructureResult.map(pi => pi.id);
      console.log(`[deletePdp] Found ${pdpInfrastructureIds.length} active pdp_infrastructure records`);

      // Get pdp_competence_development IDs for this PDP (needed for nested deletions)
      const pdpCompetenceResult = await connection.query(
        `SELECT id FROM pdp_competence_development WHERE pdpId = ? AND isDeleted = 0`,
        [id]
      );
      const pdpCompetenceIds = pdpCompetenceResult.map(pc => pc.id);
      console.log(`[deletePdp] Found ${pdpCompetenceIds.length} active pdp_competence_development records`);

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      // 1. Soft delete dealer_investment_equipment_* records (children of pdp_equipments)
      if (pdpEquipmentIds.length > 0) {
        await connection.query(
          `UPDATE dealer_investment_equipment_mbp SET isDeleted = 1, updated_at = ? WHERE pdpEquipmentId IN (?)`,
          [updatedOn, pdpEquipmentIds]
        );
        console.log(`[deletePdp] Marked dealer_investment_equipment_mbp records as deleted`);

        await connection.query(
          `UPDATE dealer_investment_equipment_projection SET isDeleted = 1, updated_at = ? WHERE pdpEquipmentId IN (?)`,
          [updatedOn, pdpEquipmentIds]
        );
        console.log(`[deletePdp] Marked dealer_investment_equipment_projection records as deleted`);

        await connection.query(
          `UPDATE dealer_investment_equipment_actuals SET isDeleted = 1, updated_at = ? WHERE pdpEquipmentId IN (?)`,
          [updatedOn, pdpEquipmentIds]
        );
        console.log(`[deletePdp] Marked dealer_investment_equipment_actuals records as deleted`);
      }

      // 2. Soft delete dealer_investment_uptime_* records (children of pdp_uptime_parts)
      if (pdpUptimeIds.length > 0) {
        await connection.query(
          `UPDATE dealer_investment_uptime_mbp SET isDeleted = 1, updated_at = ? WHERE pdpUptimeId IN (?)`,
          [updatedOn, pdpUptimeIds]
        );
        console.log(`[deletePdp] Marked dealer_investment_uptime_mbp records as deleted`);

        await connection.query(
          `UPDATE dealer_investment_uptime_projection SET isDeleted = 1, updated_at = ? WHERE pdpUptimeId IN (?)`,
          [updatedOn, pdpUptimeIds]
        );
        console.log(`[deletePdp] Marked dealer_investment_uptime_projection records as deleted`);

        await connection.query(
          `UPDATE dealer_investment_uptime_actuals SET isDeleted = 1, updated_at = ? WHERE pdpUptimeId IN (?)`,
          [updatedOn, pdpUptimeIds]
        );
        console.log(`[deletePdp] Marked dealer_investment_uptime_actuals records as deleted`);
      }

      // 3. Soft delete dealer_investment_infrastructure records (children of pdp_infrastructure)
      if (pdpInfrastructureIds.length > 0) {
        await connection.query(
          `UPDATE dealer_investment_infrastructure SET isDeleted = 1, updated_at = ? WHERE pdpInfrastructureId IN (?)`,
          [updatedOn, pdpInfrastructureIds]
        );
        console.log(`[deletePdp] Marked dealer_investment_infrastructure records as deleted`);
      }

      // 4. Soft delete dealer_investment_competence records (children of pdp_competence_development)
      if (pdpCompetenceIds.length > 0) {
        await connection.query(
          `UPDATE dealer_investment_competence SET isDeleted = 1, updated_at = ? WHERE pdpCompetenceId IN (?)`,
          [updatedOn, pdpCompetenceIds]
        );
        console.log(`[deletePdp] Marked dealer_investment_competence records as deleted`);
      }

      // 5. Soft delete dealer_investment_allocation records (children of dealer_investment)
      if (dealerInvestmentIds.length > 0) {
        await connection.query(
          `UPDATE dealer_investment_allocation SET isDeleted = 1, updated_at = ? WHERE dealerInvestmentId IN (?)`,
          [updatedOn, dealerInvestmentIds]
        );
        console.log(`[deletePdp] Marked dealer_investment_allocation records as deleted`);
      }

      // 6. Soft delete dealer_investment_machine_population records (children of dealer_investment)
      if (dealerInvestmentIds.length > 0) {
        await connection.query(
          `UPDATE dealer_investment_machine_population SET isDeleted = 1, updated_at = ? WHERE dealerInvestmentId IN (?)`,
          [updatedOn, dealerInvestmentIds]
        );
        console.log(`[deletePdp] Marked dealer_investment_machine_population records as deleted`);
      }

      // 7. Soft delete direct PDP child records
      await connection.query(`UPDATE pdp_equipments SET isDeleted = 1 WHERE pdpId = ?`, [id]);
      console.log(`[deletePdp] Marked pdp_equipments records as deleted`);

      await connection.query(`UPDATE pdp_uptime_parts SET isDeleted = 1 WHERE pdpId = ?`, [id]);
      console.log(`[deletePdp] Marked pdp_uptime_parts records as deleted`);

      await connection.query(`UPDATE pdp_infrastructure SET isDeleted = 1, updated_at = ? WHERE pdpId = ?`, [updatedOn, id]);
      console.log(`[deletePdp] Marked pdp_infrastructure records as deleted`);

      await connection.query(`UPDATE pdp_others SET isDeleted = 1, updated_at = ? WHERE pdpId = ?`, [updatedOn, id]);
      console.log(`[deletePdp] Marked pdp_others records as deleted`);

      await connection.query(`UPDATE pdp_competence_development SET isDeleted = 1, updated_at = ? WHERE pdpId = ?`, [updatedOn, id]);
      console.log(`[deletePdp] Marked pdp_competence_development records as deleted`);

      await connection.query(`UPDATE pdp_signoff SET isDeleted = 1, updated_at = ? WHERE pdpId = ?`, [updatedOn, id]);
      console.log(`[deletePdp] Marked pdp_signoff records as deleted`);

      await connection.query(`UPDATE pdp_marcom_branding SET isDeleted = 1, updated_at = ? WHERE pdpId = ?`, [updatedOn, id]);
      console.log(`[deletePdp] Marked pdp_marcom_branding records as deleted`);

      await connection.query(`UPDATE pdp_marcom_marketing SET isDeleted = 1, updated_at = ? WHERE pdpId = ?`, [updatedOn, id]);
      console.log(`[deletePdp] Marked pdp_marcom_marketing records as deleted`);

      await connection.query(`UPDATE pdp_territory_focus_entries_stats SET isDeleted = 1, updated_at = ? WHERE pdpId = ?`, [updatedOn, id]);
      console.log(`[deletePdp] Marked pdp_territory_focus_entries_stats records as deleted`);

      await connection.query(`UPDATE dealer_investment SET isDeleted = 1, updated_at = ? WHERE pdpId = ?`, [updatedOn, id]);
      console.log(`[deletePdp] Marked dealer_investment records as deleted`);

      // 8. Finally, soft delete the PDP itself
      await connection.query(`UPDATE pdp SET isDeleted = 1, updated_at = ? WHERE id = ?`, [updatedOn, id]);
      console.log(`[deletePdp] Marked PDP record as deleted`);

      console.log(`[deletePdp] Successfully completed soft delete for PDP ID: ${id}`);
      return res.status(200).send({ status: true, message: "PDP and all related records marked as deleted successfully" });
    } catch (error) {
      console.error(`[deletePdp] Error during soft delete:`, error);
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllPdpWithActionItemCounts: async function (req, res) {
    try {
      const pdpQuery = `
        SELECT 
          p.id,
          p.year,
          p.market_area,
          p.dealer,
          p.choose_dealer,
          p.pdp_start_date,
          p.pdp_end_date,
          p.physical_pdp_start_date,
          p.physical_pdp_end_date,
          p.sign_of_status,
          p.return_back_comment,
          p.sign_off_meeting_date,
          p.venue_details,
          p.special_note,
          p.completed_date,
          p.created_at,
          p.updated_at,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          COALESCE(SUM(CASE WHEN pai.status = 'Open' AND (pai.isDeleted = FALSE OR pai.isDeleted = 0) AND (pai.isActive = TRUE OR pai.isActive = 1) THEN 1 ELSE 0 END), 0) as open_count,
          COALESCE(SUM(CASE WHEN pai.status = 'In Progress' AND (pai.isDeleted = FALSE OR pai.isDeleted = 0) AND (pai.isActive = TRUE OR pai.isActive = 1) THEN 1 ELSE 0 END), 0) as ongoing_count,
          COALESCE(SUM(CASE WHEN pai.status = 'Closed' AND (pai.isDeleted = FALSE OR pai.isDeleted = 0) AND (pai.isActive = TRUE OR pai.isActive = 1) THEN 1 ELSE 0 END), 0) as closed_count
        FROM pdp p
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        LEFT JOIN pdp_action_item pai ON p.id = pai.pdp
        WHERE p.isDeleted = 0 AND ma.isDeleted = 0 AND d.isDeleted = 0
        GROUP BY 
          p.id,
          p.year,
          p.market_area,
          p.dealer,
          p.choose_dealer,
          p.pdp_start_date,
          p.pdp_end_date,
          p.physical_pdp_start_date,
          p.physical_pdp_end_date,
          p.sign_of_status,
          p.return_back_comment,
          p.sign_off_meeting_date,
          p.venue_details,
          p.special_note,
          p.completed_date,
          p.created_at,
          p.updated_at,
          ma.marketarea,
          d.dealerName
        ORDER BY p.created_at DESC, p.id DESC
      `;
      const pdpRows = await connection.query(pdpQuery);

      if (pdpRows.length === 0) {
        return res.status(200).send({ status: true, message: "No PDP records found", data: [] });
      }

      const data = pdpRows.map(p => ({
        ...p,
        dealer_info: {
          dealer_id: p.dealer,
          dealer_name: p.dealer_name
        },
        action_item_counts: {
          open: parseInt(p.open_count) || 0,
          ongoing: parseInt(p.ongoing_count) || 0,
          closed: parseInt(p.closed_count) || 0
        }
      }));

      return res.status(200).send({ status: true, message: "PDP list with action item counts retrieved", data });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
