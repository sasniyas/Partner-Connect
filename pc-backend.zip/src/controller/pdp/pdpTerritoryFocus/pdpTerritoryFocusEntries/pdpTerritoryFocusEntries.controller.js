const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Territory Focus Entry
  // Demo Request Body:
  // {
  //   "pdpId": 1,
  //   "pdp_territory_focus": 5,
  //   "py_fvsv_gpe": 100,
  //   "py_fvsv_rm": 200,
  //   "py_fvsv_sdlg": 150,
  //   "py_fvsv_breaker": 50,
  //   "py_fvsv_expectedClosure": 300,
  //   "vtv_gpe": 120,
  //   "vtv_rm": 220,
  //   "vtv_sdlg": 170,
  //   "vtv_breaker": 60,
  //   "vtv_total_plan": 1000
  // }
  addPdpTerritoryFocusEntry: async function (req, res) {
    try {
      const {
        pdpId,
        pdp_territory_focus,
        py_fvsv_gpe,
        py_fvsv_rm,
        py_fvsv_sdlg,
        py_fvsv_breaker,
        py_fvsv_expectedClosure,
        vtv_gpe,
        vtv_rm,
        vtv_sdlg,
        vtv_breaker,
        vtv_total_plan
      } = req.body;

      if (!pdpId || !pdp_territory_focus) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, pdp_territory_focus"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if PDP Territory Focus exists
      const territoryFocusExists = await connection.query(
        `SELECT id FROM pdp_territory_focus WHERE id = ? AND isDeleted = 0`,
        [pdp_territory_focus]
      );
      if (territoryFocusExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus not found or deleted" });
      }

      // Check for duplicate (same pdpId and pdp_territory_focus)
      const duplicateCheck = await connection.query(
        `SELECT id FROM pdp_territory_focus_entries WHERE pdpId = ? AND pdp_territory_focus = ? AND isDeleted = 0`,
        [pdpId, pdp_territory_focus]
      );
      if (duplicateCheck.length > 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Territory Focus Entry already exists for this PDP and Territory Focus combination"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_territory_focus_entries (
          pdpId, pdp_territory_focus, py_fvsv_gpe, py_fvsv_rm,
          py_fvsv_sdlg, py_fvsv_breaker, py_fvsv_expectedClosure,
          vtv_gpe, vtv_rm, vtv_sdlg, vtv_breaker, vtv_total_plan,
          created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
      `;

      await connection.query(insertQuery, [
        pdpId,
        pdp_territory_focus,
        py_fvsv_gpe || null,
        py_fvsv_rm || null,
        py_fvsv_sdlg || null,
        py_fvsv_breaker || null,
        py_fvsv_expectedClosure || null,
        vtv_gpe || null,
        vtv_rm || null,
        vtv_sdlg || null,
        vtv_breaker || null,
        vtv_total_plan || null,
        pdpCreatedOn,
        pdpCreatedOn
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entry added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Territory Focus Entries
  getAllPdpTerritoryFocusEntries: async function (req, res) {
    try {
      const query = `
        SELECT 
          ptfe.id,
          ptfe.pdpId,
          ptfe.pdp_territory_focus,
          ptfe.py_fvsv_gpe,
          ptfe.py_fvsv_rm,
          ptfe.py_fvsv_sdlg,
          ptfe.py_fvsv_breaker,
          ptfe.py_fvsv_expectedClosure,
          ptfe.vtv_gpe,
          ptfe.vtv_rm,
          ptfe.vtv_sdlg,
          ptfe.vtv_breaker,
          ptfe.vtv_total_plan,
          ptfe.created_at,
          ptfe.updated_at,
          ptfe.isActive,
          ptfe.isDeleted,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          dm.dealerName as dealer_name,
          ptf.branchId,
          ptf.overall_focus,
          ptf.responsible_person,
          bm.branch_name
        FROM pdp_territory_focus_entries ptfe
        LEFT JOIN pdp p ON ptfe.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master dm ON p.dealer = dm.id
        LEFT JOIN pdp_territory_focus ptf ON ptfe.pdp_territory_focus = ptf.id
        LEFT JOIN branch_master bm ON ptf.branchId = bm.id
        WHERE ptfe.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (dm.isDeleted = 0 OR dm.isDeleted IS NULL) AND (ptf.isDeleted = 0 OR ptf.isDeleted IS NULL) AND (bm.isDeleted = 0 OR bm.isDeleted IS NULL)
        ORDER BY ptfe.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Territory Focus Entries found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entries list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Territory Focus Entry by ID
  getPdpTerritoryFocusEntryById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          ptfe.id,
          ptfe.pdpId,
          ptfe.pdp_territory_focus,
          ptfe.py_fvsv_gpe,
          ptfe.py_fvsv_rm,
          ptfe.py_fvsv_sdlg,
          ptfe.py_fvsv_breaker,
          ptfe.py_fvsv_expectedClosure,
          ptfe.vtv_gpe,
          ptfe.vtv_rm,
          ptfe.vtv_sdlg,
          ptfe.vtv_breaker,
          ptfe.vtv_total_plan,
          ptfe.created_at,
          ptfe.updated_at,
          ptfe.isActive,
          ptfe.isDeleted,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          dm.dealerName as dealer_name,
          ptf.branchId,
          ptf.overall_focus,
          ptf.responsible_person,
          bm.branch_name
        FROM pdp_territory_focus_entries ptfe
        LEFT JOIN pdp p ON ptfe.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master dm ON p.dealer = dm.id
        LEFT JOIN pdp_territory_focus ptf ON ptfe.pdp_territory_focus = ptf.id
        LEFT JOIN branch_master bm ON ptf.branchId = bm.id
        WHERE ptfe.id = ? AND ptfe.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (dm.isDeleted = 0 OR dm.isDeleted IS NULL) AND (ptf.isDeleted = 0 OR ptf.isDeleted IS NULL) AND (bm.isDeleted = 0 OR bm.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus Entry not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entry retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Territory Focus Entries by PDP ID
  getPdpTerritoryFocusEntriesByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          ptfe.id,
          ptfe.pdpId,
          ptfe.pdp_territory_focus,
          ptfe.py_fvsv_gpe,
          ptfe.py_fvsv_rm,
          ptfe.py_fvsv_sdlg,
          ptfe.py_fvsv_breaker,
          ptfe.py_fvsv_expectedClosure,
          ptfe.vtv_gpe,
          ptfe.vtv_rm,
          ptfe.vtv_sdlg,
          ptfe.vtv_breaker,
          ptfe.vtv_total_plan,
          ptfe.created_at,
          ptfe.updated_at,
          ptfe.isActive,
          ptfe.isDeleted,
          ptf.branchId,
          ptf.overall_focus,
          ptf.responsible_person,
          bm.branch_name
        FROM pdp_territory_focus_entries ptfe
        LEFT JOIN pdp_territory_focus ptf ON ptfe.pdp_territory_focus = ptf.id
        LEFT JOIN branch_master bm ON ptf.branchId = bm.id
        WHERE ptfe.pdpId = ? AND ptfe.isDeleted = 0 AND (ptf.isDeleted = 0 OR ptf.isDeleted IS NULL) AND (bm.isDeleted = 0 OR bm.isDeleted IS NULL)
        ORDER BY ptfe.id DESC
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entries retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Territory Focus Entries by Territory Focus ID
  getPdpTerritoryFocusEntriesByTerritoryFocusId: async function (req, res) {
    try {
      const { territoryFocusId } = req.params;

      if (!territoryFocusId) {
        return res.status(400).send({ status: false, message: "Territory Focus ID is required" });
      }

      // Check if Territory Focus exists
      const territoryFocusExists = await connection.query(
        `SELECT id FROM pdp_territory_focus WHERE id = ? AND isDeleted = 0`,
        [territoryFocusId]
      );
      if (territoryFocusExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus not found or deleted" });
      }

      const query = `
        SELECT 
          ptfe.id,
          ptfe.pdpId,
          ptfe.pdp_territory_focus,
          ptfe.py_fvsv_gpe,
          ptfe.py_fvsv_rm,
          ptfe.py_fvsv_sdlg,
          ptfe.py_fvsv_breaker,
          ptfe.py_fvsv_expectedClosure,
          ptfe.vtv_gpe,
          ptfe.vtv_rm,
          ptfe.vtv_sdlg,
          ptfe.vtv_breaker,
          ptfe.vtv_total_plan,
          ptfe.created_at,
          ptfe.updated_at,
          ptfe.isActive,
          ptfe.isDeleted,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          dm.dealerName as dealer_name
        FROM pdp_territory_focus_entries ptfe
        LEFT JOIN pdp p ON ptfe.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master dm ON p.dealer = dm.id
        WHERE ptfe.pdp_territory_focus = ? AND ptfe.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (dm.isDeleted = 0 OR dm.isDeleted IS NULL)
        ORDER BY ptfe.id DESC
      `;

      const data = await connection.query(query, [territoryFocusId]);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entries retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Territory Focus Entry
  // Demo Request Body:
  // {
  //   "id": 1,
  //   "pdpId": 1,
  //   "pdp_territory_focus": 5,
  //   "py_fvsv_gpe": 110,
  //   "py_fvsv_rm": 210,
  //   "py_fvsv_sdlg": 160,
  //   "py_fvsv_breaker": 55,
  //   "py_fvsv_expectedClosure": 310,
  //   "vtv_gpe": 130,
  //   "vtv_rm": 230,
  //   "vtv_sdlg": 180,
  //   "vtv_breaker": 65,
  //   "vtv_total_plan": 1100
  // }
  // Note: All fields except 'id' are optional. Only include fields you want to update.
  updatePdpTerritoryFocusEntry: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        pdp_territory_focus,
        py_fvsv_gpe,
        py_fvsv_rm,
        py_fvsv_sdlg,
        py_fvsv_breaker,
        py_fvsv_expectedClosure,
        vtv_gpe,
        vtv_rm,
        vtv_sdlg,
        vtv_breaker,
        vtv_total_plan
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Territory Focus Entry exists
      const exists = await connection.query(`SELECT id FROM pdp_territory_focus_entries WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus Entry not found" });
      }

      // Validate foreign keys if provided
      if (pdpId !== undefined) {
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
        if (pdpExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP not found" });
        }
      }

      if (pdp_territory_focus !== undefined) {
        const territoryFocusExists = await connection.query(
          `SELECT id FROM pdp_territory_focus WHERE id = ? AND isDeleted = 0`,
          [pdp_territory_focus]
        );
        if (territoryFocusExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP Territory Focus not found or deleted" });
        }
      }

      // Check for duplicate if pdpId or pdp_territory_focus is being changed
      if (pdpId !== undefined || pdp_territory_focus !== undefined) {
        const currentData = await connection.query(
          `SELECT pdpId, pdp_territory_focus FROM pdp_territory_focus_entries WHERE id = ? AND isDeleted = 0`,
          [id]
        );
        const finalPdpId = pdpId !== undefined ? pdpId : currentData[0].pdpId;
        const finalTerritoryFocus = pdp_territory_focus !== undefined ? pdp_territory_focus : currentData[0].pdp_territory_focus;

        const duplicateCheck = await connection.query(
          `SELECT id FROM pdp_territory_focus_entries WHERE pdpId = ? AND pdp_territory_focus = ? AND id != ? AND isDeleted = 0`,
          [finalPdpId, finalTerritoryFocus, id]
        );
        if (duplicateCheck.length > 0) {
          return res.status(400).send({
            status: false,
            message: "PDP Territory Focus Entry already exists for this PDP and Territory Focus combination"
          });
        }
      }

      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }
      if (pdp_territory_focus !== undefined) {
        updateFields.push("pdp_territory_focus = ?");
        updateValues.push(pdp_territory_focus);
      }
      if (py_fvsv_gpe !== undefined) {
        updateFields.push("py_fvsv_gpe = ?");
        updateValues.push(py_fvsv_gpe);
      }
      if (py_fvsv_rm !== undefined) {
        updateFields.push("py_fvsv_rm = ?");
        updateValues.push(py_fvsv_rm);
      }
      if (py_fvsv_sdlg !== undefined) {
        updateFields.push("py_fvsv_sdlg = ?");
        updateValues.push(py_fvsv_sdlg);
      }
      if (py_fvsv_breaker !== undefined) {
        updateFields.push("py_fvsv_breaker = ?");
        updateValues.push(py_fvsv_breaker);
      }
      if (py_fvsv_expectedClosure !== undefined) {
        updateFields.push("py_fvsv_expectedClosure = ?");
        updateValues.push(py_fvsv_expectedClosure);
      }
      if (vtv_gpe !== undefined) {
        updateFields.push("vtv_gpe = ?");
        updateValues.push(vtv_gpe);
      }
      if (vtv_rm !== undefined) {
        updateFields.push("vtv_rm = ?");
        updateValues.push(vtv_rm);
      }
      if (vtv_sdlg !== undefined) {
        updateFields.push("vtv_sdlg = ?");
        updateValues.push(vtv_sdlg);
      }
      if (vtv_breaker !== undefined) {
        updateFields.push("vtv_breaker = ?");
        updateValues.push(vtv_breaker);
      }
      if (vtv_total_plan !== undefined) {
        updateFields.push("vtv_total_plan = ?");
        updateValues.push(vtv_total_plan);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_territory_focus_entries
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entry updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Territory Focus Entry
  deletePdpTerritoryFocusEntry: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Territory Focus Entry exists
      const exists = await connection.query(`SELECT id FROM pdp_territory_focus_entries WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus Entry not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_territory_focus_entries SET isDeleted = 1, updated_at = ? WHERE id = ? AND isDeleted = 0`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entry deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

