const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Territory Focus Entries Stats
  // Demo Request Body:
  // {
  //   "pdpId": 1,
  //   "py_gpe_pvtv": 100,
  //   "py_rm_pvtv": 200,
  //   "py_sdlg_pvtv": 150,
  //   "py_breaker_pvtv": 50,
  //   "py_gpe_etmv": 120,
  //   "py_rm_etmv": 220,
  //   "py_sdlg_etmv": 170,
  //   "py_breaker_etmv": 60,
  //   "gpe_etmv": 130,
  //   "rm_etmv": 230,
  //   "sdlg_etmv": 180,
  //   "breaker_etmv": 70
  // }
  addPdpTerritoryFocusEntriesStats: async function (req, res) {
    try {
      const {
        pdpId,
        py_gpe_pvtv,
        py_rm_pvtv,
        py_sdlg_pvtv,
        py_breaker_pvtv,
        py_gpe_etmv,
        py_rm_etmv,
        py_sdlg_etmv,
        py_breaker_etmv,
        gpe_etmv,
        rm_etmv,
        sdlg_etmv,
        breaker_etmv
      } = req.body;

      if (!pdpId) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check for duplicate (same pdpId)
      const duplicateCheck = await connection.query(
        `SELECT id FROM pdp_territory_focus_entries_stats WHERE pdpId = ? AND isDeleted = 0`,
        [pdpId]
      );
      if (duplicateCheck.length > 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Territory Focus Entries Stats already exists for this PDP"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_territory_focus_entries_stats (
          pdpId, py_gpe_pvtv, py_rm_pvtv, py_sdlg_pvtv, py_breaker_pvtv,
          py_gpe_etmv, py_rm_etmv, py_sdlg_etmv, py_breaker_etmv,
          gpe_etmv, rm_etmv, sdlg_etmv, breaker_etmv,
          created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
      `;

      await connection.query(insertQuery, [
        pdpId,
        py_gpe_pvtv || null,
        py_rm_pvtv || null,
        py_sdlg_pvtv || null,
        py_breaker_pvtv || null,
        py_gpe_etmv || null,
        py_rm_etmv || null,
        py_sdlg_etmv || null,
        py_breaker_etmv || null,
        gpe_etmv || null,
        rm_etmv || null,
        sdlg_etmv || null,
        breaker_etmv || null,
        pdpCreatedOn,
        pdpCreatedOn
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entries Stats added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Territory Focus Entries Stats
  getAllPdpTerritoryFocusEntriesStats: async function (req, res) {
    try {
      const query = `
        SELECT 
          ptfes.id,
          ptfes.pdpId,
          ptfes.py_gpe_pvtv,
          ptfes.py_rm_pvtv,
          ptfes.py_sdlg_pvtv,
          ptfes.py_breaker_pvtv,
          ptfes.py_gpe_etmv,
          ptfes.py_rm_etmv,
          ptfes.py_sdlg_etmv,
          ptfes.py_breaker_etmv,
          ptfes.gpe_etmv,
          ptfes.rm_etmv,
          ptfes.sdlg_etmv,
          ptfes.breaker_etmv,
          ptfes.created_at,
          ptfes.updated_at,
          ptfes.isActive,
          ptfes.isDeleted,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          dm.dealerName as dealer_name
        FROM pdp_territory_focus_entries_stats ptfes
        LEFT JOIN pdp p ON ptfes.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master dm ON p.dealer = dm.id
        WHERE ptfes.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (dm.isDeleted = 0 OR dm.isDeleted IS NULL)
        ORDER BY ptfes.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Territory Focus Entries Stats found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entries Stats list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Territory Focus Entries Stats by ID
  getPdpTerritoryFocusEntriesStatsById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          ptfes.id,
          ptfes.pdpId,
          ptfes.py_gpe_pvtv,
          ptfes.py_rm_pvtv,
          ptfes.py_sdlg_pvtv,
          ptfes.py_breaker_pvtv,
          ptfes.py_gpe_etmv,
          ptfes.py_rm_etmv,
          ptfes.py_sdlg_etmv,
          ptfes.py_breaker_etmv,
          ptfes.gpe_etmv,
          ptfes.rm_etmv,
          ptfes.sdlg_etmv,
          ptfes.breaker_etmv,
          ptfes.created_at,
          ptfes.updated_at,
          ptfes.isActive,
          ptfes.isDeleted,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          dm.dealerName as dealer_name
        FROM pdp_territory_focus_entries_stats ptfes
        LEFT JOIN pdp p ON ptfes.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master dm ON p.dealer = dm.id
        WHERE ptfes.id = ? AND ptfes.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (dm.isDeleted = 0 OR dm.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus Entries Stats not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entries Stats retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Territory Focus Entries Stats by PDP ID
  getPdpTerritoryFocusEntriesStatsByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          ptfes.id,
          ptfes.pdpId,
          ptfes.py_gpe_pvtv,
          ptfes.py_rm_pvtv,
          ptfes.py_sdlg_pvtv,
          ptfes.py_breaker_pvtv,
          ptfes.py_gpe_etmv,
          ptfes.py_rm_etmv,
          ptfes.py_sdlg_etmv,
          ptfes.py_breaker_etmv,
          ptfes.gpe_etmv,
          ptfes.rm_etmv,
          ptfes.sdlg_etmv,
          ptfes.breaker_etmv,
          ptfes.created_at,
          ptfes.updated_at,
          ptfes.isActive,
          ptfes.isDeleted,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          dm.dealerName as dealer_name
        FROM pdp_territory_focus_entries_stats ptfes
        LEFT JOIN pdp p ON ptfes.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master dm ON p.dealer = dm.id
        WHERE ptfes.pdpId = ? AND ptfes.isDeleted = 0
      `;

      const data = await connection.query(query, [pdpId]);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Territory Focus Entries Stats found for this PDP",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entries Stats retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Territory Focus Entries Stats
  // Demo Request Body:
  // {
  //   "id": 1,
  //   "pdpId": 1,
  //   "py_gpe_pvtv": 110,
  //   "py_rm_pvtv": 210,
  //   "py_sdlg_pvtv": 160,
  //   "py_breaker_pvtv": 55,
  //   "py_gpe_etmv": 130,
  //   "py_rm_etmv": 230,
  //   "py_sdlg_etmv": 180,
  //   "py_breaker_etmv": 65,
  //   "gpe_etmv": 140,
  //   "rm_etmv": 240,
  //   "sdlg_etmv": 190,
  //   "breaker_etmv": 75
  // }
  // Note: All fields except 'id' are optional. Only include fields you want to update.
  updatePdpTerritoryFocusEntriesStats: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        py_gpe_pvtv,
        py_rm_pvtv,
        py_sdlg_pvtv,
        py_breaker_pvtv,
        py_gpe_etmv,
        py_rm_etmv,
        py_sdlg_etmv,
        py_breaker_etmv,
        gpe_etmv,
        rm_etmv,
        sdlg_etmv,
        breaker_etmv
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Territory Focus Entries Stats exists
      const exists = await connection.query(`SELECT id FROM pdp_territory_focus_entries_stats WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus Entries Stats not found" });
      }

      // Validate foreign key if provided
      if (pdpId !== undefined) {
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
        if (pdpExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP not found" });
        }

        // Check for duplicate if pdpId is being changed
        const currentData = await connection.query(
          `SELECT pdpId FROM pdp_territory_focus_entries_stats WHERE id = ? AND isDeleted = 0`,
          [id]
        );
        const finalPdpId = pdpId !== undefined ? pdpId : currentData[0].pdpId;

        const duplicateCheck = await connection.query(
          `SELECT id FROM pdp_territory_focus_entries_stats WHERE pdpId = ? AND id != ? AND isDeleted = 0`,
          [finalPdpId, id]
        );
        if (duplicateCheck.length > 0) {
          return res.status(400).send({
            status: false,
            message: "PDP Territory Focus Entries Stats already exists for this PDP"
          });
        }
      }

      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }
      if (py_gpe_pvtv !== undefined) {
        updateFields.push("py_gpe_pvtv = ?");
        updateValues.push(py_gpe_pvtv);
      }
      if (py_rm_pvtv !== undefined) {
        updateFields.push("py_rm_pvtv = ?");
        updateValues.push(py_rm_pvtv);
      }
      if (py_sdlg_pvtv !== undefined) {
        updateFields.push("py_sdlg_pvtv = ?");
        updateValues.push(py_sdlg_pvtv);
      }
      if (py_breaker_pvtv !== undefined) {
        updateFields.push("py_breaker_pvtv = ?");
        updateValues.push(py_breaker_pvtv);
      }
      if (py_gpe_etmv !== undefined) {
        updateFields.push("py_gpe_etmv = ?");
        updateValues.push(py_gpe_etmv);
      }
      if (py_rm_etmv !== undefined) {
        updateFields.push("py_rm_etmv = ?");
        updateValues.push(py_rm_etmv);
      }
      if (py_sdlg_etmv !== undefined) {
        updateFields.push("py_sdlg_etmv = ?");
        updateValues.push(py_sdlg_etmv);
      }
      if (py_breaker_etmv !== undefined) {
        updateFields.push("py_breaker_etmv = ?");
        updateValues.push(py_breaker_etmv);
      }
      if (gpe_etmv !== undefined) {
        updateFields.push("gpe_etmv = ?");
        updateValues.push(gpe_etmv);
      }
      if (rm_etmv !== undefined) {
        updateFields.push("rm_etmv = ?");
        updateValues.push(rm_etmv);
      }
      if (sdlg_etmv !== undefined) {
        updateFields.push("sdlg_etmv = ?");
        updateValues.push(sdlg_etmv);
      }
      if (breaker_etmv !== undefined) {
        updateFields.push("breaker_etmv = ?");
        updateValues.push(breaker_etmv);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_territory_focus_entries_stats
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entries Stats updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Territory Focus Entries Stats
  deletePdpTerritoryFocusEntriesStats: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Territory Focus Entries Stats exists
      const exists = await connection.query(`SELECT id FROM pdp_territory_focus_entries_stats WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus Entries Stats not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_territory_focus_entries_stats SET isDeleted = 1, updated_at = ? WHERE id = ? AND isDeleted = 0`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus Entries Stats deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

