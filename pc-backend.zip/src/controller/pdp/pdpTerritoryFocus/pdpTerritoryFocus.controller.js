const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Territory Focus
  // Demo Request Body:
  //   {
  //     "pdpId": 1,
  //     "branchId": 10,
  //     "responsible_person": "John Doe",
  //     "overall_focus": "High",
  //     "segmentPriorityId_1": 2,
  //     "segmentPriorityId_2": 3,
  //     "segmentPriorityId_3": 4,
  //     "segmentPriorityId_4": 5,
  //     "total_plan": 1000
  //   }
  addPdpTerritoryFocus: async function (req, res) {
    try {
      const {
        pdpId,
        branchId,
        responsible_person,
        overall_focus,
        segmentPriorityId_1,
        segmentPriorityId_2,
        segmentPriorityId_3,
        segmentPriorityId_4
      } = req.body;

      if (!pdpId || !branchId || !overall_focus) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, branchId, overall_focus"
        });
      }

      // Validate overall_focus
      const validFocus = ["High", "Low", "Medium"];
      if (!validFocus.includes(overall_focus)) {
        return res.status(400).send({
          status: false,
          message: "overall_focus must be either 'High', 'Low', or 'Medium'"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if branch exists
      const branchExists = await connection.query(
        `SELECT id FROM branch_master WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND isDeleted = 0`,
        [branchId]
      );
      if (branchExists.length === 0) {
        return res.status(404).send({ status: false, message: "Branch not found or inactive" });
      }

      // Validate segment priorities if provided
      const segmentPriorityIds = [segmentPriorityId_1, segmentPriorityId_2, segmentPriorityId_3, segmentPriorityId_4].filter(id => id !== undefined && id !== null);
      if (segmentPriorityIds.length > 0) {
        for (const segId of segmentPriorityIds) {
          const segExists = await connection.query(
            `SELECT id FROM segment_priority WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND isDeleted = 0`,
            [segId]
          );
          if (segExists.length === 0) {
            return res.status(404).send({ status: false, message: `Segment Priority with id ${segId} not found or inactive` });
          }
        }
      }

      // Check for duplicate (same pdpId and branchId)
      const duplicateCheck = await connection.query(
        `SELECT id FROM pdp_territory_focus WHERE pdpId = ? AND branchId = ? AND isDeleted = 0`,
        [pdpId, branchId]
      );
      if (duplicateCheck.length > 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Territory Focus entry already exists for this PDP and Branch combination"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_territory_focus (
          pdpId, branchId, responsible_person,
          overall_focus, segmentPriorityId_1, segmentPriorityId_2,
          segmentPriorityId_3, segmentPriorityId_4,
          created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
      `;

      const insertResult = await connection.query(insertQuery, [
        pdpId,
        branchId,
        responsible_person || null,
        overall_focus,
        segmentPriorityId_1 || null,
        segmentPriorityId_2 || null,
        segmentPriorityId_3 || null,
        segmentPriorityId_4 || null,
        pdpCreatedOn,
        pdpCreatedOn,
        0 // isDeleted
      ]);

      const territoryFocusId = insertResult.insertId;

      const insertEntryQuery = `
        INSERT INTO pdp_territory_focus_entries (
          pdpId, pdp_territory_focus, py_fvsv_gpe, py_fvsv_rm,
          py_fvsv_sdlg, py_fvsv_breaker, py_fvsv_expectedClosure,
          vtv_gpe, vtv_rm, vtv_sdlg, vtv_breaker, vtv_total_plan,
          created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
      `;

      await connection.query(insertEntryQuery, [
        pdpId,
        territoryFocusId,
        0, // py_fvsv_gpe
        0, // py_fvsv_rm
        0, // py_fvsv_sdlg
        0, // py_fvsv_breaker
        0, // py_fvsv_expectedClosure
        0, // vtv_gpe
        0, // vtv_rm
        0, // vtv_sdlg
        0, // vtv_breaker
        0, // vtv_total_plan
        pdpCreatedOn,
        pdpCreatedOn,
        0 // isDeleted
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllPdpTerritoryFocus: async function (req, res) {
    try {
      const query = `
        SELECT 
          ptf.id,
          ptf.pdpId,
          ptf.branchId,
          ptf.responsible_person,
          ptf.overall_focus,
          ptf.segmentPriorityId_1,
          ptf.segmentPriorityId_2,
          ptf.segmentPriorityId_3,
          ptf.segmentPriorityId_4,
          ptf.created_at,
          ptf.updated_at,
          ptf.isActive,
          ptf.isDeleted,
          bm.branch_name,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          dm.dealerName as dealer_name,
          sp1.segment_focus_area as segment_priority_1_name,
          sp2.segment_focus_area as segment_priority_2_name,
          sp3.segment_focus_area as segment_priority_3_name,
          sp4.segment_focus_area as segment_priority_4_name
        FROM pdp_territory_focus ptf
        LEFT JOIN branch_master bm ON ptf.branchId = bm.id
        LEFT JOIN pdp p ON ptf.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master dm ON p.dealer = dm.id
        LEFT JOIN segment_priority sp1 ON ptf.segmentPriorityId_1 = sp1.id
        LEFT JOIN segment_priority sp2 ON ptf.segmentPriorityId_2 = sp2.id
        LEFT JOIN segment_priority sp3 ON ptf.segmentPriorityId_3 = sp3.id
        LEFT JOIN segment_priority sp4 ON ptf.segmentPriorityId_4 = sp4.id
        WHERE ptf.isDeleted = 0 AND (bm.isDeleted = 0 OR bm.isDeleted IS NULL) AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (dm.isDeleted = 0 OR dm.isDeleted IS NULL)
        ORDER BY ptf.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Territory Focus records found",
          data: []
        });
      }

      // Get all unique branch IDs
      const branchIds = [...new Set(data.map(item => item.branchId).filter(id => id !== null))];

      // Get district mappings for all branches
      let districtData = [];
      if (branchIds.length > 0) {
        const placeholders = branchIds.map(() => '?').join(',');
        const districtQuery = `
          SELECT bdm.branch_master_id, dt.id as district_id, dt.district_name
          FROM branch_district_mapping bdm
          LEFT JOIN districts dt ON bdm.district_id = dt.id
          WHERE bdm.branch_master_id IN (${placeholders})
        `;
        districtData = await connection.query(districtQuery, branchIds);
      }

      // Group districts by branch_master_id
      const districtMap = {};
      districtData.forEach(district => {
        if (!districtMap[district.branch_master_id]) {
          districtMap[district.branch_master_id] = [];
        }
        districtMap[district.branch_master_id].push({
          district_id: district.district_id,
          district_name: district.district_name
        });
      });

      // Combine territory focus data with district data
      const result = data.map(item => ({
        ...item,
        districts: districtMap[item.branchId] || []
      }));

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus list retrieved",
        data: result
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Territory Focus by ID
  getPdpTerritoryFocusById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          ptf.id,
          ptf.pdpId,
          ptf.branchId,
          ptf.responsible_person,
          ptf.overall_focus,
          ptf.segmentPriorityId_1,
          ptf.segmentPriorityId_2,
          ptf.segmentPriorityId_3,
          ptf.segmentPriorityId_4,
          ptf.created_at,
          ptf.updated_at,
          ptf.isActive,
          ptf.isDeleted,
          bm.branch_name,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          dm.dealerName as dealer_name,
          sp1.segment_focus_area as segment_priority_1_name,
          sp2.segment_focus_area as segment_priority_2_name,
          sp3.segment_focus_area as segment_priority_3_name,
          sp4.segment_focus_area as segment_priority_4_name
        FROM pdp_territory_focus ptf
        LEFT JOIN branch_master bm ON ptf.branchId = bm.id
        LEFT JOIN pdp p ON ptf.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master dm ON p.dealer = dm.id
        LEFT JOIN segment_priority sp1 ON ptf.segmentPriorityId_1 = sp1.id
        LEFT JOIN segment_priority sp2 ON ptf.segmentPriorityId_2 = sp2.id
        LEFT JOIN segment_priority sp3 ON ptf.segmentPriorityId_3 = sp3.id
        LEFT JOIN segment_priority sp4 ON ptf.segmentPriorityId_4 = sp4.id
        WHERE ptf.id = ? AND ptf.isDeleted = 0 AND (bm.isDeleted = 0 OR bm.isDeleted IS NULL) AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (dm.isDeleted = 0 OR dm.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus not found" });
      }

      const item = data[0];

      // Get districts for the branch
      let districts = [];
      if (item.branchId) {
        const districtQuery = `
          SELECT dt.id as district_id, dt.district_name
          FROM branch_district_mapping bdm
          LEFT JOIN districts dt ON bdm.district_id = dt.id
          WHERE bdm.branch_master_id = ?
        `;
        const districtData = await connection.query(districtQuery, [item.branchId]);
        districts = districtData.map(d => ({
          district_id: d.district_id,
          district_name: d.district_name
        }));
      }

      const result = {
        ...item,
        districts: districts
      };

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus retrieved",
        data: result
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Territory Focus by PDP ID
  getPdpTerritoryFocusByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ?`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          ptf.id,
          ptf.pdpId,
          ptf.branchId,
          ptf.responsible_person,
          ptf.overall_focus,
          ptf.segmentPriorityId_1,
          ptf.segmentPriorityId_2,
          ptf.segmentPriorityId_3,
          ptf.segmentPriorityId_4,
          ptf.created_at,
          ptf.updated_at,
          ptf.isActive,
          ptf.isDeleted,
          bm.branch_name,
          cm.cityName,
          sp1.segment_focus_area as segment_priority_1_name,
          sp2.segment_focus_area as segment_priority_2_name,
          sp3.segment_focus_area as segment_priority_3_name,
          sp4.segment_focus_area as segment_priority_4_name
        FROM pdp_territory_focus ptf
        LEFT JOIN branch_master bm ON ptf.branchId = bm.id
        LEFT JOIN city_master cm ON bm.city_id = cm.id 
        LEFT JOIN segment_priority sp1 ON ptf.segmentPriorityId_1 = sp1.id
        LEFT JOIN segment_priority sp2 ON ptf.segmentPriorityId_2 = sp2.id
        LEFT JOIN segment_priority sp3 ON ptf.segmentPriorityId_3 = sp3.id
        LEFT JOIN segment_priority sp4 ON ptf.segmentPriorityId_4 = sp4.id
        WHERE ptf.pdpId = ? AND ptf.isDeleted = 0 AND (bm.isDeleted = 0 OR bm.isDeleted IS NULL) AND (cm.isDeleted = 0 OR cm.isDeleted IS NULL)
        ORDER BY ptf.id DESC
      `;

      const data = await connection.query(query, [pdpId]);

      // Get all unique branch IDs
      const branchIds = [...new Set(data.map(item => item.branchId).filter(id => id !== null))];

      // Get district mappings for all branches
      let districtData = [];
      if (branchIds.length > 0) {
        const placeholders = branchIds.map(() => '?').join(',');
        const districtQuery = `
          SELECT bdm.branch_master_id, dt.id as district_id, dt.district_name
          FROM branch_district_mapping bdm
          LEFT JOIN districts dt ON bdm.district_id = dt.id
          WHERE bdm.branch_master_id IN (${placeholders})
        `;
        districtData = await connection.query(districtQuery, branchIds);
      }

      // Group districts by branch_master_id
      const districtMap = {};
      districtData.forEach(district => {
        if (!districtMap[district.branch_master_id]) {
          districtMap[district.branch_master_id] = [];
        }
        districtMap[district.branch_master_id].push({
          district_id: district.district_id,
          district_name: district.district_name
        });
      });

      // Combine territory focus data with district data
      const result = data.map(item => ({
        ...item,
        districts: districtMap[item.branchId] || []
      }));

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus records retrieved",
        data: result
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Territory Focus
  // Demo Request Body:
  // {
  //   "id": 1,
  //   "pdpId": 1,
  //   "branchId": 10,
  //   "responsible_person": "Jane Smith",
  //   "overall_focus": "Medium",
  //   "segmentPriorityId_1": 2,
  //   "segmentPriorityId_2": 3,
  //   "segmentPriorityId_3": null,
  //   "segmentPriorityId_4": null,
  //   "total_plan": 1500
  // }
  // Note: All fields except 'id' are optional. Only include fields you want to update.
  updatePdpTerritoryFocus: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        branchId,
        responsible_person,
        overall_focus,
        segmentPriorityId_1,
        segmentPriorityId_2,
        segmentPriorityId_3,
        segmentPriorityId_4
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Territory Focus exists
      const exists = await connection.query(`SELECT id FROM pdp_territory_focus WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus not found" });
      }

      // Validate overall_focus if provided
      if (overall_focus !== undefined) {
        const validFocus = ["High", "Low", "Medium"];
        if (!validFocus.includes(overall_focus)) {
          return res.status(400).send({
            status: false,
            message: "overall_focus must be either 'High', 'Low', or 'Medium'"
          });
        }
      }

      // Validate foreign keys if provided
      if (pdpId !== undefined) {
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
        if (pdpExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP not found" });
        }
      }

      if (branchId !== undefined) {
        const branchExists = await connection.query(
          `SELECT id FROM branch_master WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND isDeleted = 0`,
          [branchId]
        );
        if (branchExists.length === 0) {
          return res.status(404).send({ status: false, message: "Branch not found or inactive" });
        }
      }

      // Validate segment priorities if provided
      const segmentPriorityIds = [segmentPriorityId_1, segmentPriorityId_2, segmentPriorityId_3, segmentPriorityId_4]
        .filter(id => id !== undefined && id !== null);
      if (segmentPriorityIds.length > 0) {
        for (const segId of segmentPriorityIds) {
          const segExists = await connection.query(
            `SELECT id FROM segment_priority WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND isDeleted = 0`,
            [segId]
          );
          if (segExists.length === 0) {
            return res.status(404).send({ status: false, message: `Segment Priority with id ${segId} not found or inactive` });
          }
        }
      }


      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];


      if (branchId !== undefined) {
        updateFields.push("branchId = ?");
        updateValues.push(branchId);
      }
      if (responsible_person !== undefined) {
        updateFields.push("responsible_person = ?");
        updateValues.push(responsible_person);
      }
      if (overall_focus !== undefined) {
        updateFields.push("overall_focus = ?");
        updateValues.push(overall_focus);
      }
      if (segmentPriorityId_1 !== undefined) {
        updateFields.push("segmentPriorityId_1 = ?");
        updateValues.push(segmentPriorityId_1);
      }
      if (segmentPriorityId_2 !== undefined) {
        updateFields.push("segmentPriorityId_2 = ?");
        updateValues.push(segmentPriorityId_2);
      }
      if (segmentPriorityId_3 !== undefined) {
        updateFields.push("segmentPriorityId_3 = ?");
        updateValues.push(segmentPriorityId_3);
      }
      if (segmentPriorityId_4 !== undefined) {
        updateFields.push("segmentPriorityId_4 = ?");
        updateValues.push(segmentPriorityId_4);
      }


      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_territory_focus
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Territory Focus
  deletePdpTerritoryFocus: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Territory Focus exists
      const exists = await connection.query(`SELECT id FROM pdp_territory_focus WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Territory Focus not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_territory_focus SET isDeleted = 1, updated_at = ? WHERE id = ? AND isDeleted = 0`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Territory Focus deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

