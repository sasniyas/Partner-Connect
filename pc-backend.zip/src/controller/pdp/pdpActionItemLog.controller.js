const { connection } = require("../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {

  addActionLog: async function (req, res) {
    try {
      let {
        pdp_action_item,
        comment,
        target_date
      } = req.body;

      // Get updated_by from token
      const updated_by = req.decodedToken;
      console.log("updated_by", updated_by);

      // Validate required fields for action log creation
      if (!pdp_action_item) {
        return res.status(400).send({
          status: false,
          message: "PDP action item ID is required!"
        });
      }

      // Check if PDP action item exists
      const actionItemCheckQuery = `SELECT id FROM pdp_action_item WHERE id = ? AND isDeleted = 0`;
      const actionItemExists = await connection.query(actionItemCheckQuery, [pdp_action_item]);

      if (actionItemExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "PDP action item not found!"
        });
      }

      // Check if user exists
      const userCheckQuery = `SELECT id FROM userdetails WHERE id = ? AND isDeleted = 0`;
      const userExists = await connection.query(userCheckQuery, [updated_by]);

      if (userExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "User not found in token!"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const query = `
        INSERT INTO pdp_action_log 
        (updated_by, pdp_action_item, comment, createdOn, isDeleted, target_date) 
        VALUES (?, ?, ?, ?, 0, ?)
      `;

      const insertResult = await connection.query(query, [
        updated_by, pdp_action_item, comment || null, pdpCreatedOn, 0, target_date || null
      ]);

      return res.status(200).send({
        status: true,
        message: "Action log added successfully!",
        data: { id: insertResult.insertId }
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getAllActionLogs: async function (req, res) {
    try {
      const { pdp_action_item, updated_by } = req.query;

      let whereConditions = ['al.isDeleted = 0'];
      let queryParams = [];

      // Add optional filters
      if (pdp_action_item) {
        whereConditions.push('al.pdp_action_item = ?');
        queryParams.push(pdp_action_item);
      }

      if (updated_by) {
        whereConditions.push('al.updated_by = ?');
        queryParams.push(updated_by);
      }

      // Get all action logs with proper joins
      const actionLogQuery = `
        SELECT 
          al.id,
          al.updated_by,
          al.pdp_action_item,
          al.comment,
          al.createdOn,
          al.isDeleted,
          u.firstName as updated_by_name,
          u.lastName as updated_by_lastname,
          u.email as updated_by_email,
          pai.focus_area,
          pai.objective,
          pai.actions_to_achieve,
          pai.actions_progress_update,
          pai.responsibility,
          pai.priority,
          pai.target_date,
          pai.completed_date,
          pai.status as action_item_status
        FROM pdp_action_log al 
        LEFT JOIN userdetails u ON al.updated_by = u.id
        LEFT JOIN pdp_action_item pai ON al.pdp_action_item = pai.id
        WHERE ${whereConditions.join(' AND ')} AND (u.isDeleted = 0 OR u.isDeleted IS NULL) AND (pai.isDeleted = 0 OR pai.isDeleted IS NULL)
        ORDER BY al.createdOn DESC
      `;

      const actionLogData = await connection.query(actionLogQuery, queryParams);

      if (actionLogData.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No action logs found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Action logs retrieved successfully",
        data: actionLogData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getActionLogById: async function (req, res) {
    try {
      const { id } = req.params;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Get action log with proper joins
      const actionLogQuery = `
        SELECT 
          al.id,
          al.updated_by,
          al.pdp_action_item,
          al.comment,
          al.createdOn,
          al.isDeleted,
          u.firstName as updated_by_name,
          u.lastName as updated_by_lastname,
          u.email as updated_by_email,
          pai.focus_area,
          pai.objective,
          pai.actions_to_achieve,
          pai.actions_progress_update,
          pai.responsibility,
          pai.priority,
          pai.target_date,
          pai.completed_date,
          pai.status as action_item_status
        FROM pdp_action_log al 
        LEFT JOIN userdetails u ON al.updated_by = u.id
        LEFT JOIN pdp_action_item pai ON al.pdp_action_item = pai.id
        WHERE al.id = ? AND al.isDeleted = 0 AND (u.isDeleted = 0 OR u.isDeleted IS NULL) AND (pai.isDeleted = 0 OR pai.isDeleted IS NULL)
      `;

      const actionLogData = await connection.query(actionLogQuery, [id]);

      if (actionLogData.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action log not found!"
        });
      }

      const result = actionLogData[0];

      return res.status(200).send({
        status: true,
        message: "Action log retrieved successfully",
        data: result
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getActionLogsByActionItem: async function (req, res) {
    try {
      const { pdp_action_item } = req.params;

      if (!pdp_action_item) {
        return res.status(400).send({
          status: false,
          message: "PDP action item ID is required!"
        });
      }

      const actionLogQuery = `
        SELECT 
          al.id,
          al.updated_by,
          al.pdp_action_item,
          al.comment,
          al.createdOn,
          al.isDeleted,
          u.firstName as updated_by_name,
          u.lastName as updated_by_lastname,
          u.email as updated_by_email,
          pai.focus_area,
          pai.objective,
          pai.actions_to_achieve,
          pai.actions_progress_update,
          pai.responsibility,
          pai.priority,
          pai.target_date,
          pai.completed_date,
          pai.status as action_item_status
        FROM pdp_action_log al 
        LEFT JOIN userdetails u ON al.updated_by = u.id
        LEFT JOIN pdp_action_item pai ON al.pdp_action_item = pai.id
        WHERE al.pdp_action_item = ? AND al.isDeleted = 0 AND (u.isDeleted = 0 OR u.isDeleted IS NULL) AND (pai.isDeleted = 0 OR pai.isDeleted IS NULL)
        ORDER BY al.createdOn DESC
      `;

      const actionLogData = await connection.query(actionLogQuery, [pdp_action_item]);

      return res.status(200).send({
        status: true,
        message: "Action logs retrieved successfully",
        data: actionLogData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  updateActionLog: async function (req, res) {
    try {
      const { id } = req.params;
      const { comment } = req.body;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Check if action log exists
      const checkQuery = `SELECT * FROM pdp_action_log WHERE id = ? AND isDeleted = 0`;
      const existingActionLog = await connection.query(checkQuery, [id]);

      if (existingActionLog.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action log not found!"
        });
      }

      // Build update query dynamically based on provided fields
      let updateFields = [];
      let queryParams = [];

      if (comment !== undefined) {
        updateFields.push('comment = ?');
        queryParams.push(comment);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "At least one field (comment) must be provided for update!"
        });
      }

      queryParams.push(id);
      const updateQuery = `UPDATE pdp_action_log SET ${updateFields.join(', ')} WHERE id = ? AND isDeleted = 0`;

      const updatedResult = await connection.query(updateQuery, queryParams);

      return res.status(200).send({
        status: true,
        message: "Action log updated successfully!",
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  deleteActionLog: async function (req, res) {
    try {
      const { id } = req.params;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Check if action log exists before deletion
      const checkQuery = `SELECT * FROM pdp_action_log WHERE id = ? AND isDeleted = 0`;
      const existingActionLog = await connection.query(checkQuery, [id]);

      if (existingActionLog.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action log not found!"
        });
      }

      // Soft delete action log
      const deleteQuery = `UPDATE pdp_action_log SET isDeleted = 1 WHERE id = ? AND isDeleted = 0`;
      const updatedResult = await connection.query(deleteQuery, [id]);

      return res.status(200).send({
        status: true,
        message: "Action log deleted successfully!",
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },
  getTargetDate: async function (req, res) {
    try {
      const { pdp_action_item } = req.params;

      if (!pdp_action_item) {
        return res.status(400).send({
          status: false,
          message: "PDP Action item ID is required!"
        });
      }

      const query = `
        SELECT target_date 
        FROM pdp_action_log 
        WHERE pdp_action_item = ? AND target_date IS NOT NULL AND isDeleted = 0
        ORDER BY createdOn DESC
      `;

      const result = await connection.query(query, [pdp_action_item]);

      const targetDates = result.map(row => row.target_date);

      return res.status(200).send({
        status: true,
        message: "Target dates retrieved successfully",
        data: targetDates
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  }
};
