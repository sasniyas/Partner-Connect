const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

const validateForeignKey = async (query, params, notFoundMessage) => {
  const rows = await connection.query(query, params);
  if (rows.length === 0) {
    throw new Error(notFoundMessage);
  }
};

module.exports = {
  // ➕ Add PDP Competence Development
  addPdpCompetenceDevelopment: async function (req, res) {
    try {
      const {
        pdpId,
        competenceId,
        py_target,
        py_eoy,
        target,
        remarks
      } = req.body;

      if (!pdpId || !competenceId) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, competenceId"
        });
      }

      await validateForeignKey(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId], "PDP not found");
      await validateForeignKey(
        `SELECT id FROM competence WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [competenceId],
        "Competence not found or inactive"
      );

      if (py_target) {
        await validateForeignKey(
          `SELECT id FROM pdp_competence_development WHERE id = ? AND isDeleted = 0`,
          [py_target],
          "py_target reference not found"
        );
      }

      const duplicateCheck = await connection.query(
        `SELECT id FROM pdp_competence_development WHERE pdpId = ? AND competenceId = ? AND isDeleted = 0`,
        [pdpId, competenceId]
      );
      if (duplicateCheck.length > 0) {
        return res.status(400).send({
          status: false,
          message: "Entry already exists for this PDP and Competence"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_competence_development (
          pdpId,
          competenceId,
          py_target,
          py_eoy,
          target,
          remarks,
          created_at,
          updated_at,
          isDeleted
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      await connection.query(insertQuery, [
        pdpId,
        competenceId,
        py_target || null,
        py_eoy || null,
        target || null,
        remarks || null,
        pdpCreatedOn,
        pdpCreatedOn,
        0
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Competence Development added successfully"
      });
    } catch (error) {
      if (error.message.includes("not found")) {
        return res.status(404).send({ status: false, message: error.message });
      }
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Competence Developments
  getAllPdpCompetenceDevelopments: async function (_req, res) {
    try {
      const query = `
        SELECT 
          pcd.*,
          p.year AS pdp_year,
          p.market_area,
          p.dealer,
          c.competence_name,
          py.pdpId AS py_pdpId,
          py.target AS py_target_value
        FROM pdp_competence_development pcd
        LEFT JOIN pdp p ON pcd.pdpId = p.id
        LEFT JOIN competence c ON pcd.competenceId = c.id
        LEFT JOIN pdp_competence_development py ON pcd.py_target = py.id
        WHERE pcd.isDeleted = 0 AND p.isDeleted = 0 AND c.isDeleted = 0
        ORDER BY pcd.id DESC
      `;

      const data = await connection.query(query);

      return res.status(200).send({
        status: true,
        message: data.length ? "PDP Competence Development list retrieved" : "No records found",
        data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Competence Development by ID
  getPdpCompetenceDevelopmentById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          pcd.*,
          p.year AS pdp_year,
          c.competence_name,
          c.competence_type,
          py.pdpId AS py_pdpId,
          py.target AS py_target_value
        FROM pdp_competence_development pcd
        LEFT JOIN pdp p ON pcd.pdpId = p.id
        LEFT JOIN competence c ON pcd.competenceId = c.id
        LEFT JOIN pdp_competence_development py ON pcd.py_target = py.id
        WHERE pcd.id = ? AND pcd.isDeleted = 0 AND p.isDeleted = 0 AND c.isDeleted = 0
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Competence Development not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Competence Development retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Competence Developments by PDP ID
  getPdpCompetenceDevelopmentsByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      await validateForeignKey(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId], "PDP not found");

      const query = `
        SELECT 
          pcd.*,
          c.competence_name,
          c.competence_type,
          py.target AS py_target_value
        FROM pdp_competence_development pcd
        LEFT JOIN competence c ON pcd.competenceId = c.id
        LEFT JOIN pdp_competence_development py ON pcd.py_target = py.id
        WHERE pcd.pdpId = ? AND pcd.isDeleted = 0 AND c.isDeleted = 0
        ORDER BY pcd.id DESC
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Competence Developments retrieved",
        data
      });
    } catch (error) {
      if (error.message === "PDP not found") {
        return res.status(404).send({ status: false, message: error.message });
      }
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Competence Development
  updatePdpCompetenceDevelopment: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        competenceId,
        py_target,
        py_eoy,
        target,
        remarks,
        isActive,
        isDeleted
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const existing = await connection.query(
        `SELECT pdpId, competenceId FROM pdp_competence_development WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (existing.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Competence Development not found" });
      }

      if (pdpId) {
        await validateForeignKey(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId], "PDP not found");
      }

      if (competenceId) {
        await validateForeignKey(
          `SELECT id FROM competence WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [competenceId],
          "Competence not found or inactive"
        );
      }

      if (py_target) {
        await validateForeignKey(
          `SELECT id FROM pdp_competence_development WHERE id = ?`,
          [py_target],
          "py_target reference not found"
        );
      }

      if (pdpId || competenceId) {
        const finalPdpId = pdpId || existing[0].pdpId;
        const finalCompetenceId = competenceId || existing[0].competenceId;

        const duplicateCheck = await connection.query(
          `SELECT id FROM pdp_competence_development WHERE pdpId = ? AND competenceId = ? AND id != ? AND isDeleted = 0`,
          [finalPdpId, finalCompetenceId, id]
        );
        if (duplicateCheck.length > 0) {
          return res.status(400).send({
            status: false,
            message: "Entry already exists for this PDP and Competence"
          });
        }
      }

      const updateFields = [];
      const updateValues = [];
      const upsertField = (field, value) => {
        if (value !== undefined) {
          updateFields.push(`${field} = ?`);
          updateValues.push(value);
        }
      };

      upsertField("pdpId", pdpId);
      upsertField("competenceId", competenceId);
      upsertField("py_target", py_target);
      upsertField("py_eoy", py_eoy);
      upsertField("target", target);
      upsertField("remarks", remarks);
      upsertField("isActive", isActive);
      upsertField("isDeleted", isDeleted);

      if (updateFields.length === 0) {
        return res.status(400).send({ status: false, message: "No fields to update" });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_competence_development
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Competence Development updated successfully"
      });
    } catch (error) {
      if (error.message.includes("not found")) {
        return res.status(404).send({ status: false, message: error.message });
      }
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update Multiple PDP Competence Development
  updateMultiplePdpCompeDev: async function (req, res) {
    try {
      const { rows } = req.body;

      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({
          status: false,
          message: "Rows array is required"
        });
      }

      for (const row of rows) {
        const { id, ...fields } = row;

        if (!id) continue;

        const updateFields = [];
        const updateValues = [];

        // Dynamically build update fields
        for (const key in fields) {
          updateFields.push(`${key} = ?`);
          updateValues.push(fields[key]);
        }

        if (updateFields.length === 0) continue;

        // Always update updated_at
        const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        updateFields.push("updated_at = ?");
        updateValues.push(updatedOn);

        updateValues.push(id);

        const updateQuery = `
        UPDATE pdp_competence_development
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

        await connection.query(updateQuery, updateValues);
      }

      return res.status(200).send({
        status: true,
        message: "Multiple PDP Competence Development rows updated successfully"
      });

    } catch (error) {
      console.error("Error in updateMultiplePdpCompeDev:", error);
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getActiveMachines: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      await validateForeignKey(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId], "PDP not found");

      const query = `
       SELECT 
          pup.id,
          pup.pdpId,
          pup.uptimePartsId,
          pup.measurements,
          pup.category,
          pup.py_pdpUptime_id,
          pup.py_ytd,
          pup.py_eoy,
          pup.py_achievement,
          pup.target,
          pup.remarks,
          py_pup.target as py_target,
          upc.year as uptime_parts_year,
          upc.category as uptime_parts_category,
          upc.equipment_make,
          upc.details,
          upc.measurement_units
        FROM pdp_uptime_parts pup
        LEFT JOIN pdp_uptime_parts py_pup ON pup.py_pdpUptime_id = py_pup.id
        LEFT JOIN uptime_parts_category upc ON pup.uptimePartsId = upc.id
        WHERE pup.pdpId = ? AND details='Total  Active Machine Population' 
        AND pup.isDeleted = 0 AND upc.isDeleted = 0
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP  Active population retrieved",
        data
      });
    } catch (error) {
      if (error.message === "PDP not found") {
        return res.status(404).send({ status: false, message: error.message });
      }
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Competence Development
  deletePdpCompetenceDevelopment: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(
        `SELECT id FROM pdp_competence_development WHERE id = ?`,
        [id]
      );

      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Competence Development not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_competence_development SET isDeleted = 1, updated_at = ? WHERE id = ?`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Competence Development deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

