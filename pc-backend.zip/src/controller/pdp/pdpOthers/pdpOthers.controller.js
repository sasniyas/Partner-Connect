const { connection } = require("../../../mySql/mySql");
const { uploadFile } = require("../../azurestorage/fileUpload");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Others
  addPdpOthers: async function (req, res) {
    try {
      const { pdpId, othersId, optional_document_url } = req.body;

      if (!pdpId || !othersId) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, othersId"
        });
      }

      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const othersExists = await connection.query(
        `SELECT id FROM others_data WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [othersId]
      );
      if (othersExists.length === 0) {
        return res.status(404).send({ status: false, message: "Others Data not found or inactive" });
      }

      const duplicateCheck = await connection.query(
        `SELECT id FROM pdp_others WHERE pdpId = ? AND othersId = ? AND isDeleted = 0`,
        [pdpId, othersId]
      );
      if (duplicateCheck.length > 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Others entry already exists for this PDP and Others Data combination"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(
        `INSERT INTO pdp_others (pdpId, othersId, optional_document_url, created_at, updated_at, isDeleted) VALUES (?, ?, ?, ?, ?, 0)`,
        [pdpId, othersId, optional_document_url || null, pdpCreatedOn, pdpCreatedOn]
      );

      return res.status(200).send({
        status: true,
        message: "PDP Others added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllPdpOthers: async function (req, res) {
    try {
      const query = `
        SELECT 
          po.id,
          po.pdpId,
          po.othersId,
          po.optional_document_url,
          po.created_at,
          po.updated_at,
          od.file_name,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_others po
        LEFT JOIN others_data od ON po.othersId = od.id
        LEFT JOIN pdp p ON po.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE po.isDeleted = 0 AND (od.isDeleted = 0 OR od.isDeleted IS NULL) AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
        ORDER BY po.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Others records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Others list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getPdpOthersById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          po.id,
          po.pdpId,
          po.othersId,
          po.optional_document_url,
          po.created_at,
          po.updated_at,
          od.file_name,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_others po
        LEFT JOIN others_data od ON po.othersId = od.id
        LEFT JOIN pdp p ON po.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE po.id = ? AND po.isDeleted = 0 AND (od.isDeleted = 0 OR od.isDeleted IS NULL) AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Others not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Others retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getPdpOthersByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          po.id,
          po.pdpId,
          po.othersId,
          po.optional_document_url,
          po.created_at,
          po.updated_at,
          od.file_name
        FROM pdp_others po
        LEFT JOIN others_data od ON po.othersId = od.id
        WHERE po.pdpId = ? AND po.isDeleted = 0 AND (od.isDeleted = 0 OR od.isDeleted IS NULL)
        ORDER BY po.othersId
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Others retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updatePdpOthers: async function (req, res) {
    try {
      const { id, optional_document_url } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(`SELECT id FROM pdp_others WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Others not found" });
      }

      let documentUrl = optional_document_url;
      const files = req.files;
      if (files && files.length > 0) {
        const file = files[0];
        const uploadedUrl = await uploadFile(file);
        if (!uploadedUrl) {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
        documentUrl = uploadedUrl;
        console.log("File uploaded successfully, URL:", documentUrl);
      }

      if (documentUrl === undefined) {
        return res.status(400).send({
          status: false,
          message: "optional_document_url is required to update"
        });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(
        `UPDATE pdp_others SET optional_document_url = ?, updated_at = ? WHERE id = ? AND isDeleted = 0`,
        [documentUrl, updatedOn, id]
      );

      return res.status(200).send({
        status: true,
        message: "PDP Others document updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deletePdpOthers: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(`SELECT id FROM pdp_others WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Others not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_others SET isDeleted = 1, updated_at = ? WHERE id = ?`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Others deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
