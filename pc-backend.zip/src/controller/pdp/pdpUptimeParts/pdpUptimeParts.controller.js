const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Uptime Parts
  addPdpUptimeParts: async function (req, res) {
    try {
      const {
        pdpId,
        uptimePartsId,
        measurements,
        category,
        py_pdpUptime_id,
        py_ytd,
        py_eoy,
        py_achievement,
        target,
        remarks
      } = req.body;

      if (!pdpId || !uptimePartsId || !category) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, uptimePartsId, category"
        });
      }

      // Validate category
      const validCategories = ["Retails", "Key Account"];
      if (!validCategories.includes(category)) {
        return res.status(400).send({
          status: false,
          message: "Category must be either 'Retails' or 'Key Account'"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if uptime parts category exists
      const uptimePartsExists = await connection.query(
        `SELECT id FROM uptime_parts_category WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [uptimePartsId]
      );
      if (uptimePartsExists.length === 0) {
        return res.status(404).send({ status: false, message: "Uptime Parts Category not found or inactive" });
      }

      // Check for duplicate (same pdpId, uptimePartsId, and category)
      const duplicateCheck = await connection.query(
        `SELECT id FROM pdp_uptime_parts WHERE pdpId = ? AND uptimePartsId = ? AND category = ? AND isDeleted = 0`,
        [pdpId, uptimePartsId, category]
      );
      if (duplicateCheck.length > 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Uptime Parts entry already exists for this PDP, Uptime Parts, and Category combination"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_uptime_parts (
          pdpId, uptimePartsId, measurements, category, py_pdpUptime_id,
          py_ytd, py_eoy, py_achievement,
          target, remarks, created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
      `;

      await connection.query(insertQuery, [
        pdpId,
        uptimePartsId,
        measurements || null,
        category,
        py_pdpUptime_id || null,
        py_ytd || 0,
        py_eoy || 0,
        py_achievement || 0.00,
        target || 0,
        remarks || null,
        pdpCreatedOn,
        pdpCreatedOn
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Uptime Parts added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Uptime Parts
  getAllPdpUptimeParts: async function (req, res) {
    try {
      const query = `
        SELECT 
          pup.id,
          pup.pdpId,
          pup.uptimePartsId,
          pup.measurements,
          pup.category,
          pup.py_pdpUptime_id,
          pup.py_ytd,
          pup.py_eoy,
          pup.py_achievement,
          pup.target,
          pup.remarks,
          py_pup.target as py_target,
          upc.year as uptime_parts_year,
          upc.category as uptime_parts_category,
          upc.equipment_make,
          upc.details,
          upc.measurement_units,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_uptime_parts pup
        LEFT JOIN pdp_uptime_parts py_pup ON pup.py_pdpUptime_id = py_pup.id
        LEFT JOIN uptime_parts_category upc ON pup.uptimePartsId = upc.id
        LEFT JOIN pdp p ON pup.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pup.isDeleted = 0 AND (py_pup.isDeleted = 0 OR py_pup.isDeleted IS NULL) AND (upc.isDeleted = 0 OR upc.isDeleted IS NULL) AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
        ORDER BY pup.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Uptime Parts records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Uptime Parts list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Uptime Parts by ID
  getPdpUptimePartsById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          pup.id,
          pup.pdpId,
          pup.uptimePartsId,
          pup.measurements,
          pup.category,
          pup.py_pdpUptime_id,
          pup.py_ytd,
          pup.py_eoy,
          pup.py_achievement,
          pup.target,
          pup.remarks,
          py_pup.target as py_target,
          upc.year as uptime_parts_year,
          upc.category as uptime_parts_category,
          upc.equipment_make,
          upc.details,
          upc.measurement_units,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_uptime_parts pup
        LEFT JOIN pdp_uptime_parts py_pup ON pup.py_pdpUptime_id = py_pup.id
        LEFT JOIN uptime_parts_category upc ON pup.uptimePartsId = upc.id
        LEFT JOIN pdp p ON pup.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pup.id = ? AND pup.isDeleted = 0 AND (py_pup.isDeleted = 0 OR py_pup.isDeleted IS NULL) AND (upc.isDeleted = 0 OR upc.isDeleted IS NULL) AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Uptime Parts not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Uptime Parts retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Uptime Parts by PDP ID
  getPdpUptimePartsByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      let query = `
        SELECT 
          pup.id,
          pup.pdpId,
          pup.uptimePartsId,
          pup.measurements,
          pup.category,
          pup.py_pdpUptime_id,
          pup.py_ytd,
          pup.py_eoy,
          pup.py_achievement,
          pup.target,
          pup.remarks,
          py_pup.target as py_target,
          upc.year as uptime_parts_year,
          upc.category as uptime_parts_category,
          upc.equipment_make,
          upc.details,
          upc.measurement_units
        FROM pdp_uptime_parts pup
        LEFT JOIN pdp_uptime_parts py_pup ON pup.py_pdpUptime_id = py_pup.id
        LEFT JOIN uptime_parts_category upc ON pup.uptimePartsId = upc.id
        WHERE pup.isDeleted = 0 AND (py_pup.isDeleted = 0 OR py_pup.isDeleted IS NULL) AND (upc.isDeleted = 0 OR upc.isDeleted IS NULL)
      `;

      let values = [];

      if (pdpId) {
        query += " AND pup.pdpId = ?";
        values.push(pdpId);
      }

      if (req.query.category) {
        query += " AND pup.category = ? ";
        values.push(req.query.category);
      }
      query += " ORDER BY pup.uptimePartsId, pup.category";



      const data = await connection.query(query, values);

      return res.status(200).send({
        status: true,
        message: "PDP Uptime Parts retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Uptime Parts
  updatePdpUptimeParts: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        uptimePartsId,
        measurements,
        category,
        py_pdpUptime_id,
        py_ytd,
        py_eoy,
        py_achievement,
        target,
        remarks
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Uptime Parts exists
      const exists = await connection.query(`SELECT id FROM pdp_uptime_parts WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Uptime Parts not found" });
      }

      // Validate category if provided
      if (category) {
        const validCategories = ["Retails", "Key Account"];
        if (!validCategories.includes(category)) {
          return res.status(400).send({
            status: false,
            message: "Category must be either 'Retails' or 'Key Account'"
          });
        }
      }

      // Check for duplicate if pdpId, uptimePartsId, or category is being changed
      if (pdpId || uptimePartsId || category) {
        const currentData = await connection.query(
          `SELECT pdpId, uptimePartsId, category FROM pdp_uptime_parts WHERE id = ? AND isDeleted = 0`,
          [id]
        );
        const finalPdpId = pdpId || currentData[0].pdpId;
        const finalUptimePartsId = uptimePartsId || currentData[0].uptimePartsId;
        const finalCategory = category || currentData[0].category;

        const duplicateCheck = await connection.query(
          `SELECT id FROM pdp_uptime_parts WHERE pdpId = ? AND uptimePartsId = ? AND category = ? AND id != ? AND isDeleted = 0`,
          [finalPdpId, finalUptimePartsId, finalCategory, id]
        );
        if (duplicateCheck.length > 0) {
          return res.status(400).send({
            status: false,
            message: "PDP Uptime Parts entry already exists for this PDP, Uptime Parts, and Category combination"
          });
        }
      }

      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }
      if (uptimePartsId !== undefined) {
        updateFields.push("uptimePartsId = ?");
        updateValues.push(uptimePartsId);
      }
      if (measurements !== undefined) {
        updateFields.push("measurements = ?");
        updateValues.push(measurements);
      }
      if (category !== undefined) {
        updateFields.push("category = ?");
        updateValues.push(category);
      }
      if (py_pdpUptime_id !== undefined) {
        updateFields.push("py_pdpUptime_id = ?");
        updateValues.push(py_pdpUptime_id);
      }
      if (py_ytd !== undefined) {
        updateFields.push("py_ytd = ?");
        updateValues.push(py_ytd);
      }
      if (py_eoy !== undefined) {
        updateFields.push("py_eoy = ?");
        updateValues.push(py_eoy);
      }
      if (py_achievement !== undefined) {
        updateFields.push("py_achievement = ?");
        updateValues.push(py_achievement);
      }
      if (target !== undefined) {
        updateFields.push("target = ?");
        updateValues.push(target);
      }
      if (remarks !== undefined) {
        updateFields.push("remarks = ?");
        updateValues.push(remarks);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_uptime_parts
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Uptime Parts updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update Multiple PDP Uptime Parts
  updateMultiplePdpUptimeParts: async function (req, res) {
    try {
      const { rows } = req.body;

      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({
          status: false,
          message: "Rows array is required"
        });
      }

      for (const row of rows) {
        const { id, ...fields } = row;

        if (!id) continue;

        const updateFields = [];
        const updateValues = [];

        for (const key in fields) {
          updateFields.push(`${key} = ?`);
          updateValues.push(fields[key]);
        }

        if (updateFields.length === 0) continue;

        // Always update updated_at
        const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        updateFields.push("updated_at = ?");
        updateValues.push(updatedOn);

        updateValues.push(id);

        const updateQuery = `
        UPDATE pdp_uptime_parts
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

        await connection.query(updateQuery, updateValues);
      }

      return res.status(200).send({
        status: true,
        message: "Multiple PDP Uptime Parts updated successfully"
      });

    } catch (error) {
      console.error("Error updating uptime parts:", error);
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },


  // 🗑️ Delete PDP Uptime Parts
  deletePdpUptimeParts: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Uptime Parts exists
      const exists = await connection.query(`SELECT id FROM pdp_uptime_parts WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Uptime Parts not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_uptime_parts SET isDeleted = 1, updated_at = ? WHERE id = ? AND isDeleted = 0`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Uptime Parts deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

