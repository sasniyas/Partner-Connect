const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

const validateForeignKey = async (query, params, notFoundMessage) => {
  const rows = await connection.query(query, params);
  if (rows.length === 0) {
    throw new Error(notFoundMessage);
  }
};

module.exports = {
  // 📋 Get All PDP Marcom Marketing
  getAllPdpMarcomMarketing: async function (_req, res) {
    try {
      const query = `
        SELECT 
          pmm.id,
          pmm.pdpId,
          pmm.marcom_marketing_id,
          pmm.marketing_area,
          pmm.count_of_activities,
          pmm.activity_description,
          pmm.amount_spent,
          pmm.impacts,
          pmm.created_at,
          pmm.updated_at,
          pmm.isActive,
          pmm.isDeleted,
          p.year AS pdp_year,
          m.id AS marcommrk_id,
          m.activity_Type,
          m.target,
          m.createdOn AS marcommrk_createdOn,
          m.isActive AS marcommrk_isActive,
          m.isDeleted AS marcommrk_isDeleted
        FROM pdp_marcom_marketing pmm
        LEFT JOIN pdp p ON pmm.pdpId = p.id
        LEFT JOIN marcommrk m ON pmm.marcom_marketing_id = m.id
        WHERE pmm.isDeleted = 0
        ORDER BY pmm.id DESC
      `;

      const data = await connection.query(query);

      return res.status(200).send({
        status: true,
        message: data.length ? "PDP Marcom Marketing list retrieved" : "No records found",
        data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Marcom Marketing by ID
  getPdpMarcomMarketingById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          pmm.id,
          pmm.pdpId,
          pmm.marcom_marketing_id,
          pmm.marketing_area,
          pmm.count_of_activities,
          pmm.activity_description,
          pmm.amount_spent,
          pmm.impacts,
          pmm.created_at,
          pmm.updated_at,
          pmm.isActive,
          pmm.isDeleted,
          p.year AS pdp_year,
          m.id AS marcommrk_id,
          m.activity_Type,
          m.target,
          m.createdOn AS marcommrk_createdOn,
          m.isActive AS marcommrk_isActive,
          m.isDeleted AS marcommrk_isDeleted
        FROM pdp_marcom_marketing pmm
        LEFT JOIN pdp p ON pmm.pdpId = p.id
        LEFT JOIN marcommrk m ON pmm.marcom_marketing_id = m.id
        WHERE pmm.id = ? AND pmm.isDeleted = 0
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Marcom Marketing not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Marcom Marketing retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Marcom Marketing by PDP ID
  getPdpMarcomMarketingByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      await validateForeignKey(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId], "PDP not found");

      const query = `
        SELECT 
          pmm.id,
          pmm.pdpId,
          pmm.marcom_marketing_id,
          pmm.marketing_area,
          pmm.count_of_activities,
          pmm.activity_description,
          pmm.amount_spent,
          pmm.impacts,
          pmm.created_at,
          pmm.updated_at,
          pmm.isActive,
          pmm.isDeleted,
          p.year AS pdp_year,
          m.id AS marcommrk_id,
          m.activity_Type,
          m.target,
          m.createdOn AS marcommrk_createdOn,
          m.isActive AS marcommrk_isActive,
          m.isDeleted AS marcommrk_isDeleted
        FROM pdp_marcom_marketing pmm
        LEFT JOIN pdp p ON pmm.pdpId = p.id
        LEFT JOIN marcommrk m ON pmm.marcom_marketing_id = m.id
        WHERE pmm.pdpId = ? AND pmm.isDeleted = 0
        ORDER BY pmm.id DESC
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Marcom Marketing records retrieved",
        data
      });
    } catch (error) {
      if (error.message === "PDP not found") {
        return res.status(404).send({ status: false, message: error.message });
      }
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Marcom Marketing
  updatePdpMarcomMarketing: async function (req, res) {
    try {
      const {
        id,
        marketing_area,
        count_of_activities,
        activity_description,
        amount_spent,
        impacts,
        isActive,
        isDeleted
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if record exists
      const existing = await connection.query(
        `SELECT id FROM pdp_marcom_marketing WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (existing.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Marcom Marketing not found" });
      }

      const updateFields = [];
      const updateValues = [];
      const upsertField = (field, value) => {
        if (value !== undefined) {
          updateFields.push(`${field} = ?`);
          updateValues.push(value);
        }
      };

      upsertField("marketing_area", marketing_area);
      upsertField("count_of_activities", count_of_activities);
      upsertField("activity_description", activity_description);
      upsertField("amount_spent", amount_spent);
      upsertField("impacts", impacts);
      upsertField("isActive", isActive);
      upsertField("isDeleted", isDeleted);

      if (updateFields.length === 0) {
        return res.status(400).send({ status: false, message: "No fields to update" });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_marcom_marketing
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Marcom Marketing updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update Multiple PDP Equipment
  updateMultiplePdpMarcomMarketing: async function (req, res) {
    try {
      const { rows } = req.body;

      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array required" });
      }

      for (const row of rows) {
        const { id, ...fields } = row;

        if (!id) continue;

        const updateFields = [];
        const updateValues = [];

        for (const key in fields) {
          updateFields.push(`${key} = ?`);
          updateValues.push(fields[key]);
        }

        if (updateFields.length === 0) continue;

        // Always update updated_at
        const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        updateFields.push("updated_at = ?");
        updateValues.push(updatedOn);

        updateValues.push(id);

        const query = `
        UPDATE pdp_marcom_marketing 
        SET ${updateFields.join(", ")} 
        WHERE id = ? AND isDeleted = 0
      `;

        await connection.query(query, updateValues);
      }

      return res.status(200).send({
        status: true,
        message: "Multiple Pdp Marcom Marketing rows updated successfully"
      });

    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deletePdpMarcomMarketing: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(
        `SELECT id FROM pdp_marcom_marketing WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Marcom Marketing not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_marcom_marketing SET isDeleted = 1, updated_at = ? WHERE id = ? AND isDeleted = 0`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Marcom Marketing deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

