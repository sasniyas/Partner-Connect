const { connection } = require("../../../mySql/mySql");
const { uploadFile } = require("../../azurestorage/fileUpload");
const moment = require('moment-timezone');

const validateForeignKey = async (query, params, notFoundMessage) => {
  const rows = await connection.query(query, params);
  if (rows.length === 0) {
    throw new Error(notFoundMessage);
  }
};

module.exports = {
  // 📋 Get All PDP Marcom Branding
  getAllPdpMarcomBranding: async function (_req, res) {
    try {
      const query = `
        SELECT 
          pmb.id,
          pmb.pdpId,
          pmb.marcom_branding_id,
          pmb.budget,
          pmb.remarks,
          pmb.supportive_doc_url,
          pmb.created_at,
          pmb.updated_at,
          pmb.isActive,
          pmb.isDeleted,
          p.year AS pdp_year,
          m.id AS marcom_id,
          m.marcom_type,
          m.marcom_name,
          m.createdOn AS marcom_createdOn,
          m.isActive AS marcom_isActive,
          m.isDeleted AS marcom_isDeleted
        FROM pdp_marcom_branding pmb
        LEFT JOIN pdp p ON pmb.pdpId = p.id
        LEFT JOIN marcom m ON pmb.marcom_branding_id = m.id
        WHERE pmb.isDeleted = 0
        ORDER BY pmb.id DESC
      `;

      const data = await connection.query(query);

      return res.status(200).send({
        status: true,
        message: data.length ? "PDP Marcom Branding list retrieved" : "No records found",
        data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Marcom Branding by ID
  getPdpMarcomBrandingById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          pmb.id,
          pmb.pdpId,
          pmb.marcom_branding_id,
          pmb.budget,
          pmb.remarks,
          pmb.supportive_doc_url,
          pmb.created_at,
          pmb.updated_at,
          pmb.isActive,
          pmb.isDeleted,
          p.year AS pdp_year,
          m.id AS marcom_id,
          m.marcom_type,
          m.marcom_name,
          m.createdOn AS marcom_createdOn,
          m.isActive AS marcom_isActive,
          m.isDeleted AS marcom_isDeleted
        FROM pdp_marcom_branding pmb
        LEFT JOIN pdp p ON pmb.pdpId = p.id
        LEFT JOIN marcom m ON pmb.marcom_branding_id = m.id
        WHERE pmb.id = ? AND pmb.isDeleted = 0
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Marcom Branding not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Marcom Branding retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Marcom Branding by PDP ID
  getPdpMarcomBrandingByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      await validateForeignKey(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId], "PDP not found");

      const query = `
        SELECT 
          pmb.id,
          pmb.pdpId,
          pmb.marcom_branding_id,
          pmb.budget,
          pmb.remarks,
          pmb.supportive_doc_url,
          pmb.created_at,
          pmb.updated_at,
          pmb.isActive,
          pmb.isDeleted,
          p.year AS pdp_year,
          m.id AS marcom_id,
          m.marcom_type,
          m.marcom_name,
          m.createdOn AS marcom_createdOn,
          m.isActive AS marcom_isActive,
          m.isDeleted AS marcom_isDeleted
        FROM pdp_marcom_branding pmb
        LEFT JOIN pdp p ON pmb.pdpId = p.id
        LEFT JOIN marcom m ON pmb.marcom_branding_id = m.id
        WHERE pmb.pdpId = ? AND pmb.isDeleted = 0
        ORDER BY pmb.id DESC
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Marcom Branding records retrieved",
        data
      });
    } catch (error) {
      if (error.message === "PDP not found") {
        return res.status(404).send({ status: false, message: error.message });
      }
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Marcom Branding
  updatePdpMarcomBranding: async function (req, res) {
    try {
      const {
        id,
        budget,
        remarks,
        supportive_doc_url,
        isActive,
        isDeleted
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if record exists
      const existing = await connection.query(
        `SELECT id FROM pdp_marcom_branding WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (existing.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Marcom Branding not found" });
      }

      // Handle file upload if file is present
      let fileUrl = null;
      const files = req.files;
      if (files && files.length > 0) {
        const file = files[0]; // Get the first file
        const uploadedUrl = await uploadFile(file);
        if (!uploadedUrl || typeof uploadedUrl === 'object') {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
        fileUrl = uploadedUrl;
        console.log("File uploaded successfully, URL:", fileUrl);
      }

      const updateFields = [];
      const updateValues = [];
      const upsertField = (field, value) => {
        if (value !== undefined) {
          updateFields.push(`${field} = ?`);
          updateValues.push(value);
        }
      };

      upsertField("budget", budget);
      upsertField("remarks", remarks);
      // Use uploaded file URL if file was uploaded, otherwise use provided URL
      if (fileUrl !== null) {
        upsertField("supportive_doc_url", fileUrl);
      } else {
        upsertField("supportive_doc_url", supportive_doc_url);
      }
      upsertField("isActive", isActive);
      upsertField("isDeleted", isDeleted);

      if (updateFields.length === 0) {
        return res.status(400).send({ status: false, message: "No fields to update" });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_marcom_branding
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Marcom Branding updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update Multiple PDP Equipment
  updateMultiplePdpMarcomBranding: async function (req, res) {
    try {
      const { rows } = req.body;

      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array required" });
      }

      for (const row of rows) {
        const { id, ...fields } = row;

        if (!id) continue;

        const updateFields = [];
        const updateValues = [];

        for (const key in fields) {
          updateFields.push(`${key} = ?`);
          updateValues.push(fields[key]);
        }

        if (updateFields.length === 0) continue;

        // Always update updated_at
        const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        updateFields.push("updated_at = ?");
        updateValues.push(updatedOn);

        updateValues.push(id);

        const query = `
        UPDATE pdp_marcom_branding 
        SET ${updateFields.join(", ")} 
        WHERE id = ? AND isDeleted = 0
      `;

        await connection.query(query, updateValues);
      }

      return res.status(200).send({
        status: true,
        message: "Multiple Pdp Marcom Branding rows updated successfully"
      });

    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Marcom Branding
  updatePdpMarcomSupdoc: async function (req, res) {
    try {
      let {
        id,
        fileUrl
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if record exists
      const existing = await connection.query(
        `SELECT id FROM pdp_marcom_branding WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (existing.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Marcom Branding not found" });
      }


      const files = req.files;
      if (files && files.length > 0) {
        const file = files[0]; // Get the first file
        const uploadedUrl = await uploadFile(file);
        if (!uploadedUrl || typeof uploadedUrl === 'object') {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
        fileUrl = uploadedUrl;
        console.log("File uploaded successfully, URL:", fileUrl);
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const updateQuery = `
        UPDATE pdp_marcom_branding
        SET supportive_doc_url = ?, updated_at = ?
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, [fileUrl, updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Marcom Branding supproting doc updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Marcom Branding
  deletePdpMarcomSupdoc: async function (req, res) {
    try {

      let id = req.params.id

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if record exists
      const existing = await connection.query(
        `SELECT id FROM pdp_marcom_branding WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (existing.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Marcom Branding not found" });
      }




      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const updateQuery = `
        UPDATE pdp_marcom_branding
        SET supportive_doc_url = '', updated_at = ?
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Marcom Branding supproting doc removed successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deletePdpMarcomBranding: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(
        `SELECT id FROM pdp_marcom_branding WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Marcom Branding not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_marcom_branding SET isDeleted = 1, updated_at = ? WHERE id = ? AND isDeleted = 0`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Marcom Branding deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

