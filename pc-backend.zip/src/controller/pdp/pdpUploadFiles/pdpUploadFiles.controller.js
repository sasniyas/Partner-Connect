const { connection } = require("../../../mySql/mySql");
const { uploadFile } = require("../../azurestorage/fileUpload");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Upload File
  addPdpUploadFile: async function (req, res) {
    try {
      const {
        pdpId,
        category,
        file_name
      } = req.body;
      const uploaded_by = req.decodedToken
      if (!pdpId || !category) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, category"
        });
      }

      // Validate category
      const validCategories = ["Presentation", "Finance"];
      if (!validCategories.includes(category)) {
        return res.status(400).send({
          status: false,
          message: "Category must be either 'Presentation' or 'Finance'"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if uploaded_by user exists (if provided)
      if (uploaded_by) {
        const userExists = await connection.query(`SELECT id FROM userdetails WHERE id = ? AND isDeleted = 0`, [uploaded_by]);
        if (userExists.length === 0) {
          return res.status(404).send({ status: false, message: "User not found" });
        }
      }

      // Handle file upload if file is present
      let fileUrl = null;
      const files = req.files;
      if (files && files.length > 0) {
        const file = files[0]; // Get the first file
        const uploadedUrl = await uploadFile(file);
        if (!uploadedUrl || typeof uploadedUrl === 'object') {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
        fileUrl = uploadedUrl;
        console.log("File uploaded successfully, URL:", fileUrl);
      } else {
        return res.status(400).send({ status: false, message: "File is required" });
      }

      // Use file name from uploaded file if file_name not provided
      const finalFileName = file_name || (files && files[0] ? files[0].originalname : null);

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_uploadFiles (pdpId, category, file_name, file_url, uploaded_by, created_at, updated_at, isDeleted)
        VALUES (?, ?, ?, ?, ?, ?, ?, 0)
      `;

      await connection.query(insertQuery, [
        pdpId,
        category,
        finalFileName,
        fileUrl,
        uploaded_by || null,
        pdpCreatedOn,
        pdpCreatedOn
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Upload File added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Upload Files
  getAllPdpUploadFiles: async function (req, res) {
    try {
      const query = `
        SELECT 
          puf.id,
          puf.pdpId,
          puf.category,
          puf.file_name,
          puf.file_url,
          puf.uploaded_by,
          puf.created_at,
          puf.updated_at,
          puf.isActive,
          puf.isDeleted,
          u.firstName as uploaded_by_firstName,
          u.lastName as uploaded_by_lastName,
          u.email as uploaded_by_email,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_uploadFiles puf
        LEFT JOIN userdetails u ON puf.uploaded_by = u.id
        LEFT JOIN pdp p ON puf.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE (puf.isDeleted = 0) AND (puf.isActive = TRUE OR puf.isActive = 1)
        ORDER BY puf.created_at DESC, puf.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Upload Files records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Upload Files list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Upload File by ID
  getPdpUploadFileById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          puf.id,
          puf.pdpId,
          puf.category,
          puf.file_name,
          puf.file_url,
          puf.uploaded_by,
          puf.created_at,
          puf.updated_at,
          puf.isActive,
          puf.isDeleted,
          u.firstName as uploaded_by_firstName,
          u.lastName as uploaded_by_lastName,
          u.email as uploaded_by_email,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_uploadFiles puf
        LEFT JOIN userdetails u ON puf.uploaded_by = u.id
        LEFT JOIN pdp p ON puf.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE puf.id = ? AND (puf.isDeleted = 0) AND (puf.isActive = TRUE OR puf.isActive = 1)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Upload File not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Upload File retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Upload Files by PDP ID
  getPdpUploadFilesByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          puf.id,
          puf.pdpId,
          puf.category,
          puf.file_name,
          puf.file_url,
          puf.uploaded_by,
          puf.created_at,
          puf.updated_at,
          puf.isActive,
          puf.isDeleted,
          u.firstName as uploaded_by_firstName,
          u.lastName as uploaded_by_lastName,
          u.email as uploaded_by_email
        FROM pdp_uploadFiles puf
        LEFT JOIN userdetails u ON puf.uploaded_by = u.id
        WHERE puf.pdpId = ? AND (puf.isDeleted = 0) AND (puf.isActive = TRUE OR puf.isActive = 1)
        ORDER BY puf.category, puf.created_at DESC
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Upload Files retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Upload File
  updatePdpUploadFile: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        category,
        file_name,
        isActive
      } = req.body;
      const uploaded_by = req.decodedToken
      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Upload File exists
      const exists = await connection.query(`SELECT id FROM pdp_uploadFiles WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Upload File not found" });
      }

      // Handle file upload if file is present
      let fileUrl = null;
      const files = req.files;
      if (files && files.length > 0) {
        const file = files[0]; // Get the first file
        const uploadedUrl = await uploadFile(file);
        if (!uploadedUrl || typeof uploadedUrl === 'object') {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
        fileUrl = uploadedUrl;
        console.log("File uploaded successfully, URL:", fileUrl);
      }

      // Validate category if provided
      if (category) {
        const validCategories = ["Presentation", "Finance"];
        if (!validCategories.includes(category)) {
          return res.status(400).send({
            status: false,
            message: "Category must be either 'Presentation' or 'Finance'"
          });
        }
      }

      // Check if PDP exists if pdpId is being changed
      if (pdpId) {
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
        if (pdpExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP not found" });
        }
      }

      // Check if uploaded_by user exists if provided
      if (uploaded_by) {
        const userExists = await connection.query(`SELECT id FROM userdetails WHERE id = ? AND isDeleted = 0`, [uploaded_by]);
        if (userExists.length === 0) {
          return res.status(404).send({ status: false, message: "User not found" });
        }
      }

      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }
      if (category !== undefined) {
        updateFields.push("category = ?");
        updateValues.push(category);
      }
      if (file_name !== undefined) {
        updateFields.push("file_name = ?");
        updateValues.push(file_name);
      }
      if (fileUrl !== null) {
        updateFields.push("file_url = ?");
        updateValues.push(fileUrl);
        // Update file_name from uploaded file if file_name not provided
        if (file_name === undefined && files && files[0]) {
          updateFields.push("file_name = ?");
          updateValues.push(files[0].originalname);
        }
      }
      if (uploaded_by !== undefined) {
        updateFields.push("uploaded_by = ?");
        updateValues.push(uploaded_by);
      }


      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_uploadFiles
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Upload File updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Upload File (Soft Delete)
  deletePdpUploadFile: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Upload File exists
      const exists = await connection.query(`SELECT id FROM pdp_uploadFiles WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Upload File not found" });
      }

      // Soft delete: set isDeleted = 1
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(
        `UPDATE pdp_uploadFiles SET isDeleted = 1, updated_at = ? WHERE id = ? AND isDeleted = 0`,
        [updatedOn, id]
      );

      return res.status(200).send({
        status: true,
        message: "PDP Upload File deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

