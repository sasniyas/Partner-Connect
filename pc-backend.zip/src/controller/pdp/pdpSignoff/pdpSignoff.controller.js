const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

// Valid signoff categories based on schema enum
const SIGNOFF_CATEGORIES = [
  "Equipments_Volvo",
  "Equipments_Dealer",
  "Uptime_Volvo",
  "Uptime_Dealer",
  "Sales_Head",
  "Retail Sales Manager",
  "Regional_Head",
  "CEO/Dealer_Principal"
  // "Business_Head"
];

module.exports = {
  // ➕ Add PDP Signoff
  addPdpSignoff: async function (req, res) {
    try {
      const {
        pdpId,
        userId,
        category
      } = req.body;

      if (!pdpId || !userId || !category) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, userId, category"
        });
      }

      // Validate category
      if (!SIGNOFF_CATEGORIES.includes(category)) {
        return res.status(400).send({
          status: false,
          message: `Category must be one of: ${SIGNOFF_CATEGORIES.join(", ")}`
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if user exists
      const userExists = await connection.query(`SELECT id FROM userdetails WHERE id = ? AND isDeleted = 0`, [userId]);
      if (userExists.length === 0) {
        return res.status(404).send({ status: false, message: "User not found" });
      }

      // Check for duplicate (same pdpId, userId, and category) - only check active, non-deleted records
      const duplicateCheck = await connection.query(
        `SELECT id FROM pdp_signoff WHERE pdpId = ? AND userId = ? AND category = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [pdpId, userId, category]
      );
      if (duplicateCheck.length > 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Signoff entry already exists for this PDP, User, and Category combination"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_signoff (pdpId, userId, category, isSigned, isActive, isDeleted, created_at, updated_at)
        VALUES (?, ?, ?, 0, 1, 0, ?, ?)
      `;

      await connection.query(insertQuery, [
        pdpId,
        userId,
        category,
        pdpCreatedOn,
        pdpCreatedOn
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Signoff added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Signoffs
  getAllPdpSignoffs: async function (req, res) {
    try {
      const query = `
        SELECT 
          ps.id,
          ps.pdpId,
          ps.userId,
          ps.category,
          ps.isSigned,
          ps.signed_timestamp,
          ps.created_at,
          ps.updated_at,
          ps.isActive,
          ps.isDeleted,
          u.firstName as user_first_name,
          u.lastName as user_last_name,
          u.email as user_email,
          u.persona as user_persona,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_signoff ps
        LEFT JOIN userdetails u ON ps.userId = u.id
        LEFT JOIN pdp p ON ps.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE (ps.isActive = 1 OR ps.isActive IS NULL) AND (ps.isDeleted = 0 OR ps.isDeleted IS NULL)
        ORDER BY ps.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Signoff records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Signoff list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Signoff by ID
  getPdpSignoffById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          ps.id,
          ps.pdpId,
          ps.userId,
          ps.category,
          ps.isSigned,
          ps.signed_timestamp,
          ps.created_at,
          ps.updated_at,
          ps.isActive,
          ps.isDeleted,
          u.firstName as user_first_name,
          u.lastName as user_last_name,
          u.email as user_email,
          u.persona as user_persona,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_signoff ps
        LEFT JOIN userdetails u ON ps.userId = u.id
        LEFT JOIN pdp p ON ps.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE ps.id = ? AND (ps.isActive = 1 OR ps.isActive IS NULL) AND (ps.isDeleted = 0 OR ps.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Signoff not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Signoff retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Signoffs by PDP ID
  getPdpSignoffsByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          ps.id,
          ps.pdpId,
          ps.userId,
          ps.category,
          ps.isSigned,
          ps.signed_timestamp,
          ps.created_at,
          ps.updated_at,
          ps.isActive,
          ps.isDeleted,
          u.firstName as user_first_name,
          u.lastName as user_last_name,
          u.email as user_email,
          u.persona as user_persona
        FROM pdp_signoff ps
        LEFT JOIN userdetails u ON ps.userId = u.id
        WHERE ps.pdpId = ? AND (ps.isActive = 1 OR ps.isActive IS NULL) AND (ps.isDeleted = 0 OR ps.isDeleted IS NULL)
        ORDER BY ps.userId, ps.category
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Signoffs retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Signoffs by User ID
  getPdpSignoffsByUserId: async function (req, res) {
    try {
      const { userId } = req.params;

      if (!userId) {
        return res.status(400).send({ status: false, message: "User ID is required" });
      }

      // Check if user exists
      const userExists = await connection.query(`SELECT id FROM userdetails WHERE id = ? AND isDeleted = 0`, [userId]);
      if (userExists.length === 0) {
        return res.status(404).send({ status: false, message: "User not found" });
      }

      const query = `
        SELECT 
          ps.id,
          ps.pdpId,
          ps.userId,
          ps.category,
          ps.isSigned,
          ps.signed_timestamp,
          ps.created_at,
          ps.updated_at,
          ps.isActive,
          ps.isDeleted,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_signoff ps
        LEFT JOIN pdp p ON ps.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE ps.userId = ? AND (ps.isActive = 1 OR ps.isActive IS NULL) AND (ps.isDeleted = 0 OR ps.isDeleted IS NULL)
        ORDER BY ps.pdpId, ps.category
      `;

      const data = await connection.query(query, [userId]);

      return res.status(200).send({
        status: true,
        message: "PDP Signoffs retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updatePdpSignoff: async function (req, res) {
    try {
      const { id, isSigned } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      if (isSigned === undefined) {
        return res.status(400).send({ status: false, message: "isSigned is required" });
      }

      // Get userId from token
      const userId = req.decodedToken;
      if (!userId) {
        return res.status(401).send({ status: false, message: "User authentication required" });
      }

      // Build update query - always update userId, isSigned, signed_timestamp, and updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const updateQuery = `
        UPDATE pdp_signoff
        SET userId = ?, isSigned = ?, signed_timestamp = CURRENT_TIMESTAMP, updated_at = ?
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, [userId, isSigned ? 1 : 0, updatedOn, id]);

      // Fetch the pdpId of this signoff entry
      const signoffEntry = await connection.query(
        `SELECT pdpId FROM pdp_signoff WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (signoffEntry.length > 0) {
        const pdpId = signoffEntry[0].pdpId;

        // Fetch all signoffs for this pdpId
        const allSignoffs = await connection.query(
          `SELECT isSigned FROM pdp_signoff 
           WHERE pdpId = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [pdpId]
        );

        // Check if all signoffs have isSigned = 1 (true)
        const allSigned = allSignoffs.length > 0 && allSignoffs.every(signoff => signoff.isSigned === 1 || signoff.isSigned === true);

        if (allSigned) {
          // All signoffs are completed, update PDP status to "Completed" and set completed_date
          const completedDate = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
          await connection.query(
            `UPDATE pdp SET sign_of_status = ?, completed_date = ?, updated_at = ? WHERE id = ?`,
            ["Completed", completedDate, updatedOn, pdpId]
          );
        }
      }

      return res.status(200).send({
        status: true,
        message: "PDP Signoff updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Sign PDP Signoff (convenience method to sign off)
  signPdpSignoff: async function (req, res) {
    try {
      const { id } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Signoff exists and is active
      const exists = await connection.query(
        `SELECT id, isSigned FROM pdp_signoff WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Signoff not found or inactive" });
      }

      if (exists[0].isSigned === 1 || exists[0].isSigned === true) {
        return res.status(400).send({
          status: false,
          message: "PDP Signoff is already signed"
        });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const updateQuery = `
        UPDATE pdp_signoff
        SET isSigned = 1, signed_timestamp = CURRENT_TIMESTAMP, updated_at = ?
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, [updatedOn, id]);

      // Fetch the pdpId of this signoff entry
      const signoffEntry = await connection.query(
        `SELECT pdpId FROM pdp_signoff WHERE id = ? AND isDeleted = 0`,
        [id]
      );

      if (signoffEntry.length > 0) {
        const pdpId = signoffEntry[0].pdpId;

        // Fetch all signoffs for this pdpId
        const allSignoffs = await connection.query(
          `SELECT isSigned FROM pdp_signoff 
           WHERE pdpId = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [pdpId]
        );

        // Check if all signoffs have isSigned = 1 (true)
        const allSigned = allSignoffs.length > 0 && allSignoffs.every(signoff => signoff.isSigned === 1 || signoff.isSigned === true);

        if (allSigned) {
          // All signoffs are completed, update PDP status to "Completed" and set completed_date
          const completedDate = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
          await connection.query(
            `UPDATE pdp SET sign_of_status = ?, completed_date = ?, updated_at = ? WHERE id = ?`,
            ["Completed", completedDate, updatedOn, pdpId]
          );
        }
      }

      return res.status(200).send({
        status: true,
        message: "PDP Signoff signed successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Signoff (soft delete)
  deletePdpSignoff: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Signoff exists
      const exists = await connection.query(
        `SELECT id FROM pdp_signoff WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Signoff not found or already deleted" });
      }

      // Soft delete by setting isDeleted = 1
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(
        `UPDATE pdp_signoff SET isDeleted = 1, updated_at = ? WHERE id = ?`,
        [updatedOn, id]
      );

      return res.status(200).send({
        status: true,
        message: "PDP Signoff deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

