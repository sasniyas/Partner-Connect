const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Infrastructure Vehicle
  // Demo JSON Request Body:
  //   {
  //     "pdpId": 1,
  //     "pdpInfrastructureId": 1,
  //     "vehicle_type": "Commercial",
  //     "make": "Tata",
  //     "model": "Ace",
  //     "registration_number": "MH-12-AB-1234",
  //     "yop": 2020,
  //     "vehicle_age": 4,
  //     "operating_area": "Mumbai",
  //     "utilisation_rate": "Daily",
  //     "assigned_to": "John Doe"
  //   }
  addPdpInfrastructureVehicle: async function (req, res) {
    try {
      const {
        pdpId,
        pdpInfrastructureId,
        vehicle_type,
        make,
        model,
        registration_number,
        yop,
        vehicle_age,
        operating_area,
        utilisation_rate,
        assigned_to
      } = req.body;

      if (!pdpId || !pdpInfrastructureId || !vehicle_type || !make || !model || !registration_number || !yop || !vehicle_age) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, pdpInfrastructureId, vehicle_type, make, model, registration_number, yop, vehicle_age"
        });
      }

      // Validate vehicle_type enum
      const validVehicleTypes = ["Commercial", "Personal"];
      if (!validVehicleTypes.includes(vehicle_type)) {
        return res.status(400).send({
          status: false,
          message: "Vehicle type must be either 'Commercial' or 'Personal'"
        });
      }

      // Validate utilisation_rate enum if provided
      if (utilisation_rate) {
        const validUtilisationRates = ["Daily", "Monthly", "Weekly"];
        if (!validUtilisationRates.includes(utilisation_rate)) {
          return res.status(400).send({
            status: false,
            message: "Utilisation rate must be either 'Daily', 'Monthly', or 'Weekly'"
          });
        }
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if PDP Infrastructure exists
      const pdpInfrastructureExists = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ?`,
        [pdpInfrastructureId]
      );
      if (pdpInfrastructureExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      // Verify that pdpInfrastructureId belongs to the same pdpId
      const pdpInfrastructureBelongsToPdp = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ? AND pdpId = ? AND isDeleted = 0`,
        [pdpInfrastructureId, pdpId]
      );
      if (pdpInfrastructureBelongsToPdp.length === 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Infrastructure does not belong to the specified PDP"
        });
      }

      // Check for duplicate registration number
      const duplicateCheck = await connection.query(
        `SELECT id FROM pdp_infrastructure_vehicle 
         WHERE registration_number = ? 
         AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [registration_number]
      );
      if (duplicateCheck.length > 0) {
        return res.status(400).send({
          status: false,
          message: "Vehicle with this registration number already exists"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_infrastructure_vehicle (
          pdpId, pdpInfrastructureId, vehicle_type, make, model,
          registration_number, yop, vehicle_age, operating_area,
          utilisation_rate, assigned_to,
          created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      await connection.query(insertQuery, [
        pdpId,
        pdpInfrastructureId,
        vehicle_type,
        make,
        model,
        registration_number,
        yop,
        vehicle_age,
        operating_area || null,
        utilisation_rate || null,
        assigned_to || null,
        pdpCreatedOn,
        pdpCreatedOn,
        0
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Vehicle added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Infrastructure Vehicles
  getAllPdpInfrastructureVehicles: async function (req, res) {
    try {
      const query = `
        SELECT 
          piv.id,
          piv.pdpId,
          piv.pdpInfrastructureId,
          piv.vehicle_type,
          piv.make,
          piv.model,
          piv.registration_number,
          piv.yop,
          piv.vehicle_age,
          piv.operating_area,
          piv.utilisation_rate,
          piv.assigned_to,
          piv.created_at,
          piv.updated_at,
          piv.isActive,
          piv.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure_vehicle piv
        LEFT JOIN pdp p ON piv.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE piv.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
        ORDER BY piv.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Infrastructure Vehicle records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Vehicle list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Vehicle by ID
  getPdpInfrastructureVehicleById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          piv.id,
          piv.pdpId,
          piv.pdpInfrastructureId,
          piv.vehicle_type,
          piv.make,
          piv.model,
          piv.registration_number,
          piv.yop,
          piv.vehicle_age,
          piv.operating_area,
          piv.utilisation_rate,
          piv.assigned_to,
          piv.created_at,
          piv.updated_at,
          piv.isActive,
          piv.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure_vehicle piv
        LEFT JOIN pdp p ON piv.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE piv.id = ? AND piv.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Vehicle not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Vehicle retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Vehicles by PDP ID
  getPdpInfrastructureVehiclesByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          piv.id,
          piv.pdpId,
          piv.pdpInfrastructureId,
          piv.vehicle_type,
          piv.make,
          piv.model,
          piv.registration_number,
          piv.yop,
          piv.vehicle_age,
          piv.operating_area,
          piv.utilisation_rate,
          piv.assigned_to,
          piv.created_at,
          piv.updated_at,
          piv.isActive,
          piv.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition
        FROM pdp_infrastructure_vehicle piv
        LEFT JOIN pdp_infrastructure pi ON piv.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        WHERE piv.pdpId = ? AND piv.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0
        ORDER BY piv.pdpInfrastructureId, piv.registration_number
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Vehicles retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Vehicles by PDP Infrastructure ID
  getPdpInfrastructureVehiclesByPdpInfrastructureId: async function (req, res) {
    try {
      const { pdpInfrastructureId } = req.params;

      if (!pdpInfrastructureId) {
        return res.status(400).send({ status: false, message: "PDP Infrastructure ID is required" });
      }

      // Check if PDP Infrastructure exists
      const pdpInfrastructureExists = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ?`,
        [pdpInfrastructureId]
      );
      if (pdpInfrastructureExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      const query = `
        SELECT 
          piv.id,
          piv.pdpId,
          piv.pdpInfrastructureId,
          piv.vehicle_type,
          piv.make,
          piv.model,
          piv.registration_number,
          piv.yop,
          piv.vehicle_age,
          piv.operating_area,
          piv.utilisation_rate,
          piv.assigned_to,
          piv.created_at,
          piv.updated_at,
          piv.isActive,
          piv.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition
        FROM pdp_infrastructure_vehicle piv
        LEFT JOIN pdp_infrastructure pi ON piv.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        WHERE piv.pdpInfrastructureId = ? AND piv.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0
        ORDER BY piv.registration_number
      `;

      const data = await connection.query(query, [pdpInfrastructureId]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Vehicles retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Infrastructure Vehicle
  // Demo JSON Request Body (all fields are optional except id):
  // {
  //   "id": 1,
  //   "pdpId": 1,
  //   "pdpInfrastructureId": 1,
  //   "vehicle_type": "Personal",
  //   "make": "Maruti",
  //   "model": "Swift",
  //   "registration_number": "MH-12-CD-5678",
  //   "yop": 2022,
  //   "vehicle_age": 2,
  //   "operating_area": "Pune",
  //   "utilisation_rate": "Weekly",
  //   "assigned_to": "Jane Smith",
  //   "isActive": true
  // }
  updatePdpInfrastructureVehicle: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        pdpInfrastructureId,
        vehicle_type,
        make,
        model,
        registration_number,
        yop,
        vehicle_age,
        operating_area,
        utilisation_rate,
        assigned_to,
        isActive
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Infrastructure Vehicle exists
      const exists = await connection.query(
        `SELECT id FROM pdp_infrastructure_vehicle WHERE id = ?`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Vehicle not found" });
      }

      // Validate vehicle_type enum if provided
      if (vehicle_type) {
        const validVehicleTypes = ["Commercial", "Personal"];
        if (!validVehicleTypes.includes(vehicle_type)) {
          return res.status(400).send({
            status: false,
            message: "Vehicle type must be either 'Commercial' or 'Personal'"
          });
        }
      }

      // Validate utilisation_rate enum if provided
      if (utilisation_rate) {
        const validUtilisationRates = ["Daily", "Monthly", "Weekly"];
        if (!validUtilisationRates.includes(utilisation_rate)) {
          return res.status(400).send({
            status: false,
            message: "Utilisation rate must be either 'Daily', 'Monthly', or 'Weekly'"
          });
        }
      }

      // Validate foreign keys if being updated
      if (pdpId) {
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
        if (pdpExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP not found" });
        }
      }

      if (pdpInfrastructureId) {
        const pdpInfrastructureExists = await connection.query(
          `SELECT id FROM pdp_infrastructure WHERE id = ? AND isDeleted = 0`,
          [pdpInfrastructureId]
        );
        if (pdpInfrastructureExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
        }
      }

      // Verify relationship if both pdpId and pdpInfrastructureId are being updated
      if (pdpId && pdpInfrastructureId) {
        const pdpInfrastructureBelongsToPdp = await connection.query(
          `SELECT id FROM pdp_infrastructure WHERE id = ? AND pdpId = ? AND isDeleted = 0`,
          [pdpInfrastructureId, pdpId]
        );
        if (pdpInfrastructureBelongsToPdp.length === 0) {
          return res.status(400).send({
            status: false,
            message: "PDP Infrastructure does not belong to the specified PDP"
          });
        }
      }

      // Check for duplicate registration number if being changed
      if (registration_number) {
        const duplicateCheck = await connection.query(
          `SELECT id FROM pdp_infrastructure_vehicle 
           WHERE registration_number = ? AND id != ? 
           AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [registration_number, id]
        );
        if (duplicateCheck.length > 0) {
          return res.status(400).send({
            status: false,
            message: "Vehicle with this registration number already exists"
          });
        }
      }

      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }
      if (pdpInfrastructureId !== undefined) {
        updateFields.push("pdpInfrastructureId = ?");
        updateValues.push(pdpInfrastructureId);
      }
      if (vehicle_type !== undefined) {
        updateFields.push("vehicle_type = ?");
        updateValues.push(vehicle_type);
      }
      if (make !== undefined) {
        updateFields.push("make = ?");
        updateValues.push(make);
      }
      if (model !== undefined) {
        updateFields.push("model = ?");
        updateValues.push(model);
      }
      if (registration_number !== undefined) {
        updateFields.push("registration_number = ?");
        updateValues.push(registration_number);
      }
      if (yop !== undefined) {
        updateFields.push("yop = ?");
        updateValues.push(yop);
      }
      if (vehicle_age !== undefined) {
        updateFields.push("vehicle_age = ?");
        updateValues.push(vehicle_age);
      }
      if (operating_area !== undefined) {
        updateFields.push("operating_area = ?");
        updateValues.push(operating_area);
      }
      if (utilisation_rate !== undefined) {
        updateFields.push("utilisation_rate = ?");
        updateValues.push(utilisation_rate);
      }
      if (assigned_to !== undefined) {
        updateFields.push("assigned_to = ?");
        updateValues.push(assigned_to);
      }
      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_infrastructure_vehicle
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Vehicle updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Infrastructure Vehicle
  deletePdpInfrastructureVehicle: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Infrastructure Vehicle exists
      const exists = await connection.query(
        `SELECT id FROM pdp_infrastructure_vehicle WHERE id = ? AND isDeleted = 0`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Vehicle not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_infrastructure_vehicle SET isDeleted = 1, updated_at = ? WHERE id = ?`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Vehicle deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

