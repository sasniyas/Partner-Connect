const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Infrastructure Location Count
  addPdpInfrastructureLocationCount: async function (req, res) {
    try {
      const {
        pdpId,
        pdpInfrastructureId,
        location,
        count
      } = req.body;

      if (!pdpId || !pdpInfrastructureId) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, pdpInfrastructureId"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if PDP Infrastructure exists
      const pdpInfrastructureExists = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ? AND isDeleted = 0`,
        [pdpInfrastructureId]
      );
      if (pdpInfrastructureExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      // Verify that pdpInfrastructureId belongs to the same pdpId
      const pdpInfrastructureBelongsToPdp = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ? AND pdpId = ? AND isDeleted = 0`,
        [pdpInfrastructureId, pdpId]
      );
      if (pdpInfrastructureBelongsToPdp.length === 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Infrastructure does not belong to the specified PDP"
        });
      }

      // Check for duplicate (same pdpId, pdpInfrastructureId, and location)
      if (location) {
        const duplicateCheck = await connection.query(
          `SELECT id FROM pdp_infrastructure_locationCount 
           WHERE pdpId = ? AND pdpInfrastructureId = ? AND location = ? 
           AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [pdpId, pdpInfrastructureId, location]
        );
        if (duplicateCheck.length > 0) {
          return res.status(400).send({
            status: false,
            message: "Location count entry already exists for this PDP, Infrastructure, and Location combination"
          });
        }
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_infrastructure_locationCount (
          pdpId, pdpInfrastructureId, location, count,
          created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `;

      await connection.query(insertQuery, [
        pdpId,
        pdpInfrastructureId,
        location || null,
        count || 0,
        pdpCreatedOn,
        pdpCreatedOn,
        0
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Location Count added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Infrastructure Location Counts
  getAllPdpInfrastructureLocationCounts: async function (req, res) {
    try {
      const query = `
        SELECT 
          pilc.id,
          pilc.pdpId,
          pilc.pdpInfrastructureId,
          pilc.location,
          pilc.count,
          pilc.created_at,
          pilc.updated_at,
          pilc.isActive,
          pilc.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure_locationCount pilc
        LEFT JOIN pdp p ON pilc.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pilc.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
        ORDER BY pilc.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Infrastructure Location Count records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Location Count list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Location Count by ID
  getPdpInfrastructureLocationCountById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          pilc.id,
          pilc.pdpId,
          pilc.pdpInfrastructureId,
          pilc.location,
          pilc.count,
          pilc.created_at,
          pilc.updated_at,
          pilc.isActive,
          pilc.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure_locationCount pilc
        LEFT JOIN pdp p ON pilc.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pilc.id = ? AND pilc.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Location Count not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Location Count retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Location Counts by PDP ID
  getPdpInfrastructureLocationCountsByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          pilc.id,
          pilc.pdpId,
          pilc.pdpInfrastructureId,
          pilc.location,
          pilc.count,
          pilc.created_at,
          pilc.updated_at,
          pilc.isActive,
          pilc.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition
        FROM pdp_infrastructure_locationCount pilc
        LEFT JOIN pdp_infrastructure pi ON pilc.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        WHERE pilc.pdpId = ? AND pilc.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0
        ORDER BY pilc.pdpInfrastructureId, pilc.location
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Location Counts retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Location Counts by PDP Infrastructure ID
  getPdpInfrastructureLocationCountsByPdpInfrastructureId: async function (req, res) {
    try {
      const { pdpInfrastructureId } = req.params;

      if (!pdpInfrastructureId) {
        return res.status(400).send({ status: false, message: "PDP Infrastructure ID is required" });
      }

      // Check if PDP Infrastructure exists
      const pdpInfrastructureExists = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ? AND isDeleted = 0`,
        [pdpInfrastructureId]
      );
      if (pdpInfrastructureExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      const query = `
        SELECT 
          pilc.id,
          pilc.pdpId,
          pilc.pdpInfrastructureId,
          pilc.location,
          pilc.count,
          pilc.created_at,
          pilc.updated_at,
          pilc.isActive,
          pilc.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition
        FROM pdp_infrastructure_locationCount pilc
        LEFT JOIN pdp_infrastructure pi ON pilc.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        WHERE pilc.pdpInfrastructureId = ? AND pilc.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0
        ORDER BY pilc.location
      `;

      const data = await connection.query(query, [pdpInfrastructureId]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Location Counts retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Infrastructure Location Count
  updatePdpInfrastructureLocationCount: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        pdpInfrastructureId,
        location,
        count,
        isActive
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Infrastructure Location Count exists
      const exists = await connection.query(
        `SELECT id FROM pdp_infrastructure_locationCount WHERE id = ?`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Location Count not found" });
      }

      // Validate foreign keys if being updated
      if (pdpId) {
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
        if (pdpExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP not found" });
        }
      }

      if (pdpInfrastructureId) {
        const pdpInfrastructureExists = await connection.query(
          `SELECT id FROM pdp_infrastructure WHERE id = ? AND isDeleted = 0`,
          [pdpInfrastructureId]
        );
        if (pdpInfrastructureExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
        }
      }

      // Verify relationship if both pdpId and pdpInfrastructureId are being updated
      if (pdpId && pdpInfrastructureId) {
        const pdpInfrastructureBelongsToPdp = await connection.query(
          `SELECT id FROM pdp_infrastructure WHERE id = ? AND pdpId = ? AND isDeleted = 0`,
          [pdpInfrastructureId, pdpId]
        );
        if (pdpInfrastructureBelongsToPdp.length === 0) {
          return res.status(400).send({
            status: false,
            message: "PDP Infrastructure does not belong to the specified PDP"
          });
        }
      }

      // Check for duplicate if pdpId, pdpInfrastructureId, or location is being changed
      if (pdpId || pdpInfrastructureId || location) {
        const currentData = await connection.query(
          `SELECT pdpId, pdpInfrastructureId, location FROM pdp_infrastructure_locationCount WHERE id = ? AND isDeleted = 0`,
          [id]
        );
        const finalPdpId = pdpId || currentData[0].pdpId;
        const finalPdpInfrastructureId = pdpInfrastructureId || currentData[0].pdpInfrastructureId;
        const finalLocation = location !== undefined ? location : currentData[0].location;

        if (finalLocation) {
          const duplicateCheck = await connection.query(
            `SELECT id FROM pdp_infrastructure_locationCount 
             WHERE pdpId = ? AND pdpInfrastructureId = ? AND location = ? AND id != ? 
             AND (isDeleted = 0 OR isDeleted IS NULL)`,
            [finalPdpId, finalPdpInfrastructureId, finalLocation, id]
          );
          if (duplicateCheck.length > 0) {
            return res.status(400).send({
              status: false,
              message: "Location count entry already exists for this PDP, Infrastructure, and Location combination"
            });
          }
        }
      }

      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }
      if (pdpInfrastructureId !== undefined) {
        updateFields.push("pdpInfrastructureId = ?");
        updateValues.push(pdpInfrastructureId);
      }
      if (location !== undefined) {
        updateFields.push("location = ?");
        updateValues.push(location);
      }
      if (count !== undefined) {
        updateFields.push("count = ?");
        updateValues.push(count);
      }
      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_infrastructure_locationCount
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Location Count updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Infrastructure Location Count
  deletePdpInfrastructureLocationCount: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Infrastructure Location Count exists
      const exists = await connection.query(
        `SELECT id FROM pdp_infrastructure_locationCount WHERE id = ? AND isDeleted = 0`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Location Count not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_infrastructure_locationCount SET isDeleted = 1, updated_at = ? WHERE id = ?`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Location Count deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

