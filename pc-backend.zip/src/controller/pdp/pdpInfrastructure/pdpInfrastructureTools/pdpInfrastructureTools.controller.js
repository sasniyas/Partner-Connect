const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Infrastructure Tool
  // Demo JSON Request Body:
  // {
  //   "pdpId": 1,
  //   "pdpInfrastructureId": 1,
  //   "tool_type": "Hand Tool",
  //   "tool_name": "Hammer",
  //   "quantity": 5,
  //   "yop": 2020,
  //   "available": "Yes"
  // }
  addPdpInfrastructureTool: async function (req, res) {
    try {
      const {
        pdpId,
        pdpInfrastructureId,
        tool_type,
        tool_name,
        quantity,
        yop,
        available
      } = req.body;

      if (!pdpId || !pdpInfrastructureId || !tool_type || !tool_name || !quantity || !available) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, pdpInfrastructureId, tool_type, tool_name, quantity, available"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if PDP Infrastructure exists
      const pdpInfrastructureExists = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ?`,
        [pdpInfrastructureId]
      );
      if (pdpInfrastructureExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      // Verify that pdpInfrastructureId belongs to the same pdpId
      const pdpInfrastructureBelongsToPdp = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ? AND pdpId = ? AND isDeleted = 0`,
        [pdpInfrastructureId, pdpId]
      );
      if (pdpInfrastructureBelongsToPdp.length === 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Infrastructure does not belong to the specified PDP"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_infrastructure_tools (
          pdpId, pdpInfrastructureId, tool_type, tool_name, quantity, yop, available,
          created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      await connection.query(insertQuery, [
        pdpId,
        pdpInfrastructureId,
        tool_type,
        tool_name,
        quantity,
        yop || null,
        available,
        pdpCreatedOn,
        pdpCreatedOn,
        0
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Tool added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Infrastructure Tools
  getAllPdpInfrastructureTools: async function (req, res) {
    try {
      const query = `
        SELECT 
          pit.id,
          pit.pdpId,
          pit.pdpInfrastructureId,
          pit.tool_type,
          pit.tool_name,
          pit.quantity,
          pit.yop,
          pit.available,
          pit.created_at,
          pit.updated_at,
          pit.isActive,
          pit.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure_tools pit
        LEFT JOIN pdp p ON pit.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pit.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
        ORDER BY pit.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Infrastructure Tool records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Tool list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Tool by ID
  getPdpInfrastructureToolById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          pit.id,
          pit.pdpId,
          pit.pdpInfrastructureId,
          pit.tool_type,
          pit.tool_name,
          pit.quantity,
          pit.yop,
          pit.available,
          pit.created_at,
          pit.updated_at,
          pit.isActive,
          pit.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure_tools pit
        LEFT JOIN pdp p ON pit.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pit.id = ? AND pit.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Tool not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Tool retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Tools by PDP ID
  getPdpInfrastructureToolsByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          pit.id,
          pit.pdpId,
          pit.pdpInfrastructureId,
          pit.tool_type,
          pit.tool_name,
          pit.quantity,
          pit.yop,
          pit.available,
          pit.created_at,
          pit.updated_at,
          pit.isActive,
          pit.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition
        FROM pdp_infrastructure_tools pit
        LEFT JOIN pdp_infrastructure pi ON pit.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        WHERE pit.pdpId = ? AND pit.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0
        ORDER BY pit.pdpInfrastructureId, pit.tool_name
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Tools retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Tools by PDP Infrastructure ID
  getPdpInfrastructureToolsByPdpInfrastructureId: async function (req, res) {
    try {
      const { pdpInfrastructureId } = req.params;

      if (!pdpInfrastructureId) {
        return res.status(400).send({ status: false, message: "PDP Infrastructure ID is required" });
      }

      // Check if PDP Infrastructure exists
      const pdpInfrastructureExists = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ?`,
        [pdpInfrastructureId]
      );
      if (pdpInfrastructureExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      const query = `
        SELECT 
          pit.id,
          pit.pdpId,
          pit.pdpInfrastructureId,
          pit.tool_type,
          pit.tool_name,
          pit.quantity,
          pit.yop,
          pit.available,
          pit.created_at,
          pit.updated_at,
          pit.isActive,
          pit.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition
        FROM pdp_infrastructure_tools pit
        LEFT JOIN pdp_infrastructure pi ON pit.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        WHERE pit.pdpInfrastructureId = ? AND pit.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0
        ORDER BY pit.tool_name
      `;

      const data = await connection.query(query, [pdpInfrastructureId]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Tools retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Infrastructure Tool
  // Demo JSON Request Body (all fields are optional except id):
  // {
  //   "id": 1,
  //   "pdpId": 1,
  //   "pdpInfrastructureId": 1,
  //   "tool_type": "Power Tool",
  //   "tool_name": "Drill",
  //   "quantity": 3,
  //   "yop": 2021,
  //   "available": "No",
  //   "isActive": true
  // }
  updatePdpInfrastructureTool: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        pdpInfrastructureId,
        tool_type,
        tool_name,
        quantity,
        yop,
        available,
        isActive
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Infrastructure Tool exists
      const exists = await connection.query(
        `SELECT id FROM pdp_infrastructure_tools WHERE id = ? AND isDeleted = 0`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Tool not found" });
      }

      // Validate foreign keys if being updated
      if (pdpId) {
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
        if (pdpExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP not found" });
        }
      }

      if (pdpInfrastructureId) {
        const pdpInfrastructureExists = await connection.query(
          `SELECT id FROM pdp_infrastructure WHERE id = ? AND isDeleted = 0`,
          [pdpInfrastructureId]
        );
        if (pdpInfrastructureExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
        }
      }

      // Verify relationship if both pdpId and pdpInfrastructureId are being updated
      if (pdpId && pdpInfrastructureId) {
        const pdpInfrastructureBelongsToPdp = await connection.query(
          `SELECT id FROM pdp_infrastructure WHERE id = ? AND pdpId = ? AND isDeleted = 0`,
          [pdpInfrastructureId, pdpId]
        );
        if (pdpInfrastructureBelongsToPdp.length === 0) {
          return res.status(400).send({
            status: false,
            message: "PDP Infrastructure does not belong to the specified PDP"
          });
        }
      }

      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }
      if (pdpInfrastructureId !== undefined) {
        updateFields.push("pdpInfrastructureId = ?");
        updateValues.push(pdpInfrastructureId);
      }
      if (tool_type !== undefined) {
        updateFields.push("tool_type = ?");
        updateValues.push(tool_type);
      }
      if (tool_name !== undefined) {
        updateFields.push("tool_name = ?");
        updateValues.push(tool_name);
      }
      if (quantity !== undefined) {
        updateFields.push("quantity = ?");
        updateValues.push(quantity);
      }
      if (yop !== undefined) {
        updateFields.push("yop = ?");
        updateValues.push(yop);
      }
      if (available !== undefined) {
        updateFields.push("available = ?");
        updateValues.push(available);
      }
      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_infrastructure_tools
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Tool updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Infrastructure Tool
  deletePdpInfrastructureTool: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Infrastructure Tool exists
      const exists = await connection.query(
        `SELECT id FROM pdp_infrastructure_tools WHERE id = ? AND isDeleted = 0`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Tool not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_infrastructure_tools SET isDeleted = 1, updated_at = ? WHERE id = ?`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Tool deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

