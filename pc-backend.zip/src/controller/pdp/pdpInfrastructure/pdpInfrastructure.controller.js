const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Infrastructure
  addPdpInfrastructure: async function (req, res) {
    try {
      const {
        pdpId,
        infrastructureId,
        py_infrastructure_id,
        py_achievement_eoy,
        py_achievement,
        target
      } = req.body;

      if (!pdpId || !infrastructureId) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, infrastructureId"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if infrastructure exists
      const infrastructureExists = await connection.query(
        `SELECT id FROM infrastructure WHERE id = ? AND (isActive = 1 OR isActive IS NULL) AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [infrastructureId]
      );
      if (infrastructureExists.length === 0) {
        return res.status(404).send({ status: false, message: "Infrastructure not found or inactive" });
      }

      // Check for duplicate (same pdpId and infrastructureId)
      const duplicateCheck = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE pdpId = ? AND infrastructureId = ? AND isDeleted = 0`,
        [pdpId, infrastructureId]
      );
      if (duplicateCheck.length > 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Infrastructure entry already exists for this PDP and Infrastructure combination"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_infrastructure (
          pdpId, infrastructureId,
          py_achievement_eoy, py_achievement, target, py_infrastructure_id,
          created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      await connection.query(insertQuery, [
        pdpId,
        infrastructureId,
        py_achievement_eoy || 0,
        py_achievement || 0.00,
        target || 0,
        py_infrastructure_id || null,
        pdpCreatedOn,
        pdpCreatedOn,
        0
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Infrastructures
  getAllPdpInfrastructures: async function (req, res) {
    try {
      const query = `
        SELECT 
          pi.id,
          pi.pdpId,
          pi.infrastructureId,
          pi.py_infrastructure_id,
          py_pi.target as py_target,
          pi.py_achievement_eoy,
          pi.py_achievement,
          pi.target,
          pi.created_at,
          pi.updated_at,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure pi
        LEFT JOIN pdp_infrastructure py_pi ON pi.py_infrastructure_id = py_pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        LEFT JOIN pdp p ON pi.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
        ORDER BY pi.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Infrastructure records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure by ID
  getPdpInfrastructureById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          pi.id,
          pi.pdpId,
          pi.infrastructureId,
          pi.py_infrastructure_id,
          py_pi.target as py_target,
          pi.py_achievement_eoy,
          pi.py_achievement,
          pi.target,
          pi.created_at,
          pi.updated_at,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure pi
        LEFT JOIN pdp_infrastructure py_pi ON pi.py_infrastructure_id = py_pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        LEFT JOIN pdp p ON pi.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pi.id = ? AND pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructures by PDP ID
  getPdpInfrastructuresByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          pi.id,
          pi.pdpId,
          pi.infrastructureId,
          pi.py_infrastructure_id,
          py_pi.target as py_target,
          pi.py_achievement_eoy,
          pi.py_achievement,
          pi.target,
          pi.created_at,
          pi.updated_at,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure pi
        LEFT JOIN pdp_infrastructure py_pi ON pi.py_infrastructure_id = py_pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        LEFT JOIN pdp p ON pi.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pi.pdpId = ? AND pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
        ORDER BY pi.infrastructureId
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructures retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Infrastructure
  updatePdpInfrastructure: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        infrastructureId,
        py_infrastructure_id,
        py_achievement_eoy,
        py_achievement,
        target
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Infrastructure exists
      const exists = await connection.query(`SELECT id FROM pdp_infrastructure WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      // Check for duplicate if pdpId or infrastructureId is being changed
      if (pdpId || infrastructureId) {
        const currentData = await connection.query(
          `SELECT pdpId, infrastructureId FROM pdp_infrastructure WHERE id = ? AND isDeleted = 0`,
          [id]
        );
        const finalPdpId = pdpId || currentData[0].pdpId;
        const finalInfrastructureId = infrastructureId || currentData[0].infrastructureId;

        const duplicateCheck = await connection.query(
          `SELECT id FROM pdp_infrastructure WHERE pdpId = ? AND infrastructureId = ? AND id != ? AND isDeleted = 0`,
          [finalPdpId, finalInfrastructureId, id]
        );
        if (duplicateCheck.length > 0) {
          return res.status(400).send({
            status: false,
            message: "PDP Infrastructure entry already exists for this PDP and Infrastructure combination"
          });
        }
      }

      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }
      if (infrastructureId !== undefined) {
        updateFields.push("infrastructureId = ?");
        updateValues.push(infrastructureId);
      }
      if (py_achievement_eoy !== undefined) {
        updateFields.push("py_achievement_eoy = ?");
        updateValues.push(py_achievement_eoy);
      }
      if (py_achievement !== undefined) {
        updateFields.push("py_achievement = ?");
        updateValues.push(py_achievement);
      }
      if (target !== undefined) {
        updateFields.push("target = ?");
        updateValues.push(target);
      }
      if (py_infrastructure_id !== undefined) {
        updateFields.push("py_infrastructure_id = ?");
        updateValues.push(py_infrastructure_id);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_infrastructure
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Infrastructure
  deletePdpInfrastructure: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Infrastructure exists
      const exists = await connection.query(`SELECT id FROM pdp_infrastructure WHERE id = ? AND isDeleted = 0`, [id]);
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_infrastructure SET isDeleted = 1, updated_at = ? WHERE id = ?`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

