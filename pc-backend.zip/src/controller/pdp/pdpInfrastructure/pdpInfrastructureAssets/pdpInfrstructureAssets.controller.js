const { connection } = require("../../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add PDP Infrastructure Asset
  // Demo JSON Request Body:
  // {
  //   "pdpId": 1,
  //   "pdpInfrastructureId": 1,
  //   "asset_type": "Computer",
  //   "quantity": 10,
  //   "yop": 2021,
  //   "available": "Yes",
  //   "assigned_to": "John Doe"
  // }
  addPdpInfrastructureAsset: async function (req, res) {
    try {
      const {
        pdpId,
        pdpInfrastructureId,
        asset_type,
        quantity,
        yop,
        available,
        assigned_to
      } = req.body;

      if (!pdpId || !pdpInfrastructureId || !asset_type || !quantity || !available) {
        return res.status(400).send({
          status: false,
          message: "Required: pdpId, pdpInfrastructureId, asset_type, quantity, available"
        });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      // Check if PDP Infrastructure exists
      const pdpInfrastructureExists = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ?`,
        [pdpInfrastructureId]
      );
      if (pdpInfrastructureExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      // Verify that pdpInfrastructureId belongs to the same pdpId
      const pdpInfrastructureBelongsToPdp = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ? AND pdpId = ? AND isDeleted = 0`,
        [pdpInfrastructureId, pdpId]
      );
      if (pdpInfrastructureBelongsToPdp.length === 0) {
        return res.status(400).send({
          status: false,
          message: "PDP Infrastructure does not belong to the specified PDP"
        });
      }

      const pdpCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO pdp_infrastructure_asset (
          pdpId, pdpInfrastructureId, asset_type, quantity, yop, available, assigned_to,
          created_at, updated_at, isDeleted
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      await connection.query(insertQuery, [
        pdpId,
        pdpInfrastructureId,
        asset_type,
        quantity,
        yop || null,
        available,
        assigned_to || null,
        pdpCreatedOn,
        pdpCreatedOn,
        0
      ]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Asset added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📋 Get All PDP Infrastructure Assets
  getAllPdpInfrastructureAssets: async function (req, res) {
    try {
      const query = `
        SELECT 
          pia.id,
          pia.pdpId,
          pia.pdpInfrastructureId,
          pia.asset_type,
          pia.quantity,
          pia.yop,
          pia.available,
          pia.assigned_to,
          pia.created_at,
          pia.updated_at,
          pia.isActive,
          pia.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure_asset pia
        LEFT JOIN pdp p ON pia.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pia.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
        ORDER BY pia.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No PDP Infrastructure Asset records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Asset list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Asset by ID
  getPdpInfrastructureAssetById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          pia.id,
          pia.pdpId,
          pia.pdpInfrastructureId,
          pia.asset_type,
          pia.quantity,
          pia.yop,
          pia.available,
          pia.assigned_to,
          pia.created_at,
          pia.updated_at,
          pia.isActive,
          pia.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition,
          p.year as pdp_year,
          p.market_area,
          p.dealer,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name
        FROM pdp_infrastructure_asset pia
        LEFT JOIN pdp p ON pia.pdpId = p.id
        LEFT JOIN market_area ma ON p.market_area = ma.id
        LEFT JOIN dealer_master d ON p.dealer = d.id
        WHERE pia.id = ? AND pia.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0 AND p.isDeleted = 0 AND (ma.isDeleted = 0 OR ma.isDeleted IS NULL) AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Asset not found" });
      }

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Asset retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Assets by PDP ID
  getPdpInfrastructureAssetsByPdpId: async function (req, res) {
    try {
      const { pdpId } = req.params;

      if (!pdpId) {
        return res.status(400).send({ status: false, message: "PDP ID is required" });
      }

      // Check if PDP exists
      const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
      if (pdpExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP not found" });
      }

      const query = `
        SELECT 
          pia.id,
          pia.pdpId,
          pia.pdpInfrastructureId,
          pia.asset_type,
          pia.quantity,
          pia.yop,
          pia.available,
          pia.assigned_to,
          pia.created_at,
          pia.updated_at,
          pia.isActive,
          pia.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition
        FROM pdp_infrastructure_asset pia
        LEFT JOIN pdp_infrastructure pi ON pia.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        WHERE pia.pdpId = ? AND pia.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0
        ORDER BY pia.pdpInfrastructureId, pia.asset_type
      `;

      const data = await connection.query(query, [pdpId]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Assets retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔍 Get PDP Infrastructure Assets by PDP Infrastructure ID
  getPdpInfrastructureAssetsByPdpInfrastructureId: async function (req, res) {
    try {
      const { pdpInfrastructureId } = req.params;

      if (!pdpInfrastructureId) {
        return res.status(400).send({ status: false, message: "PDP Infrastructure ID is required" });
      }

      // Check if PDP Infrastructure exists
      const pdpInfrastructureExists = await connection.query(
        `SELECT id FROM pdp_infrastructure WHERE id = ?`,
        [pdpInfrastructureId]
      );
      if (pdpInfrastructureExists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
      }

      const query = `
        SELECT 
          pia.id,
          pia.pdpId,
          pia.pdpInfrastructureId,
          pia.asset_type,
          pia.quantity,
          pia.yop,
          pia.available,
          pia.assigned_to,
          pia.created_at,
          pia.updated_at,
          pia.isActive,
          pia.isDeleted,
          pi.target as infrastructure_target,
          inf.year as infrastructure_year,
          inf.facility_type,
          inf.facility_definition
        FROM pdp_infrastructure_asset pia
        LEFT JOIN pdp_infrastructure pi ON pia.pdpInfrastructureId = pi.id
        LEFT JOIN infrastructure inf ON pi.infrastructureId = inf.id
        WHERE pia.pdpInfrastructureId = ? AND pia.isDeleted = 0 AND pi.isDeleted = 0 AND inf.isDeleted = 0
        ORDER BY pia.asset_type
      `;

      const data = await connection.query(query, [pdpInfrastructureId]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Assets retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ✏️ Update PDP Infrastructure Asset
  // Demo JSON Request Body (all fields are optional except id):
  // {
  //   "id": 1,
  //   "pdpId": 1,
  //   "pdpInfrastructureId": 1,
  //   "asset_type": "Printer",
  //   "quantity": 5,
  //   "yop": 2022,
  //   "available": "No",
  //   "assigned_to": "Jane Smith",
  //   "isActive": true
  // }
  updatePdpInfrastructureAsset: async function (req, res) {
    try {
      const {
        id,
        pdpId,
        pdpInfrastructureId,
        asset_type,
        quantity,
        yop,
        available,
        assigned_to,
        isActive
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Infrastructure Asset exists
      const exists = await connection.query(
        `SELECT id FROM pdp_infrastructure_asset WHERE id = ? AND isDeleted = 0`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Asset not found" });
      }

      // Validate foreign keys if being updated
      if (pdpId) {
        const pdpExists = await connection.query(`SELECT id FROM pdp WHERE id = ? AND isDeleted = 0`, [pdpId]);
        if (pdpExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP not found" });
        }
      }

      if (pdpInfrastructureId) {
        const pdpInfrastructureExists = await connection.query(
          `SELECT id FROM pdp_infrastructure WHERE id = ? AND isDeleted = 0`,
          [pdpInfrastructureId]
        );
        if (pdpInfrastructureExists.length === 0) {
          return res.status(404).send({ status: false, message: "PDP Infrastructure not found" });
        }
      }

      // Verify relationship if both pdpId and pdpInfrastructureId are being updated
      if (pdpId && pdpInfrastructureId) {
        const pdpInfrastructureBelongsToPdp = await connection.query(
          `SELECT id FROM pdp_infrastructure WHERE id = ? AND pdpId = ? AND isDeleted = 0`,
          [pdpInfrastructureId, pdpId]
        );
        if (pdpInfrastructureBelongsToPdp.length === 0) {
          return res.status(400).send({
            status: false,
            message: "PDP Infrastructure does not belong to the specified PDP"
          });
        }
      }

      // Build update query dynamically
      const updateFields = [];
      const updateValues = [];

      if (pdpId !== undefined) {
        updateFields.push("pdpId = ?");
        updateValues.push(pdpId);
      }
      if (pdpInfrastructureId !== undefined) {
        updateFields.push("pdpInfrastructureId = ?");
        updateValues.push(pdpInfrastructureId);
      }
      if (asset_type !== undefined) {
        updateFields.push("asset_type = ?");
        updateValues.push(asset_type);
      }
      if (quantity !== undefined) {
        updateFields.push("quantity = ?");
        updateValues.push(quantity);
      }
      if (yop !== undefined) {
        updateFields.push("yop = ?");
        updateValues.push(yop);
      }
      if (available !== undefined) {
        updateFields.push("available = ?");
        updateValues.push(available);
      }
      if (assigned_to !== undefined) {
        updateFields.push("assigned_to = ?");
        updateValues.push(assigned_to);
      }
      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE pdp_infrastructure_asset
        SET ${updateFields.join(", ")}
        WHERE id = ? AND isDeleted = 0
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Asset updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete PDP Infrastructure Asset
  deletePdpInfrastructureAsset: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if PDP Infrastructure Asset exists
      const exists = await connection.query(
        `SELECT id FROM pdp_infrastructure_asset WHERE id = ? AND isDeleted = 0`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "PDP Infrastructure Asset not found" });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE pdp_infrastructure_asset SET isDeleted = 1, updated_at = ? WHERE id = ?`, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "PDP Infrastructure Asset deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

