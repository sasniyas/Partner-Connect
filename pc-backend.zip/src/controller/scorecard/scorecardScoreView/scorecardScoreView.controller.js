const { connection } = require("../../../mySql/mySql");
const { uploadFile } = require("../../azurestorage/fileUpload");
const moment = require("moment-timezone");
const { scorecardActionItemMail } = require('../../other/eMailer');

module.exports = {
  getAllScorecardScoreViews: async function (req, res) {
    try {
      const query = `
        SELECT 
          ssv.id,
          ssv.sub_kpi_id,
          ssv.scorecard_id,
          ssv.reviewer_score,
          ssv.reviewer,
          ssv.isScored,
          ssv.isExcluded,
          ssv.remarks,
          ssv.supporting_doc,
          ssv.uploaded_by,
          ssv.uploaded_on,
          ssv.final_score,
          ssv.created_at,
          ssv.updated_at,
          ssv.isActive,
          ssv.isDeleted,
          CONCAT(ub.firstName, ' ', ub.lastName) as uploaded_by_name,
          ub.email as uploaded_by_email,
          sk.createdYear as sub_kpi_createdYear,
          sk.objectiveId as sub_kpi_objectiveId,
          sk.kpiId as sub_kpi_kpiId,
          sk.kpiNumber as sub_kpi_kpiNumber,
          sk.subKpiName as sub_kpi_subKpiName,
          sk.assessmentPeriod as sub_kpi_assessmentPeriod,
          ssv.minScore,
          ssv.maxScore,
          ssv.formula,
          sk.scoringCriteria as sub_kpi_scoringCriteria,
          sk.measurement as sub_kpi_measurement,
          sk.annualScore as sub_kpi_annualScore,
          sk.annualScoringCriteria as sub_kpi_annualScoringCriteria,
          sk.docStaus as sub_kpi_docStaus,
          sk.doc as sub_kpi_doc,
          sk.criteriaDefinition as sub_kpi_criteriaDefinition,
          sk.dataSource as sub_kpi_dataSource,
          sk.createdOn as sub_kpi_createdOn,
          sk.isActive as sub_kpi_isActive,
          sk.updatedOn as sub_kpi_updatedOn,
          so.objectiveName as sub_kpi_objectiveName,
          k.kpiName as sub_kpi_kpiName,
          CONCAT(r.firstName, ' ', r.lastName) as reviewer_name,
          r.email as reviewer_email,
          sc.year as scorecard_year,
          sc.frequency as scorecard_frequency,
          sc.quarter_frequency as scorecard_quarter_frequency,
          sc.audit_location as scorecard_audit_location,
          sc.branch as scorecard_branch,
          sc.dealer_id,
          d.dealerName as dealer_name

        FROM scorecard_scoreview ssv
        LEFT JOIN sub_kpi_master sk ON ssv.sub_kpi_id = sk.id
        LEFT JOIN strategic_objective_master so ON sk.objectiveId = so.id
        LEFT JOIN kpi_master k ON sk.kpiId = k.id
        LEFT JOIN userdetails r ON ssv.reviewer = r.id
        LEFT JOIN userdetails ub ON ssv.uploaded_by = ub.id
        LEFT JOIN scorecard sc ON ssv.scorecard_id = sc.id
        LEFT JOIN dealer_master d ON sc.dealer_id = d.id
        WHERE ssv.isDeleted = 0 OR ssv.isDeleted IS NULL
        ORDER BY ssv.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No scorecard score view records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard score view list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getScorecardScoreViewById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          ssv.id,
          ssv.sub_kpi_id,
          ssv.scorecard_id,
          ssv.reviewer_score,
          ssv.reviewer,
          ssv.isScored,
          ssv.isExcluded,
          ssv.remarks,
          ssv.supporting_doc,
          ssv.uploaded_by,
          ssv.uploaded_on,
          ssv.final_score,
          ssv.created_at,
          ssv.updated_at,
          ssv.isActive,
          ssv.isDeleted,
          CONCAT(ub.firstName, ' ', ub.lastName) as uploaded_by_name,
          ub.email as uploaded_by_email,
          sk.createdYear as sub_kpi_createdYear,
          sk.objectiveId as sub_kpi_objectiveId,
          sk.kpiId as sub_kpi_kpiId,
          sk.kpiNumber as sub_kpi_kpiNumber,
          sk.subKpiName as sub_kpi_subKpiName,
          sk.assessmentPeriod as sub_kpi_assessmentPeriod,
          ssv.minScore,
          ssv.maxScore,
          ssv.formula,
          sk.scoringCriteria as sub_kpi_scoringCriteria,
          sk.measurement as sub_kpi_measurement,
          sk.annualScore as sub_kpi_annualScore,
          sk.annualScoringCriteria as sub_kpi_annualScoringCriteria,
          sk.docStaus as sub_kpi_docStaus,
          sk.doc as sub_kpi_doc,
          sk.criteriaDefinition as sub_kpi_criteriaDefinition,
          sk.dataSource as sub_kpi_dataSource,
          sk.createdOn as sub_kpi_createdOn,
          sk.isActive as sub_kpi_isActive,
          sk.updatedOn as sub_kpi_updatedOn,
          so.objectiveName as sub_kpi_objectiveName,
          k.kpiName as sub_kpi_kpiName,
          CONCAT(r.firstName, ' ', r.lastName) as reviewer_name,
          r.email as reviewer_email,
          sc.year as scorecard_year,
          sc.frequency as scorecard_frequency,
          sc.quarter_frequency as scorecard_quarter_frequency,
          sc.audit_location as scorecard_audit_location,
          sc.branch as scorecard_branch
        FROM scorecard_scoreview ssv
        LEFT JOIN sub_kpi_master sk ON ssv.sub_kpi_id = sk.id
        LEFT JOIN strategic_objective_master so ON sk.objectiveId = so.id
        LEFT JOIN kpi_master k ON sk.kpiId = k.id
        LEFT JOIN userdetails r ON ssv.reviewer = r.id
        LEFT JOIN userdetails ub ON ssv.uploaded_by = ub.id
        LEFT JOIN scorecard sc ON ssv.scorecard_id = sc.id
        WHERE ssv.id = ? AND (ssv.isDeleted = 0 OR ssv.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard score view not found" });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard score view retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getScorecardScoreViewsByScorecardId: async function (req, res) {
    try {
      const { scorecard_id } = req.params;

      if (!scorecard_id) {
        return res.status(400).send({ status: false, message: "Scorecard ID is required" });
      }

      // Extract userId from decoded token
      const userId = req.decodedToken;

      if (!userId) {
        return res.status(401).send({ status: false, message: "User not authenticated" });
      }

      // Fetch user persona and personaId (roleId) from userdetails table
      const userQuery = `
        SELECT persona, personaId 
        FROM userdetails 
        WHERE id = ?
      `;
      const userResult = await connection.query(userQuery, [userId]);

      if (userResult.length === 0) {
        return res.status(404).send({ status: false, message: "User not found" });
      }

      const userPersona = userResult[0].persona;
      const userRoleId = userResult[0].personaId;

      // Debug logging
      console.log(`[getScorecardScoreViewsByScorecardId] User ID: ${userId}`);
      console.log(`[getScorecardScoreViewsByScorecardId] User Persona: "${userPersona}"`);
      console.log(`[getScorecardScoreViewsByScorecardId] User Role ID (personaId): ${userRoleId}`);
      console.log(`[getScorecardScoreViewsByScorecardId] Scorecard ID: ${scorecard_id}`);

      let query;
      let queryParams;
      const scorecardStatusQuery = `
        SELECT review_status 
        FROM scorecard 
        WHERE id = ?
      `;
      const scorecard_status = await connection.query(scorecardStatusQuery, [scorecard_id]);
      // Check if user is Volvo Functional Manager
      if (scorecard_status != "Completed" && userPersona == 'Volvo Functional Manager' || 'Uptime & Parts Manager' || 'Auditor' || 'Retail Sales Manager') {
        console.log(`[getScorecardScoreViewsByScorecardId] Applying Volvo Functional Manager filter`);
        // Filter scoreviews to only show sub_kpis mapped to this user's roleId in subkpiuserroles table
        query = `
        SELECT 
          ssv.id,
          ssv.sub_kpi_id,
          ssv.scorecard_id,
          ssv.reviewer_score,
          ssv.reviewer,
          ssv.isScored,
          ssv.isExcluded,
          ssv.remarks,
          ssv.supporting_doc,
          ssv.uploaded_by,
          ssv.uploaded_on,
          ssv.final_score,
          ssv.created_at,
          ssv.updated_at,
          ssv.isActive,
          ssv.isDeleted,
          CONCAT(ub.firstName, ' ', ub.lastName) as uploaded_by_name,
          ub.email as uploaded_by_email,
          sk.createdYear as sub_kpi_createdYear,
          sk.objectiveId as sub_kpi_objectiveId,
          sk.kpiId as sub_kpi_kpiId,
          sk.kpiNumber as sub_kpi_kpiNumber,
          sk.subKpiName as sub_kpi_subKpiName,
          sk.assessmentPeriod as sub_kpi_assessmentPeriod,
          ssv.minScore,
          ssv.maxScore,
          ssv.formula,
          sk.scoringCriteria as sub_kpi_scoringCriteria,
          sk.measurement as sub_kpi_measurement,
          sk.annualScore as sub_kpi_annualScore,
          sk.annualScoringCriteria as sub_kpi_annualScoringCriteria,
          sk.docStaus as sub_kpi_docStaus,
          sk.doc as sub_kpi_doc,
          sk.criteriaDefinition as sub_kpi_criteriaDefinition,
          sk.dataSource as sub_kpi_dataSource,
          sk.createdOn as sub_kpi_createdOn,
          sk.isActive as sub_kpi_isActive,
          sk.updatedOn as sub_kpi_updatedOn,
          so.objectiveName as sub_kpi_objectiveName,
          k.kpiName as sub_kpi_kpiName,
          CONCAT(r.firstName, ' ', r.lastName) as reviewer_name,
          r.email as reviewer_email,
          sc.year as scorecard_year,
          sc.frequency as scorecard_frequency,
          sc.quarter_frequency as scorecard_quarter_frequency,
          sc.audit_location as scorecard_audit_location,
          sc.branch as scorecard_branch
        FROM scorecard_scoreview ssv
        LEFT JOIN sub_kpi_master sk ON ssv.sub_kpi_id = sk.id
        LEFT JOIN strategic_objective_master so ON sk.objectiveId = so.id
        LEFT JOIN kpi_master k ON sk.kpiId = k.id
        LEFT JOIN userdetails r ON ssv.reviewer = r.id
        LEFT JOIN userdetails ub ON ssv.uploaded_by = ub.id
        LEFT JOIN scorecard sc ON ssv.scorecard_id = sc.id
        INNER JOIN subkpiuserroles skur ON ssv.sub_kpi_id = skur.subKpiId
        WHERE ssv.scorecard_id = ? 
          AND skur.roleId = ?
          AND (ssv.isDeleted = 0 OR ssv.isDeleted IS NULL)
        ORDER BY ssv.id DESC
      `;
        queryParams = [scorecard_id, userRoleId];
      } else {
        console.log(`[getScorecardScoreViewsByScorecardId] Applying standard filter (all scoreviews)`);
        // Standard query - show all scoreviews for the scorecard
        query = `
        SELECT 
          ssv.id,
          ssv.sub_kpi_id,
          ssv.scorecard_id,
          ssv.reviewer_score,
          ssv.reviewer,
          ssv.isScored,
          ssv.isExcluded,
          ssv.remarks,
          ssv.supporting_doc,
          ssv.uploaded_by,
          ssv.uploaded_on,
          ssv.final_score,
          ssv.created_at,
          ssv.updated_at,
          ssv.isActive,
          ssv.isDeleted,
          CONCAT(ub.firstName, ' ', ub.lastName) as uploaded_by_name,
          ub.email as uploaded_by_email,
          sk.createdYear as sub_kpi_createdYear,
          sk.objectiveId as sub_kpi_objectiveId,
          sk.kpiId as sub_kpi_kpiId,
          sk.kpiNumber as sub_kpi_kpiNumber,
          sk.subKpiName as sub_kpi_subKpiName,
          sk.assessmentPeriod as sub_kpi_assessmentPeriod,
          ssv.minScore,
          ssv.maxScore,
          ssv.formula,
          sk.scoringCriteria as sub_kpi_scoringCriteria,
          sk.measurement as sub_kpi_measurement,
          sk.annualScore as sub_kpi_annualScore,
          sk.annualScoringCriteria as sub_kpi_annualScoringCriteria,
          sk.docStaus as sub_kpi_docStaus,
          sk.doc as sub_kpi_doc,
          sk.criteriaDefinition as sub_kpi_criteriaDefinition,
          sk.dataSource as sub_kpi_dataSource,
          sk.createdOn as sub_kpi_createdOn,
          sk.isActive as sub_kpi_isActive,
          sk.updatedOn as sub_kpi_updatedOn,
          so.objectiveName as sub_kpi_objectiveName,
          k.kpiName as sub_kpi_kpiName,
          CONCAT(r.firstName, ' ', r.lastName) as reviewer_name,
          r.email as reviewer_email,
          sc.year as scorecard_year,
          sc.frequency as scorecard_frequency,
          sc.quarter_frequency as scorecard_quarter_frequency,
          sc.audit_location as scorecard_audit_location,
          sc.branch as scorecard_branch
        FROM scorecard_scoreview ssv
        LEFT JOIN sub_kpi_master sk ON ssv.sub_kpi_id = sk.id
        LEFT JOIN strategic_objective_master so ON sk.objectiveId = so.id
        LEFT JOIN kpi_master k ON sk.kpiId = k.id
        LEFT JOIN userdetails r ON ssv.reviewer = r.id
        LEFT JOIN userdetails ub ON ssv.uploaded_by = ub.id
        LEFT JOIN scorecard sc ON ssv.scorecard_id = sc.id
        WHERE ssv.scorecard_id = ? AND (ssv.isDeleted = 0 OR ssv.isDeleted IS NULL)
        ORDER BY ssv.id DESC
      `;
        queryParams = [scorecard_id];
      }

      const data = await connection.query(query, queryParams);

      console.log(`[getScorecardScoreViewsByScorecardId] Query returned ${data.length} scoreviews`);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No scorecard score view records found for this scorecard",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard score views retrieved",
        data: data
      });
    } catch (error) {
      console.error(`[getScorecardScoreViewsByScorecardId] Error:`, error);
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateScorecardScoreView: async function (req, res) {
    try {
      const {
        id,
        sub_kpi_id,
        scorecard_id,
        reviewer_score,
        reviewer,
        isScored,
        isExcluded,
        remarks,
        final_score,
        minScore,
        maxScore,
        formula
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(
        `SELECT id, sub_kpi_id, scorecard_id, final_score, minScore, isExcluded FROM scorecard_scoreview WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      console.log("Entry is done");
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard score view not found" });
      }
      let currentSubKpiId = exists[0].sub_kpi_id;
      let currentScorecardId = exists[0].scorecard_id;
      let previousFinalScore = exists[0].final_score;
      let currentMinScore = exists[0].minScore;
      let currentIsExcluded = exists[0].isExcluded;

      const updateFields = [];
      const updateValues = [];

      if (sub_kpi_id !== undefined) {
        updateFields.push("sub_kpi_id = ?");
        updateValues.push(sub_kpi_id);
      }
      if (scorecard_id !== undefined) {
        updateFields.push("scorecard_id = ?");
        updateValues.push(scorecard_id);
      }
      if (reviewer_score !== undefined) {
        updateFields.push("reviewer_score = ?");
        updateValues.push(reviewer_score);
        // When reviewer_score is updated, automatically set reviewer from token and isScored to true
        const reviewerFromToken = req.decodedToken;
        updateFields.push("reviewer = ?");
        updateValues.push(reviewerFromToken);
        updateFields.push("isScored = ?");
        updateValues.push(true);
      } else {
        // Only update reviewer and isScored if reviewer_score is not being updated
        if (reviewer !== undefined) {
          updateFields.push("reviewer = ?");
          updateValues.push(reviewer);
        }
        if (isScored !== undefined) {
          updateFields.push("isScored = ?");
          updateValues.push(isScored);
        }
      }
      if (isExcluded !== undefined) {
        updateFields.push("isExcluded = ?");
        updateValues.push(isExcluded);
      }
      if (remarks !== undefined) {
        updateFields.push("remarks = ?");
        updateValues.push(remarks);
      }
      if (final_score !== undefined) {
        updateFields.push("final_score = ?");
        updateValues.push(final_score);
      }
      if (minScore !== undefined) {
        updateFields.push("minScore = ?");
        updateValues.push(minScore);
      }
      if (maxScore !== undefined) {
        updateFields.push("maxScore = ?");
        updateValues.push(maxScore);
      }
      if (formula !== undefined) {
        updateFields.push("formula = ?");
        updateValues.push(formula);
      }

      // Handle file upload for supporting_doc
      if (req.files && req.files.length > 0) {
        const file = req.files[0];
        const supporting_doc_url = await uploadFile(file);

        if (!supporting_doc_url || typeof supporting_doc_url === 'object') {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }

        const uploaded_by = req.decodedToken;
        const uploaded_on = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

        updateFields.push("supporting_doc = ?");
        updateValues.push(supporting_doc_url);
        updateFields.push("uploaded_by = ?");
        updateValues.push(uploaded_by);
        updateFields.push("uploaded_on = ?");
        updateValues.push(uploaded_on);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at timestamp
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedAt);

      updateValues.push(id);

      const updateQuery = `
        UPDATE scorecard_scoreview
        SET ${updateFields.join(", ")}
        WHERE id = ?
      `;

      await connection.query(updateQuery, updateValues);

      // If final_score updated, evaluate against sub KPI min score and create action item if required
      if (final_score !== undefined) {
        const targetMinScore = minScore !== undefined ? minScore : currentMinScore;
        const targetSubKpiId = sub_kpi_id !== undefined ? sub_kpi_id : currentSubKpiId;
        const effectiveIsExcluded = isExcluded !== undefined ? isExcluded : currentIsExcluded;

        if (!effectiveIsExcluded && targetMinScore !== undefined) {
          const minScoreValue = Number(targetMinScore);
          const numericFinalScore = Number(final_score);
          const previousNumericFinalScore =
            previousFinalScore !== null && previousFinalScore !== undefined
              ? Number(previousFinalScore)
              : null;

          if (
            !Number.isNaN(minScoreValue) &&
            !Number.isNaN(numericFinalScore) &&
            numericFinalScore < minScoreValue &&
            (previousNumericFinalScore === null || numericFinalScore !== previousNumericFinalScore)
          ) {
            const actionItemCreatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            const actionItemResult = await connection.query(
              `INSERT INTO scorecard_action_items (
                  scorecard_score_id,
                  created_by,
                  assigned_to,
                  action_item_status,
                  end_date,
                  final_score,
                  created_at,
                  updated_at
                ) VALUES (?, 131, NULL, 'Created', NULL, ?, ?, ?)`,
              [id, numericFinalScore, actionItemCreatedAt, actionItemCreatedAt]
            );

            const actionItemId = actionItemResult.insertId;

            // Generate auto-comment for the log
            const autoComment = `System generated: Action item created automatically because final_score (${numericFinalScore}) is below the minimum required score (${minScoreValue}).`;

            // Insert log entry in scorecard_action_log
            const actionLogCreatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
            await connection.query(
              `INSERT INTO scorecard_action_log (
                  action_item_id,
                  commented_by,
                  comments,
                  supporting_doc_url,
                  created_at,
                  updated_at
                ) VALUES (?, 131, ?, NULL, ?, ?)`,
              [actionItemId, autoComment, actionLogCreatedAt, actionLogCreatedAt]
            );

            console.log(`Action item created: scorecard_score_id=${id}, final_score=${numericFinalScore}, minScore=${minScoreValue}, sub_kpi_id=${targetSubKpiId}`);

            // Get scorecard and sub KPI details for email
            const targetScorecardId = scorecard_id !== undefined ? scorecard_id : currentScorecardId;

            if (targetScorecardId) {
              // Get scorecard details with auditor emails
              const scorecardDetailsQuery = `
                  SELECT 
                    s.id as scorecard_id,
                    s.year as scorecard_year,
                    ma.marketarea as market_area_name,
                    d.dealerName as dealer_name,
                    la.email as lead_auditor_email,
                    ca.email as co_auditor_email
                  FROM scorecard s
                  LEFT JOIN market_area ma ON s.market_area_id = ma.id
                  LEFT JOIN dealer_master d ON s.dealer_id = d.id
                  LEFT JOIN userdetails la ON s.lead_auditor = la.id
                  LEFT JOIN userdetails ca ON s.co_auditor = ca.id
                  WHERE s.id = ?
                `;
              const scorecardDetails = await connection.query(scorecardDetailsQuery, [targetScorecardId]);

              // Get sub KPI details
              const subKpiDetailsQuery = `
                  SELECT 
                    sk.subKpiName,
                    k.kpiName,
                    so.objectiveName
                  FROM sub_kpi_master sk
                  LEFT JOIN kpi_master k ON sk.kpiId = k.id
                  LEFT JOIN strategic_objective_master so ON sk.objectiveId = so.id
                  WHERE sk.id = ?
                `;
              const subKpiDetails = await connection.query(subKpiDetailsQuery, [targetSubKpiId]);

              if (scorecardDetails.length > 0 && subKpiDetails.length > 0) {
                const scorecardInfo = scorecardDetails[0];
                const subKpiInfo = subKpiDetails[0];

                // Collect auditor emails
                const auditorEmails = [];
                if (scorecardInfo.lead_auditor_email) {
                  auditorEmails.push(scorecardInfo.lead_auditor_email);
                }
                if (scorecardInfo.co_auditor_email && scorecardInfo.co_auditor_email !== scorecardInfo.lead_auditor_email) {
                  auditorEmails.push(scorecardInfo.co_auditor_email);
                }

                // Prepare action item details for email
                const actionItemDetails = {
                  action_item_id: actionItemId,
                  scorecard_id: scorecardInfo.scorecard_id,
                  scorecard_year: scorecardInfo.scorecard_year,
                  dealer_name: scorecardInfo.dealer_name,
                  market_area_name: scorecardInfo.market_area_name,
                  sub_kpi_name: subKpiInfo.subKpiName,
                  kpi_name: subKpiInfo.kpiName,
                  objective_name: subKpiInfo.objectiveName,
                  final_score: numericFinalScore,
                  minScoreValue: minScoreValue,
                  action_item_status: 'Created',
                  created_at: actionItemCreatedAt
                };

                // Send email to auditors asynchronously (fire and forget)
                if (auditorEmails.length > 0) {
                  scorecardActionItemMail(auditorEmails, actionItemDetails).catch(err => {
                    console.error('Error sending action item email to auditors:', err);
                  });
                }
              }
            }
          }
        }
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard score view updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  bulkToggleScorecardScoreViewExclusion: async function (req, res) {
    try {
      const { scorecard_id, ids } = req.body;

      if (!scorecard_id) {
        return res.status(400).send({
          status: false,
          message: "scorecard_id is required"
        });
      }

      if (ids !== undefined && !Array.isArray(ids)) {
        return res.status(400).send({
          status: false,
          message: "ids must be an array when provided"
        });
      }

      const validScorecard = await connection.query(
        `SELECT id FROM scorecard WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [scorecard_id]
      );

      if (validScorecard.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Scorecard not found"
        });
      }

      const scorecardEntries = await connection.query(
        `SELECT id FROM scorecard_scoreview 
         WHERE scorecard_id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [scorecard_id]
      );

      if (scorecardEntries.length === 0) {
        return res.status(404).send({
          status: false,
          message: "No scorecard score view entries found for this scorecard"
        });
      }

      // Set all entries for this scorecard to false
      const updatedAtBulk = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(
        `UPDATE scorecard_scoreview 
         SET isExcluded = 0, updated_at = ? 
         WHERE scorecard_id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [updatedAtBulk, scorecard_id]
      );

      let updatedTrueIds = [];

      if (ids && ids.length > 0) {
        const placeholders = ids.map(() => "?").join(", ");

        await connection.query(
          `UPDATE scorecard_scoreview 
           SET isExcluded = 1, updated_at = ? 
           WHERE scorecard_id = ? 
             AND id IN (${placeholders}) 
             AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [updatedAtBulk, scorecard_id, ...ids]
        );
        updatedTrueIds = ids;
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard score view exclusions updated successfully",
        data: {
          scorecard_id,
          excluded_ids: updatedTrueIds
        }
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteScorecardScoreView: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if scorecard score view exists
      const exists = await connection.query(
        `SELECT id FROM scorecard_scoreview WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard score view not found" });
      }

      // Soft delete
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE scorecard_scoreview SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?`, [updatedAt, id]);

      return res.status(200).send({
        status: true,
        message: "Scorecard score view deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

