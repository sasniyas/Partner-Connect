const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../../azurestorage/fileUpload");

module.exports = {
  addScorecardScoreViewDoc: async function (req, res) {
    try {
      const { scorecard_id } = req.body;
      const uploaded_by = req.decodedToken;

      if (!scorecard_id) {
        return res.status(400).send({
          status: false,
          message: "Required: scorecard_id"
        });
      }

      if (!req.files || req.files.length === 0) {
        return res.status(400).send({
          status: false,
          message: "File is required"
        });
      }

      // Check if scorecard exists
      const scorecardExists = await connection.query(
        `SELECT id FROM scorecard WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [scorecard_id]
      );
      if (scorecardExists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard not found" });
      }

      // Upload file to Azure
      const file = req.files[0];
      const doc_url = await uploadFile(file);
      
      if (!doc_url || typeof doc_url === 'object') {
        return res.status(400).send({ status: false, message: "Failed to upload file!" });
      }

      const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO scorecard_scoreview_docs (
          scorecard_id, uploaded_by, doc_url, created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?)
      `;

      await connection.query(insertQuery, [
        scorecard_id,
        uploaded_by,
        doc_url,
        createdAt,
        createdAt
      ]);

      return res.status(200).send({
        status: true,
        message: "Scorecard score view document added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllScorecardScoreViewDocs: async function (req, res) {
    try {
      const query = `
        SELECT 
          ssvd.id,
          ssvd.scorecard_id,
          ssvd.uploaded_by,
          ssvd.doc_url,
          ssvd.created_at,
          ssvd.updated_at,
          ssvd.isActive,
          ssvd.isDeleted,
          CONCAT(u.firstName, ' ', u.lastName) as uploaded_by_name,
          u.email as uploaded_by_email,
          sc.year as scorecard_year,
          sc.frequency as scorecard_frequency,
          sc.quarter_frequency as scorecard_quarter_frequency,
          sc.audit_location as scorecard_audit_location,
          sc.branch as scorecard_branch
        FROM scorecard_scoreview_docs ssvd
        LEFT JOIN userdetails u ON ssvd.uploaded_by = u.id
        LEFT JOIN scorecard sc ON ssvd.scorecard_id = sc.id
        WHERE ssvd.isDeleted = 0 OR ssvd.isDeleted IS NULL
        ORDER BY ssvd.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No scorecard score view document records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard score view document list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getScorecardScoreViewDocById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          ssvd.id,
          ssvd.scorecard_id,
          ssvd.uploaded_by,
          ssvd.doc_url,
          ssvd.created_at,
          ssvd.updated_at,
          ssvd.isActive,
          ssvd.isDeleted,
          CONCAT(u.firstName, ' ', u.lastName) as uploaded_by_name,
          u.email as uploaded_by_email,
          sc.year as scorecard_year,
          sc.frequency as scorecard_frequency,
          sc.quarter_frequency as scorecard_quarter_frequency,
          sc.audit_location as scorecard_audit_location,
          sc.branch as scorecard_branch
        FROM scorecard_scoreview_docs ssvd
        LEFT JOIN userdetails u ON ssvd.uploaded_by = u.id
        LEFT JOIN scorecard sc ON ssvd.scorecard_id = sc.id
        WHERE ssvd.id = ? AND (ssvd.isDeleted = 0 OR ssvd.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard score view document not found" });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard score view document retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getScorecardScoreViewDocsByScorecardId: async function (req, res) {
    try {
      const { scorecard_id } = req.params;

      if (!scorecard_id) {
        return res.status(400).send({ status: false, message: "Scorecard ID is required" });
      }

      const query = `
        SELECT 
          ssvd.id,
          ssvd.scorecard_id,
          ssvd.uploaded_by,
          ssvd.doc_url,
          ssvd.created_at,
          ssvd.updated_at,
          ssvd.isActive,
          ssvd.isDeleted,
          CONCAT(u.firstName, ' ', u.lastName) as uploaded_by_name,
          u.email as uploaded_by_email,
          sc.year as scorecard_year,
          sc.frequency as scorecard_frequency,
          sc.quarter_frequency as scorecard_quarter_frequency,
          sc.audit_location as scorecard_audit_location,
          sc.branch as scorecard_branch
        FROM scorecard_scoreview_docs ssvd
        LEFT JOIN userdetails u ON ssvd.uploaded_by = u.id
        LEFT JOIN scorecard sc ON ssvd.scorecard_id = sc.id
        WHERE ssvd.scorecard_id = ? AND (ssvd.isDeleted = 0 OR ssvd.isDeleted IS NULL)
        ORDER BY ssvd.id DESC
      `;

      const data = await connection.query(query, [scorecard_id]);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No scorecard score view document records found for this scorecard",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard score view documents retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateScorecardScoreViewDoc: async function (req, res) {
    try {
      const {
        id,
        scorecard_id
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(
        `SELECT id FROM scorecard_scoreview_docs WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard score view document not found" });
      }

      const updateFields = [];
      const updateValues = [];

      if (scorecard_id !== undefined) {
        // Check if scorecard exists
        const scorecardExists = await connection.query(
          `SELECT id FROM scorecard WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [scorecard_id]
        );
        if (scorecardExists.length === 0) {
          return res.status(404).send({ status: false, message: "Scorecard not found" });
        }
        updateFields.push("scorecard_id = ?");
        updateValues.push(scorecard_id);
      }

      // Handle file upload if file is present
      if (req.files && req.files.length > 0) {
        const file = req.files[0];
        const doc_url = await uploadFile(file);
        
        if (!doc_url || typeof doc_url === 'object') {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
        updateFields.push("doc_url = ?");
        updateValues.push(doc_url);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at timestamp
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedAt);

      updateValues.push(id);

      const updateQuery = `
        UPDATE scorecard_scoreview_docs
        SET ${updateFields.join(", ")}
        WHERE id = ?
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "Scorecard score view document updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleScorecardScoreViewDoc: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Get current status
      const getQuery = `SELECT isActive FROM scorecard_scoreview_docs WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`;
      const data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard score view document not found" });
      }

      const newStatus = data[0].isActive === 1 ? 0 : 1;
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const updateQuery = `UPDATE scorecard_scoreview_docs SET isActive = ?, updated_at = ? WHERE id = ?`;
      await connection.query(updateQuery, [newStatus, updatedAt, id]);

      return res.status(200).send({
        status: true,
        message: `Scorecard score view document ${newStatus === 1 ? "enabled" : "disabled"} successfully`
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteScorecardScoreViewDoc: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if scorecard score view document exists
      const exists = await connection.query(
        `SELECT id FROM scorecard_scoreview_docs WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard score view document not found" });
      }

      // Soft delete
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE scorecard_scoreview_docs SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?`, [updatedAt, id]);

      return res.status(200).send({
        status: true,
        message: "Scorecard score view document deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

