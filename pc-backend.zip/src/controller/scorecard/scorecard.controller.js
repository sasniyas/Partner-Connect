const { connection } = require("../../mySql/mySql");
const moment = require('moment-timezone');
const {
  scorecardCreatedMailForDealers,
  scorecardCreatedMailForAuditors,
  scorecardUpdatedMailForDealers,
  scorecardUpdatedMailForAuditors
} = require('../other/eMailer');
const { createNotification } = require("../notification/notification.controller");

module.exports = {

  addScorecard: async function (req, res) {
    try {
      const {
        year,
        market_area_id,
        dealer_id,
        frequency,
        quarter_frequency,
        audit_start_date,
        audit_end_date,
        physical_audit_start_date,
        physical_audit_end_date,
        lead_auditor,
        co_auditor,
        audit_location,
        branch,
        remarks,
        review_status
      } = req.body;

      if (!year || !market_area_id || !dealer_id || !frequency || !lead_auditor || !co_auditor) {
        return res.status(400).send({
          status: false,
          message: "Required: year, market_area_id, dealer_id, frequency, lead_auditor, co_auditor"
        });
      }

      if (audit_location && audit_location !== "HQ" && audit_location !== "Branch") {
        return res.status(400).send({
          status: false,
          message: "audit_location must be either HQ or Branch"
        });
      }

      // Set quarter_frequency based on frequency
      let finalQuarterFrequency = quarter_frequency;
      if (frequency === "Annual") {
        finalQuarterFrequency = "Q4";
      }

      // Check if entry already exists
      const [existingScorecard] = await connection.query(
        `SELECT id FROM scorecard 
         WHERE year = ? AND market_area_id = ? AND dealer_id = ? AND quarter_frequency = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [year, market_area_id, dealer_id, finalQuarterFrequency]
      );

      if (existingScorecard) {
        return res.status(400).send({
          status: false,
          message: "Scorecard already exists for this year, market area, dealer and quarter"
        });
      }

      const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO scorecard (
          year, market_area_id, dealer_id, frequency, quarter_frequency,
          audit_start_date, audit_end_date, physical_audit_start_date, physical_audit_end_date,
          lead_auditor, co_auditor, audit_location, branch, remarks, review_status,
          created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const result = await connection.query(insertQuery, [
        year,
        market_area_id,
        dealer_id,
        frequency,
        finalQuarterFrequency || null,
        audit_start_date || null,
        audit_end_date || null,
        physical_audit_start_date || null,
        physical_audit_end_date || null,
        lead_auditor,
        co_auditor,
        audit_location || null,
        branch || null,
        remarks || null,
        review_status || "Created",
        createdAt,
        createdAt
      ]);

      // Fetch active rows from sub_kpi_master based on frequency and quarter_frequency
      let assessmentQuery = `SELECT id, minScore, maxScore, formula FROM sub_kpi_master WHERE isActive = 1`;
      let queryParams = [];

      if (frequency === "Annual") {
        assessmentQuery += ` AND assessmentPeriod IN (?, ?)`;
        queryParams.push("Annually", "Quarterly");
      } else if (quarter_frequency === "Q1") {
        assessmentQuery += ` AND assessmentPeriod = ?`;
        queryParams.push("Quarterly");
      } else if (quarter_frequency === "Q2") {
        assessmentQuery += ` AND assessmentPeriod IN (?, ?)`;
        queryParams.push("Quarterly", "Half yearly");
      } else if (quarter_frequency === "Q3") {
        assessmentQuery += ` AND assessmentPeriod = ?`;
        queryParams.push("Quarterly");
      } else {
        // Fallback or Q4 for non-annual frequency
        assessmentQuery += ` AND assessmentPeriod = ?`;
        queryParams.push("Quarterly");
      }

      const activeSubKPIs = await connection.query(assessmentQuery, queryParams);

      // Create entries in scorecard_scoreview for each active sub_kpi
      if (activeSubKPIs.length > 0) {
        const scorecardId = result.insertId;
        const scorecardScoreViewCreatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        const scorecardScoreViewValues = activeSubKPIs.map(subKpi => [
          subKpi.id, // sub_kpi_id
          scorecardId, // scorecard_id
          null, // reviewer_score
          null, // reviewer
          false, // isScored
          false, // isExcluded
          null, // remarks
          scorecardScoreViewCreatedAt, // created_at
          scorecardScoreViewCreatedAt, // updated_at
          subKpi.minScore || 0, // minScore
          subKpi.maxScore || 0,
          subKpi.formula  // maxScore
        ]);

        await connection.query(
          `INSERT INTO scorecard_scoreview 
           (sub_kpi_id, scorecard_id, reviewer_score, reviewer, isScored, isExcluded, remarks, created_at, updated_at, minScore, maxScore, formula) 
           VALUES ?`,
          [scorecardScoreViewValues]
        );
      }

      // Get scorecard details with names for email
      const scorecardDetailsQuery = `
        SELECT 
          s.id,
          s.year,
          s.market_area_id,
          s.dealer_id,
          s.frequency,
          s.quarter_frequency,
          s.audit_start_date,
          s.audit_end_date,
          s.physical_audit_start_date,
          s.physical_audit_end_date,
          s.lead_auditor,
          s.co_auditor,
          s.audit_location,
          s.branch,
          s.remarks,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          CONCAT(la.firstName, ' ', la.lastName) as lead_auditor_name,
          la.email as lead_auditor_email,
          CONCAT(ca.firstName, ' ', ca.lastName) as co_auditor_name,
          ca.email as co_auditor_email
        FROM scorecard s
        LEFT JOIN market_area ma ON s.market_area_id = ma.id
        LEFT JOIN dealer_master d ON s.dealer_id = d.id
        LEFT JOIN userdetails la ON s.lead_auditor = la.id
        LEFT JOIN userdetails ca ON s.co_auditor = ca.id
        WHERE s.id = ?
      `;
      const scorecardDetails = await connection.query(scorecardDetailsQuery, [result.insertId]);

      if (scorecardDetails.length > 0) {
        const details = scorecardDetails[0];

        // Get dealer user emails and IDs
        const dealerUserQuery = `
          SELECT DISTINCT u.id, u.email
          FROM userDealers ud
          JOIN userdetails u ON ud.userId = u.id
          WHERE ud.dealerId = ? AND u.status = 'ACTIVE' AND u.email IS NOT NULL AND u.email != ''
        `;
        const dealerUsers = await connection.query(dealerUserQuery, [dealer_id]);
        const dealerEmails = dealerUsers.map(user => user.email).filter(email => email);
        const dealerUserIds = dealerUsers.map(user => user.id).filter(id => id);

        // Get auditor emails and IDs
        const auditorEmails = [];
        const auditorUserIds = [];
        if (details.lead_auditor_email) {
          auditorEmails.push(details.lead_auditor_email);
        }
        if (details.lead_auditor) {
          auditorUserIds.push(details.lead_auditor);
        }
        if (details.co_auditor_email && details.co_auditor_email !== details.lead_auditor_email) {
          auditorEmails.push(details.co_auditor_email);
        }
        if (details.co_auditor && details.co_auditor !== details.lead_auditor) {
          auditorUserIds.push(details.co_auditor);
        }

        // Send emails asynchronously (fire and forget)
        if (dealerEmails.length > 0) {
          scorecardCreatedMailForDealers(dealerEmails, details).catch(err => {
            console.error('Error sending scorecard creation email to dealers:', err);
          });
        }

        if (auditorEmails.length > 0) {
          scorecardCreatedMailForAuditors(auditorEmails, details).catch(err => {
            console.error('Error sending scorecard creation email to auditors:', err);
          });
        }

        // Create notifications for dealer users
        if (dealerUserIds.length > 0) {
          const dealerNotificationTitle = "New Scorecard Created";
          const dealerNotificationMessage = `A new scorecard has been created for ${details.dealer_name || 'your dealer'} for year ${details.year}. Scorecard ID: ${details.id}`;
          createNotification(dealerNotificationTitle, dealerNotificationMessage, dealerUserIds).catch(err => {
            console.error('Error creating notification for dealer users:', err);
          });
        }

        // Create notifications for auditors
        if (auditorUserIds.length > 0) {
          const auditorNotificationTitle = "New Scorecard Assigned";
          const auditorNotificationMessage = `You have been assigned to a new scorecard for ${details.dealer_name || 'dealer'} for year ${details.year}. Scorecard ID: ${details.id}`;
          createNotification(auditorNotificationTitle, auditorNotificationMessage, auditorUserIds).catch(err => {
            console.error('Error creating notification for auditors:', err);
          });
        }
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllScorecards: async function (req, res) {
    try {
      // Extract userId from decoded token
      const userId = req.decodedToken;

      if (!userId) {
        return res.status(401).send({ status: false, message: "User not authenticated" });
      }

      // Fetch user persona and marketArea from userdetails table
      const userQuery = `
        SELECT persona, marketArea 
        FROM userdetails 
        WHERE id = ?
      `;
      const userResult = await connection.query(userQuery, [userId]);

      if (userResult.length === 0) {
        return res.status(404).send({ status: false, message: "User not found" });
      }

      const userPersona = userResult[0].persona;
      let userMarketArea = userResult[0].marketArea;

      // Debug logging
      console.log(`[getAllScorecards] User ID: ${userId}`);
      console.log(`[getAllScorecards] User Persona: "${userPersona}"`);
      console.log(`[getAllScorecards] User Market Area (raw): ${userMarketArea}`);

      // If marketArea is a string (name), convert it to ID
      if (userMarketArea && isNaN(userMarketArea)) {
        const marketAreaQuery = `
          SELECT id FROM market_area WHERE marketarea = ?
        `;
        const marketAreaResult = await connection.query(marketAreaQuery, [userMarketArea]);
        if (marketAreaResult.length > 0) {
          userMarketArea = marketAreaResult[0].id;
          console.log(`[getAllScorecards] Converted Market Area name to ID: ${userMarketArea}`);
        } else {
          console.log(`[getAllScorecards] WARNING: Market Area "${userMarketArea}" not found in market_area table`);
          userMarketArea = null;
        }
      }

      // Define personas with full access (can see all scorecards)
      // TODO: Update this array based on actual business requirements
      const fullAccessPersonas = [
        'Administrator', //(All Review & All Scoreview)
        'Volvo Functional Manager', //(All Review & if subKpi is assigned to this role those scoreviews are only accessible)
        'IMT',
        'Head of Channel Development Region India'
      ];

      // Define personas with restricted access (can only see scorecards for their mapped dealers)
      // TODO: Update this array based on actual business requirements
      const restrictedAccessPersonas = [
        'Dealer Parts Manager',
        'Dealer Coordinator',
        'Dealer sales head',
        'Dealer CST Head',
        'Dealer Finance Head',
        'Dealer HR Head',
        'Dealer Principal',
        'Dealer CEO'
      ];

      // Define personas with market area restriction (can see scorecards for mapped dealers AND their market area)
      const restrictedMarketArea = [
        'Uptime & Parts Manager',
        'Retail Sales Manager',
        'Key Account Manager Uptime & Parts',
        'Key Account Manager Sales',
        'Market Area Head',
        'Volvo User'
      ];

      let query;
      let queryParams = [];

      if (fullAccessPersonas.includes(userPersona)) {
        console.log(`[getAllScorecards] Access Level: Full Access`);
        // User has full access - fetch all scorecards
        query = `
        SELECT 
          s.id,
          s.year,
          s.market_area_id,
          s.dealer_id,
          s.frequency,
          s.quarter_frequency,
          s.audit_start_date,
          s.audit_end_date,
          s.physical_audit_start_date,
          s.physical_audit_end_date,
          s.lead_auditor,
          s.co_auditor,
          s.audit_location,
          s.branch,
          s.remarks,
          s.review_status,
          s.created_at,
          s.updated_at,
          s.isActive,
          s.isDeleted,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          CONCAT(la.firstName, ' ', la.lastName) as lead_auditor_name,
          la.email as lead_auditor_email,
          CONCAT(ca.firstName, ' ', ca.lastName) as co_auditor_name,
          ca.email as co_auditor_email
        FROM scorecard s
        LEFT JOIN market_area ma ON s.market_area_id = ma.id
        LEFT JOIN dealer_master d ON s.dealer_id = d.id
        LEFT JOIN userdetails la ON s.lead_auditor = la.id
        LEFT JOIN userdetails ca ON s.co_auditor = ca.id
        WHERE s.isDeleted = 0 OR s.isDeleted IS NULL
        ORDER BY s.id DESC
      `;
      } else if (restrictedMarketArea.includes(userPersona)) {
        console.log(`[getAllScorecards] Access Level: Market Area Restricted`);
        console.log(`[getAllScorecards] Query Params: marketArea=${userMarketArea}, userId=${userId}`);
        // User has market area restriction - fetch scorecards for mapped dealers OR their market area
        query = `
        SELECT DISTINCT
          s.id,
          s.year,
          s.market_area_id,
          s.dealer_id,
          s.frequency,
          s.quarter_frequency,
          s.audit_start_date,
          s.audit_end_date,
          s.physical_audit_start_date,
          s.physical_audit_end_date,
          s.lead_auditor,
          s.co_auditor,
          s.audit_location,
          s.branch,
          s.remarks,
          s.review_status,
          s.created_at,
          s.updated_at,
          s.isActive,
          s.isDeleted,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          CONCAT(la.firstName, ' ', la.lastName) as lead_auditor_name,
          la.email as lead_auditor_email,
          CONCAT(ca.firstName, ' ', ca.lastName) as co_auditor_name,
          ca.email as co_auditor_email
        FROM scorecard s
        LEFT JOIN market_area ma ON s.market_area_id = ma.id
        LEFT JOIN dealer_master d ON s.dealer_id = d.id
        LEFT JOIN userdetails la ON s.lead_auditor = la.id
        LEFT JOIN userdetails ca ON s.co_auditor = ca.id
        WHERE (s.market_area_id = ? OR s.dealer_id IN (SELECT dealerId FROM userdealers WHERE userId = ?))
          AND (s.isDeleted = 0 OR s.isDeleted IS NULL)
        ORDER BY s.id DESC
      `;
        queryParams = [userMarketArea, userId];
      } else if (restrictedAccessPersonas.includes(userPersona)) {
        console.log(`[getAllScorecards] Access Level: Dealer Restricted`);
        // User has restricted access - fetch only scorecards for mapped dealers
        query = `
        SELECT 
          s.id,
          s.year,
          s.market_area_id,
          s.dealer_id,
          s.frequency,
          s.quarter_frequency,
          s.audit_start_date,
          s.audit_end_date,
          s.physical_audit_start_date,
          s.physical_audit_end_date,
          s.lead_auditor,
          s.co_auditor,
          s.audit_location,
          s.branch,
          s.remarks,
          s.review_status,
          s.created_at,
          s.updated_at,
          s.isActive,
          s.isDeleted,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          CONCAT(la.firstName, ' ', la.lastName) as lead_auditor_name,
          la.email as lead_auditor_email,
          CONCAT(ca.firstName, ' ', ca.lastName) as co_auditor_name,
          ca.email as co_auditor_email
        FROM scorecard s
        LEFT JOIN market_area ma ON s.market_area_id = ma.id
        LEFT JOIN dealer_master d ON s.dealer_id = d.id
        LEFT JOIN userdetails la ON s.lead_auditor = la.id
        LEFT JOIN userdetails ca ON s.co_auditor = ca.id
        INNER JOIN userdealers ud ON s.dealer_id = ud.dealerId
        WHERE ud.userId = ? AND (s.isDeleted = 0 OR s.isDeleted IS NULL)
        ORDER BY s.id DESC
      `;
        queryParams = [userId];
      } else if (userPersona === 'Auditor') {
        console.log(`[getAllScorecards] Access Level: Auditor - Only assigned scorecards`);
        // Auditor can only see scorecards where they are lead_auditor or co_auditor
        query = `
        SELECT 
          s.id,
          s.year,
          s.market_area_id,
          s.dealer_id,
          s.frequency,
          s.quarter_frequency,
          s.audit_start_date,
          s.audit_end_date,
          s.physical_audit_start_date,
          s.physical_audit_end_date,
          s.lead_auditor,
          s.co_auditor,
          s.audit_location,
          s.branch,
          s.remarks,
          s.review_status,
          s.created_at,
          s.updated_at,
          s.isActive,
          s.isDeleted,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          CONCAT(la.firstName, ' ', la.lastName) as lead_auditor_name,
          la.email as lead_auditor_email,
          CONCAT(ca.firstName, ' ', ca.lastName) as co_auditor_name,
          ca.email as co_auditor_email
        FROM scorecard s
        LEFT JOIN market_area ma ON s.market_area_id = ma.id
        LEFT JOIN dealer_master d ON s.dealer_id = d.id
        LEFT JOIN userdetails la ON s.lead_auditor = la.id
        LEFT JOIN userdetails ca ON s.co_auditor = ca.id
        WHERE (s.lead_auditor = ? OR s.co_auditor = ?)
          AND (s.isDeleted = 0 OR s.isDeleted IS NULL)
        ORDER BY s.id DESC
      `;
        queryParams = [userId, userId];
      } else {
        console.log(`[getAllScorecards] Access Level: DENIED - Unknown persona`);
        // Unknown persona - no access
        return res.status(403).send({
          status: false,
          message: "Access denied: Your persona does not have permission to view scorecards"
        });
      }

      const data = await connection.query(query, queryParams);

      console.log(`[getAllScorecards] Query returned ${data.length} scorecards`);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No scorecard records found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getScorecardById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT 
          s.id,
          s.year,
          s.market_area_id,
          s.dealer_id,
          s.frequency,
          s.quarter_frequency,
          s.audit_start_date,
          s.audit_end_date,
          s.physical_audit_start_date,
          s.physical_audit_end_date,
          s.lead_auditor,
          s.co_auditor,
          s.audit_location,
          s.branch,
          s.remarks,
          s.review_status,
          s.created_at,
          s.updated_at,
          s.isActive,
          s.isDeleted,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          CONCAT(la.firstName, ' ', la.lastName) as lead_auditor_name,
          la.email as lead_auditor_email,
          CONCAT(ca.firstName, ' ', ca.lastName) as co_auditor_name,
          ca.email as co_auditor_email
        FROM scorecard s
        LEFT JOIN market_area ma ON s.market_area_id = ma.id
        LEFT JOIN dealer_master d ON s.dealer_id = d.id
        LEFT JOIN userdetails la ON s.lead_auditor = la.id
        LEFT JOIN userdetails ca ON s.co_auditor = ca.id
        WHERE s.id = ? AND (s.isDeleted = 0 OR s.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard not found" });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },


  updateScorecard: async function (req, res) {
    try {
      const {
        id,
        year,
        market_area_id,
        dealer_id,
        frequency,
        quarter_frequency,
        audit_start_date,
        audit_end_date,
        physical_audit_start_date,
        physical_audit_end_date,
        lead_auditor,
        co_auditor,
        audit_location,
        branch,
        remarks,
        review_status
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      if (audit_location && audit_location !== "HQ" && audit_location !== "Branch") {
        return res.status(400).send({
          status: false,
          message: "audit_location must be either HQ or Branch"
        });
      }
      const exists = await connection.query(
        `SELECT id FROM scorecard WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard not found" });
      }

      // Get old scorecard details before update for email comparison
      const oldScorecardDetailsQuery = `
        SELECT 
          s.id,
          s.year,
          s.market_area_id,
          s.dealer_id,
          s.frequency,
          s.quarter_frequency,
          s.audit_start_date,
          s.audit_end_date,
          s.physical_audit_start_date,
          s.physical_audit_end_date,
          s.lead_auditor,
          s.co_auditor,
          s.audit_location,
          s.branch,
          s.remarks,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          CONCAT(la.firstName, ' ', la.lastName) as lead_auditor_name,
          la.email as lead_auditor_email,
          CONCAT(ca.firstName, ' ', ca.lastName) as co_auditor_name,
          ca.email as co_auditor_email
        FROM scorecard s
        LEFT JOIN market_area ma ON s.market_area_id = ma.id
        LEFT JOIN dealer_master d ON s.dealer_id = d.id
        LEFT JOIN userdetails la ON s.lead_auditor = la.id
        LEFT JOIN userdetails ca ON s.co_auditor = ca.id
        WHERE s.id = ?
      `;
      const oldScorecardDetails = await connection.query(oldScorecardDetailsQuery, [id]);
      const oldDetails = oldScorecardDetails.length > 0 ? oldScorecardDetails[0] : null;

      const updateFields = [];
      const updateValues = [];

      if (year !== undefined) {
        updateFields.push("year = ?");
        updateValues.push(year);
      }
      if (market_area_id !== undefined) {
        updateFields.push("market_area_id = ?");
        updateValues.push(market_area_id);
      }
      if (dealer_id !== undefined) {
        updateFields.push("dealer_id = ?");
        updateValues.push(dealer_id);
      }
      if (frequency !== undefined) {
        updateFields.push("frequency = ?");
        updateValues.push(frequency);
      }
      if (quarter_frequency !== undefined) {
        updateFields.push("quarter_frequency = ?");
        updateValues.push(quarter_frequency);
      }
      if (audit_start_date !== undefined) {
        updateFields.push("audit_start_date = ?");
        updateValues.push(audit_start_date);
      }
      if (audit_end_date !== undefined) {
        updateFields.push("audit_end_date = ?");
        updateValues.push(audit_end_date);
      }
      if (physical_audit_start_date !== undefined) {
        updateFields.push("physical_audit_start_date = ?");
        updateValues.push(physical_audit_start_date);
      }
      if (physical_audit_end_date !== undefined) {
        updateFields.push("physical_audit_end_date = ?");
        updateValues.push(physical_audit_end_date);
      }
      if (lead_auditor !== undefined) {
        updateFields.push("lead_auditor = ?");
        updateValues.push(lead_auditor);
      }
      if (co_auditor !== undefined) {
        updateFields.push("co_auditor = ?");
        updateValues.push(co_auditor);
      }
      if (audit_location !== undefined) {
        updateFields.push("audit_location = ?");
        updateValues.push(audit_location);
      }
      if (branch !== undefined) {
        updateFields.push("branch = ?");
        updateValues.push(branch);
      }
      if (remarks !== undefined) {
        updateFields.push("remarks = ?");
        updateValues.push(remarks);
      }
      if (review_status !== undefined) {
        updateFields.push("review_status = ?");
        updateValues.push(review_status);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at timestamp
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedAt);

      updateValues.push(id);

      const updateQuery = `
        UPDATE scorecard
        SET ${updateFields.join(", ")}
        WHERE id = ?
      `;

      await connection.query(updateQuery, updateValues);

      // Get new scorecard details after update for email
      const newScorecardDetailsQuery = `
        SELECT 
          s.id,
          s.year,
          s.market_area_id,
          s.dealer_id,
          s.frequency,
          s.quarter_frequency,
          s.audit_start_date,
          s.audit_end_date,
          s.physical_audit_start_date,
          s.physical_audit_end_date,
          s.lead_auditor,
          s.co_auditor,
          s.audit_location,
          s.branch,
          s.remarks,
          ma.marketarea as market_area_name,
          d.dealerName as dealer_name,
          CONCAT(la.firstName, ' ', la.lastName) as lead_auditor_name,
          la.email as lead_auditor_email,
          CONCAT(ca.firstName, ' ', ca.lastName) as co_auditor_name,
          ca.email as co_auditor_email
        FROM scorecard s
        LEFT JOIN market_area ma ON s.market_area_id = ma.id
        LEFT JOIN dealer_master d ON s.dealer_id = d.id
        LEFT JOIN userdetails la ON s.lead_auditor = la.id
        LEFT JOIN userdetails ca ON s.co_auditor = ca.id
        WHERE s.id = ?
      `;
      const newScorecardDetails = await connection.query(newScorecardDetailsQuery, [id]);

      if (oldDetails && newScorecardDetails.length > 0) {
        const newDetails = newScorecardDetails[0];

        // Determine which dealer_id to use (new or old)
        const currentDealerId = dealer_id !== undefined ? dealer_id : oldDetails.dealer_id;

        // Get dealer user emails and IDs
        const dealerUserQuery = `
          SELECT DISTINCT u.id, u.email
          FROM userDealers ud
          JOIN userdetails u ON ud.userId = u.id
          WHERE ud.dealerId = ? AND u.status = 'ACTIVE' AND u.email IS NOT NULL AND u.email != ''
        `;
        const dealerUsers = await connection.query(dealerUserQuery, [currentDealerId]);
        const dealerEmails = dealerUsers.map(user => user.email).filter(email => email);
        const dealerUserIds = dealerUsers.map(user => user.id).filter(id => id);

        // Get auditor emails and IDs (include both old and new auditors to notify all)
        const auditorEmails = new Set();
        const auditorUserIds = new Set();
        if (oldDetails.lead_auditor_email) {
          auditorEmails.add(oldDetails.lead_auditor_email);
        }
        if (oldDetails.lead_auditor) {
          auditorUserIds.add(oldDetails.lead_auditor);
        }
        if (oldDetails.co_auditor_email) {
          auditorEmails.add(oldDetails.co_auditor_email);
        }
        if (oldDetails.co_auditor) {
          auditorUserIds.add(oldDetails.co_auditor);
        }
        if (newDetails.lead_auditor_email) {
          auditorEmails.add(newDetails.lead_auditor_email);
        }
        if (newDetails.lead_auditor) {
          auditorUserIds.add(newDetails.lead_auditor);
        }
        if (newDetails.co_auditor_email) {
          auditorEmails.add(newDetails.co_auditor_email);
        }
        if (newDetails.co_auditor) {
          auditorUserIds.add(newDetails.co_auditor);
        }
        const auditorEmailsArray = Array.from(auditorEmails).filter(email => email);
        const auditorUserIdsArray = Array.from(auditorUserIds).filter(id => id);

        // Send emails asynchronously (fire and forget)
        if (dealerEmails.length > 0) {
          scorecardUpdatedMailForDealers(dealerEmails, oldDetails, newDetails).catch(err => {
            console.error('Error sending scorecard update email to dealers:', err);
          });
        }

        if (auditorEmailsArray.length > 0) {
          scorecardUpdatedMailForAuditors(auditorEmailsArray, oldDetails, newDetails).catch(err => {
            console.error('Error sending scorecard update email to auditors:', err);
          });
        }

        // Create notifications for dealer users
        if (dealerUserIds.length > 0) {
          const dealerNotificationTitle = "Scorecard Updated";
          const dealerNotificationMessage = `Scorecard for ${newDetails.dealer_name || 'your dealer'} for year ${newDetails.year} has been updated. Scorecard ID: ${newDetails.id}`;
          createNotification(dealerNotificationTitle, dealerNotificationMessage, dealerUserIds).catch(err => {
            console.error('Error creating notification for dealer users:', err);
          });
        }

        // Create notifications for auditors
        if (auditorUserIdsArray.length > 0) {
          const auditorNotificationTitle = "Scorecard Updated";
          const auditorNotificationMessage = `Scorecard for ${newDetails.dealer_name || 'dealer'} for year ${newDetails.year} has been updated. Scorecard ID: ${newDetails.id}`;
          createNotification(auditorNotificationTitle, auditorNotificationMessage, auditorUserIdsArray).catch(err => {
            console.error('Error creating notification for auditors:', err);
          });
        }
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleScorecard: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Get current status
      const getQuery = `SELECT isActive FROM scorecard WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`;
      const data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard not found" });
      }

      const newStatus = data[0].isActive === 1 ? 0 : 1;
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const updateQuery = `UPDATE scorecard SET isActive = ?, updated_at = ? WHERE id = ?`;
      await connection.query(updateQuery, [newStatus, updatedAt, id]);

      return res.status(200).send({
        status: true,
        message: `Scorecard ${newStatus === 1 ? "enabled" : "disabled"} successfully`
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  completeScorecard: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Update current scorecard status
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const updateResult = await connection.query(
        `UPDATE scorecard SET review_status = 'Completed', updated_at = ? WHERE id = ?`,
        [updatedAt, id]
      );

      if (updateResult.affectedRows === 0) {
        return res.status(404).send({ status: false, message: "Scorecard not found" });
      }

      const scorecardData = await connection.query(
        `SELECT * FROM scorecard WHERE id = ?`,
        [id]
      );
      const scorecard = scorecardData[0];

      // Check if quarter_frequency is Q4
      if (scorecard && scorecard.quarter_frequency === 'Q4') {
        const newQuarterFrequency = 'Annual';
        const newFrequency = 'Annual';

        // Check if Annual scorecard already exists to prevent duplicates
        const annualData = await connection.query(
          `SELECT id FROM scorecard 
           WHERE year = ? AND market_area_id = ? AND dealer_id = ? AND quarter_frequency = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [scorecard.year, scorecard.market_area_id, scorecard.dealer_id, newQuarterFrequency]
        );
        const existingAnnual = annualData[0];

        if (!existingAnnual) {
          const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

          // Insert new Annual Scorecard
          const insertQuery = `
            INSERT INTO scorecard (
              year, market_area_id, dealer_id, frequency, quarter_frequency,
              audit_start_date, audit_end_date, physical_audit_start_date, physical_audit_end_date,
              lead_auditor, co_auditor, audit_location, branch, remarks, review_status,
              created_at, updated_at, isActive, isDeleted
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `;

          const insertResult = await connection.query(insertQuery, [
            scorecard.year,
            scorecard.market_area_id,
            scorecard.dealer_id,
            newFrequency,
            newQuarterFrequency,
            scorecard.audit_start_date,
            scorecard.audit_end_date,
            scorecard.physical_audit_start_date,
            scorecard.physical_audit_end_date,
            scorecard.lead_auditor,
            scorecard.co_auditor,
            scorecard.audit_location,
            scorecard.branch,
            scorecard.remarks,
            'Completed',
            createdAt,
            createdAt,
            1,
            0
          ]);

        }
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard marked as Completed successfully"
      });

    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  bulkCompleteScorecard: async function (req, res) {
    try {
      // Step 1: Fetch all Q4 entries that are not completed
      const q4Scorecards = await connection.query(
        `SELECT * FROM scorecard WHERE quarter_frequency = 'Q4' AND review_status != 'Completed' AND (isDeleted = 0 OR isDeleted IS NULL)`
      );

      if (q4Scorecards.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No Q4 scorecards found to complete"
        });
      }

      const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const annualScorecardsToInsert = [];
      const q4IdsToUpdate = [];

      // Step 2: Prepare Annual scorecard entries for all fetched Q4 scorecards
      for (const scorecard of q4Scorecards) {
        q4IdsToUpdate.push(scorecard.id);

        // Check if Annual scorecard already exists to prevent duplicates
        const annualData = await connection.query(
          `SELECT id FROM scorecard 
           WHERE year = ? AND market_area_id = ? AND dealer_id = ? AND quarter_frequency = 'Annual' AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [scorecard.year, scorecard.market_area_id, scorecard.dealer_id]
        );
        const existingAnnual = annualData[0];

        // Only add to insert list if Annual doesn't exist
        if (!existingAnnual) {
          annualScorecardsToInsert.push([
            scorecard.year,
            scorecard.market_area_id,
            scorecard.dealer_id,
            'Annual', // frequency
            'Annual', // quarter_frequency
            scorecard.audit_start_date,
            scorecard.audit_end_date,
            scorecard.physical_audit_start_date,
            scorecard.physical_audit_end_date,
            scorecard.lead_auditor,
            scorecard.co_auditor,
            scorecard.audit_location,
            scorecard.branch,
            scorecard.remarks,
            'Created', // review_status
            createdAt, // created_at
            createdAt, // updated_at
            1, // isActive
            0  // isDeleted
          ]);
        }
      }

      // Insert Annual scorecards if there are any to insert
      if (annualScorecardsToInsert.length > 0) {
        const insertQuery = `
          INSERT INTO scorecard (
            year, market_area_id, dealer_id, frequency, quarter_frequency,
            audit_start_date, audit_end_date, physical_audit_start_date, physical_audit_end_date,
            lead_auditor, co_auditor, audit_location, branch, remarks, review_status,
            created_at, updated_at, isActive, isDeleted
          )
          VALUES ?
        `;

        await connection.query(insertQuery, [annualScorecardsToInsert]);
      }

      // Step 3: Update all Q4 scorecards to set review_status as 'Completed'
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const updateQuery = `
        UPDATE scorecard 
        SET review_status = 'Completed', updated_at = ?`;

      await connection.query(updateQuery, [updatedAt]);

      return res.status(200).send({
        status: true,
        message: `Successfully completed ${q4IdsToUpdate.length} Q4 scorecards and created ${annualScorecardsToInsert.length} Annual scorecards`,
        data: {
          q4_completed_count: q4IdsToUpdate.length,
          annual_created_count: annualScorecardsToInsert.length
        }
      });

    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🗑️ Delete Scorecard
  deleteScorecard: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      // Check if scorecard exists
      const exists = await connection.query(
        `SELECT id FROM scorecard WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard not found" });
      }

      // Soft delete
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE scorecard SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?`, [updatedAt, id]);

      return res.status(200).send({
        status: true,
        message: "Scorecard deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};


