const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

const ALLOWED_STATUSES = ["Created", "In Progress", "Closed", "Completed"];

module.exports = {
  addScorecardActionItem: async function (req, res) {
    try {
      const {
        scorecard_score_id,
        assigned_to,
        action_item_status,
        end_date,
        final_score
      } = req.body;
      const created_by = req.decodedToken;

      if (!created_by) {
        return res.status(401).send({ status: false, message: "Unauthorized user" });
      }

      if (!scorecard_score_id) {
        return res.status(400).send({
          status: false,
          message: "Required: scorecard_score_id"
        });
      }

      const validateScore = await connection.query(
        `SELECT id FROM scorecard_scoreview WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [scorecard_score_id]
      );
      if (validateScore.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard score view entry not found" });
      }

      if (assigned_to) {
        const assignedUser = await connection.query(
          `SELECT id FROM userdetails WHERE id = ?`,
          [assigned_to]
        );
        if (assignedUser.length === 0) {
          return res.status(404).send({ status: false, message: "Assigned user not found" });
        }
      }

      if (action_item_status && !ALLOWED_STATUSES.includes(action_item_status)) {
        return res.status(400).send({
          status: false,
          message: `action_item_status must be one of ${ALLOWED_STATUSES.join(", ")}`
        });
      }

      const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO scorecard_action_items (
          scorecard_score_id,
          created_by,
          assigned_to,
          action_item_status,
          end_date,
          final_score,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `;

      await connection.query(insertQuery, [
        scorecard_score_id,
        created_by,
        assigned_to || null,
        action_item_status || "Created",
        end_date || null,
        final_score !== undefined ? final_score : null,
        createdAt,
        createdAt
      ]);

      return res.status(200).send({
        status: true,
        message: "Scorecard action item added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllScorecardActionItems: async function (req, res) {
    try {
      const query = `
        SELECT
          sai.id,
          sai.scorecard_score_id,
          sai.created_by,
          sai.assigned_to,
          sai.action_item_status,
          sai.end_date,
          sai.final_score,
          sai.created_at,
          sai.updated_at,
          sai.isActive,
          sai.isDeleted,
          CONCAT(cb.firstName, ' ', cb.lastName) as created_by_name,
          cb.email as created_by_email,
          CONCAT(at.firstName, ' ', at.lastName) as assigned_to_name,
          at.email as assigned_to_email,
          ssv.sub_kpi_id,
          ssv.scorecard_id,
          ssv.reviewer_score,
          ssv.reviewer,
          ssv.isScored,
          ssv.isExcluded,
          ssv.remarks,
          ssv.supporting_doc,
          ssv.uploaded_by,
          ssv.final_score,
          ssv.created_at AS score_created_at,
          ssv.updated_at AS score_updated_at,
          ssv.isActive AS score_isActive,
          ssv.isDeleted AS score_isDeleted,
          ssv.uploaded_on,
          sk.createdYear AS sub_kpi_createdYear,
          sk.objectiveId AS sub_kpi_objectiveId,
          sk.kpiId AS sub_kpi_kpiId,
          sk.kpiNumber AS sub_kpi_kpiNumber,
          sk.subKpiName AS sub_kpi_subKpiName,
          sk.assessmentPeriod AS sub_kpi_assessmentPeriod,
          sk.minScore AS sub_kpi_minScore,
          sk.maxScore AS sub_kpi_maxScore,
          sk.scoringCriteria AS sub_kpi_scoringCriteria,
          sk.measurement AS sub_kpi_measurement,
          sk.annualScore AS sub_kpi_annualScore,
          sk.annualScoringCriteria AS sub_kpi_annualScoringCriteria,
          sk.docStaus AS sub_kpi_docStaus,
          sk.doc AS sub_kpi_doc,
          sk.criteriaDefinition AS sub_kpi_criteriaDefinition,
          sk.dataSource AS sub_kpi_dataSource,
          sk.createdOn AS sub_kpi_createdOn,
          sk.isActive AS sub_kpi_isActive,
          sk.updatedOn AS sub_kpi_updatedOn,
          sc.year AS scorecard_year,
          sc.quarter_frequency AS scorecard_quarter,
          sc.audit_location AS scorecard_audit_location,
          sc.branch AS scorecard_branch,
          dm.dealerName AS dealer_name,
          so.objectiveName AS strategic_objective_name
        FROM scorecard_action_items sai
        LEFT JOIN userdetails cb ON sai.created_by = cb.id
        LEFT JOIN userdetails at ON sai.assigned_to = at.id
        LEFT JOIN scorecard_scoreview ssv ON sai.scorecard_score_id = ssv.id
        LEFT JOIN sub_kpi_master sk ON ssv.sub_kpi_id = sk.id
        LEFT JOIN scorecard sc ON ssv.scorecard_id = sc.id
        LEFT JOIN dealer_master dm ON sc.dealer_id = dm.id
        LEFT JOIN strategic_objective_master so ON sk.objectiveId = so.id
        WHERE sai.isDeleted = 0 OR sai.isDeleted IS NULL
        ORDER BY sai.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No scorecard action items found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard action item list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getScorecardActionItemById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT
          sai.id,
          sai.scorecard_score_id,
          sai.created_by,
          sai.assigned_to,
          sai.action_item_status,
          sai.end_date,
          sai.final_score,
          sai.created_at,
          sai.updated_at,
          sai.isActive,
          sai.isDeleted,
          CONCAT(cb.firstName, ' ', cb.lastName) as created_by_name,
          cb.email as created_by_email,
          CONCAT(at.firstName, ' ', at.lastName) as assigned_to_name,
          at.email as assigned_to_email,
          ssv.sub_kpi_id,
          ssv.scorecard_id,
          ssv.reviewer_score,
          ssv.reviewer,
          ssv.isScored,
          ssv.isExcluded,
          ssv.remarks,
          ssv.supporting_doc,
          ssv.uploaded_by,
          ssv.final_score,
          ssv.created_at AS score_created_at,
          ssv.updated_at AS score_updated_at,
          ssv.isActive AS score_isActive,
          ssv.isDeleted AS score_isDeleted,
          ssv.uploaded_on,
          sk.createdYear AS sub_kpi_createdYear,
          sk.objectiveId AS sub_kpi_objectiveId,
          sk.kpiId AS sub_kpi_kpiId,
          sk.kpiNumber AS sub_kpi_kpiNumber,
          sk.subKpiName AS sub_kpi_subKpiName,
          sk.assessmentPeriod AS sub_kpi_assessmentPeriod,
          sk.minScore AS sub_kpi_minScore,
          sk.maxScore AS sub_kpi_maxScore,
          sk.scoringCriteria AS sub_kpi_scoringCriteria,
          sk.measurement AS sub_kpi_measurement,
          sk.annualScore AS sub_kpi_annualScore,
          sk.annualScoringCriteria AS sub_kpi_annualScoringCriteria,
          sk.docStaus AS sub_kpi_docStaus,
          sk.doc AS sub_kpi_doc,
          sk.criteriaDefinition AS sub_kpi_criteriaDefinition,
          sk.dataSource AS sub_kpi_dataSource,
          sk.createdOn AS sub_kpi_createdOn,
          sk.isActive AS sub_kpi_isActive,
          sk.updatedOn AS sub_kpi_updatedOn,
          sc.year AS scorecard_year,
          sc.quarter_frequency AS scorecard_quarter,
          sc.audit_location AS scorecard_audit_location,
          sc.branch AS scorecard_branch,
          dm.dealerName AS dealer_name,
          so.objectiveName AS strategic_objective_name
        FROM scorecard_action_items sai
        LEFT JOIN userdetails cb ON sai.created_by = cb.id
        LEFT JOIN userdetails at ON sai.assigned_to = at.id
        LEFT JOIN scorecard_scoreview ssv ON sai.scorecard_score_id = ssv.id
        LEFT JOIN sub_kpi_master sk ON ssv.sub_kpi_id = sk.id
        LEFT JOIN scorecard sc ON ssv.scorecard_id = sc.id
        LEFT JOIN dealer_master dm ON sc.dealer_id = dm.id
        LEFT JOIN strategic_objective_master so ON sk.objectiveId = so.id
        WHERE sai.id = ? AND (sai.isDeleted = 0 OR sai.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard action item not found" });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard action item retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getScorecardActionItemsByScoreId: async function (req, res) {
    try {
      const { scorecard_score_id } = req.params;

      if (!scorecard_score_id) {
        return res.status(400).send({ status: false, message: "scorecard_score_id is required" });
      }

      const query = `
        SELECT
          sai.id,
          sai.scorecard_score_id,
          sai.created_by,
          sai.assigned_to,
          sai.action_item_status,
          sai.end_date,
          sai.final_score,
          sai.created_at,
          sai.updated_at,
          sai.isActive,
          sai.isDeleted,
          CONCAT(cb.firstName, ' ', cb.lastName) as created_by_name,
          cb.email as created_by_email,
          CONCAT(at.firstName, ' ', at.lastName) as assigned_to_name,
          at.email as assigned_to_email,
          ssv.sub_kpi_id,
          ssv.scorecard_id,
          ssv.reviewer_score,
          ssv.reviewer,
          ssv.isScored,
          ssv.isExcluded,
          ssv.remarks,
          ssv.supporting_doc,
          ssv.uploaded_by,
          ssv.final_score,
          ssv.created_at AS score_created_at,
          ssv.updated_at AS score_updated_at,
          ssv.isActive AS score_isActive,
          ssv.isDeleted AS score_isDeleted,
          ssv.uploaded_on,
          sk.createdYear AS sub_kpi_createdYear,
          sk.objectiveId AS sub_kpi_objectiveId,
          sk.kpiId AS sub_kpi_kpiId,
          sk.kpiNumber AS sub_kpi_kpiNumber,
          sk.subKpiName AS sub_kpi_subKpiName,
          sk.assessmentPeriod AS sub_kpi_assessmentPeriod,
          sk.minScore AS sub_kpi_minScore,
          sk.maxScore AS sub_kpi_maxScore,
          sk.scoringCriteria AS sub_kpi_scoringCriteria,
          sk.measurement AS sub_kpi_measurement,
          sk.annualScore AS sub_kpi_annualScore,
          sk.annualScoringCriteria AS sub_kpi_annualScoringCriteria,
          sk.docStaus AS sub_kpi_docStaus,
          sk.doc AS sub_kpi_doc,
          sk.criteriaDefinition AS sub_kpi_criteriaDefinition,
          sk.dataSource AS sub_kpi_dataSource,
          sk.createdOn AS sub_kpi_createdOn,
          sk.isActive AS sub_kpi_isActive,
          sk.updatedOn AS sub_kpi_updatedOn,
          sc.year AS scorecard_year,
          sc.quarter_frequency AS scorecard_quarter,
          sc.audit_location AS scorecard_audit_location,
          sc.branch AS scorecard_branch,
          dm.dealerName AS dealer_name,
          so.objectiveName AS strategic_objective_name
        FROM scorecard_action_items sai
        LEFT JOIN userdetails cb ON sai.created_by = cb.id
        LEFT JOIN userdetails at ON sai.assigned_to = at.id
        LEFT JOIN scorecard_scoreview ssv ON sai.scorecard_score_id = ssv.id
        LEFT JOIN sub_kpi_master sk ON ssv.sub_kpi_id = sk.id
        LEFT JOIN scorecard sc ON ssv.scorecard_id = sc.id
        LEFT JOIN dealer_master dm ON sc.dealer_id = dm.id
        LEFT JOIN strategic_objective_master so ON sk.objectiveId = so.id
        WHERE sai.scorecard_score_id = ? AND (sai.isDeleted = 0 OR sai.isDeleted IS NULL)
        ORDER BY sai.id DESC
      `;

      const data = await connection.query(query, [scorecard_score_id]);

      return res.status(200).send({
        status: true,
        message: "Scorecard action items retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateScorecardActionItem: async function (req, res) {
    try {
      const {
        id,
        scorecard_score_id,
        assigned_to,
        action_item_status,
        end_date,
        isActive,
        final_score
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(
        `SELECT id FROM scorecard_action_items WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard action item not found" });
      }

      const updateFields = [];
      const updateValues = [];

      if (scorecard_score_id !== undefined) {
        const validateScore = await connection.query(
          `SELECT id FROM scorecard_scoreview WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [scorecard_score_id]
        );
        if (validateScore.length === 0) {
          return res.status(404).send({ status: false, message: "Scorecard score view entry not found" });
        }
        updateFields.push("scorecard_score_id = ?");
        updateValues.push(scorecard_score_id);
      }

      if (assigned_to !== undefined) {
        if (assigned_to === null) {
          updateFields.push("assigned_to = NULL");
        } else {
          const assignedUser = await connection.query(
            `SELECT id FROM userdetails WHERE id = ?`,
            [assigned_to]
          );
          if (assignedUser.length === 0) {
            return res.status(404).send({ status: false, message: "Assigned user not found" });
          }
          updateFields.push("assigned_to = ?");
          updateValues.push(assigned_to);
        }
      }

      if (action_item_status !== undefined) {
        if (!ALLOWED_STATUSES.includes(action_item_status)) {
          return res.status(400).send({
            status: false,
            message: `action_item_status must be one of ${ALLOWED_STATUSES.join(", ")}`
          });
        }
        updateFields.push("action_item_status = ?");
        updateValues.push(action_item_status);
      }

      if (end_date !== undefined) {
        updateFields.push("end_date = ?");
        updateValues.push(end_date);
      }

      if (final_score !== undefined) {
        updateFields.push("final_score = ?");
        updateValues.push(final_score);
      }

      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive ? 1 : 0);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at timestamp
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedAt);

      updateValues.push(id);

      const updateQuery = `
        UPDATE scorecard_action_items
        SET ${updateFields.join(", ")}
        WHERE id = ?
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "Scorecard action item updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  toggleScorecardActionItem: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const existing = await connection.query(
        `SELECT isActive FROM scorecard_action_items WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );

      if (existing.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard action item not found" });
      }

      const newStatus = existing[0].isActive === 1 ? 0 : 1;
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(
        `UPDATE scorecard_action_items SET isActive = ?, updated_at = ? WHERE id = ?`,
        [newStatus, updatedAt, id]
      );

      return res.status(200).send({
        status: true,
        message: `Scorecard action item ${newStatus === 1 ? "enabled" : "disabled"} successfully`
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteScorecardActionItem: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(
        `SELECT id FROM scorecard_action_items WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard action item not found" });
      }

      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(
        `UPDATE scorecard_action_items SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?`,
        [updatedAt, id]
      );

      return res.status(200).send({
        status: true,
        message: "Scorecard action item deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};
