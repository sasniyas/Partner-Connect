const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../../azurestorage/fileUpload");

module.exports = {
  addScorecardActionLog: async function (req, res) {
    try {
      const {
        action_item_id,
        comments
      } = req.body;
      const commented_by = req.decodedToken;

      if (!commented_by) {
        return res.status(401).send({ status: false, message: "Unauthorized user" });
      }

      if (!action_item_id) {
        return res.status(400).send({
          status: false,
          message: "Required: action_item_id"
        });
      }

      if (!comments) {
        return res.status(400).send({
          status: false,
          message: "Required: comments"
        });
      }

      const validateActionItem = await connection.query(
        `SELECT id FROM scorecard_action_items WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [action_item_id]
      );
      if (validateActionItem.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard action item not found" });
      }

      // Handle file upload for supporting_doc_url
      let supporting_doc_url = null;
      if (req.files && req.files.length > 0) {
        const file = req.files[0];
        const uploadedUrl = await uploadFile(file);
        
        if (!uploadedUrl || typeof uploadedUrl === 'object') {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
        supporting_doc_url = uploadedUrl;
      }

      const createdAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO scorecard_action_log (
          action_item_id,
          commented_by,
          comments,
          supporting_doc_url,
          created_at,
          updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?)
      `;

      await connection.query(insertQuery, [
        action_item_id,
        commented_by,
        comments,
        supporting_doc_url,
        createdAt,
        createdAt
      ]);

      return res.status(200).send({
        status: true,
        message: "Scorecard action log added successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getAllScorecardActionLogs: async function (req, res) {
    try {
      const query = `
        SELECT
          sal.id,
          sal.action_item_id,
          sal.commented_by,
          sal.comments,
          sal.supporting_doc_url,
          sal.created_at,
          sal.updated_at,
          sal.isActive,
          sal.isDeleted,
          CONCAT(cb.firstName, ' ', cb.lastName) as commented_by_name,
          cb.email as commented_by_email,
          sai.scorecard_score_id,
          sai.action_item_status,
          sai.end_date,
          sai.final_score
        FROM scorecard_action_log sal
        LEFT JOIN userdetails cb ON sal.commented_by = cb.id
        LEFT JOIN scorecard_action_items sai ON sal.action_item_id = sai.id
        WHERE sal.isDeleted = 0 OR sal.isDeleted IS NULL
        ORDER BY sal.id DESC
      `;

      const data = await connection.query(query);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No scorecard action logs found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard action log list retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getScorecardActionLogById: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const query = `
        SELECT
          sal.id,
          sal.action_item_id,
          sal.commented_by,
          sal.comments,
          sal.supporting_doc_url,
          sal.created_at,
          sal.updated_at,
          sal.isActive,
          sal.isDeleted,
          CONCAT(cb.firstName, ' ', cb.lastName) as commented_by_name,
          cb.email as commented_by_email,
          sai.scorecard_score_id,
          sai.action_item_status,
          sai.end_date,
          sai.final_score
        FROM scorecard_action_log sal
        LEFT JOIN userdetails cb ON sal.commented_by = cb.id
        LEFT JOIN scorecard_action_items sai ON sal.action_item_id = sai.id
        WHERE sal.id = ? AND (sal.isDeleted = 0 OR sal.isDeleted IS NULL)
      `;

      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard action log not found" });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard action log retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getScorecardActionLogsByActionItemId: async function (req, res) {
    try {
      const { action_item_id } = req.params;

      if (!action_item_id) {
        return res.status(400).send({ status: false, message: "action_item_id is required" });
      }

      const query = `
        SELECT
          sal.id,
          sal.action_item_id,
          sal.commented_by,
          sal.comments,
          sal.supporting_doc_url,
          sal.created_at,
          sal.updated_at,
          sal.isActive,
          sal.isDeleted,
          CONCAT(cb.firstName, ' ', cb.lastName) as commented_by_name,
          cb.email as commented_by_email,
          sai.scorecard_score_id,
          sai.action_item_status,
          sai.end_date,
          sai.final_score
        FROM scorecard_action_log sal
        LEFT JOIN userdetails cb ON sal.commented_by = cb.id
        LEFT JOIN scorecard_action_items sai ON sal.action_item_id = sai.id
        WHERE sal.action_item_id = ? AND (sal.isDeleted = 0 OR sal.isDeleted IS NULL)
        ORDER BY sal.created_at DESC
      `;

      const data = await connection.query(query, [action_item_id]);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No scorecard action logs found for this action item",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Scorecard action logs retrieved",
        data: data
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  getFirstLogCommentsByActionItemId: async function (req, res) {
    try {
      const { action_item_id } = req.params;

      if (!action_item_id) {
        return res.status(400).send({ status: false, message: "action_item_id is required" });
      }

      const query = `
        SELECT
          sal.id,
          sal.action_item_id,
          sal.comments,
          sal.created_at,
          CONCAT(cb.firstName, ' ', cb.lastName) as commented_by_name,
          cb.email as commented_by_email
        FROM scorecard_action_log sal
        LEFT JOIN userdetails cb ON sal.commented_by = cb.id
        WHERE sal.action_item_id = ? AND (sal.isDeleted = 0 OR sal.isDeleted IS NULL)
        ORDER BY sal.created_at ASC
        LIMIT 1
      `;

      const data = await connection.query(query, [action_item_id]);

      if (data.length === 0) {
        return res.status(404).send({
          status: false,
          message: "No action log found for this action item"
        });
      }

      return res.status(200).send({
        status: true,
        message: "First action log comments retrieved",
        data: data[0]
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  updateScorecardActionLog: async function (req, res) {
    try {
      const {
        id,
        action_item_id,
        comments
      } = req.body;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(
        `SELECT id FROM scorecard_action_log WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard action log not found" });
      }

      const updateFields = [];
      const updateValues = [];

      if (action_item_id !== undefined) {
        const validateActionItem = await connection.query(
          `SELECT id FROM scorecard_action_items WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
          [action_item_id]
        );
        if (validateActionItem.length === 0) {
          return res.status(404).send({ status: false, message: "Scorecard action item not found" });
        }
        updateFields.push("action_item_id = ?");
        updateValues.push(action_item_id);
      }

      if (comments !== undefined) {
        updateFields.push("comments = ?");
        updateValues.push(comments);
      }

      // Handle file upload for supporting_doc_url
      if (req.files && req.files.length > 0) {
        const file = req.files[0];
        const supporting_doc_url = await uploadFile(file);
        
        if (!supporting_doc_url || typeof supporting_doc_url === 'object') {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
        updateFields.push("supporting_doc_url = ?");
        updateValues.push(supporting_doc_url);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields to update"
        });
      }

      // Always update updated_at timestamp
      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedAt);

      updateValues.push(id);

      const updateQuery = `
        UPDATE scorecard_action_log
        SET ${updateFields.join(", ")}
        WHERE id = ?
      `;

      await connection.query(updateQuery, updateValues);

      return res.status(200).send({
        status: true,
        message: "Scorecard action log updated successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  deleteScorecardActionLog: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ status: false, message: "ID is required" });
      }

      const exists = await connection.query(
        `SELECT id FROM scorecard_action_log WHERE id = ? AND (isDeleted = 0 OR isDeleted IS NULL)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ status: false, message: "Scorecard action log not found" });
      }

      const updatedAt = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(
        `UPDATE scorecard_action_log SET isDeleted = 1, isActive = 0, updated_at = ? WHERE id = ?`,
        [updatedAt, id]
      );

      return res.status(200).send({
        status: true,
        message: "Scorecard action log deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  }
};

