const { connection } = require("../../mySql/mySql");

module.exports = {
    getUsersByMonthlyMeetingDealer: async function (req, res) {
        try {
            const { monthlyMeetingid } = req.params;

            if (!monthlyMeetingid) {
                return res.status(400).send({
                    status: false,
                    message: "monthlyMeetingid is required!"
                });
            }

            // 1. Fetch dealer_id for that monthlyMeeting from monthly_meeting table
            const meetingQuery = `SELECT dealer_id FROM monthly_meeting WHERE id = ?`;
            const meetingData = await connection.query(meetingQuery, [monthlyMeetingid]);

            if (meetingData.length === 0) {
                return res.status(404).send({
                    status: false,
                    message: "Monthly meeting not found!"
                });
            }

            const dealerId = meetingData[0].dealer_id;

            // 2. Fetch userIds mapped to that dealerId from userdealers table
            const userDealersQuery = `SELECT userId FROM userdealers WHERE dealerId = ?`;
            const userDealersData = await connection.query(userDealersQuery, [dealerId]);

            if (userDealersData.length === 0) {
                return res.status(200).send({
                    status: true,
                    message: "No users mapped to this dealer.",
                    data: []
                });
            }

            const userIds = userDealersData.map(ud => ud.userId);

            // 3. Fetch userIds and firstName from userdetails table for those userIds
            const userDetailsQuery = `SELECT id as userId, firstName, lastName FROM userdetails WHERE id IN (?)`;
            const userDetailsData = await connection.query(userDetailsQuery, [userIds]);

            return res.status(200).send({
                status: true,
                message: "Users fetched successfully.",
                data: userDetailsData
            });

        } catch (error) {
            console.error("Error in getUsersByMonthlyMeetingDealer:", error);
            return res.status(500).send({
                status: false,
                message: error.message
            });
        }
    }
};
