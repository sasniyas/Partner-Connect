const { connection } = require("../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {

  addActionLog: async function (req, res) {
    try {
      let {
        action_item_id,
        present_status,
        comments
      } = req.body;

      // Get updated_by from token
      const updated_by = req.decodedToken;
      console.log("updated_by", updated_by);

      // Validate required fields for action log creation
      if (!action_item_id) {
        return res.status(400).send({
          status: false,
          message: "Action item ID is required!"
        });
      }

      // Validate present_status if provided
      if (present_status) {
        const validStatuses = ['Open', 'Closed', 'In Progress'];
        if (!validStatuses.includes(present_status)) {
          return res.status(400).send({
            status: false,
            message: "Present status must be one of: Open, Closed, In Progress"
          });
        }
      }

      // Check if action item exists
      const actionItemCheckQuery = `SELECT id FROM action_item WHERE id = ? AND isDeleted = 0`;
      const actionItemExists = await connection.query(actionItemCheckQuery, [action_item_id]);

      if (actionItemExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action item not found!"
        });
      }

      // Check if user exists
      const userCheckQuery = `SELECT id FROM userdetails WHERE id = ?`;
      const userExists = await connection.query(userCheckQuery, [updated_by]);

      if (userExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "User not found in token!"
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const query = `
        INSERT INTO action_log 
        (updated_by, action_item_id, present_status, comments, createdOn) 
        VALUES (?, ?, ?, ?, ?)
      `;

      const insertResult = await connection.query(query, [
        updated_by, action_item_id, present_status || 'Open', comments || null, createdOn
      ]);

      return res.status(200).send({
        status: true,
        message: "Action log added successfully!",
        data: { id: insertResult.insertId }
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getAllActionLogs: async function (req, res) {
    try {
      const { action_item_id, updated_by } = req.query;

      let whereConditions = ['al.isDeleted = 0'];
      let queryParams = [];

      // Add optional filters
      if (action_item_id) {
        whereConditions.push('al.action_item_id = ?');
        queryParams.push(action_item_id);
      }

      if (updated_by) {
        whereConditions.push('al.updated_by = ?');
        queryParams.push(updated_by);
      }

      // Get all action logs with proper joins
      const actionLogQuery = `
        SELECT 
          al.id,
          al.updated_by,
          al.action_item_id,
          al.present_status,
          al.comments,
          al.createdOn,
          al.isDeleted,
          u.firstName as updated_by_name,
          u.lastName as updated_by_lastname,
          u.email as updated_by_email,
          ai.topic_of_discussion,
          ai.closure_action,
          ai.status as action_item_status,
          ai.target_date,
          ai.completed_date
        FROM action_log al 
        LEFT JOIN userdetails u ON al.updated_by = u.id 
        LEFT JOIN action_item ai ON al.action_item_id = ai.id
        WHERE ${whereConditions.join(' AND ')}
        ORDER BY al.createdOn DESC
      `;

      const actionLogData = await connection.query(actionLogQuery, queryParams);

      if (actionLogData.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No action logs found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Action logs retrieved successfully",
        data: actionLogData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getActionLogById: async function (req, res) {
    try {
      const { id } = req.params;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Get action log with proper joins
      const actionLogQuery = `
        SELECT 
          al.id,
          al.updated_by,
          al.action_item_id,
          al.present_status,
          al.comments,
          al.createdOn,
          al.isDeleted,
          u.firstName as updated_by_name,
          u.lastName as updated_by_lastname,
          u.email as updated_by_email,
          ai.topic_of_discussion,
          ai.closure_action,
          ai.status as action_item_status,
          ai.target_date,
          ai.completed_date,
          ai.department,
          d.name as department_name
        FROM action_log al 
        LEFT JOIN userdetails u ON al.updated_by = u.id 
        LEFT JOIN action_item ai ON al.action_item_id = ai.id
        LEFT JOIN departments d ON ai.department = d.id
        WHERE al.id = ? AND al.isDeleted = 0
      `;

      const actionLogData = await connection.query(actionLogQuery, [id]);

      if (actionLogData.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action log not found!"
        });
      }

      const result = actionLogData[0];

      return res.status(200).send({
        status: true,
        message: "Action log retrieved successfully",
        data: result
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getActionLogsByActionItem: async function (req, res) {
    try {
      const { action_item_id } = req.params;

      if (!action_item_id) {
        return res.status(400).send({
          status: false,
          message: "Action item ID is required!"
        });
      }

      const actionLogQuery = `
        SELECT 
          al.id,
          al.updated_by,
          al.action_item_id,
          al.present_status,
          al.comments,
          al.createdOn,
          al.isDeleted,
          u.firstName as updated_by_name,
          u.lastName as updated_by_lastname,
          u.email as updated_by_email,
          ai.topic_of_discussion,
          ai.closure_action,
          ai.status as action_item_status,
          ai.target_date,
          ai.completed_date
        FROM action_log al 
        LEFT JOIN userdetails u ON al.updated_by = u.id 
        LEFT JOIN action_item ai ON al.action_item_id = ai.id
        WHERE al.action_item_id = ? AND al.isDeleted = 0
        ORDER BY al.createdOn DESC
      `;

      const actionLogData = await connection.query(actionLogQuery, [action_item_id]);

      return res.status(200).send({
        status: true,
        message: "Action logs retrieved successfully",
        data: actionLogData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  updateActionLog: async function (req, res) {
    try {
      const { id } = req.params;
      const { present_status, comments } = req.body;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Validate present_status if provided
      if (present_status) {
        const validStatuses = ['Open', 'Closed', 'In Progress'];
        if (!validStatuses.includes(present_status)) {
          return res.status(400).send({
            status: false,
            message: "Present status must be one of: Open, Closed, In Progress"
          });
        }
      }

      // Check if action log exists
      const checkQuery = `SELECT * FROM action_log WHERE id = ? AND isDeleted = 0`;
      const existingActionLog = await connection.query(checkQuery, [id]);

      if (existingActionLog.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action log not found!"
        });
      }

      // Build update query dynamically based on provided fields
      let updateFields = [];
      let queryParams = [];

      if (present_status !== undefined) {
        updateFields.push('present_status = ?');
        queryParams.push(present_status);
      }

      if (comments !== undefined) {
        updateFields.push('comments = ?');
        queryParams.push(comments);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "At least one field (present_status or comments) must be provided for update!"
        });
      }

      queryParams.push(id);
      const updateQuery = `UPDATE action_log SET ${updateFields.join(', ')} WHERE id = ? AND isDeleted = 0`;

      const updatedResult = await connection.query(updateQuery, queryParams);

      return res.status(200).send({
        status: true,
        message: "Action log updated successfully!",
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  deleteActionLog: async function (req, res) {
    try {
      const { id } = req.params;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Check if action log exists before deletion
      const checkQuery = `SELECT * FROM action_log WHERE id = ? AND isDeleted = 0`;
      const existingActionLog = await connection.query(checkQuery, [id]);

      if (existingActionLog.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action log not found!"
        });
      }

      // Soft delete action log
      const deleteQuery = `UPDATE action_log SET isDeleted = 1 WHERE id = ?`;
      const updatedResult = await connection.query(deleteQuery, [id]);

      return res.status(200).send({
        status: true,
        message: "Action log deleted successfully!",
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getTargetDate: async function (req, res) {
    try {
      const { action_item_id } = req.params;

      if (!action_item_id) {
        return res.status(400).send({
          status: false,
          message: "Action item ID is required!"
        });
      }

      const query = `
        SELECT targetDate 
        FROM action_log 
        WHERE action_item_id = ? AND targetDate IS NOT NULL AND isDeleted = 0
        ORDER BY createdOn DESC
      `;

      const result = await connection.query(query, [action_item_id]);

      const targetDates = result.map(row => row.targetDate);

      return res.status(200).send({
        status: true,
        message: "Target dates retrieved successfully",
        data: targetDates
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  }
};
