const { connection } = require("../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../azurestorage/fileUpload");

module.exports = {

  addMonthlyMeetingTemplate: async function (req, res) {
    try {
      let {
        monthly_meeting
      } = req.body;

      // Validate required fields
      if (!monthly_meeting) {
        return res.status(400).send({
          status: false,
          message: "Monthly meeting ID is required!"
        });
      }

      // Check if monthly meeting exists
      const monthlyMeetingCheckQuery = `SELECT id FROM monthly_meeting WHERE id = ? AND isDeleted = 0`;
      const monthlyMeetingExists = await connection.query(monthlyMeetingCheckQuery, [monthly_meeting]);

      if (monthlyMeetingExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Monthly meeting not found!"
        });
      }

      let upload_fileLink = null;
      if (req.files && req.files.length > 0) {
        const file = req.files[0];
        upload_fileLink = await uploadFile(file);
        if (!upload_fileLink) {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const query = `
        INSERT INTO monthly_meeting_template 
        (monthly_meeting, upload_fileLink, createdOn, updatedOn, isDeleted) 
        VALUES (?, ?, ?, ?, 0)
      `;

      const insertResult = await connection.query(query, [
        monthly_meeting,
        upload_fileLink,
        createdOn,
        createdOn
      ]);

      return res.status(200).send({
        status: true,
        message: "Monthly meeting template added successfully!",
        data: { id: insertResult.insertId }
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getAllMonthlyMeetingTemplates: async function (req, res) {
    try {
      const { monthly_meeting } = req.query;

      let whereConditions = [];
      let queryParams = [];

      // Add optional filter
      if (monthly_meeting) {
        whereConditions.push('mmt.monthly_meeting = ?');
        queryParams.push(monthly_meeting);
      }

      // Get all monthly meeting templates with proper joins
      const templateQuery = `
        SELECT 
          mmt.id,
          mmt.monthly_meeting,
          mmt.upload_fileLink,
          mmt.createdOn,
          mmt.updatedOn,
          mm.meeting_date,
          mm.start_time,
          mm.end_time,
          mm.status as meeting_status
        FROM monthly_meeting_template mmt 
        LEFT JOIN monthly_meeting mm ON mmt.monthly_meeting = mm.id
        WHERE mmt.isDeleted = 0 ${whereConditions.length > 0 ? `AND ${whereConditions.join(' AND ')}` : ''}
        ORDER BY mmt.createdOn DESC
      `;

      const templateData = await connection.query(templateQuery, queryParams);

      if (templateData.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No monthly meeting templates found",
          data: []
        });
      }

      return res.status(200).send({
        status: true,
        message: "Monthly meeting templates retrieved successfully",
        data: templateData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getMonthlyMeetingTemplateById: async function (req, res) {
    try {
      const { id } = req.params;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Get monthly meeting template with proper joins
      const templateQuery = `
        SELECT 
          mmt.id,
          mmt.monthly_meeting,
          mmt.upload_fileLink,
          mmt.createdOn,
          mmt.updatedOn,
          mm.meeting_date,
          mm.start_time,
          mm.end_time,
          mm.status as meeting_status,
          mm.market_area_id,
          mm.dealer_id,
          ma.marketarea,
          dm.dealerName as dealer_name
        FROM monthly_meeting_template mmt 
        LEFT JOIN monthly_meeting mm ON mmt.monthly_meeting = mm.id
        LEFT JOIN market_area ma ON mm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id
        WHERE mmt.id = ? AND mmt.isDeleted = 0
      `;

      const templateData = await connection.query(templateQuery, [id]);

      if (templateData.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Monthly meeting template not found!"
        });
      }

      const result = templateData[0];

      return res.status(200).send({
        status: true,
        message: "Monthly meeting template retrieved successfully",
        data: result
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getMonthlyMeetingTemplatesByMonthlyMeeting: async function (req, res) {
    try {
      const { monthly_meeting } = req.params;

      if (!monthly_meeting) {
        return res.status(400).send({
          status: false,
          message: "Monthly meeting ID is required!"
        });
      }

      // Check if monthly meeting exists
      const monthlyMeetingCheckQuery = `SELECT id FROM monthly_meeting WHERE id = ? AND isDeleted = 0`;
      const monthlyMeetingExists = await connection.query(monthlyMeetingCheckQuery, [monthly_meeting]);

      if (monthlyMeetingExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Monthly meeting not found!"
        });
      }

      const templateQuery = `
        SELECT 
          mmt.id,
          mmt.monthly_meeting,
          mmt.upload_fileLink,
          mmt.createdOn,
          mmt.updatedOn,
          mm.meeting_date,
          mm.start_time,
          mm.end_time,
          mm.status as meeting_status
        FROM monthly_meeting_template mmt 
        LEFT JOIN monthly_meeting mm ON mmt.monthly_meeting = mm.id
        WHERE mmt.monthly_meeting = ? AND mmt.isDeleted = 0
        ORDER BY mmt.createdOn DESC
      `;

      const templateData = await connection.query(templateQuery, [monthly_meeting]);

      return res.status(200).send({
        status: true,
        message: "Monthly meeting templates retrieved successfully",
        data: templateData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  updateMonthlyMeetingTemplate: async function (req, res) {
    try {
      const { id } = req.params;
      const { upload_fileLink } = req.body;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Check if monthly meeting template exists
      const checkQuery = `SELECT * FROM monthly_meeting_template WHERE id = ? AND isDeleted = 0`;
      const existingTemplate = await connection.query(checkQuery, [id]);

      if (existingTemplate.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Monthly meeting template not found!"
        });
      }

      // Handle file upload if file is provided
      let fileUploadLink = upload_fileLink;
      if (req.files && req.files.length > 0) {
        const file = req.files[0];
        fileUploadLink = await uploadFile(file);
        if (!fileUploadLink) {
          return res.status(400).send({
            status: false,
            message: "Failed to upload file!"
          });
        }
      }

      // Build update query dynamically based on provided fields
      let updateFields = [];
      let queryParams = [];

      if (fileUploadLink !== undefined) {
        updateFields.push('upload_fileLink = ?');
        queryParams.push(fileUploadLink);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "At least one field (upload_file) must be provided for update!"
        });
      }

      // Add updatedOn timestamp
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push('updatedOn = ?');
      queryParams.push(updatedOn);

      queryParams.push(id);
      const updateQuery = `UPDATE monthly_meeting_template SET ${updateFields.join(', ')} WHERE id = ? AND isDeleted = 0`;

      const updatedResult = await connection.query(updateQuery, queryParams);

      return res.status(200).send({
        status: true,
        message: "Monthly meeting template updated successfully!",
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  bulkUploadMonthlyMeetingTemplates: async function (req, res) {
    try {
      // Handle multiple file uploads with corresponding template IDs
      // Expects templateIds as JSON array string and files in order

      if (!req.files || req.files.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No files provided for bulk upload!"
        });
      }

      // Parse template IDs from request body (sent as JSON string)
      let templateIds = [];
      if (req.body.templateIds) {
        try {
          templateIds = JSON.parse(req.body.templateIds);
        } catch (error) {
          return res.status(400).send({
            status: false,
            message: "Invalid templateIds format! Expected JSON array."
          });
        }
      }

      if (!Array.isArray(templateIds) || templateIds.length === 0) {
        return res.status(400).send({
          status: false,
          message: "Template IDs array is required and must not be empty!"
        });
      }

      if (req.files.length !== templateIds.length) {
        return res.status(400).send({
          status: false,
          message: `Number of files (${req.files.length}) does not match number of template IDs (${templateIds.length})!`
        });
      }

      // Match files with template IDs by index (first file with first ID, etc.)
      const uploads = [];
      for (let i = 0; i < req.files.length; i++) {
        uploads.push({
          id: parseInt(templateIds[i]),
          file: req.files[i]
        });
      }

      // Upload all files and update templates
      const results = [];
      const errors = [];

      for (const upload of uploads) {
        try {
          // Check if template exists
          const checkQuery = `SELECT * FROM monthly_meeting_template WHERE id = ? AND isDeleted = 0`;
          const existingTemplate = await connection.query(checkQuery, [upload.id]);

          if (existingTemplate.length === 0) {
            errors.push({
              templateId: upload.id,
              error: "Template not found"
            });
            continue;
          }

          // Upload file to Azure storage
          const fileUploadLink = await uploadFile(upload.file);
          if (!fileUploadLink) {
            errors.push({
              templateId: upload.id,
              error: "Failed to upload file"
            });
            continue;
          }

          // Update template with upload file link
          const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
          const updateQuery = `UPDATE monthly_meeting_template SET upload_fileLink = ?, updatedOn = ? WHERE id = ? AND isDeleted = 0`;
          await connection.query(updateQuery, [fileUploadLink, updatedOn, upload.id]);

          results.push({
            templateId: upload.id,
            upload_fileLink: fileUploadLink,
            status: "success"
          });
        } catch (error) {
          errors.push({
            templateId: upload.id,
            error: error.message
          });
        }
      }

      if (results.length === 0) {
        return res.status(400).send({
          status: false,
          message: "All uploads failed!",
          errors: errors
        });
      }

      return res.status(200).send({
        status: true,
        message: `Successfully uploaded ${results.length} out of ${uploads.length} file(s)!`,
        data: {
          successful: results,
          failed: errors
        }
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  deleteMonthlyMeetingTemplate: async function (req, res) {
    try {
      const { id } = req.params;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Check if monthly meeting template exists before deletion
      const checkQuery = `SELECT * FROM monthly_meeting_template WHERE id = ? AND isDeleted = 0`;
      const existingTemplate = await connection.query(checkQuery, [id]);

      if (existingTemplate.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Monthly meeting template not found!"
        });
      }

      // Soft delete: set isDeleted to 1
      const deleteQuery = `UPDATE monthly_meeting_template SET isDeleted = 1 WHERE id = ?`;
      const deletedResult = await connection.query(deleteQuery, [id]);

      return res.status(200).send({
        status: true,
        message: "Monthly meeting template deleted successfully!",
        data: deletedResult
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  }
};
