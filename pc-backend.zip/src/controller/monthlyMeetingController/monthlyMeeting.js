const { connection } = require("../../mySql/mySql");
const moment = require('moment-timezone');
const { uploadFile } = require("../azurestorage/fileUpload");
const { monthlyMeetingMail, monthlyMeetingUpdateMail, monthlyMeetingStatusMail } = require("../other/eMailer");
const { createNotification } = require("../notification/notification.controller");

// Helper function to parse JSON arrays safely
function parseJsonArray(jsonData) {
  if (!jsonData || jsonData === null || jsonData === 'null' || jsonData === '') {
    return [];
  }

  try {
    if (Array.isArray(jsonData)) {
      return jsonData;
    } else {
      return JSON.parse(jsonData);
    }
  } catch (error) {
    return [];
  }
}

// Helper function to handle the creation of meeting sequences (one-time or recurring)
async function handleMeetingCreation(body, createdBy, agenda_link) {
  const {
    market_area_id,
    dealer_id,
    meeting_date,
    start_time,
    end_time,
    recurring_meeting,
    meeting_mode,
    meeting_venue,
    meet_link,
    agenda_text,
    next_meeting_date, // This might be used for single meeting, but series calculates its own
    limit_date,
    dealerUserIds,
    volvoUserIds,
    externalEmails,
    optionalEmails
  } = body;

  let is_reoccuring = (recurring_meeting === 'One-time Meeting') ? 0 : 1;

  // 1. Generate Meeting Dates for Recurring Series
  const meetingDates = [];
  const currentMeetingDate = moment(meeting_date);
  meetingDates.push(currentMeetingDate.format('YYYY-MM-DD'));

  if (is_reoccuring && limit_date) {
    const limitDateObj = moment(limit_date);
    const frequencyMap = {
      'Monthly': 1,
      'Quarterly': 3,
      'Half Yearly': 6,
      'Annually': 12
    };

    const interval = frequencyMap[recurring_meeting];
    if (interval) {
      let nextDate = moment(currentMeetingDate).add(interval, 'months');
      while (nextDate.isSameOrBefore(limitDateObj)) {
        meetingDates.push(nextDate.format('YYYY-MM-DD'));
        nextDate = moment(nextDate).add(interval, 'months');
      }
    }
  }

  const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
  const status = 'Created';

  // Parse emails once
  const externalEmailsArray = parseJsonArray(externalEmails);
  const optionalEmailsArray = parseJsonArray(optionalEmails);
  const externalEmailsJson = JSON.stringify(externalEmailsArray);
  const optionalEmailsJson = JSON.stringify(optionalEmailsArray);

  // Parse user mappings once
  const dealerUserIdsArray = parseJsonArray(dealerUserIds);
  const volvoUserIdsArray = parseJsonArray(volvoUserIds);

  const createdMeetingIds = [];

  // 2. Iterate and create each meeting in the series
  for (let i = 0; i < meetingDates.length; i++) {
    const current_date = meetingDates[i];

    // Calculate next_meeting_date for this specific occurrence
    let current_next_meeting_date = null;
    if (i < meetingDates.length - 1) {
      current_next_meeting_date = meetingDates[i + 1];
    } else if (is_reoccuring && recurring_meeting !== 'One-time Meeting') {
      // For the last one in the series, suggest the next potential one even if it's after limit_date
      const frequencyMap = { 'Monthly': 1, 'Quarterly': 3, 'Half Yearly': 6, 'Annually': 12 };
      const interval = frequencyMap[recurring_meeting];
      if (interval) {
        current_next_meeting_date = moment(current_date).add(interval, 'months').format('YYYY-MM-DD');
      }
    }

    const query = `
      INSERT INTO monthly_meeting 
      (created_by, market_area_id, dealer_id, meeting_date, start_time, end_time, recurring_meeting, meeting_mode, meeting_link, meeting_venue, agenda_text, agenda_file_url, external_emails, optional_emails, status, createdOn, is_reoccuring, next_meeting_date, limit_date) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const insertResult = await connection.query(query, [
      createdBy, market_area_id, dealer_id, current_date, start_time, end_time, recurring_meeting,
      meeting_mode, meet_link, meeting_venue, agenda_text, agenda_link, externalEmailsJson,
      optionalEmailsJson, status, createdOn, is_reoccuring, current_next_meeting_date, limit_date
    ]);

    const createdId = insertResult.insertId;
    createdMeetingIds.push(createdId);

    // 3. Insert user mappings for EACH created meeting
    const mappingCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

    // Dealer users
    if (dealerUserIdsArray.length > 0) {
      const dealerMappingValues = dealerUserIdsArray.map(user_id => [createdId, user_id, mappingCreatedOn]);
      await connection.query(
        `INSERT INTO meeting_dealeruser_mapping(meeting_id, user_id, createdOn) VALUES ?`,
        [dealerMappingValues]
      );
    }

    // Volvo users
    if (volvoUserIdsArray.length > 0) {
      const volvoMappingValues = volvoUserIdsArray.map(user_id => [createdId, user_id, mappingCreatedOn]);
      await connection.query(
        `INSERT INTO meeting_volvouser_mapping(meeting_id, user_id, createdOn) VALUES ?`,
        [volvoMappingValues]
      );
    }
  }
  return createdMeetingIds;
}

module.exports = {

  addMonthlyMeeting: async function (req, res) {
    try {
      const {
        market_area_id,
        dealer_id,
        meeting_date,
        start_time,
        end_time,
        recurring_meeting,
        meeting_mode,
        meeting_venue,
        meet_link
      } = req.body;

      const createdBy = req.decodedToken;
      let agenda_link = req.body.agenda_link;

      const files = req.files;
      if (files && files.length > 0) {
        agenda_link = await uploadFile(files[0]);
        if (!agenda_link) {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
        console.log("blobUrl", agenda_link);
      }

      // Validate required fields
      if (!market_area_id || !createdBy || !dealer_id || !meeting_date || !start_time || !end_time || !meeting_mode || (!meeting_venue && !meet_link)) {
        return res.status(400).send({
          status: false,
          message: "All required fields (market_area_id, dealer_id, meeting_date, start_time, end_time, meeting_mode, and at least one of venue or meet_link) must be provided!"
        });
      }

      // Use helper to handle recurring meeting sequence creation
      const createdMeetingIds = await handleMeetingCreation(req.body, createdBy, agenda_link);

      // Handle Notifications and Emails for the first meeting
      if (createdMeetingIds.length > 0) {
        const firstMeetingId = createdMeetingIds[0];
        const dealerUserIdsArray = parseJsonArray(req.body.dealerUserIds);
        const volvoUserIdsArray = parseJsonArray(req.body.volvoUserIds);
        const externalEmailsArray = parseJsonArray(req.body.externalEmails);
        const optionalEmailsArray = parseJsonArray(req.body.optionalEmails);

        const allUserIds = [...dealerUserIdsArray, ...volvoUserIdsArray];
        if (allUserIds.length > 0) {
          const notificationTitle = "New Monthly Meeting Series Scheduled";
          const notificationMessage = `A new ${recurring_meeting.toLowerCase()} meeting series has been scheduled starting from ${meeting_date}. ${createdMeetingIds.length} meetings created.`;
          createNotification(notificationTitle, notificationMessage, allUserIds).catch(err => {
            console.error("Error creating notification for monthly meeting series:", err);
          });
        }

        const allEmails = [];
        if (dealerUserIdsArray.length > 0) {
          const placeholders = dealerUserIdsArray.map(() => '?').join(',');
          const dealerUserEmails = await connection.query(`SELECT email FROM userdetails WHERE id IN (${placeholders}) AND email IS NOT NULL`, dealerUserIdsArray);
          dealerUserEmails.forEach(u => u.email && !allEmails.includes(u.email) && allEmails.push(u.email));
        }
        if (volvoUserIdsArray.length > 0) {
          const placeholders = volvoUserIdsArray.map(() => '?').join(',');
          const volvoUserEmails = await connection.query(`SELECT email FROM userdetails WHERE id IN (${placeholders}) AND email IS NOT NULL`, volvoUserIdsArray);
          volvoUserEmails.forEach(u => u.email && !allEmails.includes(u.email) && allEmails.push(u.email));
        }
        externalEmailsArray.forEach(e => e && !allEmails.includes(e) && allEmails.push(e));
        optionalEmailsArray.forEach(e => e && !allEmails.includes(e) && allEmails.push(e));

        if (allEmails.length > 0) {
          const creatorInfo = await connection.query(`SELECT firstName, lastName FROM userdetails WHERE id = ?`, [createdBy]);
          const creatorName = creatorInfo.length > 0 ? `${creatorInfo[0].firstName} ${creatorInfo[0].lastName || ''}`.trim() : 'Partner Connect Team';
          const dealerInfo = await connection.query(`SELECT dealerName FROM dealer_master WHERE id = ?`, [dealer_id]);
          const dealerName = dealerInfo.length > 0 ? dealerInfo[0].dealerName : '';
          const marketAreaInfo = await connection.query(`SELECT marketarea FROM market_area WHERE id = ?`, [market_area_id]);
          const marketAreaName = marketAreaInfo.length > 0 ? marketAreaInfo[0].marketarea : '';

          const meetingDetails = {
            id: firstMeetingId,
            meeting_date,
            start_time,
            end_time,
            meeting_mode,
            meeting_venue: meeting_venue || '',
            meet_link: meet_link || '',
            agenda_text: req.body.agenda_text || '',
            agenda_link: agenda_link || '',
            dealer_name: dealerName,
            market_area: marketAreaName,
            recurring_meeting: recurring_meeting || false
          };

          monthlyMeetingMail(creatorName, allEmails, meetingDetails).catch(err => {
            console.error('Error sending monthly meeting emails:', err);
          });
        }
      }

      return res.status(200).send({
        status: true,
        message: `${createdMeetingIds.length} Monthly Meeting(s) added successfully!`
      });
    } catch (error) {
      console.error("Error in addMonthlyMeeting:", error);
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // getAllMonthlyMeetings: async function (req, res) {
  //   try {
  //     // Get all monthly meetings with proper joins
  //     const meetingQuery = `
  //       SELECT 
  //         mm.id,
  //         mm.created_by,
  //         mm.market_area_id,
  //         mm.dealer_id,
  //         mm.meeting_date,
  //         mm.start_time,
  //         mm.end_time,
  //         mm.recurring_meeting,
  //         mm.meeting_mode,
  //         mm.meeting_link,
  //         mm.meeting_venue,
  //         mm.agenda_text,
  //         mm.agenda_file_url,
  //         mm.isDeleted,
  //         mm.createdOn,
  //         mm.external_emails,
  //         mm.optional_emails,
  //         mm.status,
  //         mm.cancelled_by,
  //         mm.cancellation_reason,
  //         mm.cancellation_timestamp,
  //         ma.marketarea,
  //         dm.dealerName as dealer_name,
  //         um.firstName as created_by_name,
  //         cancelled_by_user.firstName as cancelled_by_name
  //       FROM monthly_meeting mm 
  //       LEFT JOIN market_area ma ON mm.market_area_id = ma.id 
  //       LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id 
  //       LEFT JOIN userdetails um ON mm.created_by = um.id
  //       LEFT JOIN userdetails cancelled_by_user ON mm.cancelled_by = cancelled_by_user.id
  //       WHERE mm.isDeleted = 0 
  //       ORDER BY mm.meeting_date DESC, mm.start_time DESC
  //     `;
  //     const meetingData = await connection.query(meetingQuery);

  //     if (meetingData.length === 0) {
  //       return res.status(200).send({ 
  //         status: true, 
  //         message: "No monthly meetings found", 
  //         data: [] 
  //       });
  //     }

  //     // Get dealer user mappings for all meetings
  //     const dealerUserQuery = `
  //       SELECT 
  //         mdum.meeting_id,
  //         um.firstName as dealer_user_name,
  //         um.id as dealer_user_id
  //       FROM meeting_dealeruser_mapping mdum
  //       LEFT JOIN userdetails um ON mdum.user_id = um.id
  //       WHERE mdum.meeting_id IN (${meetingData.map(m => m.id).join(',')})
  //     `;
  //     const dealerUserData = await connection.query(dealerUserQuery);

  //     // Get volvo user mappings for all meetings
  //     const volvoUserQuery = `
  //       SELECT 
  //         mvum.meeting_id,
  //         um.firstName as volvo_user_name,
  //         um.id as volvo_user_id
  //       FROM meeting_volvouser_mapping mvum
  //       LEFT JOIN userdetails um ON mvum.user_id = um.id
  //       WHERE mvum.meeting_id IN (${meetingData.map(m => m.id).join(',')})
  //     `;
  //     const volvoUserData = await connection.query(volvoUserQuery);

  //     // Group mappings by meeting_id
  //     const dealerUserMap = {};
  //     dealerUserData.forEach(user => {
  //       if (!dealerUserMap[user.meeting_id]) {
  //         dealerUserMap[user.meeting_id] = [];
  //       }
  //       dealerUserMap[user.meeting_id].push({
  //         user_id: user.dealer_user_id,
  //         user_name: user.dealer_user_name
  //       });
  //     });

  //     const volvoUserMap = {};
  //     volvoUserData.forEach(user => {
  //       if (!volvoUserMap[user.meeting_id]) {
  //         volvoUserMap[user.meeting_id] = [];
  //       }
  //       volvoUserMap[user.meeting_id].push({
  //         user_id: user.volvo_user_id,
  //         user_name: user.volvo_user_name
  //       });
  //     });

  //     // Combine meeting data with all mappings
  //     const result = meetingData.map(meeting => {
  //       let external_emails = [];
  //       let optional_emails = [];

  //       external_emails = parseJsonArray(meeting.external_emails);
  //       optional_emails = parseJsonArray(meeting.optional_emails);

  //       return {
  //         ...meeting,
  //         dealer_users: dealerUserMap[meeting.id] || [],
  //         volvo_users: volvoUserMap[meeting.id] || [],
  //         external_emails,
  //         optional_emails
  //       };
  //     });

  //     return res.status(200).send({ 
  //       status: true, 
  //       message: "Monthly meetings retrieved successfully", 
  //       data: result 
  //     });
  //   } catch (error) {
  //     return res.status(500).send({ 
  //       status: false, 
  //       message: error.message 
  //     });
  //   }
  // },
  getAllMonthlyMeetings: async function (req, res) {
    try {
      // Extract userId from decoded token
      const userId = req.decodedToken;

      if (!userId) {
        return res.status(401).send({ status: false, message: "User not authenticated" });
      }

      // Fetch user persona and marketArea from userdetails table
      const userQuery = `
        SELECT persona, marketArea 
        FROM userdetails 
        WHERE id = ?
      `;
      const userResult = await connection.query(userQuery, [userId]);

      if (userResult.length === 0) {
        return res.status(404).send({ status: false, message: "User not found" });
      }

      const userPersona = userResult[0].persona;
      let userMarketArea = userResult[0].marketArea;

      // Debug logging
      console.log(`[getAllMonthlyMeetings] User ID: ${userId}`);
      console.log(`[getAllMonthlyMeetings] User Persona: "${userPersona}"`);
      console.log(`[getAllMonthlyMeetings] User Market Area (raw): ${userMarketArea}`);

      // If marketArea is a string (name), convert it to ID
      if (userMarketArea && isNaN(userMarketArea)) {
        const marketAreaQuery = `
          SELECT id FROM market_area WHERE marketarea = ?
        `;
        const marketAreaResult = await connection.query(marketAreaQuery, [userMarketArea]);
        if (marketAreaResult.length > 0) {
          userMarketArea = marketAreaResult[0].id;
          console.log(`[getAllMonthlyMeetings] Converted Market Area name to ID: ${userMarketArea}`);
        } else {
          console.log(`[getAllMonthlyMeetings] WARNING: Market Area "${userMarketArea}" not found in market_area table`);
          userMarketArea = null;
        }
      }
      // Define personas with full access (can see all monthly meetings)
      // TODO: Update this array based on actual business requirements
      const fullAccessPersonas = [
        'Administrator',
        'Volvo Functional Manager',
        'IMT',
        'Head of Channel Development Region India'
      ];

      // Define personas with restricted access (can only see monthly meetings for their mapped dealers OR where they are participants)
      // TODO: Update this array based on actual business requirements
      const restrictedAccessPersonas = [
        'Dealer Parts Manager',
        'Dealer Coordinator',
        'Dealer sales head',
        'Dealer CST Head',
        'Dealer Finance Head',
        'Dealer HR Head',
        'Dealer Principal',
        'Dealer CEO'
      ];

      // Define personas with market area restriction (can see monthly meetings for mapped dealers OR their market area OR where they are participants)
      const restrictedMarketArea = [
        'Uptime & Parts Manager',
        'Retail Sales Manager',
        'Key Account Manager Uptime & Parts',
        'Key Account Manager Sales',
        'Market Area Head'
      ];

      let meetingQuery;
      let queryParams = [];

      if (fullAccessPersonas.includes(userPersona)) {
        console.log(`[getAllMonthlyMeetings] Access Level: Full Access`);
        // User has full access - fetch all monthly meetings
        meetingQuery = `
        SELECT 
            mm.id,
            mm.created_by,
            mm.market_area_id,
            mm.dealer_id,
            mm.meeting_date,
            mm.start_time,
            mm.end_time,
            mm.recurring_meeting,
            mm.meeting_mode,
            mm.meeting_link,
            mm.meeting_venue,
            mm.agenda_text,
            mm.agenda_file_url,
            mm.isDeleted,
            mm.createdOn,
            mm.external_emails,
            mm.optional_emails,
            mm.status,
            mm.cancelled_by,
            mm.cancellation_reason,
            mm.cancellation_timestamp,
            mm.is_reoccuring,
            mm.next_meeting_date,
            mm.limit_date,
            ma.marketarea,
            dm.dealerName as dealer_name,
            um.firstName as created_by_name,
            cancelled_by_user.firstName as cancelled_by_name
          FROM monthly_meeting mm 
          LEFT JOIN market_area ma ON mm.market_area_id = ma.id 
          LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id 
          LEFT JOIN userdetails um ON mm.created_by = um.id
          LEFT JOIN userdetails cancelled_by_user ON mm.cancelled_by = cancelled_by_user.id
          WHERE mm.isDeleted = 0
        `;
      } else if (restrictedMarketArea.includes(userPersona)) {
        console.log(`[getAllMonthlyMeetings] Access Level: Market Area Restricted`);
        console.log(`[getAllMonthlyMeetings] Query Params: marketArea=${userMarketArea}, userId=${userId}`);
        // User has market area restriction - fetch monthly meetings for their market area OR mapped dealers OR where they are participants OR they created
        meetingQuery = `
          SELECT DISTINCT
            mm.id,
            mm.created_by,
            mm.market_area_id,
            mm.dealer_id,
            mm.meeting_date,
            mm.start_time,
            mm.end_time,
            mm.recurring_meeting,
            mm.meeting_mode,
            mm.meeting_link,
            mm.meeting_venue,
            mm.agenda_text,
            mm.agenda_file_url,
            mm.isDeleted,
            mm.createdOn,
            mm.external_emails,
            mm.optional_emails,
            mm.status,
            mm.cancelled_by,
            mm.cancellation_reason,
            mm.cancellation_timestamp,
            mm.is_reoccuring,
            mm.next_meeting_date,
            mm.limit_date,
            ma.marketarea,
            dm.dealerName as dealer_name,
            um.firstName as created_by_name,
            cancelled_by_user.firstName as cancelled_by_name
          FROM monthly_meeting mm 
          LEFT JOIN market_area ma ON mm.market_area_id = ma.id 
          LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id 
          LEFT JOIN userdetails um ON mm.created_by = um.id
          LEFT JOIN userdetails cancelled_by_user ON mm.cancelled_by = cancelled_by_user.id
          LEFT JOIN meeting_dealeruser_mapping mdum ON mm.id = mdum.meeting_id
          LEFT JOIN meeting_volvouser_mapping mvum ON mm.id = mvum.meeting_id
          WHERE mm.isDeleted = 0 
            AND (
              mm.market_area_id = ? 
              OR mm.dealer_id IN (SELECT dealerId FROM userdealers WHERE userId = ?)
              OR mdum.user_id = ?
              OR mvum.user_id = ?
              OR mm.created_by = ?
            )
        `;
        queryParams = [userMarketArea, userId, userId, userId, userId];
      } else if (restrictedAccessPersonas.includes(userPersona)) {
        console.log(`[getAllMonthlyMeetings] Access Level: Dealer Restricted`);
        // User has restricted access - fetch only monthly meetings for mapped dealers OR where they are participants OR they created
        meetingQuery = `
          SELECT DISTINCT
            mm.id,
            mm.created_by,
            mm.market_area_id,
            mm.dealer_id,
            mm.meeting_date,
            mm.start_time,
            mm.end_time,
            mm.recurring_meeting,
            mm.meeting_mode,
            mm.meeting_link,
            mm.meeting_venue,
            mm.agenda_text,
            mm.agenda_file_url,
            mm.isDeleted,
            mm.createdOn,
            mm.external_emails,
            mm.optional_emails,
            mm.status,
            mm.cancelled_by,
            mm.cancellation_reason,
            mm.cancellation_timestamp,
            mm.is_reoccuring,
            mm.next_meeting_date,
            mm.limit_date,
            ma.marketarea,
            dm.dealerName as dealer_name,
            um.firstName as created_by_name,
            cancelled_by_user.firstName as cancelled_by_name
          FROM monthly_meeting mm 
          LEFT JOIN market_area ma ON mm.market_area_id = ma.id 
          LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id 
          LEFT JOIN userdetails um ON mm.created_by = um.id
          LEFT JOIN userdetails cancelled_by_user ON mm.cancelled_by = cancelled_by_user.id
          LEFT JOIN meeting_dealeruser_mapping mdum ON mm.id = mdum.meeting_id
          LEFT JOIN meeting_volvouser_mapping mvum ON mm.id = mvum.meeting_id
          WHERE mm.isDeleted = 0 
            AND (
              mm.dealer_id IN (SELECT dealerId FROM userdealers WHERE userId = ?)
              OR mdum.user_id = ?
              OR mvum.user_id = ?
              OR mm.created_by = ?
            )
        `;
        queryParams = [userId, userId, userId, userId];
      } else {
        console.log(`[getAllMonthlyMeetings] Access Level: DENIED - Unknown persona`);
        // Unknown persona - no access
        return res.status(403).send({
          status: false,
          message: "Access denied: Your persona does not have permission to view monthly meetings"
        });
      }

      const meetingData = await connection.query(meetingQuery, queryParams);

      console.log(`[getAllMonthlyMeetings] Query returned ${meetingData.length} monthly meetings`);

      if (meetingData.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No monthly meetings found",
          data: []
        });
      }

      // Get dealer user mappings for all meetings
      const dealerUserQuery = `
        SELECT 
          mdum.meeting_id,
          um.firstName as dealer_user_name,
          um.id as dealer_user_id
        FROM meeting_dealeruser_mapping mdum
        LEFT JOIN userdetails um ON mdum.user_id = um.id
        WHERE mdum.meeting_id IN (${meetingData.map(m => m.id).join(',')})
      `;
      const dealerUserData = await connection.query(dealerUserQuery);

      // Get volvo user mappings for all meetings
      const volvoUserQuery = `
        SELECT 
          mvum.meeting_id,
          um.firstName as volvo_user_name,
          um.id as volvo_user_id
        FROM meeting_volvouser_mapping mvum
        LEFT JOIN userdetails um ON mvum.user_id = um.id
        WHERE mvum.meeting_id IN (${meetingData.map(m => m.id).join(',')})
      `;
      const volvoUserData = await connection.query(volvoUserQuery);

      // Group mappings by meeting_id
      const dealerUserMap = {};
      dealerUserData.forEach(user => {
        if (!dealerUserMap[user.meeting_id]) {
          dealerUserMap[user.meeting_id] = [];
        }
        dealerUserMap[user.meeting_id].push({
          user_id: user.dealer_user_id,
          user_name: user.dealer_user_name
        });
      });

      const volvoUserMap = {};
      volvoUserData.forEach(user => {
        if (!volvoUserMap[user.meeting_id]) {
          volvoUserMap[user.meeting_id] = [];
        }
        volvoUserMap[user.meeting_id].push({
          user_id: user.volvo_user_id,
          user_name: user.volvo_user_name
        });
      });

      // Combine meeting data with all mappings
      const result = meetingData.map(meeting => {
        let external_emails = [];
        let optional_emails = [];

        external_emails = parseJsonArray(meeting.external_emails);
        optional_emails = parseJsonArray(meeting.optional_emails);

        return {
          ...meeting,
          dealer_users: dealerUserMap[meeting.id] || [],
          volvo_users: volvoUserMap[meeting.id] || [],
          external_emails,
          optional_emails
        };
      });

      return res.status(200).send({
        status: true,
        message: "Monthly meetings retrieved successfully",
        data: result
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  updateMonthlyMeeting: async function (req, res) {
    try {
      // const {
      let {
        id,
        market_area_id,
        dealer_id,
        meeting_date,
        start_time,
        end_time,
        recurring_meeting,
        dealerUserIds,
        volvoUserIds,
        externalEmails,
        optionalEmails,
        meeting_mode,
        meeting_venue,
        meet_link,
        agenda_text,
        agenda_link,
        status,
        cancellation_reason,
        next_meeting_date,
        limit_date
      } = req.body;

      let is_reoccuring = (recurring_meeting === 'One-time Meeting') ? 0 : 1;

      let createdBy = req.decodedToken;

      // Validate required fields - for cancellation or completion, only id and status are required
      const isStatusOnlyUpdate = status === 'Cancelled' || status === 'Completed';

      if (!id || !createdBy) {
        return res.status(400).send({
          status: false,
          message: "ID and authentication token are required!"
        });
      }

      // If not a status-only update, validate all other required fields
      if (!isStatusOnlyUpdate) {
        if (
          !market_area_id ||
          !dealer_id ||
          !meeting_date ||
          !start_time ||
          !end_time ||
          !meeting_mode ||
          (!meeting_venue && !meet_link)
        ) {
          return res.status(400).send({
            status: false,
            message: "All required fields (market_area_id, dealer_id, meeting_date, start_time, end_time, meeting_mode, and at least one of venue or meet_link) must be provided!"
          });
        }
      }
      const files = req.files;
      if (files && files.length > 0) {
        const file = files[0]; // Get the first file
        agenda_link = await uploadFile(file);
        if (!agenda_link) {
          return res.status(400).send({ status: false, message: "Failed to upload file!" });
        }
      }
      // Check if monthly meeting exists and get old meeting data
      console.log("Update Controller: Starting update process");
      const checkQuery = `
        SELECT 
          mm.*,
          dm.dealerName as dealer_name,
          ma.marketarea as market_area
        FROM monthly_meeting mm
        LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id
        LEFT JOIN market_area ma ON mm.market_area_id = ma.id
        WHERE mm.id = ? AND mm.isDeleted = 0
      `;
      const existingMeeting = await connection.query(checkQuery, [id]);

      if (existingMeeting.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Monthly Meeting not found!"
        });
      }

      const oldMeeting = existingMeeting[0];
      console.log("Update Controller: Old meeting found, isStatusOnlyUpdate:", isStatusOnlyUpdate);

      // // Check for duplicate monthly meeting (excluding current id)
      // const validateQuery = `
      //   SELECT * FROM monthly_meeting 
      //   WHERE market_area_id = ? AND meeting_date = ? AND created_by = ? AND start_time = ? AND id != ? AND isDeleted = 0
      // `;
      // const validateData = await connection.query(validateQuery, [market_area_id, meeting_date, createdBy, start_time, id]);

      // if (validateData.length !== 0) {
      //   return res.status(400).send({ 
      //     status: false, 
      //     message: "Monthly Meeting already exists with these details!" 
      //   });
      // }

      // Parse email arrays if they come as JSON strings
      const externalEmailsArray = parseJsonArray(externalEmails);
      const optionalEmailsArray = parseJsonArray(optionalEmails);

      const externalEmailsJson = JSON.stringify(externalEmailsArray);
      const optionalEmailsJson = JSON.stringify(optionalEmailsArray);

      let updatedResult;

      // Handle status-only updates separately (Cancelled or Completed)
      if (isStatusOnlyUpdate) {
        console.log("Update Controller: Status-only update -", status);

        if (status === 'Cancelled') {
          // When cancelling, only update status and cancellation fields
          const cancellationTimestamp = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
          const updateCancellationQuery = `
            UPDATE monthly_meeting 
            SET status = ?, cancelled_by = ?, cancellation_reason = ?, cancellation_timestamp = ?
            WHERE id = ? AND isDeleted = 0
          `;
          updatedResult = await connection.query(updateCancellationQuery, [
            status, createdBy, cancellation_reason || null, cancellationTimestamp, id
          ]);
        } else if (status === 'Completed') {
          // When completing, only update status
          const updateCompletionQuery = `
            UPDATE monthly_meeting 
            SET status = ?
            WHERE id = ? AND isDeleted = 0
          `;
          updatedResult = await connection.query(updateCompletionQuery, [
            status, id
          ]);
        }

        // Collect all emails for status notification
        console.log("Update Controller: Collecting emails for status update");
        const allEmails = [];

        // Get dealer user IDs from existing mappings
        const dealerUserMappings = await connection.query(
          `SELECT user_id FROM meeting_dealeruser_mapping WHERE meeting_id = ?`,
          [id]
        );
        const dealerUserIds = dealerUserMappings.map(m => m.user_id);

        // Get volvo user IDs from existing mappings
        const volvoUserMappings = await connection.query(
          `SELECT user_id FROM meeting_volvouser_mapping WHERE meeting_id = ?`,
          [id]
        );
        const volvoUserIds = volvoUserMappings.map(m => m.user_id);

        // Fetch emails from dealer users
        if (dealerUserIds.length > 0) {
          const placeholders = dealerUserIds.map(() => '?').join(',');
          const dealerUserEmails = await connection.query(
            `SELECT email FROM userdetails WHERE id IN (${placeholders}) AND email IS NOT NULL`,
            dealerUserIds
          );
          dealerUserEmails.forEach(user => {
            if (user.email && !allEmails.includes(user.email)) {
              allEmails.push(user.email);
            }
          });
        }

        // Fetch emails from volvo users
        if (volvoUserIds.length > 0) {
          const placeholders = volvoUserIds.map(() => '?').join(',');
          const volvoUserEmails = await connection.query(
            `SELECT email FROM userdetails WHERE id IN (${placeholders}) AND email IS NOT NULL`,
            volvoUserIds
          );
          volvoUserEmails.forEach(user => {
            if (user.email && !allEmails.includes(user.email)) {
              allEmails.push(user.email);
            }
          });
        }

        // Parse and add external emails from old meeting
        const oldExternalEmailsArray = parseJsonArray(oldMeeting.external_emails);
        oldExternalEmailsArray.forEach(email => {
          if (email && typeof email === 'string' && !allEmails.includes(email)) {
            allEmails.push(email);
          }
        });

        // Parse and add optional emails from old meeting
        const oldOptionalEmailsArray = parseJsonArray(oldMeeting.optional_emails);
        oldOptionalEmailsArray.forEach(email => {
          if (email && typeof email === 'string' && !allEmails.includes(email)) {
            allEmails.push(email);
          }
        });

        console.log("Update Controller: Status update emails collected:", allEmails);

        // Send status emails if there are any emails
        if (allEmails.length > 0) {
          // Get creator name for email
          const creatorInfo = await connection.query(
            `SELECT firstName, lastName FROM userdetails WHERE id = ?`,
            [createdBy]
          );
          const creatorName = creatorInfo.length > 0
            ? `${creatorInfo[0].firstName} ${creatorInfo[0].lastName || ''}`.trim()
            : 'Partner Connect Team';

          // Prepare meeting details for status email
          const meetingDetails = {
            id: oldMeeting.id,
            meeting_date: oldMeeting.meeting_date,
            start_time: oldMeeting.start_time,
            end_time: oldMeeting.end_time,
            meeting_mode: oldMeeting.meeting_mode,
            meeting_venue: oldMeeting.meeting_venue || '',
            meet_link: oldMeeting.meeting_link || '',
            agenda_text: oldMeeting.agenda_text || '',
            agenda_link: oldMeeting.agenda_file_url || '',
            dealer_name: oldMeeting.dealer_name || '',
            market_area: oldMeeting.market_area || '',
            recurring_meeting: oldMeeting.recurring_meeting || false
          };

          // Send status emails asynchronously (don't wait for completion)
          monthlyMeetingStatusMail(creatorName, allEmails, meetingDetails, status, cancellation_reason || null).catch(err => {
            console.error('Error sending monthly meeting status emails:', err);
          });
        }

        // Create notification for status change (Cancelled/Completed)
        const allUserIdsForStatus = [...dealerUserIds, ...volvoUserIds];
        if (allUserIdsForStatus.length > 0) {
          const notificationTitle = `Monthly Meeting ${status}`;
          const notificationMessage = status === 'Cancelled'
            ? `Monthly meeting scheduled for ${oldMeeting.meeting_date} has been cancelled.${cancellation_reason ? ` Reason: ${cancellation_reason}` : ''} Meeting ID: ${id}`
            : `Monthly meeting scheduled for ${oldMeeting.meeting_date} has been marked as completed. Meeting ID: ${id}`;
          createNotification(notificationTitle, notificationMessage, allUserIdsForStatus).catch(err => {
            console.error("Error creating notification for monthly meeting status update:", err);
          });
        }
      } else {
        // Regular update - update all fields including status if provided
        // Use old meeting's agenda_file_url if no new file is uploaded
        const finalAgendaLink = agenda_link || oldMeeting.agenda_file_url || null;
        console.log("Update Controller: Regular update, agenda_link:", finalAgendaLink);

        const updateQuery = `
          UPDATE monthly_meeting 
          SET created_by = ?, market_area_id = ?, dealer_id = ?, meeting_date = ?, start_time = ?, end_time = ?, 
              recurring_meeting = ?, meeting_mode = ?, meeting_link = ?, meeting_venue = ?, agenda_text = ?, agenda_file_url = ?, external_emails = ?, optional_emails = ?, status = COALESCE(?, status), is_reoccuring = ?, next_meeting_date = ?, limit_date = ?
          WHERE id = ? AND isDeleted = 0
        `;
        updatedResult = await connection.query(updateQuery, [
          createdBy, market_area_id, dealer_id, meeting_date, start_time, end_time,
          recurring_meeting, meeting_mode, meet_link, meeting_venue, agenda_text, finalAgendaLink, externalEmailsJson, optionalEmailsJson, status || null, is_reoccuring, next_meeting_date, limit_date, id
        ]);
        console.log("Update Controller: Database update completed");
      }

      // Only update mappings if not a status-only update
      if (!isStatusOnlyUpdate) {
        console.log("Update Controller: Updating mappings");
        // Delete existing mappings
        await connection.query(`DELETE FROM meeting_dealeruser_mapping WHERE meeting_id = ?`, [id]);
        await connection.query(`DELETE FROM meeting_volvouser_mapping WHERE meeting_id = ?`, [id]);

        // Parse JSON arrays for user IDs
        const dealerUserIdsArray = parseJsonArray(dealerUserIds);
        const volvoUserIdsArray = parseJsonArray(volvoUserIds);
        console.log("Update Controller: DealerUserIds:", dealerUserIdsArray, "VolvoUserIds:", volvoUserIdsArray);

        // Insert new dealer user mappings
        const updateDealerMappingCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        for (const dealer_user of dealerUserIdsArray) {
          await connection.query(
            `INSERT INTO meeting_dealeruser_mapping(meeting_id, user_id, createdOn) VALUES (?, ?, ?)`,
            [id, dealer_user, updateDealerMappingCreatedOn]
          );
        }

        // Insert new volvo user mappings
        const updateVolvoMappingCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
        for (const volvo_user of volvoUserIdsArray) {
          await connection.query(
            `INSERT INTO meeting_volvouser_mapping(meeting_id, user_id, createdOn) VALUES (?, ?, ?)`,
            [id, volvo_user, updateVolvoMappingCreatedOn]
          );
        }

        // Collect all emails for notification
        const allEmails = [];
        console.log("Update Controller: Starting email collection");

        // Fetch emails from dealer users
        if (dealerUserIdsArray.length > 0) {
          const placeholders = dealerUserIdsArray.map(() => '?').join(',');
          const dealerUserEmails = await connection.query(
            `SELECT email FROM userdetails WHERE id IN (${placeholders}) AND email IS NOT NULL`,
            dealerUserIdsArray
          );
          dealerUserEmails.forEach(user => {
            if (user.email && !allEmails.includes(user.email)) {
              allEmails.push(user.email);
            }
          });
        }

        // Fetch emails from volvo users
        if (volvoUserIdsArray.length > 0) {
          const placeholders = volvoUserIdsArray.map(() => '?').join(',');
          const volvoUserEmails = await connection.query(
            `SELECT email FROM userdetails WHERE id IN (${placeholders}) AND email IS NOT NULL`,
            volvoUserIdsArray
          );
          volvoUserEmails.forEach(user => {
            if (user.email && !allEmails.includes(user.email)) {
              allEmails.push(user.email);
            }
          });
        }

        // Add external emails
        externalEmailsArray.forEach(email => {
          if (email && typeof email === 'string' && !allEmails.includes(email)) {
            allEmails.push(email);
          }
        });

        // Add optional emails
        optionalEmailsArray.forEach(email => {
          if (email && typeof email === 'string' && !allEmails.includes(email)) {
            allEmails.push(email);
          }
        });

        console.log("All Emails for Update Controller", allEmails);

        // Send email notifications if there are any emails
        if (allEmails.length > 0) {
          // Get creator name for email
          const creatorInfo = await connection.query(
            `SELECT firstName, lastName FROM userdetails WHERE id = ?`,
            [createdBy]
          );
          const creatorName = creatorInfo.length > 0
            ? `${creatorInfo[0].firstName} ${creatorInfo[0].lastName || ''}`.trim()
            : 'Partner Connect Team';

          // Get dealer name for email
          const dealerInfo = await connection.query(
            `SELECT dealerName FROM dealer_master WHERE id = ?`,
            [dealer_id]
          );
          const dealerName = dealerInfo.length > 0 ? dealerInfo[0].dealerName : '';

          // Get market area name
          const marketAreaInfo = await connection.query(
            `SELECT marketarea FROM market_area WHERE id = ?`,
            [market_area_id]
          );
          const marketAreaName = marketAreaInfo.length > 0 ? marketAreaInfo[0].marketarea : '';

          // Prepare old meeting details for email
          const oldMeetingDetails = {
            id: oldMeeting.id,
            meeting_date: oldMeeting.meeting_date,
            start_time: oldMeeting.start_time,
            end_time: oldMeeting.end_time,
            meeting_mode: oldMeeting.meeting_mode,
            meeting_venue: oldMeeting.meeting_venue || '',
            meet_link: oldMeeting.meeting_link || '',
            agenda_text: oldMeeting.agenda_text || '',
            agenda_link: oldMeeting.agenda_file_url || '',
            dealer_name: oldMeeting.dealer_name || '',
            market_area: oldMeeting.market_area || '',
            recurring_meeting: oldMeeting.recurring_meeting || false
          };

          // Prepare new meeting details for email
          const newMeetingDetails = {
            id: id,
            meeting_date: meeting_date,
            start_time: start_time,
            end_time: end_time,
            meeting_mode: meeting_mode,
            meeting_venue: meeting_venue || '',
            meet_link: meet_link || '',
            agenda_text: agenda_text || '',
            agenda_link: agenda_link || oldMeeting.agenda_file_url || null,
            dealer_name: dealerName,
            market_area: marketAreaName,
            recurring_meeting: recurring_meeting || false
          };

          // Send emails asynchronously (don't wait for completion)
          monthlyMeetingUpdateMail(creatorName, allEmails, oldMeetingDetails, newMeetingDetails).catch(err => {
            console.error('Error sending monthly meeting update emails:', err);
          });
        }

        // Create notification for regular meeting update
        const allUserIdsForUpdate = [...dealerUserIdsArray, ...volvoUserIdsArray];
        if (allUserIdsForUpdate.length > 0) {
          const notificationTitle = "Monthly Meeting Updated";
          const notificationMessage = `Monthly meeting has been updated. New date: ${meeting_date}, Time: ${start_time} to ${end_time}. Meeting ID: ${id}`;
          createNotification(notificationTitle, notificationMessage, allUserIdsForUpdate).catch(err => {
            console.error("Error creating notification for monthly meeting update:", err);
          });
        }
      }

      return res.status(200).send({
        status: true,
        message: "Monthly Meeting updated successfully!",
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  deleteMonthlyMeeting: async function (req, res) {
    try {
      const { id } = req.params;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Check if monthly meeting exists before deletion
      const checkQuery = `SELECT * FROM monthly_meeting WHERE id = ? AND isDeleted = 0`;
      const existingMeeting = await connection.query(checkQuery, [id]);

      if (existingMeeting.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Monthly Meeting not found!"
        });
      }

      // Soft delete monthly meeting
      const deleteQuery = `UPDATE monthly_meeting SET isDeleted = 1 WHERE id = ?`;
      const updatedResult = await connection.query(deleteQuery, [id]);

      // Also delete all related mappings
      await connection.query(`DELETE FROM meeting_dealeruser_mapping WHERE meeting_id = ?`, [id]);
      await connection.query(`DELETE FROM meeting_volvouser_mapping WHERE meeting_id = ?`, [id]);

      return res.status(200).send({
        status: true,
        message: "Monthly Meeting deleted successfully!",
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getMonthlyMeetingById: async function (req, res) {
    try {
      const { id } = req.params;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Get monthly meeting with proper joins - using explicit column selection
      const meetingQuery = `
        SELECT 
          mm.id,
          mm.created_by,
          mm.market_area_id,
          mm.dealer_id,
          mm.meeting_date,
          mm.start_time,
          mm.end_time,
          mm.recurring_meeting,
          mm.meeting_mode,
          mm.meeting_link,
          mm.meeting_venue,
          mm.agenda_text,
          mm.agenda_file_url,
          mm.isDeleted,
          mm.createdOn,
          mm.external_emails,
          mm.optional_emails,
          mm.status,
          mm.cancelled_by,
          mm.cancellation_reason,
          mm.cancellation_timestamp,
          mm.is_reoccuring,
          mm.next_meeting_date,
          mm.limit_date,
          ma.marketarea,
          dm.dealerName as dealer_name,
          um.firstName as created_by_name,
          cancelled_by_user.firstName as cancelled_by_name
        FROM monthly_meeting mm 
        LEFT JOIN market_area ma ON mm.market_area_id = ma.id 
        LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id 
        LEFT JOIN userdetails um ON mm.created_by = um.id
        LEFT JOIN userdetails cancelled_by_user ON mm.cancelled_by = cancelled_by_user.id
        WHERE mm.id = ? AND mm.isDeleted = 0
      `;
      const meetingData = await connection.query(meetingQuery, [id]);

      if (meetingData.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Monthly Meeting not found!"
        });
      }

      const meeting = meetingData[0];

      // Get dealer user mappings
      const dealerUserQuery = `
        SELECT 
          um.firstName as dealer_user_name,
          um.id as dealer_user_id
        FROM meeting_dealeruser_mapping mdum
        LEFT JOIN userdetails um ON mdum.user_id = um.id
        WHERE mdum.meeting_id = ?
      `;
      const dealerUserData = await connection.query(dealerUserQuery, [id]);

      // Get volvo user mappings
      const volvoUserQuery = `
        SELECT 
          um.firstName as volvo_user_name,
          um.id as volvo_user_id
        FROM meeting_volvouser_mapping mvum
        LEFT JOIN userdetails um ON mvum.user_id = um.id
        WHERE mvum.meeting_id = ?
      `;
      const volvoUserData = await connection.query(volvoUserQuery, [id]);

      // Combine meeting data with all mappings
      let external_emails = [];
      let optional_emails = [];

      external_emails = parseJsonArray(meeting.external_emails);
      optional_emails = parseJsonArray(meeting.optional_emails);

      const result = {
        ...meeting,
        dealer_users: dealerUserData.map(user => ({
          user_id: user.dealer_user_id,
          user_name: user.dealer_user_name
        })),
        volvo_users: volvoUserData.map(user => ({
          user_id: user.volvo_user_id,
          user_name: user.volvo_user_name
        })),
        external_emails,
        optional_emails
      };

      return res.status(200).send({
        status: true,
        message: "Monthly Meeting retrieved successfully",
        data: result
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  }
};
