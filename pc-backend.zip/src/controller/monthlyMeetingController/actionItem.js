const { connection } = require("../../mySql/mySql");
const moment = require('moment-timezone');
const eMailerActionItem = require("../../controller/other/eMailerActionItemMonthlyMeeting");


module.exports = {

  addActionItem: async function (req, res) {
    try {
      let {
        monthly_meeting_id,
        department,
        topic_of_discussion,
        closure_action,
        responsibility,
        target_date,
        completed_date,
        status,
        comments,
        target_date_change,
        action_progress_update
      } = req.body;

      // Get created_by from token
      const created_by = req.decodedToken;
      console.log("created_by", created_by);

      if (created_by === responsibility) {
        return res.status(400).send({
          status: false,
          message: "Created by and Responsibility can't be same !!"
        });
      }
      // // Validate required fields for action item creation
      // if (
      //   !monthly_meeting_id ||
      //   !department ||
      //   !topic_of_discussion ||
      //   !closure_action ||
      //   !responsibility ||
      //   !target_date ||
      //   !status
      // ) {
      //   return res.status(400).send({
      //     status: false,
      //     message: "All required fields (monthly_meeting_id, department, topic_of_discussion, closure_action, responsibility, target_date, status) must be provided!"
      //   });
      // }

      // Validate status value
      const validStatuses = ['Open', 'Closed', 'In Progress'];
      if (!validStatuses.includes(status)) {
        return res.status(400).send({
          status: false,
          message: "Status must be one of: Open, Closed, In Progress"
        });
      }

      // Check if monthly meeting exists
      const meetingCheckQuery = `SELECT id FROM monthly_meeting WHERE id = ? AND isDeleted = 0`;
      const meetingExists = await connection.query(meetingCheckQuery, [monthly_meeting_id]);

      if (meetingExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Monthly meeting not found!"
        });
      }

      // Check if user exists
      const userCheckQuery = `SELECT id FROM userdetails WHERE id = ?`;
      const userExists = await connection.query(userCheckQuery, [created_by]);

      if (userExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "User not found in token!"
        });
      }

      // Check if department exists
      const deptCheckQuery = `SELECT id FROM departments WHERE id = ?`;
      const deptExists = await connection.query(deptCheckQuery, [department]);

      if (deptExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Department not found!"
        });
      }

      // Check if responsibility user exists
      const respCheckQuery = `SELECT id FROM userdetails WHERE id = ?`;
      const respExists = await connection.query(respCheckQuery, [responsibility]);

      if (respExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Responsibility user not found!"
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const query = `
        INSERT INTO action_item 
        (monthly_meeting_id, created_by, department, topic_of_discussion, closure_action, responsibility, target_date, completed_date, status, comments, target_date_change, action_progress_update, created_on, updated_on) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const insertResult = await connection.query(query, [
        monthly_meeting_id, created_by, department, topic_of_discussion,
        closure_action, responsibility, target_date, completed_date, status, comments || null,
        target_date_change !== undefined ? (target_date_change === true || target_date_change === "true" || target_date_change === 1) : false,
        action_progress_update || null,
        createdOn, createdOn
      ]);

      // Automatically create action log for the new action item
      const actionLogCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const actionLogQuery = `
        INSERT INTO action_log 
        (updated_by, action_item_id, present_status, comments, createdOn, targetDate) 
        VALUES (?, ?, ?, ?, ?, ?)
      `;

      const actionLogResult = await connection.query(actionLogQuery, [
        created_by, insertResult.insertId, status, 'Action item created', actionLogCreatedOn, target_date || null
      ]);

      // Fetch complete action item details with all joins for email
      const actionItemDetailsQuery = `
        SELECT 
          ai.id,
          ai.monthly_meeting_id,
          ai.created_on,
          ai.created_by,
          ai.department,
          ai.topic_of_discussion,
          ai.closure_action,
          ai.responsibility,
          ai.target_date,
          ai.completed_date,
          ai.status,
          ai.comments,
          ai.updated_on,
          ai.isActive,
          ai.isDeleted,
          ai.target_date_change,
          ai.action_progress_update,
          mm.id as meeting_id,
          mm.meeting_year,
          mm.created_by as meeting_created_by,
          mm.market_area_id,
          mm.dealer_id,
          mm.meeting_date,
          mm.start_time,
          mm.end_time,
          mm.meeting_mode,
          mm.meeting_venue,
          mm.meeting_link,
          d.name as department_name,
          cb.firstName as created_by_name,
          cb.lastName as created_by_lastname,
          cb.email as created_by_email,
          r.firstName as responsibility_name,
          r.lastName as responsibility_lastname,
          r.email as responsibility_email,
          mcb.firstName as meeting_created_by_name,
          mcb.lastName as meeting_created_by_lastname,
          ma.marketarea,
          dm.dealerName as dealer_name
        FROM action_item ai 
        LEFT JOIN monthly_meeting mm ON ai.monthly_meeting_id = mm.id 
        LEFT JOIN departments d ON ai.department = d.id 
        LEFT JOIN userdetails cb ON ai.created_by = cb.id 
        LEFT JOIN userdetails r ON ai.responsibility = r.id
        LEFT JOIN userdetails mcb ON mm.created_by = mcb.id
        LEFT JOIN market_area ma ON mm.market_area_id = ma.id 
        LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id
        WHERE ai.id = ? AND ai.isDeleted = 0
      `;

      const actionItemDetails = await connection.query(actionItemDetailsQuery, [insertResult.insertId]);

      // Send email notifications to responsibility and created_by users
      if (actionItemDetails.length > 0) {
        const actionItemData = actionItemDetails[0];
        const emailArray = [];

        // Add responsibility user email if available
        if (actionItemData.responsibility_email && actionItemData.responsibility_email.trim() !== '') {
          emailArray.push(actionItemData.responsibility_email);
        }

        // Add created_by user email if available and different from responsibility
        if (actionItemData.created_by_email &&
          actionItemData.created_by_email.trim() !== '' &&
          actionItemData.created_by_email !== actionItemData.responsibility_email) {
          emailArray.push(actionItemData.created_by_email);
        }

        // Send emails asynchronously (don't wait for completion to avoid blocking response)
        if (emailArray.length > 0) {
          eMailerActionItem.actionItemCreatedMail(emailArray, actionItemData)
            .then(emailResults => {
              console.log('Action item creation emails sent:', emailResults);
            })
            .catch(emailError => {
              console.error('Error sending action item creation emails:', emailError);
            });
        } else {
          console.log('No valid email addresses found for action item notification');
        }
      }

      return res.status(200).send({
        status: true,
        message: "Action Item added successfully!",
        data: {
          id: insertResult.insertId,
          action_log_id: actionLogResult.insertId
        }
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getAllActionItems: async function (req, res) {
    try {
      const userId = req.decodedToken;

      if (!userId) {
        return res.status(401).send({ status: false, message: "User not authenticated" });
      }

      // Fetch user persona and marketArea from userdetails table
      const userQuery = `
        SELECT persona, marketArea 
        FROM userdetails 
        WHERE id = ?
      `;
      const userResult = await connection.query(userQuery, [userId]);

      if (userResult.length === 0) {
        return res.status(404).send({ status: false, message: "User not found" });
      }

      const userPersona = userResult[0].persona;
      let userMarketArea = userResult[0].marketArea;

      // If marketArea is a string (name), convert it to ID
      if (userMarketArea && isNaN(userMarketArea)) {
        const marketAreaQuery = `
          SELECT id FROM market_area WHERE marketarea = ?
        `;
        const marketAreaResult = await connection.query(marketAreaQuery, [userMarketArea]);
        if (marketAreaResult.length > 0) {
          userMarketArea = marketAreaResult[0].id;
        } else {
          userMarketArea = null;
        }
      }

      const fullAccessPersonas = [
        'Administrator',
        'Volvo Functional Manager',
        'IMT',
        'Head of Channel Development Region India'
      ];

      const restrictedAccessPersonas = [
        'Dealer Parts Manager',
        'Dealer Coordinator',
        'Dealer sales head',
        'Dealer CST Head',
        'Dealer Finance Head',
        'Dealer HR Head',
        'Dealer Principal',
        'Dealer CEO'
      ];

      const restrictedMarketArea = [
        'Uptime & Parts Manager',
        'Retail Sales Manager',
        'Key Account Manager Uptime & Parts',
        'Key Account Manager Sales',
        'Market Area Head'
      ];

      const { monthly_meeting_id, status, department, responsibility } = req.query;

      let whereConditions = ['ai.isDeleted = 0'];
      let queryParams = [];

      // Access control logic
      if (fullAccessPersonas.includes(userPersona)) {
        // Full access - fetch all
      } else if (restrictedMarketArea.includes(userPersona)) {
        whereConditions.push(`(
          mm.market_area_id = ? 
          OR mm.dealer_id IN (SELECT dealerId FROM userdealers WHERE userId = ?)
          OR mdum.user_id = ?
          OR mvum.user_id = ?
          OR mm.created_by = ?
        )`);
        queryParams.push(userMarketArea, userId, userId, userId, userId);
      } else if (restrictedAccessPersonas.includes(userPersona)) {
        whereConditions.push(`(
          mm.dealer_id IN (SELECT dealerId FROM userdealers WHERE userId = ?)
          OR mdum.user_id = ?
          OR mvum.user_id = ?
          OR mm.created_by = ?
        )`);
        queryParams.push(userId, userId, userId, userId);
      } else {
        return res.status(403).send({
          status: false,
          message: "Access denied: Your persona does not have permission to view action items"
        });
      }

      // Add optional filters from request
      if (monthly_meeting_id) {
        whereConditions.push('ai.monthly_meeting_id = ?');
        queryParams.push(monthly_meeting_id);
      }

      if (status) {
        whereConditions.push('ai.status = ?');
        queryParams.push(status);
      }

      if (department) {
        whereConditions.push('ai.department = ?');
        queryParams.push(department);
      }

      if (responsibility) {
        whereConditions.push('ai.responsibility = ?');
        queryParams.push(responsibility);
      }

      // Get all action items with proper joins and access control
      const actionItemQuery = `
        SELECT DISTINCT
          ai.id,
          ai.monthly_meeting_id,
          ai.created_on,
          ai.created_by,
          ai.department,
          ai.topic_of_discussion,
          ai.closure_action,
          ai.responsibility,
          ai.target_date,
          ai.completed_date,
          ai.status,
          ai.comments,
          ai.updated_on,
          ai.isActive,
          ai.isDeleted,
          ai.target_date_change,
          ai.action_progress_update,
          mm.id as meeting_id,
          mm.meeting_year,
          mm.created_by as meeting_created_by,
          mm.market_area_id,
          mm.dealer_id,
          mm.meeting_date,
          mm.start_time,
          mm.end_time,
          mm.meeting_mode,
          mm.meeting_venue,
          mm.meeting_link,
          d.name as department_name,
          cb.firstName as created_by_name,
          cb.lastName as created_by_lastname,
          r.firstName as responsibility_name,
          r.lastName as responsibility_lastname,
          mcb.firstName as meeting_created_by_name,
          mcb.lastName as meeting_created_by_lastname,
          ma.marketarea,
          dm.dealerName as dealer_name
        FROM action_item ai 
        LEFT JOIN monthly_meeting mm ON ai.monthly_meeting_id = mm.id 
        LEFT JOIN departments d ON ai.department = d.id 
        LEFT JOIN userdetails cb ON ai.created_by = cb.id 
        LEFT JOIN userdetails r ON ai.responsibility = r.id
        LEFT JOIN userdetails mcb ON mm.created_by = mcb.id
        LEFT JOIN market_area ma ON mm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id
        LEFT JOIN meeting_dealeruser_mapping mdum ON mm.id = mdum.meeting_id
        LEFT JOIN meeting_volvouser_mapping mvum ON mm.id = mvum.meeting_id
        WHERE ${whereConditions.join(' AND ')}
        ORDER BY ai.created_on DESC
      `;

      const actionItemData = await connection.query(actionItemQuery, queryParams);

      return res.status(200).send({
        status: true,
        message: "Action items retrieved successfully",
        data: actionItemData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  updateActionItem: async function (req, res) {
    try {
      const { id } = req.body;

      // Validate that id is provided
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Get created_by from token
      const created_by = req.decodedToken;

      // Check if action item exists and get old data for comparison
      const oldActionItemQuery = `
        SELECT 
          ai.id,
          ai.monthly_meeting_id,
          ai.created_on,
          ai.created_by,
          ai.department,
          ai.topic_of_discussion,
          ai.closure_action,
          ai.responsibility,
          ai.target_date,
          ai.completed_date,
          ai.status,
          ai.comments,
          ai.updated_on,
          ai.isActive,
          ai.isDeleted,
          ai.target_date_change,
          ai.action_progress_update,
          mm.id as meeting_id,
          mm.meeting_year,
          mm.created_by as meeting_created_by,
          mm.market_area_id,
          mm.dealer_id,
          mm.meeting_date,
          mm.start_time,
          mm.end_time,
          mm.meeting_mode,
          mm.meeting_venue,
          mm.meeting_link,
          d.name as department_name,
          cb.firstName as created_by_name,
          cb.lastName as created_by_lastname,
          cb.email as created_by_email,
          r.firstName as responsibility_name,
          r.lastName as responsibility_lastname,
          r.email as responsibility_email,
          mcb.firstName as meeting_created_by_name,
          mcb.lastName as meeting_created_by_lastname,
          ma.marketarea,
          dm.dealerName as dealer_name
        FROM action_item ai 
        LEFT JOIN monthly_meeting mm ON ai.monthly_meeting_id = mm.id 
        LEFT JOIN departments d ON ai.department = d.id 
        LEFT JOIN userdetails cb ON ai.created_by = cb.id 
        LEFT JOIN userdetails r ON ai.responsibility = r.id
        LEFT JOIN userdetails mcb ON mm.created_by = mcb.id
        LEFT JOIN market_area ma ON mm.market_area_id = ma.id 
        LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id
        WHERE ai.id = ? AND ai.isDeleted = 0
      `;
      const oldActionItemData = await connection.query(oldActionItemQuery, [id]);

      if (oldActionItemData.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action Item not found!"
        });
      }

      const oldActionItem = oldActionItemData[0];

      // Extract only provided fields from request body
      const {
        monthly_meeting_id,
        department,
        topic_of_discussion,
        closure_action,
        responsibility,
        target_date,
        completed_date,
        status,
        comments,
        target_date_change,
        action_progress_update
      } = req.body;

      if (responsibility && created_by === responsibility) {
        return res.status(400).send({
          status: false,
          message: "Updated by and Responsibility can't be same !!"
        });
      }

      // Build dynamic update query based on provided fields
      const updateFields = [];
      const updateValues = [];

      // Validate and add fields only if they are provided (not undefined and not null)
      if (monthly_meeting_id !== undefined && monthly_meeting_id !== null) {
        // Check if monthly meeting exists
        const meetingCheckQuery = `SELECT id FROM monthly_meeting WHERE id = ? AND isDeleted = 0`;
        const meetingExists = await connection.query(meetingCheckQuery, [monthly_meeting_id]);

        if (meetingExists.length === 0) {
          return res.status(404).send({
            status: false,
            message: "Monthly meeting not found!"
          });
        }
        updateFields.push('monthly_meeting_id = ?');
        updateValues.push(monthly_meeting_id);
      }

      if (department !== undefined && department !== null) {
        // Check if department exists
        const deptCheckQuery = `SELECT id FROM departments WHERE id = ?`;
        const deptExists = await connection.query(deptCheckQuery, [department]);

        if (deptExists.length === 0) {
          return res.status(404).send({
            status: false,
            message: "Department not found!"
          });
        }
        updateFields.push('department = ?');
        updateValues.push(department);
      }

      if (topic_of_discussion !== undefined && topic_of_discussion !== null) {
        updateFields.push('topic_of_discussion = ?');
        updateValues.push(topic_of_discussion);
      }

      if (closure_action !== undefined && closure_action !== null) {
        updateFields.push('closure_action = ?');
        updateValues.push(closure_action);
      }

      if (responsibility !== undefined && responsibility !== null) {
        // Check if responsibility user exists
        const respCheckQuery = `SELECT id FROM userdetails WHERE id = ?`;
        const respExists = await connection.query(respCheckQuery, [responsibility]);

        if (respExists.length === 0) {
          return res.status(404).send({
            status: false,
            message: "Responsibility user not found!"
          });
        }
        updateFields.push('responsibility = ?');
        updateValues.push(responsibility);
      }

      if (target_date !== undefined && target_date !== null) {
        updateFields.push('target_date = ?');
        updateValues.push(target_date);
      }

      if (completed_date !== undefined && completed_date !== null) {
        updateFields.push('completed_date = ?');
        updateValues.push(completed_date);
      }

      if (status !== undefined && status !== null) {
        // Validate status value
        const validStatuses = ['Open', 'Closed', 'In Progress'];
        if (!validStatuses.includes(status)) {
          return res.status(400).send({
            status: false,
            message: "Status must be one of: Open, Closed, In Progress"
          });
        }
        updateFields.push('status = ?');
        updateValues.push(status);
      }

      if (comments !== undefined && comments !== null) {
        updateFields.push('comments = ?');
        updateValues.push(comments);
      }

      if (target_date_change !== undefined) {
        updateFields.push("target_date_change = ?");
        updateValues.push(target_date_change === true || target_date_change === "true" || target_date_change === 1);
      }

      if (action_progress_update !== undefined) {
        updateFields.push("action_progress_update = ?");
        updateValues.push(action_progress_update);
      }

      // Check if user exists (always check since we use created_by for action log)
      const userCheckQuery = `SELECT id FROM userdetails WHERE id = ?`;
      const userExists = await connection.query(userCheckQuery, [created_by]);

      if (userExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "User not found in token!"
        });
      }

      // If no fields to update, return early
      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "No fields provided to update!"
        });
      }

      // Always update updated_on timestamp (add after checking if there are fields to update)
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push('updated_on = ?');
      updateValues.push(updatedOn);

      // Build and execute update query
      const updateQuery = `
        UPDATE action_item 
        SET ${updateFields.join(', ')}
        WHERE id = ? AND isDeleted = 0
      `;

      updateValues.push(id);
      const updatedResult = await connection.query(updateQuery, updateValues);

      // Automatically create action log for the updated action item
      // Use new status if provided, otherwise use old status
      const logStatus = status !== undefined && status !== null ? status : oldActionItem.status;
      const actionLogCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const actionLogQuery = `
        INSERT INTO action_log 
        (updated_by, action_item_id, present_status, comments, createdOn, targetDate) 
        VALUES (?, ?, ?, ?, ?, ?)
      `;

      const actionLogResult = await connection.query(actionLogQuery, [
        created_by, id, logStatus, 'Action item updated', actionLogCreatedOn, target_date || null
      ]);

      // Fetch complete updated action item details with all joins for email
      const newActionItemQuery = `
        SELECT 
          ai.id,
          ai.monthly_meeting_id,
          ai.created_on,
          ai.created_by,
          ai.department,
          ai.topic_of_discussion,
          ai.closure_action,
          ai.responsibility,
          ai.target_date,
          ai.completed_date,
          ai.status,
          ai.comments,
          ai.updated_on,
          ai.isActive,
          ai.isDeleted,
          ai.target_date_change,
          ai.action_progress_update,
          mm.id as meeting_id,
          mm.meeting_year,
          mm.created_by as meeting_created_by,
          mm.market_area_id,
          mm.dealer_id,
          mm.meeting_date,
          mm.start_time,
          mm.end_time,
          mm.meeting_mode,
          mm.meeting_venue,
          mm.meeting_link,
          d.name as department_name,
          cb.firstName as created_by_name,
          cb.lastName as created_by_lastname,
          cb.email as created_by_email,
          r.firstName as responsibility_name,
          r.lastName as responsibility_lastname,
          r.email as responsibility_email,
          mcb.firstName as meeting_created_by_name,
          mcb.lastName as meeting_created_by_lastname,
          ma.marketarea,
          dm.dealerName as dealer_name
        FROM action_item ai 
        LEFT JOIN monthly_meeting mm ON ai.monthly_meeting_id = mm.id 
        LEFT JOIN departments d ON ai.department = d.id 
        LEFT JOIN userdetails cb ON ai.created_by = cb.id 
        LEFT JOIN userdetails r ON ai.responsibility = r.id
        LEFT JOIN userdetails mcb ON mm.created_by = mcb.id
        LEFT JOIN market_area ma ON mm.market_area_id = ma.id 
        LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id
        WHERE ai.id = ? AND ai.isDeleted = 0
      `;

      const newActionItemData = await connection.query(newActionItemQuery, [id]);

      // Send email notifications to responsibility and created_by users
      if (newActionItemData.length > 0) {
        const newActionItem = newActionItemData[0];
        const emailArray = [];

        // Add responsibility user email if available
        if (newActionItem.responsibility_email && newActionItem.responsibility_email.trim() !== '') {
          emailArray.push(newActionItem.responsibility_email);
        }

        // Add created_by user email if available and different from responsibility
        if (newActionItem.created_by_email &&
          newActionItem.created_by_email.trim() !== '' &&
          newActionItem.created_by_email !== newActionItem.responsibility_email) {
          emailArray.push(newActionItem.created_by_email);
        }

        // Also include old responsibility email if it changed and is different
        if (oldActionItem.responsibility_email &&
          oldActionItem.responsibility_email.trim() !== '' &&
          oldActionItem.responsibility_email !== newActionItem.responsibility_email &&
          !emailArray.includes(oldActionItem.responsibility_email)) {
          emailArray.push(oldActionItem.responsibility_email);
        }

        // Send emails asynchronously (don't wait for completion to avoid blocking response)
        if (emailArray.length > 0) {
          eMailerActionItem.actionItemUpdatedMail(emailArray, oldActionItem, newActionItem)
            .then(emailResults => {
              console.log('Action item update emails sent:', emailResults);
            })
            .catch(emailError => {
              console.error('Error sending action item update emails:', emailError);
            });
        } else {
          console.log('No valid email addresses found for action item update notification');
        }
      }

      return res.status(200).send({
        status: true,
        message: "Action Item updated successfully!",
        data: {
          updateResult: updatedResult,
          action_log_id: actionLogResult.insertId
        }
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  deleteActionItem: async function (req, res) {
    try {
      const { id } = req.params;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Check if action item exists before deletion
      const checkQuery = `SELECT * FROM action_item WHERE id = ? AND isDeleted = 0`;
      const existingActionItem = await connection.query(checkQuery, [id]);

      if (existingActionItem.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action Item not found!"
        });
      }

      // Soft delete action item
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const deleteQuery = `UPDATE action_item SET isDeleted = 1, updated_on = ? WHERE id = ?`;
      const updatedResult = await connection.query(deleteQuery, [updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: "Action Item deleted successfully!",
        data: updatedResult
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  getActionItemById: async function (req, res) {
    try {
      const { id } = req.params;

      // Validate required fields
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required!"
        });
      }

      // Get action item with proper joins
      const actionItemQuery = `
        SELECT 
          ai.id,
          ai.monthly_meeting_id,
          ai.created_on,
          ai.created_by,
          ai.department,
          ai.topic_of_discussion,
          ai.closure_action,
          ai.responsibility,
          ai.target_date,
          ai.completed_date,
          ai.status,
          ai.comments,
          ai.updated_on,
          ai.isActive,
          ai.isDeleted,
          ai.target_date_change,
          ai.action_progress_update,
          mm.id as meeting_id,
          mm.meeting_year,
          mm.created_by as meeting_created_by,
          mm.market_area_id,
          mm.dealer_id,
          mm.meeting_date,
          mm.start_time,
          mm.end_time,
          mm.meeting_mode,
          mm.meeting_venue,
          mm.meeting_link,
          mm.agenda_text,
          d.name as department_name,
          cb.firstName as created_by_name,
          cb.lastName as created_by_lastname,
          cb.email as created_by_email,
          r.firstName as responsibility_name,
          r.lastName as responsibility_lastname,
          r.email as responsibility_email,
          mcb.firstName as meeting_created_by_name,
          mcb.lastName as meeting_created_by_lastname,
          mcb.email as meeting_created_by_email,
          ma.marketarea,
          dm.dealerName as dealer_name
        FROM action_item ai 
        LEFT JOIN monthly_meeting mm ON ai.monthly_meeting_id = mm.id 
        LEFT JOIN departments d ON ai.department = d.id 
        LEFT JOIN userdetails cb ON ai.created_by = cb.id 
        LEFT JOIN userdetails r ON ai.responsibility = r.id
        LEFT JOIN userdetails mcb ON mm.created_by = mcb.id
        LEFT JOIN market_area ma ON mm.market_area_id = ma.id 
        LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id
        WHERE ai.id = ? AND ai.isDeleted = 0
      `;

      const actionItemData = await connection.query(actionItemQuery, [id]);

      if (actionItemData.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action Item not found!"
        });
      }

      const result = actionItemData[0];

      return res.status(200).send({
        status: true,
        message: "Action Item retrieved successfully",
        data: result
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // Additional function to get action items by monthly meeting
  getActionItemsByMeeting: async function (req, res) {
    try {
      const { meeting_id } = req.params;

      if (!meeting_id) {
        return res.status(400).send({
          status: false,
          message: "Meeting ID is required!"
        });
      }

      const actionItemQuery = `
        SELECT 
          ai.id,
          ai.monthly_meeting_id,
          ai.created_on,
          ai.created_by,
          ai.department,
          ai.topic_of_discussion,
          ai.closure_action,
          ai.responsibility,
          ai.target_date,
          ai.completed_date,
          ai.status,
          ai.comments,
          ai.updated_on,
          ai.isActive,
          ai.target_date_change,
          ai.action_progress_update,
          mm.id as meeting_id,
          mm.meeting_year,
          mm.created_by as meeting_created_by,
          mm.market_area_id,
          mm.dealer_id,
          mm.meeting_date,
          mm.start_time,
          mm.end_time,
          d.name as department_name,
          cb.firstName as created_by_name,
          cb.lastName as created_by_lastname,
          r.firstName as responsibility_name,
          r.lastName as responsibility_lastname,
          mcb.firstName as meeting_created_by_name,
          mcb.lastName as meeting_created_by_lastname,
          ma.marketarea,
          dm.dealerName as dealer_name
        FROM action_item ai 
        LEFT JOIN monthly_meeting mm ON ai.monthly_meeting_id = mm.id 
        LEFT JOIN departments d ON ai.department = d.id 
        LEFT JOIN userdetails cb ON ai.created_by = cb.id 
        LEFT JOIN userdetails r ON ai.responsibility = r.id
        LEFT JOIN userdetails mcb ON mm.created_by = mcb.id
        LEFT JOIN market_area ma ON mm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id
        WHERE ai.monthly_meeting_id = ? AND ai.isDeleted = 0
        ORDER BY ai.created_on DESC
      `;

      const actionItemData = await connection.query(actionItemQuery, [meeting_id]);

      return res.status(200).send({
        status: true,
        message: "Action items retrieved successfully",
        data: actionItemData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // Function to update action item status
  updateActionItemStatus: async function (req, res) {
    try {
      const { id } = req.params;
      const { status, completed_date } = req.body;

      if (!id || !status) {
        return res.status(400).send({
          status: false,
          message: "ID and status are required!"
        });
      }

      // Validate status value
      const validStatuses = ['Open', 'Closed', 'In Progress'];
      if (!validStatuses.includes(status)) {
        return res.status(400).send({
          status: false,
          message: "Status must be one of: Open, Closed, In Progress"
        });
      }

      // Check if action item exists
      const checkQuery = `SELECT * FROM action_item WHERE id = ? AND isDeleted = 0`;
      const existingActionItem = await connection.query(checkQuery, [id]);

      if (existingActionItem.length === 0) {
        return res.status(404).send({
          status: false,
          message: "Action Item not found!"
        });
      }

      // Update status and completed_date if provided
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      let updateQuery = `UPDATE action_item SET status = ?, updated_on = ?`;
      let queryParams = [status, updatedOn];

      if (completed_date) {
        updateQuery += `, completed_date = ?`;
        queryParams.push(completed_date);
      }

      updateQuery += ` WHERE id = ? AND isDeleted = 0`;
      queryParams.push(id);

      const updatedResult = await connection.query(updateQuery, queryParams);

      // Automatically create action log for the status change
      const actionLogCreatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const actionLogQuery = `
        INSERT INTO action_log 
        (updated_by, action_item_id, present_status, comments, createdOn) 
        VALUES (?, ?, ?, ?, ?)
      `;

      const actionLogResult = await connection.query(actionLogQuery, [
        req.decodedToken, id, status, `Status changed to ${status}`, actionLogCreatedOn
      ]);

      return res.status(200).send({
        status: true,
        message: "Action Item status updated successfully!",
        data: {
          updateResult: updatedResult,
          action_log_id: actionLogResult.insertId
        }
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  }
};
