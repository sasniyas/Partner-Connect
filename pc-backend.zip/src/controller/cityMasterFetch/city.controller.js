const { connection } = require("../../mySql/mySql");
const axios = require('axios');
const moment = require('moment-timezone');

module.exports = {
    bulkInsertCities: async function (req, res) {
        try {
            // 1. Fetch all active states
            const stateQuery = `SELECT id, state_name FROM indian_states`;
            const states = await connection.query(stateQuery);

            if (!states || states.length === 0) {
                return res.status(404).send({ status: false, message: "No active states found in state_master" });
            }

            let totalCitiesInserted = 0;
            const errors = [];

            // Regex to match special characters (preserving spaces and standard alphabets)
            // This will match anything that is NOT a-z, A-Z, 0-9, or space.
            // Adjust if other characters like hyphens/parentheses should be allowed.
            // The user asked to "identity the special character and replace it with the normal one".
            // Simple stripping/normalization might be safer. 
            // For "Bawāna" -> "Bawana", simply removing diacritics is best.
            const normalizeCityName = (name) => {
                return name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9 ]/g, "");
            };

            const currentTime = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

            // Helper for delay
            const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

            // 2. Loop through each state
            for (const state of states) {
                try {
                    // Add a small delay to avoid 429 Rate Limit errors
                    await sleep(2000); // 1 second delay

                    const response = await axios.post('https://countriesnow.space/api/v0.1/countries/state/cities', {
                        country: "India",
                        state: state.state_name
                    });

                    if (!response.data.error && response.data.data && response.data.data.length > 0) {
                        const cities = response.data.data;
                        const cityValues = [];

                        for (const city of cities) {
                            // 3. Clean city name
                            const cleanCityName = normalizeCityName(city);

                            cityValues.push([
                                cleanCityName,
                                state.id,
                                state.state_name,
                                currentTime,
                                currentTime
                            ]);
                        }

                        if (cityValues.length > 0) {
                            // Bulk insert for this state
                            const insertQuery = `
                 INSERT INTO cities_master (city_name, state_id, state_name, created_at, updated_at)
                 VALUES ?
               `;
                            await connection.query(insertQuery, [cityValues]);
                            totalCitiesInserted += cityValues.length;
                        }
                    }
                } catch (apiError) {
                    if (apiError.response && apiError.response.status === 429) {
                        console.warn(`Rate limit hit for state ${state.state_name}. Continuing...`);
                    } else {
                        console.error(`Error fetching cities for state ${state.state_name}:`, apiError.message);
                    }
                    errors.push({ state: state.state_name, error: apiError.message });
                    // Continue to next state even if one fails
                }
            }

            return res.status(200).send({
                status: true,
                message: "Bulk city insertion process completed",
                data: {
                    totalCitiesInserted,
                    errors
                }
            });

        } catch (error) {
            console.error("Bulk Insert Cities Error:", error);
            return res.status(500).send({ status: false, message: error.message });
        }
    }
};