const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // ➕ Add DFHM AR Aging
  addDfhmAging: async function (req, res) {
    try {
      const {
        dfhm_id,
        quarter,
        category,
        customer_name,
        current_ar,
        L30,
        L60,
        L90,
        M90
      } = req.body;

      if (!dfhm_id || !quarter || !category || !customer_name) {
        return res.status(400).send({
          status: false,
          message: "Required: dfhm_id, quarter, category, customer_name"
        });
      }

      // Validate quarter
      const validQuarters = ["Q1", "Q2", "Q3", "Q4"];
      if (!validQuarters.includes(quarter)) {
        return res.status(400).send({
          status: false,
          message: "Quarter must be one of: Q1, Q2, Q3, Q4"
        });
      }

      // Validate category
      const validCategories = ["Equipment", "Parts"];
      if (!validCategories.includes(category)) {
        return res.status(400).send({
          status: false,
          message: "Category must be one of: Equipment, Parts"
        });
      }

      // Validate dfhm_id exists
      const dfhmExists = await connection.query(
        `SELECT id FROM dfhm WHERE id = ?`,
        [dfhm_id]
      );
      if (dfhmExists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM not found"
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertQuery = `
        INSERT INTO dfhm_ar_aging (dfhm_id, quarter, category, customer_name, current_ar, L30, L60, L90, M90, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const result = await connection.query(insertQuery, [
        dfhm_id,
        quarter,
        category,
        customer_name,
        current_ar || null,
        L30 || null,
        L60 || null,
        L90 || null,
        M90 || null,
        createdOn,
        createdOn
      ]);

      return res.status(200).send({
        status: true,
        message: "DFHM AR Aging created successfully",
        id: result.insertId
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📥 Get All DFHM AR Aging
  getAllDfhmAging: async function (req, res) {
    try {
      const { dfhmId, category, customer_name } = req.query;
      
      // Build WHERE clause dynamically based on query parameters
      const whereConditions = ["(dfhm_ar_aging.isDeleted = FALSE OR dfhm_ar_aging.isDeleted = 0)"];
      const queryValues = [];

      if (dfhmId) {
        whereConditions.push("dfhm_ar_aging.dfhm_id = ?");
        queryValues.push(dfhmId);
      }

      if (category) {
        whereConditions.push("dfhm_ar_aging.category = ?");
        queryValues.push(category);
      }

      if (customer_name) {
        whereConditions.push("dfhm_ar_aging.customer_name = ?");
        queryValues.push(customer_name);
      }

      const query = `
        SELECT 
          dfhm_ar_aging.id,
          dfhm_ar_aging.dfhm_id,
          dfhm_ar_aging.quarter,
          dfhm_ar_aging.category,
          dfhm_ar_aging.customer_name,
          dfhm_ar_aging.current_ar,
          dfhm_ar_aging.L30,
          dfhm_ar_aging.L60,
          dfhm_ar_aging.L90,
          dfhm_ar_aging.M90,
          dfhm_ar_aging.created_at,
          dfhm_ar_aging.updated_at,
          dfhm_ar_aging.isActive,
          dfhm_ar_aging.isDeleted,
          dfhm.year as dfhm_year,
          dfhm.quarter as dfhm_quarter,
          dfhm.market_area_id,
          dfhm.dealerId,
          ma.marketarea as market_area_name,
          dm.dealerName,
          dm.dealerShortName
        FROM dfhm_ar_aging
        LEFT JOIN dfhm ON dfhm_ar_aging.dfhm_id = dfhm.id
        LEFT JOIN market_area ma ON dfhm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON dfhm.dealerId = dm.id
        WHERE ${whereConditions.join(" AND ")}
        ORDER BY dfhm_ar_aging.created_at DESC, dfhm_ar_aging.id DESC
      `;
      const data = await connection.query(query, queryValues);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No DFHM AR Aging records found", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        dfhm_id: item.dfhm_id,
        quarter: item.quarter,
        category: item.category,
        customer_name: item.customer_name,
        current_ar: item.current_ar,
        L30: item.L30,
        L60: item.L60,
        L90: item.L90,
        M90: item.M90,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        dfhm_info: {
          dfhm_id: item.dfhm_id,
          year: item.dfhm_year,
          quarter: item.dfhm_quarter,
          market_area_id: item.market_area_id,
          market_area_name: item.market_area_name,
          dealerId: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "DFHM AR Aging list retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  // 🔍 Get DFHM AR Aging by ID
  getDfhmAgingById: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      const query = `
        SELECT 
          dfhm_ar_aging.id,
          dfhm_ar_aging.dfhm_id,
          dfhm_ar_aging.quarter,
          dfhm_ar_aging.category,
          dfhm_ar_aging.customer_name,
          dfhm_ar_aging.current_ar,
          dfhm_ar_aging.L30,
          dfhm_ar_aging.L60,
          dfhm_ar_aging.L90,
          dfhm_ar_aging.M90,
          dfhm_ar_aging.created_at,
          dfhm_ar_aging.updated_at,
          dfhm_ar_aging.isActive,
          dfhm_ar_aging.isDeleted,
          dfhm.year as dfhm_year,
          dfhm.quarter as dfhm_quarter,
          dfhm.market_area_id,
          dfhm.dealerId,
          ma.marketarea as market_area_name,
          dm.dealerName,
          dm.dealerShortName
        FROM dfhm_ar_aging
        LEFT JOIN dfhm ON dfhm_ar_aging.dfhm_id = dfhm.id
        LEFT JOIN market_area ma ON dfhm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON dfhm.dealerId = dm.id
        WHERE dfhm_ar_aging.id = ? AND (dfhm_ar_aging.isDeleted = FALSE OR dfhm_ar_aging.isDeleted = 0)
      `;
      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "DFHM AR Aging not found" 
        });
      }

      const result = {
        id: data[0].id,
        dfhm_id: data[0].dfhm_id,
        quarter: data[0].quarter,
        category: data[0].category,
        customer_name: data[0].customer_name,
        current_ar: data[0].current_ar,
        L30: data[0].L30,
        L60: data[0].L60,
        L90: data[0].L90,
        M90: data[0].M90,
        created_at: data[0].created_at,
        updated_at: data[0].updated_at,
        isActive: data[0].isActive,
        isDeleted: data[0].isDeleted,
        dfhm_info: {
          dfhm_id: data[0].dfhm_id,
          year: data[0].dfhm_year,
          quarter: data[0].dfhm_quarter,
          market_area_id: data[0].market_area_id,
          market_area_name: data[0].market_area_name,
          dealerId: data[0].dealerId,
          dealer_name: data[0].dealerName,
          dealer_short_name: data[0].dealerShortName
        }
      };

      return res.status(200).send({ 
        status: true, 
        message: "DFHM AR Aging retrieved", 
        data: result 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  // 🔍 Get DFHM AR Aging by DFHM ID
  getDfhmAgingByDfhmId: async function (req, res) {
    try {
      const { dfhmId } = req.params;
      if (!dfhmId) {
        return res.status(400).send({ 
          status: false, 
          message: "dfhmId is required" 
        });
      }

      const query = `
        SELECT 
          dfhm_ar_aging.id,
          dfhm_ar_aging.dfhm_id,
          dfhm_ar_aging.quarter,
          dfhm_ar_aging.category,
          dfhm_ar_aging.customer_name,
          dfhm_ar_aging.current_ar,
          dfhm_ar_aging.L30,
          dfhm_ar_aging.L60,
          dfhm_ar_aging.L90,
          dfhm_ar_aging.M90,
          dfhm_ar_aging.created_at,
          dfhm_ar_aging.updated_at,
          dfhm_ar_aging.isActive,
          dfhm_ar_aging.isDeleted,
          dfhm.year as dfhm_year,
          dfhm.quarter as dfhm_quarter,
          dfhm.market_area_id,
          dfhm.dealerId,
          ma.marketarea as market_area_name,
          dm.dealerName,
          dm.dealerShortName
        FROM dfhm_ar_aging
        LEFT JOIN dfhm ON dfhm_ar_aging.dfhm_id = dfhm.id
        LEFT JOIN market_area ma ON dfhm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON dfhm.dealerId = dm.id
        WHERE dfhm_ar_aging.dfhm_id = ? AND (dfhm_ar_aging.isDeleted = FALSE OR dfhm_ar_aging.isDeleted = 0)
        ORDER BY dfhm_ar_aging.created_at DESC, dfhm_ar_aging.id DESC
      `;
      const data = await connection.query(query, [dfhmId]);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No DFHM AR Aging records found for this DFHM", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        dfhm_id: item.dfhm_id,
        quarter: item.quarter,
        category: item.category,
        customer_name: item.customer_name,
        current_ar: item.current_ar,
        L30: item.L30,
        L60: item.L60,
        L90: item.L90,
        M90: item.M90,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        dfhm_info: {
          dfhm_id: item.dfhm_id,
          year: item.dfhm_year,
          quarter: item.dfhm_quarter,
          market_area_id: item.market_area_id,
          market_area_name: item.market_area_name,
          dealerId: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "DFHM AR Aging records retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

   // 🔍 Get DFHM AR Aging by DFHM ID
  getDfhmAgingByFilters: async function (req, res) {
    try {
      let extraWhere = "";
      let values = [];

      // Quarter filter
      if (req.query.quarter) {
        extraWhere += " AND dfhm.quarter = ?";
        values.push(req.query.quarter);
      }

      // Year filter
      if (req.query.year) {
        extraWhere += " AND dfhm.year = ?";
        values.push(req.query.year);
      }

      // Dealer filter
      if (req.query.dealerId) {
        extraWhere += " AND dfhm.dealerId = ?";
        values.push(req.query.dealerId);
      }

      const query = `
        SELECT 
          dfhm_ar_aging.id,
          dfhm_ar_aging.dfhm_id,
          dfhm_ar_aging.quarter,
          dfhm_ar_aging.category,
          dfhm_ar_aging.customer_name,
          dfhm_ar_aging.current_ar,
          dfhm_ar_aging.L30,
          dfhm_ar_aging.L60,
          dfhm_ar_aging.L90,
          dfhm_ar_aging.M90,
          dfhm_ar_aging.created_at,
          dfhm_ar_aging.updated_at,
          dfhm_ar_aging.isActive,
          dfhm_ar_aging.isDeleted,
          dfhm.year as dfhm_year,
          dfhm.quarter as dfhm_quarter,
          dfhm.market_area_id,
          dfhm.dealerId,
          ma.marketarea as market_area_name,
          dm.dealerName,
          dm.dealerShortName
        FROM dfhm_ar_aging
        LEFT JOIN dfhm ON dfhm_ar_aging.dfhm_id = dfhm.id
        LEFT JOIN market_area ma ON dfhm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON dfhm.dealerId = dm.id
        WHERE (dfhm_ar_aging.isDeleted = FALSE OR dfhm_ar_aging.isDeleted = 0)
          ${extraWhere}
        ORDER BY dfhm_ar_aging.created_at DESC, dfhm_ar_aging.id DESC
      `;
      const data = await connection.query(query, values);

      if (data.length === 0) {
        return res.status(200).send({ 
          status: true, 
          message: "No DFHM AR Aging records found for this DFHM", 
          data: [] 
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        dfhm_id: item.dfhm_id,
        quarter: item.quarter,
        category: item.category,
        customer_name: item.customer_name,
        current_ar: item.current_ar,
        L30: item.L30,
        L60: item.L60,
        L90: item.L90,
        M90: item.M90,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        dfhm_info: {
          dfhm_id: item.dfhm_id,
          year: item.dfhm_year,
          quarter: item.dfhm_quarter,
          market_area_id: item.market_area_id,
          market_area_name: item.market_area_name,
          dealerId: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName
        }
      }));

      return res.status(200).send({ 
        status: true, 
        message: "DFHM AR Aging records retrieved", 
        data: formattedData 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  // 📝 Update DFHM AR Aging
  updateDfhmAging: async function (req, res) {
    try {
      const {
        id,
        dfhm_id,
        quarter,
        category,
        customer_name,
        current_ar,
        L30,
        L60,
        L90,
        M90,
        isActive
      } = req.body;

      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      // Check if DFHM AR Aging exists
      const exists = await connection.query(
        `SELECT id FROM dfhm_ar_aging WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`, 
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "DFHM AR Aging not found" 
        });
      }

      // Build update query dynamically based on provided fields
      const updateFields = [];
      const updateValues = [];

      if (dfhm_id !== undefined) {
        // Validate dfhm_id exists
        const dfhmExists = await connection.query(`SELECT id FROM dfhm WHERE id = ?`, [dfhm_id]);
        if (dfhmExists.length === 0) {
          return res.status(400).send({ 
            status: false, 
            message: "Invalid dfhm_id: DFHM not found" 
          });
        }
        updateFields.push("dfhm_id = ?");
        updateValues.push(dfhm_id);
      }

      if (quarter !== undefined) {
        // Validate quarter
        const validQuarters = ["Q1", "Q2", "Q3", "Q4"];
        if (!validQuarters.includes(quarter)) {
          return res.status(400).send({ 
            status: false, 
            message: "Quarter must be one of: Q1, Q2, Q3, Q4" 
          });
        }
        updateFields.push("quarter = ?");
        updateValues.push(quarter);
      }

      if (category !== undefined) {
        // Validate category
        const validCategories = ["Equipment", "Parts"];
        if (!validCategories.includes(category)) {
          return res.status(400).send({ 
            status: false, 
            message: "Category must be one of: Equipment, Parts" 
          });
        }
        updateFields.push("category = ?");
        updateValues.push(category);
      }

      if (customer_name !== undefined) {
        updateFields.push("customer_name = ?");
        updateValues.push(customer_name);
      }

      if (current_ar !== undefined) {
        updateFields.push("current_ar = ?");
        updateValues.push(current_ar);
      }

      if (L30 !== undefined) {
        updateFields.push("L30 = ?");
        updateValues.push(L30);
      }

      if (L60 !== undefined) {
        updateFields.push("L60 = ?");
        updateValues.push(L60);
      }

      if (L90 !== undefined) {
        updateFields.push("L90 = ?");
        updateValues.push(L90);
      }

      if (M90 !== undefined) {
        updateFields.push("M90 = ?");
        updateValues.push(M90);
      }

      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({ 
          status: false, 
          message: "At least one field must be provided for update" 
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE dfhm_ar_aging 
        SET ${updateFields.join(", ")}
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;

      const result = await connection.query(updateQuery, updateValues);

      if (result.affectedRows === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "DFHM AR Aging not found or could not be updated" 
        });
      }

      return res.status(200).send({ 
        status: true, 
        message: "DFHM AR Aging updated successfully" 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  // 📝 Update Multiple DFHM AR Aging
  updateMultipleDfhmAging: async function (req, res) {
    try {
      const { rows } = req.body;

      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ 
          status: false, 
          message: "Rows array is required" 
        });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      for (const row of rows) {
        const { id, ...fields } = row;

        if (!id) continue;

        const updateFields = [];
        const updateValues = [];

        if (fields.dfhm_id !== undefined) {
          updateFields.push("dfhm_id = ?");
          updateValues.push(fields.dfhm_id);
        }

        if (fields.quarter !== undefined) {
          updateFields.push("quarter = ?");
          updateValues.push(fields.quarter);
        }

        if (fields.category !== undefined) {
          updateFields.push("category = ?");
          updateValues.push(fields.category);
        }

        if (fields.customer_name !== undefined) {
          updateFields.push("customer_name = ?");
          updateValues.push(fields.customer_name);
        }

        if (fields.current_ar !== undefined) {
          updateFields.push("current_ar = ?");
          updateValues.push(fields.current_ar);
        }

        if (fields.L30 !== undefined) {
          updateFields.push("L30 = ?");
          updateValues.push(fields.L30);
        }

        if (fields.L60 !== undefined) {
          updateFields.push("L60 = ?");
          updateValues.push(fields.L60);
        }

        if (fields.L90 !== undefined) {
          updateFields.push("L90 = ?");
          updateValues.push(fields.L90);
        }

        if (fields.M90 !== undefined) {
          updateFields.push("M90 = ?");
          updateValues.push(fields.M90);
        }

        if (fields.isActive !== undefined) {
          updateFields.push("isActive = ?");
          updateValues.push(fields.isActive);
        }

        if (updateFields.length > 0) {
          updateFields.push("updated_at = ?");
          updateValues.push(updatedOn);
          updateValues.push(id);

          const updateQuery = `
            UPDATE dfhm_ar_aging 
            SET ${updateFields.join(", ")}
            WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
          `;

          await connection.query(updateQuery, updateValues);
        }
      }

      return res.status(200).send({ 
        status: true, 
        message: "DFHM AR Aging records updated successfully" 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  },

  // ❌ Delete DFHM AR Aging (Soft Delete)
  deleteDfhmAging: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({ 
          status: false, 
          message: "ID is required" 
        });
      }

      // Check if DFHM AR Aging exists
      const exists = await connection.query(
        `SELECT id FROM dfhm_ar_aging WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "DFHM AR Aging not found" 
        });
      }

      // Soft delete by setting isDeleted = TRUE
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const deleteQuery = `
        UPDATE dfhm_ar_aging 
        SET isDeleted = TRUE, updated_at = ?
        WHERE id = ?
      `;
      const result = await connection.query(deleteQuery, [updatedOn, id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({ 
          status: false, 
          message: "DFHM AR Aging not found" 
        });
      }

      return res.status(200).send({ 
        status: true, 
        message: "DFHM AR Aging deleted successfully" 
      });
    } catch (error) {
      return res.status(500).send({ 
        status: false, 
        message: error.message 
      });
    }
  }
};

