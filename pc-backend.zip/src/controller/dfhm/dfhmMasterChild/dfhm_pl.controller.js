const { connection } = require("../../../mySql/mySql");
const moment = require('moment-timezone');

module.exports = {
  // 📥 Get All DFHM PL
  getAllDfhmPl: async function (req, res) {
    try {
      const { dfhmId, masterPlId } = req.query;

      // Build WHERE clause dynamically based on query parameters
      const whereConditions = ["(dfhm_pl.isDeleted = FALSE OR dfhm_pl.isDeleted = 0)"];
      const queryValues = [];

      if (dfhmId) {
        whereConditions.push("dfhm_pl.dfhm_id = ?");
        queryValues.push(dfhmId);
      }

      if (masterPlId) {
        whereConditions.push("dfhm_pl.master_pl_id = ?");
        queryValues.push(masterPlId);
      }

      const query = `
        SELECT 
          dfhm_pl.id,
          dfhm_pl.master_pl_id,
          dfhm_pl.dfhm_id,
          dfhm_pl.quarter,
          dfhm_pl.month1,
          dfhm_pl.month2,
          dfhm_pl.month3,
          dfhm_pl.ytd,
          dfhm_pl.bp,
          dfhm_pl.created_at,
          dfhm_pl.updated_at,
          dfhm_pl.isActive,
          dfhm_pl.isDeleted,
          pl_master.categoryType as pl_categoryType,
          pl_master.category as pl_category,
          pl_master.subCategory as pl_subCategory,
          dfhm.year as dfhm_year,
          dfhm.quarter as dfhm_quarter,
          dfhm.market_area_id,
          dfhm.dealerId,
          ma.marketarea as market_area_name,
          dm.dealerName,
          dm.dealerShortName
        FROM dfhm_pl
        LEFT JOIN pl_master ON dfhm_pl.master_pl_id = pl_master.id
        LEFT JOIN dfhm ON dfhm_pl.dfhm_id = dfhm.id
        LEFT JOIN market_area ma ON dfhm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON dfhm.dealerId = dm.id
        WHERE ${whereConditions.join(" AND ")}
        ORDER BY dfhm_pl.created_at DESC, dfhm_pl.id DESC
      `;
      const data = await connection.query(query, queryValues);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No DFHM PL records found",
          data: []
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        master_pl_id: item.master_pl_id,
        dfhm_id: item.dfhm_id,
        quarter: item.quarter,
        month1: item.month1,
        month2: item.month2,
        month3: item.month3,
        ytd: item.ytd,
        bp: item.bp,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pl_master_info: {
          master_pl_id: item.master_pl_id,
          categoryType:item.pl_categoryType,
          category: item.pl_category,
          subCategory: item.pl_subCategory
        },
        dfhm_info: {
          dfhm_id: item.dfhm_id,
          year: item.dfhm_year,
          quarter: item.dfhm_quarter,
          market_area_id: item.market_area_id,
          market_area_name: item.market_area_name,
          dealerId: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName
        }
      }));

      return res.status(200).send({
        status: true,
        message: "DFHM PL list retrieved",
        data: formattedData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 🔍 Get DFHM PL by ID
  getDfhmPlById: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      const query = `
        SELECT 
          dfhm_pl.id,
          dfhm_pl.master_pl_id,
          dfhm_pl.dfhm_id,
          dfhm_pl.quarter,
          dfhm_pl.month1,
          dfhm_pl.month2,
          dfhm_pl.month3,
          dfhm_pl.ytd,
          dfhm_pl.bp,
          dfhm_pl.created_at,
          dfhm_pl.updated_at,
          dfhm_pl.isActive,
          dfhm_pl.isDeleted,
          pl_master.categoryType as pl_categoryType,
          pl_master.category as pl_category,
          pl_master.subCategory as pl_subCategory,
          dfhm.year as dfhm_year,
          dfhm.quarter as dfhm_quarter,
          dfhm.market_area_id,
          dfhm.dealerId,
          ma.marketarea as market_area_name,
          dm.dealerName,
          dm.dealerShortName
        FROM dfhm_pl
        LEFT JOIN pl_master ON dfhm_pl.master_pl_id = pl_master.id
        LEFT JOIN dfhm ON dfhm_pl.dfhm_id = dfhm.id
        LEFT JOIN market_area ma ON dfhm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON dfhm.dealerId = dm.id
        WHERE dfhm_pl.id = ? AND (dfhm_pl.isDeleted = FALSE OR dfhm_pl.isDeleted = 0)
      `;
      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM PL not found"
        });
      }

      const result = {
        id: data[0].id,
        master_pl_id: data[0].master_pl_id,
        dfhm_id: data[0].dfhm_id,
        quarter: data[0].quarter,
        month1: data[0].month1,
        month2: data[0].month2,
        month3: data[0].month3,
        ytd: data[0].ytd,
        bp: data[0].bp,
        created_at: data[0].created_at,
        updated_at: data[0].updated_at,
        isActive: data[0].isActive,
        isDeleted: data[0].isDeleted,
        pl_master_info: {
          master_pl_id: data[0].master_pl_id,
          categoryType:data[0].pl_categoryType,
          category: data[0].pl_category,
          subCategory: data[0].pl_subCategory
        },
        dfhm_info: {
          dfhm_id: data[0].dfhm_id,
          year: data[0].dfhm_year,
          quarter: data[0].dfhm_quarter,
          market_area_id: data[0].market_area_id,
          market_area_name: data[0].market_area_name,
          dealerId: data[0].dealerId,
          dealer_name: data[0].dealerName,
          dealer_short_name: data[0].dealerShortName
        }
      };

      return res.status(200).send({
        status: true,
        message: "DFHM PL retrieved",
        data: result
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 🔍 Get DFHM PL by DFHM ID
  getDfhmPlByDfhmId: async function (req, res) {
    try {
      const { dfhmId } = req.params;
      if (!dfhmId) {
        return res.status(400).send({
          status: false,
          message: "dfhmId is required"
        });
      }

      const query = `
        SELECT 
          dfhm_pl.id,
          dfhm_pl.master_pl_id,
          dfhm_pl.dfhm_id,
          dfhm_pl.quarter,
          dfhm_pl.month1,
          dfhm_pl.month2,
          dfhm_pl.month3,
          dfhm_pl.ytd,
          dfhm_pl.bp,
          dfhm_pl.created_at,
          dfhm_pl.updated_at,
          dfhm_pl.isActive,
          dfhm_pl.isDeleted,
          pl_master.categoryType as pl_categoryType,
          pl_master.category as pl_category,
          pl_master.subCategory as pl_subCategory,
          dfhm.year as dfhm_year,
          dfhm.quarter as dfhm_quarter,
          dfhm.market_area_id,
          dfhm.dealerId,
          ma.marketarea as market_area_name,
          dm.dealerName,
          dm.dealerShortName
        FROM dfhm_pl
        LEFT JOIN pl_master ON dfhm_pl.master_pl_id = pl_master.id
        LEFT JOIN dfhm ON dfhm_pl.dfhm_id = dfhm.id
        LEFT JOIN market_area ma ON dfhm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON dfhm.dealerId = dm.id
        WHERE dfhm_pl.dfhm_id = ? AND (dfhm_pl.isDeleted = FALSE OR dfhm_pl.isDeleted = 0)
        ORDER BY dfhm_pl.created_at DESC, dfhm_pl.id DESC
      `;
      const data = await connection.query(query, [dfhmId]);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No DFHM PL records found for this DFHM",
          data: []
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        master_pl_id: item.master_pl_id,
        dfhm_id: item.dfhm_id,
        quarter: item.quarter,
        month1: item.month1,
        month2: item.month2,
        month3: item.month3,
        ytd: item.ytd,
        bp: item.bp,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pl_master_info: {
          master_pl_id: item.master_pl_id,
          categoryType:item.pl_categoryType,
          category: item.pl_category,
          subCategory: item.pl_subCategory
        },
        dfhm_info: {
          dfhm_id: item.dfhm_id,
          year: item.dfhm_year,
          quarter: item.dfhm_quarter,
          market_area_id: item.market_area_id,
          market_area_name: item.market_area_name,
          dealerId: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName
        }
      }));

      return res.status(200).send({
        status: true,
        message: "DFHM PL records retrieved",
        data: formattedData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 🔍 Get DFHM PL by DFHM ID
  getDfhmPlByFilters: async function (req, res) {
    try {
      let extraWhere = "";
      let values = [];

      // Quarter filter
      if (req.query.quarter) {
        extraWhere += " AND dfhm.quarter = ?";
        values.push(req.query.quarter);
      }

      // Year filter
      if (req.query.year) {
        extraWhere += " AND dfhm.year = ?";
        values.push(req.query.year);
      }

      // Dealer filter
      if (req.query.dealerId) {
        extraWhere += " AND dfhm.dealerId = ?";
        values.push(req.query.dealerId);
      }


      const query = `
        SELECT 
          dfhm_pl.id,
          dfhm_pl.master_pl_id,
          dfhm_pl.dfhm_id,
          dfhm_pl.quarter,
          dfhm_pl.month1,
          dfhm_pl.month2,
          dfhm_pl.month3,
          dfhm_pl.ytd,
          dfhm_pl.bp,
          dfhm_pl.created_at,
          dfhm_pl.updated_at,
          dfhm_pl.isActive,
          dfhm_pl.isDeleted,
          pl_master.categoryType as pl_categoryType,
          pl_master.category as pl_category,
          pl_master.subCategory as pl_subCategory,
          dfhm.year as dfhm_year,
          dfhm.quarter as dfhm_quarter,
          dfhm.market_area_id,
          dfhm.dealerId,
          ma.marketarea as market_area_name,
          dm.dealerName,
          dm.dealerShortName
        FROM dfhm_pl
        LEFT JOIN pl_master ON dfhm_pl.master_pl_id = pl_master.id
        LEFT JOIN dfhm ON dfhm_pl.dfhm_id = dfhm.id
        LEFT JOIN market_area ma ON dfhm.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON dfhm.dealerId = dm.id
        WHERE (dfhm_pl.isDeleted = FALSE OR dfhm_pl.isDeleted = 0)
        ${extraWhere}
        ORDER BY dfhm_pl.created_at DESC, dfhm_pl.id DESC
      `;
      const data = await connection.query(query,values);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No DFHM PL records found for this DFHM",
          data: []
        });
      }

      const formattedData = data.map(item => ({
        id: item.id,
        master_pl_id: item.master_pl_id,
        dfhm_id: item.dfhm_id,
        quarter: item.quarter,
        month1: item.month1,
        month2: item.month2,
        month3: item.month3,
        ytd: item.ytd,
        bp: item.bp,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        pl_master_info: {
          master_pl_id: item.master_pl_id,
          categoryType:item.pl_categoryType,
          category: item.pl_category,
          subCategory: item.pl_subCategory
        },
        dfhm_info: {
          dfhm_id: item.dfhm_id,
          year: item.dfhm_year,
          quarter: item.dfhm_quarter,
          market_area_id: item.market_area_id,
          market_area_name: item.market_area_name,
          dealerId: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName
        }
      }));

      return res.status(200).send({
        status: true,
        message: "DFHM PL records retrieved",
        data: formattedData
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📝 Update DFHM PL
  updateDfhmPl: async function (req, res) {
    try {
      const {
        id,
        master_pl_id,
        dfhm_id,
        quarter,
        month1,
        month2,
        month3,
        ytd,
        bp,
        isActive
      } = req.body;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      // Check if DFHM PL exists
      const exists = await connection.query(
        `SELECT id FROM dfhm_pl WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM PL not found"
        });
      }

      // Build update query dynamically based on provided fields
      const updateFields = [];
      const updateValues = [];

      if (master_pl_id !== undefined) {
        // Validate master_pl_id exists
        const plMasterExists = await connection.query(`SELECT id FROM pl_master WHERE id = ?`, [master_pl_id]);
        if (plMasterExists.length === 0) {
          return res.status(400).send({
            status: false,
            message: "Invalid master_pl_id: PL Master not found"
          });
        }
        updateFields.push("master_pl_id = ?");
        updateValues.push(master_pl_id);
      }

      if (dfhm_id !== undefined) {
        // Validate dfhm_id exists
        const dfhmExists = await connection.query(`SELECT id FROM dfhm WHERE id = ?`, [dfhm_id]);
        if (dfhmExists.length === 0) {
          return res.status(400).send({
            status: false,
            message: "Invalid dfhm_id: DFHM not found"
          });
        }
        updateFields.push("dfhm_id = ?");
        updateValues.push(dfhm_id);
      }

      if (quarter !== undefined) {
        // Validate quarter
        const validQuarters = ["Q1", "Q2", "Q3", "Q4"];
        if (!validQuarters.includes(quarter)) {
          return res.status(400).send({
            status: false,
            message: "Quarter must be one of: Q1, Q2, Q3, Q4"
          });
        }
        updateFields.push("quarter = ?");
        updateValues.push(quarter);
      }

      if (month1 !== undefined) {
        updateFields.push("month1 = ?");
        updateValues.push(month1);
      }

      if (month2 !== undefined) {
        updateFields.push("month2 = ?");
        updateValues.push(month2);
      }

      if (month3 !== undefined) {
        updateFields.push("month3 = ?");
        updateValues.push(month3);
      }

      if (ytd !== undefined) {
        updateFields.push("ytd = ?");
        updateValues.push(ytd);
      }

      if (bp !== undefined) {
        updateFields.push("bp = ?");
        updateValues.push(bp);
      }

      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "At least one field must be provided for update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE dfhm_pl 
        SET ${updateFields.join(", ")}
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;

      const result = await connection.query(updateQuery, updateValues);

      if (result.affectedRows === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM PL not found or could not be updated"
        });
      }

      return res.status(200).send({
        status: true,
        message: "DFHM PL updated successfully"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📝 Update Multiple DFHM PL
  updateMultipleDfhmPl: async function (req, res) {
    try {
      const { rows } = req.body;

      if (!Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({
          status: false,
          message: "Rows array is required"
        });
      }

      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

      for (const row of rows) {
        const { id, ...fields } = row;

        if (!id) continue;

        const updateFields = [];
        const updateValues = [];

        if (fields.master_pl_id !== undefined) {
          updateFields.push("master_pl_id = ?");
          updateValues.push(fields.master_pl_id);
        }

        if (fields.dfhm_id !== undefined) {
          updateFields.push("dfhm_id = ?");
          updateValues.push(fields.dfhm_id);
        }

        if (fields.quarter !== undefined) {
          updateFields.push("quarter = ?");
          updateValues.push(fields.quarter);
        }

        if (fields.month1 !== undefined) {
          updateFields.push("month1 = ?");
          updateValues.push(fields.month1);
        }

        if (fields.month2 !== undefined) {
          updateFields.push("month2 = ?");
          updateValues.push(fields.month2);
        }

        if (fields.month3 !== undefined) {
          updateFields.push("month3 = ?");
          updateValues.push(fields.month3);
        }

        if (fields.ytd !== undefined) {
          updateFields.push("ytd = ?");
          updateValues.push(fields.ytd);
        }

        if (fields.bp !== undefined) {
          updateFields.push("bp = ?");
          updateValues.push(fields.bp);
        }

        if (fields.isActive !== undefined) {
          updateFields.push("isActive = ?");
          updateValues.push(fields.isActive);
        }

        if (updateFields.length > 0) {
          updateFields.push("updated_at = ?");
          updateValues.push(updatedOn);
          updateValues.push(id);

          const updateQuery = `
            UPDATE dfhm_pl 
            SET ${updateFields.join(", ")}
            WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
          `;

          await connection.query(updateQuery, updateValues);
        }
      }

      return res.status(200).send({
        status: true,
        message: "DFHM PL records updated successfully"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // ❌ Delete DFHM PL (Soft Delete)
  deleteDfhmPl: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      // Check if DFHM PL exists
      const exists = await connection.query(
        `SELECT id FROM dfhm_pl WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM PL not found"
        });
      }

      // Soft delete by setting isDeleted = TRUE
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const deleteQuery = `
        UPDATE dfhm_pl 
        SET isDeleted = TRUE, updated_at = ?
        WHERE id = ?
      `;
      const result = await connection.query(deleteQuery, [updatedOn, id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM PL not found"
        });
      }

      return res.status(200).send({
        status: true,
        message: "DFHM PL deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  }
};

