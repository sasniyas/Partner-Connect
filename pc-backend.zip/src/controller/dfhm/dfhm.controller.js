const { connection } = require("../../mySql/mySql");
const moment = require('moment-timezone');

function parseJsonArray(jsonData) {
  if (!jsonData || jsonData === null || jsonData === "null" || jsonData === "") {
    return [];
  }
  try {
    if (Array.isArray(jsonData)) {
      return jsonData;
    }
    return JSON.parse(jsonData);
  } catch (error) {
    return [];
  }
}

module.exports = {
  // ➕ Add DFHM
  // Demo Request Body:
  // {
  //   "year": 2024,
  //   "quarter": "Q1",
  //   "market_area_id": 1,
  //   "start_date": "2024-01-01",
  //   "end_date": "2024-03-31",
  //   "dealerIds": [1, 2, 3],
  //   "status": "Created",
  //   "dealer_principal_validate": null,
  //   "volvo_user_validate": null
  // }
  // Note: dealerIds can be an array or JSON string. Each dealerId will create a separate DFHM entry.
  // status defaults to "Created" if not provided. Valid values: "Created", "All Data Review", "Review by Volvo"
  addDfhm: async function (req, res) {
    try {
      const {
        year,
        quarter,
        market_area_id,
        start_date,
        end_date,
        dealerIds,
        status,
        dealer_principal_validate,
        volvo_user_validate
      } = req.body;

      if (!year || !quarter || !market_area_id || !start_date || !end_date) {
        return res.status(400).send({
          status: false,
          message: "Required: year, quarter, market_area_id, start_date, end_date"
        });
      }

      // Validate quarter
      const validQuarters = ["Q1", "Q2", "Q3", "Q4"];
      if (!validQuarters.includes(quarter)) {
        return res.status(400).send({
          status: false,
          message: "Quarter must be one of: Q1, Q2, Q3, Q4"
        });
      }

      // Validate status if provided, otherwise default to "Created"
      const validStatuses = ["Created", "All Data Review", "Review by Volvo"];
      const dfhmStatus = status && validStatuses.includes(status) ? status : "Created";

      // Parse dealerIds array
      const dealerIdsArray = parseJsonArray(dealerIds);
      if (!dealerIdsArray || dealerIdsArray.length === 0) {
        return res.status(400).send({
          status: false,
          message: "At least one dealer is required"
        });
      }

      // Check for existing DFHM records to prevent duplication (same year, same quarter, same market_area_id, same dealerId)
      const existingDfhmQuery = `
        SELECT dm.dealerName 
        FROM dfhm d
        JOIN dealer_master dm ON d.dealerId = dm.id
        WHERE d.year = ? AND d.quarter = ? AND d.market_area_id = ? AND d.dealerId IN (?)
          AND (d.isDeleted = 0 OR d.isDeleted IS NULL)
      `;
      const existingDfhms = await connection.query(existingDfhmQuery, [year, quarter, market_area_id, dealerIdsArray]);

      if (existingDfhms.length > 0) {
        const duplicateDealerNames = existingDfhms.map(dfhm => dfhm.dealerName).join(', ');
        return res.status(400).send({
          status: false,
          message: `DFHM already exists for Year: ${year}, Quarter: ${quarter}, Market Area and Dealers: ${duplicateDealerNames}`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const insertDfhmQuery = `
        INSERT INTO dfhm (year, quarter, market_area_id, start_date, end_date, dealerId, status, dealer_principal_validate, volvo_user_validate, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      // Fetch all pl_master entries
      const plMasterEntries = await connection.query(
        `SELECT id FROM pl_master`
      );

      // Fetch all balance_sheet_master entries
      const balanceSheetMasterEntries = await connection.query(
        `SELECT id FROM balance_sheet_master`
      );

      // Fetch all head_count_master entries
      const headCountMasterEntries = await connection.query(
        `SELECT id FROM head_count_master`
      );

      const createdDfhmIds = [];
      let totalDfhmPlEntriesCreated = 0;
      let totalDfhmBsEntriesCreated = 0;
      let totalDfhmHcEntriesCreated = 0;

      // Create entry for each dealer
      for (const dealerId of dealerIdsArray) {
        const result = await connection.query(insertDfhmQuery, [
          year,
          quarter,
          market_area_id,
          start_date,
          end_date,
          dealerId,
          dfhmStatus,
          dealer_principal_validate || null,
          volvo_user_validate || null,
          createdOn,
          createdOn
        ]);
        const dfhmId = result.insertId;
        createdDfhmIds.push(dfhmId);

        // Create dfhm_pl entries for each pl_master entry
        if (plMasterEntries.length > 0) {
          const dfhmPlValues = plMasterEntries.map(plMaster => [
            plMaster.id, // master_pl_id
            dfhmId, // dfhm_id
            quarter, // quarter
            null, // month1
            null, // month2
            null, // month3
            null, // ytd
            null, // bp
            createdOn, // created_at
            createdOn  // updated_at
          ]);

          // Bulk insert dfhm_pl entries
          const dfhmPlPlaceholders = dfhmPlValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
          const bulkInsertDfhmPlQuery = `
            INSERT INTO dfhm_pl (master_pl_id, dfhm_id, quarter, month1, month2, month3, ytd, bp, created_at, updated_at)
            VALUES ${dfhmPlPlaceholders}
          `;
          const dfhmPlFlatValues = dfhmPlValues.flat();
          await connection.query(bulkInsertDfhmPlQuery, dfhmPlFlatValues);
          totalDfhmPlEntriesCreated += plMasterEntries.length;
        }

        // Create dfhm_bs entries for each balance_sheet_master entry
        if (balanceSheetMasterEntries.length > 0) {
          const dfhmBsValues = balanceSheetMasterEntries.map(bsMaster => [
            bsMaster.id, // balance_sheet_master_id
            dfhmId, // dfhm_id
            quarter, // quarter
            null, // month1
            null, // month2
            null, // month3
            null, // ytd
            null, // bp
            createdOn, // created_at
            createdOn  // updated_at
          ]);

          // Bulk insert dfhm_bs entries
          const dfhmBsPlaceholders = dfhmBsValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
          const bulkInsertDfhmBsQuery = `
            INSERT INTO dfhm_bs (balance_sheet_master_id, dfhm_id, quarter, month1, month2, month3, ytd, bp, created_at, updated_at)
            VALUES ${dfhmBsPlaceholders}
          `;
          const dfhmBsFlatValues = dfhmBsValues.flat();
          await connection.query(bulkInsertDfhmBsQuery, dfhmBsFlatValues);
          totalDfhmBsEntriesCreated += balanceSheetMasterEntries.length;
        }

        // Create dfhm_hc entries for each head_count_master entry
        if (headCountMasterEntries.length > 0) {
          const dfhmHcValues = headCountMasterEntries.map(hcMaster => [
            hcMaster.id, // head_count_master_id
            dfhmId, // dfhm_id
            quarter, // quarter
            null, // month1
            null, // month2
            null, // month3
            null, // ytd
            null, // bp
            createdOn, // created_at
            createdOn  // updated_at
          ]);

          // Bulk insert dfhm_hc entries
          const dfhmHcPlaceholders = dfhmHcValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
          const bulkInsertDfhmHcQuery = `
            INSERT INTO dfhm_hc (head_count_master_id, dfhm_id, quarter, month1, month2, month3, ytd, bp, created_at, updated_at)
            VALUES ${dfhmHcPlaceholders}
          `;
          const dfhmHcFlatValues = dfhmHcValues.flat();
          await connection.query(bulkInsertDfhmHcQuery, dfhmHcFlatValues);
          totalDfhmHcEntriesCreated += headCountMasterEntries.length;
        }

        // Create dfhm_ar_aging entries (Equipment and Parts with "Others" customer)
        const dfhmArAgingValues = [
          [
            dfhmId, // dfhm_id
            quarter, // quarter
            "Equipment", // category
            "Others", // customer_name
            null, // current_ar
            null, // L30
            null, // L60
            null, // L90
            null, // M90
            createdOn, // created_at
            createdOn  // updated_at
          ],
          [
            dfhmId, // dfhm_id
            quarter, // quarter
            "Parts", // category
            "Others", // customer_name
            null, // current_ar
            null, // L30
            null, // L60
            null, // L90
            null, // M90
            createdOn, // created_at
            createdOn  // updated_at
          ]
        ];

        const dfhmArAgingPlaceholders = dfhmArAgingValues.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(', ');
        const bulkInsertDfhmArAgingQuery = `
          INSERT INTO dfhm_ar_aging (dfhm_id, quarter, category, customer_name, current_ar, L30, L60, L90, M90, created_at, updated_at)
          VALUES ${dfhmArAgingPlaceholders}
        `;
        const dfhmArAgingFlatValues = dfhmArAgingValues.flat();
        await connection.query(bulkInsertDfhmArAgingQuery, dfhmArAgingFlatValues);
      }

      return res.status(200).send({
        status: true,
        message: "DFHM created successfully",
        ids: createdDfhmIds,
        count: createdDfhmIds.length,
        dfhm_pl_entries_created: totalDfhmPlEntriesCreated,
        dfhm_bs_entries_created: totalDfhmBsEntriesCreated,
        dfhm_hc_entries_created: totalDfhmHcEntriesCreated
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📥 Get All DFHM
  getAllDfhm: async function (req, res) {
    try {
      // Step 1: Extract user identity
      const userId = req.decodedToken;

      if (!userId) {
        return res.status(401).send({ status: false, message: "User not authenticated" });
      }

      // Step 2: Fetch user context
      const userQuery = `
        SELECT persona, marketArea 
        FROM userdetails 
        WHERE id = ?
      `;
      const userResult = await connection.query(userQuery, [userId]);

      if (userResult.length === 0) {
        return res.status(404).send({ status: false, message: "User not found" });
      }

      const userPersona = userResult[0].persona;
      let userMarketArea = userResult[0].marketArea;

      // Step 3: Debug logging
      console.log(`[getAllDfhm] User ID: ${userId}`);
      console.log(`[getAllDfhm] User Persona: "${userPersona}"`);
      console.log(`[getAllDfhm] User Market Area (raw): ${userMarketArea}`);

      // Step 4: Convert market area if needed
      if (userMarketArea && isNaN(userMarketArea)) {
        const marketAreaQuery = `
          SELECT id FROM market_area WHERE marketarea = ?
        `;
        const marketAreaResult = await connection.query(marketAreaQuery, [userMarketArea]);
        if (marketAreaResult.length > 0) {
          userMarketArea = marketAreaResult[0].id;
          console.log(`[getAllDfhm] Converted Market Area name to ID: ${userMarketArea}`);
        } else {
          console.log(`[getAllDfhm] WARNING: Market Area "${userMarketArea}" not found`);
          userMarketArea = null;
        }
      }

      // Step 5: Define persona categories
      const fullAccessPersonas = [
        'Administrator',
        'Volvo Functional Manager',
        'Head of Channel Development Region India',
        // 'IMT',
      ];

      const restrictedAccessPersonas = [
        'Uptime & Parts Manager',
        'Dealer Finance Head',
        'Dealer Principal',
        'Key Account Manager Uptime & Parts',
        'Dealer CEO',
        'Financial Analyst',
        // 'Dealer Parts Manager',
        // 'Dealer Coordinator',
        // 'Dealer sales head',
        // 'Dealer CST Head',
        // 'Dealer HR Head',
      ];

      const restrictedMarketArea = [
        'Retail Sales Manager',
        'Key Account Manager Sales',
        // 'Market Area Head',
        // 'Volvo User'
      ];

      // Step 6: Build conditional query
      let query;
      let queryParams = [];

      if (fullAccessPersonas.includes(userPersona)) {
        console.log(`[getAllDfhm] Access Level: Full Access`);
        // User has full access - fetch all DFHM records
        query = `
          SELECT 
            d.id,
            d.year,
            d.quarter,
            d.market_area_id,
            d.start_date,
            d.end_date,
            d.dealerId,
            d.status,
            d.dealer_principal_validate,
            d.volvo_user_validate,
            d.created_at,
            d.updated_at,
            d.isActive,
            d.isDeleted,
            ma.marketarea as market_area_name,
            dm.dealerName,
            dm.dealerShortName
          FROM dfhm d
          LEFT JOIN market_area ma ON d.market_area_id = ma.id
          LEFT JOIN dealer_master dm ON d.dealerId = dm.id
          WHERE (d.isDeleted = FALSE OR d.isDeleted = 0)
          ORDER BY d.created_at DESC, d.id DESC
        `;
      } else if (restrictedMarketArea.includes(userPersona)) {
        console.log(`[getAllDfhm] Access Level: Market Area Restricted`);
        console.log(`[getAllDfhm] Query Params: marketArea=${userMarketArea}, userId=${userId}`);
        // User has market area restriction - fetch DFHM for mapped dealers OR their market area
        query = `
          SELECT DISTINCT
            d.id,
            d.year,
            d.quarter,
            d.market_area_id,
            d.start_date,
            d.end_date,
            d.dealerId,
            d.status,
            d.dealer_principal_validate,
            d.volvo_user_validate,
            d.created_at,
            d.updated_at,
            d.isActive,
            d.isDeleted,
            ma.marketarea as market_area_name,
            dm.dealerName,
            dm.dealerShortName
          FROM dfhm d
          LEFT JOIN market_area ma ON d.market_area_id = ma.id
          LEFT JOIN dealer_master dm ON d.dealerId = dm.id
          WHERE (d.market_area_id = ? OR d.dealerId IN (SELECT dealerId FROM userdealers WHERE userId = ?))
            AND (d.isDeleted = FALSE OR d.isDeleted = 0)
          ORDER BY d.created_at DESC, d.id DESC
        `;
        queryParams = [userMarketArea, userId];
      } else if (restrictedAccessPersonas.includes(userPersona)) {
        console.log(`[getAllDfhm] Access Level: Dealer Restricted`);
        // User has restricted access - fetch only DFHM for mapped dealers
        query = `
          SELECT 
            d.id,
            d.year,
            d.quarter,
            d.market_area_id,
            d.start_date,
            d.end_date,
            d.dealerId,
            d.status,
            d.dealer_principal_validate,
            d.volvo_user_validate,
            d.created_at,
            d.updated_at,
            d.isActive,
            d.isDeleted,
            ma.marketarea as market_area_name,
            dm.dealerName,
            dm.dealerShortName
          FROM dfhm d
          LEFT JOIN market_area ma ON d.market_area_id = ma.id
          LEFT JOIN dealer_master dm ON d.dealerId = dm.id
          INNER JOIN userdealers ud ON d.dealerId = ud.dealerId
          WHERE ud.userId = ? AND (d.isDeleted = FALSE OR d.isDeleted = 0)
          ORDER BY d.created_at DESC, d.id DESC
        `;
        queryParams = [userId];
      } else {
        console.log(`[getAllDfhm] Access Level: DENIED - Unknown persona`);
        // Unknown persona - no access
        return res.status(403).send({
          status: false,
          message: "Access denied: Your persona does not have permission to view DFHM data"
        });
      }

      // Step 7: Execute query
      const data = await connection.query(query, queryParams);

      console.log(`[getAllDfhm] Query returned ${data.length} records`);

      if (data.length === 0) {
        return res.status(200).send({
          status: true,
          message: "No DFHM records found",
          data: []
        });
      }

      // Step 8: Transform and return data
      const formattedData = data.map(item => ({
        id: item.id,
        year: item.year,
        quarter: item.quarter,
        market_area_id: item.market_area_id,
        start_date: item.start_date,
        end_date: item.end_date,
        dealerId: item.dealerId,
        status: item.status,
        dealer_principal_validate: item.dealer_principal_validate,
        volvo_user_validate: item.volvo_user_validate,
        created_at: item.created_at,
        updated_at: item.updated_at,
        isActive: item.isActive,
        isDeleted: item.isDeleted,
        market_area_info: {
          market_area_id: item.market_area_id,
          market_area_name: item.market_area_name
        },
        dealer_info: {
          dealer_id: item.dealerId,
          dealer_name: item.dealerName,
          dealer_short_name: item.dealerShortName
        }
      }));

      return res.status(200).send({
        status: true,
        message: "DFHM list retrieved successfully",
        data: formattedData
      });
    } catch (error) {
      console.error(`[getAllDfhm] Error:`, error);
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 🔍 Get DFHM by ID
  getDfhmById: async function (req, res) {
    try {
      const { id } = req.params;
      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      const query = `
        SELECT 
          d.id,
          d.year,
          d.quarter,
          d.market_area_id,
          d.start_date,
          d.end_date,
          d.dealerId,
          d.status,
          d.dealer_principal_validate,
          d.volvo_user_validate,
          d.created_at,
          d.updated_at,
          d.isActive,
          d.isDeleted,
          ma.marketarea as market_area_name,
          dm.dealerName,
          dm.dealerShortName
        FROM dfhm d
        LEFT JOIN market_area ma ON d.market_area_id = ma.id
        LEFT JOIN dealer_master dm ON d.dealerId = dm.id
        WHERE d.id = ? AND (d.isDeleted = FALSE OR d.isDeleted = 0)
      `;
      const data = await connection.query(query, [id]);

      if (data.length === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM not found"
        });
      }

      const result = {
        id: data[0].id,
        year: data[0].year,
        quarter: data[0].quarter,
        market_area_id: data[0].market_area_id,
        start_date: data[0].start_date,
        end_date: data[0].end_date,
        dealerId: data[0].dealerId,
        status: data[0].status,
        dealer_principal_validate: data[0].dealer_principal_validate,
        volvo_user_validate: data[0].volvo_user_validate,
        created_at: data[0].created_at,
        updated_at: data[0].updated_at,
        isActive: data[0].isActive,
        isDeleted: data[0].isDeleted,
        market_area_info: {
          market_area_id: data[0].market_area_id,
          market_area_name: data[0].market_area_name
        },
        dealer_info: {
          dealer_id: data[0].dealerId,
          dealer_name: data[0].dealerName,
          dealer_short_name: data[0].dealerShortName
        }
      };

      return res.status(200).send({
        status: true,
        message: "DFHM retrieved",
        data: result
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 📝 Update DFHM
  updateDfhm: async function (req, res) {
    try {
      const {
        id,
        year,
        quarter,
        market_area_id,
        start_date,
        end_date,
        dealerId,
        status,
        dealer_principal_validate,
        volvo_user_validate,
        isActive
      } = req.body;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      // Check if DFHM exists
      const exists = await connection.query(
        `SELECT id FROM dfhm WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM not found"
        });
      }

      // Build update query dynamically based on provided fields
      const updateFields = [];
      const updateValues = [];

      if (year !== undefined) {
        updateFields.push("year = ?");
        updateValues.push(year);
      }

      if (quarter !== undefined) {
        // Validate quarter
        const validQuarters = ["Q1", "Q2", "Q3", "Q4"];
        if (!validQuarters.includes(quarter)) {
          return res.status(400).send({
            status: false,
            message: "Quarter must be one of: Q1, Q2, Q3, Q4"
          });
        }
        updateFields.push("quarter = ?");
        updateValues.push(quarter);
      }

      if (market_area_id !== undefined) {
        // Validate market_area_id exists
        const marketAreaExists = await connection.query(
          `SELECT id FROM market_area WHERE id = ?`,
          [market_area_id]
        );
        if (marketAreaExists.length === 0) {
          return res.status(404).send({
            status: false,
            message: "Market area not found"
          });
        }
        updateFields.push("market_area_id = ?");
        updateValues.push(market_area_id);
      }

      if (start_date !== undefined) {
        updateFields.push("start_date = ?");
        updateValues.push(start_date);
      }

      if (end_date !== undefined) {
        updateFields.push("end_date = ?");
        updateValues.push(end_date);
      }

      if (dealerId !== undefined) {
        // Validate dealerId exists
        const dealerExists = await connection.query(
          `SELECT id FROM dealer_master WHERE id = ?`,
          [dealerId]
        );
        if (dealerExists.length === 0) {
          return res.status(404).send({
            status: false,
            message: "Dealer not found"
          });
        }
        updateFields.push("dealerId = ?");
        updateValues.push(dealerId);
      }

      if (status !== undefined) {
        // Validate status
        const validStatuses = ["Created", "All Data Review", "Review by Volvo"];
        if (!validStatuses.includes(status)) {
          return res.status(400).send({
            status: false,
            message: "Status must be one of: Created, All Data Review, Review by Volvo"
          });
        }
        updateFields.push("status = ?");
        updateValues.push(status);
      }

      if (dealer_principal_validate !== undefined) {
        updateFields.push("dealer_principal_validate = ?");
        updateValues.push(dealer_principal_validate);
      }

      if (volvo_user_validate !== undefined) {
        updateFields.push("volvo_user_validate = ?");
        updateValues.push(volvo_user_validate);
      }

      if (isActive !== undefined) {
        updateFields.push("isActive = ?");
        updateValues.push(isActive);
      }

      if (updateFields.length === 0) {
        return res.status(400).send({
          status: false,
          message: "At least one field must be provided for update"
        });
      }

      // Always update updated_at
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      updateFields.push("updated_at = ?");
      updateValues.push(updatedOn);

      updateValues.push(id);

      const updateQuery = `
        UPDATE dfhm 
        SET ${updateFields.join(", ")}
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;

      const result = await connection.query(updateQuery, updateValues);

      if (result.affectedRows === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM not found or could not be updated"
        });
      }

      return res.status(200).send({
        status: true,
        message: "DFHM updated successfully"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // 🔄 Toggle DFHM (Enable/Disable)
  toggleDfhm: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      // Get current status
      const getQuery = `
        SELECT isActive 
        FROM dfhm 
        WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)
      `;
      const data = await connection.query(getQuery, [id]);

      if (data.length === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM not found"
        });
      }

      const newStatus = data[0].isActive === 1 ? 0 : 1;
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const updateQuery = `
        UPDATE dfhm 
        SET isActive = ?, updated_at = ?
        WHERE id = ?
      `;
      await connection.query(updateQuery, [newStatus, updatedOn, id]);

      return res.status(200).send({
        status: true,
        message: `DFHM ${newStatus === 1 ? "enabled" : "disabled"} successfully!`
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },

  // ❌ Delete DFHM (Soft Delete)
  deleteDfhm: async function (req, res) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).send({
          status: false,
          message: "ID is required"
        });
      }

      // Check if DFHM exists
      const exists = await connection.query(
        `SELECT id FROM dfhm WHERE id = ? AND (isDeleted = FALSE OR isDeleted = 0)`,
        [id]
      );
      if (exists.length === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM not found"
        });
      }

      // Soft delete by setting isDeleted = TRUE
      const updatedOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const deleteQuery = `
        UPDATE dfhm 
        SET isDeleted = TRUE, updated_at = ?
        WHERE id = ?
      `;
      const result = await connection.query(deleteQuery, [updatedOn, id]);

      if (result.affectedRows === 0) {
        return res.status(404).send({
          status: false,
          message: "DFHM not found"
        });
      }

      return res.status(200).send({
        status: true,
        message: "DFHM deleted successfully"
      });
    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  }
};



