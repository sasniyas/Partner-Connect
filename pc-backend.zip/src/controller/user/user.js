const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const moment = require("moment-timezone");
const { connection } = require("../../mySql/mySql"); // your mysql connection
const { regMail, forgotPassMail } = require('../other/eMailer')
const UserLogs = require('./userLogs');
const { validateNameLength, validateEmail } = require("../../utils/validation/userManagement.validation");
const { createNotification } = require("../notification/notification.controller");

// Validation function for bulk add user
const validateUserRows = (rows) => {
  const validRows = [];
  let invalidCount = 0;
  const seenEmails = new Set();

  if (!Array.isArray(rows) || rows.length === 0) {
    return { data: [], error: rows.length || 0 };
  }

  rows.forEach((row) => {
    const {
      firstName,
      middleName,
      lastName,
      email,
      role,
      locationType,
      persona,
      personaId,
      marketArea,
      dealers
    } = row;

    // Check required fields
    if (!firstName || !lastName || !email || !role || !persona) {
      invalidCount++;
      return;
    }

    // Check name length
    if (!validateNameLength(firstName) || !validateNameLength(middleName) || !validateNameLength(lastName)) {
      invalidCount++;
      return;
    }

    // Check email validity
    if (!validateEmail(email)) {
      invalidCount++;
      return;
    }

    const trimmedEmail = email.trim().toLowerCase();
    if (trimmedEmail === "") {
      invalidCount++;
      return;
    }

    // Check for duplicate emails within the batch
    if (seenEmails.has(trimmedEmail)) {
      invalidCount++;
      return;
    }
    seenEmails.add(trimmedEmail);

    // Business rule: Regional Volvo User must have at least one Dealer
    if (role === "VOLVO_USER" && locationType === "REGION" && (!dealers || dealers.length === 0)) {
      invalidCount++;
      return;
    }

    // Row is valid
    validRows.push({
      firstName,
      middleName: middleName || "",
      lastName,
      email: trimmedEmail,
      role,
      locationType,
      persona,
      personaId,
      marketArea: marketArea || "",
      dealers: dealers || []
    });
  });

  return { data: validRows, error: invalidCount };
};

module.exports = {
  // ➕ Bulk Add User
  bulkAddUser: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      const { rows } = req.body;

      if (!rows || !Array.isArray(rows) || rows.length === 0) {
        return res.status(400).send({ status: false, message: "Rows array is required and must not be empty!" });
      }

      // Validate rows using validation function
      const { data: validRows, error: invalidCount } = validateUserRows(rows);

      if (validRows.length === 0) {
        return res.status(400).send({
          status: false,
          message: `All rows are invalid. ${invalidCount} invalid entry/entries found.`
        });
      }

      // Check for existing emails in database (optimized with single query)
      const emails = validRows.map(row => row.email);
      const existingEmailsQuery = `
        SELECT email FROM userDetails WHERE email IN (${emails.map(() => '?').join(',')}) AND isDeleted = 0
      `;
      const existingEmails = await connection.query(existingEmailsQuery, emails);
      const existingEmailsSet = new Set(existingEmails.map(e => e.email.toLowerCase()));

      const rowsToInsert = validRows.filter(row =>
        !existingEmailsSet.has(row.email)
      );
      const duplicateEmailCount = validRows.length - rowsToInsert.length;
      const totalInvalidCount = invalidCount + duplicateEmailCount;

      if (rowsToInsert.length === 0) {
        return res.status(200).send({
          status: false,
          message: `All valid rows have duplicate emails in database. ${totalInvalidCount} invalid/duplicate entry/entries found.`
        });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const activationMailTimestamp = createdOn;
      const JWT_SECRET = "VCEPCADVITIIXSr5slt178";

      // Build single bulk insert query for all users
      const insertValues = rowsToInsert.map(row => [
        row.firstName,
        row.middleName,
        row.lastName,
        row.email,
        row.role,
        row.locationType,
        row.persona,
        row.personaId,
        row.marketArea,
        createdOn,
        activationMailTimestamp
      ]);

      const query = `
        INSERT INTO userDetails 
        (firstName, middleName, lastName, email, role, locationType, persona, personaId, marketArea, createdOn, activationMailTimestamp) 
        VALUES ?
      `;
      await connection.query(query, [insertValues]);

      // Get all inserted user IDs
      const insertedEmails = rowsToInsert.map(row => row.email);
      const insertedUsers = await connection.query(
        `SELECT id, email, firstName, lastName, role FROM userDetails WHERE email IN (${insertedEmails.map(() => '?').join(',')}) AND isDeleted = 0 ORDER BY id ASC`,
        insertedEmails
      );

      // Create a map of email to user for easy lookup
      const emailToUserMap = new Map();
      insertedUsers.forEach(user => {
        emailToUserMap.set(user.email.toLowerCase(), user);
      });

      // Process each user: dealer mappings, token generation, email, and logging
      const allDealerValues = [];
      const userProcessingPromises = [];

      for (const row of rowsToInsert) {
        const user = emailToUserMap.get(row.email);
        if (!user) continue;

        const userId = user.id;

        // Collect dealer mappings
        if (row.dealers && row.dealers.length > 0) {
          const dealerValues = row.dealers.map((did) => [userId, did]);
          allDealerValues.push(...dealerValues);
        }

        // Generate token and send email (async, but don't wait)
        const token = jwt.sign({ id: userId }, JWT_SECRET, { expiresIn: "24h" });
        const link = `https://lively-bay-0661a5200.1.azurestaticapps.net/useractivation?code=${token}`;

        // Send email (fire and forget, but track promise for error handling)
        userProcessingPromises.push(
          regMail("Anand", row.firstName, row.email, link).catch(err => {
            console.error(`Failed to send email to ${row.email}:`, err);
          })
        );

        // Log user creation (fire and forget)
        userProcessingPromises.push(
          UserLogs.addLog(
            userId,
            req.decodedToken,
            "User created successfully",
            "user",
            `New user ${row.firstName} ${row.lastName} created with role ${row.role}`
          ).catch(err => {
            console.error(`Failed to log user creation for ${row.email}:`, err);
          })
        );
      }

      // Bulk insert all dealer mappings
      if (allDealerValues.length > 0) {
        await connection.query(`INSERT INTO userDealers (userId, dealerId) VALUES ?`, [allDealerValues]);
      }

      // Wait for all async operations (emails and logs) to complete
      await Promise.all(userProcessingPromises);

      // Send Notification for Bulk Add
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator' AND isDeleted = 0");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "Bulk Users Created",
          `${rowsToInsert.length} new user(s) have been created successfully.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      let message = `${rowsToInsert.length} User(s) added successfully!`;
      if (totalInvalidCount > 0) {
        message += ` ${totalInvalidCount} invalid/duplicate entry/entries were skipped.`;
      }

      return res.status(200).send({
        status: true,
        message: message,
        data: {
          inserted: rowsToInsert.length,
          invalid: totalInvalidCount
        }
      });
    } catch (error) {
      // Log system error
      await UserLogs.addLog(
        131,
        req.decodedToken,
        `Bulk user creation error: ${error.message}`,
        "user",
        `System error during bulk user creation: ${error.message}`
      ).catch(err => console.error('Failed to log error:', err));

      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // ➕ Add User
  addUser: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let {
        firstName,
        middleName,
        lastName,
        email,
        role,
        locationType,
        persona,
        personaId,
        marketArea,
        dealers,
      } = req.body;

      if (!firstName || !lastName || !email || !role || !persona) {
        return res
          .status(400)
          .send({ status: false, message: "First Name, Last Name, Email ,Role & persona are required!" });
      }

      if (!validateNameLength(firstName) || !validateNameLength(middleName) || !validateNameLength(lastName)) {
        return res
          .status(400)
          .send({ status: false, message: "First Name, Middle Name, and Last Name must not exceed 30 characters each!" });
      }

      if (!validateEmail(email)) {
        return res
          .status(400)
          .send({ status: false, message: "Please provide a valid email address!" });
      }

      if (role === "VOLVO_USER" && locationType === "REGION" && (!dealers || dealers.length === 0)) {
        return res
          .status(400)
          .send({ status: false, message: "Regional Volvo User must have at least one Dealer!" });
      }
      // if ((role === "DEALER_USER") && (!dealers || dealers.length === 0)) {
      //   return res
      //     .status(400)
      //     .send({ status: false, message: "Dealer is required for Dealer roles!" });
      // }

      // Check duplicate email
      let checkUser = await connection.query(`SELECT id FROM userDetails WHERE email = ? AND isDeleted = 0`, [email]);
      if (checkUser?.length > 0) {
        return res.status(200).send({ status: false, message: "User with this Email already exists!" });
      }

      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      const activationMailTimestamp = createdOn;

      // Insert user (without password)
      let query = `
        INSERT INTO userDetails 
        (firstName, middleName, lastName, email, role, locationType,persona,personaId, marketArea, createdOn, activationMailTimestamp) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      let result = await connection.query(query, [
        firstName,
        middleName || "",
        lastName,
        email,
        role,
        locationType,
        persona,
        personaId,
        marketArea || "",
        createdOn,
        activationMailTimestamp
      ]);

      let userId = result.insertId;

      // Insert dealer mappings
      if (dealers && dealers.length > 0) {
        let dealerValues = dealers.map((did) => [userId, did]);
        await connection.query(`INSERT INTO userDealers (userId, dealerId) VALUES ?`, [dealerValues]);
      }
      const JWT_SECRET = "VCEPCADVITIIXSr5slt178"
      // Generate activation token (valid 24 hours)
      const token = jwt.sign({ id: userId }, JWT_SECRET, { expiresIn: "24h" });

      // TODO: Send email with link `/setPassword/${token}`
      let link = `https://lively-bay-0661a5200.1.azurestaticapps.net/useractivation?code=${token}`
      await regMail("Anand", firstName, email, link)

      // Log successful user creation

      await UserLogs.addLog(
        userId,
        req.decodedToken,
        "User created successfully",
        "user",
        `New user ${firstName} ${lastName} created with role ${role}`
      );

      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator' AND isDeleted = 0");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "New User Created",
          `A new user ${firstName} ${lastName} has been created with role ${role}.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({
        status: true,
        message: "User created! Activation email sent.",
        activationLink: `https://lively-bay-0661a5200.1.azurestaticapps.net/useractivation?code=${token}`, // For testing only
      });
    } catch (error) {
      // Log system error
      await UserLogs.addLog(131, req.decodedToken, `User creation error: ${error.message}`, "user", `System error during user creation: ${error.message}`);
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 🔑 Set Password (from email link)
  setPassword: async function (req, res) {
    try {
      let { token, newPassword } = req.body;
      const JWT_SECRET = "VCEPCADVITIIXSr5slt178"; // move to env in real app
      let decoded = jwt.verify(token, JWT_SECRET);
      let userId = decoded.id;
      let SALT_KEY = "2u!Q@8r#Zp^4Xh%7"
      const saltedPassword = newPassword + SALT_KEY;
      const hashedPassword = await bcrypt.hash(saltedPassword, 10);

      let data = await connection.query(`SELECT * FROM userDetails WHERE id=${userId} AND isDeleted = 0`);
      if (data.length) {
        await connection.query(
          `UPDATE userDetails SET password=?,urlvalidation=0,status="ACTIVE" WHERE id=?`,
          [hashedPassword, userId]
        );

        // Log successful password set
        await UserLogs.addLog(
          userId,
          userId,
          "Password set successfully",
          "user",
          `User ${data[0].firstName} ${data[0].lastName} set their password successfully`
        );

      } else {
        // Log user not found error
        await UserLogs.addLog(131, 131, "Password set attempt - User not found", "user", "Password set attempt failed - User not found in database");
        return res
          .status(400)
          .send({ status: false, message: "user not found" });
      }

      return res
        .status(200)
        .send({ status: true, message: "Password set successfully! You can now log in." });
    } catch (error) {
      // Log system error
      await UserLogs.addLog(131, 131, `Password set error: ${error.message}`, "user", `System error during password set: ${error.message}`);
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 🔐 Login
  login: async function (req, res) {
    try {
      let { email, password } = req.body;
      console.log("Login is working");

      let userRows = await connection.query(`SELECT * FROM userDetails WHERE email=? AND isDeleted = 0`, [email]);
      if (userRows.length === 0) {
        // Log unsuccessful login - user not found
        await UserLogs.addLog(131, 131, "Login unsuccessful", "auth", `Login attempt failed - User with email ${email} not found`);

        return res.status(404).send({ status: false, message: "User not found!" });
      }

      let user = userRows[0];

      if (user.status !== "ACTIVE") {
        // Log unsuccessful login - account not active
        await UserLogs.addLog(
          user.id,
          131,
          "Login unsuccessful",
          "auth",
          `Login attempt failed - Account for ${user.firstName} ${user.lastName} is not active`
        );

        return res.status(403).send({ status: false, message: "Account not active!" });
      }

      let saltedPassword = password + "2u!Q@8r#Zp^4Xh%7"
      const valid = await bcrypt.compare(saltedPassword, user.password);
      if (!valid) {
        // Log unsuccessful login - invalid password
        await UserLogs.addLog(
          user.id,
          131,
          "Login unsuccessful",
          "auth",
          `Login attempt failed - Invalid password for ${user.firstName} ${user.lastName}`
        );

        return res.status(401).send({ status: false, message: "Invalid password!" });
      }

      // Update last login
      let now = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE userDetails SET lastLoginTime=? WHERE id=?`, [now, user.id]);

      // Log successful login
      await UserLogs.addLog(
        user.id,
        user.id,
        "Login successful",
        "auth",
        `User ${user.firstName} ${user.lastName} logged in successfully`
      );

      const JWT_SECRET = "VCEPCADVITIIXSr5slt178"

      // Insert into token_management table
      const tokenInsertResult = await connection.query(
        "INSERT INTO token_management (userId, isActive) VALUES (?, ?)",
        [user.id, 1]
      );
      const tokenId = tokenInsertResult.insertId;

      // Generate activation token (valid 24 hours) including tokenId and id
      const token = jwt.sign({ id: user.id, tokenId: tokenId }, JWT_SECRET, { expiresIn: "24h" });

      return res.status(200).send({ status: true, message: "Login successful!", token });
    } catch (error) {
      // Log system error
      await UserLogs.addLog(131, 131, `Login error: ${error.message}`, "auth", `System error during login: ${error.message}`);
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  Adminlogin: async function (req, res) {
    try {
      let { email } = req.body;
      console.log("AdminLogin is working");
      let userId = req.decodedToken;

      let userRows = await connection.query(`SELECT * FROM userDetails WHERE id=? AND isDeleted = 0`, [userId]);
      if (userRows.length === 0) {
        // Log unsuccessful login - user not found
        // await UserLogs.addLog(131, 131, "Login unsuccessful", "auth", `Login attempt failed - User with email ${email} not found`);
        return res.status(404).send({ status: false, message: "User not found!" });
      }

      let user = userRows[0];

      if (user.persona !== "Administrator") {
        // Log unsuccessful login - account not active
        // await UserLogs.addLog(
        //   user.id,
        //   131,
        //   "Login unsuccessful",
        //   "auth",
        //   `Login attempt failed - Account for ${user.firstName} ${user.lastName} is not active`
        // );

        return res.status(401).send({ status: false, message: "User Unauthorized to access this login!" });
      }

      // let saltedPassword = password + "2u!Q@8r#Zp^4Xh%7"
      // const valid = await bcrypt.compare(saltedPassword, user.password);
      // if (!valid) {
      //   // Log unsuccessful login - invalid password
      //   await UserLogs.addLog(
      //     user.id,
      //     131,
      //     "Login unsuccessful",
      //     "auth",
      //     `Login attempt failed - Invalid password for ${user.firstName} ${user.lastName}`
      //   );

      //   return res.status(401).send({ status: false, message: "Invalid password!" });
      // }

      let loginUsers = await connection.query(`SELECT * FROM userDetails WHERE email=? AND isDeleted = 0`, [email]);
      if (loginUsers.length === 0) {
        return res.status(404).send({ status: false, message: "User not found for login!" });
      }
      let loginUser = loginUsers[0];
      // Update last login
      let now = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`UPDATE userDetails SET lastLoginTime=? WHERE id=?`, [now, user.id]);

      // Log successful login
      await UserLogs.addLog(
        loginUser.id,
        user.id,
        "Login successful",
        "auth",
        `User ${user.firstName} ${user.lastName} logged in successfully`
      );

      const JWT_SECRET = "VCEPCADVITIIXSr5slt178";

      // Insert into token_management table
      const tokenInsertResult = await connection.query(
        "INSERT INTO token_management (userId, isActive) VALUES (?, ?)",
        [loginUser.id, 1]
      );
      const tokenId = tokenInsertResult.insertId;

      // Generate activation token (valid 24 hours) including tokenId and userId
      const token = jwt.sign({ id: loginUser.id, tokenId: tokenId }, JWT_SECRET, { expiresIn: "24h" });

      return res.status(200).send({ status: true, message: "Login successful!", token });
    } catch (error) {
      // Log system error
      await UserLogs.addLog(131, 131, `Login error: ${error.message}`, "auth", `System error during login: ${error.message}`);
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 🚪 Logout
  logout: async function (req, res) {
    try {
      const userId = req.decodedToken;
      // Get user details for logging
      const userRows = await connection.query(`SELECT * FROM userDetails WHERE id=? AND isDeleted = 0`, [userId]);

      if (userRows.length === 0) {
        // Log logout attempt for unknown user
        await UserLogs.addLog(131, 131, "Logout attempt - User not found", "auth", "Logout attempt failed - User not found in database");
        return res.status(404).send({ status: false, message: "User not found!" });
      }

      const user = userRows[0];
      const tokenId = req.tokenId;

      if (tokenId) {
        await connection.query(`UPDATE token_management SET isActive = 0 WHERE id = ?`, [tokenId]);
      }

      // Log successful logout
      await UserLogs.addLog(
        user.id,
        user.id,
        "Log out",
        "auth",
        `User ${user.firstName} ${user.lastName} logged out successfully`
      );

      return res.status(200).send({
        status: true,
        message: "Logout successful!"
      });
    } catch (error) {
      // Log system error
      await UserLogs.addLog(131, 131, `Logout error: ${error.message}`, "auth", `System error during logout: ${error.message}`);
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 📌 Get User (with dealers full details)
  getUser: async function (req, res) {
    try {
      let { id } = req.params;

      let users = await connection.query(`SELECT * FROM userDetails WHERE id=? AND isDeleted = 0`, [id]);
      if (users.length === 0) {
        return res.status(404).send({ status: false, message: "User not found!" });
      }

      let user = users[0];

      // Get dealer details for this user
      let dealers = await connection.query(`
      SELECT dm.* 
      FROM userDealers ud
      JOIN dealer_master dm ON ud.dealerId = dm.id
      WHERE ud.userId = ?
    `, [id]);

      user.dealers = dealers;

      return res.status(200).send({ status: true, data: user });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },

  // 📌 Get User (with dealers full details)
  logedInUser: async function (req, res) {
    try {
      let id = req.decodedToken

      let users = await connection.query(`SELECT * FROM userDetails WHERE id=? AND isDeleted = 0`, [id]);
      if (users.length === 0) {
        return res.status(404).send({ status: false, message: "User not found!" });
      }

      let user = users[0];

      return res.status(200).send({ status: true, data: user });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 📌 Get All Users (with dealers full details)
  getAllUsers: async function (req, res) {
    try {
      // Fetch all users
      let users = await connection.query(`SELECT * FROM userDetails WHERE isDeleted = 0 ORDER BY id DESC`);

      if (users.length === 0) {
        return res.status(200).send({ status: true, data: [] });
      }

      // Fetch dealer mappings
      let dealerMappings = await connection.query(`
      SELECT ud.userId, dm.* 
      FROM userDealers ud
      JOIN dealer_master dm ON ud.dealerId = dm.id
    `);

      // Attach dealer objects to each user
      users = users.map((u) => {
        let dealers = dealerMappings.filter((d) => d.userId === u.id);
        return { ...u, dealers };
      });

      return res.status(200).send({ status: true, data: users });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 🔄 Activate / Deactivate User (Text Based)
  toggleUserStatus: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, status } = req.body; // expected "Active" or "Inactive"

      if (!["ACTIVE", "INACTIVE"].includes(status)) {
        return res.status(400).send({
          status: false,
          message: "Status must be either 'Active' or 'Inactive'!"
        });
      }

      // Check user exists
      let users = await connection.query(`SELECT id FROM userDetails WHERE id=? AND isDeleted = 0`, [id]);
      if (users.length === 0) {
        return res.status(404).send({ status: false, message: "User not found!" });
      }

      await connection.query(`UPDATE userDetails SET status=? WHERE id=?`, [status, id]);

      return res.status(200).send({
        status: true,
        message: `User ${status === "ACTIVE" ? "activated" : "deactivated"} successfully!`
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // ✏️ assignRemoveDealers (and dealers)
  assignRemoveDealers: async function (req, res) {
    try {

      let { id, dealers } = req.body;

      // ✅ Update dealer mapping (sync instead of delete+insert)
      let existingDealers = await connection.query(`SELECT dealerId FROM userDealers WHERE userId=?`, [id]);
      let existingDealerIds = existingDealers.map(d => d.dealerId);

      let newDealerIds = dealers || [];

      // Find dealers to add (in newDealerIds but not in existingDealerIds)
      let dealersToAdd = newDealerIds.filter(did => !existingDealerIds.includes(did));

      // Find dealers to remove (in existingDealerIds but not in newDealerIds)
      let dealersToRemove = existingDealerIds.filter(did => !newDealerIds.includes(did));

      // Insert new dealers
      if (dealersToAdd.length > 0) {
        let values = dealersToAdd.map(did => [id, did]);
        await connection.query(`INSERT INTO userDealers (userId, dealerId) VALUES ?`, [values]);
      }

      // Remove old dealers
      if (dealersToRemove.length > 0) {
        await connection.query(`DELETE FROM userDealers WHERE userId=? AND dealerId IN (?)`, [id, dealersToRemove]);
      }


      return res.status(200).send({ status: true, message: "Dealers updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // ✏️ Update User (and dealers)
  updateUser: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id, firstName, middleName, lastName, email, role, locationType, persona, personaId, marketArea, dealers } = req.body;

      if (!id || !firstName || !lastName || !email || !role || !persona) {
        return res.status(400).send({ status: false, message: "Required fields are missing!" });
      }

      if (!validateNameLength(firstName) || !validateNameLength(middleName) || !validateNameLength(lastName)) {
        return res.status(400).send({ status: false, message: "First Name, Middle Name, and Last Name must not exceed 30 characters each!" });
      }

      if (!validateEmail(email)) {
        return res.status(400).send({ status: false, message: "Please provide a valid email address!" });
      }

      await connection.query(
        `UPDATE userDetails SET firstName=?, middleName=?, lastName=?,email=?, role=?, locationType=?,persona=?,personaId=?,marketArea=? WHERE id=?`,
        [firstName, middleName || "", lastName, email, role, locationType, persona, personaId, marketArea || "", id]
      );

      // ✅ Update dealer mapping (sync instead of delete+insert)
      let existingDealers = await connection.query(`SELECT dealerId FROM userDealers WHERE userId=?`, [id]);
      let existingDealerIds = existingDealers.map(d => d.dealerId);

      let newDealerIds = dealers || [];

      // Find dealers to add (in newDealerIds but not in existingDealerIds)
      let dealersToAdd = newDealerIds.filter(did => !existingDealerIds.includes(did));

      // Find dealers to remove (in existingDealerIds but not in newDealerIds)
      let dealersToRemove = existingDealerIds.filter(did => !newDealerIds.includes(did));

      // Insert new dealers
      if (dealersToAdd.length > 0) {
        let values = dealersToAdd.map(did => [id, did]);
        await connection.query(`INSERT INTO userDealers (userId, dealerId) VALUES ?`, [values]);
      }

      // Remove old dealers
      if (dealersToRemove.length > 0) {
        await connection.query(`DELETE FROM userDealers WHERE userId=? AND dealerId IN (?)`, [id, dealersToRemove]);
      }


      // Send Notification
      try {
        const admins = await connection.query("SELECT id FROM userdetails WHERE persona = 'Administrator' AND isDeleted = 0");
        const adminIds = admins.map(admin => admin.id);
        const userIdsToNotify = [...new Set([...adminIds, currentUserId])].filter(Boolean);

        await createNotification(
          "User Details Updated",
          `The user details for "${firstName} ${lastName}" have been updated.`,
          userIdsToNotify
        );
      } catch (notifError) {
        console.error("Notification Error:", notifError.message);
      }

      return res.status(200).send({ status: true, message: "User updated successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // ❌ Delete User
  deleteUser: async function (req, res) {
    try {
      // Persona Validation
      const currentUserId = req.decodedToken;
      const userResult = await connection.query("SELECT persona FROM userdetails WHERE id = ? AND isDeleted = 0", [currentUserId]);

      if (userResult.length === 0 || userResult[0].persona !== 'Administrator') {
        return res.status(401).send({ status: false, message: "unauthorized access error" });
      }

      let { id } = req.params;

      // Soft delete: set isDeleted flag to 1
      await connection.query(`UPDATE userDetails SET isDeleted=1 WHERE id=?`, [id]);

      return res.status(200).send({ status: true, message: "User deleted successfully!" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 🔑 Set Password (from email link)
  urlValidation: async function (req, res) {
    try {
      let userId = req.decodedToken
      let data = await connection.query(`SELECT * FROM userDetails WHERE id=? AND isDeleted = 0`, [userId]);
      if (!data[0].urlvalidation) return res.status(404).send({ status: false, message: "URL Expired" });

      return res
        .status(200)
        .send({ status: true, message: "OK" });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 🔑 Forgot Password API
  forgotPassword: async function (req, res) {
    try {
      let { email } = req.body;

      if (!email) {
        return res.status(400).send({ status: false, message: "Email is required!" });
      }

      if (!validateEmail(email)) {
        return res.status(400).send({ status: false, message: "Please provide a valid email address!" });
      }

      // Check if user exists
      let users = await connection.query(`SELECT id,firstName FROM userDetails WHERE  status='ACTIVE' AND email=?`, [email]);
      if (users.length === 0) {
        return res.status(404).send({ status: false, message: "User not found with this Email!" });
      }

      let userId = users[0].id;
      const JWT_SECRET = "VCEPCADVITIIXSr5slt178"; // move to env in real app
      // Generate reset token (valid for 1 hour)
      const token = jwt.sign({ id: userId, email }, JWT_SECRET, { expiresIn: "12h" });

      await connection.query(
        `UPDATE userDetails SET urlvalidation=1 WHERE id=?`,
        [userId]
      );

      // TODO: send email here with reset link
      const resetLink = `https://lively-bay-0661a5200.1.azurestaticapps.net/resetpassword?code=${token}`;
      await forgotPassMail(users[0].firstName, email, resetLink)
      return res.status(200).send({
        status: true,
        message: "Password reset email sent successfully!",
        resetLink: resetLink, // return only for testing
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
  // 🔑 Forgot Password API
  activationLink: async function (req, res) {
    try {
      let { userId, admin, user, mail } = req.body;

      if (!userId || !admin || !user || !mail) {
        return res.status(400).send({ status: false, message: "all the fiels required!" });
      }

      const JWT_SECRET = "VCEPCADVITIIXSr5slt178"; // move to env in real app
      // Generate reset token (valid for 1 hour)
      const token = jwt.sign({ id: userId, mail }, JWT_SECRET, { expiresIn: "12h" });
      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(
        `UPDATE userDetails SET activationMailTimestamp='${createdOn}',urlvalidation=1 WHERE id=?`,
        [userId]
      );

      // TODO: send email here with reset link
      const resetLink = `https://lively-bay-0661a5200.1.azurestaticapps.net/useractivation?code=${token}`;
      await regMail(admin, user, mail, resetLink)

      return res.status(200).send({
        status: true,
        message: "Password reset email sent successfully!",
        resetLink: resetLink, // return only for testing
      });
    } catch (error) {
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
