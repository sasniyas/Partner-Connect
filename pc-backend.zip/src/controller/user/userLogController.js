const UserLogs = require('./userLogs');

/**
 * User Log Controller
 * Handles all user log related API endpoints
 */

/**
 * Add a new user log
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const addUserLog = async (req, res) => {
    try {
        const { performedBy, activity, logType, message } = req.body;
        const userId = UserLogs.extractUserIdFromToken(req.user); // Extract from decoded token
        await UserLogs.addLog(userId, performedBy, activity, logType, message);
        res.status(201).json({
            status: true,
            message: "User log added successfully"
        });
    } catch (error) {
        res.status(500).json({
            status: false,
            message: "Error adding user log",
            error: error.message
        });
    }
};

/**
 * Get all user logs with optional filtering
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getAllUserLogs = async (req, res) => {
    try {
        const filters = req.query;
        const logs = await UserLogs.getAllLogs(filters);
        res.status(200).json({
            status: true,
            message: "User logs retrieved successfully",
            data: logs
        });
    } catch (error) {
        res.status(500).json({
            status: false,
            message: "Error fetching user logs",
            error: error.message
        });
    }
};

/**
 * Get a specific user log by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getUserLogById = async (req, res) => {
    try {
        const { id } = req.params;
        const log = await UserLogs.getLogById(id);
        if (!log) {
            return res.status(404).json({
                status: false,
                message: "User log not found"
            });
        }
        res.status(200).json({
            status: true,
            message: "User log retrieved successfully",
            data: log
        });
    } catch (error) {
        res.status(500).json({
            status: false,
            message: "Error fetching user log",
            error: error.message
        });
    }
};

/**
 * Update a user log
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const updateUserLog = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, activity, log_type, message } = req.body;
        const userId = UserLogs.extractUserIdFromToken(req.user); // Extract from decoded token
        const updateData = { user_id: userId, performed_by, activity, log_type, message };
        const updatedLog = await UserLogs.updateLog(id, updateData);
        if (!updatedLog) {
            return res.status(404).json({
                status: false,
                message: "User log not found"
            });
        }
        res.status(200).json({
            status: true,
            message: "User log updated successfully",
            data: updatedLog
        });
    } catch (error) {
        res.status(500).json({
            status: false,
            message: "Error updating user log",
            error: error.message
        });
    }
};

/**
 * Delete a user log
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const deleteUserLog = async (req, res) => {
    try {
        const { id } = req.params;
        const success = await UserLogs.deleteLog(id);
        if (!success) {
            return res.status(404).json({
                status: false,
                message: "User log not found"
            });
        }
        res.status(200).json({
            status: true,
            message: "User log deleted successfully"
        });
    } catch (error) {
        res.status(500).json({
            status: false,
            message: "Error deleting user log",
            error: error.message
        });
    }
};

module.exports = {
    addUserLog,
    getAllUserLogs,
    getUserLogById,
    updateUserLog,
    deleteUserLog
};
