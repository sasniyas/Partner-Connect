const { connection } = require("../../mySql/mySql");
const moment = require('moment-timezone');

/**
 * User Logging Utility
 * Handles all user-related logging activities
 */
class UserLogs {

  /**
   * Add a new log entry
   * @param {number} userId - ID of the user
   * @param {number} performedBy - ID of the user who performed the action
   * @param {string} activity - Description of the activity
   * @param {string} logType - Type of log (default: 'auth')
   * @param {string} message - Optional message for the log
   */
  static async addLog(userId, performedBy, activity, logType = 'auth', message = null) {
    try {
      const createdOn = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
      await connection.query(`
        INSERT INTO user_logs (user_id, performed_by, activity, log_type, message, createdOn, isDeleted) 
        VALUES (?, ?, ?, ?, ?, ?, 0)
      `, [userId, performedBy, activity, logType, message, createdOn]);
      console.log("User Logged");
    } catch (error) {
      console.error('Error adding log:', error);
      // Don't throw error to avoid breaking the main flow
    }
  }

  /**
   * Extract user ID from decoded token
   * @param {Object} decodedToken - Decoded JWT token
   * @returns {number} User ID
   */
  static extractUserIdFromToken(decodedToken) {
    return decodedToken?.id || decodedToken?.user_id || decodedToken?.userId || 131; // Default to 131 if not found
  }

  /**
   * Get all user logs with optional filtering
   * @param {Object} filters - Optional filters for the query
   * @returns {Array} Array of log entries
   */
  static async getAllLogs(filters = {}) {
    try {
      let query = `
        SELECT ul.*, u.firstName, u.lastName, u.email,
               CONCAT(pb.firstName, ' ', pb.lastName) as performed_by, pb.email as performedByEmail
        FROM user_logs ul 
        LEFT JOIN userdetails u ON ul.user_id = u.id
        LEFT JOIN userdetails pb ON ul.performed_by = pb.id
        WHERE ul.isDeleted = 0
      `;
      let params = [];

      if (filters.userId) {
        query += ` AND (ul.user_id = ? OR ul.performed_by = ?)`;
        params.push(filters.userId, filters.userId);
      }

      if (filters.performedBy) {
        query += ` AND (pb.firstName LIKE ? OR pb.lastName LIKE ? OR pb.email LIKE ?)`;
        params.push(`%${filters.performedBy}%`, `%${filters.performedBy}%`, `%${filters.performedBy}%`);
      }

      if (filters.logType) {
        query += ` AND ul.log_type = ?`;
        params.push(filters.logType);
      }

      if (filters.activity) {
        query += ` AND ul.activity LIKE ?`;
        params.push(`%${filters.activity}%`);
      }

      if (filters.message) {
        query += ` AND ul.message LIKE ?`;
        params.push(`%${filters.message}%`);
      }

      if (filters.startDate && filters.endDate) {
        query += ` AND ul.createdOn BETWEEN ? AND ?`;
        params.push(filters.startDate, filters.endDate);
      } else if (filters.startDate) {
        query += ` AND ul.createdOn >= ?`;
        params.push(filters.startDate);
      } else if (filters.endDate) {
        query += ` AND ul.createdOn <= ?`;
        params.push(filters.endDate);
      }

      query += ` ORDER BY ul.createdOn DESC`;

      if (filters.limit) {
        query += ` LIMIT ?`;
        params.push(filters.limit);
      }

      const logs = await connection.query(query, params);
      return logs;
    } catch (error) {
      console.error('Error fetching user logs:', error);
      throw error;
    }
  }

  /**
   * Get a specific log by ID
   * @param {number} id - Log ID
   * @returns {Object} Log entry
   */
  static async getLogById(id) {
    try {
      const logs = await connection.query(`
        SELECT ul.*, u.firstName, u.lastName, u.email,
               CONCAT(pb.firstName, ' ', pb.lastName) as performed_by, pb.email as performedByEmail
        FROM user_logs ul 
        LEFT JOIN userdetails u ON ul.user_id = u.id
        LEFT JOIN userdetails pb ON ul.performed_by = pb.id
        WHERE ul.id = ? AND ul.isDeleted = 0
      `, [id]);

      if (logs.length === 0) {
        return null;
      }

      return logs[0];
    } catch (error) {
      console.error('Error fetching log by ID:', error);
      throw error;
    }
  }

  /**
   * Update a log entry
   * @param {number} id - Log ID
   * @param {Object} updateData - Data to update
   * @returns {Object} Updated log entry
   */
  static async updateLog(id, updateData) {
    try {
      const { user_id, performed_by, activity, log_type, message } = updateData;

      const updateQuery = `
        UPDATE user_logs 
        SET user_id = ?, performed_by = ?, activity = ?, log_type = ?, message = ?
        WHERE id = ? AND isDeleted = 0
      `;

      const result = await connection.query(updateQuery, [
        user_id, performed_by, activity, log_type, message, id
      ]);

      if (result.affectedRows === 0) {
        return null;
      }

      return await UserLogs.getLogById(id);
    } catch (error) {
      console.error('Error updating log:', error);
      throw error;
    }
  }

  /**
   * Delete a log entry (soft delete)
   * @param {number} id - Log ID
   * @returns {boolean} Success status
   */
  static async deleteLog(id) {
    try {
      const result = await connection.query(`
        UPDATE user_logs 
        SET isDeleted = 1 
        WHERE id = ? AND isDeleted = 0
      `, [id]);

      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error deleting log:', error);
      throw error;
    }
  }
}

module.exports = UserLogs;
