const axios = require('axios');

async function fetchData() {
  try {
    const response = await axios.get('https://partnerconnect-testenv-bsgsebgdexfmf7bz.centralindia-01.azurewebsites.net/getMarket-area');
    
    console.log("Status:", response.status);   // 200
    console.log("Data:", response.data);       // API response
  } catch (error) {
 console.log(error)
  }
}

fetchData();
