const cron = require('node-cron');
const { connection } = require("../../../mySql/mySql");
const { monthlyMeetingMail } = require("../eMailer");
const moment = require('moment');

// Helper function to parse JSON arrays safely
function parseJsonArray(jsonData) {
  if (!jsonData || jsonData === null || jsonData === 'null' || jsonData === '') {
    return [];
  }

  try {
    if (Array.isArray(jsonData)) {
      return jsonData;
    } else {
      return JSON.parse(jsonData);
    }
  } catch (error) {
    return [];
  }
}

/**
 * Cron job to send email notifications for meetings scheduled today
 * Runs daily at 9:00 AM
 */
const sendTodayMeetingNotifications = async () => {
  try {
    console.log('📧 Cron Job: Starting daily meeting notification check...');

    // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0];
    console.log(`📅 Checking for meetings on: ${today}`);

    // Fetch meetings scheduled for today
    const meetingQuery = `
      SELECT 
        mm.id,
        mm.created_by,
        mm.market_area_id,
        mm.dealer_id,
        mm.meeting_date,
        mm.start_time,
        mm.end_time,
        mm.recurring_meeting,
        mm.meeting_mode,
        mm.meeting_link,
        mm.meeting_venue,
        mm.agenda_text,
        mm.agenda_file_url,
        mm.external_emails,
        mm.optional_emails,
        mm.status,
        dm.dealerName as dealer_name,
        ma.marketarea as market_area
      FROM monthly_meeting mm
      LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id
      LEFT JOIN market_area ma ON mm.market_area_id = ma.id
      WHERE mm.meeting_date = ?
        AND mm.isActive = 1
        AND mm.isDeleted = 0
        AND mm.status = 'Created'
    `;

    const meetings = await connection.query(meetingQuery, [today]);

    if (meetings.length === 0) {
      console.log('✅ No meetings scheduled for today.');
      return;
    }

    console.log(`📋 Found ${meetings.length} meeting(s) scheduled for today.`);

    // Process each meeting
    for (const meeting of meetings) {
      try {
        console.log(`\n📧 Processing meeting ID: ${meeting.id}`);

        // Collect all emails for this meeting
        const allEmails = [];

        // Get dealer user IDs from mappings
        const dealerUserMappings = await connection.query(
          `SELECT user_id FROM meeting_dealeruser_mapping WHERE meeting_id = ?`,
          [meeting.id]
        );
        const dealerUserIds = dealerUserMappings.map(m => m.user_id);

        // Get volvo user IDs from mappings
        const volvoUserMappings = await connection.query(
          `SELECT user_id FROM meeting_volvouser_mapping WHERE meeting_id = ?`,
          [meeting.id]
        );
        const volvoUserIds = volvoUserMappings.map(m => m.user_id);

        // Fetch emails from dealer users
        if (dealerUserIds.length > 0) {
          const placeholders = dealerUserIds.map(() => '?').join(',');
          const dealerUserEmails = await connection.query(
            `SELECT email FROM userdetails WHERE id IN (${placeholders}) AND email IS NOT NULL`,
            dealerUserIds
          );
          dealerUserEmails.forEach(user => {
            if (user.email && !allEmails.includes(user.email)) {
              allEmails.push(user.email);
            }
          });
        }

        // Fetch emails from volvo users
        if (volvoUserIds.length > 0) {
          const placeholders = volvoUserIds.map(() => '?').join(',');
          const volvoUserEmails = await connection.query(
            `SELECT email FROM userdetails WHERE id IN (${placeholders}) AND email IS NOT NULL`,
            volvoUserIds
          );
          volvoUserEmails.forEach(user => {
            if (user.email && !allEmails.includes(user.email)) {
              allEmails.push(user.email);
            }
          });
        }

        // Parse and add external emails
        const externalEmailsArray = parseJsonArray(meeting.external_emails);
        externalEmailsArray.forEach(email => {
          if (email && typeof email === 'string' && !allEmails.includes(email)) {
            allEmails.push(email);
          }
        });

        // Parse and add optional emails
        const optionalEmailsArray = parseJsonArray(meeting.optional_emails);
        optionalEmailsArray.forEach(email => {
          if (email && typeof email === 'string' && !allEmails.includes(email)) {
            allEmails.push(email);
          }
        });

        console.log(`📬 Collected ${allEmails.length} email(s) for meeting ID: ${meeting.id}`);

        // Send email notifications if there are any emails
        if (allEmails.length > 0) {
          // Get creator name for email
          const creatorInfo = await connection.query(
            `SELECT firstName, lastName FROM userdetails WHERE id = ?`,
            [meeting.created_by]
          );
          const creatorName = creatorInfo.length > 0
            ? `${creatorInfo[0].firstName} ${creatorInfo[0].lastName || ''}`.trim()
            : 'Partner Connect Team';

          // Prepare meeting details for email
          const meetingDetails = {
            id: meeting.id,
            meeting_date: meeting.meeting_date,
            start_time: meeting.start_time,
            end_time: meeting.end_time,
            meeting_mode: meeting.meeting_mode,
            meeting_venue: meeting.meeting_venue || '',
            meet_link: meeting.meeting_link || '',
            agenda_text: meeting.agenda_text || '',
            agenda_link: meeting.agenda_file_url || '',
            dealer_name: meeting.dealer_name || '',
            market_area: meeting.market_area || '',
            recurring_meeting: meeting.recurring_meeting || false
          };

          // Send emails asynchronously
          const emailResults = await monthlyMeetingMail(creatorName, allEmails, meetingDetails);

          // Log email results
          const successCount = emailResults.filter(r => r.success).length;
          const failureCount = emailResults.filter(r => !r.success).length;
          console.log(`✅ Sent ${successCount} email(s) successfully for meeting ID: ${meeting.id}`);
          if (failureCount > 0) {
            console.log(`⚠️  Failed to send ${failureCount} email(s) for meeting ID: ${meeting.id}`);
          }
        } else {
          console.log(`⚠️  No emails found for meeting ID: ${meeting.id}`);
        }
      } catch (meetingError) {
        console.error(`❌ Error processing meeting ID ${meeting.id}:`, meetingError);
      }
    }

    console.log('\n✅ Cron Job: Daily meeting notification check completed.');
  } catch (error) {
    console.error('❌ Cron Job Error:', error);
  }
};

// Schedule cron job to run daily at 9:00 AM
// Cron format: minute hour day month weekday
// '0 9 * * *' = At 9:00 AM every day
const scheduleDailyMeetingNotifications = () => {
  console.log('⏰ Scheduling daily meeting notification cron job (runs at 9:00 AM daily)...');

  cron.schedule('0 9 * * *', async () => {
    await sendTodayMeetingNotifications();
  }, {
    scheduled: true,
    timezone: "Asia/Kolkata"
  });

  console.log('✅ Daily meeting notification cron job scheduled successfully.');

  // console.log('⏰ Scheduling recurring meeting check (runs at 2:45 PM daily)...');

  // cron.schedule('0 8 * * *', async () => {
  //   await handleRecurringMeetings();
  // }, {
  //   scheduled: true,
  //   timezone: "Asia/Kolkata"
  // });

  // console.log('✅ Recurring meeting check cron job scheduled successfully.');
};


const handleRecurringMeetings = async () => {
  try {
    console.log('🔄 Cron Job: Starting recurring meeting check...');
    const today = moment();
    const nextSevenDays = moment().add(7, 'days');

    // Fetch meetings with is_reoccuring = 1 and next_meeting_date within the next 7 days
    // Join with dealer_master and market_area to get names for email
    const query = `
      SELECT 
        mm.*,
        dm.dealerName as dealer_name, 
        ma.marketarea as market_area 
      FROM monthly_meeting mm
      LEFT JOIN dealer_master dm ON mm.dealer_id = dm.id
      LEFT JOIN market_area ma ON mm.market_area_id = ma.id
      WHERE mm.is_reoccuring = 1 
      AND mm.next_meeting_date BETWEEN ? AND ?
      AND mm.isActive = 1 
      AND mm.isDeleted = 0
    `;

    // Format dates for MySQL
    const startDate = today.format('YYYY-MM-DD');
    const endDate = nextSevenDays.format('YYYY-MM-DD');

    const meetings = await connection.query(query, [startDate, endDate]);

    if (meetings.length === 0) {
      console.log('✅ No recurring meetings found due in the next 7 days.');
      return;
    }

    console.log(`📋 Found ${meetings.length} recurring meeting(s) to process.`);

    for (const meeting of meetings) {
      try {
        console.log(`\n🔄 Processing recurring meeting ID: ${meeting.id}`);

        const currentNextMeetingDate = moment(meeting.next_meeting_date);

        // 1. Insert new meeting
        const newMeetingData = {
          created_by: meeting.created_by,
          market_area_id: meeting.market_area_id,
          dealer_id: meeting.dealer_id,
          meeting_date: currentNextMeetingDate.format('YYYY-MM-DD'),
          start_time: meeting.start_time,
          end_time: meeting.end_time,
          recurring_meeting: meeting.recurring_meeting, // Keep the original frequency label
          meeting_mode: meeting.meeting_mode,
          meeting_link: meeting.meeting_link,
          meeting_venue: meeting.meeting_venue,
          agenda_text: meeting.agenda_text,
          agenda_file_url: meeting.agenda_file_url,
          isActive: 1,
          isDeleted: 0,
          createdOn: moment().format('YYYY-MM-DD HH:mm:ss'),
          optional_emails: JSON.stringify(parseJsonArray(meeting.optional_emails)),
          external_emails: JSON.stringify(parseJsonArray(meeting.external_emails)),
          status: 'Created',
          is_reoccuring: 0, // As per requirement
          limit_date: null, // As per requirement
          next_meeting_date: null, // As per requirement
          meeting_year: currentNextMeetingDate.year()
        };

        const insertResult = await connection.query('INSERT INTO monthly_meeting SET ?', newMeetingData);
        const newMeetingId = insertResult.insertId;
        console.log(`✅ Inserted new meeting for date: ${newMeetingData.meeting_date} (ID: ${newMeetingId})`);

        // 2. Copy user mappings to the new meeting
        await connection.query(
          'INSERT INTO meeting_dealeruser_mapping (meeting_id, user_id) SELECT ?, user_id FROM meeting_dealeruser_mapping WHERE meeting_id = ?',
          [newMeetingId, meeting.id]
        );
        await connection.query(
          'INSERT INTO meeting_volvouser_mapping (meeting_id, user_id) SELECT ?, user_id FROM meeting_volvouser_mapping WHERE meeting_id = ?',
          [newMeetingId, meeting.id]
        );
        console.log(`✅ Copied user mappings to new meeting ID: ${newMeetingId}`);

        // 3. Send Email Notification for the new meeting
        // Collect all emails (using original meeting ID as source since participants are same)
        const allEmails = [];

        // Get dealer user IDs from mappings
        const dealerUserMappings = await connection.query(
          `SELECT user_id FROM meeting_dealeruser_mapping WHERE meeting_id = ?`,
          [meeting.id]
        );
        const dealerUserIds = dealerUserMappings.map(m => m.user_id);

        // Get volvo user IDs from mappings
        const volvoUserMappings = await connection.query(
          `SELECT user_id FROM meeting_volvouser_mapping WHERE meeting_id = ?`,
          [meeting.id]
        );
        const volvoUserIds = volvoUserMappings.map(m => m.user_id);

        // Fetch emails from dealer users
        if (dealerUserIds.length > 0) {
          const placeholders = dealerUserIds.map(() => '?').join(',');
          const dealerUserEmails = await connection.query(
            `SELECT email FROM userdetails WHERE id IN (${placeholders}) AND email IS NOT NULL`,
            dealerUserIds
          );
          dealerUserEmails.forEach(user => {
            if (user.email && !allEmails.includes(user.email)) {
              allEmails.push(user.email);
            }
          });
        }

        // Fetch emails from volvo users
        if (volvoUserIds.length > 0) {
          const placeholders = volvoUserIds.map(() => '?').join(',');
          const volvoUserEmails = await connection.query(
            `SELECT email FROM userdetails WHERE id IN (${placeholders}) AND email IS NOT NULL`,
            volvoUserIds
          );
          volvoUserEmails.forEach(user => {
            if (user.email && !allEmails.includes(user.email)) {
              allEmails.push(user.email);
            }
          });
        }

        // Parse and add external/optional emails
        const externalEmailsArray = parseJsonArray(meeting.external_emails);
        externalEmailsArray.forEach(email => {
          if (email && typeof email === 'string' && !allEmails.includes(email)) allEmails.push(email);
        });

        const optionalEmailsArray = parseJsonArray(meeting.optional_emails);
        optionalEmailsArray.forEach(email => {
          if (email && typeof email === 'string' && !allEmails.includes(email)) allEmails.push(email);
        });

        console.log(`📬 Collected ${allEmails.length} email(s) for new meeting ID: ${newMeetingId}`);

        if (allEmails.length > 0) {
          // Get creator name
          const creatorInfo = await connection.query(
            `SELECT firstName, lastName FROM userdetails WHERE id = ?`,
            [meeting.created_by]
          );
          const creatorName = creatorInfo.length > 0
            ? `${creatorInfo[0].firstName} ${creatorInfo[0].lastName || ''}`.trim()
            : 'Partner Connect Team';

          // Prepare meeting details for email
          const emailMeetingDetails = {
            id: newMeetingId,
            meeting_date: newMeetingData.meeting_date,
            start_time: newMeetingData.start_time,
            end_time: newMeetingData.end_time,
            meeting_mode: newMeetingData.meeting_mode,
            meeting_venue: newMeetingData.meeting_venue || '',
            meet_link: newMeetingData.meeting_link || '',
            agenda_text: newMeetingData.agenda_text || '',
            agenda_link: newMeetingData.agenda_file_url || '',
            dealer_name: meeting.dealer_name || '',
            market_area: meeting.market_area || '',
            recurring_meeting: newMeetingData.recurring_meeting || false
          };

          const emailResults = await monthlyMeetingMail(creatorName, allEmails, emailMeetingDetails);
          // Log email results
          const successCount = emailResults.filter(r => r.success).length;
          const failureCount = emailResults.filter(r => !r.success).length;
          console.log(`✅ Sent ${successCount} email(s) successfully for new meeting ID: ${newMeetingId}`);
          if (failureCount > 0) {
            console.log(`⚠️  Failed to send ${failureCount} email(s) for new meeting ID: ${newMeetingId}`);
          }
        } else {
          console.log(`⚠️  No emails found for new meeting ID: ${newMeetingId}`);
        }

        // 4. Calculate next meeting date and update original meeting
        let frequencyToAdd = null;
        switch (meeting.recurring_meeting) {
          case 'Weekly': frequencyToAdd = { amount: 1, unit: 'week' }; break;
          case 'Monthly': frequencyToAdd = { amount: 1, unit: 'month' }; break;
          case 'Quarterly': frequencyToAdd = { amount: 3, unit: 'months' }; break;
          case 'Half Yearly': frequencyToAdd = { amount: 6, unit: 'months' }; break;
          case 'Annually': frequencyToAdd = { amount: 1, unit: 'year' }; break;
          // One-time Meeting or others will result in null, stopping recurrence
        }

        let updateData = {};

        if (frequencyToAdd) {
          const newNextMeetingDate = currentNextMeetingDate.clone().add(frequencyToAdd.amount, frequencyToAdd.unit);
          const limitDate = meeting.limit_date ? moment(meeting.limit_date) : null;

          if (limitDate && newNextMeetingDate.isAfter(limitDate)) {
            // Stop recurrence if limit exceeded
            updateData = {
              is_reoccuring: 0,
              next_meeting_date: null
            };
            console.log(`🛑 Recurring limit reached (Limit: ${limitDate.format('YYYY-MM-DD')}). Stopping recurrence.`);
          } else {
            // Update next meeting date
            updateData = {
              next_meeting_date: newNextMeetingDate.format('YYYY-MM-DD')
            };
            console.log(`📅 Updated next meeting date to: ${updateData.next_meeting_date}`);
          }
        } else {
          // Invalid frequency or One-time, stop recurrence
          updateData = {
            is_reoccuring: 0,
            next_meeting_date: null
          };
          console.log(`🛑 Frequency '${meeting.recurring_meeting}' is not recurring. Stopping recurrence.`);
        }

        await connection.query('UPDATE monthly_meeting SET ? WHERE id = ?', [updateData, meeting.id]);
        console.log(`✅ Updated original meeting ID: ${meeting.id}`);

      } catch (err) {
        console.error(`❌ Error processing recurring meeting ID ${meeting.id}:`, err);
      }
    }

    console.log('\n✅ Cron Job: Recurring meeting check completed.');
  } catch (error) {
    console.error('❌ Cron Job Error (Recurring Meetings):', error);
  }
};

module.exports = {
  scheduleDailyMeetingNotifications,
  sendTodayMeetingNotifications,
  handleRecurringMeetings
};

