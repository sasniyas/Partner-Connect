const nodemailer = require('nodemailer');

module.exports = {
  testMail: async function () {
    try {
      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'mailgot.it.volvo.com',
        port: 25,
        auth: {
          user: 'sameer.panigrahi@consultant.volvo.com',
          pass: 'Oneplus@123456'
        }
      });

      let info = await transporter.sendMail({
        from: 'sameer.panigrahi@consultant.volvo.com', // sender address
        to: `rathik.kumar@consultant.volvo.com`, // list of receivers
        subject: "Activate account Partner Connect 2.0", // Subject line
        html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Activate Account</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">

  </body>
  </html>`, // plain text body
      });
      return info;
    } catch (error) {
      console.log(error);
      return error;
    }
  },
};
