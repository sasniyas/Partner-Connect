const nodemailer = require('nodemailer');

module.exports={ 
notifyMAil:async function (mailId,results,date) {
  try {
    const emailContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Application Status Alert</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          color: #333;
          background-color: #f4f4f4;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 20px auto;
          background: #fff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #0078d4;
          color: #fff;
          padding: 10px 0;
          text-align: center;
          border-radius: 8px 8px 0 0;
        }
        .header h1 {
          margin: 0;
          font-size: 24px;
        }
        .content {
          padding: 20px;
        }
        .content h2 {
          font-size: 20px;
          color: #0078d4;
          margin-bottom: 10px;
        }
        .content table {
          width: 100%;
          border-collapse: collapse;
        }
        .content table, .content th, .content td {
          border: 1px solid #ddd;
        }
        .content th, .content td {
          padding: 8px;
          text-align: left;
        }
        .content th {
          background-color: #f2f2f2;
        }
        .footer {
          text-align: center;
          padding: 10px 0;
          font-size: 14px;
          color: #666;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Application Status Alert</h1>
        </div>
        <div class="content">
          <h2>Application Details</h2>
          <table>
            <tr>
              <th>Application Name</th>
              <th>URL</th>
              <th>Status</th>
              <th>Count</th>
            </tr>
            ${results.map(result => `
              <tr>
                <td>${result.projName}</td>
                <td><a href="${result.url}">${result.url}</a></td>
                <td>${result.status}</td>
              </tr>
            `).join('')}
          </table>
          <p><strong>Date:</strong> ${date}</p>
        </div>
        <div class="footer">
          <p>&copy; ${new Date().getFullYear()} Copyright - @Advitiix Technovate</p>
        </div>
      </div>
    </body> 
    </html>
  `;



//Connect with SMTP
    const transporter =await nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      auth: {
          user: 'updates@advitiix.com',
          pass: 'xlizicufaehvtumc'
      }
  });	


  let info = await transporter.sendMail({
    from: 'updates@advitiix.com', // sender address
    to: `${mailId}`, // list of receivers
    subject: "Project Status Alert From Advitiix", // Subject line
     html:emailContent, // plain text body
  });
return info
  }
  catch (error) {
    console.log(error)
    return error
  }

}
}