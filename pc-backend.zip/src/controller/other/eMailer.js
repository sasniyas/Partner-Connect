const nodemailer = require('nodemailer');

module.exports = {
  regMail: async function (admin, user, mail, link) {
    try {
      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      let info = await transporter.sendMail({
        from: 'sameer.panigrahi@advity.in', // sender address
        to: `${mail}`, // list of receivers
        subject: "Activate account Partner Connect 2.0", // Subject line
        html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Activate Account</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <h2 style="color:#003399; text-align:center;">Activate account Partner Connect 2.0</h2>
          <p><strong>Invited by:</strong>${admin}</p>
          <p>Dear <strong>${user}</strong>,</p>
          <p>You are invited as a user for <strong>Partner Connect 2.0</strong> (<a href="https://lively-bay-0661a5200.1.azurestaticapps.net/" target="_blank">partnerconnect2.0.testenv.in</a>).</p>
          <p>Click the button below to set your password and activate your account.</p>
          <p style="text-align:center; margin:30px 0;">
            <a href="${link}" target="_blank" style="background:#5D87FF; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Activate account</a>
          </p>
          <p>Kind regards,<br/>${admin}</p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`, // plain text body
      });
      return info;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  forgotPassMail: async function (user, mail, link) {
    try {
      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      let info = await transporter.sendMail({
        from: 'sameer.panigrahi@advity.in', // sender address
        to: `${mail}`, // list of receivers
        subject: "Reset your password - Partner Connect 2.0", // Subject line
        html: `<!DOCTYPE HTML
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional //EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
  xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Reset Password</title>
</head>

<body style="margin:0;padding:0;background-color:#f9f9f9;color:#000000;font-family:'Cabin',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" bgcolor="#f9f9f9">
    <tr>
      <td align="center" style="padding:10px 0;">
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png"
          alt="Partner_Connect" width="180" />
      </td>
    </tr>
    <tr>
    <tr>
      <td align="center">
        <!-- Body -->
        <table width="600" cellpadding="0" cellspacing="0" bgcolor="#ffffff" style="background-color:#f3f9f9;">
          <tr>
            <td style="padding:33px 55px; text-align:left; font-size:15px; color:#333;">
              <p>Dear <strong>${user}</strong>,</p>
              <p>You made a request to reset your password for <strong>Partner Connect 2.0</strong>. Click the link below:
              </p>
              <br>
              <p style="text-align:center; margin:30px 0;">
                <a href="${link}" target="_blank"
                  style="background:#5D87FF; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Reset
                  Password</a>
              </p>

              <br><br>
              <p>If you did not request this, you can safely ignore this email.</p>
              <p>Kind regards,<br>Team Partner Connect 2.0</p>
            </td>
          </tr>
        </table>

        <!-- Footer -->
        <table width="600" cellpadding="0" cellspacing="0" bgcolor="#003399">
          <tr>
            <td align="center" style="padding:15px; background-color:#786767; color:#fafafa; font-size:12px;">
              <p style="margin:5px 0;">This is an automatically generated message. Replies to this message will not be
                answered.</p>
              <p style="margin:5px 0;">Attention: This message is generated in the testing environment (Staging).<br>
                This message was sent for testing purposes. You may ignore the content.</p>
            </td>
          </tr>
        </table>

      </td>
    </tr>
  </table>
</body>

</html>`, // plain text body
      });
      return info;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  monthlyMeetingMail: async function (creatorName, emailArray, meetingDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray];

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format meeting date
      const meetingDate = meetingDetails.meeting_date 
        ? new Date(meetingDetails.meeting_date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })
        : meetingDetails.meeting_date;

      // Format time
      const formatTime = (time) => {
        if (!time) return '';
        const [hours, minutes] = time.split(':');
        const hour12 = parseInt(hours) % 12 || 12;
        const ampm = parseInt(hours) >= 12 ? 'PM' : 'AM';
        return `${hour12}:${minutes} ${ampm}`;
      };

      const startTime = formatTime(meetingDetails.start_time);
      const endTime = formatTime(meetingDetails.end_time);
      const timeRange = startTime && endTime ? `${startTime} - ${endTime}` : (startTime || endTime || '');

      // Meeting mode text
      const meetingMode = meetingDetails.meeting_mode 
        ? meetingDetails.meeting_mode.charAt(0).toUpperCase() + meetingDetails.meeting_mode.slice(1).toLowerCase()
        : '';

      // Meeting location/link
      const meetingLocation = meetingDetails.meet_link 
        ? `<a href="${meetingDetails.meet_link}" target="_blank" style="color:#5D87FF; text-decoration:none;">${meetingDetails.meet_link}</a>`
        : (meetingDetails.meeting_venue || 'TBD');

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `Monthly Meeting Invitation - ${meetingDetails.dealer_name || 'Partner Connect'}`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Monthly Meeting Invitation</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <h2 style="color:#003399; text-align:center; margin-bottom:20px;">Monthly Meeting Invitation</h2>
          <p>Dear Team Member,</p>
          <p>You have been invited to a <strong>Monthly Meeting</strong> for <strong>Partner Connect 2.0</strong>.</p>
          
          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Meeting Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${meetingDetails.dealer_name ? `<tr><td style="padding:5px 0;"><strong>Dealer:</strong></td><td style="padding:5px 0;">${meetingDetails.dealer_name}</td></tr>` : ''}
              ${meetingDetails.market_area ? `<tr><td style="padding:5px 0;"><strong>Market Area:</strong></td><td style="padding:5px 0;">${meetingDetails.market_area}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Date:</strong></td><td style="padding:5px 0;">${meetingDate}</td></tr>
              ${timeRange ? `<tr><td style="padding:5px 0;"><strong>Time:</strong></td><td style="padding:5px 0;">${timeRange}</td></tr>` : ''}
              ${meetingMode ? `<tr><td style="padding:5px 0;"><strong>Mode:</strong></td><td style="padding:5px 0;">${meetingMode}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Location/Link:</strong></td><td style="padding:5px 0;">${meetingLocation}</td></tr>
              ${meetingDetails.recurring_meeting ? `<tr><td style="padding:5px 0;"><strong>Recurring:</strong></td><td style="padding:5px 0;">Yes</td></tr>` : ''}
            </table>
          </div>

          ${meetingDetails.agenda_text ? `<div style="margin:20px 0;"><p><strong>Agenda:</strong></p><p style="white-space:pre-wrap;">${meetingDetails.agenda_text}</p></div>` : ''}
          
          ${meetingDetails.agenda_link ? `<p style="text-align:center; margin:20px 0;"><a href="${meetingDetails.agenda_link}" target="_blank" style="background:#5D87FF; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">View Agenda</a></p>` : ''}
          
          ${meetingDetails.meet_link ? `<p style="text-align:center; margin:20px 0;"><a href="${meetingDetails.meet_link}" target="_blank" style="background:#003399; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Join Meeting</a></p>` : ''}

          <p>Kind regards,<br/><strong></strong><br/>Partner Connect 2.0</p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  monthlyMeetingUpdateMail: async function (creatorName, emailArray, oldMeetingDetails, newMeetingDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray];

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format meeting date
      const formatDate = (date) => {
        if (!date) return '';
        return new Date(date).toLocaleDateString('en-US', { 
          weekday: 'long', 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        });
      };

      const oldMeetingDate = formatDate(oldMeetingDetails.meeting_date);
      const newMeetingDate = formatDate(newMeetingDetails.meeting_date);

      // Format time
      const formatTime = (time) => {
        if (!time) return '';
        const [hours, minutes] = time.split(':');
        const hour12 = parseInt(hours) % 12 || 12;
        const ampm = parseInt(hours) >= 12 ? 'PM' : 'AM';
        return `${hour12}:${minutes} ${ampm}`;
      };

      const oldStartTime = formatTime(oldMeetingDetails.start_time);
      const oldEndTime = formatTime(oldMeetingDetails.end_time);
      const oldTimeRange = oldStartTime && oldEndTime ? `${oldStartTime} - ${oldEndTime}` : (oldStartTime || oldEndTime || '');

      const newStartTime = formatTime(newMeetingDetails.start_time);
      const newEndTime = formatTime(newMeetingDetails.end_time);
      const newTimeRange = newStartTime && newEndTime ? `${newStartTime} - ${newEndTime}` : (newStartTime || newEndTime || '');

      // Meeting mode text
      const formatMode = (mode) => {
        if (!mode) return '';
        return mode.charAt(0).toUpperCase() + mode.slice(1).toLowerCase();
      };

      const oldMode = formatMode(oldMeetingDetails.meeting_mode);
      const newMode = formatMode(newMeetingDetails.meeting_mode);

      // Detect changes
      const changes = [];
      if (oldMeetingDate !== newMeetingDate) {
        changes.push({ field: 'Date', old: oldMeetingDate || 'N/A', new: newMeetingDate });
      }
      if (oldTimeRange !== newTimeRange) {
        changes.push({ field: 'Time', old: oldTimeRange || 'N/A', new: newTimeRange });
      }
      if (oldMode !== newMode) {
        changes.push({ field: 'Mode', old: oldMode || 'N/A', new: newMode });
      }
      if (oldMeetingDetails.meeting_venue !== newMeetingDetails.meeting_venue) {
        changes.push({ field: 'Venue', old: oldMeetingDetails.meeting_venue || 'N/A', new: newMeetingDetails.meeting_venue || 'N/A' });
      }
      if (oldMeetingDetails.meet_link !== newMeetingDetails.meet_link) {
        changes.push({ field: 'Meeting Link', old: oldMeetingDetails.meet_link || 'N/A', new: newMeetingDetails.meet_link || 'N/A' });
      }
      if (oldMeetingDetails.agenda_text !== newMeetingDetails.agenda_text) {
        changes.push({ field: 'Agenda', old: oldMeetingDetails.agenda_text || 'N/A', new: newMeetingDetails.agenda_text || 'N/A' });
      }
      if (oldMeetingDetails.recurring_meeting !== newMeetingDetails.recurring_meeting) {
        changes.push({ field: 'Recurring', old: oldMeetingDetails.recurring_meeting ? 'Yes' : 'No', new: newMeetingDetails.recurring_meeting ? 'Yes' : 'No' });
      }

      // Meeting location/link for new details
      const meetingLocation = newMeetingDetails.meet_link 
        ? `<a href="${newMeetingDetails.meet_link}" target="_blank" style="color:#5D87FF; text-decoration:none;">${newMeetingDetails.meet_link}</a>`
        : (newMeetingDetails.meeting_venue || 'TBD');

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `Monthly Meeting Updated - ${newMeetingDetails.dealer_name || 'Partner Connect'}`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Monthly Meeting Update</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <h2 style="color:#003399; text-align:center; margin-bottom:20px;">Monthly Meeting Updated</h2>
          <p>Dear Team Member,</p>
          <p>The following <strong>Monthly Meeting</strong> for <strong>Partner Connect 2.0</strong> has been updated.</p>
          
          ${changes.length > 0 ? `
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #ffc107;">
            <h3 style="color:#856404; margin-top:0; margin-bottom:15px;">⚠️ Changes Made</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${changes.map(change => `
                <tr>
                  <td style="padding:8px 0; border-bottom:1px solid #ffeaa7;">
                    <strong style="color:#856404;">${change.field}:</strong><br/>
                    <span style="color:#d63031; text-decoration:line-through;">${change.old}</span> 
                    <span style="color:#00b894;">→ ${change.new}</span>
                  </td>
                </tr>
              `).join('')}
            </table>
          </div>
          ` : ''}

          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Updated Meeting Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${newMeetingDetails.dealer_name ? `<tr><td style="padding:5px 0;"><strong>Dealer:</strong></td><td style="padding:5px 0;">${newMeetingDetails.dealer_name}</td></tr>` : ''}
              ${newMeetingDetails.market_area ? `<tr><td style="padding:5px 0;"><strong>Market Area:</strong></td><td style="padding:5px 0;">${newMeetingDetails.market_area}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Date:</strong></td><td style="padding:5px 0;">${newMeetingDate}</td></tr>
              ${newTimeRange ? `<tr><td style="padding:5px 0;"><strong>Time:</strong></td><td style="padding:5px 0;">${newTimeRange}</td></tr>` : ''}
              ${newMode ? `<tr><td style="padding:5px 0;"><strong>Mode:</strong></td><td style="padding:5px 0;">${newMode}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Location/Link:</strong></td><td style="padding:5px 0;">${meetingLocation}</td></tr>
              ${newMeetingDetails.recurring_meeting ? `<tr><td style="padding:5px 0;"><strong>Recurring:</strong></td><td style="padding:5px 0;">Yes</td></tr>` : ''}
            </table>
          </div>

          ${newMeetingDetails.agenda_text ? `<div style="margin:20px 0;"><p><strong>Agenda:</strong></p><p style="white-space:pre-wrap;">${newMeetingDetails.agenda_text}</p></div>` : ''}
          
          ${newMeetingDetails.agenda_link ? `<p style="text-align:center; margin:20px 0;"><a href="${newMeetingDetails.agenda_link}" target="_blank" style="background:#5D87FF; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">View Agenda</a></p>` : ''}
          
          ${newMeetingDetails.meet_link ? `<p style="text-align:center; margin:20px 0;"><a href="${newMeetingDetails.meet_link}" target="_blank" style="background:#003399; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Join Meeting</a></p>` : ''}

          <p style="color:#666; font-size:14px; margin-top:20px;">Please note the changes above and update your calendar accordingly.</p>

          <p>Kind regards,<br/><strong></strong><br/>Partner Connect 2.0</p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  monthlyMeetingStatusMail: async function (creatorName, emailArray, meetingDetails, status, cancellationReason) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray];

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format meeting date
      const formatDate = (date) => {
        if (!date) return '';
        return new Date(date).toLocaleDateString('en-US', { 
          weekday: 'long', 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        });
      };

      const meetingDate = formatDate(meetingDetails.meeting_date);

      // Format time
      const formatTime = (time) => {
        if (!time) return '';
        const [hours, minutes] = time.split(':');
        const hour12 = parseInt(hours) % 12 || 12;
        const ampm = parseInt(hours) >= 12 ? 'PM' : 'AM';
        return `${hour12}:${minutes} ${ampm}`;
      };

      const startTime = formatTime(meetingDetails.start_time);
      const endTime = formatTime(meetingDetails.end_time);
      const timeRange = startTime && endTime ? `${startTime} - ${endTime}` : (startTime || endTime || '');

      // Meeting mode text
      const meetingMode = meetingDetails.meeting_mode 
        ? meetingDetails.meeting_mode.charAt(0).toUpperCase() + meetingDetails.meeting_mode.slice(1).toLowerCase()
        : '';

      // Status-specific styling and message
      const isCancelled = status === 'Cancelled';
      const statusColor = isCancelled ? '#d63031' : '#00b894';
      const statusBgColor = isCancelled ? '#ffe5e5' : '#e5f9f6';
      const statusIcon = isCancelled ? '❌' : '✅';
      const statusTitle = isCancelled ? 'Meeting Cancelled' : 'Meeting Completed';
      const statusMessage = isCancelled 
        ? 'The following monthly meeting has been <strong>cancelled</strong>.'
        : 'The following monthly meeting has been <strong>completed</strong>.';

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `Monthly Meeting ${status} - ${meetingDetails.dealer_name || 'Partner Connect'}`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Monthly Meeting ${status}</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:${statusBgColor}; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid ${statusColor};">
            <h2 style="color:${statusColor}; text-align:center; margin:0; margin-bottom:10px;">${statusIcon} ${statusTitle}</h2>
            <p style="margin:0; text-align:center; color:#333;">${statusMessage}</p>
          </div>
          
          <p>Dear Team Member,</p>
          
          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Meeting Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${meetingDetails.dealer_name ? `<tr><td style="padding:5px 0;"><strong>Dealer:</strong></td><td style="padding:5px 0;">${meetingDetails.dealer_name}</td></tr>` : ''}
              ${meetingDetails.market_area ? `<tr><td style="padding:5px 0;"><strong>Market Area:</strong></td><td style="padding:5px 0;">${meetingDetails.market_area}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Date:</strong></td><td style="padding:5px 0;">${meetingDate}</td></tr>
              ${timeRange ? `<tr><td style="padding:5px 0;"><strong>Time:</strong></td><td style="padding:5px 0;">${timeRange}</td></tr>` : ''}
              ${meetingMode ? `<tr><td style="padding:5px 0;"><strong>Mode:</strong></td><td style="padding:5px 0;">${meetingMode}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Status:</strong></td><td style="padding:5px 0;"><strong style="color:${statusColor};">${status}</strong></td></tr>
            </table>
          </div>

          ${isCancelled && cancellationReason ? `
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #ffc107;">
            <p style="margin:0;"><strong>Cancellation Reason:</strong></p>
            <p style="margin:10px 0 0 0; white-space:pre-wrap;">${cancellationReason}</p>
          </div>
          ` : ''}

          <p style="color:#666; font-size:14px; margin-top:20px;">
            ${isCancelled 
              ? 'This meeting has been cancelled. Please update your calendar accordingly.' 
              : 'This meeting has been marked as completed. Thank you for your participation.'}
          </p>

          <p>Kind regards,<br/><strong></strong><br/>Partner Connect 2.0</p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  pdpCreatedMail: async function (emailArray, pdpDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for PDP creation notification');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format dates
      const formatDate = (date) => {
        if (!date) return 'N/A';
        try {
          return new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        } catch (error) {
          return date;
        }
      };

      const pdpStartDate = formatDate(pdpDetails.pdp_start_date);
      const pdpEndDate = formatDate(pdpDetails.pdp_end_date);
      const physicalPdpStartDate = formatDate(pdpDetails.physical_pdp_start_date);
      const physicalPdpEndDate = formatDate(pdpDetails.physical_pdp_end_date);

      // Format sign off status with color
      const statusColors = {
        'Not Started': '#ffc107',
        'Ongoing': '#5D87FF',
        'Closed': '#00b894'
      };
      const statusColor = statusColors[pdpDetails.sign_of_status] || '#333';

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `New PDP Created - ${pdpDetails.year} - Partner Connect 2.0`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>PDP Created</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#e5f9f6; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #00b894;">
            <h2 style="color:#00b894; text-align:center; margin:0; margin-bottom:10px;">✅ New PDP Created</h2>
            <p style="margin:0; text-align:center; color:#333;">A new PDP has been created for <strong>Partner Connect 2.0</strong>.</p>
          </div>
          
          <p>Dear Admin,</p>
          
          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">PDP Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Year:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${pdpDetails.year || 'N/A'}</td></tr>
              ${pdpDetails.market_area_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Market Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${pdpDetails.market_area_name}</td></tr>` : ''}
              ${pdpDetails.dealer_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Dealer:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${pdpDetails.dealer_name}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>PDP Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${pdpStartDate}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>PDP End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${pdpEndDate}</td></tr>
              ${physicalPdpStartDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical PDP Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${physicalPdpStartDate}</td></tr>` : ''}
              ${physicalPdpEndDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical PDP End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${physicalPdpEndDate}</td></tr>` : ''}
              <tr><td style="padding:8px 0;"><strong>Sign Off Status:</strong></td><td style="padding:8px 0;"><strong style="color:${statusColor};">${pdpDetails.sign_of_status || 'N/A'}</strong></td></tr>
            </table>
          </div>

          <p style="color:#666; font-size:14px; margin-top:20px;">
            Please review the PDP details above. The PDP has been successfully created in the system.
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  pdpUpdatedMail: async function (emailArray, oldPdpDetails, newPdpDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for PDP update notification');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format dates
      const formatDate = (date) => {
        if (!date) return 'N/A';
        try {
          return new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        } catch (error) {
          return date;
        }
      };

      // Detect changes
      const changes = [];
      
      // Compare year
      if (oldPdpDetails.year !== newPdpDetails.year) {
        changes.push({ 
          field: 'Year', 
          old: oldPdpDetails.year || 'N/A', 
          new: newPdpDetails.year || 'N/A' 
        });
      }

      // Compare market area
      if (oldPdpDetails.market_area_name !== newPdpDetails.market_area_name) {
        changes.push({ 
          field: 'Market Area', 
          old: oldPdpDetails.market_area_name || 'N/A', 
          new: newPdpDetails.market_area_name || 'N/A' 
        });
      }

      // Compare dealer
      if (oldPdpDetails.dealer_name !== newPdpDetails.dealer_name) {
        changes.push({ 
          field: 'Dealer', 
          old: oldPdpDetails.dealer_name || 'N/A', 
          new: newPdpDetails.dealer_name || 'N/A' 
        });
      }

      // Compare PDP start date
      const oldPdpStartDate = formatDate(oldPdpDetails.pdp_start_date);
      const newPdpStartDate = formatDate(newPdpDetails.pdp_start_date);
      if (oldPdpStartDate !== newPdpStartDate) {
        changes.push({ 
          field: 'PDP Start Date', 
          old: oldPdpStartDate, 
          new: newPdpStartDate 
        });
      }

      // Compare PDP end date
      const oldPdpEndDate = formatDate(oldPdpDetails.pdp_end_date);
      const newPdpEndDate = formatDate(newPdpDetails.pdp_end_date);
      if (oldPdpEndDate !== newPdpEndDate) {
        changes.push({ 
          field: 'PDP End Date', 
          old: oldPdpEndDate, 
          new: newPdpEndDate 
        });
      }

      // Compare physical PDP start date
      const oldPhysicalPdpStartDate = formatDate(oldPdpDetails.physical_pdp_start_date);
      const newPhysicalPdpStartDate = formatDate(newPdpDetails.physical_pdp_start_date);
      if (oldPhysicalPdpStartDate !== newPhysicalPdpStartDate) {
        changes.push({ 
          field: 'Physical PDP Start Date', 
          old: oldPhysicalPdpStartDate, 
          new: newPhysicalPdpStartDate 
        });
      }

      // Compare physical PDP end date
      const oldPhysicalPdpEndDate = formatDate(oldPdpDetails.physical_pdp_end_date);
      const newPhysicalPdpEndDate = formatDate(newPdpDetails.physical_pdp_end_date);
      if (oldPhysicalPdpEndDate !== newPhysicalPdpEndDate) {
        changes.push({ 
          field: 'Physical PDP End Date', 
          old: oldPhysicalPdpEndDate, 
          new: newPhysicalPdpEndDate 
        });
      }

      // Compare sign off status
      if (oldPdpDetails.sign_of_status !== newPdpDetails.sign_of_status) {
        changes.push({ 
          field: 'Sign Off Status', 
          old: oldPdpDetails.sign_of_status || 'N/A', 
          new: newPdpDetails.sign_of_status || 'N/A' 
        });
      }

      // Format sign off status with color
      const statusColors = {
        'Not Started': '#ffc107',
        'Ongoing': '#5D87FF',
        'Closed': '#00b894'
      };
      const statusColor = statusColors[newPdpDetails.sign_of_status] || '#333';

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `PDP Updated - ${newPdpDetails.year} - Partner Connect 2.0`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>PDP Updated</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #ffc107;">
            <h2 style="color:#856404; text-align:center; margin:0; margin-bottom:10px;">⚠️ PDP Updated</h2>
            <p style="margin:0; text-align:center; color:#333;">A PDP has been updated for <strong>Partner Connect 2.0</strong>.</p>
          </div>
          
          <p>Dear Admin,</p>
          
          ${changes.length > 0 ? `
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #ffc107;">
            <h3 style="color:#856404; margin-top:0; margin-bottom:15px;">⚠️ Changes Made</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${changes.map(change => `
                <tr>
                  <td style="padding:8px 0; border-bottom:1px solid #ffeaa7;">
                    <strong style="color:#856404;">${change.field}:</strong><br/>
                    <span style="color:#d63031; text-decoration:line-through;">${change.old}</span> 
                    <span style="color:#00b894;">→ ${change.new}</span>
                  </td>
                </tr>
              `).join('')}
            </table>
          </div>
          ` : ''}

          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Updated PDP Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Year:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPdpDetails.year || 'N/A'}</td></tr>
              ${newPdpDetails.market_area_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Market Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPdpDetails.market_area_name}</td></tr>` : ''}
              ${newPdpDetails.dealer_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Dealer:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPdpDetails.dealer_name}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>PDP Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPdpStartDate}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>PDP End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPdpEndDate}</td></tr>
              ${newPhysicalPdpStartDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical PDP Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPhysicalPdpStartDate}</td></tr>` : ''}
              ${newPhysicalPdpEndDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical PDP End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPhysicalPdpEndDate}</td></tr>` : ''}
              <tr><td style="padding:8px 0;"><strong>Sign Off Status:</strong></td><td style="padding:8px 0;"><strong style="color:${statusColor};">${newPdpDetails.sign_of_status || 'N/A'}</strong></td></tr>
            </table>
          </div>

          <p style="color:#666; font-size:14px; margin-top:20px;">
            ${changes.length > 0 
              ? 'Please review the changes above. The PDP has been successfully updated in the system.' 
              : 'The PDP has been updated. Please review the details above.'}
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  scorecardCreatedMailForDealers: async function (emailArray, scorecardDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for scorecard creation notification to dealers');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format dates
      const formatDate = (date) => {
        if (!date) return 'N/A';
        try {
          return new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        } catch (error) {
          return date;
        }
      };

      const auditStartDate = formatDate(scorecardDetails.audit_start_date);
      const auditEndDate = formatDate(scorecardDetails.audit_end_date);
      const physicalAuditStartDate = formatDate(scorecardDetails.physical_audit_start_date);
      const physicalAuditEndDate = formatDate(scorecardDetails.physical_audit_end_date);

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `New Scorecard Created - ${scorecardDetails.year} - Partner Connect 2.0`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Scorecard Created</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#e5f9f6; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #00b894;">
            <h2 style="color:#00b894; text-align:center; margin:0; margin-bottom:10px;">✅ New Scorecard Created</h2>
            <p style="margin:0; text-align:center; color:#333;">A new scorecard has been created for <strong>Partner Connect 2.0</strong>.</p>
          </div>
          
          <p>Dear Dealer,</p>
          
          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Scorecard Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Year:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.year || 'N/A'}</td></tr>
              ${scorecardDetails.market_area_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Market Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.market_area_name}</td></tr>` : ''}
              ${scorecardDetails.dealer_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Dealer:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.dealer_name}</td></tr>` : ''}
              ${scorecardDetails.frequency ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Frequency:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.frequency}</td></tr>` : ''}
              ${scorecardDetails.quarter_frequency ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Quarter:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.quarter_frequency}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${auditStartDate}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${auditEndDate}</td></tr>
              ${physicalAuditStartDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical Audit Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${physicalAuditStartDate}</td></tr>` : ''}
              ${physicalAuditEndDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical Audit End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${physicalAuditEndDate}</td></tr>` : ''}
              ${scorecardDetails.lead_auditor_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Lead Auditor:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.lead_auditor_name}</td></tr>` : ''}
              ${scorecardDetails.co_auditor_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Co Auditor:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.co_auditor_name}</td></tr>` : ''}
              ${scorecardDetails.audit_location ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit Location:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.audit_location}</td></tr>` : ''}
              ${scorecardDetails.branch ? `<tr><td style="padding:8px 0;"><strong>Branch:</strong></td><td style="padding:8px 0;">${scorecardDetails.branch}</td></tr>` : ''}
            </table>
          </div>

          ${scorecardDetails.remarks ? `<div style="margin:20px 0;"><p><strong>Remarks:</strong></p><p style="white-space:pre-wrap;">${scorecardDetails.remarks}</p></div>` : ''}

          <p style="color:#666; font-size:14px; margin-top:20px;">
            Please review the scorecard details above. The scorecard has been successfully created in the system.
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  scorecardCreatedMailForAuditors: async function (emailArray, scorecardDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for scorecard creation notification to auditors');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format dates
      const formatDate = (date) => {
        if (!date) return 'N/A';
        try {
          return new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        } catch (error) {
          return date;
        }
      };

      const auditStartDate = formatDate(scorecardDetails.audit_start_date);
      const auditEndDate = formatDate(scorecardDetails.audit_end_date);
      const physicalAuditStartDate = formatDate(scorecardDetails.physical_audit_start_date);
      const physicalAuditEndDate = formatDate(scorecardDetails.physical_audit_end_date);

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `New Scorecard Assigned - ${scorecardDetails.year} - Partner Connect 2.0`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Scorecard Assigned</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#e3f2fd; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #5D87FF;">
            <h2 style="color:#5D87FF; text-align:center; margin:0; margin-bottom:10px;">📋 New Scorecard Assigned</h2>
            <p style="margin:0; text-align:center; color:#333;">A new scorecard has been assigned to you for <strong>Partner Connect 2.0</strong>.</p>
          </div>
          
          <p>Dear Auditor,</p>
          
          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Scorecard Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Year:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.year || 'N/A'}</td></tr>
              ${scorecardDetails.market_area_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Market Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.market_area_name}</td></tr>` : ''}
              ${scorecardDetails.dealer_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Dealer:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.dealer_name}</td></tr>` : ''}
              ${scorecardDetails.frequency ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Frequency:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.frequency}</td></tr>` : ''}
              ${scorecardDetails.quarter_frequency ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Quarter:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.quarter_frequency}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${auditStartDate}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${auditEndDate}</td></tr>
              ${physicalAuditStartDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical Audit Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${physicalAuditStartDate}</td></tr>` : ''}
              ${physicalAuditEndDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical Audit End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${physicalAuditEndDate}</td></tr>` : ''}
              ${scorecardDetails.lead_auditor_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Lead Auditor:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.lead_auditor_name}</td></tr>` : ''}
              ${scorecardDetails.co_auditor_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Co Auditor:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.co_auditor_name}</td></tr>` : ''}
              ${scorecardDetails.audit_location ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit Location:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${scorecardDetails.audit_location}</td></tr>` : ''}
              ${scorecardDetails.branch ? `<tr><td style="padding:8px 0;"><strong>Branch:</strong></td><td style="padding:8px 0;">${scorecardDetails.branch}</td></tr>` : ''}
            </table>
          </div>

          ${scorecardDetails.remarks ? `<div style="margin:20px 0;"><p><strong>Remarks:</strong></p><p style="white-space:pre-wrap;">${scorecardDetails.remarks}</p></div>` : ''}

          <p style="color:#666; font-size:14px; margin-top:20px;">
            Please review the scorecard details above and prepare for the audit accordingly.
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  scorecardUpdatedMailForDealers: async function (emailArray, oldScorecardDetails, newScorecardDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for scorecard update notification to dealers');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format dates
      const formatDate = (date) => {
        if (!date) return 'N/A';
        try {
          return new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        } catch (error) {
          return date;
        }
      };

      // Detect changes
      const changes = [];
      
      if (oldScorecardDetails.year !== newScorecardDetails.year) {
        changes.push({ 
          field: 'Year', 
          old: oldScorecardDetails.year || 'N/A', 
          new: newScorecardDetails.year || 'N/A' 
        });
      }

      if (oldScorecardDetails.market_area_name !== newScorecardDetails.market_area_name) {
        changes.push({ 
          field: 'Market Area', 
          old: oldScorecardDetails.market_area_name || 'N/A', 
          new: newScorecardDetails.market_area_name || 'N/A' 
        });
      }

      if (oldScorecardDetails.dealer_name !== newScorecardDetails.dealer_name) {
        changes.push({ 
          field: 'Dealer', 
          old: oldScorecardDetails.dealer_name || 'N/A', 
          new: newScorecardDetails.dealer_name || 'N/A' 
        });
      }

      if (oldScorecardDetails.frequency !== newScorecardDetails.frequency) {
        changes.push({ 
          field: 'Frequency', 
          old: oldScorecardDetails.frequency || 'N/A', 
          new: newScorecardDetails.frequency || 'N/A' 
        });
      }

      if (oldScorecardDetails.quarter_frequency !== newScorecardDetails.quarter_frequency) {
        changes.push({ 
          field: 'Quarter', 
          old: oldScorecardDetails.quarter_frequency || 'N/A', 
          new: newScorecardDetails.quarter_frequency || 'N/A' 
        });
      }

      const oldAuditStartDate = formatDate(oldScorecardDetails.audit_start_date);
      const newAuditStartDate = formatDate(newScorecardDetails.audit_start_date);
      if (oldAuditStartDate !== newAuditStartDate) {
        changes.push({ 
          field: 'Audit Start Date', 
          old: oldAuditStartDate, 
          new: newAuditStartDate 
        });
      }

      const oldAuditEndDate = formatDate(oldScorecardDetails.audit_end_date);
      const newAuditEndDate = formatDate(newScorecardDetails.audit_end_date);
      if (oldAuditEndDate !== newAuditEndDate) {
        changes.push({ 
          field: 'Audit End Date', 
          old: oldAuditEndDate, 
          new: newAuditEndDate 
        });
      }

      const oldPhysicalAuditStartDate = formatDate(oldScorecardDetails.physical_audit_start_date);
      const newPhysicalAuditStartDate = formatDate(newScorecardDetails.physical_audit_start_date);
      if (oldPhysicalAuditStartDate !== newPhysicalAuditStartDate) {
        changes.push({ 
          field: 'Physical Audit Start Date', 
          old: oldPhysicalAuditStartDate, 
          new: newPhysicalAuditStartDate 
        });
      }

      const newPhysicalAuditEndDate = formatDate(newScorecardDetails.physical_audit_end_date);
      const oldPhysicalAuditEndDate = formatDate(oldScorecardDetails.physical_audit_end_date);
      if (oldPhysicalAuditEndDate !== newPhysicalAuditEndDate) {
        changes.push({ 
          field: 'Physical Audit End Date', 
          old: oldPhysicalAuditEndDate, 
          new: newPhysicalAuditEndDate 
        });
      }

      if (oldScorecardDetails.lead_auditor_name !== newScorecardDetails.lead_auditor_name) {
        changes.push({ 
          field: 'Lead Auditor', 
          old: oldScorecardDetails.lead_auditor_name || 'N/A', 
          new: newScorecardDetails.lead_auditor_name || 'N/A' 
        });
      }

      if (oldScorecardDetails.co_auditor_name !== newScorecardDetails.co_auditor_name) {
        changes.push({ 
          field: 'Co Auditor', 
          old: oldScorecardDetails.co_auditor_name || 'N/A', 
          new: newScorecardDetails.co_auditor_name || 'N/A' 
        });
      }

      if (oldScorecardDetails.audit_location !== newScorecardDetails.audit_location) {
        changes.push({ 
          field: 'Audit Location', 
          old: oldScorecardDetails.audit_location || 'N/A', 
          new: newScorecardDetails.audit_location || 'N/A' 
        });
      }

      if (oldScorecardDetails.branch !== newScorecardDetails.branch) {
        changes.push({ 
          field: 'Branch', 
          old: oldScorecardDetails.branch || 'N/A', 
          new: newScorecardDetails.branch || 'N/A' 
        });
      }

      if (oldScorecardDetails.remarks !== newScorecardDetails.remarks) {
        changes.push({ 
          field: 'Remarks', 
          old: oldScorecardDetails.remarks || 'N/A', 
          new: newScorecardDetails.remarks || 'N/A' 
        });
      }

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `Scorecard Updated - ${newScorecardDetails.year} - Partner Connect 2.0`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Scorecard Updated</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #ffc107;">
            <h2 style="color:#856404; text-align:center; margin:0; margin-bottom:10px;">⚠️ Scorecard Updated</h2>
            <p style="margin:0; text-align:center; color:#333;">A scorecard has been updated for <strong>Partner Connect 2.0</strong>.</p>
          </div>
          
          <p>Dear Dealer,</p>
          
          ${changes.length > 0 ? `
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #ffc107;">
            <h3 style="color:#856404; margin-top:0; margin-bottom:15px;">⚠️ Changes Made</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${changes.map(change => `
                <tr>
                  <td style="padding:8px 0; border-bottom:1px solid #ffeaa7;">
                    <strong style="color:#856404;">${change.field}:</strong><br/>
                    <span style="color:#d63031; text-decoration:line-through;">${change.old}</span> 
                    <span style="color:#00b894;">→ ${change.new}</span>
                  </td>
                </tr>
              `).join('')}
            </table>
          </div>
          ` : ''}

          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Updated Scorecard Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Year:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.year || 'N/A'}</td></tr>
              ${newScorecardDetails.market_area_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Market Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.market_area_name}</td></tr>` : ''}
              ${newScorecardDetails.dealer_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Dealer:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.dealer_name}</td></tr>` : ''}
              ${newScorecardDetails.frequency ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Frequency:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.frequency}</td></tr>` : ''}
              ${newScorecardDetails.quarter_frequency ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Quarter:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.quarter_frequency}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newAuditStartDate}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newAuditEndDate}</td></tr>
              ${newPhysicalAuditStartDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical Audit Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPhysicalAuditStartDate}</td></tr>` : ''}
              ${newPhysicalAuditEndDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical Audit End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPhysicalAuditEndDate}</td></tr>` : ''}
              ${newScorecardDetails.lead_auditor_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Lead Auditor:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.lead_auditor_name}</td></tr>` : ''}
              ${newScorecardDetails.co_auditor_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Co Auditor:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.co_auditor_name}</td></tr>` : ''}
              ${newScorecardDetails.audit_location ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit Location:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.audit_location}</td></tr>` : ''}
              ${newScorecardDetails.branch ? `<tr><td style="padding:8px 0;"><strong>Branch:</strong></td><td style="padding:8px 0;">${newScorecardDetails.branch}</td></tr>` : ''}
            </table>
          </div>

          ${newScorecardDetails.remarks ? `<div style="margin:20px 0;"><p><strong>Remarks:</strong></p><p style="white-space:pre-wrap;">${newScorecardDetails.remarks}</p></div>` : ''}

          <p style="color:#666; font-size:14px; margin-top:20px;">
            ${changes.length > 0 
              ? 'Please review the changes above. The scorecard has been successfully updated in the system.' 
              : 'The scorecard has been updated. Please review the details above.'}
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  scorecardUpdatedMailForAuditors: async function (emailArray, oldScorecardDetails, newScorecardDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for scorecard update notification to auditors');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format dates
      const formatDate = (date) => {
        if (!date) return 'N/A';
        try {
          return new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        } catch (error) {
          return date;
        }
      };

      // Detect changes (same as dealer function)
      const changes = [];
      
      if (oldScorecardDetails.year !== newScorecardDetails.year) {
        changes.push({ 
          field: 'Year', 
          old: oldScorecardDetails.year || 'N/A', 
          new: newScorecardDetails.year || 'N/A' 
        });
      }

      if (oldScorecardDetails.market_area_name !== newScorecardDetails.market_area_name) {
        changes.push({ 
          field: 'Market Area', 
          old: oldScorecardDetails.market_area_name || 'N/A', 
          new: newScorecardDetails.market_area_name || 'N/A' 
        });
      }

      if (oldScorecardDetails.dealer_name !== newScorecardDetails.dealer_name) {
        changes.push({ 
          field: 'Dealer', 
          old: oldScorecardDetails.dealer_name || 'N/A', 
          new: newScorecardDetails.dealer_name || 'N/A' 
        });
      }

      if (oldScorecardDetails.frequency !== newScorecardDetails.frequency) {
        changes.push({ 
          field: 'Frequency', 
          old: oldScorecardDetails.frequency || 'N/A', 
          new: newScorecardDetails.frequency || 'N/A' 
        });
      }

      if (oldScorecardDetails.quarter_frequency !== newScorecardDetails.quarter_frequency) {
        changes.push({ 
          field: 'Quarter', 
          old: oldScorecardDetails.quarter_frequency || 'N/A', 
          new: newScorecardDetails.quarter_frequency || 'N/A' 
        });
      }

      const oldAuditStartDate = formatDate(oldScorecardDetails.audit_start_date);
      const newAuditStartDate = formatDate(newScorecardDetails.audit_start_date);
      if (oldAuditStartDate !== newAuditStartDate) {
        changes.push({ 
          field: 'Audit Start Date', 
          old: oldAuditStartDate, 
          new: newAuditStartDate 
        });
      }

      const oldAuditEndDate = formatDate(oldScorecardDetails.audit_end_date);
      const newAuditEndDate = formatDate(newScorecardDetails.audit_end_date);
      if (oldAuditEndDate !== newAuditEndDate) {
        changes.push({ 
          field: 'Audit End Date', 
          old: oldAuditEndDate, 
          new: newAuditEndDate 
        });
      }

      const oldPhysicalAuditStartDate = formatDate(oldScorecardDetails.physical_audit_start_date);
      const newPhysicalAuditStartDate = formatDate(newScorecardDetails.physical_audit_start_date);
      if (oldPhysicalAuditStartDate !== newPhysicalAuditStartDate) {
        changes.push({ 
          field: 'Physical Audit Start Date', 
          old: oldPhysicalAuditStartDate, 
          new: newPhysicalAuditStartDate 
        });
      }

      const newPhysicalAuditEndDate = formatDate(newScorecardDetails.physical_audit_end_date);
      const oldPhysicalAuditEndDate = formatDate(oldScorecardDetails.physical_audit_end_date);
      if (oldPhysicalAuditEndDate !== newPhysicalAuditEndDate) {
        changes.push({ 
          field: 'Physical Audit End Date', 
          old: oldPhysicalAuditEndDate, 
          new: newPhysicalAuditEndDate 
        });
      }

      if (oldScorecardDetails.lead_auditor_name !== newScorecardDetails.lead_auditor_name) {
        changes.push({ 
          field: 'Lead Auditor', 
          old: oldScorecardDetails.lead_auditor_name || 'N/A', 
          new: newScorecardDetails.lead_auditor_name || 'N/A' 
        });
      }

      if (oldScorecardDetails.co_auditor_name !== newScorecardDetails.co_auditor_name) {
        changes.push({ 
          field: 'Co Auditor', 
          old: oldScorecardDetails.co_auditor_name || 'N/A', 
          new: newScorecardDetails.co_auditor_name || 'N/A' 
        });
      }

      if (oldScorecardDetails.audit_location !== newScorecardDetails.audit_location) {
        changes.push({ 
          field: 'Audit Location', 
          old: oldScorecardDetails.audit_location || 'N/A', 
          new: newScorecardDetails.audit_location || 'N/A' 
        });
      }

      if (oldScorecardDetails.branch !== newScorecardDetails.branch) {
        changes.push({ 
          field: 'Branch', 
          old: oldScorecardDetails.branch || 'N/A', 
          new: newScorecardDetails.branch || 'N/A' 
        });
      }

      if (oldScorecardDetails.remarks !== newScorecardDetails.remarks) {
        changes.push({ 
          field: 'Remarks', 
          old: oldScorecardDetails.remarks || 'N/A', 
          new: newScorecardDetails.remarks || 'N/A' 
        });
      }

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `Scorecard Updated - ${newScorecardDetails.year} - Partner Connect 2.0`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Scorecard Updated</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #ffc107;">
            <h2 style="color:#856404; text-align:center; margin:0; margin-bottom:10px;">⚠️ Scorecard Updated</h2>
            <p style="margin:0; text-align:center; color:#333;">A scorecard assigned to you has been updated for <strong>Partner Connect 2.0</strong>.</p>
          </div>
          
          <p>Dear Auditor,</p>
          
          ${changes.length > 0 ? `
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #ffc107;">
            <h3 style="color:#856404; margin-top:0; margin-bottom:15px;">⚠️ Changes Made</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${changes.map(change => `
                <tr>
                  <td style="padding:8px 0; border-bottom:1px solid #ffeaa7;">
                    <strong style="color:#856404;">${change.field}:</strong><br/>
                    <span style="color:#d63031; text-decoration:line-through;">${change.old}</span> 
                    <span style="color:#00b894;">→ ${change.new}</span>
                  </td>
                </tr>
              `).join('')}
            </table>
          </div>
          ` : ''}

          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Updated Scorecard Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Year:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.year || 'N/A'}</td></tr>
              ${newScorecardDetails.market_area_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Market Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.market_area_name}</td></tr>` : ''}
              ${newScorecardDetails.dealer_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Dealer:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.dealer_name}</td></tr>` : ''}
              ${newScorecardDetails.frequency ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Frequency:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.frequency}</td></tr>` : ''}
              ${newScorecardDetails.quarter_frequency ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Quarter:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.quarter_frequency}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newAuditStartDate}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newAuditEndDate}</td></tr>
              ${newPhysicalAuditStartDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical Audit Start Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPhysicalAuditStartDate}</td></tr>` : ''}
              ${newPhysicalAuditEndDate !== 'N/A' ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Physical Audit End Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newPhysicalAuditEndDate}</td></tr>` : ''}
              ${newScorecardDetails.lead_auditor_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Lead Auditor:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.lead_auditor_name}</td></tr>` : ''}
              ${newScorecardDetails.co_auditor_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Co Auditor:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.co_auditor_name}</td></tr>` : ''}
              ${newScorecardDetails.audit_location ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Audit Location:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newScorecardDetails.audit_location}</td></tr>` : ''}
              ${newScorecardDetails.branch ? `<tr><td style="padding:8px 0;"><strong>Branch:</strong></td><td style="padding:8px 0;">${newScorecardDetails.branch}</td></tr>` : ''}
            </table>
          </div>

          ${newScorecardDetails.remarks ? `<div style="margin:20px 0;"><p><strong>Remarks:</strong></p><p style="white-space:pre-wrap;">${newScorecardDetails.remarks}</p></div>` : ''}

          <p style="color:#666; font-size:14px; margin-top:20px;">
            ${changes.length > 0 
              ? 'Please review the changes above and update your schedule accordingly. The scorecard has been successfully updated in the system.' 
              : 'The scorecard has been updated. Please review the details above and update your schedule accordingly.'}
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  scorecardActionItemMail: async function (emailArray, actionItemDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for scorecard action item notification');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `Action Item Created - Scorecard Threshold Not Met - Partner Connect 2.0`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Action Item Created</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#ffe5e5; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #d63031;">
            <h2 style="color:#d63031; text-align:center; margin:0; margin-bottom:10px;">⚠️ Action Item Created</h2>
            <p style="margin:0; text-align:center; color:#333;">A new action item has been created because the scorecard threshold was not met.</p>
          </div>
          
          <p>Dear Auditor,</p>
          
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #ffc107;">
            <h3 style="color:#856404; margin-top:0; margin-bottom:15px;">⚠️ Threshold Not Met</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr>
                <td style="padding:8px 0; border-bottom:1px solid #ffeaa7;"><strong>Final Score:</strong></td>
                <td style="padding:8px 0; border-bottom:1px solid #ffeaa7;"><strong style="color:#d63031; font-size:18px;">${actionItemDetails.final_score || 'N/A'}</strong></td>
              </tr>
              <tr>
                <td style="padding:8px 0;"><strong>Minimum Required Score:</strong></td>
                <td style="padding:8px 0;"><strong style="color:#00b894; font-size:18px;">${actionItemDetails.minScoreValue || 'N/A'}</strong></td>
              </tr>
            </table>
            <p style="margin:15px 0 0 0; color:#856404; font-weight:bold;">
              The final score is below the minimum required threshold. An action item has been automatically created.
            </p>
          </div>
          
          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Action Item Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${actionItemDetails.action_item_id ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Action Item ID:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.action_item_id}</td></tr>` : ''}
              ${actionItemDetails.scorecard_id ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Scorecard ID:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.scorecard_id}</td></tr>` : ''}
              ${actionItemDetails.scorecard_year ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Year:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.scorecard_year}</td></tr>` : ''}
              ${actionItemDetails.dealer_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Dealer:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.dealer_name}</td></tr>` : ''}
              ${actionItemDetails.market_area_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Market Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.market_area_name}</td></tr>` : ''}
              ${actionItemDetails.sub_kpi_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Sub KPI:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.sub_kpi_name}</td></tr>` : ''}
              ${actionItemDetails.kpi_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>KPI:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.kpi_name}</td></tr>` : ''}
              ${actionItemDetails.objective_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Strategic Objective:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.objective_name}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Action Item Status:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong style="color:#5D87FF;">${actionItemDetails.action_item_status || 'Created'}</strong></td></tr>
              ${actionItemDetails.created_at ? `<tr><td style="padding:8px 0;"><strong>Created At:</strong></td><td style="padding:8px 0;">${new Date(actionItemDetails.created_at).toLocaleString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td></tr>` : ''}
            </table>
          </div>

          <p style="color:#666; font-size:14px; margin-top:20px;">
            Please review the action item and take necessary steps to address the scorecard threshold issue.
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  }
};
