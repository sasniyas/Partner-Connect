const moment = require('moment')
const { connection } = require('../mySql/mySql')
const jwt = require('jsonwebtoken')
const fs = require('fs');
//const {regMail,shareNotifyMAil} =require('./eMailer')

module.exports = {
  userReg: async function (req, res) {
    try {
      let {
        LastName,
        middleName,
        FirstName,
        email,
        usertype,
        location,
        userrole,
        marketarea,
        dealership,
        temdetective
      } = req.body;

      // Check if email already exists
      let validateQ = `SELECT * FROM user WHERE email = '${email}'`;
      let validateData = await connection.query(validateQ);

      if (validateData.length !== 0) {
        return res.status(200).send({
          status: true,
          message: "User already exists!"
        });
      }

      // Created timestamp
      let createdOn = moment().format("YYYY-MM-DD HH:mm:ss");

      // Insert query
      let query = `
        INSERT INTO user 
        (LastName, middleName, FirstName, email, usertype, location, userrole, marketarea, dealership, temdetective, createdOn) 
        VALUES 
        ('${LastName}', '${middleName}', '${FirstName}', '${email}', '${usertype}', '${location}', '${userrole}', '${marketarea}', '${dealership}', '${temdetective}', '${createdOn}')
      `;

      await connection.query(query);

      return res.status(200).send({
        status: true,
        message: "User successfully registered!"
      });

    } catch (error) {
      return res.status(500).send({
        status: false,
        message: error.message
      });
    }
  },
    userLogin: async function (req, res) {
        try {
            let { mail, password } = req.body
            let query = `SELECT * FROM users where mail='${mail}';`
            let deviceData = await connection.query(query);
            if (deviceData.length == 0) {
                return res.status(200).send({
                    status: true,
                    message: 'not registred!'
                })
            }

            if (deviceData[0].password == password) {
                let id = deviceData[0].id
                let category = deviceData[0].category
                let token = jwt.sign(
                    { userId: id },
                    "#@$Advity#Store",
                    { expiresIn: "12h" }
                );

                return res.status(200).send({
                    status: true,
                    token: token,
                    category: category,
                    message: 'Succesfully Logged In!'
                })

            } else {

                return res.status(200).send({
                    status: false,
                    message: 'Id & password is not correct!'
                })

            }

        } catch (error) {
            res.status(500).send({
                status: false,
                message: error.message
            })
        }
    },
    userdataByid: async function (req, res) {
        try {
            let id = req.decodedToken
            let adminquery = `SELECT * FROM users where id=${id};`
            let admin = await connection.query(adminquery);
            let admindata
            if (admin.length == 0) {
                return res.status(200).send({
                    status: false,
                    message: 'not registred!'
                })
            } else {
                admindata = admin[0]
                return res.status(200).send({
                    status: true,
                    data: admindata,
                    message: 'user data!'
                })
            }

        } catch (error) {
            return res.status(500).send({
                status: false,
                message: error.message
            })
        }
    },
}


