const nodemailer = require('nodemailer');

module.exports={ 
monthlyMeetingMail:async function (admin,user,mail,link) {
  try {
    // Ensure mail is an array
    const emailArray = Array.isArray(mail) ? mail : [mail];
    
    // Connect with SMTP
    const transporter = await nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
      }
    });	

    const results = [];
    
    // Loop through each email and send individually
    for (const email of emailArray) {
      try {
        let info = await transporter.sendMail({
          from: 'sameer.panigrahi@advity.in', // sender address
          to: `${email}`, // individual receiver
          subject: "Activate account Partner Connect 2.0", // Subject line
          html:`<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Activate Account</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <h2 style="color:#003399; text-align:center;">Activate account Partner Connect 2.0</h2>
          <p><strong>Invited by:</strong>${admin}</p>
          <p>Dear <strong>${user}</strong>,</p>
          <p>You are invited as a user for <strong>Partner Connect 2.0</strong> (<a href="https://lively-bay-0661a5200.1.azurestaticapps.net/" target="_blank">partnerconnect2.0.testenv.in</a>).</p>
          <p>Click the button below to set your password and activate your account.</p>
          <p style="text-align:center; margin:30px 0;">
            <a href="${link}" target="_blank" style="background:#5D87FF; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Activate account</a>
          </p>
          <p>Kind regards,<br/>${admin}</p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`, // plain text body
        });
        results.push({ email, success: true, info });
      } catch (emailError) {
        console.log(`Error sending email to ${email}:`, emailError);
        results.push({ email, success: false, error: emailError });
      }
    }
    
    return results;
  }
  catch (error) {
    console.log(error);
    return error;
  }
},
forgotPassMail:async function (user,mail,link) {
  try {
//Connect with SMTP
    const transporter =await nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
      }
  });	


  let info = await transporter.sendMail({
    from: 'sameer.panigrahi@advity.in', // sender address
    to: `${mail}`, // list of receivers
    subject: "Reset your password - Partner Connect 2.0", // Subject line
     html:`<!DOCTYPE HTML
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional //EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
  xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Reset Password</title>
</head>

<body style="margin:0;padding:0;background-color:#f9f9f9;color:#000000;font-family:'Cabin',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" bgcolor="#f9f9f9">
    <tr>
      <td align="center" style="padding:10px 0;">
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png"
          alt="Partner_Connect" width="180" />
      </td>
    </tr>
    <tr>
    <tr>
      <td align="center">
        <!-- Body -->
        <table width="600" cellpadding="0" cellspacing="0" bgcolor="#ffffff" style="background-color:#f3f9f9;">
          <tr>
            <td style="padding:33px 55px; text-align:left; font-size:15px; color:#333;">
              <p>Dear <strong>${user}</strong>,</p>
              <p>You made a request to reset your password for <strong>Partner Connect 2.0</strong>. Click the link below:
              </p>
              <br>
              <p style="text-align:center; margin:30px 0;">
                <a href="${link}" target="_blank"
                  style="background:#5D87FF; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Reset
                  Password</a>
              </p>

              <br><br>
              <p>If you did not request this, you can safely ignore this email.</p>
              <p>Kind regards,<br>Team Partner Connect 2.0</p>
            </td>
          </tr>
        </table>

        <!-- Footer -->
        <table width="600" cellpadding="0" cellspacing="0" bgcolor="#003399">
          <tr>
            <td align="center" style="padding:15px; background-color:#786767; color:#fafafa; font-size:12px;">
              <p style="margin:5px 0;">This is an automatically generated message. Replies to this message will not be
                answered.</p>
              <p style="margin:5px 0;">Attention: This message is generated in the testing environment (Staging).<br>
                This message was sent for testing purposes. You may ignore the content.</p>
            </td>
          </tr>
        </table>

      </td>
    </tr>
  </table>
</body>

</html>`, // plain text body
  });
return info 
  }
  catch (error) {
    console.log(error)
    return error
  }

}
}