const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");
const UserLogs = require('../user/userLogs');
const moment = require("moment-timezone");
const { connection } = require("../../mySql/mySql"); // your mysql connection
// 🔹 Azure JWKS client
const client = jwksClient({
  jwksUri:
    "https://login.microsoftonline.com/f25493ae-1c98-41d7-8a33-0be75f5fe603/discovery/v2.0/keys",
  cache: true,
  rateLimit: true,
  jwksRequestsPerMinute: 5,
});

// 🔑 Key resolver
function getKey(header, callback) {
  if (!header.kid) {
    return callback(new Error("No KID found in token header"));
  }

  client.getSigningKey(header.kid, (err, key) => {
    if (err) {
      console.error("JWKS error:", err);
      return callback(err);
    }

    const signingKey = key.getPublicKey();
    callback(null, signingKey);
  });
}

module.exports = {
  ssoLogin: async (req, res) => {
    try {
      console.log("helloworld");
      const { idToken } = req.body;

      if (!idToken) {
        return res.status(400).json({ message: "Access token missing" });
      }

      // 🔍 Debug header
      const decodedHeader = jwt.decode(idToken, { complete: true });
      console.log("TOKEN KID:", decodedHeader?.header?.kid);

      jwt.verify(
        idToken,
        getKey,
        {
          algorithms: ["RS256"],
          audience: "dd6b1598-fab8-4241-930e-e1de370a9e64",
          issuer:
            "https://login.microsoftonline.com/f25493ae-1c98-41d7-8a33-0be75f5fe603/v2.0",
        },
        async (err, decoded) => {
          if (err) {
            console.error("JWT VERIFY ERROR:", err.message);
            return res.status(401).json({ message: "Invalid token" });
          }

          if (!decoded) {
            console.error("JWT VERIFY ERROR:", err.message);
            return res.status(400).json({ message: "No User found" });
          }
          let email = decoded.preferred_username

          let userRows = await connection.query(`SELECT * FROM userDetails WHERE email=?`, [email]);
          if (userRows.length === 0) {
            // Log unsuccessful login - user not found
            await UserLogs.addLog(131, 131, "Login unsuccessful", "auth", `Login attempt failed - User with email ${email} not found`);

            return res.status(404).send({ status: false, message: "User not found!" });
          }

          let user = userRows[0];

          if (user.status !== "ACTIVE") {
            // Log unsuccessful login - account not active
            await UserLogs.addLog(
              user.id,
              131,
              "Login unsuccessful",
              "auth",
              `Login attempt failed - Account for ${user.firstName} ${user.lastName} is not active`
            );

            return res.status(403).send({ status: false, message: "Account not active!" });
          }
          // Update last login
          let now = moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
          await connection.query(`UPDATE userDetails SET lastLoginTime=? WHERE id=?`, [now, user.id]);

          // Log successful login
          await UserLogs.addLog(
            user.id,
            user.id,
            "Login successful",
            "auth",
            `User ${user.firstName} ${user.lastName} logged in successfully`
          );

          const JWT_SECRET = "VCEPCADVITIIXSr5slt178"

          // Insert into token_management table
          const tokenInsertResult = await connection.query(
            "INSERT INTO token_management (userId, isActive) VALUES (?, ?)",
            [user.id, 1]
          );
          const tokenId = tokenInsertResult.insertId;

          // Generate activation token (valid 24 hours) including tokenId and id
          const token = jwt.sign({ id: user.id, tokenId: tokenId }, JWT_SECRET, { expiresIn: "24h" });

          return res.status(200).send({ status: true, message: "Login successful!", token });

        }
      );
    } catch (error) {
      // Log system error
      await UserLogs.addLog(131, 131, `Login error: ${error.message}`, "auth", `System error during login: ${error.message}`);
      return res.status(500).send({ status: false, message: error.message });
    }
  },
};
