const nodemailer = require('nodemailer');

module.exports = {
  regMail: async function (admin, user, mail, link) {
    try {
      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      let info = await transporter.sendMail({
        from: 'sameer.panigrahi@advity.in', // sender address
        to: `${mail}`, // list of receivers
        subject: "Activate account Partner Connect 2.0", // Subject line
        html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Activate Account</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <h2 style="color:#003399; text-align:center;">Activate account Partner Connect 2.0</h2>
          <p><strong>Invited by:</strong>${admin}</p>
          <p>Dear <strong>${user}</strong>,</p>
          <p>You are invited as a user for <strong>Partner Connect 2.0</strong> (<a href="https://lively-bay-0661a5200.1.azurestaticapps.net/" target="_blank">partnerconnect2.0.testenv.in</a>).</p>
          <p>Click the button below to set your password and activate your account.</p>
          <p style="text-align:center; margin:30px 0;">
            <a href="${link}" target="_blank" style="background:#5D87FF; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Activate account</a>
          </p>
          <p>Kind regards,<br/>${admin}</p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`, // plain text body
      });
      return info;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  forgotPassMail: async function (user, mail, link) {
    try {
      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      let info = await transporter.sendMail({
        from: 'sameer.panigrahi@advity.in', // sender address
        to: `${mail}`, // list of receivers
        subject: "Reset your password - Partner Connect 2.0", // Subject line
        html: `<!DOCTYPE HTML
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional //EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
  xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Reset Password</title>
</head>

<body style="margin:0;padding:0;background-color:#f9f9f9;color:#000000;font-family:'Cabin',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" bgcolor="#f9f9f9">
    <tr>
      <td align="center" style="padding:10px 0;">
        <img
          src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png"
          alt="Partner_Connect" width="180" />
      </td>
    </tr>
    <tr>
    <tr>
      <td align="center">
        <!-- Body -->
        <table width="600" cellpadding="0" cellspacing="0" bgcolor="#ffffff" style="background-color:#f3f9f9;">
          <tr>
            <td style="padding:33px 55px; text-align:left; font-size:15px; color:#333;">
              <p>Dear <strong>${user}</strong>,</p>
              <p>You made a request to reset your password for <strong>Partner Connect 2.0</strong>. Click the link below:
              </p>
              <br>
              <p style="text-align:center; margin:30px 0;">
                <a href="${link}" target="_blank"
                  style="background:#5D87FF; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Reset
                  Password</a>
              </p>

              <br><br>
              <p>If you did not request this, you can safely ignore this email.</p>
              <p>Kind regards,<br>Team Partner Connect 2.0</p>
            </td>
          </tr>
        </table>

        <!-- Footer -->
        <table width="600" cellpadding="0" cellspacing="0" bgcolor="#003399">
          <tr>
            <td align="center" style="padding:15px; background-color:#786767; color:#fafafa; font-size:12px;">
              <p style="margin:5px 0;">This is an automatically generated message. Replies to this message will not be
                answered.</p>
              <p style="margin:5px 0;">Attention: This message is generated in the testing environment (Staging).<br>
                This message was sent for testing purposes. You may ignore the content.</p>
            </td>
          </tr>
        </table>

      </td>
    </tr>
  </table>
</body>

</html>`, // plain text body
      });
      return info;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  monthlyMeetingMail: async function (creatorName, emailArray, meetingDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray];

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format meeting date
      const meetingDate = meetingDetails.meeting_date 
        ? new Date(meetingDetails.meeting_date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })
        : meetingDetails.meeting_date;

      // Format time
      const formatTime = (time) => {
        if (!time) return '';
        const [hours, minutes] = time.split(':');
        const hour12 = parseInt(hours) % 12 || 12;
        const ampm = parseInt(hours) >= 12 ? 'PM' : 'AM';
        return `${hour12}:${minutes} ${ampm}`;
      };

      const startTime = formatTime(meetingDetails.start_time);
      const endTime = formatTime(meetingDetails.end_time);
      const timeRange = startTime && endTime ? `${startTime} - ${endTime}` : (startTime || endTime || '');

      // Meeting mode text
      const meetingMode = meetingDetails.meeting_mode 
        ? meetingDetails.meeting_mode.charAt(0).toUpperCase() + meetingDetails.meeting_mode.slice(1).toLowerCase()
        : '';

      // Meeting location/link
      const meetingLocation = meetingDetails.meet_link 
        ? `<a href="${meetingDetails.meet_link}" target="_blank" style="color:#5D87FF; text-decoration:none;">${meetingDetails.meet_link}</a>`
        : (meetingDetails.meeting_venue || 'TBD');

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `Monthly Meeting Invitation - ${meetingDetails.dealer_name || 'Partner Connect'}`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Monthly Meeting Invitation</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <h2 style="color:#003399; text-align:center; margin-bottom:20px;">Monthly Meeting Invitation</h2>
          <p>Dear Team Member,</p>
          <p>You have been invited to a <strong>Monthly Meeting</strong> for <strong>Partner Connect 2.0</strong>.</p>
          
          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Meeting Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${meetingDetails.dealer_name ? `<tr><td style="padding:5px 0;"><strong>Dealer:</strong></td><td style="padding:5px 0;">${meetingDetails.dealer_name}</td></tr>` : ''}
              ${meetingDetails.market_area ? `<tr><td style="padding:5px 0;"><strong>Market Area:</strong></td><td style="padding:5px 0;">${meetingDetails.market_area}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Date:</strong></td><td style="padding:5px 0;">${meetingDate}</td></tr>
              ${timeRange ? `<tr><td style="padding:5px 0;"><strong>Time:</strong></td><td style="padding:5px 0;">${timeRange}</td></tr>` : ''}
              ${meetingMode ? `<tr><td style="padding:5px 0;"><strong>Mode:</strong></td><td style="padding:5px 0;">${meetingMode}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Location/Link:</strong></td><td style="padding:5px 0;">${meetingLocation}</td></tr>
              ${meetingDetails.recurring_meeting ? `<tr><td style="padding:5px 0;"><strong>Recurring:</strong></td><td style="padding:5px 0;">Yes</td></tr>` : ''}
            </table>
          </div>

          ${meetingDetails.agenda_text ? `<div style="margin:20px 0;"><p><strong>Agenda:</strong></p><p style="white-space:pre-wrap;">${meetingDetails.agenda_text}</p></div>` : ''}
          
          ${meetingDetails.agenda_link ? `<p style="text-align:center; margin:20px 0;"><a href="${meetingDetails.agenda_link}" target="_blank" style="background:#5D87FF; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">View Agenda</a></p>` : ''}
          
          ${meetingDetails.meet_link ? `<p style="text-align:center; margin:20px 0;"><a href="${meetingDetails.meet_link}" target="_blank" style="background:#003399; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Join Meeting</a></p>` : ''}

          <p>Kind regards,<br/><strong>${creatorName}</strong><br/>Partner Connect 2.0</p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  monthlyMeetingUpdateMail: async function (creatorName, emailArray, oldMeetingDetails, newMeetingDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray];

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format meeting date
      const formatDate = (date) => {
        if (!date) return '';
        return new Date(date).toLocaleDateString('en-US', { 
          weekday: 'long', 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        });
      };

      const oldMeetingDate = formatDate(oldMeetingDetails.meeting_date);
      const newMeetingDate = formatDate(newMeetingDetails.meeting_date);

      // Format time
      const formatTime = (time) => {
        if (!time) return '';
        const [hours, minutes] = time.split(':');
        const hour12 = parseInt(hours) % 12 || 12;
        const ampm = parseInt(hours) >= 12 ? 'PM' : 'AM';
        return `${hour12}:${minutes} ${ampm}`;
      };

      const oldStartTime = formatTime(oldMeetingDetails.start_time);
      const oldEndTime = formatTime(oldMeetingDetails.end_time);
      const oldTimeRange = oldStartTime && oldEndTime ? `${oldStartTime} - ${oldEndTime}` : (oldStartTime || oldEndTime || '');

      const newStartTime = formatTime(newMeetingDetails.start_time);
      const newEndTime = formatTime(newMeetingDetails.end_time);
      const newTimeRange = newStartTime && newEndTime ? `${newStartTime} - ${newEndTime}` : (newStartTime || newEndTime || '');

      // Meeting mode text
      const formatMode = (mode) => {
        if (!mode) return '';
        return mode.charAt(0).toUpperCase() + mode.slice(1).toLowerCase();
      };

      const oldMode = formatMode(oldMeetingDetails.meeting_mode);
      const newMode = formatMode(newMeetingDetails.meeting_mode);

      // Detect changes
      const changes = [];
      if (oldMeetingDate !== newMeetingDate) {
        changes.push({ field: 'Date', old: oldMeetingDate || 'N/A', new: newMeetingDate });
      }
      if (oldTimeRange !== newTimeRange) {
        changes.push({ field: 'Time', old: oldTimeRange || 'N/A', new: newTimeRange });
      }
      if (oldMode !== newMode) {
        changes.push({ field: 'Mode', old: oldMode || 'N/A', new: newMode });
      }
      if (oldMeetingDetails.meeting_venue !== newMeetingDetails.meeting_venue) {
        changes.push({ field: 'Venue', old: oldMeetingDetails.meeting_venue || 'N/A', new: newMeetingDetails.meeting_venue || 'N/A' });
      }
      if (oldMeetingDetails.meet_link !== newMeetingDetails.meet_link) {
        changes.push({ field: 'Meeting Link', old: oldMeetingDetails.meet_link || 'N/A', new: newMeetingDetails.meet_link || 'N/A' });
      }
      if (oldMeetingDetails.agenda_text !== newMeetingDetails.agenda_text) {
        changes.push({ field: 'Agenda', old: oldMeetingDetails.agenda_text || 'N/A', new: newMeetingDetails.agenda_text || 'N/A' });
      }
      if (oldMeetingDetails.recurring_meeting !== newMeetingDetails.recurring_meeting) {
        changes.push({ field: 'Recurring', old: oldMeetingDetails.recurring_meeting ? 'Yes' : 'No', new: newMeetingDetails.recurring_meeting ? 'Yes' : 'No' });
      }

      // Meeting location/link for new details
      const meetingLocation = newMeetingDetails.meet_link 
        ? `<a href="${newMeetingDetails.meet_link}" target="_blank" style="color:#5D87FF; text-decoration:none;">${newMeetingDetails.meet_link}</a>`
        : (newMeetingDetails.meeting_venue || 'TBD');

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `Monthly Meeting Updated - ${newMeetingDetails.dealer_name || 'Partner Connect'}`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Monthly Meeting Update</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <h2 style="color:#003399; text-align:center; margin-bottom:20px;">Monthly Meeting Updated</h2>
          <p>Dear Team Member,</p>
          <p>The following <strong>Monthly Meeting</strong> for <strong>Partner Connect 2.0</strong> has been updated.</p>
          
          ${changes.length > 0 ? `
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #ffc107;">
            <h3 style="color:#856404; margin-top:0; margin-bottom:15px;">⚠️ Changes Made</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${changes.map(change => `
                <tr>
                  <td style="padding:8px 0; border-bottom:1px solid #ffeaa7;">
                    <strong style="color:#856404;">${change.field}:</strong><br/>
                    <span style="color:#d63031; text-decoration:line-through;">${change.old}</span> 
                    <span style="color:#00b894;">→ ${change.new}</span>
                  </td>
                </tr>
              `).join('')}
            </table>
          </div>
          ` : ''}

          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Updated Meeting Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${newMeetingDetails.dealer_name ? `<tr><td style="padding:5px 0;"><strong>Dealer:</strong></td><td style="padding:5px 0;">${newMeetingDetails.dealer_name}</td></tr>` : ''}
              ${newMeetingDetails.market_area ? `<tr><td style="padding:5px 0;"><strong>Market Area:</strong></td><td style="padding:5px 0;">${newMeetingDetails.market_area}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Date:</strong></td><td style="padding:5px 0;">${newMeetingDate}</td></tr>
              ${newTimeRange ? `<tr><td style="padding:5px 0;"><strong>Time:</strong></td><td style="padding:5px 0;">${newTimeRange}</td></tr>` : ''}
              ${newMode ? `<tr><td style="padding:5px 0;"><strong>Mode:</strong></td><td style="padding:5px 0;">${newMode}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Location/Link:</strong></td><td style="padding:5px 0;">${meetingLocation}</td></tr>
              ${newMeetingDetails.recurring_meeting ? `<tr><td style="padding:5px 0;"><strong>Recurring:</strong></td><td style="padding:5px 0;">Yes</td></tr>` : ''}
            </table>
          </div>

          ${newMeetingDetails.agenda_text ? `<div style="margin:20px 0;"><p><strong>Agenda:</strong></p><p style="white-space:pre-wrap;">${newMeetingDetails.agenda_text}</p></div>` : ''}
          
          ${newMeetingDetails.agenda_link ? `<p style="text-align:center; margin:20px 0;"><a href="${newMeetingDetails.agenda_link}" target="_blank" style="background:#5D87FF; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">View Agenda</a></p>` : ''}
          
          ${newMeetingDetails.meet_link ? `<p style="text-align:center; margin:20px 0;"><a href="${newMeetingDetails.meet_link}" target="_blank" style="background:#003399; color:#fff; padding:12px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Join Meeting</a></p>` : ''}

          <p style="color:#666; font-size:14px; margin-top:20px;">Please note the changes above and update your calendar accordingly.</p>

          <p>Kind regards,<br/><strong>${creatorName}</strong><br/>Partner Connect 2.0</p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  monthlyMeetingStatusMail: async function (creatorName, emailArray, meetingDetails, status, cancellationReason) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray];

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format meeting date
      const formatDate = (date) => {
        if (!date) return '';
        return new Date(date).toLocaleDateString('en-US', { 
          weekday: 'long', 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        });
      };

      const meetingDate = formatDate(meetingDetails.meeting_date);

      // Format time
      const formatTime = (time) => {
        if (!time) return '';
        const [hours, minutes] = time.split(':');
        const hour12 = parseInt(hours) % 12 || 12;
        const ampm = parseInt(hours) >= 12 ? 'PM' : 'AM';
        return `${hour12}:${minutes} ${ampm}`;
      };

      const startTime = formatTime(meetingDetails.start_time);
      const endTime = formatTime(meetingDetails.end_time);
      const timeRange = startTime && endTime ? `${startTime} - ${endTime}` : (startTime || endTime || '');

      // Meeting mode text
      const meetingMode = meetingDetails.meeting_mode 
        ? meetingDetails.meeting_mode.charAt(0).toUpperCase() + meetingDetails.meeting_mode.slice(1).toLowerCase()
        : '';

      // Status-specific styling and message
      const isCancelled = status === 'Cancelled';
      const statusColor = isCancelled ? '#d63031' : '#00b894';
      const statusBgColor = isCancelled ? '#ffe5e5' : '#e5f9f6';
      const statusIcon = isCancelled ? '❌' : '✅';
      const statusTitle = isCancelled ? 'Meeting Cancelled' : 'Meeting Completed';
      const statusMessage = isCancelled 
        ? 'The following monthly meeting has been <strong>cancelled</strong>.'
        : 'The following monthly meeting has been <strong>completed</strong>.';

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `Monthly Meeting ${status} - ${meetingDetails.dealer_name || 'Partner Connect'}`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Monthly Meeting ${status}</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:${statusBgColor}; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid ${statusColor};">
            <h2 style="color:${statusColor}; text-align:center; margin:0; margin-bottom:10px;">${statusIcon} ${statusTitle}</h2>
            <p style="margin:0; text-align:center; color:#333;">${statusMessage}</p>
          </div>
          
          <p>Dear Team Member,</p>
          
          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Meeting Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${meetingDetails.dealer_name ? `<tr><td style="padding:5px 0;"><strong>Dealer:</strong></td><td style="padding:5px 0;">${meetingDetails.dealer_name}</td></tr>` : ''}
              ${meetingDetails.market_area ? `<tr><td style="padding:5px 0;"><strong>Market Area:</strong></td><td style="padding:5px 0;">${meetingDetails.market_area}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Date:</strong></td><td style="padding:5px 0;">${meetingDate}</td></tr>
              ${timeRange ? `<tr><td style="padding:5px 0;"><strong>Time:</strong></td><td style="padding:5px 0;">${timeRange}</td></tr>` : ''}
              ${meetingMode ? `<tr><td style="padding:5px 0;"><strong>Mode:</strong></td><td style="padding:5px 0;">${meetingMode}</td></tr>` : ''}
              <tr><td style="padding:5px 0;"><strong>Status:</strong></td><td style="padding:5px 0;"><strong style="color:${statusColor};">${status}</strong></td></tr>
            </table>
          </div>

          ${isCancelled && cancellationReason ? `
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #ffc107;">
            <p style="margin:0;"><strong>Cancellation Reason:</strong></p>
            <p style="margin:10px 0 0 0; white-space:pre-wrap;">${cancellationReason}</p>
          </div>
          ` : ''}

          <p style="color:#666; font-size:14px; margin-top:20px;">
            ${isCancelled 
              ? 'This meeting has been cancelled. Please update your calendar accordingly.' 
              : 'This meeting has been marked as completed. Thank you for your participation.'}
          </p>

          <p>Kind regards,<br/><strong>${creatorName}</strong><br/>Partner Connect 2.0</p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  actionItemCreatedMail: async function (emailArray, actionItemDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for action item notification');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format dates
      const formatDate = (date) => {
        if (!date) return 'N/A';
        try {
          return new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        } catch (error) {
          return date;
        }
      };

      const targetDate = formatDate(actionItemDetails.target_date);
      const completedDate = formatDate(actionItemDetails.completed_date);
      const createdDate = formatDate(actionItemDetails.created_on);

      // Format status with color
      const statusColors = {
        'Open': '#5D87FF',
        'In Progress': '#ffc107',
        'Closed': '#00b894'
      };
      const statusColor = statusColors[actionItemDetails.status] || '#333';

      // Get names
      const createdByName = actionItemDetails.created_by_name && actionItemDetails.created_by_lastname
        ? `${actionItemDetails.created_by_name} ${actionItemDetails.created_by_lastname}`.trim()
        : (actionItemDetails.created_by_name || 'N/A');
      
      const responsibilityName = actionItemDetails.responsibility_name && actionItemDetails.responsibility_lastname
        ? `${actionItemDetails.responsibility_name} ${actionItemDetails.responsibility_lastname}`.trim()
        : (actionItemDetails.responsibility_name || 'N/A');

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `New Action Item Created - ${actionItemDetails.dealer_name || 'Partner Connect'}`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Action Item Created</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#e5f9f6; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #00b894;">
            <h2 style="color:#00b894; text-align:center; margin:0; margin-bottom:10px;">✅ New Action Item Created</h2>
            <p style="margin:0; text-align:center; color:#333;">A new action item has been created for <strong>Partner Connect 2.0</strong>.</p>
          </div>
          
          <p>Dear Team Member,</p>
          
          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Action Item Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${actionItemDetails.dealer_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Dealer:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.dealer_name}</td></tr>` : ''}
              ${actionItemDetails.marketarea ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Market Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.marketarea}</td></tr>` : ''}
              ${actionItemDetails.department_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Department:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.department_name}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Topic of Discussion:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.topic_of_discussion || 'N/A'}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Closure Action:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.closure_action || 'N/A'}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Responsibility:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${responsibilityName}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Created By:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${createdByName}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Target Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${targetDate}</td></tr>
              ${actionItemDetails.completed_date ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Completed Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${completedDate}</td></tr>` : ''}
              <tr><td style="padding:8px 0;"><strong>Status:</strong></td><td style="padding:8px 0;"><strong style="color:${statusColor};">${actionItemDetails.status || 'N/A'}</strong></td></tr>
            </table>
          </div>

          ${actionItemDetails.meeting_date ? `
          <div style="background-color:#f0f7ff; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #5D87FF;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Related Meeting Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr><td style="padding:5px 0;"><strong>Meeting Date:</strong></td><td style="padding:5px 0;">${formatDate(actionItemDetails.meeting_date)}</td></tr>
              ${actionItemDetails.start_time && actionItemDetails.end_time ? `
                <tr><td style="padding:5px 0;"><strong>Meeting Time:</strong></td><td style="padding:5px 0;">${actionItemDetails.start_time} - ${actionItemDetails.end_time}</td></tr>
              ` : ''}
              ${actionItemDetails.meeting_mode ? `
                <tr><td style="padding:5px 0;"><strong>Meeting Mode:</strong></td><td style="padding:5px 0;">${actionItemDetails.meeting_mode.charAt(0).toUpperCase() + actionItemDetails.meeting_mode.slice(1).toLowerCase()}</td></tr>
              ` : ''}
            </table>
          </div>
          ` : ''}

          <p style="color:#666; font-size:14px; margin-top:20px;">
            Please review the action item details above and take necessary action as required.
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  actionItemUpdatedMail: async function (emailArray, oldActionItemDetails, newActionItemDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for action item update notification');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format dates
      const formatDate = (date) => {
        if (!date) return 'N/A';
        try {
          return new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        } catch (error) {
          return date;
        }
      };

      // Detect changes
      const changes = [];
      
      // Compare topic of discussion
      if (oldActionItemDetails.topic_of_discussion !== newActionItemDetails.topic_of_discussion) {
        changes.push({ 
          field: 'Topic of Discussion', 
          old: oldActionItemDetails.topic_of_discussion || 'N/A', 
          new: newActionItemDetails.topic_of_discussion || 'N/A' 
        });
      }

      // Compare closure action
      if (oldActionItemDetails.closure_action !== newActionItemDetails.closure_action) {
        changes.push({ 
          field: 'Closure Action', 
          old: oldActionItemDetails.closure_action || 'N/A', 
          new: newActionItemDetails.closure_action || 'N/A' 
        });
      }

      // Compare responsibility
      const oldResponsibilityName = oldActionItemDetails.responsibility_name && oldActionItemDetails.responsibility_lastname
        ? `${oldActionItemDetails.responsibility_name} ${oldActionItemDetails.responsibility_lastname}`.trim()
        : (oldActionItemDetails.responsibility_name || 'N/A');
      
      const newResponsibilityName = newActionItemDetails.responsibility_name && newActionItemDetails.responsibility_lastname
        ? `${newActionItemDetails.responsibility_name} ${newActionItemDetails.responsibility_lastname}`.trim()
        : (newActionItemDetails.responsibility_name || 'N/A');

      if (oldActionItemDetails.responsibility !== newActionItemDetails.responsibility || oldResponsibilityName !== newResponsibilityName) {
        changes.push({ 
          field: 'Responsibility', 
          old: oldResponsibilityName, 
          new: newResponsibilityName 
        });
      }

      // Compare target date
      const oldTargetDate = formatDate(oldActionItemDetails.target_date);
      const newTargetDate = formatDate(newActionItemDetails.target_date);
      if (oldTargetDate !== newTargetDate) {
        changes.push({ 
          field: 'Target Date', 
          old: oldTargetDate, 
          new: newTargetDate 
        });
      }

      // Compare completed date
      const oldCompletedDate = formatDate(oldActionItemDetails.completed_date);
      const newCompletedDate = formatDate(newActionItemDetails.completed_date);
      if (oldCompletedDate !== newCompletedDate) {
        changes.push({ 
          field: 'Completed Date', 
          old: oldCompletedDate, 
          new: newCompletedDate 
        });
      }

      // Compare status
      if (oldActionItemDetails.status !== newActionItemDetails.status) {
        changes.push({ 
          field: 'Status', 
          old: oldActionItemDetails.status || 'N/A', 
          new: newActionItemDetails.status || 'N/A' 
        });
      }

      // Compare department
      if (oldActionItemDetails.department_name !== newActionItemDetails.department_name) {
        changes.push({ 
          field: 'Department', 
          old: oldActionItemDetails.department_name || 'N/A', 
          new: newActionItemDetails.department_name || 'N/A' 
        });
      }

      // Format status with color
      const statusColors = {
        'Open': '#5D87FF',
        'In Progress': '#ffc107',
        'Closed': '#00b894'
      };
      const statusColor = statusColors[newActionItemDetails.status] || '#333';

      // Get names
      const createdByName = newActionItemDetails.created_by_name && newActionItemDetails.created_by_lastname
        ? `${newActionItemDetails.created_by_name} ${newActionItemDetails.created_by_lastname}`.trim()
        : (newActionItemDetails.created_by_name || 'N/A');

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `Action Item Updated - ${newActionItemDetails.dealer_name || 'Partner Connect'}`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Action Item Updated</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #ffc107;">
            <h2 style="color:#856404; text-align:center; margin:0; margin-bottom:10px;">⚠️ Action Item Updated</h2>
            <p style="margin:0; text-align:center; color:#333;">An action item has been updated for <strong>Partner Connect 2.0</strong>.</p>
          </div>
          
          <p>Dear Team Member,</p>
          
          ${changes.length > 0 ? `
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #ffc107;">
            <h3 style="color:#856404; margin-top:0; margin-bottom:15px;">⚠️ Changes Made</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${changes.map(change => `
                <tr>
                  <td style="padding:8px 0; border-bottom:1px solid #ffeaa7;">
                    <strong style="color:#856404;">${change.field}:</strong><br/>
                    <span style="color:#d63031; text-decoration:line-through;">${change.old}</span> 
                    <span style="color:#00b894;">→ ${change.new}</span>
                  </td>
                </tr>
              `).join('')}
            </table>
          </div>
          ` : ''}

          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Updated Action Item Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${newActionItemDetails.dealer_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Dealer:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newActionItemDetails.dealer_name}</td></tr>` : ''}
              ${newActionItemDetails.marketarea ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Market Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newActionItemDetails.marketarea}</td></tr>` : ''}
              ${newActionItemDetails.department_name ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Department:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newActionItemDetails.department_name}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Topic of Discussion:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newActionItemDetails.topic_of_discussion || 'N/A'}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Closure Action:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newActionItemDetails.closure_action || 'N/A'}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Responsibility:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newResponsibilityName}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Created By:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${createdByName}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Target Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newTargetDate}</td></tr>
              ${newActionItemDetails.completed_date ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Completed Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newCompletedDate}</td></tr>` : ''}
              <tr><td style="padding:8px 0;"><strong>Status:</strong></td><td style="padding:8px 0;"><strong style="color:${statusColor};">${newActionItemDetails.status || 'N/A'}</strong></td></tr>
            </table>
          </div>

          ${newActionItemDetails.meeting_date ? `
          <div style="background-color:#f0f7ff; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #5D87FF;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Related Meeting Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr><td style="padding:5px 0;"><strong>Meeting Date:</strong></td><td style="padding:5px 0;">${formatDate(newActionItemDetails.meeting_date)}</td></tr>
              ${newActionItemDetails.start_time && newActionItemDetails.end_time ? `
                <tr><td style="padding:5px 0;"><strong>Meeting Time:</strong></td><td style="padding:5px 0;">${newActionItemDetails.start_time} - ${newActionItemDetails.end_time}</td></tr>
              ` : ''}
              ${newActionItemDetails.meeting_mode ? `
                <tr><td style="padding:5px 0;"><strong>Meeting Mode:</strong></td><td style="padding:5px 0;">${newActionItemDetails.meeting_mode.charAt(0).toUpperCase() + newActionItemDetails.meeting_mode.slice(1).toLowerCase()}</td></tr>
              ` : ''}
            </table>
          </div>
          ` : ''}

          <p style="color:#666; font-size:14px; margin-top:20px;">
            ${changes.length > 0 
              ? 'Please review the changes above and take necessary action as required.' 
              : 'The action item has been updated. Please review the details above.'}
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  pdpActionItemCreatedMail: async function (emailArray, actionItemDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for PDP action item notification');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format dates
      const formatDate = (date) => {
        if (!date) return 'N/A';
        try {
          return new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        } catch (error) {
          return date;
        }
      };

      const targetDate = formatDate(actionItemDetails.target_date);
      const completedDate = formatDate(actionItemDetails.completed_date);
      const createdDate = formatDate(actionItemDetails.created_on);

      // Format status with color
      const statusColors = {
        'Open': '#5D87FF',
        'In Progress': '#ffc107',
        'Closed': '#00b894'
      };
      const statusColor = statusColors[actionItemDetails.status] || '#333';

      // Format priority with color
      const priorityColors = {
        'High': '#d63031',
        'Medium': '#fdcb6e',
        'Low': '#00b894'
      };
      const priorityColor = priorityColors[actionItemDetails.priority] || '#333';

      // Get names
      const createdByName = actionItemDetails.created_by_name && actionItemDetails.created_by_lastname
        ? `${actionItemDetails.created_by_name} ${actionItemDetails.created_by_lastname}`.trim()
        : (actionItemDetails.created_by_name || 'N/A');
      
      const responsibilityName = actionItemDetails.responsibility_name && actionItemDetails.responsibility_lastname
        ? `${actionItemDetails.responsibility_name} ${actionItemDetails.responsibility_lastname}`.trim()
        : (actionItemDetails.responsibility_name || 'N/A');

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `New PDP Action Item Created - Partner Connect 2.0`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>PDP Action Item Created</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#e5f9f6; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #00b894;">
            <h2 style="color:#00b894; text-align:center; margin:0; margin-bottom:10px;">✅ New PDP Action Item Created</h2>
            <p style="margin:0; text-align:center; color:#333;">A new PDP action item has been created for <strong>Partner Connect 2.0</strong>.</p>
          </div>
          
          <p>Dear Team Member,</p>
          
          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">PDP Action Item Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Focus Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.focus_area || 'N/A'}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Objective:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.objective || 'N/A'}</td></tr>
              ${actionItemDetails.actions_to_achieve ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Actions to Achieve:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.actions_to_achieve}</td></tr>` : ''}
              ${actionItemDetails.actions_progress_update ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Progress Update:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${actionItemDetails.actions_progress_update}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Responsibility:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${responsibilityName}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Created By:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${createdByName}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Priority:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong style="color:${priorityColor};">${actionItemDetails.priority || 'N/A'}</strong></td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Target Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${targetDate}</td></tr>
              ${actionItemDetails.completed_date ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Completed Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${completedDate}</td></tr>` : ''}
              <tr><td style="padding:8px 0;"><strong>Status:</strong></td><td style="padding:8px 0;"><strong style="color:${statusColor};">${actionItemDetails.status || 'N/A'}</strong></td></tr>
            </table>
          </div>

          <p style="color:#666; font-size:14px; margin-top:20px;">
            Please review the PDP action item details above and take necessary action as required.
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  pdpActionItemUpdatedMail: async function (emailArray, oldActionItemDetails, newActionItemDetails) {
    try {
      // Ensure emailArray is an array
      const emails = Array.isArray(emailArray) ? emailArray : [emailArray].filter(email => email && email.trim() !== '');

      if (emails.length === 0) {
        console.log('No valid email addresses provided for PDP action item update notification');
        return [];
      }

      // Connect with SMTP
      const transporter = await nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'sameer.panigrahi@advity.in',
          pass: 'xmdzmbbgwzovggce'
        }
      });

      // Format dates
      const formatDate = (date) => {
        if (!date) return 'N/A';
        try {
          return new Date(date).toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        } catch (error) {
          return date;
        }
      };

      // Detect changes
      const changes = [];
      
      // Compare focus_area
      if (oldActionItemDetails.focus_area !== newActionItemDetails.focus_area) {
        changes.push({ 
          field: 'Focus Area', 
          old: oldActionItemDetails.focus_area || 'N/A', 
          new: newActionItemDetails.focus_area || 'N/A' 
        });
      }

      // Compare objective
      if (oldActionItemDetails.objective !== newActionItemDetails.objective) {
        changes.push({ 
          field: 'Objective', 
          old: oldActionItemDetails.objective || 'N/A', 
          new: newActionItemDetails.objective || 'N/A' 
        });
      }

      // Compare actions_to_achieve
      if (oldActionItemDetails.actions_to_achieve !== newActionItemDetails.actions_to_achieve) {
        changes.push({ 
          field: 'Actions to Achieve', 
          old: oldActionItemDetails.actions_to_achieve || 'N/A', 
          new: newActionItemDetails.actions_to_achieve || 'N/A' 
        });
      }

      // Compare actions_progress_update
      if (oldActionItemDetails.actions_progress_update !== newActionItemDetails.actions_progress_update) {
        changes.push({ 
          field: 'Progress Update', 
          old: oldActionItemDetails.actions_progress_update || 'N/A', 
          new: newActionItemDetails.actions_progress_update || 'N/A' 
        });
      }

      // Compare responsibility
      const oldResponsibilityName = oldActionItemDetails.responsibility_name && oldActionItemDetails.responsibility_lastname
        ? `${oldActionItemDetails.responsibility_name} ${oldActionItemDetails.responsibility_lastname}`.trim()
        : (oldActionItemDetails.responsibility_name || 'N/A');
      
      const newResponsibilityName = newActionItemDetails.responsibility_name && newActionItemDetails.responsibility_lastname
        ? `${newActionItemDetails.responsibility_name} ${newActionItemDetails.responsibility_lastname}`.trim()
        : (newActionItemDetails.responsibility_name || 'N/A');

      if (oldActionItemDetails.responsibility !== newActionItemDetails.responsibility || oldResponsibilityName !== newResponsibilityName) {
        changes.push({ 
          field: 'Responsibility', 
          old: oldResponsibilityName, 
          new: newResponsibilityName 
        });
      }

      // Compare priority
      if (oldActionItemDetails.priority !== newActionItemDetails.priority) {
        changes.push({ 
          field: 'Priority', 
          old: oldActionItemDetails.priority || 'N/A', 
          new: newActionItemDetails.priority || 'N/A' 
        });
      }

      // Compare target date
      const oldTargetDate = formatDate(oldActionItemDetails.target_date);
      const newTargetDate = formatDate(newActionItemDetails.target_date);
      if (oldTargetDate !== newTargetDate) {
        changes.push({ 
          field: 'Target Date', 
          old: oldTargetDate, 
          new: newTargetDate 
        });
      }

      // Compare completed date
      const oldCompletedDate = formatDate(oldActionItemDetails.completed_date);
      const newCompletedDate = formatDate(newActionItemDetails.completed_date);
      if (oldCompletedDate !== newCompletedDate) {
        changes.push({ 
          field: 'Completed Date', 
          old: oldCompletedDate, 
          new: newCompletedDate 
        });
      }

      // Compare status
      if (oldActionItemDetails.status !== newActionItemDetails.status) {
        changes.push({ 
          field: 'Status', 
          old: oldActionItemDetails.status || 'N/A', 
          new: newActionItemDetails.status || 'N/A' 
        });
      }

      // Compare isActive
      const oldIsActive = oldActionItemDetails.isActive === 1 || oldActionItemDetails.isActive === true || String(oldActionItemDetails.isActive).toLowerCase() === 'true';
      const newIsActive = newActionItemDetails.isActive === 1 || newActionItemDetails.isActive === true || String(newActionItemDetails.isActive).toLowerCase() === 'true';
      if (oldIsActive !== newIsActive) {
        changes.push({ 
          field: 'Active Status', 
          old: oldIsActive ? 'Active' : 'Inactive', 
          new: newIsActive ? 'Active' : 'Inactive' 
        });
      }

      // Compare target_data_change
      const oldTargetDataChange = oldActionItemDetails.target_data_change === 1 || oldActionItemDetails.target_data_change === true || String(oldActionItemDetails.target_data_change).toLowerCase() === 'true';
      const newTargetDataChange = newActionItemDetails.target_data_change === 1 || newActionItemDetails.target_data_change === true || String(newActionItemDetails.target_data_change).toLowerCase() === 'true';
      if (oldTargetDataChange !== newTargetDataChange) {
        changes.push({ 
          field: 'Target Data Change', 
          old: oldTargetDataChange ? 'Yes' : 'No', 
          new: newTargetDataChange ? 'Yes' : 'No' 
        });
      }

      // Format status with color
      const statusColors = {
        'Open': '#5D87FF',
        'In Progress': '#ffc107',
        'Closed': '#00b894'
      };
      const statusColor = statusColors[newActionItemDetails.status] || '#333';

      // Format priority with color
      const priorityColors = {
        'High': '#d63031',
        'Medium': '#fdcb6e',
        'Low': '#00b894'
      };
      const priorityColor = priorityColors[newActionItemDetails.priority] || '#333';

      // Get names
      const createdByName = newActionItemDetails.created_by_name && newActionItemDetails.created_by_lastname
        ? `${newActionItemDetails.created_by_name} ${newActionItemDetails.created_by_lastname}`.trim()
        : (newActionItemDetails.created_by_name || 'N/A');

      const results = [];

      // Loop through each email and send individually
      for (const email of emails) {
        try {
          let info = await transporter.sendMail({
            from: 'sameer.panigrahi@advity.in', // sender address
            to: `${email}`, // individual receiver
            subject: `PDP Action Item Updated - Partner Connect 2.0`, // Subject line
            html: `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>PDP Action Item Updated</title>
  </head>
  <body style="font-family: Arial, sans-serif; background-color:#f9f9f9; margin:0; padding:20px; color:#333;">
    <table align="center" width="600" style="background:#fff; border:1px solid #ddd; border-radius:6px; padding:20px;">
      <tr>
        <td align="center" style="padding:10px 0;">
          <img src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Login/volvo-spread-word-mark1214_1_-removebg-preview.png" alt="Partner_Connect" width="180"/>
        </td>
      </tr>
      <tr>
        <td style="padding:20px;">
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin-bottom:20px; border-left:4px solid #ffc107;">
            <h2 style="color:#856404; text-align:center; margin:0; margin-bottom:10px;">⚠️ PDP Action Item Updated</h2>
            <p style="margin:0; text-align:center; color:#333;">A PDP action item has been updated for <strong>Partner Connect 2.0</strong>.</p>
          </div>
          
          <p>Dear Team Member,</p>
          
          ${changes.length > 0 ? `
          <div style="background-color:#fff3cd; padding:15px; border-radius:4px; margin:20px 0; border-left:4px solid #ffc107;">
            <h3 style="color:#856404; margin-top:0; margin-bottom:15px;">⚠️ Changes Made</h3>
            <table style="width:100%; border-collapse:collapse;">
              ${changes.map(change => `
                <tr>
                  <td style="padding:8px 0; border-bottom:1px solid #ffeaa7;">
                    <strong style="color:#856404;">${change.field}:</strong><br/>
                    <span style="color:#d63031; text-decoration:line-through;">${change.old}</span> 
                    <span style="color:#00b894;">→ ${change.new}</span>
                  </td>
                </tr>
              `).join('')}
            </table>
          </div>
          ` : ''}

          <div style="background-color:#f5f5f5; padding:15px; border-radius:4px; margin:20px 0;">
            <h3 style="color:#003399; margin-top:0; margin-bottom:15px;">Updated PDP Action Item Details</h3>
            <table style="width:100%; border-collapse:collapse;">
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Focus Area:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newActionItemDetails.focus_area || 'N/A'}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Objective:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newActionItemDetails.objective || 'N/A'}</td></tr>
              ${newActionItemDetails.actions_to_achieve ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Actions to Achieve:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newActionItemDetails.actions_to_achieve}</td></tr>` : ''}
              ${newActionItemDetails.actions_progress_update ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Progress Update:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newActionItemDetails.actions_progress_update}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Responsibility:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newResponsibilityName}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Created By:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${createdByName}</td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Priority:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong style="color:${priorityColor};">${newActionItemDetails.priority || 'N/A'}</strong></td></tr>
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Target Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newTargetDate}</td></tr>
              ${newActionItemDetails.completed_date ? `<tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Completed Date:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;">${newCompletedDate}</td></tr>` : ''}
              <tr><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong>Status:</strong></td><td style="padding:8px 0; border-bottom:1px solid #e0e0e0;"><strong style="color:${statusColor};">${newActionItemDetails.status || 'N/A'}</strong></td></tr>
              <tr><td style="padding:8px 0;"><strong>Active:</strong></td><td style="padding:8px 0;">${newIsActive ? 'Yes' : 'No'}</td></tr>
            </table>
          </div>

          <p style="color:#666; font-size:14px; margin-top:20px;">
            ${changes.length > 0 
              ? 'Please review the changes above and take necessary action as required.' 
              : 'The PDP action item has been updated. Please review the details above.'}
          </p>

          <p>Kind regards,<br/><strong>Partner Connect 2.0</strong></p>
        </td>
      </tr>
      <tr>
        <td style="background:#f1f1f1; padding:15px; font-size:13px; color:#555; text-align:center;">
          <p>This is an automatically generated message. Replies to this message will not be answered.</p>
          <p><strong>Attention:</strong> this message is generated in the testing environment (Staging). This message was sent for testing purposes. You may ignore the content.</p>
        </td>
      </tr>
    </table>
  </body>
  </html>`,
          });
          results.push({ email, success: true, info });
        } catch (emailError) {
          console.log(`Error sending email to ${email}:`, emailError);
          results.push({ email, success: false, error: emailError });
        }
      }

      return results;
    } catch (error) {
      console.log(error);
      return error;
    }
  }
};
