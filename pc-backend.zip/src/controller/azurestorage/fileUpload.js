const { BlobServiceClient } = require("@azure/storage-blob");
const path = require("path");

// Azure Blob client
const key = "DefaultEndpointsProtocol=https;AccountName=partnerconnecttest;AccountKey=K19jq/4RcUMW7vZNQUWmGYHhhilrSn2GT9rEUPKBObgtYltpSgrdcUzReNQvGE71xhiNw+CDy1Dz+ASttOr5qw==;EndpointSuffix=core.windows.net"
const string = "test"
const blobServiceClient = BlobServiceClient.fromConnectionString(key);
const containerClient = blobServiceClient.getContainerClient(string);

// Configuration for file restrictions
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const ALLOWED_EXTENSIONS = ['.pdf', '.doc', '.docx', '.jpg', '.jpeg', '.png', '.xls', '.xlsx', '.csv', '.txt'];

module.exports = {
    uploadFile: async (file) => {
        try {
            if (!file) {
                throw new Error("No file provided");
            }

            // 1. Validation: File Extension
            const ext = path.extname(file.originalname).toLowerCase();
            if (!ALLOWED_EXTENSIONS.includes(ext)) {
                throw new Error(`Invalid file type. Allowed types: ${ALLOWED_EXTENSIONS.join(", ")}`);
            }

            // 2. Validation: File Size
            if (file.buffer.length > MAX_FILE_SIZE) {
                throw new Error(`File size exceeds the 50MB limit`);
            }

            const blobName = Date.now() + "-" + file.originalname;
            console.log("Uploading blob:", blobName);
            const blockBlobClient = containerClient.getBlockBlobClient(blobName);

            const contentType = file.mimetype || "application/octet-stream";

            // Upload file buffer
            await blockBlobClient.upload(file.buffer, file.buffer.length, {
                blobHTTPHeaders: {
                    blobContentType: contentType,
                    blobContentDisposition: "inline", // 👈 This makes browser open it instead of downloading
                },
            });
            return blockBlobClient.url
        } catch (err) {
            console.error("Upload error:", err.message);
            // Return error object or message so caller can handle it
            return { error: true, message: err.message };
        }
    }
}