const { BlobServiceClient } = require("@azure/storage-blob");
const { uploadFile } = require("./fileUpload")
// Azure Blob client
const key = "DefaultEndpointsProtocol=https;AccountName=partnerconnecttest;AccountKey=K19jq/4RcUMW7vZNQUWmGYHhhilrSn2GT9rEUPKBObgtYltpSgrdcUzReNQvGE71xhiNw+CDy1Dz+ASttOr5qw==;EndpointSuffix=core.windows.net"
const string = "test"
const blobServiceClient = BlobServiceClient.fromConnectionString(key);
const containerClient = blobServiceClient.getContainerClient(string);

module.exports = {
  test: async (req, res) => {
    try {
      if (!req.files.length) {
        return res.status(400).send("No file uploaded.");
      }
      let file = req.files[0]
      let url = await uploadFile(file)

      res.json({
        message: "✅ File uploaded successfully",
        url
      });
    } catch (err) {
      console.error("Upload error:", err.message);
      res.status(500).send("Error uploading file");
    }
  }
}