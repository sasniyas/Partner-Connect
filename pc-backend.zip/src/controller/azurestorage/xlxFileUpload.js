const { BlobServiceClient } = require("@azure/storage-blob");

// Azure Blob client
const key = "DefaultEndpointsProtocol=https;AccountName=partnerconnecttest;AccountKey=K19jq/4RcUMW7vZNQUWmGYHhhilrSn2GT9rEUPKBObgtYltpSgrdcUzReNQvGE71xhiNw+CDy1Dz+ASttOr5qw==;EndpointSuffix=core.windows.net"
const string = "xlx-file"
const blobServiceClient = BlobServiceClient.fromConnectionString(key);
const containerClient = blobServiceClient.getContainerClient(string);

module.exports = {
    uploadFile: async (file) => {
        try {
            const blobName = Date.now() + "-" + file.originalname;
            console.log(blobName)
            const blockBlobClient = containerClient.getBlockBlobClient(blobName);

            const contentType = file.mimetype || "application/octet-stream";

            // Upload file buffer
            await blockBlobClient.upload(file.buffer, file.buffer.length, {
                blobHTTPHeaders: {
                    blobContentType: contentType,
                    blobContentDisposition: "inline", // 👈 This makes browser open it instead of downloading
                },
            });
            return blockBlobClient.url
        } catch (err) {
            console.error("Upload error:", err);
            return err
        }
    }
}