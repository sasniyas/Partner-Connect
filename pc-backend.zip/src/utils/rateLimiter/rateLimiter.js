import rateLimiter from "express-rate-limit";

const limiter = rateLimiter({
    windowMs: 1 * 60 * 1000, // 1 minutes
    max: 1000, // Limit each IP to 100 requests per window
    message: "Too many requests, please try again later.",
    standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
    legacyHeaders: false, // Disable the `X-RateLimit-*` headers
    keyGenerator: (req) => {
        console.log(`[RateLimiter] Checking limit for IP: ${req.ip} | URL: ${req.originalUrl}`);
        return req.ip;
    },
    handler: (req, res, next, options) => {
        console.log(`[RateLimiter] Limit exceeded for IP: ${req.ip}`);
        res.status(options.statusCode).send(options.message);
    }
});

export default limiter;