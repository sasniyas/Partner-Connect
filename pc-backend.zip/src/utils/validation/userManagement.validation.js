const validateNameLength = (name) => {
    if (!name) return true; // Assuming empty/null is handled by other checks if required
    return name.length <= 30;
};

const validateEmail = (email) => {
    if (!email) return false;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

module.exports = {
    validateNameLength,
    validateEmail,
};
