// Validation function for KPI name
const validateKpiName = (kpiName) => {
    if (!kpiName || typeof kpiName !== 'string') {
        return false;
    }
    const trimmed = kpiName.trim();
    return trimmed.length > 0 && trimmed.length < 50;
};

// Validation function for bulk add KPI
const validateKpiRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { objectiveId, kpiName, maxScore } = row;

        // Check required fields
        if (!objectiveId || !maxScore || !validateKpiName(kpiName)) {
            invalidCount++;
            return;
        }

        const trimmedKpiName = kpiName.trim();

        // Check for duplicates within the batch (combination of objectiveId and kpiName)
        const combinationKey = `${objectiveId}_${trimmedKpiName.toLowerCase()}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            objectiveId,
            kpiName: trimmedKpiName,
            maxScore
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateKpiName,
    validateKpiRows,
};
