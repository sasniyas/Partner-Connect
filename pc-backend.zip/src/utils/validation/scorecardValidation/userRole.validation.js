// Validation function for user role
const validateUserRole = (userRole) => {
    if (!userRole || typeof userRole !== 'string') {
        return false;
    }
    const trimmed = userRole.trim();
    return trimmed.length > 0 && trimmed.length < 100;
};

// Validation function for location (required for Volvo User, null for Dealer User)
const validateLocation = (userType, location) => {
    if (userType === "Volvo User") {
        if (!location || typeof location !== 'string') {
            return false;
        }
        const trimmed = location.trim();
        return trimmed.length > 0;
    }
    // For Dealer User and other types, location can be null/optional
    return true;
};

// Validation function for bulk add role
const validateRoleRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { userType, location, userRole } = row;

        // Check required fields
        if (!userType || !validateUserRole(userRole)) {
            invalidCount++;
            return;
        }

        // Validate location based on userType
        if (!validateLocation(userType, location)) {
            invalidCount++;
            return;
        }

        // For Dealer User -> Location should be null
        let finalLocation = null;
        if (userType === "Dealer User") {
            finalLocation = location ? location.trim() : null;
        } else if (userType === "Volvo User") {
            finalLocation = location.trim();
        } else {
            // For other user types, location is optional
            finalLocation = location ? location.trim() : null;
        }

        const trimmedUserRole = userRole.trim();

        // Check for duplicates within the batch (combination of userType, userRole, and location)
        const locationKey = finalLocation === null ? "NULL" : finalLocation.toLowerCase();
        const combinationKey = `${userType}_${trimmedUserRole.toLowerCase()}_${locationKey}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            userType,
            location: finalLocation,
            userRole: trimmedUserRole
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateUserRole,
    validateLocation,
    validateRoleRows,
};
