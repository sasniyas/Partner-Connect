// Validation function for single market area
const validateMarketArea = (marketarea) => {
    if (!marketarea || typeof marketarea !== 'string') {
        return false;
    }
    const trimmed = marketarea.trim();
    return trimmed.length <= 30;
};

// Validation function for bulk add market area
const validateMarketAreaRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenMarketAreas = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { marketarea } = row;

        // Check required fields using validation function
        if (!validateMarketArea(marketarea)) {
            invalidCount++;
            return;
        }

        const trimmedMarketArea = marketarea.trim();

        // Check for duplicates within the batch
        if (seenMarketAreas.has(trimmedMarketArea.toLowerCase())) {
            invalidCount++;
            return;
        }
        seenMarketAreas.add(trimmedMarketArea.toLowerCase());

        // Row is valid
        validRows.push({
            marketarea: trimmedMarketArea
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateMarketArea,
    validateMarketAreaRows,
};
