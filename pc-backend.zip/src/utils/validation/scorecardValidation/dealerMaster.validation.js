// Validation function for dealer name
const validateDealerName = (dealerName) => {
    if (!dealerName || typeof dealerName !== 'string') {
        return false;
    }
    const trimmed = dealerName.trim();
    return trimmed.length > 0 && trimmed.length < 100;
};

// Validation function for dealer short name (optional field)
const validateDealerShortName = (dealerShortName) => {
    if (!dealerShortName) return true; // Optional field, null/undefined is valid
    if (typeof dealerShortName !== 'string') {
        return false;
    }
    const trimmed = dealerShortName.trim();
    return trimmed.length < 50;
};

// Validation function for bulk add dealer
const validateDealerRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { market_id, state_id, dealerName, dealerShortName } = row;

        // Check required fields
        if (!market_id || !state_id || !validateDealerName(dealerName)) {
            invalidCount++;
            return;
        }

        // Validate dealer short name if provided
        if (dealerShortName && !validateDealerShortName(dealerShortName)) {
            invalidCount++;
            return;
        }

        const trimmedDealerName = dealerName.trim();
        const trimmedDealerShortName = dealerShortName ? dealerShortName.trim() : null;

        // Check for duplicates within the batch (combination of dealerName, market_id, and state_id)
        const combinationKey = `${market_id}_${state_id}_${trimmedDealerName.toLowerCase()}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            market_id,
            state_id,
            dealerName: trimmedDealerName,
            dealerShortName: trimmedDealerShortName
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateDealerName,
    validateDealerShortName,
    validateDealerRows,
};
