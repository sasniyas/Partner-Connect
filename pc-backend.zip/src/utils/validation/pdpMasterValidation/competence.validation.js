// Validation function for competence fields
const validateCompetenceField = (value) => {
    if (!value || typeof value !== 'string') {
        return false;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 && trimmed.length <= 100;
};

// Validation function for bulk add competence
const validateCompetenceRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { competence_type, competence_name, di_required } = row;

        // Check required fields and length validation
        if (
            !validateCompetenceField(competence_type) ||
            !validateCompetenceField(competence_name)
        ) {
            invalidCount++;
            return;
        }

        const trimmedType = competence_type.trim();
        const trimmedName = competence_name.trim();

        // Check for duplicates within the batch (based on competence_type and competence_name)
        const combinationKey = `${trimmedType.toLowerCase()}_${trimmedName.toLowerCase()}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            competence_type: trimmedType,
            competence_name: trimmedName,
            di_required: di_required !== undefined ? di_required : 1
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateCompetenceField,
    validateCompetenceRows,
};
