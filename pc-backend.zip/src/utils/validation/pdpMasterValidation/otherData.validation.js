// Validation function for other data fields (file_name)
const validateOtherDataField = (value) => {
    if (!value || typeof value !== 'string') {
        return false;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 && trimmed.length <= 100;
};

// Validation function for bulk add other data
const validateOtherDataRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenFileNames = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { file_name } = row;

        // Check required fields and length validation
        if (!validateOtherDataField(file_name)) {
            invalidCount++;
            return;
        }

        const trimmedFileName = file_name.trim();

        // Check for duplicates within the batch
        if (seenFileNames.has(trimmedFileName.toLowerCase())) {
            invalidCount++;
            return;
        }
        seenFileNames.add(trimmedFileName.toLowerCase());

        // Row is valid
        validRows.push({
            file_name: trimmedFileName
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateOtherDataField,
    validateOtherDataRows,
};
