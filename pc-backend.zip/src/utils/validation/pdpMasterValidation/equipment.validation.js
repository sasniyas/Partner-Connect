// Validation function for equipment fields (type, make, line, model)
const validateEquipmentField = (value) => {
    if (!value || typeof value !== 'string') {
        return false;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 && trimmed.length <= 100;
};

// Validation function for bulk add equipment
const validateEquipmentRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenEquipmentModels = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { year, equipment_type, equipment_make, equipment_line, equipment_model } = row;

        // Check required fields and field lengths
        if (
            !year ||
            !validateEquipmentField(equipment_type) ||
            !validateEquipmentField(equipment_make) ||
            !validateEquipmentField(equipment_line) ||
            !validateEquipmentField(equipment_model)
        ) {
            invalidCount++;
            return;
        }

        const trimmedType = equipment_type.trim();
        const trimmedMake = equipment_make.trim();
        const trimmedLine = equipment_line.trim();
        const trimmedModel = equipment_model.trim();

        // Check for duplicates within the batch (combination of year, type, make, line, model)
        const combinationKey = `${year}_${trimmedType.toLowerCase()}_${trimmedMake.toLowerCase()}_${trimmedLine.toLowerCase()}_${trimmedModel.toLowerCase()}`;
        if (seenEquipmentModels.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenEquipmentModels.add(combinationKey);

        // Row is valid
        validRows.push({
            year,
            equipment_type: trimmedType,
            equipment_make: trimmedMake,
            equipment_line: trimmedLine,
            equipment_model: trimmedModel
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateEquipmentField,
    validateEquipmentRows,
};
