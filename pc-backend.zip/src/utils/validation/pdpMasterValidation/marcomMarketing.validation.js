// Validation function for marcom marketing fields
const validateMarcomMarketingField = (value) => {
    if (!value || typeof value !== 'string') {
        return false;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 && trimmed.length <= 100;
};

// Validation function for bulk add marcom marketing
const validateMarcomMarketingRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { activity_Type, target, year } = row;

        // Check required fields and length validation
        if (
            !validateMarcomMarketingField(activity_Type) ||
            !validateMarcomMarketingField(target)
        ) {
            invalidCount++;
            return;
        }

        const trimmedActivityType = activity_Type.trim();
        const trimmedTarget = target.trim();

        // Check for duplicates within the batch (based on activity_Type, target, and year)
        const combinationKey = `${trimmedActivityType.toLowerCase()}_${trimmedTarget.toLowerCase()}_${year || 'null'}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            activity_Type: trimmedActivityType,
            target: trimmedTarget,
            year: year || null
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateMarcomMarketingField,
    validateMarcomMarketingRows,
};
