// Validation function for uptime parts category fields
const validateUptimePartsCategoryField = (value) => {
    if (!value || typeof value !== 'string') {
        return false;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 && trimmed.length <= 100;
};

// Validation function for bulk add uptime parts category
const validateUptimePartsCategoryRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { year, category, equipment_make, details, measurement_units, di_required } = row;

        // Check required fields and length validation
        if (
            !year ||
            !validateUptimePartsCategoryField(category) ||
            !validateUptimePartsCategoryField(equipment_make) ||
            !details || // details is required based on controller logic
            !validateUptimePartsCategoryField(measurement_units)
        ) {
            invalidCount++;
            return;
        }

        const trimmedCategory = category.trim();
        const trimmedMake = equipment_make.trim();
        const trimmedUnits = measurement_units.trim();

        // Check for duplicates within the batch (based on year, category, equipment_make)
        const combinationKey = `${year}_${trimmedCategory.toLowerCase()}_${trimmedMake.toLowerCase()}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            year,
            category: trimmedCategory,
            equipment_make: trimmedMake,
            details,
            measurement_units: trimmedUnits,
            di_required: di_required !== undefined ? di_required : 1
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateUptimePartsCategoryField,
    validateUptimePartsCategoryRows,
};
