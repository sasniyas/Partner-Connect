// Validation function for marcom fields
const validateMarcomField = (value) => {
    if (!value || typeof value !== 'string') {
        return false;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 && trimmed.length <= 255;
};

// Validation function for bulk add marcom
const validateMarcomRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { marcom_type, marcom_name, year } = row;

        // Check required fields and length validation
        if (
            !validateMarcomField(marcom_type) ||
            !validateMarcomField(marcom_name)
        ) {
            invalidCount++;
            return;
        }

        const trimmedType = marcom_type.trim();
        const trimmedName = marcom_name.trim();

        // Check for duplicates within the batch (based on marcom_type and marcom_name)
        const combinationKey = `${trimmedType.toLowerCase()}_${trimmedName.toLowerCase()}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            marcom_type: trimmedType,
            marcom_name: trimmedName,
            year: year || null
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateMarcomField,
    validateMarcomRows,
};
