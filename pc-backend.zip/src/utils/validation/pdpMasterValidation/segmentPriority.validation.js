// Validation function for segment focus area fields
const validateSegmentFocusAreaField = (value) => {
    if (!value || typeof value !== 'string') {
        return false;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 && trimmed.length <= 100;
};

// Validation function for bulk add segment priority
const validateSegmentPriorityRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { segment_focus_area, year } = row;

        // Check required fields and length validation
        if (
            !validateSegmentFocusAreaField(segment_focus_area)
        ) {
            invalidCount++;
            return;
        }

        const trimmedSegmentFocusArea = segment_focus_area.trim();

        // Check for duplicates within the batch (based on segment_focus_area and year)
        const combinationKey = `${trimmedSegmentFocusArea.toLowerCase()}_${year || 'null'}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            segment_focus_area: trimmedSegmentFocusArea,
            year: year || null
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateSegmentFocusAreaField,
    validateSegmentPriorityRows,
};
