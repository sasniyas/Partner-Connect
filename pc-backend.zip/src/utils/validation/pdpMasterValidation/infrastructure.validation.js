// Validation function for infrastructure fields
const validateInfrastructureField = (value) => {
    if (!value || typeof value !== 'string') {
        return false;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 && trimmed.length <= 100;
};

// Validation function for bulk add infrastructure
const validateInfrastructureRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { year, facility_type, facility_definition } = row;

        // Check required fields and length validation
        if (
            !year ||
            !validateInfrastructureField(facility_type) ||
            !validateInfrastructureField(facility_definition)
        ) {
            invalidCount++;
            return;
        }

        const trimmedType = facility_type.trim();
        const trimmedDefinition = facility_definition.trim();

        // Check for duplicates within the batch (based on year, facility_type, and facility_definition)
        const combinationKey = `${year}_${trimmedType.toLowerCase()}_${trimmedDefinition.toLowerCase()}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            year,
            facility_type: trimmedType,
            facility_definition: trimmedDefinition
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateInfrastructureField,
    validateInfrastructureRows,
};
