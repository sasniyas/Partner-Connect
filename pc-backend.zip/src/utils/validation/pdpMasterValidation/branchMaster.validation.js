// Validation function for branch master fields
const validateBranchMasterField = (value) => {
    if (!value || typeof value !== 'string') {
        return false;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 && trimmed.length <= 100;
};

// Validation function for bulk add branch master
const validateBranchMasterRows = (rows) => {
    const allowedStatuses = ['Completed', 'Not Started', 'In Progress','New'];
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { market_area_id, dealership_id, city_id, district_ids, branch_name, facility_type, target_date, development_status } = row;

        // Check required fields
        if (!market_area_id || !dealership_id || !city_id || !district_ids || !validateBranchMasterField(branch_name) || !facility_type) {
            invalidCount++;
            return;
        }

        // Check if district_ids is an array
        if (!Array.isArray(district_ids) || district_ids.length === 0) {
            invalidCount++;
            return;
        }

        // Validate development_status if provided
        if (development_status && !allowedStatuses.includes(development_status)) {
            invalidCount++;
            return;
        }

        const trimmedBranchName = branch_name.trim();

        // Check for duplicates within the batch (based on market_area_id, dealership_id, city_id, branch_name)
        const combinationKey = `${market_area_id}_${dealership_id}_${city_id}_${trimmedBranchName.toLowerCase()}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            market_area_id,
            dealership_id,
            city_id,
            district_ids,
            branch_name: trimmedBranchName,
            facility_type,
            target_date: target_date || null,
            development_status: development_status || null
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateBranchMasterField,
    validateBranchMasterRows,
};
