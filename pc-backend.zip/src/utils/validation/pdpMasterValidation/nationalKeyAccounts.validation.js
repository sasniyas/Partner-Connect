// Validation function for national key accounts fields
const validateNationalKeyAccountsField = (value) => {
    if (!value || typeof value !== 'string') {
        return false;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 && trimmed.length <= 100;
};

// Validation function for bulk add national key accounts
const validateNationalKeyAccountRows = (rows) => {
    const validRows = [];
    let invalidCount = 0;
    const seenCombinations = new Set();

    if (!Array.isArray(rows) || rows.length === 0) {
        return { data: [], error: rows.length || 0 };
    }

    rows.forEach((row) => {
        const { market_area_id, dealer_id, key_account_customer, year } = row;

        // Check required fields and length validation
        if (
            !market_area_id ||
            !dealer_id ||
            !validateNationalKeyAccountsField(key_account_customer)
        ) {
            invalidCount++;
            return;
        }

        const trimmedCustomer = key_account_customer.trim();

        // Check for duplicates within the batch (based on market_area_id, dealer_id, key_account_customer, and year)
        const combinationKey = `${market_area_id}_${dealer_id}_${trimmedCustomer.toLowerCase()}_${year || 'null'}`;
        if (seenCombinations.has(combinationKey)) {
            invalidCount++;
            return;
        }
        seenCombinations.add(combinationKey);

        // Row is valid
        validRows.push({
            market_area_id,
            dealer_id,
            key_account_customer: trimmedCustomer,
            year: year || null
        });
    });

    return { data: validRows, error: invalidCount };
};

module.exports = {
    validateNationalKeyAccountsField,
    validateNationalKeyAccountRows,
};
