import React, { useState, useEffect, useRef, useMemo } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { ArrowLeft, Upload } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import Searchinput from "../../../Components/Searchinput";
import Filter from "../../../Components/Filter";
import DeleteModal from "../../../Components/DeleteModal";
import CompleteReview from "../../../Components/CompleteReview";
import { ArrowUp,ArrowDown,ChevronDown, ChevronUp,ChevronsUpDown } from "lucide-react";

// ⭐ Import scorecard score view services
import {
  getScorecardScoreViewsByScorecardId,
  updateScorecardScoreView,
  getScorecardScoreViewDocsByScorecardId,
  addScorecardScoreViewDoc,
  deleteScorecardScoreViewDoc,
  groupScoreViewsByObjective,
  calculateObjectiveStats,
} from "../../../services/scorecard/scorecardScoreView.service";

// ⭐ Import scoring service for quarter scores lookup
import { getAllScorecardScoreViews } from "../../../services/scorecard/scoringScoreView.service";

// ⭐ Import scorecard service for completing review (updated import)
import { updateScorecard, completeScorecard } from "../../../services/scorecard/scorecard.service";

// ⭐ Define the preferred order for objectives (GLOBAL CONSTANT)
const PREFERRED_OBJECTIVE_ORDER = [
  "Customer Excellence",
  "Business Growth and Sustainability",
  "Distribution Excellence",
  "Business Process",
  "People and Culture"
];

const ScoreAudit = () => {
  const [showCompleteReview, setShowCompleteReview] = useState(false);
  const [completeLoading, setCompleteLoading] = useState(false);

  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [isMobileView, setIsMobileView] = useState(false);
  const navigate = useNavigate();

  const location = useLocation();
  const rowData = location.state?.item;
  const scorecardId = rowData?.id;

  const [activeIndex, setActiveIndex] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [saveLoading, setSaveLoading] = useState(false);
  const tableContainerRef = useRef(null);
  // ⭐ API Data States
  const [allScoreViews, setAllScoreViews] = useState([]);
  const [allQuarterData, setAllQuarterData] = useState([]); // For quarter scores lookup
  const [groupedData, setGroupedData] = useState({});
  const [objectiveNames, setObjectiveNames] = useState([]);
  const [objtabData, setObjtabData] = useState([]);
  const [documents, setDocuments] = useState([]);

  // ✅ Current editing states
  const [excludeChecked, setExcludeChecked] = useState(false);
  const [remarks, setRemarks] = useState("");
  const [reviewerScoreInput, setReviewerScoreInput] = useState("");
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [documentToDelete, setDocumentToDelete] = useState(null);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const [scoring, setScoring] = useState({
    maxScore: "",
    minScore: "",
    threshold: "",
    reviewerScore: "",
    finalScore: "",
  });
// ========== SCROLL STATES ==========
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [scrollDirection, setScrollDirection] = useState(null); // 'up' or 'down'
  const [lastScrollTop, setLastScrollTop] = useState(0);

const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  // ========== SCROLL HANDLER ==========
  const handleTableScroll = (e) => {
    const container = e.target;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Detect scroll direction
    if (scrollTop > lastScrollTop) {
      // Scrolling DOWN - show UP arrow
      setScrollDirection('down');
    } else if (scrollTop < lastScrollTop) {
      // Scrolling UP - show DOWN arrow
      setScrollDirection('up');
    }
    setLastScrollTop(scrollTop);

    setScrollPosition(scrollTop);

    // Show buttons only if there's enough content to scroll and user has scrolled down
    const isScrollable = scrollHeight > clientHeight;
    const hasScrolledDown = scrollTop > 100;
    
    setShowScrollButtons(isScrollable && hasScrolledDown);
  };

  // ========== SCROLL TO TOP ==========
  const scrollToTop = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }
  };

  // ========== SCROLL TO BOTTOM ==========
  const scrollToBottom = () => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({
        top: tableContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  };


  const [quarterScores, setQuarterScores] = useState([
    { quarter: "Q1", score: "" },
    { quarter: "Q2", score: "" },
    { quarter: "Q3", score: "" },
  ]);

  const [filters, setFilters] = useState({
    kpiNo: [],
    strategicObjective: [],
    scored: [],
  });

  // ⭐ Fetch score views on component mount
  useEffect(() => {
    if (scorecardId) {
      fetchScoreViews();
      fetchDocuments();
      fetchAllQuarterData(); // Fetch all data for quarter scores lookup
    } else {
      setError("No scorecard ID provided");
      setLoading(false);
    }
  }, [scorecardId]);

  // ⭐ Fetch ALL score views for quarter scores lookup
  const fetchAllQuarterData = async () => {
    try {
      const data = await getAllScorecardScoreViews();
      console.log("✅ All quarter data loaded:", data.length, "records");
      setAllQuarterData(data);
    } catch (err) {
      console.error("❌ Error fetching all quarter data:", err);
    }
  };

  // ⭐ Helper function to sort objectives by preferred order
  const sortObjectivesByPreferredOrder = (objectiveNames) => {
    return objectiveNames.sort((a, b) => {
      const indexA = PREFERRED_OBJECTIVE_ORDER.indexOf(a);
      const indexB = PREFERRED_OBJECTIVE_ORDER.indexOf(b);
      
      if (indexA !== -1 && indexB !== -1) {
        return indexA - indexB;
      }
      if (indexA !== -1) return -1;
      if (indexB !== -1) return 1;
      return a.localeCompare(b);
    });
  };

  // ⭐ Fetch score views from API
  const fetchScoreViews = async () => {
    try {
      setLoading(true);
      setError(null);

      const data = await getScorecardScoreViewsByScorecardId(scorecardId);
      console.log("✅ Score views loaded:", data.length, "records");

      setAllScoreViews(data);

      const grouped = groupScoreViewsByObjective(data);
      setGroupedData(grouped);

      const names = sortObjectivesByPreferredOrder(Object.keys(grouped));
      setObjectiveNames(names);

      const tabData = names.map((name, index) => {
        const stats = calculateObjectiveStats(grouped[name]);
        return {
          obj: name,
          score: stats.scoreText,
          percentage: stats.percentageText,
          isClickable: true,
        };
      });

      const totalStats = calculateObjectiveStats(data);
      tabData.push({
        obj: "Total SubKPI",
        score: totalStats.scoreText,
        percentage: totalStats.percentageText,
        isClickable: false,
      });

      setObjtabData(tabData);
    } catch (err) {
      console.error("❌ Error fetching score views:", err);
      setError(err.message || "Failed to load score views");
    } finally {
      setLoading(false);
    }
  };

  // ⭐ Fetch documents from API
  const fetchDocuments = async () => {
    try {
      const docs = await getScorecardScoreViewDocsByScorecardId(scorecardId);
      console.log("✅ Documents loaded:", docs.length, "records");
      setDocuments(docs);
    } catch (err) {
      console.error("❌ Error fetching documents:", err);
    }
  };

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 1024);
    };
    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  // ✅ Update form when row is selected
  useEffect(() => {
    if (selectedRow) {
      setScoring(selectedRow.scoring || {});
      setExcludeChecked(selectedRow.isExcluded || false);
      setRemarks(selectedRow.remarks || "");
      setReviewerScoreInput(selectedRow.reviewerScore || selectedRow.scoring?.reviewerScore || "");

      const year = selectedRow.year || selectedRow.scorecardYear || rowData?.year;
      const dealer = selectedRow.branch || selectedRow.dealer || selectedRow.scorecardBranch || rowData?.dealer || rowData?.branch;
      const subKpiId = selectedRow.subKpiId;
      const subKpiName = selectedRow.subKpi || selectedRow.subKpiName;

      console.log("🔍 Looking for quarter scores:", { year, dealer, subKpiId, subKpiName });

      const q1Record = allQuarterData.find(row =>
        (row.year === year || row.scorecardYear === year) &&
        (row.branch === dealer || row.dealer === dealer || row.scorecardBranch === dealer) &&
        (row.subKpiId === subKpiId || row.subKpi === subKpiName || row.subKpiName === subKpiName) &&
        row.quarter === "Q1"
      );

      const q2Record = allQuarterData.find(row =>
        (row.year === year || row.scorecardYear === year) &&
        (row.branch === dealer || row.dealer === dealer || row.scorecardBranch === dealer) &&
        (row.subKpiId === subKpiId || row.subKpi === subKpiName || row.subKpiName === subKpiName) &&
        row.quarter === "Q2"
      );

      const q3Record = allQuarterData.find(row =>
        (row.year === year || row.scorecardYear === year) &&
        (row.branch === dealer || row.dealer === dealer || row.scorecardBranch === dealer) &&
        (row.subKpiId === subKpiId || row.subKpi === subKpiName || row.subKpiName === subKpiName) &&
        row.quarter === "Q3"
      );

      console.log("📊 Quarter records found:", { q1: q1Record?.finalScore, q2: q2Record?.finalScore, q3: q3Record?.finalScore });

      setQuarterScores([
        { quarter: "Q1", score: q1Record?.finalScore || "" },
        { quarter: "Q2", score: q2Record?.finalScore || "" },
        { quarter: "Q3", score: q3Record?.finalScore || "" },
      ]);
    }
  }, [selectedRow, allQuarterData, rowData]);

  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const scoredOptions = ["Yes", "No"];

  const kpiNoOptions = [...new Set(allScoreViews.map(item => item.kpiNo))].filter(Boolean).sort();

  const handleBack = () => {
    navigate(-1);
  };

  const handleDeleteDocument = (doc) => {
    setDocumentToDelete(doc);
    setIsDeleteModalOpen(true);
  };

  const confirmDeleteDocument = async () => {
    if (!documentToDelete) return;

    setDeleteLoading(true);
    try {
      await deleteScorecardScoreViewDoc(documentToDelete.id);
      setDocuments((prev) => prev.filter((doc) => doc.id !== documentToDelete.id));
      console.log("✅ Document deleted successfully");
    } catch (err) {
      console.error("❌ Error deleting document:", err);
      alert(err.message || "Failed to delete document");
    } finally {
      setDeleteLoading(false);
      setIsDeleteModalOpen(false);
      setDocumentToDelete(null);
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleFileInputChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  const handleFiles = async (files) => {
    const fileArray = Array.from(files);
    setUploadLoading(true);
    setShowUploadModal(false);

    try {
      const userStr = localStorage.getItem("user");
      const user = userStr ? JSON.parse(userStr) : null;
      const uploadedBy = user?.id || null;

      for (const file of fileArray) {
        await addScorecardScoreViewDoc({
          scorecard_id: scorecardId,
          uploaded_by: uploadedBy,
          file: file,
        });
      }

      await fetchDocuments();
      console.log("✅ Documents uploaded successfully");
    } catch (err) {
      console.error("❌ Error uploading documents:", err);
      alert(err.message || "Failed to upload documents");
    } finally {
      setUploadLoading(false);
    }
  };

  const handleDownloadFile = (doc) => {
    if (doc.docUrl) {
      window.open(doc.docUrl, '_blank');
    }
  };

  const truncateFileName = (fileName, maxLength = 20) => {
    if (!fileName || fileName.length <= maxLength) return fileName || "Unknown";
    const extension = fileName.split('.').pop();
    const nameWithoutExt = fileName.substring(0, fileName.lastIndexOf('.'));
    const truncatedName = nameWithoutExt.substring(0, maxLength - extension.length - 4);
    return `${truncatedName}...${extension}`;
  };

  const handleAddDocument = () => {
    setShowUploadModal(true);
  };

  const handleDownloadTemplate = () => {
    const csvContent = `File Name,Uploaded By,Date,Remarks\nExample Document.xlsx,John Doe,18 Nov 2025,Sample remarks here\n`;
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'Scorecard_Document_Template.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const calculateFinalScore = (reviewerValue, maxScore, measurement, formula = null) => {
    if (reviewerValue === null || reviewerValue === undefined || reviewerValue === '' || isNaN(reviewerValue)) {
      return "";
    }

    const defaultFormula = {
      "steps": [
        { "expression": "percentage <20", "then": 3 },
        { "expression": "percentage <30", "then": 5 },
        { "expression": "percentage >50", "then": 8 },
        { "expression": "percentage >80", "then": 10 }
      ]
    };

    function evaluateExpression(expression, context) {
      const operators = {
        "<": (a, b) => a < b,
        "<=": (a, b) => a <= b,
        ">": (a, b) => a > b,
        ">=": (a, b) => a >= b,
        "==": (a, b) => a === b
      };

      const cleanExpression = expression.replace(/\s+/g, ' ').trim();
      const match = cleanExpression.match(/(\w+)\s*(<=|>=|<|>|==)\s*(\d+(\.\d+)?)/);

      if (!match) return false;

      const [, variable, operator, value] = match;

      return operators[operator](context[variable], Number(value));
    }

    function executeSteps(percentage, formulaToUse) {
      let parsedFormula;

      if (typeof formulaToUse === 'string') {
        try {
          parsedFormula = JSON.parse(formulaToUse);
        } catch (e) {
          console.warn("Failed to parse formula, using default:", e);
          parsedFormula = defaultFormula;
        }
      } else if (formulaToUse && typeof formulaToUse === 'object') {
        parsedFormula = formulaToUse;
      } else {
        parsedFormula = defaultFormula;
      }

      const steps = parsedFormula?.steps || defaultFormula.steps;

      for (const step of steps) {
        if (evaluateExpression(step.expression, { percentage })) {
          return step.then;
        }
      }

      return 0;
    }

    const rv = parseFloat(reviewerValue);

    if (isNaN(rv)) return "";

    const measurementType = (measurement || "").toLowerCase();

    if (measurementType === "percentage" || measurementType === "%") {
      const formulaToUse = formula || defaultFormula;
      const finalScore = executeSteps(rv, formulaToUse);
      return finalScore.toFixed(2);
    } else {
      return rv.toFixed(2);
    }
  };

  const handleSaveRemarks = async () => {
    if (!selectedRow) {
      alert("No row selected");
      return;
    }

    setSaveLoading(true);

    try {
      const calculatedFinalScore = calculateFinalScore(
        reviewerScoreInput,
        scoring.maxScore,
        selectedRow.measurement,
        selectedRow.formula
      );

      const updateData = {
        id: selectedRow.id,
        reviewer_score: reviewerScoreInput ? parseFloat(reviewerScoreInput) : null,
        isExcluded: excludeChecked,
        remarks: remarks,
        final_score: calculatedFinalScore ? parseFloat(calculatedFinalScore) : null,
        isScored: !!reviewerScoreInput,
      };

      console.log("📤 Saving score view:", updateData);

      await updateScorecardScoreView(updateData);

      const currentStatus = rowData?.reviewStatus || rowData?.review_status;
      if (currentStatus === "Created" && reviewerScoreInput) {
        try {
          await updateScorecard(scorecardId, { review_status: "Started" });
          console.log("✅ Status changed to Started");
        } catch (statusErr) {
          console.warn("Failed to update status to Started:", statusErr);
        }
      }

      const updatedScoreViews = allScoreViews.map(item => {
        if (item.id === selectedRow.id) {
          return {
            ...item,
            reviewerScore: reviewerScoreInput,
            isExcluded: excludeChecked,
            exclude: excludeChecked ? "Yes" : "No",
            remarks: remarks,
            finalScore: calculatedFinalScore,
            isScored: !!reviewerScoreInput,
            scored: reviewerScoreInput ? "Yes" : "No",
            scoring: {
              ...item.scoring,
              reviewerScore: reviewerScoreInput,
              finalScore: calculatedFinalScore,
            },
          };
        }
        return item;
      });

      setAllScoreViews(updatedScoreViews);

      const grouped = groupScoreViewsByObjective(updatedScoreViews);
      setGroupedData(grouped);

      const names = sortObjectivesByPreferredOrder(Object.keys(grouped));
      const tabData = names.map((name) => {
        const stats = calculateObjectiveStats(grouped[name]);
        return {
          obj: name,
          score: stats.scoreText,
          percentage: stats.percentageText,
          isClickable: true,
        };
      });

      const totalStats = calculateObjectiveStats(updatedScoreViews);
      tabData.push({
        obj: "Total SubKPI",
        score: totalStats.scoreText,
        percentage: totalStats.percentageText,
        isClickable: false,
      });

      setObjtabData(tabData);

      const updatedSelectedRow = updatedScoreViews.find(item => item.id === selectedRow.id);
      setSelectedRow(updatedSelectedRow);

      console.log("✅ Changes saved successfully");
    } catch (err) {
      console.error("❌ Error saving changes:", err);
      alert(err.message || "Failed to save changes");
    } finally {
      setSaveLoading(false);
    }
  };

  const handleCompleteReview = async () => {
    setCompleteLoading(true);

    try {
      await completeScorecard(scorecardId);
      
      console.log("✅ Review completed successfully");
      
      const quarter = rowData?.quarter || rowData?.quarterFrequency;
      if (quarter === "Q4") {
        console.log("✅ Annual scorecard created automatically for Q4");
      }
      
      setShowCompleteReview(false);
      navigate(-1);
    } catch (err) {
      console.error("❌ Error completing review:", err);
      alert(err.message || "Failed to complete review");
    } finally {
      setCompleteLoading(false);
    }
  };

  const getCurrentTabData = () => {
    if (objectiveNames.length === 0) return [];
    const currentObjective = objectiveNames[activeIndex];
    if (!currentObjective || !groupedData[currentObjective]) return [];
    return groupedData[currentObjective];
  };
  const filteredData = getCurrentTabData().filter((row) => {
    const matchesSearch =
      searchTerm === "" ||
      Object.values(row).some((value) =>
        String(value).toLowerCase().includes(searchTerm.toLowerCase())
      );
    const matchesKpiNo = filters.kpiNo.length === 0 || filters.kpiNo.includes(row.kpiNo);
    const matchesScored = filters.scored.length === 0 || filters.scored.includes(row.scored);
    return matchesSearch && matchesKpiNo && matchesScored;
  });
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [filteredData, sortKey, sortOrder]);

  const sortedDatadoc = useMemo(() => {
  if (!sortKey || !sortOrder) return documents;

  return [...documents].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [documents, sortKey, sortOrder]);


  const handleRowSelect = (row) => {
    setSelectedRow(row);
    window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
  };

  const MobileRowCard = ({ row, index, isSelected }) => (
    <div
      onClick={() => handleRowSelect(row)}
      className={`bg-white border p-3 mb-3 shadow-sm cursor-pointer transition ${isSelected ? "border-darkblue1 bg-lightBlue/10 ring-2 ring-darkblue1" : "border-gray-200 hover:border-gray-400"}`}
    >
      <div className="flex justify-between items-start mb-2">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold text-darkblue1">KPI {row.kpiNo}</span>
            <span className={`text-xs font-medium px-2 py-0.5 ${row.scored === "Yes" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
              {row.scored}
            </span>
          </div>
          <p className="text-xs font-medium text-black">{row.strategicObjective}</p>
          <p className="text-xs text-gray-600">{row.kpi}</p>
        </div>
      </div>
      <div className="space-y-1.5 border-t pt-2">
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Sub KPI:</span>
          <span className="text-xs text-black text-right line-clamp-2">{row.subKpi}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Max Score:</span>
          <span className="text-xs text-black font-medium">{row.maxScore}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Reviewer Score:</span>
          <span className="text-xs text-black font-medium">{row.reviewerScore || "—"}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Final Score:</span>
          <span className="text-xs text-darkblue1 font-semibold">{row.finalScore || "—"}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Reviewer:</span>
          <span className="text-xs text-black">{row.reviewerName || "—"}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Exclude:</span>
          <span className="text-xs text-black">{row.exclude}</span>
        </div>
      </div>
    </div>
  );

  const formatDisplayDate = (dateString) => {
    if (!dateString) return "—";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return dateString;
      const day = date.getDate();
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const month = monthNames[date.getMonth()];
      const year = date.getFullYear();
      let hours = date.getHours();
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12;
      return `${day} ${month},${year} ${hours}:${minutes} ${ampm}`;
    } catch {
      return dateString;
    }
  };

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] sm:mt-[5rem] lg:mt-[6rem] p-2 lg:px-4 pb-6">
          {/* Header Section */}
          <div className="w-full flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 mb-3">
            <div className="flex items-center gap-2 flex-shrink-0">
              <ArrowLeft onClick={handleBack} size={20} className="cursor-pointer hover:scale-110 transition duration-200 text-white bg-darkblue1 p-1" />
              <h2 className="text-sm sm:text-base font-semibold text-darkblue1 truncate">Scorecard / View Reviews</h2>
              
            </div>

            <div className="w-full lg:w-auto bg-white shadow-md border border-gray-200 px-1.5 py-1">
              <div className="grid grid-cols-1 sm:grid-cols-3 divide-x divide-gray-200">
                <div className="p-3 text-center">
                  <p className="text-xs font-normal text-black mb-1">Dealer Name</p>
                  <p className="text-xs font-normal text-SteelBlue1">{rowData?.dealer || "—"}</p>
                </div>
                <div className="p-3 text-center">
                  <p className="text-xs font-normal text-black mb-1">Year / Quarter</p>
                  <p className="text-xs font-normal text-SteelBlue1">{rowData?.year || "—"} / {rowData?.quarter || rowData?.quarterFrequency || "—"}</p>
                </div>
                <div className="p-3 text-center">
                  <p className="text-xs font-normal text-black mb-1">Physical Audit Start Date</p>
                  <p className="text-xs font-normal text-SteelBlue1">{formatDisplayDate(rowData?.physicalAuditStartDateRaw || rowData?.physicalAuditStartDate)}</p>
                </div>
              </div>
            </div>

            <button onClick={() => setShowCompleteReview(true)} disabled={loading} className="bg-darkblue1 text-white px-4 py-1.5 text-xs flex-shrink-0 disabled:opacity-50">
              Complete Review
            </button>
          </div>
  <div className="hidden lg:block h-1 bg-darkblue1 w-[5%] ml-7 -mt-10 mb-10"></div>
          {loading && (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
              <span className="ml-3 text-gray-600">Loading score views...</span>
            </div>
          )}

          {error && !loading && (
            <div className="bg-red-50 border border-red-200 p-4 mb-4">
              <p className="text-red-600 text-sm">{error}</p>
              <button onClick={fetchScoreViews} className="mt-2 text-xs text-blue-600 hover:underline">Try Again</button>
            </div>
          )}

          {!loading && !error && (
            <>
              {objtabData.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-0 w-full mb-3 overflow-hidden border border-gray-300">
                  {objtabData.map((item, index) => (
                    <div
                      key={index}
                      onClick={() => { if (item.isClickable) { setActiveIndex(index); setSelectedRow(null); } }}
                      className={`p-1.5 text-center border-r border-gray-300 last:border-r-0 transition duration-200 ${item.isClickable ? "cursor-pointer" : "cursor-default bg-gray-100"} ${activeIndex === index && item.isClickable ? "bg-Dustyblue text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1" : "bg-white text-black hover:bg-darkblue1 hover:text-white"}`}
                    >
                      <p className="text-xs font-semibold mb-1 leading-tight">{item.obj}</p>
                      <p className="text-xs mb-0.5 leading-tight">{item.score}</p>
                      <p className="text-xs leading-tight">{item.percentage}</p>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-start flex-wrap gap-2 sm:gap-3 w-full mb-3">
                <Searchinput value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} placeholder="Search" className="w-full sm:w-auto" iconColor="text-black" bgColor="bg-white" borderColor="border-black/60" textColor="text-black" shadow="shadow-none" inputPadding="pl-7 pr-3 py-1.5" iconSize="w-3.5 h-3.5" iconLeft="left-3" inputWidth="w-full" focusRing="focus:ring-1 focus:ring-black/60" hoverInputClasses="hover:bg-white hover:border-black/60" />
                <Filter name="kpiNo" value={filters.kpiNo} options={kpiNoOptions} onChange={handleFilterChange} placeholder="KPI No" customWidth="w-full sm:w-[140px]" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" />
                <Filter name="scored" value={filters.scored} options={scoredOptions} onChange={handleFilterChange} placeholder="Scored" customWidth="w-full sm:w-[140px]" placeholderColor="text-black" buttonBorderColor="border-black/60" dropdownBgColor="bg-white" dropdownTextColor="text-black" dropdownHoverColor="hover:bg-lightBlue/50" dropdownBorderColor="border-black/60" closedBgColor="bg-white" hoverRingColor="ring-black" openBgColor="bg-white" textColor="text-black" />
              </div>

              {isMobileView ? (
                <div className="space-y-3 mb-4">
                  {filteredData.length > 0 ? filteredData.map((row, index) => (<MobileRowCard key={`${row.id}-${index}`} row={row} index={index} isSelected={selectedRow?.id === row.id} />)) : (<div className="bg-white border border-gray-200 p-6 text-center text-gray-500">No data available</div>)}
                </div>
              ) : (
                <div className="bg-white shadow-md border border-Dustyblue overflow-hidden relative mb-4">
                  <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-hidden"
            style={{ scrollbarWidth: "none", msOverflowStyle: "none", maxHeight: "calc(100vh - 14rem)" }}
               onScroll={handleTableScroll}
          >
            <table className="w-full text-xs border-collapse table-fixed">
              <thead className="bg-Dustyblue text-white text-xs sticky top-0 z-10">
                        <tr>
                         {/* KPI# */}
<th
  className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[6%] cursor-pointer select-none"
  onClick={() => handleSort("kpiNo")}
>
  <div className="flex items-center justify-center gap-1">
    KPI No
    {sortKey !== "kpiNo" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

    {sortKey === "kpiNo" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "kpiNo" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

{/* Strategic Objective */}
<th
  className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[12%] cursor-pointer select-none"
  onClick={() => handleSort("strategicObjective")}
>
  <div className="flex items-center gap-1">
    Strategic Objective
    {sortKey === "strategicObjective" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "strategicObjective" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

{/* KPI */}
<th
  className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[12%] cursor-pointer select-none"
  onClick={() => handleSort("kpi")}
>
  <div className="flex items-center gap-1">
    KPI
    {sortKey === "kpi" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "kpi" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

{/* Sub KPI */}
<th
  className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[12%] cursor-pointer select-none"
  onClick={() => handleSort("subKpi")}
>
  <div className="flex items-center gap-1">
    Sub KPI
    {sortKey === "subKpi" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "subKpi" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

{/* Max */}
<th
  className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%] cursor-pointer select-none"
  onClick={() => handleSort("maxScore")}
>
  <div className="flex items-center justify-center gap-1">
    Max
    {sortKey === "maxScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "maxScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

{/* Reviewer */}
<th
  className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%] cursor-pointer select-none"
  onClick={() => handleSort("reviewerScore")}
>
  <div className="flex items-center justify-center gap-1">
    Reviewer
    {sortKey === "reviewerScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "reviewerScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

{/* Final */}
<th
  className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[5%] cursor-pointer select-none"
  onClick={() => handleSort("finalScore")}
>
  <div className="flex items-center justify-center gap-1">
    Final
    {sortKey === "finalScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "finalScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

{/* Reviewer Name */}
<th
  className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[12%] cursor-pointer select-none"
  onClick={() => handleSort("reviewerName")}
>
  <div className="flex items-center gap-1">
    Reviewer Name
    {sortKey === "reviewerName" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "reviewerName" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

{/* Scored */}
<th
  className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[6%] cursor-pointer select-none"
  onClick={() => handleSort("scored")}
>
  <div className="flex items-center justify-center gap-1">
    Scored
    {sortKey === "scored" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "scored" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>

{/* Excl. */}
<th
  className="py-1.5 px-4 text-center text-xs font-medium w-[5%] cursor-pointer select-none"
  onClick={() => handleSort("exclude")}
>
  <div className="flex items-center justify-center gap-1">
    Excl.
    {sortKey === "exclude" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
    {sortKey === "exclude" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
  </div>
</th>
                        </tr>
                      </thead>
                      <tbody>
                        {sortedData.length > 0 ?sortedData.map((row, index) => (
                          <tr 
                            key={`${row.id}-${index}`} 
                            onClick={() => handleRowSelect(row)} 
                            className={`cursor-pointer hover:bg-lightBlue/30 transition border-b border-gray-200 align-top ${selectedRow?.id === row.id ? "bg-lightBlue/20 ring-2 ring-inset ring-darkblue1" : ""}`}
                          >
                            {/* KPI# */}
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center font-medium text-darkblue1">
  {row.kpiNo}
</td>

{/* Strategic Objective */}
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.strategicObjective?.length > 22)
          setHoveredCell(row.id + "-strategicObjective");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.strategicObjective || "—"}
    </p>

    {hoveredCell === row.id + "-strategicObjective" && (
      <span className="absolute left-1/2 top-full -mt-2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {row.strategicObjective}
      </span>
    )}
  </div>
</td>

{/* KPI */}
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.kpi?.length > 22)
          setHoveredCell(row.id + "-kpi");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.kpi || "—"}
    </p>

    {hoveredCell === row.id + "-kpi" && (
      <span className="absolute left-1/2 top-full -mt-2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {row.kpi}
      </span>
    )}
  </div>
</td>

{/* Sub KPI */}
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.subKpi?.length > 22)
          setHoveredCell(row.id + "-subKpi");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.subKpi || "—"}
    </p>

    {hoveredCell === row.id + "-subKpi" && (
      <span className="absolute left-1/2 top-full -mt-2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {row.subKpi}
      </span>
    )}
  </div>
</td>

{/* Max */}
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center font-semibold">
  {row.maxScore}
</td>

{/* Reviewer */}
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center">
  {row.reviewerScore || "—"}
</td>

{/* Final */}
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center font-semibold text-darkblue1">
  {row.finalScore || "—"}
</td>

{/* Reviewer Name */}
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs">
  <div className="relative">
    <p
      className="truncate max-w-[10rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.reviewerName?.length > 18)
          setHoveredCell(row.id + "-reviewerName");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.reviewerName || "—"}
    </p>

    {hoveredCell === row.id + "-reviewerName" && (
      <span className="absolute left-1/2 top-full -mt-2 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-50">
        {row.reviewerName}
      </span>
    )}
  </div>
</td>

{/* Scored */}
<td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-xs text-center">
  <span
    className={`inline-block px-1.5 py-0.5 text-[10px] font-semibold rounded ${
      row.scored === "Yes"
        ? "bg-green-100 text-green-700"
        : "bg-red-100 text-red-600"
    }`}
  >
    {row.scored}
  </span>
</td>

{/* Excl. */}
<td className="px-4 py-1 text-xs text-center">
  <span
    className={`inline-block px-1.5 py-0.5 text-[10px] font-medium rounded ${
      row.exclude === "Yes"
        ? "bg-orange-100 text-orange-700"
        : "bg-gray-100 text-gray-600"
    }`}
  >
    {row.exclude}
  </span>
</td>
                          </tr>
                        )) : (
                          <tr>
                            <td colSpan="10" className="text-center py-8 text-xs text-gray-500 italic">
                              No data available for this category
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                   {showScrollButtons && (
            <div className="fixed bottom-6 right-6 z-40 pointer-events-auto animate-fade-in">
              {/* Show UP arrow when scrolling DOWN */}
              {scrollDirection === 'down' && (
                <button
                  onClick={scrollToTop}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to top"
                >
                  <ArrowUp className="w-2 h-2" />
                </button>
              )}

              {/* Show DOWN arrow when scrolling UP */}
              {scrollDirection === 'up' && (
                <button
                  onClick={scrollToBottom}
                  className="w-4 h-4 rounded-full bg-darkblue1 text-white shadow-lg hover:bg-slate-800 transition-all duration-200 flex items-center justify-center opacity-80 hover:opacity-100 hover:scale-125 backdrop-blur-sm"
                  aria-label="Scroll to bottom"
                >
                  <ArrowDown className="w-2 h-2" />
                </button>
              )}
            </div>
          )}

                </div>
              )}

              {selectedRow && (
                <div className="bg-white border border-gray-300 p-4 shadow-lg">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                    <div className="flex flex-col">
                      <div className="mb-2">
                        <span className="text-xs font-semibold text-gray-700">Strategic Objective: </span>
                        <span className="text-xs text-black">{selectedRow.strategicObjective}</span>
                      </div>
                      <div className="border border-gray-300 p-3 bg-gray-50 flex-1">
                        <label className="flex items-center gap-2 text-xs font-medium text-gray-700 mb-3 cursor-pointer">
                          <input type="checkbox" checked={excludeChecked} onChange={(e) => setExcludeChecked(e.target.checked)} className="w-3 h-3 accent-darkblue1 cursor-pointer" />
                          Exclude from scoring
                        </label>
                        <div className="border border-gray-400 overflow-hidden">
                          <table className="w-full text-xs">
                            <thead className="bg-Dustyblue text-white">
                              <tr>
                                <th className="px-2 py-2 text-left font-normal border-r border-white">Scoring Criteria</th>
                                <th className="px-2 py-2 text-left font-normal border-r border-white">Scoring</th>
                                <th className="px-2 py-2 text-left font-normal">Quarter Score</th>
                              </tr>
                            </thead>
                            <tbody className="bg-white">
                              <tr className="border-b border-gray-300">
                                {/* ✅ FIXED: Added whitespace-pre-line to display line breaks properly */}
                                <td 
                                  rowSpan="4" 
                                  className="px-2 py-3 border-r border-gray-300 font-bold align-middle text-center bg-gray-50 text-xs whitespace-pre-line" 
                                  dangerouslySetInnerHTML={{ __html: selectedRow.scoringCriteria || "—" }} 
                                />
                                <td className="px-2 py-1.5 border-r border-gray-300">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-600 whitespace-nowrap">Max Score:</span>
                                    <span className="font-bold text-darkblue1">{scoring.maxScore}</span>
                                  </div>
                                </td>
                                <td className="px-2 py-1.5 bg-gray-50">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-600">{quarterScores[0]?.quarter}:</span>
                                    <span className="font-bold">{quarterScores[0]?.score || "—"}</span>
                                  </div>
                                </td>
                              </tr>
                              <tr className="border-b border-gray-300">
                                <td className="px-2 py-1.5 border-r border-gray-300">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-600 whitespace-nowrap">Min Score:</span>
                                    <span className="font-bold text-darkblue1">{scoring.minScore || scoring.threshold}</span>
                                  </div>
                                </td>
                                <td className="px-2 py-1.5 bg-gray-50">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-600">{quarterScores[1]?.quarter}:</span>
                                    <span className="font-bold">{quarterScores[1]?.score || "—"}</span>
                                  </div>
                                </td>
                              </tr>
                              <tr className="border-b border-gray-300 bg-green-50">
                                <td className="px-2 py-1.5 border-r border-gray-300">
                                  <div className="flex flex-col gap-1">
                                    <span className="text-gray-700 font-medium text-xs whitespace-nowrap">Reviewer Score:</span>
                                    <div className="flex items-center gap-1">
                                      <input type="number" value={reviewerScoreInput} onChange={(e) => setReviewerScoreInput(e.target.value)} placeholder="Enter" min="0" max="100" step="0.01" className="flex-1 text-xs border border-green-500 px-2 py-1 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent min-w-0" />
                                      <span className="text-gray-500 font-medium">{selectedRow.measurement === "Percentage" ? "%" : ""}</span>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-2 py-1.5 bg-gray-50">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-600">{quarterScores[2]?.quarter}:</span>
                                    <span className="font-bold">{quarterScores[2]?.score || "—"}</span>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td className="px-2 py-1.5 border-r border-gray-300 bg-blue-50">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-700 font-medium whitespace-nowrap">Final Score:</span>
                                    <span className="font-bold text-darkblue1 text-sm">
                                      {reviewerScoreInput 
                                        ? calculateFinalScore(
                                            reviewerScoreInput, 
                                            scoring.maxScore, 
                                            selectedRow.measurement,
                                            selectedRow.formula
                                          ) 
                                        : scoring.finalScore || "—"}
                                    </span>
                                  </div>
                                </td>
                                <td className="px-2 py-1.5"></td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col">
                   <div className="mb-2">
  <span className="text-xs font-semibold text-gray-700">
    {selectedRow.kpiNo}
    <sup>
      {selectedRow.kpiNo % 100 >= 11 && selectedRow.kpiNo % 100 <= 13
        ? "th"
        : selectedRow.kpiNo % 10 === 1
        ? "st"
        : selectedRow.kpiNo % 10 === 2
        ? "nd"
        : selectedRow.kpiNo % 10 === 3
        ? "rd"
        : "th"}
    </sup>{" "}
    KPI:
  </span>
  <span className="text-xs text-black">
    {selectedRow.kpi}
  </span>
</div>
                      <div className="border border-gray-300 p-1.5 bg-gray-50 flex flex-col flex-1">
                        <h3 className="text-xs font-semibold text-darkblue1 mb-2">Remarks</h3>
                        <textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Enter your remarks here..." className="border border-gray-300 text-xs px-3 py-2 resize-none flex-1 focus:ring-2 focus:ring-darkblue1 focus:border-darkblue1 outline-none bg-white min-h-[200px]"></textarea>
                      </div>
                    </div>

                    <div className="flex flex-col">
                      <div className="mb-2">
                        <span className="text-xs font-semibold text-gray-700">Sub KPI: </span>
                        <span className="text-xs text-black">{selectedRow.subKpi}</span>
                      </div>
                      <div className="border border-gray-300 p-3 bg-gray-50 flex flex-col flex-1">
                        <div className="flex justify-between items-center mb-3">
                          <h3 className="text-xs font-semibold text-darkblue1">Upload Supporting Document</h3>
                          <div className="flex gap-2">
                            <button onClick={handleDownloadTemplate} className="text-xs bg-white border border-darkblue1 text-darkblue1 px-3 py-1.5 hover:bg-darkblue1 hover:text-white transition font-medium">Template</button>
                            <button onClick={handleAddDocument} disabled={uploadLoading} className="text-xs bg-darkblue1 text-white px-3 py-1.5 hover:bg-darkblue2 transition font-medium flex items-center gap-1 disabled:opacity-50">
                              <span className="text-base leading-none">+</span>
                              <span>{uploadLoading ? "Uploading..." : "Add"}</span>
                            </button>
                          </div>
                        </div>
<div
  ref={tableContainerRef}
  className="flex-1 max-h-56 overflow-y-auto overflow-x-hidden bg-white shadow-md border border-Dustyblue"
  style={{
    scrollbarWidth: "none",
    msOverflowStyle: "none",
  }}
  // onScroll={handleTableScroll}
>                          {sortedDatadoc.length > 0 ? (
                             <table className="w-full text-xs border-collapse table-fixed">
              <thead className="bg-Dustyblue text-white text-xs sticky top-0 z-10">
                              
                                <tr>
  {/* File Name */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none"
    onClick={() => handleSort("fileName")}
  >
    <div className="flex items-center gap-1">
      File Name
      {sortKey !== "fileName" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

      {sortKey === "fileName" && sortOrder === "asc" && (
        <ChevronUp className="w-3 h-3 text-white" />
      )}
      {sortKey === "fileName" && sortOrder === "desc" && (
        <ChevronDown className="w-3 h-3 text-white" />
      )}
    </div>
  </th>

  {/* Uploaded By */}
  <th
    className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none"
    onClick={() => handleSort("uploadedBy")}
  >
    <div className="flex items-center gap-1">
      Uploaded by
      {sortKey === "uploadedBy" && sortOrder === "asc" && (
        <ChevronUp className="w-3 h-3 text-white" />
      )}
      {sortKey === "uploadedBy" && sortOrder === "desc" && (
        <ChevronDown className="w-3 h-3 text-white" />
      )}
    </div>
  </th>

  {/* Action */}
  <th
    className="py-1.5 px-4 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 border-r-0 font-medium w-16 cursor-pointer select-none"
  >
      Action
  </th>
</tr>
                            
                              </thead>
                              <tbody>
                                {sortedDatadoc.map((doc, i) => (
                                  <tr key={doc.id || i} className={`hover:bg-gray-50 transition ${i !== documents.length - 1 ? "" : ""}`}>
                                    <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 ">
                                      <button onClick={() => handleDownloadFile(doc)} className="font-semibold text-darkblue1 hover:text-blue-800 underline decoration-2 underline-offset-2 cursor-pointer text-left truncate block max-w-full transition" title={doc.name}>{truncateFileName(doc.name, 20)}</button>
                                    </td>
                                    <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0 ">
                                      <div className="text-gray-600">
                                        <div className="font-medium text-black">{doc.uploadedByName || "Unknown"}</div>
                                        <div className="text-xs text-gray-500">{doc.date}</div>
                                      </div>
                                    </td>
                                    <td className="px-3 py-1 border border-grey2 border-t-0 border-l-0  border-r-0 text-center">
                                      <button onClick={() => handleDeleteDocument(doc)} className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1.5 transition inline-flex items-center justify-center" title="Delete document">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          ) : (
                            <div className="text-center text-gray-400 text-xs py-8">
                              <svg className="w-12 h-12 mx-auto mb-2 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                              </svg>
                              <p>No documents uploaded</p>
                              <p className="text-xs mt-1">Click "+ Add" to upload files</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end mt-4 pt-3 border-t border-gray-300">
                    <button onClick={handleSaveRemarks} disabled={saveLoading} className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 hover:bg-darkblue2 transition shadow-sm disabled:opacity-50">
                      {saveLoading ? "Saving..." : "Save Changes"}
                    </button>
                  </div>
                </div>
              )}

              {!selectedRow && filteredData.length > 0 && (
                <div className="bg-white border-2 border-dashed border-gray-300 p-8 text-center">
                  <svg className="w-16 h-16 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
                  </svg>
                  <p className="text-gray-500 text-sm">Select a row from the table above to view and edit scoring details</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white max-w-2xl w-full p-6 relative shadow-2xl">
            <button onClick={() => setShowUploadModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <h3 className="text-lg font-semibold text-darkblue1 mb-1">Upload Document</h3>
            <p className="text-sm text-gray-600 mb-4">Add supporting documentation for this scorecard</p>
            <div className={`border-2 border-dashed p-12 text-center transition ${dragActive ? "border-darkblue1 bg-blue-50" : "border-gray-300 hover:border-gray-400"}`} onDragEnter={handleDrag} onDragLeave={handleDrag} onDragOver={handleDrag} onDrop={handleDrop}>
              <div className="flex flex-col items-center gap-4">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                  <Upload size={32} className="text-darkblue1" />
                </div>
                <div>
                  <p className="text-base text-gray-700 mb-1 font-medium">Choose a file or drag & drop it here</p>
                  <p className="text-sm text-gray-500">Supported formats: XLS, XLSX, PDF</p>
                  <p className="text-xs text-gray-400 mt-1">Maximum file size: 10MB</p>
                </div>
                <label htmlFor="file-upload" className="cursor-pointer">
                  <span className="inline-block bg-darkblue1 text-white text-sm font-medium px-6 py-2 hover:bg-darkblue2 transition">Browse Files</span>
                  <input type="file" accept=".xls,.xlsx,.pdf" onChange={handleFileInputChange} className="hidden" id="file-upload" multiple />
                </label>
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setShowUploadModal(false)} className="border border-gray-300 text-gray-700 text-sm font-medium px-6 py-2 hover:bg-gray-50 transition">Cancel</button>
            </div>
          </div>
        </div>
      )}

      <DeleteModal isOpen={isDeleteModalOpen} onClose={() => { if (!deleteLoading) { setIsDeleteModalOpen(false); setDocumentToDelete(null); } }} onConfirm={confirmDeleteDocument} loading={deleteLoading} title="Delete Document" message="Are you sure you want to delete this document? This action cannot be undone." />
      <CompleteReview isOpen={showCompleteReview} onClose={() => setShowCompleteReview(false)} loading={completeLoading} extraMessage="Once completed, you cannot change any values." onConfirm={handleCompleteReview} />
    </div>
  );
};

export default ScoreAudit;