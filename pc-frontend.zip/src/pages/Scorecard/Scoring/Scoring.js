import React, { useState, useEffect, useRef,  } from "react";
import Header from "../../../Components/Header";
import SubNavbar3 from "../../../Components/SubNavbar3";
import { Upload } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Filter from "../../../Components/Filter";
import DeleteModal from "../../../Components/DeleteModal";
import { useMemo } from "react";
import { ChevronDown,ChevronUp,ChevronsUpDown } from "lucide-react";
// ⭐ Import scoring services
import {
  getAllScorecardScoreViews,
  updateScorecardScoreView,
  bulkToggleScorecardScoreViewExclusion,
  getScorecardScoreViewDocsByScorecardId,
  addScorecardScoreViewDoc,
  deleteScorecardScoreViewDoc,
  getUniqueFilterOptions,
  calculateFinalScore,
} from "../../../services/scorecard/scoringScoreView.service";

const Scoring = () => {
  // ⭐ API Data State
  const [tableData, setTableData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [saveLoading, setSaveLoading] = useState(false);

  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [isMobileView, setIsMobileView] = useState(false);
  const navigate = useNavigate();
  const tableContainerRef = useRef("");

  // Scoring form states
  const [scoringData, setScoringData] = useState({
    maxScore: "",
    threshold: "",
    reviewerScore: "",
    finalScore: "",
  });

  const [quarterScores, setQuarterScores] = useState([
    { quarter: "Q1", score: "" },
    { quarter: "Q2", score: "" },
    { quarter: "Q3", score: "" },
  ]);

  const [remarks, setRemarks] = useState("");
  const [isExcluded, setIsExcluded] = useState(false);
  const [bulkExcludeLoading, setBulkExcludeLoading] = useState(false);
  const [documents, setDocuments] = useState([]);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [documentToDelete, setDocumentToDelete] = useState(null);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // Filter states
  const [filters, setFilters] = useState({
    year: [],
    quarter: [],
    marketArea: [],
    dealer: [],
    strategicObjective: [],
    kpiNo: [],
    reviewer: [],
    scored: [],
  });

  // ⭐ Dynamic filter options from API data
  const [filterOptions, setFilterOptions] = useState({
    year: [],
    quarter: [],
    dealer: [],
    strategicObjective: [],
    kpiNo: [],
    reviewer: [],
  });

  const scoredOptions = ["Yes", "No"];
const [sortKey, setSortKey] = useState(null);
const [sortOrder, setSortOrder] = useState(null);
const [hoveredCell, setHoveredCell] = useState(null);

const handleSort = (key) => {
  if (sortKey === key) {
    if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortKey(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  } else {
    setSortKey(key);
    setSortOrder("asc");
  }
};

  // ⭐ Fetch all score views on component mount
  useEffect(() => {
    fetchAllScoreViews();
  }, []);

  // ⭐ Fetch all score views from API
  const fetchAllScoreViews = async () => {
    try {
      setLoading(true);
      setError(null);

      const data = await getAllScorecardScoreViews();
      console.log("✅ All score views loaded:", data.length, "records");

      setTableData(data);

      // Extract unique filter options from data
      setFilterOptions({
        year: getUniqueFilterOptions(data, "year"),
        quarter: getUniqueFilterOptions(data, "quarter"),
        dealer: getUniqueFilterOptions(data, "dealer").filter(d => d && d !== "—"),
        strategicObjective: getUniqueFilterOptions(data, "strategicObjective"),
        kpiNo: getUniqueFilterOptions(data, "kpiNo"),
        reviewer: getUniqueFilterOptions(data, "reviewer").filter(r => r !== "—"),
      });
    } catch (err) {
      console.error("❌ Error fetching score views:", err);
      setError(err.message || "Failed to load score views");
    } finally {
      setLoading(false);
    }
  };

  // ⭐ Fetch documents for selected scorecard
  const fetchDocuments = async (scorecardId) => {
    if (!scorecardId) return;
    
    try {
      const docs = await getScorecardScoreViewDocsByScorecardId(scorecardId);
      console.log("✅ Documents loaded:", docs.length, "records");
      setDocuments(docs);
    } catch (err) {
      console.error("❌ Error fetching documents:", err);
      setDocuments([]);
    }
  };

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 1024);
    };
    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  // Update form when row is selected
  useEffect(() => {
    if (selectedRow) {
      setScoringData({
        maxScore: selectedRow.maxScore || "",
        threshold: selectedRow.threshold || selectedRow.minScore || "",
        reviewerScore: selectedRow.reviewerScore || "",
        finalScore: selectedRow.finalScore || "",
      });
      setRemarks(selectedRow.remarks || "");
      setIsExcluded(selectedRow.excluded || selectedRow.isExcluded || false);
      
      // Fetch documents for the selected scorecard
      if (selectedRow.scorecardId) {
        fetchDocuments(selectedRow.scorecardId);
      } else {
        setDocuments([]);
      }

      // ⭐ Find Quarter Scores from same Year, same Dealer, same Sub KPI
      const year = selectedRow.year || selectedRow.scorecardYear;
      const dealerId = selectedRow.dealerId;
      const dealer = selectedRow.dealer;
      const subKpiId = selectedRow.subKpiId;
      const subKpiName = selectedRow.subKpi || selectedRow.subKpiName;

      console.log("🔍 Looking for quarter scores:", { year, dealerId, dealer, subKpiId, subKpiName });

      // Find matching records for Q1, Q2, Q3 (use dealerId for accurate matching)
      const q1Record = tableData.find(row => 
        (row.year === year || String(row.scorecardYear) === String(year)) &&
        (row.dealerId === dealerId || row.dealer === dealer) &&
        (row.subKpiId === subKpiId || row.subKpi === subKpiName || row.subKpiName === subKpiName) &&
        row.quarter === "Q1"
      );

      const q2Record = tableData.find(row => 
        (row.year === year || String(row.scorecardYear) === String(year)) &&
        (row.dealerId === dealerId || row.dealer === dealer) &&
        (row.subKpiId === subKpiId || row.subKpi === subKpiName || row.subKpiName === subKpiName) &&
        row.quarter === "Q2"
      );

      const q3Record = tableData.find(row => 
        (row.year === year || String(row.scorecardYear) === String(year)) &&
        (row.dealerId === dealerId || row.dealer === dealer) &&
        (row.subKpiId === subKpiId || row.subKpi === subKpiName || row.subKpiName === subKpiName) &&
        row.quarter === "Q3"
      );

      console.log("📊 Quarter records found:", { 
        q1: q1Record?.finalScore, 
        q2: q2Record?.finalScore, 
        q3: q3Record?.finalScore 
      });

      setQuarterScores([
        { quarter: "Q1", score: q1Record?.finalScore || "" },
        { quarter: "Q2", score: q2Record?.finalScore || "" },
        { quarter: "Q3", score: q3Record?.finalScore || "" },
      ]);
    }
  }, [selectedRow, tableData]);

  // ⭐ Auto-calculate final score when reviewer score changes
  // Now uses formula from database if available
  useEffect(() => {
    if (scoringData.reviewerScore && scoringData.maxScore && selectedRow) {
      const calculatedScore = calculateFinalScore(
        scoringData.reviewerScore,
        scoringData.maxScore,
        selectedRow.measurement,  // Pass measurement type: "Absolute" or "Percentage"
        selectedRow.formula       // ⭐ Pass formula from database (null will use default)
      );
      
      if (calculatedScore) {
        setScoringData((prev) => ({
          ...prev,
          finalScore: calculatedScore,
        }));
      }
    }
  }, [scoringData.reviewerScore, scoringData.maxScore, selectedRow?.measurement, selectedRow?.formula]);

  const handleFilterChange = (name, value) => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const handleRowSelect = (row) => {
    setSelectedRow(row);
    window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
  };

  // ⭐ Save handler with API integration
  const handleSave = async () => {
    if (!selectedRow) {
      alert("Please select a row first");
      return;
    }

    setSaveLoading(true);

    try {
      // ⭐ Calculate final score with formula from database
      const calculatedFinalScore = calculateFinalScore(
        scoringData.reviewerScore,
        scoringData.maxScore,
        selectedRow.measurement,
        selectedRow.formula  // ⭐ Pass formula from database
      );

      // ✅ FIX: Use id (scorecard_scoreview primary key) for API update
      const updateData = {
        id: selectedRow.id,  // This is the scorecard_scoreview primary key
        reviewer_score: scoringData.reviewerScore ? parseFloat(scoringData.reviewerScore) : null,
        isExcluded: isExcluded,
        remarks: remarks,
        final_score: calculatedFinalScore ? parseFloat(calculatedFinalScore) : null,
        isScored: !!scoringData.reviewerScore,
      };

      console.log("📤 Saving score view:", updateData);

      await updateScorecardScoreView(updateData);

      // Update local state using rowId for accurate matching
      setTableData((prevData) =>
        prevData.map((row) =>
          row.rowId === selectedRow.rowId
            ? {
                ...row,
                excluded: isExcluded,
                isExcluded: isExcluded,
                remarks: remarks,
                reviewerScore: scoringData.reviewerScore,
                finalScore: calculatedFinalScore,
                scored: scoringData.reviewerScore ? "Yes" : row.scored,
                isScored: !!scoringData.reviewerScore,
              }
            : row
        )
      );

      // Update selected row to reflect changes immediately
      setSelectedRow((prev) => ({
        ...prev,
        excluded: isExcluded,
        isExcluded: isExcluded,
        remarks: remarks,
        reviewerScore: scoringData.reviewerScore,
        finalScore: calculatedFinalScore,
        scored: scoringData.reviewerScore ? "Yes" : prev.scored,
        isScored: !!scoringData.reviewerScore,
      }));

      // Update scoring data state
      setScoringData((prev) => ({
        ...prev,
        finalScore: calculatedFinalScore,
      }));

      console.log("✅ Data saved successfully");
    } catch (err) {
      console.error("❌ Error saving data:", err);
      alert(err.message || "Failed to save data");
    } finally {
      setSaveLoading(false);
    }
  };

  // ⭐ Handle exclusion toggle with API
  const handleExclusionToggle = async (row, newExcludedValue) => {
    try {
      // ✅ FIX: Use id (scorecard_scoreview primary key) for API update
      await updateScorecardScoreView({
        id: row.id,  // This is the scorecard_scoreview primary key
        isExcluded: newExcludedValue,
      });

      // Update local state using rowId for accurate matching
      setTableData((prevData) =>
        prevData.map((r) =>
          r.rowId === row.rowId ? { ...r, excluded: newExcludedValue, isExcluded: newExcludedValue } : r
        )
      );

      // Update selected row if it's the same
      if (selectedRow?.rowId === row.rowId) {
        setIsExcluded(newExcludedValue);
        setSelectedRow((prev) => ({ ...prev, excluded: newExcludedValue, isExcluded: newExcludedValue }));
      }

      console.log("✅ Exclusion toggled successfully");
    } catch (err) {
      console.error("❌ Error toggling exclusion:", err);
      alert(err.message || "Failed to toggle exclusion");
    }
  };

  // ⭐ Handle BULK exclusion toggle - Exclude/Include ALL filtered items at once
  const handleBulkExclusionToggle = async (excludeAll) => {
    if (filteredData.length === 0) {
      alert("No data to update");
      return;
    }

    setBulkExcludeLoading(true);

    try {
      // ✅ FIX: Group by scorecard_id, collecting scorecard_scoreview ids
      const groupedByScorecard = {};
      filteredData.forEach(row => {
        const scId = row.scorecardId;
        if (scId && !isNaN(scId) && scId > 0) {
          if (!groupedByScorecard[scId]) {
            groupedByScorecard[scId] = [];
          }
          // Use id (scorecard_scoreview primary key) for bulk exclusion
          groupedByScorecard[scId].push(row.id);
        }
      });

      const scorecardIds = Object.keys(groupedByScorecard);
      
      if (scorecardIds.length === 0) {
        throw new Error("No valid scorecard IDs found");
      }
      
      console.log(`📤 Bulk ${excludeAll ? 'excluding' : 'including'} items from ${scorecardIds.length} scorecards`);

      // Process each scorecard one by one
      for (const scorecardId of scorecardIds) {
        const idsForThisScorecard = groupedByScorecard[scorecardId];
        
        // If excluding, send the IDs to exclude
        // If including (un-excluding), send empty array to clear all exclusions
        await bulkToggleScorecardScoreViewExclusion(
          parseInt(scorecardId),
          excludeAll ? idsForThisScorecard : [],
          excludeAll
        );
      }

      // Update local state for all filtered items using rowId
      const allRowIds = filteredData.map(row => row.rowId);
      setTableData((prevData) =>
        prevData.map((row) =>
          allRowIds.includes(row.rowId) 
            ? { ...row, excluded: excludeAll, isExcluded: excludeAll } 
            : row
        )
      );

      // Update selected row if it's in the filtered list
      if (selectedRow && allRowIds.includes(selectedRow.rowId)) {
        setIsExcluded(excludeAll);
        setSelectedRow((prev) => ({ ...prev, excluded: excludeAll, isExcluded: excludeAll }));
      }

      console.log(`✅ Bulk exclusion updated: ${filteredData.length} items ${excludeAll ? 'excluded' : 'included'}`);
    } catch (err) {
      console.error("❌ Error bulk toggling exclusion:", err);
      alert(err.message || "Failed to update exclusion for all items");
    } finally {
      setBulkExcludeLoading(false);
    }
  };

  // Filter data
  const filteredData = tableData.filter((row) => {
    return (
      (filters.year.length === 0 || filters.year.includes(row.year)) &&
      (filters.quarter.length === 0 || filters.quarter.includes(row.quarter)) &&
      (filters.dealer.length === 0 || filters.dealer.includes(row.dealer)) &&
      (filters.strategicObjective.length === 0 || filters.strategicObjective.includes(row.strategicObjective)) &&
      (filters.kpiNo.length === 0 || filters.kpiNo.includes(row.kpiNo)) &&
      (filters.reviewer.length === 0 || filters.reviewer.includes(row.reviewer)) &&
      (filters.scored.length === 0 || filters.scored.includes(row.scored))
    );
  });

  // Check if all filtered items are excluded (for header checkbox state)
  const allFilteredExcluded = filteredData.length > 0 && filteredData.every(row => row.excluded || row.isExcluded);
  const someFilteredExcluded = filteredData.some(row => row.excluded || row.isExcluded);
const sortedData = useMemo(() => {
  if (!sortKey || !sortOrder) return filteredData;

  return [...filteredData].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [filteredData, sortKey, sortOrder]);
const sortedDatadoc = useMemo(() => {
  if (!sortKey || !sortOrder) return documents;

  return [...documents].sort((a, b) => {
    const valA = a[sortKey];
    const valB = b[sortKey];

    // numeric comparison if both are numbers
    if (!isNaN(valA) && !isNaN(valB)) {
      return sortOrder === "asc" ? valA - valB : valB - valA;
    }

    // fallback to string comparison
    const strA = valA ? valA.toString().toLowerCase() : "";
    const strB = valB ? valB.toString().toLowerCase() : "";

    if (strA < strB) return sortOrder === "asc" ? -1 : 1;
    if (strA > strB) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });
}, [documents, sortKey, sortOrder]);



  // Document upload handlers
  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleFileInputChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  // ⭐ Handle file upload with API
  const handleFiles = async (files) => {
    if (!selectedRow?.scorecardId) {
      alert("Please select a row first");
      return;
    }

    const fileArray = Array.from(files);
    
    setUploadLoading(true);
    setShowUploadModal(false);

    try {
      // Get current user ID from localStorage
      const userStr = localStorage.getItem("user");
      const user = userStr ? JSON.parse(userStr) : null;
      const uploadedBy = user?.id || null;

      for (const file of fileArray) {
        await addScorecardScoreViewDoc({
          scorecard_id: selectedRow.scorecardId,
          uploaded_by: uploadedBy,
          file: file,
        });
      }

      // Refresh documents list
      await fetchDocuments(selectedRow.scorecardId);
      
      console.log("✅ Documents uploaded successfully");
    } catch (err) {
      console.error("❌ Error uploading documents:", err);
      alert(err.message || "Failed to upload documents");
    } finally {
      setUploadLoading(false);
    }
  };

  // ⭐ Handle document delete with API
  const handleDeleteDocument = (doc) => {
    setDocumentToDelete(doc);
    setIsDeleteModalOpen(true);
  };

  const confirmDeleteDocument = async () => {
    if (!documentToDelete) return;

    setDeleteLoading(true);
    try {
      await deleteScorecardScoreViewDoc(documentToDelete.id);
      
      // Remove from local state
      setDocuments((prev) => prev.filter((doc) => doc.id !== documentToDelete.id));
      
      console.log("✅ Document deleted successfully");
    } catch (err) {
      console.error("❌ Error deleting document:", err);
      alert(err.message || "Failed to delete document");
    } finally {
      setDeleteLoading(false);
      setIsDeleteModalOpen(false);
      setDocumentToDelete(null);
    }
  };

  const handleDownloadFile = (doc) => {
    if (doc.docUrl) {
      window.open(doc.docUrl, '_blank');
    }
  };

  const handleDownloadTemplate = () => {
    const csvContent = `File Name,Uploaded By,Date\nExample.xlsx,User,${new Date().toLocaleString()}\n`;
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "Template.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const truncateFileName = (fileName, maxLength = 20) => {
    if (!fileName || fileName.length <= maxLength) return fileName || "Unknown";
    const extension = fileName.split(".").pop();
    const nameWithoutExt = fileName.substring(0, fileName.lastIndexOf("."));
    const truncatedName = nameWithoutExt.substring(0, maxLength - extension.length - 4);
    return `${truncatedName}...${extension}`;
  };

  // Mobile Card Component
  const MobileCard = ({ row, isSelected }) => (
    <div
      onClick={() => handleRowSelect(row)}
      className={`bg-white border p-3 mb-3 shadow-sm cursor-pointer transition ${
        isSelected ? "border-darkblue1 bg-lightBlue/10 ring-2 ring-darkblue1" : "border-gray-200 hover:border-gray-400"
      }`}
    >
      <div className="flex justify-between items-start mb-2">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold text-darkblue1">KPI {row.kpiNo}</span>
            <span
              className={`text-xs font-medium px-2 py-0.5 ${
                row.scored === "Yes" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
              }`}
            >
              {row.scored}
            </span>
          </div>
          <p className="text-xs font-medium text-black">{row.strategicObjective}</p>
          <p className="text-xs text-gray-600">{row.kpi}</p>
        </div>
      </div>

      <div className="space-y-1.5 border-t pt-2">
        <div className="flex justify-between">
          <span className="text-xs text-gray-500">Year/Quarter:</span>
          <span className="text-xs text-black">{row.year} / {row.quarter}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-xs text-gray-500">Dealer:</span>
          <span className="text-xs text-black">{row.dealer || "—"}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-xs text-gray-500">Sub KPI:</span>
          <span className="text-xs text-black text-right">{row.subKpi}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-xs text-gray-500">Max Score:</span>
          <span className="text-xs text-black">{row.maxScore}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-xs text-gray-500">Reviewer:</span>
          <span className="text-xs text-black">{row.reviewer}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Excluded:</span>
          <input
            type="checkbox"
            checked={row.excluded || row.isExcluded}
            onChange={(e) => {
              e.stopPropagation();
              handleExclusionToggle(row, e.target.checked);
            }}
            className="w-4 h-4 cursor-pointer accent-darkblue1"
          />
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-Frostwhite min-h-screen flex flex-col">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <SubNavbar3 />

      <div className={`transition-all duration-300 ${menuOpen ? "lg:ml-60" : ""} flex justify-center flex-1`}>
        <div className="w-full mt-[4.5rem] lg:mt-[6rem] p-2 lg:px-4">
          {/* Header */}
          <div className="flex items-center gap-2 mb-3">
            <h2 className="text-xl font-semibold text-darkblue1 text-center w-full">
              Scoring
            </h2>
          </div>

          {/* Loading State */}
          {loading && (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-darkblue1"></div>
              <span className="ml-3 text-gray-600">Loading score views...</span>
            </div>
          )}

          {/* Error State */}
          {error && !loading && (
            <div className="bg-red-50 border border-red-200 p-4 mb-4">
              <p className="text-red-600 text-sm">{error}</p>
              <button
                onClick={fetchAllScoreViews}
                className="mt-2 text-xs text-blue-600 hover:underline"
              >
                Try Again
              </button>
            </div>
          )}

          {/* Main Content */}
          {!loading && !error && (
            <>
              {/* Filters */}
              <div className="justify-between items-center gap-2 flex-wrap mb-2">
                <div className="flex flex-col lg:flex-row gap-2 w-full lg:w-auto items-stretch lg:items-center">
                  <Filter
                    name="year"
                    value={filters.year}
                    options={filterOptions.year}
                    onChange={handleFilterChange}
                    placeholder="Year"
                    customWidth="w-full lg:w-[100px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownBorderColor="border-black/60"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    closedBgColor="bg-white"
                    textColor="text-black"
                  />

                  <Filter
                    name="quarter"
                    value={filters.quarter}
                    options={filterOptions.quarter}
                    onChange={handleFilterChange}
                    placeholder="Quarter"
                    customWidth="w-full lg:w-[100px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    closedBgColor="bg-white"
                    textColor="text-black"
                  />

                  <Filter
                    name="dealer"
                    value={filters.dealer}
                    options={filterOptions.dealer}
                    onChange={handleFilterChange}
                    placeholder="Dealer"
                    customWidth="w-full lg:w-[150px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    closedBgColor="bg-white"
                    textColor="text-black"
                  />

                  <Filter
                    name="strategicObjective"
                    value={filters.strategicObjective}
                    options={filterOptions.strategicObjective}
                    onChange={handleFilterChange}
                    placeholder="Strategic Objective"
                    customWidth="w-full lg:w-[200px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    closedBgColor="bg-white"
                    textColor="text-black"
                  />

                  <Filter
                    name="kpiNo"
                    value={filters.kpiNo}
                    options={filterOptions.kpiNo}
                    onChange={handleFilterChange}
                    placeholder="KPI No"
                    customWidth="w-full lg:w-[100px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    closedBgColor="bg-white"
                    textColor="text-black"
                  />

                  <Filter
                    name="reviewer"
                    value={filters.reviewer}
                    options={filterOptions.reviewer}
                    onChange={handleFilterChange}
                    placeholder="Reviewer"
                    customWidth="w-full lg:w-[120px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    closedBgColor="bg-white"
                    textColor="text-black"
                  />

                  <Filter
                    name="scored"
                    value={filters.scored}
                    options={scoredOptions}
                    onChange={handleFilterChange}
                    placeholder="Scored"
                    customWidth="w-full lg:w-[100px]"
                    placeholderColor="text-black"
                    buttonBorderColor="border-black/60"
                    dropdownBorderColor="border-black/60"
                    dropdownBgColor="bg-white"
                    dropdownTextColor="text-black"
                    dropdownHoverColor="hover:bg-lightBlue/50"
                    closedBgColor="bg-white"
                    textColor="text-black"
                  />
                </div>
              </div>

              {/* Table or Mobile Cards */}
              {isMobileView ? (
                <div className="space-y-3 mb-4">
                  {filteredData.length > 0 ? (
                    filteredData.map((row) => (
                      <MobileCard
                        key={row.rowId}
                        row={row}
                        isSelected={selectedRow?.rowId === row.rowId}
                      />
                    ))
                  ) : (
                    <div className="bg-white border p-6 text-center text-gray-500">No data found</div>
                  )}
                </div>
              ) : (
                <div className="bg-white shadow-md border border-Dustyblue mb-4 overflow-hidden">
                  <div
            ref={tableContainerRef}
            className="overflow-y-auto overflow-x-hidden bg-white shadow-md border border-Dustyblue"
            style={{ scrollbarWidth: "none", msOverflowStyle: "none", maxHeight: "calc(100vh - 14rem)" }}
              // onScroll={handleTableScroll}
          >
            <table className="w-full text-xs border-collapse table-fixed">
              <thead className="bg-Dustyblue text-white text-xs sticky top-0 z-10">
                        <tr>
  {/* Year */}
  <th
    className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[6%] cursor-pointer select-none"
    onClick={() => handleSort("year")}
  >
    <div className="flex items-center gap-1">
      Year
      {sortKey !== "year" && (
      <ChevronsUpDown className="w-3 h-3 text-white" />
    )}

      {sortKey === "year" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "year" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Quarter */}
  <th
    className="py-1.5 px-2 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[7%] cursor-pointer select-none"
    onClick={() => handleSort("quarter")}
  >
    <div className="flex items-center justify-center gap-1">
      Quarter
      {sortKey === "quarter" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "quarter" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Dealer */}
  <th
    className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
    onClick={() => handleSort("dealer")}
  >
    <div className="flex items-center gap-1">
      Dealer
      {sortKey === "dealer" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "dealer" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* KPI No */}
  <th
    className="py-1.5 px-2 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[6%] cursor-pointer select-none"
    onClick={() => handleSort("kpiNo")}
  >
    <div className="flex items-center justify-center gap-1">
      KPI No
      {sortKey === "kpiNo" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "kpiNo" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Strategic Objective */}
  <th
    className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
    onClick={() => handleSort("strategicObjective")}
  >
    <div className="flex items-center gap-1">
      Strategic Objective
      {sortKey === "strategicObjective" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "strategicObjective" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* KPI */}
  <th
    className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
    onClick={() => handleSort("kpi")}
  >
    <div className="flex items-center gap-1">
      KPI
      {sortKey === "kpi" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "kpi" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Sub KPI */}
  <th
    className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[10%] cursor-pointer select-none"
    onClick={() => handleSort("subKpi")}
  >
    <div className="flex items-center gap-1">
      Sub KPI
      {sortKey === "subKpi" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "subKpi" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Max Score */}
  <th
    className="py-1.5 px-2 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%] cursor-pointer select-none"
    onClick={() => handleSort("maxScore")}
  >
    <div className="flex items-center justify-center gap-1">
      Max Score
      {sortKey === "maxScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "maxScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Threshold */}
  <th
    className="py-1.5 px-2 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%] cursor-pointer select-none"
    onClick={() => handleSort("threshold")}
  >
    <div className="flex items-center justify-center gap-1">
      Threshold
      {sortKey === "threshold" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "threshold" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Reviewer Score */}
  <th
    className="py-1.5 px-2 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%] cursor-pointer select-none"
    onClick={() => handleSort("reviewerScore")}
  >
    <div className="flex items-center justify-center gap-1">
      Reviewer Score
      {sortKey === "reviewerScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "reviewerScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Final Score */}
  <th
    className="py-1.5 px-2 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[7%] cursor-pointer select-none"
    onClick={() => handleSort("finalScore")}
  >
    <div className="flex items-center justify-center gap-1">
      Final Score
      {sortKey === "finalScore" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "finalScore" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Reviewer */}
  <th
    className="py-1.5 px-2 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%] cursor-pointer select-none"
    onClick={() => handleSort("reviewer")}
  >
    <div className="flex items-center gap-1">
      Reviewer
      {sortKey === "reviewer" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "reviewer" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>

  {/* Scored */}
  <th
    className="py-1.5 px-2 text-center text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium w-[8%] cursor-pointer select-none"
    onClick={() => handleSort("scored")}
  >
    <div className="flex items-center justify-center gap-1">
      Scored
      {sortKey === "scored" && sortOrder === "asc" && <ChevronUp className="w-3 h-3 text-white" />}
      {sortKey === "scored" && sortOrder === "desc" && <ChevronDown className="w-3 h-3 text-white" />}
    </div>
  </th>
                          <th className="px-2 py-1.5 text-center font-medium border border-white/20 border-t-0 border-l-0 border-r-0 w-[8%]">
                            <div className="flex items-center justify-center gap-1">
                              <span>Excluded</span>
                              <input
                                type="checkbox"
                                checked={allFilteredExcluded}
                                ref={(el) => {
                                  if (el) {
                                    el.indeterminate = someFilteredExcluded && !allFilteredExcluded;
                                  }
                                }}
                                onChange={(e) => handleBulkExclusionToggle(e.target.checked)}
                                disabled={bulkExcludeLoading || filteredData.length === 0}
                                className="w-3 h-3 cursor-pointer accent-white ml-1"
                                title={allFilteredExcluded ? "Uncheck all" : "Check all to exclude"}
                              />
                            </div>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {sortedData.length > 0 ? (
                          sortedData.map((row) => (
                            <tr
                              key={row.rowId}
                              onClick={() => handleRowSelect(row)}
                              className={`cursor-pointer transition hover:bg-lightBlue/30 ${
                                selectedRow?.rowId === row.rowId
                                  ? "bg-lightBlue/20 ring-2 ring-inset ring-darkblue1 text-left"
                                  : ""
                              }`}
                            >
                              <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0">{row.year}</td>
                              <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-center">{row.quarter}</td>
<td className="px-2 py-1 text-xs border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.dealer?.length > 18)
          setHoveredCell(row.id + "-dealer");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.dealer || "—"}
    </p>

    {hoveredCell === row.id + "-dealer" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {row.dealer}
      </span>
    )}
  </div>
</td>                              <td className="px-4 py-1 border border-grey2 border-t-0 border-l-0 text-center">{row.kpiNo}</td>
<td className="px-2 py-1 text-xs border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.strategicObjective?.length > 18)
          setHoveredCell(row.id + "-strategicObjective");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.strategicObjective || "—"}
    </p>

    {hoveredCell === row.id + "-strategicObjective" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {row.strategicObjective}
      </span>
    )}
  </div>
</td>             
{/* KPI */}
<td className="px-2 py-1 text-xs border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.kpi?.length > 18)
          setHoveredCell(row.id + "-kpi");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.kpi || "—"}
    </p>

    {hoveredCell === row.id + "-kpi" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {row.kpi}
      </span>
    )}
  </div>
</td>

{/* Sub KPI */}
<td className="px-2 py-1 text-xs border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.subKpi?.length > 18)
          setHoveredCell(row.id + "-subKpi");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.subKpi || "—"}
    </p>

    {hoveredCell === row.id + "-subKpi" && (
      <span className="absolute left-1/2 top-full -mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {row.subKpi}
      </span>
    )}
  </div>
</td>                              <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-center">{row.maxScore}</td>
                              <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-center">{row.threshold || row.minScore}</td>
                              <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-center">{row.reviewerScore || "—"}</td>
                              <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-center">{row.finalScore || "—"}</td>
<td className="px-2 py-1 text-xs border border-grey2 border-t-0 border-l-0">
  <div className="relative">
    <p
      className="truncate max-w-[12rem] cursor-pointer"
      onMouseEnter={() => {
        if (row.reviewer?.length > 8)
          setHoveredCell(row.id + "-reviewer");
      }}
      onMouseLeave={() => setHoveredCell(null)}
    >
      {row.reviewer || "—"}
    </p>

    {hoveredCell === row.id + "-reviewer" && (
      <span className="absolute left-1/2 top-full mt-1 bg-SteelBlue1 text-white text-[10px] px-2 py-0 whitespace-nowrap transform -translate-x-1/2 z-10">
        {row.reviewer}
      </span>
    )}
  </div>
</td>               
               <td className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-center">
                                <span className={row.scored === "Yes" ? "text-green-600 font-semibold" : "text-red-600"}>
                                  {row.scored}
                                </span>
                              </td>
                              <td
                                className="px-2 py-1 border border-grey2 border-t-0 border-l-0 text-center"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <input
                                  type="checkbox"
                                  checked={row.excluded || row.isExcluded}
                                  onChange={(e) => {
                                    e.stopPropagation();
                                    handleExclusionToggle(row, e.target.checked);
                                  }}
                                  className="w-3 h-3 cursor-pointer accent-darkblue1"
                                />
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan="14" className="text-center py-8 text-gray-500">
                              No data found
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Details Section */}
              {selectedRow && (
                <div className="bg-white border border-gray-300 p-4 shadow-lg">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                    {/* Scoring Section */}
                    <div className="flex flex-col">
                      <div className="mb-2">
                        <span className="text-xs font-semibold text-gray-700">Strategic Objective: </span>
                        <span className="text-xs text-black">{selectedRow.strategicObjective}</span>
                      </div>

                      <div className="border border-gray-300 p-3 bg-gray-50 flex-1">
                        {/* Exclude Checkbox */}
                        <label className="flex items-center gap-2 text-xs font-medium text-gray-700 mb-3 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isExcluded}
                            onChange={(e) => setIsExcluded(e.target.checked)}
                            className="w-3 h-3 accent-darkblue1 cursor-pointer"
                          />
                          Exclude from scoring
                        </label>

                        <div className="border border-gray-400 overflow-hidden">
                          <table className="w-full text-xs">
                            <thead className="bg-Dustyblue text-white">
                              <tr>
                                <th className="px-2 py-2 text-left font-normal border-r border-white">Scoring Criteria</th>
                                <th className="px-2 py-2 text-left font-normal border-r border-white">Scoring</th>
                                <th className="px-2 py-2 text-left font-normal">Quarter Score</th>
                              </tr>
                            </thead>
                            <tbody className="bg-white">
                              <tr className="border-b border-gray-300">
                                <td 
                                  rowSpan="4" 
                                  className="px-2 py-3 border-r border-gray-300 font-bold text-center bg-gray-50 text-xs align-middle"
                                  dangerouslySetInnerHTML={{ __html: selectedRow.scoringCriteria || "—" }}
                                />
                                <td className="px-2 py-1.5 border-r border-gray-300">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-600">Max Score:</span>
                                    <span className="font-bold text-darkblue1">{scoringData.maxScore}</span>
                                  </div>
                                </td>
                                <td className="px-2 py-1.5 bg-gray-50">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-600">Q1:</span>
                                    <span className="font-bold">{quarterScores[0].score || "—"}</span>
                                  </div>
                                </td>
                              </tr>
                              <tr className="border-b border-gray-300">
                                <td className="px-2 py-1.5 border-r border-gray-300">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-600">Threshold:</span>
                                    <span className="font-bold text-darkblue1">{scoringData.threshold}</span>
                                  </div>
                                </td>
                                <td className="px-2 py-1.5 bg-gray-50">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-600">Q2:</span>
                                    <span className="font-bold">{quarterScores[1].score || "—"}</span>
                                  </div>
                                </td>
                              </tr>
                              <tr className="border-b border-gray-300 bg-green-50">
                                <td className="px-2 py-1.5 border-r border-gray-300">
                                  <div className="flex flex-col gap-1">
                                    <span className="text-gray-700 font-medium">Reviewer Score:</span>
                                    <div className="flex items-center gap-1">
                                      <input
                                        type="number"
                                        value={scoringData.reviewerScore}
                                        onChange={(e) =>
                                          setScoringData((prev) => ({ ...prev, reviewerScore: e.target.value }))
                                        }
                                        placeholder="Enter score"
                                        className="text-xs border border-green-500 px-2 py-1 w-full"
                                      />
                                      <span className="text-gray-500">
                                        {selectedRow.measurement === "Percentage" ? "%" : ""}
                                      </span>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-2 py-1.5 bg-gray-50">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-600">Q3:</span>
                                    <span className="font-bold">{quarterScores[2].score || "—"}</span>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td className="px-2 py-1.5 border-r border-gray-300 bg-blue-50">
                                  <div className="flex items-center gap-1">
                                    <span className="text-gray-700 font-medium">Final Score:</span>
                                    <span className="font-bold text-darkblue1">{scoringData.finalScore || "—"}</span>
                                  </div>
                                </td>
                                <td className="px-2 py-1.5"></td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>

                    {/* Remarks Section */}
                    <div className="flex flex-col">
                    <div className="mb-2">
  <span className="text-xs font-semibold text-gray-700">
    {selectedRow.kpiNo}
    <sup>
      {selectedRow.kpiNo % 100 >= 11 && selectedRow.kpiNo % 100 <= 13
        ? "th"
        : selectedRow.kpiNo % 10 === 1
        ? "st"
        : selectedRow.kpiNo % 10 === 2
        ? "nd"
        : selectedRow.kpiNo % 10 === 3
        ? "rd"
        : "th"}
    </sup>{" "}
    KPI:
  </span>
  <span className="text-xs text-black">
    {selectedRow.kpi}
  </span>
</div>

                      <div className="border border-gray-300 p-3 bg-gray-50 flex flex-col flex-1">
                        <h3 className="text-xs font-semibold text-darkblue1 mb-2">Remarks</h3>
                        <textarea
                          value={remarks}
                          onChange={(e) => setRemarks(e.target.value)}
                          placeholder="Enter your remarks..."
                          className="border border-gray-300 text-xs px-3 py-2 resize-none w-full flex-1 focus:ring-2 focus:ring-darkblue1 bg-white"
                          style={{ minHeight: '150px', maxHeight: '300px' }}
                        ></textarea>
                      </div>
                    </div>

                    {/* Upload Documents Section */}
                    <div className="flex flex-col">
                      <div className="mb-2">
                        <span className="text-xs font-semibold text-gray-700">Sub KPI: </span>
                        <span className="text-xs text-black">{selectedRow.subKpi}</span>
                      </div>

                      <div className="border border-gray-300 p-3 bg-gray-50 flex-1">
                        <div className="flex justify-between items-center mb-3">
                          <h3 className="text-xs font-semibold text-darkblue1">Upload Supporting Document</h3>
                          <div className="flex gap-2">
                            <button
                              onClick={handleDownloadTemplate}
                              className="text-xs bg-white border border-darkblue1 text-darkblue1 px-3 py-1.5 hover:bg-darkblue1 hover:text-white transition"
                            >
                              Template
                            </button>
                            <button
                              onClick={() => setShowUploadModal(true)}
                              disabled={uploadLoading || !selectedRow?.scorecardId}
                              className="text-xs bg-darkblue1 text-white px-3 py-1.5 hover:bg-darkblue2 transition flex items-center gap-1 disabled:opacity-50"
                            >
                              <span>+</span>
                              <span>{uploadLoading ? "Uploading..." : "Add"}</span>
                            </button>
                          </div>
                        </div>

                        <div className="max-h-56 overflow-y-auto border border-gray-300 bg-white">
                          {sortedDatadoc.length > 0 ? (
                                       <table className="w-full text-xs border-collapse table-fixed">
              <thead className="bg-Dustyblue text-white text-xs sticky top-0 z-10">
                                <tr>
                                  <th
                                     className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none"
                                     onClick={() => handleSort("fileName")}
                                   >
                                     <div className="flex items-center gap-1">
                                       File Name
                                       {sortKey !== "fileName" && (
                                       <ChevronsUpDown className="w-3 h-3 text-white" />
                                     )}
                                 
                                       {sortKey === "fileName" && sortOrder === "asc" && (
                                         <ChevronUp className="w-3 h-3 text-white" />
                                       )}
                                       {sortKey === "fileName" && sortOrder === "desc" && (
                                         <ChevronDown className="w-3 h-3 text-white" />
                                       )}
                                     </div>
                                   </th>
                                 
                                   {/* Uploaded By */}
                                   <th
                                     className="py-1.5 px-4 text-left text-xs border border-grey2 border-t-0 border-l-0 border-b-0 font-medium cursor-pointer select-none"
                                     onClick={() => handleSort("uploadedBy")}
                                   >
                                     <div className="flex items-center gap-1">
                                       Uploaded by
                                       {sortKey === "uploadedBy" && sortOrder === "asc" && (
                                         <ChevronUp className="w-3 h-3 text-white" />
                                       )}
                                       {sortKey === "uploadedBy" && sortOrder === "desc" && (
                                         <ChevronDown className="w-3 h-3 text-white" />
                                       )}
                                     </div>
                                   </th>
                                  <th className="px-4 py-2 text-center font-semibold border-b w-16">Action</th>
                                </tr>
                              </thead>
                              <tbody>
                                {sortedDatadoc.map((doc) => (
                                  <tr key={doc.id} className="hover:bg-gray-50 border-b last:border-b-0">
                                    <td className="px-3 py-2.5">
                                      <button
                                        onClick={() => handleDownloadFile(doc)}
                                        className="font-semibold text-darkblue1 underline cursor-pointer text-left"
                                        title={doc.name}
                                      >
                                        {truncateFileName(doc.name)}
                                      </button>
                                    </td>
                                    <td className="px-3 py-2.5">
                                      <div className="font-medium text-black">{doc.uploadedByName}</div>
                                      <div className="text-xs text-gray-500">{doc.date}</div>
                                    </td>
                                    <td className="px-3 py-2.5 text-center">
                                      <button
                                        onClick={() => handleDeleteDocument(doc)}
                                        className="text-red-500 hover:text-red-700 p-1.5 hover:bg-red-50 transition"
                                      >
                                       <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32" fill="none">
<g clip-path="url(#clip0_6398_313)">
<path d="M10 23C10 24.1 10.9 25 12 25H20C21.1 25 22 24.1 22 23V11H10V23ZM23 8H19.5L18.5 7H13.5L12.5 8H9V10H23V8Z" fill="#BF2012"/>
</g>
<defs>
<clipPath id="clip0_6398_313">
<rect width="24" height="24" fill="white" transform="translate(4 4)"/>
</clipPath>
</defs>
</svg>

                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          ) : (
                            <div className="text-center text-gray-400 py-8">
                              <svg className="w-12 h-12 mx-auto mb-2 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                              </svg>
                              <p className="text-xs">No documents uploaded</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Save Button */}
                  <div className="flex justify-end mt-4 pt-3 border-t border-gray-300">
                    <button
                      onClick={handleSave}
                      disabled={saveLoading}
                      className="bg-darkblue1 text-white text-xs font-medium px-8 py-1.5 hover:bg-darkblue2 transition disabled:opacity-50"
                    >
                      {saveLoading ? "Saving..." : "Save"}
                    </button>
                  </div>
                </div>
              )}

              {/* Empty State */}
              {!selectedRow && filteredData.length > 0 && (
                <div className="bg-white border-2 border-dashed border-gray-300 p-8 text-center">
                  <svg className="w-16 h-16 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
                  </svg>
                  <p className="text-gray-500 text-sm">Select a row to view and edit scoring details</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white max-w-2xl w-full p-6 relative shadow-2xl">
            <button
              onClick={() => setShowUploadModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <h3 className="text-lg font-semibold text-darkblue1 mb-4">Upload Document</h3>

            <div
              className={`border-2 border-dashed p-12 text-center ${
                dragActive ? "border-darkblue1 bg-blue-50" : "border-gray-300"
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <Upload size={48} className="mx-auto mb-4 text-darkblue1" />
              <p className="text-base text-gray-700 mb-2">Choose a file or drag & drop it here</p>
              <p className="text-sm text-gray-500 mb-4">Supported formats: XLS, XLSX, PDF</p>
              <label className="cursor-pointer">
                <span className="inline-block bg-darkblue1 text-white text-sm px-6 py-2 hover:bg-darkblue2 transition">
                  Browse Files
                </span>
                <input
                  type="file"
                  accept=".xls,.xlsx,.pdf"
                  onChange={handleFileInputChange}
                  className="hidden"
                  multiple
                />
              </label>
            </div>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          if (!deleteLoading) {
            setIsDeleteModalOpen(false);
            setDocumentToDelete(null);
          }
        }}
        onConfirm={confirmDeleteDocument}
        loading={deleteLoading}
        title="Delete Document"
        message="Are you sure you want to delete this document?"
      />
    </div>
  );
};

export default Scoring;