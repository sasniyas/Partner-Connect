import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import StyledSelectField from "../../../Components/StyledSelectField";
import {
  getActiveDealers,
  getMarketAreas,
  createPdp,
  getTodayDateInput,
  getNextDateInput,
} from "../../../services/PDP/CrudPdp/crudPdp.service";
import { FaRegCalendarAlt } from "react-icons/fa";
import {useKeyboardNavigation} from "../../../util/useKeyboardNavigation"
const CreatePdp = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const formRef =useRef(null)
  // ⭐ Add loading state for save button
  const [isLoading, setIsLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    year: "",
    marketarea: "",
    chooseDealer: "",
    dealer: "",
    file: "",
    pdpstartdate: "",
    pdpenddate: "",
    physicalpdpstartdate: "",
    physicalpdpenddate: "",
  });

  const choosedealeroptions = ["All Dealers", "Dealers in MA", "Individual Dealer"].map(
    (name) => ({ label: name, value: name })
  );

  const [errors, setErrors] = useState({});
  const [dropdowns, setDropdowns] = useState({
    marketarea: false,
    dealer: false,
    chooseDealer: false,
    year: false,
  });
  const [marketAreaOptions, setMarketAreaOptions] = useState([]);
  const [marketAreasList, setMarketAreasList] = useState([]); // holds {id, marketarea}
  const [allDealers, setAllDealers] = useState([]);
  const [dealerOptions, setDealerOptions] = useState([]);

  // Refs
  const marketAreaRef = useRef(null);
  const dealerRef = useRef(null);
  const chooseDealerRef = useRef(null);
  const yearRef = useRef(null);

  const dateRefs = {
    pdpstartdate: useRef(null),
    pdpenddate: useRef(null),
    physicalpdpstartdate: useRef(null),
    physicalpdpenddate: useRef(null),
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      // Check each dropdown ref
      if (marketAreaRef.current && !marketAreaRef.current.contains(event.target)) {
        setDropdowns((prev) => ({ ...prev, marketarea: false }));
      }

      if (dealerRef.current && !dealerRef.current.contains(event.target)) {
        setDropdowns((prev) => ({ ...prev, dealer: false }));
      }

      if (chooseDealerRef.current && !chooseDealerRef.current.contains(event.target)) {
        setDropdowns((prev) => ({ ...prev, chooseDealer: false }));
      }

      if (yearRef.current && !yearRef.current.contains(event.target)) {
        setDropdowns((prev) => ({ ...prev, year: false }));
      }

      // Close datepickers
      Object.keys(dateRefs).forEach((key) => {
        if (dateRefs[key].current && !dateRefs[key].current.contains(event.target)) {
          setDropdowns((prev) => ({ ...prev, [key]: false }));
        }
      });
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // ⭐ Use helper function for today's date in Kolkata timezone
  const today = getTodayDateInput();

  // ⭐ Use helper function for next date
  const getNextDate = (date) => {
    return getNextDateInput(date);
  };
const maxDate = formData.year ? `${Number(formData.year) + 1}-12-31` : "";
  // Fetch Market Areas
  useEffect(() => {
    const fetchMarketAreas = async () => {
      try {
        const areas = await getMarketAreas(); // [{id, marketarea}]
        setMarketAreasList(areas);
        setMarketAreaOptions(areas.map((a) => a.marketarea));
      } catch (error) {
        console.error("Failed to load market areas:", error.message);
      }
    };
    fetchMarketAreas();
  }, []);
const minDate = formData.year ? `${formData.year}-01-01` : today;
  // Fetch all active dealers
  useEffect(() => {
    const fetchDealers = async () => {
      try {
        const activeDealers = await getActiveDealers();
        setAllDealers(activeDealers);
      } catch (error) {
        console.error(error.message);
      }
    };
    fetchDealers();
  }, []);

  // Update dealer options based on chooseDealer & marketarea
  useEffect(() => {
    const { chooseDealer, marketarea } = formData;
    if (!allDealers.length) return;

    let options = [];

    if (chooseDealer === "All Dealers") {
      options = allDealers.map((d) => ({
        label: d.dealerShortName,
        value: d.dealerShortName,
      }));
      setFormData((prev) => ({ ...prev, dealer: "All Dealers Selected" }));
    } else if (
      (chooseDealer === "Dealers in MA" || chooseDealer === "Individual Dealer") &&
      marketarea
    ) {
      const filtered = allDealers.filter((d) => d.marketName === marketarea);
      options = filtered.map((d) => ({
        label: d.dealerShortName,
        value: d.dealerShortName,
      }));

      if (chooseDealer === "Dealers in MA") {
        setFormData((prev) => ({
          ...prev,
          dealer: `All Dealers in ${marketarea} Selected`,
        }));
      } else {
        setFormData((prev) => ({ ...prev, dealer: "" }));
      }
    } else {
      options = [];
      setFormData((prev) => ({ ...prev, dealer: "" }));
    }

    setDealerOptions(options);
  }, [formData.chooseDealer, formData.marketarea, allDealers]);

  // ⭐ Updated handleSave with loading state
  const handleSave = async () => {
  const newErrors = {};
  const {
    year,
    marketarea,
    chooseDealer,
    dealer,
    pdpstartdate,
    pdpenddate,
    physicalpdpstartdate,
    physicalpdpenddate,
  } = formData;

  // ✅ BASIC VALIDATION
  if (!year) newErrors.year = "Please fill out this field";
  if (!marketarea) newErrors.marketarea = "Please fill out this field";
  if (!chooseDealer) newErrors.chooseDealer = "Please fill out this field";

  // ✅ DEALER VALIDATION
  if (chooseDealer === "Individual Dealer") {
    if (!dealer) {
      newErrors.dealer = "Please select a dealer";
    } else if (dealerOptions.length === 0) {
      newErrors.dealer =
        "No dealers available for the selected Market Area";
    }
  }

  if (chooseDealer === "Dealers in MA") {
    if (dealerOptions.length === 0) {
      newErrors.dealer =
        "No dealers available in the selected Market Area";
    }
  }

  if (!dealer) newErrors.dealer = "Please fill out this field";

  // ✅ REQUIRED DATE VALIDATION
  if (!pdpstartdate)
    newErrors.pdpstartdate = "PDP Start Date is required";

  if (!pdpenddate)
    newErrors.pdpenddate = "PDP End Date is required";

  if (!physicalpdpstartdate)
    newErrors.physicalpdpstartdate =
      "Physical PDP Start Date is required";

  if (!physicalpdpenddate)
    newErrors.physicalpdpenddate =
      "Physical PDP End Date is required";

  // 🔥 DATE LOGIC VALIDATION
  if (pdpstartdate && pdpenddate) {
    if (new Date(pdpenddate) <= new Date(pdpstartdate)) {
      newErrors.pdpenddate =
        "PDP End Date must be greater than PDP Start Date";
    }
  }

  if (physicalpdpstartdate && pdpstartdate) {
    if (new Date(physicalpdpstartdate) <= new Date(pdpstartdate)) {
      newErrors.physicalpdpstartdate =
        "Physical Start Date must be greater than PDP Start Date";
    }
  }

  if (physicalpdpstartdate && physicalpdpenddate) {
    if (
      new Date(physicalpdpenddate) <=
      new Date(physicalpdpstartdate)
    ) {
      newErrors.physicalpdpenddate =
        "Physical End Date must be greater than Physical Start Date";
    }
  }

  if (physicalpdpenddate && pdpenddate) {
    if (new Date(physicalpdpenddate) > new Date(pdpenddate)) {
      newErrors.physicalpdpenddate =
        "Physical End Date must be less than PDP End Date";
    }
  }

  // ❌ STOP IF ERRORS
  if (Object.keys(newErrors).length > 0) {
    setErrors(newErrors);
    console.log("Validation failed:", newErrors);
    return;
  }

  // ✅ FIND MARKET AREA ID
  const selectedMa = marketAreasList.find(
    (a) => a.marketarea === marketarea
  );

  const marketAreaId = selectedMa ? selectedMa.id : null;

  if (!marketAreaId) {
    setErrors((prev) => ({
      ...prev,
      marketarea: "Invalid Market Area",
    }));
    return;
  }

  // ✅ BUILD DEALER IDS
  let dealerIds = [];

  if (chooseDealer === "All Dealers") {
    dealerIds = allDealers.map((d) => d.id);
  } else if (chooseDealer === "Dealers in MA" && marketarea) {
    dealerIds = allDealers
      .filter((d) => d.marketName === marketarea)
      .map((d) => d.id);
  } else if (chooseDealer === "Individual Dealer") {
    const selected = allDealers.find(
      (d) => d.dealerShortName === dealer
    );
    if (selected?.id) dealerIds = [selected.id];
  }

  // ⭐ START LOADING
  setIsLoading(true);

  try {
    const payload = {
      year: Number(year),
      market_area: marketAreaId,
      choose_dealer: chooseDealer,
      pdp_start_date: pdpstartdate,
      pdp_end_date: pdpenddate,
      physical_pdp_start_date: physicalpdpstartdate || null,
      physical_pdp_end_date: physicalpdpenddate || null,
      dealers: dealerIds,
    };

    console.log("📤 Creating PDP with payload:", payload);

    const resp = await createPdp(payload);

    console.log("✅ PDP created:", resp);

    navigate("/pdp/view");
  } catch (err) {
    console.error("❌ Create PDP failed:", err.message);

    setErrors((prev) => ({
      ...prev,
      submit: err.message || "Failed to create PDP",
    }));
  } finally {
    setIsLoading(false);
  }
};
useEffect(() => {
  if (formData.year) {
    setFormData((prev) => ({
      ...prev,
      pdpstartdate: "",
      pdpenddate: "",
      physicalpdpstartdate: "",
      physicalpdpenddate: "",
    }));
  }
}, [formData.year]);
  // Handle outside click to close datepickers
  useEffect(() => {
    const handleClickOutside = (event) => {
      Object.keys(dateRefs).forEach((key) => {
        if (dateRefs[key].current && !dateRefs[key].current.contains(event.target)) {
          setDropdowns((prev) => ({ ...prev, [key]: false }));
        }
      });
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
useKeyboardNavigation({
  containerRef: formRef, // your popup div ref

  onSubmit: () => { 
   handleSave()
  },

  onCancel: () => {
    setFormData({
              year: "",
              startdate: "",
              enddate: "",
              marketarea: "",
              chooseDealer: "",
              dealer: "",
              file: "",
              pdpstartdate: "",
              pdpenddate: "",
              physicalpdpstartdate: "",
              physicalpdpenddate: "",
            });
            setErrors({});
            navigate("/pdp/view");
  },
});

  return (
    <div className="w-full max-w-7xl mx-auto">
      <h2 className="text-center text-xl font-semibold text-darkblue1 font-VolvoNovum">
        Create PDP
      </h2>

      {/* First Row: Year, Market Area, Choose Dealer, Dealer */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-4">
        {/* Year */}
        <div>
          <StyledSelectField
            label="Year"
            placeholder="Select Year"
            value={formData.year}
            setValue={(val) => setFormData({ ...formData, year: val })}
            options={Array.from({ length: 10 }, (_, i) => {
              const currentYear = new Date().getFullYear();
              return {
                label: String(currentYear + i),
                value: String(currentYear + i),
              };
            })}
            dropdownOpen={dropdowns.year}
            setDropdownOpen={(val) => setDropdowns({ ...dropdowns, year: val })}
            dropdownRef={yearRef}
            error={errors.year}
          />
        </div>

        {/* Market Area */}
        <div>
          <StyledSelectField
            label="Market Area"
            placeholder="Select Market Area"  
            value={formData.marketarea}
            setValue={(val) =>
              setFormData({ ...formData, marketarea: val, dealer: "" })
            }
            options={marketAreaOptions}
            dropdownOpen={dropdowns.marketarea}
            setDropdownOpen={(val) =>
              setDropdowns({ ...dropdowns, marketarea: val })
            }
            dropdownRef={marketAreaRef}
            error={errors.marketarea}
          />
        </div>

        {/* Choose Dealer */}
        <div>
          <StyledSelectField
            label="Choose Dealer"
            placeholder="Choose Dealer Option"
            value={formData.chooseDealer}
            setValue={(val) => setFormData({ ...formData, chooseDealer: val })}
            options={choosedealeroptions}
            dropdownOpen={dropdowns.chooseDealer}
            setDropdownOpen={(val) =>
              setDropdowns({ ...dropdowns, chooseDealer: val })
            }
            dropdownRef={chooseDealerRef}
            error={errors.chooseDealer}
          />
        </div>

        {/* Dealer */}
        <div>
          <StyledSelectField
            label="Dealer"
            placeholder="Select Dealer"
            value={formData.dealer}
            setValue={(val) => {
              if (formData.chooseDealer === "Individual Dealer") {
                setFormData({ ...formData, dealer: val });
              }
            }}
            options={dealerOptions}
            dropdownOpen={dropdowns.dealer}
            setDropdownOpen={(val) =>
              setDropdowns({ ...dropdowns, dealer: val })
            }
            dropdownRef={dealerRef}
            disabled={
              formData.chooseDealer === "All Dealers" ||
              formData.chooseDealer === "Dealers in MA"
            }
            error={errors.dealer}
          />
        </div>
      </div>

     {/* Second Row: Date Fields */}
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-2">
  {[
    { key: "pdpstartdate", label: "PDP Start Date" },
    { key: "pdpenddate", label: "PDP End Date" },
    { key: "physicalpdpstartdate", label: "Physical PDP Start Date" },
    { key: "physicalpdpenddate", label: "Physical PDP End Date" },
  ].map(({ key, label }) => {

 const openPicker = (key) => {
  const input = dateRefs[key].current;

  // ✅ Always open with today
  input.value = today;

  if (input?.showPicker) input.showPicker();
  else input?.focus();

  // ✅ Reset back after opening
  setTimeout(() => {
    input.value = formData[key] || "";
  }, 0);
};

return (
      <div key={key} className="relative w-full">

        {/* Label */}
        <label className="block text-sm font-medium text-black/70 mb-2">
          {label} <span className="text-red-500">*</span>
        </label>

        {/* Input Container */}
       <div
  onClick={() => openPicker(key)}
  className={`bg-white relative border w-full mt-1 text-xs px-3 py-1.5 outline-none focus:ring-1 focus:ring-black/30 transition-all
 cursor-pointer flex justify-between items-center 
  ${
    errors[key]
      ? "border-red1 focus:ring-red1"
      : "border-black/30 focus:ring-black/30"
  }`}
  tabIndex={0}
>
        <input
  ref={dateRefs[key]}
  type="date"
  value={formData[key]}
min={
  key === "pdpenddate"
    ? formData.pdpstartdate
      ? getNextDate(formData.pdpstartdate)
      : minDate

    : key === "physicalpdpstartdate"
    ? formData.pdpstartdate || minDate

    : key === "physicalpdpenddate"
    ? formData.physicalpdpstartdate
      ? getNextDate(formData.physicalpdpstartdate)
      : formData.pdpstartdate || minDate

    : minDate
}
max={maxDate}   // ✅ ADD THIS
  onChange={(e) => {
    setFormData((prev) => ({ ...prev, [key]: e.target.value }));
    if (errors[key]) {
      setErrors((prev) => ({ ...prev, [key]: "" }));
    }
  }}
  className={`w-full bg-transparent outline-none cursor-pointer 
  ${formData[key] ? "text-black" : "text-gray-400"}`}
/>

          {/* Calendar Icon */}
          <FaRegCalendarAlt
            className="text-black cursor-pointer"
            onClick={(e) => {
              e.stopPropagation(); 
  openPicker(key);   // ✅ FIX
            }}
          />
        </div>

        {/* Error */}
        {errors[key] && (
          <p className="text-xs text-red1 mt-1">{errors[key]}</p>
        )}
      </div>
    );
  })}
</div>

      {/* ⭐ API Error Message */}
      {errors.submit && (
        <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded">
          <p className="text-red-600 text-xs">{errors.submit}</p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex justify-end mt-2 space-x-4">
        {/* Cancel Button */}
        <button
          type="button"
          disabled={isLoading}
          onClick={() => {
            // Reset form fields
            setFormData({
              year: "",
              startdate: "",
              enddate: "",
              marketarea: "",
              chooseDealer: "",
              dealer: "",
              file: "",
              pdpstartdate: "",
              pdpenddate: "",
              physicalpdpstartdate: "",
              physicalpdpenddate: "",
            });
            setErrors({});
            navigate("/pdp/view");
          }}
          className={`flex items-center justify-center gap-2 border-2 border-mildBlue1 text-darkblue1 px-3 py-1.5 text-xs font-medium hover:bg-mildBlue1 hover:scale-105 ${
            isLoading ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <img
            src="https://yurtsv2.s3.ap-south-1.amazonaws.com/public/icons/Usermanagement/cancel.png"
            alt=""
            className="w-3 h-3"
          />
          Cancel
        </button>

        {/* ⭐ Save Button with Loading State */}
        <button
          onClick={handleSave}
          disabled={isLoading}
          className={`flex items-center justify-center gap-2 text-xs font-medium px-8 py-1.5 transition ${
            isLoading
              ? "bg-gray-400 text-white cursor-not-allowed"
              : "bg-darkblue1 text-white hover:bg-white hover:text-darkblue1 hover:border hover:border-darkblue1"
          }`}
        >
          {isLoading ? (
            <>
              {/* Spinner */}
              <svg
                className="animate-spin h-4 w-4 text-white"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                />
              </svg>
              Saving...
            </>
          ) : (
            "Save"
          )}
        </button>
      </div>
    </div>
  );
};

export default CreatePdp;